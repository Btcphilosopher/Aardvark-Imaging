-- Migration 001: Initial Schema Definition
-- Re-exports base schema definitions for migration tracking
\i database/schema.sql
\i database/seed.sql
