-- AARDVARK LIDAR Relational PostgreSQL Database Schema
-- Standard ISO-Compliant Point Cloud and Sensor State Persistence

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Projects
CREATE TABLE IF NOT EXISTS projects (
    project_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    active_coordinate_frame VARCHAR(64) DEFAULT 'sensor'
);

-- 2. Sensor Profiles
CREATE TABLE IF NOT EXISTS sensor_profiles (
    profile_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(128) NOT NULL,
    manufacturer VARCHAR(128) NOT NULL,
    model VARCHAR(128) NOT NULL,
    beam_count INT NOT NULL CHECK (beam_count > 0),
    rotation_rate_hz NUMERIC(6,2) NOT NULL DEFAULT 10.0,
    horizontal_fov_deg NUMERIC(6,2) NOT NULL DEFAULT 360.0,
    vertical_fov_deg NUMERIC(6,2) NOT NULL DEFAULT 45.0,
    min_range_m NUMERIC(8,3) NOT NULL DEFAULT 0.2,
    max_range_m NUMERIC(8,3) NOT NULL DEFAULT 120.0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 3. Sensors
CREATE TABLE IF NOT EXISTS sensors (
    sensor_id VARCHAR(64) PRIMARY KEY,
    project_id UUID REFERENCES projects(project_id) ON DELETE SET NULL,
    profile_id UUID REFERENCES sensor_profiles(profile_id),
    serial_number VARCHAR(128) NOT NULL UNIQUE,
    sensor_type VARCHAR(64) NOT NULL DEFAULT 'mechanical_spinning',
    firmware_version VARCHAR(64) DEFAULT 'v3.4.12',
    network_ip VARCHAR(64) DEFAULT '192.168.1.201',
    udp_port INT DEFAULT 2368,
    status VARCHAR(32) NOT NULL DEFAULT 'DISCONNECTED',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 4. Calibration Profiles
CREATE TABLE IF NOT EXISTS calibration_profiles (
    calibration_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sensor_id VARCHAR(64) REFERENCES sensors(sensor_id) ON DELETE CASCADE,
    version_tag VARCHAR(32) NOT NULL,
    range_offset_m NUMERIC(8,5) DEFAULT 0.0,
    range_scale NUMERIC(8,5) DEFAULT 1.0,
    azimuth_offset_rad NUMERIC(8,5) DEFAULT 0.0,
    elevation_offset_rad NUMERIC(8,5) DEFAULT 0.0,
    tx NUMERIC(8,4) DEFAULT 0.0,
    ty NUMERIC(8,4) DEFAULT 0.0,
    tz NUMERIC(8,4) DEFAULT 0.0,
    roll_rad NUMERIC(8,5) DEFAULT 0.0,
    pitch_rad NUMERIC(8,5) DEFAULT 0.0,
    yaw_rad NUMERIC(8,5) DEFAULT 0.0,
    transform_matrix_json JSONB NOT NULL,
    beam_corrections_json JSONB,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 5. Coordinate Frames & Transforms
CREATE TABLE IF NOT EXISTS coordinate_frames (
    frame_id VARCHAR(64) PRIMARY KEY,
    description TEXT,
    parent_frame_id VARCHAR(64) REFERENCES coordinate_frames(frame_id)
);

CREATE TABLE IF NOT EXISTS transforms (
    transform_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    parent_frame VARCHAR(64) REFERENCES coordinate_frames(frame_id),
    child_frame VARCHAR(64) REFERENCES coordinate_frames(frame_id),
    tx NUMERIC(8,4) NOT NULL,
    ty NUMERIC(8,4) NOT NULL,
    tz NUMERIC(8,4) NOT NULL,
    qx NUMERIC(8,6) NOT NULL,
    qy NUMERIC(8,6) NOT NULL,
    qz NUMERIC(8,6) NOT NULL,
    qw NUMERIC(8,6) NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 6. Recordings & Packet Streams
CREATE TABLE IF NOT EXISTS recordings (
    recording_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID REFERENCES projects(project_id) ON DELETE CASCADE,
    sensor_id VARCHAR(64) REFERENCES sensors(sensor_id),
    file_path TEXT NOT NULL,
    start_time TIMESTAMP WITH TIME ZONE NOT NULL,
    end_time TIMESTAMP WITH TIME ZONE,
    packet_count BIGINT DEFAULT 0,
    data_size_bytes BIGINT DEFAULT 0,
    sha256_checksum VARCHAR(64),
    status VARCHAR(32) DEFAULT 'RECORDING'
);

-- 7. Scans & Point Clouds
CREATE TABLE IF NOT EXISTS scans (
    scan_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID REFERENCES projects(project_id) ON DELETE CASCADE,
    sensor_id VARCHAR(64) REFERENCES sensors(sensor_id),
    calibration_id UUID REFERENCES calibration_profiles(calibration_id),
    timestamp_utc TIMESTAMP WITH TIME ZONE NOT NULL,
    point_count INT NOT NULL,
    ground_point_count INT DEFAULT 0,
    outlier_point_count INT DEFAULT 0,
    bounding_box_json JSONB,
    centroid_json JSONB,
    storage_path TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 8. Processing Jobs & Stages
CREATE TABLE IF NOT EXISTS processing_jobs (
    job_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID REFERENCES projects(project_id) ON DELETE CASCADE,
    scan_id UUID REFERENCES scans(scan_id),
    status VARCHAR(32) NOT NULL DEFAULT 'PENDING',
    pipeline_config_json JSONB NOT NULL,
    metrics_json JSONB,
    execution_time_ms NUMERIC(8,2),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP WITH TIME ZONE
);

-- 9. Maps & Accumulated Digital Scenes
CREATE TABLE IF NOT EXISTS maps (
    map_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID REFERENCES projects(project_id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    coordinate_frame VARCHAR(64) DEFAULT 'world',
    voxel_resolution_m NUMERIC(6,3) DEFAULT 0.05,
    total_points BIGINT DEFAULT 0,
    submap_count INT DEFAULT 0,
    quality_score NUMERIC(5,2),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 10. Spatial Measurements
CREATE TABLE IF NOT EXISTS measurements (
    measurement_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID REFERENCES projects(project_id) ON DELETE CASCADE,
    scan_id UUID REFERENCES scans(scan_id),
    measurement_type VARCHAR(64) NOT NULL,
    p1_json JSONB,
    p2_json JSONB,
    value NUMERIC(10,4) NOT NULL,
    unit VARCHAR(16) NOT NULL DEFAULT 'meters',
    uncertainty NUMERIC(6,4),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 11. Diagnostic Logs & Sensor Health
CREATE TABLE IF NOT EXISTS diagnostics (
    diagnostic_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sensor_id VARCHAR(64) REFERENCES sensors(sensor_id),
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    health_state VARCHAR(32) NOT NULL, -- HEALTHY, DEGRADED, WARNING, FAULT
    packet_rate_hz NUMERIC(8,2),
    packet_loss_pct NUMERIC(5,2),
    latency_ms NUMERIC(6,2),
    optical_temp_c NUMERIC(5,1),
    rpm_deviation_pct NUMERIC(5,2),
    invalid_point_pct NUMERIC(5,2),
    diagnostic_message TEXT
);

-- 12. Security & Audit Events
CREATE TABLE IF NOT EXISTS audit_events (
    event_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    actor VARCHAR(128) NOT NULL DEFAULT 'system_operator',
    event_type VARCHAR(64) NOT NULL,
    object_id VARCHAR(128),
    previous_state JSONB,
    new_state JSONB,
    correlation_id VARCHAR(64)
);

-- Indexes for high-frequency queries
CREATE INDEX IF NOT EXISTS idx_scans_sensor_time ON scans(sensor_id, timestamp_utc);
CREATE INDEX IF NOT EXISTS idx_diagnostics_sensor ON diagnostics(sensor_id, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON audit_events(timestamp DESC);
