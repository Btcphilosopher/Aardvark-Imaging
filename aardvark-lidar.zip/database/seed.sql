-- Initial Seed Dataset for Aardvark LiDAR System

INSERT INTO projects (project_id, name, description, active_coordinate_frame)
VALUES (
    'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11',
    'Industrial Facility Survey & SLAM',
    'Autonomous mobile robot inspection scan of heavy fabrication bay and assembly line.',
    'sensor'
) ON CONFLICT DO NOTHING;

INSERT INTO sensor_profiles (profile_id, name, manufacturer, model, beam_count, rotation_rate_hz, horizontal_fov_deg, vertical_fov_deg, min_range_m, max_range_m)
VALUES 
(
    'b0eebc99-9c0b-4ef8-bb6d-6bb9bd380a22',
    'Aardvark UltraBeam-64',
    'Aardvark Imaging',
    'AV-LIDAR-64HD',
    64,
    10.0,
    360.0,
    45.0,
    0.2,
    150.0
),
(
    'c0eebc99-9c0b-4ef8-bb6d-6bb9bd380a33',
    'Aardvark SolidState-128',
    'Aardvark Imaging',
    'AV-FLASHLIDAR-128',
    128,
    20.0,
    120.0,
    35.0,
    0.1,
    250.0
) ON CONFLICT DO NOTHING;

INSERT INTO coordinate_frames (frame_id, description, parent_frame_id)
VALUES 
('world', 'Global fixed geodetic/ENU reference frame', NULL),
('map', 'Continuous accumulated drift-free SLAM frame', 'world'),
('vehicle', 'Robot base frame at geometric chassis centroid', 'map'),
('sensor', 'LiDAR optical rotor center', 'vehicle')
ON CONFLICT DO NOTHING;

INSERT INTO audit_events (actor, event_type, object_id, new_state, correlation_id)
VALUES (
    'system_initializer',
    'database_initialized',
    'schema_v1',
    '{"status": "READY", "timestamp": "2026-09-13T00:00:00Z"}',
    'init_001'
);
