"""
End-to-End Ingestion, Decoding, Calibration, Filtering, and Mapping Integration Test.
"""
import pytest
import numpy as np
from aardvark_lidar.config.models import SensorConfig, SensorType
from aardvark_lidar.simulation.synthetic_lidar import SimulatedLidarSensor, SyntheticEnvironment
from aardvark_lidar.filtering.pipeline import FilterPipeline
from aardvark_lidar.mapping.slam_map.py import VoxelMapAccumulator
from aardvark_lidar.geometry.transforms import SE3Transform


def test_full_pipeline_stream_and_ground_extraction():
    cfg = SensorConfig(
        sensor_id="TEST-LIDAR-01",
        manufacturer="Aardvark",
        model="AV-64",
        serial_number="T01",
        sensor_type=SensorType.SIMULATED,
        beam_count=32
    )
    env = SyntheticEnvironment("industrial_warehouse")
    sensor = SimulatedLidarSensor(cfg, env)

    raw_cloud = sensor.generate_scan()
    assert len(raw_cloud) > 1000

    pipeline = FilterPipeline()
    filtered = pipeline.filter_range(raw_cloud, min_range=0.5, max_range=50.0)
    assert len(filtered) <= len(raw_cloud)

    ground, non_ground, plane = pipeline.ransac_ground_segmentation(filtered, distance_threshold=0.15)
    assert len(ground) > 0
    assert len(non_ground) > 0

    # Plane normal should point approximately along positive Z
    assert plane[2] > 0.90
