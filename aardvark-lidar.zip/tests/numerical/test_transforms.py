"""
Numerical Tests for SE(3) Rigid Transformations, Lie Group Inverses, and Vector Projections.
"""
import pytest
import numpy as np
from aardvark_lidar.geometry.transforms import SE3Transform, TransformGraph, TransformError


def test_se3_identity():
    t = SE3Transform.identity()
    assert np.allclose(t.rotation_matrix, np.eye(3))
    assert np.allclose(t.translation, np.zeros(3))


def test_se3_inverse_identity_property():
    """Verify that T * T^{-1} = I with tolerance 1e-7."""
    roll, pitch, yaw = 0.25, -0.42, 1.15
    trans = np.array([12.4, -3.8, 5.1])
    
    t = SE3Transform.from_euler(roll, pitch, yaw, trans)
    t_inv = t.inverse()
    composed = t.compose(t_inv)

    assert np.allclose(composed.rotation_matrix, np.eye(3), atol=1e-7)
    assert np.allclose(composed.translation, np.zeros(3), atol=1e-7)


def test_transform_points_exact():
    # 90-degree yaw rotation around Z: [1, 0, 0] -> [0, 1, 0]
    t = SE3Transform.from_euler(0.0, 0.0, np.pi / 2.0, np.array([2.0, 3.0, 1.0]))
    pts = np.array([[1.0, 0.0, 0.0]])
    transformed = t.transform_points(pts)

    expected = np.array([[2.0, 4.0, 1.0]]) # [0, 1, 0] + [2, 3, 1]
    assert np.allclose(transformed, expected, atol=1e-5)


def test_transform_graph_resolution():
    graph = TransformGraph()
    # world -> vehicle
    t_world_veh = SE3Transform.from_euler(0.0, 0.0, 0.0, np.array([10.0, 0.0, 0.0]))
    # vehicle -> sensor
    t_veh_sens = SE3Transform.from_euler(0.0, 0.0, 0.0, np.array([0.0, 0.0, 1.8]))

    graph.add_transform("world", "vehicle", t_world_veh)
    graph.add_transform("vehicle", "sensor", t_veh_sens)

    t_resolved = graph.resolve("world", "sensor")
    assert np.allclose(t_resolved.translation, np.array([10.0, 0.0, 1.8]))
