"""
Numerical Tests for 3D KD-Tree and SVD ICP Scan Registration.
"""
import pytest
import numpy as np
from aardvark_lidar.spatial.kdtree import KDTree3D
from aardvark_lidar.registration.icp import PointToPointICP
from aardvark_lidar.pointcloud.pointcloud import PointCloud
from aardvark_lidar.geometry.transforms import SE3Transform


def test_kdtree_nearest_neighbor_exact():
    points = np.array([
        [0.0, 0.0, 0.0],
        [1.0, 0.0, 0.0],
        [0.0, 1.0, 0.0],
        [10.0, 10.0, 10.0]
    ], dtype=np.float32)

    tree = KDTree3D(points)
    query = np.array([0.9, 0.1, 0.0], dtype=np.float32)

    idx, dist = tree.nearest_neighbor(query)
    assert idx == 1
    assert np.isclose(dist, np.sqrt((0.9-1.0)**2 + 0.1**2), atol=1e-5)


def test_icp_recovers_known_rigid_transform():
    """Verify SVD ICP accurately recovers a known SE(3) rotation and translation offset."""
    # Synthetic target geometry (box corners)
    np.random.seed(42)
    target_pts = np.random.uniform(-5.0, 5.0, size=(100, 3)).astype(np.float32)
    target_cloud = PointCloud.empty()
    target_cloud.points = target_pts

    # Ground truth transform: 5-degree yaw + [0.15, -0.10, 0.05] translation
    gt_yaw = np.radians(5.0)
    gt_trans = np.array([0.15, -0.10, 0.05], dtype=np.float64)
    gt_transform = SE3Transform.from_euler(0.0, 0.0, gt_yaw, gt_trans)

    # Source is inverse-transformed target
    src_pts = gt_transform.inverse().transform_points(target_pts).astype(np.float32)
    source_cloud = PointCloud.empty()
    source_cloud.points = src_pts

    icp = PointToPointICP(max_iterations=40, max_correspondence_distance=1.0)
    result = icp.register(source_cloud, target_cloud)

    assert result.converged
    assert result.residual_rmse < 0.01
    assert np.allclose(result.transform.translation, gt_trans, atol=0.02)
