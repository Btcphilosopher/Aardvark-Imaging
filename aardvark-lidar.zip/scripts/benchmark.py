#!/usr/bin/env python3
"""Run performance and throughput benchmarks for AARDVARK LiDAR."""
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../python")))

from aardvark_lidar.cli import cmd_benchmark
import argparse

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="AARDVARK LiDAR Benchmark Runner")
    args = parser.parse_args()
    cmd_benchmark(args)
