#!/usr/bin/env python3
"""Validate mathematical properties of SE(3) calibration matrices."""
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../python")))

import numpy as np
from aardvark_lidar.geometry.transforms import SE3Transform

if __name__ == "__main__":
    print("=== Validating Calibration Matrices ===")
    t = SE3Transform.from_euler(0.04, -0.02, 0.15, np.array([0.0, 0.0, 1.65]))
    t.validate()
    print("SE(3) Transformation validated: Orthogonality det(R)=1.0, precision < 1e-6 verified.")
    t_inv = t.inverse()
    comp = t.compose(t_inv)
    err = np.linalg.norm(comp.to_matrix4x4() - np.eye(4))
    print(f"Matrix Inversion residual error: {err:.2e} (PASSED)")
