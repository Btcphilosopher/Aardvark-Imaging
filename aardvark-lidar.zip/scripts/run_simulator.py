#!/usr/bin/env python3
"""Run real-time synthetic LiDAR environment simulator."""
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../python")))

from aardvark_lidar.cli import cmd_simulate
import argparse

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="AARDVARK LiDAR Simulator Runner")
    parser.add_argument("--scenario", default="industrial_warehouse")
    parser.add_argument("--beams", type=int, default=64)
    parser.add_argument("--rpm", type=int, default=600)
    parser.add_argument("--output", type=str, default="data/synthetic/sample_scan.ply")
    args = parser.parse_args()
    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    cmd_simulate(args)
