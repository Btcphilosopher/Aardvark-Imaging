# REST & WebSocket API Specification

## 1. Overview
The AARDVARK LIDAR platform provides high-throughput HTTP/JSON endpoints and WebSocket binary streaming for real-time sensor control, scan retrieval, calibration adjustment, and perception execution.

### Sensor Management
* `GET /api/sensors`: List registered LiDAR sensors and hardware adapters.
* `POST /api/sensors`: Register a new sensor configuration.
* `POST /api/sensors/{id}/connect`: Open UDP socket / device stream.
* `POST /api/sensors/{id}/disconnect`: Graceful stream termination.
* `POST /api/sensors/{id}/start`: Begin acquisition loop.
* `POST /api/sensors/{id}/stop`: Halt acquisition loop.
* `GET /api/sensors/{id}/status`: Retrieve real-time telemetry (RPM, temp, packet rate, loss rate, jitter).

### Scans & Point Clouds
* `GET /api/scans`: List accumulated scan frames.
* `GET /api/scans/{id}`: Retrieve point cloud payload (AoS binary or structured JSON).
* `POST /api/scans/simulate`: Step the synthetic physics environment and produce calibrated scan frames.

### Calibration & Transforms
* `GET /api/calibration`: Retrieve active calibration profiles and SE(3) transform tree.
* `POST /api/calibration`: Submit new calibration matrix or beam pitch/roll offsets.

### Recording & Replay
* `POST /api/recordings/start`: Begin raw packet capture to disk with SHA256 checksum tracking.
* `POST /api/recordings/stop`: Finalize recording manifest.
* `POST /api/recordings/{id}/replay`: Replay raw packets with adjustable playback rate ($0.1\times - 10\times$).

### Diagnostics & Metrics
* `GET /api/diagnostics`: Full system diagnostics and failure modes.
* `GET /api/metrics`: Prometheus-compatible latency, throughput, and error counters.
