# Point Cloud Binary Formats & Schema Specification

## 1. Internal Point Schema
Each 3D LiDAR point is encoded using a contiguous 48-byte memory layout (AoS) and vectorized columnar arrays (SoA) for SIMD acceleration:

| Field | Type | Unit / Range | Description |
| :--- | :--- | :--- | :--- |
| `x` | `float32` | meters | Forward coordinate in target frame |
| `y` | `float32` | meters | Lateral coordinate in target frame |
| `z` | `float32` | meters | Vertical coordinate in target frame |
| `intensity` | `float32` | 0.0 - 255.0 | Optical retro-reflectivity |
| `range` | `float32` | meters | Unprojected radial distance |
| `azimuth` | `float32` | radians | Rotor azimuth angle |
| `elevation` | `float32` | radians | Laser emitter elevation angle |
| `timestamp` | `float64` | seconds | Unix UTC epoch time |
| `ring` | `uint16` | 0 - 127 | Emitter laser channel ID |
| `return_num`| `uint8` | 1 - 3 | Echo index (1=first, 2=strongest, 3=last) |
| `flags` | `uint8` | bitmask | Ground (0x01), Outlier (0x02), Valid (0x04) |
| `cluster_id`| `int16` | -1 or ID | Euclidean cluster index |
| `packet_id` | `uint32` | counter | Ingested source packet identifier |

## 2. Supported Export Adapters
* **Polygon File Format (PLY)**: Header with float32 properties, ASCII and Little-Endian Binary formats.
* **Point Cloud Data (PCD)**: Version 0.7 ASCII/binary with structured metadata headers.
* **LAS / LAZ**: ASPRS standard LiDAR point data record formats (Format 0/1/2/3).
* **Comma Separated Values (CSV)**: Precision tabular dump for scientific tooling.
