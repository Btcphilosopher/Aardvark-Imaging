# AARDVARK LIDAR System Architecture

## 1. Executive Summary
AARDVARK LIDAR is a computational imaging and 3D perception platform engineered for high-bandwidth time-of-flight (ToF) LiDAR sensors. The architecture separates the real-time sensor ingestion and calibration domain from the spatial geometry, map accumulation, and perception analysis engines.

```
+-------------------------------------------------------------------------+
|                              PHYSICAL LAYER                             |
|  +---------------------+   +---------------------+   +---------------+  |
|  | Physical UDP Sensor |   | Recorded Packet File|   | Synthetic Sim |  |
|  +----------+----------+   +----------+----------+   +-------+-------+  |
+-------------|-------------------------|----------------------|----------+
              v                         v                      v
+-------------------------------------------------------------------------+
|                            INGESTION & DECODE                           |
|  +-------------------------------------------------------------------+  |
|  | SensorAdapter Interface (connect, stream, read_packet, status)     |  |
|  +-----------------------------------+-------------------------------+  |
|                                      v                                  |
|  +-------------------------------------------------------------------+  |
|  | PacketDecoder: Dual-return extraction, azimuth/elevation, ranges  |  |
|  | TimeSynchronizer: Sensor clock -> Host monotonic -> UTC (offset)  |  |
|  +-----------------------------------+-------------------------------+  |
+--------------------------------------|----------------------------------+
                                       v
+-------------------------------------------------------------------------+
|                        GEOMETRY & CALIBRATION SE(3)                     |
|  +-------------------------------------------------------------------+  |
|  | Spherical to Cartesian: x=r*cos(φ)*cos(θ), y=r*cos(φ)*sin(θ), z=..|  |
|  | CalibrationProfile: Per-beam Δθ, Δφ, Range Scale s, Range Offset d|  |
|  | TransformGraph: Rigid Body T_world_sensor ∈ SE(3) [R|t]           |  |
|  +-----------------------------------+-------------------------------+  |
+--------------------------------------|----------------------------------+
                                       v
+-------------------------------------------------------------------------+
|                      POINT CLOUD PROCESSING PIPELINE                    |
|  +-------------------------------------------------------------------+  |
|  | PointCloud Engine: AoS / SoA float32 coordinate & attribute array |  |
|  | Pass-Through & ROI Cropping: [x_min, x_max, y_min, y_max, z_min..]|  |
|  | Statistical Outlier Removal (SOR): k-NN mean distance filter     |  |
|  | Voxel Downsampler: 3D regular grid centroid decimation            |  |
|  | Ground Segmenter: RANSAC Plane fitting ax + by + cz + d = 0       |  |
|  +-----------------------------------+-------------------------------+  |
+--------------------------------------|----------------------------------+
                                       v
+-------------------------------------------------------------------------+
|                         REGISTRATION & MAPPING                          |
|  +-------------------------------------------------------------------+  |
|  | Point-to-Point ICP with Kabsch / SVD closed-form rotation solve  |  |
|  | PoseGraph & Odometry Accumulation: T_map_sensor(t)               |  |
|  | Voxel Map Accumulator & Submap Keyframe Buffers                   |  |
|  +-----------------------------------+-------------------------------+  |
+--------------------------------------|----------------------------------+
                                       v
+-------------------------------------------------------------------------+
|                         PERCEPTION & ANALYTICS                          |
|  +-------------------------------------------------------------------+  |
|  | Euclidean Clustering: 3D Connected Components & Bounding Boxes    |  |
|  | Measurement Caliper: 3D Point-to-Point, Point-to-Plane, Volumes  |  |
|  | Health Monitor: Packet loss, jitter, RPM deviation, thermal check |  |
|  | Storage & Export: PostgreSQL metadata, PLY / PCD / LAS outputs   |  |
|  +-------------------------------------------------------------------+  |
+-------------------------------------------------------------------------+
```

## 2. Ingestion & Provenance Guarantee
Raw UDP packets are strictly immutable. Every single reconstructed 3D point retains provenance attributes linking it back to the exact `packet_id`, `beam_id`, `source_timestamp`, `sensor_id`, and `calibration_version_id`.
