# Network Packet Processing & Decoding Architecture

## 1. UDP Packet Layout
A standard spinning mechanical or solid-state LiDAR packet consists of:
- **Packet Header (42 bytes)**: Magic identifier (0xA456), Sensor Serial, Model ID, Protocol Version, Packet Sequence, Sensor Hardware Timestamp, Diagnostic Flags.
- **Data Blocks (12 to 24 blocks per packet)**:
  - Block Header: Block Azimuth (0.01° resolution), Block Flag.
  - Channel Measurements (16, 32, 64, or 128 channels):
    - 2-byte Unsigned Integer: Range ($2\,\text{mm}$ resolution)
    - 1-byte Unsigned Integer: Calibrated Intensity (0-255)
    - 1-byte Unsigned Integer: Beam Echo / Multi-return status
- **Packet Tail (16 bytes)**: Sensor RPM, Optical Temperature ($0.1^\circ\text{C}$), Return Mode (Single/Dual), Monotonic Host Counter, Checksum (CRC32).

## 2. Ingestion Ring Buffer & Zero-Copy Protocol
Incoming UDP socket packets are pushed to a lock-free circular ring buffer with pre-allocated 64MB buffers. The worker threads decode azimuths, look up per-beam elevation lookup tables (LUT), and project spherical coordinates into Cartesian space using SIMD vectorized matrix operations.
