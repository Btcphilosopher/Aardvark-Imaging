# LiDAR SLAM, Odometry & Map Accumulation

## 1. Scan-to-Scan ICP Registration
Given Source Point Cloud $\mathcal{P} = \{\mathbf{p}_i\}_{i=1}^{N}$ and Target Reference Cloud $\mathcal{Q} = \{\mathbf{q}_j\}_{j=1}^{M}$:
1. **Nearest Neighbor Search**: For each point $\mathbf{p}_i$, find closest $\mathbf{q}_i \in \mathcal{Q}$ using KD-tree acceleration. Reject matches with $\|\mathbf{p}_i - \mathbf{q}_i\| > d_{\max}$.
2. **Centroid Computation**:
   $$\bar{\mathbf{p}} = \frac{1}{K} \sum_{k=1}^K \mathbf{p}_k, \quad \bar{\mathbf{q}} = \frac{1}{K} \sum_{k=1}^K \mathbf{q}_k$$
3. **Cross-Covariance Matrix**:
   $$\mathbf{H} = \sum_{k=1}^K (\mathbf{p}_k - \bar{\mathbf{p}})(\mathbf{q}_k - \bar{\mathbf{q}})^T$$
4. **Singular Value Decomposition (Kabsch Algorithm)**:
   $$\mathbf{H} = \mathbf{U} \mathbf{\Sigma} \mathbf{V}^T \implies \mathbf{R}^* = \mathbf{V} \begin{bmatrix} 1 & 0 & 0 \\ 0 & 1 & 0 \\ 0 & 0 & \det(\mathbf{V}\mathbf{U}^T) \end{bmatrix} \mathbf{U}^T$$
   $$\mathbf{t}^* = \bar{\mathbf{q}} - \mathbf{R}^* \bar{\mathbf{p}}$$
5. **Iteration & Convergence**: Repeat until $\|\Delta \mathbf{t}\| < \epsilon_t$ and $\|\Delta \mathbf{R} - \mathbf{I}\|_F < \epsilon_R$ or max iterations reached.

## 2. Multi-Scan Voxel Map Accumulation
Keyframe scans are transformed into the world frame via accumulated estimated poses $\mathbf{T}_{map\_sensor}(t)$. A global 3D sparse voxel hash table filters redundant points within $V_{\text{size}} = 0.05\,\text{m}$ to prevent unbounded memory growth while retaining fine structural details.
