# LiDAR Physical Sensor Model & Timing Architecture

## 1. Spherical Measurement Model
A pulsed time-of-flight LiDAR sensor measures target range $r$, horizontal azimuth angle $\theta$, and vertical elevation angle $\phi$.

The uncalibrated measurement tuple is:
$$m = (\tau, \text{sensor\_id}, \text{packet\_id}, \text{beam\_id}, \theta, \phi, r, I, k, \text{status})$$
where:
- $\tau$: Sensor hardware timestamp ($\mu s$ resolution)
- $\theta \in [0, 2\pi)$: Current emitter rotor azimuth
- $\phi \in [-\pi/2, \pi/2]$: Fixed optical vertical beam elevation
- $r \in [r_{\min}, r_{\max}]$: Time-of-flight range ($r = \frac{c \cdot \Delta t}{2}$)
- $I \in [0, 255]$: Calibrated retro-reflective intensity
- $k \in \{1, 2, \dots\}$: Return index (strongest, last, dual)

## 2. Multi-Domain Time Synchronization
To ensure determinism across multi-sensor robotic platforms, timestamps are tracked in four distinct domains:
1. **Sensor Hardware Clock ($T_{\text{sensor}}$)**: Internal oscillator counter (PTP/GPS synchronized or monotonic rollover).
2. **Host Ingestion Clock ($T_{\text{host}}$)**: Monotonic timestamp taken by NIC interrupt handler upon packet receipt.
3. **UTC Processing Time ($T_{\text{UTC}}$)**: Coordinated Universal Time with nanosecond epoch representation.
4. **Calculated Clock Offset ($\Delta(t)$)**: Derived via linear regression filtering over packet sequence intervals.
