# Spatial Calibration & Rigid SE(3) Transformations

## 1. Intrinsic Optical Calibration
For beam $i$, the corrected range $r'$, azimuth $\theta'$, and elevation $\phi'$ are modeled as:
$$r'_i = s_i \cdot r_i + d_i$$
$$\theta'_i = \theta + \Delta \theta_i$$
$$\phi'_i = \phi_i + \Delta \phi_i$$
where $s_i$ is range scale factor, $d_i$ is range distance offset, $\Delta \theta_i$ is rotational encoder azimuth offset, and $\Delta \phi_i$ is beam pitch misalignment.

## 2. Extrinsic SE(3) Rigid Transformations
The pose of the sensor frame $\{S\}$ relative to coordinate frame $\{A\}$ is parameterized by the Special Euclidean Group $\mathbf{T}_{A\_S} \in \mathrm{SE}(3)$:
$$\mathbf{T}_{A\_S} = \begin{bmatrix} \mathbf{R} & \mathbf{t} \\ \mathbf{0}^T & 1 \end{bmatrix} \in \mathbb{R}^{4 \times 4}$$
where $\mathbf{R} \in \mathrm{SO}(3)$ ($\mathbf{R}^T \mathbf{R} = \mathbf{I}, \det(\mathbf{R}) = 1$) is the rotation matrix, and $\mathbf{t} = [t_x, t_y, t_z]^T \in \mathbb{R}^3$ is translation.

For point $\mathbf{p}_S = [x_S, y_S, z_S]^T$:
$$\begin{bmatrix} \mathbf{p}_A \\ 1 \end{bmatrix} = \mathbf{T}_{A\_S} \begin{bmatrix} \mathbf{p}_S \\ 1 \end{bmatrix} = \begin{bmatrix} \mathbf{R} \mathbf{p}_S + \mathbf{t} \\ 1 \end{bmatrix}$$

## 3. Transformation Inversion & Composition
$$\mathbf{T}_{A\_S}^{-1} = \begin{bmatrix} \mathbf{R}^T & -\mathbf{R}^T \mathbf{t} \\ \mathbf{0}^T & 1 \end{bmatrix}$$
$$\mathbf{T}_{C\_S} = \mathbf{T}_{C\_B} \cdot \mathbf{T}_{B\_A} \cdot \mathbf{T}_{A\_S}$$
All matrix compositions are strictly verified for orthogonality with residual tolerance $\epsilon \le 10^{-6}$.
