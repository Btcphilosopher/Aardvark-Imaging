# AARDVARK LIDAR
## Production-Grade LiDAR Sensor, Point-Cloud and 3D Perception Platform

AARDVARK LIDAR is an open-architecture computational LiDAR imaging and 3D perception platform. It delivers deterministic sensor packet decoding, rigorous spatial calibration via $\mathrm{SE}(3)$ Lie-group transforms, robust point-cloud filtering, KD-tree accelerated spatial indexing, RANSAC ground segmentation, SVD-based ICP scan matching, SLAM map accumulation, digital twin scene synthesis, and analytical measurement instrumentation.

---

### Core Pipeline

```
PHYSICAL LIDAR / SIMULATOR
           ↓
   SENSOR ADAPTER (UDP / Mock / File / ROS 2)
           ↓
 RAW PACKETS (Binary payload, Telemetry)
           ↓
     PACKET DECODER (Azimuth, Elevation, Spherical coords)
           ↓
      TIME SYNCHRONIZER (Sensor / Host / UTC domain alignment)
           ↓
  CALIBRATION ENGINE (SE(3) rigid matrices, beam angle offsets)
           ↓
   3D POINT GENERATION (Cartesian XYZ, Intensity, Beam Ring, Return)
           ↓
   SPATIAL FILTERING (Pass-through, SOR, ROR, Voxel Downsampling)
           ↓
  GROUND SEGMENTATION (RANSAC 3D Plane, Normal estimation)
           ↓
 REGISTRATION & ODOMETRY (Point-to-Point ICP with Kabsch / SVD)
           ↓
  MAP ACCUMULATION (Voxel SLAM Map, Keyframes, Pose Graph)
           ↓
 DIGITAL TWIN & OBJECT DETECTOR (Euclidean Clustering, 3D Bounding Boxes)
           ↓
ANALYTICS, MEASUREMENT & EXPORT (PLY / PCD / CSV / LAS)
```

---

### Repository Layout

* **`python/aardvark_lidar/`**: Python core reference implementation, API layer, calibration mathematics, numerical tests, and simulation engine.
* **`rust/`**: High-throughput memory-safe packet buffers, spatial KD-trees, voxel filters, and SVD ICP registration primitives.
* **`kotlin/`**: Multiplatform desktop operator workstation interfaces and acquisition pipelines.
* **`src/`**: Interactive high-performance WebGL / Three.js 3D operator station and real-time computation engine.
* **`database/`**: PostgreSQL relational schemas, migrations, and seed datasets for projects, scans, calibrations, and audit logs.
* **`docs/`**: Comprehensive mathematical and engineering documentation.
* **`scripts/`**: CLI entry points for simulation, benchmarking, calibration validation, and dataset generation.

---

### License
Apache-2.0 License.
