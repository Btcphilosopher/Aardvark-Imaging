package com.aardvark.imaging.lidar

import com.aardvark.imaging.lidar.model.SensorConfig
import com.aardvark.imaging.lidar.acquisition.SensorClient

fun main() {
    println("==================================================")
    println("  AARDVARK LIDAR - 3D Perception & Operator Engine")
    println("  Version: 1.0.0 (Enterprise)")
    println("==================================================")
    
    val config = SensorConfig(
        sensorId = "AV-LIDAR-001",
        manufacturer = "Aardvark Imaging Systems",
        model = "AV-64HD",
        beamCount = 64,
        rotationRateHz = 10.0
    )
    
    val client = SensorClient(config)
    client.connect()
    client.startStream()
    println("Operator workstation pipeline active. Streaming live 3D telemetry...")
}
