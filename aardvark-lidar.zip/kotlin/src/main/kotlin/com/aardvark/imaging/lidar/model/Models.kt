package com.aardvark.imaging.lidar.model

data class SensorConfig(
    val sensorId: String,
    val manufacturer: String,
    val model: String,
    val beamCount: Int,
    val rotationRateHz: Double = 10.0,
    val horizontalFovDeg: Double = 360.0,
    val verticalFovDeg: Double = 45.0,
    val minRangeMeters: Double = 0.2,
    val maxRangeMeters: Double = 150.0
)

data class PointXYZI(
    val x: Float,
    val y: Float,
    val z: Float,
    val intensity: Float,
    val range: Float,
    val ring: Int,
    val timestamp: Double
)

enum class SensorState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    STREAMING,
    ERROR
}
