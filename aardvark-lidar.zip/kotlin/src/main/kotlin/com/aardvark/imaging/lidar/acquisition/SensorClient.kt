package com.aardvark.imaging.lidar.acquisition

import com.aardvark.imaging.lidar.model.SensorConfig
import com.aardvark.imaging.lidar.model.SensorState

class SensorClient(private val config: SensorConfig) {
    var state: SensorState = SensorState.DISCONNECTED
        private set

    fun connect(): Boolean {
        println("[SensorClient] Opening UDP telemetry socket on port 2368...")
        state = SensorState.CONNECTED
        return true
    }

    fun startStream() {
        if (state == SensorState.CONNECTED) {
            state = SensorState.STREAMING
            println("[SensorClient] Acquisition pipeline streaming at ${config.rotationRateHz} Hz (${config.beamCount} beams)")
        }
    }

    fun stopStream() {
        state = SensorState.CONNECTED
        println("[SensorClient] Stream stopped.")
    }

    fun disconnect() {
        state = SensorState.DISCONNECTED
        println("[SensorClient] Disconnected.")
    }
}
