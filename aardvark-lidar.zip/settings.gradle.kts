rootProject.name = "aardvark-lidar-desktop"
