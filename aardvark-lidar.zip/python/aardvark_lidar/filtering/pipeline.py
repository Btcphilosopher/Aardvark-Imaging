"""
Point Cloud Filtering & Ground Extraction Pipeline.
"""
from dataclasses import dataclass
import time
from typing import Dict, List, Optional, Tuple, Any
import numpy as np
from aardvark_lidar.pointcloud.pointcloud import PointCloud
from aardvark_lidar.spatial.kdtree import KDTree3D


@dataclass
class FilterMetrics:
    filter_name: str
    input_points: int
    output_points: int
    removed_points: int
    duration_ms: float


class FilterPipeline:
    """Composable LiDAR filtering and segmentation engine."""
    def __init__(self):
        self.metrics_history: List[FilterMetrics] = []

    def filter_range(self, cloud: PointCloud, min_range: float = 0.3, max_range: float = 100.0) -> PointCloud:
        t0 = time.perf_counter()
        mask = (cloud.ranges >= min_range) & (cloud.ranges <= max_range)
        # Also clean NaNs/Infs
        valid_xyz = ~np.isnan(cloud.points).any(axis=1) & ~np.isinf(cloud.points).any(axis=1)
        mask = mask & valid_xyz
        out = cloud.apply_mask(mask)
        self.metrics_history.append(FilterMetrics(
            "RangeFilter", len(cloud), len(out), len(cloud) - len(out), (time.perf_counter() - t0) * 1000.0
        ))
        return out

    def filter_roi(self, cloud: PointCloud, bounds: Tuple[float, float, float, float, float, float]) -> PointCloud:
        """bounds: (x_min, x_max, y_min, y_max, z_min, z_max)"""
        t0 = time.perf_counter()
        x_min, x_max, y_min, y_max, z_min, z_max = bounds
        pts = cloud.points
        mask = (pts[:, 0] >= x_min) & (pts[:, 0] <= x_max) & \
               (pts[:, 1] >= y_min) & (pts[:, 1] <= y_max) & \
               (pts[:, 2] >= z_min) & (pts[:, 2] <= z_max)
        out = cloud.apply_mask(mask)
        self.metrics_history.append(FilterMetrics(
            "ROIFilter", len(cloud), len(out), len(cloud) - len(out), (time.perf_counter() - t0) * 1000.0
        ))
        return out

    def voxel_downsample(self, cloud: PointCloud, voxel_size: float = 0.05) -> PointCloud:
        """3D spatial voxel hash grid downsampling."""
        t0 = time.perf_counter()
        if len(cloud) == 0:
            return cloud

        pts = cloud.points
        # Quantize points to integer voxel keys
        voxel_indices = np.floor(pts / voxel_size).astype(np.int32)
        # Unique voxel keys
        _, unique_indices = np.unique(voxel_indices, axis=0, return_index=True)
        out = cloud.apply_mask(unique_indices)
        self.metrics_history.append(FilterMetrics(
            "VoxelDownsample", len(cloud), len(out), len(cloud) - len(out), (time.perf_counter() - t0) * 1000.0
        ))
        return out

    def ransac_ground_segmentation(
        self,
        cloud: PointCloud,
        distance_threshold: float = 0.12,
        max_iterations: int = 150,
        slope_limit_deg: float = 15.0
    ) -> Tuple[PointCloud, PointCloud, Tuple[float, float, float, float]]:
        """
        RANSAC 3D Plane fitting for ground surface extraction:
        Plane equation: ax + by + cz + d = 0, where [a, b, c] is unit normal.
        """
        t0 = time.perf_counter()
        pts = cloud.points
        n = len(pts)
        if n < 3:
            return PointCloud.empty(), cloud, (0.0, 0.0, 1.0, 0.0)

        best_inliers = np.zeros(n, dtype=bool)
        best_plane = (0.0, 0.0, 1.0, 0.0)
        max_inlier_count = 0

        # Candidate selection focused on lower z points
        z_thresh = np.percentile(pts[:, 2], 30)
        candidate_indices = np.where(pts[:, 2] <= z_thresh)[0]
        if len(candidate_indices) < 3:
            candidate_indices = np.arange(n)

        for _ in range(max_iterations):
            sample_idx = np.random.choice(candidate_indices, 3, replace=False)
            p1, p2, p3 = pts[sample_idx[0]], pts[sample_idx[1]], pts[sample_idx[2]]

            # Normal vector from cross product
            v1 = p2 - p1
            v2 = p3 - p1
            normal = np.cross(v1, v2)
            norm = np.linalg.norm(normal)
            if norm < 1e-6:
                continue
            normal = normal / norm

            # Ensure normal points upwards (positive z)
            if normal[2] < 0:
                normal = -normal

            # Check slope angle relative to vertical z-axis [0, 0, 1]
            slope_angle = np.degrees(np.arccos(np.clip(normal[2], -1.0, 1.0)))
            if slope_angle > slope_limit_deg:
                continue

            d = -np.dot(normal, p1)

            # Distance of all points to plane: |ax + by + cz + d|
            distances = np.abs(pts @ normal + d)
            inliers = distances <= distance_threshold
            count = np.count_nonzero(inliers)

            if count > max_inlier_count:
                max_inlier_count = count
                best_inliers = inliers
                best_plane = (float(normal[0]), float(normal[1]), float(normal[2]), float(d))

        ground_cloud = cloud.apply_mask(best_inliers)
        non_ground_cloud = cloud.apply_mask(~best_inliers)
        
        # Mark ground flags
        ground_cloud.flags[:] |= 0x01

        self.metrics_history.append(FilterMetrics(
            "RANSACGround", n, len(ground_cloud), len(non_ground_cloud), (time.perf_counter() - t0) * 1000.0
        ))
        return ground_cloud, non_ground_cloud, best_plane
