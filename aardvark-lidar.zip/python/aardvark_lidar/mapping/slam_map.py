"""
LiDAR SLAM Map Accumulation & Keyframe Pose Graph Engine.
"""
from dataclasses import dataclass, field
import uuid
import time
from typing import Dict, List, Optional
import numpy as np
from aardvark_lidar.geometry.transforms import SE3Transform
from aardvark_lidar.pointcloud.pointcloud import PointCloud
from aardvark_lidar.filtering.pipeline import FilterPipeline


@dataclass
class Keyframe:
    frame_id: str
    timestamp_utc: float
    pose_world_sensor: SE3Transform
    point_cloud: PointCloud


class VoxelMapAccumulator:
    """Accumulates point clouds in global world frame with voxel grid regularization."""
    def __init__(self, voxel_size_m: float = 0.05, max_stored_points: int = 500_000):
        self.voxel_size_m = voxel_size_m
        self.max_stored_points = max_stored_points
        self.keyframes: List[Keyframe] = []
        self.accumulated_cloud: PointCloud = PointCloud.empty()
        self.filter_engine = FilterPipeline()

    def add_scan(self, scan: PointCloud, pose: SE3Transform, timestamp: float) -> None:
        keyframe_id = f"kf_{uuid.uuid4().hex[:8]}"
        
        # Transform scan points into world frame
        world_pts = pose.transform_points(scan.points)
        transformed_cloud = PointCloud(
            points=world_pts,
            intensity=scan.intensity,
            ranges=scan.ranges,
            azimuths=scan.azimuths,
            elevations=scan.elevations,
            rings=scan.rings,
            timestamps=scan.timestamps,
            flags=scan.flags,
            cluster_ids=scan.cluster_ids
        )

        kf = Keyframe(
            frame_id=keyframe_id,
            timestamp_utc=timestamp,
            pose_world_sensor=pose,
            point_cloud=transformed_cloud
        )
        self.keyframes.append(kf)

        # Merge with accumulated world cloud
        if len(self.accumulated_cloud) == 0:
            self.accumulated_cloud = transformed_cloud
        else:
            merged_pts = np.vstack((self.accumulated_cloud.points, transformed_cloud.points))
            merged_intensity = np.concatenate((self.accumulated_cloud.intensity, transformed_cloud.intensity))
            merged_ranges = np.concatenate((self.accumulated_cloud.ranges, transformed_cloud.ranges))
            merged_azimuths = np.concatenate((self.accumulated_cloud.azimuths, transformed_cloud.azimuths))
            merged_elevations = np.concatenate((self.accumulated_cloud.elevations, transformed_cloud.elevations))
            merged_rings = np.concatenate((self.accumulated_cloud.rings, transformed_cloud.rings))
            merged_ts = np.concatenate((self.accumulated_cloud.timestamps, transformed_cloud.timestamps))
            merged_flags = np.concatenate((self.accumulated_cloud.flags, transformed_cloud.flags))
            merged_clusters = np.concatenate((self.accumulated_cloud.cluster_ids, transformed_cloud.cluster_ids))

            raw_merged = PointCloud(
                points=merged_pts,
                intensity=merged_intensity,
                ranges=merged_ranges,
                azimuths=merged_azimuths,
                elevations=merged_elevations,
                rings=merged_rings,
                timestamps=merged_ts,
                flags=merged_flags,
                cluster_ids=merged_clusters
            )

            # Apply voxel downsample to maintain sparse representation
            self.accumulated_cloud = self.filter_engine.voxel_downsample(raw_merged, self.voxel_size_m)

    def get_map_cloud(self) -> PointCloud:
        return self.accumulated_cloud
