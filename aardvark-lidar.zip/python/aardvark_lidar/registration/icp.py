"""
Iterative Closest Point (ICP) Scan-to-Scan Registration Engine.
"""
from dataclasses import dataclass
import time
from typing import Optional, Tuple
import numpy as np
from aardvark_lidar.geometry.transforms import SE3Transform
from aardvark_lidar.pointcloud.pointcloud import PointCloud
from aardvark_lidar.spatial.kdtree import KDTree3D


@dataclass
class ICPResult:
    transform: SE3Transform
    fitness_score: float
    inlier_count: int
    iterations: int
    converged: bool
    residual_rmse: float
    duration_ms: float


class PointToPointICP:
    """Rigid scan registration using SVD (Kabsch algorithm) with KD-tree correspondences."""
    def __init__(
        self,
        max_iterations: int = 30,
        max_correspondence_distance: float = 0.5,
        translation_epsilon: float = 1e-4,
        rotation_epsilon: float = 1e-4,
        fitness_threshold: float = 0.8
    ):
        self.max_iterations = max_iterations
        self.max_correspondence_distance = max_correspondence_distance
        self.translation_epsilon = translation_epsilon
        self.rotation_epsilon = rotation_epsilon
        self.fitness_threshold = fitness_threshold

    def register(self, source: PointCloud, target: PointCloud, initial_transform: Optional[SE3Transform] = None) -> ICPResult:
        t0 = time.perf_counter()
        if len(source) < 6 or len(target) < 6:
            return ICPResult(
                transform=SE3Transform.identity(),
                fitness_score=0.0,
                inlier_count=0,
                iterations=0,
                converged=False,
                residual_rmse=999.0,
                duration_ms=(time.perf_counter() - t0) * 1000.0
            )

        # Build KD-tree on target point cloud
        kdtree = KDTree3D(target.points)

        current_transform = initial_transform if initial_transform else SE3Transform.identity()
        src_pts = np.copy(source.points)

        converged = False
        iteration = 0
        final_rmse = 0.0
        inlier_count = 0

        for it in range(self.max_iterations):
            iteration = it + 1
            # Transform source points with current estimate
            transformed_src = current_transform.transform_points(src_pts)

            # Find correspondences
            matched_src = []
            matched_tgt = []
            distances = []

            for i in range(len(transformed_src)):
                tgt_idx, dist = kdtree.nearest_neighbor(transformed_src[i])
                if dist <= self.max_correspondence_distance:
                    matched_src.append(transformed_src[i])
                    matched_tgt.append(target.points[tgt_idx])
                    distances.append(dist)

            inlier_count = len(matched_src)
            if inlier_count < 6:
                break

            P = np.array(matched_src) # transformed source
            Q = np.array(matched_tgt) # target

            # Compute centroids
            centroid_P = np.mean(P, axis=0)
            centroid_Q = np.mean(Q, axis=0)

            # Center coordinates
            P_prime = P - centroid_P
            Q_prime = Q - centroid_Q

            # Cross-covariance matrix H = P_prime^T * Q_prime
            H = P_prime.T @ Q_prime

            # Singular Value Decomposition
            U, S, Vt = np.linalg.svd(H)
            R_step = Vt.T @ U.T

            # Reflection correction
            if np.linalg.det(R_step) < 0:
                Vt[2, :] *= -1
                R_step = Vt.T @ U.T

            t_step = centroid_Q - R_step @ centroid_P
            step_transform = SE3Transform(R_step, t_step)

            # Update overall transform
            current_transform = step_transform.compose(current_transform)

            final_rmse = float(np.sqrt(np.mean(np.array(distances) ** 2)))

            # Check convergence
            trans_mag = float(np.linalg.norm(t_step))
            rot_trace = float(np.trace(R_step))
            rot_angle = np.arccos(np.clip((rot_trace - 1.0) / 2.0, -1.0, 1.0))

            if trans_mag < self.translation_epsilon and rot_angle < self.rotation_epsilon:
                converged = True
                break

        fitness = inlier_count / max(1, len(source))
        return ICPResult(
            transform=current_transform,
            fitness_score=fitness,
            inlier_count=inlier_count,
            iterations=iteration,
            converged=converged or (fitness >= self.fitness_threshold),
            residual_rmse=final_rmse,
            duration_ms=(time.perf_counter() - t0) * 1000.0
        )
