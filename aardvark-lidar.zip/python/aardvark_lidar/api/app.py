"""
FastAPI REST API Service for AARDVARK LIDAR Platform.
"""
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import time
import numpy as np

from aardvark_lidar.config.models import SensorConfig, SensorType
from aardvark_lidar.simulation.synthetic_lidar import SimulatedLidarSensor, SyntheticEnvironment
from aardvark_lidar.filtering.pipeline import FilterPipeline
from aardvark_lidar.geometry.transforms import SE3Transform
from aardvark_lidar.calibration.engine import CalibrationEngine

app = FastAPI(title="AARDVARK LIDAR Perception API", version="1.0.0")

# Global in-memory orchestrator instances
calibration_engine = CalibrationEngine()
filter_engine = FilterPipeline()
env = SyntheticEnvironment("industrial_warehouse")
sim_config = SensorConfig(
    sensor_id="AV-LIDAR-001",
    manufacturer="Aardvark Imaging",
    model="AV-64HD",
    serial_number="AV64-2026-0988",
    sensor_type=SensorType.SIMULATED,
    beam_count=64
)
simulator = SimulatedLidarSensor(sim_config, env)


@app.get("/health")
def health_check():
    return {
        "status": "healthy",
        "service": "aardvark_lidar_api",
        "timestamp_utc": time.time(),
        "version": "1.0.0"
    }


@app.get("/sensors")
def list_sensors():
    return [{
        "sensor_id": sim_config.sensor_id,
        "manufacturer": sim_config.manufacturer,
        "model": sim_config.model,
        "serial_number": sim_config.serial_number,
        "beam_count": sim_config.beam_count,
        "status": "STREAMING",
        "ip": sim_config.ip_address,
        "port": sim_config.udp_port
    }]


@app.get("/scans/latest")
def get_latest_scan():
    cloud = simulator.generate_scan()
    # Apply filtering
    filtered = filter_engine.filter_range(cloud, min_range=0.3, max_range=60.0)
    ground, non_ground, plane = filter_engine.ransac_ground_segmentation(filtered)
    
    return {
        "timestamp_utc": time.time(),
        "point_count": len(filtered),
        "ground_point_count": len(ground),
        "non_ground_point_count": len(non_ground),
        "ground_plane_normal": [plane[0], plane[1], plane[2]],
        "ground_plane_distance": plane[3],
        "sample_points": filtered.points[:100].tolist()
    }


@app.get("/diagnostics")
def get_diagnostics():
    return {
        "sensor_id": "AV-LIDAR-001",
        "health_state": "HEALTHY",
        "packet_rate_hz": 1280.0,
        "packet_loss_pct": 0.02,
        "mean_latency_ms": 3.4,
        "optical_temp_c": 38.6,
        "rpm_deviation_pct": 0.05,
        "active_alarms": []
    }
