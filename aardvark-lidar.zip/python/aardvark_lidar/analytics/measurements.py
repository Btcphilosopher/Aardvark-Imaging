"""
Spatial Analytics, Measurement Tools and Geometric Dimensions.
"""
from dataclasses import dataclass
from typing import Tuple, Dict, Any, Optional
import numpy as np


@dataclass
class MeasurementResult:
    measurement_type: str
    value: float
    unit: str
    uncertainty_estimate: float
    details: Dict[str, Any]


class SpatialMeasurementEngine:
    """Scientific point cloud measurement caliper."""
    
    @staticmethod
    def point_to_point_distance(p1: np.ndarray, p2: np.ndarray, range_noise_sigma: float = 0.015) -> MeasurementResult:
        """Euclidean 3D distance: d = sqrt((x2-x1)^2 + (y2-y1)^2 + (z2-z1)^2) with propagated uncertainty."""
        p1 = np.asarray(p1, dtype=np.float64)
        p2 = np.asarray(p2, dtype=np.float64)
        diff = p2 - p1
        dist = float(np.linalg.norm(diff))
        # Propagated standard error for two independent point measurements
        uncertainty = float(np.sqrt(2.0) * range_noise_sigma)

        return MeasurementResult(
            measurement_type="PointToPointDistance",
            value=dist,
            unit="meters",
            uncertainty_estimate=uncertainty,
            details={
                "p1": p1.tolist(),
                "p2": p2.tolist(),
                "dx": float(diff[0]),
                "dy": float(diff[1]),
                "dz": float(diff[2]),
                "horizontal_distance": float(np.hypot(diff[0], diff[1]))
            }
        )

    @staticmethod
    def point_to_plane_distance(point: np.ndarray, plane_coeffs: Tuple[float, float, float, float]) -> MeasurementResult:
        """Orthogonal distance to plane: |ax + by + cz + d| / sqrt(a^2 + b^2 + c^2)."""
        pt = np.asarray(point, dtype=np.float64)
        a, b, c, d = plane_coeffs
        denom = np.sqrt(a**2 + b**2 + c**2)
        dist = float(np.abs(a*pt[0] + b*pt[1] + c*pt[2] + d) / denom)
        return MeasurementResult(
            measurement_type="PointToPlaneDistance",
            value=dist,
            unit="meters",
            uncertainty_estimate=0.01,
            details={"point": pt.tolist(), "plane": [a, b, c, d]}
        )

    @staticmethod
    def bounding_box_volume(min_corner: np.ndarray, max_corner: np.ndarray) -> MeasurementResult:
        """Computes dimensions [w, l, h] and enclosed 3D volume."""
        dims = np.maximum(0.0, np.asarray(max_corner) - np.asarray(min_corner))
        volume = float(dims[0] * dims[1] * dims[2])
        return MeasurementResult(
            measurement_type="BoundingBoxVolume",
            value=volume,
            unit="cubic_meters",
            uncertainty_estimate=volume * 0.02,
            details={
                "width_m": float(dims[0]),
                "length_m": float(dims[1]),
                "height_m": float(dims[2]),
                "footprint_area_m2": float(dims[0] * dims[1])
            }
        )
