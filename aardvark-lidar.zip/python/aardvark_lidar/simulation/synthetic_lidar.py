"""
Synthetic LiDAR Ray-Casting & Digital Twin Environment Generator.
"""
from dataclasses import dataclass
from typing import List, Tuple, Optional
import numpy as np
from aardvark_lidar.config.models import SensorConfig, SensorType
from aardvark_lidar.pointcloud.pointcloud import PointCloud


@dataclass
class GeometricPrimitive:
    primitive_type: str # "plane", "box", "cylinder", "sphere"
    center: np.ndarray
    dimensions: np.ndarray # (w, h, d) or (radius, height)
    reflectivity: float
    rotation_yaw: float = 0.0


class SyntheticEnvironment:
    """Parametric digital-twin scene representation with geometric primitives."""
    def __init__(self, scenario_name: str = "industrial_warehouse"):
        self.scenario_name = scenario_name
        self.primitives: List[GeometricPrimitive] = []
        self._build_scenario(scenario_name)

    def _build_scenario(self, name: str) -> None:
        self.primitives.clear()
        
        # Ground plane at z = 0
        self.primitives.append(GeometricPrimitive(
            "plane", np.array([0.0, 0.0, 0.0]), np.array([60.0, 60.0, 0.0]), reflectivity=140.0
        ))

        if name == "industrial_warehouse":
            # Perimeter walls
            self.primitives.append(GeometricPrimitive("box", np.array([25.0, 0.0, 4.0]), np.array([1.0, 50.0, 8.0]), 180.0))
            self.primitives.append(GeometricPrimitive("box", np.array([-25.0, 0.0, 4.0]), np.array([1.0, 50.0, 8.0]), 180.0))
            self.primitives.append(GeometricPrimitive("box", np.array([0.0, 25.0, 4.0]), np.array([50.0, 1.0, 8.0]), 180.0))
            self.primitives.append(GeometricPrimitive("box", np.array([0.0, -25.0, 4.0]), np.array([50.0, 1.0, 8.0]), 180.0))

            # Industrial machinery & storage crates
            self.primitives.append(GeometricPrimitive("box", np.array([8.0, 5.0, 1.2]), np.array([3.0, 4.0, 2.4]), 210.0))
            self.primitives.append(GeometricPrimitive("box", np.array([12.0, -8.0, 1.0]), np.array([2.5, 2.5, 2.0]), 190.0))
            self.primitives.append(GeometricPrimitive("cylinder", np.array([-10.0, 6.0, 2.5]), np.array([1.5, 5.0, 0.0]), 240.0))
            self.primitives.append(GeometricPrimitive("box", np.array([-8.0, -12.0, 1.5]), np.array([4.0, 2.0, 3.0]), 170.0))

        elif name == "urban_street":
            # Road corridor with parked vehicle and trees
            self.primitives.append(GeometricPrimitive("box", np.array([15.0, 3.0, 0.8]), np.array([4.5, 1.9, 1.5]), 220.0)) # Vehicle
            self.primitives.append(GeometricPrimitive("cylinder", np.array([8.0, -4.0, 2.0]), np.array([0.4, 4.0, 0.0]), 90.0)) # Tree trunk
            self.primitives.append(GeometricPrimitive("box", np.array([5.0, 6.0, 1.0]), np.array([0.5, 0.5, 1.8]), 80.0)) # Pedestrian
            self.primitives.append(GeometricPrimitive("box", np.array([20.0, -6.0, 5.0]), np.array([12.0, 1.0, 10.0]), 160.0)) # Building facade

        else: # empty_calibration_room
            self.primitives.append(GeometricPrimitive("box", np.array([10.0, 0.0, 2.5]), np.array([0.2, 10.0, 5.0]), 200.0))
            self.primitives.append(GeometricPrimitive("box", np.array([-10.0, 0.0, 2.5]), np.array([0.2, 10.0, 5.0]), 200.0))
            self.primitives.append(GeometricPrimitive("box", np.array([0.0, 10.0, 2.5]), np.array([10.0, 0.2, 5.0]), 200.0))
            self.primitives.append(GeometricPrimitive("box", np.array([0.0, -10.0, 2.5]), np.array([10.0, 0.2, 5.0]), 200.0))


class SimulatedLidarSensor:
    """Ray-tracing synthetic LiDAR with Gaussian range noise and beam attenuation."""
    def __init__(self, config: SensorConfig, environment: SyntheticEnvironment):
        self.config = config
        self.env = environment
        self.vertical_angles = np.linspace(
            np.radians(-self.config.vertical_fov_deg / 2.0),
            np.radians(self.config.vertical_fov_deg / 2.0),
            self.config.beam_count
        )
        self.sensor_pose_z = 1.8 # Sensor mounted 1.8m above ground

    def generate_scan(self, azimuth_step_deg: float = 0.5, noise_std_m: float = 0.015) -> PointCloud:
        azimuths_deg = np.arange(0.0, self.config.horizontal_fov_deg, azimuth_step_deg)
        az_rad = np.radians(azimuths_deg)

        pts_list = []
        intensities = []
        ranges_list = []
        az_list = []
        el_list = []
        rings = []

        for ring_idx, el in enumerate(self.vertical_angles):
            cos_el = np.cos(el)
            sin_el = np.sin(el)

            for az in az_rad:
                ray_dir = np.array([cos_el * np.cos(az), cos_el * np.sin(az), sin_el])
                
                # Ray trace against ground (z = 0, sensor at [0, 0, sensor_pose_z])
                min_dist = self.config.max_range_m
                hit_reflectivity = 50.0

                if ray_dir[2] < -1e-4:
                    t_ground = -self.sensor_pose_z / ray_dir[2]
                    if 0.0 < t_ground < min_dist:
                        min_dist = t_ground
                        hit_reflectivity = 140.0

                # Ray trace against primitives
                origin = np.array([0.0, 0.0, self.sensor_pose_z])
                for prim in self.env.primitives:
                    if prim.primitive_type == "box":
                        # AABB slab intersection
                        b_min = prim.center - prim.dimensions / 2.0
                        b_max = prim.center + prim.dimensions / 2.0

                        inv_dir = np.where(np.abs(ray_dir) > 1e-6, 1.0 / ray_dir, 1e9)
                        t1 = (b_min - origin) * inv_dir
                        t2 = (b_max - origin) * inv_dir

                        t_min_v = np.minimum(t1, t2)
                        t_max_v = np.maximum(t1, t2)

                        t_enter = float(np.max(t_min_v))
                        t_exit = float(np.min(t_max_v))

                        if t_enter < t_exit and t_enter > 0.0 and t_enter < min_dist:
                            min_dist = t_enter
                            hit_reflectivity = prim.reflectivity

                    elif prim.primitive_type == "cylinder":
                        # Infinite vertical cylinder approximation
                        dx = origin[0] - prim.center[0]
                        dy = origin[1] - prim.center[1]
                        r_cyl = prim.dimensions[0]
                        a = ray_dir[0]**2 + ray_dir[1]**2
                        b = 2.0 * (dx * ray_dir[0] + dy * ray_dir[1])
                        c = dx**2 + dy**2 - r_cyl**2
                        disc = b**2 - 4.0 * a * c
                        if disc >= 0:
                            t_cyl = (-b - np.sqrt(disc)) / (2.0 * a)
                            hit_z = origin[2] + t_cyl * ray_dir[2]
                            if t_cyl > 0 and t_cyl < min_dist and (0.0 <= hit_z <= prim.dimensions[1]):
                                min_dist = t_cyl
                                hit_reflectivity = prim.reflectivity

                if min_dist < self.config.max_range_m:
                    # Apply Gaussian measurement noise
                    noisy_dist = float(np.clip(min_dist + np.random.normal(0.0, noise_std_m), self.config.min_range_m, self.config.max_range_m))
                    
                    ranges_list.append(noisy_dist)
                    az_list.append(az)
                    el_list.append(el)
                    intensities.append(float(np.clip(hit_reflectivity * (10.0 / max(1.0, noisy_dist)), 10.0, 255.0)))
                    rings.append(ring_idx)

        return PointCloud.from_spherical(
            azimuths=np.array(az_list, dtype=np.float32),
            elevations=np.array(el_list, dtype=np.float32),
            ranges=np.array(ranges_list, dtype=np.float32),
            intensities=np.array(intensities, dtype=np.float32),
            rings=np.array(rings, dtype=np.uint16)
        )
