"""
Canonical configuration schemas and data types for AARDVARK LIDAR.
"""
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple, Any
import numpy as np


class SensorType(str, Enum):
    MECHANICAL_SPINNING = "mechanical_spinning"
    SOLID_STATE_FLASH = "solid_state_flash"
    MEMS_SCANNING = "mems_scanning"
    SIMULATED = "simulated"


class SensorHealthState(str, Enum):
    HEALTHY = "HEALTHY"
    DEGRADED = "DEGRADED"
    WARNING = "WARNING"
    FAULT = "FAULT"


@dataclass
class SensorConfig:
    sensor_id: str
    manufacturer: str
    model: str
    serial_number: str
    sensor_type: SensorType
    beam_count: int
    rotation_rate_hz: float = 10.0
    horizontal_fov_deg: float = 360.0
    vertical_fov_deg: float = 45.0
    min_range_m: float = 0.2
    max_range_m: float = 150.0
    ip_address: str = "192.168.1.201"
    udp_port: int = 2368
    firmware_version: str = "v3.4.12"


@dataclass
class RawMeasurement:
    timestamp_sensor: float
    timestamp_host: float
    sensor_id: str
    packet_id: int
    beam_id: int
    azimuth_rad: float
    elevation_rad: float
    range_m: float
    intensity: float
    return_number: int = 1
    channel: int = 0
    status_flags: int = 0


@dataclass
class PointXYZIRT:
    x: float
    y: float
    z: float
    intensity: float
    range: float
    azimuth: float
    elevation: float
    timestamp: float
    ring: int
    return_number: int = 1
    confidence: float = 1.0
    sensor_id: str = "default"
    flags: int = 0
    cluster_id: int = -1
