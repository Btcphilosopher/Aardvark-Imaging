"""
LiDAR Calibration Engine: Intrinsic Optical Corrections and Extrinsic Calibration.
"""
from dataclasses import dataclass, field
import uuid
import time
from typing import Dict, List, Optional
import numpy as np
from aardvark_lidar.geometry.transforms import SE3Transform


@dataclass
class BeamCorrection:
    beam_id: int
    azimuth_offset_rad: float = 0.0
    elevation_offset_rad: float = 0.0
    range_scale: float = 1.0
    range_offset_m: float = 0.0


@dataclass
class CalibrationProfile:
    version_id: str
    sensor_id: str
    created_at_utc: float
    global_range_scale: float = 1.0
    global_range_offset_m: float = 0.0
    global_azimuth_offset_rad: float = 0.0
    global_elevation_offset_rad: float = 0.0
    extrinsic_sensor_to_body: SE3Transform = field(default_factory=SE3Transform.identity)
    beam_corrections: Dict[int, BeamCorrection] = field(default_factory=dict)
    is_active: bool = True

    def correct_measurement(self, beam_id: int, azimuth: float, elevation: float, raw_range: float) -> tuple[float, float, float]:
        """Apply intrinsic optical calibrations to spherical coordinates."""
        b_corr = self.beam_corrections.get(beam_id, BeamCorrection(beam_id=beam_id))
        
        # Corrected spherical coords
        r_corr = (raw_range * self.global_range_scale * b_corr.range_scale) + (self.global_range_offset_m + b_corr.range_offset_m)
        az_corr = azimuth + self.global_azimuth_offset_rad + b_corr.azimuth_offset_rad
        el_corr = elevation + self.global_elevation_offset_rad + b_corr.elevation_offset_rad

        # Wrap azimuth to [0, 2pi)
        az_corr = az_corr % (2.0 * np.pi)
        return az_corr, el_corr, max(0.0, r_corr)


class CalibrationEngine:
    """Manages versioned calibration records and calibration solver routines."""
    def __init__(self):
        self.profiles: Dict[str, CalibrationProfile] = {}
        self.active_profile_id: Optional[str] = None

    def register_profile(self, profile: CalibrationProfile) -> None:
        self.profiles[profile.version_id] = profile
        if profile.is_active or self.active_profile_id is None:
            self.active_profile_id = profile.version_id

    def get_active_profile(self) -> CalibrationProfile:
        if not self.active_profile_id or self.active_profile_id not in self.profiles:
            # Create default nominal profile
            default = CalibrationProfile(
                version_id=f"nominal_{uuid.uuid4().hex[:8]}",
                sensor_id="default_sensor",
                created_at_utc=time.time(),
            )
            self.register_profile(default)
        return self.profiles[self.active_profile_id]
