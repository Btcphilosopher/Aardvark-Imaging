"""
AARDVARK LIDAR - Production LiDAR Sensor, Point Cloud and Computational Perception Platform.
"""

__version__ = "1.0.0"
__author__ = "Aardvark Imaging Systems"
