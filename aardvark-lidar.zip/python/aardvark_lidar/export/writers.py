"""
Point Cloud Exporters: PLY, PCD, CSV and Provenance Headers.
"""
import io
import json
import time
from typing import Dict, Any, Optional
import numpy as np
from aardvark_lidar.pointcloud.pointcloud import PointCloud


class PointCloudExporter:
    """Scientific export serialization for downstream GIS, PCL, and CAD tools."""

    @staticmethod
    def to_ply(cloud: PointCloud, metadata: Optional[Dict[str, Any]] = None) -> str:
        """Generates standard ASCII PLY string with headers and provenance."""
        n = len(cloud)
        meta_str = json.dumps(metadata or {"exporter": "Aardvark LiDAR v1.0", "timestamp": time.time()})
        
        lines = [
            "ply",
            "format ascii 1.0",
            f"comment aardvark_metadata: {meta_str}",
            f"element vertex {n}",
            "property float x",
            "property float y",
            "property float z",
            "property float intensity",
            "property float range",
            "property ushort ring",
            "property uchar flags",
            "end_header"
        ]

        pts = cloud.points
        ints = cloud.intensity
        rngs = cloud.ranges
        rings = cloud.rings
        flgs = cloud.flags

        for i in range(n):
            lines.append(f"{pts[i,0]:.4f} {pts[i,1]:.4f} {pts[i,2]:.4f} {ints[i]:.1f} {rngs[i]:.3f} {rings[i]} {flgs[i]}")

        return "\n".join(lines)

    @staticmethod
    def to_pcd(cloud: PointCloud) -> str:
        """Generates PCD (Point Cloud Data) v0.7 ASCII string."""
        n = len(cloud)
        header = [
            "# .PCD v0.7 - Point Cloud Data file format",
            "VERSION 0.7",
            "FIELDS x y z intensity ring",
            "SIZE 4 4 4 4 2",
            "TYPE F F F F U",
            "COUNT 1 1 1 1 1",
            f"WIDTH {n}",
            "HEIGHT 1",
            "VIEWPOINT 0 0 0 1 0 0 0",
            f"POINTS {n}",
            "DATA ascii"
        ]

        pts = cloud.points
        ints = cloud.intensity
        rings = cloud.rings

        lines = header
        for i in range(n):
            lines.append(f"{pts[i,0]:.4f} {pts[i,1]:.4f} {pts[i,2]:.4f} {ints[i]:.1f} {rings[i]}")

        return "\n".join(lines)

    @staticmethod
    def to_csv(cloud: PointCloud) -> str:
        """Generates standard CSV dump."""
        n = len(cloud)
        lines = ["x,y,z,intensity,range,azimuth,elevation,ring,flags,cluster_id"]
        pts = cloud.points
        for i in range(n):
            lines.append(
                f"{pts[i,0]:.4f},{pts[i,1]:.4f},{pts[i,2]:.4f},{cloud.intensity[i]:.2f},"
                f"{cloud.ranges[i]:.3f},{cloud.azimuths[i]:.4f},{cloud.elevations[i]:.4f},"
                f"{cloud.rings[i]},{cloud.flags[i]},{cloud.cluster_ids[i]}"
            )
        return "\n".join(lines)
