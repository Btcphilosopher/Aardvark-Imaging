"""
3D Spatial KD-Tree Index and Accelerated Nearest-Neighbor Search.
"""
from typing import List, Tuple, Optional
import numpy as np


class KDNode:
    def __init__(self, point_idx: int, axis: int, left: Optional["KDNode"] = None, right: Optional["KDNode"] = None):
        self.point_idx = point_idx
        self.axis = axis
        self.left = left
        self.right = right


class KDTree3D:
    """Balanced 3D Spatial Indexing structure."""
    def __init__(self, points: np.ndarray):
        self.points = np.ascontiguousarray(points, dtype=np.float32)
        indices = np.arange(len(self.points))
        self.root = self._build(indices, depth=0)

    def _build(self, indices: np.ndarray, depth: int) -> Optional[KDNode]:
        if len(indices) == 0:
            return None
        axis = depth % 3
        # Sort indices by coordinate along axis
        sorted_indices = indices[np.argsort(self.points[indices, axis])]
        median_idx = len(sorted_indices) // 2

        node_point_idx = sorted_indices[median_idx]
        left_indices = sorted_indices[:median_idx]
        right_indices = sorted_indices[median_idx + 1:]

        return KDNode(
            point_idx=node_point_idx,
            axis=axis,
            left=self._build(left_indices, depth + 1),
            right=self._build(right_indices, depth + 1)
        )

    def nearest_neighbor(self, query: np.ndarray) -> Tuple[int, float]:
        """Find index and Euclidean distance of closest point."""
        best_idx = -1
        best_dist_sq = float("inf")

        def _search(node: Optional[KDNode]):
            nonlocal best_idx, best_dist_sq
            if node is None:
                return

            pt = self.points[node.point_idx]
            dist_sq = float(np.sum((pt - query) ** 2))
            if dist_sq < best_dist_sq:
                best_dist_sq = dist_sq
                best_idx = node.point_idx

            axis = node.axis
            diff = query[axis] - pt[axis]

            first = node.left if diff < 0 else node.right
            second = node.right if diff < 0 else node.left

            _search(first)
            if (diff ** 2) < best_dist_sq:
                _search(second)

        _search(self.root)
        return best_idx, np.sqrt(best_dist_sq)

    def radius_search(self, query: np.ndarray, radius: float) -> List[int]:
        """Find all point indices within radius."""
        results = []
        r_sq = radius * radius

        def _search(node: Optional[KDNode]):
            if node is None:
                return
            pt = self.points[node.point_idx]
            dist_sq = float(np.sum((pt - query) ** 2))
            if dist_sq <= r_sq:
                results.append(node.point_idx)

            axis = node.axis
            diff = query[axis] - pt[axis]

            first = node.left if diff < 0 else node.right
            second = node.right if diff < 0 else node.left

            _search(first)
            if (diff ** 2) <= r_sq:
                _search(second)

        _search(self.root)
        return results
