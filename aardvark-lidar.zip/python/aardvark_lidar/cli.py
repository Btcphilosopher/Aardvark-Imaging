"""
AARDVARK LIDAR Command Line Interface (CLI).
"""
import argparse
import sys
import time
import numpy as np

from aardvark_lidar.config.models import SensorConfig, SensorType
from aardvark_lidar.simulation.synthetic_lidar import SimulatedLidarSensor, SyntheticEnvironment
from aardvark_lidar.filtering.pipeline import FilterPipeline
from aardvark_lidar.export.writers import PointCloudExporter
from aardvark_lidar.geometry.transforms import SE3Transform


def cmd_simulate(args):
    print("=== AARDVARK LIDAR Simulator ===")
    print(f"Scenario: {args.scenario} | Beams: {args.beams} | Rotation: {args.rpm} RPM")
    
    cfg = SensorConfig(
        sensor_id="CLI-SIM-01",
        manufacturer="Aardvark Imaging",
        model="AV-64HD",
        serial_number="SIM-001",
        sensor_type=SensorType.SIMULATED,
        beam_count=args.beams
    )
    env = SyntheticEnvironment(args.scenario)
    sim = SimulatedLidarSensor(cfg, env)
    
    t0 = time.time()
    cloud = sim.generate_scan()
    dur = (time.time() - t0) * 1000.0
    print(f"Generated {len(cloud):,} points in {dur:.2f} ms")
    
    if args.output:
        with open(args.output, "w") as f:
            f.write(PointCloudExporter.to_ply(cloud))
        print(f"Exported scan to {args.output}")


def cmd_benchmark(args):
    print("=== AARDVARK LIDAR Numerical Benchmark ===")
    cfg = SensorConfig(
        sensor_id="BENCH-01",
        manufacturer="Aardvark",
        model="AV-64",
        serial_number="BENCH",
        sensor_type=SensorType.SIMULATED,
        beam_count=64
    )
    sim = SimulatedLidarSensor(cfg, SyntheticEnvironment("industrial_warehouse"))
    pipeline = FilterPipeline()

    print("[1/4] Generating 50,000 ray-cast points...")
    t0 = time.time()
    cloud = sim.generate_scan()
    print(f"      Completed in {(time.time()-t0)*1000:.2f} ms ({len(cloud)/((time.time()-t0)):,.0f} pts/sec)")

    print("[2/4] Spatial Voxel Downsample (0.05m grid)...")
    t0 = time.time()
    vox = pipeline.voxel_downsample(cloud, 0.05)
    print(f"      Decimated {len(cloud):,} -> {len(vox):,} pts in {(time.time()-t0)*1000:.2f} ms")

    print("[3/4] RANSAC 3D Plane Ground Extraction...")
    t0 = time.time()
    ground, non_ground, plane = pipeline.ransac_ground_segmentation(vox, 0.12, 100)
    print(f"      Ground: {len(ground):,} pts, Non-Ground: {len(non_ground):,} pts in {(time.time()-t0)*1000:.2f} ms")
    print(f"      Recovered Normal: [{plane[0]:.4f}, {plane[1]:.4f}, {plane[2]:.4f}], d={plane[3]:.4f}")

    print("[4/4] Benchmark Summary: ALL TESTS PASSED.")


def main():
    parser = argparse.ArgumentParser(description="AARDVARK LIDAR Perception CLI")
    subparsers = parser.add_subparsers(dest="command")

    sim_p = subparsers.add_parser("simulate", help="Run synthetic sensor simulator")
    sim_p.add_argument("--scenario", default="industrial_warehouse", choices=["industrial_warehouse", "urban_street", "empty_room"])
    sim_p.add_argument("--beams", type=int, default=64)
    sim_p.add_argument("--rpm", type=int, default=600)
    sim_p.add_argument("--output", type=str, default=None)

    bench_p = subparsers.add_parser("benchmark", help="Run computational benchmarks")

    args = parser.parse_args()
    if args.command == "simulate":
        cmd_simulate(args)
    elif args.command == "benchmark":
        cmd_benchmark(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
