"""
Sensor Health Monitor and Subsystem Diagnostics.
"""
from dataclasses import dataclass
import time
from typing import Dict, List, Optional
from aardvark_lidar.config.models import SensorHealthState


@dataclass
class DiagnosticReport:
    sensor_id: str
    timestamp_utc: float
    health_state: SensorHealthState
    packet_rate_hz: float
    packet_loss_pct: float
    mean_latency_ms: float
    optical_temp_c: float
    rpm_deviation_pct: float
    invalid_points_pct: float
    active_alarms: List[str]
    remediation_advice: str


class SensorHealthMonitor:
    """Continuously evaluates packet integrity, latency, jitter, and thermal telemetry."""
    def __init__(self, sensor_id: str):
        self.sensor_id = sensor_id
        self.packet_counts: int = 0
        self.dropped_packets: int = 0
        self.latencies: List[float] = []

    def evaluate_telemetry(
        self,
        current_packet_rate: float,
        packet_loss_pct: float,
        latency_ms: float,
        temperature_c: float,
        target_rpm: float,
        measured_rpm: float,
        invalid_point_ratio: float
    ) -> DiagnosticReport:
        alarms = []
        state = SensorHealthState.HEALTHY
        remediation = "System nominal. Calibration and streaming optimal."

        rpm_dev = abs(measured_rpm - target_rpm) / max(1.0, target_rpm) * 100.0

        if packet_loss_pct > 15.0 or temperature_c > 75.0 or rpm_dev > 10.0:
            state = SensorHealthState.FAULT
            if packet_loss_pct > 15.0:
                alarms.append(f"CRITICAL: High network packet loss ({packet_loss_pct:.1f}%)")
                remediation = "Verify 1GbE UDP NIC buffer sizing and cable shielding."
            if temperature_c > 75.0:
                alarms.append(f"CRITICAL: Optical core overheat ({temperature_c:.1f}°C)")
                remediation = "Halt emitter duty cycle; check active cooling heatsink."
            if rpm_dev > 10.0:
                alarms.append(f"CRITICAL: Rotor motor encoder synchronization failure ({measured_rpm:.1f} vs {target_rpm:.1f} RPM)")
                remediation = "Inspect mechanical rotor bearings and encoder disk cleanliness."

        elif packet_loss_pct > 3.0 or temperature_c > 65.0 or invalid_point_ratio > 0.20:
            state = SensorHealthState.WARNING
            if packet_loss_pct > 3.0:
                alarms.append(f"WARNING: Elevated packet loss ({packet_loss_pct:.1f}%)")
            if invalid_point_ratio > 0.20:
                alarms.append(f"WARNING: High invalid return ratio ({invalid_point_ratio*100:.1f}%)")
                remediation = "Inspect front optical dome for dirt, water droplets, or fogging."

        elif latency_ms > 25.0:
            state = SensorHealthState.DEGRADED
            alarms.append(f"DEGRADED: Processing latency above budget ({latency_ms:.1f} ms)")
            remediation = "Increase voxel grid decimation or reduce spatial ROI bounds."

        return DiagnosticReport(
            sensor_id=self.sensor_id,
            timestamp_utc=time.time(),
            health_state=state,
            packet_rate_hz=current_packet_rate,
            packet_loss_pct=packet_loss_pct,
            mean_latency_ms=latency_ms,
            optical_temp_c=temperature_c,
            rpm_deviation_pct=rpm_dev,
            invalid_points_pct=invalid_point_ratio * 100.0,
            active_alarms=alarms,
            remediation_advice=remediation
        )
