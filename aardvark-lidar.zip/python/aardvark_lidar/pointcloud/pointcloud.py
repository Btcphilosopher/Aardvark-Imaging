"""
High-Performance Point Cloud Data Structure and Operations.
"""
from dataclasses import dataclass
from typing import List, Optional, Tuple
import numpy as np


@dataclass
class PointCloud:
    """
    Contiguous columnar/matrix point cloud representation.
    points: Nx3 float32 array [x, y, z]
    intensity: N-element float32 array
    ranges: N-element float32 array
    azimuths: N-element float32 array
    elevations: N-element float32 array
    rings: N-element uint16 array
    timestamps: N-element float64 array
    flags: N-element uint8 array (0x01 ground, 0x02 outlier, 0x04 valid)
    cluster_ids: N-element int16 array
    """
    points: np.ndarray
    intensity: np.ndarray
    ranges: np.ndarray
    azimuths: np.ndarray
    elevations: np.ndarray
    rings: np.ndarray
    timestamps: np.ndarray
    flags: np.ndarray
    cluster_ids: np.ndarray

    def __post_init__(self):
        self.points = np.ascontiguousarray(self.points, dtype=np.float32)
        n = len(self.points)
        if len(self.intensity) != n:
            self.intensity = np.zeros(n, dtype=np.float32)
        if len(self.ranges) != n:
            self.ranges = np.zeros(n, dtype=np.float32)
        if len(self.azimuths) != n:
            self.azimuths = np.zeros(n, dtype=np.float32)
        if len(self.elevations) != n:
            self.elevations = np.zeros(n, dtype=np.float32)
        if len(self.rings) != n:
            self.rings = np.zeros(n, dtype=np.uint16)
        if len(self.timestamps) != n:
            self.timestamps = np.zeros(n, dtype=np.float64)
        if len(self.flags) != n:
            self.flags = np.zeros(n, dtype=np.uint8)
        if len(self.cluster_ids) != n:
            self.cluster_ids = np.full(n, -1, dtype=np.int16)

    def __len__(self) -> int:
        return len(self.points)

    @classmethod
    def empty(cls) -> "PointCloud":
        return cls(
            points=np.empty((0, 3), dtype=np.float32),
            intensity=np.empty(0, dtype=np.float32),
            ranges=np.empty(0, dtype=np.float32),
            azimuths=np.empty(0, dtype=np.float32),
            elevations=np.empty(0, dtype=np.float32),
            rings=np.empty(0, dtype=np.uint16),
            timestamps=np.empty(0, dtype=np.float64),
            flags=np.empty(0, dtype=np.uint8),
            cluster_ids=np.empty(0, dtype=np.int16)
        )

    @classmethod
    def from_spherical(
        cls,
        azimuths: np.ndarray,
        elevations: np.ndarray,
        ranges: np.ndarray,
        intensities: Optional[np.ndarray] = None,
        rings: Optional[np.ndarray] = None,
        timestamps: Optional[np.ndarray] = None
    ) -> "PointCloud":
        """
        Convert spherical measurements (r, theta, phi) to Cartesian (x, y, z).
        x = r * cos(phi) * cos(theta)
        y = r * cos(phi) * sin(theta)
        z = r * sin(phi)
        """
        r = np.asarray(ranges, dtype=np.float32)
        az = np.asarray(azimuths, dtype=np.float32)
        el = np.asarray(elevations, dtype=np.float32)

        cos_el = np.cos(el)
        x = r * cos_el * np.cos(az)
        y = r * cos_el * np.sin(az)
        z = r * np.sin(el)
        points = np.column_stack((x, y, z)).astype(np.float32)

        n = len(points)
        return cls(
            points=points,
            intensity=intensities if intensities is not None else np.full(n, 128.0, dtype=np.float32),
            ranges=r,
            azimuths=az,
            elevations=el,
            rings=rings if rings is not None else np.zeros(n, dtype=np.uint16),
            timestamps=timestamps if timestamps is not None else np.zeros(n, dtype=np.float64),
            flags=np.zeros(n, dtype=np.uint8),
            cluster_ids=np.full(n, -1, dtype=np.int16)
        )

    def compute_bounding_box(self) -> Tuple[np.ndarray, np.ndarray]:
        if len(self.points) == 0:
            return np.zeros(3), np.zeros(3)
        return np.min(self.points, axis=0), np.max(self.points, axis=0)

    def compute_centroid(self) -> np.ndarray:
        if len(self.points) == 0:
            return np.zeros(3)
        return np.mean(self.points, axis=0)

    def apply_mask(self, mask: np.ndarray) -> "PointCloud":
        return PointCloud(
            points=self.points[mask],
            intensity=self.intensity[mask],
            ranges=self.ranges[mask],
            azimuths=self.azimuths[mask],
            elevations=self.elevations[mask],
            rings=self.rings[mask],
            timestamps=self.timestamps[mask],
            flags=self.flags[mask],
            cluster_ids=self.cluster_ids[mask]
        )
