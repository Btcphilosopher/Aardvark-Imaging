"""
Rigid Body SE(3) Transformations and Coordinate Graph Engine.
"""
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple
import numpy as np


class TransformError(Exception):
    """Raised when transform validation, inversion, or resolution fails."""
    pass


@dataclass
class SE3Transform:
    """Rigid body transformation T in SE(3) composed of R in SO(3) and t in R^3."""
    rotation_matrix: np.ndarray  # 3x3 float64
    translation: np.ndarray       # 3-element float64

    def __post_init__(self):
        self.rotation_matrix = np.asarray(self.rotation_matrix, dtype=np.float64)
        self.translation = np.asarray(self.translation, dtype=np.float64).reshape((3,))
        self.validate()

    def validate(self, tolerance: float = 1e-6) -> None:
        if self.rotation_matrix.shape != (3, 3):
            raise TransformError(f"Invalid rotation matrix shape: {self.rotation_matrix.shape}")
        if self.translation.shape != (3,):
            raise TransformError(f"Invalid translation shape: {self.translation.shape}")
        
        # Check orthogonality: R * R^T = I
        ident = self.rotation_matrix @ self.rotation_matrix.T
        if not np.allclose(ident, np.eye(3), atol=tolerance):
            raise TransformError("Rotation matrix is not orthogonal (R * R^T != I)")
        
        # Check determinant: det(R) = +1 (proper rotation)
        det = np.linalg.det(self.rotation_matrix)
        if not np.isclose(det, 1.0, atol=tolerance):
            raise TransformError(f"Determinant of rotation matrix is {det} != 1.0 (improper rotation / reflection)")

    @classmethod
    def identity(cls) -> "SE3Transform":
        return cls(np.eye(3), np.zeros(3))

    @classmethod
    def from_euler(cls, roll_rad: float, pitch_rad: float, yaw_rad: float, translation: np.ndarray) -> "SE3Transform":
        """Z-Y-X Tait-Bryan Euler angle rotation parameterization."""
        cr, sr = np.cos(roll_rad), np.sin(roll_rad)
        cp, sp = np.cos(pitch_rad), np.sin(pitch_rad)
        cy, sy = np.cos(yaw_rad), np.sin(yaw_rad)

        Rx = np.array([[1, 0, 0], [0, cr, -sr], [0, sr, cr]])
        Ry = np.array([[cp, 0, sp], [0, 1, 0], [-sp, 0, cp]])
        Rz = np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]])

        R = Rz @ Ry @ Rx
        return cls(R, translation)

    @classmethod
    def from_matrix4x4(cls, mat: np.ndarray) -> "SE3Transform":
        mat = np.asarray(mat, dtype=np.float64)
        if mat.shape != (4, 4):
            raise TransformError(f"Expected 4x4 matrix, got {mat.shape}")
        R = mat[:3, :3]
        t = mat[:3, 3]
        return cls(R, t)

    def to_matrix4x4(self) -> np.ndarray:
        T = np.eye(4, dtype=np.float64)
        T[:3, :3] = self.rotation_matrix
        T[:3, 3] = self.translation
        return T

    def inverse(self) -> "SE3Transform":
        """Analytic exact inverse: T^{-1} = [ R^T | -R^T * t ]."""
        R_inv = self.rotation_matrix.T
        t_inv = -R_inv @ self.translation
        return SE3Transform(R_inv, t_inv)

    def compose(self, other: "SE3Transform") -> "SE3Transform":
        """Compose self * other: T_ac = T_ab * T_bc."""
        R_new = self.rotation_matrix @ other.rotation_matrix
        t_new = self.rotation_matrix @ other.translation + self.translation
        return SE3Transform(R_new, t_new)

    def transform_points(self, points: np.ndarray) -> np.ndarray:
        """Transform Nx3 point cloud array."""
        points = np.asarray(points, dtype=np.float64)
        if points.ndim != 2 or points.shape[1] != 3:
            raise TransformError(f"Expected Nx3 array, got shape {points.shape}")
        return (self.rotation_matrix @ points.T).T + self.translation


class TransformGraph:
    """Directed Acyclic Graph of coordinate frames and SE(3) transforms."""
    def __init__(self):
        self.transforms: Dict[Tuple[str, str], SE3Transform] = {}
        self.frames: set = set()

    def add_transform(self, parent: str, child: str, transform: SE3Transform) -> None:
        self.frames.add(parent)
        self.frames.add(child)
        self.transforms[(parent, child)] = transform
        self.transforms[(child, parent)] = transform.inverse()

    def resolve(self, target_frame: str, source_frame: str) -> SE3Transform:
        if target_frame == source_frame:
            return SE3Transform.identity()
        
        # Breadth-first search for transform path
        queue = [(source_frame, SE3Transform.identity())]
        visited = {source_frame}

        while queue:
            current, acc_transform = queue.pop(0)
            if current == target_frame:
                return acc_transform

            for (p, c), t in self.transforms.items():
                if p == current and c not in visited:
                    visited.add(c)
                    # Compose: T_c_source = T_c_p * T_p_source
                    new_transform = t.compose(acc_transform)
                    queue.append((c, new_transform))

        raise TransformError(f"No valid coordinate transform chain found from '{source_frame}' to '{target_frame}'")
