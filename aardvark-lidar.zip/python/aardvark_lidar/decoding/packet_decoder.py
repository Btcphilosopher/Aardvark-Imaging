"""
Binary LiDAR Packet Decoder & Ingestion Engine.
"""
import struct
import zlib
from typing import List, Tuple, Optional
import numpy as np
from aardvark_lidar.config.models import RawMeasurement


class PacketDecodeError(Exception):
    pass


class PacketDecoder:
    """
    Standard binary packet decoder for high-frequency LiDAR packets.
    Packet Structure:
      - Header (24 bytes): Magic (2B), Protocol (2B), Packet Seq (4B), Sensor TS (8B), Status (4B), Block Count (4B)
      - Blocks: Block Azimuth (2B), Flag (2B), Channels (N * 4B: Range 2B, Intensity 1B, Return 1B)
      - Tail (8 bytes): RPM (2B), Temp (2B), CRC32 (4B)
    """
    MAGIC_HEADER = 0xA456

    def __init__(self, beam_count: int = 64):
        self.beam_count = beam_count
        # Fixed vertical angles for beams across standard vertical FOV (-25 deg to +15 deg)
        self.vertical_beam_angles = np.linspace(-np.radians(25.0), np.radians(15.0), beam_count)

    def decode_packet(self, packet_bytes: bytes, host_timestamp: float, sensor_id: str) -> List[RawMeasurement]:
        if len(packet_bytes) < 32:
            raise PacketDecodeError(f"Packet undersized: {len(packet_bytes)} bytes")

        magic, protocol, seq, sensor_ts, status, block_count = struct.unpack_from(">HHIIII", packet_bytes, 0)
        if magic != self.MAGIC_HEADER:
            raise PacketDecodeError(f"Invalid packet magic header: 0x{magic:04X}")

        measurements = []
        offset = 24

        for _ in range(block_count):
            if offset + 4 > len(packet_bytes) - 8:
                break
            raw_azimuth, block_flag = struct.unpack_from(">HH", packet_bytes, offset)
            azimuth_rad = np.radians(raw_azimuth / 100.0)
            offset += 4

            for beam_id in range(self.beam_count):
                if offset + 4 > len(packet_bytes) - 8:
                    break
                raw_range_mm, intensity, return_num = struct.unpack_from(">HBB", packet_bytes, offset)
                offset += 4

                range_m = raw_range_mm * 0.002 # 2mm resolution
                elevation_rad = float(self.vertical_beam_angles[beam_id % len(self.vertical_beam_angles)])

                measurements.append(RawMeasurement(
                    timestamp_sensor=sensor_ts * 1e-6,
                    timestamp_host=host_timestamp,
                    sensor_id=sensor_id,
                    packet_id=seq,
                    beam_id=beam_id,
                    azimuth_rad=azimuth_rad,
                    elevation_rad=elevation_rad,
                    range_m=range_m,
                    intensity=float(intensity),
                    return_number=return_num,
                    channel=beam_id,
                    status_flags=status
                ))

        return measurements
