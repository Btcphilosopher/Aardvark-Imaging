use std::collections::HashMap;

pub struct VoxelGridFilter {
    pub voxel_size: f32,
}

impl VoxelGridFilter {
    pub fn new(voxel_size: f32) -> Self {
        Self { voxel_size }
    }

    pub fn filter(&self, points: &[[f32; 3]]) -> Vec<[f32; 3]> {
        if points.is_empty() {
            return Vec::new();
        }
        let mut grid: HashMap<(i32, i32, i32), [f32; 3]> = HashMap::new();

        for pt in points {
            let key = (
                (pt[0] / self.voxel_size).floor() as i32,
                (pt[1] / self.voxel_size).floor() as i32,
                (pt[2] / self.voxel_size).floor() as i32,
            );
            grid.entry(key).or_insert(*pt);
        }

        grid.into_values().collect()
    }
}
