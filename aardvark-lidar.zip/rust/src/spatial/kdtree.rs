pub struct KDTree3D {
    points: Vec<[f32; 3]>,
}

impl KDTree3D {
    pub fn new(points: Vec<[f32; 3]>) -> Self {
        Self { points }
    }

    pub fn nearest(&self, query: &[f32; 3]) -> Option<(usize, f32)> {
        if self.points.is_empty() {
            return None;
        }
        let mut best_idx = 0;
        let mut best_dist_sq = f32::MAX;

        for (idx, pt) in self.points.iter().enumerate() {
            let dx = pt[0] - query[0];
            let dy = pt[1] - query[1];
            let dz = pt[2] - query[2];
            let dist_sq = dx * dx + dy * dy + dz * dz;
            if dist_sq < best_dist_sq {
                best_dist_sq = dist_sq;
                best_idx = idx;
            }
        }

        Some((best_idx, best_dist_sq.sqrt()))
    }
}
