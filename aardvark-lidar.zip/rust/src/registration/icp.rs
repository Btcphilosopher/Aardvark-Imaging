use crate::geometry::SE3Transform;
use crate::spatial::KDTree3D;
use nalgebra::{Matrix3, Vector3};

pub struct PointToPointICP {
    pub max_iterations: usize,
    pub max_correspondence_distance: f32,
    pub tolerance: f32,
}

impl PointToPointICP {
    pub fn new(max_iterations: usize, max_distance: f32) -> Self {
        Self {
            max_iterations,
            max_correspondence_distance: max_distance,
            tolerance: 1e-4,
        }
    }

    pub fn align(&self, source: &[[f32; 3]], target: &[[f32; 3]]) -> (SE3Transform, f32) {
        if source.is_empty() || target.is_empty() {
            return (SE3Transform::identity(), 0.0);
        }

        let kdtree = KDTree3D::new(target.to_vec());
        let mut current_transform = SE3Transform::identity();
        let mut fitness = 0.0;

        for _ in 0..self.max_iterations {
            let mut matches = 0;
            for pt in source {
                let transformed = current_transform.transform_point(pt);
                if let Some((_, dist)) = kdtree.nearest(&transformed) {
                    if dist <= self.max_correspondence_distance {
                        matches += 1;
                    }
                }
            }
            fitness = matches as f32 / source.len() as f32;
        }

        (current_transform, fitness)
    }
}
