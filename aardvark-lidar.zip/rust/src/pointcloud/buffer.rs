#[derive(Debug, Clone)]
pub struct PointBuffer {
    pub points: Vec<[f32; 3]>,
    pub intensities: Vec<f32>,
    pub ranges: Vec<f32>,
    pub rings: Vec<u16>,
    pub timestamps: Vec<f64>,
    pub flags: Vec<u8>,
}

impl PointBuffer {
    pub fn new() -> Self {
        Self {
            points: Vec::new(),
            intensities: Vec::new(),
            ranges: Vec::new(),
            rings: Vec::new(),
            timestamps: Vec::new(),
            flags: Vec::new(),
        }
    }

    pub fn with_capacity(capacity: usize) -> Self {
        Self {
            points: Vec::with_capacity(capacity),
            intensities: Vec::with_capacity(capacity),
            ranges: Vec::with_capacity(capacity),
            rings: Vec::with_capacity(capacity),
            timestamps: Vec::with_capacity(capacity),
            flags: Vec::with_capacity(capacity),
        }
    }

    pub fn len(&self) -> usize {
        self.points.len()
    }

    pub fn is_empty(&self) -> bool {
        self.points.is_empty()
    }

    pub fn push(&mut self, pt: [f32; 3], intensity: f32, range: f32, ring: u16, ts: f64) {
        self.points.push(pt);
        self.intensities.push(intensity);
        self.ranges.push(range);
        self.rings.push(ring);
        self.timestamps.push(ts);
        self.flags.push(0);
    }
}
