use byteorder::{BigEndian, ByteOrder};

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct RawPointMeasurement {
    pub azimuth_rad: f32,
    pub elevation_rad: f32,
    pub range_m: f32,
    pub intensity: f32,
    pub ring: u16,
    pub return_num: u8,
}

pub struct PacketDecoder {
    pub beam_count: usize,
    vertical_luts: Vec<f32>,
}

impl PacketDecoder {
    pub fn new(beam_count: usize) -> Self {
        let mut luts = Vec::with_capacity(beam_count);
        let min_el = -25.0f32.to_radians();
        let max_el = 15.0f32.to_radians();
        for i in 0..beam_count {
            let ratio = i as f32 / (beam_count - 1).max(1) as f32;
            luts.push(min_el + ratio * (max_el - min_el));
        }
        Self {
            beam_count,
            vertical_luts: luts,
        }
    }

    pub fn decode(&self, bytes: &[u8]) -> Result<Vec<RawPointMeasurement>, &'static str> {
        if bytes.len() < 32 {
            return Err("Packet undersized");
        }
        let magic = BigEndian::read_u16(&bytes[0..2]);
        if magic != 0xA456 {
            return Err("Invalid magic byte");
        }

        let block_count = BigEndian::read_u32(&bytes[20..24]) as usize;
        let mut results = Vec::with_capacity(block_count * self.beam_count);
        let mut offset = 24;

        for _ in 0..block_count {
            if offset + 4 > bytes.len() - 8 {
                break;
            }
            let raw_az = BigEndian::read_u16(&bytes[offset..offset + 2]);
            let az_rad = (raw_az as f32 / 100.0).to_radians();
            offset += 4;

            for beam_id in 0..self.beam_count {
                if offset + 4 > bytes.len() - 8 {
                    break;
                }
                let raw_range = BigEndian::read_u16(&bytes[offset..offset + 2]);
                let intensity = bytes[offset + 2];
                let return_num = bytes[offset + 3];
                offset += 4;

                let range_m = (raw_range as f32) * 0.002;
                let elevation_rad = self.vertical_luts[beam_id % self.beam_count];

                results.push(RawPointMeasurement {
                    azimuth_rad: az_rad,
                    elevation_rad,
                    range_m,
                    intensity: intensity as f32,
                    ring: beam_id as u16,
                    return_num,
                });
            }
        }

        Ok(results)
    }
}
