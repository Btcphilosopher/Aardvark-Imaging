use nalgebra::{Matrix3, Matrix4, Point3, Vector3};

#[derive(Debug, Clone, PartialEq)]
pub struct SE3Transform {
    pub rotation: Matrix3<f64>,
    pub translation: Vector3<f64>,
}

impl SE3Transform {
    pub fn identity() -> Self {
        Self {
            rotation: Matrix3::identity(),
            translation: Vector3::zeros(),
        }
    }

    pub fn new(rotation: Matrix3<f64>, translation: Vector3<f64>) -> Self {
        Self {
            rotation,
            translation,
        }
    }

    pub fn inverse(&self) -> Self {
        let r_inv = self.rotation.transpose();
        let t_inv = -r_inv * self.translation;
        Self {
            rotation: r_inv,
            translation: t_inv,
        }
    }

    pub fn compose(&self, other: &Self) -> Self {
        let r_new = self.rotation * other.rotation;
        let t_new = self.rotation * other.translation + self.translation;
        Self {
            rotation: r_new,
            translation: t_new,
        }
    }

    pub fn transform_point(&self, pt: &[f32; 3]) -> [f32; 3] {
        let p = Point3::new(pt[0] as f64, pt[1] as f64, pt[2] as f64);
        let transformed = self.rotation * p + self.translation;
        [
            transformed.x as f32,
            transformed.y as f32,
            transformed.z as f32,
        ]
    }
}
