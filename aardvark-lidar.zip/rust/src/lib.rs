//! AARDVARK LIDAR High-Performance Rust Computational Core
//!
//! Provides deterministic memory-safe binary packet parsing, SIMD SE(3) transforms,
//! 3D spatial KD-tree indexing, voxel hash decimation, and SVD ICP registration.

pub mod packets;
pub mod geometry;
pub mod pointcloud;
pub mod spatial;
pub mod filtering;
pub mod registration;

pub use packets::decoder::PacketDecoder;
pub use geometry::transforms::SE3Transform;
pub use pointcloud::buffer::PointBuffer;
pub use spatial::kdtree::KDTree3D;
pub use filtering::voxel::VoxelGridFilter;
pub use registration::icp::PointToPointICP;
