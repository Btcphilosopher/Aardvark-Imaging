plugins {
    kotlin("jvm") version "1.9.22"
    application
}

group = "com.aardvark.imaging.lidar"
version = "1.0.0"

repositories {
    mavenCentral()
}

dependencies {
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.8.0")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.3")
    implementation("org.joml:joml:1.10.5")
    testImplementation(kotlin("test"))
    testImplementation("org.junit.jupiter:junit-jupiter:5.10.2")
}

application {
    mainClass.set("com.aardvark.imaging.lidar.MainKt")
}

tasks.test {
    useJUnitPlatform()
}
