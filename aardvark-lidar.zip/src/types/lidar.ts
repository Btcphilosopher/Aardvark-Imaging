/**
 * Canonical TypeScript Types for AARDVARK LIDAR Platform.
 */

export type SensorState = 'DISCONNECTED' | 'CONNECTING' | 'CONNECTED' | 'STREAMING' | 'FAULT';
export type HealthState = 'HEALTHY' | 'DEGRADED' | 'WARNING' | 'FAULT';

export type ColorMode = 
  | 'height' 
  | 'intensity' 
  | 'range' 
  | 'ring' 
  | 'ground' 
  | 'cluster' 
  | 'timestamp';

export type CameraPreset = 'orbit' | 'fps' | 'top' | 'front' | 'side' | 'sensor';

export type ScenarioId = 
  | 'industrial_warehouse' 
  | 'urban_street' 
  | 'empty_room' 
  | 'robot_inspection' 
  | 'fault_scenario';

export interface Point3D {
  x: number;
  y: number;
  z: number;
  intensity: number;
  range: number;
  azimuth: number;
  elevation: number;
  ring: number;
  timestamp: number;
  flags: number; // 0x01 ground, 0x02 outlier, 0x04 valid
  clusterId?: number;
}

export interface PointCloudData {
  points: Float32Array; // Flattened [x, y, z, ...]
  intensities: Float32Array;
  ranges: Float32Array;
  azimuths: Float32Array;
  elevations: Float32Array;
  rings: Uint16Array;
  timestamps: Float64Array;
  flags: Uint8Array;
  clusterIds: Int16Array;
  count: number;
  boundingBox: {
    min: [number, number, number];
    max: [number, number, number];
  };
  centroid: [number, number, number];
}

export interface SensorConfig {
  sensorId: string;
  manufacturer: string;
  model: string;
  serialNumber: string;
  beamCount: number; // 16, 32, 64, 128
  rotationRateHz: number; // 5.0 - 20.0 Hz (300 - 1200 RPM)
  horizontalFovDeg: number;
  verticalFovDeg: number;
  minRangeM: number;
  maxRangeM: number;
  ipAddress: string;
  udpPort: number;
  noiseStdM: number;
}

export interface SensorTelemetry {
  fps: number;
  pointsPerSec: number;
  packetRateHz: number;
  packetLossPct: number;
  ingestionLatencyMs: number;
  decodeLatencyMs: number;
  filterLatencyMs: number;
  renderLatencyMs: number;
  totalLatencyMs: number;
  opticalTempC: number;
  targetRpm: number;
  measuredRpm: number;
  jitterMs: number;
  invalidPointPct: number;
  healthState: HealthState;
  activeAlarms: string[];
}

export interface SE3Pose {
  translation: [number, number, number];
  rotationMatrix: number[][]; // 3x3
  eulerDeg: [number, number, number]; // [roll, pitch, yaw]
}

export interface GroundPlaneResult {
  normal: [number, number, number];
  distance: number;
  inlierCount: number;
  inlierRatio: number;
  slopeDeg: number;
}

export interface DetectedCluster {
  id: number;
  centroid: [number, number, number];
  dimensions: [number, number, number]; // [width, length, height]
  pointCount: number;
  confidence: number;
  classHint: 'Vehicle' | 'Pedestrian' | 'Machinery' | 'Tree' | 'Structure' | 'Unknown';
}

export interface FilterSettings {
  enableRangeFilter: boolean;
  minRangeM: number;
  maxRangeM: number;
  enableRoiFilter: boolean;
  roiBounds: {
    xMin: number;
    xMax: number;
    yMin: number;
    yMax: number;
    zMin: number;
    zMax: number;
  };
  enableVoxelFilter: boolean;
  voxelSizeM: number;
  enableRansacGround: boolean;
  groundDistanceThreshM: number;
  groundSlopeLimitDeg: number;
  enableClustering: boolean;
  clusterDistanceThreshM: number;
  minClusterPoints: number;
}

export interface ICPMetrics {
  converged: boolean;
  iterations: number;
  residualRmse: number;
  fitnessScore: number;
  durationMs: number;
  estimatedTransform: SE3Pose;
}

export interface RawPacketRecord {
  seq: number;
  timestampSensor: number;
  timestampHost: number;
  sizeBytes: number;
  blockCount: number;
  startAzimuthDeg: number;
  endAzimuthDeg: number;
  status: number;
  checksumValid: boolean;
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  actor: string;
  eventType: string;
  objectId: string;
  description: string;
  status: 'SUCCESS' | 'WARNING' | 'FAILED';
}

export interface SpatialMeasurement {
  id: string;
  type: 'PointToPoint' | 'PointToPlane' | 'BoundingBoxVolume' | 'SlopeClearance';
  name: string;
  value: number;
  unit: string;
  uncertainty: number;
  p1: [number, number, number];
  p2?: [number, number, number];
  details: Record<string, any>;
  timestamp: string;
}
