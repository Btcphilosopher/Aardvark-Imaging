/**
 * Real-Time 3D Ray-Casting LiDAR Simulation & Digital Twin Engine.
 */
import { PointCloudData, SensorConfig, ScenarioId, RawPacketRecord } from '../../types/lidar';

export interface SceneObject {
  type: 'box' | 'cylinder' | 'sphere' | 'plane';
  center: [number, number, number];
  size: [number, number, number]; // [w, l, h]
  reflectivity: number;
  label: 'Vehicle' | 'Pedestrian' | 'Machinery' | 'Tree' | 'Structure';
}

export class LidarSimulator {
  private config: SensorConfig;
  private scenario: ScenarioId;
  private objects: SceneObject[] = [];
  private currentAzimuthDeg = 0.0;
  private packetSequence = 1000;
  private sensorMountZ = 1.8; // Sensor 1.8m above ground
  private verticalAnglesRad: number[] = [];

  constructor(config: SensorConfig, scenario: ScenarioId = 'industrial_warehouse') {
    this.config = config;
    this.scenario = scenario;
    this.initBeams();
    this.loadScenario(scenario);
  }

  private initBeams() {
    this.verticalAnglesRad = [];
    const minAngle = (-this.config.verticalFovDeg / 2.0) * (Math.PI / 180.0);
    const maxAngle = (this.config.verticalFovDeg / 2.0) * (Math.PI / 180.0);
    const step = (maxAngle - minAngle) / Math.max(1, this.config.beamCount - 1);

    for (let i = 0; i < this.config.beamCount; i++) {
      this.verticalAnglesRad.push(minAngle + i * step);
    }
  }

  public setScenario(scenario: ScenarioId) {
    this.scenario = scenario;
    this.loadScenario(scenario);
  }

  public updateConfig(config: Partial<SensorConfig>) {
    this.config = { ...this.config, ...config };
    this.initBeams();
  }

  private loadScenario(scenario: ScenarioId) {
    this.objects = [];

    // Ground plane (z = 0)
    this.objects.push({
      type: 'plane',
      center: [0, 0, 0],
      size: [80, 80, 0],
      reflectivity: 120,
      label: 'Structure'
    });

    if (scenario === 'industrial_warehouse') {
      // Perimeter walls
      this.objects.push({ type: 'box', center: [20, 0, 3], size: [0.6, 40, 6], reflectivity: 160, label: 'Structure' });
      this.objects.push({ type: 'box', center: [-20, 0, 3], size: [0.6, 40, 6], reflectivity: 160, label: 'Structure' });
      this.objects.push({ type: 'box', center: [0, 20, 3], size: [40, 0.6, 6], reflectivity: 160, label: 'Structure' });
      this.objects.push({ type: 'box', center: [0, -20, 3], size: [40, 0.6, 6], reflectivity: 160, label: 'Structure' });

      // Machinery & Cargo Containers
      this.objects.push({ type: 'box', center: [6, 4, 1.2], size: [2.5, 3.5, 2.4], reflectivity: 220, label: 'Machinery' });
      this.objects.push({ type: 'box', center: [10, -6, 1.0], size: [3.0, 2.0, 2.0], reflectivity: 180, label: 'Machinery' });
      this.objects.push({ type: 'cylinder', center: [-8, 6, 2.0], size: [1.8, 1.8, 4.0], reflectivity: 240, label: 'Machinery' });
      this.objects.push({ type: 'box', center: [-6, -10, 1.5], size: [4.0, 2.5, 3.0], reflectivity: 150, label: 'Structure' });
      this.objects.push({ type: 'box', center: [0, 8, 1.0], size: [1.5, 1.5, 2.0], reflectivity: 190, label: 'Machinery' });

    } else if (scenario === 'urban_street') {
      // Road corridor
      this.objects.push({ type: 'box', center: [12, 3.5, 0.8], size: [4.8, 2.1, 1.6], reflectivity: 230, label: 'Vehicle' }); // Sedan
      this.objects.push({ type: 'box', center: [-10, -3.5, 1.2], size: [6.5, 2.4, 2.4], reflectivity: 200, label: 'Vehicle' }); // Van
      this.objects.push({ type: 'cylinder', center: [8, -5.5, 2.5], size: [0.6, 0.6, 5.0], reflectivity: 80, label: 'Tree' });
      this.objects.push({ type: 'cylinder', center: [16, -5.5, 2.5], size: [0.6, 0.6, 5.0], reflectivity: 80, label: 'Tree' });
      this.objects.push({ type: 'box', center: [4.5, 5.0, 0.9], size: [0.5, 0.5, 1.8], reflectivity: 70, label: 'Pedestrian' });
      this.objects.push({ type: 'box', center: [0, 12, 6], size: [50, 0.8, 12], reflectivity: 140, label: 'Structure' });

    } else if (scenario === 'empty_room') {
      // Survey Calibration Room
      this.objects.push({ type: 'box', center: [8, 0, 2], size: [0.2, 12, 4], reflectivity: 210, label: 'Structure' });
      this.objects.push({ type: 'box', center: [-8, 0, 2], size: [0.2, 12, 4], reflectivity: 210, label: 'Structure' });
      this.objects.push({ type: 'box', center: [0, 6, 2], size: [16, 0.2, 4], reflectivity: 210, label: 'Structure' });
      this.objects.push({ type: 'box', center: [0, -6, 2], size: [16, 0.2, 4], reflectivity: 210, label: 'Structure' });

    } else if (scenario === 'robot_inspection') {
      // Robot inspection environment with precision machinery
      this.objects.push({ type: 'box', center: [4, 0, 1.0], size: [1.8, 1.8, 2.0], reflectivity: 240, label: 'Machinery' });
      this.objects.push({ type: 'cylinder', center: [4, 3.5, 1.5], size: [1.2, 1.2, 3.0], reflectivity: 220, label: 'Machinery' });
      this.objects.push({ type: 'cylinder', center: [4, -3.5, 1.5], size: [1.2, 1.2, 3.0], reflectivity: 220, label: 'Machinery' });
      this.objects.push({ type: 'box', center: [8, 0, 1.5], size: [0.4, 6.0, 3.0], reflectivity: 180, label: 'Structure' });

    } else { // fault_scenario (high noise / vibrating)
      this.objects.push({ type: 'box', center: [5, 2, 1], size: [2, 2, 2], reflectivity: 190, label: 'Machinery' });
      this.objects.push({ type: 'box', center: [-6, -2, 1.2], size: [3, 2, 2.4], reflectivity: 170, label: 'Structure' });
    }
  }

  /**
   * Generates a complete 360-degree scan (or custom FOV) with real physics ray tracing.
   */
  public generateScan(options?: { azimuthStepDeg?: number; noiseMultiplier?: number }): { cloud: PointCloudData; packets: RawPacketRecord[] } {
    const stepDeg = options?.azimuthStepDeg ?? (this.config.beamCount >= 64 ? 0.4 : 0.6);
    const noiseMult = options?.noiseMultiplier ?? 1.0;
    const noiseStd = this.config.noiseStdM * noiseMult;

    const azimuthSteps = Math.floor(this.config.horizontalFovDeg / stepDeg);
    const totalPossiblePoints = azimuthSteps * this.config.beamCount;

    // Allocate flat buffers
    const points = new Float32Array(totalPossiblePoints * 3);
    const intensities = new Float32Array(totalPossiblePoints);
    const ranges = new Float32Array(totalPossiblePoints);
    const azimuths = new Float32Array(totalPossiblePoints);
    const elevations = new Float32Array(totalPossiblePoints);
    const rings = new Uint16Array(totalPossiblePoints);
    const timestamps = new Float64Array(totalPossiblePoints);
    const flags = new Uint8Array(totalPossiblePoints);
    const clusterIds = new Int16Array(totalPossiblePoints);

    let validCount = 0;
    const origin = [0, 0, this.sensorMountZ];
    const now = Date.now() / 1000.0;

    let minX = Infinity, minY = Infinity, minZ = Infinity;
    let maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
    let sumX = 0, sumY = 0, sumZ = 0;

    const packets: RawPacketRecord[] = [];
    let currentPacketAzimuthStart = 0;
    const blocksPerPacket = 12;
    let blockCounter = 0;

    for (let azIdx = 0; azIdx < azimuthSteps; azIdx++) {
      const azDeg = azIdx * stepDeg;
      const azRad = azDeg * (Math.PI / 180.0);
      const cosAz = Math.cos(azRad);
      const sinAz = Math.sin(azRad);

      if (blockCounter === 0) {
        currentPacketAzimuthStart = azDeg;
      }
      blockCounter++;
      if (blockCounter >= blocksPerPacket || azIdx === azimuthSteps - 1) {
        this.packetSequence++;
        packets.push({
          seq: this.packetSequence,
          timestampSensor: now * 1e6,
          timestampHost: now,
          sizeBytes: 1206,
          blockCount: blockCounter,
          startAzimuthDeg: currentPacketAzimuthStart,
          endAzimuthDeg: azDeg,
          status: 0x00,
          checksumValid: true
        });
        blockCounter = 0;
      }

      for (let beamIdx = 0; beamIdx < this.config.beamCount; beamIdx++) {
        const elRad = this.verticalAnglesRad[beamIdx];
        const cosEl = Math.cos(elRad);
        const sinEl = Math.sin(elRad);

        const rayDir: [number, number, number] = [
          cosEl * cosAz,
          cosEl * sinAz,
          sinEl
        ];

        // Raycast against ground (z = 0)
        let minHitDist = this.config.maxRangeM;
        let hitReflectivity = 50;

        if (rayDir[2] < -1e-4) {
          const tGround = -origin[2] / rayDir[2];
          if (tGround > 0 && tGround < minHitDist) {
            minHitDist = tGround;
            hitReflectivity = 120;
          }
        }

        // Raycast against objects
        for (const obj of this.objects) {
          if (obj.type === 'box') {
            const hw = obj.size[0] / 2.0;
            const hl = obj.size[1] / 2.0;
            const hh = obj.size[2] / 2.0;

            const bMin = [obj.center[0] - hw, obj.center[1] - hl, obj.center[2] - hh];
            const bMax = [obj.center[0] + hw, obj.center[1] + hl, obj.center[2] + hh];

            const invX = Math.abs(rayDir[0]) > 1e-6 ? 1.0 / rayDir[0] : 1e9;
            const invY = Math.abs(rayDir[1]) > 1e-6 ? 1.0 / rayDir[1] : 1e9;
            const invZ = Math.abs(rayDir[2]) > 1e-6 ? 1.0 / rayDir[2] : 1e9;

            const t1x = (bMin[0] - origin[0]) * invX;
            const t2x = (bMax[0] - origin[0]) * invX;
            const t1y = (bMin[1] - origin[1]) * invY;
            const t2y = (bMax[1] - origin[1]) * invY;
            const t1z = (bMin[2] - origin[2]) * invZ;
            const t2z = (bMax[2] - origin[2]) * invZ;

            const tEnter = Math.max(Math.min(t1x, t2x), Math.min(t1y, t2y), Math.min(t1z, t2z));
            const tExit = Math.min(Math.max(t1x, t2x), Math.max(t1y, t2y), Math.max(t1z, t2z));

            if (tEnter < tExit && tExit > 0 && tEnter < minHitDist) {
              const hit = tEnter > 0 ? tEnter : tExit;
              if (hit < minHitDist) {
                minHitDist = hit;
                hitReflectivity = obj.reflectivity;
              }
            }
          } else if (obj.type === 'cylinder') {
            const dx = origin[0] - obj.center[0];
            const dy = origin[1] - obj.center[1];
            const rCyl = obj.size[0] / 2.0;
            const hCyl = obj.size[2];

            const a = rayDir[0] * rayDir[0] + rayDir[1] * rayDir[1];
            const b = 2.0 * (dx * rayDir[0] + dy * rayDir[1]);
            const c = dx * dx + dy * dy - rCyl * rCyl;
            const disc = b * b - 4.0 * a * c;

            if (disc >= 0 && a > 1e-6) {
              const sqrtDisc = Math.sqrt(disc);
              const tCyl = (-b - sqrtDisc) / (2.0 * a);
              if (tCyl > 0 && tCyl < minHitDist) {
                const hitZ = origin[2] + tCyl * rayDir[2];
                if (hitZ >= 0 && hitZ <= hCyl) {
                  minHitDist = tCyl;
                  hitReflectivity = obj.reflectivity;
                }
              }
            }
          }
        }

        if (minHitDist < this.config.maxRangeM && minHitDist >= this.config.minRangeM) {
          // Add Gaussian noise
          const noise = (Math.random() - 0.5) * 2.0 * noiseStd;
          const finalRange = Math.max(0.1, minHitDist + noise);

          const px = finalRange * rayDir[0];
          const py = finalRange * rayDir[1];
          const pz = finalRange * rayDir[2] + origin[2];

          const pIdx = validCount * 3;
          points[pIdx] = px;
          points[pIdx + 1] = py;
          points[pIdx + 2] = pz;

          // Intensity based on target reflectivity and inverse square falloff
          const intensity = Math.min(255, Math.max(10, (hitReflectivity * 12.0) / Math.max(1.0, finalRange)));
          intensities[validCount] = intensity;
          ranges[validCount] = finalRange;
          azimuths[validCount] = azRad;
          elevations[validCount] = elRad;
          rings[validCount] = beamIdx;
          timestamps[validCount] = now + azIdx * 0.0001;
          flags[validCount] = 0x04; // Valid
          clusterIds[validCount] = -1;

          if (px < minX) minX = px; if (px > maxX) maxX = px;
          if (py < minY) minY = py; if (py > maxY) maxY = py;
          if (pz < minZ) minZ = pz; if (pz > maxZ) maxZ = pz;
          sumX += px; sumY += py; sumZ += pz;

          validCount++;
        }
      }
    }

    const trimmedPoints = points.slice(0, validCount * 3);
    const trimmedIntensities = intensities.slice(0, validCount);
    const trimmedRanges = ranges.slice(0, validCount);
    const trimmedAzimuths = azimuths.slice(0, validCount);
    const trimmedElevations = elevations.slice(0, validCount);
    const trimmedRings = rings.slice(0, validCount);
    const trimmedTimestamps = timestamps.slice(0, validCount);
    const trimmedFlags = flags.slice(0, validCount);
    const trimmedClusterIds = clusterIds.slice(0, validCount);

    const cloud: PointCloudData = {
      points: trimmedPoints,
      intensities: trimmedIntensities,
      ranges: trimmedRanges,
      azimuths: trimmedAzimuths,
      elevations: trimmedElevations,
      rings: trimmedRings,
      timestamps: trimmedTimestamps,
      flags: trimmedFlags,
      clusterIds: trimmedClusterIds,
      count: validCount,
      boundingBox: {
        min: [minX === Infinity ? 0 : minX, minY === Infinity ? 0 : minY, minZ === Infinity ? 0 : minZ],
        max: [maxX === -Infinity ? 0 : maxX, maxY === -Infinity ? 0 : maxY, maxZ === -Infinity ? 0 : maxZ]
      },
      centroid: validCount > 0 ? [sumX / validCount, sumY / validCount, sumZ / validCount] : [0, 0, 0]
    };

    return { cloud, packets };
  }
}
