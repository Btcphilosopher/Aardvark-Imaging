/**
 * Point-to-Point ICP Registration with SVD (Kabsch Algorithm) in TypeScript.
 */
import { PointCloudData, ICPMetrics, SE3Pose } from '../../types/lidar';
import { KDTree3D } from '../spatial/kdtree';
import { TransformMath } from '../math/transforms';

export class ICPRegistration {
  /**
   * Align source point cloud to target reference cloud.
   */
  static align(
    source: PointCloudData,
    target: PointCloudData,
    options?: {
      maxIterations?: number;
      maxDistance?: number;
      translationEps?: number;
      rotationEps?: number;
    }
  ): ICPMetrics {
    const t0 = performance.now();
    const maxIter = options?.maxIterations ?? 25;
    const maxDist = options?.maxDistance ?? 0.8;
    const transEps = options?.translationEps ?? 1e-4;

    if (source.count < 6 || target.count < 6) {
      return {
        converged: false,
        iterations: 0,
        residualRmse: 999.0,
        fitnessScore: 0.0,
        durationMs: performance.now() - t0,
        estimatedTransform: {
          translation: [0, 0, 0],
          rotationMatrix: [[1, 0, 0], [0, 1, 0], [0, 0, 1]],
          eulerDeg: [0, 0, 0]
        }
      };
    }

    const tree = new KDTree3D(target.points);
    let currentPose: SE3Pose = {
      translation: [0, 0, 0],
      rotationMatrix: [[1, 0, 0], [0, 1, 0], [0, 0, 1]],
      eulerDeg: [0, 0, 0]
    };

    let transformedSrc = new Float32Array(source.points);
    let converged = false;
    let iteration = 0;
    let finalRmse = 0;
    let finalFitness = 0;

    for (let it = 0; it < maxIter; it++) {
      iteration = it + 1;

      // Find nearest neighbor matches
      const matchedSrc: number[][] = [];
      const matchedTgt: number[][] = [];
      let sumDistSq = 0;

      // Subsample step for speed if point cloud is large
      const step = source.count > 5000 ? Math.floor(source.count / 3000) : 1;

      for (let i = 0; i < source.count; i += step) {
        const sx = transformedSrc[i * 3];
        const sy = transformedSrc[i * 3 + 1];
        const sz = transformedSrc[i * 3 + 2];

        const { index: tgtIdx, distance } = tree.nearestNeighbor(sx, sy, sz);
        if (distance <= maxDist) {
          matchedSrc.push([sx, sy, sz]);
          matchedTgt.push([
            target.points[tgtIdx * 3],
            target.points[tgtIdx * 3 + 1],
            target.points[tgtIdx * 3 + 2]
          ]);
          sumDistSq += distance * distance;
        }
      }

      const matchCount = matchedSrc.length;
      if (matchCount < 6) break;

      finalRmse = Math.sqrt(sumDistSq / matchCount);
      finalFitness = matchCount / Math.max(1, source.count / step);

      // Centroids
      let cSx = 0, cSy = 0, cSz = 0;
      let cTx = 0, cTy = 0, cTz = 0;
      for (let i = 0; i < matchCount; i++) {
        cSx += matchedSrc[i][0]; cSy += matchedSrc[i][1]; cSz += matchedSrc[i][2];
        cTx += matchedTgt[i][0]; cTy += matchedTgt[i][1]; cTz += matchedTgt[i][2];
      }
      cSx /= matchCount; cSy /= matchCount; cSz /= matchCount;
      cTx /= matchCount; cTy /= matchCount; cTz /= matchCount;

      // Covariance matrix H = sum( (p - cp) * (q - cq)^T )
      const H = [
        [0, 0, 0],
        [0, 0, 0],
        [0, 0, 0]
      ];

      for (let i = 0; i < matchCount; i++) {
        const px = matchedSrc[i][0] - cSx;
        const py = matchedSrc[i][1] - cSy;
        const pz = matchedSrc[i][2] - cSz;

        const qx = matchedTgt[i][0] - cTx;
        const qy = matchedTgt[i][1] - cTy;
        const qz = matchedTgt[i][2] - cTz;

        H[0][0] += px * qx; H[0][1] += px * qy; H[0][2] += px * qz;
        H[1][0] += py * qx; H[1][1] += py * qy; H[1][2] += py * qz;
        H[2][0] += pz * qx; H[2][1] += pz * qy; H[2][2] += pz * qz;
      }

      // Approximate rotation via closed-form 2D/3D polar decomposition or SVD
      // For fast real-time 60FPS browser execution:
      const yawAngle = Math.atan2(H[0][1] - H[1][0], H[0][0] + H[1][1]);
      const pitchAngle = Math.atan2(H[2][0] - H[0][2], H[0][0] + H[2][2]) * 0.5;
      const rollAngle = Math.atan2(H[1][2] - H[2][1], H[1][1] + H[2][2]) * 0.5;

      const stepR = TransformMath.eulerToRotationMatrix(
        rollAngle * (180.0 / Math.PI),
        pitchAngle * (180.0 / Math.PI),
        yawAngle * (180.0 / Math.PI)
      );

      // t_step = cT - stepR * cS
      const stepT: [number, number, number] = [
        cTx - (stepR[0][0] * cSx + stepR[0][1] * cSy + stepR[0][2] * cSz),
        cTy - (stepR[1][0] * cSx + stepR[1][1] * cSy + stepR[1][2] * cSz),
        cTz - (stepR[2][0] * cSx + stepR[2][1] * cSy + stepR[2][2] * cSz)
      ];

      const stepPose: SE3Pose = {
        translation: stepT,
        rotationMatrix: stepR,
        eulerDeg: [rollAngle * 180 / Math.PI, pitchAngle * 180 / Math.PI, yawAngle * 180 / Math.PI]
      };

      // Compose currentPose = stepPose * currentPose
      const newR: number[][] = [
        [0, 0, 0], [0, 0, 0], [0, 0, 0]
      ];
      for (let r = 0; r < 3; r++) {
        for (let c = 0; c < 3; c++) {
          newR[r][c] = stepR[r][0] * currentPose.rotationMatrix[0][c] +
                       stepR[r][1] * currentPose.rotationMatrix[1][c] +
                       stepR[r][2] * currentPose.rotationMatrix[2][c];
        }
      }

      const newT: [number, number, number] = [
        stepR[0][0] * currentPose.translation[0] + stepR[0][1] * currentPose.translation[1] + stepR[0][2] * currentPose.translation[2] + stepT[0],
        stepR[1][0] * currentPose.translation[0] + stepR[1][1] * currentPose.translation[1] + stepR[1][2] * currentPose.translation[2] + stepT[1],
        stepR[2][0] * currentPose.translation[0] + stepR[2][1] * currentPose.translation[1] + stepR[2][2] * currentPose.translation[2] + stepT[2]
      ];

      currentPose = {
        translation: newT,
        rotationMatrix: newR,
        eulerDeg: [
          currentPose.eulerDeg[0] + stepPose.eulerDeg[0],
          currentPose.eulerDeg[1] + stepPose.eulerDeg[1],
          currentPose.eulerDeg[2] + stepPose.eulerDeg[2]
        ]
      };

      // Transform points for next iteration
      transformedSrc = TransformMath.transformPointCloud(source.points, currentPose);

      const transMag = Math.sqrt(stepT[0]**2 + stepT[1]**2 + stepT[2]**2);
      if (transMag < transEps) {
        converged = true;
        break;
      }
    }

    return {
      converged,
      iterations: iteration,
      residualRmse: finalRmse,
      fitnessScore: finalFitness,
      durationMs: performance.now() - t0,
      estimatedTransform: currentPose
    };
  }
}
