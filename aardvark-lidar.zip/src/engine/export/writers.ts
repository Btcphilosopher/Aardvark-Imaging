/**
 * Client-Side Point Cloud Exporters and Downloader.
 */
import { PointCloudData } from '../../types/lidar';

export class PointCloudDownloader {
  static exportPLY(cloud: PointCloudData, filename = 'aardvark_scan.ply') {
    const n = cloud.count;
    const header = [
      'ply',
      'format ascii 1.0',
      'comment AARDVARK LIDAR Perception Engine Export',
      `element vertex ${n}`,
      'property float x',
      'property float y',
      'property float z',
      'property float intensity',
      'property float range',
      'property ushort ring',
      'property uchar flags',
      'property short cluster_id',
      'end_header\n'
    ].join('\n');

    const lines: string[] = [header];
    for (let i = 0; i < n; i++) {
      const x = cloud.points[i * 3].toFixed(4);
      const y = cloud.points[i * 3 + 1].toFixed(4);
      const z = cloud.points[i * 3 + 2].toFixed(4);
      const intensity = cloud.intensities[i].toFixed(1);
      const range = cloud.ranges[i].toFixed(3);
      const ring = cloud.rings[i];
      const flags = cloud.flags[i];
      const clusterId = cloud.clusterIds[i];
      lines.push(`${x} ${y} ${z} ${intensity} ${range} ${ring} ${flags} ${clusterId}`);
    }

    const blob = new Blob([lines.join('\n')], { type: 'text/plain' });
    this.triggerDownload(blob, filename);
  }

  static exportPCD(cloud: PointCloudData, filename = 'aardvark_scan.pcd') {
    const n = cloud.count;
    const header = [
      '# .PCD v0.7 - Point Cloud Data file format',
      'VERSION 0.7',
      'FIELDS x y z intensity ring',
      'SIZE 4 4 4 4 2',
      'TYPE F F F F U',
      'COUNT 1 1 1 1 1',
      `WIDTH ${n}`,
      'HEIGHT 1',
      'VIEWPOINT 0 0 0 1 0 0 0',
      `POINTS ${n}`,
      'DATA ascii\n'
    ].join('\n');

    const lines: string[] = [header];
    for (let i = 0; i < n; i++) {
      const x = cloud.points[i * 3].toFixed(4);
      const y = cloud.points[i * 3 + 1].toFixed(4);
      const z = cloud.points[i * 3 + 2].toFixed(4);
      const intensity = cloud.intensities[i].toFixed(1);
      const ring = cloud.rings[i];
      lines.push(`${x} ${y} ${z} ${intensity} ${ring}`);
    }

    const blob = new Blob([lines.join('\n')], { type: 'text/plain' });
    this.triggerDownload(blob, filename);
  }

  static exportCSV(cloud: PointCloudData, filename = 'aardvark_scan.csv') {
    const n = cloud.count;
    const lines: string[] = ['x,y,z,intensity,range,azimuth_rad,elevation_rad,ring,flags,cluster_id'];
    for (let i = 0; i < n; i++) {
      lines.push([
        cloud.points[i * 3].toFixed(4),
        cloud.points[i * 3 + 1].toFixed(4),
        cloud.points[i * 3 + 2].toFixed(4),
        cloud.intensities[i].toFixed(1),
        cloud.ranges[i].toFixed(3),
        cloud.azimuths[i].toFixed(4),
        cloud.elevations[i].toFixed(4),
        cloud.rings[i],
        cloud.flags[i],
        cloud.clusterIds[i]
      ].join(','));
    }

    const blob = new Blob([lines.join('\n')], { type: 'text/csv' });
    this.triggerDownload(blob, filename);
  }

  static exportJSON(data: any, filename = 'aardvark_project.json') {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    this.triggerDownload(blob, filename);
  }

  private static triggerDownload(blob: Blob, filename: string) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
}
