/**
 * Global 3D SLAM Map Accumulator & Keyframe Graph in TypeScript.
 */
import { PointCloudData, SE3Pose } from '../../types/lidar';
import { TransformMath } from '../math/transforms';
import { FilterPipeline } from '../pipeline/filters';

export interface KeyframeRecord {
  id: string;
  timestamp: number;
  pose: SE3Pose;
  pointCount: number;
}

export class MapAccumulator {
  private keyframes: KeyframeRecord[] = [];
  private accumulatedPoints: number[] = [];
  private accumulatedIntensities: number[] = [];
  private accumulatedRings: number[] = [];
  private voxelResolutionM = 0.08;
  private maxPoints = 250_000;

  constructor(voxelResolutionM = 0.08) {
    this.voxelResolutionM = voxelResolutionM;
  }

  public setVoxelResolution(resM: number) {
    this.voxelResolutionM = Math.max(0.02, resM);
  }

  public clear() {
    this.keyframes = [];
    this.accumulatedPoints = [];
    this.accumulatedIntensities = [];
    this.accumulatedRings = [];
  }

  public addKeyframe(cloud: PointCloudData, pose: SE3Pose): { keyframeId: string; totalMapPoints: number } {
    const kfId = `kf_${Date.now()}_${this.keyframes.length + 1}`;
    
    // Transform local scan to world frame
    const worldCoords = TransformMath.transformPointCloud(cloud.points, pose);

    // Merge into flat accumulator
    for (let i = 0; i < cloud.count; i++) {
      this.accumulatedPoints.push(
        worldCoords[i * 3],
        worldCoords[i * 3 + 1],
        worldCoords[i * 3 + 2]
      );
      this.accumulatedIntensities.push(cloud.intensities[i]);
      this.accumulatedRings.push(cloud.rings[i]);
    }

    this.keyframes.push({
      id: kfId,
      timestamp: Date.now() / 1000.0,
      pose,
      pointCount: cloud.count
    });

    // Regularize with voxel filtering if size gets large
    if (this.accumulatedPoints.length / 3 > 30_000) {
      this.voxelDecimate();
    }

    return {
      keyframeId: kfId,
      totalMapPoints: Math.floor(this.accumulatedPoints.length / 3)
    };
  }

  private voxelDecimate() {
    const count = Math.floor(this.accumulatedPoints.length / 3);
    const voxelMap = new Map<string, number>();

    for (let i = 0; i < count; i++) {
      const vx = Math.floor(this.accumulatedPoints[i * 3] / this.voxelResolutionM);
      const vy = Math.floor(this.accumulatedPoints[i * 3 + 1] / this.voxelResolutionM);
      const vz = Math.floor(this.accumulatedPoints[i * 3 + 2] / this.voxelResolutionM);
      const key = `${vx},${vy},${vz}`;
      if (!voxelMap.has(key)) {
        voxelMap.set(key, i);
      }
    }

    const indices = Array.from(voxelMap.values());
    const newPts: number[] = [];
    const newInt: number[] = [];
    const newRng: number[] = [];

    for (const idx of indices) {
      newPts.push(
        this.accumulatedPoints[idx * 3],
        this.accumulatedPoints[idx * 3 + 1],
        this.accumulatedPoints[idx * 3 + 2]
      );
      newInt.push(this.accumulatedIntensities[idx]);
      newRng.push(this.accumulatedRings[idx]);
    }

    this.accumulatedPoints = newPts;
    this.accumulatedIntensities = newInt;
    this.accumulatedRings = newRng;
  }

  public getMapCloud(): PointCloudData {
    const count = Math.floor(this.accumulatedPoints.length / 3);
    const points = new Float32Array(this.accumulatedPoints);
    const intensities = new Float32Array(this.accumulatedIntensities);
    const ranges = new Float32Array(count);
    const azimuths = new Float32Array(count);
    const elevations = new Float32Array(count);
    const rings = new Uint16Array(this.accumulatedRings);
    const timestamps = new Float64Array(count);
    const flags = new Uint8Array(count);
    const clusterIds = new Int16Array(count);
    clusterIds.fill(-1);

    let minX = Infinity, minY = Infinity, minZ = Infinity;
    let maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
    let sumX = 0, sumY = 0, sumZ = 0;

    for (let i = 0; i < count; i++) {
      const px = points[i * 3];
      const py = points[i * 3 + 1];
      const pz = points[i * 3 + 2];
      ranges[i] = Math.sqrt(px * px + py * py + pz * pz);
      if (px < minX) minX = px; if (px > maxX) maxX = px;
      if (py < minY) minY = py; if (py > maxY) maxY = py;
      if (pz < minZ) minZ = pz; if (pz > maxZ) maxZ = pz;
      sumX += px; sumY += py; sumZ += pz;
    }

    return {
      points,
      intensities,
      ranges,
      azimuths,
      elevations,
      rings,
      timestamps,
      flags,
      clusterIds,
      count,
      boundingBox: {
        min: [minX === Infinity ? 0 : minX, minY === Infinity ? 0 : minY, minZ === Infinity ? 0 : minZ],
        max: [maxX === -Infinity ? 0 : maxX, maxY === -Infinity ? 0 : maxY, maxZ === -Infinity ? 0 : maxZ]
      },
      centroid: count > 0 ? [sumX / count, sumY / count, sumZ / count] : [0, 0, 0]
    };
  }

  public getKeyframes(): KeyframeRecord[] {
    return this.keyframes;
  }
}
