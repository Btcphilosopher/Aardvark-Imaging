/**
 * Real-Time Point Cloud Processing, RANSAC Ground Segmentation, and Euclidean 3D Clustering.
 */
import { PointCloudData, FilterSettings, GroundPlaneResult, DetectedCluster } from '../../types/lidar';
import { KDTree3D } from '../spatial/kdtree';

export class FilterPipeline {
  /**
   * Execute full composable perception filter chain.
   */
  static process(
    rawCloud: PointCloudData,
    settings: FilterSettings
  ): {
    cloud: PointCloudData;
    groundPlane?: GroundPlaneResult;
    clusters: DetectedCluster[];
    metrics: {
      inputCount: number;
      filteredCount: number;
      groundCount: number;
      clusterCount: number;
      durationMs: number;
    };
  } {
    const t0 = performance.now();
    let current = rawCloud;

    // 1. Range Filtering & NaN check
    if (settings.enableRangeFilter) {
      current = this.applyRangeFilter(current, settings.minRangeM, settings.maxRangeM);
    }

    // 2. ROI Cropping
    if (settings.enableRoiFilter) {
      current = this.applyRoiFilter(current, settings.roiBounds);
    }

    // 3. Voxel Grid Downsampling
    if (settings.enableVoxelFilter) {
      current = this.applyVoxelFilter(current, settings.voxelSizeM);
    }

    let groundResult: GroundPlaneResult | undefined;

    // 4. RANSAC Ground Segmentation
    if (settings.enableRansacGround && current.count > 10) {
      const { updatedCloud, plane } = this.applyRansacGround(
        current,
        settings.groundDistanceThreshM,
        settings.groundSlopeLimitDeg
      );
      current = updatedCloud;
      groundResult = plane;
    }

    // 5. 3D Euclidean Clustering (on non-ground points)
    let clusters: DetectedCluster[] = [];
    if (settings.enableClustering && current.count > 10) {
      const clusterRes = this.extractClusters(
        current,
        settings.clusterDistanceThreshM,
        settings.minClusterPoints
      );
      current = clusterRes.updatedCloud;
      clusters = clusterRes.clusters;
    }

    let groundCount = 0;
    for (let i = 0; i < current.count; i++) {
      if ((current.flags[i] & 0x01) !== 0) groundCount++;
    }

    const durationMs = performance.now() - t0;

    return {
      cloud: current,
      groundPlane: groundResult,
      clusters,
      metrics: {
        inputCount: rawCloud.count,
        filteredCount: current.count,
        groundCount,
        clusterCount: clusters.length,
        durationMs
      }
    };
  }

  static applyRangeFilter(cloud: PointCloudData, minRange: number, maxRange: number): PointCloudData {
    const keepIndices: number[] = [];
    for (let i = 0; i < cloud.count; i++) {
      const r = cloud.ranges[i];
      const x = cloud.points[i * 3];
      const y = cloud.points[i * 3 + 1];
      const z = cloud.points[i * 3 + 2];
      if (!isNaN(x) && !isNaN(y) && !isNaN(z) && isFinite(x) && isFinite(y) && isFinite(z)) {
        if (r >= minRange && r <= maxRange) {
          keepIndices.push(i);
        }
      }
    }
    return this.subsetCloud(cloud, keepIndices);
  }

  static applyRoiFilter(
    cloud: PointCloudData,
    b: { xMin: number; xMax: number; yMin: number; yMax: number; zMin: number; zMax: number }
  ): PointCloudData {
    const keepIndices: number[] = [];
    for (let i = 0; i < cloud.count; i++) {
      const x = cloud.points[i * 3];
      const y = cloud.points[i * 3 + 1];
      const z = cloud.points[i * 3 + 2];
      if (x >= b.xMin && x <= b.xMax && y >= b.yMin && y <= b.yMax && z >= b.zMin && z <= b.zMax) {
        keepIndices.push(i);
      }
    }
    return this.subsetCloud(cloud, keepIndices);
  }

  static applyVoxelFilter(cloud: PointCloudData, voxelSize: number): PointCloudData {
    if (cloud.count === 0 || voxelSize <= 0.005) return cloud;
    const voxelMap = new Map<string, number>();

    for (let i = 0; i < cloud.count; i++) {
      const vx = Math.floor(cloud.points[i * 3] / voxelSize);
      const vy = Math.floor(cloud.points[i * 3 + 1] / voxelSize);
      const vz = Math.floor(cloud.points[i * 3 + 2] / voxelSize);
      const key = `${vx},${vy},${vz}`;
      if (!voxelMap.has(key)) {
        voxelMap.set(key, i);
      }
    }

    const keepIndices = Array.from(voxelMap.values());
    return this.subsetCloud(cloud, keepIndices);
  }

  static applyRansacGround(
    cloud: PointCloudData,
    distanceThresh: number,
    slopeLimitDeg: number
  ): { updatedCloud: PointCloudData; plane: GroundPlaneResult } {
    const n = cloud.count;
    const maxIterations = 80;

    // Filter candidate bottom points for plane proposal
    const bottomCandidates: number[] = [];
    for (let i = 0; i < n; i++) {
      if (cloud.points[i * 3 + 2] <= 0.5) {
        bottomCandidates.push(i);
      }
    }
    const pool = bottomCandidates.length >= 3 ? bottomCandidates : Array.from({ length: n }, (_, i) => i);

    let bestInliers: Uint8Array = new Uint8Array(n);
    let bestInlierCount = 0;
    let bestNormal: [number, number, number] = [0, 0, 1];
    let bestDistance = 0;

    for (let it = 0; it < maxIterations; it++) {
      const idx1 = pool[Math.floor(Math.random() * pool.length)];
      const idx2 = pool[Math.floor(Math.random() * pool.length)];
      const idx3 = pool[Math.floor(Math.random() * pool.length)];
      if (idx1 === idx2 || idx2 === idx3 || idx1 === idx3) continue;

      const p1 = [cloud.points[idx1 * 3], cloud.points[idx1 * 3 + 1], cloud.points[idx1 * 3 + 2]];
      const p2 = [cloud.points[idx2 * 3], cloud.points[idx2 * 3 + 1], cloud.points[idx2 * 3 + 2]];
      const p3 = [cloud.points[idx3 * 3], cloud.points[idx3 * 3 + 1], cloud.points[idx3 * 3 + 2]];

      // Vector cross product: (p2 - p1) x (p3 - p1)
      const v1 = [p2[0] - p1[0], p2[1] - p1[1], p2[2] - p1[2]];
      const v2 = [p3[0] - p1[0], p3[1] - p1[1], p3[2] - p1[2]];

      let nx = v1[1] * v2[2] - v1[2] * v2[1];
      let ny = v1[2] * v2[0] - v1[0] * v2[2];
      let nz = v1[0] * v2[1] - v1[1] * v2[0];

      const len = Math.sqrt(nx * nx + ny * ny + nz * nz);
      if (len < 1e-6) continue;
      nx /= len; ny /= len; nz /= len;

      if (nz < 0) {
        nx = -nx; ny = -ny; nz = -nz;
      }

      // Slope check relative to vertical z-axis
      const slope = Math.acos(Math.min(1.0, Math.max(-1.0, nz))) * (180.0 / Math.PI);
      if (slope > slopeLimitDeg) continue;

      const d = -(nx * p1[0] + ny * p1[1] + nz * p1[2]);

      let inlierCount = 0;
      const currentInliers = new Uint8Array(n);

      for (let i = 0; i < n; i++) {
        const px = cloud.points[i * 3];
        const py = cloud.points[i * 3 + 1];
        const pz = cloud.points[i * 3 + 2];
        const dist = Math.abs(nx * px + ny * py + nz * pz + d);
        if (dist <= distanceThresh) {
          currentInliers[i] = 1;
          inlierCount++;
        }
      }

      if (inlierCount > bestInlierCount) {
        bestInlierCount = inlierCount;
        bestInliers = currentInliers;
        bestNormal = [nx, ny, nz];
        bestDistance = d;
      }
    }

    // Clone flags and mark ground bit 0x01
    const newFlags = new Uint8Array(cloud.flags);
    for (let i = 0; i < n; i++) {
      if (bestInliers[i] === 1) {
        newFlags[i] |= 0x01; // Ground bit
      } else {
        newFlags[i] &= ~0x01; // Non-ground
      }
    }

    const updatedCloud: PointCloudData = {
      ...cloud,
      flags: newFlags
    };

    const slope = Math.acos(Math.min(1.0, Math.max(-1.0, bestNormal[2]))) * (180.0 / Math.PI);

    const plane: GroundPlaneResult = {
      normal: bestNormal,
      distance: bestDistance,
      inlierCount: bestInlierCount,
      inlierRatio: bestInlierCount / Math.max(1, n),
      slopeDeg: slope
    };

    return { updatedCloud, plane };
  }

  static extractClusters(
    cloud: PointCloudData,
    distThresh: number,
    minPoints: number
  ): { updatedCloud: PointCloudData; clusters: DetectedCluster[] } {
    // Only cluster non-ground points
    const nonGroundIndices: number[] = [];
    for (let i = 0; i < cloud.count; i++) {
      if ((cloud.flags[i] & 0x01) === 0) {
        nonGroundIndices.push(i);
      }
    }

    if (nonGroundIndices.length === 0) {
      return { updatedCloud: cloud, clusters: [] };
    }

    // Build KD-tree on non-ground points
    const nonGroundCoords = new Float32Array(nonGroundIndices.length * 3);
    for (let k = 0; k < nonGroundIndices.length; k++) {
      const origIdx = nonGroundIndices[k];
      nonGroundCoords[k * 3]     = cloud.points[origIdx * 3];
      nonGroundCoords[k * 3 + 1] = cloud.points[origIdx * 3 + 1];
      nonGroundCoords[k * 3 + 2] = cloud.points[origIdx * 3 + 2];
    }

    const tree = new KDTree3D(nonGroundCoords);
    const visited = new Uint8Array(nonGroundIndices.length);
    const newClusterIds = new Int16Array(cloud.clusterIds);
    newClusterIds.fill(-1);

    const clusters: DetectedCluster[] = [];
    let currentClusterId = 0;

    for (let i = 0; i < nonGroundIndices.length; i++) {
      if (visited[i] === 1) continue;

      const clusterMemberIndices: number[] = [];
      const queue = [i];
      visited[i] = 1;

      while (queue.length > 0) {
        const curr = queue.shift()!;
        clusterMemberIndices.push(curr);

        const qx = nonGroundCoords[curr * 3];
        const qy = nonGroundCoords[curr * 3 + 1];
        const qz = nonGroundCoords[curr * 3 + 2];

        const neighbors = tree.radiusSearch(qx, qy, qz, distThresh);
        for (const nbr of neighbors) {
          if (visited[nbr] === 0) {
            visited[nbr] = 1;
            queue.push(nbr);
          }
        }
      }

      if (clusterMemberIndices.length >= minPoints) {
        let minX = Infinity, minY = Infinity, minZ = Infinity;
        let maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
        let sumX = 0, sumY = 0, sumZ = 0;

        for (const localIdx of clusterMemberIndices) {
          const origIdx = nonGroundIndices[localIdx];
          newClusterIds[origIdx] = currentClusterId;

          const px = cloud.points[origIdx * 3];
          const py = cloud.points[origIdx * 3 + 1];
          const pz = cloud.points[origIdx * 3 + 2];

          if (px < minX) minX = px; if (px > maxX) maxX = px;
          if (py < minY) minY = py; if (py > maxY) maxY = py;
          if (pz < minZ) minZ = pz; if (pz > maxZ) maxZ = pz;
          sumX += px; sumY += py; sumZ += pz;
        }

        const count = clusterMemberIndices.length;
        const width = maxX - minX;
        const length = maxY - minY;
        const height = maxZ - minZ;

        // Simple Geometric Classification Heuristic
        let classHint: DetectedCluster['classHint'] = 'Unknown';
        if (width > 1.2 && length > 2.5 && height > 1.0 && height < 3.5) {
          classHint = 'Vehicle';
        } else if (width < 1.0 && length < 1.0 && height > 1.2 && height < 2.2) {
          classHint = 'Pedestrian';
        } else if (height > 3.0 && width < 1.5 && length < 1.5) {
          classHint = 'Tree';
        } else if (width > 1.0 && length > 1.0 && height > 1.5) {
          classHint = 'Machinery';
        } else {
          classHint = 'Structure';
        }

        clusters.push({
          id: currentClusterId,
          centroid: [sumX / count, sumY / count, sumZ / count],
          dimensions: [width, length, height],
          pointCount: count,
          confidence: Math.min(0.99, 0.65 + (count / 500.0) * 0.3),
          classHint
        });

        currentClusterId++;
      }
    }

    return {
      updatedCloud: {
        ...cloud,
        clusterIds: newClusterIds
      },
      clusters
    };
  }

  private static subsetCloud(cloud: PointCloudData, indices: number[]): PointCloudData {
    const count = indices.length;
    const points = new Float32Array(count * 3);
    const intensities = new Float32Array(count);
    const ranges = new Float32Array(count);
    const azimuths = new Float32Array(count);
    const elevations = new Float32Array(count);
    const rings = new Uint16Array(count);
    const timestamps = new Float64Array(count);
    const flags = new Uint8Array(count);
    const clusterIds = new Int16Array(count);

    let minX = Infinity, minY = Infinity, minZ = Infinity;
    let maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
    let sumX = 0, sumY = 0, sumZ = 0;

    for (let i = 0; i < count; i++) {
      const srcIdx = indices[i];
      const px = cloud.points[srcIdx * 3];
      const py = cloud.points[srcIdx * 3 + 1];
      const pz = cloud.points[srcIdx * 3 + 2];

      points[i * 3]     = px;
      points[i * 3 + 1] = py;
      points[i * 3 + 2] = pz;

      intensities[i] = cloud.intensities[srcIdx];
      ranges[i]      = cloud.ranges[srcIdx];
      azimuths[i]    = cloud.azimuths[srcIdx];
      elevations[i]  = cloud.elevations[srcIdx];
      rings[i]       = cloud.rings[srcIdx];
      timestamps[i]  = cloud.timestamps[srcIdx];
      flags[i]       = cloud.flags[srcIdx];
      clusterIds[i]  = cloud.clusterIds[srcIdx];

      if (px < minX) minX = px; if (px > maxX) maxX = px;
      if (py < minY) minY = py; if (py > maxY) maxY = py;
      if (pz < minZ) minZ = pz; if (pz > maxZ) maxZ = pz;
      sumX += px; sumY += py; sumZ += pz;
    }

    return {
      points,
      intensities,
      ranges,
      azimuths,
      elevations,
      rings,
      timestamps,
      flags,
      clusterIds,
      count,
      boundingBox: {
        min: [minX === Infinity ? 0 : minX, minY === Infinity ? 0 : minY, minZ === Infinity ? 0 : minZ],
        max: [maxX === -Infinity ? 0 : maxX, maxY === -Infinity ? 0 : maxY, maxZ === -Infinity ? 0 : maxZ]
      },
      centroid: count > 0 ? [sumX / count, sumY / count, sumZ / count] : [0, 0, 0]
    };
  }
}
