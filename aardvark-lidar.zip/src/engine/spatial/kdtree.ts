/**
 * 3D Spatial KD-Tree Index in TypeScript.
 */

export class KDNode3D {
  pointIndex: number;
  axis: number;
  left: KDNode3D | null = null;
  right: KDNode3D | null = null;

  constructor(pointIndex: number, axis: number) {
    this.pointIndex = pointIndex;
    this.axis = axis;
  }
}

export class KDTree3D {
  private coords: Float32Array;
  private root: KDNode3D | null = null;

  constructor(coords: Float32Array) {
    this.coords = coords;
    const n = coords.length / 3;
    const indices = new Int32Array(n);
    for (let i = 0; i < n; i++) indices[i] = i;
    this.root = this.buildTree(indices, 0);
  }

  private buildTree(indices: Int32Array, depth: number): KDNode3D | null {
    if (indices.length === 0) return null;
    const axis = depth % 3;

    // Sort indices by axis
    const arr = Array.from(indices);
    arr.sort((a, b) => this.coords[a * 3 + axis] - this.coords[b * 3 + axis]);

    const median = Math.floor(arr.length / 2);
    const node = new KDNode3D(arr[median], axis);

    node.left = this.buildTree(new Int32Array(arr.slice(0, median)), depth + 1);
    node.right = this.buildTree(new Int32Array(arr.slice(median + 1)), depth + 1);

    return node;
  }

  /** Find the nearest neighbor to query point [qx, qy, qz]. */
  nearestNeighbor(qx: number, qy: number, qz: number): { index: number; distance: number } {
    let bestIdx = -1;
    let bestDistSq = Infinity;

    const query = [qx, qy, qz];

    const search = (node: KDNode3D | null) => {
      if (!node) return;

      const idx = node.pointIndex;
      const px = this.coords[idx * 3];
      const py = this.coords[idx * 3 + 1];
      const pz = this.coords[idx * 3 + 2];

      const dx = px - qx;
      const dy = py - qy;
      const dz = pz - qz;
      const distSq = dx * dx + dy * dy + dz * dz;

      if (distSq < bestDistSq) {
        bestDistSq = distSq;
        bestIdx = idx;
      }

      const axis = node.axis;
      const diff = query[axis] - (axis === 0 ? px : axis === 1 ? py : pz);

      const first = diff < 0 ? node.left : node.right;
      const second = diff < 0 ? node.right : node.left;

      search(first);
      if (diff * diff < bestDistSq) {
        search(second);
      }
    };

    search(this.root);
    return { index: bestIdx, distance: Math.sqrt(bestDistSq) };
  }

  /** Find all points within radius. */
  radiusSearch(qx: number, qy: number, qz: number, radius: number): number[] {
    const results: number[] = [];
    const radiusSq = radius * radius;
    const query = [qx, qy, qz];

    const search = (node: KDNode3D | null) => {
      if (!node) return;

      const idx = node.pointIndex;
      const px = this.coords[idx * 3];
      const py = this.coords[idx * 3 + 1];
      const pz = this.coords[idx * 3 + 2];

      const dx = px - qx;
      const dy = py - qy;
      const dz = pz - qz;
      const distSq = dx * dx + dy * dy + dz * dz;

      if (distSq <= radiusSq) {
        results.push(idx);
      }

      const axis = node.axis;
      const diff = query[axis] - (axis === 0 ? px : axis === 1 ? py : pz);

      const first = diff < 0 ? node.left : node.right;
      const second = diff < 0 ? node.right : node.left;

      search(first);
      if (diff * diff <= radiusSq) {
        search(second);
      }
    };

    search(this.root);
    return results;
  }
}
