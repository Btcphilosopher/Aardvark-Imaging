/**
 * Mathematical SE(3) Transformation and Rotation Engine.
 */
import { SE3Pose } from '../../types/lidar';

export class TransformMath {
  /** Create a 3x3 rotation matrix from Z-Y-X Tait-Bryan Euler angles in degrees. */
  static eulerToRotationMatrix(rollDeg: number, pitchDeg: number, yawDeg: number): number[][] {
    const rad = Math.PI / 180.0;
    const r = rollDeg * rad;
    const p = pitchDeg * rad;
    const y = yawDeg * rad;

    const cr = Math.cos(r), sr = Math.sin(r);
    const cp = Math.cos(p), sp = Math.sin(p);
    const cy = Math.cos(y), sy = Math.sin(y);

    // R = Rz * Ry * Rx
    return [
      [cy * cp, cy * sp * sr - sy * cr, cy * sp * cr + sy * sr],
      [sy * cp, sy * sp * sr + cy * cr, sy * sp * cr - cy * sr],
      [-sp,     cp * sr,                cp * cr]
    ];
  }

  /** Compute determinant of a 3x3 matrix. */
  static det3x3(m: number[][]): number {
    return (
      m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) -
      m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) +
      m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0])
    );
  }

  /** Check orthogonality of 3x3 rotation matrix (R * R^T = I). */
  static validateRotationMatrix(m: number[][], tolerance = 1e-4): { isValid: boolean; det: number; orthError: number } {
    const det = this.det3x3(m);
    let orthError = 0;

    for (let r = 0; r < 3; r++) {
      for (let c = 0; c < 3; c++) {
        let dot = 0;
        for (let k = 0; k < 3; k++) {
          dot += m[r][k] * m[c][k];
        }
        const expected = r === c ? 1.0 : 0.0;
        orthError = Math.max(orthError, Math.abs(dot - expected));
      }
    }

    const isValid = Math.abs(det - 1.0) < tolerance && orthError < tolerance;
    return { isValid, det, orthError };
  }

  /** Invert an SE(3) pose: T^-1 = [ R^T | -R^T * t ]. */
  static invertSE3(pose: SE3Pose): SE3Pose {
    const R = pose.rotationMatrix;
    const t = pose.translation;

    // Transpose of R
    const R_inv: number[][] = [
      [R[0][0], R[1][0], R[2][0]],
      [R[0][1], R[1][1], R[2][1]],
      [R[0][2], R[1][2], R[2][2]]
    ];

    const t_inv: [number, number, number] = [
      -(R_inv[0][0] * t[0] + R_inv[0][1] * t[1] + R_inv[0][2] * t[2]),
      -(R_inv[1][0] * t[0] + R_inv[1][1] * t[1] + R_inv[1][2] * t[2]),
      -(R_inv[2][0] * t[0] + R_inv[2][1] * t[1] + R_inv[2][2] * t[2])
    ];

    return {
      translation: t_inv,
      rotationMatrix: R_inv,
      eulerDeg: [-pose.eulerDeg[0], -pose.eulerDeg[1], -pose.eulerDeg[2]]
    };
  }

  /** Transform single 3D point with SE(3) pose. */
  static transformPoint(pt: [number, number, number], pose: SE3Pose): [number, number, number] {
    const R = pose.rotationMatrix;
    const t = pose.translation;
    return [
      R[0][0] * pt[0] + R[0][1] * pt[1] + R[0][2] * pt[2] + t[0],
      R[1][0] * pt[0] + R[1][1] * pt[1] + R[1][2] * pt[2] + t[1],
      R[2][0] * pt[0] + R[2][1] * pt[1] + R[2][2] * pt[2] + t[2]
    ];
  }

  /** Vectorized in-place or new array point cloud transform. */
  static transformPointCloud(coords: Float32Array, pose: SE3Pose): Float32Array {
    const out = new Float32Array(coords.length);
    const R = pose.rotationMatrix;
    const t = pose.translation;

    for (let i = 0; i < coords.length; i += 3) {
      const x = coords[i];
      const y = coords[i + 1];
      const z = coords[i + 2];

      out[i]     = R[0][0] * x + R[0][1] * y + R[0][2] * z + t[0];
      out[i + 1] = R[1][0] * x + R[1][1] * y + R[1][2] * z + t[1];
      out[i + 2] = R[2][0] * x + R[2][1] * y + R[2][2] * z + t[2];
    }
    return out;
  }
}
