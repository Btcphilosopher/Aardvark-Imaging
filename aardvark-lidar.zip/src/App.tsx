/**
 * AARDVARK LIDAR - Production-Grade LiDAR Sensor & 3D Computational Perception Workstation.
 */
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  SensorConfig, 
  SensorState, 
  SensorTelemetry, 
  PointCloudData, 
  ColorMode, 
  ScenarioId, 
  FilterSettings, 
  GroundPlaneResult, 
  DetectedCluster, 
  SE3Pose, 
  ICPMetrics, 
  RawPacketRecord, 
  SpatialMeasurement, 
  AuditEvent,
  Point3D
} from './types/lidar';
import { LidarSimulator } from './engine/simulation/simulator';
import { FilterPipeline } from './engine/pipeline/filters';
import { ICPRegistration } from './engine/registration/icp';
import { MapAccumulator, KeyframeRecord } from './engine/mapping/slam';
import { TransformMath } from './engine/math/transforms';
import { PointCloudViewport } from './components/viewport/PointCloudViewport';
import { Header } from './components/navigation/Header';
import { Sidebar, TabType } from './components/navigation/Sidebar';
import { LiveScanPanel } from './components/panels/LiveScanPanel';
import { FilterPipelinePanel } from './components/panels/FilterPipelinePanel';
import { MappingPanel } from './components/panels/MappingPanel';
import { CalibrationPanel } from './components/panels/CalibrationPanel';
import { MeasurementPanel } from './components/panels/MeasurementPanel';
import { PacketAnalyzerPanel } from './components/panels/PacketAnalyzerPanel';
import { DiagnosticsPanel } from './components/panels/DiagnosticsPanel';
import { AuditExportPanel } from './components/panels/AuditExportPanel';

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<TabType>('live');

  // Sensor Configuration
  const [sensorConfig, setSensorConfig] = useState<SensorConfig>({
    sensorId: 'AV-LIDAR-001',
    manufacturer: 'Aardvark Imaging Systems',
    model: 'AV-64HD',
    serialNumber: 'AV64-2026-0988',
    beamCount: 64,
    rotationRateHz: 10.0,
    horizontalFovDeg: 360.0,
    verticalFovDeg: 45.0,
    minRangeM: 0.3,
    maxRangeM: 80.0,
    ipAddress: '192.168.1.201',
    udpPort: 2368,
    noiseStdM: 0.012
  });

  // Sensor State & Digital Twin Scenario
  const [sensorState, setSensorState] = useState<SensorState>('STREAMING');
  const [scenario, setScenario] = useState<ScenarioId>('industrial_warehouse');

  // 3D Viewport Controls
  const [colorMode, setColorMode] = useState<ColorMode>('height');
  const [pointSize, setPointSize] = useState<number>(2.5);
  const [showBoundingBoxes, setShowBoundingBoxes] = useState<boolean>(true);
  const [showGroundPlane, setShowGroundPlane] = useState<boolean>(false);
  const [showGrid, setShowGrid] = useState<boolean>(true);
  const [showRangeRings, setShowRangeRings] = useState<boolean>(true);

  // Perception Pipeline Settings
  const [filterSettings, setFilterSettings] = useState<FilterSettings>({
    enableRangeFilter: true,
    minRangeM: 0.3,
    maxRangeM: 70.0,
    enableRoiFilter: false,
    roiBounds: { xMin: -30, xMax: 30, yMin: -30, yMax: 30, zMin: -2, zMax: 15 },
    enableVoxelFilter: true,
    voxelSizeM: 0.05,
    enableRansacGround: true,
    groundDistanceThreshM: 0.12,
    groundSlopeLimitDeg: 15.0,
    enableClustering: true,
    clusterDistanceThreshM: 0.8,
    minClusterPoints: 12
  });

  // SE(3) Extrinsic Calibration
  const [calibrationPose, setCalibrationPose] = useState<SE3Pose>({
    translation: [0.0, 0.0, 0.0],
    rotationMatrix: [
      [1.0, 0.0, 0.0],
      [0.0, 1.0, 0.0],
      [0.0, 0.0, 1.0]
    ],
    eulerDeg: [0.0, 0.0, 0.0]
  });

  // Measurements, Calipers & Audit Logs
  const [measurements, setMeasurements] = useState<SpatialMeasurement[]>([]);
  const [selectedPoints, setSelectedPoints] = useState<[number, number, number][]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditEvent[]>([
    {
      id: 'audit_01',
      timestamp: new Date().toLocaleTimeString(),
      actor: 'System Bootloader',
      eventType: 'SYSTEM_INITIALIZED',
      objectId: 'AV-LIDAR-001',
      description: 'AARDVARK LIDAR perception engine started with AV-64HD profile.',
      status: 'SUCCESS'
    }
  ]);

  // Point Cloud Data States
  const [rawCloud, setRawCloud] = useState<PointCloudData | null>(null);
  const [processedCloud, setProcessedCloud] = useState<PointCloudData | null>(null);
  const [groundPlane, setGroundPlane] = useState<GroundPlaneResult | undefined>(undefined);
  const [clusters, setClusters] = useState<DetectedCluster[]>([]);
  const [pipelineDurationMs, setPipelineDurationMs] = useState<number>(4.2);

  // SLAM Map & Registration
  const [icpMetrics, setIcpMetrics] = useState<ICPMetrics | null>(null);
  const [isMapAccumulating, setIsMapAccumulating] = useState<boolean>(false);
  const [keyframes, setKeyframes] = useState<KeyframeRecord[]>([]);

  // UDP Packets & Recording
  const [recentPackets, setRecentPackets] = useState<RawPacketRecord[]>([]);
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordedPacketCount, setRecordedPacketCount] = useState<number>(0);

  // Health Diagnostics
  const [injectedFault, setInjectedFault] = useState<string | null>(null);
  const [telemetry, setTelemetry] = useState<SensorTelemetry>({
    fps: 10.0,
    pointsPerSec: 52000,
    packetRateHz: 1280.0,
    packetLossPct: 0.01,
    ingestionLatencyMs: 0.8,
    decodeLatencyMs: 1.4,
    filterLatencyMs: 3.2,
    renderLatencyMs: 2.1,
    totalLatencyMs: 7.5,
    opticalTempC: 38.4,
    targetRpm: 600,
    measuredRpm: 600,
    jitterMs: 0.2,
    invalidPointPct: 0.05,
    healthState: 'HEALTHY',
    activeAlarms: []
  });

  // Engine Singletons References
  const simulatorRef = useRef<LidarSimulator>(new LidarSimulator(sensorConfig, scenario));
  const mapAccumulatorRef = useRef<MapAccumulator>(new MapAccumulator(0.08));
  const previousCloudRef = useRef<PointCloudData | null>(null);
  const lastScanTimeRef = useRef<number>(Date.now());
  const frameCountRef = useRef<number>(0);

  // Update simulator when config or scenario changes
  useEffect(() => {
    simulatorRef.current.updateConfig(sensorConfig);
  }, [sensorConfig]);

  useEffect(() => {
    simulatorRef.current.setScenario(scenario);
    addAuditLog('SCENARIO_LOADED', scenario, `Loaded digital-twin scenario: ${scenario}`);
  }, [scenario]);

  const addAuditLog = (eventType: string, objectId: string, description: string, status: 'SUCCESS' | 'WARNING' | 'FAILED' = 'SUCCESS') => {
    setAuditLogs((prev) => [
      ...prev,
      {
        id: `audit_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        timestamp: new Date().toLocaleTimeString(),
        actor: 'Operator / Pipeline',
        eventType,
        objectId,
        description,
        status
      }
    ]);
  };

  // Perform single scan and filter pass
  const acquireScan = useCallback(() => {
    const t0 = performance.now();

    // 1. Ray-casting simulation
    const noiseMultiplier = injectedFault === 'rotor_jitter' ? 3.5 : 1.0;
    const { cloud: raw, packets } = simulatorRef.current.generateScan({ noiseMultiplier });
    setRawCloud(raw);

    // 2. Apply SE(3) Extrinsic Calibration
    let calibratedCoords = raw.points;
    if (
      calibrationPose.translation[0] !== 0 ||
      calibrationPose.translation[1] !== 0 ||
      calibrationPose.translation[2] !== 0 ||
      calibrationPose.eulerDeg[0] !== 0 ||
      calibrationPose.eulerDeg[1] !== 0 ||
      calibrationPose.eulerDeg[2] !== 0
    ) {
      calibratedCoords = TransformMath.transformPointCloud(raw.points, calibrationPose);
    }
    const calibratedCloud: PointCloudData = { ...raw, points: calibratedCoords };

    // 3. Run Filter Pipeline (Range, ROI, Voxel, RANSAC, DBSCAN)
    const tFilterStart = performance.now();
    const { cloud: filtered, groundPlane: gp, clusters: cl, metrics } = FilterPipeline.process(
      calibratedCloud,
      filterSettings
    );
    const filterDur = performance.now() - tFilterStart;

    setProcessedCloud(filtered);
    setGroundPlane(gp);
    setClusters(cl);
    setPipelineDurationMs(filterDur);

    // 4. Update SLAM Map Accumulator if active
    if (isMapAccumulating) {
      mapAccumulatorRef.current.addKeyframe(filtered, calibrationPose);
      setKeyframes([...mapAccumulatorRef.current.getKeyframes()]);
    }

    // 5. Update Packet Stream
    setRecentPackets(packets);
    if (isRecording) {
      setRecordedPacketCount((prev) => prev + packets.length);
    }

    // 6. Compute Telemetry & FPS
    frameCountRef.current++;
    const now = Date.now();
    const elapsedSec = (now - lastScanTimeRef.current) / 1000.0;
    if (elapsedSec >= 0.5) {
      const liveFps = frameCountRef.current / elapsedSec;
      frameCountRef.current = 0;
      lastScanTimeRef.current = now;

      // Telemetry faults
      let temp = 38.4 + (Math.random() - 0.5) * 0.4;
      let loss = 0.01;
      let alarms: string[] = [];
      let health: SensorTelemetry['healthState'] = 'HEALTHY';

      if (injectedFault === 'high_temp') {
        temp = 78.5 + (Math.random() - 0.5) * 1.5;
        health = 'FAULT';
        alarms.push('CRITICAL: Optical Core Thermal Threshold Exceeded (78.5°C)');
      } else if (injectedFault === 'packet_loss') {
        loss = 18.4;
        health = 'WARNING';
        alarms.push('WARNING: Elevated UDP Packet Loss (18.4%) on port 2368');
      } else if (injectedFault === 'rotor_jitter') {
        alarms.push('WARNING: Rotor phase jitter detected (±45 RPM)');
        health = 'DEGRADED';
      }

      setTelemetry({
        fps: liveFps,
        pointsPerSec: Math.floor(raw.count * liveFps),
        packetRateHz: liveFps * 128,
        packetLossPct: loss,
        ingestionLatencyMs: 0.6 + Math.random() * 0.2,
        decodeLatencyMs: 1.2 + Math.random() * 0.3,
        filterLatencyMs: filterDur,
        renderLatencyMs: 2.0 + Math.random() * 0.4,
        totalLatencyMs: 3.8 + filterDur,
        opticalTempC: temp,
        targetRpm: sensorConfig.rotationRateHz * 60,
        measuredRpm: (sensorConfig.rotationRateHz * 60) + (injectedFault === 'rotor_jitter' ? (Math.random() - 0.5) * 90 : (Math.random() - 0.5) * 2),
        jitterMs: injectedFault === 'rotor_jitter' ? 3.4 : 0.2,
        invalidPointPct: 0.04,
        healthState: health,
        activeAlarms: alarms
      });
    }

    previousCloudRef.current = filtered;
  }, [sensorConfig, scenario, calibrationPose, filterSettings, isMapAccumulating, isRecording, injectedFault]);

  // Main Live Acquisition Loop
  useEffect(() => {
    if (sensorState !== 'STREAMING') return;
    const intervalMs = Math.max(25, 1000.0 / sensorConfig.rotationRateHz);
    const timer = setInterval(() => {
      acquireScan();
    }, intervalMs);
    return () => clearInterval(timer);
  }, [sensorState, sensorConfig.rotationRateHz, acquireScan]);

  // Initial Scan Generation on mount
  useEffect(() => {
    acquireScan();
  }, []);

  // ICP Alignment Handler
  const handleRunICP = () => {
    if (rawCloud && previousCloudRef.current) {
      const result = ICPRegistration.align(rawCloud, previousCloudRef.current, {
        maxIterations: 30,
        maxDistance: 1.2
      });
      setIcpMetrics(result);
      addAuditLog(
        'ICP_REGISTRATION',
        'ICP-01',
        `Executed Point-to-Point ICP: RMSE = ${(result.residualRmse * 1000).toFixed(1)} mm (${result.iterations} iters)`
      );
    }
  };

  // Point Selection / Caliper Picker Handler
  const handlePointSelect = (pt: [number, number, number], details: Point3D) => {
    setSelectedPoints((prev) => {
      if (prev.length >= 2) return [pt];
      return [...prev, pt];
    });
  };

  return (
    <div className="flex flex-col w-screen h-screen bg-[#090d15] text-slate-100 overflow-hidden font-sans select-none">
      {/* Workstation Top Header & Global Status */}
      <Header
        telemetry={telemetry}
        sensorState={sensorState}
        config={sensorConfig}
        onConnectToggle={() => setSensorState(sensorState === 'STREAMING' ? 'DISCONNECTED' : 'STREAMING')}
      />

      {/* Main Split Layout: Sidebar + 3D Viewport + Tab Action Panels */}
      <div className="flex flex-1 overflow-hidden">
        {/* Navigation Sidebar */}
        <Sidebar
          activeTab={activeTab}
          onTabChange={setActiveTab}
          clusterCount={clusters.length}
          alarmCount={telemetry.activeAlarms.length}
        />

        {/* Central 3D Point Cloud Viewport */}
        <main className="flex-1 relative h-full bg-[#0a0d14] overflow-hidden">
          <PointCloudViewport
            cloud={activeTab === 'slam' && isMapAccumulating ? mapAccumulatorRef.current.getMapCloud() : processedCloud}
            colorMode={colorMode}
            pointSize={pointSize}
            clusters={clusters}
            groundPlane={groundPlane}
            selectedPoints={selectedPoints}
            onPointSelect={handlePointSelect}
            showBoundingBoxes={showBoundingBoxes}
            showGroundPlane={showGroundPlane}
            showGrid={showGrid}
            showRangeRings={showRangeRings}
          />
        </main>

        {/* Right-Hand Context Control & Tuning Panels */}
        <aside className="w-80 lg:w-96 bg-[#0c111a] border-l border-[#1a2333] flex flex-col h-full overflow-hidden shadow-2xl z-10">
          {activeTab === 'live' && (
            <LiveScanPanel
              config={sensorConfig}
              onConfigChange={(newCfg) => setSensorConfig((c) => ({ ...c, ...newCfg }))}
              scenario={scenario}
              onScenarioChange={setScenario}
              sensorState={sensorState}
              onSensorStateChange={setSensorState}
              onSingleStep={acquireScan}
              colorMode={colorMode}
              onColorModeChange={setColorMode}
              pointSize={pointSize}
              onPointSizeChange={setPointSize}
              showBoundingBoxes={showBoundingBoxes}
              onToggleBoundingBoxes={() => setShowBoundingBoxes(!showBoundingBoxes)}
              showGroundPlane={showGroundPlane}
              onToggleGroundPlane={() => setShowGroundPlane(!showGroundPlane)}
              showGrid={showGrid}
              onToggleGrid={() => setShowGrid(!showGrid)}
              showRangeRings={showRangeRings}
              onToggleRangeRings={() => setShowRangeRings(!showRangeRings)}
              cloud={processedCloud}
            />
          )}

          {activeTab === 'filters' && (
            <FilterPipelinePanel
              settings={filterSettings}
              onSettingsChange={(newSet) => setFilterSettings((s) => ({ ...s, ...newSet }))}
              groundPlane={groundPlane}
              clusters={clusters}
              cloud={processedCloud}
              pipelineDurationMs={pipelineDurationMs}
            />
          )}

          {activeTab === 'slam' && (
            <MappingPanel
              icpMetrics={icpMetrics}
              onRunICP={handleRunICP}
              onAddKeyframe={() => {
                if (processedCloud) {
                  mapAccumulatorRef.current.addKeyframe(processedCloud, calibrationPose);
                  setKeyframes([...mapAccumulatorRef.current.getKeyframes()]);
                  addAuditLog('KEYFRAME_COMMITTED', 'SLAM', `Committed keyframe with ${processedCloud.count} points`);
                }
              }}
              onClearMap={() => {
                mapAccumulatorRef.current.clear();
                setKeyframes([]);
                addAuditLog('MAP_CLEARED', 'SLAM', 'Global voxel map reset');
              }}
              onExportMap={() => {
                const mapCloud = mapAccumulatorRef.current.getMapCloud();
                addAuditLog('MAP_EXPORTED', 'SLAM', `Exported global map (${mapCloud.count} points)`);
              }}
              keyframes={keyframes}
              globalMapCloud={mapAccumulatorRef.current.getMapCloud()}
              isMapAccumulating={isMapAccumulating}
              onToggleAccumulate={() => setIsMapAccumulating(!isMapAccumulating)}
            />
          )}

          {activeTab === 'calibration' && (
            <CalibrationPanel
              pose={calibrationPose}
              onPoseChange={(p) => {
                setCalibrationPose(p);
                addAuditLog('CALIBRATION_UPDATED', 'SE3', `Updated extrinsics: [${p.translation.map(v => v.toFixed(2)).join(', ')}]`);
              }}
              onResetCalibration={() => {
                setCalibrationPose({
                  translation: [0, 0, 0],
                  rotationMatrix: [[1, 0, 0], [0, 1, 0], [0, 0, 1]],
                  eulerDeg: [0, 0, 0]
                });
                addAuditLog('CALIBRATION_RESET', 'SE3', 'Calibration reset to identity');
              }}
              onExportCalibration={() => {
                addAuditLog('CALIBRATION_EXPORTED', 'SE3', 'Exported calibration profile JSON');
              }}
            />
          )}

          {activeTab === 'calipers' && (
            <MeasurementPanel
              measurements={measurements}
              onAddMeasurement={(m) => {
                setMeasurements((prev) => [...prev, m]);
                addAuditLog('MEASUREMENT_RECORDED', m.id, `Measured ${m.name}: ${m.value.toFixed(3)} ${m.unit}`);
              }}
              onDeleteMeasurement={(id) => setMeasurements((prev) => prev.filter((m) => m.id !== id))}
              onClearAll={() => setMeasurements([])}
              selectedPoints={selectedPoints}
              onClearSelectedPoints={() => setSelectedPoints([])}
              groundPlane={groundPlane}
            />
          )}

          {activeTab === 'packets' && (
            <PacketAnalyzerPanel
              packets={recentPackets}
              isRecording={isRecording}
              onToggleRecording={() => {
                const next = !isRecording;
                setIsRecording(next);
                if (!next) {
                  addAuditLog('PCAP_RECORDING_SAVED', 'PCAP', `Finalized capture with ${recordedPacketCount} packets`);
                } else {
                  setRecordedPacketCount(0);
                  addAuditLog('PCAP_RECORDING_STARTED', 'PCAP', 'Live raw packet streaming capture started');
                }
              }}
              recordedPacketCount={recordedPacketCount}
            />
          )}

          {activeTab === 'diagnostics' && (
            <DiagnosticsPanel
              telemetry={telemetry}
              onInjectFault={(fault) => {
                setInjectedFault(fault === 'clear' ? null : fault);
                addAuditLog('FAULT_INJECTION', 'TEST', `Hardware test injection: ${fault}`);
              }}
            />
          )}

          {activeTab === 'export' && (
            <AuditExportPanel
              auditLogs={auditLogs}
              cloud={processedCloud}
              config={sensorConfig}
            />
          )}
        </aside>
      </div>
    </div>
  );
}
