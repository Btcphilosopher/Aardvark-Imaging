/**
 * High-Performance Three.js WebGL 3D Point Cloud Viewport.
 */
import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { 
  PointCloudData, 
  ColorMode, 
  CameraPreset, 
  DetectedCluster, 
  GroundPlaneResult,
  Point3D 
} from '../../types/lidar';
import { 
  Eye, 
  Maximize2, 
  RotateCcw, 
  Layers, 
  Crosshair, 
  Ruler, 
  Box, 
  Grid,
  Palette,
  Compass
} from 'lucide-react';

interface PointCloudViewportProps {
  cloud: PointCloudData | null;
  colorMode: ColorMode;
  pointSize: number;
  clusters: DetectedCluster[];
  groundPlane?: GroundPlaneResult;
  selectedPoints: [number, number, number][];
  onPointSelect?: (point: [number, number, number], pointDetails: Point3D) => void;
  showBoundingBoxes: boolean;
  showGroundPlane: boolean;
  showGrid: boolean;
  showRangeRings: boolean;
}

export const PointCloudViewport: React.FC<PointCloudViewportProps> = ({
  cloud,
  colorMode,
  pointSize,
  clusters,
  groundPlane,
  selectedPoints,
  onPointSelect,
  showBoundingBoxes,
  showGroundPlane,
  showGrid,
  showRangeRings
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const pointsObjectRef = useRef<THREE.Points | null>(null);
  const clusterBoxesGroupRef = useRef<THREE.Group | null>(null);
  const groundMeshRef = useRef<THREE.Mesh | null>(null);
  const gridHelperRef = useRef<THREE.GridHelper | null>(null);
  const rangeRingsGroupRef = useRef<THREE.Group | null>(null);
  const caliperMarkersGroupRef = useRef<THREE.Group | null>(null);

  const isDraggingRef = useRef(false);
  const previousMousePositionRef = useRef({ x: 0, y: 0 });
  const cameraTargetRef = useRef(new THREE.Vector3(0, 0, 1.5));
  const cameraRadiusRef = useRef(25.0);
  const cameraThetaRef = useRef(Math.PI / 4.0); // azimuthal
  const cameraPhiRef = useRef(Math.PI / 3.2);   // polar

  const [hoveredPoint, setHoveredPoint] = useState<Point3D | null>(null);
  const [activePreset, setActivePreset] = useState<CameraPreset>('orbit');
  const [viewportDims, setViewportDims] = useState({ width: 800, height: 600 });

  // Update Camera Orbit Coordinates
  const updateCameraPosition = useCallback(() => {
    if (!cameraRef.current) return;
    const r = cameraRadiusRef.current;
    const theta = cameraThetaRef.current;
    const phi = Math.max(0.05, Math.min(Math.PI / 2 - 0.01, cameraPhiRef.current));
    
    const x = cameraTargetRef.current.x + r * Math.sin(phi) * Math.sin(theta);
    const y = cameraTargetRef.current.y - r * Math.sin(phi) * Math.cos(theta);
    const z = cameraTargetRef.current.z + r * Math.cos(phi);

    cameraRef.current.position.set(x, y, z);
    cameraRef.current.lookAt(cameraTargetRef.current);
    cameraRef.current.up.set(0, 0, 1); // Z is UP in LiDAR coordinates
  }, []);

  // Initialize ThreeJS Scene
  useEffect(() => {
    if (!mountRef.current) return;

    const width = mountRef.current.clientWidth || 800;
    const height = mountRef.current.clientHeight || 600;
    setViewportDims({ width, height });

    // Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0d14); // Dark industrial slate
    sceneRef.current = scene;

    // Camera (Z-up coordinate system)
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.up.set(0, 0, 1);
    cameraRef.current = camera;
    updateCameraPosition();

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    mountRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Ambient Lighting & Directional Light
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);
    const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
    dirLight.position.set(10, -20, 30);
    scene.add(dirLight);

    // Grid (Z is UP, so rotate grid)
    const grid = new THREE.GridHelper(80, 80, 0x00f0ff, 0x1a2638);
    grid.rotation.x = Math.PI / 2;
    grid.position.set(0, 0, 0);
    scene.add(grid);
    gridHelperRef.current = grid;

    // Range Rings (10m, 20m, 30m, 40m, 50m)
    const ringsGroup = new THREE.Group();
    [10, 20, 30, 40, 50].forEach(radius => {
      const ringGeo = new THREE.RingGeometry(radius - 0.05, radius + 0.05, 64);
      const ringMat = new THREE.MeshBasicMaterial({ color: 0x224466, side: THREE.DoubleSide, transparent: true, opacity: 0.4 });
      const ringMesh = new THREE.Mesh(ringGeo, ringMat);
      ringsGroup.add(ringMesh);
    });
    scene.add(ringsGroup);
    rangeRingsGroupRef.current = ringsGroup;

    // Sensor Origin Marker (Frustum Pyramid & Coordinate Axes)
    const axes = new THREE.AxesHelper(2.0);
    axes.position.set(0, 0, 1.8);
    scene.add(axes);

    const sensorBodyGeo = new THREE.CylinderGeometry(0.3, 0.3, 0.4, 16);
    const sensorBodyMat = new THREE.MeshStandardMaterial({ color: 0x3b82f6, metalness: 0.8, roughness: 0.2 });
    const sensorBody = new THREE.Mesh(sensorBodyGeo, sensorBodyMat);
    sensorBody.rotation.x = Math.PI / 2;
    sensorBody.position.set(0, 0, 1.8);
    scene.add(sensorBody);

    // Groups for dynamic overlays
    const clusterGroup = new THREE.Group();
    scene.add(clusterGroup);
    clusterBoxesGroupRef.current = clusterGroup;

    const caliperGroup = new THREE.Group();
    scene.add(caliperGroup);
    caliperMarkersGroupRef.current = caliperGroup;

    // Animation Loop
    let animationFrameId: number;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      if (rendererRef.current && sceneRef.current && cameraRef.current) {
        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }
    };
    animate();

    // Resize Observer
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const newWidth = entry.contentRect.width;
        const newHeight = entry.contentRect.height;
        if (newWidth > 0 && newHeight > 0) {
          setViewportDims({ width: newWidth, height: newHeight });
          if (cameraRef.current && rendererRef.current) {
            cameraRef.current.aspect = newWidth / newHeight;
            cameraRef.current.updateProjectionMatrix();
            rendererRef.current.setSize(newWidth, newHeight);
          }
        }
      }
    });
    resizeObserver.observe(mountRef.current);

    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      if (renderer.domElement.parentNode) {
        renderer.domElement.parentNode.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  // Update Point Cloud WebGL Buffers
  useEffect(() => {
    if (!sceneRef.current) return;

    // Remove old point cloud
    if (pointsObjectRef.current) {
      sceneRef.current.remove(pointsObjectRef.current);
      pointsObjectRef.current.geometry.dispose();
      (pointsObjectRef.current.material as THREE.Material).dispose();
      pointsObjectRef.current = null;
    }

    if (!cloud || cloud.count === 0) return;

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(cloud.points, 3));

    // Color buffer generation based on active ColorMode
    const colors = new Float32Array(cloud.count * 3);
    const zMin = cloud.boundingBox.min[2];
    const zMax = Math.max(zMin + 0.1, cloud.boundingBox.max[2]);
    const maxRange = 40.0;

    for (let i = 0; i < cloud.count; i++) {
      let r = 1.0, g = 1.0, b = 1.0;

      if (colorMode === 'height') {
        const z = cloud.points[i * 3 + 2];
        const norm = Math.min(1.0, Math.max(0.0, (z - zMin) / (zMax - zMin)));
        // Turbo Colormap approximation
        r = Math.sin(norm * Math.PI * 1.5);
        g = Math.sin(norm * Math.PI);
        b = Math.cos(norm * Math.PI * 0.8);
      } else if (colorMode === 'intensity') {
        const intensity = cloud.intensities[i] / 255.0;
        // Thermal gradient: black -> purple -> orange -> yellow -> white
        r = Math.min(1.0, intensity * 1.5);
        g = Math.min(1.0, Math.max(0.0, (intensity - 0.3) * 1.8));
        b = Math.min(1.0, Math.max(0.0, (intensity - 0.7) * 3.0));
      } else if (colorMode === 'range') {
        const rangeNorm = Math.min(1.0, cloud.ranges[i] / 40.0);
        r = rangeNorm;
        g = 1.0 - Math.abs(rangeNorm - 0.5) * 2.0;
        b = 1.0 - rangeNorm;
      } else if (colorMode === 'ring') {
        const ring = cloud.rings[i] % 16;
        const hue = (ring / 16.0) * 360;
        const color = new THREE.Color(`hsl(${hue}, 90%, 60%)`);
        r = color.r; g = color.g; b = color.b;
      } else if (colorMode === 'ground') {
        const isGround = (cloud.flags[i] & 0x01) !== 0;
        if (isGround) {
          r = 0.15; g = 0.85; b = 0.35; // Bright Emerald Ground
        } else {
          r = 0.25; g = 0.65; b = 0.95; // Cyan/Blue Non-ground
        }
      } else if (colorMode === 'cluster') {
        const cid = cloud.clusterIds[i];
        if (cid >= 0) {
          const hue = ((cid * 73) % 360);
          const color = new THREE.Color(`hsl(${hue}, 95%, 65%)`);
          r = color.r; g = color.g; b = color.b;
        } else {
          r = 0.25; g = 0.3; b = 0.38; // Dim gray unclustered
        }
      } else { // timestamp
        const tNorm = (i / cloud.count);
        r = tNorm; g = 0.8; b = 1.0 - tNorm;
      }

      colors[i * 3]     = Math.max(0, Math.min(1, r));
      colors[i * 3 + 1] = Math.max(0, Math.min(1, g));
      colors[i * 3 + 2] = Math.max(0, Math.min(1, b));
    }

    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const material = new THREE.PointsMaterial({
      size: pointSize * 0.08,
      vertexColors: true,
      sizeAttenuation: true,
      transparent: true,
      opacity: 0.95
    });

    const pointsObj = new THREE.Points(geometry, material);
    sceneRef.current.add(pointsObj);
    pointsObjectRef.current = pointsObj;
  }, [cloud, colorMode, pointSize]);

  // Update 3D Cluster Bounding Boxes
  useEffect(() => {
    if (!clusterBoxesGroupRef.current) return;
    const group = clusterBoxesGroupRef.current;
    
    // Clear previous boxes
    while (group.children.length > 0) {
      const child = group.children[0];
      group.remove(child);
      if (child instanceof THREE.Mesh || child instanceof THREE.LineSegments) {
        child.geometry.dispose();
        (child.material as THREE.Material).dispose();
      }
    }

    if (!showBoundingBoxes || clusters.length === 0) return;

    clusters.forEach((cluster) => {
      const [w, l, h] = cluster.dimensions;
      const [cx, cy, cz] = cluster.centroid;

      const boxGeo = new THREE.BoxGeometry(w, l, h);
      const wireframeGeo = new THREE.EdgesGeometry(boxGeo);
      
      let boxColor = 0x38bdf8; // Cyan default
      if (cluster.classHint === 'Vehicle') boxColor = 0xf59e0b; // Amber
      if (cluster.classHint === 'Pedestrian') boxColor = 0xef4444; // Red
      if (cluster.classHint === 'Machinery') boxColor = 0xa855f7; // Purple
      if (cluster.classHint === 'Tree') boxColor = 0x22c55e; // Green

      const wireframeMat = new THREE.LineBasicMaterial({ color: boxColor, linewidth: 2 });
      const wireframe = new THREE.LineSegments(wireframeGeo, wireframeMat);
      wireframe.position.set(cx, cy, cz);
      group.add(wireframe);

      // Semi-transparent solid fill
      const fillMat = new THREE.MeshBasicMaterial({ color: boxColor, transparent: true, opacity: 0.12, side: THREE.DoubleSide });
      const fillMesh = new THREE.Mesh(boxGeo, fillMat);
      fillMesh.position.set(cx, cy, cz);
      group.add(fillMesh);
    });
  }, [clusters, showBoundingBoxes]);

  // Update Caliper Markers
  useEffect(() => {
    if (!caliperMarkersGroupRef.current) return;
    const group = caliperMarkersGroupRef.current;

    while (group.children.length > 0) {
      const child = group.children[0];
      group.remove(child);
      if (child instanceof THREE.Mesh || child instanceof THREE.Line) {
        child.geometry.dispose();
        (child.material as THREE.Material).dispose();
      }
    }

    if (selectedPoints.length === 0) return;

    selectedPoints.forEach((pt, idx) => {
      const sphereGeo = new THREE.SphereGeometry(0.2, 16, 16);
      const sphereMat = new THREE.MeshBasicMaterial({ color: idx === 0 ? 0xff0055 : 0x00ffcc });
      const sphere = new THREE.Mesh(sphereGeo, sphereMat);
      sphere.position.set(pt[0], pt[1], pt[2]);
      group.add(sphere);
    });

    if (selectedPoints.length === 2) {
      const lineGeo = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(selectedPoints[0][0], selectedPoints[0][1], selectedPoints[0][2]),
        new THREE.Vector3(selectedPoints[1][0], selectedPoints[1][1], selectedPoints[1][2])
      ]);
      const lineMat = new THREE.LineDashedMaterial({ color: 0xffff00, dashSize: 0.3, gapSize: 0.1 });
      const line = new THREE.Line(lineGeo, lineMat);
      line.computeLineDistances();
      group.add(line);
    }
  }, [selectedPoints]);

  // Toggle Visibility helpers
  useEffect(() => {
    if (gridHelperRef.current) gridHelperRef.current.visible = showGrid;
    if (rangeRingsGroupRef.current) rangeRingsGroupRef.current.visible = showRangeRings;
  }, [showGrid, showRangeRings]);

  // Mouse Interaction: Orbit, Pan, Zoom, Point Picking
  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDraggingRef.current) {
      const deltaX = e.clientX - previousMousePositionRef.current.x;
      const deltaY = e.clientY - previousMousePositionRef.current.y;

      if (e.buttons === 1) { // Orbit
        cameraThetaRef.current -= deltaX * 0.008;
        cameraPhiRef.current -= deltaY * 0.008;
        updateCameraPosition();
      } else if (e.buttons === 2) { // Pan
        const panSpeed = 0.02 * (cameraRadiusRef.current / 20.0);
        const cosT = Math.cos(cameraThetaRef.current);
        const sinT = Math.sin(cameraThetaRef.current);
        cameraTargetRef.current.x += (-cosT * deltaX - sinT * deltaY) * panSpeed;
        cameraTargetRef.current.y += (-sinT * deltaX + cosT * deltaY) * panSpeed;
        updateCameraPosition();
      }

      previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
    }
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  const handleWheel = (e: React.WheelEvent) => {
    cameraRadiusRef.current = Math.max(1.0, Math.min(200.0, cameraRadiusRef.current + e.deltaY * 0.03));
    updateCameraPosition();
  };

  // Point Inspection Raycaster on Click
  const handleClick = (e: React.MouseEvent) => {
    if (!mountRef.current || !cameraRef.current || !cloud || cloud.count === 0) return;
    const rect = mountRef.current.getBoundingClientRect();
    const mouseX = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const mouseY = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    const raycaster = new THREE.Raycaster();
    raycaster.params.Points.threshold = 0.3;
    raycaster.setFromCamera(new THREE.Vector2(mouseX, mouseY), cameraRef.current);

    if (pointsObjectRef.current) {
      const intersects = raycaster.intersectObject(pointsObjectRef.current);
      if (intersects.length > 0) {
        const hit = intersects[0];
        const idx = hit.index!;
        const pt: [number, number, number] = [
          cloud.points[idx * 3],
          cloud.points[idx * 3 + 1],
          cloud.points[idx * 3 + 2]
        ];

        const details: Point3D = {
          x: pt[0],
          y: pt[1],
          z: pt[2],
          intensity: cloud.intensities[idx],
          range: cloud.ranges[idx],
          azimuth: cloud.azimuths[idx] * (180 / Math.PI),
          elevation: cloud.elevations[idx] * (180 / Math.PI),
          ring: cloud.rings[idx],
          timestamp: cloud.timestamps[idx],
          flags: cloud.flags[idx],
          clusterId: cloud.clusterIds[idx]
        };

        setHoveredPoint(details);
        if (onPointSelect) onPointSelect(pt, details);
      }
    }
  };

  // Camera Presets
  const applyCameraPreset = (preset: CameraPreset) => {
    setActivePreset(preset);
    if (preset === 'top') {
      cameraThetaRef.current = 0;
      cameraPhiRef.current = 0.05;
      cameraRadiusRef.current = 35;
    } else if (preset === 'front') {
      cameraThetaRef.current = 0;
      cameraPhiRef.current = Math.PI / 2 - 0.05;
      cameraRadiusRef.current = 28;
    } else if (preset === 'side') {
      cameraThetaRef.current = Math.PI / 2;
      cameraPhiRef.current = Math.PI / 2 - 0.05;
      cameraRadiusRef.current = 28;
    } else if (preset === 'sensor') {
      cameraTargetRef.current.set(0, 0, 1.8);
      cameraThetaRef.current = 0;
      cameraPhiRef.current = Math.PI / 2.5;
      cameraRadiusRef.current = 4;
    } else { // orbit default
      cameraTargetRef.current.set(0, 0, 1.5);
      cameraThetaRef.current = Math.PI / 4.0;
      cameraPhiRef.current = Math.PI / 3.2;
      cameraRadiusRef.current = 25.0;
    }
    updateCameraPosition();
  };

  return (
    <div className="relative w-full h-full bg-[#0a0d14] overflow-hidden select-none">
      {/* Three.js Canvas Container */}
      <div
        ref={mountRef}
        className="w-full h-full cursor-crosshair"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onWheel={handleWheel}
        onClick={handleClick}
        onContextMenu={(e) => e.preventDefault()}
      />

      {/* Floating 3D Navigation Gizmo & Preset Camera Controls */}
      <div className="absolute top-4 right-4 flex flex-col gap-2 bg-[#121824]/90 backdrop-blur-md border border-[#1e293b] p-2 rounded-xl shadow-2xl z-10">
        <div className="text-[10px] font-mono text-slate-400 uppercase tracking-widest px-2 pt-1">
          Camera Views
        </div>
        <div className="grid grid-cols-3 gap-1">
          {(['orbit', 'top', 'front', 'side', 'sensor'] as CameraPreset[]).map((preset) => (
            <button
              key={preset}
              onClick={() => applyCameraPreset(preset)}
              className={`px-2 py-1 text-xs font-mono rounded capitalize transition-all ${
                activePreset === preset
                  ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40'
                  : 'bg-slate-800/60 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {preset}
            </button>
          ))}
          <button
            onClick={() => applyCameraPreset('orbit')}
            title="Reset Camera Center"
            className="p-1 text-slate-300 hover:text-cyan-400 flex items-center justify-center bg-slate-800/60 rounded"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Point Inspector HUD Badge */}
      {hoveredPoint && (
        <div className="absolute bottom-4 left-4 max-w-sm bg-[#111827]/95 backdrop-blur-md border border-cyan-500/30 p-3 rounded-xl shadow-2xl z-10 text-xs font-mono text-slate-200">
          <div className="flex items-center justify-between pb-1.5 border-b border-slate-700/60 mb-2">
            <span className="flex items-center gap-1.5 font-semibold text-cyan-400">
              <Crosshair className="w-3.5 h-3.5" /> Point Inspection
            </span>
            <span className="text-[10px] text-slate-400">Beam #{hoveredPoint.ring}</span>
          </div>
          <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-[11px]">
            <div>X: <span className="text-white font-semibold">{hoveredPoint.x.toFixed(3)} m</span></div>
            <div>Y: <span className="text-white font-semibold">{hoveredPoint.y.toFixed(3)} m</span></div>
            <div>Z: <span className="text-white font-semibold">{hoveredPoint.z.toFixed(3)} m</span></div>
            <div>Range: <span className="text-cyan-300">{hoveredPoint.range.toFixed(3)} m</span></div>
            <div>Azimuth: <span className="text-slate-300">{hoveredPoint.azimuth.toFixed(2)}°</span></div>
            <div>Elevation: <span className="text-slate-300">{hoveredPoint.elevation.toFixed(2)}°</span></div>
            <div>Intensity: <span className="text-amber-400 font-semibold">{hoveredPoint.intensity.toFixed(1)}</span></div>
            <div>Cluster: <span className="text-purple-400">{hoveredPoint.clusterId && hoveredPoint.clusterId >= 0 ? `#${hoveredPoint.clusterId}` : 'None'}</span></div>
          </div>
        </div>
      )}

      {/* Coordinate Cross Axes Indicator */}
      <div className="absolute bottom-4 right-4 bg-[#121824]/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-800 text-[10px] font-mono text-slate-400 flex items-center gap-3">
        <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-500"></span> +X (Forward)</span>
        <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-green-500"></span> +Y (Left)</span>
        <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-blue-500"></span> +Z (Up)</span>
      </div>
    </div>
  );
};
