/**
 * SE(3) Rigid Extrinsic Calibration Studio & Mathematical Matrix Engine.
 */
import React from 'react';
import { 
  Compass, 
  RotateCcw, 
  CheckCircle2, 
  AlertCircle, 
  FileDown, 
  Sliders,
  ShieldCheck
} from 'lucide-react';
import { SE3Pose } from '../../types/lidar';
import { TransformMath } from '../../engine/math/transforms';

interface CalibrationPanelProps {
  pose: SE3Pose;
  onPoseChange: (newPose: SE3Pose) => void;
  onResetCalibration: () => void;
  onExportCalibration: () => void;
}

export const CalibrationPanel: React.FC<CalibrationPanelProps> = ({
  pose,
  onPoseChange,
  onResetCalibration,
  onExportCalibration
}) => {
  const updateTranslation = (axis: 0 | 1 | 2, val: number) => {
    const newT: [number, number, number] = [pose.translation[0], pose.translation[1], pose.translation[2]];
    newT[axis] = val;
    onPoseChange({ ...pose, translation: newT });
  };

  const updateEuler = (angleIdx: 0 | 1 | 2, valDeg: number) => {
    const newEuler: [number, number, number] = [pose.eulerDeg[0], pose.eulerDeg[1], pose.eulerDeg[2]];
    newEuler[angleIdx] = valDeg;
    const newR = TransformMath.eulerToRotationMatrix(newEuler[0], newEuler[1], newEuler[2]);
    onPoseChange({ ...pose, rotationMatrix: newR, eulerDeg: newEuler });
  };

  const matrixValidation = TransformMath.validateRotationMatrix(pose.rotationMatrix);

  return (
    <div className="p-4 space-y-6 overflow-y-auto max-h-full font-mono text-xs text-slate-300">
      {/* Header & Reset */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-sm font-semibold text-white uppercase tracking-wider flex items-center gap-1.5">
            <Compass className="w-4 h-4 text-cyan-400" /> SE(3) Extrinsics
          </h2>
          <p className="text-[11px] text-slate-400">Sensor Mounting Frame $\to$ Vehicle Body Coordinate Transform</p>
        </div>
        <div className="flex gap-1.5">
          <button
            onClick={onResetCalibration}
            title="Reset to Identity Transform"
            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 flex items-center gap-1 transition-all text-[11px]"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Reset
          </button>
          <button
            onClick={onExportCalibration}
            title="Export Calibration Profile"
            className="p-1.5 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 rounded flex items-center gap-1 transition-all text-[11px]"
          >
            <FileDown className="w-3.5 h-3.5" /> Save
          </button>
        </div>
      </div>

      {/* 6-DOF Sliders */}
      <div className="bg-[#121824] border border-[#1e293b] p-3.5 rounded-xl space-y-4 shadow-lg">
        <span className="font-semibold text-white uppercase tracking-wider text-[11px] block">
          Translation Parameters [meters]
        </span>
        <div className="space-y-2.5">
          <div>
            <div className="flex justify-between text-[11px] mb-1">
              <span className="text-slate-400">t_x (Forward):</span>
              <span className="text-red-400 font-bold">{pose.translation[0].toFixed(3)} m</span>
            </div>
            <input
              type="range"
              min={-5.0}
              max={5.0}
              step={0.01}
              value={pose.translation[0]}
              onChange={(e) => updateTranslation(0, parseFloat(e.target.value))}
              className="w-full accent-red-400"
            />
          </div>
          <div>
            <div className="flex justify-between text-[11px] mb-1">
              <span className="text-slate-400">t_y (Lateral):</span>
              <span className="text-emerald-400 font-bold">{pose.translation[1].toFixed(3)} m</span>
            </div>
            <input
              type="range"
              min={-5.0}
              max={5.0}
              step={0.01}
              value={pose.translation[1]}
              onChange={(e) => updateTranslation(1, parseFloat(e.target.value))}
              className="w-full accent-emerald-400"
            />
          </div>
          <div>
            <div className="flex justify-between text-[11px] mb-1">
              <span className="text-slate-400">t_z (Vertical Elevation):</span>
              <span className="text-blue-400 font-bold">{pose.translation[2].toFixed(3)} m</span>
            </div>
            <input
              type="range"
              min={-2.0}
              max={5.0}
              step={0.01}
              value={pose.translation[2]}
              onChange={(e) => updateTranslation(2, parseFloat(e.target.value))}
              className="w-full accent-blue-400"
            />
          </div>
        </div>

        <span className="font-semibold text-white uppercase tracking-wider text-[11px] block pt-2 border-t border-slate-800">
          Rotation Parameters [Tait-Bryan Euler Degrees]
        </span>
        <div className="space-y-2.5">
          <div>
            <div className="flex justify-between text-[11px] mb-1">
              <span className="text-slate-400">Roll (X-axis):</span>
              <span className="text-cyan-400 font-bold">{pose.eulerDeg[0].toFixed(2)}°</span>
            </div>
            <input
              type="range"
              min={-45.0}
              max={45.0}
              step={0.5}
              value={pose.eulerDeg[0]}
              onChange={(e) => updateEuler(0, parseFloat(e.target.value))}
              className="w-full accent-cyan-400"
            />
          </div>
          <div>
            <div className="flex justify-between text-[11px] mb-1">
              <span className="text-slate-400">Pitch (Y-axis):</span>
              <span className="text-purple-400 font-bold">{pose.eulerDeg[1].toFixed(2)}°</span>
            </div>
            <input
              type="range"
              min={-45.0}
              max={45.0}
              step={0.5}
              value={pose.eulerDeg[1]}
              onChange={(e) => updateEuler(1, parseFloat(e.target.value))}
              className="w-full accent-purple-400"
            />
          </div>
          <div>
            <div className="flex justify-between text-[11px] mb-1">
              <span className="text-slate-400">Yaw (Z-axis Heading):</span>
              <span className="text-amber-400 font-bold">{pose.eulerDeg[2].toFixed(2)}°</span>
            </div>
            <input
              type="range"
              min={-180.0}
              max={180.0}
              step={1.0}
              value={pose.eulerDeg[2]}
              onChange={(e) => updateEuler(2, parseFloat(e.target.value))}
              className="w-full accent-amber-400"
            />
          </div>
        </div>
      </div>

      {/* 4x4 Homogeneous Transformation Matrix Display */}
      <div className="bg-[#121824] border border-[#1e293b] p-3.5 rounded-xl space-y-3">
        <div className="flex items-center justify-between">
          <span className="font-semibold text-white uppercase tracking-wider text-[11px]">
            4×4 Homogeneous Matrix T ∈ SE(3)
          </span>
          {matrixValidation.isValid ? (
            <span className="flex items-center gap-1 text-emerald-400 text-[10px] font-bold">
              <CheckCircle2 className="w-3.5 h-3.5" /> SO(3) VALID
            </span>
          ) : (
            <span className="flex items-center gap-1 text-rose-400 text-[10px] font-bold">
              <AlertCircle className="w-3.5 h-3.5" /> NON-ORTHOGONAL
            </span>
          )}
        </div>

        <div className="bg-[#0a0d14] p-3 rounded-lg border border-slate-800 font-mono text-[11px] leading-relaxed select-all">
          <div className="text-slate-300">
            [{pose.rotationMatrix[0][0].toFixed(4).padStart(7)}, {pose.rotationMatrix[0][1].toFixed(4).padStart(7)}, {pose.rotationMatrix[0][2].toFixed(4).padStart(7)}, <span className="text-red-400 font-bold">{pose.translation[0].toFixed(4).padStart(7)}</span>]
          </div>
          <div className="text-slate-300">
            [{pose.rotationMatrix[1][0].toFixed(4).padStart(7)}, {pose.rotationMatrix[1][1].toFixed(4).padStart(7)}, {pose.rotationMatrix[1][2].toFixed(4).padStart(7)}, <span className="text-emerald-400 font-bold">{pose.translation[1].toFixed(4).padStart(7)}</span>]
          </div>
          <div className="text-slate-300">
            [{pose.rotationMatrix[2][0].toFixed(4).padStart(7)}, {pose.rotationMatrix[2][1].toFixed(4).padStart(7)}, {pose.rotationMatrix[2][2].toFixed(4).padStart(7)}, <span className="text-blue-400 font-bold">{pose.translation[2].toFixed(4).padStart(7)}</span>]
          </div>
          <div className="text-slate-500">
            [ 0.0000,  0.0000,  0.0000,  1.0000]
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 text-[10px] pt-1">
          <div>
            <span className="text-slate-400">Determinant det(R):</span>
            <div className="text-white font-semibold">{matrixValidation.det.toFixed(6)}</div>
          </div>
          <div>
            <span className="text-slate-400">Orthogonality Residual:</span>
            <div className="text-emerald-400 font-semibold">{matrixValidation.orthError.toExponential(2)}</div>
          </div>
        </div>
      </div>
    </div>
  );
};
