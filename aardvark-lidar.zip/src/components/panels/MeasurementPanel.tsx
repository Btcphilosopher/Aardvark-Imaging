/**
 * 3D Spatial Measurements & Caliper Analytics Panel.
 */
import React, { useState } from 'react';
import { 
  Ruler, 
  Box, 
  Layers, 
  Crosshair, 
  Plus, 
  Trash2, 
  FileDown, 
  CheckCircle2,
  Sparkles
} from 'lucide-react';
import { SpatialMeasurement, GroundPlaneResult } from '../../types/lidar';

interface MeasurementPanelProps {
  measurements: SpatialMeasurement[];
  onAddMeasurement: (m: SpatialMeasurement) => void;
  onDeleteMeasurement: (id: string) => void;
  onClearAll: () => void;
  selectedPoints: [number, number, number][];
  onClearSelectedPoints: () => void;
  groundPlane?: GroundPlaneResult;
}

export const MeasurementPanel: React.FC<MeasurementPanelProps> = ({
  measurements,
  onAddMeasurement,
  onDeleteMeasurement,
  onClearAll,
  selectedPoints,
  onClearSelectedPoints,
  groundPlane
}) => {
  const [measType, setMeasType] = useState<'PointToPoint' | 'PointToPlane' | 'BoundingBoxVolume'>('PointToPoint');

  // Compute live distance if 2 points are selected
  let liveDistance: number | null = null;
  let liveDx = 0, liveDy = 0, liveDz = 0, liveHori = 0;
  let uncertainty = 0.021; // 2.1cm propagated error at 1.5cm sensor sigma

  if (selectedPoints.length >= 2) {
    const p1 = selectedPoints[0];
    const p2 = selectedPoints[1];
    liveDx = p2[0] - p1[0];
    liveDy = p2[1] - p1[1];
    liveDz = p2[2] - p1[2];
    liveDistance = Math.sqrt(liveDx * liveDx + liveDy * liveDy + liveDz * liveDz);
    liveHori = Math.sqrt(liveDx * liveDx + liveDy * liveDy);
  }

  // Point-to-plane distance
  let pointToPlaneDist: number | null = null;
  if (selectedPoints.length >= 1 && groundPlane) {
    const pt = selectedPoints[0];
    const [a, b, c] = groundPlane.normal;
    const d = groundPlane.distance;
    pointToPlaneDist = Math.abs(a * pt[0] + b * pt[1] + c * pt[2] + d);
  }

  const handleSaveCurrent = () => {
    if (measType === 'PointToPoint' && selectedPoints.length >= 2 && liveDistance !== null) {
      onAddMeasurement({
        id: `meas_${Date.now()}`,
        type: 'PointToPoint',
        name: `3D Distance #${measurements.length + 1}`,
        value: liveDistance,
        unit: 'm',
        uncertainty,
        p1: selectedPoints[0],
        p2: selectedPoints[1],
        details: { dx: liveDx, dy: liveDy, dz: liveDz, horizontalDist: liveHori },
        timestamp: new Date().toLocaleTimeString()
      });
      onClearSelectedPoints();
    } else if (measType === 'PointToPlane' && selectedPoints.length >= 1 && pointToPlaneDist !== null) {
      onAddMeasurement({
        id: `meas_${Date.now()}`,
        type: 'PointToPlane',
        name: `Ground Clearance #${measurements.length + 1}`,
        value: pointToPlaneDist,
        unit: 'm',
        uncertainty: 0.015,
        p1: selectedPoints[0],
        details: { planeNormal: groundPlane?.normal },
        timestamp: new Date().toLocaleTimeString()
      });
      onClearSelectedPoints();
    }
  };

  return (
    <div className="p-4 space-y-6 overflow-y-auto max-h-full font-mono text-xs text-slate-300">
      {/* Tool Selector */}
      <div className="bg-[#121824] border border-[#1e293b] p-3.5 rounded-xl space-y-3 shadow-lg">
        <span className="font-semibold text-white uppercase tracking-wider text-[11px] flex items-center gap-1.5">
          <Ruler className="w-3.5 h-3.5 text-cyan-400" /> Active Measurement Caliper
        </span>

        <div className="grid grid-cols-3 gap-1.5">
          {[
            { id: 'PointToPoint', label: 'Point-to-Point' },
            { id: 'PointToPlane', label: 'Point-to-Plane' },
            { id: 'BoundingBoxVolume', label: 'Volume Box' }
          ].map((tool) => (
            <button
              key={tool.id}
              onClick={() => setMeasType(tool.id as any)}
              className={`p-2 rounded text-center border transition-all text-[11px] ${
                measType === tool.id
                  ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500 font-bold'
                  : 'bg-slate-800/60 text-slate-400 border-slate-700 hover:text-slate-200'
              }`}
            >
              {tool.label}
            </button>
          ))}
        </div>

        {/* Interactive Caliper Picking Guide */}
        <div className="bg-[#0a0d14] p-3 rounded-lg border border-slate-800 space-y-2 text-[11px]">
          <div className="flex items-center justify-between">
            <span className="text-slate-400 font-semibold">Caliper Target Points:</span>
            <span className="text-cyan-400 font-bold">{selectedPoints.length} / {measType === 'PointToPoint' ? 2 : 1} Picked</span>
          </div>

          <p className="text-slate-400 text-[10px]">
            {measType === 'PointToPoint'
              ? 'Click any two 3D points in the WebGL viewport to calculate precise Euclidean distance.'
              : 'Click any 3D point to compute orthogonal clearance to fitted ground plane.'}
          </p>

          {/* Caliper Calculation Output */}
          {measType === 'PointToPoint' && liveDistance !== null && (
            <div className="pt-2 border-t border-slate-800 space-y-1">
              <div className="flex justify-between items-baseline">
                <span className="text-slate-400">3D Distance (d):</span>
                <span className="text-emerald-400 font-bold text-base">{liveDistance.toFixed(3)} m (±{(uncertainty*1000).toFixed(0)} mm)</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Horizontal Distance (xy):</span>
                <span className="text-cyan-300">{liveHori.toFixed(3)} m</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Components [Δx, Δy, Δz]:</span>
                <span className="text-slate-200">[{liveDx.toFixed(3)}, {liveDy.toFixed(3)}, {liveDz.toFixed(3)}] m</span>
              </div>
            </div>
          )}

          {measType === 'PointToPlane' && pointToPlaneDist !== null && (
            <div className="pt-2 border-t border-slate-800 space-y-1">
              <div className="flex justify-between items-baseline">
                <span className="text-slate-400">Ground Elevation Clearance:</span>
                <span className="text-emerald-400 font-bold text-base">{pointToPlaneDist.toFixed(3)} m</span>
              </div>
            </div>
          )}

          <div className="flex items-center gap-2 pt-2">
            <button
              onClick={handleSaveCurrent}
              disabled={measType === 'PointToPoint' ? selectedPoints.length < 2 : selectedPoints.length < 1}
              className="flex-1 py-1.5 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 disabled:opacity-40 disabled:cursor-not-allowed rounded font-semibold transition-all flex items-center justify-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" /> Save Measurement
            </button>
            <button
              onClick={onClearSelectedPoints}
              className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 text-[11px]"
            >
              Clear Picks
            </button>
          </div>
        </div>
      </div>

      {/* Saved Measurements Ledger */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-[11px] text-slate-400 font-semibold uppercase tracking-wider">
            Measurement Ledger ({measurements.length})
          </span>
          {measurements.length > 0 && (
            <button
              onClick={onClearAll}
              className="text-[10px] text-rose-400 hover:underline"
            >
              Clear All
            </button>
          )}
        </div>

        {measurements.length === 0 ? (
          <div className="p-4 bg-[#121824] border border-[#1e293b] rounded-xl text-center text-slate-500 text-xs">
            No measurements recorded. Pick points in the 3D viewport to inspect distances.
          </div>
        ) : (
          <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
            {measurements.map((m) => (
              <div key={m.id} className="p-2.5 bg-[#121824] border border-slate-800 rounded-lg flex items-center justify-between text-[11px]">
                <div>
                  <span className="font-bold text-cyan-400">{m.name}</span>
                  <div className="text-white font-semibold text-xs">
                    {m.value.toFixed(3)} {m.unit} (±{(m.uncertainty * 1000).toFixed(0)} mm)
                  </div>
                  <div className="text-[10px] text-slate-500">{m.timestamp}</div>
                </div>
                <button
                  onClick={() => onDeleteMeasurement(m.id)}
                  className="p-1 text-slate-500 hover:text-rose-400 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
