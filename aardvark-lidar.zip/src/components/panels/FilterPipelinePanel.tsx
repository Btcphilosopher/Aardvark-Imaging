/**
 * Perception Pipeline Tuning Panel: Range, ROI, Voxel Grid, RANSAC Ground Segmentation & 3D Clustering.
 */
import React from 'react';
import { 
  Sliders, 
  Layers, 
  Box, 
  Sparkles, 
  Maximize2, 
  CheckCircle2, 
  AlertTriangle,
  Flame,
  Clock
} from 'lucide-react';
import { 
  FilterSettings, 
  GroundPlaneResult, 
  DetectedCluster, 
  PointCloudData 
} from '../../types/lidar';

interface FilterPipelinePanelProps {
  settings: FilterSettings;
  onSettingsChange: (newSettings: Partial<FilterSettings>) => void;
  groundPlane?: GroundPlaneResult;
  clusters: DetectedCluster[];
  cloud: PointCloudData | null;
  pipelineDurationMs: number;
}

export const FilterPipelinePanel: React.FC<FilterPipelinePanelProps> = ({
  settings,
  onSettingsChange,
  groundPlane,
  clusters,
  cloud,
  pipelineDurationMs
}) => {
  return (
    <div className="p-4 space-y-6 overflow-y-auto max-h-full font-mono text-xs text-slate-300">
      {/* Execution Latency Status */}
      <div className="bg-[#121824] border border-[#1e293b] p-3 rounded-xl flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-emerald-400" />
          <span className="font-semibold text-white">Pipeline Execution Time:</span>
        </div>
        <span className="text-emerald-300 font-bold text-sm">{pipelineDurationMs.toFixed(2)} ms</span>
      </div>

      {/* 1. Range Filter */}
      <div className="bg-[#121824] border border-[#1e293b] p-3.5 rounded-xl space-y-3">
        <div className="flex items-center justify-between">
          <span className="font-semibold text-white uppercase tracking-wider text-[11px] flex items-center gap-1.5">
            [1] Range Filtering
          </span>
          <input
            type="checkbox"
            checked={settings.enableRangeFilter}
            onChange={(e) => onSettingsChange({ enableRangeFilter: e.target.checked })}
            className="accent-cyan-400 w-4 h-4 rounded cursor-pointer"
          />
        </div>
        <div className="grid grid-cols-2 gap-3 pt-1">
          <div className="space-y-1">
            <div className="flex justify-between text-[11px]">
              <span className="text-slate-400">Min Range:</span>
              <span className="text-cyan-400 font-semibold">{settings.minRangeM.toFixed(1)} m</span>
            </div>
            <input
              type="range"
              min={0.1}
              max={10.0}
              step={0.1}
              value={settings.minRangeM}
              onChange={(e) => onSettingsChange({ minRangeM: parseFloat(e.target.value) })}
              className="w-full accent-cyan-400"
            />
          </div>
          <div className="space-y-1">
            <div className="flex justify-between text-[11px]">
              <span className="text-slate-400">Max Range:</span>
              <span className="text-cyan-400 font-semibold">{settings.maxRangeM.toFixed(1)} m</span>
            </div>
            <input
              type="range"
              min={10.0}
              max={120.0}
              step={5.0}
              value={settings.maxRangeM}
              onChange={(e) => onSettingsChange({ maxRangeM: parseFloat(e.target.value) })}
              className="w-full accent-cyan-400"
            />
          </div>
        </div>
      </div>

      {/* 2. ROI Pass-Through Crop Filter */}
      <div className="bg-[#121824] border border-[#1e293b] p-3.5 rounded-xl space-y-3">
        <div className="flex items-center justify-between">
          <span className="font-semibold text-white uppercase tracking-wider text-[11px] flex items-center gap-1.5">
            [2] ROI Bounding Box Crop
          </span>
          <input
            type="checkbox"
            checked={settings.enableRoiFilter}
            onChange={(e) => onSettingsChange({ enableRoiFilter: e.target.checked })}
            className="accent-cyan-400 w-4 h-4 rounded cursor-pointer"
          />
        </div>
        <div className="grid grid-cols-3 gap-2 text-[11px]">
          <div>
            <span className="text-slate-400">X (Forward):</span>
            <div className="text-slate-200">[{settings.roiBounds.xMin}, {settings.roiBounds.xMax}] m</div>
          </div>
          <div>
            <span className="text-slate-400">Y (Lateral):</span>
            <div className="text-slate-200">[{settings.roiBounds.yMin}, {settings.roiBounds.yMax}] m</div>
          </div>
          <div>
            <span className="text-slate-400">Z (Vertical):</span>
            <div className="text-slate-200">[{settings.roiBounds.zMin}, {settings.roiBounds.zMax}] m</div>
          </div>
        </div>
      </div>

      {/* 3. Voxel Grid Decimation */}
      <div className="bg-[#121824] border border-[#1e293b] p-3.5 rounded-xl space-y-3">
        <div className="flex items-center justify-between">
          <span className="font-semibold text-white uppercase tracking-wider text-[11px] flex items-center gap-1.5">
            [3] Voxel Grid Downsampling
          </span>
          <input
            type="checkbox"
            checked={settings.enableVoxelFilter}
            onChange={(e) => onSettingsChange({ enableVoxelFilter: e.target.checked })}
            className="accent-cyan-400 w-4 h-4 rounded cursor-pointer"
          />
        </div>
        <div className="space-y-1">
          <div className="flex justify-between text-[11px]">
            <span className="text-slate-400">Voxel Leaf Size:</span>
            <span className="text-purple-400 font-semibold">{settings.voxelSizeM.toFixed(2)} m</span>
          </div>
          <input
            type="range"
            min={0.02}
            max={0.25}
            step={0.01}
            value={settings.voxelSizeM}
            onChange={(e) => onSettingsChange({ voxelSizeM: parseFloat(e.target.value) })}
            className="w-full accent-cyan-400"
          />
        </div>
      </div>

      {/* 4. RANSAC Ground Plane Extraction */}
      <div className="bg-[#121824] border border-[#1e293b] p-3.5 rounded-xl space-y-3">
        <div className="flex items-center justify-between">
          <span className="font-semibold text-white uppercase tracking-wider text-[11px] flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-emerald-400" /> [4] RANSAC 3D Ground Plane
          </span>
          <input
            type="checkbox"
            checked={settings.enableRansacGround}
            onChange={(e) => onSettingsChange({ enableRansacGround: e.target.checked })}
            className="accent-cyan-400 w-4 h-4 rounded cursor-pointer"
          />
        </div>
        <div className="space-y-2">
          <div className="space-y-1">
            <div className="flex justify-between text-[11px]">
              <span className="text-slate-400">Distance Threshold:</span>
              <span className="text-emerald-400 font-semibold">{(settings.groundDistanceThreshM * 100).toFixed(0)} cm</span>
            </div>
            <input
              type="range"
              min={0.05}
              max={0.35}
              step={0.02}
              value={settings.groundDistanceThreshM}
              onChange={(e) => onSettingsChange({ groundDistanceThreshM: parseFloat(e.target.value) })}
              className="w-full accent-cyan-400"
            />
          </div>

          {groundPlane && (
            <div className="bg-[#0e141f] p-2.5 rounded-lg border border-slate-800 space-y-1 text-[11px]">
              <div className="flex justify-between">
                <span className="text-slate-400">Estimated Normal:</span>
                <span className="text-white font-mono">[{groundPlane.normal[0].toFixed(3)}, {groundPlane.normal[1].toFixed(3)}, {groundPlane.normal[2].toFixed(3)}]</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Plane Equation:</span>
                <span className="text-emerald-300 font-mono">ax + by + cz + {groundPlane.distance.toFixed(3)} = 0</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Inliers / Coverage:</span>
                <span className="text-cyan-300 font-semibold">{groundPlane.inlierCount.toLocaleString()} pts ({(groundPlane.inlierRatio * 100).toFixed(1)}%)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Road Grade / Slope:</span>
                <span className="text-purple-300 font-semibold">{groundPlane.slopeDeg.toFixed(2)}°</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 5. 3D Euclidean Clustering */}
      <div className="bg-[#121824] border border-[#1e293b] p-3.5 rounded-xl space-y-3">
        <div className="flex items-center justify-between">
          <span className="font-semibold text-white uppercase tracking-wider text-[11px] flex items-center gap-1.5">
            <Box className="w-3.5 h-3.5 text-cyan-400" /> [5] 3D Euclidean Clustering
          </span>
          <input
            type="checkbox"
            checked={settings.enableClustering}
            onChange={(e) => onSettingsChange({ enableClustering: e.target.checked })}
            className="accent-cyan-400 w-4 h-4 rounded cursor-pointer"
          />
        </div>

        <div className="space-y-2">
          <div className="space-y-1">
            <div className="flex justify-between text-[11px]">
              <span className="text-slate-400">Cluster Distance Threshold:</span>
              <span className="text-cyan-400 font-semibold">{settings.clusterDistanceThreshM.toFixed(2)} m</span>
            </div>
            <input
              type="range"
              min={0.3}
              max={2.5}
              step={0.1}
              value={settings.clusterDistanceThreshM}
              onChange={(e) => onSettingsChange({ clusterDistanceThreshM: parseFloat(e.target.value) })}
              className="w-full accent-cyan-400"
            />
          </div>

          {/* Detected Clusters Table */}
          {clusters.length > 0 && (
            <div className="space-y-1.5 pt-1">
              <div className="text-[11px] text-slate-400 font-semibold">
                Detected Objects ({clusters.length}):
              </div>
              <div className="space-y-1 max-h-40 overflow-y-auto pr-1">
                {clusters.map((c) => (
                  <div key={c.id} className="bg-[#0e141f] p-2 rounded border border-slate-800 flex items-center justify-between text-[10px]">
                    <div>
                      <span className="font-bold text-cyan-300">Obj #{c.id + 1}</span> ({c.classHint})
                      <div className="text-slate-400">
                        {c.dimensions[0].toFixed(1)}m × {c.dimensions[1].toFixed(1)}m × {c.dimensions[2].toFixed(1)}m
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-white font-semibold">{c.pointCount} pts</span>
                      <div className="text-emerald-400">{(c.confidence * 100).toFixed(0)}% conf</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
