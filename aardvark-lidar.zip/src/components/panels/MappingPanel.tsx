/**
 * 3D SLAM Mapping & ICP Scan Registration Panel.
 */
import React from 'react';
import { 
  Map, 
  Layers, 
  RotateCw, 
  Trash2, 
  PlusCircle, 
  CheckCircle2, 
  Activity, 
  FileDown,
  Sparkles
} from 'lucide-react';
import { ICPMetrics, PointCloudData } from '../../types/lidar';
import { KeyframeRecord } from '../../engine/mapping/slam';

interface MappingPanelProps {
  icpMetrics: ICPMetrics | null;
  onRunICP: () => void;
  onAddKeyframe: () => void;
  onClearMap: () => void;
  onExportMap: () => void;
  keyframes: KeyframeRecord[];
  globalMapCloud: PointCloudData | null;
  isMapAccumulating: boolean;
  onToggleAccumulate: () => void;
}

export const MappingPanel: React.FC<MappingPanelProps> = ({
  icpMetrics,
  onRunICP,
  onAddKeyframe,
  onClearMap,
  onExportMap,
  keyframes,
  globalMapCloud,
  isMapAccumulating,
  onToggleAccumulate
}) => {
  return (
    <div className="p-4 space-y-6 overflow-y-auto max-h-full font-mono text-xs text-slate-300">
      {/* SLAM Map Control Card */}
      <div className="bg-[#121824] border border-[#1e293b] p-3.5 rounded-xl space-y-3 shadow-lg">
        <div className="flex items-center justify-between">
          <span className="font-semibold text-white uppercase tracking-wider text-[11px] flex items-center gap-1.5">
            <Map className="w-3.5 h-3.5 text-cyan-400" /> Global Voxel Map
          </span>
          <span className="text-[10px] text-cyan-300 font-bold">
            {keyframes.length} KEYFRAMES
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={onToggleAccumulate}
            className={`p-2 rounded-lg font-semibold border transition-all flex items-center justify-center gap-1.5 ${
              isMapAccumulating
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 hover:bg-amber-500/30'
                : 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 hover:bg-cyan-500/30'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            {isMapAccumulating ? 'Pause Accumulation' : 'Live Map Accumulation'}
          </button>
          <button
            onClick={onAddKeyframe}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg font-semibold transition-all flex items-center justify-center gap-1.5"
          >
            <PlusCircle className="w-3.5 h-3.5 text-emerald-400" /> Commit Keyframe
          </button>
        </div>

        <div className="flex items-center gap-2 pt-1">
          <button
            onClick={onExportMap}
            className="flex-1 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-center flex items-center justify-center gap-1 transition-all"
          >
            <FileDown className="w-3.5 h-3.5 text-cyan-400" /> Export Global Map (.PLY)
          </button>
          <button
            onClick={onClearMap}
            title="Clear all accumulated map keyframes"
            className="p-1.5 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 rounded flex items-center justify-center transition-all"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* SVD ICP Scan Registration Engine */}
      <div className="bg-[#121824] border border-[#1e293b] p-3.5 rounded-xl space-y-3">
        <div className="flex items-center justify-between">
          <span className="font-semibold text-white uppercase tracking-wider text-[11px] flex items-center gap-1.5">
            <RotateCw className="w-3.5 h-3.5 text-purple-400" /> Point-to-Point ICP Registration
          </span>
          <button
            onClick={onRunICP}
            className="px-2.5 py-1 bg-purple-500/20 text-purple-300 border border-purple-500/40 hover:bg-purple-500/30 rounded font-semibold transition-all"
          >
            Execute ICP Step
          </button>
        </div>

        {icpMetrics && (
          <div className="bg-[#0e141f] p-3 rounded-lg border border-slate-800 space-y-2 text-[11px]">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Status:</span>
              <span className={icpMetrics.converged ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'}>
                {icpMetrics.converged ? 'CONVERGED (Optimal)' : 'ITERATING'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Iterations / Duration:</span>
              <span className="text-white font-mono">{icpMetrics.iterations} iters / {icpMetrics.durationMs.toFixed(1)} ms</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Residual RMSE Error:</span>
              <span className="text-cyan-300 font-mono">{(icpMetrics.residualRmse * 1000).toFixed(1)} mm</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Fitness / Inlier Score:</span>
              <span className="text-purple-300 font-semibold">{(icpMetrics.fitnessScore * 100).toFixed(1)}%</span>
            </div>
            <div className="pt-1 border-t border-slate-800 text-[10px] space-y-0.5">
              <span className="text-slate-400 block font-semibold">Estimated Relative Offset:</span>
              <div>Translation: [{icpMetrics.estimatedTransform.translation.map(v => v.toFixed(3)).join(', ')}] m</div>
              <div>Rotation Euler: [{icpMetrics.estimatedTransform.eulerDeg.map(v => v.toFixed(2)).join('°, ')}°]</div>
            </div>
          </div>
        )}
      </div>

      {/* Accumulated Map Keyframes Table */}
      <div className="space-y-2">
        <div className="text-[11px] text-slate-400 font-semibold uppercase tracking-wider">
          Keyframe Trajectory Graph
        </div>
        {keyframes.length === 0 ? (
          <div className="p-4 bg-[#121824] border border-[#1e293b] rounded-xl text-center text-slate-500 text-xs">
            No keyframes committed yet. Click "Commit Keyframe" or enable "Live Map Accumulation".
          </div>
        ) : (
          <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
            {keyframes.map((kf, index) => (
              <div key={kf.id} className="p-2 bg-[#121824] border border-slate-800 rounded flex items-center justify-between text-[11px]">
                <div>
                  <span className="text-cyan-400 font-bold">Keyframe #{index + 1}</span>
                  <div className="text-slate-400 text-[10px]">
                    Pose: [{kf.pose.translation.map(v => v.toFixed(2)).join(', ')}]
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-white font-semibold">{kf.pointCount.toLocaleString()} pts</span>
                  <div className="text-[10px] text-slate-500">t = {kf.timestamp.toFixed(2)}s</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
