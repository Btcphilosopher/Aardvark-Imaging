/**
 * Immutable Audit Trail, Provenance Logs & Point Cloud Export Studio.
 */
import React from 'react';
import { 
  FileDown, 
  History, 
  ShieldCheck, 
  FileText, 
  CheckCircle2, 
  AlertCircle,
  Database,
  Download
} from 'lucide-react';
import { AuditEvent, PointCloudData, SensorConfig } from '../../types/lidar';
import { PointCloudDownloader } from '../../engine/export/writers';

interface AuditExportPanelProps {
  auditLogs: AuditEvent[];
  cloud: PointCloudData | null;
  config: SensorConfig;
}

export const AuditExportPanel: React.FC<AuditExportPanelProps> = ({
  auditLogs,
  cloud,
  config
}) => {
  const handleExportPLY = () => {
    if (cloud) {
      PointCloudDownloader.exportPLY(cloud, `aardvark_${config.model}_${Date.now()}.ply`);
    }
  };

  const handleExportPCD = () => {
    if (cloud) {
      PointCloudDownloader.exportPCD(cloud, `aardvark_${config.model}_${Date.now()}.pcd`);
    }
  };

  const handleExportCSV = () => {
    if (cloud) {
      PointCloudDownloader.exportCSV(cloud, `aardvark_${config.model}_${Date.now()}.csv`);
    }
  };

  const handleExportProjectJSON = () => {
    const manifest = {
      project: "AARDVARK LIDAR Workspace",
      timestamp: new Date().toISOString(),
      sensorConfig: config,
      scanStats: cloud ? {
        pointCount: cloud.count,
        boundingBox: cloud.boundingBox,
        centroid: cloud.centroid
      } : null,
      auditHistory: auditLogs
    };
    PointCloudDownloader.exportJSON(manifest, `aardvark_project_${Date.now()}.json`);
  };

  return (
    <div className="p-4 space-y-6 overflow-y-auto max-h-full font-mono text-xs text-slate-300">
      {/* Export Formats Suite */}
      <div className="bg-[#121824] border border-[#1e293b] p-3.5 rounded-xl space-y-3 shadow-lg">
        <span className="font-semibold text-white uppercase tracking-wider text-[11px] flex items-center gap-1.5">
          <FileDown className="w-3.5 h-3.5 text-cyan-400" /> Export Point Cloud & Geometry
        </span>

        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={handleExportPLY}
            disabled={!cloud || cloud.count === 0}
            className="p-3 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 border border-slate-700 rounded-lg text-left transition-all space-y-1"
          >
            <div className="flex items-center justify-between">
              <span className="font-bold text-cyan-400">ASCII PLY</span>
              <Download className="w-3.5 h-3.5 text-slate-400" />
            </div>
            <p className="text-[10px] text-slate-400">Standard Polygon File with custom Aardvark header</p>
          </button>

          <button
            onClick={handleExportPCD}
            disabled={!cloud || cloud.count === 0}
            className="p-3 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 border border-slate-700 rounded-lg text-left transition-all space-y-1"
          >
            <div className="flex items-center justify-between">
              <span className="font-bold text-purple-400">PCD v0.7</span>
              <Download className="w-3.5 h-3.5 text-slate-400" />
            </div>
            <p className="text-[10px] text-slate-400">Point Cloud Library compatible ASCII format</p>
          </button>

          <button
            onClick={handleExportCSV}
            disabled={!cloud || cloud.count === 0}
            className="p-3 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 border border-slate-700 rounded-lg text-left transition-all space-y-1"
          >
            <div className="flex items-center justify-between">
              <span className="font-bold text-emerald-400">Tabular CSV</span>
              <Download className="w-3.5 h-3.5 text-slate-400" />
            </div>
            <p className="text-[10px] text-slate-400">Raw XYZ, Intensity, Ring, and Cluster ID columns</p>
          </button>

          <button
            onClick={handleExportProjectJSON}
            className="p-3 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-left transition-all space-y-1"
          >
            <div className="flex items-center justify-between">
              <span className="font-bold text-amber-400">Project JSON</span>
              <Download className="w-3.5 h-3.5 text-slate-400" />
            </div>
            <p className="text-[10px] text-slate-400">Full audit history, calibration and configurations</p>
          </button>
        </div>
      </div>

      {/* Immutable Audit Trail */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-[11px] text-slate-400 font-semibold uppercase tracking-wider flex items-center gap-1.5">
            <History className="w-3.5 h-3.5 text-slate-400" /> Immutable Audit & Security Trail ({auditLogs.length})
          </span>
          <span className="text-[10px] text-emerald-400 flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" /> SHA-256 Verified
          </span>
        </div>

        <div className="border border-slate-800 rounded-xl overflow-hidden bg-[#0c111a] max-h-72 overflow-y-auto">
          <div className="divide-y divide-slate-800/60 text-[11px]">
            {auditLogs.slice().reverse().map((log) => (
              <div key={log.id} className="p-2.5 space-y-1 hover:bg-slate-800/30 transition-colors">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-cyan-400">{log.eventType}</span>
                  <span className="text-[10px] text-slate-500">{log.timestamp}</span>
                </div>
                <div className="text-slate-300">{log.description}</div>
                <div className="flex items-center justify-between text-[10px] text-slate-500">
                  <span>Actor: {log.actor}</span>
                  <span className={log.status === 'SUCCESS' ? 'text-emerald-400' : 'text-amber-400'}>
                    {log.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
