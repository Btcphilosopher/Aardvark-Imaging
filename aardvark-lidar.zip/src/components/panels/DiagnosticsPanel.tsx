/**
 * Subsystem Health Diagnostics, Latency Waterfall & Fault Injection Suite.
 */
import React from 'react';
import { 
  Activity, 
  Thermometer, 
  RotateCw, 
  AlertTriangle, 
  CheckCircle2, 
  ShieldAlert, 
  Flame, 
  Sliders, 
  Zap,
  Info
} from 'lucide-react';
import { SensorTelemetry, HealthState } from '../../types/lidar';

interface DiagnosticsPanelProps {
  telemetry: SensorTelemetry;
  onInjectFault: (faultType: 'high_temp' | 'packet_loss' | 'rotor_jitter' | 'clear') => void;
}

export const DiagnosticsPanel: React.FC<DiagnosticsPanelProps> = ({
  telemetry,
  onInjectFault
}) => {
  return (
    <div className="p-4 space-y-6 overflow-y-auto max-h-full font-mono text-xs text-slate-300">
      {/* Subsystem Health Grid */}
      <div className="space-y-2">
        <span className="text-[11px] text-slate-400 font-semibold uppercase tracking-wider">
          Subsystem Telemetry Status
        </span>
        <div className="grid grid-cols-2 gap-2">
          <div className="p-2.5 bg-[#121824] border border-[#1e293b] rounded-lg">
            <span className="text-slate-400 text-[10px] block">Laser Emitter Array</span>
            <div className="flex items-center gap-1.5 text-emerald-400 font-bold mt-1">
              <CheckCircle2 className="w-3.5 h-3.5" /> 905nm Solid-State OK
            </div>
          </div>

          <div className="p-2.5 bg-[#121824] border border-[#1e293b] rounded-lg">
            <span className="text-slate-400 text-[10px] block">Rotor Motor Encoder</span>
            <div className="flex items-center gap-1.5 text-emerald-400 font-bold mt-1">
              <RotateCw className="w-3.5 h-3.5" /> {telemetry.measuredRpm.toFixed(0)} RPM (Locked)
            </div>
          </div>

          <div className="p-2.5 bg-[#121824] border border-[#1e293b] rounded-lg">
            <span className="text-slate-400 text-[10px] block">Optical Core Temperature</span>
            <div className={`flex items-center gap-1.5 font-bold mt-1 ${
              telemetry.opticalTempC > 65 ? 'text-rose-400' : 'text-amber-400'
            }`}>
              <Thermometer className="w-3.5 h-3.5" /> {telemetry.opticalTempC.toFixed(1)}°C
            </div>
          </div>

          <div className="p-2.5 bg-[#121824] border border-[#1e293b] rounded-lg">
            <span className="text-slate-400 text-[10px] block">Network Packet Loss</span>
            <div className={`flex items-center gap-1.5 font-bold mt-1 ${
              telemetry.packetLossPct > 5 ? 'text-rose-400' : 'text-emerald-400'
            }`}>
              <Activity className="w-3.5 h-3.5" /> {telemetry.packetLossPct.toFixed(2)}% Loss
            </div>
          </div>
        </div>
      </div>

      {/* Latency Waterfall Timing Budget */}
      <div className="bg-[#121824] border border-[#1e293b] p-3.5 rounded-xl space-y-3">
        <div className="flex items-center justify-between">
          <span className="font-semibold text-white uppercase tracking-wider text-[11px] flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-cyan-400" /> Latency Budget Waterfall
          </span>
          <span className="text-emerald-300 font-bold text-xs">{telemetry.totalLatencyMs.toFixed(2)} ms</span>
        </div>

        <div className="space-y-2 text-[10px]">
          <div>
            <div className="flex justify-between text-slate-400 mb-0.5">
              <span>UDP Ingestion & Socket Read:</span>
              <span className="text-slate-200">{telemetry.ingestionLatencyMs.toFixed(2)} ms</span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div className="bg-blue-500 h-full" style={{ width: `${(telemetry.ingestionLatencyMs / telemetry.totalLatencyMs) * 100}%` }}></div>
            </div>
          </div>

          <div>
            <div className="flex justify-between text-slate-400 mb-0.5">
              <span>Binary Packet Decode & Spherical Projection:</span>
              <span className="text-slate-200">{telemetry.decodeLatencyMs.toFixed(2)} ms</span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div className="bg-cyan-400 h-full" style={{ width: `${(telemetry.decodeLatencyMs / telemetry.totalLatencyMs) * 100}%` }}></div>
            </div>
          </div>

          <div>
            <div className="flex justify-between text-slate-400 mb-0.5">
              <span>Spatial Voxel Filter & RANSAC Ground:</span>
              <span className="text-slate-200">{telemetry.filterLatencyMs.toFixed(2)} ms</span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div className="bg-purple-400 h-full" style={{ width: `${(telemetry.filterLatencyMs / telemetry.totalLatencyMs) * 100}%` }}></div>
            </div>
          </div>

          <div>
            <div className="flex justify-between text-slate-400 mb-0.5">
              <span>Three.js WebGL 60FPS Render:</span>
              <span className="text-slate-200">{telemetry.renderLatencyMs.toFixed(2)} ms</span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div className="bg-emerald-400 h-full" style={{ width: `${(telemetry.renderLatencyMs / telemetry.totalLatencyMs) * 100}%` }}></div>
            </div>
          </div>
        </div>
      </div>

      {/* Active Diagnostic Alarms */}
      <div className="space-y-2">
        <span className="text-[11px] text-slate-400 font-semibold uppercase tracking-wider">
          Active Alarms & Remediation
        </span>

        {telemetry.activeAlarms.length === 0 ? (
          <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-lg flex items-center gap-2 text-emerald-300 text-xs">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>All sensory and computation subsystems operating within nominal limits.</span>
          </div>
        ) : (
          <div className="space-y-2">
            {telemetry.activeAlarms.map((alarm, idx) => (
              <div key={idx} className="p-3 bg-rose-500/15 border border-rose-500/30 rounded-lg space-y-1">
                <div className="flex items-center gap-1.5 text-rose-300 font-bold text-xs">
                  <ShieldAlert className="w-4 h-4 text-rose-400" />
                  <span>{alarm}</span>
                </div>
                <p className="text-[10px] text-slate-300 pl-5">
                  <span className="text-cyan-400 font-semibold">Remediation:</span> Check UDP socket buffer and verify rotor synchronization.
                </p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Diagnostic Stress & Fault Injection Suite */}
      <div className="bg-[#121824] border border-[#1e293b] p-3.5 rounded-xl space-y-3">
        <span className="font-semibold text-white uppercase tracking-wider text-[11px] block">
          Hardware Fault Simulation & Diagnostics Test
        </span>
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => onInjectFault('high_temp')}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 rounded text-left transition-all"
          >
            🔥 Thermal Core Drift (78°C)
          </button>
          <button
            onClick={() => onInjectFault('packet_loss')}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-rose-300 border border-slate-700 rounded text-left transition-all"
          >
            📡 Network Packet Loss (18%)
          </button>
          <button
            onClick={() => onInjectFault('rotor_jitter')}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-purple-300 border border-slate-700 rounded text-left transition-all"
          >
            ⚙️ Rotor Motor Slip
          </button>
          <button
            onClick={() => onInjectFault('clear')}
            className="p-2 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 rounded text-left font-semibold transition-all"
          >
            ✓ Clear All Injected Faults
          </button>
        </div>
      </div>
    </div>
  );
};
