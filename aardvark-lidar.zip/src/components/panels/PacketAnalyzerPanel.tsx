/**
 * UDP Packet Stream Inspector & Recording Replay Studio.
 */
import React, { useState } from 'react';
import { 
  Binary, 
  CircleDot, 
  Square, 
  Play, 
  Pause, 
  FileText, 
  ShieldCheck, 
  Activity,
  Download
} from 'lucide-react';
import { RawPacketRecord } from '../../types/lidar';

interface PacketAnalyzerPanelProps {
  packets: RawPacketRecord[];
  isRecording: boolean;
  onToggleRecording: () => void;
  recordedPacketCount: number;
}

export const PacketAnalyzerPanel: React.FC<PacketAnalyzerPanelProps> = ({
  packets,
  isRecording,
  onToggleRecording,
  recordedPacketCount
}) => {
  const [selectedPacket, setSelectedPacket] = useState<RawPacketRecord | null>(packets[0] || null);

  return (
    <div className="p-4 space-y-6 overflow-y-auto max-h-full font-mono text-xs text-slate-300">
      {/* Recording Studio Card */}
      <div className="bg-[#121824] border border-[#1e293b] p-3.5 rounded-xl space-y-3 shadow-lg">
        <div className="flex items-center justify-between">
          <span className="font-semibold text-white uppercase tracking-wider text-[11px] flex items-center gap-1.5">
            <CircleDot className={`w-3.5 h-3.5 ${isRecording ? 'text-rose-500 animate-ping' : 'text-slate-500'}`} />
            Packet Capture & PCAP Logger
          </span>
          {isRecording && (
            <span className="text-[10px] text-rose-400 font-bold animate-pulse">
              RECORDING ACTIVE
            </span>
          )}
        </div>

        <div className="flex items-center justify-between text-[11px] bg-[#0a0d14] p-2.5 rounded-lg border border-slate-800">
          <div>
            <span className="text-slate-400">Captured Packets:</span>
            <div className="text-white font-bold text-sm">{recordedPacketCount.toLocaleString()}</div>
          </div>
          <div>
            <span className="text-slate-400">Est. PCAP Size:</span>
            <div className="text-cyan-400 font-bold text-sm">{((recordedPacketCount * 1206) / (1024 * 1024)).toFixed(2)} MB</div>
          </div>
        </div>

        <button
          onClick={onToggleRecording}
          className={`w-full py-2 rounded-lg font-semibold flex items-center justify-center gap-2 border transition-all ${
            isRecording
              ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 hover:bg-rose-500/30'
              : 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 hover:bg-cyan-500/30'
          }`}
        >
          {isRecording ? <><Square className="w-3.5 h-3.5" /> Stop Capture & Finalize PCAP</> : <><CircleDot className="w-3.5 h-3.5" /> Start Raw Packet Capture</>}
        </button>
      </div>

      {/* Live Ingested Packet Table */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-[11px] text-slate-400 font-semibold uppercase tracking-wider">
            UDP Telemetry Stream (Port 2368)
          </span>
          <span className="text-[10px] text-emerald-400 flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" /> UDP Checksums OK
          </span>
        </div>

        <div className="border border-slate-800 rounded-xl overflow-hidden bg-[#0c111a]">
          <div className="grid grid-cols-5 p-2 bg-slate-900/80 text-[10px] text-slate-400 font-bold border-b border-slate-800">
            <span>SEQ #</span>
            <span>TIME HOST</span>
            <span>AZIMUTH</span>
            <span>BLOCKS</span>
            <span>STATUS</span>
          </div>
          <div className="max-h-48 overflow-y-auto divide-y divide-slate-800/60 text-[11px]">
            {packets.slice(-15).reverse().map((p) => (
              <div
                key={p.seq}
                onClick={() => setSelectedPacket(p)}
                className={`grid grid-cols-5 p-2 cursor-pointer transition-colors ${
                  selectedPacket?.seq === p.seq ? 'bg-cyan-500/15 text-cyan-300 font-semibold' : 'hover:bg-slate-800/40'
                }`}
              >
                <span className="text-white">#{p.seq}</span>
                <span className="text-slate-400">{p.timestampHost.toFixed(3)}</span>
                <span className="text-cyan-400">{p.startAzimuthDeg.toFixed(1)}° - {p.endAzimuthDeg.toFixed(1)}°</span>
                <span className="text-purple-400">{p.blockCount} blk</span>
                <span className="text-emerald-400">0x{p.status.toString(16).padStart(2, '0')} OK</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Hex / Binary Header Inspector */}
      {selectedPacket && (
        <div className="bg-[#121824] border border-[#1e293b] p-3 rounded-xl space-y-2 text-[11px]">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-white">Packet #{selectedPacket.seq} Payload Breakdown</span>
            <span className="text-slate-400">{selectedPacket.sizeBytes} Bytes</span>
          </div>

          <div className="bg-[#0a0d14] p-2.5 rounded-lg border border-slate-800 font-mono text-[10px] text-slate-300 space-y-1">
            <div className="text-cyan-400 font-bold">Header: 0xA4 0x56 0x01 0x00 (Aardvark HD Frame)</div>
            <div className="text-slate-400">Azimuth Range: {selectedPacket.startAzimuthDeg.toFixed(2)}° $\to$ {selectedPacket.endAzimuthDeg.toFixed(2)}°</div>
            <div className="text-slate-400">Beam Return Mode: Dual Return (Strongest + Last)</div>
            <div className="text-slate-500 pt-1 border-t border-slate-800 select-all">
              A4 56 01 00 68 09 00 00 12 4F C8 02 00 0C 00 40 1E 2B 3C 4D 5E 6F 70 81
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
