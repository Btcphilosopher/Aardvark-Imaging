/**
 * Live Scan Acquisition & Digital Twin Scenario Control Panel.
 */
import React from 'react';
import { 
  Radio, 
  Play, 
  Pause, 
  StepForward, 
  Layers, 
  RotateCw, 
  Maximize2, 
  Sparkles,
  Sliders,
  Volume2,
  Box,
  Eye
} from 'lucide-react';
import { 
  SensorConfig, 
  ScenarioId, 
  ColorMode, 
  PointCloudData, 
  SensorState 
} from '../../types/lidar';

interface LiveScanPanelProps {
  config: SensorConfig;
  onConfigChange: (newConfig: Partial<SensorConfig>) => void;
  scenario: ScenarioId;
  onScenarioChange: (s: ScenarioId) => void;
  sensorState: SensorState;
  onSensorStateChange: (st: SensorState) => void;
  onSingleStep: () => void;
  colorMode: ColorMode;
  onColorModeChange: (cm: ColorMode) => void;
  pointSize: number;
  onPointSizeChange: (size: number) => void;
  showBoundingBoxes: boolean;
  onToggleBoundingBoxes: () => void;
  showGroundPlane: boolean;
  onToggleGroundPlane: () => void;
  showGrid: boolean;
  onToggleGrid: () => void;
  showRangeRings: boolean;
  onToggleRangeRings: () => void;
  cloud: PointCloudData | null;
}

export const LiveScanPanel: React.FC<LiveScanPanelProps> = ({
  config,
  onConfigChange,
  scenario,
  onScenarioChange,
  sensorState,
  onSensorStateChange,
  onSingleStep,
  colorMode,
  onColorModeChange,
  pointSize,
  onPointSizeChange,
  showBoundingBoxes,
  onToggleBoundingBoxes,
  showGroundPlane,
  onToggleGroundPlane,
  showGrid,
  onToggleGrid,
  showRangeRings,
  onToggleRangeRings,
  cloud
}) => {
  const isStreaming = sensorState === 'STREAMING';

  return (
    <div className="p-4 space-y-6 overflow-y-auto max-h-full font-mono text-xs text-slate-300">
      {/* Play / Pause / Step Acquisition Bar */}
      <div className="bg-[#121824] border border-[#1e293b] p-3 rounded-xl shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <span className="font-semibold text-white uppercase tracking-wider text-[11px] flex items-center gap-1.5">
            <Radio className="w-3.5 h-3.5 text-cyan-400" /> Acquisition State
          </span>
          <span className="text-[10px] text-cyan-400 font-bold">
            {isStreaming ? 'STREAMING ACTIVE' : 'PAUSED'}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onSensorStateChange(isStreaming ? 'CONNECTED' : 'STREAMING')}
            className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg font-semibold text-xs transition-all ${
              isStreaming
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30'
                : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30'
            }`}
          >
            {isStreaming ? <><Pause className="w-3.5 h-3.5" /> Pause Stream</> : <><Play className="w-3.5 h-3.5" /> Start Live Stream</>}
          </button>
          <button
            onClick={onSingleStep}
            title="Acquire Single 360° Scan"
            className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg flex items-center justify-center transition-all"
          >
            <StepForward className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Digital Twin Simulation Scenarios */}
      <div className="space-y-2">
        <label className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">
          Digital Twin Scenario
        </label>
        <div className="grid grid-cols-2 gap-2">
          {[
            { id: 'industrial_warehouse', label: 'Warehouse & Machinery' },
            { id: 'urban_street', label: 'Urban Street Corridor' },
            { id: 'empty_room', label: 'Survey Calibration Room' },
            { id: 'robot_inspection', label: 'Robotic Inspection Cell' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => onScenarioChange(item.id as ScenarioId)}
              className={`p-2 rounded-lg text-left border transition-all ${
                scenario === item.id
                  ? 'bg-cyan-500/15 border-cyan-500 text-cyan-300 font-semibold'
                  : 'bg-[#121824] border-[#1e293b] text-slate-400 hover:text-slate-200 hover:bg-[#1a2333]'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Sensor Geometry & Hardware Parameters */}
      <div className="bg-[#121824] border border-[#1e293b] p-3 rounded-xl space-y-4">
        <span className="font-semibold text-white uppercase tracking-wider text-[11px] block">
          LiDAR Transceiver Array
        </span>

        {/* Beam Count Selection */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-[11px]">
            <span className="text-slate-400">Beam Channels:</span>
            <span className="text-cyan-400 font-bold">{config.beamCount} Beams</span>
          </div>
          <div className="grid grid-cols-4 gap-1.5">
            {[16, 32, 64, 128].map((beams) => (
              <button
                key={beams}
                onClick={() => onConfigChange({ beamCount: beams })}
                className={`py-1 rounded text-center border transition-all ${
                  config.beamCount === beams
                    ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500 font-bold'
                    : 'bg-slate-800/60 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
              >
                {beams}
              </button>
            ))}
          </div>
        </div>

        {/* Spin Rate / RPM Slider */}
        <div className="space-y-1">
          <div className="flex justify-between text-[11px]">
            <span className="text-slate-400">Rotation Speed:</span>
            <span className="text-purple-400 font-semibold">{config.rotationRateHz.toFixed(1)} Hz ({(config.rotationRateHz * 60).toFixed(0)} RPM)</span>
          </div>
          <input
            type="range"
            min={5.0}
            max={20.0}
            step={1.0}
            value={config.rotationRateHz}
            onChange={(e) => onConfigChange({ rotationRateHz: parseFloat(e.target.value) })}
            className="w-full accent-cyan-400"
          />
        </div>

        {/* Range Noise Std Deviation */}
        <div className="space-y-1">
          <div className="flex justify-between text-[11px]">
            <span className="text-slate-400">Range Noise (σ):</span>
            <span className="text-amber-400 font-semibold">{(config.noiseStdM * 1000).toFixed(1)} mm</span>
          </div>
          <input
            type="range"
            min={0.002}
            max={0.05}
            step={0.002}
            value={config.noiseStdM}
            onChange={(e) => onConfigChange({ noiseStdM: parseFloat(e.target.value) })}
            className="w-full accent-cyan-400"
          />
        </div>
      </div>

      {/* 3D Visual Color Modes */}
      <div className="bg-[#121824] border border-[#1e293b] p-3 rounded-xl space-y-3">
        <span className="font-semibold text-white uppercase tracking-wider text-[11px] block">
          3D Point Cloud Shader & Colormap
        </span>
        <div className="grid grid-cols-2 gap-1.5">
          {[
            { id: 'height', label: 'Elevation (Z)' },
            { id: 'intensity', label: 'Reflectivity / Intensity' },
            { id: 'range', label: 'Radial Distance' },
            { id: 'ring', label: 'Laser Ring / Beam ID' },
            { id: 'ground', label: 'Ground Segmentation' },
            { id: 'cluster', label: '3D Cluster ID' },
            { id: 'timestamp', label: 'Time of Arrival' }
          ].map((mode) => (
            <button
              key={mode.id}
              onClick={() => onColorModeChange(mode.id as ColorMode)}
              className={`p-2 rounded text-left border transition-all ${
                colorMode === mode.id
                  ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 font-semibold'
                  : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:text-slate-200'
              }`}
            >
              {mode.label}
            </button>
          ))}
        </div>

        {/* Point Size */}
        <div className="space-y-1 pt-2">
          <div className="flex justify-between text-[11px]">
            <span className="text-slate-400">Point Particle Scale:</span>
            <span className="text-cyan-400 font-semibold">{pointSize.toFixed(1)}x</span>
          </div>
          <input
            type="range"
            min={1.0}
            max={8.0}
            step={0.5}
            value={pointSize}
            onChange={(e) => onPointSizeChange(parseFloat(e.target.value))}
            className="w-full accent-cyan-400"
          />
        </div>
      </div>

      {/* Viewport Overlay Toggles */}
      <div className="bg-[#121824] border border-[#1e293b] p-3 rounded-xl space-y-2">
        <span className="font-semibold text-white uppercase tracking-wider text-[11px] block">
          Viewport Overlays
        </span>
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={onToggleBoundingBoxes}
            className={`p-2 rounded border flex items-center gap-2 ${
              showBoundingBoxes ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300' : 'bg-slate-800/60 border-slate-700 text-slate-400'
            }`}
          >
            <Box className="w-3.5 h-3.5" /> 3D Bounding Boxes
          </button>
          <button
            onClick={onToggleGroundPlane}
            className={`p-2 rounded border flex items-center gap-2 ${
              showGroundPlane ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300' : 'bg-slate-800/60 border-slate-700 text-slate-400'
            }`}
          >
            <Layers className="w-3.5 h-3.5" /> Ground Normal Plane
          </button>
          <button
            onClick={onToggleGrid}
            className={`p-2 rounded border flex items-center gap-2 ${
              showGrid ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300' : 'bg-slate-800/60 border-slate-700 text-slate-400'
            }`}
          >
            <Eye className="w-3.5 h-3.5" /> Coordinate Grid
          </button>
          <button
            onClick={onToggleRangeRings}
            className={`p-2 rounded border flex items-center gap-2 ${
              showRangeRings ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300' : 'bg-slate-800/60 border-slate-700 text-slate-400'
            }`}
          >
            <RotateCw className="w-3.5 h-3.5" /> 10m-50m Range Rings
          </button>
        </div>
      </div>

      {/* Point Cloud Stats */}
      {cloud && (
        <div className="bg-[#0e141f] border border-slate-800 p-3 rounded-xl space-y-1.5 text-[11px]">
          <div className="flex justify-between">
            <span className="text-slate-400">Current Scan Points:</span>
            <span className="text-white font-bold">{cloud.count.toLocaleString()} pts</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Bounding Box Span:</span>
            <span className="text-cyan-300 font-semibold">
              {(cloud.boundingBox.max[0] - cloud.boundingBox.min[0]).toFixed(1)}m × {(cloud.boundingBox.max[1] - cloud.boundingBox.min[1]).toFixed(1)}m × {(cloud.boundingBox.max[2] - cloud.boundingBox.min[2]).toFixed(1)}m
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
