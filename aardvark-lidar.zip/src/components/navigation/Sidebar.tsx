/**
 * Primary Workstation Navigation Sidebar.
 */
import React from 'react';
import { 
  Radio, 
  Sliders, 
  Map, 
  Compass, 
  Ruler, 
  Binary, 
  Activity, 
  FileDown,
  Layers,
  Settings
} from 'lucide-react';

export type TabType = 
  | 'live' 
  | 'filters' 
  | 'slam' 
  | 'calibration' 
  | 'calipers' 
  | 'packets' 
  | 'diagnostics' 
  | 'export';

interface SidebarProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
  clusterCount: number;
  alarmCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onTabChange,
  clusterCount,
  alarmCount
}) => {
  const tabs: { id: TabType; label: string; icon: React.ReactNode; badge?: string | number }[] = [
    { id: 'live', label: 'Live Stream', icon: <Radio className="w-4 h-4" /> },
    { id: 'filters', label: 'Perception Pipeline', icon: <Sliders className="w-4 h-4" />, badge: clusterCount > 0 ? `${clusterCount} objs` : undefined },
    { id: 'slam', label: '3D SLAM Mapping', icon: <Map className="w-4 h-4" /> },
    { id: 'calibration', label: 'SE(3) Calibration', icon: <Compass className="w-4 h-4" /> },
    { id: 'calipers', label: '3D Measurements', icon: <Ruler className="w-4 h-4" /> },
    { id: 'packets', label: 'Packet Inspector', icon: <Binary className="w-4 h-4" /> },
    { id: 'diagnostics', label: 'Health & Diagnostics', icon: <Activity className="w-4 h-4" />, badge: alarmCount > 0 ? `${alarmCount} alerts` : undefined },
    { id: 'export', label: 'Audit & Export', icon: <FileDown className="w-4 h-4" /> }
  ];

  return (
    <aside className="w-56 bg-[#0c111a] border-r border-[#1a2333] flex flex-col justify-between select-none">
      <div className="p-3 space-y-1">
        <div className="text-[10px] font-mono text-slate-500 uppercase tracking-wider px-2 py-1">
          OPERATOR WORKSPACE
        </div>
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-mono transition-all ${
                isActive
                  ? 'bg-cyan-500/15 text-cyan-400 border border-cyan-500/30 font-semibold shadow-inner'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <span className={isActive ? 'text-cyan-400' : 'text-slate-400'}>
                  {tab.icon}
                </span>
                <span>{tab.label}</span>
              </div>
              {tab.badge && (
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-medium ${
                  typeof tab.badge === 'string' && tab.badge.includes('alert')
                    ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                    : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                }`}>
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Footer System Status */}
      <div className="p-3 border-t border-[#1a2333] text-[11px] font-mono text-slate-500 space-y-1">
        <div className="flex items-center justify-between">
          <span>Target Architecture:</span>
          <span className="text-slate-400">AV-LIDAR-x86</span>
        </div>
        <div className="flex items-center justify-between">
          <span>Engine Runtime:</span>
          <span className="text-emerald-400">Python/Rust SIMD</span>
        </div>
      </div>
    </aside>
  );
};
