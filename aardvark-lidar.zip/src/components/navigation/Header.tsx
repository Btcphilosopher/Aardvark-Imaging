/**
 * Workstation Header & Global Telemetry Status Bar.
 */
import React from 'react';
import { 
  Radio, 
  Activity, 
  Cpu, 
  Thermometer, 
  RotateCw, 
  ShieldAlert, 
  Wifi, 
  WifiOff,
  Zap,
  Clock
} from 'lucide-react';
import { SensorTelemetry, SensorState, SensorConfig } from '../../types/lidar';

interface HeaderProps {
  telemetry: SensorTelemetry;
  sensorState: SensorState;
  config: SensorConfig;
  onConnectToggle: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  telemetry,
  sensorState,
  config,
  onConnectToggle
}) => {
  const getHealthBadge = () => {
    switch (telemetry.healthState) {
      case 'HEALTHY':
        return <span className="flex items-center gap-1 text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full text-xs font-mono font-semibold">● NOMINAL</span>;
      case 'DEGRADED':
        return <span className="flex items-center gap-1 text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded-full text-xs font-mono font-semibold">▲ DEGRADED</span>;
      case 'WARNING':
        return <span className="flex items-center gap-1 text-orange-400 bg-orange-500/10 border border-orange-500/20 px-2 py-0.5 rounded-full text-xs font-mono font-semibold">▲ WARNING</span>;
      default:
        return <span className="flex items-center gap-1 text-rose-400 bg-rose-500/10 border border-rose-500/20 px-2 py-0.5 rounded-full text-xs font-mono font-semibold">✕ FAULT</span>;
    }
  };

  return (
    <header className="h-14 bg-[#0d121d] border-b border-[#1b2537] px-4 flex items-center justify-between select-none z-20">
      {/* Brand & System Title */}
      <div className="flex items-center gap-3">
        <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-600 to-blue-500 text-white shadow-lg shadow-cyan-500/20 font-bold font-mono text-sm">
          AV
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-sm font-semibold tracking-wide text-white font-mono">
              AARDVARK LIDAR
            </h1>
            <span className="text-[10px] bg-slate-800 text-cyan-400 border border-slate-700 px-1.5 py-0.2 rounded font-mono font-medium">
              v1.0.0 ENTERPRISE
            </span>
          </div>
          <p className="text-[11px] text-slate-400 font-mono">
            {config.model} • S/N: {config.serialNumber} • {config.beamCount} BEAMS
          </p>
        </div>
      </div>

      {/* Real-time Latency & Acquisition Telemetry */}
      <div className="hidden lg:flex items-center gap-6 font-mono text-xs text-slate-300">
        <div className="flex items-center gap-2">
          <Activity className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
          <span className="text-slate-400">Scan Rate:</span>
          <span className="text-white font-semibold">{telemetry.fps.toFixed(1)} Hz</span>
        </div>

        <div className="flex items-center gap-2">
          <Zap className="w-3.5 h-3.5 text-blue-400" />
          <span className="text-slate-400">Throughput:</span>
          <span className="text-white font-semibold">{(telemetry.pointsPerSec / 1000).toFixed(1)}k pts/s</span>
        </div>

        <div className="flex items-center gap-2">
          <Clock className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-slate-400">Latency:</span>
          <span className="text-emerald-300 font-semibold">{telemetry.totalLatencyMs.toFixed(1)} ms</span>
        </div>

        <div className="flex items-center gap-2">
          <Thermometer className="w-3.5 h-3.5 text-amber-400" />
          <span className="text-slate-400">Optics:</span>
          <span className="text-amber-300 font-semibold">{telemetry.opticalTempC.toFixed(1)}°C</span>
        </div>

        <div className="flex items-center gap-2">
          <RotateCw className="w-3.5 h-3.5 text-purple-400" />
          <span className="text-slate-400">Rotor:</span>
          <span className="text-purple-300 font-semibold">{telemetry.measuredRpm.toFixed(0)} RPM</span>
        </div>
      </div>

      {/* Connection & Diagnostics Badges */}
      <div className="flex items-center gap-3">
        {getHealthBadge()}

        <button
          onClick={onConnectToggle}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-all shadow-md ${
            sensorState === 'STREAMING' || sensorState === 'CONNECTED'
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30'
              : 'bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30'
          }`}
        >
          {sensorState === 'STREAMING' || sensorState === 'CONNECTED' ? (
            <>
              <Radio className="w-3.5 h-3.5 animate-pulse text-emerald-400" />
              <span>STREAMING</span>
            </>
          ) : (
            <>
              <WifiOff className="w-3.5 h-3.5 text-rose-400" />
              <span>DISCONNECTED</span>
            </>
          )}
        </button>
      </div>
    </header>
  );
};
