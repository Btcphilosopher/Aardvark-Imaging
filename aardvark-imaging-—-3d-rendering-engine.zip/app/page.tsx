'use client';

import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  Layers,
  Box,
  Type,
  Sun,
  Camera as CameraIcon,
  Sliders,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  Download,
  Eye,
  EyeOff,
  Plus,
  Zap,
  Activity,
  Palette,
  Compass
} from 'lucide-react';

import {
  Scene,
  SceneNode,
  NodeType,
  WebGLRenderer,
  RenderMode,
  AOVType,
  PathTracer,
  Timeline,
  Compositor,
  Exporter,
  Material,
  Vec3,
  GLYPH_PATHS
} from '../engine';

export default function AardvarkStudioPage() {
  // Engine Core Canvas References
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const compositeCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const pathTraceCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const rendererRef = useRef<WebGLRenderer | null>(null);
  const pathTracerRef = useRef<PathTracer | null>(null);
  const sceneRef = useRef<Scene | null>(null);
  const timelineRef = useRef<Timeline | null>(null);
  const compositorRef = useRef<Compositor | null>(null);

  // Synced React State for Clean Rendering
  const [sceneState, setSceneState] = useState<Scene | null>(null);
  const [timelineState, setTimelineState] = useState<Timeline | null>(null);
  const [compositorState, setCompositorState] = useState<Compositor | null>(null);

  // UI State
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [renderMode, setRenderMode] = useState<RenderMode>(RenderMode.STANDARD);
  const [aovType, setAovType] = useState<AOVType>(AOVType.BEAUTY);
  const [activeInspectorTab, setActiveInspectorTab] = useState<
    'transform' | 'extrude' | 'material' | 'camera' | 'lighting' | 'compositor'
  >('material');

  // Animation & Timeline State
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [timelineDuration] = useState<number>(5.0);

  // Path Tracer progressive status
  const [pathTracerSamples, setPathTracerSamples] = useState<number>(0);
  const [isPathTracing, setIsPathTracing] = useState<boolean>(false);

  // Performance Telemetry
  const [fps, setFps] = useState<number>(60);
  const [drawCalls, setDrawCalls] = useState<number>(0);
  const [triangles, setTriangles] = useState<number>(0);
  const [renderTimeMs, setRenderTimeMs] = useState<number>(0);

  // Interaction State (Orbit / Pan / Zoom)
  const isDraggingRef = useRef<boolean>(false);
  const lastMousePosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const dragButtonRef = useRef<number>(0); // 0: Left orbit, 2: Right pan

  // State Trigger for UI Re-renders
  const [, setSceneRevision] = useState<number>(0);

  const triggerUpdate = useCallback(() => {
    setSceneRevision((prev) => prev + 1);
  }, []);

  const updateSelectedNode = useCallback((fn: (node: SceneNode) => void) => {
    if (!sceneRef.current || !selectedNodeId) return;
    const node = sceneRef.current.findNodeById(selectedNodeId);
    if (node) {
      fn(node);
      triggerUpdate();
    }
  }, [selectedNodeId, triggerUpdate]);

  // Initialize Engine
  useEffect(() => {
    if (!canvasRef.current || !compositeCanvasRef.current || !pathTraceCanvasRef.current) return;

    const glCanvas = canvasRef.current;
    const compCanvas = compositeCanvasRef.current;
    const ptCanvas = pathTraceCanvasRef.current;

    // 1. Instantiate Renderer, Scene, Timeline, Compositor
    const renderer = new WebGLRenderer(glCanvas);
    rendererRef.current = renderer;

    const scene = Scene.createVectorShowcaseScene();
    sceneRef.current = scene;
    setSceneState(scene);

    const timeline = new Timeline();
    timeline.isPlaying = true;
    timelineRef.current = timeline;
    setTimelineState(timeline);

    const compositor = new Compositor();
    compositorRef.current = compositor;
    setCompositorState(compositor);

    const pathTracer = new PathTracer();
    pathTracerRef.current = pathTracer;

    // Resize Handler
    const handleResize = () => {
      const container = glCanvas.parentElement;
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      if (w === 0 || h === 0) return;

      glCanvas.width = w;
      glCanvas.height = h;
      compCanvas.width = w;
      compCanvas.height = h;
      ptCanvas.width = w;
      ptCanvas.height = h;

      renderer.setSize(w, h);
      scene.activeCamera.aspect = w / h;
      scene.activeCamera.updateMatrices();
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    // Animation Render Loop
    let animationFrameId: number;
    let lastTime = performance.now();

    const renderLoop = (timeNow: number) => {
      const dt = Math.min(0.1, (timeNow - lastTime) / 1000);
      lastTime = timeNow;

      if (timelineRef.current && sceneRef.current) {
        timelineRef.current.update(dt);
        const curTime = timelineRef.current.currentTime;
        setCurrentTime(curTime);

        // Drive animation tracks on scene nodes
        for (const track of timelineRef.current.tracks) {
          const val = timelineRef.current.evaluateTrack(track, curTime);
          const targetNode = sceneRef.current.root.children.find((n) => n.name === track.targetId);

          if (track.targetId === 'camera' && sceneRef.current.activeCamera) {
            if (track.property === 'camera.focusDistance') {
              sceneRef.current.activeCamera.focusDistance = val;
            }
          } else if (targetNode) {
            if (track.property === 'transform.rotation.y') {
              targetNode.transform.rotation.y = val;
              targetNode.transform.isDirty = true;
            } else if (track.property === 'transform.rotation.z') {
              targetNode.transform.rotation.z = val;
              targetNode.transform.isDirty = true;
            } else if (track.property === 'transform.position.y') {
              targetNode.transform.position.y = val;
              targetNode.transform.isDirty = true;
            }
          }
        }

        // Camera Handheld Shake
        sceneRef.current.activeCamera.updateShake(timeNow / 1000);
      }

      // Render Stage
      if (rendererRef.current && sceneRef.current && compositorRef.current) {
        if (renderMode === RenderMode.PATHTRACED) {
          if (pathTracerRef.current && pathTracerRef.current.isRendering) {
            const isDone = pathTracerRef.current.renderSampleBatch(sceneRef.current, 10);
            pathTracerRef.current.drawToCanvas(ptCanvas);
            setPathTracerSamples(pathTracerRef.current.sampleCount);
            if (isDone) {
              pathTracerRef.current.isRendering = false;
              setIsPathTracing(false);
            }
          }
        } else {
          rendererRef.current.renderMode = renderMode;
          rendererRef.current.currentAOV = aovType;
          rendererRef.current.render(sceneRef.current);

          // Run Compositor Post Deck
          compositorRef.current.composite(glCanvas, compCanvas);

          // Update Stats
          setFps(rendererRef.current.stats.fps);
          setDrawCalls(rendererRef.current.stats.drawCalls);
          setTriangles(Math.floor(rendererRef.current.stats.triangles));
          setRenderTimeMs(parseFloat(rendererRef.current.stats.renderTimeMs.toFixed(2)));
        }
      }

      animationFrameId = requestAnimationFrame(renderLoop);
    };

    animationFrameId = requestAnimationFrame(renderLoop);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, [renderMode, aovType]);

  // Viewport Orbit / Pan Navigation
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    isDraggingRef.current = true;
    dragButtonRef.current = e.button;
    lastMousePosRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDraggingRef.current || !sceneRef.current) return;

    const dx = e.clientX - lastMousePosRef.current.x;
    const dy = e.clientY - lastMousePosRef.current.y;
    lastMousePosRef.current = { x: e.clientX, y: e.clientY };

    const cam = sceneRef.current.activeCamera;
    const pos = cam.transform.position;

    if (dragButtonRef.current === 0) {
      // Left Drag: Orbit Camera around center
      const sensitivity = 0.006;
      const radius = Math.sqrt(pos.x * pos.x + pos.y * pos.y + pos.z * pos.z);
      const theta = Math.atan2(pos.x, pos.z) - dx * sensitivity;
      const phi = Math.asin(Math.max(-0.99, Math.min(0.99, pos.y / radius))) + dy * sensitivity;

      pos.x = radius * Math.cos(phi) * Math.sin(theta);
      pos.y = radius * Math.sin(phi);
      pos.z = radius * Math.cos(phi) * Math.cos(theta);

      cam.lookAt(new Vec3(0, 0.4, 0));
      cam.updateMatrices();
      triggerUpdate();
    } else if (dragButtonRef.current === 2 || e.shiftKey) {
      // Right Drag / Shift+Drag: Pan Camera
      const panSpeed = 0.005;
      pos.x -= dx * panSpeed;
      pos.y += dy * panSpeed;
      cam.lookAt(new Vec3(0, 0.4, 0));
      cam.updateMatrices();
      triggerUpdate();
    }
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    if (!sceneRef.current) return;
    const cam = sceneRef.current.activeCamera;
    const zoomFactor = 1.0 + e.deltaY * 0.001;
    cam.transform.position.scale(zoomFactor);
    cam.updateMatrices();
    triggerUpdate();
  };

  // Start Path Tracer Render
  const startPathTracing = () => {
    if (!sceneRef.current || !pathTracerRef.current || !canvasRef.current) return;
    setRenderMode(RenderMode.PATHTRACED);
    setIsPathTracing(true);
    const w = canvasRef.current.width;
    const h = canvasRef.current.height;
    pathTracerRef.current.init(w, h, sceneRef.current);
    pathTracerRef.current.isRendering = true;
  };

  // Get Current Selected Node
  const activeNodeId = selectedNodeId ?? sceneState?.root.children[2]?.id ?? null;
  const selectedNode = activeNodeId && sceneState
    ? sceneState.findNodeById(activeNodeId)
    : null;

  return (
    <div
      id="aardvark_workspace"
      className="flex flex-col w-screen h-screen bg-[#0d0f14] text-[#d1d5db] font-sans overflow-hidden select-none"
    >
      {/* 1. TOP PROFESSIONAL STUDIO BAR */}
      <header
        id="studio_header"
        className="flex items-center justify-between px-3.5 py-2 bg-[#12151d] border-b border-[#232938] z-30 shrink-0"
      >
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-2.5 py-1 bg-gradient-to-r from-amber-500/20 to-orange-500/10 border border-amber-500/40 rounded-md shadow-sm">
            <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
            <span className="text-xs font-bold tracking-wider text-amber-300 uppercase">
              Aardvark 3D Engine
            </span>
          </div>
          <span className="text-[11px] font-mono text-[#8b9bb4] hidden md:inline">
            Physically Based Renderer & Compositor
          </span>
        </div>

        {/* Center: Render Mode and AOV Selection */}
        <div className="flex items-center gap-2">
          {/* Render Mode Pills */}
          <div className="flex bg-[#181d29] p-0.5 rounded-lg border border-[#2a3449]">
            <button
              id="btn_mode_raster"
              onClick={() => {
                setRenderMode(RenderMode.STANDARD);
                setIsPathTracing(false);
              }}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-all ${
                renderMode === RenderMode.STANDARD
                  ? 'bg-amber-500 text-black shadow font-semibold'
                  : 'text-[#9aa7bc] hover:text-white'
              }`}
            >
              PBR Raster
            </button>
            <button
              id="btn_mode_cinematic"
              onClick={() => {
                setRenderMode(RenderMode.CINEMATIC);
                if (sceneRef.current) {
                  sceneRef.current.activeCamera.dofEnabled = true;
                }
                setIsPathTracing(false);
              }}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-all ${
                renderMode === RenderMode.CINEMATIC
                  ? 'bg-amber-500 text-black shadow font-semibold'
                  : 'text-[#9aa7bc] hover:text-white'
              }`}
            >
              Cinematic DoF
            </button>
            <button
              id="btn_mode_pathtracer"
              onClick={startPathTracing}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-all flex items-center gap-1.5 ${
                renderMode === RenderMode.PATHTRACED
                  ? 'bg-amber-500 text-black shadow font-semibold'
                  : 'text-[#9aa7bc] hover:text-white'
              }`}
            >
              <Zap className="w-3.5 h-3.5" />
              Path Tracer
            </button>
          </div>

          {/* AOV Pass Selector */}
          {renderMode !== RenderMode.PATHTRACED && (
            <div className="flex items-center gap-1 bg-[#181d29] px-2 py-1 rounded-lg border border-[#2a3449]">
              <Layers className="w-3.5 h-3.5 text-[#8b9bb4]" />
              <select
                id="select_aov"
                value={aovType}
                onChange={(e) => setAovType(e.target.value as AOVType)}
                className="bg-transparent text-xs text-[#d1d5db] font-medium outline-none cursor-pointer"
              >
                <option value={AOVType.BEAUTY}>AOV: Beauty Pass</option>
                <option value={AOVType.NORMALS}>AOV: Surface Normals</option>
                <option value={AOVType.DEPTH}>AOV: Linear Depth</option>
                <option value={AOVType.ALBEDO}>AOV: Base Color / Albedo</option>
                <option value={AOVType.ROUGHNESS}>AOV: Roughness Map</option>
                <option value={AOVType.METALLIC}>AOV: Metallic Map</option>
                <option value={AOVType.EMISSION}>AOV: Radiance Emission</option>
                <option value={AOVType.SHADOWS}>AOV: Shadow Mask</option>
                <option value={AOVType.OBJECT_IDS}>AOV: Object / Cryptomatte IDs</option>
              </select>
            </div>
          )}
        </div>

        {/* Right Toolbar: Preset Switcher & Exporters */}
        <div className="flex items-center gap-2">
          {/* Preset Scene Switcher */}
          <button
            id="btn_preset_vector"
            onClick={() => {
              const newScene = Scene.createVectorShowcaseScene();
              sceneRef.current = newScene;
              setSceneState(newScene);
              const node = newScene.root.children[2];
              if (node) setSelectedNodeId(node.id);
              triggerUpdate();
            }}
            className="px-2.5 py-1 text-xs bg-[#1a2130] hover:bg-[#232c3f] border border-[#2d3850] rounded-md text-[#d1d5db] transition-colors"
          >
            Vector Studio
          </button>
          <button
            id="btn_preset_product"
            onClick={() => {
              const newScene = Scene.createCinematicProductScene();
              sceneRef.current = newScene;
              setSceneState(newScene);
              const node = newScene.root.children[2];
              if (node) setSelectedNodeId(node.id);
              triggerUpdate();
            }}
            className="px-2.5 py-1 text-xs bg-[#1a2130] hover:bg-[#232c3f] border border-[#2d3850] rounded-md text-[#d1d5db] transition-colors"
          >
            Product Scene
          </button>

          {/* Export Render Button */}
          <button
            id="btn_export_png"
            onClick={() => {
              const exportCanvas =
                renderMode === RenderMode.PATHTRACED
                  ? pathTraceCanvasRef.current
                  : compositeCanvasRef.current;
              if (exportCanvas) {
                Exporter.exportImage(exportCanvas, 'aardvark_master_render.png');
              }
            }}
            className="flex items-center gap-1.5 px-3 py-1 bg-amber-500 hover:bg-amber-400 text-black font-semibold text-xs rounded-md shadow transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export PNG</span>
          </button>
        </div>
      </header>

      {/* 2. MAIN WORKSPACE VIEWPORT & PANELS */}
      <div className="flex flex-1 overflow-hidden relative">
        {/* LEFT PANEL: Composition Outliner & Scene Hierarchy */}
        <aside
          id="scene_outliner_panel"
          className="w-64 bg-[#12151d] border-r border-[#232938] flex flex-col shrink-0 z-20"
        >
          <div className="flex items-center justify-between px-3 py-2 border-b border-[#232938] bg-[#161a24]">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-bold tracking-wide uppercase text-[#c3cee0]">
                Composition Outliner
              </span>
            </div>

            {/* Add Node Quick Menu */}
            <div className="flex items-center gap-1">
              <button
                id="btn_add_extrude"
                title="Add 2D Vector Path Extrusion"
                onClick={() => {
                  if (!sceneRef.current) return;
                  const node = new SceneNode('Custom Vector Extrude', NodeType.VECTOR_LAYER);
                  node.svgPathString = GLYPH_PATHS['AARDVARK_LOGO'];
                  node.transform.setPosition((Math.random() - 0.5) * 2, 1.0, 0);
                  node.rebuildVectorMesh();
                  node.materials = [Material.createGold()];
                  sceneRef.current.add(node);
                  setSelectedNodeId(node.id);
                  triggerUpdate();
                }}
                className="p-1 hover:bg-[#252f44] rounded text-[#8b9bb4] hover:text-amber-400"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Scene Tree Node List */}
          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {sceneState?.root.children.map((node) => {
              const isSelected = node.id === selectedNodeId;
              let Icon = Box;
              if (node.type === NodeType.VECTOR_LAYER) Icon = Layers;
              else if (node.type === NodeType.TEXT_3D) Icon = Type;
              else if (node.type === NodeType.LIGHT) Icon = Sun;
              else if (node.type === NodeType.CAMERA) Icon = CameraIcon;

              return (
                <div
                  key={node.id}
                  id={`outliner_node_${node.id}`}
                  onClick={() => {
                    setSelectedNodeId(node.id);
                    triggerUpdate();
                  }}
                  className={`flex items-center justify-between px-2.5 py-1.5 rounded-md text-xs cursor-pointer transition-colors ${
                    isSelected
                      ? 'bg-[#2b354c] text-amber-300 font-semibold border border-amber-500/40'
                      : 'text-[#a2b1c8] hover:bg-[#1a202c] hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <Icon
                      className={`w-3.5 h-3.5 shrink-0 ${
                        isSelected ? 'text-amber-400' : 'text-[#72829c]'
                      }`}
                    />
                    <span className="truncate">{node.name}</span>
                  </div>

                  <div className="flex items-center gap-1">
                    {/* 2D / 3D Mode Toggle for Vector Layers */}
                    {node.type === NodeType.VECTOR_LAYER && (
                      <button
                        title={
                          node.is3D
                            ? 'Switch to Flat 2D Vector Layer'
                            : 'Switch to 3D Extruded Layer'
                        }
                        onClick={(e) => {
                          e.stopPropagation();
                          updateSelectedNode((n) => {
                            if (n.id === node.id) {
                              n.is3D = !n.is3D;
                              n.rebuildVectorMesh();
                            }
                          });
                        }}
                        className={`px-1.5 py-0.5 text-[10px] font-bold rounded ${
                          node.is3D
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                            : 'bg-blue-500/20 text-blue-400 border border-blue-500/40'
                        }`}
                      >
                        {node.is3D ? '3D' : '2D'}
                      </button>
                    )}

                    {/* Visibility toggle */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        node.visible = !node.visible;
                        triggerUpdate();
                      }}
                      className="p-1 text-[#62738d] hover:text-white"
                    >
                      {node.visible ? (
                        <Eye className="w-3.5 h-3.5" />
                      ) : (
                        <EyeOff className="w-3.5 h-3.5 text-red-400" />
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Scene Quick Stats Widget */}
          <div className="p-2.5 bg-[#10131a] border-t border-[#232938] text-[11px] font-mono space-y-1 text-[#7888a2]">
            <div className="flex justify-between">
              <span>FPS:</span>
              <span className="text-emerald-400 font-bold">{fps}</span>
            </div>
            <div className="flex justify-between">
              <span>Draw Calls:</span>
              <span className="text-amber-300">{drawCalls}</span>
            </div>
            <div className="flex justify-between">
              <span>Triangles:</span>
              <span className="text-[#c1cce0]">{triangles.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span>Frame Latency:</span>
              <span className="text-[#a4b4cc]">{renderTimeMs} ms</span>
            </div>
          </div>
        </aside>

        {/* CENTER VIEWPORT STAGE */}
        <main
          id="viewport_stage"
          className="flex-1 flex flex-col relative bg-[#090b0f] overflow-hidden"
        >
          {/* Active Canvas Layer */}
          <div className="flex-1 relative w-full h-full cursor-grab active:cursor-grabbing">
            {/* Raw WebGL Rasterizer Canvas (Hidden offscreen for Compositor) */}
            <canvas
              ref={canvasRef}
              className="absolute inset-0 w-full h-full pointer-events-none opacity-0"
            />

            {/* Compositor Final Output Canvas (Real-time PBR + Post Effects) */}
            <canvas
              ref={compositeCanvasRef}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onWheel={handleWheel}
              onContextMenu={(e) => e.preventDefault()}
              className={`absolute inset-0 w-full h-full ${
                renderMode === RenderMode.PATHTRACED ? 'hidden' : 'block'
              }`}
            />

            {/* Path Tracer Accumulation Canvas (Monte Carlo Path Traced Output) */}
            <canvas
              ref={pathTraceCanvasRef}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onWheel={handleWheel}
              onContextMenu={(e) => e.preventDefault()}
              className={`absolute inset-0 w-full h-full ${
                renderMode === RenderMode.PATHTRACED ? 'block' : 'hidden'
              }`}
            />

            {/* Floating Telemetry & Cinematic Optics HUD */}
            <div className="absolute top-3 left-3 flex flex-col gap-1.5 pointer-events-none z-10">
              <div className="flex items-center gap-2 px-2.5 py-1 bg-[#121622]/80 backdrop-blur-md border border-[#2b364e] rounded-md text-xs font-mono text-[#a5b6d1]">
                <Activity className="w-3.5 h-3.5 text-emerald-400" />
                <span>Render: {renderMode}</span>
                <span className="text-[#55647e]">|</span>
                <span>
                  Camera: {sceneState?.activeCamera.focalLength}mm f/
                  {sceneState?.activeCamera.fStop}
                </span>
                <span className="text-[#55647e]">|</span>
                <span>Focus: {sceneState?.activeCamera.focusDistance.toFixed(2)}m</span>
              </div>

              {renderMode === RenderMode.PATHTRACED && (
                <div className="flex items-center gap-2 px-2.5 py-1 bg-amber-950/80 backdrop-blur-md border border-amber-600/50 rounded-md text-xs font-mono text-amber-300">
                  <Zap className="w-3.5 h-3.5 animate-spin" />
                  <span>Monte Carlo SPP: {pathTracerSamples} / 500</span>
                  {isPathTracing ? (
                    <span className="text-emerald-400 font-bold ml-1">● Accumulating</span>
                  ) : (
                    <span className="text-amber-400 font-bold ml-1">✔ Converged</span>
                  )}
                </div>
              )}
            </div>

            {/* Viewport Control Instructions Overlay */}
            <div className="absolute bottom-3 right-3 px-2.5 py-1 bg-[#121622]/70 backdrop-blur-sm border border-[#232d40] rounded text-[11px] font-mono text-[#76869f] pointer-events-none">
              Left Drag: Orbit | Right Drag: Pan | Wheel: Dolly Zoom
            </div>
          </div>

          {/* BOTTOM MULTI-TRACK ANIMATION DOCK */}
          <div
            id="animation_timeline_dock"
            className="h-44 bg-[#12151d] border-t border-[#232938] flex flex-col shrink-0 z-20"
          >
            {/* Timeline Transport Bar */}
            <div className="flex items-center justify-between px-3 py-1.5 bg-[#161a24] border-b border-[#232938]">
              <div className="flex items-center gap-2">
                <button
                  id="btn_play_pause"
                  onClick={() => {
                    if (timelineRef.current) {
                      timelineRef.current.isPlaying = !timelineRef.current.isPlaying;
                      setIsPlaying(timelineRef.current.isPlaying);
                    }
                  }}
                  className="p-1.5 bg-amber-500 hover:bg-amber-400 text-black rounded-md font-bold transition-colors"
                >
                  {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                </button>

                <button
                  id="btn_rewind"
                  onClick={() => {
                    if (timelineRef.current) {
                      timelineRef.current.currentTime = 0;
                      setCurrentTime(0);
                    }
                  }}
                  className="p-1.5 bg-[#232c3f] hover:bg-[#2e3a52] text-[#d1d5db] rounded-md transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>

                <div className="font-mono text-xs text-amber-300 font-bold px-2 py-0.5 bg-[#0f1219] rounded border border-[#2b354b]">
                  {currentTime.toFixed(2)}s / {timelineDuration.toFixed(2)}s
                </div>
              </div>

              {/* Scrubber Range Slider */}
              <div className="flex-1 mx-4 flex items-center">
                <input
                  id="timeline_scrubber"
                  type="range"
                  min={0}
                  max={timelineDuration}
                  step={0.01}
                  value={currentTime}
                  onChange={(e) => {
                    const t = parseFloat(e.target.value);
                    if (timelineRef.current) {
                      timelineRef.current.currentTime = t;
                      setCurrentTime(t);
                    }
                  }}
                  className="w-full accent-amber-500 cursor-pointer"
                />
              </div>

              <div className="flex items-center gap-2 text-xs font-mono text-[#8b9bb4]">
                <span>30 FPS</span>
                <span className="text-emerald-400 font-bold">LIVE SYNC</span>
              </div>
            </div>

            {/* Animation Tracks Deck */}
            <div className="flex-1 overflow-y-auto p-2 space-y-1.5 font-mono text-xs">
              {timelineState?.tracks.map((track) => {
                const progressPct = (currentTime / timelineDuration) * 100;
                return (
                  <div
                    key={track.id}
                    className="flex items-center gap-2 bg-[#181d29] px-2 py-1 rounded border border-[#263147]"
                  >
                    <span className="w-48 text-[#a9b9d1] truncate font-sans text-xs">
                      {track.name}
                    </span>
                    <div className="flex-1 h-3 bg-[#0d1017] rounded-full relative overflow-hidden border border-[#232b3d]">
                      {/* Live Playhead Indicator */}
                      <div
                        className="absolute top-0 bottom-0 w-0.5 bg-amber-400 z-10"
                        style={{ left: `${progressPct}%` }}
                      />
                      {/* Keyframe diamonds */}
                      {track.keyframes.map((kf, kidx) => {
                        const kfPct = (kf.time / timelineDuration) * 100;
                        return (
                          <div
                            key={kidx}
                            title={`Keyframe: ${kf.time.toFixed(2)}s (${kf.value})`}
                            className="absolute top-0.5 w-2 h-2 bg-amber-400 rotate-45 -ml-1 shadow-sm"
                            style={{ left: `${kfPct}%` }}
                          />
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </main>

        {/* RIGHT PANEL: DCC Property Inspector & Lab */}
        <aside
          id="inspector_deck"
          className="w-80 bg-[#12151d] border-l border-[#232938] flex flex-col shrink-0 z-20"
        >
          {/* Tab Bar */}
          <div className="flex border-b border-[#232938] bg-[#161a24] overflow-x-auto">
            {(
              ['material', 'extrude', 'camera', 'lighting', 'compositor', 'transform'] as const
            ).map((tab) => (
              <button
                key={tab}
                id={`tab_${tab}`}
                onClick={() => setActiveInspectorTab(tab)}
                className={`px-3 py-2 text-xs font-semibold capitalize whitespace-nowrap transition-colors ${
                  activeInspectorTab === tab
                    ? 'text-amber-400 border-b-2 border-amber-500 bg-[#1e2433]'
                    : 'text-[#7e8ea6] hover:text-white'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          {/* Inspector Content */}
          <div className="flex-1 overflow-y-auto p-3 space-y-4 text-xs">
            {/* TAB: MATERIAL PBR */}
            {activeInspectorTab === 'material' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#c1cce0] uppercase tracking-wide">
                    Principled PBR Material
                  </span>
                  <Palette className="w-3.5 h-3.5 text-amber-400" />
                </div>

                {/* Material Presets Palette */}
                <div className="space-y-1.5">
                  <span className="text-[11px] text-[#7e8fa8]">Studio Presets:</span>
                  <div className="grid grid-cols-2 gap-1.5">
                    {[
                      { name: 'Gold Mirror', mat: Material.createGold() },
                      { name: 'Brushed Alum', mat: Material.createBrushedAluminum() },
                      { name: 'Pure Copper', mat: Material.createCopper() },
                      { name: 'Frosted Glass', mat: Material.createFrostedGlass() },
                      { name: 'Dark Obsidian', mat: Material.createObsidian() },
                      { name: 'Cyan Neon', mat: Material.createNeonEmission('#00E5FF', 3.0) }
                    ].map((preset, idx) => (
                      <button
                        key={idx}
                        onClick={() => {
                          updateSelectedNode((n) => {
                            n.materials = [preset.mat];
                          });
                        }}
                        className="px-2 py-1 bg-[#1a2130] hover:bg-[#252f44] border border-[#2b374e] rounded text-[11px] text-[#c0cde3] transition-colors"
                      >
                        {preset.name}
                      </button>
                    ))}
                  </div>
                </div>

                {selectedNode?.materials[0] && (
                  <div className="space-y-3 pt-2 border-t border-[#232938]">
                    {/* Base Color Picker */}
                    <div>
                      <div className="flex justify-between mb-1">
                        <span>Base Color:</span>
                        <span className="font-mono text-amber-300">
                          rgb({Math.round(selectedNode.materials[0].baseColor.r * 255)},{' '}
                          {Math.round(selectedNode.materials[0].baseColor.g * 255)},{' '}
                          {Math.round(selectedNode.materials[0].baseColor.b * 255)})
                        </span>
                      </div>
                      <input
                        type="color"
                        value={selectedNode.materials[0].baseColor.toHex()}
                        onChange={(e) => {
                          const val = e.target.value;
                          updateSelectedNode((n) => {
                            if (n.materials[0]) {
                              n.materials[0].baseColor.setFromHex(val);
                            }
                          });
                        }}
                        className="w-full h-7 bg-transparent cursor-pointer rounded border border-[#2d3850]"
                      />
                    </div>

                    {/* Metallic */}
                    <div>
                      <div className="flex justify-between mb-1">
                        <span>Metallic:</span>
                        <span className="font-mono text-amber-300">
                          {selectedNode.materials[0].metallic.toFixed(2)}
                        </span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={1}
                        step={0.01}
                        value={selectedNode.materials[0].metallic}
                        onChange={(e) => {
                          const val = parseFloat(e.target.value);
                          updateSelectedNode((n) => {
                            if (n.materials[0]) {
                              n.materials[0].metallic = val;
                            }
                          });
                        }}
                        className="w-full accent-amber-500"
                      />
                    </div>

                    {/* Roughness */}
                    <div>
                      <div className="flex justify-between mb-1">
                        <span>Roughness:</span>
                        <span className="font-mono text-amber-300">
                          {selectedNode.materials[0].roughness.toFixed(2)}
                        </span>
                      </div>
                      <input
                        type="range"
                        min={0.02}
                        max={1}
                        step={0.01}
                        value={selectedNode.materials[0].roughness}
                        onChange={(e) => {
                          const val = parseFloat(e.target.value);
                          updateSelectedNode((n) => {
                            if (n.materials[0]) {
                              n.materials[0].roughness = val;
                            }
                          });
                        }}
                        className="w-full accent-amber-500"
                      />
                    </div>

                    {/* Transmission (Glass) */}
                    <div>
                      <div className="flex justify-between mb-1">
                        <span>Transmission (Glass):</span>
                        <span className="font-mono text-amber-300">
                          {selectedNode.materials[0].transmission.toFixed(2)}
                        </span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={1}
                        step={0.01}
                        value={selectedNode.materials[0].transmission}
                        onChange={(e) => {
                          const val = parseFloat(e.target.value);
                          updateSelectedNode((n) => {
                            if (n.materials[0]) {
                              n.materials[0].transmission = val;
                            }
                          });
                        }}
                        className="w-full accent-amber-500"
                      />
                    </div>

                    {/* Clearcoat */}
                    <div>
                      <div className="flex justify-between mb-1">
                        <span>Clearcoat Polish:</span>
                        <span className="font-mono text-amber-300">
                          {selectedNode.materials[0].clearcoat.toFixed(2)}
                        </span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={1}
                        step={0.01}
                        value={selectedNode.materials[0].clearcoat}
                        onChange={(e) => {
                          const val = parseFloat(e.target.value);
                          updateSelectedNode((n) => {
                            if (n.materials[0]) {
                              n.materials[0].clearcoat = val;
                            }
                          });
                        }}
                        className="w-full accent-amber-500"
                      />
                    </div>

                    {/* Emission Intensity */}
                    <div>
                      <div className="flex justify-between mb-1">
                        <span>Emission Radiance:</span>
                        <span className="font-mono text-amber-300">
                          {selectedNode.materials[0].emissionIntensity.toFixed(1)}
                        </span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={10}
                        step={0.1}
                        value={selectedNode.materials[0].emissionIntensity}
                        onChange={(e) => {
                          const val = parseFloat(e.target.value);
                          updateSelectedNode((n) => {
                            if (n.materials[0]) {
                              n.materials[0].emissionIntensity = val;
                            }
                          });
                        }}
                        className="w-full accent-amber-500"
                      />
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* TAB: VECTOR EXTRUSION & TYPOGRAPHY LAB */}
            {activeInspectorTab === 'extrude' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#c1cce0] uppercase tracking-wide">
                    Vector & 3D Extrusion
                  </span>
                  <Layers className="w-3.5 h-3.5 text-amber-400" />
                </div>

                {selectedNode?.type === NodeType.VECTOR_LAYER ? (
                  <div className="space-y-3">
                    {/* SVG Path Code Editor */}
                    <div>
                      <span className="text-[11px] text-[#7e8fa8]">SVG Path Data (d=):</span>
                      <textarea
                        value={selectedNode.svgPathString}
                        onChange={(e) => {
                          const val = e.target.value;
                          updateSelectedNode((n) => {
                            n.svgPathString = val;
                            n.rebuildVectorMesh();
                          });
                        }}
                        rows={3}
                        className="w-full bg-[#0d1017] p-1.5 font-mono text-[10px] text-[#c1cce0] border border-[#263147] rounded mt-1"
                      />
                    </div>

                    {/* Extrude Depth */}
                    <div>
                      <div className="flex justify-between mb-1">
                        <span>Extrude Depth:</span>
                        <span className="font-mono text-amber-300">
                          {(selectedNode.extrudeOptions.depth ?? 0.35).toFixed(2)}
                        </span>
                      </div>
                      <input
                        type="range"
                        min={0.01}
                        max={2.0}
                        step={0.02}
                        value={selectedNode.extrudeOptions.depth ?? 0.35}
                        onChange={(e) => {
                          const val = parseFloat(e.target.value);
                          updateSelectedNode((n) => {
                            n.extrudeOptions.depth = val;
                            n.rebuildVectorMesh();
                          });
                        }}
                        className="w-full accent-amber-500"
                      />
                    </div>

                    {/* Bevel Thickness */}
                    <div>
                      <div className="flex justify-between mb-1">
                        <span>Bevel Thickness:</span>
                        <span className="font-mono text-amber-300">
                          {(selectedNode.extrudeOptions.bevelThickness ?? 0.04).toFixed(3)}
                        </span>
                      </div>
                      <input
                        type="range"
                        min={0.0}
                        max={0.15}
                        step={0.005}
                        value={selectedNode.extrudeOptions.bevelThickness ?? 0.04}
                        onChange={(e) => {
                          const val = parseFloat(e.target.value);
                          updateSelectedNode((n) => {
                            n.extrudeOptions.bevelThickness = val;
                            n.rebuildVectorMesh();
                          });
                        }}
                        className="w-full accent-amber-500"
                      />
                    </div>

                    {/* Bevel Segments */}
                    <div>
                      <div className="flex justify-between mb-1">
                        <span>Bevel Segments:</span>
                        <span className="font-mono text-amber-300">
                          {selectedNode.extrudeOptions.bevelSegments ?? 3}
                        </span>
                      </div>
                      <input
                        type="range"
                        min={1}
                        max={8}
                        step={1}
                        value={selectedNode.extrudeOptions.bevelSegments ?? 3}
                        onChange={(e) => {
                          const val = parseInt(e.target.value);
                          updateSelectedNode((n) => {
                            n.extrudeOptions.bevelSegments = val;
                            n.rebuildVectorMesh();
                          });
                        }}
                        className="w-full accent-amber-500"
                      />
                    </div>
                  </div>
                ) : selectedNode?.type === NodeType.TEXT_3D ? (
                  <div className="space-y-3">
                    {/* Text Input */}
                    <div>
                      <span className="text-[11px] text-[#7e8fa8]">Text Content:</span>
                      <input
                        type="text"
                        value={selectedNode.textString}
                        onChange={(e) => {
                          const val = e.target.value;
                          updateSelectedNode((n) => {
                            n.textString = val;
                            n.rebuildVectorMesh();
                          });
                        }}
                        className="w-full bg-[#0d1017] p-2 font-mono text-xs text-white border border-[#263147] rounded mt-1"
                      />
                    </div>

                    {/* Font Size */}
                    <div>
                      <div className="flex justify-between mb-1">
                        <span>Font Scale:</span>
                        <span className="font-mono text-amber-300">
                          {(selectedNode.textOptions.fontSize ?? 1.0).toFixed(2)}
                        </span>
                      </div>
                      <input
                        type="range"
                        min={0.2}
                        max={2.0}
                        step={0.05}
                        value={selectedNode.textOptions.fontSize ?? 1.0}
                        onChange={(e) => {
                          const val = parseFloat(e.target.value);
                          updateSelectedNode((n) => {
                            n.textOptions.fontSize = val;
                            n.rebuildVectorMesh();
                          });
                        }}
                        className="w-full accent-amber-500"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="p-3 bg-[#171b26] border border-[#242b3b] rounded text-center text-[#7888a2]">
                    Select a 2D Vector Layer or 3D Text node to edit parametric extrusion.
                  </div>
                )}
              </div>
            )}

            {/* TAB: CINEMATIC CAMERA & OPTICS */}
            {activeInspectorTab === 'camera' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#c1cce0] uppercase tracking-wide">
                    Cinematic Optics Camera
                  </span>
                  <CameraIcon className="w-3.5 h-3.5 text-amber-400" />
                </div>

                {/* Focal Length Preset Pills */}
                <div className="space-y-1.5">
                  <span className="text-[11px] text-[#7e8fa8]">Prime Lens Focal Length:</span>
                  <div className="grid grid-cols-4 gap-1">
                    {[24, 35, 50, 85].map((mm) => (
                      <button
                        key={mm}
                        onClick={() => {
                          if (sceneRef.current) {
                            sceneRef.current.activeCamera.setFocalLength(mm);
                            triggerUpdate();
                          }
                        }}
                        className={`py-1 rounded text-[11px] font-mono border transition-colors ${
                          Math.round(sceneState?.activeCamera?.focalLength ?? 50) === mm
                            ? 'bg-amber-500 text-black font-bold border-amber-400'
                            : 'bg-[#181d29] text-[#9aa7bc] border-[#2a3449] hover:text-white'
                        }`}
                      >
                        {mm}mm
                      </button>
                    ))}
                  </div>
                </div>

                {/* F-Stop Aperture */}
                <div>
                  <div className="flex justify-between mb-1">
                    <span>Aperture F-Stop (DoF):</span>
                    <span className="font-mono text-amber-300">
                      f/{(sceneState?.activeCamera?.fStop ?? 2.8).toFixed(1)}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={1.2}
                    max={16.0}
                    step={0.2}
                    value={sceneState?.activeCamera?.fStop ?? 2.8}
                    onChange={(e) => {
                      if (sceneRef.current) {
                        sceneRef.current.activeCamera.fStop = parseFloat(e.target.value);
                        triggerUpdate();
                      }
                    }}
                    className="w-full accent-amber-500"
                  />
                </div>

                {/* Focus Distance */}
                <div>
                  <div className="flex justify-between mb-1">
                    <span>Focus Distance:</span>
                    <span className="font-mono text-amber-300">
                      {(sceneState?.activeCamera?.focusDistance ?? 4.5).toFixed(2)} m
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0.5}
                    max={15.0}
                    step={0.1}
                    value={sceneState?.activeCamera?.focusDistance ?? 4.5}
                    onChange={(e) => {
                      if (sceneRef.current) {
                        sceneRef.current.activeCamera.focusDistance = parseFloat(e.target.value);
                        triggerUpdate();
                      }
                    }}
                    className="w-full accent-amber-500"
                  />
                </div>

                {/* Handheld Camera Shake Toggle */}
                <div className="pt-2 border-t border-[#232938] space-y-2">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={sceneState?.activeCamera?.shakeEnabled ?? false}
                      onChange={(e) => {
                        if (sceneRef.current) {
                          sceneRef.current.activeCamera.shakeEnabled = e.target.checked;
                          triggerUpdate();
                        }
                      }}
                      className="accent-amber-500"
                    />
                    <span className="font-semibold text-[#c1cce0]">Handheld Camera Shake</span>
                  </label>

                  {sceneState?.activeCamera?.shakeEnabled && (
                    <div>
                      <div className="flex justify-between mb-1">
                        <span>Shake Intensity:</span>
                        <span className="font-mono text-amber-300">
                          {(sceneState?.activeCamera?.shakeIntensity ?? 0.05).toFixed(2)}
                        </span>
                      </div>
                      <input
                        type="range"
                        min={0.01}
                        max={0.2}
                        step={0.01}
                        value={sceneState?.activeCamera?.shakeIntensity ?? 0.05}
                        onChange={(e) => {
                          if (sceneRef.current) {
                            sceneRef.current.activeCamera.shakeIntensity = parseFloat(
                              e.target.value
                            );
                            triggerUpdate();
                          }
                        }}
                        className="w-full accent-amber-500"
                      />
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* TAB: LIGHTING STUDIO */}
            {activeInspectorTab === 'lighting' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#c1cce0] uppercase tracking-wide">
                    Studio Lighting Deck
                  </span>
                  <Sun className="w-3.5 h-3.5 text-amber-400" />
                </div>

                {sceneState?.getAllLights().map((light) => (
                  <div
                    key={light.id}
                    className="p-2.5 bg-[#171b26] border border-[#263147] rounded-md space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-amber-300">{light.name}</span>
                      <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 bg-[#252f44] rounded text-[#8da0bd]">
                        {light.type}
                      </span>
                    </div>

                    {/* Light Intensity */}
                    <div>
                      <div className="flex justify-between mb-1">
                        <span>Intensity:</span>
                        <span className="font-mono text-amber-300">{light.intensity.toFixed(2)}</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={10}
                        step={0.1}
                        value={light.intensity}
                        onChange={(e) => {
                          light.intensity = parseFloat(e.target.value);
                          triggerUpdate();
                        }}
                        className="w-full accent-amber-500"
                      />
                    </div>

                    {/* Light Color */}
                    <div>
                      <div className="flex justify-between mb-1">
                        <span>Color:</span>
                      </div>
                      <input
                        type="color"
                        value={light.color.toHex()}
                        onChange={(e) => {
                          light.color.setFromHex(e.target.value);
                          triggerUpdate();
                        }}
                        className="w-full h-6 bg-transparent cursor-pointer rounded border border-[#2d3850]"
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* TAB: COMPOSITOR POST DECK */}
            {activeInspectorTab === 'compositor' && compositorState && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#c1cce0] uppercase tracking-wide">
                    Compositor & Color Grading
                  </span>
                  <Sliders className="w-3.5 h-3.5 text-amber-400" />
                </div>

                {/* Exposure */}
                <div>
                  <div className="flex justify-between mb-1">
                    <span>Exposure (EV):</span>
                    <span className="font-mono text-amber-300">
                      {compositorState.settings.exposure.toFixed(2)}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={-2.0}
                    max={2.0}
                    step={0.05}
                    value={compositorState.settings.exposure}
                    onChange={(e) => {
                      if (compositorRef.current) {
                        compositorRef.current.settings.exposure = parseFloat(e.target.value);
                        triggerUpdate();
                      }
                    }}
                    className="w-full accent-amber-500"
                  />
                </div>

                {/* Contrast */}
                <div>
                  <div className="flex justify-between mb-1">
                    <span>Contrast:</span>
                    <span className="font-mono text-amber-300">
                      {compositorState.settings.contrast.toFixed(2)}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0.5}
                    max={1.8}
                    step={0.05}
                    value={compositorState.settings.contrast}
                    onChange={(e) => {
                      if (compositorRef.current) {
                        compositorRef.current.settings.contrast = parseFloat(e.target.value);
                        triggerUpdate();
                      }
                    }}
                    className="w-full accent-amber-500"
                  />
                </div>

                {/* Cinematic Bloom */}
                <div>
                  <div className="flex justify-between mb-1">
                    <span>Cinematic Bloom Glow:</span>
                    <span className="font-mono text-amber-300">
                      {compositorState.settings.bloomIntensity.toFixed(2)}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={1.5}
                    step={0.05}
                    value={compositorState.settings.bloomIntensity}
                    onChange={(e) => {
                      if (compositorRef.current) {
                        compositorRef.current.settings.bloomIntensity = parseFloat(e.target.value);
                        triggerUpdate();
                      }
                    }}
                    className="w-full accent-amber-500"
                  />
                </div>

                {/* Vignette */}
                <div>
                  <div className="flex justify-between mb-1">
                    <span>Lens Vignette:</span>
                    <span className="font-mono text-amber-300">
                      {compositorState.settings.vignetteStrength.toFixed(2)}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={0.8}
                    step={0.05}
                    value={compositorState.settings.vignetteStrength}
                    onChange={(e) => {
                      if (compositorRef.current) {
                        compositorRef.current.settings.vignetteStrength = parseFloat(
                          e.target.value
                        );
                        triggerUpdate();
                      }
                    }}
                    className="w-full accent-amber-500"
                  />
                </div>

                {/* Film Grain */}
                <div>
                  <div className="flex justify-between mb-1">
                    <span>Analog Film Grain:</span>
                    <span className="font-mono text-amber-300">
                      {compositorState.settings.filmGrain.toFixed(3)}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={0.1}
                    step={0.005}
                    value={compositorState.settings.filmGrain}
                    onChange={(e) => {
                      if (compositorRef.current) {
                        compositorRef.current.settings.filmGrain = parseFloat(e.target.value);
                        triggerUpdate();
                      }
                    }}
                    className="w-full accent-amber-500"
                  />
                </div>
              </div>
            )}

            {/* TAB: TRANSFORM */}
            {activeInspectorTab === 'transform' && selectedNode && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#c1cce0] uppercase tracking-wide">
                    3D Transform & Gimbal
                  </span>
                  <Compass className="w-3.5 h-3.5 text-amber-400" />
                </div>

                {/* Position */}
                <div className="space-y-1.5">
                  <span className="text-[11px] text-[#7e8fa8]">Position (X, Y, Z):</span>
                  <div className="grid grid-cols-3 gap-1 font-mono">
                    <input
                      type="number"
                      step={0.1}
                      value={parseFloat(selectedNode.transform.position.x.toFixed(2))}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value);
                        updateSelectedNode((n) => {
                          n.transform.position.x = val;
                          n.transform.isDirty = true;
                        });
                      }}
                      className="bg-[#0d1017] p-1.5 text-center text-xs border border-[#263147] rounded"
                    />
                    <input
                      type="number"
                      step={0.1}
                      value={parseFloat(selectedNode.transform.position.y.toFixed(2))}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value);
                        updateSelectedNode((n) => {
                          n.transform.position.y = val;
                          n.transform.isDirty = true;
                        });
                      }}
                      className="bg-[#0d1017] p-1.5 text-center text-xs border border-[#263147] rounded"
                    />
                    <input
                      type="number"
                      step={0.1}
                      value={parseFloat(selectedNode.transform.position.z.toFixed(2))}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value);
                        updateSelectedNode((n) => {
                          n.transform.position.z = val;
                          n.transform.isDirty = true;
                        });
                      }}
                      className="bg-[#0d1017] p-1.5 text-center text-xs border border-[#263147] rounded"
                    />
                  </div>
                </div>

                {/* Rotation */}
                <div className="space-y-1.5">
                  <span className="text-[11px] text-[#7e8fa8]">Rotation Degrees (X, Y, Z):</span>
                  <div className="grid grid-cols-3 gap-1 font-mono">
                    <input
                      type="number"
                      step={5}
                      value={Math.round(selectedNode.transform.rotation.x)}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value);
                        updateSelectedNode((n) => {
                          n.transform.rotation.x = val;
                          n.transform.isDirty = true;
                        });
                      }}
                      className="bg-[#0d1017] p-1.5 text-center text-xs border border-[#263147] rounded"
                    />
                    <input
                      type="number"
                      step={5}
                      value={Math.round(selectedNode.transform.rotation.y)}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value);
                        updateSelectedNode((n) => {
                          n.transform.rotation.y = val;
                          n.transform.isDirty = true;
                        });
                      }}
                      className="bg-[#0d1017] p-1.5 text-center text-xs border border-[#263147] rounded"
                    />
                    <input
                      type="number"
                      step={5}
                      value={Math.round(selectedNode.transform.rotation.z)}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value);
                        updateSelectedNode((n) => {
                          n.transform.rotation.z = val;
                          n.transform.isDirty = true;
                        });
                      }}
                      className="bg-[#0d1017] p-1.5 text-center text-xs border border-[#263147] rounded"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        </aside>
      </div>
    </div>
  );
}
