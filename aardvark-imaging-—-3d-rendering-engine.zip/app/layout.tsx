import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Aardvark Imaging — 3D Rendering Engine',
  description: 'Professional-grade 3D rendering and compositing engine unifying 2D vector graphics, 2.5D layers, 3D meshes, PBR shaders, ray/path tracing, and cinematic camera pipelines.',
  openGraph: {
    title: 'Aardvark Imaging — 3D Rendering Engine',
    description: 'Professional-grade 3D rendering and compositing engine unifying 2D vector graphics, 2.5D layers, 3D meshes, PBR shaders, ray/path tracing, and cinematic camera pipelines.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Aardvark Imaging — 3D Rendering Engine',
    description: 'Professional-grade 3D rendering and compositing engine unifying 2D vector graphics, 2.5D layers, 3D meshes, PBR shaders, ray/path tracing, and cinematic camera pipelines.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
