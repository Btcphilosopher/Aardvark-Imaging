import { Vec3, Color, Mat4 } from '../core/math';
import { Transform } from '../core/transform';

export enum LightType {
  DIRECTIONAL = 'DIRECTIONAL',
  POINT = 'POINT',
  SPOT = 'SPOT',
  AREA = 'AREA',
  ENVIRONMENT = 'ENVIRONMENT'
}

export class Light {
  public id: string;
  public name: string;
  public type: LightType;
  public transform: Transform;

  public color: Color;
  public intensity: number; // in Lux / Candela / Lumens

  // Point & Spot Light properties
  public radius: number;
  public decay: number; // 2 for physical inverse square

  // Spot Light properties
  public innerConeAngle: number; // in degrees
  public outerConeAngle: number; // in degrees
  public penumbra: number;

  // Area Light properties
  public areaWidth: number;
  public areaHeight: number;

  // Shadows
  public castShadows: boolean;
  public shadowMapResolution: number;
  public shadowBias: number;
  public shadowRadius: number; // PCF blur radius

  // Shadow Matrix
  public shadowViewMatrix: Mat4;
  public shadowProjectionMatrix: Mat4;
  public shadowViewProjectionMatrix: Mat4;

  constructor(type: LightType = LightType.DIRECTIONAL) {
    this.id = 'light_' + Math.random().toString(36).substring(2, 9);
    this.name = 'Light';
    this.type = type;
    this.transform = new Transform();

    this.color = new Color(1, 0.98, 0.92); // Warm white default
    this.intensity = 1.0;

    this.radius = 15.0;
    this.decay = 2.0;

    this.innerConeAngle = 25.0;
    this.outerConeAngle = 45.0;
    this.penumbra = 0.5;

    this.areaWidth = 1.0;
    this.areaHeight = 1.0;

    this.castShadows = true;
    this.shadowMapResolution = 1024;
    this.shadowBias = 0.0005;
    this.shadowRadius = 2.0;

    this.shadowViewMatrix = new Mat4();
    this.shadowProjectionMatrix = new Mat4();
    this.shadowViewProjectionMatrix = new Mat4();

    if (type === LightType.DIRECTIONAL) {
      this.name = 'Key Directional Light';
      this.transform.setPosition(5, 8, 5);
      this.intensity = 1.8;
    } else if (type === LightType.POINT) {
      this.name = 'Point Light';
      this.transform.setPosition(0, 3, 2);
      this.intensity = 2.5;
    } else if (type === LightType.SPOT) {
      this.name = 'Spotlight';
      this.transform.setPosition(3, 6, 3);
      this.intensity = 3.0;
    } else if (type === LightType.ENVIRONMENT) {
      this.name = 'Sky Environment Light';
      this.intensity = 0.6;
      this.castShadows = false;
    }

    this.updateShadowMatrices();
  }

  updateShadowMatrices(): void {
    if (!this.castShadows) return;

    this.transform.updateWorldMatrix();
    const pos = this.transform.getWorldPosition();
    const target = new Vec3(0, 0, 0);
    const up = new Vec3(0, 1, 0);

    if (this.type === LightType.DIRECTIONAL) {
      this.shadowViewMatrix = Mat4.lookAt(pos, target, up);
      const orthoBound = 8.0;
      this.shadowProjectionMatrix = Mat4.orthographic(
        -orthoBound, orthoBound,
        -orthoBound, orthoBound,
        0.5, 30.0
      );
    } else if (this.type === LightType.SPOT) {
      this.shadowViewMatrix = Mat4.lookAt(pos, target, up);
      const fovRad = (this.outerConeAngle * 2 * Math.PI) / 180;
      this.shadowProjectionMatrix = Mat4.perspective(fovRad, 1.0, 0.5, this.radius);
    }

    this.shadowViewProjectionMatrix.multiplyMatrices(
      this.shadowProjectionMatrix,
      this.shadowViewMatrix
    );
  }
}
