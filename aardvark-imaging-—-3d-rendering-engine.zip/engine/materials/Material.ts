import { Color } from '../core/math';
import { Texture } from '../textures/Texture';

export enum AlphaMode {
  OPAQUE = 'OPAQUE',
  MASK = 'MASK',
  BLEND = 'BLEND'
}

export enum ShadingModel {
  PBR_PRINCIPLED = 'PBR_PRINCIPLED',
  UNLIT = 'UNLIT',
  PHONG_BLINN = 'PHONG_BLINN',
  TOON = 'TOON',
  MATCAP = 'MATCAP',
  WIREFRAME = 'WIREFRAME'
}

export interface MaterialParameters {
  name?: string;
  shadingModel?: ShadingModel;
  baseColor?: Color;
  baseColorMap?: Texture | null;
  metallic?: number;
  metallicMap?: Texture | null;
  roughness?: number;
  roughnessMap?: Texture | null;
  specular?: number;
  normalMap?: Texture | null;
  normalScale?: number;
  displacementMap?: Texture | null;
  displacementScale?: number;
  emission?: Color;
  emissionIntensity?: number;
  emissionMap?: Texture | null;
  opacity?: number;
  alphaCutoff?: number;
  alphaMode?: AlphaMode;
  transmission?: number;
  ior?: number;
  clearcoat?: number;
  clearcoatRoughness?: number;
  sheen?: number;
  sheenTint?: Color;
  ambientOcclusionMap?: Texture | null;
  aoStrength?: number;
  wireframe?: boolean;
  doubleSided?: boolean;
}

export class Material {
  public id: string;
  public name: string;
  public shadingModel: ShadingModel;

  public baseColor: Color;
  public baseColorMap: Texture | null;

  public metallic: number;
  public metallicMap: Texture | null;

  public roughness: number;
  public roughnessMap: Texture | null;

  public specular: number;

  public normalMap: Texture | null;
  public normalScale: number;

  public displacementMap: Texture | null;
  public displacementScale: number;

  public emission: Color;
  public emissionIntensity: number;
  public emissionMap: Texture | null;

  public opacity: number;
  public alphaCutoff: number;
  public alphaMode: AlphaMode;

  public transmission: number; // For glass, gems, water
  public ior: number;          // Index of Refraction (1.0 = air, 1.33 = water, 1.5 = glass, 2.4 = diamond)

  public clearcoat: number;
  public clearcoatRoughness: number;

  public sheen: number;
  public sheenTint: Color;

  public ambientOcclusionMap: Texture | null;
  public aoStrength: number;

  public wireframe: boolean;
  public doubleSided: boolean;

  public isDirty: boolean = true;

  constructor(params: MaterialParameters = {}) {
    this.id = 'mat_' + Math.random().toString(36).substring(2, 9);
    this.name = params.name || 'PBR Material';
    this.shadingModel = params.shadingModel || ShadingModel.PBR_PRINCIPLED;

    this.baseColor = params.baseColor ? params.baseColor.clone() : new Color(0.85, 0.85, 0.88);
    this.baseColorMap = params.baseColorMap || null;

    this.metallic = params.metallic ?? 0.0;
    this.metallicMap = params.metallicMap || null;

    this.roughness = params.roughness ?? 0.35;
    this.roughnessMap = params.roughnessMap || null;

    this.specular = params.specular ?? 0.5;

    this.normalMap = params.normalMap || null;
    this.normalScale = params.normalScale ?? 1.0;

    this.displacementMap = params.displacementMap || null;
    this.displacementScale = params.displacementScale ?? 0.05;

    this.emission = params.emission ? params.emission.clone() : new Color(0, 0, 0);
    this.emissionIntensity = params.emissionIntensity ?? 0.0;
    this.emissionMap = params.emissionMap || null;

    this.opacity = params.opacity ?? 1.0;
    this.alphaCutoff = params.alphaCutoff ?? 0.5;
    this.alphaMode = params.alphaMode || AlphaMode.OPAQUE;

    this.transmission = params.transmission ?? 0.0;
    this.ior = params.ior ?? 1.5;

    this.clearcoat = params.clearcoat ?? 0.0;
    this.clearcoatRoughness = params.clearcoatRoughness ?? 0.1;

    this.sheen = params.sheen ?? 0.0;
    this.sheenTint = params.sheenTint ? params.sheenTint.clone() : new Color(1, 1, 1);

    this.ambientOcclusionMap = params.ambientOcclusionMap || null;
    this.aoStrength = params.aoStrength ?? 1.0;

    this.wireframe = params.wireframe ?? false;
    this.doubleSided = params.doubleSided ?? false;
  }

  clone(): Material {
    const m = new Material({
      name: this.name + ' (Copy)',
      shadingModel: this.shadingModel,
      baseColor: this.baseColor.clone(),
      baseColorMap: this.baseColorMap,
      metallic: this.metallic,
      metallicMap: this.metallicMap,
      roughness: this.roughness,
      roughnessMap: this.roughnessMap,
      specular: this.specular,
      normalMap: this.normalMap,
      normalScale: this.normalScale,
      displacementMap: this.displacementMap,
      displacementScale: this.displacementScale,
      emission: this.emission.clone(),
      emissionIntensity: this.emissionIntensity,
      emissionMap: this.emissionMap,
      opacity: this.opacity,
      alphaCutoff: this.alphaCutoff,
      alphaMode: this.alphaMode,
      transmission: this.transmission,
      ior: this.ior,
      clearcoat: this.clearcoat,
      clearcoatRoughness: this.clearcoatRoughness,
      sheen: this.sheen,
      sheenTint: this.sheenTint.clone(),
      ambientOcclusionMap: this.ambientOcclusionMap,
      aoStrength: this.aoStrength,
      wireframe: this.wireframe,
      doubleSided: this.doubleSided
    });
    return m;
  }

  // Presets
  static createGold(): Material {
    return new Material({
      name: 'Polished Gold',
      baseColor: new Color(1.0, 0.82, 0.35),
      metallic: 0.98,
      roughness: 0.15,
      clearcoat: 0.2
    });
  }

  static createBrushedAluminum(): Material {
    return new Material({
      name: 'Brushed Aluminum',
      baseColor: new Color(0.91, 0.92, 0.94),
      metallic: 0.92,
      roughness: 0.38,
      clearcoat: 0.1
    });
  }

  static createFrostedGlass(): Material {
    return new Material({
      name: 'Frosted Glass',
      baseColor: new Color(0.95, 0.98, 1.0),
      metallic: 0.0,
      roughness: 0.18,
      transmission: 0.92,
      opacity: 0.4,
      ior: 1.52,
      alphaMode: AlphaMode.BLEND,
      doubleSided: true
    });
  }

  static createCarPaint(colorHex: string = '#E53935'): Material {
    const col = new Color().setHex(colorHex);
    return new Material({
      name: 'Car Paint',
      baseColor: col,
      metallic: 0.4,
      roughness: 0.22,
      clearcoat: 0.95,
      clearcoatRoughness: 0.05
    });
  }

  static createNeonEmission(colorHex: string = '#00E5FF', intensity: number = 3.5): Material {
    const col = new Color().setHex(colorHex);
    return new Material({
      name: 'Neon Luminescence',
      baseColor: col,
      metallic: 0.1,
      roughness: 0.2,
      emission: col,
      emissionIntensity: intensity
    });
  }

  static createObsidian(): Material {
    return new Material({
      name: 'Black Obsidian',
      baseColor: new Color(0.04, 0.04, 0.05),
      metallic: 0.1,
      roughness: 0.08,
      clearcoat: 0.9
    });
  }

  static createCopper(): Material {
    return new Material({
      name: 'Satin Copper',
      baseColor: new Color(0.95, 0.64, 0.54),
      metallic: 0.95,
      roughness: 0.25
    });
  }

  static createHologram(): Material {
    return new Material({
      name: 'Iridescent Hologram',
      baseColor: new Color(0.2, 0.8, 1.0),
      metallic: 0.8,
      roughness: 0.1,
      opacity: 0.65,
      transmission: 0.6,
      emission: new Color(0.1, 0.5, 0.8),
      emissionIntensity: 1.2,
      alphaMode: AlphaMode.BLEND,
      doubleSided: true
    });
  }
}
