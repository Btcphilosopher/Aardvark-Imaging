import { Vec3, Quat, Mat4 } from './math';

export class Transform {
  public position: Vec3;
  public rotation: Vec3; // Euler angles in degrees
  public quaternion: Quat;
  public scale: Vec3;
  public pivot: Vec3;

  public localMatrix: Mat4;
  public worldMatrix: Mat4;
  public normalMatrix: Mat4;

  public isDirty: boolean = true;
  private useQuaternionDirect: boolean = false;

  constructor() {
    this.position = new Vec3(0, 0, 0);
    this.rotation = new Vec3(0, 0, 0); // deg
    this.quaternion = new Quat();
    this.scale = new Vec3(1, 1, 1);
    this.pivot = new Vec3(0, 0, 0);

    this.localMatrix = new Mat4();
    this.worldMatrix = new Mat4();
    this.normalMatrix = new Mat4();
  }

  clone(): Transform {
    const t = new Transform();
    t.position.copy(this.position);
    t.rotation.copy(this.rotation);
    t.quaternion.copy(this.quaternion);
    t.scale.copy(this.scale);
    t.pivot.copy(this.pivot);
    t.localMatrix.copy(this.localMatrix);
    t.worldMatrix.copy(this.worldMatrix);
    t.normalMatrix.copy(this.normalMatrix);
    t.isDirty = true;
    return t;
  }

  setPosition(x: number, y: number, z: number): this {
    this.position.set(x, y, z);
    this.isDirty = true;
    return this;
  }

  setRotation(xDeg: number, yDeg: number, zDeg: number): this {
    this.rotation.set(xDeg, yDeg, zDeg);
    const rx = (xDeg * Math.PI) / 180;
    const ry = (yDeg * Math.PI) / 180;
    const rz = (zDeg * Math.PI) / 180;
    this.quaternion.setFromEuler(rx, ry, rz, 'XYZ');
    this.useQuaternionDirect = false;
    this.isDirty = true;
    return this;
  }

  setQuaternion(q: Quat): this {
    this.quaternion.copy(q);
    const euler = q.toEuler();
    this.rotation.set(
      (euler.x * 180) / Math.PI,
      (euler.y * 180) / Math.PI,
      (euler.z * 180) / Math.PI
    );
    this.useQuaternionDirect = true;
    this.isDirty = true;
    return this;
  }

  setScale(x: number, y: number, z: number): this {
    this.scale.set(x, y, z);
    this.isDirty = true;
    return this;
  }

  setPivot(x: number, y: number, z: number): this {
    this.pivot.set(x, y, z);
    this.isDirty = true;
    return this;
  }

  updateLocalMatrix(): void {
    if (!this.useQuaternionDirect) {
      const rx = (this.rotation.x * Math.PI) / 180;
      const ry = (this.rotation.y * Math.PI) / 180;
      const rz = (this.rotation.z * Math.PI) / 180;
      this.quaternion.setFromEuler(rx, ry, rz, 'XYZ');
    }
    this.localMatrix.compose(this.position, this.quaternion, this.scale, this.pivot);
  }

  updateWorldMatrix(parentWorldMatrix?: Mat4): void {
    this.updateLocalMatrix();
    if (parentWorldMatrix) {
      this.worldMatrix.multiplyMatrices(parentWorldMatrix, this.localMatrix);
    } else {
      this.worldMatrix.copy(this.localMatrix);
    }

    // Normal matrix = (worldMatrix^-1)^T
    this.normalMatrix.copy(this.worldMatrix).invert().transpose();
    this.isDirty = false;
  }

  getWorldPosition(): Vec3 {
    const e = this.worldMatrix.elements;
    return new Vec3(e[12], e[13], e[14]);
  }
}
