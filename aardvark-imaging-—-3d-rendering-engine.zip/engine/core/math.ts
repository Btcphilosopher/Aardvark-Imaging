/**
 * Aardvark Imaging — 3D Rendering Engine Math Core
 * High-performance vector, matrix, quaternion, ray, and bounding volume operations.
 */

export class Vec2 {
  constructor(public x: number = 0, public y: number = 0) {}

  set(x: number, y: number): this {
    this.x = x;
    this.y = y;
    return this;
  }

  clone(): Vec2 {
    return new Vec2(this.x, this.y);
  }

  copy(v: Vec2): this {
    this.x = v.x;
    this.y = v.y;
    return this;
  }

  add(v: Vec2): this {
    this.x += v.x;
    this.y += v.y;
    return this;
  }

  sub(v: Vec2): this {
    this.x -= v.x;
    this.y -= v.y;
    return this;
  }

  scale(s: number): this {
    this.x *= s;
    this.y *= s;
    return this;
  }

  dot(v: Vec2): number {
    return this.x * v.x + this.y * v.y;
  }

  lengthSq(): number {
    return this.x * this.x + this.y * this.y;
  }

  length(): number {
    return Math.sqrt(this.lengthSq());
  }

  normalize(): this {
    const len = this.length();
    if (len > 0.00001) {
      this.x /= len;
      this.y /= len;
    }
    return this;
  }

  distanceTo(v: Vec2): number {
    const dx = this.x - v.x;
    const dy = this.y - v.y;
    return Math.sqrt(dx * dx + dy * dy);
  }

  lerp(v: Vec2, t: number): this {
    this.x += (v.x - this.x) * t;
    this.y += (v.y - this.y) * t;
    return this;
  }
}

export class Vec3 {
  constructor(public x: number = 0, public y: number = 0, public z: number = 0) {}

  set(x: number, y: number, z: number): this {
    this.x = x;
    this.y = y;
    this.z = z;
    return this;
  }

  clone(): Vec3 {
    return new Vec3(this.x, this.y, this.z);
  }

  copy(v: Vec3): this {
    this.x = v.x;
    this.y = v.y;
    this.z = v.z;
    return this;
  }

  add(v: Vec3): this {
    this.x += v.x;
    this.y += v.y;
    this.z += v.z;
    return this;
  }

  static add(a: Vec3, b: Vec3): Vec3 {
    return new Vec3(a.x + b.x, a.y + b.y, a.z + b.z);
  }

  sub(v: Vec3): this {
    this.x -= v.x;
    this.y -= v.y;
    this.z -= v.z;
    return this;
  }

  static sub(a: Vec3, b: Vec3): Vec3 {
    return new Vec3(a.x - b.x, a.y - b.y, a.z - b.z);
  }

  multiply(v: Vec3): this {
    this.x *= v.x;
    this.y *= v.y;
    this.z *= v.z;
    return this;
  }

  scale(s: number): this {
    this.x *= s;
    this.y *= s;
    this.z *= s;
    return this;
  }

  static scale(v: Vec3, s: number): Vec3 {
    return new Vec3(v.x * s, v.y * s, v.z * s);
  }

  dot(v: Vec3): number {
    return this.x * v.x + this.y * v.y + this.z * v.z;
  }

  cross(v: Vec3): this {
    const x = this.y * v.z - this.z * v.y;
    const y = this.z * v.x - this.x * v.z;
    const z = this.x * v.y - this.y * v.x;
    this.x = x;
    this.y = y;
    this.z = z;
    return this;
  }

  static cross(a: Vec3, b: Vec3): Vec3 {
    return new Vec3(
      a.y * b.z - a.z * b.y,
      a.z * b.x - a.x * b.z,
      a.x * b.y - a.y * b.x
    );
  }

  lengthSq(): number {
    return this.x * this.x + this.y * this.y + this.z * this.z;
  }

  length(): number {
    return Math.sqrt(this.lengthSq());
  }

  normalize(): this {
    const len = this.length();
    if (len > 0.000001) {
      this.x /= len;
      this.y /= len;
      this.z /= len;
    }
    return this;
  }

  distanceTo(v: Vec3): number {
    const dx = this.x - v.x;
    const dy = this.y - v.y;
    const dz = this.z - v.z;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  }

  lerp(v: Vec3, t: number): this {
    this.x += (v.x - this.x) * t;
    this.y += (v.y - this.y) * t;
    this.z += (v.z - this.z) * t;
    return this;
  }

  applyMat4(m: Mat4): this {
    const e = m.elements;
    const x = this.x;
    const y = this.y;
    const z = this.z;
    const w = e[3] * x + e[7] * y + e[11] * z + e[15] || 1.0;
    this.x = (e[0] * x + e[4] * y + e[8] * z + e[12]) / w;
    this.y = (e[1] * x + e[5] * y + e[9] * z + e[13]) / w;
    this.z = (e[2] * x + e[6] * y + e[10] * z + e[14]) / w;
    return this;
  }

  applyMat4Direction(m: Mat4): this {
    const e = m.elements;
    const x = this.x;
    const y = this.y;
    const z = this.z;
    this.x = e[0] * x + e[4] * y + e[8] * z;
    this.y = e[1] * x + e[5] * y + e[9] * z;
    this.z = e[2] * x + e[6] * y + e[10] * z;
    return this.normalize();
  }

  applyQuat(q: Quat): this {
    const x = this.x, y = this.y, z = this.z;
    const qx = q.x, qy = q.y, qz = q.z, qw = q.w;

    // calculate quat * vec
    const ix = qw * x + qy * z - qz * y;
    const iy = qw * y + qz * x - qx * z;
    const iz = qw * z + qx * y - qy * x;
    const iw = -qx * x - qy * y - qz * z;

    // calculate result * inverse quat
    this.x = ix * qw + iw * -qx + iy * -qz - iz * -qy;
    this.y = iy * qw + iw * -qy + iz * -qx - ix * -qz;
    this.z = iz * qw + iw * -qz + ix * -qy - iy * -qx;
    return this;
  }

  toArray(): [number, number, number] {
    return [this.x, this.y, this.z];
  }
}

export class Vec4 {
  constructor(public x: number = 0, public y: number = 0, public z: number = 0, public w: number = 1) {}

  set(x: number, y: number, z: number, w: number = 1): this {
    this.x = x;
    this.y = y;
    this.z = z;
    this.w = w;
    return this;
  }

  clone(): Vec4 {
    return new Vec4(this.x, this.y, this.z, this.w);
  }

  copy(v: Vec4): this {
    this.x = v.x;
    this.y = v.y;
    this.z = v.z;
    this.w = v.w;
    return this;
  }

  applyMat4(m: Mat4): this {
    const e = m.elements;
    const x = this.x, y = this.y, z = this.z, w = this.w;
    this.x = e[0] * x + e[4] * y + e[8] * z + e[12] * w;
    this.y = e[1] * x + e[5] * y + e[9] * z + e[13] * w;
    this.z = e[2] * x + e[6] * y + e[10] * z + e[14] * w;
    this.w = e[3] * x + e[7] * y + e[11] * z + e[15] * w;
    return this;
  }
}

export class Quat {
  constructor(public x: number = 0, public y: number = 0, public z: number = 0, public w: number = 1) {}

  set(x: number, y: number, z: number, w: number): this {
    this.x = x;
    this.y = y;
    this.z = z;
    this.w = w;
    return this;
  }

  clone(): Quat {
    return new Quat(this.x, this.y, this.z, this.w);
  }

  copy(q: Quat): this {
    this.x = q.x;
    this.y = q.y;
    this.z = q.z;
    this.w = q.w;
    return this;
  }

  identity(): this {
    this.x = 0;
    this.y = 0;
    this.z = 0;
    this.w = 1;
    return this;
  }

  setFromEuler(eulerX: number, eulerY: number, eulerZ: number, order: string = 'XYZ'): this {
    // Angles in radians
    const c1 = Math.cos(eulerX / 2);
    const c2 = Math.cos(eulerY / 2);
    const c3 = Math.cos(eulerZ / 2);
    const s1 = Math.sin(eulerX / 2);
    const s2 = Math.sin(eulerY / 2);
    const s3 = Math.sin(eulerZ / 2);

    if (order === 'XYZ') {
      this.x = s1 * c2 * c3 + c1 * s2 * s3;
      this.y = c1 * s2 * c3 - s1 * c2 * s3;
      this.z = c1 * c2 * s3 + s1 * s2 * c3;
      this.w = c1 * c2 * c3 - s1 * s2 * s3;
    } else if (order === 'YXZ') {
      this.x = s1 * c2 * c3 + c1 * s2 * s3;
      this.y = c1 * s2 * c3 - s1 * c2 * s3;
      this.z = c1 * c2 * s3 - s1 * s2 * c3;
      this.w = c1 * c2 * c3 + s1 * s2 * s3;
    } else if (order === 'ZYX') {
      this.x = s1 * c2 * c3 - c1 * s2 * s3;
      this.y = c1 * s2 * c3 + s1 * c2 * s3;
      this.z = c1 * c2 * s3 - s1 * s2 * c3;
      this.w = c1 * c2 * c3 + s1 * s2 * s3;
    }
    return this.normalize();
  }

  toEuler(): { x: number; y: number; z: number } {
    // Returns Euler in radians (XYZ)
    const x = this.x, y = this.y, z = this.z, w = this.w;
    const sinr_cosp = 2 * (w * x + y * z);
    const cosr_cosp = 1 - 2 * (x * x + y * y);
    const roll = Math.atan2(sinr_cosp, cosr_cosp);

    const sinp = 2 * (w * y - z * x);
    let pitch: number;
    if (Math.abs(sinp) >= 1) {
      pitch = (Math.PI / 2) * Math.sign(sinp);
    } else {
      pitch = Math.asin(sinp);
    }

    const siny_cosp = 2 * (w * z + x * y);
    const cosy_cosp = 1 - 2 * (y * y + z * z);
    const yaw = Math.atan2(siny_cosp, cosy_cosp);

    return { x: roll, y: pitch, z: yaw };
  }

  setFromAxisAngle(axis: Vec3, angle: number): this {
    const half = angle / 2;
    const s = Math.sin(half);
    const norm = axis.clone().normalize();
    this.x = norm.x * s;
    this.y = norm.y * s;
    this.z = norm.z * s;
    this.w = Math.cos(half);
    return this;
  }

  multiply(q: Quat): this {
    const qax = this.x, qay = this.y, qaz = this.z, qaw = this.w;
    const qbx = q.x, qby = q.y, qbz = q.z, qbw = q.w;

    this.x = qax * qbw + qaw * qbx + qay * qbz - qaz * qby;
    this.y = qay * qbw + qaw * qby + qaz * qbx - qax * qbz;
    this.z = qaz * qbw + qaw * qbz + qax * qby - qay * qbx;
    this.w = qaw * qbw - qax * qbx - qay * qby - qaz * qbz;
    return this;
  }

  static multiply(a: Quat, b: Quat): Quat {
    return new Quat(
      a.x * b.w + a.w * b.x + a.y * b.z - a.z * b.y,
      a.y * b.w + a.w * b.y + a.z * b.x - a.x * b.z,
      a.z * b.w + a.w * b.z + a.x * b.y - a.y * b.x,
      a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z
    );
  }

  normalize(): this {
    let l = Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w);
    if (l === 0) {
      this.x = 0;
      this.y = 0;
      this.z = 0;
      this.w = 1;
    } else {
      l = 1 / l;
      this.x *= l;
      this.y *= l;
      this.z *= l;
      this.w *= l;
    }
    return this;
  }

  slerp(qb: Quat, t: number): this {
    if (t === 0) return this;
    if (t === 1) return this.copy(qb);

    let x = this.x, y = this.y, z = this.z, w = this.w;
    let cosHalfTheta = w * qb.w + x * qb.x + y * qb.y + z * qb.z;

    let bx = qb.x, by = qb.y, bz = qb.z, bw = qb.w;
    if (cosHalfTheta < 0) {
      this.w = -bw;
      this.x = -bx;
      this.y = -by;
      this.z = -bz;
      cosHalfTheta = -cosHalfTheta;
    } else {
      this.copy(qb);
    }

    if (cosHalfTheta >= 1.0) {
      this.w = w;
      this.x = x;
      this.y = y;
      this.z = z;
      return this;
    }

    const sqrSinHalfTheta = 1.0 - cosHalfTheta * cosHalfTheta;
    if (sqrSinHalfTheta <= Number.EPSILON) {
      const s = 1 - t;
      this.w = s * w + t * this.w;
      this.x = s * x + t * this.x;
      this.y = s * y + t * this.y;
      this.z = s * z + t * this.z;
      return this.normalize();
    }

    const sinHalfTheta = Math.sqrt(sqrSinHalfTheta);
    const halfTheta = Math.atan2(sinHalfTheta, cosHalfTheta);
    const ratioA = Math.sin((1 - t) * halfTheta) / sinHalfTheta;
    const ratioB = Math.sin(t * halfTheta) / sinHalfTheta;

    this.w = w * ratioA + this.w * ratioB;
    this.x = x * ratioA + this.x * ratioB;
    this.y = y * ratioA + this.y * ratioB;
    this.z = z * ratioA + this.z * ratioB;
    return this;
  }
}

export class Mat4 {
  // 4x4 matrix stored in column-major order (standard for WebGL / OpenGL)
  public elements: Float32Array;

  constructor() {
    this.elements = new Float32Array([
      1, 0, 0, 0,
      0, 1, 0, 0,
      0, 0, 1, 0,
      0, 0, 0, 1
    ]);
  }

  clone(): Mat4 {
    const m = new Mat4();
    m.elements.set(this.elements);
    return m;
  }

  copy(m: Mat4): this {
    this.elements.set(m.elements);
    return this;
  }

  identity(): this {
    const e = this.elements;
    e[0] = 1; e[4] = 0; e[8]  = 0; e[12] = 0;
    e[1] = 0; e[5] = 1; e[9]  = 0; e[13] = 0;
    e[2] = 0; e[6] = 0; e[10] = 1; e[14] = 0;
    e[3] = 0; e[7] = 0; e[11] = 0; e[15] = 1;
    return this;
  }

  multiply(m: Mat4): this {
    return this.multiplyMatrices(this, m);
  }

  multiplyMatrices(a: Mat4, b: Mat4): this {
    const ae = a.elements;
    const be = b.elements;
    const te = this.elements;

    const a11 = ae[0], a12 = ae[4], a13 = ae[8], a14 = ae[12];
    const a21 = ae[1], a22 = ae[5], a23 = ae[9], a24 = ae[13];
    const a31 = ae[2], a32 = ae[6], a33 = ae[10], a34 = ae[14];
    const a41 = ae[3], a42 = ae[7], a43 = ae[11], a44 = ae[15];

    const b11 = be[0], b12 = be[4], b13 = be[8], b14 = be[12];
    const b21 = be[1], b22 = be[5], b23 = be[9], b24 = be[13];
    const b31 = be[2], b32 = be[6], b33 = be[10], b34 = be[14];
    const b41 = be[3], b42 = be[7], b43 = be[11], b44 = be[15];

    te[0] = a11 * b11 + a12 * b21 + a13 * b31 + a14 * b41;
    te[4] = a11 * b12 + a12 * b22 + a13 * b32 + a14 * b42;
    te[8] = a11 * b13 + a12 * b23 + a13 * b33 + a14 * b43;
    te[12] = a11 * b14 + a12 * b24 + a13 * b34 + a14 * b44;

    te[1] = a21 * b11 + a22 * b21 + a23 * b31 + a24 * b41;
    te[5] = a21 * b12 + a22 * b22 + a23 * b32 + a24 * b42;
    te[9] = a21 * b13 + a22 * b23 + a23 * b33 + a24 * b43;
    te[13] = a21 * b14 + a22 * b24 + a23 * b34 + a24 * b44;

    te[2] = a31 * b11 + a32 * b21 + a33 * b31 + a34 * b41;
    te[6] = a31 * b12 + a32 * b22 + a33 * b32 + a34 * b42;
    te[10] = a31 * b13 + a32 * b23 + a33 * b33 + a34 * b43;
    te[14] = a31 * b14 + a32 * b24 + a33 * b34 + a34 * b44;

    te[3] = a41 * b11 + a42 * b21 + a43 * b31 + a44 * b41;
    te[7] = a41 * b12 + a42 * b22 + a43 * b32 + a44 * b42;
    te[11] = a41 * b13 + a42 * b23 + a43 * b33 + a44 * b43;
    te[15] = a41 * b14 + a42 * b24 + a43 * b34 + a44 * b44;

    return this;
  }

  compose(position: Vec3, quaternion: Quat, scale: Vec3, pivot: Vec3 = new Vec3(0, 0, 0)): this {
    const te = this.elements;

    const x = quaternion.x, y = quaternion.y, z = quaternion.z, w = quaternion.w;
    const x2 = x + x,	y2 = y + y, z2 = z + z;
    const xx = x * x2, xy = x * y2, xz = x * z2;
    const yy = y * y2, yz = y * z2, zz = z * z2;
    const wx = w * x2, wy = w * y2, wz = w * z2;

    const sx = scale.x, sy = scale.y, sz = scale.z;

    const m00 = (1 - (yy + zz)) * sx;
    const m01 = (xy - wz) * sy;
    const m02 = (xz + wy) * sz;

    const m10 = (xy + wz) * sx;
    const m11 = (1 - (xx + zz)) * sy;
    const m12 = (yz - wx) * sz;

    const m20 = (xz - wy) * sx;
    const m21 = (yz + wx) * sy;
    const m22 = (1 - (xx + yy)) * sz;

    // Apply pivot
    const px = pivot.x, py = pivot.y, pz = pivot.z;
    const tx = position.x - (m00 * px + m01 * py + m02 * pz);
    const ty = position.y - (m10 * px + m11 * py + m12 * pz);
    const tz = position.z - (m20 * px + m21 * py + m22 * pz);

    te[0] = m00; te[4] = m01; te[8]  = m02; te[12] = tx;
    te[1] = m10; te[5] = m11; te[9]  = m12; te[13] = ty;
    te[2] = m20; te[6] = m21; te[10] = m22; te[14] = tz;
    te[3] = 0;   te[7] = 0;   te[11] = 0;   te[15] = 1;

    return this;
  }

  invert(): this {
    const te = this.elements;
    const n11 = te[0], n21 = te[1], n31 = te[2], n41 = te[3];
    const n12 = te[4], n22 = te[5], n32 = te[6], n42 = te[7];
    const n13 = te[8], n23 = te[9], n33 = te[10], n43 = te[11];
    const n14 = te[12], n24 = te[13], n34 = te[14], n44 = te[15];

    const t11 = n23 * n34 * n42 - n24 * n33 * n42 + n24 * n32 * n43 - n22 * n34 * n43 - n23 * n32 * n44 + n22 * n33 * n44;
    const t12 = n14 * n33 * n42 - n13 * n34 * n42 - n14 * n32 * n43 + n12 * n34 * n43 + n13 * n32 * n44 - n12 * n33 * n44;
    const t13 = n13 * n24 * n42 - n14 * n23 * n42 + n14 * n22 * n43 - n12 * n24 * n43 - n13 * n22 * n44 + n12 * n23 * n44;
    const t14 = n14 * n23 * n32 - n13 * n24 * n32 - n14 * n22 * n33 + n12 * n24 * n33 + n13 * n22 * n34 - n12 * n23 * n34;

    const det = n11 * t11 + n21 * t12 + n31 * t13 + n41 * t14;

    if (det === 0) {
      return this.identity();
    }

    const detInv = 1 / det;

    te[0] = t11 * detInv;
    te[1] = (n24 * n33 * n41 - n23 * n34 * n41 - n24 * n31 * n43 + n21 * n34 * n43 + n23 * n31 * n44 - n21 * n33 * n44) * detInv;
    te[2] = (n22 * n34 * n41 - n24 * n32 * n41 + n24 * n31 * n42 - n21 * n34 * n42 - n22 * n31 * n44 + n21 * n32 * n44) * detInv;
    te[3] = (n23 * n32 * n41 - n22 * n33 * n41 - n23 * n31 * n42 + n21 * n33 * n42 + n22 * n31 * n43 - n21 * n32 * n43) * detInv;

    te[4] = t12 * detInv;
    te[5] = (n13 * n34 * n41 - n14 * n33 * n41 + n14 * n31 * n43 - n11 * n34 * n43 - n13 * n31 * n44 + n11 * n33 * n44) * detInv;
    te[6] = (n14 * n32 * n41 - n12 * n34 * n41 - n14 * n31 * n42 + n11 * n34 * n42 + n12 * n31 * n44 - n11 * n32 * n44) * detInv;
    te[7] = (n12 * n33 * n41 - n13 * n32 * n41 + n13 * n31 * n42 - n11 * n33 * n42 - n12 * n31 * n43 + n11 * n32 * n43) * detInv;

    te[8] = t13 * detInv;
    te[9] = (n14 * n23 * n41 - n13 * n24 * n41 - n14 * n21 * n43 + n11 * n24 * n43 + n13 * n21 * n44 - n11 * n23 * n44) * detInv;
    te[10] = (n12 * n24 * n41 - n14 * n22 * n41 + n14 * n21 * n42 - n11 * n24 * n42 - n12 * n21 * n44 + n11 * n22 * n44) * detInv;
    te[11] = (n13 * n22 * n41 - n12 * n23 * n41 - n13 * n21 * n42 + n11 * n23 * n42 + n12 * n21 * n43 - n11 * n22 * n43) * detInv;

    te[12] = t14 * detInv;
    te[13] = (n13 * n24 * n31 - n14 * n23 * n31 + n14 * n21 * n33 - n11 * n24 * n33 - n13 * n21 * n34 + n11 * n23 * n34) * detInv;
    te[14] = (n14 * n22 * n31 - n12 * n24 * n31 - n14 * n21 * n32 + n11 * n24 * n32 + n12 * n21 * n34 - n11 * n22 * n34) * detInv;
    te[15] = (n12 * n23 * n31 - n13 * n22 * n31 + n13 * n21 * n32 - n11 * n23 * n32 - n12 * n21 * n33 + n11 * n22 * n33) * detInv;

    return this;
  }

  transpose(): this {
    const te = this.elements;
    let t: number;
    t = te[1]; te[1] = te[4]; te[4] = t;
    t = te[2]; te[2] = te[8]; te[8] = t;
    t = te[3]; te[3] = te[12]; te[12] = t;
    t = te[6]; te[6] = te[9]; te[9] = t;
    t = te[7]; te[7] = te[13]; te[13] = t;
    t = te[11]; te[11] = te[14]; te[14] = t;
    return this;
  }

  static perspective(fovRad: number, aspect: number, near: number, far: number): Mat4 {
    const m = new Mat4();
    const te = m.elements;
    const f = 1.0 / Math.tan(fovRad / 2);
    const nf = 1 / (near - far);

    te[0] = f / aspect;
    te[1] = 0;
    te[2] = 0;
    te[3] = 0;

    te[4] = 0;
    te[5] = f;
    te[6] = 0;
    te[7] = 0;

    te[8] = 0;
    te[9] = 0;
    te[10] = (far + near) * nf;
    te[11] = -1;

    te[12] = 0;
    te[13] = 0;
    te[14] = (2 * far * near) * nf;
    te[15] = 0;

    return m;
  }

  static orthographic(left: number, right: number, bottom: number, top: number, near: number, far: number): Mat4 {
    const m = new Mat4();
    const te = m.elements;
    const lr = 1 / (left - right);
    const bt = 1 / (bottom - top);
    const nf = 1 / (near - far);

    te[0] = -2 * lr;
    te[1] = 0;
    te[2] = 0;
    te[3] = 0;

    te[4] = 0;
    te[5] = -2 * bt;
    te[6] = 0;
    te[7] = 0;

    te[8] = 0;
    te[9] = 0;
    te[10] = 2 * nf;
    te[11] = 0;

    te[12] = (left + right) * lr;
    te[13] = (top + bottom) * bt;
    te[14] = (far + near) * nf;
    te[15] = 1;

    return m;
  }

  static lookAt(eye: Vec3, target: Vec3, up: Vec3): Mat4 {
    const m = new Mat4();
    const te = m.elements;

    const z = Vec3.sub(eye, target).normalize();
    if (z.lengthSq() === 0) z.z = 1;

    const x = Vec3.cross(up, z).normalize();
    if (x.lengthSq() === 0) {
      x.x = 1;
    }

    const y = Vec3.cross(z, x);

    te[0] = x.x; te[4] = x.y; te[8]  = x.z; te[12] = -x.dot(eye);
    te[1] = y.x; te[5] = y.y; te[9]  = y.z; te[13] = -y.dot(eye);
    te[2] = z.x; te[6] = z.y; te[10] = z.z; te[14] = -z.dot(eye);
    te[3] = 0;   te[7] = 0;   te[11] = 0;   te[15] = 1;

    return m;
  }
}

export class Ray {
  constructor(public origin: Vec3 = new Vec3(), public direction: Vec3 = new Vec3(0, 0, -1)) {
    this.direction.normalize();
  }

  at(t: number): Vec3 {
    return Vec3.add(this.origin, Vec3.scale(this.direction, t));
  }
}

export class BoundingBox {
  public min: Vec3;
  public max: Vec3;

  constructor(min?: Vec3, max?: Vec3) {
    this.min = min ? min.clone() : new Vec3(Infinity, Infinity, Infinity);
    this.max = max ? max.clone() : new Vec3(-Infinity, -Infinity, -Infinity);
  }

  empty(): this {
    this.min.set(Infinity, Infinity, Infinity);
    this.max.set(-Infinity, -Infinity, -Infinity);
    return this;
  }

  expandByPoint(p: Vec3): this {
    this.min.x = Math.min(this.min.x, p.x);
    this.min.y = Math.min(this.min.y, p.y);
    this.min.z = Math.min(this.min.z, p.z);

    this.max.x = Math.max(this.max.x, p.x);
    this.max.y = Math.max(this.max.y, p.y);
    this.max.z = Math.max(this.max.z, p.z);
    return this;
  }

  expandByBox(box: BoundingBox): this {
    this.expandByPoint(box.min);
    this.expandByPoint(box.max);
    return this;
  }

  getCenter(): Vec3 {
    return new Vec3(
      (this.min.x + this.max.x) * 0.5,
      (this.min.y + this.max.y) * 0.5,
      (this.min.z + this.max.z) * 0.5
    );
  }

  getSize(): Vec3 {
    return new Vec3(
      Math.max(0, this.max.x - this.min.x),
      Math.max(0, this.max.y - this.min.y),
      Math.max(0, this.max.z - this.min.z)
    );
  }

  intersectsRay(ray: Ray): { hit: boolean; tMin: number; tMax: number } {
    let tmin = (this.min.x - ray.origin.x) / (ray.direction.x || 1e-8);
    let tmax = (this.max.x - ray.origin.x) / (ray.direction.x || 1e-8);

    if (tmin > tmax) {
      const temp = tmin; tmin = tmax; tmax = temp;
    }

    let tymin = (this.min.y - ray.origin.y) / (ray.direction.y || 1e-8);
    let tymax = (this.max.y - ray.origin.y) / (ray.direction.y || 1e-8);

    if (tymin > tymax) {
      const temp = tymin; tymin = tymax; tymax = temp;
    }

    if (tmin > tymax || tymin > tmax) {
      return { hit: false, tMin: 0, tMax: 0 };
    }

    if (tymin > tmin) tmin = tymin;
    if (tymax < tmax) tmax = tymax;

    let tzmin = (this.min.z - ray.origin.z) / (ray.direction.z || 1e-8);
    let tzmax = (this.max.z - ray.origin.z) / (ray.direction.z || 1e-8);

    if (tzmin > tzmax) {
      const temp = tzmin; tzmin = tzmax; tzmax = temp;
    }

    if (tmin > tzmax || tzmin > tmax) {
      return { hit: false, tMin: 0, tMax: 0 };
    }

    if (tzmin > tmin) tmin = tzmin;
    if (tzmax < tmax) tmax = tzmax;

    return { hit: tmax >= Math.max(0, tmin), tMin: tmin, tMax: tmax };
  }
}

export class Color {
  constructor(public r: number = 1, public g: number = 1, public b: number = 1, public a: number = 1) {}

  set(r: number, g: number, b: number, a: number = 1): this {
    this.r = r;
    this.g = g;
    this.b = b;
    this.a = a;
    return this;
  }

  setHex(hex: string): this {
    let clean = hex.replace('#', '');
    if (clean.length === 3) {
      clean = clean.split('').map(c => c + c).join('');
    }
    const num = parseInt(clean, 16);
    this.r = ((num >> 16) & 255) / 255;
    this.g = ((num >> 8) & 255) / 255;
    this.b = (num & 255) / 255;
    this.a = 1;
    return this;
  }

  setFromHex(hex: string): this {
    return this.setHex(hex);
  }

  toHex(): string {
    const r = Math.round(Math.min(1, Math.max(0, this.r)) * 255).toString(16).padStart(2, '0');
    const g = Math.round(Math.min(1, Math.max(0, this.g)) * 255).toString(16).padStart(2, '0');
    const b = Math.round(Math.min(1, Math.max(0, this.b)) * 255).toString(16).padStart(2, '0');
    return `#${r}${g}${b}`;
  }

  toRgbString(): string {
    return `rgb(${Math.round(this.r * 255)}, ${Math.round(this.g * 255)}, ${Math.round(this.b * 255)})`;
  }

  toRgbaArray(): [number, number, number, number] {
    return [this.r, this.g, this.b, this.a];
  }

  toRgbArray(): [number, number, number] {
    return [this.r, this.g, this.b];
  }

  clone(): Color {
    return new Color(this.r, this.g, this.b, this.a);
  }

  scale(s: number): this {
    this.r *= s;
    this.g *= s;
    this.b *= s;
    return this;
  }

  multiply(c: Color): this {
    this.r *= c.r;
    this.g *= c.g;
    this.b *= c.b;
    this.a *= c.a;
    return this;
  }

  add(c: Color): this {
    this.r += c.r;
    this.g += c.g;
    this.b += c.b;
    return this;
  }

  lerp(c: Color, t: number): this {
    this.r += (c.r - this.r) * t;
    this.g += (c.g - this.g) * t;
    this.b += (c.b - this.b) * t;
    this.a += (c.a - this.a) * t;
    return this;
  }
}
