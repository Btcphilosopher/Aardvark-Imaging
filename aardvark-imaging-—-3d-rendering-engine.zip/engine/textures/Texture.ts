export enum TextureFilter {
  NEAREST = 'NEAREST',
  LINEAR = 'LINEAR',
  MIPMAP_LINEAR = 'MIPMAP_LINEAR'
}

export enum TextureWrap {
  REPEAT = 'REPEAT',
  CLAMP_TO_EDGE = 'CLAMP_TO_EDGE',
  MIRRORED_REPEAT = 'MIRRORED_REPEAT'
}

export class Texture {
  public id: string;
  public name: string;
  public width: number;
  public height: number;
  public filter: TextureFilter;
  public wrapS: TextureWrap;
  public wrapT: TextureWrap;
  public flipY: boolean;
  public isHdr: boolean;

  public sourceCanvas: HTMLCanvasElement | null = null;
  public sourceImage: HTMLImageElement | null = null;
  public rawData: Float32Array | Uint8Array | null = null;

  // WebGL GPU Texture Handle Cache
  public glTexture: WebGLTexture | null = null;
  public isDirty: boolean = true;

  constructor(
    source?: HTMLCanvasElement | HTMLImageElement | Float32Array | Uint8Array,
    width: number = 256,
    height: number = 256
  ) {
    this.id = 'tex_' + Math.random().toString(36).substring(2, 9);
    this.name = 'Texture';
    this.width = width;
    this.height = height;
    this.filter = TextureFilter.MIPMAP_LINEAR;
    this.wrapS = TextureWrap.REPEAT;
    this.wrapT = TextureWrap.REPEAT;
    this.flipY = true;
    this.isHdr = false;

    if (source instanceof HTMLCanvasElement) {
      this.sourceCanvas = source;
      this.width = source.width;
      this.height = source.height;
    } else if (source instanceof HTMLImageElement) {
      this.sourceImage = source;
      this.width = source.naturalWidth || width;
      this.height = source.naturalHeight || height;
    } else if (source instanceof Float32Array || source instanceof Uint8Array) {
      this.rawData = source;
      this.width = width;
      this.height = height;
    }
  }

  // Procedural Generator: Checkerboard
  static createChecker(size: number = 512, tiles: number = 8, colA = '#222226', colB = '#55555c'): Texture {
    if (typeof document === 'undefined') return new Texture(undefined, size, size);
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      const tileSize = size / tiles;
      for (let y = 0; y < tiles; y++) {
        for (let x = 0; x < tiles; x++) {
          ctx.fillStyle = (x + y) % 2 === 0 ? colA : colB;
          ctx.fillRect(x * tileSize, y * tileSize, tileSize, tileSize);
        }
      }
    }
    const tex = new Texture(canvas, size, size);
    tex.name = 'Checker Texture';
    return tex;
  }

  // Procedural Generator: Perlin / Simplex Noise
  static createNoiseTexture(size: number = 512, scale: number = 6.0): Texture {
    if (typeof document === 'undefined') return new Texture(undefined, size, size);
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      const imgData = ctx.createImageData(size, size);
      const data = imgData.data;

      // Fast value/simplex noise synthesis
      for (let y = 0; y < size; y++) {
        for (let x = 0; x < size; x++) {
          const nx = (x / size) * scale;
          const ny = (y / size) * scale;
          const val =
            Math.sin(nx) * Math.cos(ny) * 0.5 +
            Math.sin(nx * 2.3 + ny * 1.7) * 0.25 +
            Math.cos(nx * 4.7 - ny * 3.1) * 0.125 +
            0.5;
          const b = Math.floor(Math.min(1, Math.max(0, val)) * 255);
          const idx = (y * size + x) * 4;
          data[idx] = b;
          data[idx + 1] = b;
          data[idx + 2] = b;
          data[idx + 3] = 255;
        }
      }
      ctx.putImageData(imgData, 0, 0);
    }
    const tex = new Texture(canvas, size, size);
    tex.name = 'Noise Texture';
    return tex;
  }

  // Procedural Generator: Normal Bump Map
  static createNormalNoiseMap(size: number = 512, scale: number = 8.0, strength: number = 2.0): Texture {
    if (typeof document === 'undefined') return new Texture(undefined, size, size);
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      const imgData = ctx.createImageData(size, size);
      const data = imgData.data;

      const getHeight = (x: number, y: number) => {
        const nx = (x / size) * scale;
        const ny = (y / size) * scale;
        return (
          Math.sin(nx) * Math.cos(ny) * 0.5 +
          Math.sin(nx * 2.5 + ny * 2.1) * 0.3 +
          Math.cos(nx * 5.1 - ny * 4.2) * 0.2
        );
      };

      for (let y = 0; y < size; y++) {
        for (let x = 0; x < size; x++) {
          const hL = getHeight((x - 1 + size) % size, y);
          const hR = getHeight((x + 1) % size, y);
          const hD = getHeight(x, (y - 1 + size) % size);
          const hU = getHeight(x, (y + 1) % size);

          let dx = (hR - hL) * strength;
          let dy = (hU - hD) * strength;
          let dz = 1.0;

          const len = Math.sqrt(dx * dx + dy * dy + dz * dz);
          dx /= len;
          dy /= len;
          dz /= len;

          const idx = (y * size + x) * 4;
          data[idx] = Math.floor((dx * 0.5 + 0.5) * 255);
          data[idx + 1] = Math.floor((dy * 0.5 + 0.5) * 255);
          data[idx + 2] = Math.floor((dz * 0.5 + 0.5) * 255);
          data[idx + 3] = 255;
        }
      }
      ctx.putImageData(imgData, 0, 0);
    }
    const tex = new Texture(canvas, size, size);
    tex.name = 'Normal Noise Map';
    return tex;
  }

  // Procedural Generator: Studio HDRI Environment Map (Spherical Equirectangular Panorama)
  static createStudioEnvironment(width: number = 512, height: number = 256): Texture {
    if (typeof document === 'undefined') return new Texture(undefined, width, height);
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      // Dark cinematic studio gradient
      const grad = ctx.createLinearGradient(0, 0, 0, height);
      grad.addColorStop(0, '#101524');
      grad.addColorStop(0.5, '#1e2433');
      grad.addColorStop(1, '#080a10');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);

      // Studio Key Light (Softbox Top-Right)
      const gradKey = ctx.createRadialGradient(width * 0.7, height * 0.35, 10, width * 0.7, height * 0.35, 90);
      gradKey.addColorStop(0, 'rgba(255, 250, 240, 1.0)');
      gradKey.addColorStop(0.3, 'rgba(255, 230, 200, 0.8)');
      gradKey.addColorStop(1, 'rgba(255, 200, 150, 0)');
      ctx.fillStyle = gradKey;
      ctx.beginPath();
      ctx.arc(width * 0.7, height * 0.35, 90, 0, Math.PI * 2);
      ctx.fill();

      // Studio Fill Light (Cool Softbox Left)
      const gradFill = ctx.createRadialGradient(width * 0.25, height * 0.45, 10, width * 0.25, height * 0.45, 80);
      gradFill.addColorStop(0, 'rgba(200, 230, 255, 0.9)');
      gradFill.addColorStop(0.5, 'rgba(150, 200, 255, 0.4)');
      gradFill.addColorStop(1, 'rgba(100, 160, 255, 0)');
      ctx.fillStyle = gradFill;
      ctx.beginPath();
      ctx.arc(width * 0.25, height * 0.45, 80, 0, Math.PI * 2);
      ctx.fill();

      // Rim Light / Floor reflection line
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(0, height * 0.7);
      ctx.lineTo(width, height * 0.7);
      ctx.stroke();
    }
    const tex = new Texture(canvas, width, height);
    tex.name = 'Studio HDR Map';
    tex.isHdr = true;
    return tex;
  }
}
