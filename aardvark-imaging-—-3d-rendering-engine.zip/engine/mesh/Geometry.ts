import { Vec3, BoundingBox } from '../core/math';

export interface Submesh {
  start: number;
  count: number;
  materialIndex: number;
}

export class Geometry {
  public positions: Float32Array; // 3 floats per vertex (x, y, z)
  public normals: Float32Array;   // 3 floats per vertex (nx, ny, nz)
  public uvs: Float32Array;       // 2 floats per vertex (u, v)
  public tangents: Float32Array;  // 4 floats per vertex (tx, ty, tz, tw)
  public colors: Float32Array;    // 4 floats per vertex (r, g, b, a)
  public indices: Uint32Array | Uint16Array;
  public submeshes: Submesh[] = [];
  public bounds: BoundingBox;

  // GPU Buffers / dirty flags
  public isDirty: boolean = true;

  constructor(
    positions?: Float32Array,
    normals?: Float32Array,
    uvs?: Float32Array,
    indices?: Uint32Array | Uint16Array,
    tangents?: Float32Array,
    colors?: Float32Array
  ) {
    const vCount = positions ? positions.length / 3 : 0;
    this.positions = positions || new Float32Array(0);
    this.normals = normals || new Float32Array(vCount * 3);
    this.uvs = uvs || new Float32Array(vCount * 2);
    this.tangents = tangents || new Float32Array(vCount * 4);
    this.colors = colors || new Float32Array(vCount * 4);
    this.indices = indices || new Uint32Array(0);
    this.bounds = new BoundingBox();

    if (this.positions.length > 0) {
      this.computeBounds();
      if (!normals || normals.length === 0) this.computeNormals();
      if (!tangents || tangents.length === 0) this.computeTangents();
    }
  }

  get vertexCount(): number {
    return this.positions.length / 3;
  }

  get indexCount(): number {
    return this.indices.length;
  }

  get triangleCount(): number {
    return this.indices.length > 0 ? this.indices.length / 3 : this.vertexCount / 3;
  }

  computeBounds(): BoundingBox {
    this.bounds.empty();
    const p = this.positions;
    const pt = new Vec3();
    for (let i = 0; i < p.length; i += 3) {
      pt.set(p[i], p[i + 1], p[i + 2]);
      this.bounds.expandByPoint(pt);
    }
    return this.bounds;
  }

  computeNormals(): void {
    const pos = this.positions;
    const ind = this.indices;
    const vCount = pos.length / 3;
    const norm = new Float32Array(vCount * 3);

    const pA = new Vec3(), pB = new Vec3(), pC = new Vec3();
    const cb = new Vec3(), ab = new Vec3();

    if (ind.length > 0) {
      for (let i = 0; i < ind.length; i += 3) {
        const iA = ind[i];
        const iB = ind[i + 1];
        const iC = ind[i + 2];

        pA.set(pos[iA * 3], pos[iA * 3 + 1], pos[iA * 3 + 2]);
        pB.set(pos[iB * 3], pos[iB * 3 + 1], pos[iB * 3 + 2]);
        pC.set(pos[iC * 3], pos[iC * 3 + 1], pos[iC * 3 + 2]);

        cb.subVectors(pC, pB);
        ab.subVectors(pA, pB);
        cb.cross(ab);

        norm[iA * 3] += cb.x;
        norm[iA * 3 + 1] += cb.y;
        norm[iA * 3 + 2] += cb.z;

        norm[iB * 3] += cb.x;
        norm[iB * 3 + 1] += cb.y;
        norm[iB * 3 + 2] += cb.z;

        norm[iC * 3] += cb.x;
        norm[iC * 3 + 1] += cb.y;
        norm[iC * 3 + 2] += cb.z;
      }
    } else {
      for (let i = 0; i < pos.length; i += 9) {
        pA.set(pos[i], pos[i + 1], pos[i + 2]);
        pB.set(pos[i + 3], pos[i + 4], pos[i + 5]);
        pC.set(pos[i + 6], pos[i + 7], pos[i + 8]);

        cb.subVectors(pC, pB);
        ab.subVectors(pA, pB);
        cb.cross(ab).normalize();

        norm[i] = cb.x; norm[i + 1] = cb.y; norm[i + 2] = cb.z;
        norm[i + 3] = cb.x; norm[i + 4] = cb.y; norm[i + 5] = cb.z;
        norm[i + 6] = cb.x; norm[i + 7] = cb.y; norm[i + 8] = cb.z;
      }
    }

    // Normalize
    const n = new Vec3();
    for (let i = 0; i < norm.length; i += 3) {
      n.set(norm[i], norm[i + 1], norm[i + 2]).normalize();
      norm[i] = n.x;
      norm[i + 1] = n.y;
      norm[i + 2] = n.z;
    }

    this.normals = norm;
    this.isDirty = true;
  }

  computeTangents(): void {
    const pos = this.positions;
    const uvs = this.uvs;
    const ind = this.indices;
    const vCount = pos.length / 3;

    const tan1 = new Float32Array(vCount * 3);
    const tan2 = new Float32Array(vCount * 3);

    const v1 = new Vec3(), v2 = new Vec3(), v3 = new Vec3();
    const w1 = new Vec3(), w2 = new Vec3(), w3 = new Vec3();

    const triCount = ind.length > 0 ? ind.length / 3 : vCount / 3;

    for (let i = 0; i < triCount; i++) {
      const i1 = ind.length > 0 ? ind[i * 3] : i * 3;
      const i2 = ind.length > 0 ? ind[i * 3 + 1] : i * 3 + 1;
      const i3 = ind.length > 0 ? ind[i * 3 + 2] : i * 3 + 2;

      v1.set(pos[i1 * 3], pos[i1 * 3 + 1], pos[i1 * 3 + 2]);
      v2.set(pos[i2 * 3], pos[i2 * 3 + 1], pos[i2 * 3 + 2]);
      v3.set(pos[i3 * 3], pos[i3 * 3 + 1], pos[i3 * 3 + 2]);

      w1.set(uvs[i1 * 2] || 0, uvs[i1 * 2 + 1] || 0, 0);
      w2.set(uvs[i2 * 2] || 0, uvs[i2 * 2 + 1] || 0, 0);
      w3.set(uvs[i3 * 2] || 0, uvs[i3 * 2 + 1] || 0, 0);

      const x1 = v2.x - v1.x;
      const x2 = v3.x - v1.x;
      const y1 = v2.y - v1.y;
      const y2 = v3.y - v1.y;
      const z1 = v2.z - v1.z;
      const z2 = v3.z - v1.z;

      const s1 = w2.x - w1.x;
      const s2 = w3.x - w1.x;
      const t1 = w2.y - w1.y;
      const t2 = w3.y - w1.y;

      const r = 1.0 / (s1 * t2 - s2 * t1 || 1e-6);

      const sdirX = (t2 * x1 - t1 * x2) * r;
      const sdirY = (t2 * y1 - t1 * y2) * r;
      const sdirZ = (t2 * z1 - t1 * z2) * r;

      const tdirX = (s1 * x2 - s2 * x1) * r;
      const tdirY = (s1 * y2 - s2 * y1) * r;
      const tdirZ = (s1 * z2 - s2 * z1) * r;

      tan1[i1 * 3] += sdirX; tan1[i1 * 3 + 1] += sdirY; tan1[i1 * 3 + 2] += sdirZ;
      tan1[i2 * 3] += sdirX; tan1[i2 * 3 + 1] += sdirY; tan1[i2 * 3 + 2] += sdirZ;
      tan1[i3 * 3] += sdirX; tan1[i3 * 3 + 1] += sdirY; tan1[i3 * 3 + 2] += sdirZ;

      tan2[i1 * 3] += tdirX; tan2[i1 * 3 + 1] += tdirY; tan2[i1 * 3 + 2] += tdirZ;
      tan2[i2 * 3] += tdirX; tan2[i2 * 3 + 1] += tdirY; tan2[i2 * 3 + 2] += tdirZ;
      tan2[i3 * 3] += tdirX; tan2[i3 * 3 + 1] += tdirY; tan2[i3 * 3 + 2] += tdirZ;
    }

    const tangents = new Float32Array(vCount * 4);
    const n = new Vec3(), t = new Vec3(), temp = new Vec3();

    for (let i = 0; i < vCount; i++) {
      n.set(this.normals[i * 3], this.normals[i * 3 + 1], this.normals[i * 3 + 2]);
      t.set(tan1[i * 3], tan1[i * 3 + 1], tan1[i * 3 + 2]);

      // Gram-Schmidt orthogonalize: t - n * (n . t)
      const dot = n.dot(t);
      temp.copy(n).scale(dot);
      t.sub(temp).normalize();

      tangents[i * 4] = t.x;
      tangents[i * 4 + 1] = t.y;
      tangents[i * 4 + 2] = t.z;

      // Handedness
      temp.crossVectors(n, t);
      const t2Vec = new Vec3(tan2[i * 3], tan2[i * 3 + 1], tan2[i * 3 + 2]);
      tangents[i * 4 + 3] = temp.dot(t2Vec) < 0.0 ? -1.0 : 1.0;
    }

    this.tangents = tangents;
    this.isDirty = true;
  }
}

// Vector math helper extensions
declare module '../core/math' {
  interface Vec3 {
    subVectors(a: Vec3, b: Vec3): this;
    crossVectors(a: Vec3, b: Vec3): this;
  }
}

Vec3.prototype.subVectors = function (a: Vec3, b: Vec3) {
  this.x = a.x - b.x;
  this.y = a.y - b.y;
  this.z = a.z - b.z;
  return this;
};

Vec3.prototype.crossVectors = function (a: Vec3, b: Vec3) {
  const ax = a.x, ay = a.y, az = a.z;
  const bx = b.x, by = b.y, bz = b.z;
  this.x = ay * bz - az * by;
  this.y = az * bx - ax * bz;
  this.z = ax * by - ay * bx;
  return this;
};
