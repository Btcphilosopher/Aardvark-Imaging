import { Geometry } from './Geometry';
import { Vec3 } from '../core/math';

export function createPlane(
  width: number = 2,
  height: number = 2,
  widthSegments: number = 1,
  heightSegments: number = 1
): Geometry {
  const wHalf = width / 2;
  const hHalf = height / 2;

  const gridX = Math.floor(widthSegments);
  const gridY = Math.floor(heightSegments);
  const gridX1 = gridX + 1;
  const gridY1 = gridY + 1;

  const segmentWidth = width / gridX;
  const segmentHeight = height / gridY;

  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];

  for (let iy = 0; iy < gridY1; iy++) {
    const y = iy * segmentHeight - hHalf;
    for (let ix = 0; ix < gridX1; ix++) {
      const x = ix * segmentWidth - wHalf;
      positions.push(x, -y, 0);
      normals.push(0, 0, 1);
      uvs.push(ix / gridX, 1 - iy / gridY);
    }
  }

  for (let iy = 0; iy < gridY; iy++) {
    for (let ix = 0; ix < gridX; ix++) {
      const a = ix + gridX1 * iy;
      const b = ix + gridX1 * (iy + 1);
      const c = ix + 1 + gridX1 * (iy + 1);
      const d = ix + 1 + gridX1 * iy;

      indices.push(a, b, d);
      indices.push(b, c, d);
    }
  }

  return new Geometry(
    new Float32Array(positions),
    new Float32Array(normals),
    new Float32Array(uvs),
    new Uint32Array(indices)
  );
}

export function createCube(
  width: number = 1,
  height: number = 1,
  depth: number = 1,
  widthSegments: number = 1,
  heightSegments: number = 1,
  depthSegments: number = 1
): Geometry {
  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];

  let numberOfVertices = 0;

  function buildPlane(
    u: 'x' | 'y' | 'z',
    v: 'x' | 'y' | 'z',
    w: 'x' | 'y' | 'z',
    udir: number,
    vdir: number,
    width: number,
    height: number,
    depth: number,
    gridX: number,
    gridY: number
  ) {
    const segmentWidth = width / gridX;
    const segmentHeight = height / gridY;

    const widthHalf = width / 2;
    const heightHalf = height / 2;
    const depthHalf = depth / 2;

    const gridX1 = gridX + 1;
    const gridY1 = gridY + 1;

    let vertexCounter = 0;

    const vector = new Vec3();

    // generate vertices, normals and uvs
    for (let iy = 0; iy < gridY1; iy++) {
      const y = iy * segmentHeight - heightHalf;

      for (let ix = 0; ix < gridX1; ix++) {
        const x = ix * segmentWidth - widthHalf;

        vector[u] = x * udir;
        vector[v] = y * vdir;
        vector[w] = depthHalf;

        positions.push(vector.x, vector.y, vector.z);

        vector[u] = 0;
        vector[v] = 0;
        vector[w] = depth > 0 ? 1 : -1;

        normals.push(vector.x, vector.y, vector.z);
        uvs.push(ix / gridX, 1 - iy / gridY);

        vertexCounter += 1;
      }
    }

    // indices
    for (let iy = 0; iy < gridY; iy++) {
      for (let ix = 0; ix < gridX; ix++) {
        const a = numberOfVertices + ix + gridX1 * iy;
        const b = numberOfVertices + ix + gridX1 * (iy + 1);
        const c = numberOfVertices + (ix + 1) + gridX1 * (iy + 1);
        const d = numberOfVertices + (ix + 1) + gridX1 * iy;

        indices.push(a, b, d);
        indices.push(b, c, d);
      }
    }

    numberOfVertices += vertexCounter;
  }

  // 6 faces: +z, -z, +x, -x, +y, -y
  buildPlane('x', 'y', 'z', 1, -1, width, height, depth, widthSegments, heightSegments); // px
  buildPlane('x', 'y', 'z', -1, -1, width, height, -depth, widthSegments, heightSegments); // nx
  buildPlane('z', 'y', 'x', 1, -1, depth, height, width, depthSegments, heightSegments); // py
  buildPlane('z', 'y', 'x', -1, -1, depth, height, -width, depthSegments, heightSegments); // ny
  buildPlane('x', 'z', 'y', 1, 1, width, depth, height, widthSegments, depthSegments); // pz
  buildPlane('x', 'z', 'y', 1, -1, width, depth, -height, widthSegments, depthSegments); // nz

  return new Geometry(
    new Float32Array(positions),
    new Float32Array(normals),
    new Float32Array(uvs),
    new Uint32Array(indices)
  );
}

export function createSphere(
  radius: number = 1,
  widthSegments: number = 32,
  heightSegments: number = 16,
  phiStart: number = 0,
  phiLength: number = Math.PI * 2,
  thetaStart: number = 0,
  thetaLength: number = Math.PI
): Geometry {
  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];

  const grid = [];

  for (let iy = 0; iy <= heightSegments; iy++) {
    const verticesRow = [];
    const v = iy / heightSegments;

    let uOffset = 0;
    if (iy === 0 && thetaStart === 0) {
      uOffset = 0.5 / widthSegments;
    } else if (iy === heightSegments && thetaStart + thetaLength === Math.PI) {
      uOffset = -0.5 / widthSegments;
    }

    for (let ix = 0; ix <= widthSegments; ix++) {
      const u = ix / widthSegments;

      const x = -radius * Math.cos(phiStart + u * phiLength) * Math.sin(thetaStart + v * thetaLength);
      const y = radius * Math.cos(thetaStart + v * thetaLength);
      const z = radius * Math.sin(phiStart + u * phiLength) * Math.sin(thetaStart + v * thetaLength);

      positions.push(x, y, z);

      const n = new Vec3(x, y, z).normalize();
      normals.push(n.x, n.y, n.z);

      uvs.push(u + uOffset, 1 - v);

      verticesRow.push(positions.length / 3 - 1);
    }
    grid.push(verticesRow);
  }

  for (let iy = 0; iy < heightSegments; iy++) {
    for (let ix = 0; ix < widthSegments; ix++) {
      const a = grid[iy][ix + 1];
      const b = grid[iy][ix];
      const c = grid[iy + 1][ix];
      const d = grid[iy + 1][ix + 1];

      if (iy !== 0 || thetaStart > 0) indices.push(a, b, d);
      if (iy !== heightSegments - 1 || thetaStart + thetaLength < Math.PI) indices.push(b, c, d);
    }
  }

  return new Geometry(
    new Float32Array(positions),
    new Float32Array(normals),
    new Float32Array(uvs),
    new Uint32Array(indices)
  );
}

export function createCylinder(
  radiusTop: number = 0.5,
  radiusBottom: number = 0.5,
  height: number = 1.5,
  radialSegments: number = 32,
  heightSegments: number = 1,
  openEnded: boolean = false
): Geometry {
  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];

  const indexArray: number[][] = [];
  const halfHeight = height / 2;

  // Torso
  const slope = (radiusBottom - radiusTop) / height;

  for (let y = 0; y <= heightSegments; y++) {
    const indexRow: number[] = [];
    const v = y / heightSegments;
    const radius = v * (radiusBottom - radiusTop) + radiusTop;

    for (let x = 0; x <= radialSegments; x++) {
      const u = x / radialSegments;
      const theta = u * Math.PI * 2;

      const sinTheta = Math.sin(theta);
      const cosTheta = Math.cos(theta);

      const vx = radius * sinTheta;
      const vy = -v * height + halfHeight;
      const vz = radius * cosTheta;

      positions.push(vx, vy, vz);

      const normal = new Vec3(sinTheta, slope, cosTheta).normalize();
      normals.push(normal.x, normal.y, normal.z);
      uvs.push(u, 1 - v);

      indexRow.push(positions.length / 3 - 1);
    }
    indexArray.push(indexRow);
  }

  for (let x = 0; x < radialSegments; x++) {
    for (let y = 0; y < heightSegments; y++) {
      const a = indexArray[y][x];
      const b = indexArray[y + 1][x];
      const c = indexArray[y + 1][x + 1];
      const d = indexArray[y][x + 1];

      indices.push(a, b, d);
      indices.push(b, c, d);
    }
  }

  // Top Cap
  if (!openEnded && radiusTop > 0) {
    const centerIndex = positions.length / 3;
    positions.push(0, halfHeight, 0);
    normals.push(0, 1, 0);
    uvs.push(0.5, 0.5);

    for (let x = 0; x <= radialSegments; x++) {
      const u = x / radialSegments;
      const theta = u * Math.PI * 2;
      const vx = radiusTop * Math.sin(theta);
      const vz = radiusTop * Math.cos(theta);

      positions.push(vx, halfHeight, vz);
      normals.push(0, 1, 0);
      uvs.push(Math.sin(theta) * 0.5 + 0.5, Math.cos(theta) * 0.5 + 0.5);
    }

    for (let x = 0; x < radialSegments; x++) {
      const i1 = centerIndex + 1 + x;
      const i2 = centerIndex + 1 + x + 1;
      indices.push(i2, i1, centerIndex);
    }
  }

  // Bottom Cap
  if (!openEnded && radiusBottom > 0) {
    const centerIndex = positions.length / 3;
    positions.push(0, -halfHeight, 0);
    normals.push(0, -1, 0);
    uvs.push(0.5, 0.5);

    for (let x = 0; x <= radialSegments; x++) {
      const u = x / radialSegments;
      const theta = u * Math.PI * 2;
      const vx = radiusBottom * Math.sin(theta);
      const vz = radiusBottom * Math.cos(theta);

      positions.push(vx, -halfHeight, vz);
      normals.push(0, -1, 0);
      uvs.push(Math.sin(theta) * 0.5 + 0.5, Math.cos(theta) * 0.5 + 0.5);
    }

    for (let x = 0; x < radialSegments; x++) {
      const i1 = centerIndex + 1 + x;
      const i2 = centerIndex + 1 + x + 1;
      indices.push(centerIndex, i1, i2);
    }
  }

  return new Geometry(
    new Float32Array(positions),
    new Float32Array(normals),
    new Float32Array(uvs),
    new Uint32Array(indices)
  );
}

export function createTorus(
  radius: number = 0.8,
  tube: number = 0.3,
  radialSegments: number = 24,
  tubularSegments: number = 36,
  arc: number = Math.PI * 2
): Geometry {
  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];

  for (let j = 0; j <= radialSegments; j++) {
    for (let i = 0; i <= tubularSegments; i++) {
      const u = (i / tubularSegments) * arc;
      const v = (j / radialSegments) * Math.PI * 2;

      const x = (radius + tube * Math.cos(v)) * Math.cos(u);
      const y = (radius + tube * Math.cos(v)) * Math.sin(u);
      const z = tube * Math.sin(v);

      positions.push(x, y, z);

      const cx = radius * Math.cos(u);
      const cy = radius * Math.sin(u);
      const normal = new Vec3(x - cx, y - cy, z).normalize();
      normals.push(normal.x, normal.y, normal.z);

      uvs.push(i / tubularSegments, j / radialSegments);
    }
  }

  for (let j = 1; j <= radialSegments; j++) {
    for (let i = 1; i <= tubularSegments; i++) {
      const a = (tubularSegments + 1) * j + i - 1;
      const b = (tubularSegments + 1) * (j - 1) + i - 1;
      const c = (tubularSegments + 1) * (j - 1) + i;
      const d = (tubularSegments + 1) * j + i;

      indices.push(a, b, d);
      indices.push(b, c, d);
    }
  }

  return new Geometry(
    new Float32Array(positions),
    new Float32Array(normals),
    new Float32Array(uvs),
    new Uint32Array(indices)
  );
}

export function createCone(
  radius: number = 0.5,
  height: number = 1.5,
  radialSegments: number = 32,
  heightSegments: number = 1
): Geometry {
  return createCylinder(0, radius, height, radialSegments, heightSegments, false);
}

export function createCapsule(
  radius: number = 0.4,
  length: number = 1.0,
  capSubdivisions: number = 12,
  radialSegments: number = 24
): Geometry {
  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];

  const halfLength = length / 2;
  const grid: number[][] = [];

  // Top hemisphere + cylinder + bottom hemisphere
  const totalRings = capSubdivisions * 2 + 1; // top cap + bottom cap
  for (let ring = 0; ring <= totalRings; ring++) {
    const ringIndices: number[] = [];
    let phi = 0;
    let yOffset = 0;

    if (ring <= capSubdivisions) {
      // Top hemisphere: phi from 0 to PI/2
      phi = (ring / capSubdivisions) * (Math.PI / 2);
      yOffset = halfLength;
    } else {
      // Bottom hemisphere: phi from PI/2 to PI
      phi = Math.PI / 2 + ((ring - capSubdivisions - 1) / capSubdivisions) * (Math.PI / 2);
      yOffset = -halfLength;
    }

    const sinPhi = Math.sin(phi);
    const cosPhi = Math.cos(phi);

    for (let seg = 0; seg <= radialSegments; seg++) {
      const theta = (seg / radialSegments) * Math.PI * 2;
      const sinTheta = Math.sin(theta);
      const cosTheta = Math.cos(theta);

      const x = radius * sinPhi * cosTheta;
      const y = radius * cosPhi + (ring <= capSubdivisions ? halfLength : -halfLength);
      const z = radius * sinPhi * sinTheta;

      positions.push(x, y, z);

      const nx = sinPhi * cosTheta;
      const ny = cosPhi;
      const nz = sinPhi * sinTheta;
      normals.push(nx, ny, nz);

      uvs.push(seg / radialSegments, ring / totalRings);
      ringIndices.push(positions.length / 3 - 1);
    }
    grid.push(ringIndices);
  }

  for (let ring = 0; ring < totalRings; ring++) {
    for (let seg = 0; seg < radialSegments; seg++) {
      const a = grid[ring][seg];
      const b = grid[ring + 1][seg];
      const c = grid[ring + 1][seg + 1];
      const d = grid[ring][seg + 1];

      indices.push(a, b, d);
      indices.push(b, c, d);
    }
  }

  return new Geometry(
    new Float32Array(positions),
    new Float32Array(normals),
    new Float32Array(uvs),
    new Uint32Array(indices)
  );
}
