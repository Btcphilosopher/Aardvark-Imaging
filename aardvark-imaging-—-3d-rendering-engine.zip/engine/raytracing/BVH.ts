import { Vec3, Ray, BoundingBox } from '../core/math';
import { Geometry } from '../mesh/Geometry';
import { Material } from '../materials/Material';
import { SceneNode } from '../scene/SceneNode';

export interface RayHit {
  hit: boolean;
  t: number;
  point: Vec3;
  normal: Vec3;
  uv: [number, number];
  material: Material;
  node: SceneNode;
}

export interface BVHTriangle {
  v0: Vec3;
  v1: Vec3;
  v2: Vec3;
  n0: Vec3;
  n1: Vec3;
  n2: Vec3;
  uv0: [number, number];
  uv1: [number, number];
  uv2: [number, number];
  material: Material;
  node: SceneNode;
  centroid: Vec3;
  bounds: BoundingBox;
}

export class BVHNode {
  public bounds: BoundingBox;
  public left: BVHNode | null = null;
  public right: BVHNode | null = null;
  public triangles: BVHTriangle[] = [];

  constructor() {
    this.bounds = new BoundingBox();
  }

  isLeaf(): boolean {
    return this.left === null && this.right === null;
  }
}

export class BVH {
  public root: BVHNode | null = null;
  public totalTriangles: number = 0;
  public totalNodes: number = 0;

  build(nodes: SceneNode[]): void {
    const triangles: BVHTriangle[] = [];

    for (const node of nodes) {
      if (!node.visible) continue;
      if (!node.geometry || node.geometry.positions.length === 0) continue;

      const geom = node.geometry;
      const worldMat = node.transform.worldMatrix;
      const normMat = node.transform.normalMatrix;
      const pos = geom.positions;
      const norm = geom.normals;
      const uvs = geom.uvs;
      const ind = geom.indices;

      const defaultMat = node.materials[0] || new Material();

      const getMaterialForTriangle = (triIdx: number): Material => {
        if (geom.submeshes && geom.submeshes.length > 0) {
          const indexOffset = triIdx * 3;
          for (const sub of geom.submeshes) {
            if (indexOffset >= sub.start && indexOffset < sub.start + sub.count) {
              return node.materials[sub.materialIndex] || defaultMat;
            }
          }
        }
        return defaultMat;
      };

      const triCount = ind.length > 0 ? ind.length / 3 : pos.length / 9;

      for (let i = 0; i < triCount; i++) {
        const i0 = ind.length > 0 ? ind[i * 3] : i * 3;
        const i1 = ind.length > 0 ? ind[i * 3 + 1] : i * 3 + 1;
        const i2 = ind.length > 0 ? ind[i * 3 + 2] : i * 3 + 2;

        const v0 = new Vec3(pos[i0 * 3], pos[i0 * 3 + 1], pos[i0 * 3 + 2]).applyMat4(worldMat);
        const v1 = new Vec3(pos[i1 * 3], pos[i1 * 3 + 1], pos[i1 * 3 + 2]).applyMat4(worldMat);
        const v2 = new Vec3(pos[i2 * 3], pos[i2 * 3 + 1], pos[i2 * 3 + 2]).applyMat4(worldMat);

        const n0 = new Vec3(norm[i0 * 3] || 0, norm[i0 * 3 + 1] || 1, norm[i0 * 3 + 2] || 0).applyMat4Direction(normMat);
        const n1 = new Vec3(norm[i1 * 3] || 0, norm[i1 * 3 + 1] || 1, norm[i1 * 3 + 2] || 0).applyMat4Direction(normMat);
        const n2 = new Vec3(norm[i2 * 3] || 0, norm[i2 * 3 + 1] || 1, norm[i2 * 3 + 2] || 0).applyMat4Direction(normMat);

        const uv0: [number, number] = [uvs[i0 * 2] || 0, uvs[i0 * 2 + 1] || 0];
        const uv1: [number, number] = [uvs[i1 * 2] || 0, uvs[i1 * 2 + 1] || 0];
        const uv2: [number, number] = [uvs[i2 * 2] || 0, uvs[i2 * 2 + 1] || 0];

        const centroid = new Vec3(
          (v0.x + v1.x + v2.x) / 3,
          (v0.y + v1.y + v2.y) / 3,
          (v0.z + v1.z + v2.z) / 3
        );

        const b = new BoundingBox();
        b.expandByPoint(v0);
        b.expandByPoint(v1);
        b.expandByPoint(v2);

        triangles.push({
          v0, v1, v2,
          n0, n1, n2,
          uv0, uv1, uv2,
          material: getMaterialForTriangle(i),
          node,
          centroid,
          bounds: b
        });
      }
    }

    this.totalTriangles = triangles.length;
    this.totalNodes = 0;
    this.root = this.buildRecursive(triangles, 0);
  }

  private buildRecursive(triangles: BVHTriangle[], depth: number): BVHNode {
    const node = new BVHNode();
    this.totalNodes++;

    for (const tri of triangles) {
      node.bounds.expandByBox(tri.bounds);
    }

    // Leaf condition: small count or max depth
    if (triangles.length <= 4 || depth >= 16) {
      node.triangles = triangles;
      return node;
    }

    // Split on longest axis of bounding box
    const size = node.bounds.getSize();
    let axis: 'x' | 'y' | 'z' = 'x';
    if (size.y > size.x && size.y > size.z) axis = 'y';
    else if (size.z > size.x && size.z > size.y) axis = 'z';

    triangles.sort((a, b) => a.centroid[axis] - b.centroid[axis]);

    const mid = Math.floor(triangles.length / 2);
    const leftTris = triangles.slice(0, mid);
    const rightTris = triangles.slice(mid);

    if (leftTris.length === 0 || rightTris.length === 0) {
      node.triangles = triangles;
      return node;
    }

    node.left = this.buildRecursive(leftTris, depth + 1);
    node.right = this.buildRecursive(rightTris, depth + 1);

    return node;
  }

  intersectRay(ray: Ray): RayHit | null {
    if (!this.root) return null;

    let closestHit: RayHit | null = null;
    let closestT = Infinity;

    const stack: BVHNode[] = [this.root];

    while (stack.length > 0) {
      const node = stack.pop()!;

      const boxTest = node.bounds.intersectsRay(ray);
      if (!boxTest.hit || boxTest.tMin > closestT) {
        continue;
      }

      if (node.isLeaf()) {
        for (const tri of node.triangles) {
          const triHit = this.intersectTriangle(ray, tri);
          if (triHit && triHit.t < closestT && triHit.t > 0.0001) {
            closestT = triHit.t;
            closestHit = triHit;
          }
        }
      } else {
        if (node.left) stack.push(node.left);
        if (node.right) stack.push(node.right);
      }
    }

    return closestHit;
  }

  // Möller–Trumbore Ray-Triangle intersection algorithm
  private intersectTriangle(ray: Ray, tri: BVHTriangle): RayHit | null {
    const edge1 = Vec3.sub(tri.v1, tri.v0);
    const edge2 = Vec3.sub(tri.v2, tri.v0);
    const h = Vec3.cross(ray.direction, edge2);
    const a = edge1.dot(h);

    if (a > -1e-7 && a < 1e-7) return null; // Ray parallel to triangle

    const f = 1.0 / a;
    const s = Vec3.sub(ray.origin, tri.v0);
    const u = f * s.dot(h);

    if (u < 0.0 || u > 1.0) return null;

    const q = Vec3.cross(s, edge1);
    const v = f * ray.direction.dot(q);

    if (v < 0.0 || u + v > 1.0) return null;

    const t = f * edge2.dot(q);
    if (t < 0.0001) return null;

    const hitPoint = ray.at(t);
    const w = 1.0 - u - v;

    // Interpolate normal and UVs
    const normal = new Vec3(
      w * tri.n0.x + u * tri.n1.x + v * tri.n2.x,
      w * tri.n0.y + u * tri.n1.y + v * tri.n2.y,
      w * tri.n0.z + u * tri.n1.z + v * tri.n2.z
    ).normalize();

    const uv: [number, number] = [
      w * tri.uv0[0] + u * tri.uv1[0] + v * tri.uv2[0],
      w * tri.uv0[1] + u * tri.uv1[1] + v * tri.uv2[1]
    ];

    return {
      hit: true,
      t,
      point: hitPoint,
      normal,
      uv,
      material: tri.material,
      node: tri.node
    };
  }
}
