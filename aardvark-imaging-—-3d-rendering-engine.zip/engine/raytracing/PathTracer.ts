import { Vec3, Ray, Color } from '../core/math';
import { BVH, RayHit } from './BVH';
import { Scene } from '../scene/Scene';
import { Light, LightType } from '../lights/Light';
import { ShadingModel } from '../materials/Material';

export interface PathTracerOptions {
  maxBounces?: number;
  maxSamples?: number;
  tileSize?: number;
  useDof?: boolean;
}

export class PathTracer {
  public bvh: BVH;
  public accumulationBuffer: Float32Array | null = null;
  public sampleCount: number = 0;
  public isRendering: boolean = false;
  public width: number = 0;
  public height: number = 0;

  public maxBounces: number = 4;
  public maxSamples: number = 500;

  constructor() {
    this.bvh = new BVH();
  }

  init(width: number, height: number, scene: Scene): void {
    this.width = width;
    this.height = height;
    this.sampleCount = 0;
    this.accumulationBuffer = new Float32Array(width * height * 3);

    // Build BVH from all visible meshes
    const meshes = scene.getAllMeshes();
    this.bvh.build(meshes);
  }

  reset(): void {
    this.sampleCount = 0;
    if (this.accumulationBuffer) {
      this.accumulationBuffer.fill(0);
    }
  }

  renderSampleBatch(scene: Scene, linesPerBatch: number = 20): boolean {
    if (!this.accumulationBuffer || this.width === 0 || this.height === 0) return false;
    if (this.sampleCount >= this.maxSamples) return true; // Done

    const cam = scene.activeCamera;
    const lights = scene.getAllLights();
    const w = this.width;
    const h = this.height;
    const buffer = this.accumulationBuffer;

    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        // Sub-pixel jitter for antialiasing
        const subPixelX = x + Math.random();
        const subPixelY = y + Math.random();

        const ndcX = (subPixelX / w) * 2 - 1;
        const ndcY = 1 - (subPixelY / h) * 2;

        // Thin-lens jitter for Depth of Field
        let lensJitterX = 0;
        let lensJitterY = 0;
        if (cam.dofEnabled) {
          const angle = Math.random() * Math.PI * 2;
          const radius = Math.sqrt(Math.random());
          lensJitterX = Math.cos(angle) * radius;
          lensJitterY = Math.sin(angle) * radius;
        }

        const primaryRay = cam.generateRay(ndcX, ndcY, lensJitterX, lensJitterY);
        const radiance = this.tracePath(primaryRay, scene, lights, 0);

        const idx = (y * w + x) * 3;
        buffer[idx] += radiance.r;
        buffer[idx + 1] += radiance.g;
        buffer[idx + 2] += radiance.b;
      }
    }

    this.sampleCount++;
    return this.sampleCount >= this.maxSamples;
  }

  // Trace physical ray path recursively
  private tracePath(ray: Ray, scene: Scene, lights: Light[], depth: number): Color {
    if (depth > this.maxBounces) {
      return new Color(0, 0, 0);
    }

    const hit = this.bvh.intersectRay(ray);
    if (!hit) {
      // Sky / Environment Radiance
      return this.sampleEnvironment(ray.direction, scene);
    }

    const mat = hit.material;

    // 1. Emission
    let resultColor = new Color(0, 0, 0);
    if (mat.emissionIntensity > 0) {
      const emitCol = mat.emission.clone().scale(mat.emissionIntensity);
      resultColor.add(emitCol);
    }

    if (mat.shadingModel === ShadingModel.UNLIT) {
      return mat.baseColor.clone();
    }

    const N = hit.normal.clone();
    const V = Vec3.scale(ray.direction, -1).normalize();
    const NdotV = Math.max(0, N.dot(V));

    // 2. Direct Light Shadow Sampling
    for (const light of lights) {
      if (!light.intensity) continue;

      let lightDir = new Vec3();
      let lightDistance = Infinity;
      let lightColor = light.color.clone().scale(light.intensity);

      const lightPos = light.transform.getWorldPosition();

      if (light.type === LightType.DIRECTIONAL) {
        lightDir = Vec3.scale(lightPos, -1).normalize();
        lightDistance = 1000.0;
      } else {
        const toLight = Vec3.sub(lightPos, hit.point);
        lightDistance = toLight.length();
        lightDir = toLight.normalize();

        // Distance attenuation
        const atten = 1.0 / (1.0 + 0.1 * lightDistance + 0.05 * lightDistance * lightDistance);
        lightColor.scale(atten);

        if (light.type === LightType.SPOT) {
          const spotDir = new Vec3(0, 0, -1).applyMat4Direction(light.transform.normalMatrix);
          const spotAngle = Math.acos(Math.max(-1, Math.min(1, Vec3.scale(lightDir, -1).dot(spotDir)))) * (180 / Math.PI);
          if (spotAngle > light.outerConeAngle) {
            continue;
          }
          const penumbraFactor = Math.max(0, Math.min(1, (light.outerConeAngle - spotAngle) / (light.outerConeAngle - light.innerConeAngle || 1)));
          lightColor.scale(penumbraFactor);
        }
      }

      // Shadow ray check
      const shadowRay = new Ray(
        Vec3.add(hit.point, Vec3.scale(N, 0.001)),
        lightDir
      );
      const shadowHit = this.bvh.intersectRay(shadowRay);

      if (!shadowHit || shadowHit.t > lightDistance) {
        // Light visible! Diffuse + Specular BRDF
        const NdotL = Math.max(0, N.dot(lightDir));
        if (NdotL > 0) {
          const H = Vec3.add(V, lightDir).normalize();
          const NdotH = Math.max(0, N.dot(H));

          // Lambertian diffuse
          const diffuse = mat.baseColor.clone().multiply(lightColor).scale(NdotL * (1.0 - mat.metallic));

          // Specular Cook-Torrance approximation
          const rough = Math.max(0.05, mat.roughness);
          const specPower = (2.0 / (rough * rough * rough * rough)) - 2.0;
          const specTerm = Math.pow(NdotH, Math.max(1, specPower));
          const specular = lightColor.clone().scale(specTerm * (0.04 + 0.96 * mat.metallic));

          resultColor.add(diffuse).add(specular);
        }
      }
    }

    // 3. Indirect GI Bounce / Specular Reflection / Glass Refraction
    const isTransmission = mat.transmission > 0.1 && Math.random() < mat.transmission;

    if (isTransmission) {
      // Refraction / Snell's law
      const eta = N.dot(V) > 0 ? 1.0 / mat.ior : mat.ior; // Air to glass or glass to air
      const hitNormal = N.dot(V) > 0 ? N : Vec3.scale(N, -1);
      const cosI = Math.max(-1, Math.min(1, Vec3.scale(ray.direction, -1).dot(hitNormal)));
      const sinT2 = eta * eta * (1.0 - cosI * cosI);

      if (sinT2 < 1.0) {
        // Refraction ray
        const cosT = Math.sqrt(1.0 - sinT2);
        const refrDir = Vec3.add(
          Vec3.scale(ray.direction, eta),
          Vec3.scale(hitNormal, eta * cosI - cosT)
        ).normalize();

        const refrRay = new Ray(Vec3.add(hit.point, Vec3.scale(refrDir, 0.002)), refrDir);
        const refrColor = this.tracePath(refrRay, scene, lights, depth + 1);
        resultColor.add(refrColor.multiply(mat.baseColor));
      }
    } else {
      // Diffuse or Specular Bounce
      const isSpecular = Math.random() < mat.metallic || Math.random() < (1.0 - mat.roughness) * 0.5;

      let bounceDir: Vec3;
      if (isSpecular) {
        // Specular Reflection with Roughness Jitter
        const reflectDir = Vec3.sub(ray.direction, Vec3.scale(N, 2 * ray.direction.dot(N))).normalize();
        const roughJitter = this.randomHemisphereDir(reflectDir).scale(mat.roughness * 0.5);
        bounceDir = Vec3.add(reflectDir, roughJitter).normalize();
      } else {
        // Cosine-weighted hemisphere diffuse bounce
        bounceDir = this.randomHemisphereDir(N);
      }

      const bounceRay = new Ray(Vec3.add(hit.point, Vec3.scale(N, 0.001)), bounceDir);
      const indirectColor = this.tracePath(bounceRay, scene, lights, depth + 1);

      if (isSpecular) {
        resultColor.add(indirectColor.scale(0.8));
      } else {
        const NdotB = Math.max(0, N.dot(bounceDir));
        resultColor.add(indirectColor.multiply(mat.baseColor).scale(NdotB * 0.7));
      }
    }

    return resultColor;
  }

  private randomHemisphereDir(normal: Vec3): Vec3 {
    const u1 = Math.random();
    const u2 = Math.random();
    const r = Math.sqrt(u1);
    const theta = 2 * Math.PI * u2;

    const x = r * Math.cos(theta);
    const y = r * Math.sin(theta);
    const z = Math.sqrt(Math.max(0, 1 - u1));

    // Construct local coordinate frame
    const w = normal.clone().normalize();
    const a = Math.abs(w.x) > 0.9 ? new Vec3(0, 1, 0) : new Vec3(1, 0, 0);
    const u = Vec3.cross(a, w).normalize();
    const v = Vec3.cross(w, u);

    return new Vec3(
      u.x * x + v.x * y + w.x * z,
      u.y * x + v.y * y + w.y * z,
      u.z * x + v.z * y + w.z * z
    ).normalize();
  }

  private sampleEnvironment(dir: Vec3, scene: Scene): Color {
    if (scene.environmentMap && scene.environmentMap.sourceCanvas) {
      // Sample equirectangular panorama
      const u = 0.5 + Math.atan2(dir.z, dir.x) / (2 * Math.PI);
      const v = 0.5 - Math.asin(Math.max(-1, Math.min(1, dir.y))) / Math.PI;

      const canvas = scene.environmentMap.sourceCanvas;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        const px = Math.floor(u * canvas.width);
        const py = Math.floor(v * canvas.height);
        const data = ctx.getImageData(px, py, 1, 1).data;
        return new Color(data[0] / 255, data[1] / 255, data[2] / 255);
      }
    }

    // Default Atmospheric gradient
    const t = 0.5 * (dir.y + 1.0);
    return new Color(
      0.08 + t * 0.12,
      0.10 + t * 0.15,
      0.14 + t * 0.22
    );
  }

  // Draw progressive accumulated image into target canvas with tone mapping & ACES curve
  drawToCanvas(canvas: HTMLCanvasElement): void {
    if (!this.accumulationBuffer || this.sampleCount === 0) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = this.width;
    const h = this.height;
    if (canvas.width !== w || canvas.height !== h) {
      canvas.width = w;
      canvas.height = h;
    }

    const imgData = ctx.createImageData(w, h);
    const data = imgData.data;
    const buffer = this.accumulationBuffer;
    const invSamples = 1.0 / this.sampleCount;

    for (let i = 0; i < w * h; i++) {
      let r = buffer[i * 3] * invSamples;
      let g = buffer[i * 3 + 1] * invSamples;
      let b = buffer[i * 3 + 2] * invSamples;

      // ACES Film Tone Mapping curve
      const a = 2.51, bc = 0.03, c = 2.43, d = 0.59, e = 0.14;
      r = (r * (a * r + bc)) / (r * (c * r + d) + e);
      g = (g * (a * g + bc)) / (g * (c * g + d) + e);
      b = (b * (a * b + bc)) / (b * (c * b + d) + e);

      // Gamma correction (sRGB)
      r = Math.pow(Math.max(0, Math.min(1, r)), 1.0 / 2.2);
      g = Math.pow(Math.max(0, Math.min(1, g)), 1.0 / 2.2);
      b = Math.pow(Math.max(0, Math.min(1, b)), 1.0 / 2.2);

      data[i * 4] = Math.floor(r * 255);
      data[i * 4 + 1] = Math.floor(g * 255);
      data[i * 4 + 2] = Math.floor(b * 255);
      data[i * 4 + 3] = 255;
    }

    ctx.putImageData(imgData, 0, 0);
  }
}
