import { Mat4, Vec3, Ray } from '../core/math';
import { Transform } from '../core/transform';

export enum CameraType {
  PERSPECTIVE = 'PERSPECTIVE',
  ORTHOGRAPHIC = 'ORTHOGRAPHIC'
}

export class Camera {
  public id: string;
  public name: string;
  public type: CameraType;
  public transform: Transform;

  // Perspective Optical Properties
  public fov: number; // in degrees (vertical)
  public focalLength: number; // in mm (e.g., 50mm)
  public sensorSize: number;  // 36mm (Full Frame 35mm equivalent)
  public near: number;
  public far: number;
  public aspect: number;

  // Orthographic Properties
  public orthoSize: number;

  // Physical Depth of Field Properties
  public dofEnabled: boolean;
  public focusDistance: number; // in world units
  public fStop: number;         // e.g. 1.4, 2.8, 5.6
  public bokehApertureBlades: number; // 0 for circular, 5/6/7/8 for polygon bokeh
  public bokehAnamorphicRatio: number; // 1.0 for spherical, 2.0 for anamorphic

  // Cinematic Camera Shake
  public shakeEnabled: boolean;
  public shakeIntensity: number;
  public shakeFrequency: number;
  public shakeOffset: Vec3;
  public shakeRotation: Vec3;

  // Matrix Caches
  public projectionMatrix: Mat4;
  public viewMatrix: Mat4;
  public viewProjectionMatrix: Mat4;
  public inverseViewProjectionMatrix: Mat4;

  constructor(type: CameraType = CameraType.PERSPECTIVE) {
    this.id = 'cam_' + Math.random().toString(36).substring(2, 9);
    this.name = 'Cinematic Camera';
    this.type = type;
    this.transform = new Transform();
    this.transform.setPosition(0, 1.5, 4.5);

    this.fov = 45;
    this.focalLength = 50; // 50mm standard prime
    this.sensorSize = 36;  // 35mm full frame sensor
    this.near = 0.1;
    this.far = 100.0;
    this.aspect = 16 / 9;

    this.orthoSize = 4.0;

    this.dofEnabled = false;
    this.focusDistance = 4.5;
    this.fStop = 2.8;
    this.bokehApertureBlades = 7;
    this.bokehAnamorphicRatio = 1.0;

    this.shakeEnabled = false;
    this.shakeIntensity = 0.05;
    this.shakeFrequency = 1.2;
    this.shakeOffset = new Vec3();
    this.shakeRotation = new Vec3();

    this.projectionMatrix = new Mat4();
    this.viewMatrix = new Mat4();
    this.viewProjectionMatrix = new Mat4();
    this.inverseViewProjectionMatrix = new Mat4();

    this.updateFovFromFocalLength();
    this.updateMatrices();
  }

  setFocalLength(mm: number): void {
    this.focalLength = mm;
    this.updateFovFromFocalLength();
    this.updateMatrices();
  }

  updateFovFromFocalLength(): void {
    // FOV = 2 * atan(sensorSize / (2 * focalLength)) * (180 / PI)
    const rad = 2 * Math.atan(this.sensorSize / (2 * this.focalLength));
    this.fov = (rad * 180) / Math.PI;
  }

  updateFocalLengthFromFov(): void {
    const rad = (this.fov * Math.PI) / 180;
    this.focalLength = this.sensorSize / (2 * Math.tan(rad / 2));
  }

  updateShake(time: number): void {
    if (!this.shakeEnabled) {
      this.shakeOffset.set(0, 0, 0);
      this.shakeRotation.set(0, 0, 0);
      return;
    }
    const t = time * this.shakeFrequency;
    const sx = Math.sin(t * 1.7) * Math.cos(t * 0.9) * this.shakeIntensity;
    const sy = Math.cos(t * 1.3) * Math.sin(t * 1.1) * this.shakeIntensity * 0.8;
    const sz = Math.sin(t * 0.7) * this.shakeIntensity * 0.5;

    const rx = Math.sin(t * 2.1) * (this.shakeIntensity * 15);
    const ry = Math.cos(t * 1.9) * (this.shakeIntensity * 15);
    const rz = Math.sin(t * 1.1) * (this.shakeIntensity * 8);

    this.shakeOffset.set(sx, sy, sz);
    this.shakeRotation.set(rx, ry, rz);
  }

  updateMatrices(): void {
    // 1. Update Projection
    if (this.type === CameraType.PERSPECTIVE) {
      const fovRad = (this.fov * Math.PI) / 180;
      this.projectionMatrix = Mat4.perspective(fovRad, this.aspect, this.near, this.far);
    } else {
      const halfW = (this.orthoSize * this.aspect) / 2;
      const halfH = this.orthoSize / 2;
      this.projectionMatrix = Mat4.orthographic(-halfW, halfW, -halfH, halfH, this.near, this.far);
    }

    // 2. Update Transform & View
    this.transform.updateWorldMatrix();
    this.viewMatrix.copy(this.transform.worldMatrix).invert();

    // 3. VP Matrix
    this.viewProjectionMatrix.multiplyMatrices(this.projectionMatrix, this.viewMatrix);
    this.inverseViewProjectionMatrix.copy(this.viewProjectionMatrix).invert();
  }

  lookAt(target: Vec3): void {
    const eye = this.transform.getWorldPosition();
    const up = new Vec3(0, 1, 0);
    const m = Mat4.lookAt(eye, target, up);
    // Extract rotation to transform
    this.viewMatrix.copy(m);
    this.transform.worldMatrix.copy(m).invert();
    this.transform.isDirty = true;
  }

  /**
   * Generates a primary world-space ray for raytracing/pathtracing at normalized device coordinates (ndcX, ndcY: [-1, 1])
   * with optional lens jitter for true depth-of-field sampling.
   */
  generateRay(ndcX: number, ndcY: number, lensJitterX: number = 0, lensJitterY: number = 0): Ray {
    const nearVec = new Vec3(ndcX, ndcY, -1.0).applyMat4(this.inverseViewProjectionMatrix);
    const farVec = new Vec3(ndcX, ndcY, 1.0).applyMat4(this.inverseViewProjectionMatrix);

    const cameraPos = this.transform.getWorldPosition();
    const rayDir = Vec3.sub(farVec, nearVec).normalize();

    if (!this.dofEnabled || this.fStop <= 0) {
      return new Ray(cameraPos, rayDir);
    }

    // Physical Thin Lens Model
    // Lens radius = focalLength / (2 * fStop) in mm -> converted to world units
    const lensRadius = (this.focalLength / (2 * this.fStop * 1000)) * 20.0;
    const focalPlanePoint = Vec3.add(cameraPos, Vec3.scale(rayDir, this.focusDistance));

    // Jitter on camera local XY plane
    const camRight = new Vec3(
      this.transform.worldMatrix.elements[0],
      this.transform.worldMatrix.elements[1],
      this.transform.worldMatrix.elements[2]
    ).normalize();

    const camUp = new Vec3(
      this.transform.worldMatrix.elements[4],
      this.transform.worldMatrix.elements[5],
      this.transform.worldMatrix.elements[6]
    ).normalize();

    const jitterPos = cameraPos.clone()
      .add(Vec3.scale(camRight, lensJitterX * lensRadius))
      .add(Vec3.scale(camUp, lensJitterY * lensRadius));

    const newDir = Vec3.sub(focalPlanePoint, jitterPos).normalize();
    return new Ray(jitterPos, newDir);
  }

  // Physical Circle of Confusion (CoC) diameter in pixels for a given depth z
  computeCoC(zDistance: number, viewportHeightPx: number): number {
    if (!this.dofEnabled || zDistance <= 0) return 0;
    const f = this.focalLength / 1000; // in meters
    const N = this.fStop;
    const s = this.focusDistance;
    const z = zDistance;

    // CoC formula: C = |A * (f * (s - z)) / (z * (s - f))| where A = f / N
    const A = f / N;
    const nom = Math.abs(A * f * (s - z));
    const denom = Math.abs(z * (s - f)) || 1e-6;
    const cocMeters = nom / denom;

    // Convert to sensor pixels
    const sensorHeightMeters = (this.sensorSize / 1.777) / 1000;
    const cocPixels = (cocMeters / sensorHeightMeters) * viewportHeightPx;
    return Math.min(64.0, cocPixels);
  }
}
