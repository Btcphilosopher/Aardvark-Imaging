export type EasingType =
  | 'linear'
  | 'easeInQuad'
  | 'easeOutQuad'
  | 'easeInOutQuad'
  | 'easeInCubic'
  | 'easeOutCubic'
  | 'easeInOutCubic'
  | 'easeInBack'
  | 'easeOutBack'
  | 'easeInOutBack';

export interface Keyframe<T = number> {
  time: number; // in seconds
  value: T;
  easing?: EasingType;
}

export interface AnimationTrack {
  id: string;
  name: string;
  targetId: string;
  property: string; // e.g. 'transform.position.y', 'transform.rotation.y', 'camera.focusDistance'
  keyframes: Keyframe<number>[];
}

export class Timeline {
  public currentTime: number = 0;
  public duration: number = 5.0; // 5 seconds default
  public fps: number = 30;
  public isPlaying: boolean = false;
  public loop: boolean = true;
  public playbackSpeed: number = 1.0;

  public tracks: AnimationTrack[] = [];

  constructor() {
    this.initDefaultDemoTracks();
  }

  addTrack(track: AnimationTrack): void {
    this.tracks.push(track);
  }

  removeTrack(id: string): void {
    this.tracks = this.tracks.filter((t) => t.id !== id);
  }

  addKeyframe(trackId: string, time: number, value: number, easing: EasingType = 'easeInOutQuad'): void {
    const track = this.tracks.find((t) => t.id === trackId);
    if (!track) return;

    // Check if keyframe exists at same time
    const existing = track.keyframes.find((k) => Math.abs(k.time - time) < 0.001);
    if (existing) {
      existing.value = value;
      existing.easing = easing;
    } else {
      track.keyframes.push({ time, value, easing });
      track.keyframes.sort((a, b) => a.time - b.time);
    }
  }

  update(dt: number): void {
    if (!this.isPlaying) return;

    this.currentTime += dt * this.playbackSpeed;
    if (this.currentTime > this.duration) {
      if (this.loop) {
        this.currentTime = 0;
      } else {
        this.currentTime = this.duration;
        this.isPlaying = false;
      }
    }
  }

  evaluateTrack(track: AnimationTrack, time: number): number {
    const keys = track.keyframes;
    if (keys.length === 0) return 0;
    if (keys.length === 1 || time <= keys[0].time) return keys[0].value;
    if (time >= keys[keys.length - 1].time) return keys[keys.length - 1].value;

    // Find bounding keyframes
    let k0 = keys[0];
    let k1 = keys[1];

    for (let i = 0; i < keys.length - 1; i++) {
      if (time >= keys[i].time && time <= keys[i + 1].time) {
        k0 = keys[i];
        k1 = keys[i + 1];
        break;
      }
    }

    const t = (time - k0.time) / (k1.time - k0.time || 1e-6);
    const easedT = this.applyEasing(t, k0.easing || 'easeInOutQuad');

    return k0.value + (k1.value - k0.value) * easedT;
  }

  applyEasing(t: number, easing: EasingType): number {
    switch (easing) {
      case 'linear':
        return t;
      case 'easeInQuad':
        return t * t;
      case 'easeOutQuad':
        return t * (2 - t);
      case 'easeInOutQuad':
        return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
      case 'easeInCubic':
        return t * t * t;
      case 'easeOutCubic':
        return --t * t * t + 1;
      case 'easeInOutCubic':
        return t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1;
      case 'easeOutBack': {
        const c1 = 1.70158;
        const c3 = c1 + 1;
        return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
      }
      default:
        return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
    }
  }

  // Preset animation track suite for live motion graphics showcase
  private initDefaultDemoTracks(): void {
    // 1. Logo 360 Spin + Floating Bob Track
    this.tracks.push({
      id: 'track_logo_rot_y',
      name: 'Logo Y-Rotation (360°)',
      targetId: 'Aardvark Vector Logo 3D',
      property: 'transform.rotation.y',
      keyframes: [
        { time: 0.0, value: 0, easing: 'easeInOutQuad' },
        { time: 2.5, value: 180, easing: 'easeInOutQuad' },
        { time: 5.0, value: 360, easing: 'easeInOutQuad' }
      ]
    });

    this.tracks.push({
      id: 'track_logo_pos_y',
      name: 'Logo Floating Bob (Y)',
      targetId: 'Aardvark Vector Logo 3D',
      property: 'transform.position.y',
      keyframes: [
        { time: 0.0, value: 0.8, easing: 'easeInOutQuad' },
        { time: 2.5, value: 1.15, easing: 'easeInOutQuad' },
        { time: 5.0, value: 0.8, easing: 'easeInOutQuad' }
      ]
    });

    // 2. Camera Dolly / Focus Pull Track
    this.tracks.push({
      id: 'track_camera_focus',
      name: 'Cinematic Rack Focus Distance',
      targetId: 'camera',
      property: 'camera.focusDistance',
      keyframes: [
        { time: 0.0, value: 4.5, easing: 'easeInOutCubic' },
        { time: 2.5, value: 2.2, easing: 'easeInOutCubic' },
        { time: 5.0, value: 4.5, easing: 'easeInOutCubic' }
      ]
    });

    // 3. Ring Rotation
    this.tracks.push({
      id: 'track_ring_rot',
      name: 'Glass Ring Orbit',
      targetId: 'Frosted Glass Ring',
      property: 'transform.rotation.z',
      keyframes: [
        { time: 0.0, value: 0, easing: 'linear' },
        { time: 5.0, value: 360, easing: 'linear' }
      ]
    });
  }
}
