import { Vec3, Color } from '../core/math';
import { Transform } from '../core/transform';
import { Geometry } from '../mesh/Geometry';

export interface Particle {
  position: Vec3;
  velocity: Vec3;
  acceleration: Vec3;
  color: Color;
  size: number;
  life: number;
  maxLife: number;
  rotation: number;
  rotationSpeed: number;
}

export class ParticleEmitter {
  public id: string;
  public name: string;
  public transform: Transform;
  public maxParticles: number;
  public emissionRate: number; // particles per second
  public lifetime: number;     // seconds
  public speed: number;
  public spread: number;       // cone spread angle
  public gravity: Vec3;
  public turbulence: number;
  public startSize: number;
  public endSize: number;
  public startColor: Color;
  public endColor: Color;
  public isEmitting: boolean;

  private particles: Particle[] = [];
  private emitAccumulator: number = 0;
  private geometry: Geometry;

  constructor(maxParticles: number = 1000) {
    this.id = 'emitter_' + Math.random().toString(36).substring(2, 9);
    this.name = 'Particle Spark Emitter';
    this.transform = new Transform();
    this.maxParticles = maxParticles;
    this.emissionRate = 80;
    this.lifetime = 2.5;
    this.speed = 1.5;
    this.spread = 0.5;
    this.gravity = new Vec3(0, -0.4, 0);
    this.turbulence = 0.8;
    this.startSize = 0.08;
    this.endSize = 0.01;
    this.startColor = new Color(1.0, 0.7, 0.2, 1.0); // Gold/Orange
    this.endColor = new Color(1.0, 0.1, 0.3, 0.0);   // Crimson fade
    this.isEmitting = true;

    // Create particle instance buffer
    this.geometry = new Geometry(
      new Float32Array(maxParticles * 3),
      new Float32Array(maxParticles * 3),
      new Float32Array(maxParticles * 2),
      undefined,
      undefined,
      new Float32Array(maxParticles * 4)
    );
  }

  update(dt: number, time: number): void {
    const emitterPos = this.transform.getWorldPosition();

    // 1. Emit new particles
    if (this.isEmitting) {
      this.emitAccumulator += dt * this.emissionRate;
      while (this.emitAccumulator >= 1.0 && this.particles.length < this.maxParticles) {
        this.emitAccumulator -= 1.0;
        this.emitSingle(emitterPos);
      }
    }

    // 2. Update existing particles
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;

      if (p.life <= 0) {
        this.particles.splice(i, 1);
        continue;
      }

      // Turbulence noise
      if (this.turbulence > 0) {
        const noiseX = Math.sin(p.position.x * 3.0 + time * 2.0) * this.turbulence;
        const noiseY = Math.cos(p.position.y * 3.0 + time * 2.0) * this.turbulence;
        const noiseZ = Math.sin(p.position.z * 3.0 + time * 1.5) * this.turbulence;
        p.velocity.x += noiseX * dt;
        p.velocity.y += noiseY * dt;
        p.velocity.z += noiseZ * dt;
      }

      // Gravity & Velocity
      p.velocity.x += this.gravity.x * dt;
      p.velocity.y += this.gravity.y * dt;
      p.velocity.z += this.gravity.z * dt;

      p.position.x += p.velocity.x * dt;
      p.position.y += p.velocity.y * dt;
      p.position.z += p.velocity.z * dt;

      p.rotation += p.rotationSpeed * dt;

      // Color and size interpolation over life
      const t = 1.0 - p.life / p.maxLife; // 0 -> 1
      p.color.r = this.startColor.r + (this.endColor.r - this.startColor.r) * t;
      p.color.g = this.startColor.g + (this.endColor.g - this.startColor.g) * t;
      p.color.b = this.startColor.b + (this.endColor.b - this.startColor.b) * t;
      p.color.a = this.startColor.a + (this.endColor.a - this.startColor.a) * t;
      p.size = this.startSize + (this.endSize - this.startSize) * t;
    }

    // 3. Update geometry buffer
    this.syncGeometryBuffers();
  }

  private emitSingle(pos: Vec3): void {
    const theta = Math.random() * Math.PI * 2;
    const phi = (Math.random() - 0.5) * this.spread;
    const speed = this.speed * (0.7 + Math.random() * 0.6);

    const vx = Math.cos(theta) * Math.cos(phi) * speed;
    const vy = Math.abs(Math.sin(phi) * speed) + this.speed * 0.5; // upward bias
    const vz = Math.sin(theta) * Math.cos(phi) * speed;

    this.particles.push({
      position: pos.clone().add(new Vec3(
        (Math.random() - 0.5) * 0.2,
        (Math.random() - 0.5) * 0.2,
        (Math.random() - 0.5) * 0.2
      )),
      velocity: new Vec3(vx, vy, vz),
      acceleration: new Vec3(0, 0, 0),
      color: this.startColor.clone(),
      size: this.startSize,
      life: this.lifetime * (0.8 + Math.random() * 0.4),
      maxLife: this.lifetime,
      rotation: Math.random() * Math.PI * 2,
      rotationSpeed: (Math.random() - 0.5) * 4.0
    });
  }

  private syncGeometryBuffers(): void {
    const count = this.particles.length;
    const pos = this.geometry.positions;
    const col = this.geometry.colors;

    for (let i = 0; i < count; i++) {
      const p = this.particles[i];
      pos[i * 3] = p.position.x;
      pos[i * 3 + 1] = p.position.y;
      pos[i * 3 + 2] = p.position.z;

      col[i * 4] = p.color.r;
      col[i * 4 + 1] = p.color.g;
      col[i * 4 + 2] = p.color.b;
      col[i * 4 + 3] = p.color.a;
    }
    this.geometry.isDirty = true;
  }

  get activeParticles(): Particle[] {
    return this.particles;
  }

  get particleGeometry(): Geometry {
    return this.geometry;
  }
}
