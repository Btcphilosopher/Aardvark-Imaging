import { Scene } from '../scene/Scene';
import { SceneNode, NodeType } from '../scene/SceneNode';

export class Exporter {
  // Export canvas image to downloadable Data URL or Trigger browser download
  static exportImage(canvas: HTMLCanvasElement, filename: string = 'aardvark_render.png', format: 'image/png' | 'image/jpeg' | 'image/webp' = 'image/png'): void {
    const dataUrl = canvas.toDataURL(format, 0.95);
    const link = document.createElement('a');
    link.download = filename;
    link.href = dataUrl;
    link.click();
  }

  // Export scene hierarchy and geometry to standard OBJ + MTL format
  static exportSceneToOBJ(scene: Scene): string {
    let obj = `# Aardvark Imaging 3D Engine OBJ Export\n# Scene: ${scene.name}\n\n`;
    let vertexOffset = 1;

    scene.traverse((node: SceneNode) => {
      if (!node.geometry || !node.visible) return;

      const geom = node.geometry;
      const pos = geom.positions;
      const norm = geom.normals;
      const uv = geom.uvs;
      const ind = geom.indices;
      const worldMat = node.transform.worldMatrix;

      obj += `o ${node.name.replace(/\s+/g, '_')}\n`;

      // Vertices with world transform
      for (let i = 0; i < pos.length; i += 3) {
        const x = pos[i], y = pos[i + 1], z = pos[i + 2];
        const e = worldMat.elements;
        const wx = e[0] * x + e[4] * y + e[8] * z + e[12];
        const wy = e[1] * x + e[5] * y + e[9] * z + e[13];
        const wz = e[2] * x + e[6] * y + e[10] * z + e[14];
        obj += `v ${wx.toFixed(5)} ${wy.toFixed(5)} ${wz.toFixed(5)}\n`;
      }

      // Normals
      for (let i = 0; i < norm.length; i += 3) {
        obj += `vn ${norm[i].toFixed(4)} ${norm[i + 1].toFixed(4)} ${norm[i + 2].toFixed(4)}\n`;
      }

      // UVs
      for (let i = 0; i < uv.length; i += 2) {
        obj += `vt ${uv[i].toFixed(4)} ${uv[i + 1].toFixed(4)}\n`;
      }

      // Faces
      const triCount = ind.length > 0 ? ind.length / 3 : pos.length / 9;
      for (let i = 0; i < triCount; i++) {
        const i0 = (ind.length > 0 ? ind[i * 3] : i * 3) + vertexOffset;
        const i1 = (ind.length > 0 ? ind[i * 3 + 1] : i * 3 + 1) + vertexOffset;
        const i2 = (ind.length > 0 ? ind[i * 3 + 2] : i * 3 + 2) + vertexOffset;
        obj += `f ${i0}/${i0}/${i0} ${i1}/${i1}/${i1} ${i2}/${i2}/${i2}\n`;
      }

      vertexOffset += pos.length / 3;
      obj += '\n';
    });

    return obj;
  }

  // Serialize scene into JSON
  static exportSceneToJSON(scene: Scene): string {
    const serializeNode = (node: SceneNode): any => {
      return {
        id: node.id,
        name: node.name,
        type: node.type,
        visible: node.visible,
        is3D: node.is3D,
        svgPathString: node.svgPathString,
        textString: node.textString,
        extrudeOptions: node.extrudeOptions,
        textOptions: node.textOptions,
        transform: {
          position: [node.transform.position.x, node.transform.position.y, node.transform.position.z],
          rotation: [node.transform.rotation.x, node.transform.rotation.y, node.transform.rotation.z],
          scale: [node.transform.scale.x, node.transform.scale.y, node.transform.scale.z]
        },
        materials: node.materials.map((m) => ({
          name: m.name,
          baseColor: [m.baseColor.r, m.baseColor.g, m.baseColor.b],
          metallic: m.metallic,
          roughness: m.roughness,
          transmission: m.transmission,
          clearcoat: m.clearcoat,
          emission: [m.emission.r, m.emission.g, m.emission.b],
          emissionIntensity: m.emissionIntensity
        })),
        children: node.children.map(serializeNode)
      };
    };

    const doc = {
      version: '1.0.0',
      engine: 'Aardvark Imaging 3D',
      name: scene.name,
      camera: {
        position: [scene.activeCamera.transform.position.x, scene.activeCamera.transform.position.y, scene.activeCamera.transform.position.z],
        fov: scene.activeCamera.fov,
        focalLength: scene.activeCamera.focalLength,
        focusDistance: scene.activeCamera.focusDistance,
        fStop: scene.activeCamera.fStop,
        dofEnabled: scene.activeCamera.dofEnabled
      },
      root: serializeNode(scene.root)
    };

    return JSON.stringify(doc, null, 2);
  }
}
