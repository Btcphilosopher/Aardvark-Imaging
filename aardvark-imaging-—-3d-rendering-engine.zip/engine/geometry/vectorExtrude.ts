import earcut from 'earcut';
import { Geometry, Submesh } from '../mesh/Geometry';
import { Vec2, Vec3 } from '../core/math';

export interface ExtrudeOptions {
  depth?: number;
  bevelEnabled?: boolean;
  bevelThickness?: number;
  bevelSize?: number;
  bevelOffset?: number;
  bevelSegments?: number;
  frontCap?: boolean;
  backCap?: boolean;
}

export interface Path2DContour {
  points: Vec2[];
  isHole?: boolean;
}

export interface VectorShape {
  contours: Path2DContour[];
}

/**
 * Parse an SVG path data string ("M 10 20 C ... Z") into 2D polygon contours with bezier curve sampling
 */
export function parseSvgPath(pathStr: string, curveSubdivisions: number = 16): VectorShape {
  const contours: Path2DContour[] = [];
  let currentPoints: Vec2[] = [];
  let currentPos = new Vec2(0, 0);
  let startPos = new Vec2(0, 0);

  // Command regex tokenizer
  const cmdRegex = /([a-df-z])([^a-df-z]*)/gi;
  let match;

  while ((match = cmdRegex.exec(pathStr)) !== null) {
    const cmd = match[1];
    const args = match[2]
      .trim()
      .split(/[\s,]+/)
      .filter((s) => s.length > 0)
      .map(Number);

    const isRelative = cmd === cmd.toLowerCase();
    const type = cmd.toUpperCase();

    switch (type) {
      case 'M': {
        for (let i = 0; i < args.length; i += 2) {
          let x = args[i];
          let y = args[i + 1];
          if (isRelative) {
            x += currentPos.x;
            y += currentPos.y;
          }
          currentPos.set(x, y);
          if (i === 0) {
            if (currentPoints.length > 2) {
              contours.push({ points: currentPoints });
            }
            currentPoints = [currentPos.clone()];
            startPos.copy(currentPos);
          } else {
            currentPoints.push(currentPos.clone());
          }
        }
        break;
      }
      case 'L': {
        for (let i = 0; i < args.length; i += 2) {
          let x = args[i];
          let y = args[i + 1];
          if (isRelative) {
            x += currentPos.x;
            y += currentPos.y;
          }
          currentPos.set(x, y);
          currentPoints.push(currentPos.clone());
        }
        break;
      }
      case 'H': {
        for (let i = 0; i < args.length; i++) {
          let x = args[i];
          if (isRelative) x += currentPos.x;
          currentPos.x = x;
          currentPoints.push(currentPos.clone());
        }
        break;
      }
      case 'V': {
        for (let i = 0; i < args.length; i++) {
          let y = args[i];
          if (isRelative) y += currentPos.y;
          currentPos.y = y;
          currentPoints.push(currentPos.clone());
        }
        break;
      }
      case 'C': {
        // Cubic bezier: cp1x, cp1y, cp2x, cp2y, endx, endy
        for (let i = 0; i < args.length; i += 6) {
          let p1x = args[i], p1y = args[i + 1];
          let p2x = args[i + 2], p2y = args[i + 3];
          let p3x = args[i + 4], p3y = args[i + 5];

          if (isRelative) {
            p1x += currentPos.x; p1y += currentPos.y;
            p2x += currentPos.x; p2y += currentPos.y;
            p3x += currentPos.x; p3y += currentPos.y;
          }

          const p0 = currentPos.clone();
          const p1 = new Vec2(p1x, p1y);
          const p2 = new Vec2(p2x, p2y);
          const p3 = new Vec2(p3x, p3y);

          for (let step = 1; step <= curveSubdivisions; step++) {
            const t = step / curveSubdivisions;
            const t2 = t * t;
            const t3 = t2 * t;
            const mt = 1 - t;
            const mt2 = mt * mt;
            const mt3 = mt2 * mt;

            const x = mt3 * p0.x + 3 * mt2 * t * p1.x + 3 * mt * t2 * p2.x + t3 * p3.x;
            const y = mt3 * p0.y + 3 * mt2 * t * p1.y + 3 * mt * t2 * p2.y + t3 * p3.y;
            currentPoints.push(new Vec2(x, y));
          }
          currentPos.set(p3x, p3y);
        }
        break;
      }
      case 'Q': {
        // Quadratic bezier: cpx, cpy, endx, endy
        for (let i = 0; i < args.length; i += 4) {
          let p1x = args[i], p1y = args[i + 1];
          let p2x = args[i + 2], p2y = args[i + 3];

          if (isRelative) {
            p1x += currentPos.x; p1y += currentPos.y;
            p2x += currentPos.x; p2y += currentPos.y;
          }

          const p0 = currentPos.clone();
          const p1 = new Vec2(p1x, p1y);
          const p2 = new Vec2(p2x, p2y);

          for (let step = 1; step <= curveSubdivisions; step++) {
            const t = step / curveSubdivisions;
            const mt = 1 - t;
            const x = mt * mt * p0.x + 2 * mt * t * p1.x + t * t * p2.x;
            const y = mt * mt * p0.y + 2 * mt * t * p1.y + t * t * p2.y;
            currentPoints.push(new Vec2(x, y));
          }
          currentPos.set(p2x, p2y);
        }
        break;
      }
      case 'Z': {
        if (currentPoints.length > 0 && (currentPos.x !== startPos.x || currentPos.y !== startPos.y)) {
          currentPoints.push(startPos.clone());
        }
        if (currentPoints.length > 2) {
          contours.push({ points: currentPoints });
        }
        currentPoints = [];
        currentPos.copy(startPos);
        break;
      }
    }
  }

  if (currentPoints.length > 2) {
    contours.push({ points: currentPoints });
  }

  // Determine hole classification by winding area
  contours.forEach((c) => {
    let area = 0;
    const pts = c.points;
    for (let i = 0; i < pts.length; i++) {
      const j = (i + 1) % pts.length;
      area += pts[i].x * pts[j].y - pts[j].x * pts[i].y;
    }
    c.isHole = area < 0; // Clockwise vs Counter-Clockwise
  });

  return { contours };
}

/**
 * Extrudes a 2D Vector Shape into a 3D Mesh with Bevels, caps, and material slots
 */
export function extrudeVectorShape(shape: VectorShape, options: ExtrudeOptions = {}): Geometry {
  const depth = options.depth ?? 0.5;
  const bevelEnabled = options.bevelEnabled ?? true;
  const bevelThickness = bevelEnabled ? (options.bevelThickness ?? 0.05) : 0;
  const bevelSize = bevelEnabled ? (options.bevelSize ?? 0.05) : 0;
  const bevelSegments = bevelEnabled ? Math.max(1, options.bevelSegments ?? 3) : 0;
  const frontCap = options.frontCap ?? true;
  const backCap = options.backCap ?? true;

  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];
  const submeshes: Submesh[] = [];

  // Filter valid contours
  const validContours = shape.contours.filter((c) => c.points.length >= 3);
  if (validContours.length === 0) {
    return new Geometry();
  }

  // Flatten for Earcut triangulation
  const earcutData: number[] = [];
  const holeIndices: number[] = [];

  // Find outer contour (positive area or largest)
  let outerContourIndex = 0;
  let maxArea = -Infinity;
  validContours.forEach((c, idx) => {
    let area = 0;
    for (let i = 0; i < c.points.length; i++) {
      const j = (i + 1) % c.points.length;
      area += c.points[i].x * c.points[j].y - c.points[j].x * c.points[i].y;
    }
    if (Math.abs(area) > maxArea) {
      maxArea = Math.abs(area);
      outerContourIndex = idx;
    }
  });

  const orderedContours = [
    validContours[outerContourIndex],
    ...validContours.filter((_, idx) => idx !== outerContourIndex)
  ];

  orderedContours.forEach((c, idx) => {
    if (idx > 0) {
      holeIndices.push(earcutData.length / 2);
    }
    for (const pt of c.points) {
      earcutData.push(pt.x, pt.y);
    }
  });

  // Triangulate 2D polygon with holes
  const cap2dIndices = earcut(earcutData, holeIndices, 2);

  const halfDepth = depth / 2;
  const zFront = halfDepth;
  const zBack = -halfDepth;

  // 1. FRONT CAP (Material Slot 0)
  const frontCapStartIndex = indices.length;
  if (frontCap) {
    const frontVertStart = positions.length / 3;
    const count2D = earcutData.length / 2;

    for (let i = 0; i < count2D; i++) {
      const x = earcutData[i * 2];
      const y = earcutData[i * 2 + 1];
      positions.push(x, y, zFront);
      normals.push(0, 0, 1);
      uvs.push(x, y);
    }

    for (let i = 0; i < cap2dIndices.length; i += 3) {
      indices.push(
        frontVertStart + cap2dIndices[i],
        frontVertStart + cap2dIndices[i + 1],
        frontVertStart + cap2dIndices[i + 2]
      );
    }

    submeshes.push({
      start: frontCapStartIndex,
      count: indices.length - frontCapStartIndex,
      materialIndex: 0 // Front Material
    });
  }

  // 2. BACK CAP (Material Slot 2)
  const backCapStartIndex = indices.length;
  if (backCap) {
    const backVertStart = positions.length / 3;
    const count2D = earcutData.length / 2;

    for (let i = 0; i < count2D; i++) {
      const x = earcutData[i * 2];
      const y = earcutData[i * 2 + 1];
      positions.push(x, y, zBack);
      normals.push(0, 0, -1);
      uvs.push(x, y);
    }

    for (let i = 0; i < cap2dIndices.length; i += 3) {
      // Reversed winding for back facing
      indices.push(
        backVertStart + cap2dIndices[i + 2],
        backVertStart + cap2dIndices[i + 1],
        backVertStart + cap2dIndices[i]
      );
    }

    submeshes.push({
      start: backCapStartIndex,
      count: indices.length - backCapStartIndex,
      materialIndex: 2 // Back Material
    });
  }

  // 3. SIDE WALLS & BEVELS (Material Slot 1)
  const sideStartIndex = indices.length;

  for (const contour of orderedContours) {
    const pts = contour.points;
    const numPts = pts.length;

    // Steps along z / bevel profile
    const zSteps: { z: number; scaleOffset: number }[] = [];

    if (bevelEnabled && bevelSegments > 0) {
      // Front bevel
      for (let s = 0; s <= bevelSegments; s++) {
        const t = s / bevelSegments;
        const angle = (t * Math.PI) / 2;
        const bz = zFront - bevelThickness * (1 - Math.sin(angle));
        const bo = -bevelSize * (1 - Math.cos(angle));
        zSteps.push({ z: bz, scaleOffset: bo });
      }
      // Back bevel
      for (let s = bevelSegments; s >= 0; s--) {
        const t = s / bevelSegments;
        const angle = (t * Math.PI) / 2;
        const bz = zBack + bevelThickness * (1 - Math.sin(angle));
        const bo = -bevelSize * (1 - Math.cos(angle));
        zSteps.push({ z: bz, scaleOffset: bo });
      }
    } else {
      zSteps.push({ z: zFront, scaleOffset: 0 });
      zSteps.push({ z: zBack, scaleOffset: 0 });
    }

    const ringStartIndices: number[] = [];

    for (let step = 0; step < zSteps.length; step++) {
      const curStep = zSteps[step];
      const ringStart = positions.length / 3;
      ringStartIndices.push(ringStart);

      for (let i = 0; i < numPts; i++) {
        const p = pts[i];
        // Outward normal in 2D
        const prev = pts[(i - 1 + numPts) % numPts];
        const next = pts[(i + 1) % numPts];
        const dir = new Vec2(next.x - prev.x, next.y - prev.y).normalize();
        const norm2D = new Vec2(-dir.y, dir.x);

        const vx = p.x + norm2D.x * curStep.scaleOffset;
        const vy = p.y + norm2D.y * curStep.scaleOffset;
        const vz = curStep.z;

        positions.push(vx, vy, vz);
        normals.push(norm2D.x, norm2D.y, 0);
        uvs.push(i / numPts, step / (zSteps.length - 1));
      }
    }

    // Connect rings with quads
    for (let step = 0; step < zSteps.length - 1; step++) {
      const ringA = ringStartIndices[step];
      const ringB = ringStartIndices[step + 1];

      for (let i = 0; i < numPts; i++) {
        const nextI = (i + 1) % numPts;

        const a = ringA + i;
        const b = ringB + i;
        const c = ringB + nextI;
        const d = ringA + nextI;

        indices.push(a, b, d);
        indices.push(b, c, d);
      }
    }
  }

  submeshes.push({
    start: sideStartIndex,
    count: indices.length - sideStartIndex,
    materialIndex: 1 // Side / Bevel Material
  });

  const geom = new Geometry(
    new Float32Array(positions),
    new Float32Array(normals),
    new Float32Array(uvs),
    new Uint32Array(indices)
  );
  geom.submeshes = submeshes;
  geom.computeNormals();
  geom.computeTangents();
  return geom;
}
