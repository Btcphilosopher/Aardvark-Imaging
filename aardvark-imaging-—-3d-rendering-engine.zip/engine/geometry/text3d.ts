import { Geometry } from '../mesh/Geometry';
import { parseSvgPath, extrudeVectorShape, ExtrudeOptions } from './vectorExtrude';

// Standard high-precision vector glyph paths for ASCII characters and brand logos
export const GLYPH_PATHS: Record<string, string> = {
  A: 'M 0 0 L 0.35 1 L 0.65 1 L 1 0 L 0.75 0 L 0.6 0.45 L 0.4 0.45 L 0.25 0 Z M 0.45 0.6 L 0.55 0.6 L 0.5 0.85 Z',
  B: 'M 0 0 L 0.6 0 C 0.85 0 0.95 0.15 0.95 0.3 C 0.95 0.42 0.85 0.5 0.7 0.52 C 0.88 0.55 0.98 0.68 0.98 0.8 C 0.98 0.95 0.85 1 0.6 1 L 0 1 Z M 0.25 0.2 L 0.55 0.2 C 0.68 0.2 0.72 0.28 0.72 0.38 C 0.72 0.48 0.65 0.55 0.5 0.55 L 0.25 0.55 Z M 0.25 0.68 L 0.58 0.68 C 0.7 0.68 0.75 0.75 0.75 0.83 C 0.75 0.9 0.7 0.95 0.55 0.95 L 0.25 0.95 Z',
  C: 'M 0.95 0.25 C 0.85 0.08 0.68 0 0.5 0 C 0.22 0 0 0.22 0 0.5 C 0 0.78 0.22 1 0.5 1 C 0.7 1 0.86 0.9 0.95 0.75 L 0.72 0.65 C 0.68 0.75 0.6 0.8 0.5 0.8 C 0.33 0.8 0.22 0.68 0.22 0.5 C 0.22 0.32 0.33 0.2 0.5 0.2 C 0.6 0.2 0.68 0.25 0.72 0.35 Z',
  D: 'M 0 0 L 0.5 0 C 0.8 0 1 0.22 1 0.5 C 1 0.78 0.8 1 0.5 1 L 0 1 Z M 0.25 0.2 L 0.48 0.2 C 0.68 0.2 0.75 0.32 0.75 0.5 C 0.75 0.68 0.68 0.8 0.48 0.8 L 0.25 0.8 Z',
  E: 'M 0 0 L 0.9 0 L 0.9 0.2 L 0.25 0.2 L 0.25 0.42 L 0.8 0.42 L 0.8 0.6 L 0.25 0.6 L 0.25 0.8 L 0.9 0.8 L 0.9 1 L 0 1 Z',
  F: 'M 0 0 L 0.9 0 L 0.9 0.2 L 0.25 0.2 L 0.25 0.45 L 0.8 0.45 L 0.8 0.65 L 0.25 0.65 L 0.25 1 L 0 1 Z',
  G: 'M 0.95 0.25 C 0.85 0.08 0.68 0 0.5 0 C 0.22 0 0 0.22 0 0.5 C 0 0.78 0.22 1 0.5 1 C 0.75 1 0.92 0.85 0.95 0.6 L 0.5 0.6 L 0.5 0.42 L 0.95 0.42 L 0.95 0.25 C 0.95 0.25 0.95 0.25 0.95 0.25 Z',
  H: 'M 0 0 L 0.25 0 L 0.25 0.42 L 0.75 0.42 L 0.75 0 L 1 0 L 1 1 L 0.75 1 L 0.75 0.62 L 0.25 0.62 L 0.25 1 L 0 1 Z',
  I: 'M 0 0 L 0.3 0 L 0.3 1 L 0 1 Z',
  J: 'M 0.4 0 C 0.2 0 0.05 0.1 0 0.25 L 0.2 0.38 C 0.25 0.3 0.32 0.2 0.42 0.2 C 0.52 0.2 0.6 0.28 0.6 0.4 L 0.6 1 L 0.85 1 L 0.85 0.4 C 0.85 0.18 0.68 0 0.4 0 Z',
  K: 'M 0 0 L 0.25 0 L 0.25 0.4 L 0.65 0 L 0.95 0 L 0.5 0.52 L 0.98 1 L 0.68 1 L 0.35 0.65 L 0.25 0.75 L 0.25 1 L 0 1 Z',
  L: 'M 0 0 L 0.25 0 L 0.25 0.8 L 0.85 0.8 L 0.85 1 L 0 1 Z',
  M: 'M 0 0 L 0.25 0 L 0.5 0.65 L 0.75 0 L 1 0 L 1 1 L 0.8 1 L 0.8 0.3 L 0.6 0.85 L 0.4 0.85 L 0.2 0.3 L 0.2 1 L 0 1 Z',
  N: 'M 0 0 L 0.25 0 L 0.75 0.75 L 0.75 0 L 1 0 L 1 1 L 0.75 1 L 0.25 0.25 L 0.25 1 L 0 1 Z',
  O: 'M 0.5 0 C 0.22 0 0 0.22 0 0.5 C 0 0.78 0.22 1 0.5 1 C 0.78 1 1 0.78 1 0.5 C 1 0.22 0.78 0 0.5 0 Z M 0.5 0.2 C 0.68 0.2 0.78 0.33 0.78 0.5 C 0.78 0.67 0.68 0.8 0.5 0.8 C 0.32 0.8 0.22 0.67 0.22 0.5 C 0.22 0.33 0.32 0.2 0.5 0.2 Z',
  P: 'M 0 0 L 0.6 0 C 0.85 0 0.98 0.15 0.98 0.35 C 0.98 0.55 0.85 0.7 0.6 0.7 L 0.25 0.7 L 0.25 1 L 0 1 Z M 0.25 0.2 L 0.55 0.2 C 0.68 0.2 0.75 0.28 0.75 0.42 C 0.75 0.55 0.68 0.6 0.55 0.6 L 0.25 0.6 Z',
  Q: 'M 0.5 0 C 0.22 0 0 0.22 0 0.5 C 0 0.78 0.22 1 0.5 1 C 0.65 1 0.78 0.92 0.88 0.8 L 1 1 L 1 0.75 L 0.9 0.68 C 0.96 0.62 1 0.56 1 0.5 C 1 0.22 0.78 0 0.5 0 Z M 0.5 0.2 C 0.68 0.2 0.78 0.33 0.78 0.5 C 0.78 0.67 0.68 0.8 0.5 0.8 C 0.32 0.8 0.22 0.67 0.22 0.5 C 0.22 0.33 0.32 0.2 0.5 0.2 Z',
  R: 'M 0 0 L 0.6 0 C 0.85 0 0.98 0.15 0.98 0.35 C 0.98 0.5 0.88 0.62 0.7 0.68 L 1 1 L 0.72 1 L 0.45 0.7 L 0.25 0.7 L 0.25 1 L 0 1 Z M 0.25 0.2 L 0.55 0.2 C 0.68 0.2 0.75 0.26 0.75 0.38 C 0.75 0.5 0.68 0.55 0.55 0.55 L 0.25 0.55 Z',
  S: 'M 0.85 0.22 C 0.75 0.08 0.62 0 0.45 0 C 0.22 0 0.05 0.12 0.05 0.3 C 0.05 0.48 0.2 0.55 0.42 0.6 C 0.65 0.65 0.75 0.72 0.75 0.8 C 0.75 0.88 0.65 0.95 0.5 0.95 C 0.35 0.95 0.25 0.88 0.18 0.75 L 0 0.85 C 0.1 1.02 0.28 1.1 0.5 1.1 C 0.75 1.1 0.98 0.95 0.98 0.75 C 0.98 0.55 0.8 0.48 0.55 0.42 C 0.35 0.38 0.25 0.32 0.25 0.25 C 0.25 0.18 0.35 0.12 0.45 0.12 C 0.58 0.12 0.68 0.18 0.75 0.28 Z',
  T: 'M 0 0 L 1 0 L 1 0.2 L 0.62 0.2 L 0.62 1 L 0.38 1 L 0.38 0.2 L 0 0.2 Z',
  U: 'M 0 0 L 0.25 0 L 0.25 0.65 C 0.25 0.78 0.35 0.85 0.5 0.85 C 0.65 0.85 0.75 0.78 0.75 0.65 L 0.75 0 L 1 0 L 1 0.65 C 1 0.88 0.8 1 0.5 1 C 0.2 1 0 0.88 0 0.65 Z',
  V: 'M 0 0 L 0.25 0 L 0.5 0.8 L 0.75 0 L 1 0 L 0.62 1 L 0.38 1 Z',
  W: 'M 0 0 L 0.2 0 L 0.35 0.7 L 0.5 0.25 L 0.65 0.7 L 0.8 0 L 1 0 L 0.8 1 L 0.6 1 L 0.5 0.55 L 0.4 1 L 0.2 1 Z',
  X: 'M 0 0 L 0.28 0 L 0.5 0.38 L 0.72 0 L 1 0 L 0.68 0.55 L 1 1 L 0.72 1 L 0.5 0.68 L 0.28 1 L 0 1 L 0.32 0.55 Z',
  Y: 'M 0 0 L 0.28 0 L 0.5 0.45 L 0.72 0 L 1 0 L 0.62 0.6 L 0.62 1 L 0.38 1 L 0.38 0.6 Z',
  Z: 'M 0 0 L 0.95 0 L 0.95 0.2 L 0.3 0.8 L 0.95 0.8 L 0.95 1 L 0 1 L 0 0.8 L 0.65 0.2 L 0 0.2 Z',
  '0': 'M 0.5 0 C 0.22 0 0 0.22 0 0.5 C 0 0.78 0.22 1 0.5 1 C 0.78 1 1 0.78 1 0.5 C 1 0.22 0.78 0 0.5 0 Z M 0.5 0.2 C 0.68 0.2 0.78 0.33 0.78 0.5 C 0.78 0.67 0.68 0.8 0.5 0.8 C 0.32 0.8 0.22 0.67 0.22 0.5 C 0.22 0.33 0.32 0.2 0.5 0.2 Z',
  '1': 'M 0.2 0.2 L 0.5 0 L 0.5 1 L 0.25 1 L 0.25 0.25 Z',
  '2': 'M 0.05 0.25 C 0.15 0.08 0.32 0 0.5 0 C 0.78 0 0.95 0.18 0.95 0.38 C 0.95 0.55 0.8 0.7 0.6 0.8 L 0.2 0.8 L 0.95 0.8 L 0.95 1 L 0 1 L 0 0.8 C 0.3 0.58 0.7 0.42 0.7 0.35 C 0.7 0.25 0.6 0.18 0.5 0.18 C 0.38 0.18 0.28 0.25 0.22 0.35 Z',
  '3': 'M 0.05 0.2 L 0.8 0.2 L 0.5 0.48 C 0.75 0.5 0.95 0.65 0.95 0.82 C 0.95 1 0.75 1.1 0.5 1.1 C 0.25 1.1 0.08 0.95 0 0.8 L 0.2 0.68 C 0.25 0.78 0.35 0.85 0.5 0.85 C 0.62 0.85 0.72 0.78 0.72 0.68 C 0.72 0.58 0.62 0.5 0.45 0.5 L 0.3 0.5 L 0.3 0.38 L 0.6 0.38 L 0.6 0.18 L 0.05 0.18 Z',
  '4': 'M 0.7 1 L 0.7 0.75 L 0 0.75 L 0.6 0 L 0.9 0 L 0.9 0.55 L 1 0.55 L 1 0.75 L 0.9 0.75 L 0.9 1 Z M 0.7 0.55 L 0.7 0.25 L 0.35 0.55 Z',
  '5': 'M 0.1 0 L 0.85 0 L 0.85 0.2 L 0.3 0.2 L 0.25 0.45 C 0.35 0.4 0.48 0.38 0.58 0.38 C 0.8 0.38 0.98 0.52 0.98 0.75 C 0.98 0.98 0.78 1.1 0.5 1.1 C 0.25 1.1 0.08 0.95 0 0.8 L 0.2 0.68 C 0.25 0.78 0.35 0.85 0.5 0.85 C 0.65 0.85 0.75 0.75 0.75 0.65 C 0.75 0.55 0.65 0.45 0.5 0.45 C 0.38 0.45 0.28 0.5 0.22 0.58 L 0.05 0.55 Z',
  '6': 'M 0.85 0.2 L 0.68 0.32 C 0.62 0.25 0.55 0.2 0.45 0.2 C 0.28 0.2 0.2 0.35 0.2 0.55 C 0.28 0.45 0.4 0.4 0.55 0.4 C 0.8 0.4 0.98 0.55 0.98 0.78 C 0.98 1 0.78 1.1 0.5 1.1 C 0.2 1.1 0 0.88 0 0.5 C 0 0.22 0.22 0 0.5 0 C 0.7 0 0.85 0.08 0.95 0.22 Z M 0.5 0.58 C 0.35 0.58 0.22 0.68 0.22 0.8 C 0.22 0.92 0.35 1.02 0.5 1.02 C 0.65 1.02 0.75 0.92 0.75 0.8 C 0.75 0.68 0.65 0.58 0.5 0.58 Z',
  '7': 'M 0 0 L 0.95 0 L 0.95 0.2 L 0.45 1 L 0.2 1 L 0.65 0.2 L 0 0.2 Z',
  '8': 'M 0.5 0 C 0.3 0 0.15 0.12 0.15 0.28 C 0.15 0.4 0.25 0.5 0.38 0.55 C 0.2 0.6 0.08 0.72 0.08 0.88 C 0.08 1.05 0.25 1.15 0.5 1.15 C 0.75 1.15 0.92 1.05 0.92 0.88 C 0.92 0.72 0.8 0.6 0.62 0.55 C 0.75 0.5 0.85 0.4 0.85 0.28 C 0.85 0.12 0.7 0 0.5 0 Z M 0.5 0.18 C 0.6 0.18 0.68 0.25 0.68 0.35 C 0.68 0.45 0.6 0.5 0.5 0.5 C 0.4 0.5 0.32 0.45 0.32 0.35 C 0.32 0.25 0.4 0.18 0.5 0.18 Z M 0.5 0.65 C 0.62 0.65 0.72 0.72 0.72 0.85 C 0.72 0.98 0.62 1.05 0.5 1.05 C 0.38 1.05 0.28 0.98 0.28 0.85 C 0.28 0.72 0.38 0.65 0.5 0.65 Z',
  '9': 'M 0.05 0.8 L 0.22 0.68 C 0.28 0.78 0.38 0.85 0.5 0.85 C 0.68 0.85 0.78 0.72 0.78 0.55 C 0.68 0.65 0.55 0.7 0.4 0.7 C 0.18 0.7 0 0.55 0 0.32 C 0 0.12 0.2 0 0.48 0 C 0.78 0 0.98 0.22 0.98 0.55 C 0.98 0.85 0.78 1.05 0.5 1.05 C 0.3 1.05 0.15 0.95 0.05 0.8 Z M 0.48 0.18 C 0.35 0.18 0.22 0.25 0.22 0.38 C 0.22 0.5 0.35 0.58 0.48 0.58 C 0.62 0.58 0.75 0.5 0.75 0.38 C 0.75 0.25 0.62 0.18 0.48 0.18 Z',
  ' ': '',
  '-': 'M 0 0.45 L 0.6 0.45 L 0.6 0.65 L 0 0.65 Z',
  '+': 'M 0.35 0.1 L 0.65 0.1 L 0.65 0.4 L 0.95 0.4 L 0.95 0.7 L 0.65 0.7 L 0.65 1 L 0.35 1 L 0.35 0.7 L 0.05 0.7 L 0.05 0.4 L 0.35 0.4 Z',
  '.': 'M 0 0.8 L 0.25 0.8 L 0.25 1 L 0 1 Z',
  '!': 'M 0.35 0 L 0.65 0 L 0.58 0.65 L 0.42 0.65 Z M 0.35 0.8 L 0.65 0.8 L 0.65 1 L 0.35 1 Z',
  // AARDVARK Brand Icon / Stylized Prism Logo
  AARDVARK_LOGO: 'M 0.5 0 L 1 0.9 L 0.8 1 L 0.5 0.35 L 0.2 1 L 0 0.9 Z M 0.5 0.5 L 0.7 0.9 L 0.3 0.9 Z'
};

export interface Text3DOptions extends ExtrudeOptions {
  fontSize?: number;
  tracking?: number; // letter spacing
  lineHeight?: number;
  alignment?: 'left' | 'center' | 'right';
}

/**
 * Creates 3D extruded typography geometry from text string
 */
export function create3DText(text: string, options: Text3DOptions = {}): Geometry {
  const fontSize = options.fontSize ?? 1.0;
  const tracking = options.tracking ?? 0.15;
  const uppercase = text.toUpperCase();

  const letterGeometries: Geometry[] = [];
  let currentX = 0;

  for (let i = 0; i < uppercase.length; i++) {
    const char = uppercase[i];
    if (char === ' ') {
      currentX += fontSize * 0.4 + tracking;
      continue;
    }

    const svgPath = GLYPH_PATHS[char] || GLYPH_PATHS['A'];
    if (!svgPath) {
      currentX += fontSize * 0.6 + tracking;
      continue;
    }

    const shape = parseSvgPath(svgPath, 8);
    // Scale and position the 2D contour points
    for (const contour of shape.contours) {
      for (const pt of contour.points) {
        // Invert Y to make top-up and normalize baseline
        pt.x = currentX + pt.x * fontSize;
        pt.y = (1.0 - pt.y) * fontSize;
      }
    }

    const glyphGeom = extrudeVectorShape(shape, options);
    letterGeometries.push(glyphGeom);

    currentX += fontSize * 0.75 + tracking;
  }

  // Merge all glyph geometries into one single unified Geometry
  return mergeGeometries(letterGeometries, options.alignment, currentX);
}

function mergeGeometries(geometries: Geometry[], alignment: 'left' | 'center' | 'right' = 'center', totalWidth: number): Geometry {
  if (geometries.length === 0) return new Geometry();

  let totalVerts = 0;
  let totalIndices = 0;

  for (const g of geometries) {
    totalVerts += g.positions.length;
    totalIndices += g.indices.length;
  }

  const positions = new Float32Array(totalVerts);
  const normals = new Float32Array(totalVerts);
  const uvs = new Float32Array((totalVerts / 3) * 2);
  const indices = new Uint32Array(totalIndices);

  let xOffset = 0;
  if (alignment === 'center') {
    xOffset = -totalWidth * 0.5;
  } else if (alignment === 'right') {
    xOffset = -totalWidth;
  }

  let vertOffset = 0;
  let idxOffset = 0;

  for (const g of geometries) {
    const baseVert = vertOffset / 3;

    for (let i = 0; i < g.positions.length; i += 3) {
      positions[vertOffset + i] = g.positions[i] + xOffset;
      positions[vertOffset + i + 1] = g.positions[i + 1];
      positions[vertOffset + i + 2] = g.positions[i + 2];

      normals[vertOffset + i] = g.normals[i];
      normals[vertOffset + i + 1] = g.normals[i + 1];
      normals[vertOffset + i + 2] = g.normals[i + 2];
    }

    const uvCount = (g.positions.length / 3) * 2;
    const baseUv = (vertOffset / 3) * 2;
    for (let i = 0; i < uvCount; i++) {
      uvs[baseUv + i] = g.uvs[i];
    }

    for (let i = 0; i < g.indices.length; i++) {
      indices[idxOffset + i] = baseVert + g.indices[i];
    }

    vertOffset += g.positions.length;
    idxOffset += g.indices.length;
  }

  const result = new Geometry(positions, normals, uvs, indices);
  result.computeBounds();
  result.computeTangents();
  return result;
}
