export interface CompositorSettings {
  exposure: number;       // EV: -3.0 to +3.0 (default: 0)
  contrast: number;       // 0.5 to 2.0 (default: 1.05)
  saturation: number;     // 0.0 (B&W) to 2.0 (default: 1.1)
  temperature: number;    // -1.0 (Cool/Blue) to +1.0 (Warm/Amber)
  bloomEnabled: boolean;
  bloomIntensity: number; // 0.0 to 1.5
  bloomThreshold: number; // 0.6 to 1.0
  bloomRadius: number;    // blur radius
  vignetteStrength: number; // 0.0 to 1.0
  chromaticAberration: number; // 0 to 10px
  filmGrain: number;      // 0.0 to 0.15
  dofPostEnabled: boolean;
  dofBlurRadius: number;
}

export class Compositor {
  public settings: CompositorSettings;
  private offscreenCanvas: HTMLCanvasElement | null = null;

  constructor() {
    this.settings = {
      exposure: 0.0,
      contrast: 1.05,
      saturation: 1.1,
      temperature: 0.05,
      bloomEnabled: true,
      bloomIntensity: 0.35,
      bloomThreshold: 0.75,
      bloomRadius: 12,
      vignetteStrength: 0.25,
      chromaticAberration: 1.5,
      filmGrain: 0.02,
      dofPostEnabled: false,
      dofBlurRadius: 4.0
    };
  }

  // Composite the rendered 3D image with 2D vector layers & post-processing effects
  composite(
    sourceCanvas: HTMLCanvasElement,
    targetCanvas: HTMLCanvasElement,
    vectorOverlayCanvas?: HTMLCanvasElement | null
  ): void {
    const w = targetCanvas.width;
    const h = targetCanvas.height;
    if (w === 0 || h === 0) return;

    const ctx = targetCanvas.getContext('2d');
    if (!ctx) return;

    if (!this.offscreenCanvas) {
      this.offscreenCanvas = document.createElement('canvas');
    }
    if (this.offscreenCanvas.width !== w || this.offscreenCanvas.height !== h) {
      this.offscreenCanvas.width = w;
      this.offscreenCanvas.height = h;
    }

    const offCtx = this.offscreenCanvas.getContext('2d');
    if (!offCtx) return;

    // 1. Draw base 3D render
    offCtx.clearRect(0, 0, w, h);
    offCtx.drawImage(sourceCanvas, 0, 0, w, h);

    // 2. Bloom Glow Pass
    if (this.settings.bloomEnabled && this.settings.bloomIntensity > 0) {
      offCtx.save();
      offCtx.globalCompositeOperation = 'screen';
      offCtx.filter = `blur(${this.settings.bloomRadius}px) brightness(1.2)`;
      offCtx.globalAlpha = this.settings.bloomIntensity;
      offCtx.drawImage(sourceCanvas, 0, 0, w, h);
      offCtx.restore();
    }

    // 3. 2D Vector Graphics Layer Overlay
    if (vectorOverlayCanvas) {
      offCtx.save();
      offCtx.globalCompositeOperation = 'source-over';
      offCtx.drawImage(vectorOverlayCanvas, 0, 0, w, h);
      offCtx.restore();
    }

    // 4. Pixel-level Color Grading & Optical Post-Processing
    const imgData = offCtx.getImageData(0, 0, w, h);
    const data = imgData.data;

    const expMultiplier = Math.pow(2.0, this.settings.exposure);
    const contrast = this.settings.contrast;
    const sat = this.settings.saturation;
    const temp = this.settings.temperature;
    const vignette = this.settings.vignetteStrength;
    const grain = this.settings.filmGrain;

    const halfW = w / 2;
    const halfH = h / 2;
    const maxDist = Math.sqrt(halfW * halfW + halfH * halfH);

    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const idx = (y * w + x) * 4;

        let r = data[idx] / 255;
        let g = data[idx + 1] / 255;
        let b = data[idx + 2] / 255;

        // Exposure
        r *= expMultiplier;
        g *= expMultiplier;
        b *= expMultiplier;

        // Temperature (Warm amber / Cool blue)
        if (temp > 0) {
          r += temp * 0.08;
          b -= temp * 0.05;
        } else if (temp < 0) {
          b += -temp * 0.08;
          r -= -temp * 0.05;
        }

        // Contrast: (col - 0.5) * contrast + 0.5
        r = (r - 0.5) * contrast + 0.5;
        g = (g - 0.5) * contrast + 0.5;
        b = (b - 0.5) * contrast + 0.5;

        // Saturation
        const luma = 0.2126 * r + 0.7152 * g + 0.0722 * b;
        r = luma + sat * (r - luma);
        g = luma + sat * (g - luma);
        b = luma + sat * (b - luma);

        // Vignette
        if (vignette > 0) {
          const dx = x - halfW;
          const dy = y - halfH;
          const dist = Math.sqrt(dx * dx + dy * dy) / maxDist;
          const vigFactor = 1.0 - dist * dist * vignette;
          r *= vigFactor;
          g *= vigFactor;
          b *= vigFactor;
        }

        // Film Grain
        if (grain > 0) {
          const noise = (Math.random() - 0.5) * grain;
          r += noise;
          g += noise;
          b += noise;
        }

        data[idx] = Math.floor(Math.min(1, Math.max(0, r)) * 255);
        data[idx + 1] = Math.floor(Math.min(1, Math.max(0, g)) * 255);
        data[idx + 2] = Math.floor(Math.min(1, Math.max(0, b)) * 255);
      }
    }

    // 5. Chromatic Aberration RGB channel split (if enabled)
    if (this.settings.chromaticAberration > 0) {
      const shift = Math.floor(this.settings.chromaticAberration);
      const copyData = new Uint8ClampedArray(data);
      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
          const idx = (y * w + x) * 4;
          const redX = Math.min(w - 1, x + shift);
          const blueX = Math.max(0, x - shift);
          data[idx] = copyData[(y * w + redX) * 4]; // shifted Red
          data[idx + 2] = copyData[(y * w + blueX) * 4 + 2]; // shifted Blue
        }
      }
    }

    ctx.putImageData(imgData, 0, 0);
  }
}
