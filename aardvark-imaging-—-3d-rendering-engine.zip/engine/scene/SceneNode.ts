import { Transform } from '../core/transform';
import { Geometry } from '../mesh/Geometry';
import { Material } from '../materials/Material';
import { Camera } from '../camera/Camera';
import { Light } from '../lights/Light';
import { ParticleEmitter } from '../particles/ParticleSystem';
import { VectorShape, ExtrudeOptions, extrudeVectorShape, parseSvgPath } from '../geometry/vectorExtrude';
import { create3DText, Text3DOptions } from '../geometry/text3d';

export enum NodeType {
  EMPTY = 'EMPTY',
  MESH = 'MESH',
  VECTOR_LAYER = 'VECTOR_LAYER',
  TEXT_3D = 'TEXT_3D',
  CAMERA = 'CAMERA',
  LIGHT = 'LIGHT',
  PARTICLES = 'PARTICLES',
  GROUP = 'GROUP'
}

export class SceneNode {
  public id: string;
  public name: string;
  public type: NodeType;
  public transform: Transform;
  public visible: boolean = true;
  public locked: boolean = false;

  public parent: SceneNode | null = null;
  public children: SceneNode[] = [];

  // Mesh & Materials
  public geometry: Geometry | null = null;
  public materials: Material[] = []; // Submesh or slot materials

  // Vector / 2D -> 3D properties
  public vectorShape: VectorShape | null = null;
  public svgPathString: string = '';
  public is3D: boolean = true; // When false, renders as flat 2D vector layer in compositor
  public extrudeOptions: ExtrudeOptions = {
    depth: 0.35,
    bevelEnabled: true,
    bevelThickness: 0.04,
    bevelSize: 0.04,
    bevelSegments: 3,
    frontCap: true,
    backCap: true
  };

  // 3D Text Typography properties
  public textString: string = '';
  public textOptions: Text3DOptions = {
    fontSize: 1.0,
    tracking: 0.1,
    depth: 0.35,
    bevelEnabled: true,
    bevelThickness: 0.04,
    bevelSize: 0.04,
    bevelSegments: 3
  };

  // Specific Node Subsystems
  public camera: Camera | null = null;
  public light: Light | null = null;
  public particleEmitter: ParticleEmitter | null = null;

  // Custom Metadata
  public meta: Record<string, any> = {};

  constructor(name: string = 'Node', type: NodeType = NodeType.MESH) {
    this.id = 'node_' + Math.random().toString(36).substring(2, 9);
    this.name = name;
    this.type = type;
    this.transform = new Transform();
  }

  addChild(child: SceneNode): this {
    if (child.parent) {
      child.parent.removeChild(child);
    }
    child.parent = this;
    this.children.push(child);
    return this;
  }

  removeChild(child: SceneNode): this {
    const idx = this.children.indexOf(child);
    if (idx !== -1) {
      child.parent = null;
      this.children.splice(idx, 1);
    }
    return this;
  }

  updateMatrices(): void {
    const parentMat = this.parent ? this.parent.transform.worldMatrix : undefined;
    this.transform.updateWorldMatrix(parentMat);

    if (this.camera) {
      this.camera.transform.worldMatrix.copy(this.transform.worldMatrix);
      this.camera.updateMatrices();
    }
    if (this.light) {
      this.light.transform.worldMatrix.copy(this.transform.worldMatrix);
      this.light.updateShadowMatrices();
    }
    if (this.particleEmitter) {
      this.particleEmitter.transform.worldMatrix.copy(this.transform.worldMatrix);
    }

    for (const child of this.children) {
      child.updateMatrices();
    }
  }

  rebuildVectorMesh(): void {
    if (this.type === NodeType.VECTOR_LAYER) {
      if (!this.vectorShape && this.svgPathString) {
        this.vectorShape = parseSvgPath(this.svgPathString, 12);
      }
      if (this.vectorShape) {
        if (this.is3D) {
          this.geometry = extrudeVectorShape(this.vectorShape, this.extrudeOptions);
        } else {
          // Flat 2D vector layer (0 depth)
          this.geometry = extrudeVectorShape(this.vectorShape, {
            ...this.extrudeOptions,
            depth: 0.001,
            bevelEnabled: false
          });
        }
      }
    } else if (this.type === NodeType.TEXT_3D) {
      if (this.textString) {
        this.geometry = create3DText(this.textString, this.textOptions);
      }
    }
  }
}
