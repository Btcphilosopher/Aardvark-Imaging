import { SceneNode, NodeType } from './SceneNode';
import { Camera, CameraType } from '../camera/Camera';
import { Light, LightType } from '../lights/Light';
import { Color, Vec3 } from '../core/math';
import { Material } from '../materials/Material';
import { Texture } from '../textures/Texture';
import { createCube, createSphere, createTorus, createCylinder, createPlane, createCapsule } from '../mesh/primitives';
import { GLYPH_PATHS } from '../geometry/text3d';

export class Scene {
  public id: string;
  public name: string;
  public root: SceneNode;
  public activeCamera: Camera;
  public environmentMap: Texture | null = null;
  public backgroundColor: Color;
  public ambientLightColor: Color;
  public ambientIntensity: number;

  constructor(name: string = 'Aardvark Composition') {
    this.id = 'scene_' + Math.random().toString(36).substring(2, 9);
    this.name = name;
    this.root = new SceneNode('Scene Root', NodeType.GROUP);
    this.backgroundColor = new Color(0.06, 0.07, 0.09, 1.0); // Deep charcoal
    this.ambientLightColor = new Color(0.2, 0.22, 0.28);
    this.ambientIntensity = 0.35;

    // Create Default Camera
    this.activeCamera = new Camera(CameraType.PERSPECTIVE);
    this.activeCamera.transform.setPosition(0, 1.8, 5.0);
    const camNode = new SceneNode('Main Cinematic Camera', NodeType.CAMERA);
    camNode.camera = this.activeCamera;
    camNode.transform = this.activeCamera.transform;
    this.root.addChild(camNode);
  }

  add(node: SceneNode): this {
    this.root.addChild(node);
    return this;
  }

  remove(node: SceneNode): this {
    this.root.removeChild(node);
    return this;
  }

  update(): void {
    this.root.updateMatrices();
  }

  findNodeById(id: string): SceneNode | null {
    let result: SceneNode | null = null;
    this.traverse((node) => {
      if (node.id === id) result = node;
    });
    return result;
  }

  traverse(callback: (node: SceneNode) => void): void {
    const stack: SceneNode[] = [this.root];
    while (stack.length > 0) {
      const current = stack.pop()!;
      callback(current);
      for (let i = current.children.length - 1; i >= 0; i--) {
        stack.push(current.children[i]);
      }
    }
  }

  getAllMeshes(): SceneNode[] {
    const list: SceneNode[] = [];
    this.traverse((n) => {
      if (n.visible && (n.geometry !== null || n.type === NodeType.VECTOR_LAYER || n.type === NodeType.TEXT_3D)) {
        list.push(n);
      }
    });
    return list;
  }

  getAllLights(): Light[] {
    const list: Light[] = [];
    this.traverse((n) => {
      if (n.visible && n.light) {
        list.push(n.light);
      }
    });
    return list;
  }

  // --- PRESET SCENE GENERATORS ---
  static createVectorShowcaseScene(): Scene {
    const scene = new Scene('Vector to 3D Extrusion Studio');
    scene.environmentMap = Texture.createStudioEnvironment(512, 256);

    // Key Light
    const keyLightNode = new SceneNode('Key Light', NodeType.LIGHT);
    const keyLight = new Light(LightType.DIRECTIONAL);
    keyLight.transform.setPosition(4, 7, 5);
    keyLight.intensity = 2.2;
    keyLight.color.set(1.0, 0.96, 0.9);
    keyLightNode.light = keyLight;
    keyLightNode.transform = keyLight.transform;
    scene.add(keyLightNode);

    // Fill Spot Light (Cyan accent)
    const fillLightNode = new SceneNode('Fill Light', NodeType.LIGHT);
    const fillLight = new Light(LightType.SPOT);
    fillLight.transform.setPosition(-5, 4, 3);
    fillLight.intensity = 2.5;
    fillLight.color.set(0.2, 0.8, 1.0);
    fillLightNode.light = fillLight;
    fillLightNode.transform = fillLight.transform;
    scene.add(fillLightNode);

    // Rim Point Light (Magenta accent)
    const rimLightNode = new SceneNode('Rim Light', NodeType.LIGHT);
    const rimLight = new Light(LightType.POINT);
    rimLight.transform.setPosition(0, 3, -4);
    rimLight.intensity = 3.0;
    rimLight.color.set(1.0, 0.2, 0.6);
    rimLightNode.light = rimLight;
    rimLightNode.transform = rimLight.transform;
    scene.add(rimLightNode);

    // Ground Shadow Stage Plane
    const ground = new SceneNode('Shadow Stage Floor', NodeType.MESH);
    ground.geometry = createPlane(16, 16, 1, 1);
    ground.transform.setPosition(0, -1.0, 0);
    ground.transform.setRotation(-90, 0, 0);
    ground.materials = [
      new Material({
        name: 'Studio Matte Floor',
        baseColor: new Color(0.12, 0.13, 0.16),
        metallic: 0.1,
        roughness: 0.4
      })
    ];
    scene.add(ground);

    // 1. AARDVARK 3D Logo (Vector Extrusion)
    const logoNode = new SceneNode('Aardvark Vector Logo 3D', NodeType.VECTOR_LAYER);
    logoNode.svgPathString = GLYPH_PATHS['AARDVARK_LOGO'];
    logoNode.transform.setPosition(-1.6, 0.8, 0);
    logoNode.transform.setScale(2.2, 2.2, 2.2);
    logoNode.extrudeOptions = {
      depth: 0.45,
      bevelEnabled: true,
      bevelThickness: 0.05,
      bevelSize: 0.05,
      bevelSegments: 4,
      frontCap: true,
      backCap: true
    };
    logoNode.rebuildVectorMesh();
    logoNode.materials = [
      Material.createGold(), // Front
      new Material({
        name: 'Dark Chrome Bevel',
        baseColor: new Color(0.2, 0.2, 0.25),
        metallic: 0.95,
        roughness: 0.15
      }), // Side/Bevel
      Material.createGold() // Back
    ];
    scene.add(logoNode);

    // 2. 3D Typography Layer
    const textNode = new SceneNode('Aardvark 3D Text', NodeType.TEXT_3D);
    textNode.textString = 'AARDVARK';
    textNode.textOptions = {
      fontSize: 0.55,
      tracking: 0.08,
      depth: 0.25,
      bevelEnabled: true,
      bevelThickness: 0.03,
      bevelSize: 0.03,
      bevelSegments: 3
    };
    textNode.transform.setPosition(0, -0.4, 0.5);
    textNode.rebuildVectorMesh();
    textNode.materials = [Material.createBrushedAluminum()];
    scene.add(textNode);

    // 3. Floating PBR Orbitals (Glass Torus + Obsidian Sphere + Copper Cylinder)
    const glassTorus = new SceneNode('Frosted Glass Ring', NodeType.MESH);
    glassTorus.geometry = createTorus(1.4, 0.12, 24, 48);
    glassTorus.transform.setPosition(1.8, 0.7, -0.5);
    glassTorus.transform.setRotation(35, 45, 0);
    glassTorus.materials = [Material.createFrostedGlass()];
    scene.add(glassTorus);

    const copperSphere = new SceneNode('Copper Orb', NodeType.MESH);
    copperSphere.geometry = createSphere(0.45, 32, 24);
    copperSphere.transform.setPosition(1.8, 0.7, -0.5);
    copperSphere.materials = [Material.createCopper()];
    scene.add(copperSphere);

    // Camera setup with Cinematic DoF
    scene.activeCamera.transform.setPosition(0, 1.2, 4.8);
    scene.activeCamera.dofEnabled = true;
    scene.activeCamera.focusDistance = 4.5;
    scene.activeCamera.fStop = 2.0;

    scene.update();
    return scene;
  }

  static createCinematicProductScene(): Scene {
    const scene = new Scene('Cinematic Product Showcase');
    scene.environmentMap = Texture.createStudioEnvironment(512, 256);

    // Lights
    const key = new SceneNode('Key Overhead', NodeType.LIGHT);
    const keyL = new Light(LightType.SPOT);
    keyL.transform.setPosition(0, 6, 2);
    keyL.intensity = 3.5;
    keyL.outerConeAngle = 55;
    key.light = keyL;
    key.transform = keyL.transform;
    scene.add(key);

    const blueRim = new SceneNode('Blue Rim Light', NodeType.LIGHT);
    const blueL = new Light(LightType.POINT);
    blueL.transform.setPosition(-3, 2, -2);
    blueL.color.set(0.0, 0.7, 1.0);
    blueL.intensity = 2.8;
    blueRim.light = blueL;
    blueRim.transform = blueL.transform;
    scene.add(blueRim);

    // Podium
    const podium = new SceneNode('Cylindrical Podium', NodeType.MESH);
    podium.geometry = createCylinder(1.5, 1.5, 0.4, 48);
    podium.transform.setPosition(0, -0.6, 0);
    podium.materials = [Material.createObsidian()];
    scene.add(podium);

    // Central Hero Artifact (Capsule + Torus + Text)
    const capsule = new SceneNode('Hero Core Capsule', NodeType.MESH);
    capsule.geometry = createCapsule(0.35, 0.8, 16, 32);
    capsule.transform.setPosition(0, 0.5, 0);
    capsule.materials = [Material.createHologram()];
    scene.add(capsule);

    const outerRing = new SceneNode('Gimbal Ring 1', NodeType.MESH);
    outerRing.geometry = createTorus(0.9, 0.04, 16, 48);
    outerRing.transform.setPosition(0, 0.5, 0);
    outerRing.transform.setRotation(45, 30, 0);
    outerRing.materials = [Material.createGold()];
    scene.add(outerRing);

    const text3d = new SceneNode('Product Badge', NodeType.TEXT_3D);
    text3d.textString = 'CINEMA 3D';
    text3d.textOptions = { fontSize: 0.35, depth: 0.15, bevelEnabled: true };
    text3d.transform.setPosition(0, -0.2, 1.2);
    text3d.rebuildVectorMesh();
    text3d.materials = [Material.createNeonEmission('#00E5FF', 2.0)];
    scene.add(text3d);

    scene.activeCamera.transform.setPosition(0, 1.0, 3.8);
    scene.activeCamera.dofEnabled = true;
    scene.activeCamera.focusDistance = 3.6;
    scene.activeCamera.fStop = 1.8;

    scene.update();
    return scene;
  }
}
