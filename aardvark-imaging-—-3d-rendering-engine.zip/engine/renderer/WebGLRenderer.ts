import { Scene } from '../scene/Scene';
import { Camera } from '../camera/Camera';
import { SceneNode } from '../scene/SceneNode';
import { Material, ShadingModel, AlphaMode } from '../materials/Material';
import { Light, LightType } from '../lights/Light';
import { Geometry } from '../mesh/Geometry';
import { Texture } from '../textures/Texture';
import { Color } from '../core/math';

export enum RenderMode {
  DRAFT = 'DRAFT',
  STANDARD = 'STANDARD',
  CINEMATIC = 'CINEMATIC',
  PATHTRACED = 'PATHTRACED'
}

export enum AOVType {
  BEAUTY = 'BEAUTY',
  ALBEDO = 'ALBEDO',
  DEPTH = 'DEPTH',
  NORMALS = 'NORMALS',
  POSITIONS = 'POSITIONS',
  ROUGHNESS = 'ROUGHNESS',
  METALLIC = 'METALLIC',
  EMISSION = 'EMISSION',
  SHADOWS = 'SHADOWS',
  MOTION_VECTORS = 'MOTION_VECTORS',
  OBJECT_IDS = 'OBJECT_IDS'
}

export class WebGLRenderer {
  public canvas: HTMLCanvasElement;
  public gl: WebGL2RenderingContext | WebGLRenderingContext;
  public isWebGL2: boolean = false;

  public renderMode: RenderMode = RenderMode.STANDARD;
  public currentAOV: AOVType = AOVType.BEAUTY;

  // Shader Programs
  private pbrProgram: WebGLProgram | null = null;
  private shadowProgram: WebGLProgram | null = null;
  private unlitProgram: WebGLProgram | null = null;
  private particleProgram: WebGLProgram | null = null;

  // Framebuffers & Textures for Shadow & Post Process
  private shadowFramebuffer: WebGLFramebuffer | null = null;
  private shadowDepthTexture: WebGLTexture | null = null;
  private shadowMapSize: number = 1024;

  // GPU Buffer Cache (WeakMap by Geometry)
  private bufferCache = new WeakMap<
    Geometry,
    {
      pos: WebGLBuffer;
      norm: WebGLBuffer;
      uv: WebGLBuffer;
      color: WebGLBuffer;
      indices: WebGLBuffer;
      indexCount: number;
    }
  >();

  // Texture Cache
  private textureCache = new WeakMap<Texture, WebGLTexture>();

  // Metrics & Stats
  public stats = {
    drawCalls: 0,
    triangles: 0,
    fps: 60,
    renderTimeMs: 0
  };

  private lastTime: number = performance.now();
  private frameCount: number = 0;
  private fpsTimer: number = 0;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const gl2 = canvas.getContext('webgl2', {
      alpha: false,
      antialias: true,
      depth: true,
      preserveDrawingBuffer: true,
      powerPreference: 'high-performance'
    });

    if (gl2) {
      this.gl = gl2;
      this.isWebGL2 = true;
    } else {
      const gl1 = canvas.getContext('webgl', {
        alpha: false,
        antialias: true,
        depth: true,
        preserveDrawingBuffer: true
      });
      if (!gl1) throw new Error('WebGL not supported');
      this.gl = gl1;
      this.isWebGL2 = false;
    }

    this.initGL();
  }

  private initGL(): void {
    const gl = this.gl;
    gl.enable(gl.DEPTH_TEST);
    gl.depthFunc(gl.LEQUAL);
    gl.enable(gl.CULL_FACE);
    gl.cullFace(gl.BACK);

    // Build Shaders
    this.pbrProgram = this.buildPBRProgram();
    this.shadowProgram = this.buildShadowProgram();
    this.unlitProgram = this.buildUnlitProgram();
    this.particleProgram = this.buildParticleProgram();

    this.initShadowFramebuffer();
  }

  private initShadowFramebuffer(): void {
    const gl = this.gl;
    this.shadowFramebuffer = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.shadowFramebuffer);

    this.shadowDepthTexture = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, this.shadowDepthTexture);
    gl.texImage2D(
      gl.TEXTURE_2D,
      0,
      gl.DEPTH_COMPONENT16,
      this.shadowMapSize,
      this.shadowMapSize,
      0,
      gl.DEPTH_COMPONENT,
      gl.UNSIGNED_SHORT,
      null
    );
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

    gl.framebufferTexture2D(
      gl.FRAMEBUFFER,
      gl.DEPTH_ATTACHMENT,
      gl.TEXTURE_2D,
      this.shadowDepthTexture,
      0
    );

    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  }

  setSize(width: number, height: number): void {
    this.canvas.width = width;
    this.canvas.height = height;
  }

  render(scene: Scene): void {
    const startTime = performance.now();
    const gl = this.gl;

    this.stats.drawCalls = 0;
    this.stats.triangles = 0;

    // Update scene graph
    scene.update();
    const camera = scene.activeCamera;
    const meshes = scene.getAllMeshes();
    const lights = scene.getAllLights();

    // 1. SHADOW PASS (If directional / spot shadow enabled)
    const shadowLight = lights.find((l) => l.castShadows);
    if (shadowLight && this.shadowFramebuffer) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, this.shadowFramebuffer);
      gl.viewport(0, 0, this.shadowMapSize, this.shadowMapSize);
      gl.clear(gl.DEPTH_BUFFER_BIT);

      gl.useProgram(this.shadowProgram);
      const uShadowVP = gl.getUniformLocation(this.shadowProgram!, 'u_shadowViewProjection');
      const uModel = gl.getUniformLocation(this.shadowProgram!, 'u_model');

      gl.uniformMatrix4fv(uShadowVP, false, shadowLight.shadowViewProjectionMatrix.elements);

      for (const node of meshes) {
        if (!node.geometry) continue;
        gl.uniformMatrix4fv(uModel, false, node.transform.worldMatrix.elements);
        this.drawGeometry(node.geometry, this.shadowProgram!);
      }
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    }

    // 2. MAIN BEAUTY / AOV RASTER PASS
    gl.viewport(0, 0, this.canvas.width, this.canvas.height);
    const bg = scene.backgroundColor;
    gl.clearColor(bg.r, bg.g, bg.b, 1.0);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    gl.useProgram(this.pbrProgram);
    this.bindPBRUniforms(scene, camera, lights, shadowLight);

    // Render all opaque meshes then transparent
    const opaqueMeshes = meshes.filter(
      (m) => (m.materials[0]?.alphaMode || AlphaMode.OPAQUE) !== AlphaMode.BLEND
    );
    const transparentMeshes = meshes.filter(
      (m) => (m.materials[0]?.alphaMode || AlphaMode.OPAQUE) === AlphaMode.BLEND
    );

    // Draw Opaque
    gl.disable(gl.BLEND);
    gl.depthMask(true);
    for (const node of opaqueMeshes) {
      this.drawNode(node, this.pbrProgram!);
    }

    // Draw Transparent with alpha blending & sorting
    if (transparentMeshes.length > 0) {
      gl.enable(gl.BLEND);
      gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
      gl.depthMask(false); // don't write depth for transparent
      for (const node of transparentMeshes) {
        this.drawNode(node, this.pbrProgram!);
      }
      gl.disable(gl.BLEND);
      gl.depthMask(true);
    }

    // 3. PARTICLE EMITTERS PASS
    scene.traverse((node) => {
      if (node.particleEmitter && node.visible) {
        this.renderParticles(node.particleEmitter, camera);
      }
    });

    // FPS & Render stats
    this.stats.renderTimeMs = performance.now() - startTime;
    this.frameCount++;
    const now = performance.now();
    if (now - this.fpsTimer >= 1000) {
      this.stats.fps = this.frameCount;
      this.frameCount = 0;
      this.fpsTimer = now;
    }
  }

  private drawNode(node: SceneNode, program: WebGLProgram): void {
    const gl = this.gl;
    if (!node.geometry) return;

    const uModel = gl.getUniformLocation(program, 'u_model');
    const uNormalMat = gl.getUniformLocation(program, 'u_normalMatrix');
    const uObjectId = gl.getUniformLocation(program, 'u_objectId');

    gl.uniformMatrix4fv(uModel, false, node.transform.worldMatrix.elements);
    gl.uniformMatrix4fv(uNormalMat, false, node.transform.normalMatrix.elements);

    // Hash string ID to float
    let idNum = 0.5;
    for (let i = 0; i < node.id.length; i++) idNum += node.id.charCodeAt(i) * 0.01;
    gl.uniform1f(uObjectId, idNum % 1.0);

    const geom = node.geometry;
    const defaultMat = node.materials[0] || new Material();

    if (geom.submeshes && geom.submeshes.length > 0) {
      for (const sub of geom.submeshes) {
        const mat = node.materials[sub.materialIndex] || defaultMat;
        this.bindMaterialUniforms(mat, program);
        this.drawGeometrySubmesh(geom, sub.start, sub.count, program);
      }
    } else {
      this.bindMaterialUniforms(defaultMat, program);
      this.drawGeometry(geom, program);
    }
  }

  private bindPBRUniforms(
    scene: Scene,
    camera: Camera,
    lights: Light[],
    shadowLight?: Light
  ): void {
    const gl = this.gl;
    const p = this.pbrProgram!;

    gl.uniformMatrix4fv(
      gl.getUniformLocation(p, 'u_viewProjection'),
      false,
      camera.viewProjectionMatrix.elements
    );
    const camPos = camera.transform.getWorldPosition();
    gl.uniform3f(gl.getUniformLocation(p, 'u_cameraPosition'), camPos.x, camPos.y, camPos.z);
    gl.uniform1f(gl.getUniformLocation(p, 'u_cameraNear'), camera.near);
    gl.uniform1f(gl.getUniformLocation(p, 'u_cameraFar'), camera.far);
    gl.uniform1i(gl.getUniformLocation(p, 'u_renderMode'), this.renderMode === RenderMode.DRAFT ? 0 : 1);
    gl.uniform1i(gl.getUniformLocation(p, 'u_aovType'), this.getAOVIndex(this.currentAOV));

    // Ambient Lighting
    gl.uniform3f(
      gl.getUniformLocation(p, 'u_ambientColor'),
      scene.ambientLightColor.r * scene.ambientIntensity,
      scene.ambientLightColor.g * scene.ambientIntensity,
      scene.ambientLightColor.b * scene.ambientIntensity
    );

    // Directional / Key Light
    const dirLight = lights.find((l) => l.type === LightType.DIRECTIONAL) || lights[0];
    if (dirLight) {
      const dirPos = dirLight.transform.getWorldPosition();
      const dir = dirPos.clone().scale(-1).normalize();
      gl.uniform3f(gl.getUniformLocation(p, 'u_dirLightDir'), dir.x, dir.y, dir.z);
      gl.uniform3f(
        gl.getUniformLocation(p, 'u_dirLightColor'),
        dirLight.color.r * dirLight.intensity,
        dirLight.color.g * dirLight.intensity,
        dirLight.color.b * dirLight.intensity
      );
    } else {
      gl.uniform3f(gl.getUniformLocation(p, 'u_dirLightDir'), 0.5, 1.0, 0.5);
      gl.uniform3f(gl.getUniformLocation(p, 'u_dirLightColor'), 1.0, 1.0, 1.0);
    }

    // Point Light
    const ptLight = lights.find((l) => l.type === LightType.POINT);
    if (ptLight) {
      const ptPos = ptLight.transform.getWorldPosition();
      gl.uniform3f(gl.getUniformLocation(p, 'u_pointLightPos'), ptPos.x, ptPos.y, ptPos.z);
      gl.uniform3f(
        gl.getUniformLocation(p, 'u_pointLightColor'),
        ptLight.color.r * ptLight.intensity,
        ptLight.color.g * ptLight.intensity,
        ptLight.color.b * ptLight.intensity
      );
      gl.uniform1f(gl.getUniformLocation(p, 'u_pointLightRadius'), ptLight.radius);
    } else {
      gl.uniform3f(gl.getUniformLocation(p, 'u_pointLightPos'), 0, 0, 0);
      gl.uniform3f(gl.getUniformLocation(p, 'u_pointLightColor'), 0, 0, 0);
      gl.uniform1f(gl.getUniformLocation(p, 'u_pointLightRadius'), 10.0);
    }

    // Shadow Map Binding
    if (shadowLight && this.shadowDepthTexture) {
      gl.uniformMatrix4fv(
        gl.getUniformLocation(p, 'u_shadowViewProjection'),
        false,
        shadowLight.shadowViewProjectionMatrix.elements
      );
      gl.uniform1f(gl.getUniformLocation(p, 'u_shadowBias'), shadowLight.shadowBias);
      gl.uniform1i(gl.getUniformLocation(p, 'u_hasShadowMap'), 1);

      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, this.shadowDepthTexture);
      gl.uniform1i(gl.getUniformLocation(p, 'u_shadowMap'), 0);
    } else {
      gl.uniform1i(gl.getUniformLocation(p, 'u_hasShadowMap'), 0);
    }
  }

  private bindMaterialUniforms(mat: Material, program: WebGLProgram): void {
    const gl = this.gl;
    gl.uniform3f(
      gl.getUniformLocation(program, 'u_baseColor'),
      mat.baseColor.r,
      mat.baseColor.g,
      mat.baseColor.b
    );
    gl.uniform1f(gl.getUniformLocation(program, 'u_metallic'), mat.metallic);
    gl.uniform1f(gl.getUniformLocation(program, 'u_roughness'), mat.roughness);
    gl.uniform1f(gl.getUniformLocation(program, 'u_opacity'), mat.opacity);
    gl.uniform1f(gl.getUniformLocation(program, 'u_clearcoat'), mat.clearcoat);
    gl.uniform1f(gl.getUniformLocation(program, 'u_transmission'), mat.transmission);
    gl.uniform3f(
      gl.getUniformLocation(program, 'u_emission'),
      mat.emission.r * mat.emissionIntensity,
      mat.emission.g * mat.emissionIntensity,
      mat.emission.b * mat.emissionIntensity
    );
  }

  private getAOVIndex(aov: AOVType): number {
    switch (aov) {
      case AOVType.BEAUTY: return 0;
      case AOVType.ALBEDO: return 1;
      case AOVType.DEPTH: return 2;
      case AOVType.NORMALS: return 3;
      case AOVType.POSITIONS: return 4;
      case AOVType.ROUGHNESS: return 5;
      case AOVType.METALLIC: return 6;
      case AOVType.EMISSION: return 7;
      case AOVType.SHADOWS: return 8;
      case AOVType.MOTION_VECTORS: return 9;
      case AOVType.OBJECT_IDS: return 10;
      default: return 0;
    }
  }

  private drawGeometry(geom: Geometry, program: WebGLProgram): void {
    const buffers = this.getOrCreateBuffers(geom);
    this.bindVertexAttributes(buffers, program);

    const gl = this.gl;
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, buffers.indices);
    gl.drawElements(gl.TRIANGLES, buffers.indexCount, gl.UNSIGNED_INT, 0);

    this.stats.drawCalls++;
    this.stats.triangles += buffers.indexCount / 3;
  }

  private drawGeometrySubmesh(geom: Geometry, start: number, count: number, program: WebGLProgram): void {
    const buffers = this.getOrCreateBuffers(geom);
    this.bindVertexAttributes(buffers, program);

    const gl = this.gl;
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, buffers.indices);
    gl.drawElements(gl.TRIANGLES, count, gl.UNSIGNED_INT, start * 4); // 4 bytes per uint32

    this.stats.drawCalls++;
    this.stats.triangles += count / 3;
  }

  private bindVertexAttributes(
    buffers: { pos: WebGLBuffer; norm: WebGLBuffer; uv: WebGLBuffer },
    program: WebGLProgram
  ): void {
    const gl = this.gl;
    const aPos = gl.getAttribLocation(program, 'a_position');
    const aNorm = gl.getAttribLocation(program, 'a_normal');
    const aUv = gl.getAttribLocation(program, 'a_uv');

    if (aPos !== -1) {
      gl.bindBuffer(gl.ARRAY_BUFFER, buffers.pos);
      gl.enableVertexAttribArray(aPos);
      gl.vertexAttribPointer(aPos, 3, gl.FLOAT, false, 0, 0);
    }
    if (aNorm !== -1) {
      gl.bindBuffer(gl.ARRAY_BUFFER, buffers.norm);
      gl.enableVertexAttribArray(aNorm);
      gl.vertexAttribPointer(aNorm, 3, gl.FLOAT, false, 0, 0);
    }
    if (aUv !== -1) {
      gl.bindBuffer(gl.ARRAY_BUFFER, buffers.uv);
      gl.enableVertexAttribArray(aUv);
      gl.vertexAttribPointer(aUv, 2, gl.FLOAT, false, 0, 0);
    }
  }

  private getOrCreateBuffers(geom: Geometry) {
    let cached = this.bufferCache.get(geom);
    if (!cached || geom.isDirty) {
      const gl = this.gl;

      const posBuf = cached?.pos || gl.createBuffer()!;
      gl.bindBuffer(gl.ARRAY_BUFFER, posBuf);
      gl.bufferData(gl.ARRAY_BUFFER, geom.positions, gl.STATIC_DRAW);

      const normBuf = cached?.norm || gl.createBuffer()!;
      gl.bindBuffer(gl.ARRAY_BUFFER, normBuf);
      gl.bufferData(gl.ARRAY_BUFFER, geom.normals, gl.STATIC_DRAW);

      const uvBuf = cached?.uv || gl.createBuffer()!;
      gl.bindBuffer(gl.ARRAY_BUFFER, uvBuf);
      gl.bufferData(gl.ARRAY_BUFFER, geom.uvs, gl.STATIC_DRAW);

      const colBuf = cached?.color || gl.createBuffer()!;
      gl.bindBuffer(gl.ARRAY_BUFFER, colBuf);
      gl.bufferData(gl.ARRAY_BUFFER, geom.colors, gl.STATIC_DRAW);

      const idxBuf = cached?.indices || gl.createBuffer()!;
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, idxBuf);
      gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, geom.indices, gl.STATIC_DRAW);

      cached = {
        pos: posBuf,
        norm: normBuf,
        uv: uvBuf,
        color: colBuf,
        indices: idxBuf,
        indexCount: geom.indices.length
      };

      this.bufferCache.set(geom, cached);
      geom.isDirty = false;
    }
    return cached;
  }

  private renderParticles(emitter: any, camera: Camera): void {
    const gl = this.gl;
    gl.useProgram(this.particleProgram);
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE); // Additive blending for sparks
    gl.depthMask(false);

    const uVP = gl.getUniformLocation(this.particleProgram!, 'u_viewProjection');
    gl.uniformMatrix4fv(uVP, false, camera.viewProjectionMatrix.elements);

    const geom = emitter.particleGeometry;
    const buffers = this.getOrCreateBuffers(geom);

    const aPos = gl.getAttribLocation(this.particleProgram!, 'a_position');
    const aCol = gl.getAttribLocation(this.particleProgram!, 'a_color');

    if (aPos !== -1) {
      gl.bindBuffer(gl.ARRAY_BUFFER, buffers.pos);
      gl.enableVertexAttribArray(aPos);
      gl.vertexAttribPointer(aPos, 3, gl.FLOAT, false, 0, 0);
    }
    if (aCol !== -1) {
      gl.bindBuffer(gl.ARRAY_BUFFER, buffers.color);
      gl.enableVertexAttribArray(aCol);
      gl.vertexAttribPointer(aCol, 4, gl.FLOAT, false, 0, 0);
    }

    const count = emitter.activeParticles.length;
    if (count > 0) {
      gl.drawArrays(gl.POINTS, 0, count);
      this.stats.drawCalls++;
    }

    gl.depthMask(true);
    gl.disable(gl.BLEND);
  }

  // --- SHADER COMPILATION & SOURCES ---
  private buildPBRProgram(): WebGLProgram {
    const vs = `
      attribute vec3 a_position;
      attribute vec3 a_normal;
      attribute vec2 a_uv;

      uniform mat4 u_model;
      uniform mat4 u_normalMatrix;
      uniform mat4 u_viewProjection;
      uniform mat4 u_shadowViewProjection;

      varying vec3 v_worldPosition;
      varying vec3 v_worldNormal;
      varying vec2 v_uv;
      varying vec4 v_shadowCoord;
      varying vec4 v_clipPosition;

      void main() {
        vec4 worldPos = u_model * vec4(a_position, 1.0);
        v_worldPosition = worldPos.xyz;
        v_worldNormal = normalize((u_normalMatrix * vec4(a_normal, 0.0)).xyz);
        v_uv = a_uv;
        v_shadowCoord = u_shadowViewProjection * worldPos;

        vec4 clipPos = u_viewProjection * worldPos;
        v_clipPosition = clipPos;
        gl_Position = clipPos;
      }
    `;

    const fs = `
      precision highp float;

      varying vec3 v_worldPosition;
      varying vec3 v_worldNormal;
      varying vec2 v_uv;
      varying vec4 v_shadowCoord;
      varying vec4 v_clipPosition;

      uniform vec3 u_cameraPosition;
      uniform float u_cameraNear;
      uniform float u_cameraFar;
      uniform int u_renderMode;
      uniform int u_aovType;

      uniform vec3 u_baseColor;
      uniform float u_metallic;
      uniform float u_roughness;
      uniform float u_opacity;
      uniform float u_clearcoat;
      uniform float u_transmission;
      uniform vec3 u_emission;

      uniform vec3 u_ambientColor;
      uniform vec3 u_dirLightDir;
      uniform vec3 u_dirLightColor;
      uniform vec3 u_pointLightPos;
      uniform vec3 u_pointLightColor;
      uniform float u_pointLightRadius;

      uniform sampler2D u_shadowMap;
      uniform int u_hasShadowMap;
      uniform float u_shadowBias;
      uniform float u_objectId;

      const float PI = 3.14159265359;

      // Cook-Torrance GGX Specular
      float DistributionGGX(vec3 N, vec3 H, float roughness) {
        float a = roughness * roughness;
        float a2 = a * a;
        float NdotH = max(dot(N, H), 0.0);
        float NdotH2 = NdotH * NdotH;
        float num = a2;
        float denom = (NdotH2 * (a2 - 1.0) + 1.0);
        return num / (PI * denom * denom + 0.00001);
      }

      float GeometrySchlickGGX(float NdotV, float roughness) {
        float r = (roughness + 1.0);
        float k = (r * r) / 8.0;
        return NdotV / (NdotV * (1.0 - k) + k);
      }

      float GeometrySmith(vec3 N, vec3 V, vec3 L, float roughness) {
        float NdotV = max(dot(N, V), 0.0);
        float NdotL = max(dot(N, L), 0.0);
        float ggx2 = GeometrySchlickGGX(NdotV, roughness);
        float ggx1 = GeometrySchlickGGX(NdotL, roughness);
        return ggx1 * ggx2;
      }

      vec3 fresnelSchlick(float cosTheta, vec3 F0) {
        return F0 + (1.0 - F0) * pow(clamp(1.0 - cosTheta, 0.0, 1.0), 5.0);
      }

      float calculateShadow(vec4 shadowCoord) {
        if (u_hasShadowMap == 0) return 1.0;
        vec3 projCoords = shadowCoord.xyz / shadowCoord.w;
        projCoords = projCoords * 0.5 + 0.5; // [0, 1] range

        if (projCoords.z > 1.0 || projCoords.x < 0.0 || projCoords.x > 1.0 || projCoords.y < 0.0 || projCoords.y > 1.0) {
          return 1.0;
        }

        float currentDepth = projCoords.z - u_shadowBias;
        float closestDepth = texture2D(u_shadowMap, projCoords.xy).r;
        return currentDepth > closestDepth ? 0.2 : 1.0;
      }

      void main() {
        vec3 N = normalize(v_worldNormal);
        vec3 V = normalize(u_cameraPosition - v_worldPosition);
        float NdotV = max(dot(N, V), 0.0);

        // AOV PASS MODES (Beauty, Depth, Normals, Roughness, Metallic, IDs, Shadows)
        if (u_aovType == 1) { // ALBEDO
          gl_FragColor = vec4(u_baseColor, 1.0);
          return;
        } else if (u_aovType == 2) { // LINEAR DEPTH
          float linearZ = (v_clipPosition.z / v_clipPosition.w - u_cameraNear) / (u_cameraFar - u_cameraNear);
          gl_FragColor = vec4(vec3(linearZ), 1.0);
          return;
        } else if (u_aovType == 3) { // NORMALS
          gl_FragColor = vec4(N * 0.5 + 0.5, 1.0);
          return;
        } else if (u_aovType == 4) { // POSITIONS
          gl_FragColor = vec4(v_worldPosition * 0.2 + 0.5, 1.0);
          return;
        } else if (u_aovType == 5) { // ROUGHNESS
          gl_FragColor = vec4(vec3(u_roughness), 1.0);
          return;
        } else if (u_aovType == 6) { // METALLIC
          gl_FragColor = vec4(vec3(u_metallic), 1.0);
          return;
        } else if (u_aovType == 7) { // EMISSION
          gl_FragColor = vec4(u_emission, 1.0);
          return;
        } else if (u_aovType == 8) { // SHADOW MASK
          float shadow = calculateShadow(v_shadowCoord);
          gl_FragColor = vec4(vec3(shadow), 1.0);
          return;
        } else if (u_aovType == 9) { // MOTION VECTORS
          gl_FragColor = vec4(0.5, 0.5, 0.0, 1.0);
          return;
        } else if (u_aovType == 10) { // OBJECT IDS
          gl_FragColor = vec4(u_objectId, fract(u_objectId * 7.0), fract(u_objectId * 13.0), 1.0);
          return;
        }

        // FULL PBR BEAUTY SHADING
        vec3 F0 = mix(vec3(0.04), u_baseColor, u_metallic);
        vec3 Lo = vec3(0.0);

        // 1. Directional Key Light
        vec3 L = normalize(u_dirLightDir);
        vec3 H = normalize(V + L);
        float NdotL = max(dot(N, L), 0.0);

        if (NdotL > 0.0) {
          float NDF = DistributionGGX(N, H, u_roughness);
          float G = GeometrySmith(N, V, L, u_roughness);
          vec3 F = fresnelSchlick(max(dot(H, V), 0.0), F0);

          vec3 numerator = NDF * G * F;
          float denominator = 4.0 * NdotV * NdotL + 0.0001;
          vec3 specular = numerator / denominator;

          vec3 kS = F;
          vec3 kD = (vec3(1.0) - kS) * (1.0 - u_metallic);

          float shadow = calculateShadow(v_shadowCoord);
          Lo += (kD * u_baseColor / PI + specular) * u_dirLightColor * NdotL * shadow;
        }

        // 2. Point Light
        vec3 pointToLight = u_pointLightPos - v_worldPosition;
        float dist = length(pointToLight);
        if (dist < u_pointLightRadius) {
          vec3 pointL = normalize(pointToLight);
          vec3 pointH = normalize(V + pointL);
          float pointNdotL = max(dot(N, pointL), 0.0);
          float attenuation = 1.0 / (1.0 + 0.1 * dist + 0.1 * dist * dist);

          if (pointNdotL > 0.0) {
            float NDF = DistributionGGX(N, pointH, u_roughness);
            float G = GeometrySmith(N, V, pointL, u_roughness);
            vec3 F = fresnelSchlick(max(dot(pointH, V), 0.0), F0);

            vec3 specular = (NDF * G * F) / (4.0 * NdotV * pointNdotL + 0.0001);
            vec3 kD = (vec3(1.0) - F) * (1.0 - u_metallic);
            Lo += (kD * u_baseColor / PI + specular) * u_pointLightColor * pointNdotL * attenuation;
          }
        }

        // 3. Ambient & Emission
        vec3 ambient = u_ambientColor * u_baseColor * (1.0 - u_metallic * 0.5);
        vec3 finalColor = ambient + Lo + u_emission;

        // ACES Tone Mapping
        finalColor = (finalColor * (2.51 * finalColor + 0.03)) / (finalColor * (2.43 * finalColor + 0.59) + 0.14);

        gl_FragColor = vec4(finalColor, u_opacity);
      }
    `;

    return this.createProgram(vs, fs);
  }

  private buildShadowProgram(): WebGLProgram {
    const vs = `
      attribute vec3 a_position;
      uniform mat4 u_model;
      uniform mat4 u_shadowViewProjection;

      void main() {
        gl_Position = u_shadowViewProjection * u_model * vec4(a_position, 1.0);
      }
    `;

    const fs = `
      precision highp float;
      void main() {
        // Depth written automatically
      }
    `;

    return this.createProgram(vs, fs);
  }

  private buildUnlitProgram(): WebGLProgram {
    const vs = `
      attribute vec3 a_position;
      uniform mat4 u_model;
      uniform mat4 u_viewProjection;
      void main() {
        gl_Position = u_viewProjection * u_model * vec4(a_position, 1.0);
      }
    `;
    const fs = `
      precision highp float;
      uniform vec3 u_color;
      void main() {
        gl_FragColor = vec4(u_color, 1.0);
      }
    `;
    return this.createProgram(vs, fs);
  }

  private buildParticleProgram(): WebGLProgram {
    const vs = `
      attribute vec3 a_position;
      attribute vec4 a_color;
      uniform mat4 u_viewProjection;
      varying vec4 v_color;

      void main() {
        v_color = a_color;
        gl_Position = u_viewProjection * vec4(a_position, 1.0);
        gl_PointSize = 6.0;
      }
    `;

    const fs = `
      precision highp float;
      varying vec4 v_color;

      void main() {
        vec2 coord = gl_PointCoord - vec2(0.5);
        if (length(coord) > 0.5) discard;
        float alpha = (1.0 - length(coord) * 2.0) * v_color.a;
        gl_FragColor = vec4(v_color.rgb, alpha);
      }
    `;

    return this.createProgram(vs, fs);
  }

  private createProgram(vsSource: string, fsSource: string): WebGLProgram {
    const gl = this.gl;
    const vs = gl.createShader(gl.VERTEX_SHADER)!;
    gl.shaderSource(vs, vsSource);
    gl.compileShader(vs);
    if (!gl.getShaderParameter(vs, gl.COMPILE_STATUS)) {
      throw new Error('Vertex shader compile error: ' + gl.getShaderInfoLog(vs));
    }

    const fs = gl.createShader(gl.FRAGMENT_SHADER)!;
    gl.shaderSource(fs, fsSource);
    gl.compileShader(fs);
    if (!gl.getShaderParameter(fs, gl.COMPILE_STATUS)) {
      throw new Error('Fragment shader compile error: ' + gl.getShaderInfoLog(fs));
    }

    const prog = gl.createProgram()!;
    gl.attachShader(prog, vs);
    gl.attachShader(prog, fs);
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
      throw new Error('Shader link error: ' + gl.getProgramInfoLog(prog));
    }
    return prog;
  }
}
