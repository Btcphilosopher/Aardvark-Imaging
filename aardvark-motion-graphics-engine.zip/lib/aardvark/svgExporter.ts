import { AardComposition } from './types';
import { evaluateSceneAtTime } from './engine';

export function exportToAnimatedSvg(comp: AardComposition): string {
  const fps = 30;
  const duration = comp.duration || 4;
  const totalFrames = Math.floor(duration * fps);
  const w = comp.width || 1280;
  const h = comp.height || 720;

  let svgElements = '';

  comp.objects.forEach((obj) => {
    if (!obj.visible) return;

    // Sample keyframes across time to build CSS animation
    const keyframeSteps: string[] = [];
    for (let f = 0; f <= totalFrames; f += 2) {
      const t = (f / totalFrames) * duration;
      const pct = ((f / totalFrames) * 100).toFixed(1);
      const evalFrame = evaluateSceneAtTime(comp, t);
      const evalObj = evalFrame.objects.find((o) => o.object.id === obj.id);
      if (!evalObj) continue;

      const { worldTransform, computedStyle } = evalObj;
      keyframeSteps.push(
        `${pct}% { transform: translate(${worldTransform.x}px, ${worldTransform.y}px) rotate(${worldTransform.rotation}deg) scale(${worldTransform.scaleX}, ${worldTransform.scaleY}); opacity: ${computedStyle.opacity}; }`
      );
    }

    const animName = `anim_${obj.id.replace(/[^a-zA-Z0-9]/g, '_')}`;
    const cssRule = `@keyframes ${animName} {\n  ${keyframeSteps.join('\n  ')}\n}`;

    let geomTag = '';
    if (obj.type === 'rect') {
      geomTag = `<rect x="${-obj.width / 2}" y="${-obj.height / 2}" width="${obj.width}" height="${obj.height}" rx="${obj.style.cornerRadius || 0}" fill="${obj.style.fill}" stroke="${obj.style.stroke}" stroke-width="${obj.style.strokeWidth}" />`;
    } else if (obj.type === 'circle') {
      geomTag = `<circle cx="0" cy="0" r="${obj.radius || obj.width / 2 || 40}" fill="${obj.style.fill}" stroke="${obj.style.stroke}" stroke-width="${obj.style.strokeWidth}" />`;
    } else if (obj.type === 'star') {
      geomTag = `<polygon points="0,-50 14,-15 50,-15 20,7 31,45 0,22 -31,45 -20,7 -50,-15 -14,-15" fill="${obj.style.fill}" stroke="${obj.style.stroke}" stroke-width="${obj.style.strokeWidth}" />`;
    } else if (obj.type === 'text' && obj.textProps) {
      geomTag = `<text x="0" y="0" text-anchor="middle" dominant-baseline="middle" font-size="${obj.textProps.fontSize}" font-family="${obj.textProps.fontFamily}" fill="${obj.style.fill}">${obj.textProps.text}</text>`;
    } else if (obj.type === 'path' && obj.pathData) {
      geomTag = `<path d="${obj.pathData}" fill="${obj.style.fill}" stroke="${obj.style.stroke}" stroke-width="${obj.style.strokeWidth}" />`;
    }

    svgElements += `
  <style>
    ${cssRule}
    #${obj.id} {
      animation: ${animName} ${duration}s infinite ease-in-out;
      transform-origin: 0px 0px;
    }
  </style>
  <g id="${obj.id}">
    ${geomTag}
  </g>
`;
  });

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}" style="background-color: ${comp.backgroundColor || '#0a0b10'};">
  ${svgElements}
</svg>`;
}
