import { ParticleEmitterConfig, FlowFieldConfig } from './types';

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  rotation: number;
  vRot: number;
  scale: number;
  opacity: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
  trail: { x: number; y: number }[];
}

// Deterministic Pseudo-Random Number Generator (Mulberry32)
export function mulberry32(seed: number) {
  return function () {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function simulateParticles(
  config: ParticleEmitterConfig,
  emitterX: number,
  emitterY: number,
  time: number,
  seed = 12345
): Particle[] {
  const rng = mulberry32(seed);
  const particles: Particle[] = [];
  const dt = 1 / 30;
  const totalSteps = Math.floor(time / dt);

  // We can simulate deterministic particle instances
  const count = Math.min(config.maxParticles, Math.floor(time * config.rate));

  for (let i = 0; i < count; i++) {
    const birthTime = (i / config.rate);
    if (time < birthTime) continue;

    const age = time - birthTime;
    const maxLife = config.particleLife * (0.8 + rng() * 0.4);
    if (age > maxLife && config.type !== 'continuous') continue;

    const currentAge = config.type === 'continuous' ? age % maxLife : age;
    const lifeRatio = currentAge / maxLife;

    // Initial velocity
    const angle = (config.angleMin + rng() * (config.angleMax - config.angleMin)) * (Math.PI / 180);
    const speed = config.speedMin + rng() * (config.speedMax - config.speedMin);
    let vx = Math.cos(angle) * speed;
    let vy = Math.sin(angle) * speed;
    let px = emitterX + (rng() - 0.5) * 10;
    let py = emitterY + (rng() - 0.5) * 10;

    // Integrate trajectory up to currentAge
    const steps = Math.min(100, Math.floor(currentAge / dt));
    const trail: { x: number; y: number }[] = [];

    for (let s = 0; s < steps; s++) {
      vy += config.gravity * dt * 20;
      vx += config.wind * dt * 20;
      if (config.turbulence > 0) {
        vx += (rng() - 0.5) * config.turbulence * 10 * dt;
        vy += (rng() - 0.5) * config.turbulence * 10 * dt;
      }
      px += vx * dt;
      py += vy * dt;
      if (config.trailLength > 0 && s % 2 === 0) {
        trail.push({ x: px, y: py });
        if (trail.length > config.trailLength) trail.shift();
      }
    }

    const size = config.sizeMin + (config.sizeMax - config.sizeMin) * (1 - lifeRatio * 0.5);
    const opacity = (config.opacityStart + (config.opacityEnd - config.opacityStart) * lifeRatio);

    particles.push({
      x: px,
      y: py,
      vx,
      vy,
      rotation: currentAge * 5 + i,
      vRot: 2,
      scale: 1 - lifeRatio * 0.3,
      opacity: Math.max(0, Math.min(1, opacity)),
      life: currentAge,
      maxLife,
      color: lifeRatio < 0.5 ? config.colorStart : config.colorEnd,
      size,
      trail,
    });
  }

  return particles;
}

export function computeFlowFieldVectors(
  config: FlowFieldConfig,
  time: number,
  width = 800,
  height = 600,
  seed = 9999
): { x: number; y: number; angle: number; speed: number }[] {
  const rng = mulberry32(seed);
  const points: { x: number; y: number; angle: number; speed: number }[] = [];
  const count = config.particleCount || 120;

  for (let i = 0; i < count; i++) {
    const rx = rng() * width;
    const ry = rng() * height;
    const nx = rx * config.noiseScale * 0.005;
    const ny = ry * config.noiseScale * 0.005;

    // Perlin-style curl / trigonometric noise vector
    const angle = Math.sin(nx + time * config.speed) * Math.cos(ny + time * config.speed * 0.8) * Math.PI * 4;
    points.push({
      x: rx,
      y: ry,
      angle,
      speed: config.speed * (0.8 + rng() * 0.4),
    });
  }

  return points;
}
