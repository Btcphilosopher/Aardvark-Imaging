import {
  AardComposition,
  AardObject,
  AardTrack,
  AudioBands,
  Transform2D,
  StyleProperties,
} from './types';
import { evaluateEasing } from './easing';
import { evaluateAardExpression } from './expressions';

export interface EvaluatedObject {
  object: AardObject;
  worldTransform: Transform2D;
  computedStyle: StyleProperties;
  computedPathData?: string;
  splitTextItems?: {
    text: string;
    x: number;
    y: number;
    rotation: number;
    scale: number;
    opacity: number;
  }[];
  computedRadius?: number;
  computedWidth?: number;
  computedHeight?: number;
}

export interface EvaluatedFrame {
  time: number;
  frame: number;
  camera: {
    x: number;
    y: number;
    z: number;
    rotation: number;
    rotationX: number;
    rotationY: number;
    zoom: number;
  };
  objects: EvaluatedObject[];
  width: number;
  height: number;
  backgroundColor: string;
}

function interpolateValue(
  track: AardTrack,
  time: number
): number | string | boolean {
  const kfs = track.keyframes;
  if (!kfs || kfs.length === 0) return 0;
  if (kfs.length === 1) return kfs[0].value;

  // Sort keyframes by time
  const sorted = [...kfs].sort((a, b) => a.time - b.time);

  // Before first keyframe
  if (time <= sorted[0].time) return sorted[0].value;
  // After last keyframe
  if (time >= sorted[sorted.length - 1].time) return sorted[sorted.length - 1].value;

  // Find the span
  for (let i = 0; i < sorted.length - 1; i++) {
    const k1 = sorted[i];
    const k2 = sorted[i + 1];
    if (time >= k1.time && time <= k2.time) {
      const span = k2.time - k1.time;
      if (span <= 0) return k1.value;
      const progress = (time - k1.time) / span;

      const easedT = evaluateEasing(progress, k1.easing, k1.inHandle, k1.outHandle);

      if (typeof k1.value === 'number' && typeof k2.value === 'number') {
        return k1.value + (k2.value - k1.value) * easedT;
      }

      if (typeof k1.value === 'string' && typeof k2.value === 'string') {
        // Color interpolation if hex
        if (k1.value.startsWith('#') && k2.value.startsWith('#')) {
          return interpolateHexColor(k1.value, k2.value, easedT);
        }
        return easedT >= 0.5 ? k2.value : k1.value;
      }

      return easedT >= 0.5 ? k2.value : k1.value;
    }
  }

  return sorted[0].value;
}

function interpolateHexColor(c1: string, c2: string, t: number): string {
  const r1 = parseInt(c1.slice(1, 3), 16) || 0;
  const g1 = parseInt(c1.slice(3, 5), 16) || 0;
  const b1 = parseInt(c1.slice(5, 7), 16) || 0;

  const r2 = parseInt(c2.slice(1, 3), 16) || 0;
  const g2 = parseInt(c2.slice(3, 5), 16) || 0;
  const b2 = parseInt(c2.slice(5, 7), 16) || 0;

  const r = Math.round(r1 + (r2 - r1) * t);
  const g = Math.round(g1 + (g2 - g1) * t);
  const b = Math.round(b1 + (b2 - b1) * t);

  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

// Simple path point morphing for compatible polygon/path vertices
function morphPathSvg(pathA: string, pathB: string, progress: number): string {
  const parseNumbers = (d: string) =>
    (d.match(/-?\d+(?:\.\d+)?/g) || []).map(Number);

  const numsA = parseNumbers(pathA);
  const numsB = parseNumbers(pathB);
  if (numsA.length === 0) return pathB;
  if (numsB.length === 0) return pathA;

  const maxLen = Math.max(numsA.length, numsB.length);
  const interpolated: number[] = [];

  for (let i = 0; i < maxLen; i++) {
    const vA = numsA[i % numsA.length];
    const vB = numsB[i % numsB.length];
    interpolated.push(vA + (vB - vA) * progress);
  }

  // Rebuild basic SVG path
  let out = '';
  for (let i = 0; i < interpolated.length; i += 2) {
    if (i === 0) {
      out += `M ${interpolated[i].toFixed(1)} ${(interpolated[i + 1] ?? 0).toFixed(1)} `;
    } else {
      out += `L ${interpolated[i].toFixed(1)} ${(interpolated[i + 1] ?? 0).toFixed(1)} `;
    }
  }
  return out + 'Z';
}

export function evaluateSceneAtTime(
  comp: AardComposition,
  time: number,
  audio?: AudioBands,
  mouseX?: number,
  mouseY?: number
): EvaluatedFrame {
  const frame = Math.floor(time * comp.fps);
  const duration = comp.duration || 5;
  const progress = Math.max(0, Math.min(1, time / duration));

  // Map of computed object values
  const objMap = new Map<string, { transform: Transform2D; style: StyleProperties; width: number; height: number; radius?: number }>();

  // Initialize objects
  comp.objects.forEach((obj, idx) => {
    objMap.set(obj.id, {
      transform: { ...obj.transform },
      style: {
        ...obj.style,
        glow: { ...obj.style.glow },
        shadow: { ...obj.style.shadow },
      },
      width: obj.width,
      height: obj.height,
      radius: obj.radius,
    });
  });

  // Evaluate each track
  comp.tracks.forEach((track) => {
    if (track.disabled) return;
    const target = objMap.get(track.targetId);
    if (!target) return;

    let val = interpolateValue(track, time);

    // Evaluate expression if active
    if (track.isExpressionActive && track.expression) {
      const exprVal = evaluateAardExpression(track.expression, {
        time,
        frame,
        fps: comp.fps,
        duration,
        progress,
        mouseX,
        mouseY,
        audio,
        val: typeof val === 'number' ? val : 0,
        obj: {
          x: target.transform.x,
          y: target.transform.y,
          rotation: target.transform.rotation,
          scale: target.transform.scaleX,
          opacity: target.style.opacity,
        },
      });
      if (typeof exprVal === 'number' || typeof exprVal === 'string') {
        val = exprVal;
      }
    }

    // Assign to property
    const prop = track.property;
    if (prop === 'position.x' || prop === 'x') target.transform.x = Number(val);
    else if (prop === 'position.y' || prop === 'y') target.transform.y = Number(val);
    else if (prop === 'position.z' || prop === 'z') target.transform.z = Number(val);
    else if (prop === 'rotation') target.transform.rotation = Number(val);
    else if (prop === 'rotationX') target.transform.rotationX = Number(val);
    else if (prop === 'rotationY') target.transform.rotationY = Number(val);
    else if (prop === 'scale' || prop === 'scaleX') {
      target.transform.scaleX = Number(val);
      target.transform.scaleY = Number(val);
    }
    else if (prop === 'scaleY') target.transform.scaleY = Number(val);
    else if (prop === 'opacity') target.style.opacity = Math.max(0, Math.min(1, Number(val)));
    else if (prop === 'fill') target.style.fill = String(val);
    else if (prop === 'stroke') target.style.stroke = String(val);
    else if (prop === 'strokeWidth') target.style.strokeWidth = Math.max(0, Number(val));
    else if (prop === 'blur') target.style.blur = Math.max(0, Number(val));
    else if (prop === 'trimStart') target.style.trimStart = Number(val);
    else if (prop === 'trimEnd') target.style.trimEnd = Number(val);
    else if (prop === 'trimOffset') target.style.trimOffset = Number(val);
    else if (prop === 'glow.blur') target.style.glow.blur = Number(val);
    else if (prop === 'glow.intensity') target.style.glow.intensity = Number(val);
    else if (prop === 'width') target.width = Number(val);
    else if (prop === 'height') target.height = Number(val);
    else if (prop === 'radius') target.radius = Number(val);
  });

  // Evaluate Camera
  const cam = { ...comp.camera };
  if (audio && audio.beat && cam.shake > 0) {
    cam.x += (Math.random() - 0.5) * cam.shake * 15;
    cam.y += (Math.random() - 0.5) * cam.shake * 15;
  }

  // Camera tracking target
  if (cam.targetId) {
    const target = objMap.get(cam.targetId);
    if (target) {
      cam.x += (target.transform.x - cam.x) * (cam.followDamping || 0.1);
      cam.y += (target.transform.y - cam.y) * (cam.followDamping || 0.1);
    }
  }

  // Compute world transforms & hierarchy
  const evaluatedObjects: EvaluatedObject[] = [];

  comp.objects.forEach((obj, index) => {
    if (!obj.visible) return;
    const computed = objMap.get(obj.id);
    if (!computed) return;

    let worldTransform: Transform2D = { ...computed.transform };

    // Parent propagation
    if (obj.parentId) {
      const parent = objMap.get(obj.parentId);
      if (parent) {
        const rad = (parent.transform.rotation * Math.PI) / 180;
        const cos = Math.cos(rad);
        const sin = Math.sin(rad);

        const lx = worldTransform.x * parent.transform.scaleX;
        const ly = worldTransform.y * parent.transform.scaleY;

        worldTransform.x = parent.transform.x + (lx * cos - ly * sin);
        worldTransform.y = parent.transform.y + (lx * sin + ly * cos);
        worldTransform.rotation += parent.transform.rotation;
        worldTransform.scaleX *= parent.transform.scaleX;
        worldTransform.scaleY *= parent.transform.scaleY;
      }
    }

    // Look At Constraint
    if (obj.constraints?.lookAtTargetId) {
      const target = objMap.get(obj.constraints.lookAtTargetId);
      if (target) {
        const dx = target.transform.x - worldTransform.x;
        const dy = target.transform.y - worldTransform.y;
        worldTransform.rotation = (Math.atan2(dy, dx) * 180) / Math.PI;
      }
    }

    // Path Morph evaluation
    let computedPathData = obj.pathData;
    if (obj.morphConfig && obj.morphConfig.sourcePath && obj.morphConfig.targetPath) {
      const morphTrack = comp.tracks.find(
        (t) => t.targetId === obj.id && t.property === 'morphProgress'
      );
      const morphP = morphTrack
        ? Number(interpolateValue(morphTrack, time))
        : obj.morphConfig.morphProgress;
      computedPathData = morphPathSvg(
        obj.morphConfig.sourcePath,
        obj.morphConfig.targetPath,
        morphP
      );
    }

    // Kinetic typography split items
    let splitTextItems: EvaluatedObject['splitTextItems'];
    if (obj.type === 'text' && obj.textProps && obj.textProps.splitMode !== 'none') {
      const txt = obj.textProps.text;
      const items =
        obj.textProps.splitMode === 'chars'
          ? txt.split('')
          : obj.textProps.splitMode === 'words'
          ? txt.split(' ')
          : txt.split('\n');

      const staggerDelay = obj.textProps.staggerDelay || 0.05;
      const fontSize = obj.textProps.fontSize || 32;
      const spacing = obj.textProps.letterSpacing || fontSize * 0.6;

      splitTextItems = items.map((char, cIdx) => {
        const charTime = Math.max(0, time - cIdx * staggerDelay);
        const charProgress = Math.min(1, charTime / 0.4);
        const ease = evaluateEasing(charProgress, 'elastic_out');

        let offsetY = 0;
        let charScale = 1;
        let charOpacity = 1;
        let charRot = 0;

        if (obj.textProps?.cascadePreset === 'wave') {
          offsetY = Math.sin(time * 5 + cIdx * 0.5) * 15;
        } else if (obj.textProps?.cascadePreset === 'slide') {
          offsetY = (1 - ease) * 40;
          charOpacity = ease;
        } else if (obj.textProps?.cascadePreset === 'pop') {
          charScale = ease;
          charOpacity = charProgress > 0 ? 1 : 0;
        } else if (obj.textProps?.cascadePreset === 'typewriter') {
          charOpacity = time >= cIdx * staggerDelay ? 1 : 0;
        } else {
          charOpacity = ease;
          charScale = 0.5 + ease * 0.5;
        }

        return {
          text: char,
          x: cIdx * spacing - (items.length * spacing) / 2,
          y: offsetY,
          rotation: charRot,
          scale: charScale,
          opacity: charOpacity * computed.style.opacity,
        };
      });
    }

    evaluatedObjects.push({
      object: obj,
      worldTransform,
      computedStyle: computed.style,
      computedPathData,
      splitTextItems,
      computedRadius: computed.radius,
      computedWidth: computed.width,
      computedHeight: computed.height,
    });
  });

  return {
    time,
    frame,
    camera: {
      x: cam.x,
      y: cam.y,
      z: cam.z,
      rotation: cam.rotation,
      rotationX: cam.rotationX,
      rotationY: cam.rotationY,
      zoom: 1000 / (cam.z || 1000),
    },
    objects: evaluatedObjects,
    width: comp.width || 1280,
    height: comp.height || 720,
    backgroundColor: comp.backgroundColor || '#0a0b10',
  };
}
