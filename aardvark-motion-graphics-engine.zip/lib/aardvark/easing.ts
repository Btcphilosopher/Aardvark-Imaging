import { BezierHandle, EasingType } from './types';

// Cubic Bezier calculation using Newton-Raphson
function cubicBezier(t: number, p1x: number, p1y: number, p2x: number, p2y: number): number {
  const cx = 3.0 * p1x;
  const bx = 3.0 * (p2x - p1x) - cx;
  const ax = 1.0 - cx - bx;

  const cy = 3.0 * p1y;
  const by = 3.0 * (p2y - p1y) - cy;
  const ay = 1.0 - cy - by;

  function sampleCurveX(t: number) {
    return ((ax * t + bx) * t + cx) * t;
  }

  function sampleCurveY(t: number) {
    return ((ay * t + by) * t + cy) * t;
  }

  function sampleCurveDerivativeX(t: number) {
    return (3.0 * ax * t + 2.0 * bx) * t + cx;
  }

  // Solve for t given x with Newton-Raphson
  let x = t;
  let t2 = x;
  for (let i = 0; i < 8; i++) {
    const x2 = sampleCurveX(t2) - x;
    if (Math.abs(x2) < 1e-6) return sampleCurveY(t2);
    const d2 = sampleCurveDerivativeX(t2);
    if (Math.abs(d2) < 1e-6) break;
    t2 = t2 - x2 / d2;
  }

  // Fallback bisection
  let t0 = 0.0;
  let t1 = 1.0;
  t2 = x;
  if (t2 < t0) return sampleCurveY(t0);
  if (t2 > t1) return sampleCurveY(t1);

  while (t0 < t1) {
    const x2 = sampleCurveX(t2);
    if (Math.abs(x2 - x) < 1e-6) return sampleCurveY(t2);
    if (x > x2) t0 = t2;
    else t1 = t2;
    t2 = (t1 - t0) * 0.5 + t0;
  }

  return sampleCurveY(t2);
}

export function evaluateEasing(
  t: number,
  type: EasingType,
  inHandle?: BezierHandle,
  outHandle?: BezierHandle
): number {
  const clampT = Math.max(0, Math.min(1, t));

  switch (type) {
    case 'hold':
      return clampT >= 1 ? 1 : 0;

    case 'linear':
      return clampT;

    case 'ease_in':
      return clampT * clampT;

    case 'ease_out':
      return clampT * (2 - clampT);

    case 'ease_in_out':
      return clampT < 0.5 ? 2 * clampT * clampT : -1 + (4 - 2 * clampT) * clampT;

    case 'cubic_in':
      return clampT * clampT * clampT;

    case 'cubic_out':
      return --t * t * t + 1;

    case 'cubic_in_out':
      return clampT < 0.5 ? 4 * clampT * clampT * clampT : (clampT - 1) * (2 * clampT - 2) * (2 * clampT - 2) + 1;

    case 'quartic_in_out':
      return clampT < 0.5 ? 8 * clampT * clampT * clampT * clampT : 1 - 8 * --t * t * t * t;

    case 'quintic_in_out':
      return clampT < 0.5 ? 16 * clampT * clampT * clampT * clampT * clampT : 1 + 16 * --t * t * t * t * t;

    case 'expo_out':
      return clampT === 1 ? 1 : 1 - Math.pow(2, -10 * clampT);

    case 'circ_in_out':
      return clampT < 0.5
        ? (1 - Math.sqrt(1 - 4 * (clampT * clampT))) / 2
        : (Math.sqrt(1 - (2 * clampT - 2) * (2 * clampT - 2)) + 1) / 2;

    case 'back_in': {
      const c1 = 1.70158;
      const c3 = c1 + 1;
      return c3 * clampT * clampT * clampT - c1 * clampT * clampT;
    }

    case 'back_out': {
      const c1 = 1.70158;
      const c3 = c1 + 1;
      return 1 + c3 * Math.pow(clampT - 1, 3) + c1 * Math.pow(clampT - 1, 2);
    }

    case 'back_in_out': {
      const c1 = 1.70158;
      const c2 = c1 * 1.525;
      return clampT < 0.5
        ? (Math.pow(2 * clampT, 2) * ((c2 + 1) * 2 * clampT - c2)) / 2
        : (Math.pow(2 * clampT - 2, 2) * ((c2 + 1) * (clampT * 2 - 2) + c2) + 2) / 2;
    }

    case 'elastic_in': {
      if (clampT === 0) return 0;
      if (clampT === 1) return 1;
      return -Math.pow(2, 10 * (clampT - 1)) * Math.sin(((clampT - 1.1) * 5 * Math.PI) / 0.4);
    }

    case 'elastic_out': {
      if (clampT === 0) return 0;
      if (clampT === 1) return 1;
      return Math.pow(2, -10 * clampT) * Math.sin(((clampT - 0.1) * 5 * Math.PI) / 0.4) + 1;
    }

    case 'elastic_in_out': {
      if (clampT === 0) return 0;
      if (clampT === 1) return 1;
      const cT = clampT * 2;
      if (cT < 1) {
        return -0.5 * Math.pow(2, 10 * (cT - 1)) * Math.sin(((cT - 1.1) * 5 * Math.PI) / 0.4);
      }
      return 0.5 * Math.pow(2, -10 * (cT - 1)) * Math.sin(((cT - 1.1) * 5 * Math.PI) / 0.4) + 1;
    }

    case 'bounce_out': {
      const n1 = 7.5625;
      const d1 = 2.75;
      let x = clampT;
      if (x < 1 / d1) {
        return n1 * x * x;
      } else if (x < 2 / d1) {
        return n1 * (x -= 1.5 / d1) * x + 0.75;
      } else if (x < 2.5 / d1) {
        return n1 * (x -= 2.25 / d1) * x + 0.9375;
      } else {
        return n1 * (x -= 2.625 / d1) * x + 0.984375;
      }
    }

    case 'bounce_in_out': {
      return clampT < 0.5
        ? (1 - evaluateEasing(1 - 2 * clampT, 'bounce_out')) / 2
        : (1 + evaluateEasing(2 * clampT - 1, 'bounce_out')) / 2;
    }

    case 'spring': {
      // Damped harmonic spring: 1 - exp(-d*t) * cos(w*t)
      const damping = 6.0;
      const frequency = 12.0;
      return 1 - Math.exp(-damping * clampT) * Math.cos(frequency * clampT);
    }

    case 'overshoot': {
      const s = 2.4;
      const tNorm = clampT - 1;
      return tNorm * tNorm * ((s + 1) * tNorm + s) + 1;
    }

    case 'bezier':
    case 'custom': {
      const p1x = outHandle ? Math.max(0, Math.min(1, outHandle.x)) : 0.25;
      const p1y = outHandle ? outHandle.y : 0.1;
      const p2x = inHandle ? Math.max(0, Math.min(1, inHandle.x)) : 0.25;
      const p2y = inHandle ? inHandle.y : 1.0;
      return cubicBezier(clampT, p1x, p1y, p2x, p2y);
    }

    default:
      return clampT;
  }
}
