import { AudioBands } from './types';

// Fast 1D & 2D Perlin/Simplex-style gradient noise generator for deterministic animation
class FastNoise {
  private perm: number[];

  constructor(seed = 1337) {
    this.perm = new Array(512);
    const p = new Array(256);
    for (let i = 0; i < 256; i++) p[i] = i;
    // Fisher-Yates shuffle with seed
    let s = seed % 2147483647;
    if (s <= 0) s += 2147483646;
    for (let i = 255; i > 0; i--) {
      s = (s * 16807) % 2147483647;
      const j = Math.floor((s / 2147483647) * (i + 1));
      const tmp = p[i];
      p[i] = p[j];
      p[j] = tmp;
    }
    for (let i = 0; i < 512; i++) {
      this.perm[i] = p[i & 255];
    }
  }

  private fade(t: number) {
    return t * t * t * (t * (t * 6 - 15) + 10);
  }

  private lerp(t: number, a: number, b: number) {
    return a + t * (b - a);
  }

  private grad1d(hash: number, x: number) {
    return (hash & 1) === 0 ? x : -x;
  }

  private grad2d(hash: number, x: number, y: number) {
    const h = hash & 3;
    const u = h < 2 ? x : y;
    const v = h < 2 ? y : x;
    return ((h & 1) === 0 ? u : -u) + ((h & 2) === 0 ? v : -v);
  }

  noise1D(x: number): number {
    const X = Math.floor(x) & 255;
    const xf = x - Math.floor(x);
    const u = this.fade(xf);
    return this.lerp(u, this.grad1d(this.perm[X], xf), this.grad1d(this.perm[X + 1], xf - 1)) * 2;
  }

  noise2D(x: number, y: number): number {
    const X = Math.floor(x) & 255;
    const Y = Math.floor(y) & 255;
    const xf = x - Math.floor(x);
    const yf = y - Math.floor(y);
    const u = this.fade(xf);
    const v = this.fade(yf);

    const aa = this.perm[this.perm[X] + Y];
    const ab = this.perm[this.perm[X] + Y + 1];
    const ba = this.perm[this.perm[X + 1] + Y];
    const bb = this.perm[this.perm[X + 1] + Y + 1];

    const x1 = this.lerp(u, this.grad2d(aa, xf, yf), this.grad2d(ba, xf - 1, yf));
    const x2 = this.lerp(u, this.grad2d(ab, xf, yf - 1), this.grad2d(bb, xf - 1, yf - 1));
    return this.lerp(v, x1, x2);
  }
}

const defaultNoise = new FastNoise(4242);

export interface ExpressionContext {
  time: number; // in seconds
  frame: number;
  fps: number;
  duration: number;
  progress: number; // 0 to 1
  mouseX?: number;
  mouseY?: number;
  audio?: AudioBands;
  randomSeed?: number;
  index?: number;
  total?: number;
  val?: number; // current keyframed value
  obj?: {
    x: number;
    y: number;
    rotation: number;
    scale: number;
    opacity: number;
  };
}

export function evaluateAardExpression(
  expressionStr: string,
  ctx: ExpressionContext
): number | string {
  const trimmed = expressionStr.trim();
  if (!trimmed) return ctx.val ?? 0;

  try {
    const time = ctx.time;
    const frame = ctx.frame;
    const fps = ctx.fps;
    const duration = ctx.duration;
    const progress = ctx.progress;
    const mouse_x = ctx.mouseX ?? 0;
    const mouse_y = ctx.mouseY ?? 0;
    const index = ctx.index ?? 0;
    const total = ctx.total ?? 1;
    const val = ctx.val ?? 0;
    const value = val;

    const audio_amplitude = ctx.audio?.volume ?? 0;
    const audio_bass = ctx.audio?.bass ?? 0;
    const audio_mid = ctx.audio?.mid ?? 0;
    const audio_treble = ctx.audio?.treble ?? 0;
    const audio_beat = ctx.audio?.beat ? 1 : 0;

    const object_x = ctx.obj?.x ?? 0;
    const object_y = ctx.obj?.y ?? 0;
    const object_rotation = ctx.obj?.rotation ?? 0;
    const object_scale = ctx.obj?.scale ?? 1;
    const object_opacity = ctx.obj?.opacity ?? 1;

    // Procedural Motion Functions
    const oscillate = (freq = 1, amp = 50, phase = 0) => Math.sin(time * freq * Math.PI * 2 + phase) * amp;
    const bounce = (freq = 2, decay = 2) => Math.abs(Math.sin(time * freq * Math.PI * 2)) * Math.exp(-time * decay);
    const spring = (stiffness = 100, damping = 10, mass = 1) => {
      const omega = Math.sqrt(stiffness / mass);
      const zeta = damping / (2 * Math.sqrt(stiffness * mass));
      return 1 - Math.exp(-zeta * omega * time) * Math.cos(omega * Math.sqrt(1 - zeta * zeta) * time);
    };
    const pulse = (freq = 2, duty = 0.5) => ((time * freq) % 1 < duty ? 1 : 0);
    const shake = (freq = 10, amp = 10) => defaultNoise.noise1D(time * freq) * amp;
    const wiggle = (freq = 5, amp = 20) => defaultNoise.noise1D(time * freq + index * 10) * amp;
    const orbit_x = (radius = 100, speed = 1, centerX = 0) => centerX + Math.cos(time * speed * Math.PI * 2) * radius;
    const orbit_y = (radius = 100, speed = 1, centerY = 0) => centerY + Math.sin(time * speed * Math.PI * 2) * radius;
    const spiral = (speed = 1, expansion = 20) => time * speed * expansion;
    const pendulum = (amp = 45, freq = 1) => Math.sin(time * freq * Math.PI * 2) * amp;
    const ping_pong = (min = 0, max = 100, speed = 1) => {
      const range = max - min;
      const t = (time * speed) % 2;
      return min + (t > 1 ? (2 - t) * range : t * range);
    };
    const random_walk = (speed = 1, amp = 50) => defaultNoise.noise1D(time * speed) * amp;
    const noise_motion = (scale = 1, freq = 1) => defaultNoise.noise1D(time * freq) * scale;
    const noise2d = (x: number, y: number) => defaultNoise.noise2D(x, y);

    // Math helpers
    const sin = Math.sin;
    const cos = Math.cos;
    const tan = Math.tan;
    const abs = Math.abs;
    const min = Math.min;
    const max = Math.max;
    const sqrt = Math.sqrt;
    const PI = Math.PI;
    const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));
    const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
    const smoothstep = (minVal: number, maxVal: number, v: number) => {
      const x = Math.max(0, Math.min(1, (v - minVal) / (maxVal - minVal)));
      return x * x * (3 - 2 * x);
    };
    const map = (v: number, inMin: number, inMax: number, outMin: number, outMax: number) =>
      outMin + ((v - inMin) / (inMax - inMin)) * (outMax - outMin);
    const stagger = (offsetSec = 0.1) => Math.max(0, time - index * offsetSec);

    // Safe Function Constructor execution
    const fn = new Function(
      'time', 'frame', 'fps', 'duration', 'progress', 'mouse_x', 'mouse_y', 'index', 'total', 'val', 'value',
      'audio_amplitude', 'audio_bass', 'audio_mid', 'audio_treble', 'audio_beat',
      'object_x', 'object_y', 'object_rotation', 'object_scale', 'object_opacity',
      'oscillate', 'bounce', 'spring', 'pulse', 'shake', 'wiggle', 'orbit_x', 'orbit_y',
      'spiral', 'pendulum', 'ping_pong', 'random_walk', 'noise_motion', 'noise2d',
      'sin', 'cos', 'tan', 'abs', 'min', 'max', 'sqrt', 'PI', 'clamp', 'lerp', 'smoothstep', 'map', 'stagger',
      `return (${trimmed});`
    );

    const result = fn(
      time, frame, fps, duration, progress, mouse_x, mouse_y, index, total, val, value,
      audio_amplitude, audio_bass, audio_mid, audio_treble, audio_beat,
      object_x, object_y, object_rotation, object_scale, object_opacity,
      oscillate, bounce, spring, pulse, shake, wiggle, orbit_x, orbit_y,
      spiral, pendulum, ping_pong, random_walk, noise_motion, noise2d,
      sin, cos, tan, abs, min, max, sqrt, PI, clamp, lerp, smoothstep, map, stagger
    );

    return typeof result === 'number' && !isNaN(result) ? result : (result ?? val);
  } catch {
    // If expression has a syntax error or is in mid-edit, fallback gracefully
    return ctx.val ?? 0;
  }
}
