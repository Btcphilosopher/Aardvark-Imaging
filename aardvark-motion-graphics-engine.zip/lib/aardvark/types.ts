export type ShapeType =
  | 'rect'
  | 'circle'
  | 'ellipse'
  | 'star'
  | 'polygon'
  | 'path'
  | 'line'
  | 'text'
  | 'particle_emitter'
  | 'flow_field'
  | 'group'
  | 'chart'
  | 'camera';

export type EasingType =
  | 'linear'
  | 'hold'
  | 'bezier'
  | 'ease_in'
  | 'ease_out'
  | 'ease_in_out'
  | 'cubic_in'
  | 'cubic_out'
  | 'cubic_in_out'
  | 'quartic_in_out'
  | 'quintic_in_out'
  | 'expo_out'
  | 'circ_in_out'
  | 'back_in'
  | 'back_out'
  | 'back_in_out'
  | 'elastic_in'
  | 'elastic_out'
  | 'elastic_in_out'
  | 'bounce_out'
  | 'bounce_in_out'
  | 'spring'
  | 'overshoot'
  | 'custom';

export interface BezierHandle {
  x: number; // 0 to 1 relative to keyframe span
  y: number; // Value influence
}

export interface AardKeyframe<T = number | string | boolean> {
  id: string;
  time: number; // in seconds
  frame: number;
  value: T;
  easing: EasingType;
  inHandle?: BezierHandle; // For curve editor
  outHandle?: BezierHandle;
  springParams?: {
    stiffness: number;
    damping: number;
    mass: number;
  };
}

export interface AardTrack<T = number | string | boolean> {
  id: string;
  property: string; // e.g. 'position.x', 'rotation', 'scale', 'opacity', 'fill', 'strokeWidth'
  targetId: string;
  keyframes: AardKeyframe<T>[];
  expression?: string; // e.g. 'sin(time * 3) * 50 + wiggle(2, 10)'
  isExpressionActive?: boolean;
  disabled?: boolean;
}

export interface Transform2D {
  x: number;
  y: number;
  z: number; // 2.5D depth
  rotation: number; // degrees
  rotationX?: number; // 2.5D tilt
  rotationY?: number;
  scaleX: number;
  scaleY: number;
  anchorX: number; // 0..1 or absolute
  anchorY: number;
  skewX: number;
  skewY: number;
}

export interface StyleProperties {
  fill: string;
  fillOpacity: number;
  stroke: string;
  strokeWidth: number;
  strokeOpacity: number;
  strokeDashArray?: number[];
  strokeDashOffset: number;
  opacity: number;
  blendMode: GlobalCompositeOperation;
  blur: number;
  glow: {
    enabled: boolean;
    color: string;
    blur: number;
    intensity: number;
  };
  shadow: {
    enabled: boolean;
    color: string;
    offsetX: number;
    offsetY: number;
    blur: number;
  };
  trimStart: number; // 0 to 1 (path reveal)
  trimEnd: number; // 0 to 1
  trimOffset: number; // 0 to 1
  cornerRadius?: number;
}

export interface TextProperties {
  text: string;
  fontSize: number;
  fontFamily: string;
  fontWeight: string;
  fontStyle: string;
  textAlign: 'left' | 'center' | 'right';
  letterSpacing: number;
  lineHeight: number;
  splitMode: 'none' | 'chars' | 'words' | 'lines';
  staggerDelay: number; // in seconds per split item
  cascadePreset?: 'wave' | 'slide' | 'pop' | 'typewriter' | 'tracking_expand' | 'fade_slide';
}

export interface ParticleEmitterConfig {
  type: 'burst' | 'continuous' | 'stream' | 'vortex' | 'geometric_shatter';
  rate: number; // particles per second
  maxParticles: number;
  particleLife: number; // seconds
  speedMin: number;
  speedMax: number;
  angleMin: number;
  angleMax: number;
  sizeMin: number;
  sizeMax: number;
  colorStart: string;
  colorEnd: string;
  opacityStart: number;
  opacityEnd: number;
  gravity: number;
  wind: number;
  turbulence: number;
  shape: 'circle' | 'square' | 'star' | 'triangle' | 'spark' | 'ring';
  trailLength: number;
}

export interface FlowFieldConfig {
  noiseScale: number;
  speed: number;
  particleCount: number;
  fieldColor: string;
  lineLength: number;
  lineWidth: number;
  curlNoise: boolean;
  octaves: number;
}

export interface ChartConfig {
  chartType: 'bar' | 'line' | 'pie' | 'radar';
  dataPoints: { label: string; value: number; color?: string }[];
  animationProgress: number; // 0 to 1
  showLabels: boolean;
  barWidth: number;
}

export interface PathMorphConfig {
  sourcePath: string; // SVG path data 'M 10 10 L 90 90...'
  targetPath: string;
  morphProgress: number; // 0 to 1
}

export interface FXChainNode {
  id: string;
  type: 'chromatic_aberration' | 'pixelate' | 'scanline' | 'vignette' | 'color_shift' | 'displacement_wave' | 'halftone';
  enabled: boolean;
  params: Record<string, number | string | boolean>;
}

export interface AardObject {
  id: string;
  name: string;
  type: ShapeType;
  visible: boolean;
  locked: boolean;
  parentId?: string;
  
  // Transform
  transform: Transform2D;
  
  // Geometry parameters
  width: number;
  height: number;
  radius?: number;
  innerRadius?: number;
  points?: number; // For star or polygon
  pathData?: string; // SVG path d attribute
  polylinePoints?: { x: number; y: number }[];
  
  // Special configs
  textProps?: TextProperties;
  particleConfig?: ParticleEmitterConfig;
  flowFieldConfig?: FlowFieldConfig;
  chartConfig?: ChartConfig;
  morphConfig?: PathMorphConfig;
  
  // Style
  style: StyleProperties;
  
  // Constraints & Parenting
  constraints?: {
    lookAtTargetId?: string;
    followPathTargetId?: string;
    followPathProgress?: number;
    distanceConstraint?: { targetId: string; distance: number };
  };

  // FX Chain
  fxNodes: FXChainNode[];

  // Custom metadata & tags
  tags?: string[];
}

export interface Camera25D {
  x: number;
  y: number;
  z: number; // Zoom/depth (e.g. 1000 = normal, 500 = zoom in)
  rotation: number;
  rotationX: number; // pitch
  rotationY: number; // yaw
  shake: number; // shake intensity
  shakeFrequency: number;
  targetId?: string;
  followDamping: number;
  depthOfField: {
    enabled: boolean;
    focalDistance: number;
    aperture: number;
  };
}

export interface TimelineMarker {
  id: string;
  time: number;
  label: string;
  color: string;
}

export interface AardComposition {
  id: string;
  name: string;
  width: number;
  height: number;
  fps: number;
  duration: number; // in seconds
  workAreaStart: number; // in seconds
  workAreaEnd: number; // in seconds
  backgroundColor: string;
  objects: AardObject[];
  tracks: AardTrack[];
  camera: Camera25D;
  markers: TimelineMarker[];
  motionBlur: {
    enabled: boolean;
    samples: number;
    shutterAngle: number;
  };
  onionSkinning: {
    enabled: boolean;
    prevFrames: number;
    nextFrames: number;
    opacity: number;
  };
}

export interface AardDocument {
  version: string;
  title: string;
  created: string;
  activeCompositionId: string;
  compositions: AardComposition[];
  brandTokens?: {
    primaryColor: string;
    secondaryColor: string;
    accentColor: string;
    defaultEasing: EasingType;
    defaultDuration: number;
    staggerStep: number;
    springStiffness: number;
    springDamping: number;
  };
  audioReactive?: {
    enabled: boolean;
    audioSource: 'synthesizer' | 'mic' | 'file';
    audioUrl?: string;
    bassGain: number;
    midGain: number;
    trebleGain: number;
    smoothing: number;
  };
}

export interface PlaybackState {
  isPlaying: boolean;
  isLooping: boolean;
  currentTime: number; // seconds
  currentFrame: number;
  speed: number; // 0.1x to 8x
  isRecording: boolean;
  quality: 'draft' | 'preview' | 'full' | 'final';
}

export interface AudioBands {
  volume: number;
  bass: number;
  mid: number;
  treble: number;
  beat: boolean;
  rawFft?: number[];
}

export interface NodeGraphNode {
  id: string;
  name: string;
  type: 'time' | 'sine' | 'cosine' | 'noise' | 'spring' | 'lerp' | 'clamp' | 'random' | 'math' | 'property_out' | 'object_in';
  x: number;
  y: number;
  inputs: { id: string; name: string; type: string; value?: number | string }[];
  outputs: { id: string; name: string; type: string }[];
  params: Record<string, number | string>;
}

export interface NodeGraphConnection {
  id: string;
  fromNodeId: string;
  fromOutputId: string;
  toNodeId: string;
  toInputId: string;
}
