import { AardComposition, AardDocument, AardObject, AardTrack } from './types';

export function documentToAardPythonScript(doc: AardDocument): string {
  const comp = doc.compositions.find((c) => c.id === doc.activeCompositionId) || doc.compositions[0];
  if (!comp) return '# Empty Aardvark Document';

  const lines: string[] = [
    '# ===================================================',
    '# AARDVARK IMAGING - MOTION GRAPHICS PYTHON API',
    '# Computational 2D Vector Animation & Procedural Time',
    '# ===================================================',
    '',
    'from aardvark.motion import AardDocument, Easing, Oscillate, Wiggle, Spring',
    '',
    `doc = AardDocument(title="${doc.title}", width=${comp.width}, height=${comp.height}, fps=${comp.fps})`,
    `comp = doc.get_active_composition()`,
    `comp.set_duration(${comp.duration})`,
    `comp.set_background_color("${comp.backgroundColor}")`,
    '',
  ];

  comp.objects.forEach((obj) => {
    lines.push(`# --- Object: ${obj.name} (${obj.type}) ---`);
    if (obj.type === 'rect') {
      lines.push(
        `${obj.id} = comp.add_rect(name="${obj.name}", x=${obj.transform.x}, y=${obj.transform.y}, width=${obj.width}, height=${obj.height}, fill="${obj.style.fill}", stroke="${obj.style.stroke}", stroke_width=${obj.style.strokeWidth})`
      );
    } else if (obj.type === 'circle') {
      lines.push(
        `${obj.id} = comp.add_circle(name="${obj.name}", x=${obj.transform.x}, y=${obj.transform.y}, radius=${obj.radius || 40}, fill="${obj.style.fill}", stroke="${obj.style.stroke}")`
      );
    } else if (obj.type === 'star') {
      lines.push(
        `${obj.id} = comp.add_star(name="${obj.name}", x=${obj.transform.x}, y=${obj.transform.y}, points=${obj.points || 5}, radius=${obj.radius || 50}, fill="${obj.style.fill}")`
      );
    } else if (obj.type === 'polygon') {
      lines.push(
        `${obj.id} = comp.add_polygon(name="${obj.name}", x=${obj.transform.x}, y=${obj.transform.y}, sides=${obj.points || 6}, radius=${obj.radius || 50}, fill="${obj.style.fill}")`
      );
    } else if (obj.type === 'text') {
      lines.push(
        `${obj.id} = comp.add_text("${obj.textProps?.text || 'Text'}", name="${obj.name}", x=${obj.transform.x}, y=${obj.transform.y}, font_size=${obj.textProps?.fontSize || 36}, fill="${obj.style.fill}")`
      );
      if (obj.textProps?.splitMode && obj.textProps.splitMode !== 'none') {
        lines.push(
          `${obj.id}.set_kinetic_typography(split="${obj.textProps.splitMode}", preset="${obj.textProps.cascadePreset || 'wave'}", stagger=${obj.textProps.staggerDelay || 0.05})`
        );
      }
    } else if (obj.type === 'particle_emitter') {
      lines.push(
        `${obj.id} = comp.add_particle_emitter(name="${obj.name}", x=${obj.transform.x}, y=${obj.transform.y}, max_particles=${obj.particleConfig?.maxParticles || 100}, shape="${obj.particleConfig?.shape || 'circle'}", color_start="${obj.particleConfig?.colorStart || '#38bdf8'}", color_end="${obj.particleConfig?.colorEnd || '#f43f5e'}")`
      );
    } else if (obj.type === 'flow_field') {
      lines.push(
        `${obj.id} = comp.add_flow_field(name="${obj.name}", x=${obj.transform.x}, y=${obj.transform.y}, noise_scale=${obj.flowFieldConfig?.noiseScale || 2}, count=${obj.flowFieldConfig?.particleCount || 150})`
      );
    } else if (obj.type === 'chart') {
      lines.push(
        `${obj.id} = comp.add_animated_chart(name="${obj.name}", x=${obj.transform.x}, y=${obj.transform.y}, chart_type="${obj.chartConfig?.chartType || 'bar'}")`
      );
    }

    // Tracks for this object
    const tracks = comp.tracks.filter((t) => t.targetId === obj.id);
    tracks.forEach((track) => {
      if (track.isExpressionActive && track.expression) {
        lines.push(`${obj.id}.set_expression("${track.property}", "${track.expression}")`);
      } else if (track.keyframes.length > 0) {
        track.keyframes.forEach((kf) => {
          lines.push(
            `${obj.id}.add_keyframe(property="${track.property}", time=${kf.time.toFixed(2)}, value=${typeof kf.value === 'string' ? `"${kf.value}"` : kf.value}, easing="${kf.easing}")`
          );
        });
      }
    });

    lines.push('');
  });

  lines.push('# Render animation pipeline');
  lines.push('doc.render_animation(fps=60, format="webm", quality="high")');

  return lines.join('\n');
}

export function parsePythonScriptToDocument(
  scriptText: string,
  existingDoc: AardDocument
): AardDocument {
  // A robust DSL parser that can reconstruct updated parameters from Python script edits
  const cloned: AardDocument = JSON.parse(JSON.stringify(existingDoc));
  const comp = cloned.compositions.find((c) => c.id === cloned.activeCompositionId) || cloned.compositions[0];
  if (!comp) return cloned;

  const lines = scriptText.split('\n');

  lines.forEach((line) => {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) return;

    // Check for set_expression: obj_id.set_expression("prop", "expr")
    const exprMatch = trimmed.match(/(\w+)\.set_expression\s*\(\s*["']([^"']+)["']\s*,\s*["']([^"']+)["']\s*\)/);
    if (exprMatch) {
      const [, targetId, prop, expr] = exprMatch;
      let track = comp.tracks.find((t) => t.targetId === targetId && t.property === prop);
      if (!track) {
        track = {
          id: `track_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          targetId,
          property: prop,
          keyframes: [],
          expression: expr,
          isExpressionActive: true,
        };
        comp.tracks.push(track);
      } else {
        track.expression = expr;
        track.isExpressionActive = true;
      }
    }

    // Check for comp.set_background_color("#hex")
    const bgMatch = trimmed.match(/comp\.set_background_color\s*\(\s*["']([^"']+)["']\s*\)/);
    if (bgMatch) {
      comp.backgroundColor = bgMatch[1];
    }

    // Check for comp.set_duration(num)
    const durMatch = trimmed.match(/comp\.set_duration\s*\(\s*(\d+(?:\.\d+)?)\s*\)/);
    if (durMatch) {
      comp.duration = parseFloat(durMatch[1]);
      comp.workAreaEnd = comp.duration;
    }
  });

  return cloned;
}
