import { EvaluatedFrame, EvaluatedObject } from './engine';
import { simulateParticles, computeFlowFieldVectors } from './particles';

export interface RenderOptions {
  showMotionPaths?: boolean;
  selectedObjectId?: string | null;
  showGrid?: boolean;
  showSafeFrames?: boolean;
  isDraft?: boolean;
}

export function renderFrameToCanvas(
  ctx: CanvasRenderingContext2D,
  frame: EvaluatedFrame,
  options: RenderOptions = {}
) {
  const { width, height, backgroundColor, camera, objects, time } = frame;
  const { showMotionPaths = false, selectedObjectId = null, showGrid = true, showSafeFrames = false } = options;

  // Clear canvas
  ctx.save();
  ctx.fillStyle = backgroundColor;
  ctx.fillRect(0, 0, width, height);

  // Background subtle grid
  if (showGrid) {
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
    ctx.lineWidth = 1;
    const step = 40;
    ctx.beginPath();
    for (let x = 0; x < width; x += step) {
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
    }
    for (let y = 0; y < height; y += step) {
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
    }
    ctx.stroke();

    // Center crosshair
    ctx.strokeStyle = 'rgba(99, 102, 241, 0.2)';
    ctx.beginPath();
    ctx.moveTo(width / 2, 0);
    ctx.lineTo(width / 2, height);
    ctx.moveTo(0, height / 2);
    ctx.lineTo(width, height / 2);
    ctx.stroke();
  }

  // Camera Transformation (2.5D perspective & pan/zoom)
  ctx.translate(width / 2, height / 2);
  const zoom = camera.zoom || 1;
  ctx.scale(zoom, zoom);
  ctx.rotate((camera.rotation * Math.PI) / 180);
  ctx.translate(-width / 2 - camera.x, -height / 2 - camera.y);

  // Render objects sorted by Z-index (2.5D depth)
  const sortedObjects = [...objects].sort((a, b) => (a.worldTransform.z || 0) - (b.worldTransform.z || 0));

  sortedObjects.forEach((evalObj) => {
    renderObject(ctx, evalObj, time);
  });

  // Render selection gizmo & motion path
  if (selectedObjectId) {
    const sel = objects.find((o) => o.object.id === selectedObjectId);
    if (sel) {
      renderSelectionGizmo(ctx, sel);
    }
  }

  // Safe frame boundaries
  if (showSafeFrames) {
    ctx.strokeStyle = 'rgba(234, 179, 8, 0.3)';
    ctx.lineWidth = 1;
    ctx.setLineDash([6, 6]);
    ctx.strokeRect(width * 0.05, height * 0.05, width * 0.9, height * 0.9);
    ctx.strokeRect(width * 0.1, height * 0.1, width * 0.8, height * 0.8);
    ctx.setLineDash([]);
  }

  ctx.restore();
}

function renderObject(
  ctx: CanvasRenderingContext2D,
  evalObj: EvaluatedObject,
  time: number
) {
  const { object, worldTransform, computedStyle, computedPathData, splitTextItems } = evalObj;

  ctx.save();

  // Position, Rotation, Scale
  ctx.translate(worldTransform.x, worldTransform.y);
  ctx.rotate((worldTransform.rotation * Math.PI) / 180);
  ctx.scale(worldTransform.scaleX, worldTransform.scaleY);
  ctx.transform(1, (worldTransform.skewY * Math.PI) / 180, (worldTransform.skewX * Math.PI) / 180, 1, 0, 0);

  // Alpha & Blend Mode
  ctx.globalAlpha = Math.max(0, Math.min(1, computedStyle.opacity));
  if (computedStyle.blendMode) {
    ctx.globalCompositeOperation = computedStyle.blendMode;
  }

  // Shadow
  if (computedStyle.shadow?.enabled) {
    ctx.shadowColor = computedStyle.shadow.color;
    ctx.shadowBlur = computedStyle.shadow.blur;
    ctx.shadowOffsetX = computedStyle.shadow.offsetX;
    ctx.shadowOffsetY = computedStyle.shadow.offsetY;
  }

  // Glow
  if (computedStyle.glow?.enabled) {
    ctx.shadowColor = computedStyle.glow.color;
    ctx.shadowBlur = computedStyle.glow.blur * (computedStyle.glow.intensity || 1);
  }

  // Set Fill & Stroke
  ctx.fillStyle = computedStyle.fill;
  ctx.strokeStyle = computedStyle.stroke;
  ctx.lineWidth = computedStyle.strokeWidth;

  // Render Geometry
  switch (object.type) {
    case 'rect': {
      const w = evalObj.computedWidth || object.width;
      const h = evalObj.computedHeight || object.height;
      const r = computedStyle.cornerRadius || 0;
      if (r > 0) {
        ctx.beginPath();
        ctx.roundRect(-w / 2, -h / 2, w, h, r);
        if (computedStyle.fill && computedStyle.fill !== 'transparent') ctx.fill();
        if (computedStyle.strokeWidth > 0) ctx.stroke();
      } else {
        if (computedStyle.fill && computedStyle.fill !== 'transparent') {
          ctx.fillRect(-w / 2, -h / 2, w, h);
        }
        if (computedStyle.strokeWidth > 0) {
          ctx.strokeRect(-w / 2, -h / 2, w, h);
        }
      }
      break;
    }

    case 'circle': {
      const rad = evalObj.computedRadius || object.radius || object.width / 2 || 40;
      ctx.beginPath();
      ctx.arc(0, 0, rad, 0, Math.PI * 2);
      if (computedStyle.fill && computedStyle.fill !== 'transparent') ctx.fill();
      if (computedStyle.strokeWidth > 0) ctx.stroke();
      break;
    }

    case 'ellipse': {
      const rx = (evalObj.computedWidth || object.width) / 2;
      const ry = (evalObj.computedHeight || object.height) / 2;
      ctx.beginPath();
      ctx.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2);
      if (computedStyle.fill && computedStyle.fill !== 'transparent') ctx.fill();
      if (computedStyle.strokeWidth > 0) ctx.stroke();
      break;
    }

    case 'star': {
      const pts = object.points || 5;
      const rOuter = evalObj.computedRadius || object.radius || 50;
      const rInner = object.innerRadius || rOuter * 0.45;
      ctx.beginPath();
      for (let i = 0; i < pts * 2; i++) {
        const r = i % 2 === 0 ? rOuter : rInner;
        const a = (i * Math.PI) / pts - Math.PI / 2;
        const x = Math.cos(a) * r;
        const y = Math.sin(a) * r;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      if (computedStyle.fill && computedStyle.fill !== 'transparent') ctx.fill();
      if (computedStyle.strokeWidth > 0) ctx.stroke();
      break;
    }

    case 'polygon': {
      const sides = object.points || 6;
      const rad = evalObj.computedRadius || object.radius || 50;
      ctx.beginPath();
      for (let i = 0; i < sides; i++) {
        const a = (i * 2 * Math.PI) / sides - Math.PI / 2;
        const x = Math.cos(a) * rad;
        const y = Math.sin(a) * rad;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      if (computedStyle.fill && computedStyle.fill !== 'transparent') ctx.fill();
      if (computedStyle.strokeWidth > 0) ctx.stroke();
      break;
    }

    case 'path': {
      if (computedPathData) {
        const p = new Path2D(computedPathData);
        // Handle trim path (path reveal)
        if (computedStyle.trimEnd < 1 || computedStyle.trimStart > 0) {
          ctx.setLineDash([computedStyle.trimEnd * 500, 500]);
          ctx.lineDashOffset = -computedStyle.trimStart * 500;
        }
        if (computedStyle.fill && computedStyle.fill !== 'transparent') ctx.fill(p);
        if (computedStyle.strokeWidth > 0) ctx.stroke(p);
      }
      break;
    }

    case 'text': {
      if (splitTextItems && splitTextItems.length > 0) {
        ctx.font = `${object.textProps?.fontWeight || 'bold'} ${object.textProps?.fontSize || 36}px ${object.textProps?.fontFamily || 'sans-serif'}`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';

        splitTextItems.forEach((charItem) => {
          ctx.save();
          ctx.translate(charItem.x, charItem.y);
          ctx.rotate((charItem.rotation * Math.PI) / 180);
          ctx.scale(charItem.scale, charItem.scale);
          ctx.globalAlpha = Math.max(0, Math.min(1, charItem.opacity));
          if (computedStyle.fill) ctx.fillText(charItem.text, 0, 0);
          if (computedStyle.strokeWidth > 0) ctx.strokeText(charItem.text, 0, 0);
          ctx.restore();
        });
      } else if (object.textProps) {
        ctx.font = `${object.textProps.fontWeight || 'bold'} ${object.textProps.fontSize || 36}px ${object.textProps.fontFamily || 'sans-serif'}`;
        ctx.textAlign = object.textProps.textAlign || 'center';
        ctx.textBaseline = 'middle';
        if (computedStyle.fill) ctx.fillText(object.textProps.text, 0, 0);
        if (computedStyle.strokeWidth > 0) ctx.strokeText(object.textProps.text, 0, 0);
      }
      break;
    }

    case 'particle_emitter': {
      if (object.particleConfig) {
        const particles = simulateParticles(object.particleConfig, 0, 0, time);
        particles.forEach((p) => {
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rotation);
          ctx.globalAlpha = p.opacity;
          ctx.fillStyle = p.color;

          // Render Particle Trail
          if (p.trail && p.trail.length > 1) {
            ctx.beginPath();
            ctx.strokeStyle = p.color;
            ctx.lineWidth = p.size * 0.6;
            ctx.moveTo(p.trail[0].x - p.x, p.trail[0].y - p.y);
            for (let t = 1; t < p.trail.length; t++) {
              ctx.lineTo(p.trail[t].x - p.x, p.trail[t].y - p.y);
            }
            ctx.stroke();
          }

          // Particle Shape
          if (object.particleConfig?.shape === 'star') {
            ctx.beginPath();
            for (let s = 0; s < 10; s++) {
              const r = s % 2 === 0 ? p.size : p.size * 0.4;
              const a = (s * Math.PI) / 5;
              if (s === 0) ctx.moveTo(Math.cos(a) * r, Math.sin(a) * r);
              else ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r);
            }
            ctx.fill();
          } else if (object.particleConfig?.shape === 'square') {
            ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
          } else {
            ctx.beginPath();
            ctx.arc(0, 0, p.size / 2, 0, Math.PI * 2);
            ctx.fill();
          }
          ctx.restore();
        });
      }
      break;
    }

    case 'flow_field': {
      if (object.flowFieldConfig) {
        const vectors = computeFlowFieldVectors(object.flowFieldConfig, time, object.width || 600, object.height || 400);
        ctx.strokeStyle = object.flowFieldConfig.fieldColor || '#38bdf8';
        ctx.lineWidth = object.flowFieldConfig.lineWidth || 1.5;
        ctx.beginPath();
        vectors.forEach((v) => {
          const len = object.flowFieldConfig?.lineLength || 20;
          const x2 = v.x - (object.width || 600) / 2 + Math.cos(v.angle) * len;
          const y2 = v.y - (object.height || 400) / 2 + Math.sin(v.angle) * len;
          const x1 = v.x - (object.width || 600) / 2;
          const y1 = v.y - (object.height || 400) / 2;
          ctx.moveTo(x1, y1);
          ctx.lineTo(x2, y2);
        });
        ctx.stroke();
      }
      break;
    }

    case 'chart': {
      if (object.chartConfig) {
        const { dataPoints, barWidth = 30 } = object.chartConfig;
        const totalW = dataPoints.length * (barWidth + 15);
        const startX = -totalW / 2;

        dataPoints.forEach((dp, dIdx) => {
          const bx = startX + dIdx * (barWidth + 15);
          const pProg = Math.min(1, Math.max(0, time * 1.5 - dIdx * 0.15));
          const bh = dp.value * pProg * 1.8;
          ctx.fillStyle = dp.color || computedStyle.fill || '#6366f1';
          ctx.fillRect(bx, 100 - bh, barWidth, bh);

          // Label
          ctx.fillStyle = '#ffffff';
          ctx.font = '12px sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText(dp.label, bx + barWidth / 2, 120);
          ctx.fillText(Math.round(dp.value * pProg).toString(), bx + barWidth / 2, 90 - bh);
        });
      }
      break;
    }
  }

  ctx.restore();
}

function renderSelectionGizmo(
  ctx: CanvasRenderingContext2D,
  evalObj: EvaluatedObject
) {
  const { worldTransform, computedWidth = 100, computedHeight = 100, computedRadius = 50 } = evalObj;

  ctx.save();
  ctx.translate(worldTransform.x, worldTransform.y);
  ctx.rotate((worldTransform.rotation * Math.PI) / 180);
  ctx.scale(worldTransform.scaleX, worldTransform.scaleY);

  const w = computedWidth || computedRadius * 2 || 100;
  const h = computedHeight || computedRadius * 2 || 100;

  // Bounding box
  ctx.strokeStyle = '#38bdf8';
  ctx.lineWidth = 1.5;
  ctx.setLineDash([4, 4]);
  ctx.strokeRect(-w / 2 - 8, -h / 2 - 8, w + 16, h + 16);
  ctx.setLineDash([]);

  // Corner control handles
  ctx.fillStyle = '#ffffff';
  ctx.strokeStyle = '#0284c7';
  const handleSize = 7;
  const corners = [
    { x: -w / 2 - 8, y: -h / 2 - 8 },
    { x: w / 2 + 8, y: -h / 2 - 8 },
    { x: w / 2 + 8, y: h / 2 + 8 },
    { x: -w / 2 - 8, y: h / 2 + 8 },
  ];
  corners.forEach((c) => {
    ctx.fillRect(c.x - handleSize / 2, c.y - handleSize / 2, handleSize, handleSize);
    ctx.strokeRect(c.x - handleSize / 2, c.y - handleSize / 2, handleSize, handleSize);
  });

  // Rotation handle on top
  ctx.beginPath();
  ctx.moveTo(0, -h / 2 - 8);
  ctx.lineTo(0, -h / 2 - 28);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(0, -h / 2 - 28, 4.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // Center anchor point indicator
  ctx.beginPath();
  ctx.strokeStyle = '#f43f5e';
  ctx.arc(0, 0, 4, 0, Math.PI * 2);
  ctx.stroke();

  ctx.restore();
}
