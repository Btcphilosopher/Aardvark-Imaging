'use client';

import React, { useState } from 'react';
import { AardComposition, AardObject, AardTrack, ShapeType } from '@/lib/aardvark/types';
import {
  Sliders,
  Sparkles,
  Type,
  Maximize,
  RotateCw,
  Sun,
  Eye,
  Key,
  Code,
  Layers,
  Wind,
  BarChart2,
  Trash2,
  Copy,
} from 'lucide-react';

interface InspectorPanelProps {
  composition: AardComposition;
  selectedObjectId: string | null;
  currentTime: number;
  onUpdateObject: (id: string, updates: Partial<AardObject>) => void;
  onUpdateObjectTransform: (id: string, updates: Partial<AardObject['transform']>) => void;
  onUpdateObjectStyle: (id: string, updates: Partial<AardObject['style']>) => void;
  onToggleKeyframe: (objectId: string, property: string, currentValue: number | string) => void;
  onSetExpression: (objectId: string, property: string, expression: string) => void;
  onDeleteObject: (id: string) => void;
}

export function InspectorPanel({
  composition,
  selectedObjectId,
  currentTime,
  onUpdateObject,
  onUpdateObjectTransform,
  onUpdateObjectStyle,
  onToggleKeyframe,
  onSetExpression,
  onDeleteObject,
}: InspectorPanelProps) {
  const [activeTab, setActiveTab] = useState<'properties' | 'expressions' | 'particles'>('properties');
  const [exprInputProp, setExprInputProp] = useState<string>('rotation');
  const [exprInputVal, setExprInputVal] = useState<string>('time * 90 + oscillate(freq=2, amp=20)');

  const selectedObj = composition.objects.find((o) => o.id === selectedObjectId);

  if (!selectedObj) {
    return (
      <div className="w-80 border-l border-white/10 bg-[#0c0d16] flex flex-col p-4 text-xs text-gray-400 select-none">
        <div className="flex items-center gap-2 text-gray-300 font-semibold mb-3">
          <Sliders className="w-4 h-4 text-indigo-400" />
          <span>PROPERTIES INSPECTOR</span>
        </div>
        <p className="text-gray-500 leading-relaxed">
          Select an object on the stage or timeline to inspect its animatable properties, kinetic typography, particle physics, and procedural expressions.
        </p>
      </div>
    );
  }

  const tracks = composition.tracks.filter((t) => t.targetId === selectedObj.id);
  const hasTrack = (prop: string) => tracks.some((t) => t.property === prop && t.keyframes.length > 0);
  const getExpr = (prop: string) => tracks.find((t) => t.property === prop && t.isExpressionActive)?.expression || '';

  return (
    <div className="w-80 border-l border-white/10 bg-[#0c0d16] flex flex-col h-full text-white text-xs select-none overflow-y-auto">
      {/* Header */}
      <div className="p-3 border-b border-white/10 bg-[#121422] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div
            className="w-3 h-3 rounded-full"
            style={{ backgroundColor: selectedObj.style.fill !== 'transparent' ? selectedObj.style.fill : selectedObj.style.stroke }}
          />
          <input
            id="input_obj_name"
            type="text"
            value={selectedObj.name}
            onChange={(e) => onUpdateObject(selectedObj.id, { name: e.target.value })}
            className="bg-transparent font-semibold text-white focus:outline-none focus:border-b border-indigo-400 text-xs w-36"
          />
        </div>

        <button
          id="btn_delete_selected_obj"
          onClick={() => onDeleteObject(selectedObj.id)}
          className="p-1 text-gray-500 hover:text-rose-400 rounded hover:bg-white/5 transition"
          title="Delete Object"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-white/10 bg-[#0f111d] text-[11px]">
        <button
          id="tab_props"
          onClick={() => setActiveTab('properties')}
          className={`flex-1 py-1.5 text-center font-medium transition-colors ${
            activeTab === 'properties' ? 'text-indigo-300 border-b-2 border-indigo-500 bg-white/5' : 'text-gray-400 hover:text-gray-200'
          }`}
        >
          Transform & Style
        </button>
        <button
          id="tab_expressions"
          onClick={() => setActiveTab('expressions')}
          className={`flex-1 py-1.5 text-center font-medium transition-colors ${
            activeTab === 'expressions' ? 'text-indigo-300 border-b-2 border-indigo-500 bg-white/5' : 'text-gray-400 hover:text-gray-200'
          }`}
        >
          ƒ(x) Expressions
        </button>
      </div>

      {/* Tab Content: Transform & Style */}
      {activeTab === 'properties' && (
        <div className="p-3 space-y-4">
          {/* Transform Section */}
          <div className="space-y-2">
            <span className="text-[10px] font-bold text-gray-400 tracking-wider uppercase flex items-center gap-1.5">
              <Maximize className="w-3 h-3 text-indigo-400" />
              TRANSFORM (2.5D)
            </span>

            {/* Position X / Y */}
            <div className="grid grid-cols-2 gap-2">
              <div className="flex items-center gap-1.5 bg-white/5 p-1.5 rounded border border-white/5">
                <button
                  onClick={() => onToggleKeyframe(selectedObj.id, 'position.x', selectedObj.transform.x)}
                  className={`p-0.5 rounded ${hasTrack('position.x') ? 'text-amber-400' : 'text-gray-500 hover:text-white'}`}
                  title="Toggle Keyframe ◆"
                >
                  <Key className="w-3 h-3" />
                </button>
                <span className="text-gray-400 text-[10px] font-mono">X</span>
                <input
                  type="number"
                  value={selectedObj.transform.x}
                  onChange={(e) => onUpdateObjectTransform(selectedObj.id, { x: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-transparent font-mono text-right focus:outline-none"
                />
              </div>

              <div className="flex items-center gap-1.5 bg-white/5 p-1.5 rounded border border-white/5">
                <button
                  onClick={() => onToggleKeyframe(selectedObj.id, 'position.y', selectedObj.transform.y)}
                  className={`p-0.5 rounded ${hasTrack('position.y') ? 'text-amber-400' : 'text-gray-500 hover:text-white'}`}
                  title="Toggle Keyframe ◆"
                >
                  <Key className="w-3 h-3" />
                </button>
                <span className="text-gray-400 text-[10px] font-mono">Y</span>
                <input
                  type="number"
                  value={selectedObj.transform.y}
                  onChange={(e) => onUpdateObjectTransform(selectedObj.id, { y: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-transparent font-mono text-right focus:outline-none"
                />
              </div>
            </div>

            {/* Rotation & Scale */}
            <div className="grid grid-cols-2 gap-2">
              <div className="flex items-center gap-1.5 bg-white/5 p-1.5 rounded border border-white/5">
                <button
                  onClick={() => onToggleKeyframe(selectedObj.id, 'rotation', selectedObj.transform.rotation)}
                  className={`p-0.5 rounded ${hasTrack('rotation') ? 'text-amber-400' : 'text-gray-500 hover:text-white'}`}
                  title="Toggle Keyframe ◆"
                >
                  <Key className="w-3 h-3" />
                </button>
                <span className="text-gray-400 text-[10px] font-mono">Rot°</span>
                <input
                  type="number"
                  value={Math.round(selectedObj.transform.rotation)}
                  onChange={(e) => onUpdateObjectTransform(selectedObj.id, { rotation: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-transparent font-mono text-right focus:outline-none"
                />
              </div>

              <div className="flex items-center gap-1.5 bg-white/5 p-1.5 rounded border border-white/5">
                <button
                  onClick={() => onToggleKeyframe(selectedObj.id, 'scale', selectedObj.transform.scaleX)}
                  className={`p-0.5 rounded ${hasTrack('scale') ? 'text-amber-400' : 'text-gray-500 hover:text-white'}`}
                  title="Toggle Keyframe ◆"
                >
                  <Key className="w-3 h-3" />
                </button>
                <span className="text-gray-400 text-[10px] font-mono">Scale</span>
                <input
                  type="number"
                  step="0.1"
                  value={selectedObj.transform.scaleX}
                  onChange={(e) => {
                    const s = parseFloat(e.target.value) || 1;
                    onUpdateObjectTransform(selectedObj.id, { scaleX: s, scaleY: s });
                  }}
                  className="w-full bg-transparent font-mono text-right focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Kinetic Typography (if text) */}
          {selectedObj.type === 'text' && selectedObj.textProps && (
            <div className="space-y-2 border-t border-white/10 pt-3">
              <span className="text-[10px] font-bold text-gray-400 tracking-wider uppercase flex items-center gap-1.5">
                <Type className="w-3 h-3 text-indigo-400" />
                KINETIC TYPOGRAPHY
              </span>

              <div className="space-y-1.5">
                <label className="text-[10px] text-gray-400">Text String</label>
                <input
                  type="text"
                  value={selectedObj.textProps.text}
                  onChange={(e) =>
                    onUpdateObject(selectedObj.id, {
                      textProps: { ...selectedObj.textProps!, text: e.target.value },
                    })
                  }
                  className="w-full bg-white/5 border border-white/10 rounded px-2 py-1 text-white focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-gray-400">Split Mode</label>
                  <select
                    value={selectedObj.textProps.splitMode}
                    onChange={(e) =>
                      onUpdateObject(selectedObj.id, {
                        textProps: { ...selectedObj.textProps!, splitMode: e.target.value as any },
                      })
                    }
                    className="w-full bg-white/5 border border-white/10 rounded px-1.5 py-1 text-white focus:outline-none"
                  >
                    <option value="none">None (Single)</option>
                    <option value="chars">Characters</option>
                    <option value="words">Words</option>
                    <option value="lines">Lines</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] text-gray-400">Cascade Preset</label>
                  <select
                    value={selectedObj.textProps.cascadePreset || 'wave'}
                    onChange={(e) =>
                      onUpdateObject(selectedObj.id, {
                        textProps: { ...selectedObj.textProps!, cascadePreset: e.target.value as any },
                      })
                    }
                    className="w-full bg-white/5 border border-white/10 rounded px-1.5 py-1 text-white focus:outline-none"
                  >
                    <option value="wave">Wave</option>
                    <option value="slide">Slide</option>
                    <option value="pop">Pop</option>
                    <option value="typewriter">Typewriter</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* Style & Materials */}
          <div className="space-y-2 border-t border-white/10 pt-3">
            <span className="text-[10px] font-bold text-gray-400 tracking-wider uppercase flex items-center gap-1.5">
              <Sun className="w-3 h-3 text-indigo-400" />
              FILL & STROKE
            </span>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-gray-400">Fill Color</label>
                <div className="flex items-center gap-1.5 bg-white/5 p-1 rounded border border-white/10">
                  <input
                    type="color"
                    value={selectedObj.style.fill.startsWith('#') ? selectedObj.style.fill : '#f59e0b'}
                    onChange={(e) => onUpdateObjectStyle(selectedObj.id, { fill: e.target.value })}
                    className="w-5 h-5 rounded cursor-pointer border-none bg-transparent"
                  />
                  <input
                    type="text"
                    value={selectedObj.style.fill}
                    onChange={(e) => onUpdateObjectStyle(selectedObj.id, { fill: e.target.value })}
                    className="w-full bg-transparent font-mono text-[11px] focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] text-gray-400">Stroke Color</label>
                <div className="flex items-center gap-1.5 bg-white/5 p-1 rounded border border-white/10">
                  <input
                    type="color"
                    value={selectedObj.style.stroke.startsWith('#') ? selectedObj.style.stroke : '#6366f1'}
                    onChange={(e) => onUpdateObjectStyle(selectedObj.id, { stroke: e.target.value })}
                    className="w-5 h-5 rounded cursor-pointer border-none bg-transparent"
                  />
                  <input
                    type="text"
                    value={selectedObj.style.stroke}
                    onChange={(e) => onUpdateObjectStyle(selectedObj.id, { stroke: e.target.value })}
                    className="w-full bg-transparent font-mono text-right text-[11px] focus:outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Stroke Width & Opacity */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-gray-400">Stroke Width</label>
                <input
                  type="number"
                  value={selectedObj.style.strokeWidth}
                  onChange={(e) => onUpdateObjectStyle(selectedObj.id, { strokeWidth: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-white/5 border border-white/10 rounded px-2 py-1 text-white font-mono focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] text-gray-400">Opacity (0..1)</label>
                <input
                  type="number"
                  step="0.05"
                  min="0"
                  max="1"
                  value={selectedObj.style.opacity}
                  onChange={(e) => onUpdateObjectStyle(selectedObj.id, { opacity: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-white/5 border border-white/10 rounded px-2 py-1 text-white font-mono focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Glow FX */}
          <div className="space-y-2 border-t border-white/10 pt-3">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-gray-400 tracking-wider uppercase flex items-center gap-1.5">
                <Sparkles className="w-3 h-3 text-amber-400" />
                PROCEDURAL GLOW
              </span>
              <input
                type="checkbox"
                checked={selectedObj.style.glow?.enabled || false}
                onChange={(e) =>
                  onUpdateObjectStyle(selectedObj.id, {
                    glow: {
                      ...selectedObj.style.glow,
                      enabled: e.target.checked,
                      color: selectedObj.style.glow?.color || '#38bdf8',
                      blur: selectedObj.style.glow?.blur || 15,
                      intensity: selectedObj.style.glow?.intensity || 1.2,
                    },
                  })
                }
                className="cursor-pointer"
              />
            </div>

            {selectedObj.style.glow?.enabled && (
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-gray-400">Glow Radius</label>
                  <input
                    type="number"
                    value={selectedObj.style.glow.blur}
                    onChange={(e) =>
                      onUpdateObjectStyle(selectedObj.id, {
                        glow: { ...selectedObj.style.glow, blur: parseFloat(e.target.value) || 0 },
                      })
                    }
                    className="w-full bg-white/5 border border-white/10 rounded px-2 py-1 font-mono focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-gray-400">Intensity</label>
                  <input
                    type="number"
                    step="0.1"
                    value={selectedObj.style.glow.intensity}
                    onChange={(e) =>
                      onUpdateObjectStyle(selectedObj.id, {
                        glow: { ...selectedObj.style.glow, intensity: parseFloat(e.target.value) || 1 },
                      })
                    }
                    className="w-full bg-white/5 border border-white/10 rounded px-2 py-1 font-mono focus:outline-none"
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab Content: ƒ(x) Expressions */}
      {activeTab === 'expressions' && (
        <div className="p-3 space-y-3">
          <div className="p-2 bg-indigo-950/40 rounded border border-indigo-500/20 text-[11px] text-indigo-200">
            Drive any property with pure math: <code className="font-mono text-amber-300">oscillate()</code>,{' '}
            <code className="font-mono text-amber-300">wiggle()</code>,{' '}
            <code className="font-mono text-amber-300">spring()</code>,{' '}
            <code className="font-mono text-amber-300">pulse()</code>.
          </div>

          <div className="space-y-1.5">
            <label className="text-[10px] text-gray-400">Target Property</label>
            <select
              value={exprInputProp}
              onChange={(e) => {
                setExprInputProp(e.target.value);
                setExprInputVal(getExpr(e.target.value) || 'time * 90 + oscillate(freq=2, amp=20)');
              }}
              className="w-full bg-white/5 border border-white/10 rounded px-2 py-1 text-white focus:outline-none"
            >
              <option value="rotation">rotation</option>
              <option value="position.x">position.x</option>
              <option value="position.y">position.y</option>
              <option value="scale">scale</option>
              <option value="opacity">opacity</option>
              <option value="style.blur">blur</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-[10px] text-gray-400">Expression Script</label>
            <textarea
              rows={4}
              value={exprInputVal}
              onChange={(e) => setExprInputVal(e.target.value)}
              className="w-full bg-black/40 border border-white/10 rounded p-2 text-white font-mono text-[11px] focus:outline-none focus:border-indigo-400"
              placeholder="e.g. 330 + sin(time * 3) * 40 + wiggle(2, 10)"
            />
          </div>

          <button
            id="btn_apply_expression"
            onClick={() => onSetExpression(selectedObj.id, exprInputProp, exprInputVal)}
            className="w-full py-1.5 rounded bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs shadow transition"
          >
            Apply Procedural Expression
          </button>

          {/* Expression Presets Quick-Picks */}
          <div className="space-y-1 pt-2">
            <span className="text-[10px] text-gray-400">Quick Formula Presets:</span>
            <div className="space-y-1">
              {[
                { label: 'Harmonic Wobble', expr: 'val + oscillate(freq=2, amp=25)' },
                { label: 'Perlin Wiggle', expr: 'val + wiggle(freq=3, amp=18)' },
                { label: 'Continuous Spin', expr: 'time * 120' },
                { label: 'Elastic Spring', expr: 'spring(stiffness=120, damping=10)' },
                { label: 'Staggered Sine', expr: 'sin(time * 3 + index * 0.4) * 30' },
              ].map((p, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setExprInputVal(p.expr);
                    onSetExpression(selectedObj.id, exprInputProp, p.expr);
                  }}
                  className="w-full text-left px-2 py-1 rounded bg-white/5 hover:bg-white/10 text-[10px] font-mono text-indigo-300 flex justify-between items-center"
                >
                  <span>{p.label}</span>
                  <span className="text-gray-500 text-[9px]">{p.expr}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
