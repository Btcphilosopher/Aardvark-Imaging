'use client';

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  AardDocument,
  AardComposition,
  AardObject,
  AardTrack,
  AardKeyframe,
  EasingType,
  ShapeType,
} from '@/lib/aardvark/types';
import { createDefaultDocument, TEMPLATE_PRESETS } from '@/lib/aardvark/presets';
import { CanvasView } from './CanvasView';
import { TimelinePanel } from './TimelinePanel';
import { GraphEditor } from './GraphEditor';
import { InspectorPanel } from './InspectorPanel';
import { ScriptEditor } from './ScriptEditor';
import { NodeEditor } from './NodeEditor';
import { ExportModal } from './ExportModal';
import { AiMotionPrompt } from './AiMotionPrompt';

import {
  Play,
  Pause,
  Square,
  Repeat,
  SkipBack,
  SkipForward,
  ChevronLeft,
  ChevronRight,
  Plus,
  Layers,
  Sparkles,
  Download,
  FileCode,
  Share2,
  Activity,
  Sliders,
  Maximize2,
  Circle,
  Square as RectIcon,
  Star,
  Type,
  Wind,
  BarChart2,
  Eye,
  EyeOff,
  Lock,
  Unlock,
  Volume2,
  FolderOpen,
} from 'lucide-react';

export function MotionWorkspace() {
  const [doc, setDoc] = useState<AardDocument>(() => createDefaultDocument());
  const [selectedObjectId, setSelectedObjectId] = useState<string | null>('obj_star_core');
  const [selectedTrackId, setSelectedTrackId] = useState<string | null>('track_star_rot');

  // Playback state
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [isLooping, setIsLooping] = useState(true);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.0);

  // Bottom View Tab
  const [bottomView, setBottomView] = useState<'timeline' | 'graph' | 'script' | 'nodes'>('timeline');

  // Modals
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [isAiOpen, setIsAiOpen] = useState(false);
  const [isTemplatesOpen, setIsTemplatesOpen] = useState(false);

  // Animation frame loop
  const lastTimeRef = useRef<number | null>(null);
  const requestRef = useRef<number | null>(null);

  const activeComp = doc.compositions.find((c) => c.id === doc.activeCompositionId) || doc.compositions[0];

  useEffect(() => {
    if (!isPlaying) {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
      lastTimeRef.current = null;
      return;
    }

    lastTimeRef.current = performance.now();

    const loop = (now: number) => {
      if (lastTimeRef.current != null) {
        const delta = (now - lastTimeRef.current) / 1000;
        setCurrentTime((prev) => {
          let nextTime = prev + delta * playbackSpeed;
          const duration = activeComp.duration || 4.0;
          if (nextTime >= duration) {
            if (isLooping) {
              nextTime = 0;
            } else {
              setIsPlaying(false);
              return duration;
            }
          }
          return nextTime;
        });
      }
      lastTimeRef.current = now;
      requestRef.current = requestAnimationFrame(loop);
    };

    requestRef.current = requestAnimationFrame(loop);

    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [isPlaying, playbackSpeed, isLooping, activeComp.duration]);

  // Object & Track Mutation Handlers
  const handleUpdateObject = (id: string, updates: Partial<AardObject>) => {
    setDoc((prev) => {
      const cloned = JSON.parse(JSON.stringify(prev)) as AardDocument;
      const comp = cloned.compositions.find((c) => c.id === cloned.activeCompositionId);
      if (comp) {
        const obj = comp.objects.find((o) => o.id === id);
        if (obj) Object.assign(obj, updates);
      }
      return cloned;
    });
  };

  const handleUpdateObjectTransform = (id: string, updates: Partial<AardObject['transform']>) => {
    setDoc((prev) => {
      const cloned = JSON.parse(JSON.stringify(prev)) as AardDocument;
      const comp = cloned.compositions.find((c) => c.id === cloned.activeCompositionId);
      if (comp) {
        const obj = comp.objects.find((o) => o.id === id);
        if (obj) Object.assign(obj.transform, updates);
      }
      return cloned;
    });
  };

  const handleUpdateObjectStyle = (id: string, updates: Partial<AardObject['style']>) => {
    setDoc((prev) => {
      const cloned = JSON.parse(JSON.stringify(prev)) as AardDocument;
      const comp = cloned.compositions.find((c) => c.id === cloned.activeCompositionId);
      if (comp) {
        const obj = comp.objects.find((o) => o.id === id);
        if (obj) Object.assign(obj.style, updates);
      }
      return cloned;
    });
  };

  const handleAddObject = (type: ShapeType) => {
    const id = `obj_${type}_${Date.now()}`;
    const newObj: AardObject = {
      id,
      name: `${type.toUpperCase()} Shape`,
      type,
      visible: true,
      locked: false,
      transform: {
        x: activeComp.width / 2,
        y: activeComp.height / 2,
        z: 0,
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        anchorX: 0.5,
        anchorY: 0.5,
        skewX: 0,
        skewY: 0,
      },
      width: type === 'rect' ? 140 : 100,
      height: type === 'rect' ? 100 : 100,
      radius: 50,
      points: type === 'star' ? 5 : type === 'polygon' ? 6 : undefined,
      textProps:
        type === 'text'
          ? {
              text: 'KINETIC TEXT',
              fontSize: 40,
              fontFamily: 'sans-serif',
              fontWeight: 'bold',
              fontStyle: 'normal',
              textAlign: 'center',
              letterSpacing: 20,
              lineHeight: 1.2,
              splitMode: 'chars',
              staggerDelay: 0.05,
              cascadePreset: 'wave',
            }
          : undefined,
      particleConfig:
        type === 'particle_emitter'
          ? {
              type: 'continuous',
              rate: 40,
              maxParticles: 120,
              particleLife: 1.5,
              speedMin: 50,
              speedMax: 150,
              angleMin: 0,
              angleMax: 360,
              sizeMin: 2,
              sizeMax: 6,
              colorStart: '#38bdf8',
              colorEnd: '#f43f5e',
              opacityStart: 1,
              opacityEnd: 0,
              gravity: 1,
              wind: 0,
              turbulence: 6,
              shape: 'spark',
              trailLength: 3,
            }
          : undefined,
      style: {
        fill: type === 'star' ? '#f59e0b' : type === 'rect' ? '#6366f1' : '#38bdf8',
        fillOpacity: 1,
        stroke: '#ffffff',
        strokeWidth: 2,
        strokeOpacity: 1,
        strokeDashOffset: 0,
        opacity: 1,
        blendMode: 'source-over',
        blur: 0,
        glow: { enabled: true, color: '#38bdf8', blur: 12, intensity: 1 },
        shadow: { enabled: false, color: '#000', offsetX: 0, offsetY: 0, blur: 0 },
        trimStart: 0,
        trimEnd: 1,
        trimOffset: 0,
      },
      fxNodes: [],
    };

    setDoc((prev) => {
      const cloned = JSON.parse(JSON.stringify(prev)) as AardDocument;
      const comp = cloned.compositions.find((c) => c.id === cloned.activeCompositionId);
      if (comp) {
        comp.objects.push(newObj);
      }
      return cloned;
    });

    setSelectedObjectId(id);
  };

  const handleDeleteObject = (id: string) => {
    setDoc((prev) => {
      const cloned = JSON.parse(JSON.stringify(prev)) as AardDocument;
      const comp = cloned.compositions.find((c) => c.id === cloned.activeCompositionId);
      if (comp) {
        comp.objects = comp.objects.filter((o) => o.id !== id);
        comp.tracks = comp.tracks.filter((t) => t.targetId !== id);
      }
      return cloned;
    });
    setSelectedObjectId(null);
  };

  const handleToggleKeyframe = (objectId: string, property: string, currentValue: number | string) => {
    setDoc((prev) => {
      const cloned = JSON.parse(JSON.stringify(prev)) as AardDocument;
      const comp = cloned.compositions.find((c) => c.id === cloned.activeCompositionId);
      if (!comp) return cloned;

      let track = comp.tracks.find((t) => t.targetId === objectId && t.property === property);
      if (!track) {
        track = {
          id: `track_${Date.now()}`,
          targetId: objectId,
          property,
          keyframes: [
            {
              id: `kf_${Date.now()}`,
              time: currentTime,
              frame: Math.round(currentTime * comp.fps),
              value: currentValue,
              easing: 'elastic_out',
            },
          ],
        };
        comp.tracks.push(track);
      } else {
        const existingKf = track.keyframes.find((k) => Math.abs(k.time - currentTime) < 0.05);
        if (existingKf) {
          track.keyframes = track.keyframes.filter((k) => k.id !== existingKf.id);
        } else {
          track.keyframes.push({
            id: `kf_${Date.now()}`,
            time: currentTime,
            frame: Math.round(currentTime * comp.fps),
            value: currentValue,
            easing: 'elastic_out',
          });
        }
      }
      return cloned;
    });
  };

  const handleSetExpression = (objectId: string, property: string, expression: string) => {
    setDoc((prev) => {
      const cloned = JSON.parse(JSON.stringify(prev)) as AardDocument;
      const comp = cloned.compositions.find((c) => c.id === cloned.activeCompositionId);
      if (!comp) return cloned;

      let track = comp.tracks.find((t) => t.targetId === objectId && t.property === property);
      if (!track) {
        track = {
          id: `track_${Date.now()}`,
          targetId: objectId,
          property,
          keyframes: [],
          expression,
          isExpressionActive: true,
        };
        comp.tracks.push(track);
      } else {
        track.expression = expression;
        track.isExpressionActive = true;
      }
      return cloned;
    });
  };

  const handleAddKeyframeAtTime = (trackId: string, time: number) => {
    setDoc((prev) => {
      const cloned = JSON.parse(JSON.stringify(prev)) as AardDocument;
      const comp = cloned.compositions.find((c) => c.id === cloned.activeCompositionId);
      if (!comp) return cloned;
      const track = comp.tracks.find((t) => t.id === trackId);
      if (track) {
        track.keyframes.push({
          id: `kf_${Date.now()}`,
          time,
          frame: Math.round(time * comp.fps),
          value: track.keyframes[0]?.value ?? 0,
          easing: 'elastic_out',
        });
      }
      return cloned;
    });
  };

  const handleUpdateKeyframeTime = (trackId: string, keyframeId: string, newTime: number) => {
    setDoc((prev) => {
      const cloned = JSON.parse(JSON.stringify(prev)) as AardDocument;
      const comp = cloned.compositions.find((c) => c.id === cloned.activeCompositionId);
      if (!comp) return cloned;
      const track = comp.tracks.find((t) => t.id === trackId);
      if (track) {
        const kf = track.keyframes.find((k) => k.id === keyframeId);
        if (kf) {
          kf.time = newTime;
          kf.frame = Math.round(newTime * comp.fps);
        }
      }
      return cloned;
    });
  };

  const handleApplyPresetEasing = (trackId: string, easing: EasingType) => {
    setDoc((prev) => {
      const cloned = JSON.parse(JSON.stringify(prev)) as AardDocument;
      const comp = cloned.compositions.find((c) => c.id === cloned.activeCompositionId);
      if (!comp) return cloned;
      const track = comp.tracks.find((t) => t.id === trackId);
      if (track) {
        track.keyframes.forEach((k) => {
          k.easing = easing;
        });
      }
      return cloned;
    });
  };

  const handleToggleTrackExpression = (trackId: string) => {
    setDoc((prev) => {
      const cloned = JSON.parse(JSON.stringify(prev)) as AardDocument;
      const comp = cloned.compositions.find((c) => c.id === cloned.activeCompositionId);
      if (!comp) return cloned;
      const track = comp.tracks.find((t) => t.id === trackId);
      if (track) {
        track.isExpressionActive = !track.isExpressionActive;
      }
      return cloned;
    });
  };

  const selectedTrack = activeComp.tracks.find((t) => t.id === selectedTrackId) || null;

  return (
    <div className="flex flex-col h-screen w-screen bg-[#07080d] text-white overflow-hidden select-none font-sans">
      {/* Top Application Bar */}
      <header className="h-12 border-b border-white/10 bg-[#0d0f1a] flex items-center justify-between px-4 z-20 shrink-0">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-gradient-to-br from-indigo-500 to-amber-500 flex items-center justify-center shadow-lg">
              <Activity className="w-3.5 h-3.5 text-white" />
            </div>
            <div className="flex flex-col">
              <span className="font-black tracking-wider text-xs bg-gradient-to-r from-white via-indigo-200 to-amber-300 bg-clip-text text-transparent">
                AARDVARK IMAGING
              </span>
              <span className="text-[9px] text-gray-400 font-mono tracking-widest uppercase">
                MOTION GRAPHICS ENGINE
              </span>
            </div>
          </div>

          <div className="h-4 w-px bg-white/10" />

          {/* Project Title */}
          <input
            type="text"
            value={doc.title}
            onChange={(e) => setDoc({ ...doc, title: e.target.value })}
            className="bg-transparent font-medium text-xs text-gray-200 focus:outline-none focus:border-b border-indigo-400 px-1 py-0.5 max-w-[180px]"
          />
        </div>

        {/* Center Transport Bar */}
        <div className="flex items-center gap-1.5 bg-[#141624] px-3 py-1 rounded-lg border border-white/10 shadow-inner">
          <button
            id="btn_transport_start"
            onClick={() => setCurrentTime(0)}
            className="p-1 text-gray-400 hover:text-white rounded transition"
            title="Jump to Start"
          >
            <SkipBack className="w-3.5 h-3.5" />
          </button>

          <button
            id="btn_transport_step_back"
            onClick={() => setCurrentTime((t) => Math.max(0, t - 1 / activeComp.fps))}
            className="p-1 text-gray-400 hover:text-white rounded transition"
            title="Step Back 1 Frame"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>

          <button
            id="btn_transport_play_pause"
            onClick={() => setIsPlaying((p) => !p)}
            className={`p-1.5 rounded-full transition ${
              isPlaying
                ? 'bg-amber-500 text-black shadow-[0_0_12px_rgba(245,158,11,0.6)]'
                : 'bg-indigo-600 text-white hover:bg-indigo-500 shadow-[0_0_12px_rgba(99,102,241,0.6)]'
            }`}
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
          </button>

          <button
            id="btn_transport_step_forward"
            onClick={() => setCurrentTime((t) => Math.min(activeComp.duration, t + 1 / activeComp.fps))}
            className="p-1 text-gray-400 hover:text-white rounded transition"
            title="Step Forward 1 Frame"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>

          <button
            id="btn_transport_loop"
            onClick={() => setIsLooping((l) => !l)}
            className={`p-1 rounded transition ${isLooping ? 'text-indigo-400' : 'text-gray-600'}`}
            title="Toggle Loop Playback"
          >
            <Repeat className="w-3.5 h-3.5" />
          </button>

          <div className="h-3 w-px bg-white/10 mx-1" />

          {/* Speed Selector */}
          <select
            value={playbackSpeed}
            onChange={(e) => setPlaybackSpeed(parseFloat(e.target.value))}
            className="bg-transparent text-[11px] font-mono text-gray-300 focus:outline-none cursor-pointer"
          >
            <option value="0.25" className="bg-[#141624]">0.25x</option>
            <option value="0.5" className="bg-[#141624]">0.5x</option>
            <option value="1.0" className="bg-[#141624]">1.0x</option>
            <option value="2.0" className="bg-[#141624]">2.0x</option>
            <option value="4.0" className="bg-[#141624]">4.0x</option>
          </select>
        </div>

        {/* Right Tools & Actions */}
        <div className="flex items-center gap-2">
          <button
            id="btn_open_templates"
            onClick={() => setIsTemplatesOpen((t) => !t)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-white/5 hover:bg-white/10 text-gray-300 text-xs border border-white/10 transition"
          >
            <FolderOpen className="w-3.5 h-3.5 text-amber-400" />
            <span>Presets</span>
          </button>

          <button
            id="btn_open_ai_prompt"
            onClick={() => setIsAiOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1 rounded bg-gradient-to-r from-indigo-600/80 to-purple-600/80 hover:from-indigo-600 hover:to-purple-600 text-white font-medium text-xs shadow-md border border-indigo-400/30 transition"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>AI Motion</span>
          </button>

          <button
            id="btn_open_export"
            onClick={() => setIsExportOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1 rounded bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-md transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Suite</span>
          </button>
        </div>
      </header>

      {/* Main Workspace Area (Left sidebar + Center stage + Right inspector) */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left Sidebar: Scene Objects & Quick Add */}
        <aside className="w-56 border-r border-white/10 bg-[#0c0d16] flex flex-col shrink-0 text-xs">
          {/* Add Vector Object Toolbar */}
          <div className="p-2.5 border-b border-white/10 bg-[#121422]">
            <span className="text-[10px] font-bold text-gray-400 tracking-wider uppercase block mb-1.5">
              ADD VECTOR OBJECT
            </span>
            <div className="grid grid-cols-4 gap-1">
              <button
                id="btn_add_star"
                onClick={() => handleAddObject('star')}
                className="p-1.5 rounded bg-white/5 hover:bg-indigo-600/30 text-gray-300 hover:text-white flex flex-col items-center gap-0.5 border border-white/5 transition"
                title="Vector Star"
              >
                <Star className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-[9px]">Star</span>
              </button>

              <button
                id="btn_add_circle"
                onClick={() => handleAddObject('circle')}
                className="p-1.5 rounded bg-white/5 hover:bg-indigo-600/30 text-gray-300 hover:text-white flex flex-col items-center gap-0.5 border border-white/5 transition"
                title="Circle / Ring"
              >
                <Circle className="w-3.5 h-3.5 text-sky-400" />
                <span className="text-[9px]">Circle</span>
              </button>

              <button
                id="btn_add_rect"
                onClick={() => handleAddObject('rect')}
                className="p-1.5 rounded bg-white/5 hover:bg-indigo-600/30 text-gray-300 hover:text-white flex flex-col items-center gap-0.5 border border-white/5 transition"
                title="Rectangle / Card"
              >
                <RectIcon className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-[9px]">Rect</span>
              </button>

              <button
                id="btn_add_text"
                onClick={() => handleAddObject('text')}
                className="p-1.5 rounded bg-white/5 hover:bg-indigo-600/30 text-gray-300 hover:text-white flex flex-col items-center gap-0.5 border border-white/5 transition"
                title="Kinetic Typography"
              >
                <Type className="w-3.5 h-3.5 text-rose-400" />
                <span className="text-[9px]">Text</span>
              </button>

              <button
                id="btn_add_particles"
                onClick={() => handleAddObject('particle_emitter')}
                className="p-1.5 rounded bg-white/5 hover:bg-indigo-600/30 text-gray-300 hover:text-white flex flex-col items-center gap-0.5 border border-white/5 transition"
                title="Particle Emitter"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                <span className="text-[9px]">Sparks</span>
              </button>

              <button
                id="btn_add_flow_field"
                onClick={() => handleAddObject('flow_field')}
                className="p-1.5 rounded bg-white/5 hover:bg-indigo-600/30 text-gray-300 hover:text-white flex flex-col items-center gap-0.5 border border-white/5 transition"
                title="Flow Field"
              >
                <Wind className="w-3.5 h-3.5 text-cyan-400" />
                <span className="text-[9px]">Flow</span>
              </button>

              <button
                id="btn_add_chart"
                onClick={() => handleAddObject('chart')}
                className="p-1.5 rounded bg-white/5 hover:bg-indigo-600/30 text-gray-300 hover:text-white flex flex-col items-center gap-0.5 border border-white/5 transition"
                title="Data Chart"
              >
                <BarChart2 className="w-3.5 h-3.5 text-indigo-400" />
                <span className="text-[9px]">Data</span>
              </button>

              <button
                id="btn_add_polygon"
                onClick={() => handleAddObject('polygon')}
                className="p-1.5 rounded bg-white/5 hover:bg-indigo-600/30 text-gray-300 hover:text-white flex flex-col items-center gap-0.5 border border-white/5 transition"
                title="Polygon"
              >
                <Activity className="w-3.5 h-3.5 text-purple-400" />
                <span className="text-[9px]">Poly</span>
              </button>
            </div>
          </div>

          {/* Scene Objects Tree */}
          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            <span className="text-[10px] font-bold text-gray-500 tracking-wider uppercase px-1 block mb-1">
              SCENE GRAPH ({activeComp.objects.length})
            </span>

            {activeComp.objects.map((obj) => {
              const isSelected = obj.id === selectedObjectId;
              return (
                <div
                  key={obj.id}
                  onClick={() => setSelectedObjectId(obj.id)}
                  className={`flex items-center justify-between px-2 py-1.5 rounded cursor-pointer transition-colors ${
                    isSelected ? 'bg-indigo-600/30 border border-indigo-500/40 text-white font-medium' : 'hover:bg-white/5 text-gray-400'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <div
                      className="w-2.5 h-2.5 rounded-full shrink-0"
                      style={{ backgroundColor: obj.style.fill !== 'transparent' ? obj.style.fill : obj.style.stroke }}
                    />
                    <span className="truncate">{obj.name}</span>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleUpdateObject(obj.id, { visible: !obj.visible });
                      }}
                      className="text-gray-500 hover:text-white p-0.5"
                    >
                      {obj.visible ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3 text-gray-600" />}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </aside>

        {/* Center Canvas Viewport */}
        <CanvasView
          composition={activeComp}
          currentTime={currentTime}
          selectedObjectId={selectedObjectId}
          onSelectObject={(id) => setSelectedObjectId(id)}
          onUpdateObjectTransform={handleUpdateObjectTransform}
        />

        {/* Right Inspector Panel */}
        <InspectorPanel
          composition={activeComp}
          selectedObjectId={selectedObjectId}
          currentTime={currentTime}
          onUpdateObject={handleUpdateObject}
          onUpdateObjectTransform={handleUpdateObjectTransform}
          onUpdateObjectStyle={handleUpdateObjectStyle}
          onToggleKeyframe={handleToggleKeyframe}
          onSetExpression={handleSetExpression}
          onDeleteObject={handleDeleteObject}
        />
      </div>

      {/* Bottom Dock (Timeline / Motion Graph / Python Script / Node Graph) */}
      <div className="h-64 border-t border-white/10 bg-[#090b14] flex flex-col shrink-0 z-20">
        {/* Dock Tabs Header */}
        <div className="h-8 bg-[#111320] border-b border-white/10 flex items-center justify-between px-3 text-xs">
          <div className="flex items-center gap-1">
            <button
              id="tab_timeline"
              onClick={() => setBottomView('timeline')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-semibold transition ${
                bottomView === 'timeline' ? 'bg-indigo-600 text-white shadow' : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Timeline Tracks</span>
            </button>

            <button
              id="tab_graph_editor"
              onClick={() => setBottomView('graph')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-semibold transition ${
                bottomView === 'graph' ? 'bg-indigo-600 text-white shadow' : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>Motion Curve Graph</span>
            </button>

            <button
              id="tab_script_editor"
              onClick={() => setBottomView('script')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-semibold transition ${
                bottomView === 'script' ? 'bg-indigo-600 text-white shadow' : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>Python Motion API</span>
            </button>

            <button
              id="tab_node_editor"
              onClick={() => setBottomView('nodes')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-semibold transition ${
                bottomView === 'nodes' ? 'bg-indigo-600 text-white shadow' : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>Motion Nodes</span>
            </button>
          </div>
        </div>

        {/* View Content */}
        <div className="flex-1 overflow-hidden">
          {bottomView === 'timeline' && (
            <TimelinePanel
              composition={activeComp}
              currentTime={currentTime}
              selectedObjectId={selectedObjectId}
              selectedTrackId={selectedTrackId}
              onSeek={(t) => setCurrentTime(t)}
              onSelectObject={(id) => setSelectedObjectId(id)}
              onSelectTrack={(id) => setSelectedTrackId(id)}
              onAddKeyframe={handleAddKeyframeAtTime}
              onDeleteKeyframe={() => {}}
              onUpdateKeyframeTime={handleUpdateKeyframeTime}
              onToggleTrackExpression={handleToggleTrackExpression}
            />
          )}

          {bottomView === 'graph' && (
            <GraphEditor
              track={selectedTrack}
              duration={activeComp.duration || 4.0}
              currentTime={currentTime}
              onUpdateKeyframe={() => {}}
              onApplyPresetEasing={handleApplyPresetEasing}
            />
          )}

          {bottomView === 'script' && (
            <ScriptEditor
              document={doc}
              onApplyScript={(newDoc) => setDoc(newDoc)}
            />
          )}

          {bottomView === 'nodes' && (
            <NodeEditor />
          )}
        </div>
      </div>

      {/* Preset Templates Drawer Modal */}
      {isTemplatesOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="bg-[#111322] border border-white/10 rounded-xl max-w-md w-full p-5 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <span className="font-bold text-sm text-white">LOAD MOTION TEMPLATE</span>
              <button onClick={() => setIsTemplatesOpen(false)} className="text-gray-400 hover:text-white">✕</button>
            </div>
            <div className="space-y-2">
              {TEMPLATE_PRESETS.map((tmpl, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setDoc(tmpl.docFactory());
                    setCurrentTime(0);
                    setIsTemplatesOpen(false);
                  }}
                  className="w-full text-left p-3 rounded-lg bg-white/5 hover:bg-indigo-600/20 border border-white/10 hover:border-indigo-500/40 transition group"
                >
                  <div className="font-semibold text-white group-hover:text-indigo-300">{tmpl.name}</div>
                  <div className="text-[11px] text-gray-400 mt-0.5">{tmpl.description}</div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* AI Motion Synthesis Modal */}
      <AiMotionPrompt
        document={doc}
        isOpen={isAiOpen}
        onClose={() => setIsAiOpen(false)}
        onApplyAiResult={(newDoc) => setDoc(newDoc)}
      />

      {/* Export Modal */}
      <ExportModal
        document={doc}
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
      />
    </div>
  );
}
