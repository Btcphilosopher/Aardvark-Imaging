'use client';

import React, { useState, useEffect } from 'react';
import { AardDocument } from '@/lib/aardvark/types';
import { documentToAardPythonScript, parsePythonScriptToDocument } from '@/lib/aardvark/codeBridge';
import { Play, RotateCcw, Copy, Check, FileCode } from 'lucide-react';

interface ScriptEditorProps {
  document: AardDocument;
  onApplyScript: (newDoc: AardDocument) => void;
}

export function ScriptEditor({ document: doc, onApplyScript }: ScriptEditorProps) {
  const [code, setCode] = useState<string>(() => documentToAardPythonScript(doc));
  const [copied, setCopied] = useState(false);
  const [isSaved, setIsSaved] = useState(true);

  const handleRun = () => {
    try {
      const updatedDoc = parsePythonScriptToDocument(code, doc);
      onApplyScript(updatedDoc);
      setIsSaved(true);
    } catch (e) {
      console.error('Error running script:', e);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0c14] border-t border-white/10 text-white text-xs select-none">
      {/* Top Bar */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-[#121422] border-b border-white/10">
        <div className="flex items-center gap-2">
          <FileCode className="w-3.5 h-3.5 text-emerald-400" />
          <span className="font-semibold tracking-wide text-gray-200">
            AARDVARK PYTHON CODE INTERFACE (TWO-WAY SYNC)
          </span>
          {!isSaved && (
            <span className="px-1.5 py-0.5 rounded text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30">
              Unapplied Edits
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1 px-2 py-1 rounded bg-white/5 hover:bg-white/10 text-gray-300 text-xs transition"
          >
            {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>

          <button
            id="btn_run_python_script"
            onClick={handleRun}
            className="flex items-center gap-1 px-3 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow transition"
          >
            <Play className="w-3 h-3 fill-current" />
            <span>Apply Script to Timeline</span>
          </button>
        </div>
      </div>

      {/* Editor Body */}
      <div className="flex-1 p-2 bg-[#080910] overflow-hidden flex">
        <textarea
          value={code}
          onChange={(e) => {
            setCode(e.target.value);
            setIsSaved(false);
          }}
          spellCheck={false}
          className="w-full h-full bg-transparent font-mono text-xs leading-relaxed text-indigo-200 focus:outline-none resize-none p-2 selection:bg-indigo-600/40"
        />
      </div>
    </div>
  );
}
