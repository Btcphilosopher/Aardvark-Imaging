'use client';

import React, { useState } from 'react';
import { AardDocument } from '@/lib/aardvark/types';
import { parsePythonScriptToDocument } from '@/lib/aardvark/codeBridge';
import { Sparkles, Loader2, X, Play, Wand2 } from 'lucide-react';

interface AiMotionPromptProps {
  document: AardDocument;
  isOpen: boolean;
  onClose: () => void;
  onApplyAiResult: (newDoc: AardDocument) => void;
}

export function AiMotionPrompt({
  document: doc,
  isOpen,
  onClose,
  onApplyAiResult,
}: AiMotionPromptProps) {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [aiResult, setAiResult] = useState<any | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/gemini/motion', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, currentDocument: doc }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || 'Failed to generate motion design');
      }

      setAiResult(data);
    } catch (e: any) {
      console.error(e);
      setError(e.message || 'Gemini generation error');
    } finally {
      setLoading(false);
    }
  };

  const handleApply = () => {
    if (aiResult?.pythonCode) {
      const updated = parsePythonScriptToDocument(aiResult.pythonCode, doc);
      onApplyAiResult(updated);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm select-none p-4">
      <div className="bg-[#10121f] border border-white/10 rounded-xl w-full max-w-lg shadow-2xl overflow-hidden text-white text-xs">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-white/10 bg-[#16182a]">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-400" />
            <span className="font-bold text-sm tracking-wide">GEMINI AI MOTION DIRECTOR</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-gray-400 hover:text-white rounded hover:bg-white/5 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4">
          <p className="text-gray-400 leading-relaxed">
            Describe any kinetic animation, logo reveal, procedural flow field, or brand motion sequence.
            Gemini will synthesize mathematical timing curves, expressions, and parameters.
          </p>

          <div className="space-y-1.5">
            <textarea
              rows={3}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g., Create an explosive cosmic emblem with springy rotational overshoot, pulsing energy rings, and a kinetic typewriter cascade."
              className="w-full bg-black/40 border border-white/10 rounded-lg p-3 text-white text-xs leading-relaxed focus:outline-none focus:border-indigo-400 placeholder:text-gray-600"
            />
          </div>

          {/* Quick suggestions */}
          <div className="flex flex-wrap gap-1.5">
            {[
              'Elastic Logo Punch & Particle Spark Burst',
              'Cyberpunk Sine Wave Glitch & Kinetic Text',
              'Smooth Parallax Camera 2.5D Drift',
              'Data Chart Progress Wave with Spring Easing',
            ].map((s, i) => (
              <button
                key={i}
                onClick={() => setPrompt(s)}
                className="px-2 py-1 rounded bg-white/5 hover:bg-white/10 text-[10px] text-indigo-300 border border-white/5 transition"
              >
                {s}
              </button>
            ))}
          </div>

          {error && (
            <div className="p-2.5 rounded bg-rose-950/40 border border-rose-500/30 text-rose-300 text-xs">
              {error}
            </div>
          )}

          {aiResult && (
            <div className="p-3 bg-indigo-950/30 rounded-lg border border-indigo-500/30 space-y-2">
              <div className="font-semibold text-indigo-200 text-xs flex items-center justify-between">
                <span>{aiResult.title || 'Generated Motion Composition'}</span>
                <span className="text-[10px] text-amber-400 font-mono">
                  Easing: {aiResult.recommendedEasing}
                </span>
              </div>
              <p className="text-gray-300 text-[11px] leading-relaxed">{aiResult.explanation}</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/10 bg-[#141626] flex items-center justify-end gap-2">
          <button onClick={onClose} className="px-3 py-1.5 rounded text-xs text-gray-400 hover:text-white">
            Cancel
          </button>

          {!aiResult ? (
            <button
              id="btn_generate_ai_motion"
              onClick={handleGenerate}
              disabled={loading || !prompt.trim()}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow transition disabled:opacity-50"
            >
              {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Wand2 className="w-3.5 h-3.5" />}
              <span>Synthesize Motion</span>
            </button>
          ) : (
            <button
              id="btn_apply_ai_motion"
              onClick={handleApply}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow transition"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Apply to Scene</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
