'use client';

import React, { useRef, useEffect, useState } from 'react';
import { AardComposition, AardObject, AudioBands } from '@/lib/aardvark/types';
import { evaluateSceneAtTime, EvaluatedFrame } from '@/lib/aardvark/engine';
import { renderFrameToCanvas } from '@/lib/aardvark/renderer';
import {
  ZoomIn,
  ZoomOut,
  Maximize2,
  Grid,
  Shield,
  Eye,
  Sliders,
  Activity,
} from 'lucide-react';

interface CanvasViewProps {
  composition: AardComposition;
  currentTime: number;
  selectedObjectId: string | null;
  audioBands?: AudioBands;
  onSelectObject: (id: string | null) => void;
  onUpdateObjectTransform: (id: string, updates: Partial<AardObject['transform']>) => void;
}

export function CanvasView({
  composition,
  currentTime,
  selectedObjectId,
  audioBands,
  onSelectObject,
  onUpdateObjectTransform,
}: CanvasViewProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const [zoom, setZoom] = useState<number>(0.75);
  const [showGrid, setShowGrid] = useState<boolean>(true);
  const [showSafeFrames, setShowSafeFrames] = useState<boolean>(false);
  const [showMotionPaths, setShowMotionPaths] = useState<boolean>(true);
  const [renderPerf, setRenderPerf] = useState<{ fps: number; renderMs: number }>({ fps: 60, renderMs: 1.2 });

  // Mouse drag manipulation on canvas
  const [isDraggingObj, setIsDraggingObj] = useState(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number; origX: number; origY: number } | null>(null);

  // Render frame
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const t0 = performance.now();
    const evaluatedFrame = evaluateSceneAtTime(composition, currentTime, audioBands);

    renderFrameToCanvas(ctx, evaluatedFrame, {
      selectedObjectId,
      showGrid,
      showSafeFrames,
      showMotionPaths,
    });

    const t1 = performance.now();
    setRenderPerf({
      fps: composition.fps || 60,
      renderMs: parseFloat((t1 - t0).toFixed(2)),
    });
  }, [composition, currentTime, selectedObjectId, audioBands, showGrid, showSafeFrames, showMotionPaths]);

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const clickCanvasX = (e.clientX - rect.left) / zoom;
    const clickCanvasY = (e.clientY - rect.top) / zoom;

    // Hit test objects
    const evaluatedFrame = evaluateSceneAtTime(composition, currentTime, audioBands);
    let hitId: string | null = null;

    // Check in reverse order (top to bottom)
    for (let i = evaluatedFrame.objects.length - 1; i >= 0; i--) {
      const obj = evaluatedFrame.objects[i];
      const dx = Math.abs(clickCanvasX - obj.worldTransform.x);
      const dy = Math.abs(clickCanvasY - obj.worldTransform.y);
      const w = (obj.computedWidth || 100) / 2;
      const h = (obj.computedHeight || 100) / 2;

      if (dx <= w + 15 && dy <= h + 15) {
        hitId = obj.object.id;
        break;
      }
    }

    onSelectObject(hitId);

    if (hitId) {
      const targetObj = composition.objects.find((o) => o.id === hitId);
      if (targetObj) {
        setIsDraggingObj(true);
        setDragStart({
          x: clickCanvasX,
          y: clickCanvasY,
          origX: targetObj.transform.x,
          origY: targetObj.transform.y,
        });
      }
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDraggingObj || !dragStart || !selectedObjectId) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const currentCanvasX = (e.clientX - rect.left) / zoom;
    const currentCanvasY = (e.clientY - rect.top) / zoom;

    const deltaX = currentCanvasX - dragStart.x;
    const deltaY = currentCanvasY - dragStart.y;

    onUpdateObjectTransform(selectedObjectId, {
      x: Math.round(dragStart.origX + deltaX),
      y: Math.round(dragStart.origY + deltaY),
    });
  };

  const handleMouseUp = () => {
    setIsDraggingObj(false);
    setDragStart(null);
  };

  return (
    <div
      ref={containerRef}
      className="flex-1 flex flex-col bg-[#05060a] relative overflow-hidden select-none"
    >
      {/* Viewport Top Bar */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-[#0e101a] border-b border-white/10 text-xs text-gray-300">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-gray-200">STAGE VIEWPORT</span>
          <span className="text-[11px] text-gray-500 font-mono">
            {composition.width}x{composition.height} @ {Math.round(zoom * 100)}%
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Zoom Controls */}
          <div className="flex items-center bg-white/5 rounded border border-white/10 px-1 py-0.5">
            <button
              id="btn_zoom_out"
              onClick={() => setZoom((z) => Math.max(0.25, z - 0.1))}
              className="p-1 hover:text-white"
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="text-[11px] font-mono px-1.5">{Math.round(zoom * 100)}%</span>
            <button
              id="btn_zoom_in"
              onClick={() => setZoom((z) => Math.min(2.0, z + 0.1))}
              className="p-1 hover:text-white"
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              id="btn_zoom_fit"
              onClick={() => setZoom(0.7)}
              className="p-1 hover:text-white border-l border-white/10 ml-0.5"
              title="Fit to Screen"
            >
              <Maximize2 className="w-3 h-3" />
            </button>
          </div>

          {/* Grid & Safe margins toggles */}
          <button
            id="btn_toggle_grid"
            onClick={() => setShowGrid((g) => !g)}
            className={`p-1.5 rounded text-xs flex items-center gap-1 ${
              showGrid ? 'bg-indigo-600/30 text-indigo-200 border border-indigo-500/40' : 'bg-white/5 text-gray-400'
            }`}
            title="Toggle Alignment Grid"
          >
            <Grid className="w-3.5 h-3.5" />
          </button>

          <button
            id="btn_toggle_safe_frames"
            onClick={() => setShowSafeFrames((s) => !s)}
            className={`p-1.5 rounded text-xs flex items-center gap-1 ${
              showSafeFrames ? 'bg-amber-500/30 text-amber-200 border border-amber-500/40' : 'bg-white/5 text-gray-400'
            }`}
            title="Toggle Safe Margins"
          >
            <Shield className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Canvas Container Center */}
      <div className="flex-1 flex items-center justify-center p-4 overflow-auto bg-[#07080e] relative">
        <div
          className="shadow-2xl border border-white/10 rounded-sm relative"
          style={{
            width: composition.width * zoom,
            height: composition.height * zoom,
          }}
        >
          <canvas
            ref={canvasRef}
            width={composition.width}
            height={composition.height}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            style={{
              width: `${composition.width * zoom}px`,
              height: `${composition.height * zoom}px`,
              display: 'block',
            }}
            className="cursor-default"
          />
        </div>

        {/* HUD Performance Overlay (Motion Debugger) */}
        <div className="absolute bottom-3 left-3 px-2 py-1 rounded bg-black/70 backdrop-blur border border-white/10 text-[10px] font-mono text-gray-400 flex items-center gap-3 pointer-events-none">
          <div className="flex items-center gap-1 text-emerald-400">
            <Activity className="w-3 h-3" />
            <span>{renderPerf.fps} FPS</span>
          </div>
          <span>Eval: {renderPerf.renderMs}ms</span>
          <span>Objects: {composition.objects.length}</span>
          <span>Tracks: {composition.tracks.length}</span>
        </div>
      </div>
    </div>
  );
}
