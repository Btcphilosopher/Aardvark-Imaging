'use client';

import React, { useRef, useEffect, useState } from 'react';
import { AardTrack, AardKeyframe, EasingType } from '@/lib/aardvark/types';
import { evaluateEasing } from '@/lib/aardvark/easing';
import { Activity, Sparkles, Sliders, ChevronDown } from 'lucide-react';

interface GraphEditorProps {
  track: AardTrack | null;
  duration: number;
  currentTime: number;
  onUpdateKeyframe: (trackId: string, keyframeId: string, updates: Partial<AardKeyframe>) => void;
  onApplyPresetEasing: (trackId: string, easing: EasingType) => void;
}

export function GraphEditor({
  track,
  duration,
  currentTime,
  onUpdateKeyframe,
  onApplyPresetEasing,
}: GraphEditorProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [selectedKeyframeId, setSelectedKeyframeId] = useState<string | null>(null);

  const keyframes = track?.keyframes;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const currentKeyframes = track?.keyframes || [];

    const width = canvas.width;
    const height = canvas.height;

    // Clear background
    ctx.fillStyle = '#0f111a';
    ctx.fillRect(0, 0, width, height);

    // Subtle grid
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.lineWidth = 1;
    for (let x = 0; x < width; x += 40) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = 0; y < height; y += 30) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    if (!track || currentKeyframes.length === 0) {
      ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
      ctx.font = '13px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('Select an animated track with keyframes to edit motion curves', width / 2, height / 2);
      return;
    }

    // Determine value range
    const numValues = currentKeyframes.map((k) => (typeof k.value === 'number' ? k.value : 0));
    const minVal = Math.min(...numValues, 0);
    const maxVal = Math.max(...numValues, 1);
    const valRange = maxVal - minVal || 1;
    const padding = 35;

    const timeToX = (t: number) => padding + (t / duration) * (width - padding * 2);
    const valToY = (v: number) => height - padding - ((v - minVal) / valRange) * (height - padding * 2);

    // Draw Continuous Motion Curve
    ctx.strokeStyle = '#6366f1';
    ctx.lineWidth = 2.5;
    ctx.beginPath();

    const sortedKfs = [...currentKeyframes].sort((a, b) => a.time - b.time);
    const sampleSteps = 200;

    for (let s = 0; s <= sampleSteps; s++) {
      const sampleT = (s / sampleSteps) * duration;
      let sampleVal = sortedKfs[0].value as number;

      if (sampleT <= sortedKfs[0].time) {
        sampleVal = sortedKfs[0].value as number;
      } else if (sampleT >= sortedKfs[sortedKfs.length - 1].time) {
        sampleVal = sortedKfs[sortedKfs.length - 1].value as number;
      } else {
        for (let i = 0; i < sortedKfs.length - 1; i++) {
          const k1 = sortedKfs[i];
          const k2 = sortedKfs[i + 1];
          if (sampleT >= k1.time && sampleT <= k2.time) {
            const span = k2.time - k1.time;
            const p = span > 0 ? (sampleT - k1.time) / span : 0;
            const easeP = evaluateEasing(p, k1.easing, k1.inHandle, k1.outHandle);
            const v1 = typeof k1.value === 'number' ? k1.value : 0;
            const v2 = typeof k2.value === 'number' ? k2.value : 0;
            sampleVal = v1 + (v2 - v1) * easeP;
            break;
          }
        }
      }

      const x = timeToX(sampleT);
      const y = valToY(typeof sampleVal === 'number' ? sampleVal : 0);

      if (s === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // Draw Current Playhead Line
    const playheadX = timeToX(currentTime);
    ctx.strokeStyle = '#f43f5e';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.moveTo(playheadX, 0);
    ctx.lineTo(playheadX, height);
    ctx.stroke();
    ctx.setLineDash([]);

    // Draw Keyframe Nodes & Handles
    sortedKfs.forEach((kf) => {
      const kfX = timeToX(kf.time);
      const kfY = valToY(typeof kf.value === 'number' ? kf.value : 0);
      const isSel = kf.id === selectedKeyframeId;

      // Handle lines
      if (isSel && kf.outHandle) {
        const hx = kfX + kf.outHandle.x * 60;
        const hy = kfY - kf.outHandle.y * 40;
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(kfX, kfY);
        ctx.lineTo(hx, hy);
        ctx.stroke();
        ctx.fillStyle = '#38bdf8';
        ctx.beginPath();
        ctx.arc(hx, hy, 4, 0, Math.PI * 2);
        ctx.fill();
      }

      // Keyframe Point
      ctx.fillStyle = isSel ? '#38bdf8' : '#ffffff';
      ctx.strokeStyle = isSel ? '#ffffff' : '#6366f1';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(kfX, kfY, isSel ? 6 : 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Label
      ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
      ctx.font = '10px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(`${typeof kf.value === 'number' ? kf.value.toFixed(1) : kf.value}`, kfX, kfY - 10);
    });
  }, [track, duration, currentTime, selectedKeyframeId]);

  const easings: { label: string; value: EasingType }[] = [
    { label: 'Linear', value: 'linear' },
    { label: 'Elastic Out', value: 'elastic_out' },
    { label: 'Spring', value: 'spring' },
    { label: 'Back Out', value: 'back_out' },
    { label: 'Ease In Out', value: 'ease_in_out' },
    { label: 'Bounce Out', value: 'bounce_out' },
    { label: 'Expo Out', value: 'expo_out' },
    { label: 'Cubic In Out', value: 'cubic_in_out' },
  ];

  return (
    <div className="flex flex-col h-full bg-[#0d0e15] border-t border-white/10 text-white select-none">
      {/* Top Toolbar */}
      <div className="flex items-center justify-between px-3 py-1.5 border-b border-white/10 bg-[#13151f] text-xs">
        <div className="flex items-center gap-2">
          <Activity className="w-3.5 h-3.5 text-indigo-400" />
          <span className="font-semibold tracking-wide text-gray-200">
            MOTION GRAPH EDITOR {track ? `— [${track.property}]` : ''}
          </span>
        </div>

        {track && (
          <div className="flex items-center gap-2">
            <span className="text-gray-400">Curve Preset:</span>
            <div className="flex items-center gap-1">
              {easings.map((e) => (
                <button
                  key={e.value}
                  id={`btn_ease_${e.value}`}
                  onClick={() => onApplyPresetEasing(track.id, e.value)}
                  className="px-2 py-0.5 rounded text-[11px] bg-white/5 hover:bg-indigo-600/30 text-gray-300 hover:text-white transition-colors"
                >
                  {e.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Graph Canvas */}
      <div className="flex-1 relative w-full h-full min-h-[160px]">
        <canvas
          ref={canvasRef}
          width={900}
          height={200}
          className="w-full h-full block cursor-crosshair"
          onClick={(e) => {
            const kfs = track?.keyframes || [];
            if (!track || kfs.length === 0) return;
            const canvas = canvasRef.current;
            if (!canvas) return;
            const rect = canvas.getBoundingClientRect();
            const clickX = e.clientX - rect.left;
            const clickTime = (clickX / rect.width) * duration;

            // Find nearest keyframe
            let nearest: AardKeyframe | null = null;
            let minDist = Infinity;
            kfs.forEach((k) => {
              const d = Math.abs(k.time - clickTime);
              if (d < minDist) {
                minDist = d;
                nearest = k;
              }
            });

            if (nearest && minDist < 0.25) {
              setSelectedKeyframeId((nearest as AardKeyframe).id);
            } else {
              setSelectedKeyframeId(null);
            }
          }}
        />
      </div>
    </div>
  );
}
