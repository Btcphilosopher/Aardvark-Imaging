'use client';

import React, { useState } from 'react';
import { AardComposition, AardDocument } from '@/lib/aardvark/types';
import { evaluateSceneAtTime } from '@/lib/aardvark/engine';
import { renderFrameToCanvas } from '@/lib/aardvark/renderer';
import { exportToAnimatedSvg } from '@/lib/aardvark/svgExporter';
import { documentToAardPythonScript } from '@/lib/aardvark/codeBridge';
import JSZip from 'jszip';
import {
  Download,
  Film,
  FileCode,
  Image as ImageIcon,
  CheckCircle,
  Loader2,
  X,
  Sparkles,
} from 'lucide-react';

interface ExportModalProps {
  document: AardDocument;
  isOpen: boolean;
  onClose: () => void;
}

export function ExportModal({ document: doc, isOpen, onClose }: ExportModalProps) {
  const [exportType, setExportType] = useState<'video' | 'png_sequence' | 'svg' | 'json' | 'python'>('video');
  const [isExporting, setIsExporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [statusMessage, setStatusMessage] = useState('');

  if (!isOpen) return null;

  const comp = doc.compositions.find((c) => c.id === doc.activeCompositionId) || doc.compositions[0];

  const handleExport = async () => {
    setIsExporting(true);
    setProgress(0);

    try {
      if (exportType === 'svg') {
        setStatusMessage('Generating Vector SVG with CSS Keyframes...');
        const svgContent = exportToAnimatedSvg(comp);
        const blob = new Blob([svgContent], { type: 'image/svg+xml' });
        const url = URL.createObjectURL(blob);
        const a = window.document.createElement('a');
        a.href = url;
        a.download = `${comp.name.toLowerCase().replace(/\s+/g, '_')}_animated.svg`;
        a.click();
        URL.revokeObjectURL(url);
      } else if (exportType === 'json') {
        setStatusMessage('Packaging .aard document JSON...');
        const jsonContent = JSON.stringify(doc, null, 2);
        const blob = new Blob([jsonContent], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = window.document.createElement('a');
        a.href = url;
        a.download = `${doc.title.toLowerCase().replace(/\s+/g, '_')}.aard`;
        a.click();
        URL.revokeObjectURL(url);
      } else if (exportType === 'python') {
        setStatusMessage('Generating Aardvark Motion Python script...');
        const pyCode = documentToAardPythonScript(doc);
        const blob = new Blob([pyCode], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = window.document.createElement('a');
        a.href = url;
        a.download = `${doc.title.toLowerCase().replace(/\s+/g, '_')}_motion.py`;
        a.click();
        URL.revokeObjectURL(url);
      } else if (exportType === 'png_sequence') {
        setStatusMessage('Rendering deterministic PNG frames to ZIP...');
        const zip = new JSZip();
        const fps = 30;
        const totalFrames = Math.floor((comp.duration || 4) * fps);

        const canvas = window.document.createElement('canvas');
        canvas.width = comp.width;
        canvas.height = comp.height;
        const ctx = canvas.getContext('2d');

        if (ctx) {
          for (let f = 0; f <= totalFrames; f++) {
            const t = f / fps;
            const evalFrame = evaluateSceneAtTime(comp, t);
            renderFrameToCanvas(ctx, evalFrame, { showGrid: false, showSafeFrames: false });

            const dataUrl = canvas.toDataURL('image/png');
            const base64Data = dataUrl.replace(/^data:image\/png;base64,/, '');
            const frameNumber = f.toString().padStart(4, '0');
            zip.file(`frame_${frameNumber}.png`, base64Data, { base64: true });

            setProgress(Math.round((f / totalFrames) * 90));
          }
        }

        setStatusMessage('Compressing ZIP bundle...');
        const content = await zip.generateAsync({ type: 'blob' });
        const url = URL.createObjectURL(content);
        const a = window.document.createElement('a');
        a.href = url;
        a.download = `${comp.name.toLowerCase().replace(/\s+/g, '_')}_png_sequence.zip`;
        a.click();
        URL.revokeObjectURL(url);
        setProgress(100);
      } else if (exportType === 'video') {
        setStatusMessage('Recording canvas stream to WebM Video...');
        const canvas = window.document.createElement('canvas');
        canvas.width = comp.width;
        canvas.height = comp.height;
        const ctx = canvas.getContext('2d');

        if (!ctx) throw new Error('Canvas context not available');

        const stream = canvas.captureStream(60);
        const mediaRecorder = new MediaRecorder(stream, {
          mimeType: 'video/webm;codecs=vp9',
          videoBitsPerSecond: 5000000,
        });

        const chunks: Blob[] = [];
        mediaRecorder.ondataavailable = (e) => {
          if (e.data.size > 0) chunks.push(e.data);
        };

        mediaRecorder.onstop = () => {
          const blob = new Blob(chunks, { type: 'video/webm' });
          const url = URL.createObjectURL(blob);
          const a = window.document.createElement('a');
          a.href = url;
          a.download = `${comp.name.toLowerCase().replace(/\s+/g, '_')}_motion.webm`;
          a.click();
          URL.revokeObjectURL(url);
          setProgress(100);
          setIsExporting(false);
        };

        mediaRecorder.start();

        const duration = comp.duration || 4;
        const totalSteps = Math.floor(duration * 60);

        for (let s = 0; s <= totalSteps; s++) {
          const t = (s / totalSteps) * duration;
          const evalFrame = evaluateSceneAtTime(comp, t);
          renderFrameToCanvas(ctx, evalFrame, { showGrid: false, showSafeFrames: false });
          setProgress(Math.round((s / totalSteps) * 95));
          await new Promise((r) => setTimeout(r, 16));
        }

        mediaRecorder.stop();
        return;
      }

      setIsExporting(false);
      setStatusMessage('Export completed successfully!');
    } catch (err: any) {
      console.error('Export failed:', err);
      setStatusMessage(`Export error: ${err.message || 'Unknown failure'}`);
      setIsExporting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm select-none p-4">
      <div className="bg-[#10121d] border border-white/10 rounded-xl w-full max-w-lg shadow-2xl overflow-hidden text-white text-xs">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-white/10 bg-[#161928]">
          <div className="flex items-center gap-2">
            <Film className="w-4 h-4 text-indigo-400" />
            <span className="font-bold text-sm tracking-wide">EXPORT MOTION GRAPHICS</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-gray-400 hover:text-white rounded hover:bg-white/5 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          <div className="space-y-2">
            <label className="text-gray-300 font-semibold">Select Export Format</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setExportType('video')}
                className={`p-3 rounded-lg border text-left flex flex-col gap-1 transition-all ${
                  exportType === 'video'
                    ? 'bg-indigo-600/20 border-indigo-500 text-white'
                    : 'bg-white/5 border-white/10 text-gray-400 hover:text-gray-200'
                }`}
              >
                <div className="flex items-center gap-2 font-semibold text-xs">
                  <Film className="w-3.5 h-3.5 text-indigo-400" />
                  <span>WebM Video (60fps)</span>
                </div>
                <span className="text-[10px] text-gray-400">High-bitrate VP9 video capture</span>
              </button>

              <button
                onClick={() => setExportType('png_sequence')}
                className={`p-3 rounded-lg border text-left flex flex-col gap-1 transition-all ${
                  exportType === 'png_sequence'
                    ? 'bg-indigo-600/20 border-indigo-500 text-white'
                    : 'bg-white/5 border-white/10 text-gray-400 hover:text-gray-200'
                }`}
              >
                <div className="flex items-center gap-2 font-semibold text-xs">
                  <ImageIcon className="w-3.5 h-3.5 text-sky-400" />
                  <span>PNG Sequence (ZIP)</span>
                </div>
                <span className="text-[10px] text-gray-400">Frame-by-frame alpha channel bundle</span>
              </button>

              <button
                onClick={() => setExportType('svg')}
                className={`p-3 rounded-lg border text-left flex flex-col gap-1 transition-all ${
                  exportType === 'svg'
                    ? 'bg-indigo-600/20 border-indigo-500 text-white'
                    : 'bg-white/5 border-white/10 text-gray-400 hover:text-gray-200'
                }`}
              >
                <div className="flex items-center gap-2 font-semibold text-xs">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>Animated SVG</span>
                </div>
                <span className="text-[10px] text-gray-400">Pure vector with CSS Keyframe loop</span>
              </button>

              <button
                onClick={() => setExportType('python')}
                className={`p-3 rounded-lg border text-left flex flex-col gap-1 transition-all ${
                  exportType === 'python'
                    ? 'bg-indigo-600/20 border-indigo-500 text-white'
                    : 'bg-white/5 border-white/10 text-gray-400 hover:text-gray-200'
                }`}
              >
                <div className="flex items-center gap-2 font-semibold text-xs">
                  <FileCode className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Aardvark Python (.py)</span>
                </div>
                <span className="text-[10px] text-gray-400">Executable motion script code</span>
              </button>
            </div>
          </div>

          {/* Progress Bar & Status */}
          {isExporting && (
            <div className="space-y-1.5 p-3 rounded-lg bg-black/40 border border-white/5">
              <div className="flex items-center justify-between text-[11px] text-indigo-300 font-mono">
                <span>{statusMessage}</span>
                <span>{progress}%</span>
              </div>
              <div className="w-full bg-white/10 rounded-full h-1.5 overflow-hidden">
                <div
                  className="bg-indigo-500 h-full transition-all duration-150"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/10 bg-[#141624] flex items-center justify-end gap-2">
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded text-xs text-gray-400 hover:text-white transition"
          >
            Cancel
          </button>
          <button
            id="btn_confirm_export"
            onClick={handleExport}
            disabled={isExporting}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-lg transition disabled:opacity-50"
          >
            {isExporting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
            <span>Export {exportType.toUpperCase()}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
