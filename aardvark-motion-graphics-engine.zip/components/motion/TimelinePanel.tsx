'use client';

import React, { useRef, useState } from 'react';
import { AardComposition, AardTrack, AardKeyframe } from '@/lib/aardvark/types';
import {
  Eye,
  EyeOff,
  Lock,
  Unlock,
  Key,
  Code,
  Activity,
  Plus,
  Trash2,
  Clock,
  Layers,
} from 'lucide-react';

interface TimelinePanelProps {
  composition: AardComposition;
  currentTime: number;
  selectedObjectId: string | null;
  selectedTrackId: string | null;
  onSeek: (time: number) => void;
  onSelectObject: (id: string | null) => void;
  onSelectTrack: (id: string | null) => void;
  onAddKeyframe: (trackId: string, time: number) => void;
  onDeleteKeyframe: (trackId: string, keyframeId: string) => void;
  onUpdateKeyframeTime: (trackId: string, keyframeId: string, newTime: number) => void;
  onToggleTrackExpression: (trackId: string) => void;
}

export function TimelinePanel({
  composition,
  currentTime,
  selectedObjectId,
  selectedTrackId,
  onSeek,
  onSelectObject,
  onSelectTrack,
  onAddKeyframe,
  onDeleteKeyframe,
  onUpdateKeyframeTime,
  onToggleTrackExpression,
}: TimelinePanelProps) {
  const rulerRef = useRef<HTMLDivElement | null>(null);
  const [draggingKf, setDraggingKf] = useState<{ trackId: string; kfId: string } | null>(null);

  const duration = composition.duration || 4.0;
  const fps = composition.fps || 60;
  const currentFrame = Math.round(currentTime * fps);

  // SMPTE timecode: HH:MM:SS:FF
  const pad = (n: number) => n.toString().padStart(2, '0');
  const totalSecs = Math.floor(currentTime);
  const smpteFrames = Math.floor((currentTime % 1) * fps);
  const smpte = `00:${pad(Math.floor(totalSecs / 60))}:${pad(totalSecs % 60)}:${pad(smpteFrames)}`;

  const handleRulerMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = Math.max(0, Math.min(rect.width, e.clientX - rect.left));
    const newT = (x / rect.width) * duration;
    onSeek(newT);

    const onMouseMove = (moveEvent: MouseEvent) => {
      const moveX = Math.max(0, Math.min(rect.width, moveEvent.clientX - rect.left));
      onSeek((moveX / rect.width) * duration);
    };

    const onMouseUp = () => {
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
    };

    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0b12] border-t border-white/10 text-white select-none">
      {/* Timeline Controls Header */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-[#121420] border-b border-white/10 text-xs">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 font-mono text-indigo-300 font-bold bg-black/40 px-2 py-0.5 rounded border border-indigo-500/30">
            <Clock className="w-3 h-3 text-indigo-400" />
            <span>{smpte}</span>
            <span className="text-[10px] text-gray-500 font-normal">({currentFrame}f)</span>
          </div>

          <div className="text-gray-400 flex items-center gap-1">
            <span>Duration:</span>
            <span className="text-gray-200 font-mono font-medium">{duration.toFixed(2)}s</span>
            <span className="text-gray-500">|</span>
            <span className="text-gray-200 font-mono font-medium">{fps} FPS</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {selectedTrackId && (
            <button
              id="btn_add_keyframe_at_playhead"
              onClick={() => onAddKeyframe(selectedTrackId, currentTime)}
              className="flex items-center gap-1 px-2 py-1 rounded bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-500/40 text-indigo-200 text-xs transition"
            >
              <Key className="w-3 h-3" />
              <span>Add Keyframe (◆)</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Track Grid */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left Track Names Column */}
        <div className="w-64 border-r border-white/10 bg-[#0d0f18] flex flex-col shrink-0 overflow-y-auto">
          <div className="h-7 px-3 flex items-center bg-[#131622] border-b border-white/10 text-[11px] font-semibold text-gray-400 tracking-wider">
            <Layers className="w-3.5 h-3.5 mr-1.5 text-indigo-400" />
            <span>LAYERS & TRACKS</span>
          </div>

          <div className="flex-1 divide-y divide-white/5">
            {composition.objects.map((obj) => {
              const objTracks = composition.tracks.filter((t) => t.targetId === obj.id);
              const isObjSelected = obj.id === selectedObjectId;

              return (
                <div key={obj.id} className="flex flex-col">
                  {/* Object Row */}
                  <div
                    onClick={() => onSelectObject(obj.id)}
                    className={`flex items-center justify-between px-3 py-1.5 cursor-pointer text-xs transition-colors ${
                      isObjSelected ? 'bg-indigo-600/20 text-white font-medium' : 'hover:bg-white/5 text-gray-300'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 truncate">
                      <div
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: obj.style.fill !== 'transparent' ? obj.style.fill : obj.style.stroke }}
                      />
                      <span className="truncate">{obj.name}</span>
                    </div>

                    <span className="text-[10px] text-gray-500 uppercase px-1 py-0.5 bg-white/5 rounded">
                      {obj.type}
                    </span>
                  </div>

                  {/* Sub-Tracks */}
                  {objTracks.map((track) => {
                    const isTrackSelected = track.id === selectedTrackId;
                    return (
                      <div
                        key={track.id}
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectObject(obj.id);
                          onSelectTrack(track.id);
                        }}
                        className={`flex items-center justify-between pl-7 pr-3 py-1 text-[11px] cursor-pointer border-l-2 transition-colors ${
                          isTrackSelected
                            ? 'bg-indigo-950/40 border-indigo-500 text-indigo-200'
                            : 'border-transparent text-gray-400 hover:bg-white/5'
                        }`}
                      >
                        <span className="font-mono truncate">{track.property}</span>

                        <div className="flex items-center gap-1">
                          {track.expression && (
                            <button
                              id={`btn_toggle_expr_${track.id}`}
                              onClick={(e) => {
                                e.stopPropagation();
                                onToggleTrackExpression(track.id);
                              }}
                              className={`p-0.5 rounded text-[10px] ${
                                track.isExpressionActive
                                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                  : 'bg-white/5 text-gray-500'
                              }`}
                              title={track.expression}
                            >
                              <Code className="w-3 h-3" />
                            </button>
                          )}
                          <span className="text-[10px] text-gray-500">{track.keyframes.length} kf</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Keyframe Timeline Area */}
        <div className="flex-1 flex flex-col overflow-x-auto relative bg-[#090a10]">
          {/* Time Ruler */}
          <div
            ref={rulerRef}
            onMouseDown={handleRulerMouseDown}
            className="h-7 border-b border-white/10 bg-[#131622] relative cursor-pointer select-none shrink-0"
          >
            {/* Ticks */}
            {Array.from({ length: 21 }).map((_, i) => {
              const tickTime = (i / 20) * duration;
              const leftPct = (i / 20) * 100;
              return (
                <div
                  key={i}
                  className="absolute top-0 bottom-0 border-l border-white/10 text-[9px] text-gray-400 pl-1 pt-0.5 font-mono pointer-events-none"
                  style={{ left: `${leftPct}%` }}
                >
                  {i % 2 === 0 ? `${tickTime.toFixed(1)}s` : ''}
                </div>
              );
            })}

            {/* Playhead Marker */}
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-rose-500 z-30 pointer-events-none shadow-[0_0_8px_rgba(244,63,94,0.8)]"
              style={{ left: `${(currentTime / duration) * 100}%` }}
            >
              <div className="w-2.5 h-2.5 bg-rose-500 rounded-full -translate-x-[4px] -translate-y-1 shadow" />
            </div>
          </div>

          {/* Keyframe Track Lanes */}
          <div className="flex-1 relative divide-y divide-white/5 overflow-y-auto">
            {/* Playhead Vertical Line */}
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-rose-500/80 z-20 pointer-events-none"
              style={{ left: `${(currentTime / duration) * 100}%` }}
            />

            {composition.objects.map((obj) => {
              const objTracks = composition.tracks.filter((t) => t.targetId === obj.id);

              return (
                <div key={obj.id} className="flex flex-col">
                  {/* Object Spacer Row */}
                  <div className="h-7 bg-white/[0.02]" />

                  {/* Tracks */}
                  {objTracks.map((track) => {
                    return (
                      <div
                        key={track.id}
                        onClick={() => {
                          onSelectObject(obj.id);
                          onSelectTrack(track.id);
                        }}
                        className="h-6 relative hover:bg-white/[0.04] transition-colors cursor-pointer"
                      >
                        {/* Keyframe Diamonds */}
                        {track.keyframes.map((kf) => {
                          const leftPct = Math.max(0, Math.min(100, (kf.time / duration) * 100));

                          return (
                            <div
                              key={kf.id}
                              onMouseDown={(e) => {
                                e.stopPropagation();
                                setDraggingKf({ trackId: track.id, kfId: kf.id });

                                const onMove = (moveEv: MouseEvent) => {
                                  if (!rulerRef.current) return;
                                  const rect = rulerRef.current.getBoundingClientRect();
                                  const relX = Math.max(0, Math.min(rect.width, moveEv.clientX - rect.left));
                                  const newT = Math.max(0, Math.min(duration, (relX / rect.width) * duration));
                                  onUpdateKeyframeTime(track.id, kf.id, newT);
                                };

                                const onUp = () => {
                                  setDraggingKf(null);
                                  window.removeEventListener('mousemove', onMove);
                                  window.removeEventListener('mouseup', onUp);
                                };

                                window.addEventListener('mousemove', onMove);
                                window.addEventListener('mouseup', onUp);
                              }}
                              className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-3.5 h-3.5 rotate-45 bg-indigo-400 hover:bg-indigo-300 border border-white shadow cursor-grab active:cursor-grabbing z-10 transition-transform hover:scale-125"
                              style={{ left: `${leftPct}%` }}
                              title={`Keyframe at ${kf.time.toFixed(2)}s | Value: ${kf.value} | Easing: ${kf.easing}`}
                            />
                          );
                        })}
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
