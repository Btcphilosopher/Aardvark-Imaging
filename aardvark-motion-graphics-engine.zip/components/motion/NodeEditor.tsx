'use client';

import React, { useState } from 'react';
import { NodeGraphNode, NodeGraphConnection } from '@/lib/aardvark/types';
import { Share2, Plus, Play, Sparkles, Activity } from 'lucide-react';

interface NodeEditorProps {
  onApplyNodeGraphToTrack?: (trackId: string, expression: string) => void;
}

export function NodeEditor({ onApplyNodeGraphToTrack }: NodeEditorProps) {
  const [nodes, setNodes] = useState<NodeGraphNode[]>([
    {
      id: 'node_time',
      name: 'Time Variable',
      type: 'time',
      x: 40,
      y: 80,
      inputs: [],
      outputs: [{ id: 'out_t', name: 'time (s)', type: 'number' }],
      params: { speed: 1.0 },
    },
    {
      id: 'node_sine',
      name: 'Oscillator (Sine)',
      type: 'sine',
      x: 260,
      y: 60,
      inputs: [{ id: 'in_t', name: 'time', type: 'number' }],
      outputs: [{ id: 'out_v', name: 'value', type: 'number' }],
      params: { frequency: 2.0, amplitude: 35.0 },
    },
    {
      id: 'node_out',
      name: 'Rotation Output',
      type: 'property_out',
      x: 520,
      y: 80,
      inputs: [{ id: 'in_val', name: 'target val', type: 'number' }],
      outputs: [],
      params: { targetProperty: 'rotation' },
    },
  ]);

  return (
    <div className="flex flex-col h-full bg-[#090a12] border-t border-white/10 text-white text-xs select-none relative overflow-hidden">
      {/* Top Bar */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-[#121422] border-b border-white/10">
        <div className="flex items-center gap-2">
          <Share2 className="w-3.5 h-3.5 text-indigo-400" />
          <span className="font-semibold tracking-wide text-gray-200">
            AARD MOTION NODE GRAPH (VISUAL PROCEDURAL PROGRAMMING)
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              const id = `node_${Date.now()}`;
              setNodes((prev) => [
                ...prev,
                {
                  id,
                  name: 'Perlin Noise',
                  type: 'noise',
                  x: 260,
                  y: 160,
                  inputs: [{ id: 'in_t', name: 'time', type: 'number' }],
                  outputs: [{ id: 'out_n', name: 'noise', type: 'number' }],
                  params: { scale: 20, octaves: 2 },
                },
              ]);
            }}
            className="flex items-center gap-1 px-2 py-1 rounded bg-white/5 hover:bg-white/10 text-xs transition"
          >
            <Plus className="w-3 h-3" />
            <span>Add Node</span>
          </button>
        </div>
      </div>

      {/* Node Canvas Area */}
      <div className="flex-1 relative bg-[#07080f] overflow-auto p-6">
        {/* Subtle grid dots */}
        <div className="absolute inset-0 bg-[radial-gradient(#202336_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none opacity-40" />

        {/* Connections SVG */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
          <path
            d="M 180 115 C 220 115, 220 95, 260 95"
            fill="none"
            stroke="#6366f1"
            strokeWidth="2.5"
            strokeDasharray="4 2"
          />
          <path
            d="M 400 95 C 460 95, 460 115, 520 115"
            fill="none"
            stroke="#6366f1"
            strokeWidth="2.5"
          />
        </svg>

        {/* Nodes */}
        <div className="relative z-10 flex gap-10">
          {nodes.map((node) => (
            <div
              key={node.id}
              className="w-48 bg-[#131626] border border-white/15 rounded-lg shadow-xl overflow-hidden text-xs"
              style={{ transform: `translate(${node.x}px, ${node.y}px)` }}
            >
              <div className="px-3 py-1.5 bg-[#1b1f35] border-b border-white/10 font-bold flex items-center justify-between text-[11px] text-indigo-300">
                <span>{node.name}</span>
                <span className="text-[9px] uppercase px-1 py-0.5 rounded bg-white/10 text-gray-400">
                  {node.type}
                </span>
              </div>

              <div className="p-3 space-y-2">
                {node.outputs.map((out) => (
                  <div key={out.id} className="flex justify-between items-center text-[10px] text-gray-300">
                    <span>{out.name}</span>
                    <div className="w-2.5 h-2.5 rounded-full bg-indigo-500 border border-white ring-2 ring-indigo-500/20" />
                  </div>
                ))}

                {node.inputs.map((inp) => (
                  <div key={inp.id} className="flex justify-between items-center text-[10px] text-gray-300">
                    <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 border border-white ring-2 ring-emerald-500/20" />
                    <span>{inp.name}</span>
                  </div>
                ))}

                {/* Node Params */}
                {Object.entries(node.params).map(([k, v]) => (
                  <div key={k} className="flex items-center justify-between text-[10px] pt-1 border-t border-white/5">
                    <span className="text-gray-400 capitalize">{k}:</span>
                    <span className="font-mono text-indigo-200">{String(v)}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
