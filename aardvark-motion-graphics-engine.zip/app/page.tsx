'use client';

import React from 'react';
import { MotionWorkspace } from '@/components/motion/MotionWorkspace';

export default function Page() {
  return (
    <main className="w-full h-full min-h-screen bg-[#07080d] text-white">
      <MotionWorkspace />
    </main>
  );
}
