import { GoogleGenAI } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json(
        { error: 'GEMINI_API_KEY environment variable is not set.' },
        { status: 500 }
      );
    }

    const { prompt, currentDocument } = await req.json();

    const ai = new GoogleGenAI({ apiKey });

    const systemInstruction = `You are the Aardvark Motion AI Copilot, an expert motion graphics director and computational animator.
Given a user's natural language creative request and optional existing Aardvark document context, generate structured motion graphics ideas, mathematical procedural expressions, keyframe animation timing, or complete Python Aardvark code snippets.

Respond with a clean JSON object adhering to this structure:
{
  "title": "Suggested Composition Title",
  "explanation": "Brief 1-2 sentence description of the motion design concept",
  "recommendedEasing": "elastic_out" | "spring" | "back_out" | "cubic_in_out" | "expo_out",
  "expressions": [
    { "property": "rotation" | "position.y" | "scale" | "opacity", "expression": "e.g. 360 + oscillate(freq=2, amp=20)" }
  ],
  "kineticPreset": "wave" | "slide" | "pop" | "typewriter",
  "pythonCode": "Valid Aardvark Python script snippet"
}
Output only valid JSON.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: `Generate an Aardvark motion graphics composition for the following prompt: "${prompt}".\nCurrent Document Context: ${JSON.stringify(currentDocument?.title || 'Blank')}`,
            },
          ],
        },
      ],
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
      },
    });

    const responseText = response.text || '{}';
    const parsed = JSON.parse(responseText);

    return NextResponse.json(parsed);
  } catch (error: unknown) {
    console.error('Gemini motion error:', error);
    const msg = error instanceof Error ? error.message : 'Unknown error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
