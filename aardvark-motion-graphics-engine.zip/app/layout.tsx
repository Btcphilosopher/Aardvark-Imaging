import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Aardvark Motion Graphics Engine',
  description: 'Computational 2D motion design, vector animation, procedural expressions, Flash graphics, particle systems, curve editor, and timeline studio.',
  openGraph: {
    title: 'Aardvark Motion Graphics Engine',
    description: 'Computational 2D motion design, vector animation, procedural expressions, Flash graphics, particle systems, curve editor, and timeline studio.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Aardvark Motion Graphics Engine',
    description: 'Computational 2D motion design, vector animation, procedural expressions, Flash graphics, particle systems, curve editor, and timeline studio.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
