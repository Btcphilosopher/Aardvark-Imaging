# SLOWFRAME.PRO — Industrial Python Slow-Motion Engine

[![Python Version](https://img.shields.io/badge/python-3.10%20%7C%203.11%20%7C%203.12%20%7C%203.13-blue.svg)](https://python.org)
[![Engine](https://img.shields.io/badge/engine-Temporal%20Reconstruction-amber.svg)](https://slowframe.pro)
[![Architecture](https://img.shields.io/badge/pipeline-Optical%20Flow%20%7C%20Occlusion%20%7C%20Consistency-emerald.svg)](https://slowframe.pro)

**SLOWFRAME.PRO** is an industrial-grade computational video slow-motion and temporal frame reconstruction engine. Unlike standard video-speed controllers that merely duplicate frames, SLOWFRAME.PRO generates intermediate frames using dense bidirectional optical flow, forward-backward occlusion boundary analysis, temporal consistency filtering, artifact suppression, physics-based shutter angle motion blur, and optional AI neural interpolator plugins (RIFE, FILM, Super SloMo).

---

## Key Features

- **Exact Fractional & Power-of-Two Slow-Motion**: Supports `1.25x`, `1.5x`, `2x`, `4x`, `8x`, `16x`, and `32x` slowdown with exact presentation timestamps (PTS).
- **Dense Bidirectional Optical Flow**: Calculates forward ($A \rightarrow B$) and backward ($B \rightarrow A$) vector fields for symmetric temporal reconstruction.
- **Occlusion Analysis**: Identifies motion discontinuities and disocclusions to dynamically blend forward warps, backward warps, and inpainting.
- **Temporal Consistency Engine**: Eliminates flicker, geometric warping, and texture deformation across consecutive generated frames.
- **Artifact Detection & Confidence Scoring**: Assigns per-frame confidence scores, occlusion density, and artifact probability.
- **Scene Detection**: Automatically detects hard cuts, fades, and camera switches to prevent cross-scene ghosting.
- **Physical Motion Blur**: Simulates customizable camera shutter angles ($90^\circ$, $180^\circ$, $270^\circ$, $360^\circ$) using estimated motion vectors.
- **8K / 4K Tiled Memory Pipeline**: Memory-aware streaming buffer that safely handles ultra-high-resolution streams without RAM exhaustion.
- **Professional Preservation**: Retains 10-bit bit depths, Rec.709/Rec.2020 HDR metadata, timecodes, and audio time-stretching.
- **Pluggable AI & Hardware Backends**: Extensible interfaces for PyTorch/ONNX AI models, CUDA, Apple Silicon Metal, and CPU vectorization.

---

## Architecture

```
VIDEO INPUT
     │
     ▼
VIDEO DECODER (FFmpeg Safe Streaming)
     │
     ▼
FRAME BUFFER (Streaming / Tile-aware)
     │
     ▼
MOTION ANALYSER
     ├── Dense Optical Flow (Farneback / DIS / TV-L1)
     ├── Feature Tracking (Lucas-Kanade)
     ├── Scene Detection (Cut / Fade / Transition)
     └── Motion Vectors
     │
     ▼
OCCLUSION ANALYSER (Forward-Backward Inconsistency Mask)
     │
     ▼
FRAME INTERPOLATOR (Bidirectional Symmetric Warp)
     │
     ▼
TEMPORAL REFINEMENT (Consistency & Anti-Flicker)
     │
     ▼
ARTIFACT DETECTION (Confidence & Edge Stability)
     │
     ▼
MOTION-BLUR ENGINE (Shutter Angle Synthesis)
     │
     ▼
OPTIONAL SUPER-RESOLUTION (Pluggable Upscaler)
     │
     ▼
VIDEO ENCODER (H.264 / HEVC / ProRes / AV1)
     │
     ▼
OUTPUT + QUALITY REPORT (PSNR, SSIM, Smoothness)
```

---

## Installation

```bash
# Basic installation
pip install slowframe

# With AI model acceleration
pip install slowframe[ai]

# With development and test tools
pip install slowframe[dev]
```

---

## Python API

```python
from slowframe import SlowMotionEngine, SlowFrameConfig

# Initialize engine
engine = SlowMotionEngine()

# Process video with 8x slow-motion
result = engine.process(
    input="race.mov",
    output="race_slow.mov",
    slow_factor=8,
    method="bidirectional",
    quality="ultra",
    motion_blur="cinematic"
)

print(f"Output FPS: {result.output_fps}")
print(f"Frames Generated: {result.frames_generated}")
print(f"Temporal Consistency: {result.quality_score:.2%}")
print(f"Artifact Score: {result.artifact_score:.2%}")
```

### Programmable Pipeline

```python
from slowframe import SlowFramePipeline

pipeline = (
    SlowFramePipeline()
        .decode("source.mp4")
        .detect_scenes(threshold=30.0)
        .analyse_motion(method="farneback")
        .analyse_occlusions()
        .interpolate(factor=4.0, method="bidirectional")
        .refine_temporal()
        .apply_motion_blur(shutter_angle=180.0)
        .encode("output_slow.mp4")
)

result = pipeline.execute()
```

---

## Command Line Interface (CLI)

```bash
# Standard 4x slow motion
slowframe input.mp4 --slow 4 --output output.mp4

# High-quality 8x slow motion with cinematic motion blur
slowframe race.mov --slow 8 --method bidirectional --quality ultra --motion-blur cinematic --output race_slow.mp4

# Video motion and scene cut analysis
slowframe analyse input.mp4

# Quick 3-second preview generation
slowframe preview input.mp4 --slow 4 --output preview.mp4

# Batch processing
slowframe batch ./inputs ./outputs --slow 4 --quality balanced

# Resume interrupted long-running job
slowframe resume JOB_1718000000
```

---

## Test Suite

```bash
pytest
```
