"""
SLOWFRAME.PRO — Peak Signal-to-Noise Ratio (PSNR) Metric
"""

from __future__ import annotations
import numpy as np


def compute_psnr(img_a: np.ndarray, img_b: np.ndarray, max_val: float = 255.0) -> float:
    """Compute Peak Signal-to-Noise Ratio (PSNR) in dB between two images."""
    if img_a.shape != img_b.shape:
        raise ValueError(f"Images must have identical shapes for PSNR: {img_a.shape} vs {img_b.shape}")

    a_f = img_a.astype(np.float64)
    b_f = img_b.astype(np.float64)
    
    mse = np.mean((a_f - b_f) ** 2)
    if mse <= 1e-10:
        return 100.0  # Perfect match
        
    psnr = 10.0 * np.log10((max_val ** 2) / mse)
    return float(psnr)
