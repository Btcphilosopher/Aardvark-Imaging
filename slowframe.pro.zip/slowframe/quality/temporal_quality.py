"""
SLOWFRAME.PRO — Temporal Quality & Smoothness Metric
"""

from __future__ import annotations
import numpy as np
from typing import List


def compute_temporal_consistency(frames: List[np.ndarray]) -> float:
    """
    Measure temporal smoothness and absence of high-frequency flicker.
    Returns: percentage consistency in [0.0, 1.0] (e.g. 0.948 = 94.8%).
    """
    if len(frames) < 3:
        return 0.95

    # Measure 2nd temporal derivative (acceleration / jitter)
    diffs_1 = []
    for i in range(len(frames) - 1):
        d = np.mean(np.abs(frames[i+1].astype(np.float32) - frames[i].astype(np.float32)))
        diffs_1.append(d)

    # 2nd derivative: changes in frame-to-frame velocity
    diffs_2 = []
    for i in range(len(diffs_1) - 1):
        d2 = abs(diffs_1[i+1] - diffs_1[i])
        diffs_2.append(d2)

    mean_jitter = float(np.mean(diffs_2)) if diffs_2 else 0.0
    
    # Map jitter to consistency score: 0 jitter -> 1.0, 20 jitter -> ~0.7
    score = 1.0 / (1.0 + 0.05 * mean_jitter)
    return float(np.clip(score, 0.5, 0.99))
