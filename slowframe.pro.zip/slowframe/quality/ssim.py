"""
SLOWFRAME.PRO — Structural Similarity Index Measure (SSIM) Metric
"""

from __future__ import annotations
import numpy as np

try:
    import cv2
    HAS_OPENCV = True
except ImportError:
    HAS_OPENCV = False


def compute_ssim(img_a: np.ndarray, img_b: np.ndarray, k1: float = 0.01, k2: float = 0.03, l: float = 255.0) -> float:
    """Compute Structural Similarity Index (SSIM) between two images."""
    if img_a.shape != img_b.shape:
        raise ValueError(f"Images must have identical shapes for SSIM: {img_a.shape} vs {img_b.shape}")

    c1 = (k1 * l) ** 2
    c2 = (k2 * l) ** 2

    a_f = img_a.astype(np.float64)
    b_f = img_b.astype(np.float64)

    if a_f.ndim == 3:
        # Average SSIM across color channels
        scores = []
        for c in range(a_f.shape[2]):
            scores.append(_ssim_2d(a_f[:, :, c], b_f[:, :, c], c1, c2))
        return float(np.mean(scores))
    else:
        return float(_ssim_2d(a_f, b_f, c1, c2))


def _ssim_2d(x: np.ndarray, y: np.ndarray, c1: float, c2: float) -> float:
    if HAS_OPENCV:
        mu_x = cv2.GaussianBlur(x, (11, 11), 1.5)
        mu_y = cv2.GaussianBlur(y, (11, 11), 1.5)
    else:
        # Uniform box filter fallback
        mu_x = np.mean(x)
        mu_y = np.mean(y)

    mu_x_sq = mu_x * mu_x
    mu_y_sq = mu_y * mu_y
    mu_xy = mu_x * mu_y

    if HAS_OPENCV:
        sigma_x_sq = cv2.GaussianBlur(x * x, (11, 11), 1.5) - mu_x_sq
        sigma_y_sq = cv2.GaussianBlur(y * y, (11, 11), 1.5) - mu_y_sq
        sigma_xy = cv2.GaussianBlur(x * y, (11, 11), 1.5) - mu_xy
    else:
        sigma_x_sq = np.var(x)
        sigma_y_sq = np.var(y)
        sigma_xy = np.mean((x - mu_x) * (y - mu_y))

    ssim_map = ((2 * mu_xy + c1) * (2 * sigma_xy + c2)) / ((mu_x_sq + mu_y_sq + c1) * (sigma_x_sq + sigma_y_sq + c2))
    return float(np.mean(ssim_map))
