"""
SLOWFRAME.PRO — CLI Module
"""

from slowframe.cli.main import main

__all__ = ["main"]
