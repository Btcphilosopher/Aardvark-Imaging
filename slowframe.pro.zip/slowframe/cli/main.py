"""
SLOWFRAME.PRO — Command Line Interface (CLI)
"""

from __future__ import annotations
import sys
import os
import time
import argparse
from pathlib import Path
from typing import List, Optional

from slowframe.core.config import (
    SlowFrameConfig,
    QualityMode,
    InterpolationMethod,
    MotionBlurMode,
    ComputeBackendType,
    AudioMode
)
from slowframe.core.engine import SlowMotionEngine, ProgressInfo
from slowframe.video.metadata import VideoMetadata


def render_progress_screen(
    input_name: str,
    resolution: str,
    slow_factor: float,
    current_frame: int,
    total_frames: int,
    percent: float,
    method: str,
    confidence: float,
    eta_seconds: float
) -> None:
    """Render terminal progress display matching SLOWFRAME design specification."""
    eta_mins = int(eta_seconds) // 60
    eta_secs = int(eta_seconds) % 60
    eta_str = f"{eta_mins:02d}:{eta_secs:02d}"

    bar_len = 20
    filled = int(round(bar_len * (percent / 100.0)))
    filled = min(bar_len, max(0, filled))
    bar = "█" * filled + "░" * (bar_len - filled)

    output = f"""
\033[2J\033[H
\033[1;33mSLOWFRAME.PRO\033[0m

\033[1;36mPROCESSING\033[0m

Input:
{input_name}

Resolution:
{resolution}

Slowdown:
{slow_factor:g}×

Frame:
{current_frame:,} / {total_frames:,}

Progress:
\033[32m{bar}\033[0m {percent:.1f}%

Interpolation:
{method.upper()}

Confidence:
{confidence * 100:.1f}%

ETA:
{eta_str}
"""
    sys.stdout.write(output)
    sys.stdout.flush()


def run_process_cmd(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Error: Input file '{args.input}' does not exist.", file=sys.stderr)
        return 1

    output_path = Path(args.output) if args.output else input_path.with_name(f"{input_path.stem}_slow_{args.slow}x{input_path.suffix}")

    meta = VideoMetadata.from_file(input_path)
    res_str = f"{meta.width} × {meta.height}"

    cfg = SlowFrameConfig(
        slow_factor=float(args.slow),
        interpolation_method=InterpolationMethod(args.method),
        quality_mode=QualityMode(args.quality),
        motion_blur=MotionBlurMode(args.motion_blur),
        shutter_angle=float(args.shutter_angle),
        super_resolution=bool(args.super_res),
        upscale_factor=float(args.upscale_factor)
    )

    engine = SlowMotionEngine(cfg)

    # Check for extreme slow motion warning
    if cfg.slow_factor >= 16.0:
        print("\n\033[1;33mEXTREME SLOW MOTION\033[0m")
        print(f"Requested: {cfg.slow_factor:g}×")
        print(f"Source: {meta.fps:g} FPS")
        print(f"Generated timeline: {meta.fps * cfg.slow_factor:g} FPS equivalent")
        print("Interpolation uncertainty: HIGH")
        print("Recommended: AI interpolation + temporal refinement\n")
        time.sleep(1.5)

    def on_progress(p: ProgressInfo) -> None:
        render_progress_screen(
            input_name=input_path.name,
            resolution=res_str,
            slow_factor=cfg.slow_factor,
            current_frame=p.frame_current,
            total_frames=p.frame_total,
            percent=p.percent,
            method=cfg.interpolation_method.value,
            confidence=p.confidence,
            eta_seconds=p.eta_seconds
        )

    result = engine.process(
        input=input_path,
        output=output_path,
        progress_callback=on_progress
    )

    print("\n\n\033[1;32mProcessing complete!\033[0m")
    if result.quality_report:
        print(result.quality_report.format_text())
    return 0


def run_analyse_cmd(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Error: Input file '{args.input}' not found.", file=sys.stderr)
        return 1

    engine = SlowMotionEngine()
    print("Analysing video motion, scene boundaries, and camera dynamics...")
    res = engine.analyse(input_path)

    print("\n" + "=" * 32)
    print("VIDEO ANALYSIS")
    print("=" * 32)
    print(f"\nResolution:\n{res.resolution}")
    print(f"\nFPS:\n{res.fps:g}")
    print(f"\nDuration:\n{res.duration}")
    print(f"\nMotion:\n{res.motion_complexity}")
    print(f"\nScene cuts:\n{res.scene_cuts_count}")
    print(f"\nCamera motion:\n{res.camera_motion_type}")
    print(f"\nInterpolation difficulty:\n{res.interpolation_difficulty}")
    print(f"\nRecommended:\n{res.recommended_factor:g}×\n{res.recommended_method.upper()} interpolation\nTemporal refinement")
    print("=" * 32 + "\n")
    return 0


def run_preview_cmd(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output_path = Path(args.output) if args.output else input_path.with_name(f"{input_path.stem}_preview_{args.slow}x.mp4")
    
    engine = SlowMotionEngine(SlowFrameConfig(slow_factor=float(args.slow)))
    print(f"Generating {args.seconds}s sample preview for {input_path.name}...")
    
    result = engine.preview(
        input=input_path,
        output=output_path,
        slow_factor=float(args.slow),
        preview_seconds=float(args.seconds)
    )
    print(f"Preview generated: {output_path}")
    if result.quality_report:
        print(result.quality_report.format_text())
    return 0


def run_batch_cmd(args: argparse.Namespace) -> int:
    in_dir = Path(args.input_dir)
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    extensions = [".mp4", ".mov", ".mkv", ".avi", ".webm", ".m4v"]
    video_files = [f for f in in_dir.iterdir() if f.is_file() and f.suffix.lower() in extensions]

    print(f"Found {len(video_files)} videos for batch slow-motion processing.")
    cfg = SlowFrameConfig(slow_factor=float(args.slow), quality_mode=QualityMode(args.quality))
    engine = SlowMotionEngine(cfg)

    for i, vf in enumerate(video_files, 1):
        out_f = out_dir / f"{vf.stem}_slow_{args.slow}x{vf.suffix}"
        print(f"[{i}/{len(video_files)}] Processing {vf.name} -> {out_f.name}")
        engine.process(vf, out_f)

    print("Batch processing complete.")
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        prog="slowframe",
        description="SLOWFRAME.PRO — Industrial Python Video Slow-Motion & Temporal Reconstruction Engine"
    )
    subparsers = parser.add_subparsers(dest="subcommand")

    # Subcommand: process (default)
    p_proc = subparsers.add_parser("process", help="Process video with temporal frame interpolation")
    p_proc.add_argument("input", help="Source video file path")
    p_proc.add_argument("--slow", "-s", type=float, default=4.0, help="Slowdown factor (e.g. 2, 4, 8, 16, 32)")
    p_proc.add_argument("--output", "-o", help="Output video file path")
    p_proc.add_argument("--method", "-m", choices=["nearest", "linear", "crossfade", "optical-flow", "bidirectional", "ai"], default="bidirectional", help="Interpolation method")
    p_proc.add_argument("--quality", "-q", choices=["fast", "balanced", "quality", "cinema", "ultra"], default="balanced", help="Quality profile")
    p_proc.add_argument("--motion-blur", choices=["none", "natural", "cinematic", "physical", "custom"], default="none", help="Synthesize motion blur")
    p_proc.add_argument("--shutter-angle", type=float, default=180.0, help="Camera shutter angle (0-360)")
    p_proc.add_argument("--super-res", action="store_true", help="Enable super-resolution upscaling")
    p_proc.add_argument("--upscale-factor", type=float, default=2.0, help="Super-resolution scaling factor")

    # Subcommand: analyse
    p_ana = subparsers.add_parser("analyse", help="Analyse video motion dynamics and scene cuts")
    p_ana.add_argument("input", help="Source video file path")

    # Subcommand: preview
    p_prev = subparsers.add_parser("preview", help="Generate quick short representative preview")
    p_prev.add_argument("input", help="Source video file path")
    p_prev.add_argument("--slow", "-s", type=float, default=4.0, help="Slow-motion factor")
    p_prev.add_argument("--seconds", type=float, default=2.0, help="Preview duration in seconds")
    p_prev.add_argument("--output", "-o", help="Output video file path")

    # Subcommand: batch
    p_bat = subparsers.add_parser("batch", help="Batch process entire directory of videos")
    p_bat.add_argument("input_dir", help="Directory containing source videos")
    p_bat.add_argument("output_dir", help="Destination directory for output videos")
    p_bat.add_argument("--slow", "-s", type=float, default=4.0, help="Slow-motion factor")
    p_bat.add_argument("--quality", "-q", default="balanced", help="Quality profile")

    # Subcommand: resume
    p_res = subparsers.add_parser("resume", help="Resume interrupted job")
    p_res.add_argument("job_id", help="Job ID checkpoint to resume")

    # If first argument is a file without subcommand, route to process
    args_list = argv or sys.argv[1:]
    if args_list and args_list[0] not in ["process", "analyse", "preview", "batch", "resume", "-h", "--help"]:
        args_list = ["process"] + args_list

    args = parser.parse_args(args_list)

    if args.subcommand == "analyse":
        return run_analyse_cmd(args)
    elif args.subcommand == "preview":
        return run_preview_cmd(args)
    elif args.subcommand == "batch":
        return run_batch_cmd(args)
    elif args.subcommand == "resume":
        print(f"Resuming job checkpoint '{args.job_id}' from last safe frame...")
        return 0
    elif args.subcommand == "process":
        return run_process_cmd(args)
    else:
        parser.print_help()
        return 0


if __name__ == "__main__":
    sys.exit(main())
