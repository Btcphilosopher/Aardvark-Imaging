"""
SLOWFRAME.PRO — Unidirectional Optical Flow Interpolator
"""

from __future__ import annotations
import numpy as np
from typing import Optional

try:
    import cv2
    HAS_OPENCV = True
except ImportError:
    HAS_OPENCV = False

from slowframe.motion.optical_flow import MotionEstimator


class UnidirectionalFlowInterpolator:
    """Warps frames forward or backward along a single optical flow field."""

    def __init__(self, estimator: Optional[MotionEstimator] = None):
        self.estimator = estimator or MotionEstimator()

    def interpolate(self, img_a: np.ndarray, img_b: np.ndarray, t: float) -> np.ndarray:
        """
        Interpolate frame at fractional time t in [0.0, 1.0].
        Calculates flow A -> B, scales by t, and warps A.
        """
        t = float(np.clip(t, 0.0, 1.0))
        if t == 0.0:
            return img_a.copy()
        if t == 1.0:
            return img_b.copy()

        flow_ab = self.estimator.estimate_unidirectional(img_a, img_b)
        flow_scaled = flow_ab * t
        
        warped_a = self.warp(img_a, flow_scaled)
        
        # Simple blend with linear crossfade for stability in fast regions
        crossfade = (1.0 - t) * img_a.astype(np.float32) + t * img_b.astype(np.float32)
        blended = 0.85 * warped_a.astype(np.float32) + 0.15 * crossfade
        
        return np.clip(blended, 0, 255).astype(img_a.dtype)

    def warp(self, image: np.ndarray, flow: np.ndarray) -> np.ndarray:
        """Warp image using flow field."""
        h, w = image.shape[:2]
        if HAS_OPENCV:
            grid_x, grid_y = np.meshgrid(np.arange(w), np.arange(h))
            map_x = (grid_x - flow[..., 0]).astype(np.float32)
            map_y = (grid_y - flow[..., 1]).astype(np.float32)
            warped = cv2.remap(image, map_x, map_y, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
            return warped
        else:
            # Fallback
            return self.estimator._numpy_bilinear_warp(image, -flow)
