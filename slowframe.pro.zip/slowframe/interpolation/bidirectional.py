"""
SLOWFRAME.PRO — Bidirectional Optical Flow & Occlusion-Aware Interpolator
"""

from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from typing import Optional, Tuple

try:
    import cv2
    HAS_OPENCV = True
except ImportError:
    HAS_OPENCV = False

from slowframe.motion.optical_flow import MotionEstimator, OpticalFlowResult


@dataclass
class InterpolatedFrameResult:
    image: np.ndarray          # Interpolated RGB image (H, W, C)
    confidence: float          # Global quality confidence [0.0, 1.0]
    occlusion_mask: np.ndarray # (H, W) 0.0=unoccluded, 1.0=occluded
    confidence_map: np.ndarray # (H, W) per-pixel confidence
    warped_a: np.ndarray       # Forward warp from A
    warped_b: np.ndarray       # Backward warp from B


class BidirectionalFlowInterpolator:
    """
    Industrial Bidirectional Optical Flow Engine with Occlusion Masking
    and Symmetric Temporal Blending.
    """

    def __init__(self, estimator: Optional[MotionEstimator] = None):
        self.estimator = estimator or MotionEstimator()

    def interpolate(
        self,
        img_a: np.ndarray,
        img_b: np.ndarray,
        t: float,
        flow_result: Optional[OpticalFlowResult] = None
    ) -> InterpolatedFrameResult:
        """
        Synthesize intermediate frame at relative time t in [0.0, 1.0].
        
        Algorithm:
        1. Calculate bidirectional flows V_ab (A -> B) and V_ba (B -> A).
        2. Compute occlusion masks using forward-backward inconsistency.
        3. Project forward flow to time t:  F_t = t * V_ab
        4. Project backward flow to time t: B_t = (1 - t) * V_ba
        5. Warp Frame A along F_t and Frame B along B_t.
        6. Compute temporal weighting with occlusion penalty:
           w_a = (1 - t) * (1 - occ_a)
           w_b = t * (1 - occ_b)
        7. Composite and apply hole inpainting where both are occluded.
        """
        t = float(np.clip(t, 0.0, 1.0))
        h, w = img_a.shape[:2]

        if t == 0.0:
            return InterpolatedFrameResult(
                image=img_a.copy(),
                confidence=1.0,
                occlusion_mask=np.zeros((h, w), dtype=np.float32),
                confidence_map=np.ones((h, w), dtype=np.float32),
                warped_a=img_a.copy(),
                warped_b=img_a.copy()
            )
        if t == 1.0:
            return InterpolatedFrameResult(
                image=img_b.copy(),
                confidence=1.0,
                occlusion_mask=np.zeros((h, w), dtype=np.float32),
                confidence_map=np.ones((h, w), dtype=np.float32),
                warped_a=img_b.copy(),
                warped_b=img_b.copy()
            )

        if flow_result is None:
            flow_result = self.estimator.estimate_bidirectional(img_a, img_b)

        v_ab = flow_result.flow_forward
        v_ba = flow_result.flow_backward

        # Scaled flow fields to time t
        # A warps forward to t: displacement = t * v_ab
        flow_a_to_t = v_ab * t
        # B warps backward to t: displacement = (1.0 - t) * v_ba
        flow_b_to_t = v_ba * (1.0 - t)

        # Warp Frame A and Frame B
        warped_a = self._warp_image(img_a, flow_a_to_t)
        warped_b = self._warp_image(img_b, flow_b_to_t)

        # Warped occlusion maps
        occ_a = flow_result.occlusion_mask
        occ_b = self._warp_mask(occ_a, flow_b_to_t)

        # Base temporal weights
        wa = (1.0 - t) * (1.0 - 0.8 * occ_a)
        wb = t * (1.0 - 0.8 * occ_b)

        wa = np.maximum(wa, 0.01)[:, :, None]
        wb = np.maximum(wb, 0.01)[:, :, None]
        total_w = wa + wb

        wa_norm = wa / total_w
        wb_norm = wb / total_w

        wa_f = warped_a.astype(np.float32)
        wb_f = warped_b.astype(np.float32)

        # Composite frame
        composite = wa_norm * wa_f + wb_norm * wb_f

        # Hole filling / Inpainting where occlusion is severe
        severe_occ = (occ_a > 0.85) & (occ_b > 0.85)
        if np.any(severe_occ) and HAS_OPENCV:
            crossfade = (1.0 - t) * img_a.astype(np.float32) + t * img_b.astype(np.float32)
            composite[severe_occ] = crossfade[severe_occ]

        out_img = np.clip(composite, 0, 255).astype(img_a.dtype)

        # Compute frame confidence
        mean_conf = float(np.mean(flow_result.confidence_map))
        
        return InterpolatedFrameResult(
            image=out_img,
            confidence=mean_conf,
            occlusion_mask=flow_result.occlusion_mask,
            confidence_map=flow_result.confidence_map,
            warped_a=warped_a,
            warped_b=warped_b
        )

    def _warp_image(self, image: np.ndarray, flow: np.ndarray) -> np.ndarray:
        """Backward mapping coordinate warp."""
        h, w = image.shape[:2]
        if HAS_OPENCV:
            grid_x, grid_y = np.meshgrid(np.arange(w), np.arange(h))
            map_x = (grid_x - flow[..., 0]).astype(np.float32)
            map_y = (grid_y - flow[..., 1]).astype(np.float32)
            return cv2.remap(image, map_x, map_y, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
        else:
            return self.estimator._numpy_bilinear_warp(image, -flow)

    def _warp_mask(self, mask: np.ndarray, flow: np.ndarray) -> np.ndarray:
        h, w = mask.shape[:2]
        if HAS_OPENCV:
            grid_x, grid_y = np.meshgrid(np.arange(w), np.arange(h))
            map_x = (grid_x - flow[..., 0]).astype(np.float32)
            map_y = (grid_y - flow[..., 1]).astype(np.float32)
            return cv2.remap(mask, map_x, map_y, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
        return mask
