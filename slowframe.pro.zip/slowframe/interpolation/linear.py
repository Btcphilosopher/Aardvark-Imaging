"""
SLOWFRAME.PRO — Linear & Nearest Frame Interpolation
"""

from __future__ import annotations
import numpy as np
from typing import Tuple


class LinearInterpolator:
    """Linear crossfade and nearest-neighbor frame interpolators."""

    @staticmethod
    def interpolate_nearest(img_a: np.ndarray, img_b: np.ndarray, t: float) -> np.ndarray:
        """Select nearest frame based on timestamp factor t in [0.0, 1.0]."""
        if t < 0.5:
            return img_a.copy()
        return img_b.copy()

    @staticmethod
    def interpolate_crossfade(img_a: np.ndarray, img_b: np.ndarray, t: float) -> np.ndarray:
        """Linear weighted blending between Frame A and Frame B."""
        t = np.clip(t, 0.0, 1.0)
        a_f = img_a.astype(np.float32)
        b_f = img_b.astype(np.float32)
        blended = (1.0 - t) * a_f + t * b_f
        return np.clip(blended, 0, 255).astype(img_a.dtype)
