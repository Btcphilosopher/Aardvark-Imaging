"""
SLOWFRAME.PRO — Interpolation Subsystem
"""

from slowframe.interpolation.linear import LinearInterpolator
from slowframe.interpolation.optical_flow import UnidirectionalFlowInterpolator
from slowframe.interpolation.bidirectional import BidirectionalFlowInterpolator, InterpolatedFrameResult
from slowframe.interpolation.ai_interpolator import (
    AIInterpolator,
    RIFEInterpolatorPlugin,
    FILMInterpolatorPlugin,
    SuperSloMoPlugin,
    AIPluginRegistry,
    AIModelInfo
)

__all__ = [
    "LinearInterpolator",
    "UnidirectionalFlowInterpolator",
    "BidirectionalFlowInterpolator",
    "InterpolatedFrameResult",
    "AIInterpolator",
    "RIFEInterpolatorPlugin",
    "FILMInterpolatorPlugin",
    "SuperSloMoPlugin",
    "AIPluginRegistry",
    "AIModelInfo",
]
