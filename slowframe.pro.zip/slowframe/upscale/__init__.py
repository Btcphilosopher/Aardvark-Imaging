"""
SLOWFRAME.PRO — Upscale & Super-Resolution Subsystem
"""

from slowframe.upscale.super_resolution import SuperResolutionEngine, SuperResolutionModelInfo

__all__ = [
    "SuperResolutionEngine",
    "SuperResolutionModelInfo",
]
