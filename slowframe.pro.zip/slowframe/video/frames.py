"""
SLOWFRAME.PRO — Frame Representation & Memory Buffer Management
"""

from __future__ import annotations
import numpy as np
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List, Iterator, Tuple


@dataclass
class FrameMetadata:
    """Metadata for an individual frame."""
    index: int
    timestamp: float  # In seconds (e.g. 0.03333)
    pts: int          # Presentation timestamp integer ticks
    timebase: float = 1.0 / 1000000.0  # Microsecond default
    is_interpolated: bool = False
    source_pair: Optional[Tuple[int, int]] = None  # (Frame A index, Frame B index)
    interpolation_t: float = 0.0  # Relative time [0.0, 1.0] between pair
    confidence_score: float = 1.0  # Interpolation quality confidence [0.0, 1.0]
    occlusion_level: str = "LOW"   # "LOW", "MEDIUM", "HIGH"
    motion_complexity: str = "MEDIUM"
    artifact_probability: float = 0.0
    scene_id: int = 0
    color_space: str = "bt709"
    extra: Dict[str, Any] = field(default_factory=dict)


class Frame:
    """
    Industrial frame container with numpy ndarray data, metadata,
    and memory-efficient tile extraction for 4K/8K workloads.
    """

    def __init__(
        self,
        data: np.ndarray,
        index: int = 0,
        timestamp: float = 0.0,
        pts: int = 0,
        is_interpolated: bool = False,
        color_space: str = "bt709",
        metadata: Optional[FrameMetadata] = None,
    ):
        if not isinstance(data, np.ndarray):
            raise TypeError(f"Frame data must be numpy.ndarray, got {type(data)}")
        
        # Ensure contiguous array for high performance C/OpenCV operations
        self._data = np.ascontiguousarray(data)
        
        if self._data.ndim == 2:
            # Grayscale -> 3 channel
            self._data = np.stack([self._data]*3, axis=-1)
        elif self._data.ndim == 3 and self._data.shape[2] == 4:
            # Drop alpha if present for raw RGB
            self._data = self._data[:, :, :3]

        self.height, self.width = self._data.shape[:2]
        self.channels = self._data.shape[2] if self._data.ndim == 3 else 1
        self.dtype = self._data.dtype
        
        if metadata is not None:
            self.metadata = metadata
        else:
            self.metadata = FrameMetadata(
                index=index,
                timestamp=timestamp,
                pts=pts,
                is_interpolated=is_interpolated,
                color_space=color_space
            )

    @property
    def data(self) -> np.ndarray:
        """Raw image array (H, W, C) in RGB format."""
        return self._data

    @data.setter
    def data(self, new_data: np.ndarray) -> None:
        self._data = np.ascontiguousarray(new_data)
        self.height, self.width = self._data.shape[:2]

    @property
    def index(self) -> int:
        return self.metadata.index

    @property
    def timestamp(self) -> float:
        return self.metadata.timestamp

    @property
    def is_interpolated(self) -> bool:
        return self.metadata.is_interpolated

    def as_uint8(self) -> np.ndarray:
        """Return RGB image as uint8 [0, 255]."""
        if self._data.dtype == np.uint8:
            return self._data
        if np.issubdtype(self._data.dtype, np.floating):
            # Scale float [0.0, 1.0] to [0, 255]
            if self._data.max() <= 1.05:
                return np.clip(self._data * 255.0, 0, 255).astype(np.uint8)
            return np.clip(self._data, 0, 255).astype(np.uint8)
        if self._data.dtype == np.uint16:
            # 16-bit to 8-bit
            return (self._data >> 8).astype(np.uint8)
        return np.clip(self._data, 0, 255).astype(np.uint8)

    def as_float32(self) -> np.ndarray:
        """Return RGB image as float32 [0.0, 1.0]."""
        if self._data.dtype == np.float32 and self._data.max() <= 1.05:
            return self._data
        return self.as_uint8().astype(np.float32) / 255.0

    def as_grayscale(self) -> np.ndarray:
        """Convert to 1-channel grayscale uint8."""
        rgb = self.as_uint8()
        # Fast perceptual luminance: 0.299 R + 0.587 G + 0.114 B
        gray = (0.299 * rgb[:, :, 0] + 0.587 * rgb[:, :, 1] + 0.114 * rgb[:, :, 2]).astype(np.uint8)
        return gray

    def copy(self) -> Frame:
        """Deep copy frame data and metadata."""
        import copy
        return Frame(
            data=self._data.copy(),
            metadata=copy.deepcopy(self.metadata)
        )

    def extract_tiles(self, tile_size: int = 1024, overlap: int = 64) -> Iterator[Tuple[Tuple[int, int, int, int], np.ndarray]]:
        """
        Yield (bbox, tile_data) for memory-aware 4K/8K tile processing.
        bbox = (y_min, y_max, x_min, x_max)
        """
        stride = tile_size - overlap
        for y in range(0, self.height, stride):
            y_end = min(y + tile_size, self.height)
            y_start = max(0, y_end - tile_size) if y_end == self.height else y
            for x in range(0, self.width, stride):
                x_end = min(x + tile_size, self.width)
                x_start = max(0, x_end - tile_size) if x_end == self.width else x
                
                tile = self._data[y_start:y_end, x_start:x_end]
                yield (y_start, y_end, x_start, x_end), tile

    @staticmethod
    def assemble_tiles(
        tiles: List[Tuple[Tuple[int, int, int, int], np.ndarray]],
        target_shape: Tuple[int, int, int],
        overlap: int = 64,
        dtype: np.dtype = np.uint8
    ) -> np.ndarray:
        """Seamlessly assemble tiles with linear blending in overlapping margins."""
        h, w, c = target_shape
        out_accum = np.zeros((h, w, c), dtype=np.float32)
        weight_accum = np.zeros((h, w, 1), dtype=np.float32)

        for (y1, y2, x1, x2), tile in tiles:
            th, tw = y2 - y1, x2 - x1
            # Generate 2D feathering weight for tile
            wy = np.ones(th, dtype=np.float32)
            wx = np.ones(tw, dtype=np.float32)
            
            if y1 > 0 and overlap > 0:
                wy[:overlap] = np.linspace(0.0, 1.0, overlap)
            if y2 < h and overlap > 0:
                wy[-overlap:] = np.linspace(1.0, 0.0, overlap)
                
            if x1 > 0 and overlap > 0:
                wx[:overlap] = np.linspace(0.0, 1.0, overlap)
            if x2 < w and overlap > 0:
                wx[-overlap:] = np.linspace(1.0, 0.0, overlap)
                
            w2d = (wy[:, None] * wx[None, :])[:, :, None]
            tile_f = tile.astype(np.float32) if tile.dtype != np.float32 else tile
            
            out_accum[y1:y2, x1:x2] += tile_f * w2d
            weight_accum[y1:y2, x1:x2] += w2d

        weight_accum = np.maximum(weight_accum, 1e-6)
        result = out_accum / weight_accum
        if np.issubdtype(dtype, np.integer):
            return np.clip(result, 0, 255).astype(dtype)
        return result.astype(dtype)


class FrameSequence:
    """Fixed-capacity ring buffer or list of frames with memory limits."""

    def __init__(self, capacity: int = 32):
        self.capacity = capacity
        self._frames: List[Frame] = []

    def append(self, frame: Frame) -> None:
        self._frames.append(frame)
        if len(self._frames) > self.capacity:
            self._frames.pop(0)

    def __getitem__(self, idx: int) -> Frame:
        return self._frames[idx]

    def __len__(self) -> int:
        return len(self._frames)

    def clear(self) -> None:
        self._frames.clear()

    def get_last_pair(self) -> Optional[Tuple[Frame, Frame]]:
        if len(self._frames) >= 2:
            return self._frames[-2], self._frames[-1]
        return None
