"""
SLOWFRAME.PRO — Safe Streaming Video Encoder & Audio Time-Stretching
"""

from __future__ import annotations
import os
import subprocess
import numpy as np
from pathlib import Path
from typing import Optional, Dict, Any

from slowframe.core.config import SlowFrameConfig, AudioMode
from slowframe.video.metadata import VideoMetadata


class VideoEncoder:
    """
    Industrial Streaming Video Encoder utilizing FFmpeg stdin pipe.
    Supports H.264, HEVC, ProRes, AV1, HDR preservation, and audio time-stretching.
    """

    def __init__(
        self,
        output_path: str | Path,
        width: int,
        height: int,
        fps: float,
        config: Optional[SlowFrameConfig] = None,
        source_metadata: Optional[VideoMetadata] = None
    ):
        self.output_path = str(output_path)
        self.width = width
        self.height = height
        self.fps = fps
        self.config = config or SlowFrameConfig()
        self.source_metadata = source_metadata
        self._proc: Optional[subprocess.Popen] = None
        self._frames_written = 0
        
        # Ensure parent output directory exists
        Path(self.output_path).parent.mkdir(parents=True, exist_ok=True)

    def open(self) -> None:
        """Start the background FFmpeg encoder process."""
        if self._proc is not None:
            return

        cmd = [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel", "error",
            "-f", "rawvideo",
            "-vcodec", "rawvideo",
            "-s", f"{self.width}x{self.height}",
            "-pix_fmt", "rgb24",
            "-r", f"{self.fps:.6f}",
            "-i", "-",  # Video from stdin pipe
        ]

        # Audio time-stretching if source has audio and mode is TIME_STRETCH
        has_audio = (
            self.source_metadata is not None and
            len(self.source_metadata.audio_streams) > 0 and
            self.config.audio_mode != AudioMode.MUTE
        )

        audio_filters = []
        if has_audio and self.source_metadata:
            src_path = self.source_metadata.path
            cmd.extend(["-i", src_path])
            
            if self.config.audio_mode == AudioMode.TIME_STRETCH:
                # Audio tempo must be slowed down by slow_factor: tempo = 1.0 / slow_factor
                # atempo supports factors between 0.5 and 2.0. For higher factors, chain filters:
                target_tempo = 1.0 / float(self.config.slow_factor)
                
                tempo_chain = []
                remaining_tempo = target_tempo
                while remaining_tempo < 0.5:
                    tempo_chain.append("atempo=0.5")
                    remaining_tempo /= 0.5
                tempo_chain.append(f"atempo={remaining_tempo:.4f}")
                
                audio_filters.append(",".join(tempo_chain))

        if audio_filters:
            cmd.extend(["-filter:a", ",".join(audio_filters)])
            cmd.extend(["-c:a", "aac", "-b:a", "192k"])
        elif not has_audio:
            cmd.extend(["-an"])

        # Codec selection
        codec_name = self.config.output_codec.lower()
        if codec_name in ["h264", "x264", "libx264"]:
            cmd.extend([
                "-c:v", "libx264",
                "-preset", self.config.preset,
                "-crf", str(self.config.crf),
                "-pix_fmt", "yuv420p"
            ])
        elif codec_name in ["hevc", "h265", "libx265"]:
            cmd.extend([
                "-c:v", "libx265",
                "-preset", self.config.preset,
                "-crf", str(self.config.crf),
                "-pix_fmt", "yuv420p"
            ])
        elif codec_name in ["prores", "prores_ks"]:
            cmd.extend([
                "-c:v", "prores_ks",
                "-profile:v", "3",  # ProRes 422 HQ
                "-pix_fmt", "yuv422p10le"
            ])
        elif codec_name in ["av1", "libaom-av1"]:
            cmd.extend([
                "-c:v", "libaom-av1",
                "-crf", str(self.config.crf),
                "-b:v", "0",
                "-pix_fmt", "yuv420p"
            ])
        else:
            cmd.extend(["-c:v", "libx264", "-pix_fmt", "yuv420p"])

        cmd.append(self.output_path)

        try:
            self._proc = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
        except Exception as e:
            raise RuntimeError(f"Failed to start FFmpeg encoder: {e}")

    def write_frame(self, frame_data: np.ndarray) -> None:
        """Write single RGB24 image array to encoder pipe."""
        if self._proc is None:
            self.open()

        if frame_data.dtype != np.uint8:
            data_u8 = np.clip(frame_data, 0, 255).astype(np.uint8)
        else:
            data_u8 = frame_data

        if not data_u8.flags["C_CONTIGUOUS"]:
            data_u8 = np.ascontiguousarray(data_u8)

        try:
            self._proc.stdin.write(data_u8.tobytes())
            self._frames_written += 1
        except BrokenPipeError:
            err = self._proc.stderr.read().decode('utf-8', errors='ignore') if self._proc.stderr else ""
            raise RuntimeError(f"FFmpeg encoder broken pipe: {err}")

    def close(self) -> None:
        """Close stdin and wait for FFmpeg to finalize container."""
        if self._proc is None:
            return

        try:
            if self._proc.stdin:
                self._proc.stdin.close()
            if self._proc.stdout:
                self._proc.stdout.close()
            if self._proc.stderr:
                self._proc.stderr.close()
            self._proc.wait(timeout=60)
        except Exception:
            if self._proc.poll() is None:
                self._proc.kill()
        finally:
            self._proc = None

    def __enter__(self) -> VideoEncoder:
        self.open()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()
