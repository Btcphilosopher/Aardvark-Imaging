"""
SLOWFRAME.PRO — Safe FFmpeg Video Decoder & Frame Streamer
"""

from __future__ import annotations
import os
import subprocess
import numpy as np
from pathlib import Path
from typing import Iterator, Optional, Tuple

from slowframe.video.frames import Frame, FrameMetadata
from slowframe.video.metadata import VideoMetadata


class VideoDecoder:
    """
    Industrial Safe Video Decoder using streaming FFmpeg subprocess pipes.
    Memory-efficient: streams uncompressed frames sequentially without RAM exhaustion.
    """

    def __init__(self, file_path: str | Path):
        self.file_path = str(file_path)
        self.metadata = VideoMetadata.from_file(self.file_path)

    def stream_frames(
        self,
        start_frame: int = 0,
        max_frames: Optional[int] = None
    ) -> Iterator[Frame]:
        """
        Yield uncompressed RGB24 Frame instances one by one via FFmpeg pipe.
        """
        w = self.metadata.width
        h = self.metadata.height
        frame_bytes = w * h * 3  # RGB24
        fps = self.metadata.fps
        timebase = 1.0 / fps if fps > 0 else 1.0 / 30.0

        # Build FFmpeg command
        cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error"]
        
        if start_frame > 0:
            start_time = start_frame / fps
            cmd.extend(["-ss", f"{start_time:.6f}"])

        cmd.extend([
            "-i", self.file_path,
            "-f", "rawvideo",
            "-pix_fmt", "rgb24",
            "-"
        ])

        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                bufsize=10 * frame_bytes
            )
        except Exception as e:
            # If FFmpeg binary fails to start, yield empty or raise
            raise RuntimeError(f"Failed to start FFmpeg decoder process: {e}")

        curr_idx = start_frame
        frames_yielded = 0

        try:
            while True:
                if max_frames is not None and frames_yielded >= max_frames:
                    break

                raw = proc.stdout.read(frame_bytes)
                if not raw or len(raw) < frame_bytes:
                    break

                img_data = np.frombuffer(raw, dtype=np.uint8).reshape((h, w, 3))
                t_sec = curr_idx * timebase
                pts = int(round(t_sec * 1000000))

                meta = FrameMetadata(
                    index=curr_idx,
                    timestamp=t_sec,
                    pts=pts,
                    is_interpolated=False,
                    color_space=self.metadata.color_space
                )

                yield Frame(data=img_data, metadata=meta)
                curr_idx += 1
                frames_yielded += 1

        finally:
            if proc.poll() is None:
                proc.kill()
            if proc.stdout:
                proc.stdout.close()
            if proc.stderr:
                proc.stderr.close()
            proc.wait()
