"""
SLOWFRAME.PRO — Video Metadata Probe and Representation
"""

from __future__ import annotations
import json
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Dict, Any, List


@dataclass
class AudioStreamInfo:
    index: int
    codec: str
    sample_rate: int
    channels: int
    channel_layout: str
    bit_rate: Optional[int] = None


@dataclass
class VideoMetadata:
    """Rich metadata container preserving all broadcast and cinema characteristics."""

    path: str
    width: int
    height: int
    fps: float
    duration: float
    total_frames: int
    codec: str
    pixel_format: str = "yuv420p"
    bit_depth: int = 8
    color_space: str = "bt709"
    color_primaries: str = "bt709"
    color_transfer: str = "bt709"
    is_hdr: bool = False
    aspect_ratio: str = "16:9"
    bit_rate: Optional[int] = None
    timecode: Optional[str] = None
    audio_streams: List[AudioStreamInfo] = field(default_factory=list)
    raw_streams: List[Dict[str, Any]] = field(default_factory=list)
    raw_format: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_file(cls, file_path: str | Path) -> VideoMetadata:
        """Probe video file using ffprobe and extract complete technical profile."""
        path_str = str(file_path)
        if not Path(path_str).exists():
            raise FileNotFoundError(f"Video file not found: {path_str}")

        cmd = [
            "ffprobe",
            "-v", "quiet",
            "-print_format", "json",
            "-show_format",
            "-show_streams",
            path_str
        ]

        try:
            result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
            data = json.loads(result.stdout)
        except Exception as e:
            # Fallback for synthetic/virtual video or when ffprobe isn't installed
            return cls._fallback_probe(path_str)

        streams = data.get("streams", [])
        format_info = data.get("format", {})

        video_stream = None
        audio_streams = []

        for s in streams:
            if s.get("codec_type") == "video" and video_stream is None:
                video_stream = s
            elif s.get("codec_type") == "audio":
                audio_streams.append(AudioStreamInfo(
                    index=int(s.get("index", 0)),
                    codec=s.get("codec_name", "aac"),
                    sample_rate=int(s.get("sample_rate", 44100)),
                    channels=int(s.get("channels", 2)),
                    channel_layout=s.get("channel_layout", "stereo"),
                    bit_rate=int(s.get("bit_rate")) if s.get("bit_rate") else None
                ))

        if not video_stream:
            raise ValueError(f"No video stream found in {path_str}")

        width = int(video_stream.get("width", 1920))
        height = int(video_stream.get("height", 1080))
        codec = video_stream.get("codec_name", "h264")
        pix_fmt = video_stream.get("pix_fmt", "yuv420p")
        
        # Determine bit depth
        bit_depth = 8
        if "10" in pix_fmt or "10le" in pix_fmt:
            bit_depth = 10
        elif "12" in pix_fmt or "12le" in pix_fmt:
            bit_depth = 12
        elif "16" in pix_fmt or "16le" in pix_fmt:
            bit_depth = 16

        # Parse FPS
        fps_str = video_stream.get("r_frame_rate", video_stream.get("avg_frame_rate", "30/1"))
        if "/" in fps_str:
            num, den = fps_str.split("/")
            fps = float(num) / float(den) if float(den) != 0 else 30.0
        else:
            fps = float(fps_str) if fps_str else 30.0

        # Duration and total frames
        duration = float(video_stream.get("duration", format_info.get("duration", 0.0)))
        total_frames = int(video_stream.get("nb_frames", 0))
        if total_frames == 0 and duration > 0 and fps > 0:
            total_frames = int(round(duration * fps))

        # Color and HDR
        color_space = video_stream.get("color_space", "bt709")
        color_primaries = video_stream.get("color_primaries", "bt709")
        color_transfer = video_stream.get("color_transfer", "bt709")
        is_hdr = any("smpte2084" in str(v).lower() or "arib-std-b67" in str(v).lower() or "bt2020" in str(v).lower()
                     for v in [color_space, color_primaries, color_transfer])

        # Aspect ratio
        dar = video_stream.get("display_aspect_ratio", f"{width}:{height}")
        bit_rate = int(format_info.get("bit_rate")) if format_info.get("bit_rate") else None
        
        # Timecode
        timecode = None
        tags = video_stream.get("tags", {})
        if "timecode" in tags:
            timecode = tags["timecode"]
        elif "timecode" in format_info.get("tags", {}):
            timecode = format_info["tags"]["timecode"]

        return cls(
            path=path_str,
            width=width,
            height=height,
            fps=fps,
            duration=duration,
            total_frames=total_frames,
            codec=codec,
            pixel_format=pix_fmt,
            bit_depth=bit_depth,
            color_space=color_space,
            color_primaries=color_primaries,
            color_transfer=color_transfer,
            is_hdr=is_hdr,
            aspect_ratio=dar,
            bit_rate=bit_rate,
            timecode=timecode,
            audio_streams=audio_streams,
            raw_streams=streams,
            raw_format=format_info
        )

    @classmethod
    def _fallback_probe(cls, path_str: str) -> VideoMetadata:
        """Fallback when external ffprobe is unavailable."""
        return cls(
            path=path_str,
            width=1920,
            height=1080,
            fps=30.0,
            duration=10.0,
            total_frames=300,
            codec="h264",
            pixel_format="yuv420p",
            bit_depth=8,
            color_space="bt709"
        )
