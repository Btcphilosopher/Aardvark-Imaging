"""
SLOWFRAME.PRO — Industrial Python Video Slow-Motion & Temporal Reconstruction Engine
"""

from slowframe.core.config import (
    SlowFrameConfig,
    QualityMode,
    InterpolationMethod,
    MotionBlurMode,
    ComputeBackendType,
    AudioMode,
    MotionCategory,
)
from slowframe.core.engine import SlowMotionEngine, SlowMotionResult
from slowframe.core.pipeline import SlowFramePipeline
from slowframe.core.timeline import Timeline, TimelineItem
from slowframe.video.frames import Frame, FrameMetadata, FrameSequence
from slowframe.video.metadata import VideoMetadata
from slowframe.quality.metrics import QualityAnalyzer, QualityReport

__version__ = "1.0.0"
__author__ = "SLOWFRAME Engine Team"

__all__ = [
    "SlowMotionEngine",
    "SlowMotionResult",
    "SlowFrameConfig",
    "SlowFramePipeline",
    "Timeline",
    "TimelineItem",
    "Frame",
    "FrameMetadata",
    "FrameSequence",
    "VideoMetadata",
    "QualityAnalyzer",
    "QualityReport",
    "QualityMode",
    "InterpolationMethod",
    "MotionBlurMode",
    "ComputeBackendType",
    "AudioMode",
    "MotionCategory",
]
