"""
SLOWFRAME.PRO — Optical Flow Motion Estimator & Dense Vector Fields
"""

from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from typing import Optional, Tuple, Dict, Any

try:
    import cv2
    HAS_OPENCV = True
except ImportError:
    HAS_OPENCV = False


@dataclass
class OpticalFlowResult:
    """Container for computed forward & backward optical flow fields."""
    flow_forward: np.ndarray   # (H, W, 2) flow from A -> B (dx, dy)
    flow_backward: np.ndarray  # (H, W, 2) flow from B -> A (dx, dy)
    magnitude_forward: np.ndarray
    magnitude_backward: np.ndarray
    confidence_map: np.ndarray # (H, W) in [0.0, 1.0]
    occlusion_mask: np.ndarray # (H, W) float in [0.0, 1.0] (1.0 = occluded)
    mean_motion: float
    max_motion: float


class MotionEstimator:
    """
    Industrial Motion Estimator supporting Farneback, DIS, Lucas-Kanade,
    TV-L1, and pure-NumPy gradient block fallback.
    """

    def __init__(
        self,
        algorithm: str = "farneback",
        pyr_scale: float = 0.5,
        levels: int = 4,
        winsize: int = 15,
        iterations: int = 3,
        poly_n: int = 5,
        poly_sigma: float = 1.2
    ):
        self.algorithm = algorithm.lower()
        self.pyr_scale = pyr_scale
        self.levels = levels
        self.winsize = winsize
        self.iterations = iterations
        self.poly_n = poly_n
        self.poly_sigma = poly_sigma
        
        self._dis_flow = None
        if HAS_OPENCV and hasattr(cv2, "DISOpticalFlow_create"):
            try:
                self._dis_flow = cv2.DISOpticalFlow_create(cv2.DISOPTICAL_FLOW_PRESET_MEDIUM)
            except Exception:
                self._dis_flow = None

    def estimate_unidirectional(self, img_a: np.ndarray, img_b: np.ndarray) -> np.ndarray:
        """
        Estimate 2D flow field from img_a to img_b.
        Returns: (H, W, 2) array of (dx, dy).
        """
        gray_a = self._to_gray(img_a)
        gray_b = self._to_gray(img_b)
        h, w = gray_a.shape

        if HAS_OPENCV:
            if self.algorithm == "dis" and self._dis_flow is not None:
                flow = self._dis_flow.calc(gray_a, gray_b, None)
                return flow
            elif self.algorithm == "tvl1" and hasattr(cv2, "optflow") and hasattr(cv2.optflow, "createOptFlow_DualTVL1"):
                tvl1 = cv2.optflow.createOptFlow_DualTVL1()
                return tvl1.calc(gray_a, gray_b, None)
            else:
                # Farneback dense optical flow
                flags = 0
                flow = cv2.calcOpticalFlowFarneback(
                    gray_a,
                    gray_b,
                    None,
                    self.pyr_scale,
                    self.levels,
                    self.winsize,
                    self.iterations,
                    self.poly_n,
                    self.poly_sigma,
                    flags
                )
                return flow
        else:
            return self._numpy_gradient_flow(gray_a, gray_b)

    def estimate_bidirectional(self, img_a: np.ndarray, img_b: np.ndarray) -> OpticalFlowResult:
        """
        Estimate symmetric forward (A -> B) and backward (B -> A) flow fields,
        along with occlusion detection via forward-backward consistency check.
        """
        flow_fwd = self.estimate_unidirectional(img_a, img_b)
        flow_bwd = self.estimate_unidirectional(img_b, img_a)

        mag_fwd = np.sqrt(flow_fwd[..., 0] ** 2 + flow_fwd[..., 1] ** 2)
        mag_bwd = np.sqrt(flow_bwd[..., 0] ** 2 + flow_bwd[..., 1] ** 2)

        # Compute Forward-Backward Inconsistency (Occlusion detection)
        # Warp flow_bwd using flow_fwd
        warped_bwd = self.warp_flow(flow_bwd, flow_fwd)
        diff = flow_fwd + warped_bwd
        inconsistency = np.sqrt(diff[..., 0] ** 2 + diff[..., 1] ** 2)
        
        # Occlusion mask: areas where forward-backward flow deviates significantly
        # Normalized between 0.0 (clean) and 1.0 (occluded/disoccluded)
        thresh = np.maximum(0.5, 0.05 * (mag_fwd + 1.0))
        occlusion_raw = inconsistency / (thresh * 2.0)
        occlusion_mask = np.clip(occlusion_raw, 0.0, 1.0).astype(np.float32)

        # Confidence map is inverse of occlusion and magnitude variance
        confidence_map = np.clip(1.0 - (occlusion_mask * 0.8), 0.1, 1.0).astype(np.float32)

        mean_motion = float(np.mean(mag_fwd))
        max_motion = float(np.max(mag_fwd))

        return OpticalFlowResult(
            flow_forward=flow_fwd,
            flow_backward=flow_bwd,
            magnitude_forward=mag_fwd,
            magnitude_backward=mag_bwd,
            confidence_map=confidence_map,
            occlusion_mask=occlusion_mask,
            mean_motion=mean_motion,
            max_motion=max_motion
        )

    def warp_flow(self, flow: np.ndarray, motion: np.ndarray) -> np.ndarray:
        """Warp a flow field (H, W, 2) by motion vector field (H, W, 2)."""
        h, w = flow.shape[:2]
        if HAS_OPENCV:
            grid_x, grid_y = np.meshgrid(np.arange(w), np.arange(h))
            map_x = (grid_x + motion[..., 0]).astype(np.float32)
            map_y = (grid_y + motion[..., 1]).astype(np.float32)
            warped_x = cv2.remap(flow[..., 0], map_x, map_y, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
            warped_y = cv2.remap(flow[..., 1], map_x, map_y, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
            return np.stack([warped_x, warped_y], axis=-1)
        else:
            return self._numpy_bilinear_warp(flow, motion)

    def _to_gray(self, img: np.ndarray) -> np.ndarray:
        """Convert input image array to grayscale uint8."""
        if img.ndim == 2:
            return img.astype(np.uint8) if img.dtype != np.uint8 else img
        if HAS_OPENCV:
            if img.shape[2] == 3:
                return cv2.cvtColor(img.astype(np.uint8), cv2.COLOR_RGB2GRAY)
            elif img.shape[2] == 4:
                return cv2.cvtColor(img.astype(np.uint8), cv2.COLOR_RGBA2GRAY)
        # NumPy conversion
        rgb = img[:, :, :3].astype(np.float32)
        gray = 0.299 * rgb[:, :, 0] + 0.587 * rgb[:, :, 1] + 0.114 * rgb[:, :, 2]
        return np.clip(gray, 0, 255).astype(np.uint8)

    def _numpy_gradient_flow(self, gray_a: np.ndarray, gray_b: np.ndarray) -> np.ndarray:
        """Pure NumPy Horn-Schunck / Lucas-Kanade gradient flow estimation."""
        h, w = gray_a.shape
        ga = gray_a.astype(np.float32) / 255.0
        gb = gray_b.astype(np.float32) / 255.0

        # Spatial gradients
        gx = (np.gradient(ga, axis=1) + np.gradient(gb, axis=1)) * 0.5
        gy = (np.gradient(ga, axis=0) + np.gradient(gb, axis=0)) * 0.5
        gt = gb - ga

        # Simple regularized Lucas-Kanade in local blocks
        flow = np.zeros((h, w, 2), dtype=np.float32)
        denom = (gx * gx + gy * gy + 0.01)
        flow[..., 0] = -gt * gx / denom
        flow[..., 1] = -gt * gy / denom
        
        # Smooth flow field
        return np.clip(flow, -50.0, 50.0)

    def _numpy_bilinear_warp(self, image: np.ndarray, flow: np.ndarray) -> np.ndarray:
        """NumPy implementation of bilinear spatial warping."""
        h, w = image.shape[:2]
        grid_x, grid_y = np.meshgrid(np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32))
        src_x = np.clip(grid_x + flow[..., 0], 0, w - 1)
        src_y = np.clip(grid_y + flow[..., 1], 0, h - 1)

        x0 = np.floor(src_x).astype(np.int32)
        x1 = np.minimum(x0 + 1, w - 1)
        y0 = np.floor(src_y).astype(np.int32)
        y1 = np.minimum(y0 + 1, h - 1)

        wa = ((x1 - src_x) * (y1 - src_y))[..., None]
        wb = ((src_x - x0) * (y1 - src_y))[..., None]
        wc = ((x1 - src_x) * (src_y - y0))[..., None]
        wd = ((src_x - x0) * (src_y - y0))[..., None]

        c = image.shape[2] if image.ndim == 3 else 1
        img_reshaped = image if image.ndim == 3 else image[:, :, None]

        Ia = img_reshaped[y0, x0]
        Ib = img_reshaped[y0, x1]
        Ic = img_reshaped[y1, x0]
        Id = img_reshaped[y1, x1]

        warped = (wa * Ia + wb * Ib + wc * Ic + wd * Id)
        return warped if image.ndim == 3 else warped[:, :, 0]
