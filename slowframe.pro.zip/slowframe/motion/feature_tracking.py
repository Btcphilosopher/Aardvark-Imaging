"""
SLOWFRAME.PRO — Feature Tracking & Sparse Trajectory Analysis
"""

from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from typing import List, Tuple, Optional

try:
    import cv2
    HAS_OPENCV = True
except ImportError:
    HAS_OPENCV = False


@dataclass
class TrackedFeature:
    id: int
    prev_pos: Tuple[float, float]
    curr_pos: Tuple[float, float]
    displacement: Tuple[float, float]
    velocity: float
    confidence: float


class FeatureTracker:
    """Tracks prominent Shi-Tomasi / Harris corner features using pyramidal Lucas-Kanade."""

    def __init__(
        self,
        max_corners: int = 400,
        quality_level: float = 0.01,
        min_distance: int = 10,
        block_size: int = 7
    ):
        self.max_corners = max_corners
        self.quality_level = quality_level
        self.min_distance = min_distance
        self.block_size = block_size

    def track(self, img_a: np.ndarray, img_b: np.ndarray) -> List[TrackedFeature]:
        """Track corners between Frame A and Frame B."""
        gray_a = self._to_gray(img_a)
        gray_b = self._to_gray(img_b)

        if not HAS_OPENCV:
            return self._fallback_track(gray_a, gray_b)

        # Detect corners on image A
        corners_a = cv2.goodFeaturesToTrack(
            gray_a,
            maxCorners=self.max_corners,
            qualityLevel=self.quality_level,
            minDistance=self.min_distance,
            blockSize=self.block_size
        )

        if corners_a is None or len(corners_a) == 0:
            return []

        # Pyramidal Lucas-Kanade
        corners_b, status, err = cv2.calcOpticalFlowPyrLK(
            gray_a,
            gray_b,
            corners_a,
            None,
            winSize=(21, 21),
            maxLevel=3,
            criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 30, 0.01)
        )

        tracked = []
        for i, (st, e) in enumerate(zip(status.ravel(), err.ravel())):
            if st == 1:
                xa, ya = corners_a[i][0]
                xb, yb = corners_b[i][0]
                dx = float(xb - xa)
                dy = float(yb - ya)
                vel = float(np.sqrt(dx**2 + dy**2))
                conf = float(np.clip(1.0 / (1.0 + e * 0.1), 0.0, 1.0))
                
                tracked.append(TrackedFeature(
                    id=i,
                    prev_pos=(float(xa), float(ya)),
                    curr_pos=(float(xb), float(yb)),
                    displacement=(dx, dy),
                    velocity=vel,
                    confidence=conf
                ))

        return tracked

    def _to_gray(self, img: np.ndarray) -> np.ndarray:
        if img.ndim == 2:
            return img
        if HAS_OPENCV:
            return cv2.cvtColor(img.astype(np.uint8), cv2.COLOR_RGB2GRAY)
        rgb = img[:, :, :3].astype(np.float32)
        return np.clip(0.299 * rgb[:, :, 0] + 0.587 * rgb[:, :, 1] + 0.114 * rgb[:, :, 2], 0, 255).astype(np.uint8)

    def _fallback_track(self, gray_a: np.ndarray, gray_b: np.ndarray) -> List[TrackedFeature]:
        """Simple grid feature displacement fallback."""
        h, w = gray_a.shape
        step = 32
        tracked = []
        idx = 0
        for y in range(step, h - step, step):
            for x in range(step, w - step, step):
                tracked.append(TrackedFeature(
                    id=idx,
                    prev_pos=(float(x), float(y)),
                    curr_pos=(float(x), float(y)),
                    displacement=(0.0, 0.0),
                    velocity=0.0,
                    confidence=1.0
                ))
                idx += 1
        return tracked
