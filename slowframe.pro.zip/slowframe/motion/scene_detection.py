"""
SLOWFRAME.PRO — Scene Cut, Fade & Global Camera Motion Analysis
"""

from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from typing import Optional, Tuple, List, Dict, Any

try:
    import cv2
    HAS_OPENCV = True
except ImportError:
    HAS_OPENCV = False


@dataclass
class CameraMotion:
    translation_x: float  # Pan (pixels)
    translation_y: float  # Tilt (pixels)
    rotation: float       # Roll in degrees
    scale: float          # Zoom factor (~1.0 = no zoom)
    shear: float
    is_handheld: bool
    confidence: float


@dataclass
class SceneBoundary:
    frame_index: int
    boundary_type: str  # "CUT", "FADE_IN", "FADE_OUT", "DISSOLVE"
    score: float
    prev_scene_id: int
    next_scene_id: int


class SceneDetector:
    """
    Detects scene transitions (hard cuts, fades, crossfades) to prevent
    the engine from interpolating across structural cuts, and computes
    global camera motion transformation (pan, tilt, zoom, rotation).
    """

    def __init__(
        self,
        cut_threshold: float = 30.0,
        fade_threshold: float = 12.0,
        min_scene_length: int = 4
    ):
        self.cut_threshold = cut_threshold
        self.fade_threshold = fade_threshold
        self.min_scene_length = min_scene_length
        self.current_scene_id = 0
        self.last_cut_frame = 0

    def is_scene_cut(self, img_a: np.ndarray, img_b: np.ndarray) -> Tuple[bool, float, str]:
        """
        Evaluate if there is a scene cut between Frame A and Frame B.
        Returns: (is_cut, diff_score, transition_type)
        """
        gray_a = self._to_gray(img_a)
        gray_b = self._to_gray(img_b)

        # 1. Color/Luminance Histogram Correlation
        if HAS_OPENCV:
            hist_a = cv2.calcHist([gray_a], [0], None, [32], [0, 256])
            hist_b = cv2.calcHist([gray_b], [0], None, [32], [0, 256])
            cv2.normalize(hist_a, hist_a, 0, 1, cv2.NORM_MINMAX)
            cv2.normalize(hist_b, hist_b, 0, 1, cv2.NORM_MINMAX)
            hist_corr = cv2.compareHist(hist_a, hist_b, cv2.HISTCMP_CORREL)
        else:
            ha, _ = np.histogram(gray_a, bins=32, range=(0, 256), density=True)
            hb, _ = np.histogram(gray_b, bins=32, range=(0, 256), density=True)
            hist_corr = np.corrcoef(ha, hb)[0, 1] if (np.std(ha) > 1e-5 and np.std(hb) > 1e-5) else 1.0

        # 2. Mean Absolute Pixel Difference (MAD in color space)
        if img_a.ndim == 3 and img_b.ndim == 3:
            diff_color = np.abs(img_a.astype(np.float32) - img_b.astype(np.float32))
            mad = float(np.mean(diff_color))
        else:
            diff = np.abs(gray_a.astype(np.float32) - gray_b.astype(np.float32))
            mad = float(np.mean(diff))

        # 3. Luminance level check (fades)
        mean_a = float(np.mean(gray_a))
        mean_b = float(np.mean(gray_b))

        # Hard Cut: high pixel difference OR (moderate difference and low histogram correlation)
        if mad > self.cut_threshold and (hist_corr < 0.70 or mad > self.cut_threshold * 1.3):
            return True, mad, "CUT"

        # Fade to / from black
        if mean_a < 3.0 and mean_b > 15.0:
            return True, mad, "FADE_IN"
        elif mean_a > 15.0 and mean_b < 3.0:
            return True, mad, "FADE_OUT"

        return False, mad, "NONE"

    def estimate_camera_motion(self, img_a: np.ndarray, img_b: np.ndarray) -> CameraMotion:
        """
        Estimate global affine / homography transformation representing
        camera pan, tilt, rotation, and zoom.
        """
        gray_a = self._to_gray(img_a)
        gray_b = self._to_gray(img_b)

        if not HAS_OPENCV:
            return CameraMotion(0.0, 0.0, 0.0, 1.0, 0.0, False, 1.0)

        # Detect features
        pts_a = cv2.goodFeaturesToTrack(gray_a, maxCorners=200, qualityLevel=0.01, minDistance=15)
        if pts_a is None or len(pts_a) < 10:
            return CameraMotion(0.0, 0.0, 0.0, 1.0, 0.0, False, 0.0)

        pts_b, status, _ = cv2.calcOpticalFlowPyrLK(gray_a, gray_b, pts_a, None)
        good_a = pts_a[status == 1]
        good_b = pts_b[status == 1]

        if len(good_a) < 6:
            return CameraMotion(0.0, 0.0, 0.0, 1.0, 0.0, False, 0.0)

        # Estimate robust affine transform with RANSAC
        matrix, inliers = cv2.estimateAffinePartial2D(good_a, good_b, method=cv2.RANSAC)
        if matrix is None:
            return CameraMotion(0.0, 0.0, 0.0, 1.0, 0.0, False, 0.0)

        tx = float(matrix[0, 2])
        ty = float(matrix[1, 2])
        a = matrix[0, 0]
        b = matrix[0, 1]
        
        scale = float(np.sqrt(a**2 + b**2))
        rotation = float(np.arctan2(b, a) * 180.0 / np.pi)
        
        confidence = float(np.sum(inliers)) / float(len(good_a)) if inliers is not None else 0.5
        is_handheld = (abs(rotation) > 0.1) or (abs(tx) > 0.5 and abs(ty) > 0.5)

        return CameraMotion(
            translation_x=tx,
            translation_y=ty,
            rotation=rotation,
            scale=scale,
            shear=0.0,
            is_handheld=is_handheld,
            confidence=confidence
        )

    def _to_gray(self, img: np.ndarray) -> np.ndarray:
        if img.ndim == 2:
            return img
        if HAS_OPENCV:
            return cv2.cvtColor(img.astype(np.uint8), cv2.COLOR_RGB2GRAY)
        rgb = img[:, :, :3].astype(np.float32)
        return np.clip(0.299 * rgb[:, :, 0] + 0.587 * rgb[:, :, 1] + 0.114 * rgb[:, :, 2], 0, 255).astype(np.uint8)
