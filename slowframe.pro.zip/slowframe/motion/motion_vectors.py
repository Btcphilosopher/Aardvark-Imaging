"""
SLOWFRAME.PRO — Motion Vectors, Flow Field Visualizer & Grid Analysis
"""

from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from typing import Optional, Tuple

try:
    import cv2
    HAS_OPENCV = True
except ImportError:
    HAS_OPENCV = False


@dataclass
class MotionVectorGrid:
    """Sub-sampled motion vector grid for visualization and hardware estimation."""
    grid_x: np.ndarray  # X coordinates of vector origins
    grid_y: np.ndarray  # Y coordinates of vector origins
    vx: np.ndarray      # Horizontal displacement in pixels
    vy: np.ndarray      # Vertical displacement in pixels
    magnitude: np.ndarray
    angle: np.ndarray   # In radians [-pi, pi]
    step: int


class MotionVectorEngine:
    """Generates motion vector grids, heatmaps, and HSV color-wheel representations."""

    @staticmethod
    def extract_grid(flow: np.ndarray, step: int = 16) -> MotionVectorGrid:
        """Sub-sample dense flow (H, W, 2) into regular vector grid."""
        h, w = flow.shape[:2]
        y, x = np.mgrid[step//2:h:step, step//2:w:step]
        
        vx = flow[y, x, 0]
        vy = flow[y, x, 1]
        
        magnitude = np.sqrt(vx**2 + vy**2)
        angle = np.arctan2(vy, vx)
        
        return MotionVectorGrid(
            grid_x=x,
            grid_y=y,
            vx=vx,
            vy=vy,
            magnitude=magnitude,
            angle=angle,
            step=step
        )

    @staticmethod
    def flow_to_hsv_rgb(flow: np.ndarray, max_speed: Optional[float] = None) -> np.ndarray:
        """
        Convert dense optical flow (H, W, 2) to standard Middlebury HSV colormap RGB image.
        Hue = direction of motion, Saturation = 1.0, Value = normalized magnitude.
        """
        h, w = flow.shape[:2]
        fx, fy = flow[..., 0], flow[..., 1]
        mag = np.sqrt(fx**2 + fy**2)
        ang = np.arctan2(fy, fx) + np.pi  # [0, 2*pi]

        if max_speed is None:
            max_speed = float(np.percentile(mag, 99))
            if max_speed < 1.0:
                max_speed = 1.0

        # Normalization
        norm_mag = np.clip(mag / max_speed, 0.0, 1.0)
        
        if HAS_OPENCV:
            hsv = np.zeros((h, w, 3), dtype=np.uint8)
            hsv[..., 0] = (ang * 180 / np.pi / 2).astype(np.uint8)  # OpenCV hue is 0-180
            hsv[..., 1] = 255
            hsv[..., 2] = (norm_mag * 255).astype(np.uint8)
            rgb = cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)
            return rgb
        else:
            # Pure numpy HSV to RGB conversion
            h_norm = ang / (2 * np.pi) * 6.0
            i = np.floor(h_norm).astype(np.int32) % 6
            f = h_norm - np.floor(h_norm)
            v = norm_mag
            p = 0.0
            q = v * (1.0 - f)
            t = v * f

            r = np.zeros((h, w), dtype=np.float32)
            g = np.zeros((h, w), dtype=np.float32)
            b = np.zeros((h, w), dtype=np.float32)

            r[i == 0] = v[i == 0]; g[i == 0] = t[i == 0]; b[i == 0] = p
            r[i == 1] = q[i == 1]; g[i == 1] = v[i == 1]; b[i == 1] = p
            r[i == 2] = p;         g[i == 2] = v[i == 2]; b[i == 2] = t[i == 2]
            r[i == 3] = p;         g[i == 3] = q[i == 3]; b[i == 3] = v[i == 3]
            r[i == 4] = t[i == 4]; g[i == 4] = p;         b[i == 4] = v[i == 4]
            r[i == 5] = v[i == 5]; g[i == 5] = p;         b[i == 5] = q[i == 5]

            rgb = np.stack([r, g, b], axis=-1)
            return np.clip(rgb * 255.0, 0, 255).astype(np.uint8)
