"""
SLOWFRAME.PRO — Configuration & Enums
"""

from __future__ import annotations
import json
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Optional, Dict, Any


class QualityMode(str, Enum):
    FAST = "fast"          # OpenCV DIS/Farneback optical flow, low iterations
    BALANCED = "balanced"  # Bidirectional optical flow + occlusion mask
    QUALITY = "quality"    # Enhanced bidirectional flow + temporal refinement
    CINEMA = "cinema"      # AI interpolation (or high-density bidirectional flow) + temporal consistency
    ULTRA = "ultra"        # High-precision bidirectional flow / AI + super-resolution + artifact analysis


class InterpolationMethod(str, Enum):
    NEAREST = "nearest"
    LINEAR = "linear"
    CROSSFADE = "crossfade"
    OPTICAL_FLOW = "optical-flow"
    BIDIRECTIONAL = "bidirectional"
    AI = "ai"


class MotionBlurMode(str, Enum):
    NONE = "none"
    NATURAL = "natural"      # 180° shutter angle
    CINEMATIC = "cinematic"  # 180° shutter with exponential falloff
    PHYSICAL = "physical"    # Configurable shutter angle and samples
    CUSTOM = "custom"


class ComputeBackendType(str, Enum):
    CPU = "cpu"
    CUDA = "cuda"
    METAL = "metal"          # Apple Silicon MPS / Metal
    OPENCL = "opencl"
    AUTO = "auto"


class AudioMode(str, Enum):
    PRESERVE = "preserve"          # Keep original audio unchanged in duration
    TIME_STRETCH = "time_stretch"  # Stretch audio to match video duration with pitch correction
    PITCH_CORRECT = "pitch_correct"
    MUTE = "mute"                  # Remove audio
    REPLACE = "replace"            # Replace audio with external file


class MotionCategory(str, Enum):
    STATIC = "STATIC"
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    EXTREME = "EXTREME"


@dataclass
class SlowFrameConfig:
    """Configuration container for SLOWFRAME.PRO processing jobs."""

    slow_factor: float = 4.0
    input_fps: Optional[float] = None
    output_fps: Optional[float] = None
    interpolation_method: InterpolationMethod = InterpolationMethod.BIDIRECTIONAL
    quality_mode: QualityMode = QualityMode.BALANCED
    
    # Motion analysis
    optical_flow_algorithm: str = "farneback"  # "farneback", "dis", "tvl1", "deepflow"
    scene_detection: bool = True
    scene_threshold: float = 28.0
    
    # Occlusion & Temporal
    occlusion_detection: bool = True
    occlusion_threshold: float = 1.2
    temporal_refinement: bool = True
    temporal_window: int = 3
    temporal_smoothing_factor: float = 0.35
    artifact_detection: bool = True
    artifact_threshold: float = 0.15
    
    # Motion blur
    motion_blur: MotionBlurMode = MotionBlurMode.NONE
    shutter_angle: float = 180.0  # Degrees (0 to 360)
    exposure_time: float = 0.5
    motion_blur_strength: float = 1.0
    temporal_samples: int = 8
    
    # Super-resolution & 8K/4K Tiling
    super_resolution: bool = False
    upscale_factor: float = 2.0
    target_width: Optional[int] = None
    target_height: Optional[int] = None
    
    tile_size: int = 1024
    tile_overlap: int = 64
    worker_count: int = 4
    gpu_memory_limit_mb: int = 4096
    hardware_backend: ComputeBackendType = ComputeBackendType.AUTO
    
    # Audio
    audio_mode: AudioMode = AudioMode.TIME_STRETCH
    audio_pitch_shift: bool = True
    
    # Encoding options
    output_codec: str = "h264"  # "h264", "hevc", "prores", "av1"
    crf: int = 18
    preset: str = "medium"
    pixel_format: str = "yuv420p"  # "yuv420p", "yuv422p10le", "yuv444p10le"
    preserve_hdr: bool = True
    
    # Checkpoint & Job control
    job_id: Optional[str] = None
    checkpoint_interval: int = 50
    resume: bool = False
    
    # Custom extra metadata
    custom_options: Dict[str, Any] = field(default_factory=dict)

    def validate(self) -> None:
        """Validate configuration settings and adjust dependencies."""
        if self.slow_factor <= 0:
            raise ValueError(f"Slowdown factor must be > 0, got {self.slow_factor}")
        if self.shutter_angle < 0 or self.shutter_angle > 360:
            raise ValueError(f"Shutter angle must be between 0 and 360, got {self.shutter_angle}")
        if self.tile_size < 128:
            raise ValueError(f"Tile size must be at least 128, got {self.tile_size}")
            
        # Warn or flag extreme slow motion
        if self.slow_factor >= 16.0:
            self.custom_options["extreme_slow_motion"] = True

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        data = asdict(self)
        # Convert enums to string values
        data["interpolation_method"] = self.interpolation_method.value
        data["quality_mode"] = self.quality_mode.value
        data["motion_blur"] = self.motion_blur.value
        data["hardware_backend"] = self.hardware_backend.value
        data["audio_mode"] = self.audio_mode.value
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> SlowFrameConfig:
        """Instantiate configuration from dictionary."""
        cfg_data = data.copy()
        if "interpolation_method" in cfg_data:
            cfg_data["interpolation_method"] = InterpolationMethod(cfg_data["interpolation_method"])
        if "quality_mode" in cfg_data:
            cfg_data["quality_mode"] = QualityMode(cfg_data["quality_mode"])
        if "motion_blur" in cfg_data:
            cfg_data["motion_blur"] = MotionBlurMode(cfg_data["motion_blur"])
        if "hardware_backend" in cfg_data:
            cfg_data["hardware_backend"] = ComputeBackendType(cfg_data["hardware_backend"])
        if "audio_mode" in cfg_data:
            cfg_data["audio_mode"] = AudioMode(cfg_data["audio_mode"])
        return cls(**cfg_data)

    def to_json(self, indent: int = 2) -> str:
        """Serialize configuration to JSON string."""
        return json.dumps(self.to_dict(), indent=indent)

    @classmethod
    def from_json(cls, json_str: str) -> SlowFrameConfig:
        """Load configuration from JSON string."""
        return cls.from_dict(json.loads(json_str))
