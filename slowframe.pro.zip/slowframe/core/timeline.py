"""
SLOWFRAME.PRO — Timeline Engine & Exact PTS Temporal Synthesis
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import List, Iterator, Tuple, Optional


@dataclass
class TimelineItem:
    """Represents a discrete moment on the output timeline."""
    output_index: int
    output_timestamp: float  # In seconds
    output_pts: int
    source_index_a: int
    source_index_b: int
    t: float  # Interpolation factor 0.0 (frame A) to 1.0 (frame B)
    is_source: bool  # True if this is an exact source frame (t == 0.0 or t == 1.0)
    scene_boundary: bool = False


class Timeline:
    """
    Computes exact fractional timestamps and reconstructs intermediate time-points
    for any slow-motion factor (1.25x, 1.5x, 2x, 4x, 8x, 16x, 32x, etc.).
    
    Example for 4x slow motion with 30 FPS source:
    Source: 30 FPS, delta = 1/30 = 0.033333s
    Output: 120 FPS timeline, delta = 1/120 = 0.008333s
    Between F0 (t=0) and F1 (t=1):
      - output frame 0: F0 (t = 0.0)
      - output frame 1: I1 (t = 0.25)
      - output frame 2: I2 (t = 0.50)
      - output frame 3: I3 (t = 0.75)
      - output frame 4: F1 (t = 0.0 relative to next pair or 1.0)
    """

    def __init__(
        self,
        source_frame_count: int,
        source_fps: float,
        slow_factor: float = 4.0,
        target_fps: Optional[float] = None,
        timebase: int = 1000000  # Microseconds
    ):
        if source_frame_count < 1:
            raise ValueError(f"Source frame count must be >= 1, got {source_frame_count}")
        if source_fps <= 0:
            raise ValueError(f"Source FPS must be > 0, got {source_fps}")
        if slow_factor <= 0:
            raise ValueError(f"Slow factor must be > 0, got {slow_factor}")

        self.source_frame_count = source_frame_count
        self.source_fps = source_fps
        self.slow_factor = slow_factor
        
        # Output FPS is either specified or computed as source_fps * slow_factor
        # Note: In temporal reconstruction mode:
        # Output timeline generates `slow_factor` times as many frames.
        # If played back at source_fps, duration is multiplied by slow_factor.
        # If played back at output_fps, it is real-time high-frame-rate (HFR).
        self.output_fps = target_fps if target_fps is not None else (source_fps * slow_factor)
        self.timebase = timebase
        
        # Calculate total output frames
        # For N source frames, there are (N - 1) intervals, each producing `slow_factor` frames,
        # plus the final frame.
        if source_frame_count == 1:
            self.total_output_frames = 1
        else:
            self.total_output_frames = int(round((source_frame_count - 1) * slow_factor)) + 1

        self.source_duration = (source_frame_count - 1) / source_fps if source_frame_count > 1 else 0.0
        self.reconstructed_duration = (self.total_output_frames - 1) / self.source_fps if self.total_output_frames > 1 else 0.0

    def get_schedule(self) -> List[TimelineItem]:
        """Generate complete timeline schedule items."""
        return list(self.iter_schedule())

    def iter_schedule(self) -> Iterator[TimelineItem]:
        """Yield timeline items sequentially."""
        if self.source_frame_count == 1:
            yield TimelineItem(
                output_index=0,
                output_timestamp=0.0,
                output_pts=0,
                source_index_a=0,
                source_index_b=0,
                t=0.0,
                is_source=True
            )
            return

        dt_out = 1.0 / (self.source_fps * self.slow_factor)
        
        for out_idx in range(self.total_output_frames):
            # Output timestamp in virtual source timeline
            t_virtual = out_idx * dt_out
            # Corresponding fractional source frame index
            src_pos = out_idx / float(self.slow_factor)
            
            src_a = int(src_pos)
            src_b = min(src_a + 1, self.source_frame_count - 1)
            
            t_interp = src_pos - src_a
            
            # Boundary fix: if we're at the very end
            if src_a >= self.source_frame_count - 1:
                src_a = self.source_frame_count - 1
                src_b = self.source_frame_count - 1
                t_interp = 0.0
                is_src = True
            else:
                is_src = (abs(t_interp) < 1e-7) or (abs(t_interp - 1.0) < 1e-7)

            pts = int(round(t_virtual * self.timebase))
            
            yield TimelineItem(
                output_index=out_idx,
                output_timestamp=t_virtual,
                output_pts=pts,
                source_index_a=src_a,
                source_index_b=src_b,
                t=float(t_interp),
                is_source=is_src
            )

    def get_intermediate_count_per_interval(self) -> int:
        """Return number of synthesized frames between each source pair for integer factors."""
        if self.slow_factor.is_integer():
            return int(self.slow_factor) - 1
        return int(self.slow_factor)
