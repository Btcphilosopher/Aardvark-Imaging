"""
SLOWFRAME.PRO — Programmable Modular Processing Pipeline
"""

from __future__ import annotations
import numpy as np
from pathlib import Path
from typing import Optional, List, Dict, Any, Callable

from slowframe.core.config import SlowFrameConfig, InterpolationMethod, MotionBlurMode
from slowframe.video.metadata import VideoMetadata
from slowframe.video.decoder import VideoDecoder
from slowframe.video.encoder import VideoEncoder
from slowframe.video.frames import Frame
from slowframe.motion.optical_flow import MotionEstimator
from slowframe.motion.scene_detection import SceneDetector
from slowframe.interpolation.bidirectional import BidirectionalFlowInterpolator
from slowframe.temporal.consistency import TemporalConsistencyEngine
from slowframe.temporal.artifact_detection import ArtifactDetector
from slowframe.effects.motion_blur import MotionBlurEngine
from slowframe.upscale.super_resolution import SuperResolutionEngine
from slowframe.quality.metrics import QualityAnalyzer, QualityReport


class SlowFramePipeline:
    """
    Programmable Pipeline builder for custom slow-motion synthesis graphs.
    """

    def __init__(self, config: Optional[SlowFrameConfig] = None):
        self.config = config or SlowFrameConfig()
        self._input_path: Optional[str] = None
        self._output_path: Optional[str] = None
        
        # Stages
        self.motion_estimator = MotionEstimator(algorithm=self.config.optical_flow_algorithm)
        self.scene_detector = SceneDetector(cut_threshold=self.config.scene_threshold)
        self.interpolator = BidirectionalFlowInterpolator(self.motion_estimator)
        self.temporal_engine = TemporalConsistencyEngine(
            smoothing_factor=self.config.temporal_smoothing_factor
        )
        self.artifact_detector = ArtifactDetector()
        self.blur_engine = MotionBlurEngine(
            mode=self.config.motion_blur,
            shutter_angle=self.config.shutter_angle
        )
        self.super_res_engine = SuperResolutionEngine(scale_factor=self.config.upscale_factor)
        self.quality_analyzer = QualityAnalyzer()

    def decode(self, input_path: str | Path) -> SlowFramePipeline:
        self._input_path = str(input_path)
        return self

    def detect_scenes(self, threshold: float = 28.0) -> SlowFramePipeline:
        self.config.scene_detection = True
        self.config.scene_threshold = threshold
        self.scene_detector = SceneDetector(cut_threshold=threshold)
        return self

    def analyse_motion(self, method: str = "farneback") -> SlowFramePipeline:
        self.config.optical_flow_algorithm = method
        self.motion_estimator = MotionEstimator(algorithm=method)
        self.interpolator = BidirectionalFlowInterpolator(self.motion_estimator)
        return self

    def estimate_flow(self) -> SlowFramePipeline:
        return self

    def analyse_occlusions(self) -> SlowFramePipeline:
        self.config.occlusion_detection = True
        return self

    def interpolate(self, factor: float = 4.0, method: str = "bidirectional") -> SlowFramePipeline:
        self.config.slow_factor = factor
        self.config.interpolation_method = InterpolationMethod(method)
        return self

    def refine_temporal(self) -> SlowFramePipeline:
        self.config.temporal_refinement = True
        return self

    def apply_motion_blur(self, shutter_angle: float = 180.0, mode: str = "cinematic") -> SlowFramePipeline:
        self.config.motion_blur = MotionBlurMode(mode)
        self.config.shutter_angle = shutter_angle
        self.blur_engine = MotionBlurEngine(mode=self.config.motion_blur, shutter_angle=shutter_angle)
        return self

    def upscale(self, factor: float = 2.0) -> SlowFramePipeline:
        self.config.super_resolution = True
        self.config.upscale_factor = factor
        self.super_res_engine = SuperResolutionEngine(scale_factor=factor)
        return self

    def encode(self, output_path: str | Path) -> SlowFramePipeline:
        self._output_path = str(output_path)
        return self

    def execute(self) -> Any:
        """Run the configured pipeline via SlowMotionEngine."""
        if not self._input_path:
            raise ValueError("Pipeline decode() input path not specified")
        if not self._output_path:
            raise ValueError("Pipeline encode() output path not specified")

        from slowframe.core.engine import SlowMotionEngine
        engine = SlowMotionEngine(self.config)
        return engine.process(
            input=self._input_path,
            output=self._output_path
        )
