"""
SLOWFRAME.PRO — Core Engine & Configuration Subsystem
"""

from slowframe.core.config import (
    SlowFrameConfig,
    QualityMode,
    InterpolationMethod,
    MotionBlurMode,
    ComputeBackendType,
    AudioMode,
    MotionCategory,
)
from slowframe.core.timeline import Timeline, TimelineItem
from slowframe.core.pipeline import SlowFramePipeline
from slowframe.core.engine import SlowMotionEngine, SlowMotionResult, ProgressInfo, VideoAnalysisResult

__all__ = [
    "SlowFrameConfig",
    "QualityMode",
    "InterpolationMethod",
    "MotionBlurMode",
    "ComputeBackendType",
    "AudioMode",
    "MotionCategory",
    "Timeline",
    "TimelineItem",
    "SlowFramePipeline",
    "SlowMotionEngine",
    "SlowMotionResult",
    "ProgressInfo",
    "VideoAnalysisResult",
]
