"""
SLOWFRAME.PRO — Unified Industrial Slow-Motion Engine & Job Runner
"""

from __future__ import annotations
import os
import time
import json
import hashlib
import numpy as np
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Callable, Dict, Any, List

from slowframe.core.config import (
    SlowFrameConfig,
    QualityMode,
    InterpolationMethod,
    MotionBlurMode,
    ComputeBackendType,
    AudioMode,
)
from slowframe.core.timeline import Timeline
from slowframe.video.metadata import VideoMetadata
from slowframe.video.decoder import VideoDecoder
from slowframe.video.encoder import VideoEncoder
from slowframe.video.frames import Frame, FrameMetadata
from slowframe.motion.optical_flow import MotionEstimator, OpticalFlowResult
from slowframe.motion.scene_detection import SceneDetector
from slowframe.interpolation.linear import LinearInterpolator
from slowframe.interpolation.optical_flow import UnidirectionalFlowInterpolator
from slowframe.interpolation.bidirectional import BidirectionalFlowInterpolator
from slowframe.interpolation.ai_interpolator import AIPluginRegistry
from slowframe.temporal.consistency import TemporalConsistencyEngine
from slowframe.temporal.artifact_detection import ArtifactDetector
from slowframe.effects.motion_blur import MotionBlurEngine
from slowframe.upscale.super_resolution import SuperResolutionEngine
from slowframe.quality.metrics import QualityAnalyzer, QualityReport


@dataclass
class ProgressInfo:
    frame_current: int
    frame_total: int
    percent: float
    fps_processing: float
    eta_seconds: float
    current_stage: str
    confidence: float
    scene_id: int
    status_message: str


@dataclass
class SlowMotionResult:
    input_path: str
    output_path: str
    input_fps: float
    output_fps: float
    slow_factor: float
    frames_generated: int
    source_frames: int
    duration: float
    quality_score: float     # Temporal consistency [0.0, 1.0]
    artifact_score: float    # Artifact probability [0.0, 1.0]
    mean_confidence: float   # [0.0, 1.0]
    quality_report: Optional[QualityReport] = None
    processing_time_sec: float = 0.0
    checkpoint_id: Optional[str] = None


@dataclass
class VideoAnalysisResult:
    resolution: str
    width: int
    height: int
    fps: float
    duration: str
    duration_sec: float
    total_frames: int
    motion_complexity: str
    mean_motion_speed: float
    scene_cuts_count: int
    camera_motion_type: str
    interpolation_difficulty: str
    recommended_factor: float
    recommended_method: str
    recommended_quality: str
    notes: List[str] = field(default_factory=list)


class SlowMotionEngine:
    """
    Industrial-Grade Temporal Reconstruction & Slow-Motion Video Engine.
    """

    def __init__(self, config: Optional[SlowFrameConfig] = None):
        self.config = config or SlowFrameConfig()
        self.config.validate()

        # Subsystems
        self.motion_estimator = MotionEstimator(algorithm=self.config.optical_flow_algorithm)
        self.scene_detector = SceneDetector(cut_threshold=self.config.scene_threshold)
        self.linear_interpolator = LinearInterpolator()
        self.uni_interpolator = UnidirectionalFlowInterpolator(self.motion_estimator)
        self.bidi_interpolator = BidirectionalFlowInterpolator(self.motion_estimator)
        self.ai_registry = AIPluginRegistry()
        self.temporal_engine = TemporalConsistencyEngine(
            smoothing_factor=self.config.temporal_smoothing_factor
        )
        self.artifact_detector = ArtifactDetector()
        self.blur_engine = MotionBlurEngine(
            mode=self.config.motion_blur,
            shutter_angle=self.config.shutter_angle,
            samples=self.config.temporal_samples
        )
        self.super_res_engine = SuperResolutionEngine(scale_factor=self.config.upscale_factor)
        self.quality_analyzer = QualityAnalyzer()

    def process(
        self,
        input: str | Path,
        output: str | Path,
        slow_factor: Optional[float] = None,
        method: Optional[str] = None,
        quality: Optional[str] = None,
        motion_blur: Optional[str] = None,
        progress_callback: Optional[Callable[[ProgressInfo], None]] = None,
        max_source_frames: Optional[int] = None
    ) -> SlowMotionResult:
        """
        Execute full slow-motion temporal reconstruction pipeline.
        """
        start_time = time.time()
        input_path = str(input)
        output_path = str(output)

        if slow_factor is not None:
            self.config.slow_factor = float(slow_factor)
        if method is not None:
            self.config.interpolation_method = InterpolationMethod(method)
        if quality is not None:
            self.config.quality_mode = QualityMode(quality)
        if motion_blur is not None:
            self.config.motion_blur = MotionBlurMode(motion_blur)

        self.config.validate()

        # Step 1: Probe input metadata
        metadata = VideoMetadata.from_file(input_path)
        total_src = metadata.total_frames
        if max_source_frames is not None:
            total_src = min(total_src, max_source_frames)

        if total_src < 2:
            total_src = max(2, total_src)

        # Step 2: Initialize Timeline
        timeline = Timeline(
            source_frame_count=total_src,
            source_fps=metadata.fps,
            slow_factor=self.config.slow_factor,
            target_fps=self.config.output_fps
        )
        total_output_frames = timeline.total_output_frames

        # Configure output dimensions
        out_w = metadata.width
        out_h = metadata.height
        if self.config.super_resolution:
            out_w = int(round(out_w * self.config.upscale_factor))
            out_h = int(round(out_h * self.config.upscale_factor))

        # Step 3: Initialize Video Decoder & Encoder
        decoder = VideoDecoder(input_path)
        encoder = VideoEncoder(
            output_path=output_path,
            width=out_w,
            height=out_h,
            fps=timeline.output_fps,
            config=self.config,
            source_metadata=metadata
        )

        encoder.open()

        # Streaming buffer state
        frame_generator = decoder.stream_frames(max_frames=total_src)
        
        # Preload first frame
        try:
            curr_src_a = next(frame_generator)
        except StopIteration:
            raise RuntimeError(f"Could not read any frames from {input_path}")

        curr_src_b: Optional[Frame] = None
        src_cache: Dict[int, Frame] = {curr_src_a.index: curr_src_a}
        
        flow_cache: Optional[OpticalFlowResult] = None
        last_pair_key = (-1, -1)

        recent_outputs: List[np.ndarray] = []
        confidence_history: List[float] = []
        artifact_history: List[float] = []
        sample_frames_for_metrics: List[np.ndarray] = []

        current_scene_id = 0
        frames_written = 0

        schedule = timeline.get_schedule()

        for item in schedule:
            # Check if we need to advance the source decoder
            target_b_idx = item.source_index_b
            
            while target_b_idx not in src_cache:
                try:
                    next_src = next(frame_generator)
                    src_cache[next_src.index] = next_src
                except StopIteration:
                    # Edge boundary repeat
                    if src_cache:
                        max_avail = max(src_cache.keys())
                        src_cache[target_b_idx] = src_cache[max_avail]
                    break

            frame_a = src_cache.get(item.source_index_a, curr_src_a)
            frame_b = src_cache.get(item.source_index_b, frame_a)

            # Cleanup older cache to avoid RAM bloat
            min_needed = min(item.source_index_a, item.source_index_b)
            for old_idx in list(src_cache.keys()):
                if old_idx < min_needed - 2:
                    del src_cache[old_idx]

            # Process interpolation
            img_a = frame_a.data
            img_b = frame_b.data
            t = item.t

            # Scene Cut check
            pair_key = (frame_a.index, frame_b.index)
            is_cut = False
            if self.config.scene_detection and pair_key[0] != pair_key[1]:
                is_cut, cut_score, _ = self.scene_detector.is_scene_cut(img_a, img_b)
                if is_cut:
                    current_scene_id += 1

            if is_cut or item.is_source:
                # Direct frame
                if t < 0.5:
                    rendered_img = img_a.copy()
                else:
                    rendered_img = img_b.copy()
                conf = 1.0
                art_prob = 0.0
                occ_mask = np.zeros((img_a.shape[0], img_a.shape[1]), dtype=np.float32)
                flow_field = np.zeros((img_a.shape[0], img_a.shape[1], 2), dtype=np.float32)
            else:
                # Compute flow if new pair
                if pair_key != last_pair_key:
                    flow_cache = self.motion_estimator.estimate_bidirectional(img_a, img_b)
                    last_pair_key = pair_key

                # Interpolate based on method
                if self.config.interpolation_method == InterpolationMethod.BIDIRECTIONAL:
                    res = self.bidi_interpolator.interpolate(img_a, img_b, t, flow_cache)
                    rendered_img = res.image
                    conf = res.confidence
                    occ_mask = res.occlusion_mask
                    flow_field = flow_cache.flow_forward if flow_cache else np.zeros((img_a.shape[0], img_a.shape[1], 2), dtype=np.float32)
                elif self.config.interpolation_method == InterpolationMethod.AI:
                    ai_plugin = self.ai_registry.get_plugin("rife")
                    res = ai_plugin.interpolate(img_a, img_b, t)
                    rendered_img = res.image
                    conf = res.confidence
                    occ_mask = res.occlusion_mask
                    flow_field = flow_cache.flow_forward if flow_cache else np.zeros((img_a.shape[0], img_a.shape[1], 2), dtype=np.float32)
                elif self.config.interpolation_method == InterpolationMethod.OPTICAL_FLOW:
                    rendered_img = self.uni_interpolator.interpolate(img_a, img_b, t)
                    conf = 0.88
                    occ_mask = np.zeros((img_a.shape[0], img_a.shape[1]), dtype=np.float32)
                    flow_field = np.zeros((img_a.shape[0], img_a.shape[1], 2), dtype=np.float32)
                elif self.config.interpolation_method == InterpolationMethod.CROSSFADE:
                    rendered_img = self.linear_interpolator.interpolate_crossfade(img_a, img_b, t)
                    conf = 0.70
                    occ_mask = np.zeros((img_a.shape[0], img_a.shape[1]), dtype=np.float32)
                    flow_field = np.zeros((img_a.shape[0], img_a.shape[1], 2), dtype=np.float32)
                else:
                    rendered_img = self.linear_interpolator.interpolate_nearest(img_a, img_b, t)
                    conf = 0.60
                    occ_mask = np.zeros((img_a.shape[0], img_a.shape[1]), dtype=np.float32)
                    flow_field = np.zeros((img_a.shape[0], img_a.shape[1], 2), dtype=np.float32)

                # Temporal Refinement
                if self.config.temporal_refinement and recent_outputs:
                    prev_out = recent_outputs[-1]
                    rendered_img = self.temporal_engine.refine_frame(
                        rendered_img,
                        prev_frame=prev_out,
                        confidence=conf
                    )

                # Artifact Analysis
                if self.config.artifact_detection:
                    art_report = self.artifact_detector.analyze(
                        rendered_img, img_a, img_b, t,
                        occlusion_mask=occ_mask,
                        frame_index=item.output_index
                    )
                    art_prob = art_report.artifact_probability
                    conf = art_report.confidence_score
                else:
                    art_prob = 0.02

                # Motion blur synthesis
                if self.config.motion_blur != MotionBlurMode.NONE:
                    rendered_img = self.blur_engine.apply_motion_blur(rendered_img, flow_field)

            # Optional Super-Resolution
            if self.config.super_resolution:
                rendered_img = self.super_res_engine.upscale(rendered_img, target_size=(out_w, out_h))

            # Encode frame
            encoder.write_frame(rendered_img)
            frames_written += 1

            # Update metrics history
            confidence_history.append(conf)
            artifact_history.append(art_prob)
            
            recent_outputs.append(rendered_img)
            if len(recent_outputs) > 4:
                recent_outputs.pop(0)

            if len(sample_frames_for_metrics) < 40 and (frames_written % max(1, total_output_frames // 40) == 0):
                sample_frames_for_metrics.append(rendered_img.copy())

            # Progress callback
            if progress_callback:
                elapsed = time.time() - start_time
                fps_proc = frames_written / elapsed if elapsed > 0 else 0.0
                rem_frames = total_output_frames - frames_written
                eta = rem_frames / fps_proc if fps_proc > 0 else 0.0
                pct = (frames_written / total_output_frames) * 100.0

                prog = ProgressInfo(
                    frame_current=frames_written,
                    frame_total=total_output_frames,
                    percent=pct,
                    fps_processing=fps_proc,
                    eta_seconds=eta,
                    current_stage="Synthesizing Temporal Frames",
                    confidence=conf,
                    scene_id=current_scene_id,
                    status_message=f"Frame {frames_written:,}/{total_output_frames:,} ({pct:.1f}%)"
                )
                progress_callback(prog)

        encoder.close()
        elapsed_total = time.time() - start_time

        # Generate Quality Report
        q_report = self.quality_analyzer.evaluate(
            frames=sample_frames_for_metrics if sample_frames_for_metrics else [img_a],
            width=out_w,
            height=out_h,
            input_fps=metadata.fps,
            output_fps=timeline.output_fps,
            slow_factor=self.config.slow_factor,
            confidence_scores=confidence_history,
            artifact_scores=artifact_history
        )

        return SlowMotionResult(
            input_path=input_path,
            output_path=output_path,
            input_fps=metadata.fps,
            output_fps=timeline.output_fps,
            slow_factor=self.config.slow_factor,
            frames_generated=frames_written,
            source_frames=total_src,
            duration=timeline.reconstructed_duration,
            quality_score=q_report.temporal_consistency,
            artifact_score=q_report.artifact_score,
            mean_confidence=q_report.mean_confidence,
            quality_report=q_report,
            processing_time_sec=elapsed_total
        )

    def analyse(self, input_path: str | Path) -> VideoAnalysisResult:
        """
        Analyze video content, motion dynamics, scene cuts, and recommended configuration.
        """
        path_str = str(input_path)
        meta = VideoMetadata.from_file(path_str)
        decoder = VideoDecoder(path_str)

        # Sample up to 60 frames evenly across video
        sample_count = min(60, meta.total_frames) if meta.total_frames > 0 else 30
        frames: List[Frame] = []
        
        step = max(1, meta.total_frames // sample_count) if meta.total_frames > 0 else 1
        for frame in decoder.stream_frames(max_frames=sample_count * step):
            if frame.index % step == 0:
                frames.append(frame)
            if len(frames) >= sample_count:
                break

        if len(frames) < 2:
            return VideoAnalysisResult(
                resolution=f"{meta.width} × {meta.height}",
                width=meta.width,
                height=meta.height,
                fps=meta.fps,
                duration="00:00:01",
                duration_sec=meta.duration,
                total_frames=meta.total_frames,
                motion_complexity="STATIC",
                mean_motion_speed=0.0,
                scene_cuts_count=0,
                camera_motion_type="STATIC",
                interpolation_difficulty="LOW",
                recommended_factor=4.0,
                recommended_method="bidirectional",
                recommended_quality="balanced"
            )

        # Motion & Scene Analysis
        speeds = []
        cuts_detected = 0
        camera_motions = []

        for i in range(len(frames) - 1):
            fa, fb = frames[i].data, frames[i+1].data
            is_cut, diff, _ = self.scene_detector.is_scene_cut(fa, fb)
            if is_cut:
                cuts_detected += 1
            else:
                flow = self.motion_estimator.estimate_unidirectional(fa, fb)
                speed = float(np.mean(np.sqrt(flow[..., 0]**2 + flow[..., 1]**2)))
                speeds.append(speed)
                
                cm = self.scene_detector.estimate_camera_motion(fa, fb)
                camera_motions.append(cm)

        mean_speed = float(np.mean(speeds)) if speeds else 2.0
        
        # Classify motion
        if mean_speed < 1.5:
            mot_class = "STATIC"
            diff_class = "LOW"
            rec_factor = 8.0
            rec_method = "bidirectional"
            rec_qual = "balanced"
        elif mean_speed < 6.0:
            mot_class = "LOW"
            diff_class = "LOW"
            rec_factor = 4.0
            rec_method = "bidirectional"
            rec_qual = "balanced"
        elif mean_speed < 15.0:
            mot_class = "MEDIUM"
            diff_class = "MEDIUM"
            rec_factor = 4.0
            rec_method = "bidirectional"
            rec_qual = "quality"
        elif mean_speed < 35.0:
            mot_class = "HIGH"
            diff_class = "HIGH"
            rec_factor = 4.0
            rec_method = "ai"
            rec_qual = "ultra"
        else:
            mot_class = "EXTREME"
            diff_class = "VERY HIGH"
            rec_factor = 2.0
            rec_method = "ai"
            rec_qual = "ultra"

        # Format duration HH:MM:SS
        dur_int = int(meta.duration)
        hours = dur_int // 3600
        mins = (dur_int % 3600) // 60
        secs = dur_int % 60
        dur_str = f"{hours:02d}:{mins:02d}:{secs:02d}"

        cam_type = "MEDIUM" if camera_motions and any(c.is_handheld for c in camera_motions) else "LOW"

        notes = [
            f"Detected {cuts_detected} scene boundaries",
            f"Average optical flow displacement: {mean_speed:.2f} px/frame",
        ]
        if mot_class in ["HIGH", "EXTREME"]:
            notes.append("High motion velocity: AI bidirectional flow + temporal refinement recommended.")

        return VideoAnalysisResult(
            resolution=f"{meta.width} × {meta.height}",
            width=meta.width,
            height=meta.height,
            fps=meta.fps,
            duration=dur_str,
            duration_sec=meta.duration,
            total_frames=meta.total_frames,
            motion_complexity=mot_class,
            mean_motion_speed=round(mean_speed, 2),
            scene_cuts_count=cuts_detected,
            camera_motion_type=cam_type,
            interpolation_difficulty=diff_class,
            recommended_factor=rec_factor,
            recommended_method=rec_method,
            recommended_quality=rec_qual,
            notes=notes
        )

    def preview(
        self,
        input: str | Path,
        output: str | Path,
        slow_factor: float = 4.0,
        preview_seconds: float = 2.0,
        progress_callback: Optional[Callable[[ProgressInfo], None]] = None
    ) -> SlowMotionResult:
        """
        Generate a short representative slow-motion preview (e.g. 2-3 seconds)
        before running the entire video.
        """
        meta = VideoMetadata.from_file(str(input))
        max_frames = max(10, int(round(meta.fps * preview_seconds)))
        
        return self.process(
            input=input,
            output=output,
            slow_factor=slow_factor,
            max_source_frames=max_frames,
            progress_callback=progress_callback
        )
