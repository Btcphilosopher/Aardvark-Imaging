"""
SLOWFRAME.PRO — Physics-Based Motion Blur & Shutter Angle Engine
"""

from __future__ import annotations
import numpy as np
from typing import Optional, List

try:
    import cv2
    HAS_OPENCV = True
except ImportError:
    HAS_OPENCV = False

from slowframe.core.config import MotionBlurMode


class MotionBlurEngine:
    """
    Generates realistic optical motion blur synthesized from estimated
    motion vectors according to camera shutter angle and exposure characteristics.
    """

    def __init__(
        self,
        mode: MotionBlurMode = MotionBlurMode.CINEMATIC,
        shutter_angle: float = 180.0,
        samples: int = 8,
        strength: float = 1.0
    ):
        self.mode = mode
        self.shutter_angle = float(shutter_angle)  # Degrees: 180 = standard cinema
        self.samples = max(2, samples)
        self.strength = float(strength)

    def apply_motion_blur(
        self,
        image: np.ndarray,
        flow: np.ndarray
    ) -> np.ndarray:
        """
        Synthesize directional motion blur along flow vector trajectories.
        flow: (H, W, 2) vector field (dx, dy)
        """
        if self.mode == MotionBlurMode.NONE or self.shutter_angle <= 0.0:
            return image.copy()

        h, w = image.shape[:2]
        # Shutter fraction = shutter_angle / 360.0 (e.g. 180 / 360 = 0.5 exposure time)
        exposure_factor = (self.shutter_angle / 360.0) * self.strength
        
        # Scale flow by exposure factor
        effective_flow = flow * exposure_factor
        mag = np.sqrt(effective_flow[..., 0]**2 + effective_flow[..., 1]**2)

        if np.max(mag) < 0.5:
            # Negligible motion
            return image.copy()

        # Multi-sample trajectory integration
        # Sample points along [-0.5, +0.5] trajectory interval centered on frame
        t_offsets = np.linspace(-0.5, 0.5, self.samples)
        
        # In cinematic mode, center sample has higher optical weighting (curved iris falloff)
        if self.mode == MotionBlurMode.CINEMATIC:
            weights = np.exp(-0.5 * (t_offsets / 0.3)**2)
            weights /= np.sum(weights)
        else:
            weights = np.ones(self.samples) / self.samples

        accum = np.zeros((h, w, 3), dtype=np.float32)
        img_f = image.astype(np.float32)

        if HAS_OPENCV:
            grid_x, grid_y = np.meshgrid(np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32))
            for t_step, w_step in zip(t_offsets, weights):
                shift_x = grid_x + (effective_flow[..., 0] * t_step).astype(np.float32)
                shift_y = grid_y + (effective_flow[..., 1] * t_step).astype(np.float32)
                sampled = cv2.remap(image, shift_x, shift_y, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
                accum += sampled.astype(np.float32) * w_step
        else:
            accum = img_f

        return np.clip(accum, 0, 255).astype(image.dtype)
