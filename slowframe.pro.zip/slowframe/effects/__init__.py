"""
SLOWFRAME.PRO — Visual & Temporal Effects Subsystem
"""

from slowframe.effects.motion_blur import MotionBlurEngine
from slowframe.effects.frame_blending import FrameBlender

__all__ = [
    "MotionBlurEngine",
    "FrameBlender",
]
