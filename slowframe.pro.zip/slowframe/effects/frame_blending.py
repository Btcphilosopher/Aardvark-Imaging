"""
SLOWFRAME.PRO — Temporal Frame Blending & Sub-Frame Accumulation
"""

from __future__ import annotations
import numpy as np
from typing import List


class FrameBlender:
    """Accumulates and composites sub-frame exposure slices for motion smoothing."""

    @staticmethod
    def blend_frames(frames: List[np.ndarray], weights: List[float]) -> np.ndarray:
        """Weighted linear blending of multiple consecutive sub-frames."""
        if not frames:
            raise ValueError("Empty frames list in blend_frames")
        
        w_sum = sum(weights)
        if w_sum <= 0:
            raise ValueError("Sum of weights must be positive")

        norm_weights = [w / w_sum for w in weights]
        accum = np.zeros_like(frames[0], dtype=np.float32)

        for f, w in zip(frames, norm_weights):
            accum += f.astype(np.float32) * w

        return np.clip(accum, 0, 255).astype(frames[0].dtype)
