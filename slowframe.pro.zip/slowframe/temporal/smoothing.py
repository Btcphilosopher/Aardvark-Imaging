"""
SLOWFRAME.PRO — Motion Trajectory Temporal Smoothing
"""

from __future__ import annotations
import numpy as np
from typing import List


class TemporalSmoother:
    """Smooths motion trajectories and acceleration spikes across reconstructed frames."""

    def __init__(self, filter_strength: float = 0.5):
        self.filter_strength = filter_strength

    def smooth_motion_vectors(self, vector_series: List[np.ndarray]) -> List[np.ndarray]:
        """Apply Gaussian temporal filter across sequence of flow fields."""
        if len(vector_series) < 3:
            return vector_series

        smoothed = []
        n = len(vector_series)
        for i in range(n):
            weights = []
            flows = []
            for offset in [-1, 0, 1]:
                idx = i + offset
                if 0 <= idx < n:
                    w = 0.5 if offset == 0 else 0.25
                    weights.append(w)
                    flows.append(vector_series[idx])
            
            w_sum = sum(weights)
            avg_flow = sum(f * w for f, w in zip(flows, weights)) / w_sum
            smoothed.append(avg_flow)

        return smoothed
