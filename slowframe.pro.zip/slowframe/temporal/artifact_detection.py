"""
SLOWFRAME.PRO — Artifact Detection & Quality Confidence Scoring
"""

from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from typing import Optional, Tuple, Dict, Any

try:
    import cv2
    HAS_OPENCV = True
except ImportError:
    HAS_OPENCV = False


@dataclass
class ArtifactReport:
    frame_index: int
    confidence_score: float        # [0.0, 1.0] (e.g. 0.96)
    occlusion_level: str           # "LOW", "MEDIUM", "HIGH"
    motion_complexity: str         # "STATIC", "LOW", "MEDIUM", "HIGH", "EXTREME"
    artifact_probability: float    # [0.0, 1.0] (e.g. 0.03)
    double_edge_score: float
    ghosting_score: float
    temporal_flicker_score: float
    details: Dict[str, Any]


class ArtifactDetector:
    """
    Industrial Artifact Detector that scans synthesized frames for:
    - Double edges & ghost contours
    - Warping tears and shear discontinuities
    - High-frequency temporal flicker
    - Texture duplication anomalies
    """

    def __init__(
        self,
        double_edge_threshold: float = 0.18,
        ghosting_threshold: float = 0.22,
        flicker_threshold: float = 0.15
    ):
        self.double_edge_threshold = double_edge_threshold
        self.ghosting_threshold = ghosting_threshold
        self.flicker_threshold = flicker_threshold

    def analyze(
        self,
        interpolated_frame: np.ndarray,
        frame_a: np.ndarray,
        frame_b: np.ndarray,
        t: float,
        occlusion_mask: Optional[np.ndarray] = None,
        flow_magnitude: Optional[float] = None,
        frame_index: int = 0
    ) -> ArtifactReport:
        """Analyze an interpolated frame and return comprehensive artifact diagnostics."""
        interp_f = interpolated_frame.astype(np.float32)
        fa_f = frame_a.astype(np.float32)
        fb_f = frame_b.astype(np.float32)

        # 1. Motion Complexity Classification
        motion_val = flow_magnitude if flow_magnitude is not None else float(np.mean(np.abs(fa_f - fb_f)))
        if motion_val < 1.0:
            motion_cat = "STATIC"
        elif motion_val < 6.0:
            motion_cat = "LOW"
        elif motion_val < 18.0:
            motion_cat = "MEDIUM"
        elif motion_val < 40.0:
            motion_cat = "HIGH"
        else:
            motion_cat = "EXTREME"

        # 2. Occlusion Level
        if occlusion_mask is not None:
            mean_occ = float(np.mean(occlusion_mask))
            if mean_occ < 0.08:
                occ_level = "LOW"
            elif mean_occ < 0.25:
                occ_level = "MEDIUM"
            else:
                occ_level = "HIGH"
        else:
            mean_occ = 0.05
            occ_level = "LOW"

        # 3. Double Edge / Ghosting Analysis
        # If a frame has ghosting, edge gradients from both frame A and B appear simultaneously
        # in regions where they shouldn't exist.
        if HAS_OPENCV:
            gray_i = cv2.cvtColor(interpolated_frame, cv2.COLOR_RGB2GRAY)
            gray_a = cv2.cvtColor(frame_a, cv2.COLOR_RGB2GRAY)
            gray_b = cv2.cvtColor(frame_b, cv2.COLOR_RGB2GRAY)

            edge_i = cv2.Canny(gray_i, 50, 150).astype(np.float32) / 255.0
            edge_a = cv2.Canny(gray_a, 50, 150).astype(np.float32) / 255.0
            edge_b = cv2.Canny(gray_b, 50, 150).astype(np.float32) / 255.0

            # Double edge metric: high edge response where neither A nor B had edge
            spurious_edges = np.maximum(0.0, edge_i - np.maximum(edge_a, edge_b))
            double_edge_score = float(np.mean(spurious_edges))
        else:
            double_edge_score = 0.02

        # 4. Temporal Linear Deviation (Ghosting Score)
        expected_linear = (1.0 - t) * fa_f + t * fb_f
        deviation = np.abs(interp_f - expected_linear)
        ghosting_score = float(np.percentile(deviation, 95) / 255.0)

        # 5. Temporal Flicker Metric
        flicker_score = float(np.abs(np.mean(interp_f) - ((1.0 - t) * np.mean(fa_f) + t * np.mean(fb_f))) / 255.0)

        # 6. Combined Artifact Probability & Confidence Score
        raw_artifact_prob = (
            0.4 * double_edge_score +
            0.35 * (ghosting_score * 0.5) +
            0.25 * (mean_occ * 0.8) +
            0.2 * flicker_score
        )
        artifact_prob = float(np.clip(raw_artifact_prob, 0.01, 0.95))
        confidence = float(np.clip(1.0 - artifact_prob, 0.05, 0.99))

        return ArtifactReport(
            frame_index=frame_index,
            confidence_score=round(confidence, 3),
            occlusion_level=occ_level,
            motion_complexity=motion_cat,
            artifact_probability=round(artifact_prob, 3),
            double_edge_score=round(double_edge_score, 4),
            ghosting_score=round(ghosting_score, 4),
            temporal_flicker_score=round(flicker_score, 4),
            details={
                "mean_occlusion": round(mean_occ, 3),
                "motion_magnitude": round(motion_val, 2)
            }
        )
