"""
SLOWFRAME.PRO — Temporal Consistency & Anti-Flicker Engine
"""

from __future__ import annotations
import numpy as np
from typing import List, Optional

try:
    import cv2
    HAS_OPENCV = True
except ImportError:
    HAS_OPENCV = False


class TemporalConsistencyEngine:
    """
    Stabilizes consecutive interpolated frames to eliminate high-frequency
    temporal flicker, warping pulsation, and brightness instability while
    preserving crisp high-frequency edge textures.
    """

    def __init__(
        self,
        window_size: int = 3,
        smoothing_factor: float = 0.35,
        edge_threshold: float = 25.0
    ):
        self.window_size = window_size
        self.smoothing_factor = smoothing_factor
        self.edge_threshold = edge_threshold

    def refine_frame(
        self,
        current_frame: np.ndarray,
        prev_frame: Optional[np.ndarray] = None,
        next_frame: Optional[np.ndarray] = None,
        confidence: float = 1.0
    ) -> np.ndarray:
        """
        Refine a single frame using forward/backward temporal context.
        Uses edge-aware bilateral temporal blending: smooths flat regions
        where flow jitter occurs, while leaving strong edges untouched.
        """
        if prev_frame is None and next_frame is None:
            return current_frame.copy()

        curr_f = current_frame.astype(np.float32)
        
        # Calculate local spatial edges to prevent plastic over-smoothing
        if HAS_OPENCV:
            gray = cv2.cvtColor(current_frame, cv2.COLOR_RGB2GRAY) if current_frame.ndim == 3 else current_frame
            edges = cv2.Sobel(gray, cv2.CV_32F, 1, 1, ksize=3)
            edge_weight = np.clip(np.abs(edges) / self.edge_threshold, 0.0, 1.0)[:, :, None]
        else:
            gx = np.gradient(curr_f.mean(axis=-1), axis=1)
            gy = np.gradient(curr_f.mean(axis=-1), axis=0)
            edge_weight = np.clip(np.sqrt(gx**2 + gy**2) / self.edge_threshold, 0.0, 1.0)[:, :, None]

        # Temporal neighbor average
        neighbors = []
        if prev_frame is not None:
            neighbors.append(prev_frame.astype(np.float32))
        if next_frame is not None:
            neighbors.append(next_frame.astype(np.float32))

        if not neighbors:
            return current_frame.copy()

        temp_avg = np.mean(neighbors, axis=0)
        
        # Adaptive blend factor:
        # - Higher smoothing if confidence is low
        # - Lower smoothing where strong edges exist (retain sharpness)
        alpha = self.smoothing_factor * (1.0 - 0.5 * confidence) * (1.0 - 0.7 * edge_weight)
        alpha = np.clip(alpha, 0.0, 0.5)

        refined = (1.0 - alpha) * curr_f + alpha * temp_avg
        return np.clip(refined, 0, 255).astype(current_frame.dtype)

    def normalize_brightness_drift(self, sequence: List[np.ndarray]) -> List[np.ndarray]:
        """Normalize subtle frame-to-frame exposure or flicker oscillations."""
        if len(sequence) < 3:
            return sequence

        means = [float(np.mean(f)) for f in sequence]
        # Moving average of luminance
        kernel_size = min(5, len(sequence))
        kernel = np.ones(kernel_size) / kernel_size
        smooth_means = np.convolve(means, kernel, mode='same')

        corrected = []
        for frame, raw_m, smooth_m in zip(sequence, means, smooth_means):
            if raw_m > 1.0:
                gain = smooth_m / raw_m
                # Bound gain strictly to avoid artifacts
                gain = np.clip(gain, 0.92, 1.08)
                adj = np.clip(frame.astype(np.float32) * gain, 0, 255).astype(frame.dtype)
                corrected.append(adj)
            else:
                corrected.append(frame)

        return corrected
