"""
Unit & Pytest tests for Quality Metrics (PSNR, SSIM, Temporal Consistency).
"""

import unittest
import numpy as np
from tests.conftest import create_synthetic_frame
from slowframe.quality.psnr import compute_psnr
from slowframe.quality.ssim import compute_ssim
from slowframe.quality.temporal_quality import compute_temporal_consistency
from slowframe.quality.metrics import QualityAnalyzer


class TestMetrics(unittest.TestCase):
    def test_psnr(self):
        f1 = create_synthetic_frame("static", 0.0, 100, 100)
        # Identical images
        self.assertTrue(compute_psnr(f1, f1) >= 99.0)

        # Perturbed image
        f2 = np.clip(f1.astype(np.float32) + 5.0, 0, 255).astype(np.uint8)
        psnr = compute_psnr(f1, f2)
        self.assertTrue(20.0 < psnr < 60.0)

    def test_ssim(self):
        f1 = create_synthetic_frame("static", 0.0, 100, 100)
        self.assertAlmostEqual(compute_ssim(f1, f1), 1.0, places=3)

    def test_quality_analyzer(self):
        analyzer = QualityAnalyzer()
        f1 = create_synthetic_frame("static", 0.0, 100, 100)
        f2 = create_synthetic_frame("static", 0.0, 100, 100)
        
        rep = analyzer.evaluate(
            frames=[f1, f2],
            width=100,
            height=100,
            input_fps=30.0,
            output_fps=120.0,
            slow_factor=4.0
        )
        
        self.assertTrue(rep.temporal_consistency > 0.8)
        self.assertIn("SLOWFRAME QUALITY REPORT", rep.format_text())


if __name__ == "__main__":
    unittest.main()
