"""
Unit & Pytest tests for Frame Interpolation backends.
"""

import unittest
import numpy as np
from tests.conftest import create_synthetic_frame
from slowframe.interpolation.linear import LinearInterpolator
from slowframe.interpolation.optical_flow import UnidirectionalFlowInterpolator
from slowframe.interpolation.bidirectional import BidirectionalFlowInterpolator
from slowframe.interpolation.ai_interpolator import RIFEInterpolatorPlugin


class TestInterpolation(unittest.TestCase):
    def test_linear_interpolation(self):
        fa = np.zeros((100, 100, 3), dtype=np.uint8)
        fb = np.ones((100, 100, 3), dtype=np.uint8) * 100
        
        mid = LinearInterpolator.interpolate_crossfade(fa, fb, 0.5)
        self.assertTrue(np.allclose(mid, 50, atol=2))
        
        near = LinearInterpolator.interpolate_nearest(fa, fb, 0.2)
        self.assertTrue(np.array_equal(near, fa))

    def test_bidirectional_interpolation(self):
        fa = create_synthetic_frame("translating_circle", 0.0, 160, 120)
        fb = create_synthetic_frame("translating_circle", 0.2, 160, 120)
        
        interpolator = BidirectionalFlowInterpolator()
        res = interpolator.interpolate(fa, fb, 0.5)
        
        self.assertEqual(res.image.shape, (120, 160, 3))
        self.assertTrue(0.0 <= res.confidence <= 1.0)
        self.assertEqual(res.occlusion_mask.shape, (120, 160))
        self.assertEqual(res.confidence_map.shape, (120, 160))

    def test_ai_fallback(self):
        fa = create_synthetic_frame("static", 0.0, 100, 100)
        fb = create_synthetic_frame("static", 0.1, 100, 100)
        
        rife = RIFEInterpolatorPlugin()
        info = rife.get_info()
        self.assertIn("RIFE", info.name)
        
        res = rife.interpolate(fa, fb, 0.5)
        self.assertEqual(res.image.shape, (100, 100, 3))


if __name__ == "__main__":
    unittest.main()
