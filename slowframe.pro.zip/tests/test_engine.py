"""
Full end-to-end unit tests for SlowMotionEngine and CLI.
"""

import os
import unittest
import tempfile
from pathlib import Path
from tests.conftest import create_synthetic_frame
from slowframe.core.engine import SlowMotionEngine
from slowframe.core.config import SlowFrameConfig, InterpolationMethod, MotionBlurMode
from slowframe.cli.main import main


class TestEngine(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.tmp_path = Path(self.temp_dir.name)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_engine_process_synthetic(self):
        out_video = self.tmp_path / "output_slow.mp4"
        in_video = self.tmp_path / "input_test.mp4"
        
        import cv2
        w, h, fps, count = 160, 120, 24.0, 6
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        writer = cv2.VideoWriter(str(in_video), fourcc, fps, (w, h))
        for i in range(count):
            t = i / float(count - 1)
            frame = create_synthetic_frame("translating_circle", t, w, h)
            writer.write(cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))
        writer.release()

        cfg = SlowFrameConfig(
            slow_factor=2.0,
            interpolation_method=InterpolationMethod.BIDIRECTIONAL,
            motion_blur=MotionBlurMode.CINEMATIC
        )
        engine = SlowMotionEngine(cfg)
        
        res = engine.process(input=in_video, output=out_video)
        
        self.assertEqual(res.slow_factor, 2.0)
        self.assertEqual(res.output_fps, 48.0)
        self.assertTrue(res.frames_generated > count)
        self.assertTrue(res.quality_score > 0.5)
        self.assertTrue(out_video.exists())

    def test_engine_analyse(self):
        in_video = self.tmp_path / "analyse_test.mp4"
        import cv2
        w, h, fps, count = 160, 120, 30.0, 8
        writer = cv2.VideoWriter(str(in_video), cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
        for i in range(count):
            frame = create_synthetic_frame("translating_circle", i / 7.0, w, h)
            writer.write(cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))
        writer.release()

        engine = SlowMotionEngine()
        analysis = engine.analyse(in_video)
        self.assertEqual(analysis.width, 160)
        self.assertEqual(analysis.height, 120)
        self.assertIn(analysis.motion_complexity, ["STATIC", "LOW", "MEDIUM", "HIGH", "EXTREME"])

    def test_cli_analyse(self):
        in_video = self.tmp_path / "cli_test.mp4"
        import cv2
        w, h, fps, count = 160, 120, 24.0, 5
        writer = cv2.VideoWriter(str(in_video), cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
        for i in range(count):
            frame = create_synthetic_frame("static", 0.0, w, h)
            writer.write(cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))
        writer.release()

        code = main(["analyse", str(in_video)])
        self.assertEqual(code, 0)


if __name__ == "__main__":
    unittest.main()
