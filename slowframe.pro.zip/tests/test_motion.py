"""
Unit & Pytest tests for Motion Estimation, Feature Tracking, and Scene Detection.
"""

import unittest
import numpy as np
from tests.conftest import create_synthetic_frame
from slowframe.motion.optical_flow import MotionEstimator
from slowframe.motion.scene_detection import SceneDetector
from slowframe.motion.motion_vectors import MotionVectorEngine


class TestMotion(unittest.TestCase):
    def test_optical_flow_estimation(self):
        fa = create_synthetic_frame("translating_circle", 0.0, 160, 120)
        fb = create_synthetic_frame("translating_circle", 0.1, 160, 120)

        estimator = MotionEstimator(algorithm="farneback")
        res = estimator.estimate_bidirectional(fa, fb)

        self.assertEqual(res.flow_forward.shape, (120, 160, 2))
        self.assertEqual(res.flow_backward.shape, (120, 160, 2))
        self.assertTrue(res.mean_motion >= 0.0)
        self.assertEqual(res.occlusion_mask.shape, (120, 160))

    def test_scene_detection(self):
        detector = SceneDetector(cut_threshold=25.0)

        # Similar frames (no cut)
        fa = create_synthetic_frame("static", 0.0, 160, 120)
        fb = create_synthetic_frame("static", 0.0, 160, 120)
        is_cut, score, _ = detector.is_scene_cut(fa, fb)
        self.assertFalse(is_cut)

        # Hard cut
        scene1 = create_synthetic_frame("scene_cut", 0.1, 160, 120)
        scene2 = create_synthetic_frame("scene_cut", 0.9, 160, 120)
        is_cut_hard, score_hard, type_hard = detector.is_scene_cut(scene1, scene2)
        self.assertTrue(is_cut_hard)
        self.assertEqual(type_hard, "CUT")

    def test_motion_vector_hsv(self):
        flow = np.zeros((100, 100, 2), dtype=np.float32)
        flow[:, :, 0] = 5.0  # Horizontal motion
        hsv_rgb = MotionVectorEngine.flow_to_hsv_rgb(flow)
        self.assertEqual(hsv_rgb.shape, (100, 100, 3))
        self.assertEqual(hsv_rgb.dtype, np.uint8)


if __name__ == "__main__":
    unittest.main()
