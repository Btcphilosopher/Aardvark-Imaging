"""
SLOWFRAME.PRO — Test Suite Fixtures & Synthetic Video Generators
"""

from __future__ import annotations
import os
import tempfile
import numpy as np
try:
    import pytest
    HAS_PYTEST = True
except ImportError:
    HAS_PYTEST = False
    # Mock fixture decorator if pytest is not installed
    class _MockPytest:
        @staticmethod
        def fixture(fn):
            return fn
    pytest = _MockPytest()
from pathlib import Path
from typing import List, Tuple

try:
    import cv2
    HAS_OPENCV = True
except ImportError:
    HAS_OPENCV = False

from slowframe.video.frames import Frame, FrameMetadata


def create_synthetic_frame(
    pattern: str = "translating_circle",
    t: float = 0.0,
    width: int = 320,
    height: int = 240
) -> np.ndarray:
    """
    Generate synthetic test frames with mathematically predictable motion
    for rigorous quantitative testing.
    """
    img = np.zeros((height, width, 3), dtype=np.uint8)

    if pattern == "static":
        # Static grid texture
        grid_size = 20
        for y in range(0, height, grid_size):
            for x in range(0, width, grid_size):
                if (x // grid_size + y // grid_size) % 2 == 0:
                    img[y:y+grid_size, x:x+grid_size] = [70, 80, 95]
                else:
                    img[y:y+grid_size, x:x+grid_size] = [40, 45, 55]

    elif pattern == "translating_circle":
        # Background gradient
        gx, gy = np.meshgrid(np.linspace(0, 1, width), np.linspace(0, 1, height))
        img[..., 0] = (gx * 100).astype(np.uint8)
        img[..., 1] = (gy * 100).astype(np.uint8)
        img[..., 2] = 120

        # Circle moving horizontally from left to right: x = 50 + t * 200
        cx = int(50 + t * 200)
        cy = height // 2
        radius = 30
        
        y_idx, x_idx = np.ogrid[:height, :width]
        dist = np.sqrt((x_idx - cx)**2 + (y_idx - cy)**2)
        mask = dist <= radius
        img[mask] = [255, 200, 50]

    elif pattern == "rotating_object":
        # Center rotating square
        angle = t * np.pi * 2.0  # 1 full rotation
        cx, cy = width // 2, height // 2
        
        y_idx, x_idx = np.meshgrid(np.arange(height) - cy, np.arange(width) - cx, indexing='ij')
        
        rot_x = x_idx * np.cos(angle) - y_idx * np.sin(angle)
        rot_y = x_idx * np.sin(angle) + y_idx * np.cos(angle)
        
        square_mask = (np.abs(rot_x) < 40) & (np.abs(rot_y) < 40)
        img[square_mask] = [0, 220, 255]

    elif pattern == "occlusion":
        # Stationary background circle, moving vertical foreground bar
        cx, cy = width // 2, height // 2
        y_idx, x_idx = np.ogrid[:height, :width]
        
        # Red background sphere
        dist = np.sqrt((x_idx - cx)**2 + (y_idx - cy)**2)
        img[dist <= 45] = [230, 40, 40]
        
        # Green foreground pillar moving across
        bar_x = int(30 + t * 240)
        bar_width = 35
        bar_mask = (x_idx >= bar_x) & (x_idx <= bar_x + bar_width)
        img[bar_mask] = [40, 230, 70]

    elif pattern == "camera_pan":
        # Background scene sliding horizontally (simulating camera pan)
        shift_x = int(t * 80)
        gx, _ = np.meshgrid(np.arange(width) + shift_x, np.arange(height))
        stripe = ((gx // 25) % 2) * 180 + 40
        img[..., 0] = stripe.astype(np.uint8)
        img[..., 1] = (stripe * 0.7).astype(np.uint8)
        img[..., 2] = 200

    elif pattern == "scene_cut":
        if t < 0.5:
            # Scene 1: Warm orange
            img[:] = [240, 140, 50]
        else:
            # Scene 2: Cool cyan
            img[:] = [30, 180, 240]

    else:
        # Default gradient
        img[:] = int(t * 255)

    return img


@pytest.fixture
def synthetic_video_path(tmp_path: Path) -> Path:
    """Generate a small 10-frame synthetic test video file."""
    video_file = tmp_path / "synthetic_test.mp4"
    w, h, fps, count = 320, 240, 30.0, 12

    if HAS_OPENCV:
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        writer = cv2.VideoWriter(str(video_file), fourcc, fps, (w, h))
        for i in range(count):
            t = i / float(count - 1)
            frame = create_synthetic_frame("translating_circle", t, w, h)
            # OpenCV expects BGR
            bgr = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
            writer.write(bgr)
        writer.release()
    else:
        # Create empty dummy file
        video_file.touch()

    return video_file
