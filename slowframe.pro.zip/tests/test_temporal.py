"""
Unit & Pytest tests for Temporal Consistency, Artifact Detection & Motion Blur.
"""

import unittest
import numpy as np
from tests.conftest import create_synthetic_frame
from slowframe.temporal.consistency import TemporalConsistencyEngine
from slowframe.temporal.artifact_detection import ArtifactDetector
from slowframe.effects.motion_blur import MotionBlurEngine
from slowframe.core.config import MotionBlurMode


class TestTemporal(unittest.TestCase):
    def test_temporal_consistency(self):
        engine = TemporalConsistencyEngine()
        f1 = create_synthetic_frame("static", 0.0, 100, 100)
        f2 = create_synthetic_frame("static", 0.0, 100, 100)
        
        refined = engine.refine_frame(f2, prev_frame=f1, confidence=0.95)
        self.assertEqual(refined.shape, (100, 100, 3))

    def test_artifact_detector(self):
        detector = ArtifactDetector()
        fa = create_synthetic_frame("translating_circle", 0.0, 160, 120)
        fb = create_synthetic_frame("translating_circle", 0.2, 160, 120)
        
        interp = ((fa.astype(np.float32) + fb.astype(np.float32)) * 0.5).astype(np.uint8)
        rep = detector.analyze(interp, fa, fb, t=0.5, frame_index=1)
        
        self.assertTrue(0.0 <= rep.confidence_score <= 1.0)
        self.assertTrue(0.0 <= rep.artifact_probability <= 1.0)
        self.assertIn(rep.occlusion_level, ["LOW", "MEDIUM", "HIGH"])

    def test_motion_blur(self):
        blur_eng = MotionBlurEngine(mode=MotionBlurMode.CINEMATIC, shutter_angle=180.0)
        img = create_synthetic_frame("translating_circle", 0.0, 100, 100)
        flow = np.ones((100, 100, 2), dtype=np.float32) * 8.0
        
        blurred = blur_eng.apply_motion_blur(img, flow)
        self.assertEqual(blurred.shape, (100, 100, 3))


if __name__ == "__main__":
    unittest.main()
