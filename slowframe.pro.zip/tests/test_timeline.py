"""
Unit & Pytest tests for Timeline Engine and PTS generation.
"""

import unittest
from slowframe.core.timeline import Timeline


class TestTimeline(unittest.TestCase):
    def test_timeline_2x(self):
        tl = Timeline(source_frame_count=5, source_fps=30.0, slow_factor=2.0)
        self.assertEqual(tl.total_output_frames, 9)
        self.assertEqual(tl.output_fps, 60.0)
        items = tl.get_schedule()
        self.assertEqual(len(items), 9)
        self.assertEqual(items[0].t, 0.0)
        self.assertTrue(items[0].is_source)
        self.assertEqual(items[1].t, 0.5)
        self.assertFalse(items[1].is_source)
        self.assertEqual(items[2].t, 0.0)
        self.assertTrue(items[2].is_source)

    def test_timeline_4x(self):
        tl = Timeline(source_frame_count=3, source_fps=24.0, slow_factor=4.0)
        self.assertEqual(tl.total_output_frames, 9)
        self.assertEqual(tl.output_fps, 96.0)
        items = tl.get_schedule()
        self.assertEqual(items[0].t, 0.0)
        self.assertAlmostEqual(items[1].t, 0.25, places=4)
        self.assertAlmostEqual(items[2].t, 0.50, places=4)
        self.assertAlmostEqual(items[3].t, 0.75, places=4)
        self.assertAlmostEqual(items[4].t, 0.0, places=4)

    def test_timeline_fractional(self):
        tl = Timeline(source_frame_count=10, source_fps=60.0, slow_factor=1.5)
        self.assertEqual(tl.total_output_frames, 15)
        items = tl.get_schedule()
        self.assertEqual(len(items), 15)
        self.assertEqual(items[-1].source_index_a, 9)


if __name__ == "__main__":
    unittest.main()
