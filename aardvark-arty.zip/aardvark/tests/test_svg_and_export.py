import os
import tempfile

import pytest

from aardvark.document.document import Document
from aardvark.core.object import AardObject, AardObjectType
from aardvark.vector import shapes
from aardvark.colour.colour import AardColour
from aardvark.export.svg import AardSVGWriter, AardSVGParser, parse_svg_path_d
from aardvark.export.raster import export_raster
from aardvark.raster.image import RasterImage


def _doc_with_shapes():
    doc = Document("SVGTest")
    ab = doc.add_artboard("Main", 200, 150, AardColour.from_hex("#101010"))
    rect = AardObject(AardObjectType.SHAPE, name="Rect")
    rect.data = shapes.rectangle(10, 10, 60, 40)
    rect.style.fill = AardColour.from_hex("#ff0000")
    ab.add(rect)
    circle = AardObject(AardObjectType.SHAPE, name="Circle")
    circle.data = shapes.circle(center=(150, 75), radius=30)
    circle.style.fill = AardColour.from_hex("#00ff00")
    circle.style.stroke = AardColour.from_hex("#0000ff")
    circle.style.stroke_width = 3
    ab.add(circle)
    return doc


def test_svg_writer_produces_valid_xml():
    import xml.etree.ElementTree as ET

    doc = _doc_with_shapes()
    writer = AardSVGWriter(200, 150)
    svg_text = writer.write(doc)
    root = ET.fromstring(svg_text)
    assert root.tag.endswith("svg")


def test_svg_roundtrip_preserves_object_count():
    doc = _doc_with_shapes()
    writer = AardSVGWriter(200, 150)
    svg_text = writer.write(doc)
    parser = AardSVGParser()
    imported = parser.parse(svg_text)
    # Each top-level object was wrapped in its own <g>; both should parse back.
    assert len(imported.children) == 2


def test_svg_roundtrip_preserves_fill_colour():
    doc = _doc_with_shapes()
    writer = AardSVGWriter(200, 150)
    svg_text = writer.write(doc)
    imported = AardSVGParser().parse(svg_text)
    rect_group = imported.children[0]
    path_obj = rect_group.children[0]
    assert path_obj.style.fill.to_hex() == "#ff0000"


def test_parse_svg_path_d_line_and_curve():
    p = parse_svg_path_d("M 0 0 L 10 0 L 10 10 Z")
    polys = p.to_polygons()
    assert polys[0][0] == pytest.approx((0, 0))
    assert polys[0][1] == pytest.approx((10, 0))
    assert polys[0][2] == pytest.approx((10, 10))


def test_parse_svg_path_d_relative_commands():
    p = parse_svg_path_d("M 0 0 l 10 0 l 0 10 z")
    polys = p.to_polygons()
    assert polys[0][1] == pytest.approx((10, 0))
    assert polys[0][2] == pytest.approx((10, 10))


def test_png_export_creates_file_with_expected_size():
    doc = _doc_with_shapes()
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "out.png")
        image = export_raster(doc, path, dpi=96.0)
        assert os.path.exists(path)
        reloaded = RasterImage.from_file(path)
        assert reloaded.size == (200, 150)


def test_png_export_at_higher_dpi_scales_pixels():
    doc = _doc_with_shapes()
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "out.png")
        image = export_raster(doc, path, dpi=192.0)  # 2x
        assert image.size == (400, 300)


def test_png_export_has_nontransparent_pixels_where_shapes_are():
    doc = _doc_with_shapes()
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "out.png")
        image = export_raster(doc, path, dpi=96.0, background=None)
    # Centre of the circle at (150, 75), radius 30 -> should be green-filled.
    r, g, b, a = image.array[75, 150]
    assert g > r and g > b
    assert a > 0.9


def test_unsupported_raster_format_raises():
    doc = _doc_with_shapes()
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "out.xyz")
        with pytest.raises(ValueError):
            export_raster(doc, path, format="xyz")


def test_pdf_export_creates_nonempty_file():
    reportlab = pytest.importorskip("reportlab")
    from aardvark.export.pdf import AardPublication, export_pdf

    doc = _doc_with_shapes()
    pub = AardPublication(doc)
    pub.add_page(0, dpi=150)
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "out.pdf")
        export_pdf(pub, path)
        assert os.path.getsize(path) > 500
