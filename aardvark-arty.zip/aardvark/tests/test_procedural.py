import numpy as np
import pytest

from aardvark.procedural import noise, fractals, lsystem, flowfield, cellular


def test_perlin_deterministic_given_seed():
    xs = np.linspace(0, 5, 32)
    ys = np.linspace(0, 5, 32)
    xx, yy = np.meshgrid(xs, ys)
    a = noise.perlin(xx, yy, seed=42)
    b = noise.perlin(xx, yy, seed=42)
    assert np.array_equal(a, b)


def test_perlin_different_seeds_differ():
    xs = np.linspace(0, 5, 16)
    ys = np.linspace(0, 5, 16)
    xx, yy = np.meshgrid(xs, ys)
    a = noise.perlin(xx, yy, seed=1)
    b = noise.perlin(xx, yy, seed=2)
    assert not np.array_equal(a, b)


def test_perlin_range_bounded():
    xs = np.linspace(0, 20, 64)
    ys = np.linspace(0, 20, 64)
    xx, yy = np.meshgrid(xs, ys)
    v = noise.perlin(xx, yy, seed=7)
    assert v.min() >= -1.01
    assert v.max() <= 1.01


def test_value_noise_range_spans_unit_interval():
    xs = np.linspace(0, 10, 64)
    ys = np.linspace(0, 10, 64)
    xx, yy = np.meshgrid(xs, ys)
    v = noise.value_noise(xx, yy, seed=3)
    assert v.min() < 0.1
    assert v.max() > 0.9


def test_fbm_deterministic():
    xs = np.linspace(0, 3, 20)
    ys = np.linspace(0, 3, 20)
    xx, yy = np.meshgrid(xs, ys)
    a = noise.fbm(xx, yy, octaves=4, seed=5)
    b = noise.fbm(xx, yy, octaves=4, seed=5)
    assert np.array_equal(a, b)


def test_voronoi_assigns_nearest_point():
    xs = np.array([[0.0, 10.0]])
    ys = np.array([[0.0, 0.0]])
    dist, idx, pts = noise.voronoi(xs, ys, n_points=5, bounds=(0, 0, 10, 10), seed=0)
    assert dist.shape == xs.shape
    for i in range(2):
        d_direct = np.hypot(pts[:, 0] - xs[0, i], pts[:, 1] - ys[0, i])
        assert dist[0, i] == pytest.approx(d_direct.min(), abs=1e-9)


def test_mandelbrot_deterministic_and_bounded():
    a = fractals.mandelbrot(32, 32, max_iter=50)
    b = fractals.mandelbrot(32, 32, max_iter=50)
    assert np.array_equal(a, b)
    assert a.min() >= 0
    assert a.max() <= 1


def test_barnsley_fern_deterministic_given_seed():
    a = fractals.barnsley_fern(2000, seed=1)
    b = fractals.barnsley_fern(2000, seed=1)
    assert np.array_equal(a, b)
    c = fractals.barnsley_fern(2000, seed=2)
    assert not np.array_equal(a, c)


def test_recursive_tree_produces_segments_within_depth():
    segments = list(fractals.recursive_tree(0, 0, 0, 100, depth=3))
    assert len(segments) > 0
    assert max(s[4] for s in segments) <= 3


def test_lsystem_expand_koch():
    system = lsystem.preset("koch_curve")
    expanded = system.expand(2)
    assert expanded.count("F") == 5 ** 2  # each F -> 5 chars containing 4 F's... verify by growth
    assert len(expanded) > len(system.axiom)


def test_lsystem_turtle_segments_returns_lines():
    system = lsystem.preset("koch_curve")
    commands = system.expand(1)
    segments = lsystem.turtle_segments(commands, system.angle, system.step)
    assert len(segments) == commands.count("F")


def test_flow_field_deterministic():
    a = flowfield.flow_field(particles=50, steps=20, seed=11, width=100, height=100)
    b = flowfield.flow_field(particles=50, steps=20, seed=11, width=100, height=100)
    assert a == b


def test_flow_field_particles_stay_in_bounds():
    trajectories = flowfield.flow_field(particles=20, steps=30, width=100, height=100, seed=3)
    for traj in trajectories:
        for x, y in traj:
            assert -1 <= x <= 101
            assert -1 <= y <= 101


def test_game_of_life_step_still_life_block_is_stable():
    grid = np.zeros((6, 6), dtype=bool)
    # A 2x2 "block" is a still life under Conway's rules.
    grid[2, 2] = grid[2, 3] = grid[3, 2] = grid[3, 3] = True
    next_grid = cellular.game_of_life_step(grid)
    assert np.array_equal(grid, next_grid)


def test_elementary_ca_rule30_deterministic():
    a = cellular.elementary_ca(30, width=51, generations=20)
    b = cellular.elementary_ca(30, width=51, generations=20)
    assert np.array_equal(a, b)
    assert a[0].sum() == 1  # single seed cell
