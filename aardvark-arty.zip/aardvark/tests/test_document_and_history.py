import os
import tempfile

import pytest

from aardvark.document.document import Document
from aardvark.core.object import AardObject, AardObjectType
from aardvark.vector import shapes
from aardvark.colour.colour import AardColour
from aardvark.colour.gradient import AardGradient
from aardvark.history.history import History, make_command


def _build_test_document():
    doc = Document("Roundtrip")
    ab = doc.add_artboard("Main", 200, 150, AardColour.from_hex("#111111"))
    circle = AardObject(AardObjectType.SHAPE, name="Circle")
    circle.data = shapes.circle(center=(100, 75), radius=40)
    circle.style.fill = AardColour.from_hex("#E6E0D2")
    circle.style.stroke = AardGradient.linear([AardColour.from_hex("#C9A84C"), AardColour.from_hex("#00E5FF")])
    circle.tags = ["hero"]
    circle.metadata["note"] = "test object"
    group = AardObject(AardObjectType.GROUP, name="Group")
    group.add(circle)
    ab.add(group)
    return doc


def test_document_roundtrip_preserves_structure():
    doc = _build_test_document()
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "test.aard")
        doc.save(path)
        reloaded = Document.load(path)

    assert reloaded.name == "Roundtrip"
    ab = reloaded.artboards[0]
    assert ab.width == 200
    assert ab.height == 150
    assert ab.background.to_hex() == "#111111"

    group = ab.root.children[0]
    assert group.type.value == "GROUP"
    circle = group.children[0]
    assert circle.name == "Circle"
    assert circle.tags == ["hero"]
    assert circle.metadata["note"] == "test object"
    assert circle.style.fill.to_hex() == "#e6e0d2"
    assert isinstance(circle.style.stroke, AardGradient)
    assert circle.data.bounds() == pytest.approx((60, 35, 140, 115), abs=0.5)


def test_document_roundtrip_preserves_generator_metadata():
    doc = Document("Gen")
    ab = doc.add_artboard("Main", 100, 100)
    star = AardObject(AardObjectType.SHAPE, name="Star")
    star.data = shapes.star(points=6, inner_radius=10, outer_radius=20)
    star.generator = {"name": "star", "kwargs": {"points": 6, "inner_radius": 10, "outer_radius": 20}}
    ab.add(star)
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "gen.aard")
        doc.save(path)
        reloaded = Document.load(path)
    assert reloaded.artboards[0].root.children[0].generator == star.generator


def test_document_roundtrip_embeds_raster_image_asset():
    from aardvark.raster.image import RasterImage

    doc = Document("WithImage")
    ab = doc.add_artboard("Main", 50, 50)
    img_obj = AardObject(AardObjectType.IMAGE, name="Photo")
    img_obj.data = RasterImage.blank(20, 20, AardColour.from_hex("#ff0000"))
    ab.add(img_obj)
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "img.aard")
        doc.save(path)
        assert os.path.getsize(path) > 0
        reloaded = Document.load(path)
    reloaded_img = reloaded.artboards[0].root.children[0].data
    assert reloaded_img.size == (20, 20)


def test_history_undo_redo():
    state = {"value": 0}
    history = History()

    def make_set_command(new_value):
        old_value = state["value"]
        return make_command(
            f"set to {new_value}",
            do_fn=lambda: state.__setitem__("value", new_value),
            undo_fn=lambda: state.__setitem__("value", old_value),
        )

    history.do(make_set_command(1))
    history.do(make_set_command(2))
    history.do(make_set_command(3))
    assert state["value"] == 3

    assert history.undo() is True
    assert state["value"] == 2
    assert history.undo() is True
    assert state["value"] == 1

    assert history.redo() is True
    assert state["value"] == 2

    assert history.can_undo() is True
    assert history.undo() is True
    assert history.undo() is True
    assert history.can_undo() is False
    assert history.undo() is False  # nothing left to undo


def test_history_branching_creates_new_branch_without_discarding_old():
    state = {"value": 0}
    history = History()

    def cmd(v):
        old = state["value"]
        return make_command(str(v), lambda: state.__setitem__("value", v), lambda: state.__setitem__("value", old))

    history.do(cmd(1))
    history.do(cmd(2))
    history.undo()  # back to value=1
    history.do(cmd(99))  # new branch
    assert state["value"] == 99
    # Original branch (value=2) should still exist as a sibling.
    assert len(history.current.parent.children) == 2


def test_history_snapshot_and_checkout():
    state = {"value": 0}
    history = History()

    def cmd(v):
        old = state["value"]
        return make_command(str(v), lambda: state.__setitem__("value", v), lambda: state.__setitem__("value", old))

    history.do(cmd(1))
    snap = history.snapshot("v1")
    history.do(cmd(2))
    history.do(cmd(3))
    assert state["value"] == 3
    history.checkout(snap)
    assert state["value"] == 1
