import math

import pytest

from aardvark.geometry import bezier as bz


def test_lerp_endpoints():
    assert bz.lerp((0, 0), (10, 20), 0.0) == (0, 0)
    assert bz.lerp((0, 0), (10, 20), 1.0) == (10, 20)
    assert bz.lerp((0, 0), (10, 20), 0.5) == (5, 10)


def test_cubic_point_endpoints_match_anchors():
    p0, p1, p2, p3 = (0, 0), (10, 40), (30, 40), (40, 0)
    assert bz.cubic_point(p0, p1, p2, p3, 0.0) == pytest.approx(p0)
    assert bz.cubic_point(p0, p1, p2, p3, 1.0) == pytest.approx(p3)


def test_quadratic_to_cubic_matches_quadratic_curve():
    p0, p1, p2 = (0, 0), (25, 50), (50, 0)
    _, c1, c2, p3 = bz.quadratic_to_cubic(p0, p1, p2)
    for t in (0.0, 0.25, 0.5, 0.75, 1.0):
        quad_pt = bz.quadratic_point(p0, p1, p2, t)
        cubic_pt = bz.cubic_point(p0, c1, c2, p3, t)
        assert quad_pt == pytest.approx(cubic_pt, abs=1e-9)


def test_flatten_cubic_endpoints_and_monotonic_progress():
    p0, p1, p2, p3 = (0, 0), (0, 50), (50, 50), (50, 0)
    pts = bz.flatten_cubic(p0, p1, p2, p3, tolerance=0.1)
    assert pts[-1] == pytest.approx(p3, abs=1e-6)
    # Flattening a smooth curve should produce more than just the endpoint.
    assert len(pts) > 2


def test_flatten_cubic_tighter_tolerance_yields_more_points():
    p0, p1, p2, p3 = (0, 0), (0, 80), (80, 80), (80, 0)
    coarse = bz.flatten_cubic(p0, p1, p2, p3, tolerance=5.0)
    fine = bz.flatten_cubic(p0, p1, p2, p3, tolerance=0.05)
    assert len(fine) >= len(coarse)


def test_split_cubic_reproduces_original_curve():
    p0, p1, p2, p3 = (0, 0), (10, 30), (30, 30), (40, 0)
    left, right = bz.split_cubic(p0, p1, p2, p3, 0.5)
    assert left[0] == p0
    assert right[3] == p3
    assert left[3] == right[0]  # curves meet exactly at the split point
    mid_direct = bz.cubic_point(p0, p1, p2, p3, 0.5)
    assert left[3] == pytest.approx(mid_direct, abs=1e-9)


def test_cubic_bbox_matches_flattened_extrema():
    p0, p1, p2, p3 = (0, 0), (-20, 50), (60, 50), (40, 0)
    bx0, by0, bx1, by1 = bz.cubic_bbox(p0, p1, p2, p3)
    pts = [p0] + bz.flatten_cubic(p0, p1, p2, p3, tolerance=0.01)
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    # The analytic bbox must contain the densely-flattened polyline (with small AA tolerance).
    assert bx0 <= min(xs) + 1e-3
    assert bx1 >= max(xs) - 1e-3
    assert by0 <= min(ys) + 1e-3
    assert by1 >= max(ys) - 1e-3


def test_cubic_length_of_straight_line_matches_distance():
    p0, p3 = (0, 0), (30, 40)
    # Control points collinear with the endpoints -> the curve is a straight line.
    p1 = bz.lerp(p0, p3, 1 / 3)
    p2 = bz.lerp(p0, p3, 2 / 3)
    length = bz.cubic_length(p0, p1, p2, p3)
    assert length == pytest.approx(50.0, abs=0.05)  # 3-4-5 triangle * 10


def test_arc_to_cubics_endpoints():
    segs = bz.arc_to_cubics(0, 0, 10, 10, 0, math.pi / 2)
    assert segs[0][0] == pytest.approx((10, 0), abs=1e-9)
    assert segs[-1][3] == pytest.approx((0, 10), abs=1e-6)


def test_endpoint_arc_to_center_roundtrip():
    # A quarter-circle arc of radius 10 from (10, 0) to (0, 10).
    params = bz.endpoint_arc_to_center(10, 0, 0, 10, 10, 10, 0, False, True)
    assert params is not None
    cx, cy, rx, ry, a0, a1, rot = params
    assert (cx, cy) == pytest.approx((0, 0), abs=1e-6)
    assert rx == pytest.approx(10)
    assert ry == pytest.approx(10)
