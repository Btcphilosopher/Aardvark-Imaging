import os
import tempfile

import pytest

import aardvark as aard
from aardvark.colour.colour import AardColour
from aardvark.colour.gradient import AardGradient


def test_spec_example_end_to_end():
    """Mirrors the spec's own scripting example almost verbatim (section 32)."""
    doc = aard.create_document(400, 300)
    circle = aard.circle(center=(200, 150), radius=50)
    circle.fill = "#E6E0D2"
    doc.add(circle)
    with tempfile.TemporaryDirectory() as tmp:
        out = os.path.join(tmp, "artwork.png")
        doc.export(out)
        assert os.path.exists(out)


def test_fill_setter_accepts_hex_string():
    circle = aard.circle(radius=10)
    circle.fill = "#00e5ff"
    assert isinstance(circle.style.fill, AardColour)
    assert circle.fill.to_hex() == "#00e5ff"


def test_fill_setter_accepts_gradient():
    circle = aard.circle(radius=10)
    grad = AardGradient.linear([AardColour(1, 0, 0), AardColour(0, 0, 1)])
    circle.fill = grad
    assert circle.fill is grad


def test_stroke_setters():
    rect = aard.rectangle(width=20, height=20)
    rect.stroke = "#ffffff"
    rect.stroke_width = 4
    assert rect.stroke.to_hex() == "#ffffff"
    assert rect.style.stroke_width == 4


def test_document_add_and_group():
    doc = aard.create_document(100, 100)
    c1 = aard.circle(radius=5)
    c2 = aard.circle(radius=5)
    g = doc.group(c1, c2, name="Pair")
    assert g.name == "Pair"
    assert len(g.children) == 2
    assert g in doc.artboard.root.children


def test_generative_loop_produces_editable_objects():
    """The spec's generative-design example: a Python for-loop producing
    editable objects, each independently transformable."""
    doc = aard.create_document(1000, 1000)
    objects = []
    for i in range(20):
        c = aard.circle(center=(i * 20, 50), radius=5 + i / 5)
        c.fill = "#C9A84C"
        doc.add(c)
        objects.append(c)
    assert len(doc.artboard.root.children) == 20
    # Each remains individually editable/movable.
    objects[0].move(10, 10)
    assert objects[0].position == (10, 10)
    assert objects[1].position == (0, 0)


def test_regenerate_rebuilds_geometry_from_generator_params():
    star = aard.star(points=5, inner_radius=10, outer_radius=20)
    original_bounds = star.data.bounds()
    star.generator["kwargs"]["outer_radius"] = 40
    aard.regenerate(star)
    new_bounds = star.data.bounds()
    assert new_bounds != original_bounds
    span_original = original_bounds[2] - original_bounds[0]
    span_new = new_bounds[2] - new_bounds[0]
    assert span_new > span_original


def test_svg_export_via_document_wrapper():
    doc = aard.create_document(100, 100)
    doc.add(aard.circle(center=(50, 50), radius=20))
    with tempfile.TemporaryDirectory() as tmp:
        out = os.path.join(tmp, "out.svg")
        doc.export(out)
        with open(out) as f:
            content = f.read()
        assert "<svg" in content


def test_aard_save_and_load_via_wrapper():
    doc = aard.create_document(100, 100)
    doc.add(aard.circle(radius=20))
    with tempfile.TemporaryDirectory() as tmp:
        out = os.path.join(tmp, "doc.aard")
        doc.export(out)
        from aardvark.document.document import Document

        reloaded = Document.load(out)
        assert len(reloaded.artboards[0].root.children) == 1
