import pytest

shapely = pytest.importorskip("shapely")

from aardvark.vector import shapes, boolean


def _area(path, samples=200):
    """Approximate polygon area via the shoelace formula (single simple subpath)."""
    poly = path.to_polygons()[0]
    n = len(poly)
    area = 0.0
    for i in range(n):
        x0, y0 = poly[i]
        x1, y1 = poly[(i + 1) % n]
        area += x0 * y1 - x1 * y0
    return abs(area) / 2


def test_union_of_disjoint_squares_area():
    a = shapes.rectangle(0, 0, 10, 10)
    b = shapes.rectangle(20, 0, 10, 10)
    result = boolean.union(a, b)
    total = sum(_area(Path_) for Path_ in _split_subpaths(result))
    assert total == pytest.approx(200, rel=0.02)


def _split_subpaths(path):
    """Yield one single-subpath Path per subpath, for area measurement."""
    from aardvark.vector.path import Path

    for sub, closed in zip(path.subpaths, path.closed_flags):
        p = Path()
        p.subpaths = [sub]
        p.closed_flags = [closed]
        yield p


def test_union_of_overlapping_squares_area_less_than_sum():
    a = shapes.rectangle(0, 0, 10, 10)
    b = shapes.rectangle(5, 0, 10, 10)
    result = boolean.union(a, b)
    total = sum(_area(p) for p in _split_subpaths(result))
    assert total == pytest.approx(150, rel=0.02)  # 100 + 100 - 50 overlap


def test_intersect_of_overlapping_squares():
    a = shapes.rectangle(0, 0, 10, 10)
    b = shapes.rectangle(5, 0, 10, 10)
    result = boolean.intersect(a, b)
    total = sum(_area(p) for p in _split_subpaths(result))
    assert total == pytest.approx(50, rel=0.02)


def test_subtract_removes_overlap():
    a = shapes.rectangle(0, 0, 10, 10)
    b = shapes.rectangle(5, 0, 10, 10)
    result = boolean.subtract(a, b)
    total = sum(_area(p) for p in _split_subpaths(result))
    assert total == pytest.approx(50, rel=0.02)


def test_xor_of_overlapping_squares():
    a = shapes.rectangle(0, 0, 10, 10)
    b = shapes.rectangle(5, 0, 10, 10)
    result = boolean.xor(a, b)
    total = sum(_area(p) for p in _split_subpaths(result))
    assert total == pytest.approx(100, rel=0.02)  # union - intersect = 150 - 50


def test_boolean_result_stays_editable_path_type():
    from aardvark.vector.path import Path

    a = shapes.circle(radius=10)
    b = shapes.circle(center=(5, 0), radius=10)
    result = boolean.union(a, b)
    assert isinstance(result, Path)
    assert len(result.nodes()) > 0
