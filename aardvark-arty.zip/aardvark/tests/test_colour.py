import pytest

from aardvark.colour.colour import AardColour


def test_hex_roundtrip():
    c = AardColour.from_hex("#C9A84C")
    assert c.to_hex() == "#c9a84c"


def test_hex_short_form():
    c = AardColour.from_hex("#0f0")
    assert c.to_rgb8()[:3] == (0, 255, 0)


def test_rgb8_roundtrip():
    c = AardColour.from_rgb8(200, 100, 50)
    r, g, b, a = c.to_rgb8()
    assert (r, g, b) == (200, 100, 50)
    assert a == 255


def test_hsl_roundtrip_approx():
    original = AardColour.from_hex("#3366CC")
    h, s, l = original.to_hsl()
    reconstructed = AardColour.from_hsl(h, s, l)
    assert reconstructed.to_rgb8()[:3] == pytest.approx(original.to_rgb8()[:3], abs=1)


def test_hsv_roundtrip_approx():
    original = AardColour.from_hex("#FF8800")
    h, s, v = original.to_hsv()
    reconstructed = AardColour.from_hsv(h, s, v)
    assert reconstructed.to_rgb8()[:3] == pytest.approx(original.to_rgb8()[:3], abs=1)


def test_cmyk_roundtrip_approx():
    original = AardColour.from_hex("#446688")
    c, m, y, k = original.to_cmyk()
    reconstructed = AardColour.from_cmyk(c, m, y, k)
    assert reconstructed.to_rgb8()[:3] == pytest.approx(original.to_rgb8()[:3], abs=1)


def test_lab_roundtrip_approx():
    original = AardColour.from_hex("#8844AA")
    L, a, b = original.to_lab()
    reconstructed = AardColour.from_lab(L, a, b)
    assert reconstructed.to_rgb8()[:3] == pytest.approx(original.to_rgb8()[:3], abs=1)


def test_black_and_white_luminance():
    assert AardColour(0, 0, 0).luminance() == pytest.approx(0.0)
    assert AardColour(1, 1, 1).luminance() == pytest.approx(1.0)


def test_contrast_ratio_black_white_is_21():
    ratio = AardColour(0, 0, 0).contrast_ratio(AardColour(1, 1, 1))
    assert ratio == pytest.approx(21.0, abs=0.01)


def test_mix_midpoint():
    a = AardColour(0, 0, 0)
    b = AardColour(1, 1, 1)
    mid = a.mix(b, 0.5)
    assert (mid.r, mid.g, mid.b) == pytest.approx((0.5, 0.5, 0.5))


def test_rotate_hue_360_is_identity():
    c = AardColour.from_hex("#3366CC")
    rotated = c.rotate_hue(360)
    assert rotated.to_rgb8()[:3] == pytest.approx(c.to_rgb8()[:3], abs=1)


def test_array_conversions_match_scalar_for_single_pixel():
    import numpy as np
    from aardvark.colour.colour import rgb_to_lab_array, rgb_to_cmyk_array

    c = AardColour.from_hex("#8844AA")
    arr = np.array([[c.r, c.g, c.b]])
    lab_arr = rgb_to_lab_array(arr)[0]
    lab_scalar = c.to_lab()
    assert tuple(lab_arr) == pytest.approx(lab_scalar, abs=1e-3)

    cmyk_arr = rgb_to_cmyk_array(arr)[0]
    cmyk_scalar = c.to_cmyk()
    assert tuple(cmyk_arr) == pytest.approx(cmyk_scalar, abs=1e-3)
