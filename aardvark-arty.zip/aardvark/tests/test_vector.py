import math

import pytest

from aardvark.vector import shapes
from aardvark.vector.path import Path


def test_rectangle_bounds():
    p = shapes.rectangle(10, 20, 100, 50)
    assert p.bounds() == pytest.approx((10, 20, 110, 70))


def test_circle_bounds_approximately_correct():
    p = shapes.circle(center=(0, 0), radius=50)
    minx, miny, maxx, maxy = p.bounds()
    # Bezier circle approximation should be very close to the true radius.
    assert minx == pytest.approx(-50, abs=0.1)
    assert maxx == pytest.approx(50, abs=0.1)
    assert miny == pytest.approx(-50, abs=0.1)
    assert maxy == pytest.approx(50, abs=0.1)


def test_star_has_correct_point_count():
    p = shapes.star(points=5, inner_radius=10, outer_radius=20)
    polys = p.to_polygons()
    assert len(polys) == 1
    assert len(polys[0]) == 10  # 5 outer + 5 inner vertices


def test_polygon_requires_at_least_3_sides():
    with pytest.raises(ValueError):
        shapes.polygon(sides=2)


def test_path_transformed_translates_geometry():
    from aardvark.core.transform import Transform

    p = shapes.rectangle(0, 0, 10, 10)
    moved = p.transformed(Transform.translation(5, 5))
    assert moved.bounds() == pytest.approx((5, 5, 15, 15))
    # Original path must be unmodified (immutable-style transform).
    assert p.bounds() == pytest.approx((0, 0, 10, 10))


def test_path_length_of_straight_segment():
    p = Path()
    p.move_to(0, 0)
    p.line_to(30, 40)
    assert p.length() == pytest.approx(50.0)


def test_path_point_at_start_and_end():
    p = Path()
    p.move_to(0, 0)
    p.line_to(100, 0)
    start_pt, _ = p.point_at(0)
    end_pt, _ = p.point_at(100)
    assert start_pt == pytest.approx((0, 0))
    assert end_pt == pytest.approx((100, 0))


def test_path_point_at_midpoint():
    p = Path()
    p.move_to(0, 0)
    p.line_to(100, 0)
    mid_pt, angle = p.point_at(50)
    assert mid_pt == pytest.approx((50, 0), abs=1e-6)
    assert angle == pytest.approx(0.0, abs=1e-6)


def test_insert_node_splits_line_segment():
    p = Path()
    p.move_to(0, 0)
    p.line_to(10, 0)
    p.insert_node(0, 1, t=0.5)
    nodes = p.nodes()
    assert len(nodes) == 3
    assert nodes[1].anchor == pytest.approx((5, 0))


def test_reversed_path_keeps_same_bounds():
    p = shapes.star(points=6, inner_radius=10, outer_radius=25)
    rev = p.reversed()
    assert rev.bounds() == pytest.approx(p.bounds(), abs=1e-6)


def test_ring_uses_evenodd_fill_rule():
    p = shapes.ring(inner_radius=10, outer_radius=20)
    assert p.fill_rule == "evenodd"
    assert len(p.subpaths) == 2


def test_arc_to_cubics_used_by_path_arc_reaches_target_angle():
    p = Path()
    p.arc(0, 0, 10, 0, 180)
    polys = p.to_polygons()
    end_point = polys[0][-1]
    assert end_point == pytest.approx((-10, 0), abs=1e-6)
