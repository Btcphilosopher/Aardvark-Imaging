import math

import pytest

from aardvark.typography.text import TextObject, CharacterStyle, ParagraphStyle
from aardvark.patterns import symmetry, pattern
from aardvark.vector import shapes
from aardvark.layout.grid import ColumnGrid, modular_scale, golden_section, GOLDEN_RATIO
from aardvark.colour.colour import AardColour


def test_text_shape_produces_one_glyph_per_character():
    t = TextObject("Hello", CharacterStyle(size=20))
    run = t.shape()
    assert len(run.glyphs) == 5


def test_text_alignment_center_centers_within_frame():
    left = TextObject("Hi", CharacterStyle(size=20), ParagraphStyle(alignment="left"), frame_width=200)
    center = TextObject("Hi", CharacterStyle(size=20), ParagraphStyle(alignment="center"), frame_width=200)
    left_run = left.shape()
    center_run = center.shape()
    assert center_run.glyphs[0].position[0] > left_run.glyphs[0].position[0]


def test_text_on_path_positions_glyphs_along_path():
    from aardvark.vector.path import Path

    p = Path()
    p.move_to(0, 0)
    p.line_to(200, 0)
    t = TextObject("ABCDE", CharacterStyle(size=16), path=p)
    run = t.shape()
    xs = [g.position[0] for g in run.glyphs]
    assert xs == sorted(xs)  # glyphs progress monotonically along the path
    assert all(y == pytest.approx(0, abs=1e-6) for _, y in [g.position for g in run.glyphs])


def test_bilateral_mirror_symmetry_produces_mirrored_bounds():
    shape = shapes.rectangle(10, 0, 20, 10)  # offset to the right of x=0
    copies = symmetry.bilateral(shape, axis="vertical", center=(0, 0))
    assert len(copies) == 2
    b0 = copies[0].bounds()
    b1 = copies[1].bounds()
    assert b1[0] == pytest.approx(-b0[2], abs=1e-6)
    assert b1[2] == pytest.approx(-b0[0], abs=1e-6)


def test_rotational_symmetry_count():
    star = shapes.star(points=5, inner_radius=5, outer_radius=10)
    copies = symmetry.rotational(star, count=6, center=(0, 0))
    assert len(copies) == 6


def test_kaleidoscopic_symmetry_preserves_area_order_of_magnitude():
    shape = shapes.circle(center=(20, 0), radius=5)
    copies = symmetry.kaleidoscopic(shape, segments=8, center=(0, 0))
    assert len(copies) == 8
    # All copies should be roughly the same distance from the center.
    for c in copies:
        minx, miny, maxx, maxy = c.bounds()
        cx, cy = (minx + maxx) / 2, (miny + maxy) / 2
        assert math.hypot(cx, cy) == pytest.approx(20, abs=1.0)


def test_tile_pattern_grid_placement_count():
    unit = shapes.circle(radius=5)
    placements = pattern.tile_pattern(unit, columns=4, rows=3, spacing_x=20, spacing_y=20)
    assert len(placements) == 12


def test_radial_pattern_places_at_correct_radius():
    unit = shapes.circle(radius=2)
    placements = pattern.radial_pattern(unit, count=4, radius=50, center=(0, 0), face_outward=False)
    for _, t in placements:
        x, y = t.apply(0, 0)
        assert math.hypot(x, y) == pytest.approx(50, abs=1e-6)


def test_column_grid_bounds_count_and_span():
    grid = ColumnGrid(x=0, y=0, width=1000, height=200, columns=5, gutter=10, margin=20)
    bounds = grid.column_bounds()
    assert len(bounds) == 5
    assert bounds[0][0] == pytest.approx(20)
    assert bounds[-1][1] == pytest.approx(980)


def test_modular_scale_growth():
    scale = modular_scale(base=16, ratio=1.5, steps=4, start=0)
    assert scale[0] == pytest.approx(16)
    for a, b in zip(scale, scale[1:]):
        assert b == pytest.approx(a * 1.5)


def test_golden_section_split_ratio():
    a, b = golden_section(0, 0, 100, 50, vertical_first=True)
    assert a[2] + b[2] == pytest.approx(100)
    assert a[2] / b[2] == pytest.approx(GOLDEN_RATIO, abs=1e-6)
