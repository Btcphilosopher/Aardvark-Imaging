import numpy as np
import pytest

from aardvark.raster.image import RasterImage
from aardvark.raster.layer import composite
from aardvark.core.object import BlendMode
from aardvark.colour.colour import AardColour
from aardvark.masks.mask import AardMask, combine


def test_blank_image_is_transparent():
    img = RasterImage.blank(10, 10)
    assert img.array[..., 3].sum() == 0


def test_blank_image_with_fill():
    img = RasterImage.blank(4, 4, AardColour.from_hex("#ff0000"))
    assert np.allclose(img.array[..., 0], 1.0)
    assert np.allclose(img.array[..., 3], 1.0)


def test_normal_blend_over_transparent_shows_source():
    backdrop = RasterImage.blank(2, 2)
    source = RasterImage.blank(2, 2, AardColour(1, 0, 0, 1))
    result = composite(backdrop, source, BlendMode.NORMAL, opacity=1.0)
    assert np.allclose(result.array[..., 0], 1.0)
    assert np.allclose(result.array[..., 3], 1.0)


def test_normal_blend_respects_opacity():
    backdrop = RasterImage.blank(2, 2, AardColour(0, 0, 0, 1))
    source = RasterImage.blank(2, 2, AardColour(1, 1, 1, 1))
    result = composite(backdrop, source, BlendMode.NORMAL, opacity=0.5)
    assert np.allclose(result.array[..., 0], 0.5, atol=1e-5)


def test_multiply_blend_darkens():
    backdrop = RasterImage.blank(2, 2, AardColour(0.8, 0.8, 0.8, 1))
    source = RasterImage.blank(2, 2, AardColour(0.5, 0.5, 0.5, 1))
    result = composite(backdrop, source, BlendMode.MULTIPLY, opacity=1.0)
    assert np.allclose(result.array[..., 0], 0.4, atol=1e-5)


def test_screen_blend_lightens():
    backdrop = RasterImage.blank(2, 2, AardColour(0.2, 0.2, 0.2, 1))
    source = RasterImage.blank(2, 2, AardColour(0.5, 0.5, 0.5, 1))
    result = composite(backdrop, source, BlendMode.SCREEN, opacity=1.0)
    expected = 0.2 + 0.5 - 0.2 * 0.5
    assert np.allclose(result.array[..., 0], expected, atol=1e-5)


def test_resize_preserves_aspect_dimensions():
    img = RasterImage.blank(100, 50, AardColour(1, 0, 0))
    resized = img.resize(50, 25)
    assert resized.size == (50, 25)


def test_grayscale_removes_colour_but_keeps_alpha():
    img = RasterImage.blank(2, 2, AardColour(1, 0, 0, 0.7))
    gray = img.to_grayscale()
    assert np.allclose(gray.array[..., 0], gray.array[..., 1])
    assert np.allclose(gray.array[..., 3], 0.7)


def test_paste_alpha_composites():
    base = RasterImage.blank(10, 10, AardColour(0, 0, 0, 1))
    patch = RasterImage.blank(4, 4, AardColour(1, 1, 1, 1))
    base.paste(patch, 2, 2)
    assert np.allclose(base.array[2:6, 2:6, 0], 1.0)
    assert np.allclose(base.array[0, 0, 0], 0.0)


def test_mask_from_raster_alpha():
    alpha = np.ones((8, 8), dtype=np.float32) * 0.5
    mask = AardMask.from_raster_alpha(alpha)
    resolved = mask.to_alpha(8, 8)
    assert np.allclose(resolved, 0.5)


def test_mask_invert():
    alpha = np.zeros((4, 4), dtype=np.float32)
    alpha[0, 0] = 1.0
    mask = AardMask.from_raster_alpha(alpha, invert=True)
    resolved = mask.to_alpha(4, 4)
    assert resolved[0, 0] == pytest.approx(0.0)
    assert resolved[1, 1] == pytest.approx(1.0)


def test_mask_combine_intersect():
    a = AardMask.from_raster_alpha(np.array([[1.0, 1.0], [0.0, 0.0]], dtype=np.float32))
    b = AardMask.from_raster_alpha(np.array([[1.0, 0.0], [1.0, 0.0]], dtype=np.float32))
    result = combine(a, b, "INTERSECT", 2, 2)
    resolved = result.to_alpha(2, 2)
    assert resolved[0, 0] == pytest.approx(1.0)
    assert resolved[0, 1] == pytest.approx(0.0)
    assert resolved[1, 0] == pytest.approx(0.0)


def test_mask_combine_add_clamped():
    a = AardMask.from_raster_alpha(np.array([[0.8]], dtype=np.float32))
    b = AardMask.from_raster_alpha(np.array([[0.6]], dtype=np.float32))
    result = combine(a, b, "ADD", 1, 1)
    assert result.to_alpha(1, 1)[0, 0] == pytest.approx(1.0)


def test_vector_mask_rasterizes_shape():
    from aardvark.vector import shapes

    circle_path = shapes.circle(center=(50, 50), radius=40)
    mask = AardMask.from_path(circle_path)
    alpha = mask.to_alpha(100, 100, bbox=(0, 0, 100, 100))
    assert alpha[50, 50] > 0.9  # centre of circle should be fully inside
    assert alpha[2, 2] < 0.1  # corner should be outside
