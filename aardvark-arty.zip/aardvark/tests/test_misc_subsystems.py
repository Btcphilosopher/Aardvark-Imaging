import math

import numpy as np
import pytest

from aardvark.document.document import Document
from aardvark.core.object import AardObject, AardObjectType, BlendMode
from aardvark.vector import shapes
from aardvark.colour.colour import AardColour
from aardvark.rendering.renderer import CPURenderer
from aardvark.animation.timeline import Timeline, Keyframe, EASINGS
from aardvark.paint.brush import Brush, render_stroke, preset
from aardvark.effects import effects as fx
from aardvark.data.binding import DataBinding, Scale, bind
from aardvark.composition.analysis import analyse
from aardvark.three_d import scene as three_d


def test_renderer_respects_object_visibility():
    doc = Document("Vis")
    ab = doc.add_artboard("Main", 50, 50)
    c = AardObject(AardObjectType.SHAPE, name="Hidden")
    c.data = shapes.circle(center=(25, 25), radius=20)
    c.style.fill = AardColour(1, 1, 1)
    c.visibility = False
    ab.add(c)
    renderer = CPURenderer(supersample=1)
    img = renderer.render_document(doc)
    assert img.array[..., 3].sum() == 0  # nothing drawn


def test_renderer_group_opacity_applies_to_whole_group():
    doc = Document("GroupOpacity")
    ab = doc.add_artboard("Main", 50, 50)
    group = AardObject(AardObjectType.GROUP, name="G")
    group.opacity = 0.5
    c = AardObject(AardObjectType.SHAPE, name="C")
    c.data = shapes.rectangle(0, 0, 50, 50)
    c.style.fill = AardColour(1, 1, 1, 1)
    group.add(c)
    ab.add(group)
    renderer = CPURenderer(supersample=1)
    img = renderer.render_document(doc)
    assert img.array[25, 25, 3] == pytest.approx(0.5, abs=0.02)


def test_renderer_mask_restricts_visible_area():
    from aardvark.masks.mask import AardMask

    doc = Document("Masked")
    ab = doc.add_artboard("Main", 50, 50)
    rect = AardObject(AardObjectType.SHAPE, name="Rect")
    rect.data = shapes.rectangle(0, 0, 50, 50)
    rect.style.fill = AardColour(1, 1, 1, 1)
    alpha = np.zeros((50, 50), dtype=np.float32)
    alpha[:, :25] = 1.0  # only left half visible
    rect.mask = AardMask.from_raster_alpha(alpha)
    ab.add(rect)
    renderer = CPURenderer(supersample=1)
    img = renderer.render_document(doc)
    assert img.array[25, 10, 3] > 0.9
    assert img.array[25, 40, 3] < 0.1


def test_timeline_interpolates_position_linearly():
    obj = AardObject(AardObjectType.SHAPE, name="Mover")
    timeline = Timeline(duration=2.0, fps=10)
    timeline.animate(obj, "position", [Keyframe(0.0, (0, 0)), Keyframe(2.0, (100, 0))])
    timeline.apply(1.0)
    assert obj.position == pytest.approx((50, 0), abs=1e-6)


def test_timeline_easing_changes_midpoint():
    obj_linear = AardObject(AardObjectType.SHAPE)
    obj_eased = AardObject(AardObjectType.SHAPE)
    tl1 = Timeline(2.0, 10)
    tl1.animate(obj_linear, "opacity", [Keyframe(0, 0.0, easing="linear"), Keyframe(2.0, 1.0)])
    tl2 = Timeline(2.0, 10)
    tl2.animate(obj_eased, "opacity", [Keyframe(0, 0.0, easing="ease_in"), Keyframe(2.0, 1.0)])
    tl1.apply(1.0)
    tl2.apply(1.0)
    assert obj_linear.opacity == pytest.approx(0.5, abs=1e-6)
    assert obj_eased.opacity < obj_linear.opacity  # ease_in starts slower


def test_brush_stroke_renders_nonempty_alpha():
    brush = preset("ink")
    points = [(0, 0), (20, 0), (40, 10), (60, 10)]
    tile, offset = render_stroke(points, brush, AardColour(1, 1, 1, 1))
    assert tile.array[..., 3].sum() > 0


def test_brush_stroke_respects_pressure_size():
    brush = Brush(diameter=20, pressure_to_size=1.0, spacing=0.5)
    light, _ = render_stroke([(0, 0), (5, 0)], brush, AardColour(1, 1, 1), pressures=[0.1, 0.1])
    heavy, _ = render_stroke([(0, 0), (5, 0)], brush, AardColour(1, 1, 1), pressures=[1.0, 1.0])
    assert heavy.array[..., 3].sum() > light.array[..., 3].sum()


def test_effects_gaussian_blur_spreads_alpha():
    from aardvark.raster.image import RasterImage

    img = RasterImage.blank(20, 20)
    img.array[10, 10] = [1, 1, 1, 1]
    blurred = fx.gaussian_blur(img, radius=3)
    assert blurred.array[10, 12, 3] > 0  # alpha has spread to neighbouring pixels
    assert blurred.array[10, 10, 3] < 1.0  # peak has softened


def test_effects_drop_shadow_larger_canvas():
    from aardvark.raster.image import RasterImage

    img = RasterImage.blank(20, 20, AardColour(1, 1, 1, 1))
    shadow = fx.drop_shadow(img, offset=(4, 4), blur=2)
    assert shadow.width > img.width
    assert shadow.height > img.height


def test_data_binding_maps_columns_to_position_and_size():
    records = [{"x": 0, "y": 0, "v": 1}, {"x": 10, "y": 5, "v": 10}]
    size_scale = Scale.from_data([r["v"] for r in records], (2, 20))
    binding = DataBinding(
        x=DataBinding.field("x"),
        y=DataBinding.field("y"),
        size=lambda row: size_scale(row["v"]),
    )
    objects = bind(records, binding)
    assert len(objects) == 2
    assert objects[0].position == (0, 0)
    assert objects[1].position == (10, 5)


def test_composition_analyse_detects_offcenter_balance():
    doc = Document("Comp")
    ab = doc.add_artboard("Main", 100, 100)  # no background -> transparent
    rect = AardObject(AardObjectType.SHAPE, name="R")
    rect.data = shapes.rectangle(60, 60, 30, 30)  # weighted toward bottom-right
    rect.style.fill = AardColour(0, 0, 0, 1)
    ab.add(rect)
    renderer = CPURenderer(supersample=1)
    img = renderer.render_document(doc)
    report = analyse(img)
    assert report.balance[0] > 0  # centre of mass right of canvas centre
    assert report.balance[1] > 0  # centre of mass below canvas centre


def test_three_d_cube_has_8_vertices_and_12_faces():
    mesh = three_d.cube(size=2)
    assert mesh.vertices.shape == (8, 3)
    assert mesh.faces.shape == (12, 3)


def test_three_d_sphere_normals_point_outward():
    mesh = three_d.sphere(radius=1, segments=8, rings=6)
    normals = mesh.compute_normals()
    # For a sphere centred at the origin, vertex normals should broadly
    # align with the vertex position direction (positive dot product).
    dots = np.sum(mesh.vertices * normals, axis=1)
    assert (dots > 0).mean() > 0.9


def test_extrude_path_produces_closed_prism():
    p = shapes.rectangle(0, 0, 10, 10)
    mesh = three_d.extrude_path(p, depth=5)
    assert mesh.vertices.shape[1] == 3
    zs = set(np.round(mesh.vertices[:, 2], 4))
    assert zs == {2.5, -2.5}
