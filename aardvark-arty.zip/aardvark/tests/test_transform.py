import math

import pytest

from aardvark.core.transform import Transform


def test_identity_is_noop():
    t = Transform.identity()
    assert t.apply(5, 7) == (5, 7)


def test_translation():
    t = Transform.translation(10, -3)
    assert t.apply(0, 0) == (10, -3)


def test_rotation_about_world_origin_90deg():
    t = Transform.rotation(90)
    x, y = t.apply(1, 0)
    assert (x, y) == pytest.approx((0, 1), abs=1e-9)


def test_rotation_pivot_stays_fixed():
    """Regression test: Transform.around() must keep the pivot point fixed
    under rotation, not shift it."""
    pivot = (10, 0)
    t = Transform.rotation(90, origin=pivot)
    assert t.apply(*pivot) == pytest.approx(pivot, abs=1e-9)
    # A point 5 units away from the pivot should still be 5 units away after rotation.
    px, py = t.apply(15, 0)
    assert math.hypot(px - pivot[0], py - pivot[1]) == pytest.approx(5.0, abs=1e-9)


def test_scaling_pivot_stays_fixed():
    pivot = (5, 5)
    t = Transform.scaling(2, origin=pivot)
    assert t.apply(*pivot) == pytest.approx(pivot, abs=1e-9)
    assert t.apply(7, 5) == pytest.approx((9, 5), abs=1e-9)


def test_reflection_pivot_stays_fixed():
    pivot = (3, 4)
    t = Transform.reflection("x", origin=pivot)
    assert t.apply(*pivot) == pytest.approx(pivot, abs=1e-9)


def test_shearing_pivot_stays_fixed():
    pivot = (2, 2)
    t = Transform.shearing(shx=20, origin=pivot)
    assert t.apply(*pivot) == pytest.approx(pivot, abs=1e-9)


def test_inverse_undoes_transform():
    t = Transform.translation(5, 5).then(Transform.rotation(37)).then(Transform.scaling(1.7, 0.6))
    inv = t.inverse()
    x, y = 12.3, -4.5
    fx, fy = t.apply(x, y)
    rx, ry = inv.apply(fx, fy)
    assert (rx, ry) == pytest.approx((x, y), abs=1e-6)


def test_then_composition_order():
    # Translate then rotate should differ from rotate then translate.
    a = Transform.translation(10, 0).then(Transform.rotation(90))
    b = Transform.rotation(90).then(Transform.translation(10, 0))
    pa = a.apply(0, 0)
    pb = b.apply(0, 0)
    assert pa != pytest.approx(pb, abs=1e-6)


def test_decompose_recovers_pure_translation():
    t = Transform.translation(3, 4)
    d = t.decompose()
    assert d["translation"] == pytest.approx((3, 4))
    assert d["scale"] == pytest.approx((1, 1))
    assert d["rotation"] == pytest.approx(0, abs=1e-9)


def test_decompose_recovers_pure_rotation():
    d = Transform.rotation(37).decompose()
    assert d["rotation"] == pytest.approx(37, abs=1e-6)
    assert d["scale"] == pytest.approx((1, 1), abs=1e-9)


def test_decompose_recovers_pure_scale():
    d = Transform.scaling(2, 3).decompose()
    assert d["scale"] == pytest.approx((2, 3), abs=1e-9)
    assert d["rotation"] == pytest.approx(0, abs=1e-9)
