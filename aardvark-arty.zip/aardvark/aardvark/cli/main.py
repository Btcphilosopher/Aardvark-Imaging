"""Command-line interface (spec section 82: the same Document must be
manipulable through GUI, Python, CLI, plugin or automation identically).

Usage::

    aardvark new "My Piece" --width 1920 --height 1080 -o piece.aard
    aardvark run generate_poster.py
    aardvark export piece.aard piece.png --dpi 300
    aardvark export piece.aard piece.svg
    aardvark info
"""
from __future__ import annotations

import argparse
import runpy
import sys

from .. import __version__
from ..document.document import Document
from ..colour.colour import AardColour


def cmd_new(args) -> int:
    doc = Document(args.name)
    bg = AardColour.from_hex(args.background) if args.background else None
    doc.add_artboard("Main", args.width, args.height, bg)
    doc.save(args.output)
    print(f"Created {args.output} ({args.width}x{args.height})")
    return 0


def cmd_run(args) -> int:
    runpy.run_path(args.script, run_name="__main__")
    return 0


def cmd_export(args) -> int:
    doc = Document.load(args.input)
    fmt = args.format or args.output.rsplit(".", 1)[-1]
    if fmt == "svg":
        from ..export.svg import AardSVGWriter

        ab = doc.artboards[args.artboard]
        AardSVGWriter(ab.width, ab.height).save(args.output, doc, args.artboard)
    elif fmt == "pdf":
        from ..export.pdf import AardPublication, export_pdf

        pub = AardPublication(doc)
        pub.add_page(args.artboard, dpi=args.dpi, trim_marks=args.trim_marks, bleed=args.bleed)
        export_pdf(pub, args.output)
    else:
        from ..export.raster import export_raster

        export_raster(doc, args.output, format=fmt, artboard_index=args.artboard, dpi=args.dpi)
    print(f"Exported {args.input} -> {args.output}")
    return 0


def cmd_info(args) -> int:
    from ..vector.shapes import GENERATORS
    from ..paint.brush import PRESETS as brush_presets
    from ..procedural.lsystem import PRESETS as lsystem_presets

    print(f"AARDVARK {__version__}")
    print(f"Shape generators: {', '.join(sorted(GENERATORS))}")
    print(f"Brush presets: {', '.join(sorted(brush_presets))}")
    print(f"L-system presets: {', '.join(sorted(lsystem_presets))}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="aardvark", description="AARDVARK computational art & design engine")
    sub = parser.add_subparsers(dest="command", required=True)

    p_new = sub.add_parser("new", help="Create a new blank .aard document")
    p_new.add_argument("name")
    p_new.add_argument("--width", type=float, default=1920)
    p_new.add_argument("--height", type=float, default=1080)
    p_new.add_argument("--background", default=None, help="hex colour, e.g. #101010")
    p_new.add_argument("-o", "--output", required=True)
    p_new.set_defaults(func=cmd_new)

    p_run = sub.add_parser("run", help="Execute a Python script using the aardvark API")
    p_run.add_argument("script")
    p_run.set_defaults(func=cmd_run)

    p_export = sub.add_parser("export", help="Export a .aard document to PNG/JPEG/TIFF/WebP/SVG/PDF")
    p_export.add_argument("input")
    p_export.add_argument("output")
    p_export.add_argument("--format", default=None)
    p_export.add_argument("--artboard", type=int, default=0)
    p_export.add_argument("--dpi", type=float, default=96.0)
    p_export.add_argument("--bleed", type=float, default=0.0)
    p_export.add_argument("--trim-marks", action="store_true", dest="trim_marks")
    p_export.set_defaults(func=cmd_export)

    p_info = sub.add_parser("info", help="List available generators/presets and the version")
    p_info.set_defaults(func=cmd_info)

    return parser


def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
