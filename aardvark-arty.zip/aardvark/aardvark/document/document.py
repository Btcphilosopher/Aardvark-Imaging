"""Document model (spec sections 2-3): Document -> Artboard -> scene graph,
plus the native ``.aard`` file format.

A ``.aard`` file is a zip container:

* ``manifest.json`` — document metadata, artboard list, each artboard's
  scene graph (as nested :meth:`AardObject.to_dict`), palettes,
  variables, guides, grids, export profiles and history log.
* ``assets/<id>.<ext>`` — binary payloads referenced by manifest entries
  (embedded raster images, fonts). Vector/text/procedural data is stored
  as plain JSON inside the manifest itself, since it's just numbers.

This makes the ``.aard`` file "the recipe for the artwork, not merely a
flattened image" (spec section 3): reopening it reconstructs the full
editable scene graph, including each procedural object's generator
parameters.
"""
from __future__ import annotations

import io
import json
import zipfile
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..core.object import AardObject, AardObjectType
from ..colour.colour import AardColour
from ..colour.palette import AardPalette


FORMAT_VERSION = "1.0"


@dataclass
class ExportProfile:
    name: str
    format: str  # png | jpeg | svg | pdf | ...
    dpi: float = 300.0
    scale: float = 1.0
    colour_profile: str = "sRGB"
    background: Optional[str] = None  # hex, or None for transparent

    def to_dict(self):
        return {
            "name": self.name,
            "format": self.format,
            "dpi": self.dpi,
            "scale": self.scale,
            "colour_profile": self.colour_profile,
            "background": self.background,
        }

    @classmethod
    def from_dict(cls, d):
        return cls(**d)


class Artboard:
    """A single composition/canvas within a Document (spec section 45)."""

    def __init__(self, name: str, width: float, height: float, background: Optional[AardColour] = None):
        self.name = name
        self.width = width
        self.height = height
        self.background = background
        self.root = AardObject(AardObjectType.ARTBOARD, name=name)
        self.guides: List[dict] = []
        self.grids: List[dict] = []

    def add(self, obj: AardObject) -> AardObject:
        return self.root.add(obj)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "width": self.width,
            "height": self.height,
            "background": self.background.to_dict() if self.background else None,
            "root": self.root.to_dict(),
            "guides": self.guides,
            "grids": self.grids,
        }

    @classmethod
    def from_dict(cls, d: dict, data_decoder=None) -> "Artboard":
        bg = AardColour.from_dict(d["background"]) if d.get("background") else None
        ab = cls(d["name"], d["width"], d["height"], bg)
        ab.root = AardObject.from_dict(d["root"], data_decoder=data_decoder)
        ab.guides = d.get("guides", [])
        ab.grids = d.get("grids", [])
        return ab


class Document:
    """The single source of truth for an AARDVARK artwork (spec section 82):
    the same Document can be driven by the GUI, the Python scripting API,
    the CLI, or a plugin, identically."""

    def __init__(self, name: str = "Untitled"):
        self.name = name
        self.artboards: List[Artboard] = []
        self.palettes: List[AardPalette] = []
        self.variables: Dict[str, Any] = {}
        self.fonts: List[str] = []
        self.export_profiles: List[ExportProfile] = []
        self.metadata: Dict[str, Any] = {}
        self.history = None  # set lazily by aardvark.history.History if used
        self._assets: Dict[str, bytes] = {}  # asset id -> binary payload (images, fonts)

    # ------------------------------------------------------------------
    # Artboards
    # ------------------------------------------------------------------
    def add_artboard(self, name: str, width: float, height: float, background: Optional[AardColour] = None) -> Artboard:
        ab = Artboard(name, width, height, background)
        self.artboards.append(ab)
        return ab

    @property
    def artboard(self) -> Artboard:
        """Convenience accessor for single-artboard documents."""
        if not self.artboards:
            raise ValueError("Document has no artboards yet; call add_artboard() first")
        return self.artboards[0]

    def find_by_id(self, id: str) -> Optional[AardObject]:
        for ab in self.artboards:
            found = ab.root.find_by_id(id)
            if found:
                return found
        return None

    # ------------------------------------------------------------------
    # Assets (embedded binary payloads)
    # ------------------------------------------------------------------
    def register_asset(self, asset_id: str, payload: bytes) -> str:
        self._assets[asset_id] = payload
        return asset_id

    def get_asset(self, asset_id: str) -> Optional[bytes]:
        return self._assets.get(asset_id)

    # ------------------------------------------------------------------
    # Serialization: in-memory dict
    # ------------------------------------------------------------------
    def to_dict(self) -> dict:
        return {
            "format_version": FORMAT_VERSION,
            "name": self.name,
            "artboards": [ab.to_dict() for ab in self.artboards],
            "palettes": [p.to_dict() for p in self.palettes],
            "variables": self.variables,
            "fonts": self.fonts,
            "export_profiles": [p.to_dict() for p in self.export_profiles],
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, d: dict, data_decoder=None) -> "Document":
        doc = cls(d.get("name", "Untitled"))
        doc.artboards = [Artboard.from_dict(ad, data_decoder=data_decoder) for ad in d.get("artboards", [])]
        doc.palettes = [AardPalette.from_dict(p) for p in d.get("palettes", [])]
        doc.variables = d.get("variables", {})
        doc.fonts = d.get("fonts", [])
        doc.export_profiles = [ExportProfile.from_dict(p) for p in d.get("export_profiles", [])]
        doc.metadata = d.get("metadata", {})
        return doc

    # ------------------------------------------------------------------
    # .aard file I/O
    # ------------------------------------------------------------------
    def save(self, path: str) -> None:
        data_encoder, assets = _make_data_encoder(self)
        manifest = self.to_dict()
        # Re-walk with the asset-aware encoder now that objects carrying
        # binary payloads (images) have registered themselves.
        for i, ab in enumerate(self.artboards):
            manifest["artboards"][i]["root"] = _encode_object(ab.root, data_encoder)

        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("manifest.json", json.dumps(manifest, indent=2))
            for asset_id, payload in assets.items():
                zf.writestr(f"assets/{asset_id}", payload)

    @classmethod
    def load(cls, path: str) -> "Document":
        with zipfile.ZipFile(path, "r") as zf:
            manifest = json.loads(zf.read("manifest.json"))
            asset_names = {n for n in zf.namelist() if n.startswith("assets/")}
            assets = {n[len("assets/"):]: zf.read(n) for n in asset_names}

        def data_decoder(d):
            return _decode_data(d, assets)

        return cls.from_dict(manifest, data_decoder=data_decoder)


# ---------------------------------------------------------------------
# Data payload encode/decode (Path, TextObject, RasterImage, AardGradient, ...)
# ---------------------------------------------------------------------
def _encode_object(obj: AardObject, data_encoder) -> dict:
    d = {
        "id": obj.id,
        "type": obj.type.value,
        "name": obj.name,
        "position": list(obj.position),
        "rotation": obj.rotation,
        "scale": list(obj.scale),
        "opacity": obj.opacity,
        "visibility": obj.visibility,
        "locked": obj.locked,
        "blend_mode": obj.blend_mode.value,
        "transform": obj.transform.to_dict(),
        "style": obj.style.to_dict(),
        "metadata": obj.metadata,
        "tags": obj.tags,
        "generator": obj.generator,
        "data": data_encoder(obj.data) if obj.data is not None else None,
        "children": [_encode_object(c, data_encoder) for c in obj.children],
    }
    return d


def _make_data_encoder(document: "Document"):
    assets: Dict[str, bytes] = {}

    def encode(data):
        from ..vector.path import Path
        from ..typography.text import TextObject
        from ..raster.image import RasterImage
        from ..colour.gradient import AardGradient

        if isinstance(data, Path):
            return {"__type__": "Path", **data.to_dict()}
        if isinstance(data, TextObject):
            return {"__type__": "TextObject", **data.to_dict()}
        if isinstance(data, AardGradient):
            return {"__type__": "AardGradient", **data.to_dict()}
        if isinstance(data, RasterImage):
            import uuid

            asset_id = f"{uuid.uuid4().hex}.png"
            buf = io.BytesIO()
            data.to_pil().save(buf, format="PNG")
            assets[asset_id] = buf.getvalue()
            return {"__type__": "RasterImage", "asset": asset_id}
        # Unknown payloads are dropped with a metadata breadcrumb rather
        # than crashing the whole save.
        return {"__type__": "Unsupported", "repr": repr(data)[:200]}

    return encode, assets


def _decode_data(d: dict, assets: Dict[str, bytes]):
    from ..vector.path import Path
    from ..typography.text import TextObject
    from ..raster.image import RasterImage
    from ..colour.gradient import AardGradient
    from PIL import Image
    import io as _io

    t = d.get("__type__")
    if t == "Path":
        return Path.from_dict(d)
    if t == "TextObject":
        return TextObject.from_dict(d)
    if t == "AardGradient":
        return AardGradient.from_dict(d)
    if t == "RasterImage":
        payload = assets.get(d["asset"])
        if payload is None:
            return None
        return RasterImage.from_pil(Image.open(_io.BytesIO(payload)))
    return None
