"""L-system engine (spec section 9 & 37): rule-based string rewriting
turned into turtle-graphics geometry, deterministic given a seed for any
stochastic rules used.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, List, Tuple


@dataclass
class LSystem:
    axiom: str
    rules: Dict[str, str]
    angle: float = 25.0
    step: float = 10.0

    def expand(self, iterations: int) -> str:
        s = self.axiom
        for _ in range(iterations):
            s = "".join(self.rules.get(ch, ch) for ch in s)
        return s


def turtle_segments(commands: str, angle: float, step: float, start=(0.0, 0.0), start_heading: float = -90.0) -> List[Tuple[float, float, float, float]]:
    """Interpret a turtle-graphics command string into line segments.

    F/G: move forward drawing a line. f: move forward without drawing.
    +/-: turn by ``angle``. [ / ]: push/pop turtle state (position+heading).
    """
    x, y = start
    heading = start_heading
    stack = []
    segments = []
    for ch in commands:
        if ch in "FG":
            rad = math.radians(heading)
            nx, ny = x + step * math.cos(rad), y + step * math.sin(rad)
            segments.append((x, y, nx, ny))
            x, y = nx, ny
        elif ch == "f":
            rad = math.radians(heading)
            x, y = x + step * math.cos(rad), y + step * math.sin(rad)
        elif ch == "+":
            heading += angle
        elif ch == "-":
            heading -= angle
        elif ch == "[":
            stack.append((x, y, heading))
        elif ch == "]":
            if stack:
                x, y, heading = stack.pop()
        # other characters (e.g. 'X' in classic plant grammars) are no-ops
    return segments


# Common presets (spec section 37: "recursive trees")
PRESETS = {
    "koch_curve": LSystem(axiom="F", rules={"F": "F+F-F-F+F"}, angle=90, step=6),
    "koch_snowflake": LSystem(axiom="F++F++F", rules={"F": "F-F++F-F"}, angle=60, step=6),
    "sierpinski_arrowhead": LSystem(axiom="A", rules={"A": "B-A-B", "B": "A+B+A"}, angle=60, step=8),
    "dragon_curve": LSystem(axiom="FX", rules={"X": "X+YF+", "Y": "-FX-Y"}, angle=90, step=6),
    "plant": LSystem(axiom="X", rules={"X": "F+[[X]-X]-F[-FX]+X", "F": "FF"}, angle=25, step=5),
    "bush": LSystem(axiom="F", rules={"F": "FF-[-F+F+F]+[+F-F-F]"}, angle=22.5, step=6),
}


def preset(name: str) -> LSystem:
    if name not in PRESETS:
        raise ValueError(f"Unknown L-system preset {name!r}; choose from {list(PRESETS)}")
    import copy

    return copy.deepcopy(PRESETS[name])
