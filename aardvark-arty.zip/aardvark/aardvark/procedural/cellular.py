"""Cellular automata and reaction-diffusion (spec section 9)."""
from __future__ import annotations

import numpy as np


def game_of_life_step(grid: np.ndarray) -> np.ndarray:
    """One Conway's Game of Life step on a boolean (H, W) grid, toroidal
    (wraparound) boundary."""
    neighbours = sum(
        np.roll(np.roll(grid, dy, axis=0), dx, axis=1)
        for dy in (-1, 0, 1)
        for dx in (-1, 0, 1)
        if not (dx == 0 and dy == 0)
    )
    return (neighbours == 3) | (grid & (neighbours == 2))


def game_of_life(width: int, height: int, generations: int = 50, density: float = 0.35, seed: int = 0):
    """Yields successive (H, W) boolean grids, ``generations`` of them."""
    rng = np.random.default_rng(seed)
    grid = rng.random((height, width)) < density
    for _ in range(generations):
        yield grid
        grid = game_of_life_step(grid)


def elementary_ca(rule: int, width: int = 200, generations: int = 100, seed: int = 0) -> np.ndarray:
    """Wolfram's elementary 1D cellular automata. Returns a (generations,
    width) boolean array — row 0 is a single live cell in the centre."""
    rule_bits = [(rule >> i) & 1 for i in range(8)]
    grid = np.zeros((generations, width), dtype=bool)
    grid[0, width // 2] = True
    for g in range(1, generations):
        left = np.roll(grid[g - 1], 1)
        center = grid[g - 1]
        right = np.roll(grid[g - 1], -1)
        idx = (left.astype(int) << 2) | (center.astype(int) << 1) | right.astype(int)
        grid[g] = np.array(rule_bits)[idx].astype(bool)
    return grid


def reaction_diffusion(
    width: int = 200,
    height: int = 200,
    steps: int = 2000,
    da: float = 1.0,
    db: float = 0.5,
    feed: float = 0.055,
    kill: float = 0.062,
    seed: int = 0,
):
    """Gray-Scott reaction-diffusion. Returns the final (A, B) concentration
    grids (both (H, W) float arrays). Classic feed/kill pairs produce
    coral, spots, or maze-like textures — (0.055, 0.062) is "coral"."""
    rng = np.random.default_rng(seed)
    A = np.ones((height, width))
    B = np.zeros((height, width))
    r = height // 10
    cy, cx = height // 2, width // 2
    B[cy - r : cy + r, cx - r : cx + r] = 1.0
    B += rng.normal(0, 0.02, size=B.shape)
    B = np.clip(B, 0, 1)

    def laplacian(Z):
        return (
            -Z
            + 0.2 * (np.roll(Z, 1, 0) + np.roll(Z, -1, 0) + np.roll(Z, 1, 1) + np.roll(Z, -1, 1))
            + 0.05 * (np.roll(np.roll(Z, 1, 0), 1, 1) + np.roll(np.roll(Z, 1, 0), -1, 1) + np.roll(np.roll(Z, -1, 0), 1, 1) + np.roll(np.roll(Z, -1, 0), -1, 1))
        )

    for _ in range(steps):
        lapA, lapB = laplacian(A), laplacian(B)
        reaction = A * B * B
        A += da * lapA - reaction + feed * (1 - A)
        B += db * lapB + reaction - (kill + feed) * B
        np.clip(A, 0, 1, out=A)
        np.clip(B, 0, 1, out=B)
    return A, B
