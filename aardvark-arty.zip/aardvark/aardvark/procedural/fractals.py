"""Fractal engine (spec section 37): Mandelbrot, Julia, Barnsley fern,
and recursive-tree L-system-adjacent geometry. Rendered at arbitrary
resolution via numpy where the maths is naturally continuous (Mandelbrot
/ Julia); the fern is a point-cloud IFS sampler.
"""
from __future__ import annotations

from typing import Tuple

import numpy as np


def mandelbrot(width: int, height: int, center=(-0.5, 0.0), scale: float = 1.5, max_iter: int = 200) -> np.ndarray:
    """Returns an (H, W) float32 array of normalised escape-time values in [0, 1]."""
    cx, cy = center
    aspect = width / height
    xs = np.linspace(cx - scale * aspect, cx + scale * aspect, width)
    ys = np.linspace(cy - scale, cy + scale, height)
    X, Y = np.meshgrid(xs, ys)
    C = X + 1j * Y
    Z = np.zeros_like(C)
    div_time = np.full(C.shape, max_iter, dtype=np.float64)
    mask = np.ones(C.shape, dtype=bool)
    for i in range(max_iter):
        Z[mask] = Z[mask] ** 2 + C[mask]
        escaped = np.abs(Z) > 2
        newly = escaped & mask
        div_time[newly] = i
        mask &= ~escaped
        if not mask.any():
            break
    return (div_time / max_iter).astype(np.float32)


def julia(width: int, height: int, c: complex = -0.7 + 0.27015j, center=(0.0, 0.0), scale: float = 1.5, max_iter: int = 200) -> np.ndarray:
    cx, cy = center
    aspect = width / height
    xs = np.linspace(cx - scale * aspect, cx + scale * aspect, width)
    ys = np.linspace(cy - scale, cy + scale, height)
    X, Y = np.meshgrid(xs, ys)
    Z = X + 1j * Y
    div_time = np.full(Z.shape, max_iter, dtype=np.float64)
    mask = np.ones(Z.shape, dtype=bool)
    for i in range(max_iter):
        Z[mask] = Z[mask] ** 2 + c
        escaped = np.abs(Z) > 2
        newly = escaped & mask
        div_time[newly] = i
        mask &= ~escaped
        if not mask.any():
            break
    return (div_time / max_iter).astype(np.float32)


def barnsley_fern(n_points: int = 60000, seed: int = 0) -> np.ndarray:
    """Returns an (n_points, 2) array of fern points in the classic
    Barnsley IFS coordinate range (x roughly [-3, 3], y [0, 10])."""
    rng = np.random.default_rng(seed)
    x, y = 0.0, 0.0
    pts = np.empty((n_points, 2), dtype=np.float64)
    r = rng.random(n_points)
    for i in range(n_points):
        u = r[i]
        if u < 0.01:
            x, y = 0.0, 0.16 * y
        elif u < 0.86:
            x, y = 0.85 * x + 0.04 * y, -0.04 * x + 0.85 * y + 1.6
        elif u < 0.93:
            x, y = 0.20 * x - 0.26 * y, 0.23 * x + 0.22 * y + 1.6
        else:
            x, y = -0.15 * x + 0.28 * y, 0.26 * x + 0.24 * y + 0.44
        pts[i] = (x, y)
    return pts


def sierpinski_triangle(n_points: int = 40000, seed: int = 0) -> np.ndarray:
    rng = np.random.default_rng(seed)
    verts = np.array([[0, 0], [1, 0], [0.5, np.sqrt(3) / 2]])
    p = verts[0].copy()
    pts = np.empty((n_points, 2))
    choices = rng.integers(0, 3, n_points)
    for i in range(n_points):
        p = (p + verts[choices[i]]) / 2
        pts[i] = p
    return pts


def recursive_tree(x, y, angle_deg, length, depth, angle_delta=25.0, length_ratio=0.72, min_length=2.0):
    """Yields (x0, y0, x1, y1, depth) branch segments of a simple recursive tree."""
    if depth <= 0 or length < min_length:
        return
    import math

    rad = math.radians(angle_deg)
    x1 = x + length * math.sin(rad)
    y1 = y - length * math.cos(rad)
    yield (x, y, x1, y1, depth)
    yield from recursive_tree(x1, y1, angle_deg - angle_delta, length * length_ratio, depth - 1, angle_delta, length_ratio, min_length)
    yield from recursive_tree(x1, y1, angle_deg + angle_delta, length * length_ratio, depth - 1, angle_delta, length_ratio, min_length)
