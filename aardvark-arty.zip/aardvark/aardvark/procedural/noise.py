"""Noise generators (spec section 9): Perlin, Simplex, value noise,
fractal Brownian motion, and Voronoi/Worley noise — all deterministic
given a seed (spec section 64: reproducible art).

Self-contained numpy implementations (no external ``noise``/``perlin-numpy``
dependency), vectorised over whole coordinate grids so they're fast enough
for megapixel-scale procedural fills.
"""
from __future__ import annotations

import numpy as np


def _permutation_table(seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    p = np.arange(256, dtype=np.int32)
    rng.shuffle(p)
    return np.tile(p, 2)


def _fade(t):
    return t * t * t * (t * (t * 6 - 15) + 10)


def _lerp(a, b, t):
    return a + t * (b - a)


_GRADIENTS = np.array(
    [
        [1, 1], [-1, 1], [1, -1], [-1, -1],
        [1, 0], [-1, 0], [0, 1], [0, -1],
    ],
    dtype=np.float64,
)


def perlin(x: np.ndarray, y: np.ndarray, seed: int = 0) -> np.ndarray:
    """Classic gradient (Perlin) noise, output range approximately [-1, 1].
    ``x``/``y`` are numpy arrays of the same shape (a coordinate grid)."""
    perm = _permutation_table(seed)
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)

    xi = np.floor(x).astype(np.int64) & 255
    yi = np.floor(y).astype(np.int64) & 255
    xf = x - np.floor(x)
    yf = y - np.floor(y)
    u, v = _fade(xf), _fade(yf)

    def grad(hash_val, gx, gy):
        g = _GRADIENTS[hash_val % 8]
        return g[..., 0] * gx + g[..., 1] * gy

    aa = perm[perm[xi] + yi]
    ab = perm[perm[xi] + yi + 1]
    ba = perm[perm[xi + 1] + yi]
    bb = perm[perm[xi + 1] + yi + 1]

    n00 = grad(aa, xf, yf)
    n10 = grad(ba, xf - 1, yf)
    n01 = grad(ab, xf, yf - 1)
    n11 = grad(bb, xf - 1, yf - 1)

    x1 = _lerp(n00, n10, u)
    x2 = _lerp(n01, n11, u)
    return _lerp(x1, x2, v)


def simplex(x: np.ndarray, y: np.ndarray, seed: int = 0) -> np.ndarray:
    """2D simplex noise, output range approximately [-1, 1]."""
    perm = _permutation_table(seed)
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)

    F2 = 0.5 * (np.sqrt(3.0) - 1.0)
    G2 = (3.0 - np.sqrt(3.0)) / 6.0

    s = (x + y) * F2
    i = np.floor(x + s)
    j = np.floor(y + s)
    t = (i + j) * G2
    X0, Y0 = i - t, j - t
    x0, y0 = x - X0, y - Y0

    i1 = (x0 > y0).astype(np.float64)
    j1 = 1.0 - i1

    x1 = x0 - i1 + G2
    y1 = y0 - j1 + G2
    x2 = x0 - 1.0 + 2.0 * G2
    y2 = y0 - 1.0 + 2.0 * G2

    ii = i.astype(np.int64) & 255
    jj = j.astype(np.int64) & 255

    def grad_contrib(gi, xx, yy):
        g = _GRADIENTS[gi % 8]
        t = 0.5 - xx ** 2 - yy ** 2
        t = np.maximum(t, 0)
        return (t ** 4) * (g[..., 0] * xx + g[..., 1] * yy)

    gi0 = perm[ii + perm[jj]]
    gi1 = perm[(ii + i1.astype(np.int64)) + perm[(jj + j1.astype(np.int64))]]
    gi2 = perm[ii + 1 + perm[jj + 1]]

    n0 = grad_contrib(gi0, x0, y0)
    n1 = grad_contrib(gi1, x1, y1)
    n2 = grad_contrib(gi2, x2, y2)

    return 70.0 * (n0 + n1 + n2)


def value_noise(x: np.ndarray, y: np.ndarray, seed: int = 0) -> np.ndarray:
    """Smooth (bicubic-ish) value noise in [0, 1] — cheap, good for masks/textures."""
    perm = _permutation_table(seed)
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    xi = np.floor(x).astype(np.int64) & 255
    yi = np.floor(y).astype(np.int64) & 255
    xf, yf = x - np.floor(x), y - np.floor(y)
    u, v = _fade(xf), _fade(yf)

    def rand_at(px, py):
        # perm values are 0..255; the second lookup remaps through the
        # permutation table again so the result isn't just (py & 255)
        # linearly biasing the low bits, then normalise to [0, 1].
        return perm[(perm[px & 255] + (py & 255)) & 511] / 255.0

    n00 = rand_at(xi, yi)
    n10 = rand_at(xi + 1, yi)
    n01 = rand_at(xi, yi + 1)
    n11 = rand_at(xi + 1, yi + 1)
    x1 = _lerp(n00, n10, u)
    x2 = _lerp(n01, n11, u)
    return _lerp(x1, x2, v)


def fbm(x: np.ndarray, y: np.ndarray, octaves: int = 5, lacunarity: float = 2.0, gain: float = 0.5, seed: int = 0, kind: str = "perlin") -> np.ndarray:
    """Fractal Brownian motion: sum of ``octaves`` layers of noise at
    increasing frequency and decreasing amplitude."""
    fn = {"perlin": perlin, "simplex": simplex, "value": value_noise}[kind]
    total = np.zeros_like(np.asarray(x, dtype=np.float64))
    amplitude = 1.0
    frequency = 1.0
    max_amp = 0.0
    for i in range(octaves):
        total += fn(x * frequency, y * frequency, seed=seed + i * 101) * amplitude
        max_amp += amplitude
        amplitude *= gain
        frequency *= lacunarity
    return total / max_amp if max_amp else total


def voronoi(x: np.ndarray, y: np.ndarray, n_points: int = 24, bounds=(0, 0, 1, 1), seed: int = 0, metric: str = "euclidean"):
    """Cellular (Worley/Voronoi) noise. Returns (distance_to_nearest,
    cell_index) arrays, both broadcast to the shape of ``x``/``y``."""
    rng = np.random.default_rng(seed)
    minx, miny, maxx, maxy = bounds
    pts = np.stack([rng.uniform(minx, maxx, n_points), rng.uniform(miny, maxy, n_points)], axis=-1)

    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    flat_x, flat_y = x.ravel(), y.ravel()
    diff_x = flat_x[:, None] - pts[None, :, 0]
    diff_y = flat_y[:, None] - pts[None, :, 1]
    if metric == "manhattan":
        dist = np.abs(diff_x) + np.abs(diff_y)
    else:
        dist = np.hypot(diff_x, diff_y)
    nearest_idx = np.argmin(dist, axis=1)
    nearest_dist = dist[np.arange(dist.shape[0]), nearest_idx]
    return nearest_dist.reshape(x.shape), nearest_idx.reshape(x.shape), pts
