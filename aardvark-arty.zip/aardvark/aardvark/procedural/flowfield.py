"""Flow-field engine (spec section 36): FIELD -> PARTICLES -> TRAJECTORIES
-> BRUSH STROKES -> ARTWORK.

:func:`flow_field` matches the spec's own usage example::

    art = aard.procedural.flow_field(particles=10000, turbulence=0.35, scale=2.0)

and returns a list of polyline trajectories (each a list of (x, y) points)
that callers turn into Path objects, brush strokes, or particle renders.
"""
from __future__ import annotations

from typing import List, Tuple

import numpy as np

from . import noise as _noise

Point = Tuple[float, float]


def curl_noise(x: np.ndarray, y: np.ndarray, seed: int = 0, eps: float = 0.5) -> Tuple[np.ndarray, np.ndarray]:
    """2D curl of a scalar Perlin field — a cheap divergence-free vector
    field, which is what gives flow-field art its "fluid" look instead of
    noise gradients that pile particles up at extrema."""
    n1 = _noise.perlin(x, y + eps, seed=seed)
    n2 = _noise.perlin(x, y - eps, seed=seed)
    n3 = _noise.perlin(x + eps, y, seed=seed)
    n4 = _noise.perlin(x - eps, y, seed=seed)
    dx = (n1 - n2) / (2 * eps)
    dy = -(n3 - n4) / (2 * eps)
    return dx, dy


def flow_field(
    particles: int = 2000,
    turbulence: float = 0.35,
    scale: float = 2.0,
    steps: int = 120,
    step_length: float = 3.0,
    width: float = 800,
    height: float = 800,
    seed: int = 0,
) -> List[List[Point]]:
    """Trace ``particles`` trajectories through a curl-noise flow field.

    ``scale`` controls the field's spatial frequency (bigger = larger,
    smoother eddies); ``turbulence`` blends in a second, higher-frequency
    octave to roughen the flow.
    """
    rng = np.random.default_rng(seed)
    xs = rng.uniform(0, width, particles)
    ys = rng.uniform(0, height, particles)
    trajectories: List[List[Point]] = [[(float(xs[i]), float(ys[i]))] for i in range(particles)]

    px, py = xs.copy(), ys.copy()
    for _ in range(steps):
        nx, ny = px / (width / scale), py / (height / scale)
        dx, dy = curl_noise(nx, ny, seed=seed)
        if turbulence > 0:
            dx2, dy2 = curl_noise(nx * 3.7, ny * 3.7, seed=seed + 999)
            dx = dx * (1 - turbulence) + dx2 * turbulence
            dy = dy * (1 - turbulence) + dy2 * turbulence
        length = np.hypot(dx, dy) + 1e-9
        px = px + dx / length * step_length
        py = py + dy / length * step_length
        in_bounds = (px >= 0) & (px < width) & (py >= 0) & (py < height)
        for i in range(particles):
            if in_bounds[i]:
                trajectories[i].append((float(px[i]), float(py[i])))
    return trajectories


def flow_field_paths(**kwargs):
    """Same as :func:`flow_field` but returns AARDVARK ``Path`` objects
    (one polyline per particle) ready to attach to AardObjects."""
    from ..vector.path import Path

    trajectories = flow_field(**kwargs)
    paths = []
    for traj in trajectories:
        if len(traj) < 2:
            continue
        p = Path()
        p.move_to(*traj[0])
        for pt in traj[1:]:
            p.line_to(*pt)
        paths.append(p)
    return paths
