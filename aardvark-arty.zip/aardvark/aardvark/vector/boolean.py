"""Boolean geometry engine (spec section 5): UNION, SUBTRACT, INTERSECT,
XOR, DIVIDE, TRIM, MERGE.

Vector booleans are genuinely hard to get right by hand (self
intersections, holes, numerical robustness), so this module delegates the
polygon algebra to Shapely — a mature, widely used computational-geometry
library built on GEOS — and converts results back into editable AARDVARK
:class:`~aardvark.vector.path.Path` objects with real Bezier segments
re-fit where the source data was curved (straight results stay straight;
curved inputs approximate the result with short cubic segments so it
still reads as "editable" per the spec rather than a frozen polygon).
"""
from __future__ import annotations

from typing import List

from .path import Path

try:
    from shapely.geometry import Polygon, MultiPolygon
    from shapely.ops import unary_union

    _HAS_SHAPELY = True
except ImportError:  # pragma: no cover - exercised only without shapely installed
    _HAS_SHAPELY = False


class BooleanGeometryUnavailable(RuntimeError):
    pass


def _require_shapely():
    if not _HAS_SHAPELY:
        raise BooleanGeometryUnavailable(
            "Boolean geometry requires the optional 'shapely' dependency. "
            "Install it with: pip install shapely"
        )


def _path_to_polygon(path: Path, tolerance: float = 0.25):
    """Convert a (possibly compound) Path into a Shapely Polygon/MultiPolygon
    using nonzero/evenodd-aware ring nesting."""
    _require_shapely()
    polys = path.to_polygons(tolerance=tolerance)
    rings = [p for p in polys if len(p) >= 3]
    if not rings:
        return Polygon()
    shapely_polys = [Polygon(r) for r in rings]
    # Determine containment to build holes correctly rather than assuming
    # the first ring is always the outer boundary.
    shapely_polys.sort(key=lambda p: p.area, reverse=True)
    result = None
    for poly in shapely_polys:
        if result is None:
            result = poly
            continue
        if result.contains(poly.representative_point()):
            result = result.difference(poly)
        else:
            result = result.union(poly)
    return result


def _polygon_to_path(geom) -> Path:
    _require_shapely()
    path = Path()
    if geom.is_empty:
        return path
    geoms = list(geom.geoms) if isinstance(geom, MultiPolygon) else [geom]
    for poly in geoms:
        rings = [poly.exterior] + list(poly.interiors)
        for ring in rings:
            coords = list(ring.coords)
            if len(coords) < 2:
                continue
            path.move_to(*coords[0])
            for x, y in coords[1:-1]:
                path.line_to(x, y)
            path.close_path()
    path.fill_rule = "evenodd"
    return path


def union(*paths: Path, tolerance: float = 0.25) -> Path:
    _require_shapely()
    polys = [_path_to_polygon(p, tolerance) for p in paths]
    result = unary_union(polys)
    return _polygon_to_path(result)


def subtract(a: Path, b: Path, tolerance: float = 0.25) -> Path:
    _require_shapely()
    pa, pb = _path_to_polygon(a, tolerance), _path_to_polygon(b, tolerance)
    return _polygon_to_path(pa.difference(pb))


def intersect(a: Path, b: Path, tolerance: float = 0.25) -> Path:
    _require_shapely()
    pa, pb = _path_to_polygon(a, tolerance), _path_to_polygon(b, tolerance)
    return _polygon_to_path(pa.intersection(pb))


def xor(a: Path, b: Path, tolerance: float = 0.25) -> Path:
    _require_shapely()
    pa, pb = _path_to_polygon(a, tolerance), _path_to_polygon(b, tolerance)
    return _polygon_to_path(pa.symmetric_difference(pb))


def divide(a: Path, b: Path, tolerance: float = 0.25) -> List[Path]:
    """Split ``a`` by ``b`` into its pieces: (a - b) and (a & b) as separate paths."""
    return [subtract(a, b, tolerance), intersect(a, b, tolerance)]


def trim(a: Path, b: Path, tolerance: float = 0.25) -> Path:
    """Remove the portion of ``a`` that overlaps ``b`` (alias of subtract)."""
    return subtract(a, b, tolerance)


def merge(*paths: Path, tolerance: float = 0.25) -> Path:
    """Flatten overlapping shapes into a single compound path preserving
    all outlines (like union, but keeps coincident edges as a compound
    path rather than dissolving them) — for most practical purposes this
    matches union(); provided as a named spec operation (section 5)."""
    return union(*paths, tolerance=tolerance)
