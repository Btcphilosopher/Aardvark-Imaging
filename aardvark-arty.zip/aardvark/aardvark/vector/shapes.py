"""Parametric shape generator (spec section 8).

Every function here returns a :class:`~aardvark.vector.path.Path` built
purely from its parameters. Nothing here mutates state, so calling
``star(points=7, inner_radius=20, outer_radius=50)`` again with the same
arguments always regenerates the identical geometry — which is what lets
:mod:`aardvark.core.object` attach a ``generator`` dict (name + kwargs) to
an object and treat it as still-parametric rather than "baked" pixels or a
frozen point list (an object's ``regenerate()`` in
:mod:`aardvark.scripting.api` just calls the named function again).
"""
from __future__ import annotations

import math
from typing import List, Tuple

from .path import Path

Point = Tuple[float, float]


def circle(center: Point = (0, 0), radius: float = 50) -> Path:
    return ellipse(center=center, rx=radius, ry=radius)


def ellipse(center: Point = (0, 0), rx: float = 50, ry: float = 30) -> Path:
    cx, cy = center
    k = 0.5522847498307936  # 4/3 * (sqrt(2) - 1), the standard circle-Bezier constant
    p = Path()
    p.move_to(cx + rx, cy)
    p.curve_to((cx + rx, cy + ry * k), (cx + rx * k, cy + ry), (cx, cy + ry))
    p.curve_to((cx - rx * k, cy + ry), (cx - rx, cy + ry * k), (cx - rx, cy))
    p.curve_to((cx - rx, cy - ry * k), (cx - rx * k, cy - ry), (cx, cy - ry))
    p.curve_to((cx + rx * k, cy - ry), (cx + rx, cy - ry * k), (cx + rx, cy))
    p.close_path()
    return p


def rectangle(x: float = 0, y: float = 0, width: float = 100, height: float = 60) -> Path:
    p = Path()
    p.move_to(x, y)
    p.line_to(x + width, y)
    p.line_to(x + width, y + height)
    p.line_to(x, y + height)
    p.close_path()
    return p


def rounded_rectangle(
    x: float = 0, y: float = 0, width: float = 100, height: float = 60, radius: float = 12
) -> Path:
    r = min(radius, width / 2, height / 2)
    k = 0.5522847498307936 * r
    p = Path()
    p.move_to(x + r, y)
    p.line_to(x + width - r, y)
    p.curve_to((x + width - r + k, y), (x + width, y + r - k), (x + width, y + r))
    p.line_to(x + width, y + height - r)
    p.curve_to((x + width, y + height - r + k), (x + width - r + k, y + height), (x + width - r, y + height))
    p.line_to(x + r, y + height)
    p.curve_to((x + r - k, y + height), (x, y + height - r + k), (x, y + height - r))
    p.line_to(x, y + r)
    p.curve_to((x, y + r - k), (x + r - k, y), (x + r, y))
    p.close_path()
    return p


def polygon(center: Point = (0, 0), sides: int = 6, radius: float = 50, rotation: float = -90) -> Path:
    if sides < 3:
        raise ValueError("polygon requires at least 3 sides")
    cx, cy = center
    p = Path()
    for i in range(sides):
        angle = math.radians(rotation + 360 * i / sides)
        x, y = cx + radius * math.cos(angle), cy + radius * math.sin(angle)
        if i == 0:
            p.move_to(x, y)
        else:
            p.line_to(x, y)
    p.close_path()
    return p


def star(
    center: Point = (0, 0),
    points: int = 5,
    inner_radius: float = 20,
    outer_radius: float = 50,
    rotation: float = -90,
) -> Path:
    if points < 2:
        raise ValueError("star requires at least 2 points")
    cx, cy = center
    p = Path()
    total = points * 2
    for i in range(total):
        r = outer_radius if i % 2 == 0 else inner_radius
        angle = math.radians(rotation + 360 * i / total)
        x, y = cx + r * math.cos(angle), cy + r * math.sin(angle)
        if i == 0:
            p.move_to(x, y)
        else:
            p.line_to(x, y)
    p.close_path()
    return p


def ring(center: Point = (0, 0), inner_radius: float = 30, outer_radius: float = 50) -> Path:
    """Annulus: outer circle + reversed inner circle, evenodd-filled hole."""
    p = circle(center, outer_radius)
    inner = circle(center, inner_radius).reversed()
    p.append_path(inner)
    p.fill_rule = "evenodd"
    return p


def capsule(x: float = 0, y: float = 0, width: float = 120, height: float = 50) -> Path:
    """A rectangle with fully-rounded short ends (stadium shape)."""
    r = height / 2
    return rounded_rectangle(x, y, width, height, radius=r)


def spiral(
    center: Point = (0, 0),
    turns: float = 3.0,
    start_radius: float = 5.0,
    end_radius: float = 100.0,
    points_per_turn: int = 24,
) -> Path:
    cx, cy = center
    total_points = max(2, int(turns * points_per_turn))
    p = Path()
    for i in range(total_points + 1):
        t = i / total_points
        angle = 2 * math.pi * turns * t
        r = start_radius + (end_radius - start_radius) * t
        x, y = cx + r * math.cos(angle), cy + r * math.sin(angle)
        if i == 0:
            p.move_to(x, y)
        else:
            p.line_to(x, y)
    return p


def arc_shape(
    center: Point = (0, 0), radius: float = 50, start_deg: float = 0, end_deg: float = 90, close: bool = False
) -> Path:
    p = Path()
    p.arc(center[0], center[1], radius, start_deg, end_deg)
    if close:
        p.line_to(*center)
        p.close_path()
    return p


def grid(x: float = 0, y: float = 0, width: float = 400, height: float = 400, columns: int = 8, rows: int = 8) -> Path:
    """A grid of cell-boundary lines as one compound path (each line a subpath)."""
    p = Path()
    for c in range(columns + 1):
        gx = x + width * c / columns
        p.move_to(gx, y)
        p.line_to(gx, y + height)
    for r in range(rows + 1):
        gy = y + height * r / rows
        p.move_to(x, gy)
        p.line_to(x + width, gy)
    return p


def isometric_grid(
    x: float = 0, y: float = 0, width: float = 400, height: float = 400, cell: float = 40
) -> Path:
    """A grid of lines at -30/30/90 degrees approximating an isometric lattice."""
    p = Path()
    step_x = cell
    n_diag = int((width + height) / (step_x * math.cos(math.radians(30)))) + 2
    for i in range(-n_diag, n_diag):
        ox = x + i * step_x
        p.move_to(ox, y)
        p.line_to(ox + height / math.tan(math.radians(60)), y + height)
    for i in range(-n_diag, n_diag):
        ox = x + i * step_x
        p.move_to(ox, y)
        p.line_to(ox - height / math.tan(math.radians(60)), y + height)
    cols = int(width / cell) + 1
    for c in range(cols):
        gx = x + c * cell
        p.move_to(gx, y)
        p.line_to(gx, y + height)
    return p


def golden_rectangle(x: float = 0, y: float = 0, width: float = 100) -> Path:
    phi = (1 + math.sqrt(5)) / 2
    return rectangle(x, y, width, width / phi)


GENERATORS = {
    "circle": circle,
    "ellipse": ellipse,
    "rectangle": rectangle,
    "rounded_rectangle": rounded_rectangle,
    "polygon": polygon,
    "star": star,
    "ring": ring,
    "capsule": capsule,
    "spiral": spiral,
    "arc_shape": arc_shape,
    "grid": grid,
    "isometric_grid": isometric_grid,
    "golden_rectangle": golden_rectangle,
}
