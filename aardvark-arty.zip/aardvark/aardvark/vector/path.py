"""The vector engine: Path geometry, node model, and command construction
(spec sections 4 & 6).

Internally a Path is a list of subpaths. Each subpath is a list of
*segments* of two kinds:

* ``('L', (x, y))`` — a straight line to an anchor point
* ``('C', (x1, y1), (x2, y2), (x, y))`` — a cubic Bezier to an anchor
  point, with its two control points

The first entry of every subpath is always ``('M', (x, y))``. This is the
same normal form SVG path data reduces to, which makes the SVG bridge
(section 43) exact and loss-free, while still letting :class:`Node` expose
anchor/handle-level editing for a "node editor" (section 6).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from ..geometry import bezier as bz

Point = Tuple[float, float]


@dataclass
class Node:
    """A single editable anchor point with its Bezier handles.

    ``node_type`` is one of ``"corner"``, ``"smooth"`` (handles collinear,
    independent length) or ``"symmetric"`` (handles collinear and equal
    length) — section 6 of the spec.
    """

    anchor: Point
    in_handle: Optional[Point] = None  # absolute position of incoming control point
    out_handle: Optional[Point] = None  # absolute position of outgoing control point
    node_type: str = "corner"
    subpath_index: int = 0
    segment_index: int = 0

    def in_tangent(self) -> Optional[Point]:
        if self.in_handle is None:
            return None
        dx = self.anchor[0] - self.in_handle[0]
        dy = self.anchor[1] - self.in_handle[1]
        length = math.hypot(dx, dy)
        return (dx / length, dy / length) if length else None

    def out_tangent(self) -> Optional[Point]:
        if self.out_handle is None:
            return None
        dx = self.out_handle[0] - self.anchor[0]
        dy = self.out_handle[1] - self.anchor[1]
        length = math.hypot(dx, dy)
        return (dx / length, dy / length) if length else None

    def enforce_symmetry(self) -> None:
        """Update handles so the node satisfies its node_type constraint."""
        if self.node_type == "corner" or self.in_handle is None or self.out_handle is None:
            return
        ax, ay = self.anchor
        odx, ody = self.out_handle[0] - ax, self.out_handle[1] - ay
        out_len = math.hypot(odx, ody)
        if self.node_type == "symmetric":
            in_len = out_len
        else:  # smooth: independent lengths, shared direction
            idx0, idy0 = self.in_handle[0] - ax, self.in_handle[1] - ay
            in_len = math.hypot(idx0, idy0)
        if out_len < 1e-12:
            return
        ux, uy = odx / out_len, ody / out_len
        self.in_handle = (ax - ux * in_len, ay - uy * in_len)


class Path:
    """Mathematically serious vector path with a node-editable model."""

    def __init__(self):
        self.subpaths: List[list] = []
        self._current: Optional[list] = None
        self.closed_flags: List[bool] = []
        self.fill_rule: str = "nonzero"  # nonzero | evenodd

    # ------------------------------------------------------------------
    # Path construction commands (section 4)
    # ------------------------------------------------------------------
    def move_to(self, x: float, y: float) -> "Path":
        self._current = [("M", (float(x), float(y)))]
        self.subpaths.append(self._current)
        self.closed_flags.append(False)
        return self

    def line_to(self, x: float, y: float) -> "Path":
        self._require_current()
        self._current.append(("L", (float(x), float(y))))
        return self

    def curve_to(self, c1: Point, c2: Point, p: Point) -> "Path":
        self._require_current()
        self._current.append(("C", tuple(map(float, c1)), tuple(map(float, c2)), tuple(map(float, p))))
        return self

    def quad_to(self, c: Point, p: Point) -> "Path":
        self._require_current()
        p0 = self._current[-1][-1]
        _, c1, c2, p3 = bz.quadratic_to_cubic(p0, c, p)
        self._current.append(("C", c1, c2, p3))
        return self

    def arc_to(
        self, rx: float, ry: float, x_rotation: float, large_arc: bool, sweep: bool, x: float, y: float
    ) -> "Path":
        """SVG-style endpoint arc: arcs from the current point to (x, y)."""
        self._require_current()
        x0, y0 = self._current[-1][-1]
        params = bz.endpoint_arc_to_center(x0, y0, x, y, rx, ry, x_rotation, large_arc, sweep)
        if params is None:
            return self.line_to(x, y)
        cx, cy, rrx, rry, a0, a1, rot = params
        for p0, p1, p2, p3 in bz.arc_to_cubics(cx, cy, rrx, rry, a0, a1, rot):
            self._current.append(("C", p1, p2, p3))
        return self

    def arc(self, cx: float, cy: float, r: float, start_deg: float, end_deg: float) -> "Path":
        """Convenience: a full centre-parameterised circular arc as a new subpath."""
        a0, a1 = math.radians(start_deg), math.radians(end_deg)
        segs = bz.arc_to_cubics(cx, cy, r, r, a0, a1)
        if not segs:
            return self
        self.move_to(*segs[0][0])
        for p0, p1, p2, p3 in segs:
            self._current.append(("C", p1, p2, p3))
        return self

    def close_path(self) -> "Path":
        self._require_current()
        self.closed_flags[-1] = True
        return self

    def _require_current(self):
        if self._current is None:
            raise RuntimeError("Path.move_to() must be called before drawing commands")

    # ------------------------------------------------------------------
    # Node model (section 6)
    # ------------------------------------------------------------------
    def nodes(self) -> List[Node]:
        result: List[Node] = []
        for si, sub in enumerate(self.subpaths):
            n = len(sub)
            for i, seg in enumerate(sub):
                anchor = seg[-1]
                out_handle = None
                if i + 1 < n and sub[i + 1][0] == "C":
                    out_handle = sub[i + 1][1]
                elif i + 1 >= n and self.closed_flags[si] and n > 1 and sub[0][0] == "M":
                    first_after = sub[1] if len(sub) > 1 else None
                    if first_after and first_after[0] == "C":
                        out_handle = None  # wrap handled below for anchor 0 only
                in_handle = seg[1] if seg[0] == "C" else None
                node_type = "corner"
                if in_handle and out_handle:
                    t_in = Node(anchor, in_handle, out_handle).in_tangent()
                    t_out = Node(anchor, in_handle, out_handle).out_tangent()
                    if t_in and t_out:
                        cross = t_in[0] * t_out[1] - t_in[1] * t_out[0]
                        dot = t_in[0] * t_out[0] + t_in[1] * t_out[1]
                        if abs(cross) < 1e-3 and dot > 0:
                            node_type = "smooth"
                result.append(Node(anchor, in_handle, out_handle, node_type, si, i))
        return result

    def insert_node(self, subpath_index: int, segment_index: int, t: float = 0.5) -> None:
        """Split the segment at ``segment_index`` in subpath ``subpath_index`` at parameter t."""
        sub = self.subpaths[subpath_index]
        if segment_index <= 0 or segment_index >= len(sub):
            raise IndexError("segment_index out of range")
        prev_anchor = sub[segment_index - 1][-1]
        seg = sub[segment_index]
        if seg[0] == "L":
            mid = bz.lerp(prev_anchor, seg[1], t)
            sub[segment_index : segment_index + 1] = [("L", mid), ("L", seg[1])]
        else:
            _, c1, c2, p3 = seg
            left, right = bz.split_cubic(prev_anchor, c1, c2, p3, t)
            sub[segment_index : segment_index + 1] = [
                ("C", left[1], left[2], left[3]),
                ("C", right[1], right[2], right[3]),
            ]

    def delete_node(self, subpath_index: int, node_index: int) -> None:
        """Remove the anchor at ``node_index`` (0-based within the subpath), reconnecting
        its neighbours with a straight line."""
        sub = self.subpaths[subpath_index]
        if node_index == 0:
            if len(sub) > 1:
                sub.pop(1)
                sub[0] = ("M", sub[0][-1] if node_index else sub[1][-1] if len(sub) > 1 else sub[0][-1])
            return
        del sub[node_index]

    def convert_node(self, subpath_index: int, node_index: int, to: str) -> None:
        """Convert the segment ending at node_index between 'line' and 'curve'."""
        sub = self.subpaths[subpath_index]
        seg = sub[node_index]
        prev_anchor = sub[node_index - 1][-1] if node_index > 0 else seg[-1]
        if to == "curve" and seg[0] != "C":
            c1 = bz.lerp(prev_anchor, seg[-1], 1 / 3)
            c2 = bz.lerp(prev_anchor, seg[-1], 2 / 3)
            sub[node_index] = ("C", c1, c2, seg[-1])
        elif to == "line" and seg[0] != "L":
            sub[node_index] = ("L", seg[-1])

    # ------------------------------------------------------------------
    # Flattening / sampling
    # ------------------------------------------------------------------
    def to_polygons(self, tolerance: float = 0.25) -> List[List[Point]]:
        """Flatten to polygons (one per subpath) in local space."""
        polys: List[List[Point]] = []
        for sub in self.subpaths:
            pts: List[Point] = [sub[0][-1]]
            for seg in sub[1:]:
                if seg[0] == "L":
                    pts.append(seg[1])
                elif seg[0] == "C":
                    p0 = pts[-1]
                    pts.extend(bz.flatten_cubic(p0, seg[1], seg[2], seg[3], tolerance))
            polys.append(pts)
        return polys

    def bounds(self) -> Optional[Tuple[float, float, float, float]]:
        xs, ys = [], []
        for sub in self.subpaths:
            p0 = sub[0][-1]
            xs.append(p0[0])
            ys.append(p0[1])
            for seg in sub[1:]:
                if seg[0] == "L":
                    xs.append(seg[1][0])
                    ys.append(seg[1][1])
                else:
                    bx0, by0, bx1, by1 = bz.cubic_bbox(p0, seg[1], seg[2], seg[3])
                    xs.extend([bx0, bx1])
                    ys.extend([by0, by1])
                    p0 = seg[3]
        if not xs:
            return None
        return (min(xs), min(ys), max(xs), max(ys))

    def length(self, tolerance: float = 0.1) -> float:
        total = 0.0
        for sub in self.subpaths:
            p0 = sub[0][-1]
            for seg in sub[1:]:
                if seg[0] == "L":
                    total += math.hypot(seg[1][0] - p0[0], seg[1][1] - p0[1])
                    p0 = seg[1]
                else:
                    total += bz.cubic_length(p0, seg[1], seg[2], seg[3], tolerance)
                    p0 = seg[3]
        return total

    def point_at(self, distance: float, tolerance: float = 0.5):
        """Sample (point, tangent_normal_angle) at arclength ``distance`` along the path."""
        remaining = distance
        for sub in self.subpaths:
            p0 = sub[0][-1]
            for seg in sub[1:]:
                if seg[0] == "L":
                    seg_len = math.hypot(seg[1][0] - p0[0], seg[1][1] - p0[1])
                    if remaining <= seg_len:
                        t = remaining / seg_len if seg_len else 0
                        pt = bz.lerp(p0, seg[1], t)
                        angle = math.atan2(seg[1][1] - p0[1], seg[1][0] - p0[0])
                        return pt, angle
                    remaining -= seg_len
                    p0 = seg[1]
                else:
                    # Sample the cubic at fixed parametric steps and build a
                    # cumulative arclength table, then interpolate within
                    # the bracketing sample for the target distance.
                    samples = 40
                    ts = [i / samples for i in range(samples + 1)]
                    pts = [bz.cubic_point(p0, seg[1], seg[2], seg[3], t) for t in ts]
                    cum = [0.0]
                    for a, b in zip(pts, pts[1:]):
                        cum.append(cum[-1] + math.hypot(b[0] - a[0], b[1] - a[1]))
                    seg_len = cum[-1]
                    if remaining <= seg_len:
                        for i in range(samples):
                            if cum[i + 1] >= remaining:
                                span = cum[i + 1] - cum[i]
                                frac = (remaining - cum[i]) / span if span else 0.0
                                t = ts[i] + frac * (ts[i + 1] - ts[i])
                                pt = bz.cubic_point(p0, seg[1], seg[2], seg[3], t)
                                tx, ty = bz.cubic_tangent(p0, seg[1], seg[2], seg[3], t)
                                return pt, math.atan2(ty, tx)
                    remaining -= seg_len
                    p0 = seg[3]
        # past the end: return final point
        last_sub = self.subpaths[-1]
        return last_sub[-1][-1], 0.0

    # ------------------------------------------------------------------
    # Transform application (bakes a Transform into geometry — used by
    # boolean ops / export which need world-space coordinates)
    # ------------------------------------------------------------------
    def transformed(self, transform) -> "Path":
        new = Path()
        new.fill_rule = self.fill_rule
        for sub, closed in zip(self.subpaths, self.closed_flags):
            new_sub = []
            for seg in sub:
                if seg[0] == "M" or seg[0] == "L":
                    new_sub.append((seg[0], transform.apply(*seg[1])))
                else:
                    new_sub.append(
                        (
                            "C",
                            transform.apply(*seg[1]),
                            transform.apply(*seg[2]),
                            transform.apply(*seg[3]),
                        )
                    )
            new.subpaths.append(new_sub)
            new.closed_flags.append(closed)
        return new

    def reversed(self) -> "Path":
        """Return a new Path with subpath direction reversed (for compound paths / XOR fills)."""
        new = Path()
        new.fill_rule = self.fill_rule
        for sub, closed in zip(self.subpaths, self.closed_flags):
            anchors = [seg[-1] for seg in sub]
            rev_anchors = list(reversed(anchors))
            new_sub = [("M", rev_anchors[0])]
            idx = len(sub) - 1
            for i in range(1, len(rev_anchors)):
                seg = sub[idx]
                if seg[0] == "C":
                    new_sub.append(("C", seg[2], seg[1], rev_anchors[i]))
                else:
                    new_sub.append(("L", rev_anchors[i]))
                idx -= 1
            new.subpaths.append(new_sub)
            new.closed_flags.append(closed)
        return new

    def append_path(self, other: "Path") -> "Path":
        """Combine into a compound path (used by boolean results, text-as-path, etc.)."""
        self.subpaths.extend(other.subpaths)
        self.closed_flags.extend(other.closed_flags)
        return self

    def is_empty(self) -> bool:
        return len(self.subpaths) == 0

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------
    def to_dict(self) -> dict:
        return {
            "subpaths": self.subpaths,
            "closed": self.closed_flags,
            "fill_rule": self.fill_rule,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Path":
        p = cls()
        p.subpaths = [[tuple(seg) if not isinstance(seg, tuple) else seg for seg in sub] for sub in d["subpaths"]]
        # JSON round-trips tuples as lists; normalise back to tuples of tuples
        norm = []
        for sub in p.subpaths:
            nsub = []
            for seg in sub:
                kind = seg[0]
                pts = tuple(tuple(pt) for pt in seg[1:])
                nsub.append((kind, *pts))
            norm.append(nsub)
        p.subpaths = norm
        p.closed_flags = list(d["closed"])
        p.fill_rule = d.get("fill_rule", "nonzero")
        return p

    def copy(self) -> "Path":
        import copy as _copy

        return _copy.deepcopy(self)

    def __repr__(self):
        return f"<Path subpaths={len(self.subpaths)}>"
