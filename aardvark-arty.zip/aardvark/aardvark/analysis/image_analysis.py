"""Image analysis (spec sections 67-69): dominant colours, edges,
histogram, brightness/contrast, visual density, and segmentation, with
results usable to drive design generation or converted into masks/paths.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np

from ..colour.palette import AardPalette, extract_from_image
from ..raster.image import RasterImage


@dataclass
class ImageAnalysisReport:
    dominant_palette: AardPalette
    brightness: float
    contrast: float
    histogram: Dict[str, np.ndarray]
    edge_density: float


def histogram(image: RasterImage, bins: int = 32) -> Dict[str, np.ndarray]:
    arr = image.to_numpy("uint8")
    out = {}
    for i, ch in enumerate("rgb"):
        hist, _ = np.histogram(arr[..., i], bins=bins, range=(0, 255))
        out[ch] = hist
    luminance = (0.2126 * arr[..., 0] + 0.7152 * arr[..., 1] + 0.0722 * arr[..., 2]).astype(np.uint8)
    hist, _ = np.histogram(luminance, bins=bins, range=(0, 255))
    out["luminance"] = hist
    return out


def brightness_contrast(image: RasterImage) -> Tuple[float, float]:
    rgb = image.array[..., :3]
    luminance = 0.2126 * rgb[..., 0] + 0.7152 * rgb[..., 1] + 0.0722 * rgb[..., 2]
    return float(luminance.mean()), float(luminance.std())


def edge_map(image: RasterImage) -> np.ndarray:
    """Sobel-gradient-magnitude edge map, normalised to [0, 1]. Uses OpenCV
    if available for speed; falls back to a numpy Sobel convolution."""
    gray = (image.to_grayscale().array[..., 0] * 255).astype(np.uint8)
    try:
        import cv2

        gx = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
        gy = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)
    except ImportError:
        kx = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=np.float32)
        ky = kx.T
        gx = _convolve2d(gray.astype(np.float32), kx)
        gy = _convolve2d(gray.astype(np.float32), ky)
    mag = np.hypot(gx, gy)
    mx = mag.max()
    return (mag / mx if mx > 0 else mag).astype(np.float32)


def _convolve2d(img: np.ndarray, kernel: np.ndarray) -> np.ndarray:
    kh, kw = kernel.shape
    pad_h, pad_w = kh // 2, kw // 2
    padded = np.pad(img, ((pad_h, pad_h), (pad_w, pad_w)), mode="edge")
    out = np.zeros_like(img)
    for i in range(kh):
        for j in range(kw):
            out += kernel[i, j] * padded[i : i + img.shape[0], j : j + img.shape[1]]
    return out


def analyse(image: RasterImage, n_colours: int = 6) -> ImageAnalysisReport:
    palette = extract_from_image(image, n_colours=n_colours)
    brightness, contrast = brightness_contrast(image)
    edges = edge_map(image)
    return ImageAnalysisReport(
        dominant_palette=palette,
        brightness=brightness,
        contrast=contrast,
        histogram=histogram(image),
        edge_density=float((edges > 0.2).mean()),
    )


def segment_foreground(image: RasterImage, threshold: float = 0.5) -> np.ndarray:
    """A crude foreground/background split using GrabCut when OpenCV is
    available, else a saliency-free brightness/edge heuristic. Returns a
    (H, W) boolean foreground mask — good enough to drive a mask/path, not
    a substitute for a trained segmentation model."""
    try:
        import cv2

        arr = image.to_numpy("uint8")[..., :3]
        mask = np.zeros(arr.shape[:2], np.uint8)
        bgd_model = np.zeros((1, 65), np.float64)
        fgd_model = np.zeros((1, 65), np.float64)
        h, w = arr.shape[:2]
        rect = (int(w * 0.05), int(h * 0.05), int(w * 0.9), int(h * 0.9))
        cv2.grabCut(arr, mask, rect, bgd_model, fgd_model, 5, cv2.GC_INIT_WITH_RECT)
        return np.where((mask == cv2.GC_FGD) | (mask == cv2.GC_PR_FGD), True, False)
    except Exception:
        edges = edge_map(image)
        gray = image.to_grayscale().array[..., 0]
        centre_bias = _radial_falloff(gray.shape)
        score = edges * 0.6 + centre_bias * 0.4
        return score > threshold


def _radial_falloff(shape) -> np.ndarray:
    h, w = shape
    yy, xx = np.mgrid[0:h, 0:w]
    cy, cx = h / 2, w / 2
    dist = np.hypot(xx - cx, yy - cy) / np.hypot(cx, cy)
    return np.clip(1 - dist, 0, 1)
