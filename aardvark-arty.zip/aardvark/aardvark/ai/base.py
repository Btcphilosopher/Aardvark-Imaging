"""AI creative engine (spec sections 49-50): AI is an optional subsystem,
not the foundation. An :class:`AICreativeModel` turns a natural-language
(or structured) request into a *structured creative operation* — vectors,
masks, layouts, palettes, typography, composition proposals, or
procedural parameters — which is then applied to the Document as normal
AARD operations, so the artist stays in control and every AI-suggested
change is a plain, inspectable, undoable edit rather than a flattened
image.

No model ships here: :class:`AICreativeModel` is the interface a plugin
implements against a real provider. :class:`DesignAssistant` is the
higher-level, spec-section-50 surface ("make this composition more
balanced") that a caller wires up to a concrete model.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from ..core.object import AardObject


@dataclass
class CreativeOperation:
    """A structured, inspectable proposal — never raw pixels. ``kind`` is
    one of: 'palette', 'layout', 'composition_note', 'procedural_params',
    'typography', 'objects' (a list of ready-to-add AardObjects)."""

    kind: str
    payload: Any
    rationale: str = ""


class AICreativeModel:
    """Interface a plugin implements to back the AI subsystem with a real
    provider. Deliberately narrow: one method, structured in, structured
    out — see module docstring."""

    def propose(self, instruction: str, context: Dict[str, Any]) -> List[CreativeOperation]:
        raise NotImplementedError("Register a concrete AICreativeModel via a plugin to enable AI features.")


class NullModel(AICreativeModel):
    """The default model when none is configured: explains itself instead
    of silently doing nothing, so a caller who forgot to wire up a model
    gets a clear signal rather than mysterious no-ops."""

    def propose(self, instruction: str, context: Dict[str, Any]) -> List[CreativeOperation]:
        return [
            CreativeOperation(
                kind="composition_note",
                payload=(
                    "No AI model is configured. AARDVARK's AI subsystem is an optional "
                    "plugin surface (spec section 49) — register an AICreativeModel "
                    "(e.g. wrapping a real provider) to enable it."
                ),
                rationale="NullModel default",
            )
        ]


class DesignAssistant:
    """The conversational surface (spec section 50): ``ask()`` returns
    :class:`CreativeOperation` proposals; the caller decides whether/how to
    apply them to the Document, which keeps the artist in control."""

    def __init__(self, model: Optional[AICreativeModel] = None):
        self.model = model or NullModel()
        self.history: List[Dict[str, Any]] = []

    def ask(self, instruction: str, document=None, selection: Optional[List[AardObject]] = None) -> List[CreativeOperation]:
        context = {
            "document_name": getattr(document, "name", None) if document is not None else None,
            "selection_ids": [o.id for o in selection] if selection else [],
        }
        operations = self.model.propose(instruction, context)
        self.history.append({"instruction": instruction, "operations": operations})
        return operations

    def apply(self, operation: CreativeOperation, target_artboard=None) -> None:
        """Apply a CreativeOperation of kind 'objects' to a document
        artboard as normal AardObjects; other kinds are advisory (palette/
        layout/typography/composition_note) and left for the caller to
        interpret, since applying those safely is context-specific."""
        if operation.kind == "objects" and target_artboard is not None:
            for obj in operation.payload:
                target_artboard.add(obj)
