"""Font resolution.

AARDVARK doesn't bundle fonts; it searches common OS font directories for
a family name and caches the result, and lets a script register an
explicit path. If nothing can be found, rendering falls back to Pillow's
built-in bitmap font so text objects still rasterize (at reduced fidelity)
rather than raising a hard error mid-render.
"""
from __future__ import annotations

import os
from functools import lru_cache
from typing import Optional

_SEARCH_ROOTS = [
    "/usr/share/fonts",
    "/usr/local/share/fonts",
    os.path.expanduser("~/.fonts"),
    os.path.expanduser("~/Library/Fonts"),
    "/Library/Fonts",
    "/System/Library/Fonts",
    "C:\\Windows\\Fonts",
]

_registered: dict[str, str] = {}


def register_font(family: str, path: str) -> None:
    """Explicitly associate a family name with a font file path."""
    _registered[family.lower()] = path


@lru_cache(maxsize=1)
def _index_system_fonts() -> dict:
    """Walk the search roots once and index basename (without extension,
    lowercased, spaces stripped) -> full path, for .ttf/.otf/.ttc files."""
    index: dict[str, str] = {}
    for root in _SEARCH_ROOTS:
        if not os.path.isdir(root):
            continue
        for dirpath, _dirs, files in os.walk(root):
            for f in files:
                lower = f.lower()
                if lower.endswith((".ttf", ".otf", ".ttc")):
                    key = os.path.splitext(lower)[0].replace(" ", "").replace("-", "")
                    index.setdefault(key, os.path.join(dirpath, f))
    return index


def find_font_path(family: str, weight: str = "regular", italic: bool = False) -> Optional[str]:
    key = family.lower()
    if key in _registered:
        return _registered[key]

    index = _index_system_fonts()
    normalized_family = family.lower().replace(" ", "").replace("-", "")
    weight_tokens = [weight.lower()] if weight else []
    candidates = []
    suffix = ("italic" if italic else "") + (weight.lower() if weight and weight.lower() != "regular" else "")
    for candidate_suffix in filter(None, [normalized_family + suffix, normalized_family + weight.lower() if weight else None, normalized_family]):
        if candidate_suffix in index:
            return index[candidate_suffix]
    for indexed_key, path in index.items():
        if indexed_key.startswith(normalized_family):
            candidates.append((indexed_key, path))
    if not candidates:
        return None
    # Prefer a match whose remaining suffix best reflects the requested style.
    def score(item):
        k, _p = item
        rest = k[len(normalized_family):]
        s = 0
        if italic and "italic" in rest:
            s += 2
        if not italic and "italic" not in rest and "oblique" not in rest:
            s += 1
        if weight and weight.lower() in rest:
            s += 2
        if rest == "":
            s += 1
        return s

    candidates.sort(key=score, reverse=True)
    return candidates[0][1]


def load_font(family: str, size: int, weight: str = "regular", italic: bool = False):
    from PIL import ImageFont

    path = find_font_path(family, weight, italic)
    if path:
        try:
            return ImageFont.truetype(path, size=size)
        except Exception:
            pass
    try:
        return ImageFont.load_default(size=size)
    except TypeError:
        # Older Pillow: load_default() takes no size argument.
        return ImageFont.load_default()
