"""Typography engine (spec sections 19-20): TextObject, TextFrame,
GlyphRun, CharacterStyle, ParagraphStyle, text-on-path.

Glyph shaping here is advance-width based (Pillow/FreeType metrics), not a
full HarfBuzz shaping pipeline — kerning uses Pillow's per-pair advance
where the font provides it, but complex-script shaping, ligature
substitution and OpenType feature tags (``liga``, ``smcp``, ``onum``, ...)
are accepted on :class:`CharacterStyle` as metadata and forwarded to the
font engine when Pillow/FreeType honours them, rather than implemented
from scratch. This is documented explicitly rather than silently
pretended-away.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from ..colour.colour import AardColour
from . import fonts as _fonts


@dataclass
class CharacterStyle:
    family: str = "DejaVu Sans"
    weight: str = "regular"
    italic: bool = False
    size: float = 24.0
    tracking: float = 0.0  # extra space between characters, in px
    colour: AardColour = field(default_factory=lambda: AardColour(0, 0, 0))
    opentype_features: dict = field(default_factory=dict)  # e.g. {"liga": True, "smcp": True}
    small_caps: bool = False
    numeral_style: str = "default"  # default | oldstyle | tabular

    def to_dict(self):
        return {
            "family": self.family,
            "weight": self.weight,
            "italic": self.italic,
            "size": self.size,
            "tracking": self.tracking,
            "colour": self.colour.to_dict(),
            "opentype_features": self.opentype_features,
            "small_caps": self.small_caps,
            "numeral_style": self.numeral_style,
        }


@dataclass
class ParagraphStyle:
    alignment: str = "left"  # left | center | right | justify
    leading: Optional[float] = None  # line height in px; None = 1.2 * size
    space_before: float = 0.0
    space_after: float = 0.0
    columns: int = 1
    column_gutter: float = 16.0

    def to_dict(self):
        return {
            "alignment": self.alignment,
            "leading": self.leading,
            "space_before": self.space_before,
            "space_after": self.space_after,
            "columns": self.columns,
            "column_gutter": self.column_gutter,
        }


@dataclass
class GlyphInstance:
    char: str
    position: Tuple[float, float]
    rotation: float = 0.0
    style: Optional[CharacterStyle] = None


class GlyphRun:
    """A resolved run of positioned glyphs ready for rendering."""

    def __init__(self, glyphs: List[GlyphInstance]):
        self.glyphs = glyphs

    def bounds(self):
        if not self.glyphs:
            return None
        xs = [g.position[0] for g in self.glyphs]
        ys = [g.position[1] for g in self.glyphs]
        return (min(xs), min(ys), max(xs), max(ys))


@dataclass
class TextFrame:
    """A rectangular container that a :class:`TextObject` flows into
    (spec section 19). Distinct from the text run itself so the same
    content can be re-flowed into a different frame (e.g. responsive
    layout, spec section 60) without rebuilding character styling."""

    width: float
    height: float
    columns: int = 1
    column_gutter: float = 16.0
    padding: float = 0.0

    def inner_width(self) -> float:
        if self.columns <= 1:
            return self.width - 2 * self.padding
        total_gutter = self.column_gutter * (self.columns - 1)
        return (self.width - 2 * self.padding - total_gutter) / self.columns


class TextObject:
    """A text run laid out either in a rectangular frame or along a Path."""

    def __init__(
        self,
        content: str,
        character_style: Optional[CharacterStyle] = None,
        paragraph_style: Optional[ParagraphStyle] = None,
        frame_width: Optional[float] = None,
        frame_height: Optional[float] = None,
        path=None,
        path_offset: float = 0.0,
    ):
        self.content = content
        self.character_style = character_style or CharacterStyle()
        self.paragraph_style = paragraph_style or ParagraphStyle()
        self.frame_width = frame_width
        self.frame_height = frame_height
        self.path = path  # a vector.path.Path to lay text along, or None
        self.path_offset = path_offset

    def resolve_font(self, style: CharacterStyle):
        return _fonts.load_font(style.family, int(round(style.size)), style.weight, style.italic)

    def _advance(self, ch: str, style: CharacterStyle, font) -> float:
        try:
            width = font.getlength(ch)
        except AttributeError:
            width = font.getsize(ch)[0]
        return width + style.tracking

    def layout_lines(self) -> List[str]:
        """Word-wrap ``content`` to ``frame_width`` if set; otherwise one line per '\\n'."""
        if self.frame_width is None:
            return self.content.split("\n")
        font = self.resolve_font(self.character_style)
        lines: List[str] = []
        for paragraph in self.content.split("\n"):
            words = paragraph.split(" ")
            current = ""
            for word in words:
                trial = (current + " " + word).strip()
                width = sum(self._advance(c, self.character_style, font) for c in trial)
                if width > self.frame_width and current:
                    lines.append(current)
                    current = word
                else:
                    current = trial
            lines.append(current)
        return lines

    def shape(self) -> GlyphRun:
        """Resolve character positions, producing a GlyphRun. If ``self.path``
        is set, lays glyphs along the path (spec section 20: text on path);
        otherwise lays out within the rectangular frame with the configured
        alignment (spec section 19-21)."""
        style = self.character_style
        font = self.resolve_font(style)
        leading = self.paragraph_style.leading or style.size * 1.2

        text = self.content.upper() if style.small_caps else self.content

        if self.path is not None:
            glyphs = []
            cursor = self.path_offset
            for ch in text:
                adv = self._advance(ch, style, font)
                pt, angle = self.path.point_at(cursor + adv / 2)
                glyphs.append(GlyphInstance(ch, pt, math.degrees(angle), style))
                cursor += adv
            return GlyphRun(glyphs)

        lines = self.layout_lines()
        glyphs = []
        y = style.size
        for line in lines:
            widths = [self._advance(c, style, font) for c in line]
            total_width = sum(widths)
            if self.paragraph_style.alignment == "center" and self.frame_width:
                x = (self.frame_width - total_width) / 2
            elif self.paragraph_style.alignment == "right" and self.frame_width:
                x = self.frame_width - total_width
            else:
                x = 0.0
            extra_gap = 0.0
            if self.paragraph_style.alignment == "justify" and self.frame_width and len(line) > 1:
                extra_gap = max(0.0, (self.frame_width - total_width) / max(1, line.count(" ")))
            for ch, w in zip(line, widths):
                glyphs.append(GlyphInstance(ch, (x, y), 0.0, style))
                x += w + (extra_gap if ch == " " else 0.0)
            y += leading
        return GlyphRun(glyphs)

    def bounds(self):
        run = self.shape()
        b = run.bounds()
        if b is None:
            return (0, 0, 0, 0)
        minx, miny, maxx, maxy = b
        pad = self.character_style.size
        return (minx, miny - pad, maxx + pad, maxy + pad * 0.3)

    def to_dict(self) -> dict:
        return {
            "content": self.content,
            "character_style": self.character_style.to_dict(),
            "paragraph_style": self.paragraph_style.to_dict(),
            "frame_width": self.frame_width,
            "frame_height": self.frame_height,
            "path_offset": self.path_offset,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "TextObject":
        cs = CharacterStyle(
            **{**d["character_style"], "colour": AardColour.from_dict(d["character_style"]["colour"])}
        )
        ps = ParagraphStyle(**d["paragraph_style"])
        return cls(d["content"], cs, ps, d.get("frame_width"), d.get("frame_height"), None, d.get("path_offset", 0.0))
