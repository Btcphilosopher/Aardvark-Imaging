"""Design system & tokens engine (spec sections 22 & 59): reusable colour,
typographic, spacing, radius, shadow and grid tokens plus components,
bundled into a brand-level :class:`DesignSystem`. Changing a token
propagates to every object that references it (spec: "Changing a token
should update all dependent objects") because objects don't copy the
token's value — they hold a :class:`TokenRef` that resolves against the
system at render/access time.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional


@dataclass
class TokenRef:
    """A live reference to a named token — resolve with ``ref.get(system)``
    rather than reading a frozen value, so token edits propagate."""

    name: str
    category: str = "colour"  # colour | type | spacing | radius | shadow | grid

    def get(self, system: "DesignSystem") -> Any:
        return system.resolve(self.category, self.name)


@dataclass
class Component:
    """A reusable design element: geometry/style/parameters template plus
    child components, instantiable many times from one shared definition
    (spec section 61)."""

    name: str
    build: Callable[..., Any]  # (design_system, **params) -> AardObject
    default_params: Dict[str, Any] = field(default_factory=dict)
    children: List["Component"] = field(default_factory=list)

    def instantiate(self, system: "DesignSystem", **overrides):
        params = {**self.default_params, **overrides}
        return self.build(system, **params)


class DesignSystem:
    def __init__(self, name: str = "Brand"):
        self.name = name
        self.tokens: Dict[str, Dict[str, Any]] = {
            "colour": {},
            "type": {},
            "spacing": {},
            "radius": {},
            "shadow": {},
            "grid": {},
        }
        self.components: Dict[str, Component] = {}
        self._listeners: List[Callable[[str, str, Any], None]] = []

    # ------------------------------------------------------------------
    def set_token(self, category: str, name: str, value: Any) -> TokenRef:
        if category not in self.tokens:
            raise ValueError(f"Unknown token category {category!r}; choose from {list(self.tokens)}")
        self.tokens[category][name] = value
        for listener in self._listeners:
            listener(category, name, value)
        return TokenRef(name, category)

    def resolve(self, category: str, name: str) -> Any:
        try:
            return self.tokens[category][name]
        except KeyError:
            raise KeyError(f"No {category} token named {name!r} in design system {self.name!r}")

    def on_token_change(self, listener: Callable[[str, str, Any], None]) -> None:
        """Register a callback ``(category, name, value)`` invoked whenever
        a token changes, so a scene-graph binding layer can re-resolve and
        redraw dependent objects."""
        self._listeners.append(listener)

    def register_component(self, component: Component) -> None:
        self.components[component.name] = component

    def instantiate(self, component_name: str, **params):
        return self.components[component_name].instantiate(self, **params)

    # ------------------------------------------------------------------
    def colour_tokens(self, mapping: Dict[str, Any]) -> Dict[str, TokenRef]:
        return {name: self.set_token("colour", name, value) for name, value in mapping.items()}

    def type_tokens(self, mapping: Dict[str, Any]) -> Dict[str, TokenRef]:
        return {name: self.set_token("type", name, value) for name, value in mapping.items()}

    def spacing_scale(self, base: float = 4.0, steps: int = 8, ratio: float = 1.5) -> Dict[str, TokenRef]:
        out = {}
        value = base
        for i in range(steps):
            out[f"space-{i}"] = self.set_token("spacing", f"space-{i}", round(value, 2))
            value *= ratio
        return out

    def to_dict(self) -> dict:
        def enc(v):
            return v.to_dict() if hasattr(v, "to_dict") else v

        return {
            "name": self.name,
            "tokens": {cat: {k: enc(v) for k, v in vals.items()} for cat, vals in self.tokens.items()},
        }
