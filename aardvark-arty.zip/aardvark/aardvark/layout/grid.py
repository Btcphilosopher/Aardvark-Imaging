"""Grid & layout engine (spec sections 21 & 24): the grid is itself an
object with columns/rows/margins/gutters, plus baseline, golden-ratio,
modular-scale, isometric, polar and perspective variants.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Tuple

Point = Tuple[float, float]


@dataclass
class ColumnGrid:
    x: float
    y: float
    width: float
    height: float
    columns: int = 12
    gutter: float = 20.0
    margin: float = 40.0

    def column_bounds(self) -> List[Tuple[float, float]]:
        """Returns [(x0, x1), ...] for each column, in absolute coordinates."""
        inner_x = self.x + self.margin
        inner_w = self.width - 2 * self.margin
        col_w = (inner_w - self.gutter * (self.columns - 1)) / self.columns
        bounds = []
        for i in range(self.columns):
            x0 = inner_x + i * (col_w + self.gutter)
            bounds.append((x0, x0 + col_w))
        return bounds

    def column_x(self, index: int) -> float:
        return self.column_bounds()[index][0]


@dataclass
class BaselineGrid:
    y: float
    height: float
    line_height: float = 24.0

    def lines(self) -> List[float]:
        n = int(self.height // self.line_height)
        return [self.y + i * self.line_height for i in range(n + 1)]

    def snap(self, y: float) -> float:
        return self.y + round((y - self.y) / self.line_height) * self.line_height


@dataclass
class PolarGrid:
    center: Point
    radial_divisions: int = 8
    angular_divisions: int = 12
    max_radius: float = 200.0

    def rings(self) -> List[float]:
        return [self.max_radius * (i + 1) / self.radial_divisions for i in range(self.radial_divisions)]

    def spokes(self) -> List[float]:
        return [360.0 * i / self.angular_divisions for i in range(self.angular_divisions)]

    def points(self) -> List[Point]:
        pts = []
        for r in self.rings():
            for a in self.spokes():
                rad = math.radians(a)
                pts.append((self.center[0] + r * math.cos(rad), self.center[1] + r * math.sin(rad)))
        return pts


GOLDEN_RATIO = (1 + math.sqrt(5)) / 2


def modular_scale(base: float, ratio: float = GOLDEN_RATIO, steps: int = 8, start: int = -2) -> List[float]:
    """A typographic modular scale: base * ratio**n for n in [start, start+steps)."""
    return [base * (ratio ** n) for n in range(start, start + steps)]


def golden_section(x: float, y: float, width: float, height: float, vertical_first: bool = True):
    """Split a rectangle at the golden ratio; returns (rect_a, rect_b) as
    (x, y, w, h) tuples, the classic recursive golden-rectangle construction."""
    if vertical_first:
        split = width / GOLDEN_RATIO
        return (x, y, split, height), (x + split, y, width - split, height)
    split = height / GOLDEN_RATIO
    return (x, y, width, split), (x, y + split, width, height - split)


def golden_spiral_rects(x: float, y: float, width: float, height: float, iterations: int = 8):
    """Recursive golden-section subdivision, alternating orientation —
    yields (x, y, w, h) rectangles whose corners trace the classic golden
    spiral construction."""
    rects = []
    rect = (x, y, width, height)
    vertical = True
    for _ in range(iterations):
        a, b = golden_section(*rect, vertical_first=vertical)
        rects.append(a)
        rect = b
        vertical = not vertical
    rects.append(rect)
    return rects


@dataclass
class IsometricGrid:
    x: float
    y: float
    width: float
    height: float
    cell: float = 40.0

    def to_screen(self, iso_x: float, iso_y: float) -> Point:
        """Convert isometric (col, row) lattice coordinates to screen space."""
        sx = self.x + (iso_x - iso_y) * self.cell * math.cos(math.radians(30))
        sy = self.y + (iso_x + iso_y) * self.cell * math.sin(math.radians(30))
        return (sx, sy)


@dataclass
class PerspectiveGrid:
    """A simple 1-point perspective grid: a vanishing point plus a ground
    line, generating converging guide lines useful for architectural/
    technical drawing (spec section 70)."""

    vanishing_point: Point
    horizon_y: float
    ground_points: List[float] = field(default_factory=list)  # x positions along a foreground baseline
    baseline_y: float = 0.0

    def lines(self) -> List[Tuple[Point, Point]]:
        return [(self.vanishing_point, (gx, self.baseline_y)) for gx in self.ground_points]
