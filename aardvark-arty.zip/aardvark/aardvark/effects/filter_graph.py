"""Node-based effects system (spec section 27): IMAGE -> COLOUR -> BLUR ->
MASK -> DISTORT -> BLEND -> OUTPUT, expressed as a small DAG of
:class:`FilterNode` objects rather than a hard-coded pipeline, so nodes
can be reordered, branched, or reused across multiple outputs.
"""
from __future__ import annotations

from typing import Callable, Dict, List, Optional

from ..raster.image import RasterImage
from ..raster.layer import composite
from ..core.object import BlendMode
from . import effects as fx


class FilterNode:
    def __init__(self, name: str, fn: Callable[..., RasterImage], **params):
        self.name = name
        self.fn = fn
        self.params = params
        self.inputs: List["FilterNode"] = []

    def connect(self, *nodes: "FilterNode") -> "FilterNode":
        self.inputs.extend(nodes)
        return self

    def evaluate(self, source: RasterImage, _cache: Optional[Dict[int, RasterImage]] = None) -> RasterImage:
        cache = {} if _cache is None else _cache
        if id(self) in cache:
            return cache[id(self)]
        if self.inputs:
            resolved = [n.evaluate(source, cache) for n in self.inputs]
            result = self.fn(*resolved, **self.params)
        else:
            result = self.fn(source, **self.params)
        cache[id(self)] = result
        return result


# ----------------------------------------------------------------------
# Convenience node constructors for the built-in library
# ----------------------------------------------------------------------
def blur_node(radius: float = 6.0) -> FilterNode:
    return FilterNode("blur", fx.gaussian_blur, radius=radius)


def sharpen_node(amount: float = 1.0) -> FilterNode:
    return FilterNode("sharpen", fx.sharpen, amount=amount)


def grain_node(amount: float = 0.08, seed: int = 0) -> FilterNode:
    return FilterNode("grain", fx.grain, amount=amount, seed=seed)


def colourise_node(colour, strength: float = 1.0) -> FilterNode:
    return FilterNode("colourise", fx.colourise, colour=colour, strength=strength)


def outline_node(thickness: int = 2, colour=None) -> FilterNode:
    from ..colour.colour import AardColour

    return FilterNode("outline", fx.outline, thickness=thickness, colour=colour or AardColour(0, 0, 0))


def shadow_node(offset=(6, 6), blur=8.0, colour=None) -> FilterNode:
    from ..colour.colour import AardColour

    return FilterNode("drop_shadow", fx.drop_shadow, offset=offset, blur=blur, colour=colour or AardColour(0, 0, 0, 0.6))


def swirl_node(strength: float = 2.0, radius: Optional[float] = None) -> FilterNode:
    return FilterNode("warp_swirl", fx.warp_swirl, strength=strength, radius=radius)


def _blend_fn(a: RasterImage, b: RasterImage, mode: BlendMode = BlendMode.NORMAL, opacity: float = 1.0) -> RasterImage:
    return composite(a, b, mode, opacity)


def blend_node(mode: BlendMode = BlendMode.NORMAL, opacity: float = 1.0) -> FilterNode:
    """A 2-input node: connect(backdrop_node, source_node)."""
    node = FilterNode("blend", _blend_fn, mode=mode, opacity=opacity)
    return node


class FilterGraph:
    """A named collection of nodes with one designated output, for reuse
    across multiple source images."""

    def __init__(self, output: FilterNode):
        self.output = output

    def run(self, source: RasterImage) -> RasterImage:
        return self.output.evaluate(source)
