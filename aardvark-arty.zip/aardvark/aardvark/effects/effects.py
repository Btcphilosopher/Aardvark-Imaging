"""Non-destructive effects engine (spec section 28): shadow, glow,
outline, bevel, emboss, blur, distortion, grain, light, colourisation.

Every effect here is a pure function ``RasterImage -> RasterImage`` (or
takes extra parameters and returns a new image), so applying an effect
never mutates the input — "non-destructive" in the sense that the caller
keeps the original and can re-apply the effect chain with different
parameters at any time (spec's Filter Graph, section 27, composes these
functions as nodes).
"""
from __future__ import annotations

import math
from typing import Tuple

import numpy as np
from PIL import Image, ImageFilter, ImageChops

from ..colour.colour import AardColour
from ..raster.image import RasterImage


def gaussian_blur(image: RasterImage, radius: float) -> RasterImage:
    img = image.to_pil().filter(ImageFilter.GaussianBlur(radius))
    return RasterImage.from_pil(img)


def sharpen(image: RasterImage, amount: float = 1.0) -> RasterImage:
    img = image.to_pil().filter(ImageFilter.UnsharpMask(radius=2, percent=int(150 * amount), threshold=2))
    return RasterImage.from_pil(img)


def grain(image: RasterImage, amount: float = 0.08, seed: int = 0) -> RasterImage:
    rng = np.random.default_rng(seed)
    noise = rng.normal(0, amount, size=image.array.shape[:2])
    out = image.array.copy()
    for c in range(3):
        out[..., c] = np.clip(out[..., c] + noise, 0, 1)
    return RasterImage(out, image.bit_depth, image.colour_space)


def outline(image: RasterImage, thickness: int = 2, colour: AardColour = AardColour(0, 0, 0)) -> RasterImage:
    alpha = image.array[..., 3]
    mask = Image.fromarray((alpha * 255).astype(np.uint8), mode="L")
    dilated = mask.filter(ImageFilter.MaxFilter(2 * thickness + 1))
    ring = ImageChops.subtract(dilated, mask)
    ring_arr = np.asarray(ring).astype(np.float32) / 255.0
    out = image.array.copy()
    out_colour = np.array([colour.r, colour.g, colour.b])
    ring_a = ring_arr * colour.a
    existing_a = out[..., 3]
    combined_a = ring_a + existing_a * (1 - ring_a)
    safe = np.where(combined_a > 1e-6, combined_a, 1.0)
    out[..., :3] = (out_colour * ring_a[..., None] + out[..., :3] * existing_a[..., None] * (1 - ring_a[..., None])) / safe[..., None]
    out[..., 3] = combined_a
    return RasterImage(out, image.bit_depth, image.colour_space)


def drop_shadow(
    image: RasterImage, offset: Tuple[float, float] = (6, 6), blur: float = 8.0, colour: AardColour = AardColour(0, 0, 0, 0.6), spread: int = 0
) -> RasterImage:
    """Returns a new, larger canvas containing the shadow composited behind the source."""
    ox, oy = offset
    pad = int(math.ceil(blur * 3 + abs(ox) + abs(oy) + spread + 4))
    w, h = image.width + pad * 2, image.height + pad * 2
    shadow_alpha = Image.fromarray((image.array[..., 3] * 255).astype(np.uint8), mode="L")
    if spread > 0:
        shadow_alpha = shadow_alpha.filter(ImageFilter.MaxFilter(2 * spread + 1))
    canvas_a = Image.new("L", (w, h), 0)
    canvas_a.paste(shadow_alpha, (pad + int(ox), pad + int(oy)))
    canvas_a = canvas_a.filter(ImageFilter.GaussianBlur(blur))
    a_arr = (np.asarray(canvas_a).astype(np.float32) / 255.0) * colour.a

    out = np.zeros((h, w, 4), dtype=np.float32)
    out[..., 0] = colour.r
    out[..., 1] = colour.g
    out[..., 2] = colour.b
    out[..., 3] = a_arr

    shadow_layer = RasterImage(out)
    shadow_layer.paste(image, pad, pad)
    return shadow_layer


def outer_glow(image: RasterImage, radius: float = 12.0, colour: AardColour = AardColour(1, 1, 0.6, 0.9), intensity: float = 1.0) -> RasterImage:
    layer = drop_shadow(image, offset=(0, 0), blur=radius, colour=colour.with_alpha(colour.a * intensity))
    return layer


def bevel_emboss(image: RasterImage, depth: float = 3.0, angle_deg: float = 135.0, blur: float = 3.0) -> RasterImage:
    """Simulated bevel using a Sobel-style gradient of the blurred alpha as
    a pseudo height-field, lit from ``angle_deg``."""
    alpha = image.array[..., 3]
    blurred = np.asarray(Image.fromarray((alpha * 255).astype(np.uint8), "L").filter(ImageFilter.GaussianBlur(blur))).astype(np.float32) / 255.0
    gy, gx = np.gradient(blurred * depth)
    angle = math.radians(angle_deg)
    light = np.array([math.cos(angle), math.sin(angle), 1.0])
    light = light / np.linalg.norm(light)
    normals = np.stack([-gx, -gy, np.ones_like(gx)], axis=-1)
    normals /= np.linalg.norm(normals, axis=-1, keepdims=True) + 1e-9
    shade = np.clip(np.tensordot(normals, light, axes=([2], [0])), 0, 1)
    out = image.array.copy()
    out[..., :3] = np.clip(out[..., :3] * (0.5 + shade[..., None] * 0.7), 0, 1)
    return RasterImage(out, image.bit_depth, image.colour_space)


def colourise(image: RasterImage, colour: AardColour, strength: float = 1.0) -> RasterImage:
    gray = image.to_grayscale().array
    tinted = gray.copy()
    tinted[..., 0] = gray[..., 0] * colour.r
    tinted[..., 1] = gray[..., 1] * colour.g
    tinted[..., 2] = gray[..., 2] * colour.b
    out = image.array * (1 - strength) + tinted * strength
    out[..., 3] = image.array[..., 3]
    return RasterImage(out, image.bit_depth, image.colour_space)


def distort_displacement(image: RasterImage, displacement_map: np.ndarray, strength: float = 20.0) -> RasterImage:
    """Displace pixels by a (H, W) or (H, W, 2) map in [-1, 1] * strength px."""
    h, w = image.height, image.width
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    if displacement_map.ndim == 2:
        dx = dy = displacement_map
    else:
        dx, dy = displacement_map[..., 0], displacement_map[..., 1]
    src_x = np.clip(xx + dx * strength, 0, w - 1).astype(np.int32)
    src_y = np.clip(yy + dy * strength, 0, h - 1).astype(np.int32)
    out = image.array[src_y, src_x]
    return RasterImage(out, image.bit_depth, image.colour_space)


def warp_swirl(image: RasterImage, strength: float = 2.0, radius: float | None = None) -> RasterImage:
    h, w = image.height, image.width
    cx, cy = w / 2, h / 2
    radius = radius or min(cx, cy)
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    dx, dy = xx - cx, yy - cy
    dist = np.hypot(dx, dy)
    factor = np.clip(1 - dist / radius, 0, 1)
    angle = strength * factor ** 2
    cos_a, sin_a = np.cos(angle), np.sin(angle)
    src_x = cx + dx * cos_a - dy * sin_a
    src_y = cy + dx * sin_a + dy * cos_a
    src_x = np.clip(src_x, 0, w - 1).astype(np.int32)
    src_y = np.clip(src_y, 0, h - 1).astype(np.int32)
    out = image.array[src_y, src_x]
    return RasterImage(out, image.bit_depth, image.colour_space)
