"""Data-driven graphics (spec section 34): bind a dataset's columns to
visual properties (position, size, colour, rotation, opacity, shape) and
produce AardObjects — generative posters, infographics, statistical art,
maps, financial visualisations, architectural diagrams.
"""
from __future__ import annotations

import csv
import json
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from ..colour.colour import AardColour
from ..colour.gradient import AardGradient
from ..core.object import AardObject, AardObjectType
from ..vector import shapes


def load_csv(path: str) -> List[Dict[str, Any]]:
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        rows = []
        for row in reader:
            parsed = {}
            for k, v in row.items():
                parsed[k] = _coerce(v)
            rows.append(parsed)
        return rows


def load_json(path: str) -> List[Dict[str, Any]]:
    with open(path) as f:
        data = json.load(f)
    if isinstance(data, dict):
        # Accept either a list-of-records document, or a {"records": [...]}-shaped one.
        data = data.get("records", [data])
    return data


def load_dataframe(df) -> List[Dict[str, Any]]:
    """Accepts a pandas DataFrame (spec section 34: Pandas integration)."""
    return df.to_dict(orient="records")


def _coerce(value: str):
    if value is None or value == "":
        return None
    for caster in (int, float):
        try:
            return caster(value)
        except (TypeError, ValueError):
            continue
    return value


@dataclass
class Scale:
    """Maps a data value to a visual range, linearly by default."""

    domain: tuple
    range: tuple
    clamp: bool = True

    def __call__(self, value: float) -> float:
        d0, d1 = self.domain
        r0, r1 = self.range
        if d1 == d0:
            t = 0.0
        else:
            t = (value - d0) / (d1 - d0)
        if self.clamp:
            t = max(0.0, min(1.0, t))
        return r0 + t * (r1 - r0)

    @classmethod
    def from_data(cls, values, range: tuple, clamp: bool = True) -> "Scale":
        values = [v for v in values if v is not None]
        return cls((min(values), max(values)), range, clamp)


@dataclass
class DataBinding:
    """Declarative mapping: dataset column -> visual channel."""

    x: Optional[Callable[[dict], float]] = None
    y: Optional[Callable[[dict], float]] = None
    size: Optional[Callable[[dict], float]] = None
    colour: Optional[Callable[[dict], Any]] = None
    rotation: Optional[Callable[[dict], float]] = None
    opacity: Optional[Callable[[dict], float]] = None
    shape: Optional[Callable[[dict], str]] = "circle"

    @staticmethod
    def field(name: str, scale: Optional[Scale] = None) -> Callable[[dict], float]:
        if scale is None:
            return lambda row: row.get(name)
        return lambda row: scale(row.get(name, 0) or 0)


def bind(records: List[Dict[str, Any]], binding: DataBinding, default_size: float = 8.0, default_colour: Optional[AardColour] = None) -> List[AardObject]:
    """Turn a dataset into a list of AardObjects positioned/sized/coloured
    according to ``binding`` (spec section 34)."""
    default_colour = default_colour or AardColour(0.7, 0.7, 0.8)
    objects = []
    generator_fns = {
        "circle": shapes.circle,
        "rectangle": lambda center, radius: shapes.rectangle(center[0] - radius, center[1] - radius, radius * 2, radius * 2),
        "star": lambda center, radius: shapes.star(center=center, outer_radius=radius, inner_radius=radius * 0.5),
    }
    for i, row in enumerate(records):
        x = binding.x(row) if binding.x else 0.0
        y = binding.y(row) if binding.y else 0.0
        size = binding.size(row) if binding.size else default_size
        colour_val = binding.colour(row) if binding.colour else default_colour
        colour = colour_val if isinstance(colour_val, AardColour) else default_colour
        shape_name = binding.shape(row) if callable(binding.shape) else (binding.shape or "circle")

        path = generator_fns.get(shape_name, shapes.circle)(center=(0, 0), radius=size)
        obj = AardObject(AardObjectType.SHAPE, name=f"datum-{i}")
        obj.data = path
        obj.style.fill = colour
        obj.position = (x, y)
        if binding.rotation:
            obj.rotation = binding.rotation(row) or 0.0
        if binding.opacity:
            obj.opacity = binding.opacity(row) if binding.opacity(row) is not None else 1.0
        obj.metadata["data_row"] = row
        obj.generator = {"name": "data_binding", "kwargs": {"row_index": i}}
        objects.append(obj)
    return objects


def colour_scale(records: List[Dict[str, Any]], field: str, gradient: AardGradient) -> Callable[[dict], AardColour]:
    values = [r.get(field) for r in records if r.get(field) is not None]
    lo, hi = (min(values), max(values)) if values else (0, 1)

    def fn(row):
        v = row.get(field)
        if v is None:
            return gradient.sample(0.0)
        t = (v - lo) / (hi - lo) if hi != lo else 0.0
        return gradient.sample(max(0.0, min(1.0, t)))

    return fn
