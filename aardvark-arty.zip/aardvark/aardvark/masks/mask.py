"""Mask engine (spec section 26): raster, vector, gradient, procedural,
alpha, luminosity and colour masks, combinable with ADD/SUBTRACT/
INTERSECT/MULTIPLY/MINIMUM/MAXIMUM.

Every mask kind reduces, ultimately, to a single-channel float32 alpha
array in [0, 1] at a requested resolution — that's what
:meth:`AardMask.to_alpha` produces, and what the renderer multiplies into
an object's rendered alpha channel.
"""
from __future__ import annotations

from typing import Callable, Optional, Tuple

import numpy as np

from ..colour.colour import AardColour


class AardMask:
    KINDS = ("raster", "vector", "gradient", "procedural", "luminosity", "colour")

    def __init__(self, kind: str, data, invert: bool = False, feather: float = 0.0):
        if kind not in self.KINDS:
            raise ValueError(f"Unknown mask kind {kind!r}; choose from {self.KINDS}")
        self.kind = kind
        self.data = data
        self.invert = invert
        self.feather = feather  # gaussian blur radius (px) applied to the resolved alpha

    # ------------------------------------------------------------------
    # Constructors
    # ------------------------------------------------------------------
    @classmethod
    def from_raster_alpha(cls, array: np.ndarray, invert: bool = False, feather: float = 0.0) -> "AardMask":
        return cls("raster", array, invert, feather)

    @classmethod
    def from_path(cls, path, invert: bool = False, feather: float = 0.0) -> "AardMask":
        return cls("vector", path, invert, feather)

    @classmethod
    def from_gradient(cls, gradient, invert: bool = False, feather: float = 0.0) -> "AardMask":
        return cls("gradient", gradient, invert, feather)

    @classmethod
    def from_image_luminosity(cls, raster_image, invert: bool = False, feather: float = 0.0) -> "AardMask":
        return cls("luminosity", raster_image, invert, feather)

    @classmethod
    def from_colour_key(cls, raster_image, key: AardColour, tolerance: float = 0.15, invert: bool = False, feather: float = 0.0) -> "AardMask":
        return cls("colour", (raster_image, key, tolerance), invert, feather)

    @classmethod
    def from_function(cls, fn: Callable[[np.ndarray, np.ndarray], np.ndarray], invert: bool = False, feather: float = 0.0) -> "AardMask":
        """``fn(x_grid, y_grid) -> alpha_grid`` in normalised [0,1] mask space."""
        return cls("procedural", fn, invert, feather)

    # ------------------------------------------------------------------
    # Resolution to an alpha buffer
    # ------------------------------------------------------------------
    def to_alpha(self, width: int, height: int, bbox: Optional[Tuple[float, float, float, float]] = None) -> np.ndarray:
        if bbox is None:
            bbox = (0, 0, width, height)
        minx, miny, maxx, maxy = bbox

        if self.kind == "raster":
            arr = self.data
            if arr.ndim == 3:
                arr = arr[..., -1] if arr.shape[-1] == 1 else arr[..., 3] if arr.shape[-1] == 4 else arr.mean(axis=-1)
            alpha = _resize_array(arr, width, height)
        elif self.kind == "vector":
            alpha = _rasterize_path_alpha(self.data, width, height, bbox)
        elif self.kind == "gradient":
            g = self.data
            rgba = g.rasterize(width, height, bbox)
            alpha = rgba[..., 3] if np.any(rgba[..., 3] < 1) else (
                0.2126 * rgba[..., 0] + 0.7152 * rgba[..., 1] + 0.0722 * rgba[..., 2]
            )
        elif self.kind == "luminosity":
            img = self.data
            arr = _resize_array(img.array, width, height, channels=True)
            alpha = 0.2126 * arr[..., 0] + 0.7152 * arr[..., 1] + 0.0722 * arr[..., 2]
            alpha = alpha * arr[..., 3]
        elif self.kind == "colour":
            img, key, tolerance = self.data
            arr = _resize_array(img.array, width, height, channels=True)
            dist = np.sqrt((arr[..., 0] - key.r) ** 2 + (arr[..., 1] - key.g) ** 2 + (arr[..., 2] - key.b) ** 2)
            alpha = np.clip(1.0 - dist / max(tolerance, 1e-6), 0.0, 1.0)
        elif self.kind == "procedural":
            xs = (np.arange(width) + 0.5) / width * (maxx - minx) + minx
            ys = (np.arange(height) + 0.5) / height * (maxy - miny) + miny
            xx, yy = np.meshgrid(xs, ys)
            alpha = np.clip(self.data(xx, yy), 0.0, 1.0)
        else:  # pragma: no cover
            alpha = np.ones((height, width), dtype=np.float32)

        if self.feather > 0:
            alpha = _gaussian_blur(alpha, self.feather)
        if self.invert:
            alpha = 1.0 - alpha
        return alpha.astype(np.float32)


def _resize_array(arr: np.ndarray, width: int, height: int, channels: bool = False) -> np.ndarray:
    from PIL import Image

    if arr.shape[:2] == (height, width):
        return arr
    src = (np.clip(arr, 0, 1) * 255).astype(np.uint8)
    mode = "RGBA" if channels and src.shape[-1] == 4 else ("RGB" if channels else "L")
    img = Image.fromarray(src, mode=mode).resize((width, height), Image.BILINEAR)
    out = np.asarray(img).astype(np.float32) / 255.0
    return out


def _rasterize_path_alpha(path, width: int, height: int, bbox) -> np.ndarray:
    from PIL import Image, ImageDraw

    minx, miny, maxx, maxy = bbox
    span_x = (maxx - minx) or 1
    span_y = (maxy - miny) or 1
    ss = 2  # supersample for antialiasing
    img = Image.new("L", (width * ss, height * ss), 0)
    draw = ImageDraw.Draw(img)
    for poly in path.to_polygons():
        pts = [
            ((x - minx) / span_x * width * ss, (y - miny) / span_y * height * ss)
            for x, y in poly
        ]
        if len(pts) >= 3:
            draw.polygon(pts, fill=255)
    img = img.resize((width, height), Image.BILINEAR)
    return np.asarray(img).astype(np.float32) / 255.0


def _gaussian_blur(alpha: np.ndarray, radius: float) -> np.ndarray:
    from PIL import Image, ImageFilter

    img = Image.fromarray((np.clip(alpha, 0, 1) * 255).astype(np.uint8), mode="L")
    img = img.filter(ImageFilter.GaussianBlur(radius))
    return np.asarray(img).astype(np.float32) / 255.0


# ----------------------------------------------------------------------
# Combine operators
# ----------------------------------------------------------------------
def combine(a: AardMask, b: AardMask, op: str, width: int, height: int, bbox=None) -> AardMask:
    aa = a.to_alpha(width, height, bbox)
    ba = b.to_alpha(width, height, bbox)
    ops = {
        "ADD": lambda x, y: np.clip(x + y, 0, 1),
        "SUBTRACT": lambda x, y: np.clip(x - y, 0, 1),
        "INTERSECT": np.minimum,
        "MULTIPLY": lambda x, y: x * y,
        "MINIMUM": np.minimum,
        "MAXIMUM": np.maximum,
    }
    if op not in ops:
        raise ValueError(f"Unknown mask combine op {op!r}; choose from {list(ops)}")
    result = ops[op](aa, ba)
    return AardMask.from_raster_alpha(result.astype(np.float32))
