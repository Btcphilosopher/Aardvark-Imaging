"""3D foundation (spec section 39): a future-compatible scene
representation. AARDVARK is not exclusively 2D — this module provides
plain-data Scene/Camera/Light/Material/Mesh/Object3D types and a handful
of primitive mesh generators (cube, sphere, plane, cylinder) plus
extrusion of a 2D Path into a 3D mesh, without shipping a full 3D
renderer (spec section 52's GPURenderer extension point is where a real
rasteriser/raytracer would plug in).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import numpy as np

from ..colour.colour import AardColour

Vec3 = Tuple[float, float, float]


@dataclass
class Material:
    base_colour: AardColour = field(default_factory=lambda: AardColour(0.8, 0.8, 0.8))
    metallic: float = 0.0
    roughness: float = 0.5
    emissive: AardColour = field(default_factory=lambda: AardColour(0, 0, 0))


@dataclass
class Mesh:
    vertices: np.ndarray  # (N, 3) float
    faces: np.ndarray  # (M, 3) int, triangle indices
    normals: Optional[np.ndarray] = None
    material: Material = field(default_factory=Material)

    def bounds(self):
        return (self.vertices.min(axis=0), self.vertices.max(axis=0))

    def compute_normals(self) -> np.ndarray:
        normals = np.zeros_like(self.vertices)
        for f in self.faces:
            v0, v1, v2 = self.vertices[f]
            n = np.cross(v1 - v0, v2 - v0)
            for idx in f:
                normals[idx] += n
        norm = np.linalg.norm(normals, axis=1, keepdims=True)
        norm[norm == 0] = 1
        self.normals = normals / norm
        return self.normals


@dataclass
class Object3D:
    mesh: Mesh
    position: Vec3 = (0.0, 0.0, 0.0)
    rotation: Vec3 = (0.0, 0.0, 0.0)  # Euler degrees
    scale: Vec3 = (1.0, 1.0, 1.0)
    name: str = "Object3D"


@dataclass
class Camera:
    position: Vec3 = (0.0, 0.0, 5.0)
    target: Vec3 = (0.0, 0.0, 0.0)
    up: Vec3 = (0.0, 1.0, 0.0)
    fov_degrees: float = 50.0
    projection: str = "perspective"  # perspective | orthographic
    near: float = 0.1
    far: float = 1000.0


@dataclass
class Light:
    kind: str = "point"  # point | directional | ambient
    position: Vec3 = (0.0, 5.0, 5.0)
    colour: AardColour = field(default_factory=lambda: AardColour(1, 1, 1))
    intensity: float = 1.0


@dataclass
class Scene:
    objects: List[Object3D] = field(default_factory=list)
    lights: List[Light] = field(default_factory=list)
    camera: Camera = field(default_factory=Camera)

    def add(self, obj: Object3D) -> Object3D:
        self.objects.append(obj)
        return obj


# ----------------------------------------------------------------------
# Primitive generators
# ----------------------------------------------------------------------
def cube(size: float = 1.0) -> Mesh:
    s = size / 2
    v = np.array(
        [
            [-s, -s, -s], [s, -s, -s], [s, s, -s], [-s, s, -s],
            [-s, -s, s], [s, -s, s], [s, s, s], [-s, s, s],
        ],
        dtype=np.float64,
    )
    faces = np.array(
        [
            [0, 2, 1], [0, 3, 2],  # back
            [4, 5, 6], [4, 6, 7],  # front
            [0, 1, 5], [0, 5, 4],  # bottom
            [3, 6, 2], [3, 7, 6],  # top
            [0, 4, 7], [0, 7, 3],  # left
            [1, 2, 6], [1, 6, 5],  # right
        ],
        dtype=np.int64,
    )
    return Mesh(v, faces)


def plane(width: float = 1.0, height: float = 1.0, segments: int = 1) -> Mesh:
    xs = np.linspace(-width / 2, width / 2, segments + 1)
    ys = np.linspace(-height / 2, height / 2, segments + 1)
    verts = []
    for y in ys:
        for x in xs:
            verts.append([x, 0, y])
    verts = np.array(verts)
    faces = []
    cols = segments + 1
    for row in range(segments):
        for col in range(segments):
            i0 = row * cols + col
            i1 = i0 + 1
            i2 = i0 + cols
            i3 = i2 + 1
            faces.append([i0, i2, i1])
            faces.append([i1, i2, i3])
    return Mesh(verts, np.array(faces, dtype=np.int64))


def sphere(radius: float = 1.0, segments: int = 24, rings: int = 16) -> Mesh:
    verts = []
    for r in range(rings + 1):
        phi = math.pi * r / rings
        for s in range(segments + 1):
            theta = 2 * math.pi * s / segments
            x = radius * math.sin(phi) * math.cos(theta)
            y = radius * math.cos(phi)
            z = radius * math.sin(phi) * math.sin(theta)
            verts.append([x, y, z])
    verts = np.array(verts)
    faces = []
    cols = segments + 1
    for r in range(rings):
        for s in range(segments):
            i0 = r * cols + s
            i1 = i0 + 1
            i2 = i0 + cols
            i3 = i2 + 1
            faces.append([i0, i1, i2])
            faces.append([i1, i3, i2])
    return Mesh(verts, np.array(faces, dtype=np.int64))


def cylinder(radius: float = 1.0, height: float = 2.0, segments: int = 24) -> Mesh:
    verts = []
    for s in range(segments):
        theta = 2 * math.pi * s / segments
        x, z = radius * math.cos(theta), radius * math.sin(theta)
        verts.append([x, -height / 2, z])
        verts.append([x, height / 2, z])
    verts.append([0, -height / 2, 0])  # bottom centre
    verts.append([0, height / 2, 0])  # top centre
    verts = np.array(verts)
    bottom_c, top_c = len(verts) - 2, len(verts) - 1
    faces = []
    for s in range(segments):
        b0, t0 = 2 * s, 2 * s + 1
        b1, t1 = 2 * ((s + 1) % segments), 2 * ((s + 1) % segments) + 1
        faces.append([b0, t0, b1])
        faces.append([t0, t1, b1])
        faces.append([bottom_c, b0, b1])
        faces.append([top_c, t1, t0])
    return Mesh(verts, np.array(faces, dtype=np.int64))


def extrude_path(path, depth: float = 1.0) -> Mesh:
    """Extrude a 2D vector Path (flattened) into a simple prism mesh —
    the bridge from the vector engine's flat geometry into 3D (spec
    section 39: "the 2D vector engine should be capable of generating
    geometry that can later be extruded into 3D")."""
    polys = path.to_polygons()
    if not polys:
        raise ValueError("Cannot extrude an empty path")
    ring = polys[0]
    n = len(ring)
    front = [[x, y, depth / 2] for x, y in ring]
    back = [[x, y, -depth / 2] for x, y in ring]
    verts = np.array(front + back)
    faces = []
    # Simple fan triangulation for the caps (assumes a roughly convex ring;
    # documented limitation for concave outlines).
    for i in range(1, n - 1):
        faces.append([0, i, i + 1])
        faces.append([n, n + i + 1, n + i])
    for i in range(n):
        j = (i + 1) % n
        faces.append([i, j, n + i])
        faces.append([j, n + j, n + i])
    return Mesh(verts, np.array(faces, dtype=np.int64))
