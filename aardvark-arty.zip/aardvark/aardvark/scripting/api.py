"""AARDVARK scripting API (spec sections 31-32 & 63): the embedded Python
API that makes Python itself a creative medium — this is what
``import aardvark as aard`` gives you, matching the spec's own usage
examples::

    doc = aard.create_document(4000, 3000)
    circle = aard.circle(center=(2000, 1500), radius=500)
    circle.fill = "#E6E0D2"
    doc.add(circle)
    doc.export("artwork.png")

Every object this module hands back is a plain
:class:`~aardvark.core.object.AardObject` (or a very thin document
wrapper) — there is no separate "scripting-only" object type, so
anything built this way is exactly as editable from the GUI, the .aard
file, or a plugin as anything built any other way (spec section 82).
"""
from __future__ import annotations

from typing import Optional, Tuple

from ..core.object import AardObject, AardObjectType, BlendMode
from ..colour.colour import AardColour
from ..document.document import Document, Artboard
from ..vector import shapes as _shapes
from ..vector.path import Path
from ..typography.text import TextObject, CharacterStyle, ParagraphStyle


class AardDocument:
    """Thin, ergonomic wrapper around :class:`~aardvark.document.Document`
    for scripting: ``doc.add(obj)`` adds to the first artboard,
    ``doc.export(path)`` dispatches on file extension. The wrapped
    ``Document`` (``doc.document``) is the real source of truth and works
    with every other subsystem unwrapped."""

    def __init__(self, document: Document):
        self.document = document

    # ------------------------------------------------------------------
    @property
    def artboard(self) -> Artboard:
        return self.document.artboard

    def add_artboard(self, name: str, width: float, height: float, background=None) -> Artboard:
        return self.document.add_artboard(name, width, height, AardObject._coerce_paint(background) if background else None)

    def add(self, obj: AardObject, artboard_index: int = 0) -> AardObject:
        return self.document.artboards[artboard_index].add(obj)

    def group(self, *objects: AardObject, name: str = "Group") -> AardObject:
        g = AardObject(AardObjectType.GROUP, name=name)
        for o in objects:
            g.add(o)
        self.add(g)
        return g

    # ------------------------------------------------------------------
    def save(self, path: str) -> None:
        self.document.save(path)

    def export(self, path: str, format: Optional[str] = None, artboard_index: int = 0, dpi: float = 96.0, **kwargs) -> None:
        fmt = (format or path.rsplit(".", 1)[-1]).lower()
        if fmt == "aard":
            self.save(path)
        elif fmt == "svg":
            from ..export.svg import AardSVGWriter

            artboard = self.document.artboards[artboard_index]
            AardSVGWriter(artboard.width, artboard.height).save(path, self.document, artboard_index)
        elif fmt == "pdf":
            from ..export.pdf import AardPublication, export_pdf

            pub = AardPublication(self.document)
            pub.add_page(artboard_index, dpi=kwargs.get("print_dpi", 300.0))
            export_pdf(pub, path)
        else:
            from ..export.raster import export_raster

            export_raster(self.document, path, format=fmt, artboard_index=artboard_index, dpi=dpi, **{k: v for k, v in kwargs.items() if k != "print_dpi"})

    def render(self, artboard_index: int = 0, dpi: float = 96.0, supersample: int = 2):
        from ..export.raster import render_to_raster

        return render_to_raster(self.document, artboard_index, dpi=dpi, supersample=supersample)

    def __getattr__(self, item):
        # Passthrough for anything not explicitly wrapped (palettes,
        # variables, fonts, metadata, find_by_id, ...).
        return getattr(self.document, item)


def create_document(width: float = 1920, height: float = 1080, name: str = "Untitled", background=None) -> AardDocument:
    doc = Document(name)
    bg = AardObject._coerce_paint(background) if background is not None else None
    doc.add_artboard("Main", width, height, bg)
    return AardDocument(doc)


# ----------------------------------------------------------------------
# Shape constructors (spec section 8) — build a Path via the shape
# generator library, wrap it in an AardObject, and record the generator
# call so the object stays parametric (``obj.regenerate()`` below).
# ----------------------------------------------------------------------
def _make_shape_object(generator_name: str, path_fn, name: str, kwargs: dict) -> AardObject:
    obj = AardObject(AardObjectType.SHAPE, name=name)
    obj.data = path_fn(**kwargs)
    obj.generator = {"name": generator_name, "kwargs": kwargs}
    return obj


def circle(center: Tuple[float, float] = (0, 0), radius: float = 50) -> AardObject:
    return _make_shape_object("circle", _shapes.circle, "Circle", dict(center=center, radius=radius))


def ellipse(center: Tuple[float, float] = (0, 0), rx: float = 50, ry: float = 30) -> AardObject:
    return _make_shape_object("ellipse", _shapes.ellipse, "Ellipse", dict(center=center, rx=rx, ry=ry))


def rectangle(x: float = 0, y: float = 0, width: float = 100, height: float = 60) -> AardObject:
    return _make_shape_object("rectangle", _shapes.rectangle, "Rectangle", dict(x=x, y=y, width=width, height=height))


def rounded_rectangle(x: float = 0, y: float = 0, width: float = 100, height: float = 60, radius: float = 12) -> AardObject:
    return _make_shape_object("rounded_rectangle", _shapes.rounded_rectangle, "Rounded Rectangle", dict(x=x, y=y, width=width, height=height, radius=radius))


def polygon(center: Tuple[float, float] = (0, 0), sides: int = 6, radius: float = 50, rotation: float = -90) -> AardObject:
    return _make_shape_object("polygon", _shapes.polygon, "Polygon", dict(center=center, sides=sides, radius=radius, rotation=rotation))


def star(center: Tuple[float, float] = (0, 0), points: int = 5, inner_radius: float = 20, outer_radius: float = 50, rotation: float = -90) -> AardObject:
    return _make_shape_object(
        "star", _shapes.star, "Star", dict(center=center, points=points, inner_radius=inner_radius, outer_radius=outer_radius, rotation=rotation)
    )


def ring(center: Tuple[float, float] = (0, 0), inner_radius: float = 30, outer_radius: float = 50) -> AardObject:
    return _make_shape_object("ring", _shapes.ring, "Ring", dict(center=center, inner_radius=inner_radius, outer_radius=outer_radius))


def spiral(center: Tuple[float, float] = (0, 0), turns: float = 3.0, start_radius: float = 5.0, end_radius: float = 100.0) -> AardObject:
    return _make_shape_object("spiral", _shapes.spiral, "Spiral", dict(center=center, turns=turns, start_radius=start_radius, end_radius=end_radius))


def text(content: str, x: float = 0, y: float = 0, size: float = 24, family: str = "DejaVu Sans", colour="#000000") -> AardObject:
    obj = AardObject(AardObjectType.TEXT, name="Text")
    style = CharacterStyle(family=family, size=size, colour=AardColour.from_hex(colour) if isinstance(colour, str) else colour)
    obj.data = TextObject(content, style)
    obj.position = (x, y)
    return obj


def image(path_or_raster, x: float = 0, y: float = 0) -> AardObject:
    from ..raster.image import RasterImage

    obj = AardObject(AardObjectType.IMAGE, name="Image")
    obj.data = path_or_raster if hasattr(path_or_raster, "array") else RasterImage.from_file(path_or_raster)
    obj.position = (x, y)
    return obj


def group(*objects: AardObject, name: str = "Group") -> AardObject:
    g = AardObject(AardObjectType.GROUP, name=name)
    for o in objects:
        g.add(o)
    return g


def regenerate(obj: AardObject) -> AardObject:
    """Rebuild a parametric shape object's geometry from its recorded
    generator (spec section 9: "the resulting artwork should remain
    associated with its generator parameters"). Mutate ``obj.generator['kwargs']``
    and call this to re-derive ``obj.data``."""
    if not obj.generator:
        raise ValueError("Object has no recorded generator to regenerate from")
    fn = _shapes.GENERATORS.get(obj.generator["name"])
    if fn is None:
        raise ValueError(f"Unknown generator {obj.generator['name']!r}")
    obj.data = fn(**obj.generator["kwargs"])
    return obj
