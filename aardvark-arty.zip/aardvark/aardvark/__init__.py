"""AARDVARK — a Python-native computational art, design, illustration,
typography, vector, raster and generative graphics engine.

    IDEA -> GEOMETRY -> COLOUR -> MATERIAL -> IMAGE -> COMPOSITION ->
    TYPOGRAPHY -> MOTION -> DESIGN

This top-level package IS the scripting surface the spec describes:
``import aardvark as aard`` gives you ``aard.create_document``,
``aard.circle``/``aard.star``/etc., ``aard.procedural.flow_field``, and
every other subsystem as a submodule (``aard.colour``, ``aard.vector``,
``aard.raster``, ``aard.effects``, ...). See the project README for the
full map, and ``aardvark.core.object.AardObject`` for the universal
object model everything else builds on.
"""
from __future__ import annotations

__version__ = "0.1.0"

# Subsystems, exposed as submodules (aard.colour.AardColour, aard.vector.shapes.star, ...)
from . import core  # noqa: F401
from . import geometry  # noqa: F401
from . import vector  # noqa: F401
from . import colour  # noqa: F401
from . import raster  # noqa: F401
from . import masks  # noqa: F401
from . import paint  # noqa: F401
from . import typography  # noqa: F401
from . import layout  # noqa: F401
from . import composition  # noqa: F401
from . import procedural  # noqa: F401
from . import particles  # noqa: F401
from . import patterns  # noqa: F401
from . import data  # noqa: F401
from . import analysis  # noqa: F401
from . import effects  # noqa: F401
from . import animation  # noqa: F401
from . import three_d  # noqa: F401
from . import history  # noqa: F401
from . import rendering  # noqa: F401
from . import export  # noqa: F401
from . import document  # noqa: F401
from . import scripting  # noqa: F401
from . import plugins  # noqa: F401
from . import ai  # noqa: F401
from . import assets  # noqa: F401

# The scripting facade, flattened onto the package root (spec section 32):
#   import aardvark as aard
#   doc = aard.create_document(4000, 3000)
#   c = aard.circle(center=(2000, 1500), radius=500); c.fill = "#E6E0D2"
#   doc.add(c); doc.export("artwork.png")
from .scripting.api import (  # noqa: F401
    AardDocument,
    create_document,
    circle,
    ellipse,
    rectangle,
    rounded_rectangle,
    polygon,
    star,
    ring,
    spiral,
    text,
    image,
    group,
    regenerate,
)

# A handful of the most commonly reached-for names, also flattened.
from .core.object import AardObject, AardObjectType, BlendMode  # noqa: F401
from .colour.colour import AardColour  # noqa: F401
from .colour.gradient import AardGradient  # noqa: F401
from .colour.palette import AardPalette  # noqa: F401
from .document.document import Document, Artboard  # noqa: F401
from .vector.path import Path  # noqa: F401
from .rendering.renderer import CPURenderer, PreviewRenderer, ExportRenderer  # noqa: F401

__all__ = [
    "__version__",
    # subsystems
    "core", "geometry", "vector", "colour", "raster", "masks", "paint",
    "typography", "layout", "composition", "procedural", "particles",
    "patterns", "data", "analysis", "effects", "animation", "three_d",
    "history", "rendering", "export", "document", "scripting", "plugins",
    "ai", "assets",
    # scripting facade
    "AardDocument", "create_document", "circle", "ellipse", "rectangle",
    "rounded_rectangle", "polygon", "star", "ring", "spiral", "text",
    "image", "group", "regenerate",
    # commonly used types
    "AardObject", "AardObjectType", "BlendMode", "AardColour",
    "AardGradient", "AardPalette", "Document", "Artboard", "Path",
    "CPURenderer", "PreviewRenderer", "ExportRenderer",
]
