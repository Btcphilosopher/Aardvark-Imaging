"""Motion engine (spec section 40-41): keyframes, easing curves,
expressions, and export to GIF / MP4 / WebM / image sequence.

Objects gain animatable channels — position, rotation, scale, opacity,
fill colour — driven by keyframes on a :class:`Timeline`. Procedural
functions can drive a channel too (an "expression"), since a
:class:`Track` accepts either keyframes or a plain callable ``t -> value``.
"""
from __future__ import annotations

import math
import os
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

from ..colour.colour import AardColour

Easing = Callable[[float], float]


def linear(t: float) -> float:
    return t


def ease_in(t: float) -> float:
    return t * t


def ease_out(t: float) -> float:
    return 1 - (1 - t) * (1 - t)


def ease_in_out(t: float) -> float:
    return 3 * t * t - 2 * t * t * t


def cubic_bezier_easing(x1: float, y1: float, x2: float, y2: float) -> Easing:
    """CSS-style cubic-bezier easing curve (control points (x1,y1),(x2,y2),
    endpoints fixed at (0,0) and (1,1))."""

    def bezier1d(t, a, b):
        return 3 * (1 - t) ** 2 * t * a + 3 * (1 - t) * t ** 2 * b + t ** 3

    def fn(t: float) -> float:
        lo, hi = 0.0, 1.0
        for _ in range(24):
            mid = (lo + hi) / 2
            x = bezier1d(mid, x1, x2)
            if x < t:
                lo = mid
            else:
                hi = mid
        return bezier1d((lo + hi) / 2, y1, y2)

    return fn


EASINGS: Dict[str, Easing] = {
    "linear": linear,
    "ease_in": ease_in,
    "ease_out": ease_out,
    "ease_in_out": ease_in_out,
}


@dataclass
class Keyframe:
    time: float  # seconds
    value: Any
    easing: Union[str, Easing] = "linear"

    def easing_fn(self) -> Easing:
        return EASINGS[self.easing] if isinstance(self.easing, str) else self.easing


def _interp_value(a, b, t):
    if isinstance(a, AardColour) and isinstance(b, AardColour):
        return a.mix(b, t)
    if isinstance(a, (tuple, list)) and isinstance(b, (tuple, list)):
        return type(a)(_interp_value(x, y, t) for x, y in zip(a, b))
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return a + (b - a) * t
    return a if t < 1 else b


class Track:
    """A single animatable channel: either a list of :class:`Keyframe`, or
    an expression function ``t -> value`` (spec: "procedural functions")."""

    def __init__(self, target: Any, property_name: str, keyframes: Optional[List[Keyframe]] = None, expression: Optional[Callable[[float], Any]] = None):
        self.target = target
        self.property_name = property_name
        self.keyframes = sorted(keyframes or [], key=lambda k: k.time)
        self.expression = expression

    def value_at(self, t: float) -> Any:
        if self.expression is not None:
            return self.expression(t)
        if not self.keyframes:
            return None
        if t <= self.keyframes[0].time:
            return self.keyframes[0].value
        if t >= self.keyframes[-1].time:
            return self.keyframes[-1].value
        for k0, k1 in zip(self.keyframes, self.keyframes[1:]):
            if k0.time <= t <= k1.time:
                span = k1.time - k0.time
                local_t = (t - k0.time) / span if span else 0.0
                local_t = k0.easing_fn()(local_t)
                return _interp_value(k0.value, k1.value, local_t)
        return self.keyframes[-1].value

    def apply(self, t: float) -> None:
        value = self.value_at(t)
        if value is None:
            return
        if "." in self.property_name:
            obj_path, attr = self.property_name.rsplit(".", 1)
            target = self.target
            for part in obj_path.split("."):
                target = getattr(target, part)
            setattr(target, attr, value)
        else:
            setattr(self.target, self.property_name, value)


class Timeline:
    def __init__(self, duration: float = 3.0, fps: float = 30.0):
        self.duration = duration
        self.fps = fps
        self.tracks: List[Track] = []

    def animate(self, target: Any, property_name: str, keyframes: List[Keyframe]) -> Track:
        track = Track(target, property_name, keyframes=keyframes)
        self.tracks.append(track)
        return track

    def animate_expression(self, target: Any, property_name: str, expression: Callable[[float], Any]) -> Track:
        track = Track(target, property_name, expression=expression)
        self.tracks.append(track)
        return track

    def apply(self, t: float) -> None:
        for track in self.tracks:
            track.apply(t)

    def frame_times(self) -> List[float]:
        n = max(1, int(round(self.duration * self.fps)))
        return [i / self.fps for i in range(n)]


def render_animation(timeline: Timeline, renderer, root_provider: Callable[[], Any], width: int, height: int, background=None):
    """Render every frame of ``timeline`` with ``renderer`` (a CPURenderer)
    against ``root_provider()`` (a callable returning the current scene
    root — usually just ``lambda: artboard.root``, since Timeline mutates
    the same Document in place at each frame time)."""
    frames = []
    for t in timeline.frame_times():
        timeline.apply(t)
        frames.append(renderer.render(root_provider(), width, height, background))
    return frames


def export_gif(frames, path: str, fps: float = 30.0) -> None:
    pil_frames = [f.to_pil().convert("P", palette=1) for f in frames]
    duration_ms = int(1000 / fps)
    pil_frames[0].save(path, save_all=True, append_images=pil_frames[1:], duration=duration_ms, loop=0, disposal=2)


def export_image_sequence(frames, directory: str, prefix: str = "frame", ext: str = "png") -> List[str]:
    os.makedirs(directory, exist_ok=True)
    paths = []
    digits = max(4, len(str(len(frames))))
    for i, frame in enumerate(frames):
        path = os.path.join(directory, f"{prefix}_{str(i).zfill(digits)}.{ext}")
        frame.save(path)
        paths.append(path)
    return paths


def export_video(frames, path: str, fps: float = 30.0, codec: str = "libx264") -> None:
    """Exports MP4/WebM via imageio + ffmpeg. Raises a clear error (rather
    than silently no-op'ing) if the optional ffmpeg backend isn't
    available in this environment."""
    try:
        import imageio.v3 as iio
    except ImportError as e:  # pragma: no cover
        raise RuntimeError("Video export requires the optional 'imageio' dependency (pip install imageio[ffmpeg]).") from e
    arrays = [f.to_numpy("uint8")[..., :3] for f in frames]
    try:
        iio.imwrite(path, arrays, fps=fps, codec=codec)
    except Exception as e:  # pragma: no cover
        raise RuntimeError(
            "Video export failed — this usually means the ffmpeg plugin isn't installed "
            "(pip install imageio[ffmpeg]). Image-sequence and GIF export don't need it."
        ) from e
