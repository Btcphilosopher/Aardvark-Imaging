"""Layer system: RasterLayer and blend-mode compositing (spec sections 10 & 26)."""
from __future__ import annotations

from typing import List, Optional

import numpy as np

from ..core.object import BlendMode
from .image import RasterImage


def _blend(mode: BlendMode, cb: np.ndarray, cs: np.ndarray) -> np.ndarray:
    """Per-channel blend function. cb = backdrop, cs = source, both in [0,1]."""
    if mode == BlendMode.NORMAL:
        return cs
    if mode == BlendMode.MULTIPLY:
        return cb * cs
    if mode == BlendMode.SCREEN:
        return cb + cs - cb * cs
    if mode == BlendMode.DARKEN:
        return np.minimum(cb, cs)
    if mode == BlendMode.LIGHTEN:
        return np.maximum(cb, cs)
    if mode == BlendMode.DIFFERENCE:
        return np.abs(cb - cs)
    if mode == BlendMode.EXCLUSION:
        return cb + cs - 2 * cb * cs
    if mode == BlendMode.ADD:
        return np.clip(cb + cs, 0, 1)
    if mode == BlendMode.OVERLAY:
        return np.where(cb <= 0.5, 2 * cb * cs, 1 - 2 * (1 - cb) * (1 - cs))
    if mode == BlendMode.HARD_LIGHT:
        return np.where(cs <= 0.5, 2 * cb * cs, 1 - 2 * (1 - cb) * (1 - cs))
    if mode == BlendMode.SOFT_LIGHT:
        d = np.where(cb <= 0.25, ((16 * cb - 12) * cb + 4) * cb, np.sqrt(np.clip(cb, 0, 1)))
        return np.where(cs <= 0.5, cb - (1 - 2 * cs) * cb * (1 - cb), cb + (2 * cs - 1) * (d - cb))
    if mode == BlendMode.COLOR_DODGE:
        return np.where(cb == 0, 0, np.where(cs >= 1, 1, np.minimum(1, cb / np.clip(1 - cs, 1e-6, 1))))
    if mode == BlendMode.COLOR_BURN:
        return np.where(cb >= 1, 1, np.where(cs <= 0, 0, 1 - np.minimum(1, (1 - cb) / np.clip(cs, 1e-6, 1))))
    raise ValueError(f"Unsupported blend mode: {mode}")


def composite(backdrop: RasterImage, source: RasterImage, mode: BlendMode = BlendMode.NORMAL, opacity: float = 1.0) -> RasterImage:
    """Composite ``source`` over ``backdrop`` (same size) using standard
    Porter-Duff "over" alpha compositing with the given blend mode applied
    to colour channels first (W3C compositing/blending model)."""
    cb = backdrop.array[..., :3]
    cs = source.array[..., :3]
    ab = backdrop.array[..., 3:4]
    as_ = source.array[..., 3:4] * opacity

    blended = _blend(mode, cb, cs)
    # Mix the blended colour with the raw source colour according to backdrop alpha
    # (areas with no backdrop just show the source colour, per spec).
    mixed_colour = (1 - ab) * cs + ab * blended

    out_a = as_ + ab * (1 - as_)
    out_a_safe = np.where(out_a > 1e-6, out_a, 1.0)
    out_rgb = (as_ * mixed_colour + ab * (1 - as_) * cb) / out_a_safe

    out = np.concatenate([out_rgb, out_a], axis=-1)
    return RasterImage(out.astype(np.float32), backdrop.bit_depth, backdrop.colour_space)


class RasterLayer:
    def __init__(self, image: RasterImage, name: str = "Layer", blend_mode: BlendMode = BlendMode.NORMAL, opacity: float = 1.0, visible: bool = True):
        self.image = image
        self.name = name
        self.blend_mode = blend_mode
        self.opacity = opacity
        self.visible = visible


class LayerStack:
    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height
        self.layers: List[RasterLayer] = []

    def add(self, layer: RasterLayer) -> "LayerStack":
        self.layers.append(layer)
        return self

    def flatten(self) -> RasterImage:
        canvas = RasterImage.blank(self.width, self.height)
        for layer in self.layers:
            if not layer.visible or layer.opacity <= 0:
                continue
            img = layer.image
            if img.size != (self.width, self.height):
                padded = RasterImage.blank(self.width, self.height)
                padded.paste(img, 0, 0)
                img = padded
            canvas = composite(canvas, img, layer.blend_mode, layer.opacity)
        return canvas
