"""Raster engine core (spec section 15): RasterImage, RasterBuffer, Tile,
TileCache, Region.

Internal representation is a float32 numpy array of shape (H, W, 4) in
RGBA with components in [0, 1] (linear-light-agnostic — values are sRGB
gamma-encoded like :class:`~aardvark.colour.colour.AardColour`, which is
what every ``from_pil``/``to_pil`` round trip assumes). ``bit_depth``
records the *nominal* precision (8/16/32) for export purposes; the numpy
buffer itself is always float32 for uniform, fast vector maths — a
RasterImage exported at 8-bit simply quantises on the way out.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np
from PIL import Image

from ..colour.colour import AardColour


class RasterImage:
    def __init__(self, array: np.ndarray, bit_depth: int = 8, colour_space: str = "RGBA"):
        if array.ndim == 2:
            array = np.stack([array] * 3 + [np.ones_like(array)], axis=-1)
        if array.shape[-1] == 3:
            alpha = np.ones(array.shape[:2] + (1,), dtype=array.dtype)
            array = np.concatenate([array, alpha], axis=-1)
        self.array = array.astype(np.float32)
        self.bit_depth = bit_depth
        self.colour_space = colour_space

    # ------------------------------------------------------------------
    # Constructors
    # ------------------------------------------------------------------
    @classmethod
    def blank(cls, width: int, height: int, fill: Optional[AardColour] = None, bit_depth: int = 8) -> "RasterImage":
        arr = np.zeros((height, width, 4), dtype=np.float32)
        if fill is not None:
            arr[..., 0] = fill.r
            arr[..., 1] = fill.g
            arr[..., 2] = fill.b
            arr[..., 3] = fill.a
        return cls(arr, bit_depth=bit_depth)

    @classmethod
    def from_pil(cls, img: Image.Image) -> "RasterImage":
        img = img.convert("RGBA")
        arr = np.asarray(img).astype(np.float32) / 255.0
        return cls(arr, bit_depth=8)

    @classmethod
    def from_file(cls, path: str) -> "RasterImage":
        return cls.from_pil(Image.open(path))

    @classmethod
    def from_numpy(cls, arr: np.ndarray, assume_float: Optional[bool] = None) -> "RasterImage":
        arr = np.asarray(arr)
        if assume_float is None:
            assume_float = np.issubdtype(arr.dtype, np.floating)
        if not assume_float:
            arr = arr.astype(np.float32) / 255.0
        return cls(arr)

    # ------------------------------------------------------------------
    # Basic properties
    # ------------------------------------------------------------------
    @property
    def width(self) -> int:
        return self.array.shape[1]

    @property
    def height(self) -> int:
        return self.array.shape[0]

    @property
    def size(self) -> Tuple[int, int]:
        return (self.width, self.height)

    def bounds(self) -> Tuple[float, float, float, float]:
        """Local-space bounds, consistent with how the renderer places an
        image tile (local origin at (0, 0), spanning its pixel size) — lets
        generic code (mask placement, composition analysis, layout) call
        ``obj.bounds()`` on an IMAGE object the same way it does on a Path."""
        return (0.0, 0.0, float(self.width), float(self.height))

    def to_numpy(self, dtype: str = "float32") -> np.ndarray:
        if dtype == "float32":
            return self.array
        if dtype == "uint8":
            return np.clip(self.array * 255, 0, 255).astype(np.uint8)
        if dtype == "uint16":
            return np.clip(self.array * 65535, 0, 65535).astype(np.uint16)
        raise ValueError(f"Unsupported dtype {dtype!r}")

    def to_pil(self) -> Image.Image:
        arr8 = self.to_numpy("uint8")
        return Image.fromarray(arr8, mode="RGBA")

    def copy(self) -> "RasterImage":
        return RasterImage(self.array.copy(), self.bit_depth, self.colour_space)

    # ------------------------------------------------------------------
    # Colour-space conversions (vectorised, spec section 16 <-> 15 bridge)
    # ------------------------------------------------------------------
    def to_lab(self) -> np.ndarray:
        from ..colour.colour import rgb_to_lab_array

        return rgb_to_lab_array(self.array[..., :3])

    def to_cmyk(self) -> np.ndarray:
        from ..colour.colour import rgb_to_cmyk_array

        return rgb_to_cmyk_array(self.array[..., :3])

    def to_grayscale(self) -> "RasterImage":
        rgb = self.array[..., :3]
        gray = rgb[..., 0] * 0.2126 + rgb[..., 1] * 0.7152 + rgb[..., 2] * 0.0722
        out = np.stack([gray, gray, gray, self.array[..., 3]], axis=-1)
        return RasterImage(out, self.bit_depth, "GRAY")

    # ------------------------------------------------------------------
    # Geometric operations
    # ------------------------------------------------------------------
    def resize(self, width: int, height: int, resample: str = "lanczos") -> "RasterImage":
        methods = {
            "nearest": Image.NEAREST,
            "bilinear": Image.BILINEAR,
            "bicubic": Image.BICUBIC,
            "lanczos": Image.LANCZOS,
        }
        img = self.to_pil().resize((width, height), methods.get(resample, Image.LANCZOS))
        return RasterImage.from_pil(img)

    def crop(self, box: Tuple[int, int, int, int]) -> "RasterImage":
        x0, y0, x1, y1 = box
        return RasterImage(self.array[y0:y1, x0:x1].copy(), self.bit_depth, self.colour_space)

    def paste(self, other: "RasterImage", x: int, y: int) -> None:
        """Alpha-composite ``other`` onto self at (x, y), in place."""
        h, w = other.height, other.width
        x0, y0 = max(x, 0), max(y, 0)
        x1, y1 = min(x + w, self.width), min(y + h, self.height)
        if x1 <= x0 or y1 <= y0:
            return
        sx0, sy0 = x0 - x, y0 - y
        sx1, sy1 = sx0 + (x1 - x0), sy0 + (y1 - y0)
        src = other.array[sy0:sy1, sx0:sx1]
        dst = self.array[y0:y1, x0:x1]
        src_a = src[..., 3:4]
        self.array[y0:y1, x0:x1] = src * src_a + dst * (1 - src_a)

    def flip_horizontal(self) -> "RasterImage":
        return RasterImage(self.array[:, ::-1, :].copy(), self.bit_depth, self.colour_space)

    def flip_vertical(self) -> "RasterImage":
        return RasterImage(self.array[::-1, :, :].copy(), self.bit_depth, self.colour_space)

    # ------------------------------------------------------------------
    # I/O
    # ------------------------------------------------------------------
    def save(self, path: str, **kwargs) -> None:
        self.to_pil().save(path, **kwargs)


@dataclass
class Region:
    """A rectangular region of interest within a raster, used for dirty-rect
    tracking and tiled processing."""

    x: int
    y: int
    width: int
    height: int

    def intersects(self, other: "Region") -> bool:
        return not (
            self.x + self.width <= other.x
            or other.x + other.width <= self.x
            or self.y + self.height <= other.y
            or other.y + other.height <= self.y
        )

    def union(self, other: "Region") -> "Region":
        x0 = min(self.x, other.x)
        y0 = min(self.y, other.y)
        x1 = max(self.x + self.width, other.x + other.width)
        y1 = max(self.y + self.height, other.y + other.height)
        return Region(x0, y0, x1 - x0, y1 - y0)

    def as_slice(self):
        return (slice(self.y, self.y + self.height), slice(self.x, self.x + self.width))


class Tile:
    """A single tile of a larger raster (spec section 51: tile processing
    for very large artwork)."""

    def __init__(self, x: int, y: int, image: RasterImage):
        self.x = x
        self.y = y
        self.image = image
        self.dirty = True

    @property
    def region(self) -> Region:
        return Region(self.x, self.y, self.image.width, self.image.height)


class TileCache:
    """Splits a RasterImage into a grid of tiles and reassembles it lazily,
    so large-format artwork can be processed piecewise instead of
    allocating one enormous contiguous buffer up front."""

    def __init__(self, width: int, height: int, tile_size: int = 256):
        self.width = width
        self.height = height
        self.tile_size = tile_size
        self.tiles: dict[Tuple[int, int], Tile] = {}

    def get_or_create(self, tx: int, ty: int) -> Tile:
        key = (tx, ty)
        if key not in self.tiles:
            x, y = tx * self.tile_size, ty * self.tile_size
            w = min(self.tile_size, self.width - x)
            h = min(self.tile_size, self.height - y)
            self.tiles[key] = Tile(x, y, RasterImage.blank(w, h))
        return self.tiles[key]

    def tiles_for_region(self, region: Region):
        tx0 = region.x // self.tile_size
        ty0 = region.y // self.tile_size
        tx1 = (region.x + region.width - 1) // self.tile_size
        ty1 = (region.y + region.height - 1) // self.tile_size
        for ty in range(ty0, ty1 + 1):
            for tx in range(tx0, tx1 + 1):
                yield self.get_or_create(tx, ty)

    def composite(self) -> RasterImage:
        canvas = RasterImage.blank(self.width, self.height)
        for tile in self.tiles.values():
            canvas.paste(tile.image, tile.x, tile.y)
        return canvas


RasterBuffer = RasterImage  # alias used by other subsystems for raw pixel math
