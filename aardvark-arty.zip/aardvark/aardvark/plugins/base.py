"""Plugin system (spec section 62): plugins can add brushes, filters,
generators, formats, tools, AI models, fonts, renderers and data
connectors by registering into the relevant subsystem's registry.
"""
from __future__ import annotations

from typing import Callable, Dict, List, Optional


class AardPlugin:
    name: str = "UnnamedPlugin"
    version: str = "0.0.1"

    def register(self, aard) -> None:  # noqa: D102 - see PluginRegistry.register
        """Called once at load time with the plugin API surface (an
        :class:`AardvarkAPI`-like object exposing ``.brushes``,
        ``.filters``, ``.generators``, ``.formats``, ``.tools``, ``.fonts``,
        ``.renderers``, ``.data_connectors`` registries, each with a
        ``.add(name, value)`` method)."""
        raise NotImplementedError


class Registry:
    def __init__(self, kind: str):
        self.kind = kind
        self._items: Dict[str, object] = {}

    def add(self, name: str, value: object) -> None:
        if name in self._items:
            raise ValueError(f"A {self.kind} named {name!r} is already registered")
        self._items[name] = value

    def get(self, name: str) -> object:
        return self._items[name]

    def __contains__(self, name: str) -> bool:
        return name in self._items

    def __iter__(self):
        return iter(self._items.items())

    def names(self) -> List[str]:
        return list(self._items)


class PluginHost:
    """The object passed to ``plugin.register(aard)`` — a namespaced set of
    registries a plugin can extend, plus the loaded-plugin list."""

    def __init__(self):
        self.brushes = Registry("brush")
        self.filters = Registry("filter")
        self.generators = Registry("generator")
        self.formats = Registry("format")
        self.tools = Registry("tool")
        self.fonts = Registry("font")
        self.renderers = Registry("renderer")
        self.data_connectors = Registry("data connector")
        self.loaded: List[AardPlugin] = []

    def load(self, plugin: AardPlugin) -> None:
        plugin.register(self)
        self.loaded.append(plugin)

    def load_all(self, plugins) -> None:
        for p in plugins:
            self.load(p)
