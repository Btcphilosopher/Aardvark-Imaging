"""Rendering architecture (spec section 52): the Document is the source of
truth; a Renderer is a separate, swappable view onto it.

:class:`CPURenderer` is the reference implementation (no GPU dependency,
so it runs anywhere numpy/Pillow run) and is used for on-screen preview,
export, and everything in the test suite. It walks the scene graph,
isolating each object into its own transparent layer (so group opacity
and blend modes composite correctly), transforming vector geometry into
canvas space, and alpha-compositing bottom to top.

``PreviewRenderer`` and ``ExportRenderer`` are thin CPURenderer
subclasses that pick different defaults (fast/low-res vs. high-quality),
matching the spec's naming without pretending there's a GPU backend here
— :class:`GPURenderer` is provided as a documented extension point
(spec section 52) that a plugin can implement against the same interface.
"""
from __future__ import annotations

import math
from typing import Optional, Tuple

import numpy as np
from PIL import Image, ImageDraw

from ..core.object import AardObject, AardObjectType, BlendMode
from ..core.transform import Transform
from ..colour.colour import AardColour
from ..colour.gradient import AardGradient
from ..raster.image import RasterImage
from ..raster.layer import composite
from ..vector.path import Path
from ..typography.text import TextObject


class Renderer:
    """Abstract renderer interface (spec section 52)."""

    def render(self, root: AardObject, width: int, height: int, background: Optional[AardColour] = None) -> RasterImage:
        raise NotImplementedError


class CPURenderer(Renderer):
    def __init__(self, supersample: int = 2, dpi_scale: float = 1.0, max_fill_supersample_px: int = 4_000_000):
        self.supersample = max(1, int(supersample))
        self.dpi_scale = dpi_scale
        self.max_fill_supersample_px = max_fill_supersample_px

    # ------------------------------------------------------------------
    # Public entry points
    # ------------------------------------------------------------------
    def render(self, root: AardObject, width: int, height: int, background: Optional[AardColour] = None) -> RasterImage:
        canvas = RasterImage.blank(width, height, background)
        base_scale = Transform.scaling(self.dpi_scale)
        for child in root.children:
            self._composite_node(child, canvas, width, height, base_scale)
        return canvas

    def render_document(self, document, artboard_index: int = 0) -> RasterImage:
        artboard = document.artboards[artboard_index]
        w = max(1, int(round(artboard.width * self.dpi_scale)))
        h = max(1, int(round(artboard.height * self.dpi_scale)))
        return self.render(artboard.root, w, h, background=artboard.background)

    # ------------------------------------------------------------------
    # Scene graph traversal
    #
    # A node only needs its own full-canvas-sized *isolated* layer when
    # something about ITS OWN compositing requires one: partial opacity, a
    # non-normal blend mode, or a mask — those only produce the right
    # result if the whole subtree is composited as one unit first (spec
    # section 27's "group opacity" semantics). The overwhelming common
    # case — a plain, fully-opaque, normally-blended, unmasked object,
    # which is most leaves in any scene with more than a handful of
    # objects — draws straight onto whatever buffer its parent is already
    # accumulating into, skipping a `width*height*4*4`-byte allocation and
    # a full-canvas blend per object (spec section 51: avoid unnecessary
    # copying of enormous buffers). Region-limited drawing already happens
    # one level down, in _draw_path/_draw_text/_draw_image.
    # ------------------------------------------------------------------
    @staticmethod
    def _needs_isolation(node: AardObject) -> bool:
        return node.opacity < 1.0 or node.blend_mode != BlendMode.NORMAL or node.mask is not None

    def _composite_node(self, node: AardObject, canvas: RasterImage, width: int, height: int, parent_matrix: Transform) -> None:
        if not node.visibility or node.opacity <= 0:
            return
        world_matrix = node.local_matrix().then(parent_matrix)
        if not self._needs_isolation(node):
            self._draw_content(node, canvas, world_matrix)
            for child in node.children:
                self._composite_node(child, canvas, width, height, world_matrix)
            return

        # Isolation is needed for correctness, but not at full-canvas size:
        # confine the temporary layer (and the blend back into `canvas`) to
        # the node's own world-space bounding region. A scene with many
        # small isolated objects (semi-transparent or additively-blended
        # particles/strokes, say) then costs O(sum of each object's own
        # pixel area) rather than O(object count * canvas area).
        subtree_bounds = node.bounds()
        region = None
        if subtree_bounds is not None:
            corners = [
                (subtree_bounds[0], subtree_bounds[1]),
                (subtree_bounds[2], subtree_bounds[1]),
                (subtree_bounds[2], subtree_bounds[3]),
                (subtree_bounds[0], subtree_bounds[3]),
            ]
            world_corners = world_matrix.apply_points(corners)
            xs = [c[0] for c in world_corners]
            ys = [c[1] for c in world_corners]
            pad = 4  # headroom for stroke width / AA
            region = self._canvas_region_for((min(xs) - pad, min(ys) - pad, max(xs) + pad, max(ys) + pad), width, height, pad=0)

        if region is None and subtree_bounds is not None:
            return  # bounded content that falls entirely outside the canvas
        if region is None:
            x0, y0, x1, y1 = 0, 0, width, height  # bounds unavailable — fall back to full canvas
        else:
            x0, y0, x1, y1 = region
        rw, rh = x1 - x0, y1 - y0

        region_matrix = world_matrix.then(Transform.translation(-x0, -y0))
        layer = self._render_isolated_subtree(node, rw, rh, region_matrix)
        if node.mask is not None:
            self._apply_mask(node, layer, region_matrix)
        backdrop = RasterImage(canvas.array[y0:y1, x0:x1].copy(), canvas.bit_depth, canvas.colour_space)
        blended = composite(backdrop, layer, node.blend_mode, node.opacity)
        canvas.array[y0:y1, x0:x1] = blended.array

    def _render_isolated_subtree(self, node: AardObject, width: int, height: int, world_matrix: Transform) -> RasterImage:
        """Render ``node`` and its whole subtree onto one fresh transparent
        layer sized ``(width, height)`` — the node's own region, not
        necessarily the full canvas; see :meth:`_composite_node`. Children
        that don't themselves need isolation are drawn directly onto this
        layer via the same fast path as top-level rendering."""
        layer = RasterImage.blank(width, height)
        self._draw_content(node, layer, world_matrix)
        for child in node.children:
            self._composite_node(child, layer, width, height, world_matrix)
        return layer

    def _apply_mask(self, node: AardObject, layer: RasterImage, world_matrix: Transform) -> None:
        """Multiply ``node.mask`` into ``layer``'s alpha channel.

        A mask is authored in the *object's own local coordinate space*
        (like a layer mask sized to its layer) — a raster mask array is
        exactly as big as the thing it's masking, a vector mask's Path
        uses the same local coordinates as the object's own geometry, and
        so on. So we resolve it against the object's local bounds and map
        that region into canvas space via the object's own world matrix,
        rather than stretching it across the whole canvas (which would
        silently mis-scale a small mask over an unrelated area for any
        object that isn't exactly canvas-sized). Rotation/shear use the
        axis-aligned bounding region as a documented approximation.
        """
        local_bounds = node.bounds()
        if local_bounds is None:
            alpha = node.mask.to_alpha(layer.width, layer.height)
            layer.array[..., 3] *= alpha
            return
        corners = [
            (local_bounds[0], local_bounds[1]),
            (local_bounds[2], local_bounds[1]),
            (local_bounds[2], local_bounds[3]),
            (local_bounds[0], local_bounds[3]),
        ]
        world_corners = world_matrix.apply_points(corners)
        xs = [c[0] for c in world_corners]
        ys = [c[1] for c in world_corners]
        region = self._canvas_region_for((min(xs), min(ys), max(xs), max(ys)), layer.width, layer.height, pad=0)
        if region is None:
            return
        x0, y0, x1, y1 = region
        rw, rh = x1 - x0, y1 - y0
        region_alpha = node.mask.to_alpha(rw, rh, bbox=local_bounds)
        layer.array[y0:y1, x0:x1, 3] *= region_alpha

    # ------------------------------------------------------------------
    # Content drawing
    # ------------------------------------------------------------------
    def _draw_content(self, node: AardObject, layer: RasterImage, world_matrix: Transform) -> None:
        data = node.data
        if data is None:
            return
        if isinstance(data, Path):
            self._draw_path(data, node.style, world_matrix, layer)
        elif isinstance(data, TextObject):
            self._draw_text(data, world_matrix, layer)
        elif isinstance(data, RasterImage):
            self._draw_image(data, world_matrix, layer)

    def _canvas_region_for(self, world_bounds, width, height, pad=2):
        if world_bounds is None:
            return None
        minx, miny, maxx, maxy = world_bounds
        x0 = max(0, int(math.floor(minx)) - pad)
        y0 = max(0, int(math.floor(miny)) - pad)
        x1 = min(width, int(math.ceil(maxx)) + pad)
        y1 = min(height, int(math.ceil(maxy)) + pad)
        if x1 <= x0 or y1 <= y0:
            return None
        return (x0, y0, x1, y1)

    def _draw_path(self, path: Path, style, world_matrix: Transform, layer: RasterImage) -> None:
        world_path = path.transformed(world_matrix)
        wb = world_path.bounds()
        stroke_pad = int(math.ceil((style.stroke_width or 0) / 2)) + 2
        region = self._canvas_region_for(wb, layer.width, layer.height, pad=stroke_pad)
        if region is None:
            return
        x0, y0, x1, y1 = region
        rw, rh = x1 - x0, y1 - y0
        ss = self.supersample if (rw * rh * self.supersample ** 2) <= self.max_fill_supersample_px else 1

        polys = world_path.to_polygons(tolerance=0.3)
        local_polys = [[(px - x0, py - y0) for px, py in poly] for poly in polys]

        try:
            inv = world_matrix.inverse()
        except ZeroDivisionError:
            inv = Transform.identity()

        tile = np.zeros((rh, rw, 4), dtype=np.float32)

        if style.fill is not None and len(local_polys) > 0:
            fill_mask = _xor_fill_mask(local_polys, rw, rh, ss)
            colour_rgba = _colour_or_gradient_grid(style.fill, x0, y0, rw, rh, inv)
            tile = _over(tile, colour_rgba, fill_mask)

        if style.stroke is not None and style.stroke_width > 0:
            stroke_mask = _stroke_mask(local_polys, rw, rh, ss, style.stroke_width, style.stroke_cap, style.stroke_join, path.closed_flags)
            colour_rgba = _colour_or_gradient_grid(style.stroke, x0, y0, rw, rh, inv)
            tile = _over(tile, colour_rgba, stroke_mask)

        layer.array[y0:y1, x0:x1] = _alpha_over(layer.array[y0:y1, x0:x1], tile)

    def _draw_text(self, text: TextObject, world_matrix: Transform, layer: RasterImage) -> None:
        run = text.shape()
        style = text.character_style
        font = text.resolve_font(style)
        pad = int(style.size)
        b = text.bounds()
        if b is None:
            return
        # Local-space tile sized to the text bounds, drawn unrotated, then
        # affine-warped as a block into canvas space (keeps per-glyph
        # kerning exact while still honouring the object's world rotation
        # and scale as a single resample).
        minx, miny, maxx, maxy = b
        local_w = max(1, int(math.ceil(maxx - minx)) + 4)
        local_h = max(1, int(math.ceil(maxy - miny)) + 4)
        local_w = min(local_w, 8000)
        local_h = min(local_h, 8000)
        tile = Image.new("RGBA", (local_w, local_h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(tile)
        for g in run.glyphs:
            gx, gy = g.position[0] - minx + 2, g.position[1] - miny + 2
            colour = (g.style or style).colour
            fill = colour.to_rgb8()
            if abs(g.rotation) > 1e-6:
                glyph_img = Image.new("RGBA", (int(style.size * 3), int(style.size * 3)), (0, 0, 0, 0))
                gdraw = ImageDraw.Draw(glyph_img)
                gdraw.text((style.size, style.size), g.char, font=font, fill=fill)
                rotated = glyph_img.rotate(-g.rotation, resample=Image.BICUBIC, center=(style.size, style.size))
                tile.alpha_composite(rotated, (int(gx - style.size), int(gy - style.size)))
            else:
                draw.text((gx, gy - style.size * 0.8), g.char, font=font, fill=fill)

        self._warp_tile_into_layer(tile, (minx - 2, miny - 2), world_matrix, layer)

    def _draw_image(self, image: RasterImage, world_matrix: Transform, layer: RasterImage) -> None:
        tile = image.to_pil().convert("RGBA")
        self._warp_tile_into_layer(tile, (0, 0), world_matrix, layer)

    def _warp_tile_into_layer(self, tile: Image.Image, local_origin: Tuple[float, float], world_matrix: Transform, layer: RasterImage) -> None:
        """Place a local-space RGBA PIL tile into ``layer`` using an affine warp."""
        ox, oy = local_origin
        # World-space bounding box of the tile's 4 corners.
        corners = [(ox, oy), (ox + tile.width, oy), (ox + tile.width, oy + tile.height), (ox, oy + tile.height)]
        world_corners = world_matrix.apply_points(corners)
        xs = [c[0] for c in world_corners]
        ys = [c[1] for c in world_corners]
        region = self._canvas_region_for((min(xs), min(ys), max(xs), max(ys)), layer.width, layer.height)
        if region is None:
            return
        x0, y0, x1, y1 = region
        rw, rh = x1 - x0, y1 - y0
        try:
            inv = world_matrix.inverse()
        except ZeroDivisionError:
            return
        # PIL's AFFINE transform maps *destination* pixel -> source pixel,
        # i.e. we need (canvas -> local) which is exactly `inv`, offset by
        # the region origin and the tile's local origin.
        a, b, c, d, tx, ty = inv.a, inv.b, inv.c, inv.d, inv.tx, inv.ty
        # dest pixel (px, py) in region-local coords corresponds to canvas
        # coords (px + x0, py + y0); map to local, then to tile pixel space.
        coeffs = (
            a,
            c,
            a * x0 + c * y0 + tx - ox,
            b,
            d,
            b * x0 + d * y0 + ty - oy,
        )
        warped = tile.transform((rw, rh), Image.AFFINE, coeffs, resample=Image.BICUBIC)
        warped_arr = np.asarray(warped).astype(np.float32) / 255.0
        layer.array[y0:y1, x0:x1] = _alpha_over(layer.array[y0:y1, x0:x1], warped_arr)


class PreviewRenderer(CPURenderer):
    """Fast, lower-fidelity renderer for interactive canvas preview."""

    def __init__(self):
        super().__init__(supersample=1, dpi_scale=1.0)


class ExportRenderer(CPURenderer):
    """High-fidelity renderer used for file export."""

    def __init__(self, dpi: float = 300.0, reference_dpi: float = 96.0, supersample: int = 2):
        super().__init__(supersample=supersample, dpi_scale=dpi / reference_dpi)


class GPURenderer(Renderer):  # pragma: no cover - documented extension point
    """Extension point for a hardware-accelerated backend (spec section 52).

    No GPU backend ships with AARDVARK's Python engine; a plugin can
    implement :meth:`render` (e.g. against ModernGL / wgpu) and register
    itself so the rest of the system (export, preview, animation) can pick
    it interchangeably with :class:`CPURenderer`, since both satisfy the
    same :class:`Renderer` interface.
    """

    def render(self, root: AardObject, width: int, height: int, background=None) -> RasterImage:
        raise NotImplementedError("No GPU backend is bundled; implement this in a plugin (see aardvark.plugins).")


# ---------------------------------------------------------------------
# Low-level rasterisation helpers
# ---------------------------------------------------------------------
def _xor_fill_mask(local_polys, width: int, height: int, ss: int) -> np.ndarray:
    """Even-odd-correct fill mask via XOR compositing of each subpath's
    filled region. For a single simple (non-self-intersecting) subpath
    this is exactly a normal fill; for the multi-subpath compound paths
    produced by boolean ops / ring() with opposite winding, XOR is exactly
    the even-odd fill rule."""
    acc = np.zeros((height * ss, width * ss), dtype=bool)
    for poly in local_polys:
        if len(poly) < 3:
            continue
        img = Image.new("1", (width * ss, height * ss), 0)
        draw = ImageDraw.Draw(img)
        pts = [(x * ss, y * ss) for x, y in poly]
        draw.polygon(pts, fill=1)
        acc ^= np.asarray(img, dtype=bool)
    mask_img = Image.fromarray((acc.astype(np.uint8) * 255)).resize((width, height), Image.BILINEAR)
    return np.asarray(mask_img).astype(np.float32) / 255.0


def _stroke_mask(local_polys, width, height, ss, stroke_width, cap, join, closed_flags) -> np.ndarray:
    img = Image.new("L", (width * ss, height * ss), 0)
    draw = ImageDraw.Draw(img)
    w = max(1, int(round(stroke_width * ss)))
    for poly, closed in zip(local_polys, closed_flags):
        if len(poly) < 2:
            continue
        pts = [(x * ss, y * ss) for x, y in poly]
        if closed and pts[0] != pts[-1]:
            pts = pts + [pts[0]]
        try:
            draw.line(pts, fill=255, width=w, joint="curve")
        except TypeError:
            draw.line(pts, fill=255, width=w)
        if cap == "round" or join == "round":
            r = w / 2
            for px, py in pts:
                draw.ellipse([px - r, py - r, px + r, py + r], fill=255)
    mask_img = img.resize((width, height), Image.BILINEAR)
    return np.asarray(mask_img).astype(np.float32) / 255.0


def _colour_or_gradient_grid(fill, x0, y0, w, h, inv_world_matrix: Transform) -> np.ndarray:
    if isinstance(fill, AardColour):
        out = np.empty((h, w, 4), dtype=np.float32)
        out[..., 0] = fill.r
        out[..., 1] = fill.g
        out[..., 2] = fill.b
        out[..., 3] = fill.a
        return out
    if isinstance(fill, AardGradient):
        xs = np.arange(w) + x0 + 0.5
        ys = np.arange(h) + y0 + 0.5
        xx, yy = np.meshgrid(xs, ys)
        a, b, c, d, tx, ty = inv_world_matrix.a, inv_world_matrix.b, inv_world_matrix.c, inv_world_matrix.d, inv_world_matrix.tx, inv_world_matrix.ty
        local_x = a * xx + c * yy + tx
        local_y = b * xx + d * yy + ty
        return _gradient_sample_grid(fill, local_x, local_y)
    # Unknown/unset fill type -> fully transparent.
    return np.zeros((h, w, 4), dtype=np.float32)


def _gradient_sample_grid(gradient: AardGradient, uu: np.ndarray, vv: np.ndarray) -> np.ndarray:
    """Vectorised version of AardGradient.colour_at over a coordinate grid."""
    if gradient.kind == "linear":
        sx, sy = gradient.start
        ex, ey = gradient.end
        dx, dy = ex - sx, ey - sy
        length2 = dx * dx + dy * dy or 1e-9
        t = ((uu - sx) * dx + (vv - sy) * dy) / length2
    elif gradient.kind == "radial":
        cx, cy = gradient.start
        rx, ry = gradient.end
        radius = math.hypot(rx - cx, ry - cy) or 1e-9
        t = np.hypot(uu - cx, vv - cy) / radius
    elif gradient.kind == "angular":
        cx, cy = gradient.start
        t = (np.arctan2(vv - cy, uu - cx) + math.pi) / (2 * math.pi)
    else:  # diamond
        cx, cy = gradient.start
        rx, ry = gradient.end
        half_w = abs(rx - cx) or 1e-9
        half_h = abs(ry - cy) or 1e-9
        t = np.abs(uu - cx) / half_w + np.abs(vv - cy) / half_h

    if gradient.noise:
        t = t + gradient.noise * (np.sin(uu * 37.1 + vv * 19.7) * 0.5)
    t = np.clip(t, 0.0, 1.0)

    h, w = t.shape
    out = np.zeros((h, w, 4), dtype=np.float32)
    stops = gradient.stops
    if not stops:
        return out
    if len(stops) == 1:
        c = stops[0].colour
        out[..., :] = [c.r, c.g, c.b, c.a]
        return out
    for i in range(len(stops) - 1):
        s0, s1 = stops[i], stops[i + 1]
        upper_inclusive = i == len(stops) - 2
        mask = (t >= s0.offset) & ((t <= s1.offset) if upper_inclusive else (t < s1.offset))
        span = (s1.offset - s0.offset) or 1e-9
        local_t = np.clip((t - s0.offset) / span, 0, 1)
        for ch, attr in enumerate("rgba"):
            c0, c1 = getattr(s0.colour, attr), getattr(s1.colour, attr)
            out[..., ch] = np.where(mask, c0 + (c1 - c0) * local_t, out[..., ch])
    out[t <= stops[0].offset] = [stops[0].colour.r, stops[0].colour.g, stops[0].colour.b, stops[0].colour.a]
    out[t >= stops[-1].offset] = [stops[-1].colour.r, stops[-1].colour.g, stops[-1].colour.b, stops[-1].colour.a]
    return out


def _over(dest: np.ndarray, src_rgba: np.ndarray, src_alpha_mask: np.ndarray) -> np.ndarray:
    src = src_rgba.copy()
    src[..., 3] = src[..., 3] * src_alpha_mask
    return _alpha_over(dest, src)


def _alpha_over(dest: np.ndarray, src: np.ndarray) -> np.ndarray:
    sa = src[..., 3:4]
    da = dest[..., 3:4]
    out_a = sa + da * (1 - sa)
    safe = np.where(out_a > 1e-6, out_a, 1.0)
    out_rgb = (src[..., :3] * sa + dest[..., :3] * da * (1 - sa)) / safe
    return np.concatenate([out_rgb, out_a], axis=-1).astype(np.float32)
