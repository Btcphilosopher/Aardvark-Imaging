"""2D particle system (spec section 35): particles with position, velocity,
acceleration, mass, life, colour, size, rotation, opacity, driven by
composable forces (gravity, wind, noise, attraction, repulsion, vortex,
drag, flow field).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable, List, Optional, Tuple

import numpy as np

from ..colour.colour import AardColour

Point = Tuple[float, float]


@dataclass
class Particle:
    position: Point
    velocity: Point = (0.0, 0.0)
    acceleration: Point = (0.0, 0.0)
    mass: float = 1.0
    life: float = 1.0  # remaining life, 0..1 typically, decremented externally
    max_life: float = 1.0
    colour: AardColour = field(default_factory=lambda: AardColour(1, 1, 1))
    size: float = 4.0
    rotation: float = 0.0
    opacity: float = 1.0
    trail: List[Point] = field(default_factory=list)

    @property
    def alive(self) -> bool:
        return self.life > 0


Force = Callable[[Particle, float], Tuple[float, float]]


def gravity(gx: float = 0.0, gy: float = 98.0) -> Force:
    return lambda p, dt: (gx, gy)


def wind(wx: float, wy: float = 0.0) -> Force:
    return lambda p, dt: (wx, wy)


def drag(coefficient: float = 0.02) -> Force:
    def fn(p: Particle, dt: float):
        vx, vy = p.velocity
        speed = math.hypot(vx, vy)
        return (-coefficient * vx * speed, -coefficient * vy * speed)

    return fn


def attraction(center: Point, strength: float = 500.0) -> Force:
    def fn(p: Particle, dt: float):
        dx, dy = center[0] - p.position[0], center[1] - p.position[1]
        dist2 = dx * dx + dy * dy + 1e-6
        dist = math.sqrt(dist2)
        f = strength / dist2
        return (f * dx / dist, f * dy / dist)

    return fn


def repulsion(center: Point, strength: float = 500.0) -> Force:
    fn = attraction(center, -strength)
    return fn


def vortex(center: Point, strength: float = 200.0) -> Force:
    def fn(p: Particle, dt: float):
        dx, dy = p.position[0] - center[0], p.position[1] - center[1]
        dist = math.hypot(dx, dy) + 1e-6
        tx, ty = -dy / dist, dx / dist
        return (tx * strength, ty * strength)

    return fn


def noise_force(strength: float = 100.0, scale: float = 0.01, seed: int = 0) -> Force:
    from ..procedural.noise import perlin

    def fn(p: Particle, dt: float):
        x, y = p.position
        angle = perlin(np.array([x * scale]), np.array([y * scale]), seed=seed)[0] * math.pi * 2
        return (math.cos(angle) * strength, math.sin(angle) * strength)

    return fn


def flow_field_force(field_fn: Callable[[float, float], Tuple[float, float]], strength: float = 300.0) -> Force:
    """Wrap a scalar field function (x, y) -> (dx, dy) (e.g.
    :func:`aardvark.procedural.flowfield.curl_noise` sampled pointwise) as
    a particle force."""

    def fn(p: Particle, dt: float):
        dx, dy = field_fn(*p.position)
        return (dx * strength, dy * strength)

    return fn


class ParticleSystem:
    def __init__(self, particles: Optional[List[Particle]] = None):
        self.particles: List[Particle] = particles or []
        self.forces: List[Force] = []
        self.record_trails = False
        self.max_trail_length = 60

    def add_force(self, force: Force) -> "ParticleSystem":
        self.forces.append(force)
        return self

    def emit(self, n: int, origin: Point, spread: float = 10.0, speed: float = 50.0, life: float = 1.0, colour: Optional[AardColour] = None, seed: Optional[int] = None) -> "ParticleSystem":
        rng = np.random.default_rng(seed)
        for _ in range(n):
            angle = rng.uniform(0, 2 * math.pi)
            s = rng.uniform(0, speed)
            ox = origin[0] + rng.normal(0, spread)
            oy = origin[1] + rng.normal(0, spread)
            self.particles.append(
                Particle(
                    position=(ox, oy),
                    velocity=(math.cos(angle) * s, math.sin(angle) * s),
                    life=life,
                    max_life=life,
                    colour=colour or AardColour(1, 1, 1),
                )
            )
        return self

    def step(self, dt: float = 1 / 60) -> None:
        for p in self.particles:
            if not p.alive:
                continue
            ax, ay = 0.0, 0.0
            for force in self.forces:
                fx, fy = force(p, dt)
                ax += fx / p.mass
                ay += fy / p.mass
            vx, vy = p.velocity
            vx += ax * dt
            vy += ay * dt
            x, y = p.position
            x += vx * dt
            y += vy * dt
            p.velocity = (vx, vy)
            p.position = (x, y)
            p.life -= dt
            p.opacity = max(0.0, min(1.0, p.life / p.max_life)) if p.max_life else p.opacity
            if self.record_trails:
                p.trail.append(p.position)
                if len(p.trail) > self.max_trail_length:
                    p.trail.pop(0)
        self.particles = [p for p in self.particles if p.alive]

    def simulate(self, steps: int, dt: float = 1 / 60) -> None:
        for _ in range(steps):
            self.step(dt)
