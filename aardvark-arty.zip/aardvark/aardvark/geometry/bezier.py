"""Bezier mathematics: evaluation, flattening, arcs, length, splitting.

All curves are represented with plain float ``(x, y)`` tuples so this
module has no dependency on the object model and can be unit-tested in
isolation (spec section 81: "Bezier mathematics" is an explicit test
target).
"""
from __future__ import annotations

import math
from typing import List, Tuple

Point = Tuple[float, float]


def lerp(p0: Point, p1: Point, t: float) -> Point:
    return (p0[0] + (p1[0] - p0[0]) * t, p0[1] + (p1[1] - p0[1]) * t)


def quadratic_point(p0: Point, p1: Point, p2: Point, t: float) -> Point:
    a = lerp(p0, p1, t)
    b = lerp(p1, p2, t)
    return lerp(a, b, t)


def cubic_point(p0: Point, p1: Point, p2: Point, p3: Point, t: float) -> Point:
    mt = 1 - t
    x = (
        mt ** 3 * p0[0]
        + 3 * mt ** 2 * t * p1[0]
        + 3 * mt * t ** 2 * p2[0]
        + t ** 3 * p3[0]
    )
    y = (
        mt ** 3 * p0[1]
        + 3 * mt ** 2 * t * p1[1]
        + 3 * mt * t ** 2 * p2[1]
        + t ** 3 * p3[1]
    )
    return (x, y)


def quadratic_to_cubic(p0: Point, p1: Point, p2: Point) -> Tuple[Point, Point, Point, Point]:
    """Exact degree-elevation of a quadratic to an equivalent cubic Bezier."""
    c1 = (p0[0] + 2 / 3 * (p1[0] - p0[0]), p0[1] + 2 / 3 * (p1[1] - p0[1]))
    c2 = (p2[0] + 2 / 3 * (p1[0] - p2[0]), p2[1] + 2 / 3 * (p1[1] - p2[1]))
    return p0, c1, c2, p2


def cubic_derivative(p0: Point, p1: Point, p2: Point, p3: Point, t: float) -> Point:
    mt = 1 - t
    x = 3 * mt ** 2 * (p1[0] - p0[0]) + 6 * mt * t * (p2[0] - p1[0]) + 3 * t ** 2 * (p3[0] - p2[0])
    y = 3 * mt ** 2 * (p1[1] - p0[1]) + 6 * mt * t * (p2[1] - p1[1]) + 3 * t ** 2 * (p3[1] - p2[1])
    return (x, y)


def cubic_tangent(p0: Point, p1: Point, p2: Point, p3: Point, t: float) -> Point:
    dx, dy = cubic_derivative(p0, p1, p2, p3, t)
    length = math.hypot(dx, dy)
    if length < 1e-12:
        return (0.0, 0.0)
    return (dx / length, dy / length)


def cubic_normal(p0: Point, p1: Point, p2: Point, p3: Point, t: float) -> Point:
    tx, ty = cubic_tangent(p0, p1, p2, p3, t)
    return (-ty, tx)


def flatten_cubic(
    p0: Point, p1: Point, p2: Point, p3: Point, tolerance: float = 0.25, max_depth: int = 24
) -> List[Point]:
    """Adaptively flatten a cubic Bezier into a polyline (excludes p0, includes p3)."""

    def is_flat_enough(a, b, c, d) -> bool:
        # Distance of control points from the chord a-d.
        ux = 3 * b[0] - 2 * a[0] - d[0]
        uy = 3 * b[1] - 2 * a[1] - d[1]
        vx = 3 * c[0] - a[0] - 2 * d[0]
        vy = 3 * c[1] - a[1] - 2 * d[1]
        ux, uy, vx, vy = ux * ux, uy * uy, vx * vx, vy * vy
        if ux < vx:
            ux = vx
        if uy < vy:
            uy = vy
        return (ux + uy) <= 16 * tolerance * tolerance

    result: List[Point] = []

    def recurse(a, b, c, d, depth):
        if depth >= max_depth or is_flat_enough(a, b, c, d):
            result.append(d)
            return
        ab = lerp(a, b, 0.5)
        bc = lerp(b, c, 0.5)
        cd = lerp(c, d, 0.5)
        abbc = lerp(ab, bc, 0.5)
        bccd = lerp(bc, cd, 0.5)
        mid = lerp(abbc, bccd, 0.5)
        recurse(a, ab, abbc, mid, depth + 1)
        recurse(mid, bccd, cd, d, depth + 1)

    recurse(p0, p1, p2, p3, 0)
    return result


def split_cubic(p0: Point, p1: Point, p2: Point, p3: Point, t: float):
    """De Casteljau split. Returns (left_curve, right_curve), each a 4-tuple."""
    ab = lerp(p0, p1, t)
    bc = lerp(p1, p2, t)
    cd = lerp(p2, p3, t)
    abbc = lerp(ab, bc, t)
    bccd = lerp(bc, cd, t)
    m = lerp(abbc, bccd, t)
    return (p0, ab, abbc, m), (m, bccd, cd, p3)


def cubic_length(p0: Point, p1: Point, p2: Point, p3: Point, tolerance: float = 0.1) -> float:
    pts = [p0] + flatten_cubic(p0, p1, p2, p3, tolerance=tolerance)
    return polyline_length(pts)


def polyline_length(points: List[Point]) -> float:
    total = 0.0
    for (x0, y0), (x1, y1) in zip(points, points[1:]):
        total += math.hypot(x1 - x0, y1 - y0)
    return total


def cubic_bbox(p0: Point, p1: Point, p2: Point, p3: Point) -> Tuple[float, float, float, float]:
    """Tight bounding box using the analytic extrema of the cubic."""
    xs = [p0[0], p3[0]]
    ys = [p0[1], p3[1]]
    for i in (0, 1):
        a = -p0[i] + 3 * p1[i] - 3 * p2[i] + p3[i]
        b = 2 * (p0[i] - 2 * p1[i] + p2[i])
        c = p1[i] - p0[i]
        roots = []
        if abs(a) < 1e-12:
            if abs(b) > 1e-12:
                roots.append(-c / b)
        else:
            disc = b * b - 4 * a * c
            if disc >= 0:
                sq = math.sqrt(disc)
                roots.append((-b + sq) / (2 * a))
                roots.append((-b - sq) / (2 * a))
        for t in roots:
            if 0 <= t <= 1:
                pt = cubic_point(p0, p1, p2, p3, t)
                (xs if i == 0 else ys).append(pt[i])
    return (min(xs), min(ys), max(xs), max(ys))


def arc_to_cubics(
    cx: float, cy: float, rx: float, ry: float, start_angle: float, end_angle: float, rotation: float = 0.0
) -> List[Tuple[Point, Point, Point, Point]]:
    """Approximate a circular/elliptical arc with cubic Bezier segments.

    Angles are in radians, measured from the ellipse's local +x axis.
    Splits into segments of at most 90 degrees for good accuracy, using
    the standard 4/3*tan(theta/4) control-point-length approximation.
    """
    segments: List[Tuple[Point, Point, Point, Point]] = []
    total = end_angle - start_angle
    if total == 0:
        return segments
    direction = 1 if total > 0 else -1
    remaining = abs(total)
    max_seg = math.pi / 2
    angle = start_angle
    cos_r, sin_r = math.cos(rotation), math.sin(rotation)

    def to_world(x, y):
        return (cx + x * cos_r - y * sin_r, cy + x * sin_r + y * cos_r)

    while remaining > 1e-9:
        seg = min(max_seg, remaining)
        a0 = angle
        a1 = angle + direction * seg
        alpha = math.tan((a1 - a0) / 4) * 4 / 3
        p0 = (rx * math.cos(a0), ry * math.sin(a0))
        p3 = (rx * math.cos(a1), ry * math.sin(a1))
        p1 = (p0[0] - alpha * rx * math.sin(a0), p0[1] + alpha * ry * math.cos(a0))
        p2 = (p3[0] + alpha * rx * math.sin(a1), p3[1] - alpha * ry * math.cos(a1))
        segments.append((to_world(*p0), to_world(*p1), to_world(*p2), to_world(*p3)))
        angle = a1
        remaining -= seg
    return segments


def endpoint_arc_to_center(
    x0, y0, x1, y1, rx, ry, x_rotation_deg, large_arc, sweep
):
    """SVG-style endpoint arc parameterisation -> centre parameterisation.

    Returns (cx, cy, rx, ry, start_angle, end_angle, rotation_rad) suitable
    for :func:`arc_to_cubics`.
    """
    if rx == 0 or ry == 0:
        return None
    phi = math.radians(x_rotation_deg)
    cos_phi, sin_phi = math.cos(phi), math.sin(phi)
    dx2, dy2 = (x0 - x1) / 2.0, (y0 - y1) / 2.0
    x1p = cos_phi * dx2 + sin_phi * dy2
    y1p = -sin_phi * dx2 + cos_phi * dy2

    rx, ry = abs(rx), abs(ry)
    lam = (x1p ** 2) / (rx ** 2) + (y1p ** 2) / (ry ** 2)
    if lam > 1:
        s = math.sqrt(lam)
        rx *= s
        ry *= s

    sign = -1 if large_arc == sweep else 1
    num = rx ** 2 * ry ** 2 - rx ** 2 * y1p ** 2 - ry ** 2 * x1p ** 2
    den = rx ** 2 * y1p ** 2 + ry ** 2 * x1p ** 2
    co = sign * math.sqrt(max(num / den, 0.0)) if den else 0.0
    cxp = co * (rx * y1p / ry)
    cyp = co * -(ry * x1p / rx)

    cx = cos_phi * cxp - sin_phi * cyp + (x0 + x1) / 2.0
    cy = sin_phi * cxp + cos_phi * cyp + (y0 + y1) / 2.0

    def angle(ux, uy, vx, vy):
        dot = ux * vx + uy * vy
        length = math.hypot(ux, uy) * math.hypot(vx, vy)
        ang = math.acos(max(-1, min(1, dot / length))) if length else 0.0
        if ux * vy - uy * vx < 0:
            ang = -ang
        return ang

    start_angle = angle(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry)
    delta = angle((x1p - cxp) / rx, (y1p - cyp) / ry, (-x1p - cxp) / rx, (-y1p - cyp) / ry)
    if not sweep and delta > 0:
        delta -= 2 * math.pi
    elif sweep and delta < 0:
        delta += 2 * math.pi

    return cx, cy, rx, ry, start_angle, start_angle + delta, phi
