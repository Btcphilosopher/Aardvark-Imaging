"""Compositional analysis (spec section 23): balance, symmetry, density,
negative space, visual weight, alignment, contrast, hierarchy — computed
as guides/metrics, never automatically dictating the design.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import List, Tuple

import numpy as np

from ..raster.image import RasterImage


@dataclass
class CompositionReport:
    balance: Tuple[float, float]  # centre of visual mass, normalised [-1, 1] offset from canvas center
    density: float  # fraction of non-transparent / non-background pixels
    negative_space: float  # 1 - density
    symmetry_horizontal: float  # 0..1, 1 = perfectly mirror-symmetric left/right
    symmetry_vertical: float
    visual_weight_grid: np.ndarray  # coarse (rows, cols) weight map
    contrast: float  # stddev of luminance, a crude global-contrast proxy

    def summary(self) -> str:
        bx, by = self.balance
        lean = []
        if abs(bx) > 0.08:
            lean.append("right" if bx > 0 else "left")
        if abs(by) > 0.08:
            lean.append("bottom" if by > 0 else "top")
        lean_txt = f"leans {' & '.join(lean)}" if lean else "centred"
        return (
            f"density={self.density:.2f} negative_space={self.negative_space:.2f} "
            f"balance={lean_txt} h_symmetry={self.symmetry_horizontal:.2f} "
            f"v_symmetry={self.symmetry_vertical:.2f} contrast={self.contrast:.2f}"
        )


def _luminance_and_weight(image: RasterImage) -> Tuple[np.ndarray, np.ndarray]:
    rgb = image.array[..., :3]
    alpha = image.array[..., 3]
    luminance = 0.2126 * rgb[..., 0] + 0.7152 * rgb[..., 1] + 0.0722 * rgb[..., 2]
    # "Visual weight" here treats darker + more opaque + more saturated
    # pixels as heavier — a simple, documented heuristic, not a perceptual model.
    saturation = np.max(rgb, axis=-1) - np.min(rgb, axis=-1)
    weight = alpha * (1.0 - luminance * 0.5) * (0.6 + 0.4 * saturation)
    return luminance, weight


def analyse(image: RasterImage, grid_size: int = 8) -> CompositionReport:
    """Note: ``density``/``negative_space`` are measured from the alpha
    channel, so render onto a *transparent* background (no artboard fill)
    before analysing — an opaque background fill will otherwise read as
    100% density, which is correct by definition but rarely what you want."""
    luminance, weight = _luminance_and_weight(image)
    h, w = weight.shape
    total_weight = weight.sum()

    yy, xx = np.mgrid[0:h, 0:w]
    if total_weight > 1e-9:
        cx = (xx * weight).sum() / total_weight
        cy = (yy * weight).sum() / total_weight
    else:
        cx, cy = w / 2, h / 2
    balance = (2 * (cx - w / 2) / w, 2 * (cy - h / 2) / h)

    alpha = image.array[..., 3]
    density = float((alpha > 0.02).mean())

    left = weight[:, : w // 2]
    right = weight[:, w // 2 :][:, ::-1]
    min_w = min(left.shape[1], right.shape[1])
    h_diff = np.abs(left[:, :min_w] - right[:, :min_w]).sum()
    h_total = left[:, :min_w].sum() + right[:, :min_w].sum() + 1e-9
    symmetry_h = 1.0 - min(1.0, h_diff / h_total)

    top = weight[: h // 2, :]
    bottom = weight[h // 2 :, :][::-1, :]
    min_h = min(top.shape[0], bottom.shape[0])
    v_diff = np.abs(top[:min_h] - bottom[:min_h]).sum()
    v_total = top[:min_h].sum() + bottom[:min_h].sum() + 1e-9
    symmetry_v = 1.0 - min(1.0, v_diff / v_total)

    gy = max(1, h // grid_size)
    gx = max(1, w // grid_size)
    weight_grid = weight[: gy * grid_size, : gx * grid_size].reshape(grid_size, gy, grid_size, gx).mean(axis=(1, 3)) if h >= grid_size and w >= grid_size else weight

    contrast = float(luminance[alpha > 0.02].std()) if density > 0 else 0.0

    return CompositionReport(
        balance=balance,
        density=density,
        negative_space=1 - density,
        symmetry_horizontal=symmetry_h,
        symmetry_vertical=symmetry_v,
        visual_weight_grid=weight_grid,
        contrast=contrast,
    )


def rule_of_thirds_lines(width: float, height: float) -> List[Tuple[Tuple[float, float], Tuple[float, float]]]:
    lines = []
    for i in (1, 2):
        x = width * i / 3
        lines.append(((x, 0), (x, height)))
    for i in (1, 2):
        y = height * i / 3
        lines.append(((0, y), (width, y)))
    return lines


def alignment_guides(bounds_list: List[Tuple[float, float, float, float]], tolerance: float = 2.0) -> dict:
    """Given a list of (minx, miny, maxx, maxy) object bounds, report which
    edges/centres are (nearly) aligned across objects — used to render
    "snap" guides."""
    edges = {"left": [], "right": [], "top": [], "bottom": [], "center_x": [], "center_y": []}
    for i, (minx, miny, maxx, maxy) in enumerate(bounds_list):
        edges["left"].append((i, minx))
        edges["right"].append((i, maxx))
        edges["top"].append((i, miny))
        edges["bottom"].append((i, maxy))
        edges["center_x"].append((i, (minx + maxx) / 2))
        edges["center_y"].append((i, (miny + maxy) / 2))

    groups = {}
    for edge_name, values in edges.items():
        values_sorted = sorted(values, key=lambda v: v[1])
        clusters = []
        current = [values_sorted[0]] if values_sorted else []
        for prev, curr in zip(values_sorted, values_sorted[1:]):
            if abs(curr[1] - prev[1]) <= tolerance:
                current.append(curr)
            else:
                if len(current) > 1:
                    clusters.append(current)
                current = [curr]
        if len(current) > 1:
            clusters.append(current)
        groups[edge_name] = clusters
    return groups
