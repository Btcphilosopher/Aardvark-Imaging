"""Palette engine: harmony generation and image colour extraction (section 17)."""
from __future__ import annotations

from typing import List, Optional

from .colour import AardColour


class AardPalette:
    def __init__(self, colours: Optional[List[AardColour]] = None, name: str = "Palette"):
        self.name = name
        self.colours: List[AardColour] = colours or []

    def add(self, colour: AardColour) -> "AardPalette":
        self.colours.append(colour)
        return self

    def __len__(self):
        return len(self.colours)

    def __iter__(self):
        return iter(self.colours)

    def __getitem__(self, i):
        return self.colours[i]

    def sorted_by_luminance(self) -> "AardPalette":
        return AardPalette(sorted(self.colours, key=lambda c: c.luminance()), self.name)

    def to_dict(self) -> dict:
        return {"name": self.name, "colours": [c.to_dict() for c in self.colours]}

    @classmethod
    def from_dict(cls, d: dict) -> "AardPalette":
        return cls([AardColour.from_dict(c) for c in d["colours"]], d.get("name", "Palette"))


# ----------------------------------------------------------------------
# Harmony generators
# ----------------------------------------------------------------------
def complementary(base: AardColour) -> AardPalette:
    return AardPalette([base, base.rotate_hue(180)], "Complementary")


def analogous(base: AardColour, spread: float = 30, count: int = 3) -> AardPalette:
    half = (count - 1) / 2
    return AardPalette([base.rotate_hue(spread * (i - half)) for i in range(count)], "Analogous")


def triadic(base: AardColour) -> AardPalette:
    return AardPalette([base, base.rotate_hue(120), base.rotate_hue(240)], "Triadic")


def split_complementary(base: AardColour, spread: float = 30) -> AardPalette:
    return AardPalette([base, base.rotate_hue(180 - spread), base.rotate_hue(180 + spread)], "Split Complementary")


def monochromatic(base: AardColour, count: int = 5) -> AardPalette:
    h, s, l = base.to_hsl()
    lights = [max(0.06, min(0.94, l + (i - count // 2) * (0.8 / count))) for i in range(count)]
    return AardPalette([AardColour.from_hsl(h, s, lv) for lv in lights], "Monochromatic")


def tetradic(base: AardColour) -> AardPalette:
    return AardPalette([base, base.rotate_hue(90), base.rotate_hue(180), base.rotate_hue(270)], "Tetradic")


def generate_harmony(base: AardColour, scheme: str = "complementary", **kwargs) -> AardPalette:
    generators = {
        "complementary": complementary,
        "analogous": analogous,
        "triadic": triadic,
        "split_complementary": split_complementary,
        "monochromatic": monochromatic,
        "tetradic": tetradic,
    }
    if scheme not in generators:
        raise ValueError(f"Unknown harmony scheme: {scheme!r}. Choose from {list(generators)}")
    return generators[scheme](base, **kwargs)


# ----------------------------------------------------------------------
# Palette extraction from a raster image
# ----------------------------------------------------------------------
def extract_from_image(image, n_colours: int = 6, sample: int = 4000) -> AardPalette:
    """K-means colour clustering over an image's pixels.

    ``image`` may be a PIL Image, a RasterImage, or a numpy HxWx3/4 array.
    Falls back to a coarse histogram bucketing if scipy is unavailable.
    """
    import numpy as np

    arr = _as_rgb_array(image)
    h, w, _ = arr.shape
    pixels = arr.reshape(-1, 3).astype(float)
    if pixels.shape[0] > sample:
        idx = np.random.default_rng(0).choice(pixels.shape[0], sample, replace=False)
        pixels = pixels[idx]

    try:
        from scipy.cluster.vq import kmeans2

        centroids, _ = kmeans2(pixels, n_colours, seed=0, minit="++")
    except Exception:
        # Fallback: simple binning by quantised colour.
        quant = (pixels // 32).astype(int)
        uniques, counts = np.unique(quant, axis=0, return_counts=True)
        order = np.argsort(-counts)[:n_colours]
        centroids = (uniques[order] * 32 + 16).astype(float)

    colours = [AardColour(*(c / 255.0 for c in centroid[:3]), 1.0) for centroid in centroids]
    return AardPalette(colours, "Extracted")


def _as_rgb_array(image):
    import numpy as np

    if hasattr(image, "to_numpy"):
        arr = image.to_numpy()
    elif hasattr(image, "array"):
        arr = image.array
    else:
        arr = np.asarray(image.convert("RGB") if hasattr(image, "convert") else image)
    arr = np.clip(arr, 0, 255) if arr.dtype != np.uint8 else arr
    if arr.ndim == 2:
        arr = np.stack([arr] * 3, axis=-1)
    if arr.shape[-1] == 4:
        arr = arr[..., :3]
    if arr.dtype != np.uint8:
        arr = (arr * 255 if arr.max() <= 1.0 else arr).astype(np.uint8)
    return arr
