"""Gradient engine (spec section 18): linear, radial, angular, diamond,
multi-stop and noise-perturbed gradients with editable stops."""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Tuple

from .colour import AardColour


@dataclass
class GradientStop:
    offset: float  # 0..1
    colour: AardColour

    def to_dict(self):
        return {"offset": self.offset, "colour": self.colour.to_dict()}

    @classmethod
    def from_dict(cls, d):
        return cls(d["offset"], AardColour.from_dict(d["colour"]))


class AardGradient:
    KINDS = ("linear", "radial", "angular", "diamond")

    def __init__(
        self,
        kind: str = "linear",
        stops: List[GradientStop] | None = None,
        start: Tuple[float, float] = (0.0, 0.0),
        end: Tuple[float, float] = (1.0, 0.0),
        noise: float = 0.0,
    ):
        if kind not in self.KINDS:
            raise ValueError(f"Unknown gradient kind {kind!r}; choose from {self.KINDS}")
        self.kind = kind
        self.stops: List[GradientStop] = sorted(stops or [], key=lambda s: s.offset)
        self.start = start  # for linear: line start; for radial/angular/diamond: centre
        self.end = end  # for linear: line end; for radial: defines radius via distance
        self.noise = noise  # 0..1 amount of procedural turbulence added to the offset

    @classmethod
    def linear(cls, colours: List[AardColour], start=(0, 0), end=(1, 0)) -> "AardGradient":
        stops = [GradientStop(i / (len(colours) - 1) if len(colours) > 1 else 0.0, c) for i, c in enumerate(colours)]
        return cls("linear", stops, start, end)

    @classmethod
    def radial(cls, colours: List[AardColour], center=(0.5, 0.5), radius_point=(1.0, 0.5)) -> "AardGradient":
        stops = [GradientStop(i / (len(colours) - 1) if len(colours) > 1 else 0.0, c) for i, c in enumerate(colours)]
        return cls("radial", stops, center, radius_point)

    def add_stop(self, offset: float, colour: AardColour) -> "AardGradient":
        self.stops.append(GradientStop(offset, colour))
        self.stops.sort(key=lambda s: s.offset)
        return self

    def remove_stop(self, index: int) -> "AardGradient":
        del self.stops[index]
        return self

    def sample(self, t: float) -> AardColour:
        """Sample the colour ramp (ignoring spatial kind) at parameter t in [0,1]."""
        if not self.stops:
            return AardColour(0, 0, 0, 0)
        if len(self.stops) == 1:
            return self.stops[0].colour
        t = max(0.0, min(1.0, t))
        if t <= self.stops[0].offset:
            return self.stops[0].colour
        if t >= self.stops[-1].offset:
            return self.stops[-1].colour
        for s0, s1 in zip(self.stops, self.stops[1:]):
            if s0.offset <= t <= s1.offset:
                span = s1.offset - s0.offset
                local_t = (t - s0.offset) / span if span else 0
                return s0.colour.mix(s1.colour, local_t)
        return self.stops[-1].colour

    def value_at(self, u: float, v: float) -> float:
        """Spatial parameter t in [0,1] for a point (u, v) in unit gradient space,
        before the colour ramp is applied. (u, v) are typically the bounding-box
        normalised coordinates of a fill point."""
        if self.kind == "linear":
            sx, sy = self.start
            ex, ey = self.end
            dx, dy = ex - sx, ey - sy
            length2 = dx * dx + dy * dy
            if length2 == 0:
                return 0.0
            t = ((u - sx) * dx + (v - sy) * dy) / length2
        elif self.kind == "radial":
            cx, cy = self.start
            rx, ry = self.end
            radius = math.hypot(rx - cx, ry - cy) or 1e-9
            t = math.hypot(u - cx, v - cy) / radius
        elif self.kind == "angular":
            cx, cy = self.start
            ang = math.atan2(v - cy, u - cx)
            t = (ang + math.pi) / (2 * math.pi)
        elif self.kind == "diamond":
            cx, cy = self.start
            rx, ry = self.end
            half_w = abs(rx - cx) or 1e-9
            half_h = abs(ry - cy) or 1e-9
            t = abs(u - cx) / half_w + abs(v - cy) / half_h
        else:  # pragma: no cover
            t = 0.0
        if self.noise:
            t += self.noise * (math.sin(u * 37.1 + v * 19.7) * 0.5)
        return max(0.0, min(1.0, t))

    def colour_at(self, u: float, v: float) -> AardColour:
        return self.sample(self.value_at(u, v))

    def rasterize(self, width: int, height: int, bbox: Tuple[float, float, float, float] | None = None):
        """Render the gradient into an (H, W, 4) float32 numpy array in [0,1],
        mapping pixel space to the gradient's unit coordinate space via bbox
        (minx, miny, maxx, maxy); defaults to the pixel rect itself."""
        import numpy as np

        if bbox is None:
            bbox = (0, 0, width, height)
        minx, miny, maxx, maxy = bbox
        xs = (np.arange(width) + 0.5) / width * (maxx - minx) + minx
        ys = (np.arange(height) + 0.5) / height * (maxy - miny) + miny
        uu, vv = np.meshgrid(xs, ys)

        out = np.zeros((height, width, 4), dtype=np.float32)
        # Vectorised sampling of value_at + ramp for the supported kinds.
        if self.kind == "linear":
            sx, sy = self.start
            ex, ey = self.end
            dx, dy = ex - sx, ey - sy
            length2 = dx * dx + dy * dy or 1e-9
            t = ((uu - sx) * dx + (vv - sy) * dy) / length2
        elif self.kind == "radial":
            cx, cy = self.start
            rx, ry = self.end
            radius = math.hypot(rx - cx, ry - cy) or 1e-9
            t = np.hypot(uu - cx, vv - cy) / radius
        elif self.kind == "angular":
            cx, cy = self.start
            t = (np.arctan2(vv - cy, uu - cx) + math.pi) / (2 * math.pi)
        else:  # diamond
            cx, cy = self.start
            rx, ry = self.end
            half_w = abs(rx - cx) or 1e-9
            half_h = abs(ry - cy) or 1e-9
            t = np.abs(uu - cx) / half_w + np.abs(vv - cy) / half_h

        if self.noise:
            t = t + self.noise * (np.sin(uu * 37.1 + vv * 19.7) * 0.5)
        t = np.clip(t, 0.0, 1.0)

        if not self.stops:
            return out
        stops = self.stops
        for i in range(len(stops) - 1):
            s0, s1 = stops[i], stops[i + 1]
            mask = (t >= s0.offset) & (t <= s1.offset if i == len(stops) - 2 else t < s1.offset)
            span = (s1.offset - s0.offset) or 1e-9
            local_t = np.clip((t - s0.offset) / span, 0, 1)
            for ch in range(4):
                c0 = getattr(s0.colour, "rgba"[ch])
                c1 = getattr(s1.colour, "rgba"[ch])
                out[..., ch] = np.where(mask, c0 + (c1 - c0) * local_t, out[..., ch])
        out[t <= stops[0].offset] = np.array([stops[0].colour.r, stops[0].colour.g, stops[0].colour.b, stops[0].colour.a])
        out[t >= stops[-1].offset] = np.array(
            [stops[-1].colour.r, stops[-1].colour.g, stops[-1].colour.b, stops[-1].colour.a]
        )
        return out

    def to_dict(self) -> dict:
        return {
            "kind": self.kind,
            "stops": [s.to_dict() for s in self.stops],
            "start": list(self.start),
            "end": list(self.end),
            "noise": self.noise,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "AardGradient":
        return cls(
            d["kind"],
            [GradientStop.from_dict(s) for s in d["stops"]],
            tuple(d["start"]),
            tuple(d["end"]),
            d.get("noise", 0.0),
        )
