"""First-class colour objects and colour-space conversion (spec section 16).

``AardColour`` stores colour internally as linear-light sRGB floats in
``[0, 1]`` plus alpha, and converts on demand to/from RGB (8-bit), HSL,
HSV, CMYK, LAB, XYZ and linear RGB. Keeping one canonical internal
representation (rather than tagging each instance with "whatever space it
was created in") is what makes round-trip conversion and colour maths
(mixing, gradients, harmony generation) well-defined.
"""
from __future__ import annotations

import colorsys
import math
from dataclasses import dataclass
from typing import Tuple


def _srgb_to_linear(c: float) -> float:
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def _linear_to_srgb(c: float) -> float:
    c = max(0.0, min(1.0, c))
    return c * 12.92 if c <= 0.0031308 else 1.055 * c ** (1 / 2.4) - 0.055


# sRGB D65 <-> XYZ matrices
_RGB_TO_XYZ = (
    (0.4124564, 0.3575761, 0.1804375),
    (0.2126729, 0.7151522, 0.0721750),
    (0.0193339, 0.1191920, 0.9503041),
)
_XYZ_TO_RGB = (
    (3.2404542, -1.5371385, -0.4985314),
    (-0.9692660, 1.8760108, 0.0415560),
    (0.0556434, -0.2040259, 1.0572252),
)
_D65 = (0.95047, 1.0, 1.08883)


@dataclass(frozen=True)
class AardColour:
    """RGBA colour, components in [0, 1], sRGB gamma-encoded (the usual
    "what a hex code means") unless otherwise noted."""

    r: float
    g: float
    b: float
    a: float = 1.0

    # ------------------------------------------------------------------
    # Constructors
    # ------------------------------------------------------------------
    @classmethod
    def from_hex(cls, hex_str: str) -> "AardColour":
        s = hex_str.lstrip("#")
        if len(s) == 3:
            s = "".join(ch * 2 for ch in s)
        if len(s) == 6:
            s += "ff"
        if len(s) != 8:
            raise ValueError(f"Invalid hex colour: {hex_str!r}")
        r, g, b, a = (int(s[i : i + 2], 16) / 255 for i in range(0, 8, 2))
        return cls(r, g, b, a)

    @classmethod
    def from_rgb8(cls, r: int, g: int, b: int, a: int = 255) -> "AardColour":
        return cls(r / 255, g / 255, b / 255, a / 255)

    @classmethod
    def from_hsl(cls, h: float, s: float, l: float, a: float = 1.0) -> "AardColour":
        r, g, b = colorsys.hls_to_rgb((h % 360) / 360, l, s)
        return cls(r, g, b, a)

    @classmethod
    def from_hsv(cls, h: float, s: float, v: float, a: float = 1.0) -> "AardColour":
        r, g, b = colorsys.hsv_to_rgb((h % 360) / 360, s, v)
        return cls(r, g, b, a)

    @classmethod
    def from_cmyk(cls, c: float, m: float, y: float, k: float, a: float = 1.0) -> "AardColour":
        r = (1 - c) * (1 - k)
        g = (1 - m) * (1 - k)
        b = (1 - y) * (1 - k)
        return cls(r, g, b, a)

    @classmethod
    def from_lab(cls, L: float, a_: float, b_: float, alpha: float = 1.0) -> "AardColour":
        fy = (L + 16) / 116
        fx = fy + a_ / 500
        fz = fy - b_ / 200

        def finv(t):
            return t ** 3 if t ** 3 > 0.008856 else (t - 16 / 116) / 7.787

        x, y, z = finv(fx) * _D65[0], finv(fy) * _D65[1], finv(fz) * _D65[2]
        return cls.from_xyz(x, y, z, alpha)

    @classmethod
    def from_xyz(cls, x: float, y: float, z: float, a: float = 1.0) -> "AardColour":
        rl = sum(m * v for m, v in zip(_XYZ_TO_RGB[0], (x, y, z)))
        gl = sum(m * v for m, v in zip(_XYZ_TO_RGB[1], (x, y, z)))
        bl = sum(m * v for m, v in zip(_XYZ_TO_RGB[2], (x, y, z)))
        return cls(_linear_to_srgb(rl), _linear_to_srgb(gl), _linear_to_srgb(bl), a)

    @classmethod
    def from_linear_rgb(cls, r: float, g: float, b: float, a: float = 1.0) -> "AardColour":
        return cls(_linear_to_srgb(r), _linear_to_srgb(g), _linear_to_srgb(b), a)

    @classmethod
    def gray(cls, value: float, a: float = 1.0) -> "AardColour":
        return cls(value, value, value, a)

    # ------------------------------------------------------------------
    # Conversions
    # ------------------------------------------------------------------
    def to_hex(self, include_alpha: bool = False) -> str:
        r, g, b, a = (round(max(0, min(1, c)) * 255) for c in (self.r, self.g, self.b, self.a))
        if include_alpha:
            return f"#{r:02x}{g:02x}{b:02x}{a:02x}"
        return f"#{r:02x}{g:02x}{b:02x}"

    def to_rgb8(self) -> Tuple[int, int, int, int]:
        return tuple(round(max(0, min(1, c)) * 255) for c in (self.r, self.g, self.b, self.a))

    def to_hsl(self) -> Tuple[float, float, float]:
        h, l, s = colorsys.rgb_to_hls(self.r, self.g, self.b)
        return (h * 360, s, l)

    def to_hsv(self) -> Tuple[float, float, float]:
        h, s, v = colorsys.rgb_to_hsv(self.r, self.g, self.b)
        return (h * 360, s, v)

    def to_cmyk(self) -> Tuple[float, float, float, float]:
        k = 1 - max(self.r, self.g, self.b)
        if k >= 1 - 1e-9:
            return (0.0, 0.0, 0.0, 1.0)
        c = (1 - self.r - k) / (1 - k)
        m = (1 - self.g - k) / (1 - k)
        y = (1 - self.b - k) / (1 - k)
        return (c, m, y, k)

    def to_linear_rgb(self) -> Tuple[float, float, float]:
        return (_srgb_to_linear(self.r), _srgb_to_linear(self.g), _srgb_to_linear(self.b))

    def to_xyz(self) -> Tuple[float, float, float]:
        rl, gl, bl = self.to_linear_rgb()
        x = sum(m * v for m, v in zip(_RGB_TO_XYZ[0], (rl, gl, bl)))
        y = sum(m * v for m, v in zip(_RGB_TO_XYZ[1], (rl, gl, bl)))
        z = sum(m * v for m, v in zip(_RGB_TO_XYZ[2], (rl, gl, bl)))
        return (x, y, z)

    def to_lab(self) -> Tuple[float, float, float]:
        x, y, z = self.to_xyz()

        def f(t, ref):
            t = t / ref
            return t ** (1 / 3) if t > 0.008856 else 7.787 * t + 16 / 116

        fx, fy, fz = f(x, _D65[0]), f(y, _D65[1]), f(z, _D65[2])
        L = 116 * fy - 16
        a = 500 * (fx - fy)
        b = 200 * (fy - fz)
        return (L, a, b)

    def luminance(self) -> float:
        """Relative (perceptual) luminance, WCAG-style, using linear RGB."""
        r, g, b = self.to_linear_rgb()
        return 0.2126 * r + 0.7152 * g + 0.0722 * b

    def contrast_ratio(self, other: "AardColour") -> float:
        l1, l2 = self.luminance(), other.luminance()
        lighter, darker = max(l1, l2), min(l1, l2)
        return (lighter + 0.05) / (darker + 0.05)

    # ------------------------------------------------------------------
    # Colour maths
    # ------------------------------------------------------------------
    def mix(self, other: "AardColour", t: float = 0.5, space: str = "srgb") -> "AardColour":
        """Blend towards ``other``. space: 'srgb' (naive/fast) or 'lab' (perceptual)."""
        if space == "lab":
            L1, a1, b1 = self.to_lab()
            L2, a2, b2 = other.to_lab()
            L = L1 + (L2 - L1) * t
            a = a1 + (a2 - a1) * t
            b = b1 + (b2 - b1) * t
            alpha = self.a + (other.a - self.a) * t
            return AardColour.from_lab(L, a, b, alpha)
        r = self.r + (other.r - self.r) * t
        g = self.g + (other.g - self.g) * t
        b = self.b + (other.b - self.b) * t
        a = self.a + (other.a - self.a) * t
        return AardColour(r, g, b, a)

    def with_alpha(self, a: float) -> "AardColour":
        return AardColour(self.r, self.g, self.b, a)

    def lighten(self, amount: float = 0.1) -> "AardColour":
        h, s, l = self.to_hsl()
        return AardColour.from_hsl(h, s, max(0.0, min(1.0, l + amount)), self.a)

    def darken(self, amount: float = 0.1) -> "AardColour":
        return self.lighten(-amount)

    def saturate(self, amount: float = 0.1) -> "AardColour":
        h, s, l = self.to_hsl()
        return AardColour.from_hsl(h, max(0.0, min(1.0, s + amount)), l, self.a)

    def rotate_hue(self, degrees: float) -> "AardColour":
        h, s, l = self.to_hsl()
        return AardColour.from_hsl(h + degrees, s, l, self.a)

    def to_dict(self) -> dict:
        return {"r": self.r, "g": self.g, "b": self.b, "a": self.a}

    @classmethod
    def from_dict(cls, d: dict) -> "AardColour":
        return cls(d["r"], d["g"], d["b"], d.get("a", 1.0))

    def __repr__(self):
        return f"AardColour({self.to_hex(True)})"


# A handful of named constants used throughout examples & defaults.
TRANSPARENT = AardColour(0, 0, 0, 0)
BLACK = AardColour(0, 0, 0)
WHITE = AardColour(1, 1, 1)


# ---------------------------------------------------------------------
# Vectorised (numpy array) colour-space conversions, used by the raster
# engine so whole images can be converted without a Python-level pixel
# loop (spec section 15: 8/16/32-bit, RGBA/RGB/LAB/CMYK/gray support).
# All array functions operate on float arrays in [0, 1] (last axis =
# channels) unless noted, mirroring the scalar AardColour maths above.
# ---------------------------------------------------------------------
def srgb_to_linear_array(a):
    import numpy as np

    a = np.asarray(a, dtype=np.float64)
    return np.where(a <= 0.04045, a / 12.92, ((a + 0.055) / 1.055) ** 2.4)


def linear_to_srgb_array(a):
    import numpy as np

    a = np.clip(np.asarray(a, dtype=np.float64), 0.0, 1.0)
    return np.where(a <= 0.0031308, a * 12.92, 1.055 * np.power(a, 1 / 2.4) - 0.055)


def rgb_to_xyz_array(rgb):
    import numpy as np

    lin = srgb_to_linear_array(rgb)
    m = np.array(_RGB_TO_XYZ)
    return lin @ m.T


def xyz_to_rgb_array(xyz):
    import numpy as np

    m = np.array(_XYZ_TO_RGB)
    lin = np.asarray(xyz) @ m.T
    return linear_to_srgb_array(lin)


def rgb_to_lab_array(rgb):
    import numpy as np

    xyz = rgb_to_xyz_array(rgb)
    ref = np.array(_D65)
    t = xyz / ref

    def f(t):
        return np.where(t > 0.008856, np.cbrt(t), 7.787 * t + 16 / 116)

    ft = f(t)
    L = 116 * ft[..., 1] - 16
    a = 500 * (ft[..., 0] - ft[..., 1])
    b = 200 * (ft[..., 1] - ft[..., 2])
    return np.stack([L, a, b], axis=-1)


def lab_to_rgb_array(lab):
    import numpy as np

    lab = np.asarray(lab, dtype=np.float64)
    L, a, b = lab[..., 0], lab[..., 1], lab[..., 2]
    fy = (L + 16) / 116
    fx = fy + a / 500
    fz = fy - b / 200

    def finv(t):
        return np.where(t ** 3 > 0.008856, t ** 3, (t - 16 / 116) / 7.787)

    ref = np.array(_D65)
    xyz = np.stack([finv(fx) * ref[0], finv(fy) * ref[1], finv(fz) * ref[2]], axis=-1)
    return xyz_to_rgb_array(xyz)


def rgb_to_cmyk_array(rgb):
    import numpy as np

    rgb = np.clip(np.asarray(rgb, dtype=np.float64), 0.0, 1.0)
    k = 1 - np.max(rgb, axis=-1)
    safe_k = np.where(k >= 1 - 1e-9, 1.0, 1 - k)
    c = np.where(k >= 1 - 1e-9, 0.0, (1 - rgb[..., 0] - k) / safe_k)
    m = np.where(k >= 1 - 1e-9, 0.0, (1 - rgb[..., 1] - k) / safe_k)
    y = np.where(k >= 1 - 1e-9, 0.0, (1 - rgb[..., 2] - k) / safe_k)
    return np.stack([c, m, y, k], axis=-1)


def cmyk_to_rgb_array(cmyk):
    import numpy as np

    cmyk = np.asarray(cmyk, dtype=np.float64)
    c, m, y, k = cmyk[..., 0], cmyk[..., 1], cmyk[..., 2], cmyk[..., 3]
    r = (1 - c) * (1 - k)
    g = (1 - m) * (1 - k)
    b = (1 - y) * (1 - k)
    return np.stack([r, g, b], axis=-1)
