"""Paint engine: brush model, stamp generation and stroke rendering
(spec sections 12-13).

A :class:`Brush` is a parametric description; :func:`stamp` rasterises one
brush "dab" at a given diameter, and :func:`render_stroke` stamps it
repeatedly along a polyline at ``spacing`` intervals, modulating size /
opacity / colour by a simulated pressure/velocity/tilt profile (spec
section 13 — "brush dynamics"). This is a simulated approximation
suitable for procedurally generated strokes and recorded/replayed tablet
data alike; it does not claim physical pigment accuracy (see
:mod:`aardvark.paint.mixing` for the explicitly-labelled approximate
pigment model, spec section 14).
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import Callable, List, Optional, Sequence, Tuple

import numpy as np

from ..colour.colour import AardColour
from ..raster.image import RasterImage

Point = Tuple[float, float]


@dataclass
class Brush:
    shape: str = "round"  # round | square | texture
    diameter: float = 24.0
    hardness: float = 0.8  # 0 (soft falloff) .. 1 (hard edge)
    opacity: float = 1.0
    spacing: float = 0.15  # stamp spacing as a fraction of diameter
    flow: float = 1.0  # per-stamp alpha buildup rate
    texture_strength: float = 0.0  # 0..1 amount of grain noise applied to alpha
    scatter: float = 0.0  # random positional jitter, as a fraction of diameter
    angle_jitter: float = 0.0  # degrees of random per-stamp rotation
    seed: int = 0

    # Dynamics mapping: how tablet inputs modulate the stamp (section 13)
    pressure_to_size: float = 1.0  # 0 = pressure ignored, 1 = full range
    pressure_to_opacity: float = 0.5
    velocity_to_size: float = 0.0

    def to_dict(self):
        return {k: getattr(self, k) for k in self.__dataclass_fields__}

    @classmethod
    def from_dict(cls, d):
        return cls(**d)


# ----------------------------------------------------------------------
# Presets (spec section 12)
# ----------------------------------------------------------------------
PRESETS = {
    "pencil": Brush(shape="round", diameter=3, hardness=0.9, opacity=0.85, spacing=0.1, texture_strength=0.35, flow=0.9),
    "ink": Brush(shape="round", diameter=6, hardness=1.0, opacity=1.0, spacing=0.08, flow=1.0),
    "charcoal": Brush(shape="texture", diameter=28, hardness=0.3, opacity=0.6, spacing=0.12, texture_strength=0.8, scatter=0.15),
    "paint": Brush(shape="round", diameter=32, hardness=0.6, opacity=0.9, spacing=0.15, flow=0.8),
    "airbrush": Brush(shape="round", diameter=60, hardness=0.05, opacity=0.25, spacing=0.05, flow=0.3),
    "watercolour": Brush(shape="round", diameter=40, hardness=0.15, opacity=0.35, spacing=0.2, flow=0.25, texture_strength=0.2),
    "oil": Brush(shape="round", diameter=26, hardness=0.7, opacity=0.95, spacing=0.18, texture_strength=0.15),
    "marker": Brush(shape="square", diameter=18, hardness=1.0, opacity=0.85, spacing=0.1, flow=0.9),
    "chalk": Brush(shape="texture", diameter=22, hardness=0.4, opacity=0.55, spacing=0.15, texture_strength=0.9, scatter=0.2),
    "pastel": Brush(shape="texture", diameter=24, hardness=0.35, opacity=0.6, spacing=0.15, texture_strength=0.7, scatter=0.12),
    "eraser": Brush(shape="round", diameter=30, hardness=0.7, opacity=1.0, spacing=0.1),
    "smudge": Brush(shape="round", diameter=30, hardness=0.4, opacity=0.5, spacing=0.1),
}


def preset(name: str) -> Brush:
    if name not in PRESETS:
        raise ValueError(f"Unknown brush preset {name!r}; choose from {list(PRESETS)}")
    import copy

    return copy.deepcopy(PRESETS[name])


# ----------------------------------------------------------------------
# Stamp generation
# ----------------------------------------------------------------------
def stamp(brush: Brush, diameter: Optional[float] = None, rng: Optional[random.Random] = None) -> np.ndarray:
    """Render one brush dab as an (D, D) float32 alpha array in [0, 1]."""
    d = max(1, int(round(diameter if diameter is not None else brush.diameter)))
    yy, xx = np.mgrid[0:d, 0:d].astype(np.float64)
    cx = cy = (d - 1) / 2
    if brush.shape == "square":
        dist = np.maximum(np.abs(xx - cx), np.abs(yy - cy)) / (d / 2)
    else:
        dist = np.hypot(xx - cx, yy - cy) / (d / 2)
    hardness = min(max(brush.hardness, 0.0), 0.999)
    alpha = np.clip(1.0 - (dist - hardness) / max(1e-6, 1 - hardness), 0.0, 1.0)
    alpha = np.where(dist <= hardness, 1.0, alpha)

    if brush.texture_strength > 0:
        rng = rng or random.Random(brush.seed)
        noise = _value_noise((d, d), scale=max(2, d // 6), rng=rng)
        alpha = alpha * (1 - brush.texture_strength) + alpha * noise * brush.texture_strength

    return np.clip(alpha, 0.0, 1.0).astype(np.float32)


def _value_noise(shape: Tuple[int, int], scale: int, rng: random.Random) -> np.ndarray:
    h, w = shape
    gh, gw = max(2, h // scale + 2), max(2, w // scale + 2)
    grid = np.array([[rng.random() for _ in range(gw)] for _ in range(gh)])
    from PIL import Image

    img = Image.fromarray((grid * 255).astype(np.uint8)).resize((w, h), Image.BICUBIC)
    return np.asarray(img).astype(np.float64) / 255.0


# ----------------------------------------------------------------------
# Stroke rendering
# ----------------------------------------------------------------------
def render_stroke(
    points: Sequence[Point],
    brush: Brush,
    colour: AardColour,
    pressures: Optional[Sequence[float]] = None,
    canvas_size: Optional[Tuple[int, int]] = None,
    bbox_pad: float = 4.0,
) -> Tuple[RasterImage, Tuple[int, int]]:
    """Render a brush stroke along ``points``. Returns (tile, (offset_x, offset_y))
    — a tightly cropped RGBA tile plus its placement offset — unless
    ``canvas_size`` is given, in which case a full canvas-sized RasterImage
    is returned instead."""
    if len(points) < 1:
        raise ValueError("render_stroke needs at least one point")

    rng = random.Random(brush.seed)
    if pressures is None:
        pressures = [1.0] * len(points)

    # Resample the polyline at brush.spacing * diameter arclength intervals,
    # interpolating pressure along the way.
    resampled: List[Tuple[Point, float]] = []
    step = max(1.0, brush.spacing * brush.diameter)
    if len(points) == 1:
        resampled = [(points[0], pressures[0])]
    else:
        acc = 0.0
        resampled.append((points[0], pressures[0]))
        for (x0, y0), (x1, y1), p0, p1 in zip(points, points[1:], pressures, pressures[1:]):
            seg_len = math.hypot(x1 - x0, y1 - y0)
            if seg_len == 0:
                continue
            pos = acc
            while pos + step <= acc + seg_len:
                t = (pos + step - acc) / seg_len
                pos += step
                x = x0 + (x1 - x0) * t
                y = y0 + (y1 - y0) * t
                p = p0 + (p1 - p0) * t
                resampled.append(((x, y), p))
            acc += seg_len

    max_d = brush.diameter * (1 + brush.pressure_to_size)
    if canvas_size is not None:
        width, height = canvas_size
        ox, oy = 0, 0
    else:
        xs = [p[0][0] for p in resampled]
        ys = [p[0][1] for p in resampled]
        pad = max_d / 2 + bbox_pad
        minx, maxx = min(xs) - pad, max(xs) + pad
        miny, maxy = min(ys) - pad, max(ys) + pad
        width, height = max(1, int(math.ceil(maxx - minx))), max(1, int(math.ceil(maxy - miny)))
        ox, oy = minx, miny

    canvas = np.zeros((height, width, 4), dtype=np.float32)

    for (x, y), pressure in resampled:
        size = brush.diameter * (1 - brush.pressure_to_size + brush.pressure_to_size * pressure)
        op = brush.opacity * (1 - brush.pressure_to_opacity + brush.pressure_to_opacity * pressure) * brush.flow
        dab = stamp(brush, diameter=size, rng=rng)
        jx = (rng.random() - 0.5) * 2 * brush.scatter * brush.diameter
        jy = (rng.random() - 0.5) * 2 * brush.scatter * brush.diameter
        px, py = x - ox + jx, y - oy + jy
        _stamp_onto(canvas, dab, px, py, colour, op)

    tile = RasterImage(canvas)
    if canvas_size is not None:
        return tile, (0, 0)
    return tile, (int(round(ox)), int(round(oy)))


def _stamp_onto(canvas: np.ndarray, dab: np.ndarray, cx: float, cy: float, colour: AardColour, opacity: float) -> None:
    d = dab.shape[0]
    x0 = int(round(cx - d / 2))
    y0 = int(round(cy - d / 2))
    ch, cw = canvas.shape[:2]
    sx0, sy0 = max(0, -x0), max(0, -y0)
    dx0, dy0 = max(0, x0), max(0, y0)
    dx1, dy1 = min(cw, x0 + d), min(ch, y0 + d)
    if dx1 <= dx0 or dy1 <= dy0:
        return
    sx1 = sx0 + (dx1 - dx0)
    sy1 = sy0 + (dy1 - dy0)
    a = dab[sy0:sy1, sx0:sx1] * opacity
    dest = canvas[dy0:dy1, dx0:dx1]
    src_rgb = np.array([colour.r, colour.g, colour.b])
    out_a = a + dest[..., 3] * (1 - a)
    safe = np.where(out_a > 1e-6, out_a, 1.0)
    out_rgb = (src_rgb * a[..., None] + dest[..., :3] * dest[..., 3:4] * (1 - a[..., None])) / safe[..., None]
    dest[..., :3] = out_rgb
    dest[..., 3] = out_a
