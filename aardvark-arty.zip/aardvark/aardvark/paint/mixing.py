"""Paint mixing (spec section 14): an optional, explicitly-approximate
pigment model.

This module is a *simulated* subtractive-mixing approximation loosely
inspired by Kubelka-Munk-style pigment mixing (mixing in a
reflectance-like subtractive space rather than naive additive RGB
averaging), parameterised by a per-pigment ``strength`` (tinting power)
and a medium ``wetness``/``density`` that affects how much of the
backdrop shows through. It is **not** validated against real pigment
spectral data, and the spec explicitly says not to claim physical
accuracy unless validated — so this module doesn't: read it as "plausible
painterly mixing behaviour" (blues + yellows tend toward green, opposed
hues muddy rather than average to grey), not as a colourimetric model.
"""
from __future__ import annotations

from dataclasses import dataclass

from ..colour.colour import AardColour


@dataclass
class Pigment:
    colour: AardColour
    strength: float = 1.0  # tinting strength / concentration
    opacity: float = 1.0  # binder opacity (how much backdrop shows through)


@dataclass
class Medium:
    name: str = "watercolour"
    binder_opacity: float = 0.4
    wetness: float = 0.7
    density: float = 0.5


MEDIA = {
    "watercolour": Medium("watercolour", binder_opacity=0.25, wetness=0.9, density=0.3),
    "oil": Medium("oil", binder_opacity=0.85, wetness=0.3, density=0.8),
    "acrylic": Medium("acrylic", binder_opacity=0.75, wetness=0.4, density=0.7),
    "ink": Medium("ink", binder_opacity=0.95, wetness=0.6, density=0.9),
}


def _reflectance(c: AardColour) -> tuple:
    # Treat linear-light RGB as a crude 3-band "reflectance" proxy.
    return c.to_linear_rgb()


def mix_pigments(a: Pigment, b: Pigment, ratio: float = 0.5, medium: Medium | None = None) -> AardColour:
    """Subtractive-style mix of two pigments. ``ratio`` is the proportion
    of ``b`` (0 = pure a, 1 = pure b)."""
    medium = medium or MEDIA["watercolour"]
    ra = _reflectance(a.colour)
    rb = _reflectance(b.colour)
    wa = a.strength * (1 - ratio)
    wb = b.strength * ratio
    total = wa + wb or 1e-9

    # Subtractive combination: multiply reflectances (like stacked filters),
    # weighted by relative concentration, which pushes mixed complementary
    # hues toward darker/muddier results rather than a flat RGB average.
    mixed = tuple(
        (ra[i] ** (wa / total)) * (rb[i] ** (wb / total)) for i in range(3)
    )
    result = AardColour.from_linear_rgb(*mixed)
    # Medium density slightly desaturates/darkens toward the medium's own body colour behaviour.
    result = result.mix(AardColour.gray(0.5), (1 - medium.density) * 0.15)
    return result


def apply_wet_blend(base: AardColour, applied: AardColour, medium: Medium | None = None, coverage: float = 1.0) -> AardColour:
    """Blend a new stroke of ``applied`` pigment over ``base``, honouring the
    medium's wetness (higher wetness = more blending with what's beneath,
    like watercolour) and binder opacity."""
    medium = medium or MEDIA["watercolour"]
    effective_opacity = medium.binder_opacity * coverage
    blended = base.mix(applied, effective_opacity)
    # Wetness lets some of the base show through even at full coverage.
    return blended.mix(base, medium.wetness * (1 - effective_opacity))
