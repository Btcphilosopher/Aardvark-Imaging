"""Non-destructive history engine (spec sections 46-47): every operation
is a Command, supporting undo/redo, branching history, and named
snapshots — a visual-history timeline the artist can branch from.

The critical architectural rule (spec section 82) is that the *Document*
is the source of truth; History wraps a Document by recording Commands
that mutate it, never by owning geometry itself, so the same Document can
also be edited directly (scripting, CLI, plugin) without going through
History at all when that's not wanted.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Callable, List, Optional


class Command:
    """Base class for a reversible operation. Subclass and implement
    ``do``/``undo``, or use :func:`make_command` for a quick closure-based
    command."""

    name: str = "Command"

    def do(self) -> None:
        raise NotImplementedError

    def undo(self) -> None:
        raise NotImplementedError


class FunctionCommand(Command):
    def __init__(self, name: str, do_fn: Callable[[], None], undo_fn: Callable[[], None]):
        self.name = name
        self._do = do_fn
        self._undo = undo_fn

    def do(self) -> None:
        self._do()

    def undo(self) -> None:
        self._undo()


def make_command(name: str, do_fn: Callable[[], None], undo_fn: Callable[[], None]) -> FunctionCommand:
    return FunctionCommand(name, do_fn, undo_fn)


@dataclass
class HistoryNode:
    command: Optional[Command]
    parent: Optional["HistoryNode"]
    children: List["HistoryNode"] = field(default_factory=list)
    timestamp: float = field(default_factory=time.time)
    label: Optional[str] = None

    def path_from_root(self) -> List["HistoryNode"]:
        node, chain = self, []
        while node is not None:
            chain.append(node)
            node = node.parent
        return list(reversed(chain))


class History:
    """A branching undo/redo tree (spec section 47's "visual history"):
    undoing then performing a *new* command creates a new branch rather
    than discarding the redo-able future, and any earlier node can be
    revisited directly via :meth:`checkout`."""

    def __init__(self):
        self.root = HistoryNode(command=None, parent=None, label="Initial state")
        self.current = self.root
        self._named_versions: dict[str, HistoryNode] = {}

    def do(self, command: Command) -> None:
        command.do()
        node = HistoryNode(command=command, parent=self.current)
        self.current.children.append(node)
        self.current = node

    def can_undo(self) -> bool:
        return self.current.parent is not None

    def can_redo(self) -> bool:
        return len(self.current.children) > 0

    def undo(self) -> bool:
        if not self.can_undo():
            return False
        self.current.command.undo()
        self.current = self.current.parent
        return True

    def redo(self, branch_index: int = -1) -> bool:
        if not self.can_redo():
            return False
        node = self.current.children[branch_index]
        node.command.do()
        self.current = node
        return True

    def checkout(self, node: HistoryNode) -> None:
        """Jump directly to an arbitrary node, replaying commands from the
        nearest common ancestor (undoing off the current branch, redoing
        onto the target branch)."""
        current_chain = self.current.path_from_root()
        target_chain = node.path_from_root()
        common_len = 0
        for a, b in zip(current_chain, target_chain):
            if a is not b:
                break
            common_len += 1
        for n in reversed(current_chain[common_len:]):
            n.command.undo()
        for n in target_chain[common_len:]:
            n.command.do()
        self.current = node

    def snapshot(self, label: str) -> HistoryNode:
        self._named_versions[label] = self.current
        self.current.label = label
        return self.current

    def get_snapshot(self, label: str) -> Optional[HistoryNode]:
        return self._named_versions.get(label)

    def timeline(self) -> List[HistoryNode]:
        """Linear list of nodes on the path from root to the current node
        (the "VERSION 01, 02, 03..." view for the simple, non-branching case)."""
        return self.current.path_from_root()
