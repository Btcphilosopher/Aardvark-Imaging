"""SVG as a first-class format (spec section 43): AardSVGWriter and
AardSVGParser map AARD objects directly to/from SVG elements — paths,
rects, circles, text, groups, gradients, masks — rather than treating SVG
as a lossy one-way export target.
"""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from typing import Optional

from ..core.object import AardObject, AardObjectType, BlendMode
from ..colour.colour import AardColour
from ..colour.gradient import AardGradient, GradientStop
from ..vector.path import Path
from ..typography.text import TextObject

SVG_NS = "http://www.w3.org/2000/svg"
ET.register_namespace("", SVG_NS)


class AardSVGWriter:
    def __init__(self, width: float, height: float):
        self.width = width
        self.height = height
        self._defs: list = []
        self._gradient_counter = 0

    def _fill_to_attr(self, fill) -> tuple[str, Optional[str]]:
        if fill is None:
            return "none", None
        if isinstance(fill, AardColour):
            if fill.a >= 0.999:
                return fill.to_hex(), None
            return fill.to_hex(), str(round(fill.a, 4))
        if isinstance(fill, AardGradient):
            self._gradient_counter += 1
            gid = f"grad{self._gradient_counter}"
            self._defs.append(_gradient_to_svg_element(fill, gid))
            return f"url(#{gid})", None
        return "none", None

    def _write_path(self, obj: AardObject, parent: ET.Element) -> None:
        path: Path = obj.data
        d = _path_to_d(path)
        el = ET.SubElement(parent, "path", {"d": d})
        if path.fill_rule == "evenodd":
            el.set("fill-rule", "evenodd")
        self._apply_style(obj, el)

    def _write_text(self, obj: AardObject, parent: ET.Element) -> None:
        text: TextObject = obj.data
        el = ET.SubElement(parent, "text", {"x": "0", "y": "0", "font-family": text.character_style.family, "font-size": str(text.character_style.size)})
        fill, opacity = self._fill_to_attr(text.character_style.colour)
        el.set("fill", fill)
        if opacity:
            el.set("fill-opacity", opacity)
        el.text = text.content

    def _write_image(self, obj: AardObject, parent: ET.Element) -> None:
        import base64
        import io

        img = obj.data
        buf = io.BytesIO()
        img.to_pil().save(buf, format="PNG")
        data_uri = "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode("ascii")
        ET.SubElement(parent, "image", {"href": data_uri, "width": str(img.width), "height": str(img.height)})

    def _apply_style(self, obj: AardObject, el: ET.Element) -> None:
        style = obj.style
        fill, fill_opacity = self._fill_to_attr(style.fill)
        el.set("fill", fill)
        if fill_opacity:
            el.set("fill-opacity", fill_opacity)
        if style.stroke is not None:
            stroke, stroke_opacity = self._fill_to_attr(style.stroke)
            el.set("stroke", stroke)
            el.set("stroke-width", str(style.stroke_width))
            if stroke_opacity:
                el.set("stroke-opacity", stroke_opacity)
            if style.stroke_cap != "butt":
                el.set("stroke-linecap", style.stroke_cap)
            if style.stroke_join != "miter":
                el.set("stroke-linejoin", style.stroke_join)
            if style.dash:
                el.set("stroke-dasharray", " ".join(str(d) for d in style.dash))

    def _write_object(self, obj: AardObject, parent: ET.Element) -> None:
        if not obj.visibility:
            return
        group = ET.SubElement(parent, "g", {"id": obj.id})
        transform_parts = []
        x, y = obj.position
        if x or y:
            transform_parts.append(f"translate({x},{y})")
        if obj.rotation:
            transform_parts.append(f"rotate({obj.rotation})")
        sx, sy = obj.scale
        if sx != 1 or sy != 1:
            transform_parts.append(f"scale({sx},{sy})")
        if transform_parts:
            group.set("transform", " ".join(transform_parts))
        if obj.opacity < 1:
            group.set("opacity", str(obj.opacity))

        if isinstance(obj.data, Path):
            self._write_path(obj, group)
        elif isinstance(obj.data, TextObject):
            self._write_text(obj, group)
        elif hasattr(obj.data, "to_pil"):
            self._write_image(obj, group)

        for child in obj.children:
            self._write_object(child, group)

    def write(self, root_or_document, artboard_index: int = 0) -> str:
        from ..document.document import Document

        if isinstance(root_or_document, Document):
            artboard = root_or_document.artboards[artboard_index]
            root_obj = artboard.root
            width, height = artboard.width, artboard.height
        else:
            root_obj = root_or_document
            width, height = self.width, self.height

        svg = ET.Element(
            "svg",
            {
                "xmlns": SVG_NS,
                "width": str(width),
                "height": str(height),
                "viewBox": f"0 0 {width} {height}",
            },
        )
        defs = ET.SubElement(svg, "defs")
        for child in root_obj.children:
            self._write_object(child, svg)
        for d in self._defs:
            defs.append(d)
        return '<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(svg, encoding="unicode")

    def save(self, path: str, root_or_document, artboard_index: int = 0) -> None:
        with open(path, "w") as f:
            f.write(self.write(root_or_document, artboard_index))


def _gradient_to_svg_element(gradient: AardGradient, gid: str) -> ET.Element:
    if gradient.kind == "radial":
        el = ET.Element("radialGradient", {"id": gid, "gradientUnits": "userSpaceOnUse", "cx": str(gradient.start[0]), "cy": str(gradient.start[1]), "r": str(max(1e-6, ((gradient.end[0] - gradient.start[0]) ** 2 + (gradient.end[1] - gradient.start[1]) ** 2) ** 0.5))})
    else:
        el = ET.Element("linearGradient", {"id": gid, "gradientUnits": "userSpaceOnUse", "x1": str(gradient.start[0]), "y1": str(gradient.start[1]), "x2": str(gradient.end[0]), "y2": str(gradient.end[1])})
    for stop in gradient.stops:
        ET.SubElement(el, "stop", {"offset": str(stop.offset), "stop-color": stop.colour.to_hex(), "stop-opacity": str(stop.colour.a)})
    return el


def _path_to_d(path: Path) -> str:
    parts = []
    for sub, closed in zip(path.subpaths, path.closed_flags):
        for seg in sub:
            if seg[0] == "M":
                parts.append(f"M {seg[1][0]:.4f} {seg[1][1]:.4f}")
            elif seg[0] == "L":
                parts.append(f"L {seg[1][0]:.4f} {seg[1][1]:.4f}")
            elif seg[0] == "C":
                parts.append(f"C {seg[1][0]:.4f} {seg[1][1]:.4f} {seg[2][0]:.4f} {seg[2][1]:.4f} {seg[3][0]:.4f} {seg[3][1]:.4f}")
        if closed:
            parts.append("Z")
    return " ".join(parts)


# ---------------------------------------------------------------------
# Parser (SVG -> AARD objects)
# ---------------------------------------------------------------------
_PATH_CMD_RE = re.compile(r"([MLCQAZmlcqaz])([^MLCQAZmlcqaz]*)")


def parse_svg_path_d(d: str) -> Path:
    """Parses a (subset of) SVG path data into an AARDVARK Path: M, L, C,
    Q, Z (absolute and relative), which covers everything AardSVGWriter
    emits and most hand-authored simple paths. Arcs ('A'/'a') are
    approximated as a straight line to the endpoint if encountered — full
    arc support goes through Path.arc_to() when building paths
    programmatically."""
    path = Path()
    cursor = (0.0, 0.0)
    start = (0.0, 0.0)
    last_cubic_ctrl = None
    for cmd, arg_str in _PATH_CMD_RE.findall(d):
        nums = [float(n) for n in re.findall(r"-?\d*\.?\d+(?:e-?\d+)?", arg_str)]
        is_rel = cmd.islower()
        cmd_u = cmd.upper()
        if cmd_u == "M":
            x, y = nums[0], nums[1]
            if is_rel:
                x, y = cursor[0] + x, cursor[1] + y
            path.move_to(x, y)
            cursor = (x, y)
            start = cursor
            for i in range(2, len(nums) - 1, 2):
                x, y = nums[i], nums[i + 1]
                if is_rel:
                    x, y = cursor[0] + x, cursor[1] + y
                path.line_to(x, y)
                cursor = (x, y)
        elif cmd_u == "L":
            for i in range(0, len(nums) - 1, 2):
                x, y = nums[i], nums[i + 1]
                if is_rel:
                    x, y = cursor[0] + x, cursor[1] + y
                path.line_to(x, y)
                cursor = (x, y)
        elif cmd_u == "C":
            for i in range(0, len(nums) - 5, 6):
                c1 = (nums[i], nums[i + 1])
                c2 = (nums[i + 2], nums[i + 3])
                p = (nums[i + 4], nums[i + 5])
                if is_rel:
                    c1 = (cursor[0] + c1[0], cursor[1] + c1[1])
                    c2 = (cursor[0] + c2[0], cursor[1] + c2[1])
                    p = (cursor[0] + p[0], cursor[1] + p[1])
                path.curve_to(c1, c2, p)
                cursor = p
                last_cubic_ctrl = c2
        elif cmd_u == "Q":
            for i in range(0, len(nums) - 3, 4):
                c = (nums[i], nums[i + 1])
                p = (nums[i + 2], nums[i + 3])
                if is_rel:
                    c = (cursor[0] + c[0], cursor[1] + c[1])
                    p = (cursor[0] + p[0], cursor[1] + p[1])
                path.quad_to(c, p)
                cursor = p
        elif cmd_u == "Z":
            path.close_path()
            cursor = start
    return path


def _colour_from_svg(value: Optional[str], opacity: Optional[str] = None) -> Optional[AardColour]:
    if not value or value == "none":
        return None
    a = float(opacity) if opacity else 1.0
    if value.startswith("#"):
        return AardColour.from_hex(value).with_alpha(a)
    named = {"black": "#000000", "white": "#ffffff", "red": "#ff0000", "green": "#008000", "blue": "#0000ff", "none": None}
    if value in named and named[value]:
        return AardColour.from_hex(named[value]).with_alpha(a)
    return None


class AardSVGParser:
    def parse(self, svg_text: str) -> AardObject:
        svg_text = re.sub(r'\sxmlns="[^"]+"', "", svg_text, count=1)
        root = ET.fromstring(svg_text)
        group = AardObject(AardObjectType.GROUP, name="Imported SVG")
        for el in root:
            obj = self._parse_element(el)
            if obj is not None:
                group.add(obj)
        return group

    def parse_file(self, path: str) -> AardObject:
        with open(path) as f:
            return self.parse(f.read())

    def _tag(self, el) -> str:
        return el.tag.split("}")[-1]

    def _parse_element(self, el) -> Optional[AardObject]:
        tag = self._tag(el)
        if tag == "g":
            group = AardObject(AardObjectType.GROUP, name="g")
            for child in el:
                obj = self._parse_element(child)
                if obj is not None:
                    group.add(obj)
            return group
        if tag == "path":
            p = parse_svg_path_d(el.get("d", ""))
            obj = AardObject(AardObjectType.PATH, name="path")
            obj.data = p
            self._apply_style(el, obj)
            return obj
        if tag == "rect":
            from ..vector import shapes

            x, y = float(el.get("x", 0)), float(el.get("y", 0))
            w, h = float(el.get("width", 0)), float(el.get("height", 0))
            rx = float(el.get("rx", 0) or 0)
            p = shapes.rounded_rectangle(x, y, w, h, rx) if rx else shapes.rectangle(x, y, w, h)
            obj = AardObject(AardObjectType.SHAPE, name="rect")
            obj.data = p
            self._apply_style(el, obj)
            return obj
        if tag == "circle":
            from ..vector import shapes

            cx, cy, r = float(el.get("cx", 0)), float(el.get("cy", 0)), float(el.get("r", 0))
            obj = AardObject(AardObjectType.SHAPE, name="circle")
            obj.data = shapes.circle((cx, cy), r)
            self._apply_style(el, obj)
            return obj
        if tag == "ellipse":
            from ..vector import shapes

            cx, cy = float(el.get("cx", 0)), float(el.get("cy", 0))
            rx, ry = float(el.get("rx", 0)), float(el.get("ry", 0))
            obj = AardObject(AardObjectType.SHAPE, name="ellipse")
            obj.data = shapes.ellipse((cx, cy), rx, ry)
            self._apply_style(el, obj)
            return obj
        if tag == "text":
            from ..typography.text import TextObject, CharacterStyle

            style = CharacterStyle(
                family=el.get("font-family", "DejaVu Sans"),
                size=float(el.get("font-size", 16)),
                colour=_colour_from_svg(el.get("fill", "#000000")) or AardColour(0, 0, 0),
            )
            obj = AardObject(AardObjectType.TEXT, name="text")
            obj.data = TextObject(el.text or "", style)
            obj.position = (float(el.get("x", 0)), float(el.get("y", 0)))
            return obj
        return None

    def _apply_style(self, el, obj: AardObject) -> None:
        fill = _colour_from_svg(el.get("fill", "#000000"), el.get("fill-opacity"))
        obj.style.fill = fill if el.get("fill") != "none" else None
        stroke = _colour_from_svg(el.get("stroke"), el.get("stroke-opacity"))
        if stroke is not None:
            obj.style.stroke = stroke
            obj.style.stroke_width = float(el.get("stroke-width", 1))
