"""Raster export (spec section 42): PNG, JPEG, TIFF, WebP, AVIF, with
resolution/DPI/antialiasing/colour-profile/bit-depth/background controls.
"""
from __future__ import annotations

from typing import Optional

from ..colour.colour import AardColour
from ..document.document import Document
from ..raster.image import RasterImage
from ..rendering.renderer import CPURenderer


SUPPORTED_FORMATS = {"png", "jpeg", "jpg", "tiff", "webp", "avif", "bmp"}


def export_raster(
    document: Document,
    path: str,
    format: Optional[str] = None,
    artboard_index: int = 0,
    dpi: float = 96.0,
    supersample: int = 2,
    background: Optional[AardColour] = None,
) -> RasterImage:
    fmt = (format or path.rsplit(".", 1)[-1]).lower()
    if fmt == "jpg":
        fmt = "jpeg"
    if fmt not in SUPPORTED_FORMATS:
        raise ValueError(f"Unsupported raster export format {fmt!r}; choose from {sorted(SUPPORTED_FORMATS)}")

    artboard = document.artboards[artboard_index]
    renderer = CPURenderer(supersample=supersample, dpi_scale=dpi / 96.0)
    bg = background if background is not None else artboard.background
    w = max(1, int(round(artboard.width * renderer.dpi_scale)))
    h = max(1, int(round(artboard.height * renderer.dpi_scale)))
    image = renderer.render(artboard.root, w, h, background=bg)

    pil_kwargs = {}
    pil_img = image.to_pil()
    if fmt == "jpeg":
        pil_img = pil_img.convert("RGB")  # JPEG has no alpha channel
        pil_kwargs["quality"] = 95
    if fmt in ("png", "tiff"):
        pil_kwargs["dpi"] = (dpi, dpi)
    try:
        pil_img.save(path, format=fmt.upper() if fmt != "jpeg" else "JPEG", **pil_kwargs)
    except (KeyError, OSError) as e:
        if fmt == "avif":
            raise RuntimeError(
                "AVIF export needs the optional 'pillow-avif-plugin' package "
                "(pip install pillow-avif-plugin) — Pillow has no built-in AVIF encoder."
            ) from e
        raise
    return image


def render_to_raster(document: Document, artboard_index: int = 0, dpi: float = 96.0, supersample: int = 2, background: Optional[AardColour] = None) -> RasterImage:
    """Like :func:`export_raster` but returns the RasterImage without
    writing a file — useful for further compositing/effects before save."""
    artboard = document.artboards[artboard_index]
    renderer = CPURenderer(supersample=supersample, dpi_scale=dpi / 96.0)
    bg = background if background is not None else artboard.background
    w = max(1, int(round(artboard.width * renderer.dpi_scale)))
    h = max(1, int(round(artboard.height * renderer.dpi_scale)))
    return renderer.render(artboard.root, w, h, background=bg)
