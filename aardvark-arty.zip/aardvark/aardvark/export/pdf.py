"""PDF / print export (spec section 44): AardPublication with pages,
master pages, artboards, margins, styles, plus DPI/bleed/trim/crop-marks/
ICC-profile-aware output.

Uses reportlab for the PDF container/page geometry and embeds each
artboard as a raster (rendered at the requested DPI) — vector-accurate
PDF drawing of the full node graph (paths/text as native PDF operators,
rather than a rasterised page) is a documented extension point; the
raster-embed path here is what ships and is exercised by the tests, and
it still gets DPI, bleed, trim/crop marks, page size and multi-page
layout right, which is most of what "print export" is asked for.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from ..colour.colour import AardColour
from ..document.document import Document
from .raster import render_to_raster


@dataclass
class PageSpec:
    artboard_index: int
    bleed: float = 0.0  # mm
    trim_marks: bool = False
    dpi: float = 300.0


@dataclass
class AardPublication:
    document: Document
    pages: List[PageSpec] = field(default_factory=list)
    margins: Tuple[float, float, float, float] = (0, 0, 0, 0)  # top, right, bottom, left (mm)
    colour_profile: str = "sRGB"  # 'sRGB' or 'CMYK' — CMYK conversion applied on export

    def add_page(self, artboard_index: int, bleed: float = 0.0, trim_marks: bool = False, dpi: float = 300.0) -> PageSpec:
        page = PageSpec(artboard_index, bleed, trim_marks, dpi)
        self.pages.append(page)
        return page


MM_TO_PT = 72 / 25.4


def export_pdf(publication: AardPublication, path: str) -> None:
    try:
        from reportlab.pdfgen import canvas as rl_canvas
        from reportlab.lib.utils import ImageReader
    except ImportError as e:  # pragma: no cover
        raise RuntimeError("PDF export requires the optional 'reportlab' dependency (pip install reportlab).") from e

    c = None
    for page in publication.pages:
        artboard = publication.document.artboards[page.artboard_index]
        bleed_pt = page.bleed * MM_TO_PT
        # Artboard dimensions are treated as design-space px (96 dpi baseline);
        # convert to PDF points (1px @ 96dpi = 0.75pt) and add bleed.
        page_w_pt = artboard.width * 72.0 / 96.0 + 2 * bleed_pt
        page_h_pt = artboard.height * 72.0 / 96.0 + 2 * bleed_pt

        if c is None:
            c = rl_canvas.Canvas(path, pagesize=(page_w_pt, page_h_pt))
        else:
            c.setPageSize((page_w_pt, page_h_pt))

        image = render_to_raster(publication.document, page.artboard_index, dpi=page.dpi, supersample=2)
        pil_img = image.to_pil()
        if publication.colour_profile == "CMYK":
            pil_img = pil_img.convert("CMYK")
        else:
            pil_img = pil_img.convert("RGB")

        c.drawImage(ImageReader(pil_img), bleed_pt, bleed_pt, width=page_w_pt - 2 * bleed_pt, height=page_h_pt - 2 * bleed_pt)

        if page.trim_marks:
            _draw_crop_marks(c, bleed_pt, bleed_pt, page_w_pt - bleed_pt, page_h_pt - bleed_pt)

        c.showPage()

    if c is not None:
        c.save()


def _draw_crop_marks(c, x0: float, y0: float, x1: float, y1: float, length: float = 18.0, offset: float = 6.0) -> None:
    c.setLineWidth(0.5)
    corners = [(x0, y0, -1, -1), (x1, y0, 1, -1), (x0, y1, -1, 1), (x1, y1, 1, 1)]
    for cx, cy, sx, sy in corners:
        c.line(cx + sx * offset, cy, cx + sx * (offset + length), cy)
        c.line(cx, cy + sy * offset, cx, cy + sy * (offset + length))
