"""Generative pattern engine (spec section 10): tile, radial and linear
repeats with reflect/rotate/offset/scale/randomise, plus hexagonal and
Voronoi/organic patterns.

Every function returns a list of (Path, Transform) placements — "recipes"
rather than baked geometry — so a caller can turn them into AardObjects
that stay individually editable, per the spec's "everything should remain
editable" principle.
"""
from __future__ import annotations

import math
import random
from typing import List, Optional, Tuple

from ..core.transform import Transform
from ..vector.path import Path

Placement = Tuple[Path, Transform]
Point = Tuple[float, float]


def tile_pattern(
    unit: Path,
    columns: int,
    rows: int,
    spacing_x: float,
    spacing_y: float,
    origin: Point = (0, 0),
    stagger: float = 0.0,
    rotate_alternate: float = 0.0,
    scale_jitter: float = 0.0,
    seed: int = 0,
) -> List[Placement]:
    rng = random.Random(seed)
    placements: List[Placement] = []
    for row in range(rows):
        row_offset = (spacing_x * stagger) if row % 2 == 1 else 0.0
        for col in range(columns):
            x = origin[0] + col * spacing_x + row_offset
            y = origin[1] + row * spacing_y
            t = Transform.translation(x, y)
            if rotate_alternate and (row + col) % 2 == 1:
                t = Transform.rotation(rotate_alternate).then(t)
            if scale_jitter:
                s = 1.0 + rng.uniform(-scale_jitter, scale_jitter)
                t = Transform.scaling(s).then(t)
            placements.append((unit, t))
    return placements


def linear_pattern(unit: Path, count: int, dx: float, dy: float, origin: Point = (0, 0), scale_step: float = 0.0, rotate_step: float = 0.0) -> List[Placement]:
    placements = []
    for i in range(count):
        t = Transform.translation(origin[0] + dx * i, origin[1] + dy * i)
        if rotate_step:
            t = Transform.rotation(rotate_step * i).then(t)
        if scale_step:
            t = Transform.scaling(1.0 + scale_step * i).then(t)
        placements.append((unit, t))
    return placements


def radial_pattern(unit: Path, count: int, radius: float, center: Point = (0, 0), start_angle: float = 0.0, face_outward: bool = True) -> List[Placement]:
    placements = []
    for i in range(count):
        angle = start_angle + 360.0 * i / count
        rad = math.radians(angle)
        x = center[0] + radius * math.cos(rad)
        y = center[1] + radius * math.sin(rad)
        t = Transform.translation(x, y)
        if face_outward:
            t = Transform.rotation(angle + 90).then(t)
        placements.append((unit, t))
    return placements


def hex_grid_centers(width: float, height: float, cell_radius: float, origin: Point = (0, 0)) -> List[Point]:
    """Centers of a pointy-top hexagonal grid tiling a width x height area."""
    centers = []
    hex_h = cell_radius * math.sqrt(3)
    col_spacing = cell_radius * 1.5
    cols = int(width / col_spacing) + 2
    rows = int(height / hex_h) + 2
    for col in range(cols):
        x = origin[0] + col * col_spacing
        y_offset = (hex_h / 2) if col % 2 == 1 else 0.0
        for row in range(rows):
            y = origin[1] + row * hex_h + y_offset
            if x <= width and y <= height:
                centers.append((x, y))
    return centers


def hex_pattern(unit: Path, width: float, height: float, cell_radius: float, origin: Point = (0, 0), rotate: float = 0.0) -> List[Placement]:
    centers = hex_grid_centers(width, height, cell_radius, origin)
    t_rotate = Transform.rotation(rotate) if rotate else Transform.identity()
    return [(unit, t_rotate.then(Transform.translation(x, y))) for x, y in centers]


def voronoi_pattern(width: float, height: float, n_cells: int = 24, seed: int = 0) -> List[Path]:
    """Voronoi cell polygons clipped to (0, 0, width, height), each
    returned as a closed Path — an "organic pattern" (spec section 10)."""
    from ..vector.boolean import _HAS_SHAPELY, BooleanGeometryUnavailable

    if not _HAS_SHAPELY:
        raise BooleanGeometryUnavailable("voronoi_pattern requires shapely (pip install shapely)")

    import numpy as np
    from scipy.spatial import Voronoi
    from shapely.geometry import box, Polygon as ShapelyPolygon

    rng = np.random.default_rng(seed)
    points = rng.uniform([0, 0], [width, height], size=(n_cells, 2))
    # Mirror points across all four bbox edges so boundary cells clip
    # cleanly against a finite Voronoi diagram instead of producing
    # unbounded regions.
    mirror_left = points * [-1, 1]
    mirror_right = points * [-1, 1] + [2 * width, 0]
    mirror_top = points * [1, -1]
    mirror_bottom = points * [1, -1] + [0, 2 * height]
    extra = np.concatenate([points, mirror_left, mirror_right, mirror_top, mirror_bottom])
    vor = Voronoi(extra)
    clip_box = box(0, 0, width, height)

    paths = []
    for i in range(n_cells):
        region_index = vor.point_region[i]
        region = vor.regions[region_index]
        if not region or -1 in region:
            continue
        poly_pts = [vor.vertices[v] for v in region]
        if len(poly_pts) < 3:
            continue
        shp = ShapelyPolygon(poly_pts).intersection(clip_box)
        if shp.is_empty:
            continue
        geoms = list(shp.geoms) if shp.geom_type == "MultiPolygon" else [shp]
        for g in geoms:
            coords = list(g.exterior.coords)
            p = Path()
            p.move_to(*coords[0])
            for c in coords[1:-1]:
                p.line_to(*c)
            p.close_path()
            paths.append(p)
    return paths
