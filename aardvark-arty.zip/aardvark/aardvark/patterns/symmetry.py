"""Symmetry engine (spec section 11): the user draws once, AARDVARK
generates the symmetric geometry — vertical/horizontal/bilateral mirror,
rotational, radial, and kaleidoscopic symmetry, expressed as functions
returning transformed copies of a source :class:`Path` so the result stays
editable (each copy is still a normal Path, not a merged blob).
"""
from __future__ import annotations

import math
from typing import List, Tuple

from ..core.transform import Transform
from ..vector.path import Path

Point = Tuple[float, float]


def mirror(path: Path, axis: str = "vertical", center: Point = (0, 0)) -> Path:
    """axis: 'vertical' (flip across a vertical line through center, i.e.
    left<->right), 'horizontal' (flip across a horizontal line), or
    'diagonal' (swap x/y about the center)."""
    if axis == "vertical":
        t = Transform.reflection("y", origin=center)  # flips x
    elif axis == "horizontal":
        t = Transform.reflection("x", origin=center)  # flips y
    elif axis == "diagonal":
        cx, cy = center
        t = Transform.translation(cx, cy).then(Transform(0, 1, 1, 0, 0, 0)).then(Transform.translation(-cx, -cy))
    else:
        raise ValueError("axis must be 'vertical', 'horizontal' or 'diagonal'")
    return path.transformed(t)


def bilateral(path: Path, axis: str = "vertical", center: Point = (0, 0)) -> List[Path]:
    """Original + its mirror — the classic "draw one half" workflow."""
    return [path, mirror(path, axis, center)]


def rotational(path: Path, count: int, center: Point = (0, 0)) -> List[Path]:
    """``count`` rotated copies spaced evenly around a full turn."""
    copies = []
    for i in range(count):
        angle = 360.0 * i / count
        t = Transform.rotation(angle, origin=center)
        copies.append(path.transformed(t))
    return copies


def radial(path: Path, count: int, center: Point = (0, 0), radius_offset: float = 0.0) -> List[Path]:
    """Like :func:`rotational`, with an optional additional outward offset
    per copy (spokes-from-center layouts)."""
    copies = []
    for i in range(count):
        angle = 360.0 * i / count
        rad = math.radians(angle)
        dx, dy = radius_offset * math.cos(rad), radius_offset * math.sin(rad)
        t = Transform.rotation(angle, origin=center).then(Transform.translation(dx, dy))
        copies.append(path.transformed(t))
    return copies


def kaleidoscopic(path: Path, segments: int = 8, center: Point = (0, 0)) -> List[Path]:
    """Alternating mirror + rotate — a classic kaleidoscope tiling: each
    successive wedge is a mirrored copy of the previous one."""
    copies = []
    for i in range(segments):
        angle = 360.0 * i / segments
        t = Transform.rotation(angle, origin=center)
        wedge = path if i % 2 == 0 else mirror(path, "vertical", center)
        copies.append(wedge.transformed(t))
    return copies
