"""The universal Aard Object model and scene graph (spec sections 1-2).

The fundamental object in AARDVARK is not a pixel — it is the AardObject:
a node that may represent a path, shape, text run, image, brush stroke,
colour field, gradient, mask, pattern, procedural generator, geometric
construction, symbol, component, group, artboard, animation or data
visualisation, while remaining editable and addressable through the
scene graph, the Python scripting API, and the GUI alike (the document
is the single source of truth — section 82).
"""
from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import Any, Iterator, Optional

from .ids import new_id
from .transform import Transform


class AardObjectType(enum.Enum):
    PATH = "PATH"
    SHAPE = "SHAPE"
    TEXT = "TEXT"
    IMAGE = "IMAGE"
    BRUSH_STROKE = "BRUSH_STROKE"
    GROUP = "GROUP"
    MASK = "MASK"
    GRADIENT = "GRADIENT"
    PATTERN = "PATTERN"
    SYMBOL = "SYMBOL"
    COMPONENT = "COMPONENT"
    PROCEDURAL = "PROCEDURAL"
    OBJECT_3D = "3D_OBJECT"
    ARTBOARD = "ARTBOARD"
    GUIDE = "GUIDE"
    GRID = "GRID"
    DOCUMENT = "DOCUMENT"


class BlendMode(enum.Enum):
    NORMAL = "normal"
    MULTIPLY = "multiply"
    SCREEN = "screen"
    OVERLAY = "overlay"
    DARKEN = "darken"
    LIGHTEN = "lighten"
    COLOR_DODGE = "color-dodge"
    COLOR_BURN = "color-burn"
    HARD_LIGHT = "hard-light"
    SOFT_LIGHT = "soft-light"
    DIFFERENCE = "difference"
    EXCLUSION = "exclusion"
    ADD = "add"


@dataclass
class Style:
    """Shared visual style attributes usable by any AardObject."""

    fill: Optional[Any] = None  # AardColour, AardGradient, AardPattern, or None
    stroke: Optional[Any] = None
    stroke_width: float = 1.0
    stroke_cap: str = "butt"  # butt | round | square
    stroke_join: str = "miter"  # miter | round | bevel
    dash: Optional[list] = None

    def to_dict(self) -> dict:
        def enc(v):
            if v is None:
                return None
            if hasattr(v, "to_dict"):
                return {"__type__": type(v).__name__, **v.to_dict()}
            return v

        return {
            "fill": enc(self.fill),
            "stroke": enc(self.stroke),
            "stroke_width": self.stroke_width,
            "stroke_cap": self.stroke_cap,
            "stroke_join": self.stroke_join,
            "dash": self.dash,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Style":
        def dec(v):
            if v is None:
                return None
            t = v.get("__type__")
            if t == "AardColour":
                from ..colour.colour import AardColour

                return AardColour.from_dict(v)
            if t == "AardGradient":
                from ..colour.gradient import AardGradient

                return AardGradient.from_dict(v)
            return None

        return cls(
            fill=dec(d.get("fill")),
            stroke=dec(d.get("stroke")),
            stroke_width=d.get("stroke_width", 1.0),
            stroke_cap=d.get("stroke_cap", "butt"),
            stroke_join=d.get("stroke_join", "miter"),
            dash=d.get("dash"),
        )


class AardObject:
    """Universal scene-graph node.

    Every AARDVARK entity — path, shape, text, image, brush stroke, colour
    field, gradient, mask, pattern, procedural generator, geometric
    construction, symbol, component, group, artboard, animation or data
    visualisation — is represented (or wrapped) as an AardObject so that
    the whole document can be traversed, searched, transformed and
    serialized uniformly.
    """

    def __init__(
        self,
        type: AardObjectType,
        id: Optional[str] = None,
        name: Optional[str] = None,
    ):
        self.id = id or new_id(type.value.lower())
        self.type = type
        self.name = name or self.id
        self.parent: Optional["AardObject"] = None
        self.children: list["AardObject"] = []

        self.transform = Transform.identity()
        self.position = (0.0, 0.0)
        self.rotation = 0.0
        self.scale = (1.0, 1.0)
        self.opacity = 1.0
        self.visibility = True
        self.locked = False
        self.blend_mode = BlendMode.NORMAL
        self.style = Style()
        self.metadata: dict[str, Any] = {}
        self.tags: list[str] = []

        # Universal mask slot (spec section 26: "masks are universal").
        # Holds an AardMask (raster / vector / gradient / procedural /
        # colour / luminosity) applied to this object's rendered alpha.
        self.mask: Optional[Any] = None

        # Generator provenance: for PROCEDURAL / parametric SHAPE objects,
        # records the callable name + kwargs used to build the geometry so
        # the object "remains associated with its generator parameters"
        # (spec section 9) and can be regenerated deterministically.
        self.generator: Optional[dict] = None

        # Object-specific payload (Path geometry, PIL image, text runs, ...)
        self.data: Any = None

    # ------------------------------------------------------------------
    # Scene graph management
    # ------------------------------------------------------------------
    def add(self, child: "AardObject", index: Optional[int] = None) -> "AardObject":
        if child is self:
            raise ValueError("An object cannot be its own child")
        if child.parent is not None:
            child.parent.remove(child)
        child.parent = self
        if index is None:
            self.children.append(child)
        else:
            self.children.insert(index, child)
        return child

    def remove(self, child: "AardObject") -> None:
        if child in self.children:
            self.children.remove(child)
            child.parent = None

    def reparent(self, new_parent: "AardObject", index: Optional[int] = None) -> None:
        new_parent.add(self, index)

    def index_in_parent(self) -> Optional[int]:
        if self.parent is None:
            return None
        return self.parent.children.index(self)

    def walk(self) -> Iterator["AardObject"]:
        """Depth-first traversal including self."""
        yield self
        for child in self.children:
            yield from child.walk()

    def find(self, predicate) -> list["AardObject"]:
        return [obj for obj in self.walk() if predicate(obj)]

    def find_by_id(self, id: str) -> Optional["AardObject"]:
        for obj in self.walk():
            if obj.id == id:
                return obj
        return None

    def find_by_tag(self, tag: str) -> list["AardObject"]:
        return self.find(lambda o: tag in o.tags)

    def ancestors(self) -> Iterator["AardObject"]:
        node = self.parent
        while node is not None:
            yield node
            node = node.parent

    def root(self) -> "AardObject":
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def depth(self) -> int:
        return sum(1 for _ in self.ancestors())

    # ------------------------------------------------------------------
    # Transform convenience (keep .position/.rotation/.scale in sync with
    # the composed affine Transform used for actual math)
    # ------------------------------------------------------------------
    def local_matrix(self) -> Transform:
        t = Transform.translation(*self.position)
        r = Transform.rotation(self.rotation)
        s = Transform.scaling(*self.scale)
        return s.then(r).then(t).then(self.transform)

    def world_matrix(self) -> Transform:
        m = self.local_matrix()
        node = self.parent
        while node is not None:
            m = m.then(node.local_matrix())
            node = node.parent
        return m

    def move(self, dx: float, dy: float) -> "AardObject":
        x, y = self.position
        self.position = (x + dx, y + dy)
        return self

    def move_to(self, x: float, y: float) -> "AardObject":
        self.position = (x, y)
        return self

    def rotate(self, degrees: float) -> "AardObject":
        self.rotation += degrees
        return self

    def scale_by(self, sx: float, sy: Optional[float] = None) -> "AardObject":
        if sy is None:
            sy = sx
        cx, cy = self.scale
        self.scale = (cx * sx, cy * sy)
        return self

    # ------------------------------------------------------------------
    # Ergonomic style shortcuts — ``circle.fill = "#E6E0D2"`` (spec section
    # 32's scripting example) works directly on the object, coercing hex
    # strings to AardColour, while ``circle.style.fill`` still works for
    # code that wants the Style object explicitly.
    # ------------------------------------------------------------------
    @staticmethod
    def _coerce_paint(value):
        if isinstance(value, str):
            from ..colour.colour import AardColour

            return AardColour.from_hex(value)
        return value

    @property
    def fill(self):
        return self.style.fill

    @fill.setter
    def fill(self, value):
        self.style.fill = self._coerce_paint(value)

    @property
    def stroke(self):
        return self.style.stroke

    @stroke.setter
    def stroke(self, value):
        self.style.stroke = self._coerce_paint(value)

    @property
    def stroke_width(self):
        return self.style.stroke_width

    @stroke_width.setter
    def stroke_width(self, value):
        self.style.stroke_width = value

    # ------------------------------------------------------------------
    # Misc
    # ------------------------------------------------------------------
    def duplicate(self, deep: bool = True) -> "AardObject":
        import copy

        clone = copy.deepcopy(self)
        clone.id = new_id(self.type.value.lower())
        clone.parent = None
        if not deep:
            clone.children = []
        else:
            for c in clone.children:
                c.parent = clone
        return clone

    def bounds(self):
        """Local-space bounding box (minx, miny, maxx, maxy) or None.

        Subsystems (vector, raster, text, ...) attach a ``bounds()``-capable
        payload to ``self.data``; this delegates to it when possible so
        generic composition/layout code can call ``obj.bounds()`` on any
        object. Own geometry and children are aggregated together (rare,
        but an object can have both, e.g. a decorated path) so nothing
        with children is ever under-reported — callers like the renderer's
        region sizing rely on this bound never being smaller than what
        actually gets drawn.
        """
        xs0, ys0 = [], []
        if hasattr(self.data, "bounds"):
            try:
                own = self.data.bounds()
            except Exception:
                own = None
            if own is not None:
                minx, miny, maxx, maxy = own
                xs0.extend([minx, maxx])
                ys0.extend([miny, maxy])
        for c in self.children:
            b = c.bounds()
            if b is None:
                continue
            minx, miny, maxx, maxy = b
            pts = [(minx, miny), (maxx, miny), (maxx, maxy), (minx, maxy)]
            pts = c.local_matrix().apply_points(pts)
            for px, py in pts:
                xs0.append(px)
                ys0.append(py)
        if not xs0:
            return None
        return (min(xs0), min(ys0), max(xs0), max(ys0))

    def __repr__(self) -> str:
        return f"<AardObject {self.type.value} id={self.id!r} name={self.name!r} children={len(self.children)}>"

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------
    def to_dict(self) -> dict:
        from ..vector.path import Path as VectorPath  # local import to avoid cycles

        data_repr = None
        if self.data is not None:
            if hasattr(self.data, "to_dict"):
                data_repr = {"__type__": type(self.data).__name__, **self.data.to_dict()}
            else:
                data_repr = None  # raster/binary payloads handled by document asset store

        return {
            "id": self.id,
            "type": self.type.value,
            "name": self.name,
            "position": list(self.position),
            "rotation": self.rotation,
            "scale": list(self.scale),
            "opacity": self.opacity,
            "visibility": self.visibility,
            "locked": self.locked,
            "blend_mode": self.blend_mode.value,
            "transform": self.transform.to_dict(),
            "style": self.style.to_dict(),
            "metadata": self.metadata,
            "tags": self.tags,
            "generator": self.generator,
            "data": data_repr,
            "children": [c.to_dict() for c in self.children],
        }

    @classmethod
    def from_dict(cls, d: dict, data_decoder=None) -> "AardObject":
        obj = cls(AardObjectType(d["type"]), id=d["id"], name=d.get("name"))
        obj.position = tuple(d.get("position", (0, 0)))
        obj.rotation = d.get("rotation", 0.0)
        obj.scale = tuple(d.get("scale", (1, 1)))
        obj.opacity = d.get("opacity", 1.0)
        obj.visibility = d.get("visibility", True)
        obj.locked = d.get("locked", False)
        obj.blend_mode = BlendMode(d.get("blend_mode", "normal"))
        obj.transform = Transform.from_dict(d.get("transform", {})) if d.get("transform") else Transform.identity()
        if d.get("style"):
            obj.style = Style.from_dict(d["style"])
        obj.metadata = d.get("metadata", {})
        obj.tags = d.get("tags", [])
        obj.generator = d.get("generator")
        if data_decoder is not None and d.get("data") is not None:
            obj.data = data_decoder(d["data"])
        for cd in d.get("children", []):
            obj.add(AardObject.from_dict(cd, data_decoder=data_decoder))
        return obj
