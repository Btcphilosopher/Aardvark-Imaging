"""Deterministic, collision-resistant identifiers for Aard Objects."""
from __future__ import annotations

import itertools
import uuid

_counter = itertools.count(1)


def new_id(prefix: str = "aard") -> str:
    """Generate a new object id.

    Ids are of the form ``prefix-<8 hex chars>-<counter>``. The counter
    component guarantees uniqueness within a single process even if the
    system clock or random source is degenerate; the hex component keeps
    ids from different processes from colliding when documents are merged.
    """
    return f"{prefix}-{uuid.uuid4().hex[:8]}-{next(_counter)}"
