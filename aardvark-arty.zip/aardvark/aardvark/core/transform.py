"""Affine transformation engine.

AARDVARK represents 2D affine transforms as a 2x3 matrix::

    | a  c  tx |
    | b  d  ty |
    | 0  0  1  |

applied to column vectors ``[x, y, 1]``. Composition is matrix
multiplication, so ``A.then(B)`` means "apply A, then apply B" and is
implemented as ``B.matrix @ A.matrix``.

Objects preserve their original parametric geometry; the Transform is
carried alongside geometry rather than baked into it, so a Path generated
by ``star(...)`` remains a star even after rotation/scale (section 7 & 8
of the spec).
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterable, Tuple

Number = float


@dataclass(frozen=True)
class Transform:
    a: float = 1.0
    b: float = 0.0
    c: float = 0.0
    d: float = 1.0
    tx: float = 0.0
    ty: float = 0.0

    # ------------------------------------------------------------------
    # Constructors
    # ------------------------------------------------------------------
    @classmethod
    def identity(cls) -> "Transform":
        return cls()

    @classmethod
    def translation(cls, dx: float, dy: float) -> "Transform":
        return cls(1, 0, 0, 1, dx, dy)

    @classmethod
    def scaling(cls, sx: float, sy: float | None = None, origin: Tuple[float, float] = (0, 0)) -> "Transform":
        if sy is None:
            sy = sx
        t = cls(sx, 0, 0, sy, 0, 0)
        return Transform.around(t, origin)

    @classmethod
    def rotation(cls, degrees: float, origin: Tuple[float, float] = (0, 0)) -> "Transform":
        r = math.radians(degrees)
        cos_r, sin_r = math.cos(r), math.sin(r)
        t = cls(cos_r, sin_r, -sin_r, cos_r, 0, 0)
        return Transform.around(t, origin)

    @classmethod
    def shearing(cls, shx: float = 0.0, shy: float = 0.0, origin: Tuple[float, float] = (0, 0)) -> "Transform":
        t = cls(1, math.tan(math.radians(shy)), math.tan(math.radians(shx)), 1, 0, 0)
        return Transform.around(t, origin)

    @classmethod
    def reflection(cls, axis: str = "x", origin: Tuple[float, float] = (0, 0)) -> "Transform":
        if axis == "x":
            t = cls(1, 0, 0, -1, 0, 0)
        elif axis == "y":
            t = cls(-1, 0, 0, 1, 0, 0)
        elif axis == "origin":
            t = cls(-1, 0, 0, -1, 0, 0)
        else:
            raise ValueError("axis must be 'x', 'y' or 'origin'")
        return Transform.around(t, origin)

    @staticmethod
    def around(t: "Transform", origin: Tuple[float, float]) -> "Transform":
        if origin == (0, 0):
            return t
        ox, oy = origin
        return Transform.translation(-ox, -oy).then(t).then(Transform.translation(ox, oy))

    # ------------------------------------------------------------------
    # Composition
    # ------------------------------------------------------------------
    def then(self, other: "Transform") -> "Transform":
        """Return the transform equal to "apply self, then apply other"."""
        a1, b1, c1, d1, tx1, ty1 = self.a, self.b, self.c, self.d, self.tx, self.ty
        a2, b2, c2, d2, tx2, ty2 = other.a, other.b, other.c, other.d, other.tx, other.ty
        return Transform(
            a=a2 * a1 + c2 * b1,
            b=b2 * a1 + d2 * b1,
            c=a2 * c1 + c2 * d1,
            d=b2 * c1 + d2 * d1,
            tx=a2 * tx1 + c2 * ty1 + tx2,
            ty=b2 * tx1 + d2 * ty1 + ty2,
        )

    def __matmul__(self, other: "Transform") -> "Transform":
        return other.then(self)

    def inverse(self) -> "Transform":
        det = self.a * self.d - self.b * self.c
        if abs(det) < 1e-12:
            raise ZeroDivisionError("Transform is not invertible (determinant ~ 0)")
        ia = self.d / det
        ib = -self.b / det
        ic = -self.c / det
        id_ = self.a / det
        itx = -(ia * self.tx + ic * self.ty)
        ity = -(ib * self.tx + id_ * self.ty)
        return Transform(ia, ib, ic, id_, itx, ity)

    # ------------------------------------------------------------------
    # Application
    # ------------------------------------------------------------------
    def apply(self, x: float, y: float) -> Tuple[float, float]:
        return (self.a * x + self.c * y + self.tx, self.b * x + self.d * y + self.ty)

    def apply_vector(self, dx: float, dy: float) -> Tuple[float, float]:
        """Apply the linear part only (ignores translation) — for directions/normals."""
        return (self.a * dx + self.c * dy, self.b * dx + self.d * dy)

    def apply_points(self, points: Iterable[Tuple[float, float]]) -> list[Tuple[float, float]]:
        return [self.apply(x, y) for x, y in points]

    # ------------------------------------------------------------------
    # Decomposition (translation, rotation, scale, shear)
    # ------------------------------------------------------------------
    def decompose(self) -> dict:
        a, b, c, d = self.a, self.b, self.c, self.d
        scale_x = math.hypot(a, b)
        shear = (a * c + b * d) / scale_x if scale_x else 0.0
        c2 = c - a * shear
        d2 = d - b * shear
        scale_y = math.hypot(c2, d2)
        shear /= scale_y if scale_y else 1.0
        determinant = a * d - b * c
        if determinant < 0:
            scale_x = -scale_x
        rotation = math.degrees(math.atan2(b, a))
        return {
            "translation": (self.tx, self.ty),
            "rotation": rotation,
            "scale": (scale_x, scale_y),
            "shear": shear,
        }

    def as_matrix3(self):
        import numpy as np

        return np.array(
            [
                [self.a, self.c, self.tx],
                [self.b, self.d, self.ty],
                [0.0, 0.0, 1.0],
            ]
        )

    def to_svg(self) -> str:
        return f"matrix({self.a},{self.b},{self.c},{self.d},{self.tx},{self.ty})"

    def to_dict(self) -> dict:
        return {"a": self.a, "b": self.b, "c": self.c, "d": self.d, "tx": self.tx, "ty": self.ty}

    @classmethod
    def from_dict(cls, data: dict) -> "Transform":
        return cls(**data)


@dataclass
class PerspectiveTransform:
    """A projective (homogeneous) transform for perspective warps (section 7).

    Stored as a full 3x3 matrix, unlike the affine :class:`Transform`.
    """

    matrix: "object" = None  # numpy array, set in __post_init__

    def __post_init__(self):
        import numpy as np

        if self.matrix is None:
            self.matrix = np.eye(3)

    @classmethod
    def from_quad(cls, src, dst):
        """Compute the perspective transform mapping 4 src points to 4 dst points."""
        import numpy as np

        A = []
        b = []
        for (x, y), (u, v) in zip(src, dst):
            A.append([x, y, 1, 0, 0, 0, -u * x, -u * y])
            b.append(u)
            A.append([0, 0, 0, x, y, 1, -v * x, -v * y])
            b.append(v)
        A = np.array(A)
        b = np.array(b)
        h = np.linalg.solve(A, b)
        m = np.array([[h[0], h[1], h[2]], [h[3], h[4], h[5]], [h[6], h[7], 1.0]])
        return cls(matrix=m)

    def apply(self, x: float, y: float) -> Tuple[float, float]:
        import numpy as np

        v = self.matrix @ np.array([x, y, 1.0])
        return (v[0] / v[2], v[1] / v[2])

    def apply_points(self, points):
        return [self.apply(x, y) for x, y in points]
