"""Asset library (spec section 48): brushes, fonts, patterns, textures,
symbols, images, palettes, presets and procedural generators with
searchable metadata.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class Asset:
    id: str
    kind: str  # brush | font | pattern | texture | symbol | image | palette | preset | generator
    name: str
    payload: Any
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


class AssetLibrary:
    def __init__(self):
        self._assets: Dict[str, Asset] = {}

    def add(self, asset: Asset) -> Asset:
        self._assets[asset.id] = asset
        return asset

    def register(self, kind: str, name: str, payload: Any, tags: Optional[List[str]] = None, **metadata) -> Asset:
        asset_id = f"{kind}:{name}"
        return self.add(Asset(asset_id, kind, name, payload, tags or [], metadata))

    def get(self, asset_id: str) -> Optional[Asset]:
        return self._assets.get(asset_id)

    def by_kind(self, kind: str) -> List[Asset]:
        return [a for a in self._assets.values() if a.kind == kind]

    def search(self, query: str) -> List[Asset]:
        q = query.lower()
        return [
            a
            for a in self._assets.values()
            if q in a.name.lower() or any(q in tag.lower() for tag in a.tags) or q in a.kind.lower()
        ]

    def __len__(self):
        return len(self._assets)

    def __iter__(self):
        return iter(self._assets.values())


def default_library() -> AssetLibrary:
    """Populate a library with the built-in brush presets and L-system
    presets, so a fresh document has something to browse immediately."""
    from ..paint.brush import PRESETS as brush_presets
    from ..procedural.lsystem import PRESETS as lsystem_presets

    lib = AssetLibrary()
    for name, brush in brush_presets.items():
        lib.register("brush", name, brush, tags=["builtin"])
    for name, system in lsystem_presets.items():
        lib.register("generator", name, system, tags=["builtin", "lsystem"])
    return lib
