"""First vertical slice (spec section 78):

    OPEN AARDVARK -> NEW DOCUMENT -> CREATE SHAPE -> MOVE -> ROTATE ->
    CHANGE COLOUR -> ADD TEXT -> ADD IMAGE -> ADD MASK -> GROUP -> UNDO ->
    SAVE .AARD -> EXPORT SVG/PNG

Run with:  python examples/01_first_vertical_slice.py
"""
import os

import numpy as np

import aardvark as aard
from aardvark.core.object import AardObject, AardObjectType
from aardvark.colour.colour import AardColour
from aardvark.masks.mask import AardMask
from aardvark.raster.image import RasterImage
from aardvark.history.history import History, make_command

OUT_DIR = os.path.join(os.path.dirname(__file__), "output")
os.makedirs(OUT_DIR, exist_ok=True)

# NEW DOCUMENT
doc = aard.create_document(1000, 700, name="First Slice", background="#0B0B0C")

# CREATE SHAPE
hexagon = aard.polygon(center=(300, 350), sides=6, radius=160)
hexagon.fill = "#26262A"

# MOVE + ROTATE
hexagon.move(40, -10)
hexagon.rotate(15)

# CHANGE COLOUR
hexagon.fill = "#C9A84C"
hexagon.stroke = "#00E5FF"
hexagon.stroke_width = 3

doc.add(hexagon)

# ADD TEXT
title = aard.text("AARDVARK", x=520, y=220, size=64, family="DejaVu Sans", colour="#F2EFE6")
title.name = "Title"
doc.add(title)

subtitle = aard.text(
    "computational art & design engine", x=522, y=310, size=20, family="DejaVu Sans", colour="#9A9A9E"
)
doc.add(subtitle)

# ADD IMAGE — a small procedurally generated placeholder "photograph" so
# this example has no external asset dependency; RasterImage is a normal
# first-class object either way (imported photo or generated pixels).
noise_rgb = (np.random.default_rng(7).random((160, 160, 3)) * 0.3 + 0.15)
placeholder_photo = RasterImage.from_numpy(noise_rgb, assume_float=True)
photo_obj = aard.image(placeholder_photo, x=560, y=340)
photo_obj.name = "Placeholder Photo"

# ADD MASK — a soft circular vignette mask on the photo.
yy, xx = np.mgrid[0:160, 0:160]
dist = np.hypot(xx - 80, yy - 80) / 80
vignette_alpha = np.clip(1.2 - dist, 0, 1).astype(np.float32)
photo_obj.mask = AardMask.from_raster_alpha(vignette_alpha, feather=4)
doc.add(photo_obj)

# GROUP — collect the title + subtitle into one group.
text_group = doc.group(title, subtitle, name="Titles")

# UNDO — demonstrate the history engine wrapping a document edit.
history = History()
original_opacity = hexagon.opacity


def set_opacity(obj, value):
    old = obj.opacity

    def do():
        obj.opacity = value

    def undo():
        obj.opacity = old

    return make_command(f"Set opacity to {value}", do, undo)


history.do(set_opacity(hexagon, 0.4))
assert hexagon.opacity == 0.4
history.undo()
assert hexagon.opacity == original_opacity
print(f"Undo restored hexagon.opacity to {hexagon.opacity}")

# SAVE .AARD — the full editable recipe, not a flattened image.
aard_path = os.path.join(OUT_DIR, "01_first_slice.aard")
doc.export(aard_path)
print(f"Saved {aard_path}")

# EXPORT SVG / PNG
svg_path = os.path.join(OUT_DIR, "01_first_slice.svg")
png_path = os.path.join(OUT_DIR, "01_first_slice.png")
doc.export(svg_path)
doc.export(png_path, dpi=150)
print(f"Exported {svg_path}")
print(f"Exported {png_path}")
