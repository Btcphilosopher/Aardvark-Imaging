"""Third vertical slice (spec section 80):

    Procedural art, particles, data visualisation, image analysis,
    animation, AI-assisted object generation.
"""
import os

import numpy as np

import aardvark as aard
from aardvark.core.object import AardObject, AardObjectType, BlendMode
from aardvark.colour.colour import AardColour
from aardvark.colour.gradient import AardGradient
from aardvark.procedural.flowfield import flow_field_paths
from aardvark.particles.particle import ParticleSystem, gravity, drag, vortex
from aardvark.data.binding import Scale, DataBinding, bind, colour_scale
from aardvark.analysis.image_analysis import analyse as analyse_image
from aardvark.animation.timeline import Timeline, Keyframe, render_animation, export_gif
from aardvark.rendering.renderer import CPURenderer
from aardvark.ai.base import DesignAssistant

OUT_DIR = os.path.join(os.path.dirname(__file__), "output")
os.makedirs(OUT_DIR, exist_ok=True)

# --- Procedural art: flow-field trajectories rendered as thin gradient strokes
doc = aard.create_document(1000, 1000, name="Third Slice", background="#08080A")
paths = flow_field_paths(particles=500, turbulence=0.4, scale=2.5, steps=90, width=1000, height=1000, seed=21)
flow_group = doc.group(name="Flow Field")
field_gradient_colours = [AardColour.from_hex("#00E5FF"), AardColour.from_hex("#C9A84C")]
for i, path in enumerate(paths):
    obj = AardObject(AardObjectType.PATH, name=f"flow-{i}")
    obj.data = path
    obj.style.stroke = field_gradient_colours[i % 2]
    obj.style.stroke_width = 1.2
    obj.opacity = 0.55
    obj.blend_mode = BlendMode.ADD
    flow_group.add(obj)

# --- Particle system: a small vortex burst, sampled at a few time steps and
#     rendered as dots so the simulation itself becomes artwork.
system = ParticleSystem()
system.add_force(gravity(0, 40)).add_force(drag(0.01)).add_force(vortex((500, 500), strength=120))
system.emit(150, origin=(500, 500), spread=20, speed=180, life=2.5, colour=AardColour.from_hex("#8844AA"))
particle_group = doc.group(name="Particles")
for _ in range(40):
    system.step(1 / 30)
for p in system.particles:
    dot = aard.circle(center=p.position, radius=max(0.5, p.size * p.opacity))
    dot.fill = p.colour.with_alpha(p.opacity)
    particle_group.add(dot)

doc.export(os.path.join(OUT_DIR, "03_procedural_particles.png"), dpi=100)
print("Exported procedural + particle artwork.")

# --- Data visualisation: a small generative bar chart from a data binding --
records = [{"label": f"Q{i+1}", "value": v} for i, v in enumerate([32, 58, 41, 77, 63, 90, 48])]
value_scale = Scale.from_data([r["value"] for r in records], (10, 260))
palette_gradient = AardGradient.linear([AardColour.from_hex("#00E5FF"), AardColour.from_hex("#C9A84C")])
bar_colour = colour_scale(records, "value", palette_gradient)

chart_doc = aard.create_document(700, 360, name="Chart", background="#101013")
bar_width = 70
for i, row in enumerate(records):
    h = value_scale(row["value"])
    bar = aard.rectangle(x=40 + i * (bar_width + 20), y=300 - h, width=bar_width, height=h)
    bar.fill = bar_colour(row)
    chart_doc.add(bar)
    label = aard.text(row["label"], x=40 + i * (bar_width + 20) + 18, y=325, size=14, colour="#D8D5CC")
    chart_doc.add(label)
chart_doc.export(os.path.join(OUT_DIR, "03_data_chart.png"), dpi=120)
print("Exported data-driven bar chart.")

# --- Image analysis: analyse the procedural artwork we just made -----------
renderer = CPURenderer(supersample=1)
rendered = renderer.render_document(doc)
report = analyse_image(rendered, n_colours=5)
print(f"Image analysis: brightness={report.brightness:.3f} contrast={report.contrast:.3f} "
      f"edge_density={report.edge_density:.3f}")
print("Dominant palette:", [c.to_hex() for c in report.dominant_palette])

# --- Animation: a short GIF of a shape travelling along an eased path ------
anim_doc = aard.create_document(300, 200, name="Anim", background="#0B0B0C")
mover = aard.circle(radius=16)
mover.fill = "#00E5FF"
anim_doc.add(mover)
timeline = Timeline(duration=1.5, fps=20)
timeline.animate(mover, "position", [Keyframe(0.0, (20, 100), easing="ease_in_out"), Keyframe(1.5, (280, 100), easing="ease_in_out")])
timeline.animate(mover, "opacity", [Keyframe(0.0, 0.2), Keyframe(0.75, 1.0), Keyframe(1.5, 0.2)])
frames = render_animation(timeline, renderer, lambda: anim_doc.artboard.root, 300, 200, background=AardColour.from_hex("#0B0B0C"))
export_gif(frames, os.path.join(OUT_DIR, "03_animation.gif"), fps=20)
print(f"Exported {len(frames)}-frame animation.")

# --- AI-assisted object generation (spec section 49-50): the interface is
#     honestly a stub without a configured model — this demonstrates the
#     contract (structured proposals, not flattened pixels) rather than a
#     specific provider integration.
assistant = DesignAssistant()
proposals = assistant.ask("make this composition more balanced", document=doc)
for p in proposals:
    print(f"AI proposal [{p.kind}]: {p.payload}")
