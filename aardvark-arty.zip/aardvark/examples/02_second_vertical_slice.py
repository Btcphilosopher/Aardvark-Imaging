"""Second vertical slice (spec section 79):

    Bezier paths, boolean geometry, brushes, layers, gradients,
    typography, procedural shapes, Python scripting.
"""
import os

import aardvark as aard
from aardvark.core.object import AardObject, AardObjectType, BlendMode
from aardvark.vector import boolean
from aardvark.vector.path import Path
from aardvark.colour.colour import AardColour
from aardvark.colour.gradient import AardGradient
from aardvark.paint.brush import preset, render_stroke
from aardvark.raster.image import RasterImage
from aardvark.typography.text import TextObject, CharacterStyle, ParagraphStyle

OUT_DIR = os.path.join(os.path.dirname(__file__), "output")
os.makedirs(OUT_DIR, exist_ok=True)

doc = aard.create_document(1200, 800, name="Second Slice", background="#0B0B0C")
ab = doc.artboard

# --- Bezier path, drawn by hand with explicit commands -------------------
leaf = Path()
leaf.move_to(600, 200)
leaf.curve_to((680, 220), (700, 300), (600, 380))
leaf.curve_to((500, 300), (520, 220), (600, 200))
leaf.close_path()
leaf_obj = AardObject(AardObjectType.PATH, name="Leaf")
leaf_obj.data = leaf
leaf_obj.style.fill = AardGradient.linear(
    [AardColour.from_hex("#00E5FF"), AardColour.from_hex("#0B3D91")], start=(520, 200), end=(700, 380)
)
doc.add(leaf_obj)

# --- Boolean geometry: circle union rectangle, minus a hole ---------------
circle_a = aard.circle(center=(150, 150), radius=90).data
rect_b = aard.rectangle(x=150, y=90, width=120, height=120).data
union_result = boolean.union(circle_a, rect_b)
hole = aard.circle(center=(150, 150), radius=30).data
final_geo = boolean.subtract(union_result, hole)

boolean_obj = AardObject(AardObjectType.PATH, name="Boolean Result")
boolean_obj.data = final_geo
boolean_obj.fill = "#C9A84C"
doc.add(boolean_obj)

# --- Brush stroke, rendered as a raster and placed as an IMAGE object ------
brush = preset("charcoal")
stroke_points = [(50 + i * 15, 520 + (i % 3) * 10) for i in range(30)]
tile, offset = render_stroke(stroke_points, brush, AardColour.from_hex("#F2EFE6"))
stroke_obj = AardObject(AardObjectType.BRUSH_STROKE, name="Charcoal Stroke")
stroke_obj.data = tile
stroke_obj.position = offset
doc.add(stroke_obj)

# --- Typography: a text frame with wrapping + justification ---------------
body_style = CharacterStyle(family="DejaVu Sans", size=16, colour=AardColour.from_hex("#D8D5CC"))
para_style = ParagraphStyle(alignment="justify", leading=24)
body_text = TextObject(
    "AARDVARK treats geometry, colour, material, image, composition, "
    "typography and motion as one continuous computational medium rather "
    "than a stack of separate applications.",
    body_style,
    para_style,
    frame_width=380,
)
body_obj = AardObject(AardObjectType.TEXT, name="Body Copy")
body_obj.data = body_text
body_obj.position = (750, 480)
doc.add(body_obj)

# --- Procedural shapes generated with a plain Python loop (spec section 31) -
palette = ["#C9A84C", "#00E5FF", "#8844AA", "#F2EFE6"]
dots_group = doc.group(name="Procedural Dots")
import math

for i in range(60):
    angle = i * 0.35
    r = 4 + i * 4.2
    x = 950 + r * math.cos(angle)
    y = 220 + r * math.sin(angle)
    dot = aard.circle(center=(x, y), radius=3 + (i % 5))
    dot.fill = palette[i % len(palette)]
    dot.opacity = 0.85
    dots_group.add(dot)

doc.export(os.path.join(OUT_DIR, "02_second_slice.png"), dpi=150)
doc.export(os.path.join(OUT_DIR, "02_second_slice.svg"))
doc.export(os.path.join(OUT_DIR, "02_second_slice.aard"))
print("Second vertical slice exported.")
