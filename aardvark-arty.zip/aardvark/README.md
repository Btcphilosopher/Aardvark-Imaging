# AARDVARK

**A Python-native computational art, design, illustration, typography, vector, raster and generative graphics engine.**

```
IDEA → GEOMETRY → COLOUR → MATERIAL → IMAGE → COMPOSITION → TYPOGRAPHY → MOTION → DESIGN
```

AARDVARK is not a photo editor, not a drawing app, not a vector editor — it's the
computational engine those applications would be built *on top of*. The fundamental
unit is not a pixel; it's the **Aard Object**: a path, shape, text run, image, brush
stroke, colour field, gradient, mask, pattern, procedural generator, symbol, group,
artboard, or animation — all living in one scene graph, all editable, all reachable
identically from a GUI, the Python scripting API, the CLI, or a plugin, because the
single source of truth is always the **Document**, never any one view onto it.

This build is the engine: a real, tested, headless Python library plus a CLI. There
is no bundled GUI — the spec's own architectural rule (section 82) is that the UI is
only a *view and control surface* over the Document, never the source of truth, so a
faithful "first vertical slice" is a Document/scene-graph/renderer/export pipeline
that a GUI could be built against later, exercised end-to-end without one.

## Install

```bash
pip install -e .            # core: numpy, Pillow, shapely
pip install -e ".[full]"    # + scipy, reportlab, imageio[ffmpeg], opencv, fonttools
pip install -e ".[dev]"     # + pytest, pytest-cov
```

Python 3.9+. Every optional feature (PDF export, MP4 export, Voronoi patterns,
palette extraction without scipy's fallback, faster edge detection) raises a clear,
actionable `RuntimeError` naming the missing package if you use it without its
optional dependency — nothing fails silently or produces a degraded result without
saying so.

## Quickstart

```python
import aardvark as aard

doc = aard.create_document(4000, 3000)
circle = aard.circle(center=(2000, 1500), radius=500)
circle.fill = "#E6E0D2"
doc.add(circle)
doc.export("artwork.png")
```

`import aardvark as aard` *is* the scripting API the spec describes (section 32) —
every subsystem hangs off it as a submodule (`aard.colour`, `aard.vector`,
`aard.procedural`, `aard.effects`, ...) alongside the flattened shape/document
helpers shown above. Nothing returned by `aard.circle()`/`aard.star()`/etc. is a
special "scripting" object — it's a plain `AardObject`, exactly as editable from the
`.aard` file, a plugin, or (eventually) a GUI.

```python
# Generative design as ordinary Python (spec section 31)
import math
for i in range(100):
    dot = aard.circle(center=(i * 20, math.sin(i) * 50 + 200), radius=i / 10 + 1)
    dot.fill = "#00E5FF"
    doc.add(dot)

# Procedural art
trajectories = aard.procedural.flow_field(particles=10000, turbulence=0.35, scale=2.0)
```

Three runnable, progressively richer walkthroughs live in `examples/`, matching the
spec's own three vertical slices (sections 78-80) — run them and look in
`examples/output/`:

- `01_first_vertical_slice.py` — new document, shape, move/rotate/recolour, text,
  image + mask, group, undo, save `.aard`, export SVG/PNG.
- `02_second_vertical_slice.py` — hand-drawn Bezier paths, boolean geometry, a
  charcoal brush stroke, gradients, justified text wrap, a procedural Python loop.
- `03_third_vertical_slice.py` — 500-trajectory flow-field art, a particle vortex,
  a data-driven bar chart, image analysis of the result, a short eased GIF
  animation, and the AI-assistant contract (honestly stubbed — see below).

## Architecture

```
aardvark/
├── core/          AardObject, AardObjectType, Transform (affine matrices), Style, scene graph
├── document/      Document, Artboard, .aard file format (zip: manifest.json + assets/)
├── geometry/      Bezier maths: eval, flatten, split, arc<->cubic conversion, bbox, length
├── vector/        Path (node/handle model), parametric shapes, boolean ops (via shapely)
├── colour/        AardColour (RGB/HSL/HSV/LAB/XYZ/CMYK), AardPalette, AardGradient
├── raster/        RasterImage/Layer/Tile/TileCache, blend-mode compositing
├── masks/         Raster/vector/gradient/procedural/luminosity/colour masks + combine ops
├── paint/         Brush model + stamp/stroke rendering, an explicitly-approximate pigment model
├── typography/    TextObject/TextFrame/GlyphRun/CharacterStyle/ParagraphStyle, text-on-path
├── layout/        Column/baseline/polar/isometric/perspective grids, design tokens & system
├── composition/   Balance/symmetry/density/contrast analysis (guides, not auto-layout)
├── procedural/    Perlin/simplex/value noise, fBm, Voronoi, fractals, L-systems, flow fields, CA
├── particles/     2D particle system with composable forces
├── patterns/      Tile/radial/linear/hex/Voronoi patterns; mirror/rotational/kaleidoscopic symmetry
├── data/          CSV/JSON/DataFrame → visual-channel binding (position/size/colour/...)
├── analysis/      Image analysis: palette extraction, histogram, edges, crude segmentation
├── effects/       Non-destructive blur/shadow/glow/outline/bevel/grain/warp + a filter graph
├── animation/     Keyframes, easing (incl. cubic-bezier), Timeline, GIF/MP4/image-sequence export
├── three_d/       Scene/Camera/Light/Material/Mesh/Object3D + cube/sphere/plane/cylinder/extrude
├── history/       Branching undo/redo Command tree with named snapshots
├── rendering/      CPURenderer (region-limited, not full-canvas-per-object), Preview/ExportRenderer
├── export/        AardSVGWriter/Parser, PNG/JPEG/TIFF/WebP export, PDF/print (AardPublication)
├── scripting/     The `aard.*` facade (create_document, circle, star, ..., regenerate)
├── plugins/       AardPlugin base + registries (brushes/filters/generators/formats/tools/...)
├── ai/            AICreativeModel interface + DesignAssistant (structured proposals, not pixels)
├── assets/        AssetLibrary with searchable brush/font/pattern/palette/preset metadata
└── cli/           `aardvark new|run|export|info`
```

## What's real vs. what's a documented stub

Everything above is implemented and exercised by the test suite — this isn't a
folder skeleton. A few things are deliberately narrower than the full spec
fantasy, and say so in their own docstrings rather than pretending otherwise:

- **No bundled GUI.** The spec's own critical rule (section 82) is that the UI is
  a view, not the source of truth — this ships the engine that view would sit on.
- **Rendering is CPU-only** (`CPURenderer`, built on NumPy + Pillow). `GPURenderer`
  is a documented extension point (same `Renderer` interface) with no backend
  bundled.
- **Typography shaping is advance-width based** (Pillow/FreeType metrics), not a
  full HarfBuzz pipeline — no complex-script shaping or real ligature substitution.
  OpenType feature flags are accepted and forwarded, not implemented from scratch.
- **The pigment-mixing model** (`paint.mixing`) is explicitly labelled as a
  plausible approximation, per the spec's own instruction not to claim physical
  accuracy without validating it against real pigment data.
- **PDF export embeds each page as a high-DPI raster**, not native vector PDF
  operators — it still gets page size, DPI, bleed, trim marks and CMYK/sRGB right.
- **The AI subsystem** (`ai.DesignAssistant`) is a real, structured interface
  (proposals carry palettes/layouts/objects, never flattened pixels) with no
  model wired in — `NullModel` explains this instead of silently no-opping, and a
  plugin supplies a concrete `AICreativeModel` to activate it.
- **Boolean geometry requires `shapely`** (an optional dependency, on by default in
  `pyproject.toml`) rather than a hand-rolled polygon clipper, because getting that
  robust by hand is a research problem in itself.

## Testing

```bash
pytest                    # 130+ tests: geometry, boolean ops, colour conversion,
                           # rasterisation, masks, .aard round-trip, undo/redo,
                           # procedural determinism, SVG round-trip, PNG/PDF export
```

This suite is not decorative — building it against the real implementation caught
and fixed several genuine bugs before this release, including a pivot-point sign
error in `Transform`'s rotate/scale/shear-around-a-point path, inward-facing
normals on the built-in 3D primitives, a value-noise generator that only ever
produced values in [0, 0.25], and a mask-scaling bug where an object's own mask was
being stretched across the whole canvas instead of its own region.

## The `.aard` file format

A `.aard` file is a zip: `manifest.json` (the full scene graph, styles, transforms,
generator parameters, palettes, variables, export profiles) plus `assets/*.png` for
embedded raster images. It's the artwork's *recipe*, not a flattened image —
reopening one reconstructs every object exactly as editable as it was, including a
procedural shape's original generator parameters (`aardvark.scripting.api.regenerate`).

## CLI

```bash
aardvark new "My Piece" --width 1920 --height 1080 -o piece.aard
aardvark run generate_poster.py
aardvark export piece.aard piece.png --dpi 300
aardvark export piece.aard piece.svg
aardvark info
```

## License

MIT.
