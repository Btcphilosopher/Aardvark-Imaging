"""
Geometry optimiser: applies vertex welding, normal-computation
vectorisation and LOD simplification to a mesh, benchmarking each step
against its naive baseline and validating geometric error against the
caller's tolerance before accepting it.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from cgi_x.core.state import OptimizationRecord
from cgi_x.geometry.mesh import Mesh
from cgi_x.geometry.normals import (
    compute_face_normals_naive,
    compute_face_normals_vectorized,
    max_normal_deviation,
)
from cgi_x.geometry.simplification import SimplificationResult, simplify_by_clustering
from cgi_x.geometry.topology import remove_unreferenced_vertices, weld_duplicate_vertices
from cgi_x.profiling.benchmark import compare


@dataclass
class GeometryOptimizationResult:
    mesh: Mesh
    original_vertex_count: int
    original_face_count: int
    records: List[OptimizationRecord] = field(default_factory=list)

    @property
    def vertex_reduction_percent(self) -> float:
        if self.original_vertex_count == 0:
            return 0.0
        return (self.original_vertex_count - self.mesh.vertex_count) / self.original_vertex_count * 100


def optimize_normals(mesh: Mesh, repeats: int = 5) -> OptimizationRecord:
    """Benchmark naive vs vectorised face-normal computation on this mesh
    and record the real, measured gain. Also validates that the two
    methods produce numerically equivalent normals (they must — this
    optimisation changes *how* the answer is computed, never *what* it is)."""
    comparison = compare(compute_face_normals_naive, compute_face_normals_vectorized,
                          mesh, repeats=repeats, warmup=1, label="geometry.normals")

    naive_normals = compute_face_normals_naive(mesh)
    fast_normals = compute_face_normals_vectorized(mesh)
    deviation = max_normal_deviation(naive_normals, fast_normals)

    accepted = comparison.is_statistically_faster() and deviation < 1e-6

    return OptimizationRecord(
        workload=f"{mesh.name}.normals",
        category="geometry",
        baseline_time=comparison.baseline.median_wall_time,
        optimized_time=comparison.optimised.median_wall_time,
        gain_fraction=comparison.speed_gain_fraction,
        memory_change_fraction=comparison.memory_change_fraction,
        quality_difference=deviation,
        accepted=accepted,
        reason="vectorised normals match naive computation to numerical precision" if accepted
               else "rejected: gain not significant or normals diverged",
    )


def optimize_mesh(
    mesh: Mesh,
    max_geometric_error: float = 0.001,
    lod_grid_resolution: Optional[int] = None,
    weld_decimals: int = 6,
) -> GeometryOptimizationResult:
    """
    Run the full geometry-optimisation stage on one mesh:
      1. Weld duplicate vertices (zero visual impact, guaranteed win).
      2. Optionally simplify via clustering, but only accept it if the
         measured geometric error stays under `max_geometric_error`.
    """
    records: List[OptimizationRecord] = []
    original_v, original_f = mesh.vertex_count, mesh.face_count

    welded = weld_duplicate_vertices(mesh, decimals=weld_decimals)
    welded = remove_unreferenced_vertices(welded)
    weld_reduction = 1 - (welded.vertex_count / max(1, original_v))
    records.append(OptimizationRecord(
        workload=f"{mesh.name}.weld",
        category="geometry",
        baseline_time=0.0,
        optimized_time=0.0,
        gain_fraction=weld_reduction,
        quality_difference=0.0,
        accepted=True,
        reason="duplicate-vertex welding is lossless (zero geometric error)",
        extra={"vertices_removed": original_v - welded.vertex_count},
    ))

    final_mesh = welded

    if lod_grid_resolution is not None:
        simplification: SimplificationResult = simplify_by_clustering(welded, grid_resolution=lod_grid_resolution)
        accepted = simplification.geometric_error <= max_geometric_error
        records.append(OptimizationRecord(
            workload=f"{mesh.name}.simplify",
            category="geometry",
            baseline_time=0.0,
            optimized_time=0.0,
            gain_fraction=simplification.reduction_fraction,
            quality_difference=simplification.geometric_error,
            accepted=accepted,
            reason=(f"geometric error {simplification.geometric_error:.5f} within tolerance {max_geometric_error}"
                    if accepted else
                    f"rejected: geometric error {simplification.geometric_error:.5f} exceeds tolerance {max_geometric_error}"),
        ))
        if accepted:
            final_mesh = simplification.mesh

    records.append(optimize_normals(final_mesh))

    return GeometryOptimizationResult(
        mesh=final_mesh,
        original_vertex_count=original_v,
        original_face_count=original_f,
        records=records,
    )
