"""Cache optimiser: wraps an arbitrary function with content-addressable
caching and measures the real hit-driven speedup on a representative
call pattern (as opposed to assuming caching always helps)."""

from __future__ import annotations

from typing import Callable, Iterable

from cgi_x.cache.cache import Cache, make_cache_key
from cgi_x.core.state import OptimizationRecord
from cgi_x.profiling.profiler import Profiler


def memoize(cache: Cache, version: str = "1"):
    """Decorator: cache a function's return value by its arguments."""
    def decorator(func: Callable):
        def wrapper(*args, **kwargs):
            key = make_cache_key((args, kwargs), version=version)
            return cache.get_or_compute(key, lambda: func(*args, **kwargs), persist=False)
        wrapper.__wrapped__ = func
        return wrapper
    return decorator


def measure_cache_gain(func: Callable, call_args: Iterable[tuple], workload_name: str = "cached_call") -> OptimizationRecord:
    """
    Run `func` over a realistic sequence of calls (with repeats, mimicking
    a real pipeline where the same scene/asset evaluation is requested
    multiple times) both uncached and cached, and record the measured gain.
    """
    call_args = list(call_args)

    with Profiler("cache.uncached") as p_uncached:
        for args in call_args:
            func(*args)

    cache = Cache()
    cached_func = memoize(cache)(func)
    with Profiler("cache.cached") as p_cached:
        for args in call_args:
            cached_func(*args)

    baseline = p_uncached.sample.wall_time
    optimized = p_cached.sample.wall_time
    gain = (baseline - optimized) / baseline if baseline > 0 else 0.0

    return OptimizationRecord(
        workload=workload_name,
        category="cache",
        baseline_time=baseline,
        optimized_time=optimized,
        gain_fraction=gain,
        memory_change_fraction=0.0,
        quality_difference=0.0,
        accepted=gain > 0,
        reason=f"cache hit rate {cache.stats.hit_rate:.2%} over {len(call_args)} calls",
    )
