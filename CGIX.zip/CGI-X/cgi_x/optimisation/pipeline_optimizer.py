"""
Pipeline optimiser: runs every applicable per-category optimiser against a
scene, feeds the real measurements into the `MarginalGainEngine`, and
returns the combined, correctly-aggregated result. This is the module
`core.engine.Optimizer` delegates to.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from cgi_x.analytics.performance import MarginalGainEngine
from cgi_x.config.settings import QualityConstraints
from cgi_x.core.state import OptimizationRecord
from cgi_x.optimisation.geometry_optimizer import optimize_mesh
from cgi_x.optimisation.render_optimizer import apply_subdivision_recommendations, optimize_render_prep
from cgi_x.optimisation.simulation_optimizer import optimize_simulation_suite
from cgi_x.rendering.scene import Scene


@dataclass
class PipelineOptimizationResult:
    records: List[OptimizationRecord] = field(default_factory=list)
    gain_engine: MarginalGainEngine = field(default_factory=MarginalGainEngine)

    @property
    def accepted_records(self) -> List[OptimizationRecord]:
        return [r for r in self.records if r.accepted]

    @property
    def rejected_records(self) -> List[OptimizationRecord]:
        return [r for r in self.records if not r.accepted]


def optimize_pipeline(scene: Scene, constraints: Optional[QualityConstraints] = None,
                       run_simulation_benchmarks: bool = True) -> PipelineOptimizationResult:
    constraints = constraints or QualityConstraints()
    records: List[OptimizationRecord] = []
    gain_engine = MarginalGainEngine()

    # --- geometry ---
    for name, obj in list(scene.objects.items()):
        result = optimize_mesh(obj.mesh, max_geometric_error=constraints.max_geometric_error)
        obj.mesh = result.mesh
        records.extend(result.records)

    geometry_records = [r for r in records if r.category == "geometry" and r.accepted and r.baseline_time > 0]
    if geometry_records:
        gain_engine.record_raw(
            "geometry",
            baseline_time=sum(r.baseline_time for r in geometry_records),
            optimized_time=sum(r.optimized_time for r in geometry_records),
            memory_change_fraction=sum(r.memory_change_fraction for r in geometry_records) / len(geometry_records),
        )

    # --- render prep ---
    render_record = optimize_render_prep(scene)
    records.append(render_record)
    records.extend(apply_subdivision_recommendations(scene))
    gain_engine.record_raw("render", render_record.baseline_time, render_record.optimized_time,
                            render_record.memory_change_fraction)

    # --- simulation ---
    if run_simulation_benchmarks:
        sim_records = optimize_simulation_suite()
        records.extend(sim_records)
        accepted_sim = [r for r in sim_records if r.accepted]
        if accepted_sim:
            gain_engine.record_raw(
                "simulation",
                baseline_time=sum(r.baseline_time for r in accepted_sim),
                optimized_time=sum(r.optimized_time for r in accepted_sim),
            )

    return PipelineOptimizationResult(records=records, gain_engine=gain_engine)
