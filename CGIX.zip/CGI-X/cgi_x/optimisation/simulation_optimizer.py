"""
Simulation optimiser: benchmarks naive vs vectorised particle/cloth steps
and validates that the vectorised path produces numerically equivalent
state (within a tight tolerance — floating-point summation order differs
slightly between the two paths, but the physical result must not)."""

from __future__ import annotations

from typing import List

import numpy as np

from cgi_x.core.state import OptimizationRecord
from cgi_x.profiling.benchmark import compare
from cgi_x.simulation import cloth as cloth_mod
from cgi_x.simulation import particles as particles_mod


def optimize_particle_step(n: int = 20000, dt: float = 1 / 60, repeats: int = 5) -> OptimizationRecord:
    system = particles_mod.ParticleSystem.random(n)

    comparison = compare(
        particles_mod.step_naive, particles_mod.step_vectorized,
        system, dt, repeats=repeats, warmup=1, label="simulation.particles",
    )

    naive_result = particles_mod.step_naive(system, dt)
    fast_result = particles_mod.step_vectorized(system, dt)
    state_error = float(np.max(np.abs(naive_result.positions - fast_result.positions)))

    accepted = comparison.is_statistically_faster() and state_error < 1e-9

    return OptimizationRecord(
        workload="particles.step",
        category="simulation",
        baseline_time=comparison.baseline.median_wall_time,
        optimized_time=comparison.optimised.median_wall_time,
        gain_fraction=comparison.speed_gain_fraction,
        memory_change_fraction=comparison.memory_change_fraction,
        quality_difference=state_error,
        accepted=accepted,
        reason=f"n={n} particles, max state deviation {state_error:.2e}",
    )


def optimize_cloth_step(rows: int = 24, cols: int = 24, dt: float = 1 / 60, repeats: int = 5) -> OptimizationRecord:
    cloth = cloth_mod.ClothGrid.create(rows, cols)

    comparison = compare(
        cloth_mod.step_naive, cloth_mod.step_vectorized,
        cloth, dt, repeats=repeats, warmup=1, label="simulation.cloth",
    )

    naive_result = cloth_mod.step_naive(cloth, dt)
    fast_result = cloth_mod.step_vectorized(cloth, dt)
    state_error = float(np.max(np.abs(naive_result.positions - fast_result.positions)))

    accepted = comparison.is_statistically_faster() and state_error < 1e-6

    return OptimizationRecord(
        workload="cloth.step",
        category="simulation",
        baseline_time=comparison.baseline.median_wall_time,
        optimized_time=comparison.optimised.median_wall_time,
        gain_fraction=comparison.speed_gain_fraction,
        memory_change_fraction=comparison.memory_change_fraction,
        quality_difference=state_error,
        accepted=accepted,
        reason=f"{rows}x{cols} cloth grid, max state deviation {state_error:.2e}",
    )


def optimize_simulation_suite() -> List[OptimizationRecord]:
    return [optimize_particle_step(), optimize_cloth_step()]
