"""
Memory optimiser: precision downcasting (where tolerance allows), object
pooling demonstration, and memory telemetry — all measured, never assumed.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, List

import numpy as np

from cgi_x.core.state import OptimizationRecord
from cgi_x.geometry.mesh import Mesh
from cgi_x.numerical.precision import evaluate_precision_reduction
from cgi_x.profiling.profiler import Profiler


def optimize_mesh_precision(mesh: Mesh, max_relative_error: float = 1e-4) -> OptimizationRecord:
    """Attempt float64 -> float32 downcast of vertex data; accept only if
    the measured relative error stays within tolerance."""
    report = evaluate_precision_reduction(mesh.vertices, np.float32, max_relative_error)
    return OptimizationRecord(
        workload=f"{mesh.name}.vertex_precision",
        category="memory",
        baseline_time=0.0,
        optimized_time=0.0,
        gain_fraction=-report.memory_change_fraction,  # negative memory change = positive gain
        memory_change_fraction=report.memory_change_fraction,
        quality_difference=report.max_relative_error,
        accepted=report.within_tolerance,
        reason=(f"float32 downcast: max relative error {report.max_relative_error:.2e} within tolerance"
                if report.within_tolerance else
                f"rejected: max relative error {report.max_relative_error:.2e} exceeds tolerance {max_relative_error}"),
    )


class ObjectPool:
    """
    Generic object pool: reuse pre-allocated objects instead of
    allocating/discarding on every use. Effective for short-lived numpy
    buffers (e.g. per-frame simulation scratch arrays) where repeated
    allocation dominates over the actual computation.
    """

    def __init__(self, factory: Callable[[], Any], reset: Callable[[Any], None] = None, max_size: int = 64):
        self._factory = factory
        self._reset = reset
        self._pool: List[Any] = []
        self.max_size = max_size
        self.reused = 0
        self.created = 0

    def acquire(self) -> Any:
        if self._pool:
            self.reused += 1
            return self._pool.pop()
        self.created += 1
        return self._factory()

    def release(self, obj: Any) -> None:
        if self._reset is not None:
            self._reset(obj)
        if len(self._pool) < self.max_size:
            self._pool.append(obj)

    @property
    def reuse_ratio(self) -> float:
        total = self.reused + self.created
        return self.reused / total if total else 0.0


def measure_pooled_vs_unpooled(factory: Callable[[], Any], iterations: int = 1000) -> OptimizationRecord:
    """Benchmark allocate-every-time vs pool-and-reuse for a given factory."""
    with Profiler("memory.unpooled") as p_unpooled:
        for _ in range(iterations):
            _ = factory()

    pool = ObjectPool(factory)
    with Profiler("memory.pooled") as p_pooled:
        for _ in range(iterations):
            obj = pool.acquire()
            pool.release(obj)

    baseline = p_unpooled.sample.wall_time
    optimized = p_pooled.sample.wall_time
    gain = (baseline - optimized) / baseline if baseline > 0 else 0.0

    return OptimizationRecord(
        workload="object_pool",
        category="memory",
        baseline_time=baseline,
        optimized_time=optimized,
        gain_fraction=gain,
        memory_change_fraction=0.0,
        quality_difference=0.0,
        accepted=gain > 0,
        reason=f"pooling reuse ratio {pool.reuse_ratio:.2%}",
    )
