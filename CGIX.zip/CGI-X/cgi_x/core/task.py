"""A unit of work in a CGI-X task graph."""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional


class TaskStatus(enum.Enum):
    PENDING = "pending"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"


@dataclass
class TaskResult:
    status: TaskStatus
    value: Any = None
    error: Optional[str] = None
    wall_time: float = 0.0


@dataclass
class Task:
    """A single named unit of work with declared dependencies.

    `func` receives the resolved results of every task named in
    `depends_on` as keyword arguments (keyed by dependency name), followed
    by any static kwargs supplied at construction time.
    """

    name: str
    func: Callable
    depends_on: List[str] = field(default_factory=list)
    kwargs: Dict[str, Any] = field(default_factory=dict)
    status: TaskStatus = TaskStatus.PENDING
    result: Optional[TaskResult] = None

    def run(self, dependency_results: Dict[str, Any]) -> TaskResult:
        import time

        self.status = TaskStatus.RUNNING
        start = time.perf_counter()
        try:
            call_kwargs = dict(self.kwargs)
            call_kwargs.update(dependency_results)
            value = self.func(**call_kwargs)
            elapsed = time.perf_counter() - start
            self.status = TaskStatus.DONE
            self.result = TaskResult(status=TaskStatus.DONE, value=value, wall_time=elapsed)
        except Exception as exc:  # noqa: BLE001 - surfaced via TaskResult
            elapsed = time.perf_counter() - start
            self.status = TaskStatus.FAILED
            self.result = TaskResult(status=TaskStatus.FAILED, error=str(exc), wall_time=elapsed)
        return self.result
