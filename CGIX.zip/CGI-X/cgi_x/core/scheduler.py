"""
Core-level scheduler façade. The real implementation lives in
`cgi_x.parallel.scheduler` / `cgi_x.parallel.task_graph`; this module
re-exports it under `cgi_x.core` so pipeline code only needs to import
from `cgi_x.core`.
"""

from __future__ import annotations

from cgi_x.parallel.scheduler import ParallelScheduler, ScheduleReport
from cgi_x.parallel.task_graph import CycleError, TaskGraph

__all__ = ["ParallelScheduler", "ScheduleReport", "TaskGraph", "CycleError"]
