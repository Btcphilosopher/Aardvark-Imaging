"""
Production-chain pipeline representation:

    ASSET IMPORT -> SCENE BUILD -> SIMULATION -> CACHE -> TEXTURE
    -> RENDER PREP -> RENDER -> COMPOSITING -> EXPORT

`Pipeline` is a named, ordered convenience wrapper around a `TaskGraph`
for exactly this kind of linear-with-branches production chain, giving
each stage a human-readable name for reporting and bottleneck analysis.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, List, Optional

from cgi_x.core.task import Task
from cgi_x.parallel.scheduler import ParallelScheduler, ScheduleReport
from cgi_x.parallel.task_graph import TaskGraph

STANDARD_STAGES = [
    "asset_import",
    "scene_build",
    "simulation",
    "cache",
    "texture",
    "render_prep",
    "render",
    "compositing",
    "export",
]


@dataclass
class Pipeline:
    name: str = "production_pipeline"
    graph: TaskGraph = field(default_factory=TaskGraph)

    def add_stage(self, name: str, func: Callable, depends_on: Optional[List[str]] = None, **kwargs) -> "Pipeline":
        self.graph.add(Task(name=name, func=func, depends_on=depends_on or [], kwargs=kwargs))
        return self

    def run(self, max_workers: Optional[int] = None) -> ScheduleReport:
        return ParallelScheduler(max_workers=max_workers).run(self.graph)

    def stage_costs(self, report: ScheduleReport) -> dict:
        """Fraction of total pipeline wall-time attributable to each wave
        (used by the profiling engine's per-task percentage breakdown)."""
        # Wave-level timing isn't tracked per-task by the scheduler by default;
        # callers that need per-task timing should wrap `func` with a Profiler.
        return {"waves": report.waves, "total_wall_time": report.wall_time}
