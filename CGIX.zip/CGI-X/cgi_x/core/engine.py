"""
CGI-X public API surface.

    from cgi_x import Optimizer

    optimizer = Optimizer()
    result = optimizer.optimize(scene=scene, constraints={"max_visual_error": 0.005})
    print(result.performance_gain)
    print(result.memory_saved)

`Optimizer` also exposes `benchmark()`, `profile()`, `compare()`,
`validate()`, `cache()` and `analyse()`, per the spec.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from cgi_x.analytics.marginal_gain import PerformanceReport, build_report
from cgi_x.analytics.performance import CostEngine, MarginalGainEngine
from cgi_x.cache.cache import Cache
from cgi_x.config.settings import QualityConstraints, Settings
from cgi_x.core.state import OptimizationRecord
from cgi_x.optimisation.pipeline_optimizer import PipelineOptimizationResult, optimize_pipeline
from cgi_x.profiling.benchmark import BenchmarkResult, ComparisonResult, benchmark, compare
from cgi_x.profiling.profiler import Profiler, ProfileSample
from cgi_x.profiling.telemetry import TelemetryStore
from cgi_x.rendering.render_analysis import SceneAnalysis, analyze_scene
from cgi_x.rendering.scene import Scene


@dataclass
class OptimizationResult:
    """Result of `Optimizer.optimize()`."""

    scene: Scene
    records: List[OptimizationRecord]
    gain_engine: MarginalGainEngine
    report: PerformanceReport

    @property
    def performance_gain(self) -> float:
        """Aggregate pipeline speed gain, as a fraction (0.05 = 5%)."""
        return self.gain_engine.total_pipeline_gain_fraction

    @property
    def performance_gain_percent(self) -> float:
        return self.gain_engine.total_pipeline_gain_percent

    @property
    def memory_saved(self) -> float:
        """Mean fractional memory change across accepted optimisations
        (negative = memory saved)."""
        accepted = [r for r in self.records if r.accepted]
        if not accepted:
            return 0.0
        return -sum(r.memory_change_fraction for r in accepted) / len(accepted)

    @property
    def accepted(self) -> List[OptimizationRecord]:
        return [r for r in self.records if r.accepted]

    @property
    def rejected(self) -> List[OptimizationRecord]:
        return [r for r in self.records if not r.accepted]

    def summary(self) -> str:
        return self.report.render()


class Engine:
    """Low-level orchestrator: profile -> analyse -> optimise -> benchmark
    -> validate -> accept/reject -> deploy -> measure again. `Optimizer`
    is the friendly façade over this."""

    def __init__(self, settings: Optional[Settings] = None):
        self.settings = settings or Settings()
        self.settings.ensure_dirs()
        self.cache = Cache(max_bytes=self.settings.cache_max_bytes, disk_dir=self.settings.cache_dir)
        self.telemetry = TelemetryStore(self.settings.telemetry_path)
        self.cost_engine = CostEngine()

    def profile_scene(self, scene: Scene) -> ProfileSample:
        with Profiler(f"{scene.name}.profile") as p:
            _ = scene.total_face_count()
            _ = scene.total_vertex_count()
        return p.sample

    def analyse_scene(self, scene: Scene) -> SceneAnalysis:
        return analyze_scene(scene)

    def run_pipeline_optimization(self, scene: Scene, constraints: QualityConstraints) -> PipelineOptimizationResult:
        result = optimize_pipeline(scene, constraints=constraints)
        for record in result.records:
            self.telemetry.record(record)
        return result


class Optimizer:
    """
    The main CGI-X entry point.

        optimizer = Optimizer()
        result = optimizer.optimize(scene=scene, constraints={"max_visual_error": 0.005})
    """

    def __init__(self, settings: Optional[Settings] = None):
        self.engine = Engine(settings)

    # -- primary API -----------------------------------------------------

    def optimize(self, scene: Scene, constraints: Optional[Dict[str, float]] = None,
                  project_name: Optional[str] = None) -> OptimizationResult:
        qc = self._resolve_constraints(constraints)
        pipeline_result = self.engine.run_pipeline_optimization(scene, qc)

        report = build_report(
            project=project_name or scene.name,
            gain_engine=pipeline_result.gain_engine,
            quality_change_percent=self._mean_quality_difference(pipeline_result.records) * 100,
        )

        return OptimizationResult(
            scene=scene,
            records=pipeline_result.records,
            gain_engine=pipeline_result.gain_engine,
            report=report,
        )

    def benchmark(self, func: Callable, *args, repeats: int = None, **kwargs) -> BenchmarkResult:
        return benchmark(func, *args, repeats=repeats or self.engine.settings.benchmark_repeats, **kwargs)

    def profile(self, func: Callable, *args, label: Optional[str] = None, **kwargs) -> ProfileSample:
        from cgi_x.profiling.profiler import profile_call
        _, sample = profile_call(func, *args, label=label, **kwargs)
        return sample

    def compare(self, baseline_func: Callable, optimised_func: Callable, *args, **kwargs) -> ComparisonResult:
        return compare(baseline_func, optimised_func, *args, **kwargs)

    def validate(self, records: List[OptimizationRecord], constraints: Optional[Dict[str, float]] = None) -> bool:
        qc = self._resolve_constraints(constraints)
        return all(
            r.quality_difference <= qc.max_visual_error or r.category != "render"
            for r in records if r.accepted
        )

    def cache(self) -> Cache:
        return self.engine.cache

    def analyse(self, scene: Scene) -> SceneAnalysis:
        return self.engine.analyse_scene(scene)

    # -- internals ---------------------------------------------------------

    def _resolve_constraints(self, constraints: Optional[Dict[str, float]]) -> QualityConstraints:
        base = self.engine.settings.quality
        if not constraints:
            return base
        return QualityConstraints(
            max_visual_error=constraints.get("max_visual_error", base.max_visual_error),
            max_geometric_error=constraints.get("max_geometric_error", base.max_geometric_error),
            max_simulation_error=constraints.get("max_simulation_error", base.max_simulation_error),
            min_speed_gain=constraints.get("min_speed_gain", base.min_speed_gain),
        )

    def _mean_quality_difference(self, records: List[OptimizationRecord]) -> float:
        accepted = [r for r in records if r.accepted]
        if not accepted:
            return 0.0
        return sum(r.quality_difference for r in accepted) / len(accepted)
