"""Core dataclasses shared across the whole CGI-X engine."""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, Optional


@dataclass
class OptimizationRecord:
    """One row of CGI-X's optimisation telemetry / history."""

    optimization_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    workload: str = ""
    category: str = ""                 # geometry / cache / memory / simulation / asset ...
    baseline_time: float = 0.0
    optimized_time: float = 0.0
    gain_fraction: float = 0.0
    memory_change_fraction: float = 0.0
    quality_difference: float = 0.0
    accepted: bool = False
    reason: str = ""
    confidence: Optional[float] = None
    timestamp: float = field(default_factory=time.time)
    extra: Dict[str, Any] = field(default_factory=dict)

    @property
    def gain_percent(self) -> float:
        return self.gain_fraction * 100.0


@dataclass
class QualityReport:
    """Result of comparing an optimised output against a reference."""

    metric: str
    value: float
    within_tolerance: bool
    tolerance: float
    details: Dict[str, Any] = field(default_factory=dict)
