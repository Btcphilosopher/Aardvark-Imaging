import os

import numpy as np
import pytest

from cgi_x.assets.dependency_graph import DependencyGraph, Priority
from cgi_x.assets.loader import AssetLoader
from cgi_x.assets.validation import validate_asset_path, validate_mesh
from cgi_x.geometry.mesh import Mesh
from cgi_x.io.obj import load_obj, save_obj


@pytest.fixture
def obj_file(tmp_path):
    mesh = Mesh.synthetic_sphere(subdivisions=1, name="test_sphere")
    path = str(tmp_path / "sphere.obj")
    save_obj(mesh, path)
    return path, mesh


def test_obj_round_trip(obj_file):
    path, original = obj_file
    loaded = load_obj(path)
    assert loaded.vertex_count == original.vertex_count
    assert loaded.face_count == original.face_count
    assert np.allclose(loaded.vertices, original.vertices, atol=1e-5)


def test_asset_loader_deduplicates_identical_content(obj_file):
    path, _ = obj_file
    loader = AssetLoader()
    handle1 = loader.register(path, load_obj)
    handle2 = loader.register(path, load_obj)
    mesh1 = handle1.get()
    mesh2 = handle2.get()
    assert mesh1.vertex_count == mesh2.vertex_count
    assert loader.cache.dedup_ratio > 0


def test_validate_missing_asset_path_reports_error(tmp_path):
    report = validate_asset_path(str(tmp_path / "does_not_exist.obj"))
    assert not report.is_valid


def test_validate_mesh_flags_out_of_range_face_index():
    vertices = np.zeros((2, 3))
    faces = np.array([[0, 1, 5]], dtype=np.int64)
    mesh = Mesh(vertices=vertices, faces=faces)
    report = validate_mesh(mesh)
    assert not report.is_valid


def test_validate_mesh_flags_nan_vertices():
    vertices = np.array([[0.0, 0.0, float("nan")], [1, 0, 0], [0, 1, 0]])
    faces = np.array([[0, 1, 2]], dtype=np.int64)
    mesh = Mesh(vertices=vertices, faces=faces)
    report = validate_mesh(mesh)
    assert not report.is_valid


def test_dependency_graph_load_order_respects_priority_and_deps():
    graph = DependencyGraph()
    graph.add_asset("core_rig", priority=Priority.CORE)
    graph.add_asset("hero_texture", priority=Priority.VISIBLE, depends_on=["core_rig"])
    graph.add_asset("background_prop", priority=Priority.BACKGROUND)

    order = graph.load_order()
    assert order.index("core_rig") < order.index("hero_texture")
    assert "background_prop" in graph.deferrable_assets(up_to=Priority.VISIBLE)


def test_dependency_graph_shared_assets():
    graph = DependencyGraph()
    graph.register_reference("shared_texture", "object_a")
    graph.register_reference("shared_texture", "object_b")
    graph.register_reference("unique_texture", "object_c")
    assert "shared_texture" in graph.shared_assets()
    assert "unique_texture" not in graph.shared_assets()
