import numpy as np
import pytest

from cgi_x import Optimizer
from cgi_x.config.settings import Settings
from cgi_x.geometry.mesh import Mesh
from cgi_x.integrations.generic import GenericAdapter
from cgi_x.rendering.materials import Material
from cgi_x.rendering.scene import Scene, SceneObject


def build_small_scene() -> Scene:
    scene = Scene(name="integration_test_scene")
    for i in range(3):
        mesh = Mesh.synthetic_sphere(subdivisions=2, name=f"obj_{i}")
        transform = np.eye(4)
        transform[:3, 3] = [i, 0, 0] if i != 2 else [0, 0, 0]  # obj_0 and obj_2 share a transform
        material = Material(name=f"mat_{i}", texture_count=2)
        obj = SceneObject(name=f"obj_{i}", mesh=mesh, transform=transform, material=material,
                           visible=(i != 1))
        if i == 0:
            obj.subdivision_level = 6
        scene.add_object(obj)
    return scene


@pytest.fixture(scope="module")
def optimizer(tmp_path_factory):
    settings = Settings()
    settings.cache_dir = str(tmp_path_factory.mktemp("cgi_x_cache"))
    settings.telemetry_path = str(tmp_path_factory.mktemp("telemetry") / "telemetry.jsonl")
    return Optimizer(settings)


def test_optimize_returns_a_result_with_records(optimizer):
    scene = build_small_scene()
    result = optimizer.optimize(scene, constraints={"max_visual_error": 0.05, "max_geometric_error": 0.05})
    assert len(result.records) > 0
    assert isinstance(result.performance_gain, float)


def test_optimize_never_exceeds_declared_quality_tolerance(optimizer):
    scene = build_small_scene()
    tolerance = 0.01
    result = optimizer.optimize(scene, constraints={"max_geometric_error": tolerance})
    geometry_records = [r for r in result.accepted if r.category == "geometry" and "simplify" in r.workload]
    for r in geometry_records:
        assert r.quality_difference <= tolerance


def test_optimize_report_renders_without_error(optimizer):
    scene = build_small_scene()
    result = optimizer.optimize(scene, project_name="TEST_PROJECT")
    report_text = result.summary()
    assert "CGI-X PERFORMANCE REPORT" in report_text
    assert "TEST_PROJECT" in report_text


def test_generic_adapter_pull_push_round_trip(optimizer):
    scene = build_small_scene()
    adapter = GenericAdapter(scene)
    assert adapter.is_available()
    result = adapter.optimize_in_place(optimizer, constraints={"max_geometric_error": 0.05})
    assert adapter.pull_scene() is result.scene


def test_analyse_flags_hidden_and_over_subdivided_objects(optimizer):
    scene = build_small_scene()
    analysis = optimizer.analyse(scene)
    assert analysis.hidden_object_count == 1
    assert len(analysis.subdivision_recommendations) == 1
    assert analysis.subdivision_recommendations[0].object_name == "obj_0"


def test_validate_accepts_records_within_tolerance(optimizer):
    scene = build_small_scene()
    result = optimizer.optimize(scene, constraints={"max_visual_error": 0.5, "max_geometric_error": 0.5})
    assert optimizer.validate(result.records, constraints={"max_visual_error": 0.5})
