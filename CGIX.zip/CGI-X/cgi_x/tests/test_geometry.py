import numpy as np
import pytest

from cgi_x.geometry.mesh import Mesh
from cgi_x.geometry.normals import (
    compute_face_normals_naive,
    compute_face_normals_vectorized,
    compute_vertex_normals_vectorized,
    max_normal_deviation,
)
from cgi_x.geometry.simplification import simplify_by_clustering
from cgi_x.geometry.subdivision import subdivide_midpoint
from cgi_x.geometry.topology import (
    edge_list,
    find_unreferenced_vertices,
    remove_unreferenced_vertices,
    weld_duplicate_vertices,
)
from cgi_x.geometry.transforms import apply_transform, batch_apply_transforms, compose, rotation_matrix_axis_angle, \
    scale_matrix, translation_matrix


def make_triangle_mesh():
    vertices = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0]], dtype=np.float64)
    faces = np.array([[0, 1, 2]], dtype=np.int64)
    return Mesh(vertices=vertices, faces=faces)


def test_mesh_basic_properties():
    mesh = make_triangle_mesh()
    assert mesh.vertex_count == 3
    assert mesh.face_count == 1
    assert mesh.memory_bytes() > 0


def test_normals_naive_vs_vectorized_agree():
    mesh = Mesh.synthetic_sphere(subdivisions=2)
    naive = compute_face_normals_naive(mesh)
    fast = compute_face_normals_vectorized(mesh)
    assert naive.shape == fast.shape
    # Naive (pure-Python, float-by-float) and vectorised (NumPy, SIMD-batched)
    # summation orders differ at the ULP level; both are numerically correct,
    # so the tolerance reflects floating-point equivalence, not divergence.
    assert max_normal_deviation(naive, fast) < 1e-6


def test_vertex_normals_are_unit_length():
    mesh = Mesh.synthetic_sphere(subdivisions=2)
    normals = compute_vertex_normals_vectorized(mesh)
    lengths = np.linalg.norm(normals, axis=1)
    assert np.allclose(lengths, 1.0, atol=1e-6)


def test_weld_duplicate_vertices_reduces_count():
    vertices = np.array([[0, 0, 0], [0, 0, 0], [1, 0, 0], [0, 1, 0]], dtype=np.float64)
    faces = np.array([[0, 2, 3], [1, 2, 3]], dtype=np.int64)
    mesh = Mesh(vertices=vertices, faces=faces)
    welded = weld_duplicate_vertices(mesh)
    assert welded.vertex_count == 3


def test_unreferenced_vertex_removal():
    vertices = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0], [5, 5, 5]], dtype=np.float64)
    faces = np.array([[0, 1, 2]], dtype=np.int64)
    mesh = Mesh(vertices=vertices, faces=faces)
    assert len(find_unreferenced_vertices(mesh)) == 1
    cleaned = remove_unreferenced_vertices(mesh)
    assert cleaned.vertex_count == 3
    assert cleaned.faces.max() < cleaned.vertex_count


def test_edge_list_is_unique_and_undirected():
    mesh = make_triangle_mesh()
    edges = edge_list(mesh)
    assert edges.shape == (3, 2)
    assert np.all(edges[:, 0] < edges[:, 1])


def test_simplification_reduces_faces_within_tolerance():
    mesh = Mesh.synthetic_sphere(subdivisions=4)
    result = simplify_by_clustering(mesh, grid_resolution=16)
    assert result.mesh.face_count < mesh.face_count
    assert result.reduction_fraction > 0
    assert result.geometric_error < 0.2  # coarse grid but still bounded


def test_subdivision_increases_face_count_by_four():
    mesh = make_triangle_mesh()
    subdivided = subdivide_midpoint(mesh, levels=1)
    assert subdivided.face_count == mesh.face_count * 4


def test_transform_round_trip():
    vertices = np.array([[1.0, 0.0, 0.0]])
    m = compose(translation_matrix([1, 0, 0]), rotation_matrix_axis_angle([0, 1, 0], np.pi / 2), scale_matrix(1.0))
    transformed = apply_transform(vertices, m)
    assert transformed.shape == (1, 3)


def test_batch_apply_transforms_shape():
    vertices = np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]])
    matrices = np.stack([np.eye(4), translation_matrix([1, 1, 1])])
    out = batch_apply_transforms(vertices, matrices)
    assert out.shape == (2, 2, 3)
    assert np.allclose(out[0], vertices)
    assert np.allclose(out[1], vertices + 1)


def test_mesh_rejects_bad_shapes():
    with pytest.raises(ValueError):
        Mesh(vertices=np.zeros((3, 2)), faces=np.zeros((1, 3), dtype=np.int64))
