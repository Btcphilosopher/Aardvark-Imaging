import numpy as np

from cgi_x.analytics.quality import compare_images, geometric_error_fraction, mse, psnr, ssim


def test_mse_zero_for_identical_images():
    img = np.random.default_rng(0).random((32, 32, 3)).astype(np.float32)
    assert mse(img, img) == 0.0


def test_psnr_is_infinite_for_identical_images():
    img = np.random.default_rng(0).random((32, 32, 3)).astype(np.float32)
    assert psnr(img, img) == float("inf")


def test_psnr_decreases_with_more_noise():
    rng = np.random.default_rng(0)
    img = rng.random((32, 32, 3)).astype(np.float32)
    small_noise = img + rng.normal(0, 0.01, img.shape).astype(np.float32)
    big_noise = img + rng.normal(0, 0.2, img.shape).astype(np.float32)
    assert psnr(img, small_noise) > psnr(img, big_noise)


def test_ssim_is_one_for_identical_images():
    img = np.random.default_rng(0).random((64, 64)).astype(np.float64)
    assert ssim(img, img) > 0.999


def test_ssim_decreases_with_structural_change():
    rng = np.random.default_rng(0)
    img = rng.random((64, 64))
    scrambled = rng.permutation(img.flatten()).reshape(img.shape)
    assert ssim(img, img) > ssim(img, scrambled)


def test_compare_images_within_tolerance():
    img = np.random.default_rng(1).random((32, 32, 3)).astype(np.float32)
    slightly_off = img.copy()
    slightly_off[0, 0, 0] += 0.001
    report = compare_images(img, slightly_off)
    assert report.within_tolerance(max_error=0.05)


def test_geometric_error_zero_for_identical_point_sets():
    points = np.random.default_rng(0).random((50, 3))
    assert geometric_error_fraction(points, points, bbox_diagonal=1.0) == 0.0


def test_geometric_error_increases_with_displacement():
    rng = np.random.default_rng(0)
    points = rng.random((50, 3))
    displaced = points + 0.05
    small_error = geometric_error_fraction(points, displaced, bbox_diagonal=1.0)
    far_displaced = points + 0.5
    large_error = geometric_error_fraction(points, far_displaced, bbox_diagonal=1.0)
    assert small_error < large_error
