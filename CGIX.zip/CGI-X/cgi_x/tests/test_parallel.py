import pytest

from cgi_x.core.task import Task, TaskStatus
from cgi_x.parallel.scheduler import ParallelScheduler
from cgi_x.parallel.task_graph import CycleError, TaskGraph
from cgi_x.parallel.workers import WorkerPool


def test_task_graph_execution_waves_respect_dependencies():
    graph = TaskGraph()
    graph.add(Task("a", lambda: 1))
    graph.add(Task("b", lambda: 2, depends_on=["a"]))
    graph.add(Task("c", lambda: 3, depends_on=["a"]))
    graph.add(Task("d", lambda: 4, depends_on=["b", "c"]))

    waves = graph.execution_waves()
    assert waves[0] == ["a"]
    assert set(waves[1]) == {"b", "c"}
    assert waves[2] == ["d"]


def test_task_graph_detects_cycles():
    graph = TaskGraph()
    graph.add(Task("a", lambda: 1, depends_on=["b"]))
    graph.add(Task("b", lambda: 2, depends_on=["a"]))
    with pytest.raises(CycleError):
        graph.execution_waves()


def test_task_graph_rejects_unknown_dependency():
    graph = TaskGraph()
    graph.add(Task("a", lambda: 1, depends_on=["nonexistent"]))
    with pytest.raises(ValueError):
        graph.execution_waves()


def test_parallel_scheduler_runs_and_resolves_results():
    graph = TaskGraph()
    graph.add(Task("a", lambda: 5))
    graph.add(Task("b", lambda a: a * 2, depends_on=["a"]))
    graph.add(Task("c", lambda b: b + 1, depends_on=["b"]))

    report = ParallelScheduler(max_workers=2).run(graph)
    assert report.results["a"] == 5
    assert report.results["b"] == 10
    assert report.results["c"] == 11
    assert not report.failed


def test_parallel_scheduler_records_failures_without_crashing():
    graph = TaskGraph()

    def boom():
        raise ValueError("intentional failure")

    graph.add(Task("a", boom))
    report = ParallelScheduler().run(graph)
    assert "a" in report.failed


def test_worker_pool_thread_map():
    with WorkerPool(max_workers=4, kind="thread") as pool:
        results = pool.map(lambda x: x * x, range(10))
    assert results == [x * x for x in range(10)]
