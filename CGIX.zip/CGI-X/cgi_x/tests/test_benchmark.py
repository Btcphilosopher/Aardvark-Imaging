import time

from cgi_x.analytics.performance import MarginalGainEngine
from cgi_x.profiling.benchmark import ComparisonResult, benchmark, compare


def fast_fn():
    return sum(range(1000))


def slow_fn():
    time.sleep(0.01)
    return sum(range(1000))


def test_benchmark_returns_requested_number_of_samples():
    result = benchmark(fast_fn, repeats=7, warmup=1)
    assert len(result.samples) == 7
    assert result.mean_wall_time >= 0


def test_benchmark_is_reproducible_in_shape_across_runs():
    result1 = benchmark(fast_fn, repeats=5, warmup=1)
    result2 = benchmark(fast_fn, repeats=5, warmup=1)
    # Not asserting identical timings (that's not reproducible in wall-clock
    # terms) — asserting the *statistics machinery* is stable and sane.
    assert len(result1.samples) == len(result2.samples) == 5
    assert result1.min_wall_time <= result1.mean_wall_time


def test_compare_detects_real_speed_difference():
    comparison = compare(slow_fn, fast_fn, repeats=3, warmup=1, label="fast_vs_slow")
    assert isinstance(comparison, ComparisonResult)
    assert comparison.speed_gain_fraction > 0
    assert comparison.is_statistically_faster()


def test_marginal_gain_engine_aggregates_correctly_not_additively():
    engine = MarginalGainEngine()
    # category A: 100s -> 90s (10% gain), category B: 10s -> 9.5s (5% gain)
    engine.record_raw("geometry", baseline_time=100.0, optimized_time=90.0)
    engine.record_raw("cache", baseline_time=10.0, optimized_time=9.5)

    # naive (WRONG) additive sum would be 15%; correct aggregate uses totals.
    naive_wrong_sum = 10.0 + 5.0
    correct = engine.total_pipeline_gain_percent

    assert abs(correct - ((110 - 99.5) / 110 * 100)) < 1e-9
    assert correct != naive_wrong_sum


def test_marginal_gain_engine_handles_no_categories():
    engine = MarginalGainEngine()
    assert engine.total_pipeline_gain_fraction == 0.0
