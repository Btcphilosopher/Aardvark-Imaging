import numpy as np

from cgi_x.numerical.integration import (
    adaptive_quad_integrate,
    select_integration_method,
    simpson_integrate,
    trapezoid_integrate,
)
from cgi_x.numerical.interpolation import cubic_interpolate, linear_interpolate, select_interpolation_method
from cgi_x.numerical.linear_algebra import auto_solve, batched_matmul, solve_dense, sparsity
from cgi_x.numerical.precision import downcast_if_safe, evaluate_precision_reduction


def test_integration_methods_agree_on_smooth_function():
    f = lambda x: np.sin(x)
    ref = adaptive_quad_integrate(f, 0, np.pi)
    assert abs(trapezoid_integrate(f, 0, np.pi, n=2000) - ref) < 1e-3
    assert abs(simpson_integrate(f, 0, np.pi, n=2001) - ref) < 1e-5


def test_select_integration_method_meets_tolerance():
    f = lambda x: x ** 2
    choice = select_integration_method(f, 0, 1, reference=1 / 3, max_error=1e-3)
    assert choice.error_vs_reference <= 1e-3 or choice.method == "adaptive_quad"


def test_interpolation_linear_vs_cubic():
    x = np.linspace(0, 10, 20)
    y = np.sin(x)
    x_new = np.linspace(0, 10, 100)
    lin = linear_interpolate(x, y, x_new)
    cub = cubic_interpolate(x, y, x_new)
    assert lin.shape == cub.shape == x_new.shape


def test_select_interpolation_method_picks_valid_choice():
    x = np.linspace(0, 10, 30)
    y = np.sin(x)
    x_new = np.linspace(0, 10, 200)
    reference = np.sin(x_new)
    choice = select_interpolation_method(x, y, x_new, reference_y=reference, min_accuracy=0.9)
    assert choice.method in ("linear", "cubic")
    assert choice.accuracy >= 0.9


def test_solve_dense_matches_numpy():
    A = np.array([[3.0, 1.0], [1.0, 2.0]])
    b = np.array([9.0, 8.0])
    x = solve_dense(A, b)
    assert np.allclose(A @ x, b)


def test_auto_solve_handles_sparse_and_dense():
    A = np.eye(100) * 4.0
    b = np.ones(100)
    x = auto_solve(A, b)
    assert np.allclose(A @ x, b, atol=1e-6)
    assert sparsity(A) > 0.9


def test_batched_matmul():
    matrices = np.stack([np.eye(3) * 2, np.eye(3) * 3])
    vectors = np.array([[1.0, 1.0, 1.0], [2.0, 2.0, 2.0]])
    result = batched_matmul(matrices, vectors)
    assert np.allclose(result, [[2, 2, 2], [6, 6, 6]])


def test_precision_downcast_accepted_when_within_tolerance():
    array = np.random.default_rng(0).random(1000) * 10
    report = evaluate_precision_reduction(array, np.float32, max_relative_error=1e-2)
    assert report.within_tolerance
    assert report.memory_change_fraction < 0


def test_downcast_if_safe_rejects_when_too_lossy():
    # Extremely tight tolerance should force rejection even for float32.
    array = np.random.default_rng(0).random(1000) * 1e10
    result, report = downcast_if_safe(array, np.float32, max_relative_error=1e-12)
    assert result.dtype == array.dtype  # rejected, original returned
    assert not report.within_tolerance
