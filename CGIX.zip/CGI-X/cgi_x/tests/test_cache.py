import numpy as np
import pytest

from cgi_x.cache.cache import Cache, make_cache_key
from cgi_x.cache.scene_cache import SceneCache
from cgi_x.cache.simulation_cache import SimulationCache


def test_cache_key_changes_with_input():
    k1 = make_cache_key(np.array([1, 2, 3]), {"p": 1}, version="1", dependencies=["a"])
    k2 = make_cache_key(np.array([1, 2, 4]), {"p": 1}, version="1", dependencies=["a"])
    assert k1 != k2


def test_cache_key_changes_with_parameters():
    k1 = make_cache_key("input", {"p": 1})
    k2 = make_cache_key("input", {"p": 2})
    assert k1 != k2


def test_cache_key_changes_with_version():
    k1 = make_cache_key("input", {}, version="1")
    k2 = make_cache_key("input", {}, version="2")
    assert k1 != k2


def test_cache_key_changes_with_dependencies():
    k1 = make_cache_key("input", {}, dependencies=["dep_a"])
    k2 = make_cache_key("input", {}, dependencies=["dep_b"])
    assert k1 != k2


def test_cache_get_or_compute_hits_second_time():
    cache = Cache()
    calls = {"n": 0}

    def compute():
        calls["n"] += 1
        return 42

    key = make_cache_key("x")
    assert cache.get_or_compute(key, compute) == 42
    assert cache.get_or_compute(key, compute) == 42
    assert calls["n"] == 1
    assert cache.stats.hits == 1
    assert cache.stats.misses == 1


def test_cache_never_returns_stale_result_for_changed_key():
    cache = Cache()
    key1 = make_cache_key("v1", version="1")
    key2 = make_cache_key("v1", version="2")
    cache.set(key1, "old_value")
    assert cache.get(key2) is None  # different version must not see the old entry


def test_cache_eviction_respects_byte_budget():
    cache = Cache(max_bytes=1024)
    for i in range(200):
        cache.set(str(i), np.zeros(64, dtype=np.float64), persist=False)
    assert cache.stats.evictions > 0


def test_scene_cache_reuses_evaluation():
    scene_cache = SceneCache()
    calls = {"n": 0}

    def evaluate():
        calls["n"] += 1
        return "result"

    scene_cache.evaluate(("fingerprint",), evaluate)
    scene_cache.evaluate(("fingerprint",), evaluate)
    assert calls["n"] == 1


def test_simulation_cache_checkpoint_roundtrip():
    sim_cache = SimulationCache()
    sim_cache.save_checkpoint("sim1", frame=10, state={"t": 10}, parameters={"dt": 0.01})
    loaded = sim_cache.load_checkpoint("sim1", frame=10, parameters={"dt": 0.01})
    assert loaded == {"t": 10}


def test_simulation_cache_nearest_checkpoint():
    sim_cache = SimulationCache()
    sim_cache.save_checkpoint("sim1", frame=10, state="A", parameters={})
    sim_cache.save_checkpoint("sim1", frame=20, state="B", parameters={})
    frame, state = sim_cache.nearest_checkpoint("sim1", target_frame=15, parameters={}, available_frames=[10, 20])
    assert frame == 10
    assert state == "A"
