import numpy as np

from cgi_x.geometry.mesh import Mesh
from cgi_x.optimisation.memory_optimizer import ObjectPool, measure_pooled_vs_unpooled, optimize_mesh_precision
from cgi_x.profiling.memory import MemoryProfiler, current_memory_bytes
from cgi_x.profiling.profiler import Profiler


def test_profiler_reports_positive_wall_time():
    with Profiler("sleep_like_work") as p:
        total = sum(i * i for i in range(200_000))
    assert p.sample.wall_time > 0
    assert total > 0


def test_object_pool_reuses_objects():
    pool = ObjectPool(factory=lambda: [0] * 100)
    obj1 = pool.acquire()
    pool.release(obj1)
    obj2 = pool.acquire()
    assert obj1 is obj2
    assert pool.reuse_ratio > 0


def test_measure_pooled_vs_unpooled_returns_a_record():
    record = measure_pooled_vs_unpooled(lambda: [0] * 1000, iterations=200)
    assert record.category == "memory"
    assert record.baseline_time >= 0
    assert record.optimized_time >= 0


def test_mesh_precision_downcast_accept_or_reject_is_consistent():
    mesh = Mesh.synthetic_sphere(subdivisions=2)
    record = optimize_mesh_precision(mesh, max_relative_error=1e-2)
    assert record.category == "memory"
    if record.accepted:
        assert record.memory_change_fraction < 0


def test_memory_profiler_context_manager():
    with MemoryProfiler() as prof:
        _ = np.zeros((1000, 1000))
    assert isinstance(prof.deltas, list)


def test_current_memory_bytes_nonnegative_when_not_tracing():
    assert current_memory_bytes() >= 0
