"""
Core mesh representation: NumPy-backed vertex/face buffers.

All CGI-X geometry operations work on contiguous NumPy arrays rather than
Python lists of tuples — this is the single biggest, most reliable
computational win available for mesh processing in Python, and every
other geometry optimisation in this package builds on it.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np


@dataclass
class Mesh:
    """A triangle (or polygon, pre-triangulated) mesh.

    vertices: (N, 3) float64 array of positions
    faces:    (M, 3) int64 array of vertex indices (triangles)
    normals:  optional (N, 3) float64 array of vertex normals
    uvs:      optional (N, 2) float64 array of texture coordinates
    """

    vertices: np.ndarray
    faces: np.ndarray
    normals: Optional[np.ndarray] = None
    uvs: Optional[np.ndarray] = None
    name: str = "mesh"

    def __post_init__(self):
        self.vertices = np.asarray(self.vertices, dtype=np.float64)
        self.faces = np.asarray(self.faces, dtype=np.int64)
        if self.vertices.ndim != 2 or self.vertices.shape[1] != 3:
            raise ValueError("vertices must be an (N, 3) array")
        if self.faces.ndim != 2 or self.faces.shape[1] != 3:
            raise ValueError("faces must be an (M, 3) triangle index array")

    @property
    def vertex_count(self) -> int:
        return int(self.vertices.shape[0])

    @property
    def face_count(self) -> int:
        return int(self.faces.shape[0])

    @property
    def bounding_box(self):
        return self.vertices.min(axis=0), self.vertices.max(axis=0)

    @property
    def bounding_diagonal(self) -> float:
        lo, hi = self.bounding_box
        return float(np.linalg.norm(hi - lo))

    def copy(self) -> "Mesh":
        return Mesh(
            vertices=self.vertices.copy(),
            faces=self.faces.copy(),
            normals=None if self.normals is None else self.normals.copy(),
            uvs=None if self.uvs is None else self.uvs.copy(),
            name=self.name,
        )

    def memory_bytes(self) -> int:
        total = self.vertices.nbytes + self.faces.nbytes
        if self.normals is not None:
            total += self.normals.nbytes
        if self.uvs is not None:
            total += self.uvs.nbytes
        return int(total)

    @staticmethod
    def synthetic_sphere(subdivisions: int = 3, radius: float = 1.0, name: str = "sphere") -> "Mesh":
        """Generate a synthetic UV-sphere for tests, benchmarks and demos."""
        rings = max(3, subdivisions * 4)
        segments = max(3, subdivisions * 8)

        verts = [np.array([0.0, radius, 0.0])]
        for i in range(1, rings):
            phi = np.pi * i / rings
            y = np.cos(phi) * radius
            r = np.sin(phi) * radius
            for j in range(segments):
                theta = 2 * np.pi * j / segments
                verts.append(np.array([r * np.cos(theta), y, r * np.sin(theta)]))
        verts.append(np.array([0.0, -radius, 0.0]))
        vertices = np.array(verts, dtype=np.float64)

        faces = []
        top = 0
        bottom = len(vertices) - 1
        first_ring = 1

        for j in range(segments):
            a = first_ring + j
            b = first_ring + (j + 1) % segments
            faces.append([top, b, a])

        for i in range(rings - 2):
            ring0 = first_ring + i * segments
            ring1 = first_ring + (i + 1) * segments
            for j in range(segments):
                a = ring0 + j
                b = ring0 + (j + 1) % segments
                c = ring1 + j
                d = ring1 + (j + 1) % segments
                faces.append([a, b, d])
                faces.append([a, d, c])

        last_ring = first_ring + (rings - 2) * segments
        for j in range(segments):
            a = last_ring + j
            b = last_ring + (j + 1) % segments
            faces.append([bottom, a, b])

        return Mesh(vertices=vertices, faces=np.array(faces, dtype=np.int64), name=name)
