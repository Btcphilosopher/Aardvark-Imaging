"""Affine transforms as 4x4 matrices, applied via vectorised batch matmul."""

from __future__ import annotations

import numpy as np


def translation_matrix(t) -> np.ndarray:
    m = np.eye(4)
    m[:3, 3] = t
    return m


def scale_matrix(s) -> np.ndarray:
    m = np.eye(4)
    if np.isscalar(s):
        s = (s, s, s)
    m[0, 0], m[1, 1], m[2, 2] = s
    return m


def rotation_matrix_axis_angle(axis, angle_rad: float) -> np.ndarray:
    axis = np.asarray(axis, dtype=np.float64)
    axis = axis / (np.linalg.norm(axis) + 1e-15)
    x, y, z = axis
    c, s = np.cos(angle_rad), np.sin(angle_rad)
    C = 1 - c
    r = np.array([
        [x * x * C + c,     x * y * C - z * s, x * z * C + y * s, 0],
        [y * x * C + z * s, y * y * C + c,     y * z * C - x * s, 0],
        [z * x * C - y * s, z * y * C + x * s, z * z * C + c,     0],
        [0, 0, 0, 1],
    ])
    return r


def compose(*matrices: np.ndarray) -> np.ndarray:
    """Compose transforms left-to-right in application order (first applied
    innermost), i.e. compose(T, R, S) applies S then R then T."""
    result = np.eye(4)
    for m in reversed(matrices):
        result = result @ m
    return result


def apply_transform(vertices: np.ndarray, matrix: np.ndarray) -> np.ndarray:
    """Vectorised homogeneous transform of an (N, 3) vertex array."""
    homogeneous = np.hstack([vertices, np.ones((vertices.shape[0], 1))])
    transformed = homogeneous @ matrix.T
    return transformed[:, :3]


def batch_apply_transforms(vertices: np.ndarray, matrices: np.ndarray) -> np.ndarray:
    """Apply a different 4x4 transform to each instance of a base mesh in
    one vectorised call — used for instancing/batching optimisation.

    vertices: (N, 3), matrices: (K, 4, 4) -> returns (K, N, 3)
    """
    homogeneous = np.hstack([vertices, np.ones((vertices.shape[0], 1))])  # (N, 4)
    # (K, 4, 4) @ (4, N) -> (K, 4, N) -> transpose to (K, N, 4)
    out = np.einsum("kij,nj->kni", matrices, homogeneous)
    return out[:, :, :3]


def redundant_transform_pairs(matrices: dict, decimals: int = 6) -> list:
    """Identify objects sharing an identical transform (common in scenes
    with copy-pasted objects) — a candidate for instancing."""
    seen: dict = {}
    duplicates = []
    for name, m in matrices.items():
        key = tuple(np.round(m, decimals=decimals).flatten())
        if key in seen:
            duplicates.append((seen[key], name))
        else:
            seen[key] = name
    return duplicates
