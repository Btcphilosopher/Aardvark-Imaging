"""
Simplified subdivision surface (midpoint/loop-style triangle subdivision)
used both to *increase* detail for testing simplification round-trips and
to model the cost of the "reduce subdivision level" scene recommendation
described in the render-analysis module.
"""

from __future__ import annotations

import numpy as np

from cgi_x.geometry.mesh import Mesh
from cgi_x.geometry.topology import weld_duplicate_vertices


def subdivide_midpoint(mesh: Mesh, levels: int = 1) -> Mesh:
    """Loop-style midpoint subdivision: each triangle becomes 4. Vectorised
    per level; vertices are welded afterwards so shared edges don't crack."""
    current = mesh
    for _ in range(levels):
        verts = current.vertices
        tris = current.faces

        a, b, c = tris[:, 0], tris[:, 1], tris[:, 2]
        mid_ab = (verts[a] + verts[b]) / 2.0
        mid_bc = (verts[b] + verts[c]) / 2.0
        mid_ca = (verts[c] + verts[a]) / 2.0

        n = verts.shape[0]
        m = tris.shape[0]
        new_verts = np.vstack([verts, mid_ab, mid_bc, mid_ca])

        idx_ab = n + np.arange(m)
        idx_bc = n + m + np.arange(m)
        idx_ca = n + 2 * m + np.arange(m)

        new_faces = np.vstack([
            np.stack([a, idx_ab, idx_ca], axis=1),
            np.stack([idx_ab, b, idx_bc], axis=1),
            np.stack([idx_ca, idx_bc, c], axis=1),
            np.stack([idx_ab, idx_bc, idx_ca], axis=1),
        ])

        current = Mesh(vertices=new_verts, faces=new_faces, name=current.name)
        current = weld_duplicate_vertices(current, decimals=8)

    return current


def estimate_subdivision_cost(face_count: int, levels: int) -> int:
    """Each level roughly quadruples the triangle count."""
    return face_count * (4 ** levels)
