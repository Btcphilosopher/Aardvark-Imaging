"""
Mesh simplification for LOD generation.

Implements grid-based vertex clustering: a fast, robust, fully vectorised
simplification method well suited to automatic marginal-gain optimisation
(as opposed to full quadric-error edge collapse, which is higher quality
but much slower to compute and harder to bound deterministically). CGI-X
measures the resulting geometric error directly rather than assuming the
target reduction is safe.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from cgi_x.geometry.mesh import Mesh
from cgi_x.geometry.topology import remove_unreferenced_vertices


@dataclass
class SimplificationResult:
    mesh: Mesh
    original_vertex_count: int
    original_face_count: int
    reduction_fraction: float          # face-count reduction, 0..1
    geometric_error: float             # RMS vertex displacement / bbox diagonal


def simplify_by_clustering(mesh: Mesh, grid_resolution: int = 64) -> SimplificationResult:
    """
    Snap every vertex to the nearest cell of a `grid_resolution`^3 voxel
    grid spanning the mesh's bounding box, then weld and drop degenerate
    faces. Lower `grid_resolution` -> more aggressive simplification.
    """
    lo, hi = mesh.bounding_box
    extent = np.maximum(hi - lo, 1e-9)
    cell_size = extent / grid_resolution

    cell_indices = np.floor((mesh.vertices - lo) / cell_size).astype(np.int64)
    cell_indices = np.clip(cell_indices, 0, grid_resolution - 1)

    # Representative position per occupied cell = mean of vertices in it (vectorised).
    flat_keys = (
        cell_indices[:, 0] * grid_resolution * grid_resolution
        + cell_indices[:, 1] * grid_resolution
        + cell_indices[:, 2]
    )
    unique_keys, inverse, counts = np.unique(flat_keys, return_inverse=True, return_counts=True)

    cluster_sum = np.zeros((len(unique_keys), 3), dtype=np.float64)
    np.add.at(cluster_sum, inverse, mesh.vertices)
    cluster_mean = cluster_sum / counts[:, None]

    new_vertices = cluster_mean
    new_faces = inverse[mesh.faces]

    # Drop degenerate faces (all three corners collapsed to the same cluster).
    degenerate = (
        (new_faces[:, 0] == new_faces[:, 1])
        | (new_faces[:, 1] == new_faces[:, 2])
        | (new_faces[:, 0] == new_faces[:, 2])
    )
    new_faces = new_faces[~degenerate]

    simplified = Mesh(vertices=new_vertices, faces=new_faces, name=mesh.name)
    simplified = remove_unreferenced_vertices(simplified)

    error = _geometric_error(mesh, simplified)
    reduction = 1.0 - (simplified.face_count / max(1, mesh.face_count))

    return SimplificationResult(
        mesh=simplified,
        original_vertex_count=mesh.vertex_count,
        original_face_count=mesh.face_count,
        reduction_fraction=reduction,
        geometric_error=error,
    )


def _geometric_error(original: Mesh, simplified: Mesh) -> float:
    """
    Approximate geometric error as the RMS nearest-neighbour distance from
    a sample of original vertices to the simplified mesh's vertices,
    normalised by the bounding-box diagonal so it is a scale-independent
    fraction (matches the tolerance convention used by QualityConstraints).
    """
    from scipy.spatial import cKDTree

    diag = original.bounding_diagonal
    if diag <= 0:
        return 0.0

    tree = cKDTree(simplified.vertices)
    sample = original.vertices
    if len(sample) > 5000:
        idx = np.random.default_rng(0).choice(len(sample), 5000, replace=False)
        sample = sample[idx]

    distances, _ = tree.query(sample)
    rms = np.sqrt(np.mean(distances ** 2))
    return float(rms / diag)


def generate_lod_chain(mesh: Mesh, levels=(64, 32, 16, 8)) -> list:
    """Generate a chain of progressively coarser LODs from finest to coarsest."""
    return [simplify_by_clustering(mesh, grid_resolution=r) for r in levels]
