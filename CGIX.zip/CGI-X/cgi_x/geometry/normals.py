"""
Normal computation — naive (pure-Python, one triangle at a time) vs
vectorised (NumPy, whole mesh at once). CGI-X ships both so the gain can
be measured honestly rather than assumed, and the marginal-gain engine
reports the real speedup.
"""

from __future__ import annotations

import numpy as np

from cgi_x.geometry.mesh import Mesh


def compute_face_normals_naive(mesh: Mesh) -> np.ndarray:
    """Pure-Python per-triangle loop — the baseline most hand-written
    pipeline glue code actually looks like."""
    normals = []
    verts = mesh.vertices
    for tri in mesh.faces:
        a, b, c = verts[tri[0]], verts[tri[1]], verts[tri[2]]
        e1 = [b[0] - a[0], b[1] - a[1], b[2] - a[2]]
        e2 = [c[0] - a[0], c[1] - a[1], c[2] - a[2]]
        nx = e1[1] * e2[2] - e1[2] * e2[1]
        ny = e1[2] * e2[0] - e1[0] * e2[2]
        nz = e1[0] * e2[1] - e1[1] * e2[0]
        length = (nx * nx + ny * ny + nz * nz) ** 0.5
        if length > 1e-12:
            nx, ny, nz = nx / length, ny / length, nz / length
        normals.append((nx, ny, nz))
    return np.array(normals, dtype=np.float64)


def compute_face_normals_vectorized(mesh: Mesh) -> np.ndarray:
    """Fully vectorised NumPy version — the CGI-X-optimised path."""
    verts = mesh.vertices
    tris = mesh.faces
    a = verts[tris[:, 0]]
    b = verts[tris[:, 1]]
    c = verts[tris[:, 2]]
    normals = np.cross(b - a, c - a)
    lengths = np.linalg.norm(normals, axis=1, keepdims=True)
    lengths = np.where(lengths > 1e-12, lengths, 1.0)
    return normals / lengths


def compute_vertex_normals_vectorized(mesh: Mesh) -> np.ndarray:
    """Area-weighted vertex normals via scatter-add, fully vectorised."""
    verts = mesh.vertices
    tris = mesh.faces
    a = verts[tris[:, 0]]
    b = verts[tris[:, 1]]
    c = verts[tris[:, 2]]
    face_normals_unnormalized = np.cross(b - a, c - a)  # magnitude encodes area weight

    vertex_normals = np.zeros_like(verts)
    np.add.at(vertex_normals, tris[:, 0], face_normals_unnormalized)
    np.add.at(vertex_normals, tris[:, 1], face_normals_unnormalized)
    np.add.at(vertex_normals, tris[:, 2], face_normals_unnormalized)

    lengths = np.linalg.norm(vertex_normals, axis=1, keepdims=True)
    lengths = np.where(lengths > 1e-12, lengths, 1.0)
    return vertex_normals / lengths


def max_normal_deviation(a: np.ndarray, b: np.ndarray) -> float:
    """Largest angular deviation (radians) between two equally-ordered
    normal arrays — used to validate that an optimisation preserves
    shading fidelity."""
    dots = np.clip(np.sum(a * b, axis=1), -1.0, 1.0)
    return float(np.max(np.arccos(dots)))
