"""
Topology utilities: adjacency, duplicate-vertex welding, edge extraction.
Duplicate vertices are extremely common in imported/exported meshes (every
seam produces them) and welding them is a reliable, measurable memory and
bandwidth win with zero visual impact.
"""

from __future__ import annotations

from typing import Dict, List, Tuple

import numpy as np

from cgi_x.geometry.mesh import Mesh


def weld_duplicate_vertices(mesh: Mesh, decimals: int = 6) -> Mesh:
    """
    Merge vertices that are identical to `decimals` decimal places and
    remap face indices accordingly. This never changes the rendered shape
    (geometric error is exactly zero for coincident vertices) but reduces
    vertex-buffer size and downstream computation.
    """
    rounded = np.round(mesh.vertices, decimals=decimals)
    # np.unique on structured view gives stable, vectorised dedup with inverse mapping.
    view = np.ascontiguousarray(rounded).view(
        np.dtype((np.void, rounded.dtype.itemsize * rounded.shape[1]))
    )
    _, unique_idx, inverse = np.unique(view, return_index=True, return_inverse=True)

    new_vertices = mesh.vertices[unique_idx]
    new_faces = inverse[mesh.faces.reshape(-1)].reshape(mesh.faces.shape)

    new_normals = mesh.normals[unique_idx] if mesh.normals is not None else None
    new_uvs = mesh.uvs[unique_idx] if mesh.uvs is not None else None

    return Mesh(vertices=new_vertices, faces=new_faces, normals=new_normals,
                uvs=new_uvs, name=mesh.name)


def build_vertex_adjacency(mesh: Mesh) -> List[set]:
    """Vertex -> set of adjacent vertex indices, built from the face list."""
    adjacency: List[set] = [set() for _ in range(mesh.vertex_count)]
    for tri in mesh.faces:
        a, b, c = int(tri[0]), int(tri[1]), int(tri[2])
        adjacency[a].update((b, c))
        adjacency[b].update((a, c))
        adjacency[c].update((a, b))
    return adjacency


def edge_list(mesh: Mesh) -> np.ndarray:
    """Unique undirected edges as an (E, 2) array, vectorised."""
    tris = mesh.faces
    edges = np.concatenate([
        tris[:, [0, 1]],
        tris[:, [1, 2]],
        tris[:, [2, 0]],
    ], axis=0)
    edges = np.sort(edges, axis=1)
    return np.unique(edges, axis=0)


def find_unreferenced_vertices(mesh: Mesh) -> np.ndarray:
    """Vertices that no face references — safe to drop entirely."""
    referenced = np.zeros(mesh.vertex_count, dtype=bool)
    referenced[mesh.faces.reshape(-1)] = True
    return np.where(~referenced)[0]


def remove_unreferenced_vertices(mesh: Mesh) -> Mesh:
    unreferenced = find_unreferenced_vertices(mesh)
    if len(unreferenced) == 0:
        return mesh.copy()

    keep_mask = np.ones(mesh.vertex_count, dtype=bool)
    keep_mask[unreferenced] = False
    old_to_new = np.cumsum(keep_mask) - 1

    new_vertices = mesh.vertices[keep_mask]
    new_faces = old_to_new[mesh.faces]
    new_normals = mesh.normals[keep_mask] if mesh.normals is not None else None
    new_uvs = mesh.uvs[keep_mask] if mesh.uvs is not None else None

    return Mesh(vertices=new_vertices, faces=new_faces, normals=new_normals,
                uvs=new_uvs, name=mesh.name)
