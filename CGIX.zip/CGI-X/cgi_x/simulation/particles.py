"""
Particle system — naive per-particle Python loop vs vectorised NumPy,
plus spatial partitioning (uniform grid) for neighbour queries so
pairwise-interaction costs don't scale O(n^2) unnecessarily.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


@dataclass
class ParticleSystem:
    positions: np.ndarray   # (N, 3)
    velocities: np.ndarray  # (N, 3)
    mass: np.ndarray        # (N,)
    gravity: np.ndarray = field(default_factory=lambda: np.array([0.0, -9.81, 0.0]))
    drag: float = 0.02

    @property
    def count(self) -> int:
        return int(self.positions.shape[0])

    @staticmethod
    def random(n: int, seed: int = 0) -> "ParticleSystem":
        rng = np.random.default_rng(seed)
        return ParticleSystem(
            positions=rng.uniform(-1, 1, size=(n, 3)),
            velocities=rng.uniform(-0.1, 0.1, size=(n, 3)),
            mass=np.full(n, 1.0),
        )

    def copy(self) -> "ParticleSystem":
        return ParticleSystem(
            positions=self.positions.copy(),
            velocities=self.velocities.copy(),
            mass=self.mass.copy(),
            gravity=self.gravity.copy(),
            drag=self.drag,
        )


def step_naive(system: ParticleSystem, dt: float) -> ParticleSystem:
    """Pure-Python per-particle update loop — the baseline."""
    n = system.count
    new_positions = np.empty_like(system.positions)
    new_velocities = np.empty_like(system.velocities)
    for i in range(n):
        vx = system.velocities[i, 0] + system.gravity[0] * dt
        vy = system.velocities[i, 1] + system.gravity[1] * dt
        vz = system.velocities[i, 2] + system.gravity[2] * dt
        vx *= (1.0 - system.drag)
        vy *= (1.0 - system.drag)
        vz *= (1.0 - system.drag)
        new_velocities[i] = (vx, vy, vz)
        new_positions[i] = system.positions[i] + new_velocities[i] * dt
    out = system.copy()
    out.positions, out.velocities = new_positions, new_velocities
    return out


def step_vectorized(system: ParticleSystem, dt: float) -> ParticleSystem:
    """Fully vectorised NumPy update — the CGI-X-optimised path."""
    new_velocities = (system.velocities + system.gravity * dt) * (1.0 - system.drag)
    new_positions = system.positions + new_velocities * dt
    out = system.copy()
    out.positions, out.velocities = new_positions, new_velocities
    return out


def uniform_grid_neighbors(positions: np.ndarray, cell_size: float):
    """
    Bucket particles into a uniform spatial grid, returning a dict mapping
    cell-key -> array of particle indices. Reduces neighbour queries from
    O(n^2) to roughly O(n) for typically-distributed particle sets, which
    is the standard spatial-partitioning technique required for cheap
    pairwise simulation forces (SPH, collisions, flocking, etc.).
    """
    cell_indices = np.floor(positions / cell_size).astype(np.int64)
    keys = [tuple(row) for row in cell_indices]

    buckets: dict = {}
    for i, key in enumerate(keys):
        buckets.setdefault(key, []).append(i)
    return {k: np.array(v) for k, v in buckets.items()}
