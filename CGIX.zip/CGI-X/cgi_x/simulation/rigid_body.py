"""Simple rigid-body linear + angular dynamics, vectorised over a whole
batch of bodies at once (typical for background/set-dressing objects in a
production scene)."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class RigidBodyBatch:
    positions: np.ndarray       # (N, 3)
    velocities: np.ndarray      # (N, 3)
    orientations: np.ndarray    # (N, 4) quaternions (w, x, y, z)
    angular_velocities: np.ndarray  # (N, 3)
    mass: np.ndarray            # (N,)
    restitution: float = 0.4
    ground_y: float = 0.0

    @property
    def count(self) -> int:
        return int(self.positions.shape[0])

    @staticmethod
    def random(n: int, seed: int = 0) -> "RigidBodyBatch":
        rng = np.random.default_rng(seed)
        orientations = np.zeros((n, 4))
        orientations[:, 0] = 1.0
        return RigidBodyBatch(
            positions=rng.uniform([-2, 2, -2], [2, 6, 2], size=(n, 3)),
            velocities=np.zeros((n, 3)),
            orientations=orientations,
            angular_velocities=rng.uniform(-1, 1, size=(n, 3)),
            mass=np.full(n, 1.0),
        )


def _integrate_quaternions(orientations: np.ndarray, angular_velocities: np.ndarray, dt: float) -> np.ndarray:
    """First-order quaternion integration, vectorised, followed by renormalisation."""
    w, x, y, z = orientations[:, 0], orientations[:, 1], orientations[:, 2], orientations[:, 3]
    wx, wy, wz = angular_velocities[:, 0], angular_velocities[:, 1], angular_velocities[:, 2]

    dq = 0.5 * dt * np.stack([
        -x * wx - y * wy - z * wz,
        w * wx + y * wz - z * wy,
        w * wy - x * wz + z * wx,
        w * wz + x * wy - y * wx,
    ], axis=1)

    new_orientations = orientations + dq
    norms = np.linalg.norm(new_orientations, axis=1, keepdims=True)
    norms = np.where(norms > 1e-12, norms, 1.0)
    return new_orientations / norms


def step(batch: RigidBodyBatch, dt: float, gravity=(0.0, -9.81, 0.0)) -> RigidBodyBatch:
    """Vectorised gravity integration, ground collision with restitution,
    and quaternion orientation update for the whole batch at once."""
    new_velocities = batch.velocities + np.array(gravity) * dt
    new_positions = batch.positions + new_velocities * dt

    below_ground = new_positions[:, 1] < batch.ground_y
    new_positions[below_ground, 1] = batch.ground_y
    new_velocities[below_ground, 1] *= -batch.restitution

    new_orientations = _integrate_quaternions(batch.orientations, batch.angular_velocities, dt)

    return RigidBodyBatch(
        positions=new_positions,
        velocities=new_velocities,
        orientations=new_orientations,
        angular_velocities=batch.angular_velocities,
        mass=batch.mass,
        restitution=batch.restitution,
        ground_y=batch.ground_y,
    )
