"""Time integrators shared by the particle/cloth/rigid-body solvers."""

from __future__ import annotations

from typing import Callable

import numpy as np


def semi_implicit_euler_step(positions: np.ndarray, velocities: np.ndarray,
                              forces: np.ndarray, mass: np.ndarray, dt: float):
    """Symplectic Euler: update velocity first, then position with the new
    velocity. Cheap, unconditionally stable enough for most VFX-grade
    real-time-ish previews, and fully vectorised."""
    accel = forces / mass[:, None]
    new_velocities = velocities + accel * dt
    new_positions = positions + new_velocities * dt
    return new_positions, new_velocities


def rk4_step(state: np.ndarray, dt: float, derivative_fn: Callable[[np.ndarray], np.ndarray]) -> np.ndarray:
    """Classic 4th-order Runge-Kutta for a first-order ODE system
    `dstate/dt = derivative_fn(state)`, vectorised over the whole state
    array. Higher accuracy per step than Euler, at 4x the derivative
    evaluations — CGI-X's adaptive solver picks between these based on
    the error/time tradeoff actually observed."""
    k1 = derivative_fn(state)
    k2 = derivative_fn(state + 0.5 * dt * k1)
    k3 = derivative_fn(state + 0.5 * dt * k2)
    k4 = derivative_fn(state + dt * k3)
    return state + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)
