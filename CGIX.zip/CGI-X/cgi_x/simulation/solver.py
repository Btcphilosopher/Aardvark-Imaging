"""
Adaptive-timestep solver wrapper.

Monitors ERROR + CONVERGENCE + TIME simultaneously, as required by the
simulation-optimisation spec: it never shrinks/grows the timestep on
speed considerations alone without checking the resulting local error
estimate (via step-doubling / Richardson extrapolation).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, List

import numpy as np

from cgi_x.simulation.numerical import rk4_step


@dataclass
class SolverStepLog:
    time: float
    dt: float
    error_estimate: float
    accepted: bool


@dataclass
class AdaptiveSolveResult:
    final_state: np.ndarray
    log: List[SolverStepLog] = field(default_factory=list)
    total_steps: int = 0
    accepted_steps: int = 0

    @property
    def rejection_rate(self) -> float:
        if self.total_steps == 0:
            return 0.0
        return 1.0 - (self.accepted_steps / self.total_steps)


def adaptive_rk4_solve(
    initial_state: np.ndarray,
    derivative_fn: Callable[[np.ndarray], np.ndarray],
    t_start: float,
    t_end: float,
    dt_init: float = 0.01,
    error_tolerance: float = 1e-4,
    dt_min: float = 1e-6,
    dt_max: float = 0.5,
) -> AdaptiveSolveResult:
    """
    Step-doubling adaptive RK4: each step is taken once at `dt` and once as
    two half-steps at `dt/2`; the difference between the two estimates the
    local truncation error. The timestep grows when error is comfortably
    below tolerance (fewer steps -> faster) and shrinks when it isn't
    (protecting numerical stability) — error, convergence and time are all
    inspected together on every step, never speed alone.
    """
    state = np.array(initial_state, dtype=np.float64)
    t = t_start
    dt = dt_init
    log: List[SolverStepLog] = []
    total_steps = 0
    accepted_steps = 0

    while t < t_end:
        dt = min(dt, t_end - t)

        full_step = rk4_step(state, dt, derivative_fn)
        half1 = rk4_step(state, dt / 2, derivative_fn)
        half2 = rk4_step(half1, dt / 2, derivative_fn)

        error_estimate = float(np.max(np.abs(half2 - full_step))) if state.size else 0.0
        total_steps += 1

        accepted = error_estimate <= error_tolerance or dt <= dt_min
        log.append(SolverStepLog(time=t, dt=dt, error_estimate=error_estimate, accepted=accepted))

        if accepted:
            state = half2  # the higher-accuracy estimate
            t += dt
            accepted_steps += 1
            if error_estimate > 0:
                # Standard step-doubling growth heuristic, clamped.
                growth = min(2.0, max(0.5, 0.9 * (error_tolerance / error_estimate) ** 0.2))
            else:
                growth = 1.5
            dt = float(np.clip(dt * growth, dt_min, dt_max))
        else:
            dt = max(dt_min, dt * 0.5)

    return AdaptiveSolveResult(final_state=state, log=log, total_steps=total_steps,
                                accepted_steps=accepted_steps)
