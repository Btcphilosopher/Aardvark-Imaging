"""
Simplified SPH (Smoothed Particle Hydrodynamics) fluid step, small-scale,
intended as a realistic-shaped benchmark workload for spatial partitioning
rather than a production fluid solver. Naive O(n^2) neighbour search vs
uniform-grid-accelerated neighbour search, so the spatial-partitioning
gain can be measured on a genuinely pairwise-interaction workload.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from cgi_x.simulation.particles import uniform_grid_neighbors


@dataclass
class FluidState:
    positions: np.ndarray
    velocities: np.ndarray
    density: np.ndarray
    smoothing_radius: float = 0.2
    rest_density: float = 1000.0
    stiffness: float = 200.0

    @staticmethod
    def random_block(n: int, seed: int = 0, smoothing_radius: float = 0.2) -> "FluidState":
        rng = np.random.default_rng(seed)
        side = int(np.ceil(n ** (1 / 3)))
        positions = rng.uniform(0, side * smoothing_radius * 0.5, size=(n, 3))
        return FluidState(
            positions=positions,
            velocities=np.zeros((n, 3)),
            density=np.full(n, 1000.0),
            smoothing_radius=smoothing_radius,
        )


def _poly6(r2: np.ndarray, h: float) -> np.ndarray:
    h2 = h * h
    coeff = 315.0 / (64.0 * np.pi * h ** 9)
    diff = np.clip(h2 - r2, 0, None)
    return coeff * diff ** 3


def compute_density_naive(state: FluidState) -> np.ndarray:
    n = state.positions.shape[0]
    density = np.zeros(n)
    h = state.smoothing_radius
    for i in range(n):
        acc = 0.0
        for j in range(n):
            r2 = float(np.sum((state.positions[i] - state.positions[j]) ** 2))
            if r2 < h * h:
                acc += float(_poly6(np.array([r2]), h)[0])
        density[i] = acc
    return density


def compute_density_grid(state: FluidState) -> np.ndarray:
    """Uniform-grid-accelerated density: only check particles in the same
    or neighbouring grid cells instead of every other particle."""
    n = state.positions.shape[0]
    h = state.smoothing_radius
    buckets = uniform_grid_neighbors(state.positions, cell_size=h)
    cell_of = {tuple(np.floor(p / h).astype(np.int64)): None for p in state.positions}
    cell_indices = np.floor(state.positions / h).astype(np.int64)

    density = np.zeros(n)
    offsets = [(dx, dy, dz) for dx in (-1, 0, 1) for dy in (-1, 0, 1) for dz in (-1, 0, 1)]

    for i in range(n):
        cell = tuple(cell_indices[i])
        neighbor_idx = []
        for off in offsets:
            key = (cell[0] + off[0], cell[1] + off[1], cell[2] + off[2])
            if key in buckets:
                neighbor_idx.append(buckets[key])
        if not neighbor_idx:
            continue
        idx = np.concatenate(neighbor_idx)
        diffs = state.positions[idx] - state.positions[i]
        r2 = np.sum(diffs ** 2, axis=1)
        mask = r2 < h * h
        density[i] = float(np.sum(_poly6(r2[mask], h)))

    return density
