"""
Mass-spring cloth simulation on a regular grid, naive vs vectorised, used
by the simulation optimiser to demonstrate/measure a real, non-trivial
constraint-solving workload.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class ClothGrid:
    positions: np.ndarray     # (rows*cols, 3)
    velocities: np.ndarray    # (rows*cols, 3)
    rows: int
    cols: int
    rest_length: float
    stiffness: float = 400.0
    damping: float = 0.98
    mass: float = 0.05
    pinned: np.ndarray = None  # boolean mask, rows*cols

    @staticmethod
    def create(rows: int, cols: int, spacing: float = 0.1) -> "ClothGrid":
        xs, zs = np.meshgrid(np.arange(cols) * spacing, np.arange(rows) * spacing)
        positions = np.stack([xs.ravel(), np.zeros(rows * cols), zs.ravel()], axis=1)
        velocities = np.zeros_like(positions)
        pinned = np.zeros(rows * cols, dtype=bool)
        pinned[:cols] = True  # pin the top row, like fabric hanging from a rail
        return ClothGrid(positions=positions, velocities=velocities, rows=rows, cols=cols,
                          rest_length=spacing, pinned=pinned)

    def index(self, r: int, c: int) -> int:
        return r * self.cols + c

    def structural_springs(self):
        springs = []
        for r in range(self.rows):
            for c in range(self.cols):
                i = self.index(r, c)
                if c + 1 < self.cols:
                    springs.append((i, self.index(r, c + 1)))
                if r + 1 < self.rows:
                    springs.append((i, self.index(r + 1, c)))
        return np.array(springs, dtype=np.int64)


def step_naive(cloth: ClothGrid, dt: float, gravity=(0.0, -9.81, 0.0)) -> ClothGrid:
    """Per-spring Python loop force accumulation — the baseline."""
    springs = cloth.structural_springs()
    forces = np.tile(np.array(gravity) * cloth.mass, (cloth.positions.shape[0], 1))

    for a, b in springs:
        delta = cloth.positions[b] - cloth.positions[a]
        dist = float(np.linalg.norm(delta)) or 1e-9
        direction = delta / dist
        stretch = dist - cloth.rest_length
        f = cloth.stiffness * stretch * direction
        forces[a] += f
        forces[b] -= f

    accel = forces / cloth.mass
    new_velocities = (cloth.velocities + accel * dt) * cloth.damping
    new_velocities[cloth.pinned] = 0.0
    new_positions = cloth.positions + new_velocities * dt

    out = ClothGrid(new_positions, new_velocities, cloth.rows, cloth.cols,
                     cloth.rest_length, cloth.stiffness, cloth.damping, cloth.mass, cloth.pinned)
    return out


def step_vectorized(cloth: ClothGrid, dt: float, gravity=(0.0, -9.81, 0.0)) -> ClothGrid:
    """Vectorised spring-force accumulation via scatter-add."""
    springs = cloth.structural_springs()
    a_idx, b_idx = springs[:, 0], springs[:, 1]

    delta = cloth.positions[b_idx] - cloth.positions[a_idx]
    dist = np.linalg.norm(delta, axis=1, keepdims=True)
    dist_safe = np.where(dist > 1e-9, dist, 1e-9)
    direction = delta / dist_safe
    stretch = dist - cloth.rest_length
    spring_force = cloth.stiffness * stretch * direction

    forces = np.tile(np.array(gravity) * cloth.mass, (cloth.positions.shape[0], 1))
    np.add.at(forces, a_idx, spring_force)
    np.add.at(forces, b_idx, -spring_force)

    accel = forces / cloth.mass
    new_velocities = (cloth.velocities + accel * dt) * cloth.damping
    new_velocities[cloth.pinned] = 0.0
    new_positions = cloth.positions + new_velocities * dt

    return ClothGrid(new_positions, new_velocities, cloth.rows, cloth.cols,
                      cloth.rest_length, cloth.stiffness, cloth.damping, cloth.mass, cloth.pinned)
