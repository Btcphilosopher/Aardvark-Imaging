"""Wavefront OBJ reader/writer — pure Python, no external dependencies,
fully functional for triangulated meshes with optional UVs/normals."""

from __future__ import annotations

import numpy as np

from cgi_x.geometry.mesh import Mesh


def load_obj(path: str, name: str = None) -> Mesh:
    vertices = []
    uvs = []
    normals = []
    faces = []

    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            tag = parts[0]

            if tag == "v":
                vertices.append([float(x) for x in parts[1:4]])
            elif tag == "vt":
                uvs.append([float(x) for x in parts[1:3]])
            elif tag == "vn":
                normals.append([float(x) for x in parts[1:4]])
            elif tag == "f":
                idx = []
                for token in parts[1:]:
                    vi = token.split("/")[0]
                    idx.append(int(vi) - 1 if int(vi) > 0 else len(vertices) + int(vi))
                # fan-triangulate faces with >3 vertices
                for i in range(1, len(idx) - 1):
                    faces.append([idx[0], idx[i], idx[i + 1]])

    mesh = Mesh(
        vertices=np.array(vertices, dtype=np.float64) if vertices else np.zeros((0, 3)),
        faces=np.array(faces, dtype=np.int64) if faces else np.zeros((0, 3), dtype=np.int64),
        uvs=np.array(uvs, dtype=np.float64) if uvs and len(uvs) == len(vertices) else None,
        name=name or path,
    )
    return mesh


def save_obj(mesh: Mesh, path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"# exported by CGI-X\no {mesh.name}\n")
        for v in mesh.vertices:
            f.write(f"v {v[0]:.6f} {v[1]:.6f} {v[2]:.6f}\n")
        if mesh.uvs is not None:
            for uv in mesh.uvs:
                f.write(f"vt {uv[0]:.6f} {uv[1]:.6f}\n")
        for tri in mesh.faces:
            i0, i1, i2 = tri[0] + 1, tri[1] + 1, tri[2] + 1
            f.write(f"f {i0} {i1} {i2}\n")
