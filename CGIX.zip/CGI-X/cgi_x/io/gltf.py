"""
Minimal glTF 2.0 reader/writer for a single triangle mesh (positions +
indices), using only the standard library (`json` + `struct`) — no
`pygltflib` dependency required. Supports both the `.gltf` (JSON + a
separate `.bin`) and embedded-base64-buffer forms on read; writes the
`.gltf` + `.bin` form.

This deliberately covers the common CGI-X use case (round-tripping mesh
geometry between pipeline stages) rather than the full glTF spec
(skinning, animation, PBR materials, etc.) — see `cgi_x.io.usd` /
`cgi_x.io.alembic` docstrings for the same scoping note on richer formats.
"""

from __future__ import annotations

import base64
import json
import os
import struct

import numpy as np

from cgi_x.geometry.mesh import Mesh

_COMPONENT_TYPE_FLOAT = 5126
_COMPONENT_TYPE_UINT32 = 5125


def save_gltf(mesh: Mesh, path: str) -> None:
    bin_path = os.path.splitext(path)[0] + ".bin"

    positions = mesh.vertices.astype(np.float32)
    indices = mesh.faces.astype(np.uint32).reshape(-1)

    positions_bytes = positions.tobytes()
    # glTF requires 4-byte alignment between bufferViews.
    pad = (-len(positions_bytes)) % 4
    indices_bytes = indices.tobytes()

    with open(bin_path, "wb") as f:
        f.write(positions_bytes)
        f.write(b"\x00" * pad)
        f.write(indices_bytes)

    gltf = {
        "asset": {"version": "2.0", "generator": "CGI-X"},
        "scenes": [{"nodes": [0]}],
        "scene": 0,
        "nodes": [{"mesh": 0, "name": mesh.name}],
        "meshes": [{
            "primitives": [{
                "attributes": {"POSITION": 0},
                "indices": 1,
                "mode": 4,  # TRIANGLES
            }],
            "name": mesh.name,
        }],
        "buffers": [{"uri": os.path.basename(bin_path), "byteLength": len(positions_bytes) + pad + len(indices_bytes)}],
        "bufferViews": [
            {"buffer": 0, "byteOffset": 0, "byteLength": len(positions_bytes), "target": 34962},
            {"buffer": 0, "byteOffset": len(positions_bytes) + pad, "byteLength": len(indices_bytes), "target": 34963},
        ],
        "accessors": [
            {
                "bufferView": 0, "componentType": _COMPONENT_TYPE_FLOAT, "count": positions.shape[0],
                "type": "VEC3",
                "min": positions.min(axis=0).tolist(), "max": positions.max(axis=0).tolist(),
            },
            {"bufferView": 1, "componentType": _COMPONENT_TYPE_UINT32, "count": indices.shape[0], "type": "SCALAR"},
        ],
    }

    with open(path, "w", encoding="utf-8") as f:
        json.dump(gltf, f, indent=2)


def load_gltf(path: str, name: str = None) -> Mesh:
    with open(path, "r", encoding="utf-8") as f:
        gltf = json.load(f)

    buffer_uri = gltf["buffers"][0]["uri"]
    if buffer_uri.startswith("data:"):
        header, encoded = buffer_uri.split(",", 1)
        buffer_bytes = base64.b64decode(encoded)
    else:
        bin_path = os.path.join(os.path.dirname(path), buffer_uri)
        with open(bin_path, "rb") as bf:
            buffer_bytes = bf.read()

    mesh_def = gltf["meshes"][0]["primitives"][0]
    position_accessor_idx = mesh_def["attributes"]["POSITION"]
    indices_accessor_idx = mesh_def["indices"]

    positions = _read_accessor(gltf, buffer_bytes, position_accessor_idx).reshape(-1, 3)
    indices = _read_accessor(gltf, buffer_bytes, indices_accessor_idx).reshape(-1, 3)

    return Mesh(vertices=positions.astype(np.float64), faces=indices.astype(np.int64),
                name=name or gltf["meshes"][0].get("name", path))


def _read_accessor(gltf: dict, buffer_bytes: bytes, accessor_idx: int) -> np.ndarray:
    accessor = gltf["accessors"][accessor_idx]
    buffer_view = gltf["bufferViews"][accessor["bufferView"]]
    offset = buffer_view.get("byteOffset", 0)
    length = buffer_view["byteLength"]
    raw = buffer_bytes[offset: offset + length]

    dtype_map = {
        _COMPONENT_TYPE_FLOAT: np.float32,
        _COMPONENT_TYPE_UINT32: np.uint32,
        5123: np.uint16,  # UNSIGNED_SHORT
        5121: np.uint8,   # UNSIGNED_BYTE
    }
    dtype = dtype_map[accessor["componentType"]]
    return np.frombuffer(raw, dtype=dtype)
