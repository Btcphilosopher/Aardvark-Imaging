"""
Alembic (.abc) adapter.

Alembic is a binary, HDF5/Ogawa-backed cache format with no pure-Python
implementation — reading/writing it correctly requires the official
`alembic` Python bindings (built from the Alembic C++ SDK) or a DCC's
bundled bindings (e.g. Maya's `alembic` module). CGI-X does not vendor or
reimplement that binary format; instead this adapter binds to the real
library when present and fails loudly, with install guidance, when it
is not — never silently no-ops or fabricates data.
"""

from __future__ import annotations

from cgi_x.geometry.mesh import Mesh

_INSTALL_HINT = (
    "Alembic support requires the official Python bindings (the `alembic` "
    "package built against the Alembic C++ SDK), which are not installable "
    "via a plain `pip install` on most platforms. Options:\n"
    "  * Use the Alembic bindings bundled with Maya/Houdini (import this "
    "module from within that application's Python interpreter), or\n"
    "  * Build alembic-python from https://github.com/alembic/alembic, or\n"
    "  * Convert to/from .abc using the DCC application and use "
    "cgi_x.io.obj / cgi_x.io.gltf for the CGI-X-native round trip."
)


def _import_alembic():
    try:
        import alembic  # type: ignore
        return alembic
    except ImportError as exc:
        raise ImportError(f"cgi_x.io.alembic: {_INSTALL_HINT}") from exc


def load_alembic(path: str, name: str = None) -> Mesh:
    alembic = _import_alembic()
    from alembic.Abc import IArchive  # type: ignore
    from alembic.AbcGeom import IPolyMesh, IPolyMeshSchema  # type: ignore
    import numpy as np

    archive = IArchive(path)
    top = archive.getTop()

    def find_mesh(obj):
        for i in range(obj.getNumChildren()):
            child = obj.getChild(i)
            if IPolyMesh.matches(child.getMetaData()):
                return IPolyMesh(child)
            found = find_mesh(child)
            if found is not None:
                return found
        return None

    poly_mesh = find_mesh(top)
    if poly_mesh is None:
        raise ValueError(f"no polymesh found in {path}")

    schema = poly_mesh.getSchema()
    sample = schema.getValue()
    positions = np.array(sample.getPositions(), dtype=np.float64).reshape(-1, 3)
    face_indices = np.array(sample.getFaceIndices())
    face_counts = np.array(sample.getFaceCounts())

    faces = []
    cursor = 0
    for count in face_counts:
        poly = face_indices[cursor: cursor + count]
        for i in range(1, count - 1):
            faces.append([poly[0], poly[i], poly[i + 1]])
        cursor += count

    return Mesh(vertices=positions, faces=np.array(faces, dtype=np.int64), name=name or path)


def save_alembic(mesh: Mesh, path: str) -> None:
    _import_alembic()
    from alembic.Abc import OArchive  # type: ignore
    from alembic.AbcGeom import OPolyMesh, OPolyMeshSchemaSample  # type: ignore

    archive = OArchive(path)
    obj = OPolyMesh(archive.getTop(), mesh.name)
    sample = OPolyMeshSchemaSample(
        mesh.vertices.astype("float32"),
        mesh.faces.reshape(-1).astype("int32"),
        (mesh.faces.shape[1],) * mesh.faces.shape[0],
    )
    obj.getSchema().set(sample)
