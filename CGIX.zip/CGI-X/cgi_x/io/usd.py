"""
USD (Universal Scene Description) adapter.

Like Alembic, USD is a complex binary/text hybrid format whose only
correct implementation is Pixar's own USD library (`pxr`, distributed as
`usd-core` on PyPI, or the copy bundled with Houdini/Maya/Blender's USD
plugin). CGI-X binds to `pxr` when available rather than reimplementing
USD parsing, and raises a clear, actionable error when it is not — this
keeps CGI-X honest about what it can and cannot do without the real SDK.
"""

from __future__ import annotations

from cgi_x.geometry.mesh import Mesh

_INSTALL_HINT = (
    "USD support requires Pixar's USD Python bindings. Install with "
    "`pip install usd-core`, or use the `pxr` module bundled with "
    "Houdini/Maya/Blender's USD plugin (import this module from within "
    "that application's Python interpreter)."
)


def _import_pxr():
    try:
        from pxr import Usd, UsdGeom  # type: ignore
        return Usd, UsdGeom
    except ImportError as exc:
        raise ImportError(f"cgi_x.io.usd: {_INSTALL_HINT}") from exc


def load_usd(path: str, mesh_prim_path: str = None, name: str = None) -> Mesh:
    Usd, UsdGeom = _import_pxr()
    import numpy as np

    stage = Usd.Stage.Open(path)
    if stage is None:
        raise ValueError(f"could not open USD stage: {path}")

    mesh_prim = None
    if mesh_prim_path:
        prim = stage.GetPrimAtPath(mesh_prim_path)
        if prim and prim.IsA(UsdGeom.Mesh):
            mesh_prim = UsdGeom.Mesh(prim)
    else:
        for prim in stage.Traverse():
            if prim.IsA(UsdGeom.Mesh):
                mesh_prim = UsdGeom.Mesh(prim)
                break

    if mesh_prim is None:
        raise ValueError(f"no UsdGeomMesh found in {path}")

    points = np.array(mesh_prim.GetPointsAttr().Get(), dtype=np.float64)
    face_vertex_counts = np.array(mesh_prim.GetFaceVertexCountsAttr().Get())
    face_vertex_indices = np.array(mesh_prim.GetFaceVertexIndicesAttr().Get())

    faces = []
    cursor = 0
    for count in face_vertex_counts:
        poly = face_vertex_indices[cursor: cursor + count]
        for i in range(1, count - 1):
            faces.append([poly[0], poly[i], poly[i + 1]])
        cursor += count

    return Mesh(vertices=points, faces=np.array(faces, dtype=np.int64), name=name or path)


def save_usd(mesh: Mesh, path: str, mesh_prim_path: str = "/Mesh") -> None:
    Usd, UsdGeom = _import_pxr()

    stage = Usd.Stage.CreateNew(path)
    usd_mesh = UsdGeom.Mesh.Define(stage, mesh_prim_path)
    usd_mesh.GetPointsAttr().Set([tuple(v) for v in mesh.vertices])
    usd_mesh.GetFaceVertexCountsAttr().Set([3] * mesh.faces.shape[0])
    usd_mesh.GetFaceVertexIndicesAttr().Set(mesh.faces.reshape(-1).tolist())
    stage.GetRootLayer().Save()
