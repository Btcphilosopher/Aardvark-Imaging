"""
CGI-X CLI entry point.

Runs the full MEASURE -> PROFILE -> FIND BOTTLENECK -> OPTIMISE ->
BENCHMARK -> VALIDATE -> ACCEPT/REJECT loop end-to-end on a synthetic
production-shaped scene, and prints a CGI-X performance report.

    python -m cgi_x.main
    python -m cgi_x.main --project "FILM_042" --spheres 6 --subdivisions 4
"""

from __future__ import annotations

import argparse
import sys

import numpy as np

from cgi_x import Optimizer
from cgi_x.analytics.performance import CostEngine
from cgi_x.geometry.mesh import Mesh
from cgi_x.rendering.materials import Material
from cgi_x.rendering.scene import Scene, SceneObject


def build_demo_scene(name: str, n_objects: int, subdivisions: int) -> Scene:
    """Build a synthetic scene shaped like a real production asset set:
    several meshes, some duplicated transforms (instancing candidates),
    some hidden objects, and one over-subdivided hero object."""
    scene = Scene(name=name)
    rng = np.random.default_rng(42)

    for i in range(n_objects):
        mesh = Mesh.synthetic_sphere(subdivisions=subdivisions, name=f"prop_{i:03d}")
        transform = np.eye(4)
        # duplicate every 3rd transform on purpose, to exercise instancing detection
        transform[:3, 3] = [(i % 3) * 2.0, 0.0, (i // 3) * 2.0]

        material = Material(name=f"mat_{i:03d}", texture_count=int(rng.integers(1, 6)),
                             has_subsurface_scattering=bool(i == 0))
        visible = not (i % 7 == 0 and i != 0)  # scatter a few hidden objects through the scene

        obj = SceneObject(name=f"prop_{i:03d}", mesh=mesh, transform=transform,
                           material=material, visible=visible)
        if i == 0:
            obj.subdivision_level = 5  # hero object: deliberately over-subdivided
        scene.add_object(obj)

    return scene


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="CGI-X — computational optimisation layer for CGI/VFX pipelines")
    parser.add_argument("--project", default="DEMO_PROJECT", help="Project name for the report")
    parser.add_argument("--objects", type=int, default=12, help="Number of synthetic scene objects")
    parser.add_argument("--subdivisions", type=int, default=3, help="Base subdivision level of each sphere")
    parser.add_argument("--max-visual-error", type=float, default=0.005)
    parser.add_argument("--max-geometric-error", type=float, default=0.001)
    parser.add_argument("--project-hours", type=float, default=14200.0,
                         help="Baseline CPU-hours for the cost-engine estimate")
    parser.add_argument("--hourly-rate", type=float, default=0.35, help="Cost per compute-hour")
    args = parser.parse_args(argv)

    print(f"CGI-X v1.0.0 — building demo scene '{args.project}'"
          f" ({args.objects} objects, subdivision level {args.subdivisions})...\n")

    scene = build_demo_scene(args.project, args.objects, args.subdivisions)

    optimizer = Optimizer()
    print(optimizer.engine.settings.hardware.summary())
    print()

    print("Running MEASURE -> PROFILE -> OPTIMISE -> BENCHMARK -> VALIDATE loop...\n")
    result = optimizer.optimize(
        scene,
        constraints={
            "max_visual_error": args.max_visual_error,
            "max_geometric_error": args.max_geometric_error,
        },
        project_name=args.project,
    )

    print(result.gain_engine.breakdown_report())
    print()
    print(f"Optimisations accepted: {len(result.accepted)}   rejected: {len(result.rejected)}\n")

    for record in result.records:
        status = "ACCEPT" if record.accepted else "REJECT"
        print(f"  [{status}] {record.category:<11} {record.workload:<28} "
              f"gain={record.gain_percent:+7.2f}%  quality_diff={record.quality_difference:.2e}  "
              f"— {record.reason}")

    print()
    cost_engine = CostEngine(hourly_rate=args.hourly_rate)
    cost_estimate = cost_engine.estimate_from_gain(result.gain_engine, args.project_hours)

    print("=" * 60)
    print(result.summary())
    print()
    print(cost_estimate.report())
    print("=" * 60)

    return 0


if __name__ == "__main__":
    sys.exit(main())
