"""
Optional HTTP API server exposing the CGI-X Optimizer over FastAPI.

FastAPI/uvicorn are optional dependencies — importing `cgi_x` never
requires them; only running `python -m cgi_x.api.server` or calling
`create_app()` does. This keeps CGI-X usable as a pure library
(embedded inside a DCC's Python interpreter, for example) without
forcing a web framework dependency on every install.
"""

from __future__ import annotations

from typing import Any, Dict, Optional


def create_app():
    try:
        from fastapi import FastAPI
        from pydantic import BaseModel
    except ImportError as exc:
        raise ImportError(
            "cgi_x.api.server requires FastAPI + uvicorn + pydantic. "
            "Install with `pip install cgi-x[api]` or `pip install fastapi uvicorn pydantic`."
        ) from exc

    from cgi_x import Optimizer
    from cgi_x.geometry.mesh import Mesh
    from cgi_x.rendering.scene import Scene, SceneObject

    app = FastAPI(title="CGI-X API", version="1.0.0",
                   description="Computational optimisation layer for CGI/VFX pipelines")
    optimizer = Optimizer()

    class OptimizeRequest(BaseModel):
        project_name: str = "unnamed_project"
        sphere_subdivisions: int = 3      # demo payload: builds a synthetic scene server-side
        max_visual_error: float = 0.005
        max_geometric_error: float = 0.001

    class OptimizeResponse(BaseModel):
        project: str
        performance_gain_percent: float
        memory_saved_percent: float
        accepted_count: int
        rejected_count: int
        report: str

    @app.get("/health")
    def health() -> Dict[str, str]:
        return {"status": "ok", "engine": "cgi-x"}

    @app.get("/hardware")
    def hardware() -> Dict[str, Any]:
        return {"summary": optimizer.engine.settings.hardware.summary()}

    @app.post("/optimize", response_model=OptimizeResponse)
    def optimize(req: OptimizeRequest) -> OptimizeResponse:
        scene = Scene(name=req.project_name)
        mesh = Mesh.synthetic_sphere(subdivisions=req.sphere_subdivisions, name="demo_sphere")
        scene.add_object(SceneObject(name="demo_sphere", mesh=mesh))

        result = optimizer.optimize(
            scene,
            constraints={
                "max_visual_error": req.max_visual_error,
                "max_geometric_error": req.max_geometric_error,
            },
            project_name=req.project_name,
        )

        return OptimizeResponse(
            project=req.project_name,
            performance_gain_percent=result.performance_gain_percent,
            memory_saved_percent=result.memory_saved * 100,
            accepted_count=len(result.accepted),
            rejected_count=len(result.rejected),
            report=result.summary(),
        )

    return app


def run(host: str = "127.0.0.1", port: int = 8420):  # pragma: no cover - manual entry point
    import uvicorn
    uvicorn.run(create_app(), host=host, port=port)


if __name__ == "__main__":  # pragma: no cover
    run()
