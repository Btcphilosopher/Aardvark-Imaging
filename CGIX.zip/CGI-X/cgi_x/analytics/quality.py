"""
Visual and geometric difference engine: MSE, PSNR, SSIM (pure-NumPy
implementation, no extra dependency required) for image comparison, plus
a normalised geometric-error metric for meshes. This is what lets CGI-X
reject an optimisation that "went too far" instead of assuming it's fine.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


def mse(reference: np.ndarray, candidate: np.ndarray) -> float:
    ref = reference.astype(np.float64)
    cand = candidate.astype(np.float64)
    return float(np.mean((ref - cand) ** 2))


def psnr(reference: np.ndarray, candidate: np.ndarray, max_value: float = 1.0) -> float:
    error = mse(reference, candidate)
    if error <= 1e-12:
        return float("inf")
    return float(10 * np.log10((max_value ** 2) / error))


def _gaussian_kernel(size: int = 11, sigma: float = 1.5) -> np.ndarray:
    ax = np.arange(size) - size // 2
    kernel_1d = np.exp(-(ax ** 2) / (2 * sigma ** 2))
    kernel_1d /= kernel_1d.sum()
    return np.outer(kernel_1d, kernel_1d)


def _convolve2d_same(image: np.ndarray, kernel: np.ndarray) -> np.ndarray:
    from scipy.signal import convolve2d
    return convolve2d(image, kernel, mode="same", boundary="symm")


def ssim(reference: np.ndarray, candidate: np.ndarray, max_value: float = 1.0) -> float:
    """
    Structural similarity, computed the standard way (local mean, variance,
    covariance via Gaussian windows). Operates on single-channel (or
    channel-averaged) images.
    """
    ref = reference.astype(np.float64)
    cand = candidate.astype(np.float64)
    if ref.ndim == 3:
        ref = ref[..., :3].mean(axis=-1)
    if cand.ndim == 3:
        cand = cand[..., :3].mean(axis=-1)

    k1, k2 = 0.01, 0.03
    c1 = (k1 * max_value) ** 2
    c2 = (k2 * max_value) ** 2

    kernel = _gaussian_kernel()
    mu_ref = _convolve2d_same(ref, kernel)
    mu_cand = _convolve2d_same(cand, kernel)

    mu_ref_sq = mu_ref ** 2
    mu_cand_sq = mu_cand ** 2
    mu_ref_cand = mu_ref * mu_cand

    sigma_ref_sq = _convolve2d_same(ref * ref, kernel) - mu_ref_sq
    sigma_cand_sq = _convolve2d_same(cand * cand, kernel) - mu_cand_sq
    sigma_ref_cand = _convolve2d_same(ref * cand, kernel) - mu_ref_cand

    numerator = (2 * mu_ref_cand + c1) * (2 * sigma_ref_cand + c2)
    denominator = (mu_ref_sq + mu_cand_sq + c1) * (sigma_ref_sq + sigma_cand_sq + c2)
    ssim_map = numerator / denominator

    return float(np.mean(ssim_map))


@dataclass
class VisualDiffReport:
    mse: float
    psnr: float
    ssim: float
    perceptual_error: float  # 1 - ssim, a simple perceptual-error proxy

    def within_tolerance(self, max_error: float) -> bool:
        return self.perceptual_error <= max_error


def compare_images(reference: np.ndarray, candidate: np.ndarray, max_value: float = 1.0) -> VisualDiffReport:
    s = ssim(reference, candidate, max_value)
    return VisualDiffReport(
        mse=mse(reference, candidate),
        psnr=psnr(reference, candidate, max_value),
        ssim=s,
        perceptual_error=1.0 - s,
    )


def geometric_error_fraction(reference_vertices: np.ndarray, candidate_vertices: np.ndarray,
                              bbox_diagonal: float) -> float:
    """RMS nearest-neighbour distance between two point sets, normalised by
    bounding-box diagonal, as used by the geometry simplification module."""
    from scipy.spatial import cKDTree

    if bbox_diagonal <= 0:
        return 0.0
    tree = cKDTree(candidate_vertices)
    distances, _ = tree.query(reference_vertices)
    rms = float(np.sqrt(np.mean(distances ** 2)))
    return rms / bbox_diagonal
