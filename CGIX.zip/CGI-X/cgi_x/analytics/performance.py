"""
The marginal-gain engine.

For every optimisation category CGI-X records a real (baseline, optimised)
wall-clock pair from `cgi_x.profiling.benchmark`. The *pipeline*-level gain
is never the naive sum of per-category percentages — it is derived from
the actual total baseline time vs actual total optimised time across every
stage that was measured, which is the only mathematically correct way to
combine percentage gains from stages of different absolute cost.

Also includes the cost engine: turning CPU-hours saved into an estimated
compute cost saving.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

from cgi_x.profiling.benchmark import ComparisonResult


@dataclass
class CategoryGain:
    category: str
    baseline_time: float
    optimized_time: float
    memory_change_fraction: float = 0.0

    @property
    def gain_fraction(self) -> float:
        if self.baseline_time <= 0:
            return 0.0
        return (self.baseline_time - self.optimized_time) / self.baseline_time

    @property
    def gain_percent(self) -> float:
        return self.gain_fraction * 100.0


class MarginalGainEngine:
    """Accumulates per-category (baseline, optimised) timings from real
    benchmarks and derives a mathematically correct aggregate pipeline
    gain — never additive percentage stacking."""

    def __init__(self):
        self._categories: Dict[str, CategoryGain] = {}

    def record(self, category: str, comparison: ComparisonResult) -> CategoryGain:
        entry = CategoryGain(
            category=category,
            baseline_time=comparison.baseline.median_wall_time,
            optimized_time=comparison.optimised.median_wall_time,
            memory_change_fraction=comparison.memory_change_fraction,
        )
        self._categories[category] = entry
        return entry

    def record_raw(self, category: str, baseline_time: float, optimized_time: float,
                    memory_change_fraction: float = 0.0) -> CategoryGain:
        entry = CategoryGain(category, baseline_time, optimized_time, memory_change_fraction)
        self._categories[category] = entry
        return entry

    def categories(self) -> List[CategoryGain]:
        return list(self._categories.values())

    @property
    def total_baseline_time(self) -> float:
        return sum(c.baseline_time for c in self._categories.values())

    @property
    def total_optimized_time(self) -> float:
        return sum(c.optimized_time for c in self._categories.values())

    @property
    def total_pipeline_gain_fraction(self) -> float:
        """The only correct aggregate: (sum baseline - sum optimised) / sum baseline.
        This is NOT the sum of the individual percentage gains."""
        total_baseline = self.total_baseline_time
        if total_baseline <= 0:
            return 0.0
        return (total_baseline - self.total_optimized_time) / total_baseline

    @property
    def total_pipeline_gain_percent(self) -> float:
        return self.total_pipeline_gain_fraction * 100.0

    def breakdown_report(self) -> str:
        lines = []
        for c in sorted(self._categories.values(), key=lambda c: -c.gain_fraction):
            lines.append(f"{c.category.upper():<22}{c.gain_percent:+.2f}%")
        lines.append("")
        lines.append(f"{'TOTAL PIPELINE GAIN':<22}{self.total_pipeline_gain_percent:+.2f}%")
        return "\n".join(lines)


@dataclass
class CostEstimate:
    baseline_hours: float
    optimized_hours: float
    hours_saved: float
    hourly_rate: float
    currency_symbol: str = "£"

    @property
    def savings(self) -> float:
        return self.hours_saved * self.hourly_rate

    def report(self) -> str:
        return (
            f"Baseline compute time:    {self.baseline_hours:,.1f} CPU-hours\n"
            f"CGI-X compute time:       {self.optimized_hours:,.1f} CPU-hours\n"
            f"Saved:                    {self.hours_saved:,.1f} CPU-hours\n"
            f"Estimated compute saving: {self.currency_symbol}{self.savings:,.2f}"
        )


class CostEngine:
    """Converts measured compute-time gains into estimated financial
    savings. `hourly_rate` should reflect the caller's actual cloud/render
    farm/electricity cost per compute-hour — CGI-X does not assume one."""

    def __init__(self, hourly_rate: float = 0.35, currency_symbol: str = "£"):
        self.hourly_rate = hourly_rate
        self.currency_symbol = currency_symbol

    def estimate(self, baseline_hours: float, optimized_hours: float) -> CostEstimate:
        return CostEstimate(
            baseline_hours=baseline_hours,
            optimized_hours=optimized_hours,
            hours_saved=baseline_hours - optimized_hours,
            hourly_rate=self.hourly_rate,
            currency_symbol=self.currency_symbol,
        )

    def estimate_from_gain(self, gain_engine: MarginalGainEngine, total_project_hours: float) -> CostEstimate:
        """Scale a small measured benchmark's gain fraction up to a
        project-scale compute-hour estimate."""
        gain_fraction = gain_engine.total_pipeline_gain_fraction
        optimized_hours = total_project_hours * (1 - gain_fraction)
        return self.estimate(total_project_hours, optimized_hours)
