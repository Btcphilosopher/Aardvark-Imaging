"""Report generation matching CGI-X's formatted-report conventions."""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

from cgi_x.analytics.performance import CostEstimate, MarginalGainEngine
from cgi_x.core.state import OptimizationRecord


@dataclass
class PerformanceReport:
    project: str
    baseline_seconds: float
    optimized_seconds: float
    memory_change_percent: float
    quality_change_percent: float
    cost_estimate: Optional[CostEstimate] = None

    @property
    def gain_percent(self) -> float:
        if self.baseline_seconds <= 0:
            return 0.0
        return (self.baseline_seconds - self.optimized_seconds) / self.baseline_seconds * 100.0

    def render(self) -> str:
        lines = [
            "CGI-X PERFORMANCE REPORT",
            "-" * 24,
            "",
            f"PROJECT: {self.project}",
            "",
            "BASELINE:",
            f"{self.baseline_seconds:,.2f} seconds",
            "",
            "OPTIMISED:",
            f"{self.optimized_seconds:,.2f} seconds",
            "",
            f"GAIN:",
            f"{self.gain_percent:.2f}%",
            "",
            "MEMORY:",
            f"{self.memory_change_percent:+.2f}%",
            "",
            "QUALITY CHANGE:",
            f"{self.quality_change_percent:.3f}%",
        ]
        if self.cost_estimate is not None:
            lines += ["", "ESTIMATED COMPUTE SAVING:", f"{self.cost_estimate.currency_symbol}{self.cost_estimate.savings:,.2f}"]
        return "\n".join(lines)


def build_report(project: str, gain_engine: MarginalGainEngine, quality_change_percent: float = 0.0,
                  cost_estimate: Optional[CostEstimate] = None) -> PerformanceReport:
    memory_changes = [c.memory_change_fraction for c in gain_engine.categories()]
    mean_memory_change = (sum(memory_changes) / len(memory_changes) * 100.0) if memory_changes else 0.0

    return PerformanceReport(
        project=project,
        baseline_seconds=gain_engine.total_baseline_time,
        optimized_seconds=gain_engine.total_optimized_time,
        memory_change_percent=mean_memory_change,
        quality_change_percent=quality_change_percent,
        cost_estimate=cost_estimate,
    )


def optimization_history_summary(records: List[OptimizationRecord]) -> str:
    if not records:
        return "No optimisation history recorded yet."
    accepted = [r for r in records if r.accepted]
    lines = [
        f"Optimisations evaluated: {len(records)}",
        f"Accepted:                {len(accepted)}",
        f"Rejected:                {len(records) - len(accepted)}",
    ]
    if accepted:
        avg_gain = sum(r.gain_fraction for r in accepted) / len(accepted) * 100
        lines.append(f"Average accepted gain:   {avg_gain:.2f}%")
    return "\n".join(lines)
