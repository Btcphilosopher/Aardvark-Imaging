"""Reusable linear algebra routines built on NumPy/SciPy, with a dense-vs-
sparse solver chooser that benchmarks rather than assumes."""

from __future__ import annotations

import numpy as np
import scipy.linalg as sla
import scipy.sparse as sp
import scipy.sparse.linalg as spla


def solve_dense(A: np.ndarray, b: np.ndarray) -> np.ndarray:
    return sla.solve(A, b, assume_a="gen")


def solve_sparse(A: sp.spmatrix, b: np.ndarray) -> np.ndarray:
    return spla.spsolve(A.tocsc(), b)


def sparsity(A: np.ndarray) -> float:
    """Fraction of zero entries."""
    return 1.0 - (np.count_nonzero(A) / A.size)


def auto_solve(A, b, sparsity_threshold: float = 0.7):
    """
    Choose a dense or sparse solver based on the actual sparsity of A.
    Sparse solvers only win once a matrix is sparse *and* large enough that
    the CSR/CSC construction overhead is repaid; below the threshold dense
    LAPACK routines are faster in practice.
    """
    dense = np.asarray(A) if not sp.issparse(A) else np.asarray(A.todense())
    if dense.shape[0] < 64:
        return solve_dense(dense, b)

    frac_zero = sparsity(dense)
    if frac_zero >= sparsity_threshold:
        sparse_A = sp.csr_matrix(dense)
        return solve_sparse(sparse_A, b)
    return solve_dense(dense, b)


def batched_matmul(matrices: np.ndarray, vectors: np.ndarray) -> np.ndarray:
    """Vectorised batch of (K,4,4)@(K,4) style products via einsum, avoiding
    a Python loop over K matrix-vector products."""
    return np.einsum("kij,kj->ki", matrices, vectors)


def condition_number(A: np.ndarray) -> float:
    return float(np.linalg.cond(A))
