"""Numerical integration and differentiation routines with a method
benchmark/selector, matching the "METHOD A vs METHOD B" pattern used
throughout CGI-X's numerical layer."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np
from scipy import integrate


_trapezoid = getattr(np, "trapezoid", None) or np.trapz  # np.trapz removed in NumPy 2.0+


def trapezoid_integrate(f: Callable, a: float, b: float, n: int = 1000) -> float:
    xs = np.linspace(a, b, n)
    ys = f(xs)
    return float(_trapezoid(ys, xs))


def simpson_integrate(f: Callable, a: float, b: float, n: int = 1000) -> float:
    if n % 2 == 0:
        n += 1
    xs = np.linspace(a, b, n)
    ys = f(xs)
    return float(integrate.simpson(ys, x=xs))


def adaptive_quad_integrate(f: Callable, a: float, b: float) -> float:
    value, _ = integrate.quad(f, a, b)
    return float(value)


def central_difference(f: Callable, x: np.ndarray, h: float = 1e-5) -> np.ndarray:
    """Vectorised central-difference derivative estimate."""
    return (f(x + h) - f(x - h)) / (2 * h)


@dataclass
class IntegrationChoice:
    method: str
    value: float
    error_vs_reference: float
    wall_time: float


def select_integration_method(f: Callable, a: float, b: float, reference: float = None,
                               max_error: float = 1e-4) -> IntegrationChoice:
    """Benchmark trapezoid/Simpson/adaptive quadrature and pick the fastest
    one meeting the accuracy tolerance against a supplied reference (or
    against `adaptive_quad_integrate` if no reference is given)."""
    from cgi_x.profiling.benchmark import benchmark

    ref = reference if reference is not None else adaptive_quad_integrate(f, a, b)

    candidates = []
    for name, fn, args, kwargs in [
        ("trapezoid", trapezoid_integrate, (f, a, b), {}),
        ("simpson", simpson_integrate, (f, a, b), {}),
        ("adaptive_quad", adaptive_quad_integrate, (f, a, b), {}),
    ]:
        bench = benchmark(fn, *args, repeats=5, warmup=1, label=name, **kwargs)
        value = fn(*args, **kwargs)
        error = abs(value - ref) / (abs(ref) or 1.0)
        candidates.append(IntegrationChoice(name, value, error, bench.median_wall_time))

    eligible = [c for c in candidates if c.error_vs_reference <= max_error] or candidates
    return min(eligible, key=lambda c: c.wall_time)
