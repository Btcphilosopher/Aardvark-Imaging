"""Interpolation routines with a benchmarked method selector.

METHOD A: linear         accuracy = baseline, runtime = fastest
METHOD B: cubic spline    accuracy = higher on curved data, runtime slower

CGI-X measures both on the actual data and picks the cheaper method that
still meets the caller's declared accuracy tolerance, rather than
defaulting to the fanciest available algorithm.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np
from scipy.interpolate import CubicSpline, interp1d


@dataclass
class MethodChoice:
    method: str
    runtime_ratio: float   # relative to the slowest candidate considered
    accuracy: float        # 1 - normalised RMS error against a held-out reference
    fn: Callable


def linear_interpolate(x, y, x_new):
    return np.interp(x_new, x, y)


def cubic_interpolate(x, y, x_new):
    spline = CubicSpline(x, y)
    return spline(x_new)


def select_interpolation_method(x, y, x_new, reference_y=None, min_accuracy: float = 0.999) -> MethodChoice:
    """
    Benchmark linear vs cubic interpolation on the given data. If a
    `reference_y` (ground truth at x_new) is supplied, compute real
    accuracy for each method and pick the fastest one that clears
    `min_accuracy`. Falls back to linear if neither reference nor a clear
    winner is available (linear is the safe, cheap default).
    """
    from cgi_x.profiling.benchmark import benchmark

    linear_bench = benchmark(linear_interpolate, x, y, x_new, repeats=5, warmup=1, label="linear")
    cubic_bench = benchmark(cubic_interpolate, x, y, x_new, repeats=5, warmup=1, label="cubic")

    slowest = max(linear_bench.median_wall_time, cubic_bench.median_wall_time) or 1e-9

    def _accuracy(fn):
        if reference_y is None:
            return 1.0
        pred = fn(x, y, x_new)
        rms = np.sqrt(np.mean((pred - reference_y) ** 2))
        scale = np.max(np.abs(reference_y)) or 1.0
        return float(max(0.0, 1.0 - rms / scale))

    candidates = [
        MethodChoice("linear", linear_bench.median_wall_time / slowest, _accuracy(linear_interpolate), linear_interpolate),
        MethodChoice("cubic", cubic_bench.median_wall_time / slowest, _accuracy(cubic_interpolate), cubic_interpolate),
    ]

    eligible = [c for c in candidates if c.accuracy >= min_accuracy] or candidates
    return min(eligible, key=lambda c: c.runtime_ratio)
