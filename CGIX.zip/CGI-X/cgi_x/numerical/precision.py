"""
Precision/memory tradeoff helpers: float64 -> float32 downcasting with
measured error, used by the memory optimiser for "compact numerical
representations" where the tolerance allows it.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class PrecisionReport:
    original_dtype: str
    reduced_dtype: str
    memory_change_fraction: float
    max_relative_error: float
    within_tolerance: bool


def evaluate_precision_reduction(array: np.ndarray, target_dtype=np.float32,
                                  max_relative_error: float = 1e-4) -> PrecisionReport:
    original = np.asarray(array)
    reduced = original.astype(target_dtype)
    back = reduced.astype(original.dtype)

    denom = np.maximum(np.abs(original), 1e-12)
    rel_error = np.max(np.abs(back - original) / denom)

    mem_change = (reduced.nbytes - original.nbytes) / original.nbytes if original.nbytes else 0.0

    return PrecisionReport(
        original_dtype=str(original.dtype),
        reduced_dtype=str(reduced.dtype),
        memory_change_fraction=float(mem_change),
        max_relative_error=float(rel_error),
        within_tolerance=bool(rel_error <= max_relative_error),
    )


def downcast_if_safe(array: np.ndarray, target_dtype=np.float32,
                      max_relative_error: float = 1e-4):
    """Return (possibly downcast array, PrecisionReport). Only downcasts
    when the measured relative error is within tolerance."""
    report = evaluate_precision_reduction(array, target_dtype, max_relative_error)
    if report.within_tolerance:
        return array.astype(target_dtype), report
    return array, report
