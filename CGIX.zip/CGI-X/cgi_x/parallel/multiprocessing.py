"""
Process-based parallel map helpers, plus a vectorised-vs-parallel chooser.

For most CGI-X numerical work the honest answer is "vectorise with NumPy",
which is faster than multiprocessing for anything that fits comfortably
in memory (no pickling / IPC overhead). `auto_parallel_map` benchmarks
a small sample to decide whether spreading the full job across processes
is actually worth the fork/pickle overhead, rather than assuming so.
"""

from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor
from typing import Callable, List, Sequence

from cgi_x.profiling.benchmark import benchmark


def process_map(func: Callable, items: Sequence, max_workers: int = None) -> List:
    """Plain process-pool map; picks up all results, preserving order."""
    with ProcessPoolExecutor(max_workers=max_workers) as ex:
        return list(ex.map(func, items))


def auto_parallel_map(func: Callable, items: Sequence, max_workers: int = None,
                       sample_size: int = 8) -> List:
    """
    Decide, via a real measured sample, whether process-based parallelism
    beats serial execution for this workload, then run the full job with
    the winning strategy. Never assumes multiprocessing is a win.
    """
    if len(items) <= sample_size:
        sample = list(items)
    else:
        step = max(1, len(items) // sample_size)
        sample = list(items)[::step][:sample_size]

    serial_bench = benchmark(lambda: [func(i) for i in sample], repeats=1, warmup=0,
                              label="serial_sample")
    parallel_bench = benchmark(lambda: process_map(func, sample, max_workers=max_workers),
                                repeats=1, warmup=0, label="parallel_sample")

    serial_per_item = serial_bench.mean_wall_time / max(1, len(sample))
    parallel_per_item = parallel_bench.mean_wall_time / max(1, len(sample))

    if parallel_per_item < serial_per_item:
        return process_map(func, items, max_workers=max_workers)
    return [func(i) for i in items]
