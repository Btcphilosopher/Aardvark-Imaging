"""
Task-graph representation and topological execution planning.

    TASK A
     ├── TASK B
     ├── TASK C
     │
     └── TASK D
           ↓
         TASK E

CGI-X represents a pipeline as a DAG of `Task` objects, resolves the
dependency order, and groups independent tasks into "waves" that can run
concurrently.
"""

from __future__ import annotations

from collections import defaultdict, deque
from typing import Dict, List

from cgi_x.core.task import Task


class CycleError(ValueError):
    pass


class TaskGraph:
    def __init__(self):
        self._tasks: Dict[str, Task] = {}

    def add(self, task: Task) -> "TaskGraph":
        if task.name in self._tasks:
            raise ValueError(f"duplicate task name: {task.name}")
        self._tasks[task.name] = task
        return self

    def __contains__(self, name: str) -> bool:
        return name in self._tasks

    def __len__(self) -> int:
        return len(self._tasks)

    def get(self, name: str) -> Task:
        return self._tasks[name]

    def tasks(self) -> List[Task]:
        return list(self._tasks.values())

    def _validate_dependencies(self) -> None:
        for task in self._tasks.values():
            for dep in task.depends_on:
                if dep not in self._tasks:
                    raise ValueError(f"task '{task.name}' depends on unknown task '{dep}'")

    def execution_waves(self) -> List[List[str]]:
        """
        Kahn's algorithm: group tasks into ordered "waves" where every task
        in a wave has all its dependencies satisfied by earlier waves. Tasks
        within a wave are mutually independent and safe to execute
        concurrently.
        """
        self._validate_dependencies()

        in_degree = {name: len(task.depends_on) for name, task in self._tasks.items()}
        dependents = defaultdict(list)
        for name, task in self._tasks.items():
            for dep in task.depends_on:
                dependents[dep].append(name)

        frontier = deque(sorted(name for name, deg in in_degree.items() if deg == 0))
        waves: List[List[str]] = []
        visited = 0

        while frontier:
            wave = sorted(frontier)
            waves.append(wave)
            next_frontier = deque()
            for name in wave:
                visited += 1
                for dependent in dependents[name]:
                    in_degree[dependent] -= 1
                    if in_degree[dependent] == 0:
                        next_frontier.append(dependent)
            frontier = next_frontier

        if visited != len(self._tasks):
            remaining = set(self._tasks) - {n for wave in waves for n in wave}
            raise CycleError(f"cycle detected among tasks: {sorted(remaining)}")

        return waves

    def critical_path_length(self) -> int:
        """Number of sequential waves required — the longest dependency chain."""
        return len(self.execution_waves())
