"""
Parallel scheduler: executes a `TaskGraph` wave-by-wave, running every
task within a wave concurrently on a thread pool (NumPy/SciPy calls
release the GIL for their heavy C loops, so thread-based concurrency is
effective for the numerical workloads CGI-X targets; pure-Python-bound
tasks can still opt into process-based execution via `WorkerPool`).
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any, Dict, List

from cgi_x.core.task import Task, TaskStatus
from cgi_x.parallel.task_graph import TaskGraph
from cgi_x.profiling.profiler import Profiler


@dataclass
class ScheduleReport:
    waves: List[List[str]] = field(default_factory=list)
    results: Dict[str, Any] = field(default_factory=dict)
    wall_time: float = 0.0
    failed: List[str] = field(default_factory=list)


class ParallelScheduler:
    def __init__(self, max_workers: int = None):
        self.max_workers = max_workers

    def run(self, graph: TaskGraph) -> ScheduleReport:
        waves = graph.execution_waves()
        results: Dict[str, Any] = {}
        failed: List[str] = []

        with Profiler("scheduler.run") as prof:
            with ThreadPoolExecutor(max_workers=self.max_workers) as pool:
                for wave in waves:
                    futures = {}
                    for name in wave:
                        task = graph.get(name)
                        dep_results = {dep: results[dep] for dep in task.depends_on if dep in results}
                        futures[name] = pool.submit(task.run, dep_results)
                    for name, future in futures.items():
                        task_result = future.result()
                        if task_result.status == TaskStatus.FAILED:
                            failed.append(name)
                        results[name] = task_result.value

        return ScheduleReport(waves=waves, results=results, wall_time=prof.sample.wall_time, failed=failed)
