"""Thread/process pool wrappers used by the scheduler and optimisers."""

from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
from typing import Callable, Iterable, List, Optional


class WorkerPool:
    """
    A small wrapper unifying thread- and process-based execution behind one
    interface, so higher layers (scheduler, optimisers) don't need to care
    which backend is in use.

    Use `kind="thread"` for I/O-bound or NumPy-releases-the-GIL workloads
    (most geometry/numerical work with vectorised NumPy already releases
    the GIL during the heavy C loops). Use `kind="process"` for genuinely
    CPU-bound pure-Python work that needs true parallelism.
    """

    def __init__(self, max_workers: Optional[int] = None, kind: str = "thread"):
        self.max_workers = max_workers
        self.kind = kind
        self._executor = None

    def __enter__(self) -> "WorkerPool":
        cls = ThreadPoolExecutor if self.kind == "thread" else ProcessPoolExecutor
        self._executor = cls(max_workers=self.max_workers)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        if self._executor is not None:
            self._executor.shutdown(wait=True)
        return False

    def map(self, func: Callable, items: Iterable) -> List:
        assert self._executor is not None, "WorkerPool must be used as a context manager"
        return list(self._executor.map(func, items))

    def submit_all(self, func: Callable, items: Iterable):
        assert self._executor is not None, "WorkerPool must be used as a context manager"
        return [self._executor.submit(func, item) for item in items]
