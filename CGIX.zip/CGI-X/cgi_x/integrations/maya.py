"""
Maya adapter.

Runs only inside Maya's `mayapy`/embedded Python interpreter (where
`maya.cmds` / `maya.api.OpenMaya` are importable). Uses the Maya Python
API 2.0 (`maya.api.OpenMaya`) for fast, vectorised-friendly mesh data
access rather than the slower `cmds.polyEvaluate`-style per-element
queries.
"""

from __future__ import annotations

import numpy as np

from cgi_x.geometry.mesh import Mesh
from cgi_x.integrations.generic import BaseAdapter
from cgi_x.rendering.scene import Scene, SceneObject


class MayaAdapter(BaseAdapter):
    name = "maya"

    def is_available(self) -> bool:
        try:
            import maya.cmds  # noqa: F401
            return True
        except ImportError:
            return False

    def pull_scene(self) -> Scene:
        import maya.api.OpenMaya as om
        import maya.cmds as cmds

        scene = Scene(name=cmds.file(q=True, sceneName=True, shortName=True) or "maya_scene")

        for transform in cmds.ls(type="mesh", noIntermediate=True) or []:
            shape_dag = om.MSelectionList().add(transform).getDagPath(0)
            mesh_fn = om.MFnMesh(shape_dag)

            points = mesh_fn.getPoints(om.MSpace.kWorld)
            vertices = np.array([[p.x, p.y, p.z] for p in points], dtype=np.float64)

            triangle_counts, triangle_vertices = mesh_fn.getTriangles()
            faces = np.array(triangle_vertices, dtype=np.int64).reshape(-1, 3)

            transform_name = cmds.listRelatives(transform, parent=True, fullPath=True)[0]
            matrix = cmds.xform(transform_name, q=True, matrix=True, worldSpace=True)
            transform_matrix = np.array(matrix, dtype=np.float64).reshape(4, 4).T

            mesh = Mesh(vertices=vertices, faces=faces, name=transform)
            visible = cmds.getAttr(f"{transform_name}.visibility")
            scene.add_object(SceneObject(name=transform, mesh=mesh, transform=transform_matrix, visible=bool(visible)))

        return scene

    def push_scene(self, scene: Scene) -> None:
        import maya.api.OpenMaya as om
        import maya.cmds as cmds

        for name, scene_obj in scene.objects.items():
            if not cmds.objExists(name):
                continue

            shape_dag = om.MSelectionList().add(name).getDagPath(0)
            mesh_fn = om.MFnMesh(shape_dag)

            points = om.MPointArray([om.MPoint(*v) for v in scene_obj.mesh.vertices])
            mesh_fn.setPoints(points, om.MSpace.kWorld)

            transform_name = cmds.listRelatives(name, parent=True, fullPath=True)[0]
            cmds.setAttr(f"{transform_name}.visibility", scene_obj.visible)
