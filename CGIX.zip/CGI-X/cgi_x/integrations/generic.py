"""
Base adapter interface and the fully-functional generic adapter.

Every DCC adapter (Blender/Maya/Houdini/Unreal) implements this same
interface: pull a `Scene` out of the host application, and push an
optimised `Scene` back in. This keeps host-application-specific logic
entirely inside the adapters — the core engine never imports `bpy`,
`maya.cmds`, `hou` or `unreal` directly.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional

from cgi_x.rendering.scene import Scene


class BaseAdapter(ABC):
    """Common interface implemented by every host-application adapter."""

    name: str = "base"

    @abstractmethod
    def is_available(self) -> bool:
        """Whether this adapter's host application is importable/running
        in the current process."""

    @abstractmethod
    def pull_scene(self) -> Scene:
        """Read the host application's current scene into a CGI-X `Scene`."""

    @abstractmethod
    def push_scene(self, scene: Scene) -> None:
        """Write an optimised CGI-X `Scene` back into the host application."""

    def optimize_in_place(self, optimizer, constraints: Optional[dict] = None):
        """Convenience: pull -> optimise -> push, returning the result."""
        if not self.is_available():
            raise RuntimeError(f"{self.name} adapter: host application is not available in this process")
        scene = self.pull_scene()
        result = optimizer.optimize(scene, constraints=constraints)
        self.push_scene(result.scene)
        return result


class GenericAdapter(BaseAdapter):
    """
    Adapter for plain-Python / non-DCC use: the 'scene' is already a
    CGI-X `Scene` object, so pull/push are identity operations. This is
    the fully testable, dependency-free adapter used by the test suite,
    CLI, and any custom pipeline glue code that builds `Scene` objects
    directly (batch render farms, asset-validation services, etc.).
    """

    name = "generic"

    def __init__(self, scene: Optional[Scene] = None):
        self._scene = scene

    def is_available(self) -> bool:
        return True

    def pull_scene(self) -> Scene:
        if self._scene is None:
            raise RuntimeError("GenericAdapter has no scene set; pass one to the constructor "
                                "or call `set_scene()` first")
        return self._scene

    def push_scene(self, scene: Scene) -> None:
        self._scene = scene

    def set_scene(self, scene: Scene) -> None:
        self._scene = scene
