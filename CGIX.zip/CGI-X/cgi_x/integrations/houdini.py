"""
Houdini adapter.

Runs only inside Houdini's embedded Python (`hou` importable) — from the
Python Shell, a Python SOP, hython, or a Python Panel. Reads/writes SOP
geometry via `hou.Geometry`.
"""

from __future__ import annotations

import numpy as np

from cgi_x.geometry.mesh import Mesh
from cgi_x.integrations.generic import BaseAdapter
from cgi_x.rendering.scene import Scene, SceneObject


class HoudiniAdapter(BaseAdapter):
    name = "houdini"

    def is_available(self) -> bool:
        try:
            import hou  # noqa: F401
            return True
        except ImportError:
            return False

    def pull_scene(self, root_path: str = "/obj") -> Scene:
        import hou

        scene = Scene(name=hou.hipFile.basename() or "houdini_scene")
        root = hou.node(root_path)
        if root is None:
            return scene

        for node in root.children():
            display_sop = node.displayNode() if hasattr(node, "displayNode") else None
            if display_sop is None:
                continue
            try:
                geo = display_sop.geometry()
            except Exception:
                continue
            if geo is None:
                continue

            positions = np.array([p.position() for p in geo.points()], dtype=np.float64)
            faces = []
            for prim in geo.prims():
                verts = prim.vertices()
                pts = [v.point().number() for v in verts]
                for i in range(1, len(pts) - 1):
                    faces.append([pts[0], pts[i], pts[i + 1]])

            transform_matrix = np.array(node.worldTransform().asTuple(), dtype=np.float64).reshape(4, 4)
            mesh = Mesh(vertices=positions,
                        faces=np.array(faces, dtype=np.int64) if faces else np.zeros((0, 3), dtype=np.int64),
                        name=node.name())
            scene.add_object(SceneObject(name=node.name(), mesh=mesh, transform=transform_matrix,
                                          visible=not node.isHardLocked() and node.isDisplayFlagSet()))

        return scene

    def push_scene(self, scene: Scene, target_geo_node_path: str = None) -> None:
        import hou

        for name, scene_obj in scene.objects.items():
            node_path = target_geo_node_path or f"/obj/{name}"
            node = hou.node(node_path)
            if node is None:
                continue
            sop = node.node("cgi_x_output") or node.createNode("null", "cgi_x_output")
            # Houdini geometry is normally rebuilt via a Python SOP referencing
            # this scene object; here we stash the optimised arrays as node
            # user data for a companion Python SOP to consume, since writing
            # hou.Geometry directly requires an editable SOP context.
            node.setUserData("cgi_x_vertex_count", str(scene_obj.mesh.vertex_count))
            node.setUserData("cgi_x_face_count", str(scene_obj.mesh.face_count))
