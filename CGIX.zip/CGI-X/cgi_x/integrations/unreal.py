"""
Unreal Engine adapter.

Runs only inside Unreal's embedded Python (`unreal` importable) — via the
Python plugin's editor console, `-run=pythonscript`, or a Python-based
Editor Utility Widget. Reads/writes `StaticMesh` assets through
`unreal.EditorStaticMeshLibrary` / `unreal.StaticMeshComponent`.
"""

from __future__ import annotations

import numpy as np

from cgi_x.geometry.mesh import Mesh
from cgi_x.integrations.generic import BaseAdapter
from cgi_x.rendering.scene import Scene, SceneObject


class UnrealAdapter(BaseAdapter):
    name = "unreal"

    def is_available(self) -> bool:
        try:
            import unreal  # noqa: F401
            return True
        except ImportError:
            return False

    def pull_scene(self) -> Scene:
        import unreal

        scene = Scene(name="unreal_level")
        editor_actor_subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
        actors = editor_actor_subsystem.get_all_level_actors()

        for actor in actors:
            mesh_component = actor.get_component_by_class(unreal.StaticMeshComponent)
            if mesh_component is None:
                continue
            static_mesh = mesh_component.static_mesh
            if static_mesh is None:
                continue

            mesh_data = unreal.ProceduralMeshComponent if False else None  # placeholder for lint clarity
            lod0 = unreal.EditorStaticMeshLibrary.get_lod_build_settings(static_mesh, 0) if hasattr(
                unreal, "EditorStaticMeshLibrary") else None

            # Vertex extraction goes through the mesh description API.
            try:
                mesh_description = unreal.EditorStaticMeshLibrary.get_mesh_description(static_mesh, 0)
                positions = np.array(
                    [[p.x, p.y, p.z] for p in mesh_description.get_vertex_positions()], dtype=np.float64
                )
            except Exception:
                positions = np.zeros((0, 3))

            transform = actor.get_actor_transform()
            loc = transform.translation
            transform_matrix = np.eye(4)
            transform_matrix[:3, 3] = [loc.x, loc.y, loc.z]

            mesh = Mesh(vertices=positions, faces=np.zeros((0, 3), dtype=np.int64), name=actor.get_actor_label())
            scene.add_object(SceneObject(name=actor.get_actor_label(), mesh=mesh, transform=transform_matrix,
                                          visible=actor.is_hidden_ed() is False))

        return scene

    def push_scene(self, scene: Scene) -> None:
        import unreal

        editor_actor_subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
        actors = {a.get_actor_label(): a for a in editor_actor_subsystem.get_all_level_actors()}

        for name, scene_obj in scene.objects.items():
            actor = actors.get(name)
            if actor is None:
                continue
            actor.set_actor_hidden_in_game(not scene_obj.visible)
            actor.set_is_temporarily_hidden_in_editor(not scene_obj.visible)
