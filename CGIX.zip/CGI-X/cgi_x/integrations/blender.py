"""
Blender adapter.

Runs only inside Blender's embedded Python interpreter (where `bpy` is
importable) — e.g. from a Blender script, an add-on's operator, or
Blender's `--python` CLI flag. Converts between `bpy` mesh objects and
CGI-X `Scene`/`Mesh` objects using Blender's own evaluated-mesh API so
modifiers are respected.
"""

from __future__ import annotations

import numpy as np

from cgi_x.geometry.mesh import Mesh
from cgi_x.integrations.generic import BaseAdapter
from cgi_x.rendering.scene import Scene, SceneObject


class BlenderAdapter(BaseAdapter):
    name = "blender"

    def is_available(self) -> bool:
        try:
            import bpy  # noqa: F401
            return True
        except ImportError:
            return False

    def pull_scene(self) -> Scene:
        import bpy

        scene = Scene(name=bpy.context.scene.name)
        depsgraph = bpy.context.evaluated_depsgraph_get()

        for obj in bpy.context.scene.objects:
            if obj.type != "MESH":
                continue
            eval_obj = obj.evaluated_get(depsgraph)
            mesh_data = eval_obj.to_mesh()
            mesh_data.calc_loop_triangles()

            vertices = np.array([v.co[:] for v in mesh_data.vertices], dtype=np.float64)
            faces = np.array([list(tri.vertices) for tri in mesh_data.loop_triangles], dtype=np.int64)

            transform = np.array(obj.matrix_world, dtype=np.float64)
            mesh = Mesh(vertices=vertices, faces=faces if len(faces) else np.zeros((0, 3), dtype=np.int64),
                        name=obj.name)
            scene.add_object(SceneObject(name=obj.name, mesh=mesh, transform=transform, visible=not obj.hide_render))

            eval_obj.to_mesh_clear()

        return scene

    def push_scene(self, scene: Scene) -> None:
        import bmesh
        import bpy

        for name, scene_obj in scene.objects.items():
            bpy_obj = bpy.data.objects.get(name)
            if bpy_obj is None or bpy_obj.type != "MESH":
                continue

            bm = bmesh.new()
            for v in scene_obj.mesh.vertices:
                bm.verts.new(v)
            bm.verts.ensure_lookup_table()
            for tri in scene_obj.mesh.faces:
                try:
                    bm.faces.new([bm.verts[i] for i in tri])
                except ValueError:
                    continue  # duplicate face, skip

            bm.to_mesh(bpy_obj.data)
            bm.free()
            bpy_obj.data.update()
            bpy_obj.hide_render = not scene_obj.visible
