"""Light types used for scene analysis (a scene with many overlapping
lights is a common render-cost hotspot worth flagging)."""

from __future__ import annotations

import enum
from dataclasses import dataclass, field

import numpy as np


class LightType(enum.Enum):
    POINT = "point"
    DIRECTIONAL = "directional"
    AREA = "area"
    SPOT = "spot"


@dataclass
class Light:
    name: str
    type: LightType
    position: np.ndarray = field(default_factory=lambda: np.zeros(3))
    intensity: float = 1.0
    radius: float = 10.0  # effective falloff radius, for point/spot
    casts_shadows: bool = True
