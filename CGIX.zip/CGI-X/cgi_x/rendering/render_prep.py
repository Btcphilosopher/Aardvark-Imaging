"""
Render-preparation: build an efficient render representation from a Scene
without implementing the final renderer itself — visibility culling,
transform batching/instancing detection, and dependency ordering.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

import numpy as np

from cgi_x.geometry.transforms import redundant_transform_pairs
from cgi_x.rendering.scene import Scene, SceneObject


@dataclass
class RenderPackage:
    visible_objects: List[str] = field(default_factory=list)
    culled_objects: List[str] = field(default_factory=list)
    instance_groups: Dict[str, List[str]] = field(default_factory=dict)
    total_visible_faces: int = 0


def prepare_scene(scene: Scene) -> RenderPackage:
    visible = [name for name, obj in scene.objects.items() if obj.visible]
    culled = [name for name, obj in scene.objects.items() if not obj.visible]

    if scene.camera is not None and visible:
        centers = np.array([
            (scene.objects[n].mesh.bounding_box[0] + scene.objects[n].mesh.bounding_box[1]) / 2
            for n in visible
        ])
        radii = np.array([scene.objects[n].mesh.bounding_diagonal / 2 for n in visible])
        mask = scene.camera.frustum_cull(centers, radii)
        newly_culled = [n for n, keep in zip(visible, mask) if not keep]
        visible = [n for n, keep in zip(visible, mask) if keep]
        culled = culled + newly_culled

    transforms = {name: scene.objects[name].transform for name in visible}
    duplicate_pairs = redundant_transform_pairs(transforms)
    instance_groups: Dict[str, List[str]] = {}
    for a, b in duplicate_pairs:
        instance_groups.setdefault(a, [a]).append(b)

    total_faces = sum(scene.objects[n].mesh.face_count for n in visible)

    return RenderPackage(
        visible_objects=visible,
        culled_objects=culled,
        instance_groups=instance_groups,
        total_visible_faces=total_faces,
    )
