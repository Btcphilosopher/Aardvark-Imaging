"""Scene container: objects, transforms, lights, materials, camera. This is
the shape CGI-X's optimisers, analysers and adapters all operate on
regardless of which DCC application produced it."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np

from cgi_x.geometry.mesh import Mesh
from cgi_x.rendering.camera import Camera
from cgi_x.rendering.lights import Light
from cgi_x.rendering.materials import Material


@dataclass
class SceneObject:
    name: str
    mesh: Mesh
    transform: np.ndarray = field(default_factory=lambda: np.eye(4))
    material: Optional[Material] = None
    visible: bool = True
    subdivision_level: int = 0


@dataclass
class Scene:
    name: str = "scene"
    objects: Dict[str, SceneObject] = field(default_factory=dict)
    lights: Dict[str, Light] = field(default_factory=dict)
    camera: Optional[Camera] = None

    def add_object(self, obj: SceneObject) -> "Scene":
        self.objects[obj.name] = obj
        return self

    def add_light(self, light: Light) -> "Scene":
        self.lights[light.name] = light
        return self

    def total_vertex_count(self) -> int:
        return sum(o.mesh.vertex_count for o in self.objects.values())

    def total_face_count(self) -> int:
        return sum(o.mesh.face_count for o in self.objects.values())

    def total_memory_bytes(self) -> int:
        return sum(o.mesh.memory_bytes() for o in self.objects.values())

    def fingerprint(self) -> tuple:
        """A cheap, deterministic fingerprint used as a cache key basis —
        not a full content hash (that would defeat the point of avoiding
        re-evaluation), but sensitive to structural/topology changes."""
        return tuple(sorted(
            (name, obj.mesh.vertex_count, obj.mesh.face_count, obj.visible,
             round(float(np.sum(obj.transform)), 6))
            for name, obj in self.objects.items()
        ))
