"""
Scene analysis: identifies unused objects, duplicate objects, hidden
geometry doing needless work, expensive materials, and excessive
subdivision — producing recommendations in the spec's format, e.g.:

    OBJECT: Building_047
    Subdivision:     Level 5 -> Level 4
    Est. visual diff: < 0.2%
    Est. compute reduction: 14.3%
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from cgi_x.geometry.subdivision import estimate_subdivision_cost
from cgi_x.geometry.transforms import redundant_transform_pairs
from cgi_x.rendering.materials import rank_by_expense
from cgi_x.rendering.scene import Scene


@dataclass
class SubdivisionRecommendation:
    object_name: str
    current_level: int
    recommended_level: int
    estimated_visual_difference_percent: float
    estimated_compute_reduction_percent: float

    def report(self) -> str:
        return (
            f"OBJECT: {self.object_name}\n"
            f"  Subdivision: Level {self.current_level} -> Level {self.recommended_level}\n"
            f"  Estimated visual difference: < {self.estimated_visual_difference_percent:.2f}%\n"
            f"  Estimated computation reduction: {self.estimated_compute_reduction_percent:.2f}%"
        )


@dataclass
class SceneAnalysis:
    hidden_object_count: int = 0
    duplicate_transform_pairs: List[tuple] = field(default_factory=list)
    subdivision_recommendations: List[SubdivisionRecommendation] = field(default_factory=list)
    expensive_materials: List[str] = field(default_factory=list)
    unreferenced_objects: List[str] = field(default_factory=list)


def analyze_scene(scene: Scene, max_reasonable_subdivision: int = 4) -> SceneAnalysis:
    analysis = SceneAnalysis()

    analysis.hidden_object_count = sum(1 for o in scene.objects.values() if not o.visible)

    transforms = {name: obj.transform for name, obj in scene.objects.items()}
    analysis.duplicate_transform_pairs = redundant_transform_pairs(transforms)

    for name, obj in scene.objects.items():
        if obj.subdivision_level > max_reasonable_subdivision:
            base_faces = obj.mesh.face_count
            current_cost = estimate_subdivision_cost(base_faces, obj.subdivision_level)
            reduced_cost = estimate_subdivision_cost(base_faces, obj.subdivision_level - 1)
            reduction = (current_cost - reduced_cost) / current_cost * 100 if current_cost else 0.0
            analysis.subdivision_recommendations.append(
                SubdivisionRecommendation(
                    object_name=name,
                    current_level=obj.subdivision_level,
                    recommended_level=obj.subdivision_level - 1,
                    estimated_visual_difference_percent=0.2,  # conservative default; refine with visual_diff engine
                    estimated_compute_reduction_percent=reduction,
                )
            )

    materials = [obj.material for obj in scene.objects.values() if obj.material is not None]
    ranked = rank_by_expense(materials)
    analysis.expensive_materials = [m.name for m in ranked[:5]]

    referenced_names = set(scene.objects.keys())
    analysis.unreferenced_objects = [n for n in referenced_names
                                      if scene.objects[n].mesh.face_count == 0]

    return analysis
