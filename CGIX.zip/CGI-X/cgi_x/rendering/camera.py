"""Camera: view/projection matrices and frustum-culling test."""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


@dataclass
class Camera:
    position: np.ndarray = field(default_factory=lambda: np.array([0.0, 0.0, 5.0]))
    target: np.ndarray = field(default_factory=lambda: np.array([0.0, 0.0, 0.0]))
    up: np.ndarray = field(default_factory=lambda: np.array([0.0, 1.0, 0.0]))
    fov_degrees: float = 50.0
    aspect: float = 16 / 9
    near: float = 0.1
    far: float = 1000.0

    def view_matrix(self) -> np.ndarray:
        forward = self.target - self.position
        forward = forward / (np.linalg.norm(forward) + 1e-12)
        right = np.cross(forward, self.up)
        right = right / (np.linalg.norm(right) + 1e-12)
        true_up = np.cross(right, forward)

        m = np.eye(4)
        m[0, :3] = right
        m[1, :3] = true_up
        m[2, :3] = -forward
        translate = np.eye(4)
        translate[:3, 3] = -self.position
        return m @ translate

    def projection_matrix(self) -> np.ndarray:
        f = 1.0 / np.tan(np.radians(self.fov_degrees) / 2)
        m = np.zeros((4, 4))
        m[0, 0] = f / self.aspect
        m[1, 1] = f
        m[2, 2] = (self.far + self.near) / (self.near - self.far)
        m[2, 3] = (2 * self.far * self.near) / (self.near - self.far)
        m[3, 2] = -1.0
        return m

    def view_projection_matrix(self) -> np.ndarray:
        return self.projection_matrix() @ self.view_matrix()

    def frustum_cull(self, bbox_centers: np.ndarray, bbox_radii: np.ndarray) -> np.ndarray:
        """Vectorised approximate sphere-frustum test: returns a boolean
        mask of which bounding spheres are (possibly) visible. Conservative
        (may keep a few borderline-invisible objects, never drops a
        visible one) so it never changes the rendered image."""
        vp = self.view_projection_matrix()
        homogeneous = np.hstack([bbox_centers, np.ones((bbox_centers.shape[0], 1))])
        clip = homogeneous @ vp.T
        w = np.abs(clip[:, 3]) + 1e-9

        visible = np.ones(len(bbox_centers), dtype=bool)
        for axis in range(3):
            visible &= (clip[:, axis] > -w - bbox_radii * 2) & (clip[:, axis] < w + bbox_radii * 2)
        return visible
