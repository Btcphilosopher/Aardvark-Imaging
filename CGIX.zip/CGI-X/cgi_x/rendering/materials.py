"""Material definitions and a cheap "expense score" heuristic used by
render-prep/analysis to flag disproportionately costly shaders."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List


@dataclass
class Material:
    name: str
    texture_count: int = 0
    has_subsurface_scattering: bool = False
    has_displacement: bool = False
    transparency: float = 0.0
    node_count: int = 1  # approximate shader graph complexity

    def expense_score(self) -> float:
        """A simple, transparent, deterministic heuristic (not learned):
        more textures/nodes and SSS/displacement raise evaluation cost."""
        score = 1.0 + 0.15 * self.texture_count + 0.05 * self.node_count
        if self.has_subsurface_scattering:
            score *= 2.2
        if self.has_displacement:
            score *= 1.6
        if self.transparency > 0:
            score *= 1.0 + 0.5 * self.transparency
        return score


def rank_by_expense(materials: List[Material]) -> List[Material]:
    return sorted(materials, key=lambda m: m.expense_score(), reverse=True)
