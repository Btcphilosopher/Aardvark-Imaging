"""
Core profiling primitives: wall-clock time, CPU time and memory, captured
around any block of work. Everything in CGI-X that claims a gain does so
by wrapping baseline and optimised code in a `Profiler` and comparing the
resulting `ProfileSample` objects — never by assumption.
"""

from __future__ import annotations

import time
import tracemalloc
from contextlib import ContextDecorator
from dataclasses import dataclass, field
from typing import Optional

try:
    import resource  # POSIX only
except ImportError:  # pragma: no cover
    resource = None


@dataclass
class ProfileSample:
    """A single measured execution."""

    label: str
    wall_time: float = 0.0          # seconds, time.perf_counter
    cpu_time: float = 0.0           # seconds, time.process_time
    peak_memory_bytes: int = 0      # tracemalloc peak during the block
    current_memory_bytes: int = 0   # tracemalloc current at block end
    max_rss_bytes: int = 0          # OS-reported peak resident set size
    metadata: dict = field(default_factory=dict)

    @property
    def serial_fraction(self) -> float:
        """CPU time / wall time. >1 implies multi-core parallel work happened."""
        if self.wall_time <= 0:
            return 0.0
        return self.cpu_time / self.wall_time

    def to_dict(self) -> dict:
        return {
            "label": self.label,
            "wall_time": self.wall_time,
            "cpu_time": self.cpu_time,
            "peak_memory_bytes": self.peak_memory_bytes,
            "current_memory_bytes": self.current_memory_bytes,
            "max_rss_bytes": self.max_rss_bytes,
            "metadata": self.metadata,
        }


class Profiler(ContextDecorator):
    """
    Measures wall time, CPU time and memory for a block of code.

        with Profiler("geometry.normals") as p:
            compute_normals(mesh)
        print(p.sample.wall_time)

    Can also be used as a decorator: `@Profiler("my.task")`.
    """

    def __init__(self, label: str = "block", track_memory: bool = True):
        self.label = label
        self.track_memory = track_memory
        self.sample: Optional[ProfileSample] = None
        self._wall_start = 0.0
        self._cpu_start = 0.0
        self._tracemalloc_started_here = False

    def __enter__(self) -> "Profiler":
        if self.track_memory and not tracemalloc.is_tracing():
            tracemalloc.start()
            self._tracemalloc_started_here = True
        elif self.track_memory:
            tracemalloc.reset_peak()

        self._cpu_start = time.process_time()
        self._wall_start = time.perf_counter()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        wall_elapsed = time.perf_counter() - self._wall_start
        cpu_elapsed = time.process_time() - self._cpu_start

        peak_mem = 0
        cur_mem = 0
        if self.track_memory and tracemalloc.is_tracing():
            cur_mem, peak_mem = tracemalloc.get_traced_memory()
            if self._tracemalloc_started_here:
                tracemalloc.stop()

        max_rss = 0
        if resource is not None:
            try:
                max_rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
            except Exception:
                max_rss = 0

        self.sample = ProfileSample(
            label=self.label,
            wall_time=wall_elapsed,
            cpu_time=cpu_elapsed,
            peak_memory_bytes=peak_mem,
            current_memory_bytes=cur_mem,
            max_rss_bytes=max_rss,
        )
        return False  # never suppress exceptions


def profile_call(func, *args, label: Optional[str] = None, **kwargs):
    """Profile a single call, returning (result, ProfileSample)."""
    with Profiler(label or getattr(func, "__name__", "call")) as p:
        result = func(*args, **kwargs)
    return result, p.sample
