"""
Benchmark harness: run a callable N times, discard warmup noise sensibly,
and compute robust statistics. Used to compare a baseline implementation
against an optimised one with real, repeated wall-clock measurements
rather than a single noisy sample.
"""

from __future__ import annotations

import statistics
from dataclasses import dataclass, field
from typing import Callable, List, Optional

from cgi_x.profiling.profiler import Profiler, ProfileSample


@dataclass
class BenchmarkResult:
    label: str
    samples: List[ProfileSample] = field(default_factory=list)

    @property
    def wall_times(self) -> List[float]:
        return [s.wall_time for s in self.samples]

    @property
    def mean_wall_time(self) -> float:
        return statistics.mean(self.wall_times) if self.samples else 0.0

    @property
    def median_wall_time(self) -> float:
        return statistics.median(self.wall_times) if self.samples else 0.0

    @property
    def stdev_wall_time(self) -> float:
        return statistics.pstdev(self.wall_times) if len(self.samples) > 1 else 0.0

    @property
    def min_wall_time(self) -> float:
        return min(self.wall_times) if self.samples else 0.0

    @property
    def mean_peak_memory(self) -> float:
        vals = [s.peak_memory_bytes for s in self.samples]
        return statistics.mean(vals) if vals else 0.0

    def to_dict(self) -> dict:
        return {
            "label": self.label,
            "mean_wall_time": self.mean_wall_time,
            "median_wall_time": self.median_wall_time,
            "stdev_wall_time": self.stdev_wall_time,
            "min_wall_time": self.min_wall_time,
            "mean_peak_memory": self.mean_peak_memory,
            "n": len(self.samples),
        }


def benchmark(
    func: Callable,
    *args,
    repeats: int = 5,
    warmup: int = 1,
    label: Optional[str] = None,
    **kwargs,
) -> BenchmarkResult:
    """Run `func(*args, **kwargs)` `repeats` times and collect statistics.

    `warmup` runs are executed first and discarded (JIT/caching/import
    effects), matching standard benchmarking practice.
    """
    name = label or getattr(func, "__name__", "benchmark")

    for _ in range(max(0, warmup)):
        func(*args, **kwargs)

    result = BenchmarkResult(label=name)
    for i in range(repeats):
        with Profiler(f"{name}[{i}]") as p:
            func(*args, **kwargs)
        result.samples.append(p.sample)
    return result


@dataclass
class ComparisonResult:
    baseline: BenchmarkResult
    optimised: BenchmarkResult

    @property
    def speed_gain_fraction(self) -> float:
        """Positive = optimised is faster. Uses median wall time (robust to outliers)."""
        b = self.baseline.median_wall_time
        o = self.optimised.median_wall_time
        if b <= 0:
            return 0.0
        return (b - o) / b

    @property
    def speed_gain_percent(self) -> float:
        return self.speed_gain_fraction * 100.0

    @property
    def speedup_factor(self) -> float:
        o = self.optimised.median_wall_time
        if o <= 0:
            return float("inf")
        return self.baseline.median_wall_time / o

    @property
    def memory_change_fraction(self) -> float:
        """Negative = optimised uses less memory."""
        b = self.baseline.mean_peak_memory
        o = self.optimised.mean_peak_memory
        if b <= 0:
            return 0.0
        return (o - b) / b

    @property
    def memory_change_percent(self) -> float:
        return self.memory_change_fraction * 100.0

    def is_statistically_faster(self, min_effect: float = 0.01) -> bool:
        """A crude but honest significance check: the optimised median must
        beat the baseline median by more than one baseline standard
        deviation (or `min_effect` fraction, whichever is larger)."""
        margin = max(self.baseline.stdev_wall_time, self.baseline.median_wall_time * min_effect)
        return (self.baseline.median_wall_time - self.optimised.median_wall_time) > margin

    def summary(self) -> str:
        return (
            f"{self.baseline.label}\n"
            f"  Baseline:  {self.baseline.median_wall_time * 1000:.3f} ms\n"
            f"  CGI-X:     {self.optimised.median_wall_time * 1000:.3f} ms\n"
            f"  Gain:      {self.speed_gain_percent:+.2f}%\n"
            f"  Memory:    {self.memory_change_percent:+.2f}%"
        )


def compare(
    baseline_func: Callable,
    optimised_func: Callable,
    *args,
    repeats: int = 5,
    warmup: int = 1,
    label: Optional[str] = None,
    baseline_args: Optional[tuple] = None,
    optimised_args: Optional[tuple] = None,
    **kwargs,
) -> ComparisonResult:
    """Benchmark a baseline implementation against an optimised one on the
    same (or equivalent) inputs and return the real, measured difference."""
    name = label or getattr(optimised_func, "__name__", "comparison")
    b_args = baseline_args if baseline_args is not None else args
    o_args = optimised_args if optimised_args is not None else args

    baseline_result = benchmark(baseline_func, *b_args, repeats=repeats, warmup=warmup,
                                 label=f"{name}.baseline", **kwargs)
    optimised_result = benchmark(optimised_func, *o_args, repeats=repeats, warmup=warmup,
                                  label=f"{name}.optimised", **kwargs)
    return ComparisonResult(baseline=baseline_result, optimised=optimised_result)
