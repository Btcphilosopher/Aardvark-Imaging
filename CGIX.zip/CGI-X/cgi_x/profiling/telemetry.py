"""
Telemetry recorder.

Every optimisation CGI-X performs is recorded as an `OptimizationRecord`
(see `cgi_x.core.state`) and appended to a JSON-lines telemetry log. This
gives CGI-X an optimisation history it can query later for:

  * adaptive optimisation (has this exact workload been sped up reliably
    before, and with what confidence?)
  * regression detection across releases
  * cost-engine reporting
"""

from __future__ import annotations

import json
import os
import statistics
from dataclasses import asdict
from typing import Iterable, List, Optional

from cgi_x.core.state import OptimizationRecord


class TelemetryStore:
    """Append-only JSONL store of optimisation records."""

    def __init__(self, path: str):
        self.path = path
        os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)

    def record(self, entry: OptimizationRecord) -> None:
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(asdict(entry), default=str) + "\n")

    def all_records(self) -> List[dict]:
        if not os.path.exists(self.path):
            return []
        records = []
        with open(self.path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        return records

    def records_for_workload(self, workload: str) -> List[dict]:
        return [r for r in self.all_records() if r.get("workload") == workload]

    def confidence_for_workload(self, workload: str, min_samples: int = 3) -> Optional[dict]:
        """
        Compute a deterministic confidence estimate for a workload based on
        the history of accepted optimisations. Confidence is defined as the
        fraction of historical runs where the optimisation actually beat
        baseline, scaled down by the coefficient of variation of the gain
        (unstable gains lower confidence). This is a transparent, rule-based
        calculation — not an opaque learned model.
        """
        records = self.records_for_workload(workload)
        if len(records) < min_samples:
            return None

        gains = [r["gain_fraction"] for r in records if r.get("accepted")]
        if not gains:
            return {"confidence": 0.0, "n": len(records), "mean_gain": 0.0}

        success_rate = len(gains) / len(records)
        mean_gain = statistics.mean(gains)
        stdev_gain = statistics.pstdev(gains) if len(gains) > 1 else 0.0
        stability = 1.0 if mean_gain == 0 else max(0.0, 1.0 - min(1.0, stdev_gain / abs(mean_gain)))
        confidence = success_rate * stability

        return {
            "confidence": round(confidence * 100, 2),
            "n": len(records),
            "mean_gain_percent": round(mean_gain * 100, 3),
            "mean_optimized_time": statistics.mean([r["optimized_time"] for r in records]),
            "mean_baseline_time": statistics.mean([r["baseline_time"] for r in records]),
        }
