"""Memory profiling helpers: tracemalloc snapshots and diffing."""

from __future__ import annotations

import tracemalloc
from dataclasses import dataclass
from typing import List


@dataclass
class MemoryDelta:
    file: str
    line: int
    size_diff_bytes: int
    count_diff: int


class MemoryProfiler:
    """Snapshot-based memory profiler for locating allocation hot spots."""

    def __init__(self):
        self._snapshot_before = None
        self._started_here = False

    def start(self):
        if not tracemalloc.is_tracing():
            tracemalloc.start()
            self._started_here = True
        self._snapshot_before = tracemalloc.take_snapshot()
        return self

    def stop(self, top_n: int = 10) -> List[MemoryDelta]:
        snapshot_after = tracemalloc.take_snapshot()
        stats = snapshot_after.compare_to(self._snapshot_before, "lineno")
        deltas = []
        for stat in stats[:top_n]:
            frame = stat.traceback[0]
            deltas.append(
                MemoryDelta(
                    file=frame.filename,
                    line=frame.lineno,
                    size_diff_bytes=stat.size_diff,
                    count_diff=stat.count_diff,
                )
            )
        if self._started_here:
            tracemalloc.stop()
        return deltas

    def __enter__(self):
        return self.start()

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.deltas = self.stop()
        return False


def current_memory_bytes() -> int:
    if tracemalloc.is_tracing():
        current, _ = tracemalloc.get_traced_memory()
        return current
    return 0
