"""
Generic lazy asset loader.

Wraps `AssetCache` with a lazy-loading proxy so an asset's bytes/mesh
aren't decoded until first access, and are shared across every reference
to the same underlying file.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, Optional

from cgi_x.assets.metadata import extract_metadata
from cgi_x.assets.validation import validate_asset_path
from cgi_x.cache.asset_cache import AssetCache


class LazyAsset:
    """A handle to an asset that is only loaded from disk on first `.get()`."""

    def __init__(self, path: str, loader_fn: Callable[[str], Any], cache: AssetCache):
        self.path = path
        self._loader_fn = loader_fn
        self._cache = cache
        self._loaded = False

    def get(self) -> Any:
        value = self._cache.load(self.path, self._loader_fn)
        self._loaded = True
        return value

    @property
    def is_loaded(self) -> bool:
        return self._loaded


class AssetLoader:
    """Central asset-loading entry point: validates, lazily loads, and
    deduplicates via content-hash caching."""

    def __init__(self, cache: Optional[AssetCache] = None):
        self.cache = cache or AssetCache()
        self._registry: Dict[str, LazyAsset] = {}

    def register(self, path: str, loader_fn: Callable[[str], Any], strict: bool = True) -> LazyAsset:
        report = validate_asset_path(path)
        if not report.is_valid and strict:
            raise FileNotFoundError("; ".join(i.message for i in report.issues if i.severity == "error"))

        if path in self._registry:
            return self._registry[path]

        handle = LazyAsset(path, loader_fn, self.cache)
        self._registry[path] = handle
        return handle

    def metadata(self, path: str):
        return extract_metadata(path)

    def stats(self) -> dict:
        return {
            "registered": len(self._registry),
            "loaded": sum(1 for h in self._registry.values() if h.is_loaded),
            "dedup_ratio": self.cache.dedup_ratio,
            "cache_hit_rate": self.cache.cache.stats.hit_rate,
        }
