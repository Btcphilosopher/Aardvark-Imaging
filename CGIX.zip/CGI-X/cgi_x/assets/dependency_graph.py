"""
Asset dependency graph: determines load order and identifies what is
required vs deferrable, matching the streaming policy:

    LOAD CORE -> LOAD VISIBLE -> LOAD NEARBY -> STREAM BACKGROUND
"""

from __future__ import annotations

import enum
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Dict, List, Set


class Priority(enum.IntEnum):
    CORE = 0
    VISIBLE = 1
    NEARBY = 2
    BACKGROUND = 3


@dataclass
class AssetNode:
    name: str
    priority: Priority = Priority.BACKGROUND
    depends_on: Set[str] = field(default_factory=set)
    shared_by: Set[str] = field(default_factory=set)  # scene objects referencing this asset


class DependencyGraph:
    def __init__(self):
        self._nodes: Dict[str, AssetNode] = {}

    def add_asset(self, name: str, priority: Priority = Priority.BACKGROUND,
                   depends_on: List[str] = None) -> "DependencyGraph":
        node = self._nodes.setdefault(name, AssetNode(name=name, priority=priority))
        node.priority = min(node.priority, priority)
        for dep in depends_on or []:
            node.depends_on.add(dep)
            self._nodes.setdefault(dep, AssetNode(name=dep))
        return self

    def register_reference(self, asset_name: str, referencing_object: str) -> None:
        node = self._nodes.setdefault(asset_name, AssetNode(name=asset_name))
        node.shared_by.add(referencing_object)

    def shared_assets(self) -> List[str]:
        """Assets referenced by more than one object — candidates for
        dedup / instancing / single-load-many-use."""
        return [n.name for n in self._nodes.values() if len(n.shared_by) > 1]

    def load_order(self) -> List[str]:
        """Topological order (dependencies first) with priority as the
        tie-breaker, so CORE assets a VISIBLE asset depends on are loaded
        first, and otherwise CORE < VISIBLE < NEARBY < BACKGROUND."""
        in_degree = {name: 0 for name in self._nodes}
        dependents = defaultdict(list)
        for name, node in self._nodes.items():
            for dep in node.depends_on:
                in_degree[name] += 1
                dependents[dep].append(name)

        ready = deque(sorted((n for n, d in in_degree.items() if d == 0),
                              key=lambda n: self._nodes[n].priority))
        order = []
        while ready:
            # keep the ready set sorted by priority every pop for a stable, load-policy-respecting order
            ready_list = sorted(ready, key=lambda n: self._nodes[n].priority)
            name = ready_list[0]
            ready.remove(name)
            order.append(name)
            for dependent in dependents[name]:
                in_degree[dependent] -= 1
                if in_degree[dependent] == 0:
                    ready.append(dependent)
        return order

    def deferrable_assets(self, up_to: Priority = Priority.VISIBLE) -> List[str]:
        """Assets that can be safely loaded later (streamed) because
        nothing at or above `up_to` priority needs them yet."""
        return [n.name for n in self._nodes.values() if n.priority > up_to]
