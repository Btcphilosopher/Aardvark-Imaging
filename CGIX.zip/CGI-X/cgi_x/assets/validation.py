"""Asset validation: missing files, unreadable formats, degenerate meshes."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import List

from cgi_x.geometry.mesh import Mesh


@dataclass
class ValidationIssue:
    severity: str  # "error" | "warning"
    message: str


@dataclass
class ValidationReport:
    issues: List[ValidationIssue] = field(default_factory=list)

    @property
    def is_valid(self) -> bool:
        return not any(i.severity == "error" for i in self.issues)

    def add(self, severity: str, message: str) -> None:
        self.issues.append(ValidationIssue(severity, message))


def validate_asset_path(path: str) -> ValidationReport:
    report = ValidationReport()
    if not os.path.exists(path):
        report.add("error", f"missing file: {path}")
        return report
    if os.path.getsize(path) == 0:
        report.add("error", f"zero-byte file: {path}")
    return report


def validate_mesh(mesh: Mesh) -> ValidationReport:
    report = ValidationReport()
    if mesh.vertex_count == 0:
        report.add("error", "mesh has no vertices")
        return report
    if mesh.face_count == 0:
        report.add("warning", "mesh has no faces")

    max_index = mesh.faces.max() if mesh.face_count else -1
    if max_index >= mesh.vertex_count:
        report.add("error", f"face references out-of-range vertex index {max_index}")

    import numpy as np
    if not np.all(np.isfinite(mesh.vertices)):
        report.add("error", "mesh contains non-finite vertex coordinates (NaN/Inf)")

    degenerate = np.sum(
        (mesh.faces[:, 0] == mesh.faces[:, 1])
        | (mesh.faces[:, 1] == mesh.faces[:, 2])
        | (mesh.faces[:, 0] == mesh.faces[:, 2])
    ) if mesh.face_count else 0
    if degenerate:
        report.add("warning", f"{int(degenerate)} degenerate face(s) found")

    return report
