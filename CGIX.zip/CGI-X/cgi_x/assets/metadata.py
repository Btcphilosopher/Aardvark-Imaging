"""Lightweight asset metadata extraction and content fingerprinting."""

from __future__ import annotations

import os
from dataclasses import dataclass

from cgi_x.cache.asset_cache import file_content_hash


@dataclass
class AssetMetadata:
    path: str
    size_bytes: int
    content_hash: str
    extension: str
    modified_time: float


def extract_metadata(path: str) -> AssetMetadata:
    stat = os.stat(path)
    return AssetMetadata(
        path=path,
        size_bytes=stat.st_size,
        content_hash=file_content_hash(path),
        extension=os.path.splitext(path)[1].lower(),
        modified_time=stat.st_mtime,
    )
