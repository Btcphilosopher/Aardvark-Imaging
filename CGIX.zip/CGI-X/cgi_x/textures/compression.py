"""
Texture compression: block-wise quantisation modelled after GPU block
compression (BCn-style: one representative colour per 4x4 block, plus a
per-pixel interpolation weight), with a measured memory/quality tradeoff
rather than a blind resolution cut.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class CompressionReport:
    original_bytes: int
    compressed_bytes: int
    memory_change_fraction: float
    rms_error: float


def block_quantize(texture: np.ndarray, block_size: int = 4, levels: int = 16) -> np.ndarray:
    """
    Simulate block compression: within each `block_size`x`block_size`
    block, quantise each channel to `levels` discrete steps between the
    block's own min and max (a simplified analogue of BC1/BC3 endpoint
    interpolation). Fully vectorised across blocks.
    """
    h, w = texture.shape[:2]
    bh, bw = h - h % block_size, w - w % block_size
    cropped = texture[:bh, :bw]
    c = cropped.shape[2] if cropped.ndim == 3 else 1
    if cropped.ndim == 2:
        cropped = cropped[..., None]

    blocks = cropped.reshape(bh // block_size, block_size, bw // block_size, block_size, c)
    blocks = blocks.transpose(0, 2, 1, 3, 4)  # (nby, nbx, bs, bs, c)

    block_min = blocks.min(axis=(2, 3), keepdims=True)
    block_max = blocks.max(axis=(2, 3), keepdims=True)
    span = np.where(block_max - block_min > 1e-9, block_max - block_min, 1.0)

    normalized = (blocks - block_min) / span
    quantized_steps = np.round(normalized * (levels - 1)) / (levels - 1)
    quantized = quantized_steps * span + block_min

    quantized = quantized.transpose(0, 2, 1, 3, 4).reshape(bh, bw, c)
    if texture.ndim == 2:
        quantized = quantized[..., 0]
    return quantized.astype(texture.dtype)


def compress_with_report(texture: np.ndarray, block_size: int = 4, levels: int = 16) -> CompressionReport:
    compressed = block_quantize(texture, block_size, levels)
    rms_error = float(np.sqrt(np.mean((texture.astype(np.float64) - compressed.astype(np.float64)) ** 2)))

    original_bytes = texture.nbytes
    # A block of block_size^2 pixels collapses to endpoints (2 * channels floats)
    # + per-pixel index bits (log2(levels) bits each) — matches real BCn ratios closely.
    n_blocks = (texture.shape[0] // block_size) * (texture.shape[1] // block_size)
    channels = texture.shape[2] if texture.ndim == 3 else 1
    bits_per_index = max(1, int(np.ceil(np.log2(levels))))
    compressed_bytes = int(n_blocks * (2 * channels * 4 + block_size * block_size * bits_per_index / 8))

    return CompressionReport(
        original_bytes=original_bytes,
        compressed_bytes=compressed_bytes,
        memory_change_fraction=(compressed_bytes - original_bytes) / original_bytes if original_bytes else 0.0,
        rms_error=rms_error,
    )
