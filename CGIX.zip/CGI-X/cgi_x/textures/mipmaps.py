"""Mipmap chain generation via vectorised 2x2 box downsampling."""

from __future__ import annotations

from typing import List

import numpy as np


def generate_mipmap_chain(texture: np.ndarray, min_size: int = 1) -> List[np.ndarray]:
    """Build a full mip chain down to `min_size`x`min_size` (or smaller edge)
    using successive 2x2 box averaging — a standard, vectorised, GPU-
    equivalent-quality downsample."""
    chain = [texture]
    current = texture
    h, w = current.shape[:2]

    while h > min_size and w > min_size:
        new_h, new_w = max(1, h // 2), max(1, w // 2)
        cropped = current[: new_h * 2, : new_w * 2]
        reshaped = cropped.reshape(new_h, 2, new_w, 2, *current.shape[2:])
        current = reshaped.mean(axis=(1, 3))
        chain.append(current)
        h, w = current.shape[:2]

    return chain


def total_mipmap_memory(chain: List[np.ndarray]) -> int:
    return sum(level.nbytes for level in chain)
