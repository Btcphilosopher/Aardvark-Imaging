"""Priority texture streaming queue: distance-to-camera and visual
importance jointly determine load order, so distant/flat textures stream
in later without any perceptible quality loss near the camera."""

from __future__ import annotations

import heapq
from dataclasses import dataclass, field
from typing import List, Tuple


@dataclass(order=True)
class _QueueEntry:
    priority: float
    name: str = field(compare=False)


class TextureStreamQueue:
    def __init__(self):
        self._heap: List[_QueueEntry] = []

    def enqueue(self, name: str, distance: float, visual_importance: float) -> None:
        """Lower `priority` value = loaded sooner. Combines distance
        (closer = more urgent) and visual importance (higher-detail
        textures are prioritised at equal distance)."""
        priority = distance / (1.0 + visual_importance)
        heapq.heappush(self._heap, _QueueEntry(priority, name))

    def pop_next(self) -> str:
        return heapq.heappop(self._heap).name

    def __len__(self) -> int:
        return len(self._heap)

    def drain_order(self) -> List[str]:
        return [heapq.heappop(self._heap).name for _ in range(len(self._heap))]
