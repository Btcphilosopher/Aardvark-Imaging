"""Texture loading as NumPy arrays. Uses Pillow if available for real
image formats; otherwise supports synthetic generation for tests/
benchmarks so the rest of the texture pipeline can be exercised without
requiring image assets or extra dependencies."""

from __future__ import annotations

import numpy as np

try:
    from PIL import Image
    _HAS_PIL = True
except ImportError:  # pragma: no cover - Pillow is optional
    _HAS_PIL = False


def load_texture(path: str) -> np.ndarray:
    """Load an image file into an (H, W, C) float32 array in [0, 1]."""
    if not _HAS_PIL:
        raise ImportError("Pillow is required to load real image files; install with `pip install Pillow`, "
                           "or use `synthetic_texture()` for testing.")
    img = Image.open(path).convert("RGBA")
    arr = np.asarray(img, dtype=np.float32) / 255.0
    return arr


def synthetic_texture(width: int = 512, height: int = 512, seed: int = 0) -> np.ndarray:
    """Generate a smooth synthetic RGBA texture for tests/benchmarks."""
    rng = np.random.default_rng(seed)
    base = rng.random((height // 16, width // 16, 4)).astype(np.float32)
    return np.repeat(np.repeat(base, 16, axis=0), 16, axis=1)[:height, :width]


def estimate_visual_importance(texture: np.ndarray) -> float:
    """
    Cheap, deterministic proxy for how much detail a texture actually
    carries: high-frequency energy (gradient magnitude) normalised by
    resolution. Low-importance textures (flat colours, blurred masks) are
    safe to compress or resize more aggressively than detailed ones.
    """
    gray = texture[..., :3].mean(axis=-1) if texture.ndim == 3 else texture
    gy, gx = np.gradient(gray)
    gradient_energy = float(np.mean(np.sqrt(gx ** 2 + gy ** 2)))
    return gradient_energy
