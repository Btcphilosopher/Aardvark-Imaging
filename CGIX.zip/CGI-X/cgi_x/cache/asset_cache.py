"""Cache for loaded assets (meshes, textures) keyed by file content hash +
loader parameters, so identical assets referenced from multiple places in
a scene are only loaded and decoded once."""

from __future__ import annotations

import hashlib
import os
from typing import Any, Callable, Optional

from cgi_x.cache.cache import Cache, make_cache_key


def file_content_hash(path: str, chunk_size: int = 1024 * 1024) -> str:
    hasher = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            hasher.update(chunk)
    return hasher.hexdigest()


class AssetCache:
    def __init__(self, cache: Optional[Cache] = None):
        self.cache = cache or Cache()
        self._loads = 0
        self._reuses = 0

    def load(self, path: str, loader_fn: Callable[[str], Any], parameters: Optional[dict] = None,
              version: str = "1") -> Any:
        try:
            fingerprint = file_content_hash(path)
        except FileNotFoundError:
            raise
        key = make_cache_key(fingerprint, parameters, version)

        cached = self.cache.get(key)
        if cached is not None:
            self._reuses += 1
            return cached

        value = loader_fn(path)
        self.cache.set(key, value)
        self._loads += 1
        return value

    @property
    def dedup_ratio(self) -> float:
        total = self._loads + self._reuses
        return self._reuses / total if total else 0.0
