"""Cache for scene-evaluation results, keyed on scene content + dependencies."""

from __future__ import annotations

from typing import Any, Callable, Iterable, Optional

from cgi_x.cache.cache import Cache, make_cache_key


class SceneCache:
    def __init__(self, cache: Optional[Cache] = None):
        self.cache = cache or Cache()

    def evaluate(self, scene_fingerprint: Any, evaluate_fn: Callable,
                 parameters: Optional[dict] = None, version: str = "1",
                 dependencies: Optional[Iterable[str]] = None) -> Any:
        key = make_cache_key(scene_fingerprint, parameters, version, dependencies)
        return self.cache.get_or_compute(key, evaluate_fn)
