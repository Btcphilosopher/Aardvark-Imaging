"""
Content-addressable cache with a two-tier (memory + disk) backend.

A cache key incorporates:

    INPUT + PARAMETERS + VERSION + DEPENDENCIES

so a change to any of those invalidates the entry automatically — CGI-X
never returns a stale result silently.
"""

from __future__ import annotations

import hashlib
import os
import pickle
import time
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Any, Iterable, Optional


def make_cache_key(input_data: Any, parameters: Optional[dict] = None,
                    version: str = "1", dependencies: Optional[Iterable[str]] = None) -> str:
    """
    Build a content-addressable key from input + parameters + version +
    dependencies. Uses a stable hash of a repr-based fingerprint; for
    NumPy arrays the raw bytes are hashed directly so identical data
    always produces the same key regardless of object identity.
    """
    hasher = hashlib.sha256()

    def feed(obj: Any):
        try:
            import numpy as np
            if isinstance(obj, np.ndarray):
                hasher.update(obj.tobytes())
                hasher.update(str(obj.shape).encode())
                hasher.update(str(obj.dtype).encode())
                return
        except ImportError:
            pass
        if isinstance(obj, (bytes, bytearray)):
            hasher.update(obj)
        else:
            hasher.update(repr(obj).encode("utf-8", errors="replace"))

    feed(input_data)
    feed(parameters or {})
    hasher.update(str(version).encode())
    for dep in sorted(dependencies or []):
        hasher.update(dep.encode())

    return hasher.hexdigest()


@dataclass
class CacheStats:
    hits: int = 0
    misses: int = 0
    evictions: int = 0

    @property
    def hit_rate(self) -> float:
        total = self.hits + self.misses
        return self.hits / total if total else 0.0


@dataclass
class _Entry:
    value: Any
    size_bytes: int
    created_at: float = field(default_factory=time.time)


class Cache:
    """LRU in-memory cache with optional disk persistence and a byte budget."""

    def __init__(self, max_bytes: int = 512 * 1024 * 1024, disk_dir: Optional[str] = None):
        self.max_bytes = max_bytes
        self.disk_dir = disk_dir
        self._store: "OrderedDict[str, _Entry]" = OrderedDict()
        self._current_bytes = 0
        self.stats = CacheStats()
        if disk_dir:
            os.makedirs(disk_dir, exist_ok=True)

    def _disk_path(self, key: str) -> Optional[str]:
        if not self.disk_dir:
            return None
        return os.path.join(self.disk_dir, key + ".pkl")

    def get(self, key: str) -> Optional[Any]:
        if key in self._store:
            self._store.move_to_end(key)
            self.stats.hits += 1
            return self._store[key].value

        disk_path = self._disk_path(key)
        if disk_path and os.path.exists(disk_path):
            with open(disk_path, "rb") as f:
                value = pickle.load(f)
            self._insert_memory(key, value)
            self.stats.hits += 1
            return value

        self.stats.misses += 1
        return None

    def _estimate_size(self, value: Any) -> int:
        try:
            import numpy as np
            if isinstance(value, np.ndarray):
                return int(value.nbytes)
        except ImportError:
            pass
        try:
            return len(pickle.dumps(value, protocol=pickle.HIGHEST_PROTOCOL))
        except Exception:
            return 1024

    def _insert_memory(self, key: str, value: Any):
        size = self._estimate_size(value)
        self._store[key] = _Entry(value=value, size_bytes=size)
        self._current_bytes += size
        self._store.move_to_end(key)
        self._evict_if_needed()

    def _evict_if_needed(self):
        while self._current_bytes > self.max_bytes and self._store:
            _, entry = self._store.popitem(last=False)
            self._current_bytes -= entry.size_bytes
            self.stats.evictions += 1

    def set(self, key: str, value: Any, persist: bool = True) -> None:
        self._insert_memory(key, value)
        disk_path = self._disk_path(key)
        if persist and disk_path:
            with open(disk_path, "wb") as f:
                pickle.dump(value, f, protocol=pickle.HIGHEST_PROTOCOL)

    def get_or_compute(self, key: str, compute_fn, persist: bool = True) -> Any:
        cached = self.get(key)
        if cached is not None:
            return cached
        value = compute_fn()
        self.set(key, value, persist=persist)
        return value

    def clear(self):
        self._store.clear()
        self._current_bytes = 0
