"""Checkpointing cache for iterative simulations: reuse a previously
computed state instead of re-simulating from t=0 when only later frames
of a run are needed (state-reuse optimisation)."""

from __future__ import annotations

from typing import Any, Callable, Optional

from cgi_x.cache.cache import Cache, make_cache_key


class SimulationCache:
    def __init__(self, cache: Optional[Cache] = None):
        self.cache = cache or Cache()

    def checkpoint_key(self, sim_id: str, frame: int, parameters: dict, version: str = "1") -> str:
        return make_cache_key(f"{sim_id}:{frame}", parameters, version)

    def save_checkpoint(self, sim_id: str, frame: int, state: Any, parameters: dict, version: str = "1"):
        key = self.checkpoint_key(sim_id, frame, parameters, version)
        self.cache.set(key, state)

    def load_checkpoint(self, sim_id: str, frame: int, parameters: dict, version: str = "1") -> Optional[Any]:
        key = self.checkpoint_key(sim_id, frame, parameters, version)
        return self.cache.get(key)

    def nearest_checkpoint(self, sim_id: str, target_frame: int, parameters: dict,
                            available_frames, version: str = "1"):
        """Find the closest cached frame at or before `target_frame` so a
        simulation can resume instead of restarting."""
        candidates = sorted(f for f in available_frames if f <= target_frame)
        if not candidates:
            return None, None
        frame = candidates[-1]
        return frame, self.load_checkpoint(sim_id, frame, parameters, version)
