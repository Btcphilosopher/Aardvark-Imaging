"""
CGI-X — Professional Computational Optimisation Layer for CGI / VFX pipelines.

CGI-X does not replace Blender, Maya, Houdini, Unreal Engine, Cinema 4D or a
professional renderer. It sits underneath them and extracts marginal,
measured, validated performance gains from geometry processing, simulation,
texture handling, asset loading, caching, render preparation, scene
evaluation, data movement, numerical calculation and parallel execution.

Every optimisation in CGI-X follows the same loop:

    MEASURE -> PROFILE -> FIND BOTTLENECK -> OPTIMISE -> BENCHMARK
    -> VALIDATE QUALITY -> ACCEPT/REJECT -> DEPLOY -> MEASURE AGAIN

Nothing is accepted on the basis of an assumption. Every optimisation ships
with a baseline, an optimised measurement and a real, benchmarked
difference. Optimisations that exceed a declared quality tolerance are
rejected automatically.
"""

from cgi_x.core.engine import Engine, Optimizer, OptimizationResult
from cgi_x.config.settings import Settings, HardwareProfile

__version__ = "1.0.0"

__all__ = [
    "Engine",
    "Optimizer",
    "OptimizationResult",
    "Settings",
    "HardwareProfile",
    "__version__",
]
