"""
Hardware abstraction and global settings for CGI-X.

CGI-X never hard-codes itself to one machine. It detects the CPU core
count, available RAM, storage characteristics and NumPy's SIMD/BLAS
configuration at startup and adapts scheduling and chunk sizes to match.
"""

from __future__ import annotations

import multiprocessing
import os
import platform
import shutil
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

try:
    import psutil  # optional but preferred for accurate memory figures
except ImportError:  # pragma: no cover - psutil is an optional dependency
    psutil = None


@dataclass(frozen=True)
class HardwareProfile:
    """A snapshot of the machine CGI-X is currently running on."""

    cpu_count_logical: int
    cpu_count_physical: int
    total_ram_bytes: int
    available_ram_bytes: int
    platform: str
    python_version: str
    numpy_version: str
    blas_backend: str
    simd_features: str
    free_disk_bytes: int
    gpu_available: bool = False
    gpu_name: Optional[str] = None

    @property
    def total_ram_gb(self) -> float:
        return self.total_ram_bytes / (1024 ** 3)

    @property
    def available_ram_gb(self) -> float:
        return self.available_ram_bytes / (1024 ** 3)

    def recommended_worker_count(self, reserve_core: bool = True) -> int:
        """A sane default worker count for CPU-bound parallel work."""
        n = self.cpu_count_logical
        if reserve_core and n > 1:
            n -= 1
        return max(1, n)

    def summary(self) -> str:
        lines = [
            "HARDWARE PROFILE",
            f"  CPU (logical/physical): {self.cpu_count_logical}/{self.cpu_count_physical}",
            f"  RAM total/available:    {self.total_ram_gb:.2f} GB / {self.available_ram_gb:.2f} GB",
            f"  Free disk:               {self.free_disk_bytes / (1024**3):.2f} GB",
            f"  Platform:                {self.platform}",
            f"  Python:                  {self.python_version}",
            f"  NumPy:                   {self.numpy_version} (BLAS: {self.blas_backend})",
            f"  SIMD:                    {self.simd_features}",
            f"  GPU:                     {self.gpu_name or 'not detected'}",
        ]
        return "\n".join(lines)


def _detect_blas_backend() -> str:
    try:
        cfg = np.show_config(mode="dicts")
        if isinstance(cfg, dict):
            blas = cfg.get("Build Dependencies", {}).get("blas", {})
            name = blas.get("name")
            if name:
                return str(name)
    except Exception:
        pass
    return "unknown"


def _detect_simd_features() -> str:
    # NumPy >=2.0 renamed the private `numpy.core` namespace to `numpy._core`;
    # try both so this works across NumPy 1.x and 2.x without a deprecation warning.
    try:
        umath = getattr(np, "_core", None)
        umath = umath._multiarray_umath if umath is not None else np.core._multiarray_umath  # type: ignore[attr-defined]
        baseline = umath.__cpu_baseline__
        dispatch = [f for f in umath.__cpu_dispatch__ if umath.__cpu_features__.get(f)]
        return f"baseline={','.join(baseline) or 'none'} dispatch={','.join(dispatch) or 'none'}"
    except Exception:
        return "unknown"


def detect_hardware() -> HardwareProfile:
    """Detect the current machine's hardware profile."""
    cpu_logical = multiprocessing.cpu_count()
    cpu_physical = cpu_logical
    total_ram = 0
    available_ram = 0

    if psutil is not None:
        try:
            cpu_physical = psutil.cpu_count(logical=False) or cpu_logical
            vm = psutil.virtual_memory()
            total_ram = vm.total
            available_ram = vm.available
        except Exception:
            pass

    if total_ram == 0:
        # Fallback for systems without psutil.
        try:
            total_ram = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
            available_ram = total_ram
        except (ValueError, AttributeError, OSError):
            total_ram = 8 * 1024 ** 3
            available_ram = 4 * 1024 ** 3

    free_disk = shutil.disk_usage(os.getcwd()).free

    return HardwareProfile(
        cpu_count_logical=cpu_logical,
        cpu_count_physical=cpu_physical,
        total_ram_bytes=total_ram,
        available_ram_bytes=available_ram,
        platform=platform.platform(),
        python_version=platform.python_version(),
        numpy_version=np.__version__,
        blas_backend=_detect_blas_backend(),
        simd_features=_detect_simd_features(),
        free_disk_bytes=free_disk,
        gpu_available=False,
        gpu_name=None,
    )


@dataclass
class QualityConstraints:
    """Tolerances an optimisation must respect to be accepted."""

    max_visual_error: float = 0.005       # fraction, e.g. SSIM-derived / PSNR-derived error
    max_geometric_error: float = 0.001    # fraction of bounding-box diagonal
    max_simulation_error: float = 0.0001  # fraction, relative state error
    min_speed_gain: float = 0.0           # reject "optimisations" that aren't faster


@dataclass
class Settings:
    """Global CGI-X configuration."""

    cache_dir: str = field(default_factory=lambda: os.path.join(os.getcwd(), ".cgi_x_cache"))
    telemetry_path: str = field(default_factory=lambda: os.path.join(os.getcwd(), ".cgi_x_cache", "telemetry.jsonl"))
    max_workers: Optional[int] = None
    quality: QualityConstraints = field(default_factory=QualityConstraints)
    hardware: HardwareProfile = field(default_factory=detect_hardware)
    benchmark_repeats: int = 5
    cache_max_bytes: int = 2 * 1024 ** 3

    def worker_count(self) -> int:
        if self.max_workers:
            return self.max_workers
        return self.hardware.recommended_worker_count()

    def ensure_dirs(self) -> None:
        os.makedirs(self.cache_dir, exist_ok=True)
        os.makedirs(os.path.dirname(self.telemetry_path), exist_ok=True)


DEFAULT_SETTINGS = Settings()
