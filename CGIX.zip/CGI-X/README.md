# CGI-X

**A professional computational optimisation layer for CGI, VFX, animation and 3D-production software.**

CGI-X does not replace Blender, Maya, Houdini, Unreal Engine, Cinema 4D or a professional
renderer. It sits underneath them and extracts marginal, *measured*, *validated* performance
gains from every stage of the production pipeline:

```
EXISTING CGI SOFTWARE
        │
        ▼
      CGI-X
        │
        ▼
COMPUTATIONAL OPTIMISATION
        │
        ▼
MORE EFFICIENT PIPELINE
```

A 1% improvement is valuable. A 5% improvement is significant. A 10% improvement across a
major production pipeline is transformational. CGI-X exists to find those gains everywhere —
geometry, memory, caching, simulation, texture handling, asset loading, render preparation,
scene evaluation, numerical calculation and parallel execution — and never to claim one it
hasn't actually measured.

## Philosophy

Every optimisation in CGI-X follows the same loop, with no exceptions:

```
MEASURE → PROFILE → FIND BOTTLENECK → OPTIMISE → BENCHMARK
        → VALIDATE QUALITY → ACCEPT / REJECT → DEPLOY → MEASURE AGAIN
```

Nothing is accepted on the basis of an assumption. Every optimisation ships with a baseline
measurement, an optimised measurement, and the *real* difference between them
(`cgi_x.profiling.benchmark`). Optimisations that exceed a declared quality tolerance —
visual, geometric or simulation error — are rejected automatically
(`cgi_x.config.settings.QualityConstraints`), and the rejection is recorded, not hidden.

## Install

```bash
pip install -e .                 # core (NumPy + SciPy only)
pip install -e ".[dev]"          # + pytest, psutil, Pillow
pip install -e ".[api]"          # + FastAPI/uvicorn for cgi_x.api.server
```

## Quick start

```python
from cgi_x import Optimizer
from cgi_x.geometry.mesh import Mesh
from cgi_x.rendering.scene import Scene, SceneObject

scene = Scene(name="my_shot")
scene.add_object(SceneObject(name="hero", mesh=Mesh.synthetic_sphere(subdivisions=4)))

optimizer = Optimizer()
result = optimizer.optimize(scene, constraints={"max_visual_error": 0.005})

print(result.performance_gain)      # fraction, e.g. 0.0842
print(result.memory_saved)          # fraction, e.g. 0.031
print(result.summary())             # formatted CGI-X performance report
```

Or run the bundled end-to-end demo directly:

```bash
python -m cgi_x.main --project "FILM_042" --objects 24 --subdivisions 4
```

which builds a synthetic production-shaped scene, runs the full
measure→optimise→benchmark→validate loop, and prints a report in the form:

```
CGI-X PERFORMANCE REPORT
------------------------

PROJECT: FILM_042

BASELINE:
4,812.00 seconds

OPTIMISED:
4,391.00 seconds

GAIN:
8.75%

MEMORY:
-11.20%

QUALITY CHANGE:
0.080%

ESTIMATED COMPUTE SAVING:
£XX,XXX.XX
```

## Architecture

```
                CGI SOFTWARE
                     │
                     ▼
               CGI-X API  (cgi_x.core.engine.Optimizer)
                     │
        ┌────────────┼────────────┐
        ▼            ▼            ▼
    GEOMETRY      SIMULATION    RENDER
        │            │            │
        └────────────┼────────────┘
                     ▼
              OPTIMISATION CORE  (cgi_x.optimisation.*)
                     ▼
        ┌────────────┼────────────┐
        ▼            ▼            ▼
     CACHE        PARALLEL      MEMORY
        │            │            │
        └────────────┼────────────┘
                     ▼
             OPTIMISED OUTPUT
```

## Package layout

| Package | Responsibility |
|---|---|
| `cgi_x.core` | `Optimizer`/`Engine` public API, `Pipeline`, `Task`/`TaskGraph` orchestration |
| `cgi_x.geometry` | NumPy-backed `Mesh`, normals, topology (welding/adjacency), transforms, subdivision, LOD simplification |
| `cgi_x.simulation` | Adaptive-timestep solver, particles, cloth, rigid bodies, simplified SPH fluids — naive vs vectorised, always benchmarked |
| `cgi_x.rendering` | `Scene`, `Camera`, `Light`, `Material`, render-prep (culling/instancing) and scene analysis/recommendations |
| `cgi_x.textures` | Texture loading, mipmap chains, block-quantisation compression, priority streaming |
| `cgi_x.assets` | Lazy loading, dependency graph (load ordering + streaming policy), metadata, validation |
| `cgi_x.optimisation` | The actual optimisers: geometry, memory, cache, simulation, render, and the pipeline-level aggregator |
| `cgi_x.cache` | Content-addressable cache (`input + parameters + version + dependencies`), scene/simulation/asset caches |
| `cgi_x.parallel` | `TaskGraph` (wave-based topological scheduling), thread/process worker pools, benchmarked auto-parallel map |
| `cgi_x.profiling` | `Profiler` (wall/CPU/memory), `benchmark`/`compare`, telemetry store with rule-based confidence scoring |
| `cgi_x.numerical` | Linear algebra, interpolation, integration, precision — each with a benchmarked method selector |
| `cgi_x.io` | OBJ (pure Python), minimal glTF (stdlib only), Alembic/USD adapters that bind to the real SDKs when present |
| `cgi_x.integrations` | `BaseAdapter` + fully-functional `GenericAdapter`, plus Blender/Maya/Houdini/Unreal adapters that only activate inside their host application |
| `cgi_x.analytics` | Visual/geometric quality metrics (MSE/PSNR/SSIM), the marginal-gain engine (correctly aggregated, never additive), cost engine |
| `cgi_x.api` | Optional FastAPI server exposing `Optimizer` over HTTP |
| `cgi_x.config` | Hardware detection and abstraction, quality-constraint defaults |

## The marginal-gain engine

`cgi_x.analytics.performance.MarginalGainEngine` never adds percentages together. Given
per-category `(baseline_time, optimized_time)` pairs from real benchmarks, the pipeline-level
gain is:

```
TOTAL PIPELINE GAIN = (Σ baseline_time − Σ optimized_time) / Σ baseline_time
```

which is the only mathematically correct way to combine gains from stages of different
absolute cost — see `cgi_x/tests/test_benchmark.py::test_marginal_gain_engine_aggregates_correctly_not_additively`
for a worked example showing why naive percentage-stacking is wrong.

## Quality preservation

Every optimiser records a `quality_difference` alongside its `gain_fraction`
(`cgi_x.core.state.OptimizationRecord`), and compares it against the caller's
`QualityConstraints` before setting `accepted = True`. Rejections are kept, not discarded —
`OptimizationResult.rejected` shows exactly what CGI-X considered and turned down, and why.

## Format support

- **OBJ** and a **minimal glTF** (positions/indices) reader/writer ship fully working,
  standard-library-only implementations.
- **Alembic** and **USD** are genuinely complex binary formats with no honest pure-Python
  reimplementation. Their adapters (`cgi_x.io.alembic`, `cgi_x.io.usd`) bind to the real
  `alembic` / `pxr` (`usd-core`) libraries when installed, and raise a clear, actionable
  `ImportError` with install instructions when they are not — CGI-X never silently
  fabricates or drops data for these formats.

## DCC integrations

`cgi_x.integrations.generic.GenericAdapter` is fully functional and dependency-free — it's
what the test suite and CLI use, and what any custom Python pipeline glue code should use to
hand CGI-X a `Scene` directly. The Blender/Maya/Houdini/Unreal adapters implement the same
`BaseAdapter` interface using each application's real Python API (`bpy`, `maya.api.OpenMaya`,
`hou`, `unreal`), but — like any DCC integration — can only run *inside* that application's
embedded Python interpreter. `adapter.is_available()` reports whether the host is present
before anything is attempted.

## Testing

```bash
pip install -e ".[dev]"
pytest
```

The suite covers geometry correctness (naive vs vectorised numerical agreement), numerical
routines, cache-key correctness (never returns a stale result for a changed input/parameter/
version/dependency), parallel task-graph scheduling (including cycle detection and failure
handling), memory optimisation, asset loading/validation, quality-metric behaviour, benchmark
reproducibility, and a full pipeline integration test asserting that optimisations never
exceed a declared tolerance.

## What CGI-X deliberately does not do

- It does not implement a renderer, a full modelling toolkit, or a timeline/animation editor.
- It does not apply an optimisation without benchmarking it first.
- It does not accept a result outside its declared quality tolerance.
- It does not reimplement Alembic/USD's binary formats from scratch.
- It does not make opaque, unexplainable decisions — the adaptive-optimisation confidence
  score in `cgi_x.profiling.telemetry.TelemetryStore.confidence_for_workload` is a
  transparent, auditable formula over real historical measurements, not a learned black box.
