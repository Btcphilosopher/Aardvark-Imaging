import React, { createContext, useContext, useState, useMemo } from 'react';
import {
  Supplier,
  RawMaterial,
  MaterialLot,
  Formulation,
  Colour,
  FactoryTank,
  BatchRecord,
  PackagedSKU,
  Pallet,
  LogisticsShipment,
  TradeMerchant,
  SalesOrder,
  PainterJob,
  EventLog,
  UserPersona,
  LotStatus,
  BatchStatus,
  ScenarioShockState,
  FormulaVersion
} from '../types/paintchain';
import {
  INITIAL_SUPPLIERS,
  INITIAL_MATERIALS,
  INITIAL_MATERIAL_LOTS,
  INITIAL_FORMULATIONS,
  INITIAL_COLOURS,
  INITIAL_TANKS,
  INITIAL_BATCHES,
  INITIAL_SKUS,
  INITIAL_PALLETS,
  INITIAL_LOGISTICS,
  INITIAL_MERCHANTS,
  INITIAL_ORDERS,
  INITIAL_PAINTER_JOBS,
  INITIAL_EVENT_LOGS
} from '../data/syntheticDatabase';

export type ModuleType =
  | 'OVERVIEW'
  | 'SUPPLY'
  | 'MATERIALS'
  | 'LAB'
  | 'FORMULAS'
  | 'PRODUCTION'
  | 'QUALITY'
  | 'INVENTORY'
  | 'LOGISTICS'
  | 'PRODUCTS'
  | 'TRADE'
  | 'PAINTERS'
  | 'PROJECTS'
  | 'TRACE'
  | 'ANALYTICS';

interface PaintChainContextType {
  activeModule: ModuleType;
  setActiveModule: (module: ModuleType) => void;
  activePersona: UserPersona;
  setActivePersona: (persona: UserPersona) => void;
  
  suppliers: Supplier[];
  materials: RawMaterial[];
  materialLots: MaterialLot[];
  formulations: Formulation[];
  colours: Colour[];
  tanks: FactoryTank[];
  batches: BatchRecord[];
  skus: PackagedSKU[];
  pallets: Pallet[];
  shipments: LogisticsShipment[];
  merchants: TradeMerchant[];
  orders: SalesOrder[];
  painterJobs: PainterJob[];
  eventLogs: EventLog[];

  searchQuery: string;
  setSearchQuery: (q: string) => void;
  selectedTraceBatchId: string;
  setSelectedTraceBatchId: (id: string) => void;

  scenarioShock: ScenarioShockState;
  setScenarioShock: React.Dispatch<React.SetStateAction<ScenarioShockState>>;

  // Actions
  triggerSignatureDemo: (demoNumber: 1 | 2 | 3 | 4) => void;
  updateLotStatus: (lotNumber: string, status: LotStatus) => void;
  updateBatchStatus: (batchNumber: string, status: BatchStatus, quarantineReason?: string) => void;
  addPainterJob: (job: PainterJob) => void;
  addSalesOrder: (order: SalesOrder) => void;
  addFormulationRevision: (formulaId: string, revision: FormulaVersion) => void;
  addEventLog: (event: Omit<EventLog, 'id' | 'timestamp'>) => void;
  calculateBatchCostWithShocks: (batchNumber: string) => { rawMaterialCost: number; laborCost: number; energyCost: number; totalCost: number; costPerLitre: number };
}

const PaintChainContext = createContext<PaintChainContextType | undefined>(undefined);

export const PaintChainProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeModule, setActiveModule] = useState<ModuleType>('OVERVIEW');
  const [activePersona, setActivePersona] = useState<UserPersona>('ALL');

  const [suppliers] = useState<Supplier[]>(INITIAL_SUPPLIERS);
  const [materials, setMaterials] = useState<RawMaterial[]>(INITIAL_MATERIALS);
  const [materialLots, setMaterialLots] = useState<MaterialLot[]>(INITIAL_MATERIAL_LOTS);
  const [formulations, setFormulations] = useState<Formulation[]>(INITIAL_FORMULATIONS);
  const [colours] = useState<Colour[]>(INITIAL_COLOURS);
  const [tanks] = useState<FactoryTank[]>(INITIAL_TANKS);
  const [batches, setBatches] = useState<BatchRecord[]>(INITIAL_BATCHES);
  const [skus, setSkus] = useState<PackagedSKU[]>(INITIAL_SKUS);
  const [pallets, setPallets] = useState<Pallet[]>(INITIAL_PALLETS);
  const [shipments] = useState<LogisticsShipment[]>(INITIAL_LOGISTICS);
  const [merchants] = useState<TradeMerchant[]>(INITIAL_MERCHANTS);
  const [orders, setOrders] = useState<SalesOrder[]>(INITIAL_ORDERS);
  const [painterJobs, setPainterJobs] = useState<PainterJob[]>(INITIAL_PAINTER_JOBS);
  const [eventLogs, setEventLogs] = useState<EventLog[]>(INITIAL_EVENT_LOGS);

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTraceBatchId, setSelectedTraceBatchId] = useState('BATCH-26-09184');

  const [scenarioShock, setScenarioShock] = useState<ScenarioShockState>({
    tio2PriceShockPct: 0,
    resinPriceShockPct: 0,
    solventDelayDays: 0,
    shadeFailureTriggered: false,
    painterDemandMultiplier: 1.0
  });

  const addEventLog = (event: Omit<EventLog, 'id' | 'timestamp'>) => {
    const newLog: EventLog = {
      ...event,
      id: `EVT-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19)
    };
    setEventLogs(prev => [newLog, ...prev]);
  };

  const updateLotStatus = (lotNumber: string, status: LotStatus) => {
    setMaterialLots(prev =>
      prev.map(lot => (lot.lotNumber === lotNumber ? { ...lot, status } : lot))
    );
    addEventLog({
      eventType: 'RAW_MATERIAL_STATUS_CHANGE',
      actor: 'Material QA Manager',
      description: `Lot ${lotNumber} status changed to ${status}`,
      severity: status === 'REJECTED' ? 'ALERT' : 'SUCCESS'
    });
  };

  const updateBatchStatus = (batchNumber: string, status: BatchStatus, quarantineReason?: string) => {
    setBatches(prev =>
      prev.map(b => {
        if (b.batchNumber === batchNumber) {
          const financialValue = status === 'QUARANTINED' ? (b.costPerLitre * b.actualKg / 1.42) : undefined;
          return {
            ...b,
            status,
            quarantineReason: quarantineReason || b.quarantineReason,
            quarantineFinancialValue: financialValue
          };
        }
        return b;
      })
    );

    if (status === 'QUARANTINED') {
      // Also update associated pallets and SKUs to quarantine!
      setPallets(prev =>
        prev.map(p => (p.batchNumber === batchNumber ? { ...p, status: 'QUARANTINE' } : p))
      );
    }

    addEventLog({
      eventType: status === 'QUARANTINED' ? 'BATCH_QUARANTINED' : 'BATCH_STATUS_UPDATE',
      actor: 'Quality Assurance Control',
      description: `Batch ${batchNumber} updated to ${status}${quarantineReason ? `: ${quarantineReason}` : ''}`,
      batchNumber,
      severity: status === 'QUARANTINED' ? 'ALERT' : 'SUCCESS'
    });
  };

  const addPainterJob = (job: PainterJob) => {
    setPainterJobs(prev => [job, ...prev]);
    addEventLog({
      eventType: 'PAINTER_JOB_CREATED',
      actor: job.painterName,
      description: `New Painter Job ${job.id} created for ${job.clientName} in ${job.city}`,
      severity: 'INFO'
    });
  };

  const addSalesOrder = (order: SalesOrder) => {
    setOrders(prev => [order, ...prev]);
    addEventLog({
      eventType: 'ORDER_CREATED',
      actor: order.merchantName,
      description: `Sales Order ${order.id} (£${order.totalAmount.toFixed(2)}) placed by ${order.customerOrPainterName}`,
      severity: 'SUCCESS'
    });
  };

  const addFormulationRevision = (formulaId: string, revision: FormulaVersion) => {
    setFormulations(prev =>
      prev.map(f => {
        if (f.id === formulaId) {
          return {
            ...f,
            currentVersion: revision.versionId,
            revisions: [revision, ...f.revisions]
          };
        }
        return f;
      })
    );
    addEventLog({
      eventType: 'FORMULA_REVISION_ADDED',
      actor: revision.author,
      description: `Formulation ${formulaId} updated to ${revision.versionId}: ${revision.reasonForChange}`,
      severity: 'INFO'
    });
  };

  const calculateBatchCostWithShocks = (batchNumber: string) => {
    const batch = batches.find(b => b.batchNumber === batchNumber) || batches[0];
    const formula = formulations.find(f => f.id === batch.formulaId);
    const activeVersion = formula?.revisions.find(r => r.versionId === batch.formulaVersion) || formula?.revisions[0];

    if (!activeVersion) {
      return { rawMaterialCost: 16000, laborCost: 1200, energyCost: 800, totalCost: 18000, costPerLitre: 2.01 };
    }

    let rawMaterialCost = 0;
    activeVersion.ingredients.forEach(ing => {
      const mat = materials.find(m => m.id === ing.materialId);
      let baseCost = ing.costPerBatch;
      if (mat?.category === 'PIGMENTS' && mat.code.includes('TIO2')) {
        baseCost *= (1 + scenarioShock.tio2PriceShockPct / 100);
      } else if (mat?.category === 'BINDERS') {
        baseCost *= (1 + scenarioShock.resinPriceShockPct / 100);
      }
      rawMaterialCost += baseCost;
    });

    const laborCost = 1250;
    const energyCost = 850;
    const totalCost = rawMaterialCost + laborCost + energyCost;
    const litres = batch.actualKg / (activeVersion.targetDensityGPerMl || 1.42);
    const costPerLitre = totalCost / litres;

    return { rawMaterialCost, laborCost, energyCost, totalCost, costPerLitre };
  };

  const triggerSignatureDemo = (demoNumber: 1 | 2 | 3 | 4) => {
    if (demoNumber === 1) {
      // Demo 1: Trace One Tin of Paint
      setSelectedTraceBatchId('BATCH-26-09184');
      setActiveModule('TRACE');
      addEventLog({
        eventType: 'SIGNATURE_DEMO_LAUNCHED',
        actor: 'User Session',
        description: 'Executing Signature Demo 1: Complete Traceability of Batch BATCH-26-09184 (Bristol Stone 5L Tin)',
        batchNumber: 'BATCH-26-09184',
        severity: 'INFO'
      });
    } else if (demoNumber === 2) {
      // Demo 2: Raw Material Shock (+18% TiO2 price)
      setScenarioShock(prev => ({
        ...prev,
        tio2PriceShockPct: prev.tio2PriceShockPct === 18 ? 0 : 18
      }));
      setMaterials(prev =>
        prev.map(m => (m.category === 'PIGMENTS' && m.code.includes('TIO2') ? { ...m, costPerKg: 3.40 * (1 + 18 / 100) } : m))
      );
      setActiveModule('ANALYTICS');
      addEventLog({
        eventType: 'SIGNATURE_DEMO_LAUNCHED',
        actor: 'Scenario Engine',
        description: 'Executing Signature Demo 2: Simulated +18% TiO2 Raw Material Cost Shock across formulations & batch margins',
        severity: 'WARNING'
      });
    } else if (demoNumber === 3) {
      // Demo 3: Shade Failure & Quarantine
      updateBatchStatus('BATCH-26-09184', 'QUARANTINED', 'Shade Deviation ΔE = 1.42 (Target < 1.00)');
      setScenarioShock(prev => ({ ...prev, shadeFailureTriggered: true }));
      setActiveModule('QUALITY');
      addEventLog({
        eventType: 'SIGNATURE_DEMO_LAUNCHED',
        actor: 'QC Laboratory',
        description: 'Executing Signature Demo 3: Shade QC Failure on BATCH-26-09184 → Quarantine & Hold £18,420 Stock',
        batchNumber: 'BATCH-26-09184',
        severity: 'ALERT'
      });
    } else if (demoNumber === 4) {
      // Demo 4: Painter to Factory Demand Propagation
      const newJobId = `JOB-00${Math.floor(Math.random() * 8000 + 1000)}`;
      const newJob: PainterJob = {
        id: newJobId,
        painterName: 'Apex Decorators UK Ltd.',
        clientName: 'Yorkshire Heritage Trust',
        propertyAddress: 'The Old Rectory, Harrogate HG1 2PA',
        city: 'Harrogate',
        status: 'PAINT_ORDERED',
        createdDate: new Date().toISOString().split('T')[0],
        totalLitresEstimated: 120,
        rooms: [
          {
            roomId: 'RM-YORK-01',
            roomName: 'Grand Drawing Room & Gallery',
            lengthM: 12.0,
            widthM: 8.5,
            heightM: 4.0,
            doors: 4,
            windows: 6,
            coats: 2,
            substrate: 'Historic Lime Render',
            wallAreaM2: 164.0,
            ceilingAreaM2: 102.0,
            estimatedLitresRequired: 120,
            productName: 'Premium Interior Matt Emulsion',
            colourName: 'Bristol Stone',
            colourHex: '#C8BFB0',
            allocatedBatchNumber: 'BATCH-26-09184'
          }
        ]
      };
      addPainterJob(newJob);
      setActiveModule('PAINTERS');
      addEventLog({
        eventType: 'SIGNATURE_DEMO_LAUNCHED',
        actor: 'Painter Application',
        description: `Executing Signature Demo 4: Painter Job ${newJobId} created -> 120L Trade Demand propagated to Factory Schedule`,
        severity: 'SUCCESS'
      });
    }
  };

  const value = useMemo(
    () => ({
      activeModule,
      setActiveModule,
      activePersona,
      setActivePersona,
      suppliers,
      materials,
      materialLots,
      formulations,
      colours,
      tanks,
      batches,
      skus,
      pallets,
      shipments,
      merchants,
      orders,
      painterJobs,
      eventLogs,
      searchQuery,
      setSearchQuery,
      selectedTraceBatchId,
      setSelectedTraceBatchId,
      scenarioShock,
      setScenarioShock,
      triggerSignatureDemo,
      updateLotStatus,
      updateBatchStatus,
      addPainterJob,
      addSalesOrder,
      addFormulationRevision,
      addEventLog,
      calculateBatchCostWithShocks
    }),
    [
      activeModule,
      activePersona,
      suppliers,
      materials,
      materialLots,
      formulations,
      colours,
      tanks,
      batches,
      skus,
      pallets,
      shipments,
      merchants,
      orders,
      painterJobs,
      eventLogs,
      searchQuery,
      selectedTraceBatchId,
      scenarioShock
    ]
  );

  return <PaintChainContext.Provider value={value}>{children}</PaintChainContext.Provider>;
};

export const usePaintChain = () => {
  const context = useContext(PaintChainContext);
  if (!context) {
    throw new Error('usePaintChain must be used within a PaintChainProvider');
  }
  return context;
};
