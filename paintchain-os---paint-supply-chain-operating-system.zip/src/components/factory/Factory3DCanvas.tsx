import React, { useState } from 'react';
import { usePaintChain } from '../../context/PaintChainContext';
import { FactoryTank } from '../../types/paintchain';
import { Factory, Activity, Thermometer, RotateCw, CheckCircle2, AlertOctagon, Wrench } from 'lucide-react';

export const Factory3DCanvas: React.FC = () => {
  const { tanks, batches, setSelectedTraceBatchId, setActiveModule } = usePaintChain();
  const [selectedTank, setSelectedTank] = useState<FactoryTank | null>(tanks[0]);

  return (
    <div className="bg-[#151817] border border-[#292D2C] rounded-lg p-4 space-y-4">
      {/* Title Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-[#292D2C]">
        <div>
          <div className="flex items-center gap-2">
            <Factory className="w-5 h-5 text-[#31596A]" />
            <h3 className="font-display font-bold text-base text-[#ECE9E1]">
              BRISTOL CENTRAL PAINT PLANT — 2.5D DIGITAL TWIN
            </h3>
          </div>
          <p className="text-xs text-[#68716F] font-mono mt-0.5">
            Real-time Telemetry, Agitation RPM, Temperature Monitors & Liquid Tank Levels
          </p>
        </div>

        <div className="flex items-center gap-3 text-xs font-mono">
          <span className="flex items-center gap-1 text-[#486451]">
            <span className="w-2 h-2 rounded-full bg-[#486451] animate-ping" /> Active Vessels: {tanks.filter(t => t.status === 'Active').length}/{tanks.length}
          </span>
          <span className="text-[#68716F]">|</span>
          <span className="text-[#ECE9E1]">Overall Plant Load: 86.4%</span>
        </div>
      </div>

      {/* Interactive Plant Diagram */}
      <div className="relative bg-[#151817] border border-[#292D2C] rounded-lg p-6 overflow-hidden min-h-[380px] flex flex-col justify-between">
        {/* Subtle grid background */}
        <div
          className="absolute inset-0 opacity-10 pointer-events-none"
          style={{
            backgroundImage: `radial-gradient(#31596A 1px, transparent 1px)`,
            backgroundSize: '24px 24px'
          }}
        />

        {/* Process Flow Pipelines header line */}
        <div className="relative z-10 flex items-center justify-between text-[11px] font-mono text-[#68716F] border-b border-[#292D2C] pb-2 mb-4">
          <span>STAGE 1: BINDER & SOLVENT SILOS</span>
          <span>STAGE 2: HIGH-SPEED DISPERSION & MILLING</span>
          <span>STAGE 3: LET-DOWN & FILLING LINE</span>
        </div>

        {/* Plant Vessels Grid */}
        <div className="relative z-10 grid grid-cols-1 md:grid-cols-5 gap-4">
          {tanks.map((tank, idx) => {
            const isSelected = selectedTank?.id === tank.id;
            const levelPct = Math.round((tank.currentLevelL / tank.capacityL) * 100);

            return (
              <div
                key={tank.id}
                onClick={() => setSelectedTank(tank)}
                className={`p-3 rounded border transition-all cursor-pointer relative group flex flex-col justify-between ${
                  isSelected
                    ? 'bg-[#292D2C] border-[#31596A] shadow-lg shadow-[#31596A]/20 scale-[1.02]'
                    : 'bg-[#292D2C]/40 border-[#292D2C] hover:border-[#68716F]'
                }`}
              >
                {/* Tank Header */}
                <div>
                  <div className="flex items-center justify-between text-xs font-mono mb-1">
                    <span className="font-bold text-[#ECE9E1]">{tank.id}</span>
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded font-semibold ${
                        tank.status === 'Active'
                          ? 'bg-[#486451]/20 text-[#486451]'
                          : tank.status === 'Idle'
                          ? 'bg-[#68716F]/20 text-[#68716F]'
                          : 'bg-[#C28A35]/20 text-[#C28A35]'
                      }`}
                    >
                      {tank.status}
                    </span>
                  </div>
                  <div className="text-[11px] font-medium text-[#B9B7B0] truncate">{tank.type}</div>
                </div>

                {/* Animated Tank Visual */}
                <div className="my-3 flex items-center justify-center relative">
                  <div className="w-16 h-24 rounded-t-lg border-2 border-[#68716F] bg-[#151817] relative overflow-hidden flex flex-col justify-end">
                    {/* Liquid fill animation */}
                    <div
                      className="w-full bg-[#31596A]/80 transition-all duration-700 relative"
                      style={{ height: `${levelPct}%` }}
                    >
                      {/* Agitation wave effect */}
                      {tank.rpm > 0 && (
                        <div className="absolute top-0 inset-x-0 h-1 bg-white/40 animate-pulse" />
                      )}
                    </div>

                    {/* Disperser Agitator Blade Overlay */}
                    {tank.rpm > 0 && (
                      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                        <RotateCw className="w-6 h-6 text-[#ECE9E1]/70 animate-spin" style={{ animationDuration: `${Math.max(0.5, 3000 / (tank.rpm || 100))}s` }} />
                      </div>
                    )}

                    {/* Level percentage text */}
                    <div className="absolute inset-0 flex items-center justify-center font-mono text-[10px] font-bold text-white drop-shadow">
                      {levelPct}%
                    </div>
                  </div>
                </div>

                {/* Tank Metrics */}
                <div className="space-y-1 text-[10px] font-mono text-[#68716F] pt-2 border-t border-[#292D2C]">
                  <div className="flex justify-between">
                    <span>Level:</span>
                    <span className="text-[#ECE9E1]">{tank.currentLevelL.toLocaleString()} L</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Temp:</span>
                    <span className="text-[#B58A3C]">{tank.temperatureC}°C</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Agitation:</span>
                    <span className="text-[#31596A]">{tank.rpm} RPM</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Tank Inspection Drawer */}
        {selectedTank && (
          <div className="relative z-10 mt-6 p-4 rounded bg-[#292D2C] border border-[#31596A]/50 flex flex-wrap items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="font-mono font-bold text-sm text-[#ECE9E1]">{selectedTank.name}</span>
                <span className="text-xs px-2 py-0.5 rounded bg-[#151817] text-[#31596A] font-mono">
                  Capacity: {selectedTank.capacityL.toLocaleString()} L
                </span>
              </div>
              <div className="text-xs text-[#B9B7B0]">
                Current Active Batch: <strong className="text-[#ECE9E1] font-mono">{selectedTank.currentBatchNumber || 'NO BATCH ASSIGNED'}</strong>
              </div>
            </div>

            <div className="flex items-center gap-4 text-xs font-mono">
              <div className="text-right">
                <div className="text-[#68716F]">AGITATION SPEED</div>
                <div className="text-sm font-bold text-[#31596A]">{selectedTank.rpm} RPM</div>
              </div>
              <div className="text-right">
                <div className="text-[#68716F]">VESSEL TEMP</div>
                <div className="text-sm font-bold text-[#B58A3C]">{selectedTank.temperatureC} °C</div>
              </div>
              <div className="text-right">
                <div className="text-[#68716F]">UTILISATION</div>
                <div className="text-sm font-bold text-[#486451]">{selectedTank.utilizationPct}%</div>
              </div>

              {selectedTank.currentBatchNumber && (
                <button
                  onClick={() => {
                    setSelectedTraceBatchId(selectedTank.currentBatchNumber!);
                    setActiveModule('TRACE');
                  }}
                  className="px-3 py-1.5 rounded bg-[#31596A] hover:bg-[#31596A]/80 text-white font-sans text-xs font-semibold cursor-pointer transition-colors"
                >
                  Inspect Batch Trace →
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
