import React, { useState, useEffect } from 'react';
import { usePaintChain, ModuleType } from '../../context/PaintChainContext';
import { Search, X, Factory, Layers, FlaskConical, Building2, Paintbrush, Package, ArrowRight } from 'lucide-react';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({ isOpen, onClose }) => {
  const {
    suppliers,
    materials,
    materialLots,
    formulations,
    colours,
    batches,
    skus,
    orders,
    painterJobs,
    setActiveModule,
    setSelectedTraceBatchId
  } = usePaintChain();

  const [term, setTerm] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
        else setTerm('');
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const lowerTerm = term.toLowerCase().trim();

  // Search matches
  const batchMatches = batches.filter(
    b =>
      b.batchNumber.toLowerCase().includes(lowerTerm) ||
      b.colourName.toLowerCase().includes(lowerTerm) ||
      b.productName.toLowerCase().includes(lowerTerm)
  );

  const colourMatches = colours.filter(
    c => c.name.toLowerCase().includes(lowerTerm) || c.colourCode.toLowerCase().includes(lowerTerm)
  );

  const supplierMatches = suppliers.filter(
    s => s.name.toLowerCase().includes(lowerTerm) || s.code.toLowerCase().includes(lowerTerm)
  );

  const lotMatches = materialLots.filter(
    l => l.lotNumber.toLowerCase().includes(lowerTerm) || l.supplierLotRef.toLowerCase().includes(lowerTerm)
  );

  const formulaMatches = formulations.filter(
    f => f.formulaCode.toLowerCase().includes(lowerTerm) || f.name.toLowerCase().includes(lowerTerm)
  );

  const jobMatches = painterJobs.filter(
    j =>
      j.id.toLowerCase().includes(lowerTerm) ||
      j.clientName.toLowerCase().includes(lowerTerm) ||
      j.painterName.toLowerCase().includes(lowerTerm) ||
      j.propertyAddress.toLowerCase().includes(lowerTerm)
  );

  const navigateTo = (module: ModuleType, batchId?: string) => {
    if (batchId) {
      setSelectedTraceBatchId(batchId);
    }
    setActiveModule(module);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-start justify-center pt-20 px-4">
      <div className="bg-[#151817] border border-[#31596A]/60 rounded-lg max-w-2xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[80vh]">
        {/* Search Header */}
        <div className="p-4 border-b border-[#292D2C] flex items-center gap-3 bg-[#292D2C]/40">
          <Search className="w-5 h-5 text-[#31596A]" />
          <input
            type="text"
            value={term}
            onChange={e => setTerm(e.target.value)}
            placeholder="Search batch number, colour, chemical, supplier, job, formula, lot..."
            className="flex-1 bg-transparent text-[#ECE9E1] placeholder-[#68716F] font-mono text-sm focus:outline-none"
            autoFocus
          />
          <button onClick={onClose} className="p-1 rounded text-[#68716F] hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results List */}
        <div className="p-4 overflow-y-auto space-y-6 divide-y divide-[#292D2C]">
          {!lowerTerm && (
            <div className="text-center py-8 text-[#68716F] text-xs font-mono">
              Type to search the entire PaintChain OS digital twin dataset...
              <div className="mt-2 flex justify-center gap-2">
                <span className="px-2 py-0.5 rounded bg-[#292D2C] text-[#ECE9E1]">BATCH-26-09184</span>
                <span className="px-2 py-0.5 rounded bg-[#292D2C] text-[#ECE9E1]">Bristol Stone</span>
                <span className="px-2 py-0.5 rounded bg-[#292D2C] text-[#ECE9E1]">RM-TIO2</span>
                <span className="px-2 py-0.5 rounded bg-[#292D2C] text-[#ECE9E1]">JOB-004182</span>
              </div>
            </div>
          )}

          {/* Batches */}
          {batchMatches.length > 0 && (
            <div className="pt-2">
              <div className="text-[11px] font-mono text-[#31596A] font-semibold uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Factory className="w-3.5 h-3.5" /> Production Batches ({batchMatches.length})
              </div>
              <div className="space-y-1.5">
                {batchMatches.map(b => (
                  <button
                    key={b.batchNumber}
                    onClick={() => navigateTo('TRACE', b.batchNumber)}
                    className="w-full text-left p-2.5 rounded bg-[#292D2C]/40 hover:bg-[#292D2C] border border-[#292D2C] hover:border-[#31596A] transition-all flex items-center justify-between group cursor-pointer"
                  >
                    <div>
                      <span className="font-mono text-xs font-bold text-[#ECE9E1] mr-2">{b.batchNumber}</span>
                      <span className="text-xs text-[#B9B7B0]">{b.productName} — {b.colourName}</span>
                      <span className="ml-2 text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#151817] text-[#486451]">
                        {b.status}
                      </span>
                    </div>
                    <ArrowRight className="w-4 h-4 text-[#68716F] group-hover:text-white transition-colors" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Colours */}
          {colourMatches.length > 0 && (
            <div className="pt-4">
              <div className="text-[11px] font-mono text-[#B58A3C] font-semibold uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <FlaskConical className="w-3.5 h-3.5" /> Colours & Shade Recipes ({colourMatches.length})
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {colourMatches.map(c => (
                  <button
                    key={c.id}
                    onClick={() => navigateTo('LAB')}
                    className="text-left p-2.5 rounded bg-[#292D2C]/40 hover:bg-[#292D2C] border border-[#292D2C] hover:border-[#B58A3C] transition-all flex items-center gap-3 group cursor-pointer"
                  >
                    <div className="w-5 h-5 rounded border border-[#68716F]" style={{ backgroundColor: c.hex }} />
                    <div className="flex-1">
                      <div className="font-semibold text-xs text-[#ECE9E1]">{c.name}</div>
                      <div className="font-mono text-[10px] text-[#68716F]">{c.colourCode} · Lab({c.lab.L}, {c.lab.a}, {c.lab.b})</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Suppliers & Lots */}
          {(supplierMatches.length > 0 || lotMatches.length > 0) && (
            <div className="pt-4">
              <div className="text-[11px] font-mono text-[#486451] font-semibold uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5" /> Chemical Suppliers & Raw Material Lots
              </div>
              <div className="space-y-1.5">
                {supplierMatches.map(s => (
                  <button
                    key={s.id}
                    onClick={() => navigateTo('SUPPLY')}
                    className="w-full text-left p-2 rounded bg-[#292D2C]/40 hover:bg-[#292D2C] text-xs flex justify-between cursor-pointer"
                  >
                    <span className="font-semibold text-[#ECE9E1]">{s.name} ({s.code})</span>
                    <span className="text-[#68716F] font-mono">{s.city}, {s.country}</span>
                  </button>
                ))}
                {lotMatches.map(l => (
                  <button
                    key={l.lotNumber}
                    onClick={() => navigateTo('MATERIALS')}
                    className="w-full text-left p-2 rounded bg-[#292D2C]/40 hover:bg-[#292D2C] text-xs flex justify-between cursor-pointer"
                  >
                    <span className="font-mono text-[#B58A3C] font-semibold">{l.lotNumber}</span>
                    <span className="text-[#68716F] font-mono">{l.quantityKg.toLocaleString()} kg · {l.status}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Painter Jobs */}
          {jobMatches.length > 0 && (
            <div className="pt-4">
              <div className="text-[11px] font-mono text-[#315A78] font-semibold uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Paintbrush className="w-3.5 h-3.5" /> Painter Jobs & Project Surfaces ({jobMatches.length})
              </div>
              <div className="space-y-1.5">
                {jobMatches.map(j => (
                  <button
                    key={j.id}
                    onClick={() => navigateTo('PROJECTS')}
                    className="w-full text-left p-2.5 rounded bg-[#292D2C]/40 hover:bg-[#292D2C] border border-[#292D2C] transition-all cursor-pointer"
                  >
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-mono font-bold text-[#ECE9E1]">{j.id} — {j.clientName}</span>
                      <span className="text-[#68716F]">{j.city}</span>
                    </div>
                    <div className="text-[11px] text-[#B9B7B0] truncate mt-0.5">{j.propertyAddress}</div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
