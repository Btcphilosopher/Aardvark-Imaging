import React from 'react';
import { usePaintChain } from '../../context/PaintChainContext';
import { Activity, X, AlertTriangle, CheckCircle2, Info, Factory, ShieldAlert } from 'lucide-react';

interface EventStreamConsoleProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EventStreamConsole: React.FC<EventStreamConsoleProps> = ({ isOpen, onClose }) => {
  const { eventLogs, setSelectedTraceBatchId, setActiveModule } = usePaintChain();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-[480px] bg-[#151817] border-l border-[#31596A]/60 shadow-2xl flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-[#292D2C] bg-[#292D2C]/40 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Activity className="w-5 h-5 text-[#486451] animate-pulse" />
          <span className="font-display font-bold text-sm text-[#ECE9E1] tracking-wide">
            INDUSTRIAL EVENT STREAM
          </span>
          <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-[#31596A]/30 text-[#31596A] border border-[#31596A]/50">
            WEBSOCKET LIVE
          </span>
        </div>
        <button onClick={onClose} className="p-1 rounded text-[#68716F] hover:text-white">
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Subheader info */}
      <div className="px-4 py-2 bg-[#292D2C] text-[11px] font-mono text-[#B9B7B0] flex items-center justify-between border-b border-[#292D2C]">
        <span>Audit Trail & Telemetry Fan-Out</span>
        <span>{eventLogs.length} Events Recorded</span>
      </div>

      {/* Event List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 font-mono text-xs">
        {eventLogs.map(evt => {
          let badgeColor = 'bg-[#292D2C] text-[#B9B7B0]';
          let Icon = Info;
          if (evt.severity === 'SUCCESS') {
            badgeColor = 'bg-[#486451]/20 text-[#486451] border-[#486451]/40';
            Icon = CheckCircle2;
          } else if (evt.severity === 'ALERT') {
            badgeColor = 'bg-[#9D4038]/20 text-[#9D4038] border-[#9D4038]/40 animate-pulse';
            Icon = ShieldAlert;
          } else if (evt.severity === 'WARNING') {
            badgeColor = 'bg-[#C28A35]/20 text-[#C28A35] border-[#C28A35]/40';
            Icon = AlertTriangle;
          }

          return (
            <div
              key={evt.id}
              className="p-3 rounded bg-[#292D2C]/30 border border-[#292D2C] hover:border-[#31596A] transition-all space-y-1.5"
            >
              <div className="flex items-center justify-between text-[11px] text-[#68716F]">
                <span className="flex items-center gap-1.5 font-semibold text-[#ECE9E1]">
                  <Icon className="w-3.5 h-3.5" />
                  {evt.eventType}
                </span>
                <span>{evt.timestamp}</span>
              </div>

              <div className="text-xs text-[#ECE9E1] font-sans leading-relaxed">
                {evt.description}
              </div>

              <div className="flex items-center justify-between text-[10px] text-[#68716F] pt-1 border-t border-[#292D2C]/60">
                <span>Actor: {evt.actor}</span>
                {evt.batchNumber && (
                  <button
                    onClick={() => {
                      setSelectedTraceBatchId(evt.batchNumber!);
                      setActiveModule('TRACE');
                      onClose();
                    }}
                    className="text-[#31596A] hover:underline flex items-center gap-1 font-mono font-bold cursor-pointer"
                  >
                    <Factory className="w-3 h-3" />
                    {evt.batchNumber} →
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
