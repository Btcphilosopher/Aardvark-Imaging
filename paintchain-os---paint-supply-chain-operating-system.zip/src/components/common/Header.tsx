import React, { useState } from 'react';
import { usePaintChain, ModuleType } from '../../context/PaintChainContext';
import {
  Search,
  Activity,
  Layers,
  FlaskConical,
  Factory,
  CheckCircle2,
  Package,
  Truck,
  Building2,
  Paintbrush,
  Sparkles,
  Zap,
  TrendingUp,
  AlertTriangle,
  User,
  Menu,
  X
} from 'lucide-react';
import { UserPersona } from '../../types/paintchain';

const MODULES: { id: ModuleType; label: string; icon: React.FC<{ className?: string }> }[] = [
  { id: 'OVERVIEW', label: 'Overview', icon: Activity },
  { id: 'SUPPLY', label: 'Supply', icon: Building2 },
  { id: 'MATERIALS', label: 'Materials', icon: Layers },
  { id: 'LAB', label: 'Lab', icon: FlaskConical },
  { id: 'FORMULAS', label: 'Formulas', icon: Sparkles },
  { id: 'PRODUCTION', label: 'Production', icon: Factory },
  { id: 'QUALITY', label: 'Quality', icon: CheckCircle2 },
  { id: 'INVENTORY', label: 'Inventory', icon: Package },
  { id: 'LOGISTICS', label: 'Logistics', icon: Truck },
  { id: 'PRODUCTS', label: 'Products', icon: Package },
  { id: 'TRADE', label: 'Trade', icon: Building2 },
  { id: 'PAINTERS', label: 'Painters', icon: Paintbrush },
  { id: 'PROJECTS', label: 'Projects', icon: Layers },
  { id: 'TRACE', label: 'Trace', icon: Activity },
  { id: 'ANALYTICS', label: 'Analytics', icon: TrendingUp }
];

const PERSONAS: { id: UserPersona; label: string }[] = [
  { id: 'ALL', label: 'System Admin / Executive' },
  { id: 'SUPPLIER', label: 'Chemical Supplier' },
  { id: 'MANUFACTURER', label: 'Paint Manufacturer' },
  { id: 'LAB_CHEMIST', label: 'Colour Chemist' },
  { id: 'WAREHOUSE_MGR', label: 'Warehouse Manager' },
  { id: 'TRADE_MERCHANT', label: 'Trade Merchant' },
  { id: 'PAINTER', label: 'Professional Painter' },
  { id: 'ARCHITECT', label: 'Architect / Designer' },
  { id: 'CUSTOMER', label: 'Property Owner' }
];

interface HeaderProps {
  onOpenSearch: () => void;
  onOpenEvents: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenSearch, onOpenEvents }) => {
  const {
    activeModule,
    setActiveModule,
    activePersona,
    setActivePersona,
    triggerSignatureDemo,
    scenarioShock,
    batches
  } = usePaintChain();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [demosDropdownOpen, setDemosDropdownOpen] = useState(false);

  const quarantinedBatch = batches.find(b => b.status === 'QUARANTINED');

  return (
    <header className="sticky top-0 z-40 bg-[#151817]/95 backdrop-blur border-b border-[#292D2C]">
      {/* Signature Demos Announcement Bar */}
      <div className="bg-[#292D2C] text-[#ECE9E1] px-4 py-1 text-xs border-b border-[#31596A]/30 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1 font-mono text-[#B58A3C] font-semibold">
            <Zap className="w-3.5 h-3.5 text-[#C28A35] animate-pulse" /> SIGNATURE DEMOS:
          </span>
          <button
            onClick={() => triggerSignatureDemo(1)}
            className="hover:text-[#31596A] text-[#ECE9E1] underline decoration-[#31596A] underline-offset-2 transition-colors cursor-pointer"
          >
            1. Trace Batch-09184
          </button>
          <span className="text-[#68716F]">·</span>
          <button
            onClick={() => triggerSignatureDemo(2)}
            className={`hover:text-[#31596A] transition-colors cursor-pointer ${
              scenarioShock.tio2PriceShockPct > 0 ? 'text-[#C28A35] font-bold' : ''
            }`}
          >
            2. Raw Material Shock ({scenarioShock.tio2PriceShockPct > 0 ? `+${scenarioShock.tio2PriceShockPct}% TiO₂ ACTIVE` : 'Simulate +18% TiO₂'})
          </button>
          <span className="text-[#68716F]">·</span>
          <button
            onClick={() => triggerSignatureDemo(3)}
            className={`hover:text-[#9D4038] transition-colors cursor-pointer ${
              quarantinedBatch ? 'text-[#9D4038] font-bold animate-pulse' : ''
            }`}
          >
            3. Shade Failure Quarantine {quarantinedBatch ? '(QUARANTINE ACTIVE)' : ''}
          </button>
          <span className="text-[#68716F]">·</span>
          <button
            onClick={() => triggerSignatureDemo(4)}
            className="hover:text-[#486451] transition-colors cursor-pointer"
          >
            4. Painter Demand Cascade
          </button>
        </div>

        <div className="flex items-center gap-4">
          <button
            onClick={onOpenEvents}
            className="flex items-center gap-1.5 font-mono text-[11px] text-[#31596A] hover:text-white transition-colors cursor-pointer"
          >
            <Activity className="w-3.5 h-3.5 text-[#486451]" />
            LIVE EVENT STREAM
          </button>
        </div>
      </div>

      {/* Main Top Bar */}
      <div className="max-w-[1700px] mx-auto px-4 lg:px-6 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <a
            onClick={() => setActiveModule('OVERVIEW')}
            className="cursor-pointer group flex items-center gap-2.5"
          >
            <div className="w-8 h-8 rounded bg-gradient-to-br from-[#31596A] to-[#292D2C] border border-[#31596A]/50 flex items-center justify-center font-display font-extrabold text-[#ECE9E1] text-base group-hover:border-[#ECE9E1] transition-all">
              P
            </div>
            <div>
              <span className="font-display font-extrabold tracking-tight text-lg text-[#ECE9E1] group-hover:text-white transition-colors">
                PAINTCHAIN <span className="text-[#31596A]">OS</span>
              </span>
            </div>
          </a>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden xl:flex items-center gap-1 overflow-x-auto py-1 scrollbar-none">
          {MODULES.map(m => {
            const Icon = m.icon;
            const isActive = activeModule === m.id;
            return (
              <button
                key={m.id}
                onClick={() => setActiveModule(m.id)}
                className={`px-2.5 py-1.5 rounded text-xs font-medium transition-all whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
                  isActive
                    ? 'bg-[#292D2C] text-white border border-[#31596A]/60 shadow-sm'
                    : 'text-[#B9B7B0] hover:text-[#ECE9E1] hover:bg-[#292D2C]/50'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#31596A]' : 'text-[#68716F]'}`} />
                {m.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Search & Actions */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenSearch}
            className="flex items-center gap-2 px-3 py-1.5 rounded bg-[#292D2C] border border-[#68716F]/30 text-xs text-[#B9B7B0] hover:text-white hover:border-[#31596A] transition-all cursor-pointer"
          >
            <Search className="w-3.5 h-3.5 text-[#31596A]" />
            <span className="hidden sm:inline font-mono">SEARCH ANYTHING (Ctrl+K)</span>
          </button>

          {/* Persona Switcher */}
          <div className="hidden sm:flex items-center gap-1.5 bg-[#292D2C] border border-[#68716F]/30 rounded px-2 py-1">
            <User className="w-3.5 h-3.5 text-[#B58A3C]" />
            <select
              value={activePersona}
              onChange={e => setActivePersona(e.target.value as UserPersona)}
              className="bg-transparent text-xs text-[#ECE9E1] font-mono focus:outline-none cursor-pointer"
            >
              {PERSONAS.map(p => (
                <option key={p.id} value={p.id} className="bg-[#151817] text-[#ECE9E1]">
                  {p.label}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="xl:hidden p-2 rounded bg-[#292D2C] text-[#ECE9E1] hover:text-white"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Nav Menu */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-[#151817] border-b border-[#292D2C] p-4 grid grid-cols-2 sm:grid-cols-3 gap-2">
          {MODULES.map(m => {
            const Icon = m.icon;
            const isActive = activeModule === m.id;
            return (
              <button
                key={m.id}
                onClick={() => {
                  setActiveModule(m.id);
                  setMobileMenuOpen(false);
                }}
                className={`p-2 rounded text-xs font-medium flex items-center gap-2 ${
                  isActive ? 'bg-[#31596A] text-white' : 'text-[#B9B7B0] bg-[#292D2C]/40'
                }`}
              >
                <Icon className="w-4 h-4" />
                {m.label}
              </button>
            );
          })}
        </div>
      )}
    </header>
  );
};
