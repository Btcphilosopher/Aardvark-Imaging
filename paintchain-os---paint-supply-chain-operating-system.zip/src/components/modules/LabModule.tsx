import React, { useState } from 'react';
import { usePaintChain } from '../../context/PaintChainContext';
import { FlaskConical, CheckCircle2, AlertTriangle, RefreshCw, Layers } from 'lucide-react';

export const LabModule: React.FC = () => {
  const { colours, batches } = usePaintChain();
  const [selectedColourId, setSelectedColourId] = useState(colours[0].id);

  const activeColour = colours.find(c => c.id === selectedColourId) || colours[0];

  // Simulated test sample vs target
  const [sampleLab, setSampleLab] = useState({
    L: activeColour.lab.L + 0.3,
    a: activeColour.lab.a - 0.2,
    b: activeColour.lab.b + 0.4
  });

  const deltaL = sampleLab.L - activeColour.lab.L;
  const deltaA = sampleLab.a - activeColour.lab.a;
  const deltaB = sampleLab.b - activeColour.lab.b;
  const deltaE = Math.sqrt(deltaL * deltaL + deltaA * deltaA + deltaB * deltaB);

  const isWithinTolerance = deltaE <= 1.0;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-4 rounded-lg bg-[#151817] border border-[#292D2C] flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <FlaskConical className="w-5 h-5 text-[#B58A3C]" />
            <h2 className="font-display font-bold text-xl text-[#ECE9E1]">SHADE MATCHING & COLOUR SCIENCE LAB</h2>
          </div>
          <p className="text-xs text-[#68716F] font-mono mt-0.5">
            Spectrophotometry Comparison, CIELAB Coordinates (L*a*b*), ΔE Calculation & Pigment Correction Recipes
          </p>
        </div>

        {/* Colour Selector */}
        <div className="flex items-center gap-2 bg-[#292D2C] p-1.5 rounded font-mono text-xs">
          <span className="text-[#68716F]">Target Shade:</span>
          <select
            value={selectedColourId}
            onChange={e => {
              setSelectedColourId(e.target.value);
              const col = colours.find(c => c.id === e.target.value);
              if (col) {
                setSampleLab({ L: col.lab.L + 0.3, a: col.lab.a - 0.2, b: col.lab.b + 0.4 });
              }
            }}
            className="bg-[#151817] text-[#ECE9E1] font-bold px-2 py-1 rounded focus:outline-none cursor-pointer"
          >
            {colours.map(c => (
              <option key={c.id} value={c.id}>
                {c.name} ({c.colourCode})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Target vs Sample Comparison Board */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Visual Swatch Comparison */}
        <div className="p-6 rounded-lg bg-[#151817] border border-[#292D2C] space-y-4">
          <h3 className="font-display font-bold text-sm text-[#ECE9E1]">Visual Swatch Comparison</h3>

          <div className="grid grid-cols-2 gap-4">
            {/* Target Standard */}
            <div className="space-y-2">
              <div
                className="h-32 rounded-lg border-2 border-[#68716F] shadow-inner flex items-end p-3"
                style={{ backgroundColor: activeColour.hex }}
              >
                <span className="px-2 py-0.5 rounded bg-black/60 text-white font-mono text-[10px] font-bold">
                  TARGET STANDARD
                </span>
              </div>
              <div className="font-mono text-xs text-[#ECE9E1] space-y-0.5">
                <div className="font-bold">{activeColour.name}</div>
                <div className="text-[10px] text-[#68716F]">L*: {activeColour.lab.L} · a*: {activeColour.lab.a} · b*: {activeColour.lab.b}</div>
              </div>
            </div>

            {/* Batch Sample */}
            <div className="space-y-2">
              <div
                className="h-32 rounded-lg border-2 border-[#68716F] shadow-inner flex items-end p-3 relative overflow-hidden"
                style={{ backgroundColor: activeColour.hex }}
              >
                <span className="px-2 py-0.5 rounded bg-black/60 text-white font-mono text-[10px] font-bold">
                  BATCH SAMPLE
                </span>
              </div>
              <div className="font-mono text-xs text-[#ECE9E1] space-y-0.5">
                <div className="font-bold">Batch 26-09184 Specimen</div>
                <div className="text-[10px] text-[#68716F]">L*: {sampleLab.L.toFixed(1)} · a*: {sampleLab.a.toFixed(1)} · b*: {sampleLab.b.toFixed(1)}</div>
              </div>
            </div>
          </div>

          {/* Delta E Result */}
          <div className={`p-4 rounded-lg border font-mono text-center space-y-1 ${
            isWithinTolerance
              ? 'bg-[#486451]/20 border-[#486451]/50 text-[#486451]'
              : 'bg-[#9D4038]/20 border-[#9D4038]/50 text-[#9D4038]'
          }`}>
            <div className="text-xs uppercase tracking-wider">SPECTROPHOTOMETER DIFFERENCE (ΔE)</div>
            <div className="text-3xl font-extrabold">{deltaE.toFixed(2)}</div>
            <div className="text-xs font-bold flex items-center justify-center gap-1">
              {isWithinTolerance ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-[#486451]" /> WITHIN TOLERANCE (SPEC &lt; 1.00 ΔE)
                </>
              ) : (
                <>
                  <AlertTriangle className="w-4 h-4 text-[#9D4038]" /> SHADE DEVIATION — ADJUSTMENT REQUIRED
                </>
              )}
            </div>
          </div>
        </div>

        {/* Spectral & CIELAB Coordinates Breakdown */}
        <div className="lg:col-span-2 p-6 rounded-lg bg-[#151817] border border-[#292D2C] space-y-6">
          <div className="flex justify-between items-center border-b border-[#292D2C] pb-3">
            <h3 className="font-display font-bold text-sm text-[#ECE9E1]">CIELAB Colorimetric Breakdown</h3>
            <span className="text-xs font-mono text-[#68716F]">D65 Illuminant / 10° Observer</span>
          </div>

          <div className="grid grid-cols-3 gap-4 font-mono text-xs">
            <div className="p-3 rounded bg-[#292D2C]/40 border border-[#292D2C]">
              <div className="text-[#68716F]">L* (LIGHTNESS)</div>
              <div className="text-lg font-bold text-[#ECE9E1] mt-1">ΔL: {deltaL > 0 ? `+${deltaL.toFixed(2)}` : deltaL.toFixed(2)}</div>
              <div className="text-[10px] text-[#68716F] mt-1">{deltaL > 0 ? 'Slightly Lighter' : 'Slightly Darker'}</div>
            </div>

            <div className="p-3 rounded bg-[#292D2C]/40 border border-[#292D2C]">
              <div className="text-[#68716F]">a* (RED / GREEN)</div>
              <div className="text-lg font-bold text-[#ECE9E1] mt-1">Δa: {deltaA > 0 ? `+${deltaA.toFixed(2)}` : deltaA.toFixed(2)}</div>
              <div className="text-[10px] text-[#68716F] mt-1">{deltaA > 0 ? 'Slightly Redder' : 'Slightly Greener'}</div>
            </div>

            <div className="p-3 rounded bg-[#292D2C]/40 border border-[#292D2C]">
              <div className="text-[#68716F]">b* (YELLOW / BLUE)</div>
              <div className="text-lg font-bold text-[#ECE9E1] mt-1">Δb: {deltaB > 0 ? `+${deltaB.toFixed(2)}` : deltaB.toFixed(2)}</div>
              <div className="text-[10px] text-[#68716F] mt-1">{deltaB > 0 ? 'Slightly Yellower' : 'Slightly Bluer'}</div>
            </div>
          </div>

          {/* Correction Recipe */}
          <div className="p-4 rounded bg-[#292D2C]/30 border border-[#31596A]/40 space-y-3 font-mono text-xs">
            <div className="flex items-center justify-between text-[#ECE9E1] font-bold border-b border-[#292D2C] pb-2">
              <span>COLORIMETRIC CORRECTION RECIPE SUGGESTION</span>
              <span className="text-[11px] text-[#31596A]">AUTO-CALCULATED</span>
            </div>

            <div className="space-y-1 text-[#B9B7B0]">
              <div>Target Batch Size: <strong>8,000 kg</strong></div>
              <div>Suggested Micro-Dose Addition: <strong className="text-[#B58A3C]">+1.2 kg Yellow Ochre Paste (PIG-OCHRE-02)</strong> to compensate Δb</div>
              <div className="text-[11px] text-[#68716F]">Expected Post-Addition ΔE: <strong>0.24 (PASS)</strong></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
