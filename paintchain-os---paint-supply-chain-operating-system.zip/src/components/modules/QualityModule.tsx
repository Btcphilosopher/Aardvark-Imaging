import React from 'react';
import { usePaintChain } from '../../context/PaintChainContext';
import { CheckCircle2, AlertOctagon, ShieldAlert, FileCheck, ArrowRight, RotateCcw } from 'lucide-react';

export const QualityModule: React.FC = () => {
  const { batches, updateBatchStatus, triggerSignatureDemo } = usePaintChain();

  const quarantinedBatch = batches.find(b => b.status === 'QUARANTINED');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-4 rounded-lg bg-[#151817] border border-[#292D2C] flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-[#486451]" />
            <h2 className="font-display font-bold text-xl text-[#ECE9E1]">QUALITY CONTROL & QUARANTINE SYSTEM</h2>
          </div>
          <p className="text-xs text-[#68716F] font-mono mt-0.5">
            Specification Testing: Viscosity (KU), Specific Gravity, Gloss %, ΔE Shade Matching, Non-Volatile Solids & Adhesion
          </p>
        </div>

        <button
          onClick={() => triggerSignatureDemo(3)}
          className="px-3 py-1.5 rounded bg-[#9D4038] hover:bg-[#9D4038]/80 text-white font-mono text-xs font-bold cursor-pointer transition-colors flex items-center gap-1.5"
        >
          <AlertOctagon className="w-4 h-4" />
          Trigger Shade Quarantine Demo
        </button>
      </div>

      {/* Quarantine Alert Panel if active */}
      {quarantinedBatch && (
        <div className="p-6 rounded-lg bg-[#9D4038]/15 border-2 border-[#9D4038] space-y-4 animate-fade-in">
          <div className="flex flex-wrap justify-between items-start gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-[#9D4038] font-mono font-bold text-sm">
                <ShieldAlert className="w-5 h-5 animate-bounce" />
                ACTIVE QUARANTINE HOLD — FINANCIAL & INVENTORY LOCK
              </div>
              <h3 className="font-display font-bold text-lg text-[#ECE9E1]">
                Batch {quarantinedBatch.batchNumber} ({quarantinedBatch.productName} — {quarantinedBatch.colourName})
              </h3>
              <p className="text-xs text-[#B9B7B0] font-mono">
                Reason: {quarantinedBatch.quarantineReason || 'Shade Deviation ΔE = 1.42 (Exceeds Spec Tolerance < 1.00 ΔE)'}
              </p>
            </div>

            <div className="text-right font-mono text-xs">
              <div className="text-[#68716F]">FINANCIAL VALUE ON HOLD</div>
              <div className="text-2xl font-bold text-[#9D4038]">£18,420.00</div>
              <div className="text-[11px] text-[#B9B7B0]">1,840 x 5L SKUs Locked in Warehouse Zone Q</div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-[#9D4038]/40">
            <button
              onClick={() => updateBatchStatus(quarantinedBatch.batchNumber, 'REWORK', 'Micro-Dose Tint Correction Applied')}
              className="px-4 py-2 rounded bg-[#C28A35] hover:bg-[#C28A35]/80 text-white font-mono text-xs font-bold cursor-pointer transition-colors"
            >
              Approve Plant Rework (Tint Correction)
            </button>
            <button
              onClick={() => updateBatchStatus(quarantinedBatch.batchNumber, 'QC_RELEASED')}
              className="px-4 py-2 rounded bg-[#486451] hover:bg-[#486451]/80 text-white font-mono text-xs font-bold cursor-pointer transition-colors"
            >
              Override & Release Batch
            </button>
          </div>
        </div>
      )}

      {/* QC Test Specification Table for BATCH-26-09184 */}
      <div className="p-6 rounded-lg bg-[#151817] border border-[#292D2C] space-y-4">
        <div className="flex justify-between items-center border-b border-[#292D2C] pb-3">
          <div>
            <span className="font-mono font-bold text-sm text-[#31596A]">QC SPECIFICATION SHEET</span>
            <h3 className="font-display font-bold text-base text-[#ECE9E1]">BATCH-26-09184 (Bristol Stone 8,000 kg Run)</h3>
          </div>
          <span className="text-xs font-mono text-[#68716F]">Inspector: Dr. S. Finch (Chief QC Chemist)</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="border-b border-[#292D2C] text-[#68716F]">
                <th className="py-2">Test Parameter</th>
                <th className="py-2">Specification Range</th>
                <th className="py-2">Target Value</th>
                <th className="py-2">Measured Result</th>
                <th className="py-2 text-right">Pass / Fail</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#292D2C]/40 text-[#ECE9E1]">
              {batches[0].qualityTests.map(test => (
                <tr key={test.id}>
                  <td className="py-2 font-semibold text-[#ECE9E1]">{test.testName}</td>
                  <td className="py-2 text-[#68716F]">{test.specification}</td>
                  <td className="py-2 text-[#31596A]">{test.targetValue}</td>
                  <td className="py-2 font-bold text-[#B58A3C]">{test.measuredValue}</td>
                  <td className="py-2 text-right">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        test.passed
                          ? 'bg-[#486451]/20 text-[#486451]'
                          : 'bg-[#9D4038]/20 text-[#9D4038]'
                      }`}
                    >
                      {test.passed ? 'PASS' : 'FAIL'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
