import React, { useState } from 'react';
import { usePaintChain } from '../../context/PaintChainContext';
import { Building2, Award, Clock, FileText, TrendingUp, CheckCircle, AlertTriangle, ShieldCheck } from 'lucide-react';

export const SupplyModule: React.FC = () => {
  const { suppliers, scenarioShock } = usePaintChain();
  const [selectedSupplierId, setSelectedSupplierId] = useState(suppliers[0].id);

  const activeSupplier = suppliers.find(s => s.id === selectedSupplierId) || suppliers[0];

  return (
    <div className="space-y-6">
      {/* Module Title */}
      <div className="p-4 rounded-lg bg-[#151817] border border-[#292D2C] flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-[#31596A]" />
            <h2 className="font-display font-bold text-xl text-[#ECE9E1]">CHEMICAL SUPPLIER DIRECTORY</h2>
          </div>
          <p className="text-xs text-[#68716F] font-mono mt-0.5">
            Verified Chemical Manufacturers, Resin Synthesizers, Pigment Refiners, Technical Certificates & Lead Times
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono">
          <span className="px-2.5 py-1 rounded bg-[#486451]/20 text-[#486451] border border-[#486451]/40 font-bold">
            {suppliers.filter(s => s.approvedStatus === 'Approved').length} APPROVED SUPPLIERS
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Supplier List */}
        <div className="space-y-3">
          <h3 className="text-xs font-mono text-[#68716F] uppercase tracking-wider">Approved Suppliers</h3>
          <div className="space-y-2">
            {suppliers.map(s => {
              const isSelected = s.id === selectedSupplierId;
              const isPriceShocked = s.categories.includes('PIGMENTS') && scenarioShock.tio2PriceShockPct > 0;

              return (
                <div
                  key={s.id}
                  onClick={() => setSelectedSupplierId(s.id)}
                  className={`p-3.5 rounded-lg border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#292D2C] border-[#31596A] shadow-md'
                      : 'bg-[#151817] border-[#292D2C] hover:border-[#68716F]'
                  }`}
                >
                  <div className="flex items-center justify-between font-mono text-xs mb-1">
                    <span className="font-bold text-[#ECE9E1]">{s.name}</span>
                    <span className="text-[#31596A] font-bold">{s.code}</span>
                  </div>
                  <div className="text-xs text-[#B9B7B0]">{s.city}, {s.country}</div>

                  <div className="mt-2.5 flex items-center justify-between text-[11px] font-mono text-[#68716F] pt-2 border-t border-[#292D2C]/60">
                    <span>On-Time: <strong className="text-[#486451]">{s.deliveryPerformancePct}%</strong></span>
                    <span>Lead: <strong className="text-[#ECE9E1]">{s.leadTimeDays} days</strong></span>
                    {isPriceShocked && (
                      <span className="text-[#C28A35] font-bold animate-pulse">+18% Price Shock</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Supplier Detail Card */}
        <div className="lg:col-span-2 space-y-6">
          <div className="p-6 rounded-lg bg-[#151817] border border-[#292D2C] space-y-6">
            {/* Header */}
            <div className="flex flex-wrap justify-between items-start gap-4 border-b border-[#292D2C] pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-display font-bold text-xl text-[#ECE9E1]">{activeSupplier.name}</h3>
                  <span className="px-2 py-0.5 rounded bg-[#486451]/20 text-[#486451] border border-[#486451]/40 font-mono text-xs font-bold">
                    <ShieldCheck className="w-3.5 h-3.5 inline mr-1" />
                    {activeSupplier.approvedStatus}
                  </span>
                </div>
                <p className="text-xs text-[#68716F] font-mono mt-1">
                  Supplier Code: {activeSupplier.code} · Location: {activeSupplier.city}, {activeSupplier.country}
                </p>
              </div>

              <div className="text-right font-mono text-xs">
                <div className="text-[#68716F]">RATING & RELIABILITY</div>
                <div className="text-lg font-bold text-[#B58A3C]">★ {activeSupplier.rating} / 5.0</div>
              </div>
            </div>

            {/* Performance Stats Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="p-3 rounded bg-[#292D2C]/40 border border-[#292D2C] font-mono">
                <div className="text-[11px] text-[#68716F]">DELIVERY PERFORMANCE</div>
                <div className="text-lg font-bold text-[#486451] mt-1">{activeSupplier.deliveryPerformancePct}%</div>
              </div>
              <div className="p-3 rounded bg-[#292D2C]/40 border border-[#292D2C] font-mono">
                <div className="text-[11px] text-[#68716F]">AVG LEAD TIME</div>
                <div className="text-lg font-bold text-[#ECE9E1] mt-1">{activeSupplier.leadTimeDays} Days</div>
              </div>
              <div className="p-3 rounded bg-[#292D2C]/40 border border-[#292D2C] font-mono">
                <div className="text-[11px] text-[#68716F]">MIN ORDER QUANTITY</div>
                <div className="text-lg font-bold text-[#31596A] mt-1">{activeSupplier.minOrderQtyKg.toLocaleString()} kg</div>
              </div>
              <div className="p-3 rounded bg-[#292D2C]/40 border border-[#292D2C] font-mono">
                <div className="text-[11px] text-[#68716F]">12M PRICE VARIANCE</div>
                <div className={`text-lg font-bold mt-1 ${activeSupplier.priceTrendPct > 10 ? 'text-[#C28A35]' : 'text-[#486451]'}`}>
                  +{activeSupplier.priceTrendPct}%
                </div>
              </div>
            </div>

            {/* Quality Certificates & SDS Documents */}
            <div className="space-y-3 pt-2">
              <h4 className="text-xs font-mono text-[#68716F] uppercase tracking-wider">Quality Standards & Technical Documentation</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 rounded bg-[#292D2C]/30 border border-[#292D2C]">
                  <div className="text-xs font-bold text-[#ECE9E1] mb-2 flex items-center gap-1.5">
                    <Award className="w-4 h-4 text-[#B58A3C]" /> Compliance Certificates
                  </div>
                  <div className="space-y-1">
                    {activeSupplier.certificates.map(cert => (
                      <div key={cert} className="text-xs text-[#B9B7B0] flex items-center gap-1 font-mono">
                        <CheckCircle className="w-3 h-3 text-[#486451]" /> {cert}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="p-3 rounded bg-[#292D2C]/30 border border-[#292D2C]">
                  <div className="text-xs font-bold text-[#ECE9E1] mb-2 flex items-center gap-1.5">
                    <FileText className="w-4 h-4 text-[#31596A]" /> Safety Data Sheets (SDS)
                  </div>
                  <div className="text-xs text-[#B9B7B0] font-mono space-y-1">
                    <div>Active SDS On File: <strong>{activeSupplier.sdsDocumentCount} Documents</strong></div>
                    <div>REACH / UKCA Registration: <span className="text-[#486451]">VALID UNTIL 2029</span></div>
                    <div className="text-[11px] text-[#68716F] mt-1">Contact: {activeSupplier.contactEmail}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
