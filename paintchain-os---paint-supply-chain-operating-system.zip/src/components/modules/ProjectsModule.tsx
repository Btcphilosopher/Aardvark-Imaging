import React from 'react';
import { usePaintChain } from '../../context/PaintChainContext';
import { Layers, CheckCircle2, ArrowRight } from 'lucide-react';

export const ProjectsModule: React.FC = () => {
  const { painterJobs, setSelectedTraceBatchId, setActiveModule } = usePaintChain();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-4 rounded-lg bg-[#151817] border border-[#292D2C] flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-[#31596A]" />
            <h2 className="font-display font-bold text-xl text-[#ECE9E1]">CUSTOMER & PROPERTY SURFACE PROVENANCE</h2>
          </div>
          <p className="text-xs text-[#68716F] font-mono mt-0.5">
            Room-by-Room Applied Surface History — Connecting Finished Rooms Back to Factory Batches & Chemicals
          </p>
        </div>
      </div>

      {/* Property Projects List */}
      <div className="space-y-4">
        {painterJobs.map(job => (
          <div key={job.id} className="p-6 rounded-lg bg-[#151817] border border-[#292D2C] space-y-4">
            <div className="border-b border-[#292D2C] pb-3">
              <span className="font-mono text-xs text-[#31596A] font-bold">PROJECT LOCATION</span>
              <h3 className="font-display font-bold text-lg text-[#ECE9E1]">{job.propertyAddress}</h3>
              <p className="text-xs text-[#B9B7B0] font-mono">Owner / Client: <strong>{job.clientName}</strong> · Decorator: {job.painterName}</p>
            </div>

            {/* Room Surfaces */}
            <div className="space-y-3">
              {job.rooms.map(room => (
                <div key={room.roomId} className="p-4 rounded bg-[#292D2C]/40 border border-[#292D2C] space-y-2 font-mono text-xs">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-sm text-[#ECE9E1]">{room.roomName}</span>
                    <span className="px-2 py-0.5 rounded bg-[#486451]/20 text-[#486451] font-bold">
                      APPLICATION VERIFIED
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[#68716F] pt-2 border-t border-[#292D2C]">
                    <div>COLOUR: <strong className="text-[#ECE9E1]">{room.colourName}</strong></div>
                    <div>COATS: <strong className="text-[#ECE9E1]">{room.coats} Coats</strong></div>
                    <div>SUBSTRATE: <strong className="text-[#B9B7B0]">{room.substrate}</strong></div>
                    <div>APPLIED DATE: <strong className="text-[#ECE9E1]">{room.appliedDate || '2026-09-26'}</strong></div>
                  </div>

                  <div className="pt-2 flex justify-between items-center text-[11px]">
                    <span className="text-[#68716F]">Allocated Batch: <strong className="text-[#B58A3C]">{room.allocatedBatchNumber}</strong></span>
                    <button
                      onClick={() => {
                        setSelectedTraceBatchId(room.allocatedBatchNumber);
                        setActiveModule('TRACE');
                      }}
                      className="text-[#31596A] hover:underline flex items-center gap-1 font-bold cursor-pointer"
                    >
                      Trace Surface Back to Chemicals →
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
