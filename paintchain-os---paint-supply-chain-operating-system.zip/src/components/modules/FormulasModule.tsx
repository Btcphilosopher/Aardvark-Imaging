import React, { useState } from 'react';
import { usePaintChain } from '../../context/PaintChainContext';
import { Sparkles, ShieldCheck, History, GitCompare, Calculator, ArrowRight, Lock } from 'lucide-react';

export const FormulasModule: React.FC = () => {
  const { formulations, materials, scenarioShock, calculateBatchCostWithShocks } = usePaintChain();
  const [selectedFormulaId, setSelectedFormulaId] = useState(formulations[0].id);
  const [batchScaleKg, setBatchScaleKg] = useState(8000);

  const formula = formulations.find(f => f.id === selectedFormulaId) || formulations[0];
  const v12 = formula.revisions.find(r => r.versionId === 'v12.0') || formula.revisions[0];
  const v14 = formula.revisions.find(r => r.versionId === 'v14.3') || formula.revisions[0];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-4 rounded-lg bg-[#151817] border border-[#292D2C] flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#31596A]" />
            <h2 className="font-display font-bold text-xl text-[#ECE9E1]">FORMULATION LAB & REVISION CONTROL</h2>
          </div>
          <p className="text-xs text-[#68716F] font-mono mt-0.5">
            Formulation % Ingredient Recipes, VOC Compliance, IP Access Control & Formula Version Evolution (v12 → v14.3)
          </p>
        </div>

        {/* IP Protection Indicator */}
        <div className="flex items-center gap-2 bg-[#292D2C] px-3 py-1.5 rounded font-mono text-xs border border-[#31596A]/40">
          <Lock className="w-4 h-4 text-[#B58A3C]" />
          <span className="text-[#ECE9E1] font-bold">IP PROTECTED FORMULATION</span>
        </div>
      </div>

      {/* Formula Metadata Card */}
      <div className="p-6 rounded-lg bg-[#151817] border border-[#292D2C] space-y-4">
        <div className="flex flex-wrap justify-between items-start gap-4 border-b border-[#292D2C] pb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono font-bold text-lg text-[#31596A]">{formula.formulaCode}</span>
              <span className="px-2 py-0.5 rounded bg-[#486451]/20 text-[#486451] font-mono text-xs font-bold border border-[#486451]/40">
                ACTIVE VERSION: {formula.currentVersion}
              </span>
            </div>
            <h3 className="font-display font-bold text-xl text-[#ECE9E1] mt-1">{formula.name}</h3>
            <p className="text-xs text-[#68716F] font-mono mt-0.5">{formula.productFamily}</p>
          </div>

          {/* Scaling Calculator Control */}
          <div className="flex items-center gap-3 bg-[#292D2C] p-2 rounded border border-[#292D2C]">
            <Calculator className="w-4 h-4 text-[#B58A3C]" />
            <span className="text-xs font-mono text-[#68716F]">Batch Scale Size:</span>
            <input
              type="number"
              value={batchScaleKg}
              onChange={e => setBatchScaleKg(parseInt(e.target.value) || 1000)}
              className="w-24 bg-[#151817] text-[#ECE9E1] font-mono font-bold text-xs px-2 py-1 rounded border border-[#68716F]/40 focus:outline-none"
            />
            <span className="text-xs font-mono text-[#ECE9E1]">kg</span>
          </div>
        </div>

        {/* Side-by-Side Version Comparison (v12 vs v14.3) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Version v12.0 Legacy */}
          <div className="p-4 rounded bg-[#292D2C]/30 border border-[#292D2C] space-y-3 font-mono text-xs">
            <div className="flex justify-between items-center border-b border-[#292D2C] pb-2">
              <span className="font-bold text-[#68716F]">REVISION v12.0 (LEGACY)</span>
              <span className="text-[10px] text-[#9D4038]">SUPERSEDED</span>
            </div>

            <div className="space-y-1 text-[#68716F] text-[11px]">
              <div>Author: {v12.author}</div>
              <div>VOC Level: <strong className="text-[#9D4038]">{v12.vocGramsPerLitre} g/L</strong> (Higher Solvent)</div>
              <div>Viscosity: {v12.targetViscosityKu} KU · Gloss: {v12.targetGlossPct}%</div>
            </div>

            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-[#292D2C] text-[#68716F]">
                  <th className="py-1">Ingredient</th>
                  <th className="py-1 text-right">%</th>
                  <th className="py-1 text-right">kg Yield</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#292D2C]/40 text-[#B9B7B0]">
                {v12.ingredients.map(ing => {
                  const mat = materials.find(m => m.id === ing.materialId);
                  const scaledKg = ((ing.percentage / 100) * batchScaleKg).toFixed(1);

                  return (
                    <tr key={ing.materialId}>
                      <td className="py-1">{mat?.name}</td>
                      <td className="py-1 text-right font-bold">{ing.percentage}%</td>
                      <td className="py-1 text-right text-[#ECE9E1]">{scaledKg} kg</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Version v14.3 Approved Active */}
          <div className="p-4 rounded bg-[#292D2C]/50 border border-[#31596A]/60 space-y-3 font-mono text-xs shadow-md">
            <div className="flex justify-between items-center border-b border-[#292D2C] pb-2">
              <span className="font-bold text-[#31596A]">REVISION v14.3 (CURRENT APPROVED)</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-[#486451]/20 text-[#486451] font-bold">
                ACTIVE FORMULA
              </span>
            </div>

            <div className="space-y-1 text-[#B9B7B0] text-[11px]">
              <div>Author: {v14.author}</div>
              <div>VOC Level: <strong className="text-[#486451]">{v14.vocGramsPerLitre} g/L</strong> (Ultra-Low VOC Compliant)</div>
              <div>Viscosity: {v14.targetViscosityKu} KU · Gloss: {v14.targetGlossPct}%</div>
            </div>

            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-[#292D2C] text-[#68716F]">
                  <th className="py-1">Ingredient</th>
                  <th className="py-1 text-right">%</th>
                  <th className="py-1 text-right">kg Yield</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#292D2C]/40 text-[#ECE9E1]">
                {v14.ingredients.map(ing => {
                  const mat = materials.find(m => m.id === ing.materialId);
                  const scaledKg = ((ing.percentage / 100) * batchScaleKg).toFixed(1);

                  return (
                    <tr key={ing.materialId}>
                      <td className="py-1 font-medium">{mat?.name}</td>
                      <td className="py-1 text-right font-bold text-[#31596A]">{ing.percentage}%</td>
                      <td className="py-1 text-right text-[#486451] font-bold">{scaledKg} kg</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
