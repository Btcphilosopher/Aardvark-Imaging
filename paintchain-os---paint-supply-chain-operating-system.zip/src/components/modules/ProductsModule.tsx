import React from 'react';
import { usePaintChain } from '../../context/PaintChainContext';
import { Package, FileText, QrCode, ShieldCheck, ArrowRight } from 'lucide-react';

export const ProductsModule: React.FC = () => {
  const { skus, batches, setSelectedTraceBatchId, setActiveModule } = usePaintChain();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-4 rounded-lg bg-[#151817] border border-[#292D2C] flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Package className="w-5 h-5 text-[#31596A]" />
            <h2 className="font-display font-bold text-xl text-[#ECE9E1]">DIGITAL PRODUCT PASSPORTS & PACKAGED SKUs</h2>
          </div>
          <p className="text-xs text-[#68716F] font-mono mt-0.5">
            500ml to 20L Trade Tubs, Barcodes, Technical Data Sheets & End-to-End Batch Provenance Passports
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="px-2.5 py-1 rounded bg-[#31596A]/20 text-[#31596A] font-bold border border-[#31596A]/40">
            {skus.length} ACTIVE PACKAGED SKUs
          </span>
        </div>
      </div>

      {/* SKUs List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {skus.map(sku => {
          const batch = batches.find(b => b.batchNumber === sku.batchNumber);

          return (
            <div key={sku.id} className="p-6 rounded-lg bg-[#151817] border border-[#292D2C] space-y-4">
              <div className="flex justify-between items-start border-b border-[#292D2C] pb-3">
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded border-2 border-[#68716F] shadow-sm shrink-0"
                    style={{ backgroundColor: sku.colourHex }}
                  />
                  <div>
                    <span className="font-mono text-xs text-[#31596A] font-bold">{sku.skuCode}</span>
                    <h3 className="font-display font-bold text-base text-[#ECE9E1]">{sku.productName}</h3>
                    <p className="text-xs text-[#B9B7B0] font-mono">{sku.colourName} — Pack Size: <strong>{sku.packSize}</strong></p>
                  </div>
                </div>

                <span className="px-2 py-0.5 rounded bg-[#486451]/20 text-[#486451] font-mono text-[10px] font-bold border border-[#486451]/40">
                  PASSPORT VALID
                </span>
              </div>

              {/* SKU Passport Data */}
              <div className="grid grid-cols-2 gap-3 font-mono text-xs text-[#68716F]">
                <div className="p-2.5 rounded bg-[#292D2C]/40 border border-[#292D2C]">
                  <div>TRADE PRICE</div>
                  <div className="text-base font-bold text-[#ECE9E1] mt-0.5">£{sku.tradePrice.toFixed(2)}</div>
                </div>
                <div className="p-2.5 rounded bg-[#292D2C]/40 border border-[#292D2C]">
                  <div>RETAIL PRICE</div>
                  <div className="text-base font-bold text-[#B58A3C] mt-0.5">£{sku.retailPrice.toFixed(2)}</div>
                </div>
                <div className="p-2.5 rounded bg-[#292D2C]/40 border border-[#292D2C]">
                  <div>BARCODE (EAN-13)</div>
                  <div className="text-xs font-bold text-[#ECE9E1] mt-1">{sku.barcode}</div>
                </div>
                <div className="p-2.5 rounded bg-[#292D2C]/40 border border-[#292D2C]">
                  <div>BATCH PROVENANCE</div>
                  <div className="text-xs font-bold text-[#31596A] mt-1">{sku.batchNumber}</div>
                </div>
              </div>

              <div className="pt-2 border-t border-[#292D2C] flex justify-between items-center font-mono text-xs">
                <span className="text-[#68716F]">Units in Warehouse: <strong className="text-[#ECE9E1]">{sku.unitsInWarehouse}</strong></span>
                <button
                  onClick={() => {
                    setSelectedTraceBatchId(sku.batchNumber);
                    setActiveModule('TRACE');
                  }}
                  className="text-[#31596A] hover:underline flex items-center gap-1 font-bold cursor-pointer"
                >
                  Trace Tin Provenance →
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
