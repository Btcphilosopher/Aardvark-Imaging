import React from 'react';
import { usePaintChain } from '../../context/PaintChainContext';
import { Truck, Navigation, Thermometer, MapPin, CheckCircle2, ShieldCheck } from 'lucide-react';

export const LogisticsModule: React.FC = () => {
  const { shipments } = usePaintChain();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-4 rounded-lg bg-[#151817] border border-[#292D2C] flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Truck className="w-5 h-5 text-[#31596A]" />
            <h2 className="font-display font-bold text-xl text-[#ECE9E1]">LOGISTICS ENGINE & FLEET GPS TRACKING</h2>
          </div>
          <p className="text-xs text-[#68716F] font-mono mt-0.5">
            Factory → Distribution Centre → Trade Merchant → Painter Site Logistics & Temperature Monitoring
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="px-2.5 py-1 rounded bg-[#31596A]/20 text-[#31596A] font-bold border border-[#31596A]/40">
            {shipments.length} FLEET VEHICLES IN TRANSIT
          </span>
        </div>
      </div>

      {/* Shipments List */}
      <div className="space-y-4">
        {shipments.map(s => (
          <div key={s.id} className="p-6 rounded-lg bg-[#151817] border border-[#292D2C] space-y-4">
            <div className="flex flex-wrap justify-between items-start gap-4 border-b border-[#292D2C] pb-3 font-mono">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-lg text-[#ECE9E1]">{s.id}</span>
                  <span className="px-2 py-0.5 rounded bg-[#486451]/20 text-[#486451] text-xs font-bold border border-[#486451]/40">
                    {s.status}
                  </span>
                </div>
                <div className="text-xs text-[#68716F] mt-0.5">Vehicle: <strong className="text-[#ECE9E1]">{s.vehicleReg}</strong> · Driver: {s.driverName}</div>
              </div>

              <div className="text-right text-xs space-y-1">
                <div className="text-[#68716F]">EXPECTED ARRIVAL (ETA)</div>
                <div className="text-sm font-bold text-[#31596A]">{new Date(s.eta).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
              </div>
            </div>

            {/* Logistics Route Details */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
              <div className="p-3 rounded bg-[#292D2C]/40 border border-[#292D2C]">
                <div className="text-[#68716F] flex items-center gap-1"><MapPin className="w-3.5 h-3.5 text-[#31596A]" /> ORIGIN FACILITY</div>
                <div className="text-xs font-bold text-[#ECE9E1] mt-1">{s.origin}</div>
              </div>
              <div className="p-3 rounded bg-[#292D2C]/40 border border-[#292D2C]">
                <div className="text-[#68716F] flex items-center gap-1"><Navigation className="w-3.5 h-3.5 text-[#486451]" /> DESTINATION</div>
                <div className="text-xs font-bold text-[#ECE9E1] mt-1">{s.destination}</div>
              </div>
              <div className="p-3 rounded bg-[#292D2C]/40 border border-[#292D2C]">
                <div className="text-[#68716F] flex items-center gap-1"><Thermometer className="w-3.5 h-3.5 text-[#B58A3C]" /> CARGO TEMP TELEMETRY</div>
                <div className="text-xs font-bold text-[#B58A3C] mt-1">{s.temperatureC} °C (Storage Safe)</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
