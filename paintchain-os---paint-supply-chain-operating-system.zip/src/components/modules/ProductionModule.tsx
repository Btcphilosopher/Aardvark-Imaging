import React from 'react';
import { usePaintChain } from '../../context/PaintChainContext';
import { Factory, Play, CheckCircle2, Clock, RotateCw, AlertTriangle, ArrowRight } from 'lucide-react';

export const ProductionModule: React.FC = () => {
  const { batches, tanks, setSelectedTraceBatchId, setActiveModule } = usePaintChain();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-4 rounded-lg bg-[#151817] border border-[#292D2C] flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Factory className="w-5 h-5 text-[#31596A]" />
            <h2 className="font-display font-bold text-xl text-[#ECE9E1]">PRODUCTION PLANNING & BATCH GENEALOGY</h2>
          </div>
          <p className="text-xs text-[#68716F] font-mono mt-0.5">
            Stage Scheduling: Pre-Mix → Dispersion → Milling → Let-Down → QC → High-Speed Packaging
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="px-2.5 py-1 rounded bg-[#31596A]/20 text-[#31596A] font-bold border border-[#31596A]/40">
            {batches.length} BATCH RECORDS ACTIVE
          </span>
        </div>
      </div>

      {/* Batches Production Records */}
      <div className="space-y-4">
        {batches.map(batch => {
          const isQuarantined = batch.status === 'QUARANTINED';
          const vessel = tanks.find(t => t.id === batch.tankId);

          return (
            <div
              key={batch.batchNumber}
              className={`p-6 rounded-lg border transition-all space-y-4 ${
                isQuarantined
                  ? 'bg-[#9D4038]/10 border-[#9D4038]'
                  : 'bg-[#151817] border-[#292D2C] hover:border-[#31596A]'
              }`}
            >
              <div className="flex flex-wrap justify-between items-start gap-4 border-b border-[#292D2C] pb-3">
                <div>
                  <div className="flex items-center gap-3 font-mono">
                    <span className="font-bold text-lg text-[#ECE9E1]">{batch.batchNumber}</span>
                    <span
                      className={`px-2.5 py-0.5 rounded text-xs font-bold ${
                        batch.status === 'QC_RELEASED'
                          ? 'bg-[#486451]/20 text-[#486451] border border-[#486451]/40'
                          : isQuarantined
                          ? 'bg-[#9D4038]/20 text-[#9D4038] border border-[#9D4038]/40 animate-pulse'
                          : 'bg-[#C28A35]/20 text-[#C28A35] border border-[#C28A35]/40'
                      }`}
                    >
                      {batch.status}
                    </span>
                  </div>
                  <div className="font-display font-bold text-base text-[#ECE9E1] mt-1">
                    {batch.productName} — <span className="text-[#31596A]">{batch.colourName}</span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={() => {
                      setSelectedTraceBatchId(batch.batchNumber);
                      setActiveModule('TRACE');
                    }}
                    className="px-3 py-1.5 rounded bg-[#31596A] hover:bg-[#31596A]/80 text-white font-mono text-xs font-bold cursor-pointer transition-colors flex items-center gap-1"
                  >
                    View Batch Genealogy <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Batch Metrics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 font-mono text-xs">
                <div className="p-3 rounded bg-[#292D2C]/40 border border-[#292D2C]">
                  <div className="text-[#68716F]">TARGET YIELD</div>
                  <div className="text-base font-bold text-[#ECE9E1] mt-0.5">{batch.targetKg.toLocaleString()} kg</div>
                </div>
                <div className="p-3 rounded bg-[#292D2C]/40 border border-[#292D2C]">
                  <div className="text-[#68716F]">ACTUAL YIELD</div>
                  <div className="text-base font-bold text-[#486451] mt-0.5">{batch.actualKg.toLocaleString()} kg ({batch.yieldPct}%)</div>
                </div>
                <div className="p-3 rounded bg-[#292D2C]/40 border border-[#292D2C]">
                  <div className="text-[#68716F]">VESSEL / TANK</div>
                  <div className="text-base font-bold text-[#31596A] mt-0.5">{batch.tankId} ({vessel?.type})</div>
                </div>
                <div className="p-3 rounded bg-[#292D2C]/40 border border-[#292D2C]">
                  <div className="text-[#68716F]">PLANT OPERATOR</div>
                  <div className="text-xs font-bold text-[#B9B7B0] mt-1">{batch.operator}</div>
                </div>
              </div>

              {/* Consumed Raw Material Lots */}
              <div className="space-y-2">
                <div className="text-xs font-mono text-[#68716F] uppercase tracking-wider">Consumed Chemical Lots (Genealogy Input)</div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 font-mono text-xs">
                  {batch.consumedLots.map(lot => (
                    <div key={lot.lotNumber} className="p-2 rounded bg-[#292D2C]/30 border border-[#292D2C]">
                      <div className="text-[#B58A3C] font-bold">{lot.lotNumber}</div>
                      <div className="text-[11px] text-[#68716F]">Quantity Used: {lot.actualKgUsed.toLocaleString()} kg</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
