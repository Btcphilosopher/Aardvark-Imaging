import React, { useState } from 'react';
import { usePaintChain } from '../../context/PaintChainContext';
import { Paintbrush, Calculator, Plus, CheckCircle2, ArrowRight } from 'lucide-react';
import { PainterJob } from '../../types/paintchain';

export const PaintersModule: React.FC = () => {
  const { painterJobs, colours, batches, addPainterJob, setSelectedTraceBatchId, setActiveModule } = usePaintChain();

  // Calculator state
  const [roomLength, setRoomLength] = useState(6.5);
  const [roomWidth, setRoomWidth] = useState(4.2);
  const [roomHeight, setRoomHeight] = useState(3.2);
  const [doorsCount, setDoorsCount] = useState(2);
  const [windowsCount, setWindowsCount] = useState(2);
  const [coatsCount, setCoatsCount] = useState(2);

  // Surface Math (Wall Area = 2*(L+W)*H - Doors(2m²)*D - Windows(1.5m²)*W)
  const grossWallArea = 2 * (roomLength + roomWidth) * roomHeight;
  const netWallArea = Math.max(10, grossWallArea - (doorsCount * 2.0) - (windowsCount * 1.5));
  const totalCoverageSqM = netWallArea * coatsCount;
  // Coverage rate: 12 m² / Litre
  const estimatedLitres = Math.ceil((totalCoverageSqM / 12) * 10) / 10;
  const recommendedTins = Math.ceil(estimatedLitres / 5);

  const handleCreateNewJob = () => {
    const newJobId = `JOB-00${Math.floor(Math.random() * 8000 + 1000)}`;
    const newJob: PainterJob = {
      id: newJobId,
      painterName: 'G. H. Decorators Ltd.',
      clientName: 'Lord Harrington',
      propertyAddress: '8 Royal Crescent, Bath BA1 2LS',
      city: 'Bath',
      status: 'IN_PROGRESS',
      createdDate: new Date().toISOString().split('T')[0],
      totalLitresEstimated: recommendedTins * 5,
      rooms: [
        {
          roomId: `RM-${Date.now()}`,
          roomName: 'Drawing Room',
          lengthM: roomLength,
          widthM: roomWidth,
          heightM: roomHeight,
          doors: doorsCount,
          windows: windowsCount,
          coats: coatsCount,
          substrate: 'Plasterboard with Mist Coat',
          wallAreaM2: netWallArea,
          ceilingAreaM2: roomLength * roomWidth,
          estimatedLitresRequired: recommendedTins * 5,
          productName: 'Premium Interior Matt Emulsion',
          colourName: 'Bristol Stone',
          colourHex: '#C8BFB0',
          allocatedBatchNumber: 'BATCH-26-09184',
          appliedDate: new Date().toISOString().split('T')[0]
        }
      ]
    };
    addPainterJob(newJob);
    alert(`Job ${newJobId} created! Paint requirement (${recommendedTins * 5}L) propagated to merchant stock.`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-4 rounded-lg bg-[#151817] border border-[#292D2C] flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Paintbrush className="w-5 h-5 text-[#315A78]" />
            <h2 className="font-display font-bold text-xl text-[#ECE9E1]">PAINTER APP & QUANTITY CALCULATOR</h2>
          </div>
          <p className="text-xs text-[#68716F] font-mono mt-0.5">
            Job Planning, Surface Area Calculation (m²), Litres Needed & Downstream Batch Tracking
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="px-2.5 py-1 rounded bg-[#315A78]/20 text-[#315A78] font-bold border border-[#315A78]/40">
            PAINTER NETWORK ACTIVE
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Quantity Calculator */}
        <div className="p-6 rounded-lg bg-[#151817] border border-[#292D2C] space-y-4">
          <div className="flex items-center gap-2 border-b border-[#292D2C] pb-3">
            <Calculator className="w-5 h-5 text-[#B58A3C]" />
            <h3 className="font-display font-bold text-base text-[#ECE9E1]">Paint Calculator</h3>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div>
              <label className="text-[#68716F] block mb-1">Room Length (m):</label>
              <input
                type="number"
                step="0.1"
                value={roomLength}
                onChange={e => setRoomLength(parseFloat(e.target.value) || 1)}
                className="w-full bg-[#292D2C] text-[#ECE9E1] font-bold p-2 rounded border border-[#292D2C] focus:outline-none"
              />
            </div>

            <div>
              <label className="text-[#68716F] block mb-1">Room Width (m):</label>
              <input
                type="number"
                step="0.1"
                value={roomWidth}
                onChange={e => setRoomWidth(parseFloat(e.target.value) || 1)}
                className="w-full bg-[#292D2C] text-[#ECE9E1] font-bold p-2 rounded border border-[#292D2C] focus:outline-none"
              />
            </div>

            <div>
              <label className="text-[#68716F] block mb-1">Ceiling Height (m):</label>
              <input
                type="number"
                step="0.1"
                value={roomHeight}
                onChange={e => setRoomHeight(parseFloat(e.target.value) || 1)}
                className="w-full bg-[#292D2C] text-[#ECE9E1] font-bold p-2 rounded border border-[#292D2C] focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[#68716F] block mb-1">Doors:</label>
                <input
                  type="number"
                  value={doorsCount}
                  onChange={e => setDoorsCount(parseInt(e.target.value) || 0)}
                  className="w-full bg-[#292D2C] text-[#ECE9E1] font-bold p-2 rounded border border-[#292D2C] focus:outline-none"
                />
              </div>
              <div>
                <label className="text-[#68716F] block mb-1">Coats:</label>
                <input
                  type="number"
                  value={coatsCount}
                  onChange={e => setCoatsCount(parseInt(e.target.value) || 1)}
                  className="w-full bg-[#292D2C] text-[#ECE9E1] font-bold p-2 rounded border border-[#292D2C] focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Calculator Output */}
          <div className="p-4 rounded bg-[#292D2C]/40 border border-[#31596A]/40 space-y-2 font-mono text-xs">
            <div className="flex justify-between text-[#68716F]">
              <span>NET WALL AREA:</span>
              <strong className="text-[#ECE9E1]">{netWallArea.toFixed(1)} m²</strong>
            </div>
            <div className="flex justify-between text-[#68716F]">
              <span>ESTIMATED LITRES:</span>
              <strong className="text-[#B58A3C]">{estimatedLitres.toFixed(1)} Litres</strong>
            </div>
            <div className="flex justify-between text-[#ECE9E1] font-bold pt-2 border-t border-[#292D2C]">
              <span>RECOMMENDED TIN PACK:</span>
              <span className="text-[#486451]">{recommendedTins} x 5L Tins ({recommendedTins * 5}L)</span>
            </div>
          </div>

          <button
            onClick={handleCreateNewJob}
            className="w-full py-2.5 rounded bg-[#315A78] hover:bg-[#315A78]/80 text-white font-mono text-xs font-bold cursor-pointer transition-colors flex items-center justify-center gap-1.5"
          >
            <Plus className="w-4 h-4" /> Save Job & Reserve Batch Tins
          </button>
        </div>

        {/* Existing Painter Jobs */}
        <div className="lg:col-span-2 space-y-4">
          <h3 className="font-display font-bold text-base text-[#ECE9E1]">Active Painter Jobs & Surface Records</h3>

          <div className="space-y-4">
            {painterJobs.map(job => (
              <div key={job.id} className="p-6 rounded-lg bg-[#151817] border border-[#292D2C] space-y-4">
                <div className="flex justify-between items-start border-b border-[#292D2C] pb-3 font-mono">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-base text-[#ECE9E1]">{job.id}</span>
                      <span className="px-2 py-0.5 rounded bg-[#486451]/20 text-[#486451] text-xs font-bold border border-[#486451]/40">
                        {job.status}
                      </span>
                    </div>
                    <div className="text-xs text-[#B9B7B0] font-sans mt-0.5">
                      Client: <strong>{job.clientName}</strong> · Painter: {job.painterName}
                    </div>
                  </div>

                  <div className="text-right text-xs text-[#68716F]">
                    <div>{job.city}</div>
                    <div className="text-[#ECE9E1] font-bold">{job.totalLitresEstimated} Litres Total</div>
                  </div>
                </div>

                {/* Rooms Specs */}
                <div className="space-y-2">
                  {job.rooms.map(room => (
                    <div key={room.roomId} className="p-3 rounded bg-[#292D2C]/30 border border-[#292D2C] font-mono text-xs space-y-1">
                      <div className="flex justify-between font-bold text-[#ECE9E1]">
                        <span>{room.roomName}</span>
                        <span className="text-[#31596A]">{room.colourName} ({room.productName})</span>
                      </div>
                      <div className="text-[11px] text-[#68716F] flex justify-between">
                        <span>Wall Area: {room.wallAreaM2} m² · Litres: {room.estimatedLitresRequired}L</span>
                        <span>Batch: <strong className="text-[#B58A3C]">{room.allocatedBatchNumber}</strong></span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
