import React from 'react';
import { usePaintChain } from '../../context/PaintChainContext';
import { Factory3DCanvas } from '../factory/Factory3DCanvas';
import {
  Activity,
  Layers,
  Factory,
  CheckCircle2,
  AlertTriangle,
  TrendingUp,
  Truck,
  Building2,
  Zap,
  ArrowUpRight
} from 'lucide-react';

export const OverviewModule: React.FC = () => {
  const {
    batches,
    materials,
    tanks,
    skus,
    orders,
    scenarioShock,
    triggerSignatureDemo,
    calculateBatchCostWithShocks,
    setActiveModule
  } = usePaintChain();

  const activeBatchesCount = batches.filter(b => b.status !== 'QC_RELEASED').length;
  const quarantinedBatches = batches.filter(b => b.status === 'QUARANTINED');

  const totalRawMaterialStockKg = materials.reduce((acc, m) => acc + m.currentStockKg, 0);
  const totalRawMaterialValueGbp = materials.reduce((acc, m) => acc + (m.currentStockKg * m.costPerKg), 0);

  const batchCost = calculateBatchCostWithShocks('BATCH-26-09184');

  return (
    <div className="space-y-6">
      {/* Executive Header Banner */}
      <div className="p-6 rounded-lg bg-gradient-to-r from-[#151817] via-[#292D2C] to-[#151817] border border-[#31596A]/60 flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-[#31596A]/30 text-[#31596A] font-mono text-xs font-bold border border-[#31596A]">
              SYSTEM VERIFIED
            </span>
            <h2 className="font-display font-black text-2xl text-[#ECE9E1] tracking-tight">
              EXECUTIVE CONTROL CENTRE
            </h2>
          </div>
          <p className="text-sm text-[#B9B7B0]">
            Plant Telemetry, Raw Material Reserves, Quality Pass Rates & End-to-End Supply Chain Provenance
          </p>
        </div>

        {/* Quick Signature Demo Callouts */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => triggerSignatureDemo(1)}
            className="px-3 py-2 rounded bg-[#292D2C] border border-[#31596A] hover:bg-[#31596A] text-[#ECE9E1] text-xs font-mono transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <Zap className="w-3.5 h-3.5 text-[#B58A3C]" />
            Demo 1: Trace Batch-09184
          </button>
          <button
            onClick={() => triggerSignatureDemo(2)}
            className="px-3 py-2 rounded bg-[#292D2C] border border-[#C28A35] hover:bg-[#C28A35] text-[#ECE9E1] text-xs font-mono transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <TrendingUp className="w-3.5 h-3.5 text-[#C28A35]" />
            Demo 2: TiO₂ Shock (+18%)
          </button>
        </div>
      </div>

      {/* KPI Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Raw Material Reserve */}
        <div className="p-4 rounded-lg bg-[#151817] border border-[#292D2C] space-y-2">
          <div className="flex justify-between items-center text-xs text-[#68716F] font-mono">
            <span>RAW MATERIAL RESERVE</span>
            <Layers className="w-4 h-4 text-[#31596A]" />
          </div>
          <div className="text-2xl font-mono font-bold text-[#ECE9E1]">
            {(totalRawMaterialStockKg / 1000).toFixed(1)}k <span className="text-sm text-[#68716F]">tonnes</span>
          </div>
          <div className="text-xs font-mono text-[#486451]">
            Valuation: £{totalRawMaterialValueGbp.toLocaleString('en-GB', { maximumFractionDigits: 0 })}
          </div>
        </div>

        {/* Plant Production */}
        <div className="p-4 rounded-lg bg-[#151817] border border-[#292D2C] space-y-2">
          <div className="flex justify-between items-center text-xs text-[#68716F] font-mono">
            <span>BATCHES IN PRODUCTION</span>
            <Factory className="w-4 h-4 text-[#31596A]" />
          </div>
          <div className="text-2xl font-mono font-bold text-[#ECE9E1]">
            {activeBatchesCount} <span className="text-sm text-[#68716F]">Batches Active</span>
          </div>
          <div className="text-xs font-mono text-[#31596A]">
            Tanks Utilization: 88% ({tanks.filter(t => t.status === 'Active').length} Active Vessels)
          </div>
        </div>

        {/* Quality Pass Rate */}
        <div className="p-4 rounded-lg bg-[#151817] border border-[#292D2C] space-y-2">
          <div className="flex justify-between items-center text-xs text-[#68716F] font-mono">
            <span>QUALITY PASS RATE</span>
            <CheckCircle2 className="w-4 h-4 text-[#486451]" />
          </div>
          <div className="text-2xl font-mono font-bold text-[#486451]">
            {quarantinedBatches.length > 0 ? '92.4%' : '99.2%'}
          </div>
          <div className="text-xs font-mono text-[#9D4038]">
            {quarantinedBatches.length > 0
              ? `⚠️ ${quarantinedBatches.length} Batch Quarantined (£18,420 hold)`
              : 'Zero Active Quality Deviations'}
          </div>
        </div>

        {/* Cost per Litre */}
        <div className="p-4 rounded-lg bg-[#151817] border border-[#292D2C] space-y-2">
          <div className="flex justify-between items-center text-xs text-[#68716F] font-mono">
            <span>BATCH COST / LITRE</span>
            <TrendingUp className="w-4 h-4 text-[#B58A3C]" />
          </div>
          <div className="text-2xl font-mono font-bold text-[#B58A3C]">
            £{batchCost.costPerLitre.toFixed(2)} <span className="text-sm text-[#68716F]">/ L</span>
          </div>
          <div className="text-xs font-mono text-[#ECE9E1]">
            Target Trade Price: £5.70/L (Gross Margin 64.7%)
          </div>
        </div>
      </div>

      {/* 2.5D Factory Twin Visualizer */}
      <Factory3DCanvas />

      {/* Quick Access Modules Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Raw Material Inventory Breakdown */}
        <div className="p-4 rounded-lg bg-[#151817] border border-[#292D2C] space-y-3">
          <div className="flex justify-between items-center border-b border-[#292D2C] pb-2">
            <h4 className="font-display font-bold text-sm text-[#ECE9E1]">Raw Material Breakdown</h4>
            <button
              onClick={() => setActiveModule('MATERIALS')}
              className="text-xs font-mono text-[#31596A] hover:underline flex items-center gap-1 cursor-pointer"
            >
              View Lots <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="space-y-2 font-mono text-xs">
            {materials.map(m => (
              <div key={m.id} className="flex justify-between items-center p-2 rounded bg-[#292D2C]/40">
                <div>
                  <div className="font-bold text-[#ECE9E1]">{m.name}</div>
                  <div className="text-[10px] text-[#68716F]">{m.category} · £{m.costPerKg.toFixed(2)}/kg</div>
                </div>
                <div className="text-right">
                  <div className="text-[#31596A] font-bold">{m.currentStockKg.toLocaleString()} kg</div>
                  <div className="text-[10px] text-[#486451]">Stock Safe</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Live Active Production Batches */}
        <div className="p-4 rounded-lg bg-[#151817] border border-[#292D2C] space-y-3">
          <div className="flex justify-between items-center border-b border-[#292D2C] pb-2">
            <h4 className="font-display font-bold text-sm text-[#ECE9E1]">Plant Production Batches</h4>
            <button
              onClick={() => setActiveModule('PRODUCTION')}
              className="text-xs font-mono text-[#31596A] hover:underline flex items-center gap-1 cursor-pointer"
            >
              Plant Schedule <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="space-y-2 font-mono text-xs">
            {batches.map(b => (
              <div key={b.batchNumber} className="p-2.5 rounded bg-[#292D2C]/40 space-y-1">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-[#ECE9E1]">{b.batchNumber}</span>
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded ${
                      b.status === 'QC_RELEASED'
                        ? 'bg-[#486451]/20 text-[#486451]'
                        : b.status === 'QUARANTINED'
                        ? 'bg-[#9D4038]/20 text-[#9D4038] font-bold'
                        : 'bg-[#C28A35]/20 text-[#C28A35]'
                    }`}
                  >
                    {b.status}
                  </span>
                </div>
                <div className="text-[#B9B7B0] text-[11px]">{b.productName} — {b.colourName}</div>
                <div className="flex justify-between text-[10px] text-[#68716F] pt-1 border-t border-[#292D2C]/60">
                  <span>Target: {b.targetKg.toLocaleString()} kg</span>
                  <span>Vessel: {b.tankId}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Downstream Painter & Trade Demand */}
        <div className="p-4 rounded-lg bg-[#151817] border border-[#292D2C] space-y-3">
          <div className="flex justify-between items-center border-b border-[#292D2C] pb-2">
            <h4 className="font-display font-bold text-sm text-[#ECE9E1]">Trade & Painter Demand</h4>
            <button
              onClick={() => setActiveModule('PAINTERS')}
              className="text-xs font-mono text-[#31596A] hover:underline flex items-center gap-1 cursor-pointer"
            >
              Painter App <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="space-y-2 text-xs font-mono">
            {orders.map(o => (
              <div key={o.id} className="p-2.5 rounded bg-[#292D2C]/40 space-y-1">
                <div className="flex justify-between font-bold text-[#ECE9E1]">
                  <span>{o.id}</span>
                  <span className="text-[#486451]">£{o.totalAmount.toFixed(2)}</span>
                </div>
                <div className="text-[11px] text-[#B9B7B0]">{o.merchantName}</div>
                <div className="text-[10px] text-[#68716F]">Customer: {o.customerOrPainterName}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
