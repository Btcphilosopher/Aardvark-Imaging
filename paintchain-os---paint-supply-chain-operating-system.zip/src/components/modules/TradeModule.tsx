import React, { useState } from 'react';
import { usePaintChain } from '../../context/PaintChainContext';
import { Building2, ShoppingCart, CheckCircle2, Plus } from 'lucide-react';

export const TradeModule: React.FC = () => {
  const { merchants, skus, addSalesOrder } = usePaintChain();
  const [selectedMerchantId, setSelectedMerchantId] = useState(merchants[0].id);

  const activeMerchant = merchants.find(m => m.id === selectedMerchantId) || merchants[0];

  const [orderQuantity, setOrderQuantity] = useState(48);

  const handlePlaceOrder = () => {
    const sku = skus[0];
    const newOrderId = `ORD-${Math.floor(Math.random() * 80000 + 10000)}`;
    addSalesOrder({
      id: newOrderId,
      merchantId: activeMerchant.id,
      merchantName: activeMerchant.name,
      customerOrPainterName: 'G. H. Decorators Ltd.',
      items: [
        {
          skuCode: sku.skuCode,
          productName: sku.productName,
          colourName: sku.colourName,
          packSize: sku.packSize,
          quantity: orderQuantity,
          unitPrice: sku.tradePrice,
          batchAllocated: sku.batchNumber
        }
      ],
      totalAmount: orderQuantity * sku.tradePrice,
      status: 'ALLOCATED',
      placedAt: new Date().toISOString()
    });
    alert(`Trade Order ${newOrderId} placed successfully for ${activeMerchant.name}!`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-4 rounded-lg bg-[#151817] border border-[#292D2C] flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-[#31596A]" />
            <h2 className="font-display font-bold text-xl text-[#ECE9E1]">TRADE MERCHANT PORTAL</h2>
          </div>
          <p className="text-xs text-[#68716F] font-mono mt-0.5">
            B2B Merchant Accounts, Stock Reservations, Click & Collect & Bulk Trade Order Builder
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="px-2.5 py-1 rounded bg-[#486451]/20 text-[#486451] font-bold border border-[#486451]/40">
            MERCHANT NETWORK ACTIVE
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Merchant Selector */}
        <div className="space-y-3">
          <h3 className="text-xs font-mono text-[#68716F] uppercase tracking-wider">Merchant Accounts</h3>
          <div className="space-y-2">
            {merchants.map(m => (
              <div
                key={m.id}
                onClick={() => setSelectedMerchantId(m.id)}
                className={`p-4 rounded-lg border transition-all cursor-pointer font-mono ${
                  m.id === selectedMerchantId
                    ? 'bg-[#292D2C] border-[#31596A]'
                    : 'bg-[#151817] border-[#292D2C] hover:border-[#68716F]'
                }`}
              >
                <div className="flex justify-between font-bold text-xs text-[#ECE9E1]">
                  <span>{m.name}</span>
                  <span className="text-[#31596A]">{m.city}</span>
                </div>
                <div className="text-[11px] text-[#68716F] mt-2 flex justify-between border-t border-[#292D2C] pt-2">
                  <span>Stock: {m.stockCount} Tins</span>
                  <span>Credit: £{m.creditLimit.toLocaleString()}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Trade Order Builder */}
        <div className="lg:col-span-2 p-6 rounded-lg bg-[#151817] border border-[#292D2C] space-y-6">
          <div className="flex justify-between items-center border-b border-[#292D2C] pb-3 font-mono">
            <div>
              <h3 className="font-display font-bold text-lg text-[#ECE9E1]">Trade Order Builder</h3>
              <p className="text-xs text-[#68716F]">Account: {activeMerchant.name}</p>
            </div>
            <span className="text-xs text-[#486451] font-bold">Credit Available: £{(activeMerchant.creditLimit - activeMerchant.outstandingBalance).toLocaleString()}</span>
          </div>

          {/* Product Order Line */}
          <div className="p-4 rounded bg-[#292D2C]/40 border border-[#292D2C] space-y-3 font-mono text-xs">
            <div className="flex justify-between font-bold text-[#ECE9E1]">
              <span>5L Premium Interior Matt Emulsion — Bristol Stone</span>
              <span className="text-[#31596A]">Trade Price: £28.50 / unit</span>
            </div>

            <div className="flex items-center gap-4 pt-2">
              <span className="text-[#68716F]">Order Quantity (Tins):</span>
              <input
                type="number"
                value={orderQuantity}
                onChange={e => setOrderQuantity(parseInt(e.target.value) || 1)}
                className="w-24 bg-[#151817] text-[#ECE9E1] font-bold px-3 py-1.5 rounded border border-[#68716F]/40 focus:outline-none"
              />
              <span className="text-[#ECE9E1] font-bold">Total: £{(orderQuantity * 28.50).toFixed(2)}</span>
            </div>
          </div>

          <button
            onClick={handlePlaceOrder}
            className="w-full py-3 rounded bg-[#31596A] hover:bg-[#31596A]/80 text-white font-mono text-xs font-bold cursor-pointer transition-colors flex items-center justify-center gap-2"
          >
            <ShoppingCart className="w-4 h-4" />
            Place Trade Order & Allocate Warehouse Stock
          </button>
        </div>
      </div>
    </div>
  );
};
