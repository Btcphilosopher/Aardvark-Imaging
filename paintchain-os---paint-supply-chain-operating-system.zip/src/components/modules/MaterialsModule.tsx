import React, { useState } from 'react';
import { usePaintChain } from '../../context/PaintChainContext';
import { LotStatus, RawMaterialCategory } from '../../types/paintchain';
import { Layers, ShieldAlert, CheckCircle2, Clock, AlertTriangle, Plus, Filter } from 'lucide-react';

export const MaterialsModule: React.FC = () => {
  const { materialLots, materials, suppliers, updateLotStatus } = usePaintChain();
  const [selectedCategory, setSelectedCategory] = useState<RawMaterialCategory | 'ALL'>('ALL');

  const filteredLots = materialLots.filter(lot => {
    const mat = materials.find(m => m.id === lot.materialId);
    if (selectedCategory === 'ALL') return true;
    return mat?.category === selectedCategory;
  });

  return (
    <div className="space-y-6">
      {/* Module Header */}
      <div className="p-4 rounded-lg bg-[#151817] border border-[#292D2C] flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-[#31596A]" />
            <h2 className="font-display font-bold text-xl text-[#ECE9E1]">RAW MATERIAL LOT SYSTEM</h2>
          </div>
          <p className="text-xs text-[#68716F] font-mono mt-0.5">
            Chemical Inventory Lots: Binders, Pigments, Fillers, Solvents & Additives with QC Lot Certificates
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex items-center gap-1 bg-[#292D2C] p-1 rounded font-mono text-xs">
          {(['ALL', 'BINDERS', 'PIGMENTS', 'FILLERS', 'SOLVENTS', 'ADDITIVES'] as const).map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
                selectedCategory === cat ? 'bg-[#31596A] text-white font-bold' : 'text-[#B9B7B0] hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Lot Status Grid */}
      <div className="bg-[#151817] border border-[#292D2C] rounded-lg overflow-hidden">
        <div className="p-4 border-b border-[#292D2C] bg-[#292D2C]/30 flex justify-between items-center text-xs font-mono text-[#68716F]">
          <span>DIGITAL LOT RECORDS ({filteredLots.length})</span>
          <span>RECEIVED → QUARANTINED → TESTED → RELEASED → CONSUMED</span>
        </div>

        <div className="divide-y divide-[#292D2C]">
          {filteredLots.map(lot => {
            const material = materials.find(m => m.id === lot.materialId);
            const supplier = suppliers.find(s => s.id === lot.supplierId);

            return (
              <div key={lot.lotNumber} className="p-4 hover:bg-[#292D2C]/30 transition-colors space-y-3">
                <div className="flex flex-wrap justify-between items-start gap-2">
                  <div>
                    <div className="flex items-center gap-2 font-mono">
                      <span className="font-bold text-sm text-[#ECE9E1]">{lot.lotNumber}</span>
                      <span className="text-xs text-[#31596A] font-semibold">[{material?.category}]</span>
                      <span className="text-xs text-[#68716F]">Ref: {lot.supplierLotRef}</span>
                    </div>
                    <div className="text-xs font-medium text-[#B9B7B0] mt-0.5">
                      {material?.name} ({material?.chemicalType})
                    </div>
                  </div>

                  {/* Status Dropdown */}
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-[#68716F] font-mono">Status:</span>
                    <select
                      value={lot.status}
                      onChange={e => updateLotStatus(lot.lotNumber, e.target.value as LotStatus)}
                      className={`px-2.5 py-1 rounded text-xs font-mono font-bold focus:outline-none cursor-pointer border ${
                        lot.status === 'RELEASED'
                          ? 'bg-[#486451]/20 text-[#486451] border-[#486451]/50'
                          : lot.status === 'QUARANTINED'
                          ? 'bg-[#9D4038]/20 text-[#9D4038] border-[#9D4038]/50'
                          : 'bg-[#C28A35]/20 text-[#C28A35] border-[#C28A35]/50'
                      }`}
                    >
                      <option value="RECEIVED" className="bg-[#151817]">RECEIVED</option>
                      <option value="QUARANTINED" className="bg-[#151817]">QUARANTINED</option>
                      <option value="TESTED" className="bg-[#151817]">TESTED</option>
                      <option value="RELEASED" className="bg-[#151817]">RELEASED</option>
                      <option value="CONSUMED" className="bg-[#151817]">CONSUMED</option>
                      <option value="REJECTED" className="bg-[#151817]">REJECTED</option>
                    </select>
                  </div>
                </div>

                {/* Details Bar */}
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs font-mono text-[#68716F] pt-2 border-t border-[#292D2C]/60 bg-[#292D2C]/20 p-2.5 rounded">
                  <div>
                    <span className="block text-[10px] text-[#68716F]">QUANTITY:</span>
                    <strong className="text-[#ECE9E1]">{lot.quantityKg.toLocaleString()} kg</strong>
                  </div>
                  <div>
                    <span className="block text-[10px] text-[#68716F]">SUPPLIER:</span>
                    <strong className="text-[#B9B7B0]">{supplier?.name}</strong>
                  </div>
                  <div>
                    <span className="block text-[10px] text-[#68716F]">LOCATION:</span>
                    <strong className="text-[#31596A]">{lot.warehouseLocation}</strong>
                  </div>
                  <div>
                    <span className="block text-[10px] text-[#68716F]">ARRIVAL DATE:</span>
                    <strong className="text-[#ECE9E1]">{lot.arrivalDate}</strong>
                  </div>
                  <div>
                    <span className="block text-[10px] text-[#68716F]">QC CERTIFICATE:</span>
                    <strong className="text-[#486451]">{lot.qcCertificateNo}</strong>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
