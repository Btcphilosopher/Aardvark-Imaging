import React from 'react';
import { usePaintChain } from '../../context/PaintChainContext';
import { Package, Layers, ShieldAlert, CheckCircle2, ArrowRight } from 'lucide-react';

export const InventoryModule: React.FC = () => {
  const { pallets, skus, batches } = usePaintChain();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-4 rounded-lg bg-[#151817] border border-[#292D2C] flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Package className="w-5 h-5 text-[#31596A]" />
            <h2 className="font-display font-bold text-xl text-[#ECE9E1]">WAREHOUSE DIGITAL TWIN & PALLET MANAGEMENT</h2>
          </div>
          <p className="text-xs text-[#68716F] font-mono mt-0.5">
            Aisles A1-A8, Racking Systems, FEFO/FIFO Dispatch Tracking & Finished Paint Stock Locations
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="px-2.5 py-1 rounded bg-[#486451]/20 text-[#486451] font-bold border border-[#486451]/40">
            FEFO / FIFO ENFORCED
          </span>
        </div>
      </div>

      {/* Warehouse Layout Visualizer */}
      <div className="p-6 rounded-lg bg-[#151817] border border-[#292D2C] space-y-4">
        <h3 className="font-display font-bold text-sm text-[#ECE9E1] border-b border-[#292D2C] pb-2">
          Finished Goods Warehouse Floor Plan (Aisle A - Architectural Coatings Zone)
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {pallets.map(pallet => {
            const sku = skus.find(s => s.skuCode === pallet.skuCode);
            const isQuarantine = pallet.status === 'QUARANTINE';

            return (
              <div
                key={pallet.id}
                className={`p-4 rounded-lg border font-mono space-y-2 ${
                  isQuarantine
                    ? 'bg-[#9D4038]/10 border-[#9D4038]'
                    : 'bg-[#292D2C]/40 border-[#292D2C]'
                }`}
              >
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-[#ECE9E1]">{pallet.id}</span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      pallet.status === 'IN_STOCK'
                        ? 'bg-[#486451]/20 text-[#486451]'
                        : isQuarantine
                        ? 'bg-[#9D4038]/20 text-[#9D4038]'
                        : 'bg-[#C28A35]/20 text-[#C28A35]'
                    }`}
                  >
                    {pallet.status}
                  </span>
                </div>

                <div className="text-xs text-[#B9B7B0] font-sans font-semibold">
                  {sku?.productName} — {sku?.colourName} ({sku?.packSize})
                </div>

                <div className="text-xs text-[#68716F] space-y-0.5 pt-2 border-t border-[#292D2C]">
                  <div>Location: <strong className="text-[#31596A]">{pallet.locationCode}</strong></div>
                  <div>Units on Pallet: <strong className="text-[#ECE9E1]">{pallet.quantityUnits} Tins</strong></div>
                  <div>Batch Ref: <strong className="text-[#B58A3C]">{pallet.batchNumber}</strong></div>
                  {pallet.destination && (
                    <div className="text-[11px] text-[#486451] pt-1">Dest: {pallet.destination}</div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
