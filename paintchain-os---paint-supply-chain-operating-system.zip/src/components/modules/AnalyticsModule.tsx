import React from 'react';
import { usePaintChain } from '../../context/PaintChainContext';
import { TrendingUp, Zap, AlertTriangle, Calculator, DollarSign, ArrowRight } from 'lucide-react';

export const AnalyticsModule: React.FC = () => {
  const {
    scenarioShock,
    setScenarioShock,
    triggerSignatureDemo,
    calculateBatchCostWithShocks,
    batches
  } = usePaintChain();

  const batchCost = calculateBatchCostWithShocks('BATCH-26-09184');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-4 rounded-lg bg-[#151817] border border-[#292D2C] flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-[#31596A]" />
            <h2 className="font-display font-bold text-xl text-[#ECE9E1]">SUPPLY CHAIN SCENARIO & COSTING ENGINE</h2>
          </div>
          <p className="text-xs text-[#68716F] font-mono mt-0.5">
            Simulate Raw Material Price Shocks, Factory Disruption, Margin Recalculations & Demand Cascades
          </p>
        </div>

        <button
          onClick={() => triggerSignatureDemo(2)}
          className="px-3 py-1.5 rounded bg-[#C28A35] hover:bg-[#C28A35]/80 text-white font-mono text-xs font-bold cursor-pointer transition-colors flex items-center gap-1.5"
        >
          <Zap className="w-4 h-4" />
          Toggle TiO₂ +18% Price Shock
        </button>
      </div>

      {/* Interactive Scenario Controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-6 rounded-lg bg-[#151817] border border-[#292D2C] space-y-4">
          <h3 className="font-display font-bold text-sm text-[#ECE9E1] border-b border-[#292D2C] pb-2">
            Simulation Parameters
          </h3>

          <div className="space-y-4 font-mono text-xs">
            <div>
              <div className="flex justify-between text-[#68716F] mb-1">
                <span>TiO₂ Pigment Price Variance:</span>
                <span className="text-[#C28A35] font-bold">+{scenarioShock.tio2PriceShockPct}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="50"
                value={scenarioShock.tio2PriceShockPct}
                onChange={e => setScenarioShock(prev => ({ ...prev, tio2PriceShockPct: parseInt(e.target.value) || 0 }))}
                className="w-full accent-[#C28A35] cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-[#68716F] mb-1">
                <span>Acrylic Binder Price Variance:</span>
                <span className="text-[#31596A] font-bold">+{scenarioShock.resinPriceShockPct}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="50"
                value={scenarioShock.resinPriceShockPct}
                onChange={e => setScenarioShock(prev => ({ ...prev, resinPriceShockPct: parseInt(e.target.value) || 0 }))}
                className="w-full accent-[#31596A] cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Live Costing Recalculation Output */}
        <div className="p-6 rounded-lg bg-[#151817] border border-[#31596A]/60 space-y-4 font-mono">
          <h3 className="font-display font-bold text-sm text-[#ECE9E1] border-b border-[#292D2C] pb-2">
            Live True Batch Costing (Batch-09184 — 8,000 kg Run)
          </h3>

          <div className="space-y-2 text-xs">
            <div className="flex justify-between text-[#68716F]">
              <span>RAW MATERIAL COST:</span>
              <strong className="text-[#ECE9E1]">£{batchCost.rawMaterialCost.toLocaleString('en-GB', { minimumFractionDigits: 2 })}</strong>
            </div>
            <div className="flex justify-between text-[#68716F]">
              <span>LABOUR & PLANT OPERATING COST:</span>
              <strong className="text-[#ECE9E1]">£{batchCost.laborCost.toFixed(2)}</strong>
            </div>
            <div className="flex justify-between text-[#68716F]">
              <span>ENERGY & DISPERSION UTILITY COST:</span>
              <strong className="text-[#ECE9E1]">£{batchCost.energyCost.toFixed(2)}</strong>
            </div>
            <div className="flex justify-between text-[#ECE9E1] font-bold pt-2 border-t border-[#292D2C] text-sm">
              <span>TOTAL BATCH MANUFACTURING COST:</span>
              <span className="text-[#B58A3C]">£{batchCost.totalCost.toLocaleString('en-GB', { minimumFractionDigits: 2 })}</span>
            </div>
            <div className="flex justify-between text-[#486451] font-bold text-sm pt-1">
              <span>TRUE BATCH COST PER LITRE:</span>
              <span>£{batchCost.costPerLitre.toFixed(2)} / Litre</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
