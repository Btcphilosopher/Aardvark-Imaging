import React, { useState } from 'react';
import { usePaintChain } from '../../context/PaintChainContext';
import {
  Activity,
  ArrowRight,
  ArrowLeft,
  Building2,
  Layers,
  Sparkles,
  Factory,
  Package,
  Truck,
  Paintbrush,
  Home,
  CheckCircle2,
  ShieldAlert,
  Zap
} from 'lucide-react';

export const TraceModule: React.FC = () => {
  const {
    selectedTraceBatchId,
    setSelectedTraceBatchId,
    batches,
    formulations,
    colours,
    materials,
    suppliers,
    skus,
    pallets,
    merchants,
    painterJobs
  } = usePaintChain();

  const [traceDirection, setTraceDirection] = useState<'BOTH' | 'BACKWARD' | 'FORWARD'>('BOTH');

  const batch = batches.find(b => b.batchNumber === selectedTraceBatchId) || batches[0];
  const formula = formulations.find(f => f.id === batch.formulaId);
  const colour = colours.find(c => c.id === batch.colourId);

  // Upstream
  const consumedLots = batch.consumedLots;
  const upstreamSuppliers = suppliers.slice(0, 3);

  // Downstream
  const downstreamSKUs = skus.filter(s => s.batchNumber === batch.batchNumber);
  const downstreamPallets = pallets.filter(p => p.batchNumber === batch.batchNumber);
  const downstreamJobs = painterJobs.filter(j => j.rooms.some(r => r.allocatedBatchNumber === batch.batchNumber));

  return (
    <div className="space-y-6">
      {/* Signature Demo 1 Header Banner */}
      <div className="p-6 rounded-lg bg-gradient-to-r from-[#151817] via-[#292D2C] to-[#151817] border-2 border-[#31596A] space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-[#31596A] text-white font-mono text-xs font-bold flex items-center gap-1">
                <Zap className="w-3.5 h-3.5" /> SIGNATURE DEMO 1
              </span>
              <h2 className="font-display font-extrabold text-2xl text-[#ECE9E1]">
                END-TO-END PAINT GENEALOGY & PROVENANCE
              </h2>
            </div>
            <p className="text-xs text-[#B9B7B0] font-mono">
              Tracing <strong className="text-[#ECE9E1]">BATCH-26-09184</strong> (5L Premium Interior Matt in Bristol Stone) backwards to chemical lots & suppliers, and forwards to finished room surfaces.
            </p>
          </div>

          {/* Batch Switcher */}
          <div className="flex items-center gap-2 bg-[#292D2C] p-2 rounded font-mono text-xs border border-[#31596A]/40">
            <span className="text-[#68716F]">Target Batch:</span>
            <select
              value={selectedTraceBatchId}
              onChange={e => setSelectedTraceBatchId(e.target.value)}
              className="bg-[#151817] text-[#ECE9E1] font-bold px-2 py-1 rounded focus:outline-none cursor-pointer"
            >
              {batches.map(b => (
                <option key={b.batchNumber} value={b.batchNumber}>
                  {b.batchNumber} ({b.colourName})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Direction Toggles */}
        <div className="flex items-center gap-2 pt-2 border-t border-[#292D2C] font-mono text-xs">
          <span className="text-[#68716F]">Trace Vector:</span>
          <button
            onClick={() => setTraceDirection('BOTH')}
            className={`px-3 py-1 rounded cursor-pointer ${traceDirection === 'BOTH' ? 'bg-[#31596A] text-white font-bold' : 'bg-[#292D2C] text-[#B9B7B0]'}`}
          >
            Full Chain (Chemicals → Surface)
          </button>
          <button
            onClick={() => setTraceDirection('BACKWARD')}
            className={`px-3 py-1 rounded cursor-pointer ${traceDirection === 'BACKWARD' ? 'bg-[#31596A] text-white font-bold' : 'bg-[#292D2C] text-[#B9B7B0]'}`}
          >
            ← Trace Backward (Upstream)
          </button>
          <button
            onClick={() => setTraceDirection('FORWARD')}
            className={`px-3 py-1 rounded cursor-pointer ${traceDirection === 'FORWARD' ? 'bg-[#31596A] text-white font-bold' : 'bg-[#292D2C] text-[#B9B7B0]'}`}
          >
            Trace Forward (Downstream) →
          </button>
        </div>
      </div>

      {/* Interactive Genealogy Chain Tree */}
      <div className="p-6 rounded-lg bg-[#151817] border border-[#292D2C] space-y-8 overflow-x-auto">
        <div className="min-w-[1000px] space-y-8">
          {/* UPSTREAM NODES */}
          {(traceDirection === 'BOTH' || traceDirection === 'BACKWARD') && (
            <div className="space-y-4">
              <div className="text-xs font-mono text-[#31596A] font-bold uppercase tracking-wider flex items-center gap-2">
                <ArrowLeft className="w-4 h-4" /> UPSTREAM GENEALOGY (CHEMICAL SUPPLIERS → RAW LOTS → FORMULA)
              </div>

              <div className="grid grid-cols-3 gap-4 font-mono text-xs">
                {/* 1. Suppliers */}
                <div className="p-4 rounded bg-[#292D2C]/40 border border-[#292D2C] space-y-2">
                  <div className="text-[#68716F] flex items-center gap-1.5"><Building2 className="w-4 h-4 text-[#31596A]" /> 1. CHEMICAL SUPPLIERS</div>
                  <div className="space-y-1">
                    {upstreamSuppliers.map(s => (
                      <div key={s.id} className="p-2 rounded bg-[#151817] text-[#ECE9E1]">
                        <div className="font-bold">{s.name}</div>
                        <div className="text-[10px] text-[#68716F]">{s.city}, {s.country}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 2. Raw Material Lots */}
                <div className="p-4 rounded bg-[#292D2C]/40 border border-[#292D2C] space-y-2">
                  <div className="text-[#68716F] flex items-center gap-1.5"><Layers className="w-4 h-4 text-[#B58A3C]" /> 2. RAW MATERIAL LOTS</div>
                  <div className="space-y-1">
                    {consumedLots.map(lot => (
                      <div key={lot.lotNumber} className="p-2 rounded bg-[#151817] text-[#ECE9E1]">
                        <div className="font-bold text-[#B58A3C]">{lot.lotNumber}</div>
                        <div className="text-[10px] text-[#68716F]">Qty Used: {lot.actualKgUsed} kg</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 3. Formulation */}
                <div className="p-4 rounded bg-[#292D2C]/40 border border-[#31596A]/60 space-y-2">
                  <div className="text-[#68716F] flex items-center gap-1.5"><Sparkles className="w-4 h-4 text-[#31596A]" /> 3. FORMULATION REVISION</div>
                  <div className="p-2.5 rounded bg-[#151817] text-[#ECE9E1] space-y-1">
                    <div className="font-bold text-[#31596A]">{formula?.formulaCode}</div>
                    <div className="text-xs">Version: <strong>{batch.formulaVersion}</strong></div>
                    <div className="text-[10px] text-[#486451]">VOC Level: 8.2 g/L</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* CENTRAL NODE: PRODUCTION BATCH */}
          <div className="p-6 rounded-lg bg-[#292D2C] border-2 border-[#31596A] shadow-xl text-center space-y-3 font-mono">
            <div className="flex justify-center items-center gap-2 text-xs text-[#31596A] font-bold">
              <Factory className="w-5 h-5 animate-pulse" /> CENTRAL BATCH NODE
            </div>
            <div className="text-2xl font-extrabold text-[#ECE9E1]">{batch.batchNumber}</div>
            <div className="text-sm text-[#B9B7B0]">
              {batch.productName} — <span className="text-[#31596A] font-bold">{batch.colourName}</span>
            </div>
            <div className="flex justify-center gap-6 text-xs text-[#68716F] pt-2 border-t border-[#31596A]/30">
              <span>Actual Yield: <strong className="text-[#ECE9E1]">{batch.actualKg.toLocaleString()} kg</strong></span>
              <span>Vessel: <strong className="text-[#ECE9E1]">{batch.tankId}</strong></span>
              <span>Status: <strong className={batch.status === 'QUARANTINED' ? 'text-[#9D4038]' : 'text-[#486451]'}>{batch.status}</strong></span>
            </div>
          </div>

          {/* DOWNSTREAM NODES */}
          {(traceDirection === 'BOTH' || traceDirection === 'FORWARD') && (
            <div className="space-y-4">
              <div className="text-xs font-mono text-[#486451] font-bold uppercase tracking-wider flex items-center gap-2">
                DOWNSTREAM DISTRIBUTION (FILLING LINE → WAREHOUSE → MERCHANT → PAINTER → ROOM SURFACE) <ArrowRight className="w-4 h-4" />
              </div>

              <div className="grid grid-cols-4 gap-4 font-mono text-xs">
                {/* 1. Packaged SKUs */}
                <div className="p-4 rounded bg-[#292D2C]/40 border border-[#292D2C] space-y-2">
                  <div className="text-[#68716F] flex items-center gap-1.5"><Package className="w-4 h-4 text-[#31596A]" /> 1. PACKAGED SKUs</div>
                  {downstreamSKUs.map(s => (
                    <div key={s.id} className="p-2 rounded bg-[#151817] text-[#ECE9E1]">
                      <div className="font-bold">{s.skuCode}</div>
                      <div className="text-[10px] text-[#68716F]">Pack: {s.packSize} · EAN: {s.barcode}</div>
                    </div>
                  ))}
                </div>

                {/* 2. Warehouse Pallets */}
                <div className="p-4 rounded bg-[#292D2C]/40 border border-[#292D2C] space-y-2">
                  <div className="text-[#68716F] flex items-center gap-1.5"><Package className="w-4 h-4 text-[#B58A3C]" /> 2. PALLETS</div>
                  {downstreamPallets.map(p => (
                    <div key={p.id} className="p-2 rounded bg-[#151817] text-[#ECE9E1]">
                      <div className="font-bold text-[#B58A3C]">{p.id}</div>
                      <div className="text-[10px] text-[#68716F]">Location: {p.locationCode}</div>
                    </div>
                  ))}
                </div>

                {/* 3. Trade Merchant */}
                <div className="p-4 rounded bg-[#292D2C]/40 border border-[#292D2C] space-y-2">
                  <div className="text-[#68716F] flex items-center gap-1.5"><Building2 className="w-4 h-4 text-[#486451]" /> 3. TRADE MERCHANT</div>
                  <div className="p-2 rounded bg-[#151817] text-[#ECE9E1]">
                    <div className="font-bold">Crown & Trades Bristol</div>
                    <div className="text-[10px] text-[#68716F]">Order: ORD-90214</div>
                  </div>
                </div>

                {/* 4. Applied Room Surface */}
                <div className="p-4 rounded bg-[#292D2C]/40 border border-[#486451]/60 space-y-2">
                  <div className="text-[#68716F] flex items-center gap-1.5"><Home className="w-4 h-4 text-[#486451]" /> 4. FINISHED SURFACE</div>
                  {downstreamJobs.map(j => (
                    <div key={j.id} className="p-2 rounded bg-[#151817] text-[#ECE9E1] space-y-1">
                      <div className="font-bold text-[#486451]">{j.rooms[0].roomName}</div>
                      <div className="text-[10px] text-[#B9B7B0]">{j.propertyAddress}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
