export type RawMaterialCategory = 'BINDERS' | 'PIGMENTS' | 'FILLERS' | 'SOLVENTS' | 'ADDITIVES';

export type LotStatus = 'RECEIVED' | 'QUARANTINED' | 'TESTED' | 'RELEASED' | 'CONSUMED' | 'REJECTED';

export type BatchStatus = 'QUEUED' | 'PRE-MIX' | 'DISPERSION' | 'MILLING' | 'LET-DOWN' | 'AWAITING_QC' | 'QC_RELEASED' | 'QUARANTINED' | 'FILLED' | 'REWORK';

export type ColourFamily = 'WHITE' | 'OFF-WHITE' | 'GREY' | 'BLACK' | 'BLUE' | 'GREEN' | 'YELLOW' | 'ORANGE' | 'RED' | 'PINK' | 'PURPLE' | 'BROWN' | 'EARTH' | 'STONE';

export type UserPersona = 'ALL' | 'SUPPLIER' | 'MANUFACTURER' | 'LAB_CHEMIST' | 'WAREHOUSE_MGR' | 'TRADE_MERCHANT' | 'PAINTER' | 'ARCHITECT' | 'CUSTOMER';

export interface Supplier {
  id: string;
  name: string;
  code: string;
  country: string;
  city: string;
  categories: RawMaterialCategory[];
  approvedStatus: 'Approved' | 'Under Audit' | 'Provisional';
  rating: number; // 0 - 5
  deliveryPerformancePct: number;
  priceTrendPct: number;
  leadTimeDays: number;
  minOrderQtyKg: number;
  certificates: string[];
  contactEmail: string;
  sdsDocumentCount: number;
}

export interface RawMaterial {
  id: string;
  code: string;
  name: string;
  category: RawMaterialCategory;
  chemicalType: string;
  supplierId: string;
  unit: 'kg' | 'L' | 'tonnes';
  costPerKg: number;
  densityGPerMl: number;
  vocGramsPerLitre: number;
  purityPct: number;
  reorderLevelKg: number;
  currentStockKg: number;
  sdsCode: string;
}

export interface MaterialLot {
  lotNumber: string; // e.g. RM-TIO2-20260921-00482
  materialId: string;
  supplierId: string;
  supplierLotRef: string;
  quantityKg: number;
  arrivalDate: string;
  expiryDate: string;
  warehouseLocation: string;
  status: LotStatus;
  qcCertificateNo: string;
  unitCost: number;
}

export interface FormulaIngredient {
  materialId: string;
  percentage: number; // e.g. 31.2%
  targetKg: number;   // calculated based on batch size
  costPerBatch: number;
}

export interface FormulaVersion {
  versionId: string; // e.g. v14.3
  revisionDate: string;
  author: string;
  reasonForChange: string;
  isApproved: boolean;
  targetBatchSizeKg: number;
  vocGramsPerLitre: number;
  targetViscosityKu: number;
  targetGlossPct: number;
  targetDensityGPerMl: number;
  ingredients: FormulaIngredient[];
  estimatedCostPerLitre: number;
}

export interface Formulation {
  id: string;
  formulaCode: string; // e.g. TV-EMULSION-WHITE-MATT
  name: string;
  productFamily: string;
  currentVersion: string; // v14.3
  revisions: FormulaVersion[];
  ipProtected: boolean;
}

export interface Colour {
  id: string;
  colourCode: string; // e.g. TV-COL-421
  name: string;       // e.g. Bristol Stone
  family: ColourFamily;
  hex: string;
  rgb: { r: number; g: number; b: number };
  lab: { L: number; a: number; b: number };
  basePaintFormulaId: string;
  tintRecipe: {
    baseVolume: string;
    doses: { pigmentId: string; doseMl: number }[];
  };
}

export interface FactoryTank {
  id: string; // T-01 to T-16
  name: string;
  type: 'Storage' | 'High-Speed Disperser' | 'Media Mill' | 'Let-Down Vessel' | 'Filling Line';
  capacityL: number;
  currentLevelL: number;
  currentBatchNumber?: string;
  temperatureC: number;
  rpm: number;
  status: 'Active' | 'Idle' | 'Cleaning' | 'Maintenance' | 'Alarm';
  utilizationPct: number;
}

export interface BatchConsumedLot {
  lotNumber: string;
  materialId: string;
  actualKgUsed: number;
}

export interface QualityTest {
  id: string;
  testName: string;
  specification: string;
  targetValue: string;
  measuredValue: string;
  unit: string;
  passed: boolean;
  operator: string;
  timestamp: string;
}

export interface BatchRecord {
  batchNumber: string; // e.g. BATCH-26-09184
  productName: string;
  formulaId: string;
  formulaVersion: string;
  colourId: string;
  colourName: string;
  targetKg: number;
  actualKg: number;
  tankId: string;
  operator: string;
  status: BatchStatus;
  startTime: string;
  completionTime?: string;
  consumedLots: BatchConsumedLot[];
  qualityTests: QualityTest[];
  quarantineReason?: string;
  quarantineFinancialValue?: number;
  yieldPct: number;
  costPerLitre: number;
}

export interface PackagedSKU {
  id: string;
  skuCode: string; // e.g. SKU-PIM-BS-5L
  productName: string;
  colourName: string;
  colourHex: string;
  packSize: '500ml' | '1L' | '2.5L' | '5L' | '10L' | '15L' | '20L';
  litresPerUnit: number;
  batchNumber: string;
  unitsProduced: number;
  unitsInWarehouse: number;
  unitsReserved: number;
  tradePrice: number;
  retailPrice: number;
  barcode: string;
  palletIds: string[];
}

export interface Pallet {
  id: string; // e.g. PAL-8842
  skuCode: string;
  batchNumber: string;
  quantityUnits: number;
  locationCode: string; // e.g. A-04-R02-S3
  status: 'IN_STOCK' | 'RESERVED' | 'QUARANTINE' | 'DISPATCHED';
  destination?: string;
}

export interface LogisticsShipment {
  id: string; // e.g. SHP-2026-9921
  vehicleReg: string;
  driverName: string;
  origin: string;
  destination: string;
  destinationType: 'FACTORY' | 'WAREHOUSE' | 'MERCHANT' | 'PAINTER';
  palletIds: string[];
  status: 'SCHEDULED' | 'LOADING' | 'IN_TRANSIT' | 'DELIVERED';
  eta: string;
  temperatureC: number;
  gpsCoordinates: { lat: number; lng: number };
}

export interface TradeMerchant {
  id: string;
  name: string;
  city: string;
  stockCount: number;
  creditLimit: number;
  outstandingBalance: number;
  rating: number;
}

export interface SalesOrder {
  id: string; // e.g. ORD-90214
  merchantId: string;
  merchantName: string;
  customerOrPainterName: string;
  jobId?: string;
  items: {
    skuCode: string;
    productName: string;
    colourName: string;
    packSize: string;
    quantity: number;
    unitPrice: number;
    batchAllocated: string;
  }[];
  totalAmount: number;
  status: 'PENDING' | 'ALLOCATED' | 'PICKED' | 'DISPATCHED' | 'DELIVERED';
  placedAt: string;
}

export interface RoomSpecification {
  roomId: string;
  roomName: string;
  lengthM: number;
  widthM: number;
  heightM: number;
  doors: number;
  windows: number;
  coats: number;
  substrate: string;
  wallAreaM2: number;
  ceilingAreaM2: number;
  estimatedLitresRequired: number;
  productName: string;
  colourName: string;
  colourHex: string;
  allocatedBatchNumber: string;
  appliedDate?: string;
  applicationNotes?: string;
  photosUploaded?: number;
}

export interface PainterJob {
  id: string; // e.g. JOB-004182
  painterName: string;
  clientName: string;
  propertyAddress: string;
  city: string;
  rooms: RoomSpecification[];
  totalLitresEstimated: number;
  status: 'PLANNING' | 'PAINT_ORDERED' | 'IN_PROGRESS' | 'COMPLETED';
  createdDate: string;
}

export interface TraceabilityNode {
  id: string;
  title: string;
  type: 'SUPPLIER' | 'RAW_LOT' | 'FORMULA' | 'TANK' | 'BATCH' | 'FILLING' | 'PALLET' | 'WAREHOUSE' | 'MERCHANT' | 'PAINTER' | 'PROJECT' | 'ROOM';
  details: Record<string, string | number>;
  status: 'NORMAL' | 'QUARANTINE' | 'HIGHLIGHTED';
  children?: TraceabilityNode[];
}

export interface EventLog {
  id: string;
  timestamp: string;
  eventType: string;
  actor: string;
  description: string;
  batchNumber?: string;
  severity: 'INFO' | 'SUCCESS' | 'WARNING' | 'ALERT';
}

export interface ScenarioShockState {
  tio2PriceShockPct: number;      // e.g. +18%
  resinPriceShockPct: number;     // e.g. +5%
  solventDelayDays: number;       // e.g. 7 days
  shadeFailureTriggered: boolean; // e.g. true for Signature Demo 3
  painterDemandMultiplier: number;// e.g. 1.25x
}
