import React, { useState } from 'react';
import { PaintChainProvider, usePaintChain } from './context/PaintChainContext';
import { Header } from './components/common/Header';
import { GlobalSearchModal } from './components/common/GlobalSearchModal';
import { EventStreamConsole } from './components/common/EventStreamConsole';

// Modules
import { OverviewModule } from './components/modules/OverviewModule';
import { SupplyModule } from './components/modules/SupplyModule';
import { MaterialsModule } from './components/modules/MaterialsModule';
import { LabModule } from './components/modules/LabModule';
import { FormulasModule } from './components/modules/FormulasModule';
import { ProductionModule } from './components/modules/ProductionModule';
import { QualityModule } from './components/modules/QualityModule';
import { InventoryModule } from './components/modules/InventoryModule';
import { LogisticsModule } from './components/modules/LogisticsModule';
import { ProductsModule } from './components/modules/ProductsModule';
import { TradeModule } from './components/modules/TradeModule';
import { PaintersModule } from './components/modules/PaintersModule';
import { ProjectsModule } from './components/modules/ProjectsModule';
import { TraceModule } from './components/modules/TraceModule';
import { AnalyticsModule } from './components/modules/AnalyticsModule';

const ModuleContent: React.FC = () => {
  const { activeModule } = usePaintChain();

  switch (activeModule) {
    case 'OVERVIEW':
      return <OverviewModule />;
    case 'SUPPLY':
      return <SupplyModule />;
    case 'MATERIALS':
      return <MaterialsModule />;
    case 'LAB':
      return <LabModule />;
    case 'FORMULAS':
      return <FormulasModule />;
    case 'PRODUCTION':
      return <ProductionModule />;
    case 'QUALITY':
      return <QualityModule />;
    case 'INVENTORY':
      return <InventoryModule />;
    case 'LOGISTICS':
      return <LogisticsModule />;
    case 'PRODUCTS':
      return <ProductsModule />;
    case 'TRADE':
      return <TradeModule />;
    case 'PAINTERS':
      return <PaintersModule />;
    case 'PROJECTS':
      return <ProjectsModule />;
    case 'TRACE':
      return <TraceModule />;
    case 'ANALYTICS':
      return <AnalyticsModule />;
    default:
      return <OverviewModule />;
  }
};

export default function App() {
  const [searchOpen, setSearchOpen] = useState(false);
  const [eventsOpen, setEventsOpen] = useState(false);

  return (
    <PaintChainProvider>
      <div className="min-h-screen bg-[#151817] text-[#ECE9E1] font-sans flex flex-col selection:bg-[#31596A] selection:text-white">
        {/* Header */}
        <Header onOpenSearch={() => setSearchOpen(true)} onOpenEvents={() => setEventsOpen(true)} />

        {/* Main Content Area */}
        <main className="flex-1 max-w-[1700px] w-full mx-auto px-4 lg:px-6 py-6">
          <ModuleContent />
        </main>

        {/* Quiet Industrial Footer */}
        <footer className="border-t border-[#292D2C] bg-[#151817] py-6 px-6 text-xs text-[#68716F] font-mono">
          <div className="max-w-[1700px] mx-auto flex flex-wrap justify-between items-center gap-4">
            <div>
              <strong className="text-[#ECE9E1]">PAINTCHAIN OS</strong> — End-to-End Paint & Coatings Supply Chain Operating System
            </div>
            <div className="flex items-center gap-4">
              <span>SYNTHETIC INDUSTRIAL DATA WORLD</span>
              <span>·</span>
              <span>REST API: /api/v1/trace/BATCH-26-09184</span>
              <span>·</span>
              <span>WEBSOCKETS ACTIVE</span>
            </div>
          </div>
        </footer>

        {/* Modals & Slide-overs */}
        <GlobalSearchModal isOpen={searchOpen} onClose={() => setSearchOpen(false)} />
        <EventStreamConsole isOpen={eventsOpen} onClose={() => setEventsOpen(false)} />
      </div>
    </PaintChainProvider>
  );
}
