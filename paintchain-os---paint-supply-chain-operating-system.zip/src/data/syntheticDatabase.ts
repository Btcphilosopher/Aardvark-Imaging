import {
  Supplier,
  RawMaterial,
  MaterialLot,
  Formulation,
  Colour,
  FactoryTank,
  BatchRecord,
  PackagedSKU,
  Pallet,
  LogisticsShipment,
  TradeMerchant,
  SalesOrder,
  PainterJob,
  EventLog
} from '../types/paintchain';

export const INITIAL_SUPPLIERS: Supplier[] = [
  {
    id: 'SUP-01',
    name: 'British Acrylic Resins Ltd',
    code: 'BAR-UK',
    country: 'United Kingdom',
    city: 'Manchester',
    categories: ['BINDERS'],
    approvedStatus: 'Approved',
    rating: 4.9,
    deliveryPerformancePct: 98.4,
    priceTrendPct: 2.1,
    leadTimeDays: 4,
    minOrderQtyKg: 5000,
    certificates: ['ISO 9001:2015', 'REACH Compliant', 'ISO 14001'],
    contactEmail: 'technical@britishacrylics.co.uk',
    sdsDocumentCount: 14
  },
  {
    id: 'SUP-02',
    name: 'Titanium Pigments UK PLC',
    code: 'TIO2-UK',
    country: 'United Kingdom',
    city: 'Grimsby',
    categories: ['PIGMENTS'],
    approvedStatus: 'Approved',
    rating: 4.8,
    deliveryPerformancePct: 96.8,
    priceTrendPct: 18.0, // Used for Shock simulation!
    leadTimeDays: 7,
    minOrderQtyKg: 10000,
    certificates: ['ISO 9001', 'Heavy Metal Free Certificate'],
    contactEmail: 'sales@titaniumpigments.co.uk',
    sdsDocumentCount: 8
  },
  {
    id: 'SUP-03',
    name: 'Cotswold Minerals & Fillers',
    code: 'CMF-GLOS',
    country: 'United Kingdom',
    city: 'Stroud',
    categories: ['FILLERS'],
    approvedStatus: 'Approved',
    rating: 4.9,
    deliveryPerformancePct: 99.1,
    priceTrendPct: 0.8,
    leadTimeDays: 2,
    minOrderQtyKg: 2000,
    certificates: ['ISO 9001', 'UKCA Quality Standard'],
    contactEmail: 'orders@cotswoldminerals.co.uk',
    sdsDocumentCount: 6
  },
  {
    id: 'SUP-04',
    name: 'Thames Solvents & Specialty Esters',
    code: 'TSSE-LDN',
    country: 'United Kingdom',
    city: 'London',
    categories: ['SOLVENTS'],
    approvedStatus: 'Approved',
    rating: 4.6,
    deliveryPerformancePct: 94.2,
    priceTrendPct: 4.5,
    leadTimeDays: 5,
    minOrderQtyKg: 1000,
    certificates: ['ISO 9001', 'Hazmat Carrier Certified'],
    contactEmail: 'supply@thamessolvents.co.uk',
    sdsDocumentCount: 22
  },
  {
    id: 'SUP-05',
    name: 'AddiTech Polymer Additives',
    code: 'ADDT-BAM',
    country: 'United Kingdom',
    city: 'Birmingham',
    categories: ['ADDITIVES'],
    approvedStatus: 'Approved',
    rating: 4.7,
    deliveryPerformancePct: 97.5,
    priceTrendPct: 1.5,
    leadTimeDays: 3,
    minOrderQtyKg: 500,
    certificates: ['ISO 9001', 'EcoVadis Gold'],
    contactEmail: 'support@additechpolymers.co.uk',
    sdsDocumentCount: 31
  }
];

export const INITIAL_MATERIALS: RawMaterial[] = [
  {
    id: 'RM-ACRYLIC-01',
    code: 'RM-ACR-101',
    name: 'Pure Acrylic Emulsion (50% Solids)',
    category: 'BINDERS',
    chemicalType: 'Styrene-Acrylic Latex',
    supplierId: 'SUP-01',
    unit: 'kg',
    costPerKg: 2.85,
    densityGPerMl: 1.05,
    vocGramsPerLitre: 12,
    purityPct: 99.5,
    reorderLevelKg: 15000,
    currentStockKg: 38400,
    sdsCode: 'SDS-BAR-ACR-50'
  },
  {
    id: 'RM-TIO2-01',
    code: 'RM-TIO2-402',
    name: 'Titanium Dioxide Rutile Pigment',
    category: 'PIGMENTS',
    chemicalType: 'Surface Treated TiO2',
    supplierId: 'SUP-02',
    unit: 'kg',
    costPerKg: 3.40,
    densityGPerMl: 4.20,
    vocGramsPerLitre: 0,
    purityPct: 99.8,
    reorderLevelKg: 20000,
    currentStockKg: 82000,
    sdsCode: 'SDS-TIO2-RUTILE'
  },
  {
    id: 'RM-CALCIUM-01',
    code: 'RM-CAL-200',
    name: 'Micro-Mesh Calcium Carbonate Extender',
    category: 'FILLERS',
    chemicalType: 'Ground Natural Limestone',
    supplierId: 'SUP-03',
    unit: 'kg',
    costPerKg: 0.42,
    densityGPerMl: 2.70,
    vocGramsPerLitre: 0,
    purityPct: 98.2,
    reorderLevelKg: 30000,
    currentStockKg: 112000,
    sdsCode: 'SDS-CAL-EXT-2'
  },
  {
    id: 'RM-WATER-01',
    code: 'RM-H2O-001',
    name: 'Deionised Purified Water',
    category: 'SOLVENTS',
    chemicalType: 'Purified H2O',
    supplierId: 'SUP-04',
    unit: 'kg',
    costPerKg: 0.05,
    densityGPerMl: 1.00,
    vocGramsPerLitre: 0,
    purityPct: 99.99,
    reorderLevelKg: 50000,
    currentStockKg: 250000,
    sdsCode: 'SDS-WATER-DI'
  },
  {
    id: 'RM-ADDITIVE-DISP',
    code: 'RM-ADD-DISP1',
    name: 'Sodium Polycarboxylate Dispersant',
    category: 'ADDITIVES',
    chemicalType: 'Polymeric Dispersant',
    supplierId: 'SUP-05',
    unit: 'kg',
    costPerKg: 6.80,
    densityGPerMl: 1.12,
    vocGramsPerLitre: 5,
    purityPct: 98.0,
    reorderLevelKg: 1000,
    currentStockKg: 3400,
    sdsCode: 'SDS-ADD-DISP-01'
  },
  {
    id: 'RM-ADDITIVE-RHEO',
    code: 'RM-ADD-RHEO2',
    name: 'HEUR Hydrophobic Rheology Modifier',
    category: 'ADDITIVES',
    chemicalType: 'Ethoxylated Polyurethane',
    supplierId: 'SUP-05',
    unit: 'kg',
    costPerKg: 11.50,
    densityGPerMl: 1.04,
    vocGramsPerLitre: 15,
    purityPct: 97.5,
    reorderLevelKg: 800,
    currentStockKg: 2100,
    sdsCode: 'SDS-ADD-RHEO-02'
  }
];

export const INITIAL_MATERIAL_LOTS: MaterialLot[] = [
  {
    lotNumber: 'RM-TIO2-20260921-00482',
    materialId: 'RM-TIO2-01',
    supplierId: 'SUP-02',
    supplierLotRef: 'TIO2-BATCH-9941A',
    quantityKg: 25000,
    arrivalDate: '2026-09-21',
    expiryDate: '2028-09-21',
    warehouseLocation: 'RAW-ZONE-A02',
    status: 'RELEASED',
    qcCertificateNo: 'QC-CERT-SUP-9941',
    unitCost: 3.40
  },
  {
    lotNumber: 'RM-ACR-20260920-00192',
    materialId: 'RM-ACRYLIC-01',
    supplierId: 'SUP-01',
    supplierLotRef: 'BAR-ACR-8812',
    quantityKg: 30000,
    arrivalDate: '2026-09-20',
    expiryDate: '2027-09-20',
    warehouseLocation: 'RAW-ZONE-B01',
    status: 'RELEASED',
    qcCertificateNo: 'QC-CERT-BAR-8812',
    unitCost: 2.85
  },
  {
    lotNumber: 'RM-CAL-20260919-00331',
    materialId: 'RM-CALCIUM-01',
    supplierId: 'SUP-03',
    supplierLotRef: 'CMF-CAL-4401',
    quantityKg: 40000,
    arrivalDate: '2026-09-19',
    expiryDate: '2029-09-19',
    warehouseLocation: 'RAW-ZONE-C04',
    status: 'RELEASED',
    qcCertificateNo: 'QC-CERT-CMF-4401',
    unitCost: 0.42
  },
  {
    lotNumber: 'RM-ADD-20260922-00088',
    materialId: 'RM-ADDITIVE-DISP',
    supplierId: 'SUP-05',
    supplierLotRef: 'ADDT-DISP-302',
    quantityKg: 1500,
    arrivalDate: '2026-09-22',
    expiryDate: '2027-09-22',
    warehouseLocation: 'RAW-ZONE-D01',
    status: 'RELEASED',
    qcCertificateNo: 'QC-CERT-ADDT-302',
    unitCost: 6.80
  }
];

export const INITIAL_FORMULATIONS: Formulation[] = [
  {
    id: 'FORM-PIM-01',
    formulaCode: 'TV-EMULSION-WHITE-MATT',
    name: 'Premium Interior Matt Emulsion',
    productFamily: 'Architectural Decorative Coatings',
    currentVersion: 'v14.3',
    ipProtected: true,
    revisions: [
      {
        versionId: 'v12.0',
        revisionDate: '2025-01-15',
        author: 'Dr. Alistair Vance, Lead Formulation Chemist',
        reasonForChange: 'Legacy baseline formula with 25g/L VOC solvent levels',
        isApproved: false,
        targetBatchSizeKg: 8000,
        vocGramsPerLitre: 24.5,
        targetViscosityKu: 102,
        targetGlossPct: 3.5,
        targetDensityGPerMl: 1.40,
        estimatedCostPerLitre: 1.82,
        ingredients: [
          { materialId: 'RM-ACRYLIC-01', percentage: 30.0, targetKg: 2400, costPerBatch: 6840 },
          { materialId: 'RM-TIO2-01', percentage: 18.0, targetKg: 1440, costPerBatch: 4896 },
          { materialId: 'RM-CALCIUM-01', percentage: 29.0, targetKg: 2320, costPerBatch: 974.4 },
          { materialId: 'RM-WATER-01', percentage: 18.5, targetKg: 1480, costPerBatch: 74 },
          { materialId: 'RM-ADDITIVE-DISP', percentage: 2.5, targetKg: 200, costPerBatch: 1360 },
          { materialId: 'RM-ADDITIVE-RHEO', percentage: 2.0, targetKg: 160, costPerBatch: 1840 }
        ]
      },
      {
        versionId: 'v14.3',
        revisionDate: '2026-05-10',
        author: 'Dr. Alistair Vance & Dr. E. Sterling',
        reasonForChange: 'Ultra-low VOC formulation update with optimized TiO2 dispersion and improved scrub resistance',
        isApproved: true,
        targetBatchSizeKg: 8000,
        vocGramsPerLitre: 8.2,
        targetViscosityKu: 106,
        targetGlossPct: 3.0,
        targetDensityGPerMl: 1.42,
        estimatedCostPerLitre: 2.01,
        ingredients: [
          { materialId: 'RM-ACRYLIC-01', percentage: 31.2, targetKg: 2496, costPerBatch: 7113.6 },
          { materialId: 'RM-TIO2-01', percentage: 17.5, targetKg: 1400, costPerBatch: 4760.0 },
          { materialId: 'RM-CALCIUM-01', percentage: 28.0, targetKg: 2240, costPerBatch: 940.8 },
          { materialId: 'RM-WATER-01', percentage: 19.0, targetKg: 1520, costPerBatch: 76.0 },
          { materialId: 'RM-ADDITIVE-DISP', percentage: 2.3, targetKg: 184, costPerBatch: 1251.2 },
          { materialId: 'RM-ADDITIVE-RHEO', percentage: 2.0, targetKg: 160, costPerBatch: 1840.0 }
        ]
      }
    ]
  }
];

export const INITIAL_COLOURS: Colour[] = [
  {
    id: 'COL-BRISTOL-STONE',
    colourCode: 'TV-COL-421',
    name: 'Bristol Stone',
    family: 'STONE',
    hex: '#C8BFB0',
    rgb: { r: 200, g: 191, b: 176 },
    lab: { L: 77.2, a: 1.4, b: 8.2 },
    basePaintFormulaId: 'FORM-PIM-01',
    tintRecipe: {
      baseVolume: '1000ml',
      doses: [
        { pigmentId: 'RM-TIO2-01', doseMl: 14.2 },
        { pigmentId: 'PIGMENT-OCHRE', doseMl: 4.8 },
        { pigmentId: 'PIGMENT-BLACK', doseMl: 0.6 }
      ]
    }
  },
  {
    id: 'COL-BRISTOL-BLUE',
    colourCode: 'TV-COL-422',
    name: 'Bristol Blue',
    family: 'BLUE',
    hex: '#315A78',
    rgb: { r: 49, g: 90, b: 120 },
    lab: { L: 38.4, a: -6.2, b: -21.4 },
    basePaintFormulaId: 'FORM-PIM-01',
    tintRecipe: {
      baseVolume: '1000ml',
      doses: [
        { pigmentId: 'PIGMENT-BLUE-PHTHALO', doseMl: 28.5 },
        { pigmentId: 'RM-TIO2-01', doseMl: 8.0 }
      ]
    }
  },
  {
    id: 'COL-SOMERSET-CLAY',
    colourCode: 'TV-COL-423',
    name: 'Somerset Clay',
    family: 'EARTH',
    hex: '#B58A3C',
    rgb: { r: 181, g: 138, b: 60 },
    lab: { L: 59.8, a: 11.2, b: 42.1 },
    basePaintFormulaId: 'FORM-PIM-01',
    tintRecipe: {
      baseVolume: '1000ml',
      doses: [
        { pigmentId: 'PIGMENT-OCHRE', doseMl: 32.0 },
        { pigmentId: 'PIGMENT-RED-OXIDE', doseMl: 5.2 }
      ]
    }
  },
  {
    id: 'COL-HIGHLAND-MIST',
    colourCode: 'TV-COL-424',
    name: 'Highland Mist',
    family: 'OFF-WHITE',
    hex: '#ECE9E1',
    rgb: { r: 236, g: 233, b: 225 },
    lab: { L: 92.4, a: -0.2, b: 4.1 },
    basePaintFormulaId: 'FORM-PIM-01',
    tintRecipe: {
      baseVolume: '1000ml',
      doses: [
        { pigmentId: 'RM-TIO2-01', doseMl: 22.0 },
        { pigmentId: 'PIGMENT-OCHRE', doseMl: 1.2 }
      ]
    }
  }
];

export const INITIAL_TANKS: FactoryTank[] = [
  {
    id: 'T-14',
    name: 'T-14 Dispersion & Mixing Vessel',
    type: 'High-Speed Disperser',
    capacityL: 10000,
    currentLevelL: 5600,
    currentBatchNumber: 'BATCH-26-09184',
    temperatureC: 24.2,
    rpm: 1250,
    status: 'Active',
    utilizationPct: 88.0
  },
  {
    id: 'T-01',
    name: 'T-01 Binder Storage Silo (Acrylic)',
    type: 'Storage',
    capacityL: 50000,
    currentLevelL: 36800,
    temperatureC: 18.5,
    rpm: 0,
    status: 'Active',
    utilizationPct: 73.6
  },
  {
    id: 'T-08',
    name: 'T-08 Horizontal Media Mill',
    type: 'Media Mill',
    capacityL: 3000,
    currentLevelL: 0,
    temperatureC: 20.0,
    rpm: 0,
    status: 'Idle',
    utilizationPct: 45.0
  },
  {
    id: 'T-12',
    name: 'T-12 Let-Down & Adjusting Tank',
    type: 'Let-Down Vessel',
    capacityL: 12000,
    currentLevelL: 8000,
    currentBatchNumber: 'BATCH-26-09185',
    temperatureC: 22.1,
    rpm: 420,
    status: 'Active',
    utilizationPct: 92.0
  },
  {
    id: 'T-16',
    name: 'T-16 High-Speed Automated Filling Line',
    type: 'Filling Line',
    capacityL: 5000,
    currentLevelL: 1200,
    currentBatchNumber: 'BATCH-26-09184',
    temperatureC: 21.0,
    rpm: 0,
    status: 'Active',
    utilizationPct: 95.0
  }
];

export const INITIAL_BATCHES: BatchRecord[] = [
  {
    batchNumber: 'BATCH-26-09184',
    productName: 'Premium Interior Matt Emulsion',
    formulaId: 'FORM-PIM-01',
    formulaVersion: 'v14.3',
    colourId: 'COL-BRISTOL-STONE',
    colourName: 'Bristol Stone',
    targetKg: 8000,
    actualKg: 7964,
    tankId: 'T-14',
    operator: 'Chief Plant Op. Marcus Thorne',
    status: 'QC_RELEASED',
    startTime: '2026-09-25T07:30:00Z',
    completionTime: '2026-09-25T14:15:00Z',
    yieldPct: 99.55,
    costPerLitre: 2.01,
    consumedLots: [
      { lotNumber: 'RM-TIO2-20260921-00482', materialId: 'RM-TIO2-01', actualKgUsed: 1400 },
      { lotNumber: 'RM-ACR-20260920-00192', materialId: 'RM-ACRYLIC-01', actualKgUsed: 2496 },
      { lotNumber: 'RM-CAL-20260919-00331', materialId: 'RM-CALCIUM-01', actualKgUsed: 2240 },
      { lotNumber: 'RM-ADD-20260922-00088', materialId: 'RM-ADDITIVE-DISP', actualKgUsed: 184 }
    ],
    qualityTests: [
      { id: 'QT-01', testName: 'Viscosity (KU @ 25°C)', specification: '100 - 110 KU', targetValue: '106 KU', measuredValue: '106.2 KU', unit: 'KU', passed: true, operator: 'Dr. S. Finch', timestamp: '2026-09-25 13:10' },
      { id: 'QT-02', testName: 'Density / Specific Gravity', specification: '1.40 - 1.44 g/ml', targetValue: '1.42 g/ml', measuredValue: '1.418 g/ml', unit: 'g/ml', passed: true, operator: 'Dr. S. Finch', timestamp: '2026-09-25 13:15' },
      { id: 'QT-03', testName: 'Colour Shade ΔE vs Standard', specification: 'ΔE < 1.00', targetValue: '0.00', measuredValue: '0.82', unit: 'ΔE', passed: true, operator: 'Dr. S. Finch', timestamp: '2026-09-25 13:25' },
      { id: 'QT-04', testName: 'Specular Gloss (60° Angle)', specification: '2.5% - 3.5%', targetValue: '3.0%', measuredValue: '3.1%', unit: '%', passed: true, operator: 'Dr. S. Finch', timestamp: '2026-09-25 13:30' },
      { id: 'QT-05', testName: 'Non-Volatile Solids Content', specification: '56.0% - 60.0%', targetValue: '58.0%', measuredValue: '58.2%', unit: '%', passed: true, operator: 'Dr. S. Finch', timestamp: '2026-09-25 13:40' }
    ]
  },
  {
    batchNumber: 'BATCH-26-09185',
    productName: 'Premium Interior Matt Emulsion',
    formulaId: 'FORM-PIM-01',
    formulaVersion: 'v14.3',
    colourId: 'COL-BRISTOL-BLUE',
    colourName: 'Bristol Blue',
    targetKg: 6000,
    actualKg: 5980,
    tankId: 'T-12',
    operator: 'Plant Op. David Ross',
    status: 'LET-DOWN',
    startTime: '2026-09-26T02:00:00Z',
    yieldPct: 99.66,
    costPerLitre: 2.14,
    consumedLots: [
      { lotNumber: 'RM-TIO2-20260921-00482', materialId: 'RM-TIO2-01', actualKgUsed: 1050 },
      { lotNumber: 'RM-ACR-20260920-00192', materialId: 'RM-ACRYLIC-01', actualKgUsed: 1872 }
    ],
    qualityTests: []
  }
];

export const INITIAL_SKUS: PackagedSKU[] = [
  {
    id: 'SKU-001',
    skuCode: 'SKU-PIM-BS-5L',
    productName: 'Premium Interior Matt Emulsion',
    colourName: 'Bristol Stone',
    colourHex: '#C8BFB0',
    packSize: '5L',
    litresPerUnit: 5,
    batchNumber: 'BATCH-26-09184',
    unitsProduced: 1120,
    unitsInWarehouse: 840,
    unitsReserved: 280,
    tradePrice: 28.50,
    retailPrice: 42.00,
    barcode: '5060918400512',
    palletIds: ['PAL-8842', 'PAL-8843']
  },
  {
    id: 'SKU-002',
    skuCode: 'SKU-PIM-BS-10L',
    productName: 'Premium Interior Matt Emulsion',
    colourName: 'Bristol Stone',
    colourHex: '#C8BFB0',
    packSize: '10L',
    litresPerUnit: 10,
    batchNumber: 'BATCH-26-09184',
    unitsProduced: 240,
    unitsInWarehouse: 180,
    unitsReserved: 60,
    tradePrice: 52.00,
    retailPrice: 78.00,
    barcode: '5060918401014',
    palletIds: ['PAL-8844']
  }
];

export const INITIAL_PALLETS: Pallet[] = [
  {
    id: 'PAL-8842',
    skuCode: 'SKU-PIM-BS-5L',
    batchNumber: 'BATCH-26-09184',
    quantityUnits: 560,
    locationCode: 'A-04-R02-S3',
    status: 'IN_STOCK'
  },
  {
    id: 'PAL-8843',
    skuCode: 'SKU-PIM-BS-5L',
    batchNumber: 'BATCH-26-09184',
    quantityUnits: 280,
    locationCode: 'A-04-R02-S4',
    status: 'RESERVED',
    destination: 'Crown & Trades Merchant Bristol'
  }
];

export const INITIAL_LOGISTICS: LogisticsShipment[] = [
  {
    id: 'SHP-2026-9921',
    vehicleReg: 'VX74 PNT',
    driverName: 'Robert Vance',
    origin: 'Bristol Paints Main Factory',
    destination: 'Crown & Trades Merchant Depot (Bristol)',
    destinationType: 'MERCHANT',
    palletIds: ['PAL-8843'],
    status: 'IN_TRANSIT',
    eta: '2026-09-26T11:30:00Z',
    temperatureC: 18.2,
    gpsCoordinates: { lat: 51.4545, lng: -2.5879 }
  }
];

export const INITIAL_MERCHANTS: TradeMerchant[] = [
  {
    id: 'MERCH-01',
    name: 'Crown & Trades Merchant Bristol',
    city: 'Bristol',
    stockCount: 1420,
    creditLimit: 50000,
    outstandingBalance: 12400,
    rating: 4.9
  },
  {
    id: 'MERCH-02',
    name: 'London Decorator Supplies Ltd',
    city: 'London',
    stockCount: 3800,
    creditLimit: 120000,
    outstandingBalance: 42100,
    rating: 4.8
  }
];

export const INITIAL_ORDERS: SalesOrder[] = [
  {
    id: 'ORD-90214',
    merchantId: 'MERCH-01',
    merchantName: 'Crown & Trades Merchant Bristol',
    customerOrPainterName: 'G. H. Decorators Ltd.',
    jobId: 'JOB-004182',
    items: [
      {
        skuCode: 'SKU-PIM-BS-5L',
        productName: 'Premium Interior Matt Emulsion',
        colourName: 'Bristol Stone',
        packSize: '5L',
        quantity: 3,
        unitPrice: 28.50,
        batchAllocated: 'BATCH-26-09184'
      }
    ],
    totalAmount: 85.50,
    status: 'DELIVERED',
    placedAt: '2026-09-25T16:00:00Z'
  }
];

export const INITIAL_PAINTER_JOBS: PainterJob[] = [
  {
    id: 'JOB-004182',
    painterName: 'G. H. Decorators Ltd.',
    clientName: 'Lady Eleanor Vance',
    propertyAddress: '14 Georgian Crescent, Bath BA1 2LR',
    city: 'Bath',
    status: 'IN_PROGRESS',
    createdDate: '2026-09-24',
    totalLitresEstimated: 15,
    rooms: [
      {
        roomId: 'RM-HALL-01',
        roomName: 'Main Reception Hall & Stairwell',
        lengthM: 6.5,
        widthM: 4.2,
        heightM: 3.2,
        doors: 4,
        windows: 2,
        coats: 2,
        substrate: 'Freshly Skimmed Gypsum Plaster with Primer',
        wallAreaM2: 52.4,
        ceilingAreaM2: 27.3,
        estimatedLitresRequired: 15.0,
        productName: 'Premium Interior Matt Emulsion',
        colourName: 'Bristol Stone',
        colourHex: '#C8BFB0',
        allocatedBatchNumber: 'BATCH-26-09184',
        appliedDate: '2026-09-26',
        applicationNotes: 'Applied via short-pile microfibre roller. Excellent wet coverage and smooth matte leveling.',
        photosUploaded: 3
      }
    ]
  }
];

export const INITIAL_EVENT_LOGS: EventLog[] = [
  {
    id: 'EVT-1001',
    timestamp: '2026-09-21 09:14:00',
    eventType: 'RAW_MATERIAL_RECEIVED',
    actor: 'Logistics Supervisor J. Cole',
    description: 'Received 25,000 kg Titanium Dioxide Rutile Lot RM-TIO2-20260921-00482 from Titanium Pigments UK PLC',
    severity: 'INFO'
  },
  {
    id: 'EVT-1002',
    timestamp: '2026-09-21 14:20:00',
    eventType: 'RAW_MATERIAL_RELEASED',
    actor: 'QC Chemist Dr. S. Finch',
    description: 'QC Released Lot RM-TIO2-20260921-00482 after purity & moisture test validation',
    severity: 'SUCCESS'
  },
  {
    id: 'EVT-1003',
    timestamp: '2026-09-25 07:30:00',
    eventType: 'BATCH_STARTED',
    actor: 'Plant Op. Marcus Thorne',
    description: 'Initiated production batch BATCH-26-09184 in Dispersion Tank T-14 using Formula TV-EMULSION-WHITE-MATT v14.3',
    batchNumber: 'BATCH-26-09184',
    severity: 'INFO'
  },
  {
    id: 'EVT-1004',
    timestamp: '2026-09-25 13:45:00',
    eventType: 'QC_PASSED',
    actor: 'Dr. S. Finch',
    description: 'Batch BATCH-26-09184 passed all 5 QC specification tests (Viscosity 106.2 KU, ΔE 0.82)',
    batchNumber: 'BATCH-26-09184',
    severity: 'SUCCESS'
  },
  {
    id: 'EVT-1005',
    timestamp: '2026-09-25 15:30:00',
    eventType: 'PAINT_PACKAGED',
    actor: 'Automated Line 16',
    description: 'Completed filling 1,120 x 5L tins for BATCH-26-09184 into Pallets PAL-8842 & PAL-8843',
    batchNumber: 'BATCH-26-09184',
    severity: 'SUCCESS'
  },
  {
    id: 'EVT-1006',
    timestamp: '2026-09-26 08:10:00',
    eventType: 'PAINTER_APPLIED',
    actor: 'Painter G. H. Decorators Ltd.',
    description: 'Applied 5L tin from BATCH-26-09184 to Reception Hall surface at 14 Georgian Crescent, Bath',
    batchNumber: 'BATCH-26-09184',
    severity: 'SUCCESS'
  }
];
