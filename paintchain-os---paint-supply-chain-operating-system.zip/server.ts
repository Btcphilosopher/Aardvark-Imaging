import express from 'express';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import {
  INITIAL_SUPPLIERS,
  INITIAL_MATERIALS,
  INITIAL_MATERIAL_LOTS,
  INITIAL_FORMULATIONS,
  INITIAL_COLOURS,
  INITIAL_TANKS,
  INITIAL_BATCHES,
  INITIAL_SKUS,
  INITIAL_PALLETS,
  INITIAL_ORDERS,
  INITIAL_PAINTER_JOBS
} from './src/data/syntheticDatabase.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;

app.use(express.json());

// API v1 Routes
app.get('/api/v1/materials', (req, res) => {
  res.json({ status: 'success', data: INITIAL_MATERIALS });
});

app.get('/api/v1/suppliers', (req, res) => {
  res.json({ status: 'success', data: INITIAL_SUPPLIERS });
});

app.get('/api/v1/material-lots', (req, res) => {
  res.json({ status: 'success', data: INITIAL_MATERIAL_LOTS });
});

app.get('/api/v1/formulas', (req, res) => {
  res.json({ status: 'success', data: INITIAL_FORMULATIONS });
});

app.get('/api/v1/formulas/:id', (req, res) => {
  const formula = INITIAL_FORMULATIONS.find(f => f.id === req.params.id);
  if (!formula) return res.status(404).json({ error: 'Formula not found' });
  res.json({ status: 'success', data: formula });
});

app.get('/api/v1/batches', (req, res) => {
  res.json({ status: 'success', data: INITIAL_BATCHES });
});

app.get('/api/v1/batches/:id', (req, res) => {
  const batch = INITIAL_BATCHES.find(b => b.batchNumber === req.params.id);
  if (!batch) return res.status(404).json({ error: 'Batch not found' });
  res.json({ status: 'success', data: batch });
});

app.get('/api/v1/products', (req, res) => {
  res.json({ status: 'success', data: INITIAL_SKUS });
});

app.get('/api/v1/colours', (req, res) => {
  res.json({ status: 'success', data: INITIAL_COLOURS });
});

app.get('/api/v1/inventory', (req, res) => {
  res.json({ status: 'success', data: INITIAL_PALLETS });
});

app.get('/api/v1/orders', (req, res) => {
  res.json({ status: 'success', data: INITIAL_ORDERS });
});

app.get('/api/v1/jobs', (req, res) => {
  res.json({ status: 'success', data: INITIAL_PAINTER_JOBS });
});

app.get('/api/v1/trace/:batchId', (req, res) => {
  const batchId = req.params.batchId;
  const batch = INITIAL_BATCHES.find(b => b.batchNumber === batchId) || INITIAL_BATCHES[0];
  const formula = INITIAL_FORMULATIONS.find(f => f.id === batch.formulaId);
  const colour = INITIAL_COLOURS.find(c => c.id === batch.colourId);

  res.json({
    status: 'success',
    data: {
      batchId: batch.batchNumber,
      product: batch.productName,
      colour: batch.colourName,
      formula: formula?.formulaCode,
      version: batch.formulaVersion,
      rawMaterialLots: batch.consumedLots,
      qualityTests: batch.qualityTests,
      status: batch.status,
      yieldKg: batch.actualKg,
      downstreamSKUs: INITIAL_SKUS.filter(s => s.batchNumber === batch.batchNumber),
      downstreamOrders: INITIAL_ORDERS.filter(o => o.items.some(i => i.batchAllocated === batch.batchNumber)),
      downstreamPainterJobs: INITIAL_PAINTER_JOBS.filter(j => j.rooms.some(r => r.allocatedBatchNumber === batch.batchNumber))
    }
  });
});

app.get('/api/v1/analytics', (req, res) => {
  res.json({
    status: 'success',
    data: {
      totalBatches: INITIAL_BATCHES.length,
      qcPassRatePct: 99.2,
      rawMaterialInventoryValueGbp: 482500,
      activeTanksCount: INITIAL_TANKS.filter(t => t.status === 'Active').length,
      totalTanksCount: INITIAL_TANKS.length,
      averageCostPerLitre: 2.01,
      tradeMerchantDemandPct: 114.5
    }
  });
});

// Vite Middleware for frontend development
async function startServer() {
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: 'spa'
  });

  app.use(vite.middlewares);

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`PAINTCHAIN OS server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
