"""
VIDEO ENGINE
Ultra-high-resolution video project model: presets (8K/12K/16K), standard
frame rates, frame stepping, cropping/scaling/transcoding at the project
level. Actual video *codec* I/O is intentionally out of scope here (per the
engineering brief: "do not implement proprietary codecs from scratch") --
this module models frames/timing/transform pipeline and defers muxing to a
replaceable export backend (see export.py).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, List, Optional

import numpy as np

from .image import Image16K, RESOLUTION_PRESETS
from .resolution import ResolutionEngine, Interpolation

VIDEO_RESOLUTION_PRESETS = {
    "8K": RESOLUTION_PRESETS["8K"],
    "12K": RESOLUTION_PRESETS["12K"],
    "16K": RESOLUTION_PRESETS["16K"],
}

STANDARD_FRAME_RATES = (24, 25, 30, 50, 60, 120)


@dataclass
class VideoFrame:
    index: int
    timestamp: float          # seconds
    image: Image16K

    @property
    def width(self) -> int:
        return self.image.width

    @property
    def height(self) -> int:
        return self.image.height


class VideoProject:
    """A sequence of VideoFrame objects at a fixed resolution/fps, with
    frame-stepping, cropping, scaling and (stub) transcoding support."""

    def __init__(self, width: int, height: int, fps: float, name: str = "untitled"):
        if fps not in STANDARD_FRAME_RATES:
            raise ValueError(f"fps must be one of {STANDARD_FRAME_RATES}, got {fps}")
        self.width = width
        self.height = height
        self.fps = fps
        self.name = name
        self.frames: List[VideoFrame] = []
        self._resolution_engine = ResolutionEngine()

    @classmethod
    def from_preset(cls, preset: str, fps: float, name: str = "untitled") -> "VideoProject":
        if preset not in VIDEO_RESOLUTION_PRESETS:
            raise KeyError(f"Unknown video preset: {preset}")
        w, h = VIDEO_RESOLUTION_PRESETS[preset]
        return cls(w, h, fps, name)

    @property
    def frame_count(self) -> int:
        return len(self.frames)

    @property
    def duration_seconds(self) -> float:
        return self.frame_count / self.fps if self.fps else 0.0

    def add_frame(self, image: Image16K) -> VideoFrame:
        if (image.width, image.height) != (self.width, self.height):
            raise ValueError(
                f"frame size {image.width}x{image.height} does not match project "
                f"{self.width}x{self.height}"
            )
        idx = len(self.frames)
        vf = VideoFrame(index=idx, timestamp=idx / self.fps, image=image)
        self.frames.append(vf)
        return vf

    def get_frame(self, index: int) -> VideoFrame:
        return self.frames[index]

    def step(self, index: int, delta: int = 1) -> Optional[VideoFrame]:
        """Frame stepping: return the frame `delta` steps away from `index`, or
        None if out of range."""
        target = index + delta
        if 0 <= target < len(self.frames):
            return self.frames[target]
        return None

    def frame_at_time(self, seconds: float) -> Optional[VideoFrame]:
        idx = int(round(seconds * self.fps))
        if 0 <= idx < len(self.frames):
            return self.frames[idx]
        return None

    # -- transforms across the whole project ---------------------------------
    def crop(self, x: int, y: int, width: int, height: int) -> "VideoProject":
        out = VideoProject(width, height, self.fps, self.name + "_cropped")
        for vf in self.frames:
            cropped = self._resolution_engine.crop(vf.image, x, y, width, height)
            out.add_frame(cropped)
        return out

    def scale(self, factor: float, method: Interpolation = Interpolation.LANCZOS) -> "VideoProject":
        if not self.frames:
            raise ValueError("cannot scale an empty project")
        w = max(1, round(self.width * factor))
        h = max(1, round(self.height * factor))
        out = VideoProject(w, h, self.fps, self.name + "_scaled")
        for vf in self.frames:
            out.add_frame(self._resolution_engine.scale(vf.image, factor, method))
        return out

    def apply(self, fn: Callable[[Image16K], Image16K]) -> "VideoProject":
        """Apply an arbitrary per-frame operation, returning a new project."""
        out = VideoProject(self.width, self.height, self.fps, self.name)
        for vf in self.frames:
            out.add_frame(fn(vf.image))
        return out

    def transcode_plan(self, target_preset: str, target_fps: float, codec: str = "prores") -> dict:
        """Return a transcode plan (resolution + fps + codec target) without
        performing actual codec-specific encoding, which is delegated to a
        replaceable backend in export.py."""
        if target_preset not in VIDEO_RESOLUTION_PRESETS and target_preset not in RESOLUTION_PRESETS:
            raise KeyError(f"Unknown target preset: {target_preset}")
        tw, th = RESOLUTION_PRESETS.get(target_preset, VIDEO_RESOLUTION_PRESETS.get(target_preset))
        return {
            "source": {"width": self.width, "height": self.height, "fps": self.fps,
                       "frames": self.frame_count},
            "target": {"width": tw, "height": th, "fps": target_fps, "codec": codec},
            "requires_scaling": (tw, th) != (self.width, self.height),
            "requires_retiming": target_fps != self.fps,
        }

    def describe(self) -> dict:
        return {
            "name": self.name, "width": self.width, "height": self.height,
            "fps": self.fps, "frame_count": self.frame_count,
            "duration_seconds": round(self.duration_seconds, 4),
        }
