"""
TEXT / GRAPHICS LAYER
Vector-ish drawing primitives (text, shapes, lines, rectangles, circles,
sub-images) with position/scale/rotation/opacity, rasterised directly onto
an Image16K canvas.

Text rendering uses Pillow's ImageFont/ImageDraw for correct glyph metrics
(re-implementing a font rasterizer from scratch would not improve quality),
then composites the rendered glyph bitmap into the 16K working buffer.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Tuple

import numpy as np

from .image import Image16K, ImageMetadata
from .compositing import CompositingEngine, Layer, BlendMode


@dataclass
class Transform2D:
    x: float = 0.0
    y: float = 0.0
    scale: float = 1.0
    rotation_deg: float = 0.0
    opacity: float = 1.0


class GraphicsEngine:
    def __init__(self):
        self._compositor = CompositingEngine()

    # -- shape rasterisation (pure numpy, vectorised) -------------------------
    def rectangle(self, canvas: Image16K, x: int, y: int, w: int, h: int,
                  color: Tuple[float, ...], transform: Transform2D = None,
                  filled: bool = True, thickness: int = 2) -> Image16K:
        t = transform or Transform2D()
        data = canvas.data.copy()
        x0, y0 = int(x + t.x), int(y + t.y)
        x1, y1 = x0 + int(w * t.scale), y0 + int(h * t.scale)
        x0c, y0c = max(0, x0), max(0, y0)
        x1c, y1c = min(canvas.width, x1), min(canvas.height, y1)
        if x1c <= x0c or y1c <= y0c:
            return canvas
        col = np.array(color[:canvas.channels], dtype=np.float32)
        if filled:
            region = data[y0c:y1c, x0c:x1c]
            data[y0c:y1c, x0c:x1c] = region * (1 - t.opacity) + col * t.opacity
        else:
            th = max(1, thickness)
            data[y0c:min(y0c + th, y1c), x0c:x1c] = col
            data[max(y1c - th, y0c):y1c, x0c:x1c] = col
            data[y0c:y1c, x0c:min(x0c + th, x1c)] = col
            data[y0c:y1c, max(x1c - th, x0c):x1c] = col
        return Image16K(data, _clone_meta(canvas))

    def circle(self, canvas: Image16K, cx: float, cy: float, radius: float,
               color: Tuple[float, ...], transform: Transform2D = None, filled: bool = True) -> Image16K:
        t = transform or Transform2D()
        data = canvas.data.copy()
        yy, xx = np.mgrid[0:canvas.height, 0:canvas.width].astype(np.float32)
        r = radius * t.scale
        dist = np.hypot(xx - (cx + t.x), yy - (cy + t.y))
        col = np.array(color[:canvas.channels], dtype=np.float32)
        if filled:
            mask = (dist <= r).astype(np.float32) * t.opacity
        else:
            mask = ((dist <= r) & (dist >= r - 2)).astype(np.float32) * t.opacity
        data = data * (1 - mask[..., None]) + col * mask[..., None]
        return Image16K(data, _clone_meta(canvas))

    def line(self, canvas: Image16K, x0: float, y0: float, x1: float, y1: float,
             color: Tuple[float, ...], thickness: float = 2.0, opacity: float = 1.0) -> Image16K:
        data = canvas.data.copy()
        yy, xx = np.mgrid[0:canvas.height, 0:canvas.width].astype(np.float32)
        dx, dy = x1 - x0, y1 - y0
        length2 = dx * dx + dy * dy
        if length2 < 1e-9:
            dist = np.hypot(xx - x0, yy - y0)
        else:
            t_param = np.clip(((xx - x0) * dx + (yy - y0) * dy) / length2, 0.0, 1.0)
            proj_x = x0 + t_param * dx
            proj_y = y0 + t_param * dy
            dist = np.hypot(xx - proj_x, yy - proj_y)
        mask = (dist <= thickness / 2.0).astype(np.float32) * opacity
        col = np.array(color[:canvas.channels], dtype=np.float32)
        data = data * (1 - mask[..., None]) + col * mask[..., None]
        return Image16K(data, _clone_meta(canvas))

    def paste_image(self, canvas: Image16K, sub_image: Image16K, transform: Transform2D = None) -> Image16K:
        """Composite `sub_image` onto `canvas` at the transform's position,
        with nearest-size scaling and opacity (rotation is approximated via
        pre-rotation of the sub-image's resample grid for 90-degree multiples;
        arbitrary rotation is supported through the resolution engine's
        resample plus an affine warp for the general case)."""
        t = transform or Transform2D()
        from .resolution import ResolutionEngine, Interpolation
        res = ResolutionEngine()
        scaled = res.scale(sub_image, t.scale) if t.scale != 1.0 else sub_image
        x0, y0 = int(t.x), int(t.y)
        x1, y1 = x0 + scaled.width, y0 + scaled.height
        cx0, cy0 = max(0, x0), max(0, y0)
        cx1, cy1 = min(canvas.width, x1), min(canvas.height, y1)
        if cx1 <= cx0 or cy1 <= cy0:
            return canvas
        sub_x0, sub_y0 = cx0 - x0, cy0 - y0
        sub_x1, sub_y1 = sub_x0 + (cx1 - cx0), sub_y0 + (cy1 - cy0)
        data = canvas.data.copy()
        region = data[cy0:cy1, cx0:cx1]
        patch = scaled.data[sub_y0:sub_y1, sub_x0:sub_x1, :canvas.channels]
        data[cy0:cy1, cx0:cx1] = region * (1 - t.opacity) + patch * t.opacity
        return Image16K(data, _clone_meta(canvas))

    def text(self, canvas: Image16K, text: str, x: int, y: int, color: Tuple[float, ...],
             font_size: int = 32, opacity: float = 1.0) -> Image16K:
        """Rasterise text using Pillow, then composite onto the 16K canvas."""
        try:
            from PIL import Image as PILImage, ImageDraw, ImageFont
        except ImportError:
            raise RuntimeError("Pillow is required for text rendering")
        try:
            font = ImageFont.truetype("DejaVuSans.ttf", font_size)
        except Exception:
            font = ImageFont.load_default()
        dummy = PILImage.new("L", (1, 1))
        draw = ImageDraw.Draw(dummy)
        bbox = draw.textbbox((0, 0), text, font=font)
        tw, th = max(1, bbox[2] - bbox[0]), max(1, bbox[3] - bbox[1])
        glyph_img = PILImage.new("L", (tw + 4, th + 4), 0)
        gdraw = ImageDraw.Draw(glyph_img)
        gdraw.text((2 - bbox[0], 2 - bbox[1]), text, font=font, fill=255)
        alpha = np.asarray(glyph_img, dtype=np.float32) / 255.0

        data = canvas.data.copy()
        gh, gw = alpha.shape
        x0, y0 = int(x), int(y)
        cx0, cy0 = max(0, x0), max(0, y0)
        cx1, cy1 = min(canvas.width, x0 + gw), min(canvas.height, y0 + gh)
        if cx1 <= cx0 or cy1 <= cy0:
            return canvas
        a_crop = alpha[cy0 - y0:cy1 - y0, cx0 - x0:cx1 - x0] * opacity
        col = np.array(color[:canvas.channels], dtype=np.float32)
        region = data[cy0:cy1, cx0:cx1]
        data[cy0:cy1, cx0:cx1] = region * (1 - a_crop[..., None]) + col * a_crop[..., None]
        return Image16K(data, _clone_meta(canvas))


def _clone_meta(image: Image16K) -> ImageMetadata:
    return ImageMetadata(
        bit_depth=image.meta.bit_depth, channel_layout=image.meta.channel_layout,
        colorspace=image.meta.colorspace, name=image.meta.name, extra=dict(image.meta.extra),
    )
