"""
DIGITAL ZOOM / CROP / PAN / SCAN
Treats a 16K (or any) master image as a virtual camera source: extract a
smaller "virtual window" and pan/scan/zoom across the master, calculating
the resulting effective resolution at each step.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Tuple

from .image import Image16K, RESOLUTION_PRESETS
from .resolution import ResolutionEngine, Interpolation


@dataclass
class ZoomStep:
    crop_width: int
    crop_height: int
    zoom_factor: float
    effective_resolution: Tuple[int, int]


class DigitalZoomEngine:
    def __init__(self):
        self._res = ResolutionEngine()

    def digital_zoom(self, image: Image16K, factor: float,
                      output_width: int = None, output_height: int = None,
                      method: Interpolation = Interpolation.LANCZOS) -> Image16K:
        """Crop a centered window of size (W/factor, H/factor); optionally
        resize back up to (output_width, output_height) -- classic 'digital
        zoom' behaviour. With no output size given, the cropped window itself
        is returned (no resample)."""
        if factor < 1.0:
            raise ValueError("factor must be >= 1.0")
        crop_w = max(1, int(image.width // factor))
        crop_h = max(1, int(image.height // factor))
        x = (image.width - crop_w) // 2
        y = (image.height - crop_h) // 2
        cropped = self._res.crop(image, x, y, crop_w, crop_h)
        if output_width and output_height:
            return self._res.resize(cropped, output_width, output_height, method)
        return cropped

    def crop_window(self, image: Image16K, x: int, y: int, width: int, height: int) -> Image16K:
        return self._res.crop(image, x, y, width, height)

    def pan(self, image: Image16K, window_width: int, window_height: int,
            x: int, y: int) -> Image16K:
        """Extract a window at (x, y) -- used to move a virtual camera across
        a large master image without changing zoom level."""
        x = max(0, min(x, image.width - window_width))
        y = max(0, min(y, image.height - window_height))
        return self._res.crop(image, x, y, window_width, window_height)

    def crop_ladder(self, image: Image16K, presets: List[str]) -> List[ZoomStep]:
        """Compute the sequence of crops needed to step from the master
        resolution down through a ladder of named resolution presets (e.g.
        16K -> "4K" -> "1080p" -> "720p"), reporting the zoom factor and
        effective resolution retained at each step."""
        steps = []
        src_w = image.width
        for preset in presets:
            if preset not in RESOLUTION_PRESETS:
                raise KeyError(f"Unknown resolution preset: {preset}")
            tw, th = RESOLUTION_PRESETS[preset]
            zoom = src_w / tw
            steps.append(ZoomStep(crop_width=tw, crop_height=th, zoom_factor=round(zoom, 6),
                                   effective_resolution=(tw, th)))
        return steps

    def effective_resolution_after_crop(self, source_w: int, source_h: int,
                                         crop_w: int, crop_h: int) -> dict:
        return {
            "source": (source_w, source_h),
            "crop": (crop_w, crop_h),
            "retained_fraction_pixels": round((crop_w * crop_h) / (source_w * source_h), 6),
            "linear_zoom_factor": round(source_w / crop_w, 4) if crop_w else float("inf"),
        }
