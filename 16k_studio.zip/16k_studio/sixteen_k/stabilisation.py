"""DIGITAL STABILISATION -- estimates per-frame translation/rotation and the
crop required to compensate, and provides a configurable stabilize() pass."""
from __future__ import annotations

from dataclasses import dataclass
from typing import List

import numpy as np

from .image import Image16K
from .motion import MotionEngine
from .resolution import ResolutionEngine


@dataclass
class FrameTransform:
    dx: float
    dy: float
    rotation_deg: float
    required_crop_px: float


class StabilisationEngine:
    def __init__(self):
        self._motion = MotionEngine()
        self._res = ResolutionEngine()

    def estimate_frame_movement(self, a: Image16K, b: Image16K, block_size: int = 16,
                                 search_radius: int = 4) -> FrameTransform:
        field = self._motion.estimate_motion(a, b, block_size=block_size, search_radius=search_radius)
        dx = float(field.vectors_x.mean())
        dy = float(field.vectors_y.mean())
        half = field.vectors_y.shape[1] // 2
        if half > 0 and field.vectors_y.shape[1] - half > 0:
            left_dy = field.vectors_y[:, :half].mean()
            right_dy = field.vectors_y[:, half:].mean()
            rotation_deg = float(np.degrees(np.arctan2(right_dy - left_dy, field.block_size * max(half, 1))))
        else:
            rotation_deg = 0.0
        required_crop = float(np.hypot(dx, dy))
        return FrameTransform(dx=dx, dy=dy, rotation_deg=rotation_deg, required_crop_px=required_crop)

    def estimate_sequence_movement(self, frames: List[Image16K], block_size: int = 16,
                                    search_radius: int = 4) -> List[FrameTransform]:
        return [self.estimate_frame_movement(frames[i], frames[i + 1], block_size, search_radius)
                for i in range(len(frames) - 1)]

    def stabilize(self, frames: List[Image16K], strength: float = 1.0, block_size: int = 16,
                  search_radius: int = 4, margin_fraction: float = 0.1) -> List[Image16K]:
        """Compensate accumulated translation drift by cropping a
        strength-scaled counter-offset window from each frame, then resizing
        back to the original dimensions -- so every output frame shares one
        consistent size regardless of correction magnitude."""
        if not frames:
            return []
        if not (0.0 <= strength <= 1.0):
            raise ValueError("strength must be within [0, 1]")
        w, h = frames[0].width, frames[0].height
        margin_x = max(1, int(w * margin_fraction))
        margin_y = max(1, int(h * margin_fraction))
        crop_w = max(1, w - 2 * margin_x)
        crop_h = max(1, h - 2 * margin_y)

        def centered_crop_resize(img: Image16K, offset_x: int = 0, offset_y: int = 0) -> Image16K:
            cx = margin_x + offset_x
            cy = margin_y + offset_y
            cx = max(0, min(cx, w - crop_w))
            cy = max(0, min(cy, h - crop_h))
            cropped = self._res.crop(img, cx, cy, crop_w, crop_h)
            return self._res.resize(cropped, w, h)

        out = [centered_crop_resize(frames[0])]
        if len(frames) == 1:
            return out
        movements = self.estimate_sequence_movement(frames, block_size, search_radius)
        cum_x, cum_y = 0.0, 0.0
        for i, mv in enumerate(movements, start=1):
            cum_x += mv.dx
            cum_y += mv.dy
            comp_x = int(np.clip(-cum_x * strength, -margin_x, margin_x))
            comp_y = int(np.clip(-cum_y * strength, -margin_y, margin_y))
            out.append(centered_crop_resize(frames[i], comp_x, comp_y))
        return out
