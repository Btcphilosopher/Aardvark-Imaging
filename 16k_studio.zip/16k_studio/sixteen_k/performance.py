"""
PERFORMANCE ENGINE
Benchmarks throughput (pixels/sec, frames/sec, memory bandwidth), tracks
processing latency, and generates human-readable performance reports.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Callable, List

import numpy as np

from .image import Image16K


@dataclass
class BenchmarkResult:
    name: str
    iterations: int
    total_seconds: float
    pixels_per_iteration: int

    @property
    def seconds_per_iteration(self) -> float:
        return self.total_seconds / self.iterations if self.iterations else 0.0

    @property
    def fps(self) -> float:
        return self.iterations / self.total_seconds if self.total_seconds > 0 else float("inf")

    @property
    def pixels_per_second(self) -> float:
        return self.pixels_per_iteration * self.fps

    @property
    def megapixels_per_second(self) -> float:
        return self.pixels_per_second / 1_000_000.0

    def as_dict(self) -> dict:
        return {
            "name": self.name, "iterations": self.iterations,
            "total_seconds": round(self.total_seconds, 6),
            "seconds_per_iteration": round(self.seconds_per_iteration, 6),
            "fps": round(self.fps, 3),
            "megapixels_per_second": round(self.megapixels_per_second, 3),
        }


class PerformanceEngine:
    def __init__(self):
        self.history: List[BenchmarkResult] = []

    def benchmark(self, name: str, fn: Callable[[], None], image: Image16K = None,
                  iterations: int = 5, warmup: int = 1) -> BenchmarkResult:
        for _ in range(warmup):
            fn()
        start = time.perf_counter()
        for _ in range(iterations):
            fn()
        elapsed = time.perf_counter() - start
        pixels = image.pixel_count if image is not None else 0
        result = BenchmarkResult(name=name, iterations=iterations, total_seconds=elapsed,
                                  pixels_per_iteration=pixels)
        self.history.append(result)
        return result

    def memory_throughput_gbps(self, bytes_moved: int, seconds: float) -> float:
        if seconds <= 0:
            return float("inf")
        return (bytes_moved / seconds) / (1024 ** 3)

    def cpu_utilization_estimate(self) -> float:
        """Best-effort CPU utilization snapshot; falls back gracefully when
        `psutil` isn't available in the runtime environment."""
        try:
            import psutil
            return psutil.cpu_percent(interval=0.05)
        except Exception:
            return -1.0

    def report(self) -> dict:
        return {
            "benchmarks": [b.as_dict() for b in self.history],
            "cpu_utilization_percent": self.cpu_utilization_estimate(),
        }
