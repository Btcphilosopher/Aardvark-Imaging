"""
HDR ENGINE
Represents scene-referred vs display-referred luminance separately, and
provides tone mapping / highlight & shadow recovery / HDR compositing.
"""
from __future__ import annotations

from dataclasses import dataclass
import enum

import numpy as np

from .image import Image16K, ImageMetadata

_LUMA_WEIGHTS = np.array([0.2126, 0.7152, 0.0722], dtype=np.float32)  # Rec.709


@dataclass
class DynamicRange:
    scene_min_nits: float
    scene_max_nits: float
    display_min_nits: float = 0.05
    display_max_nits: float = 100.0

    @property
    def scene_stops(self) -> float:
        return float(np.log2(max(self.scene_max_nits, 1e-6) / max(self.scene_min_nits, 1e-6)))

    @property
    def display_stops(self) -> float:
        return float(np.log2(max(self.display_max_nits, 1e-6) / max(self.display_min_nits, 1e-6)))


class ToneMapOperator(enum.Enum):
    REINHARD = "reinhard"
    REINHARD_EXTENDED = "reinhard_extended"
    ACES_FILMIC = "aces_filmic"
    CLAMP = "clamp"


def _luma(data: np.ndarray) -> np.ndarray:
    c = min(3, data.shape[-1])
    return np.tensordot(data[..., :c], _LUMA_WEIGHTS[:c], axes=([2], [0]))


class HDREngine:
    def scene_luminance(self, image: Image16K, exposure_nits_at_1_0: float = 100.0) -> np.ndarray:
        """Map normalized linear pixel values to absolute scene luminance (nits),
        given the nit value that corresponds to a normalized pixel value of 1.0."""
        return _luma(image.data) * exposure_nits_at_1_0

    def display_luminance(self, image: Image16K, display_max_nits: float = 100.0) -> np.ndarray:
        return np.clip(_luma(image.data), 0.0, 1.0) * display_max_nits

    def dynamic_range(self, image: Image16K, exposure_nits_at_1_0: float = 100.0,
                       display_max_nits: float = 100.0) -> DynamicRange:
        luma = self.scene_luminance(image, exposure_nits_at_1_0)
        nonzero = luma[luma > 1e-6]
        scene_min = float(nonzero.min()) if nonzero.size else 1e-6
        scene_max = float(luma.max())
        return DynamicRange(scene_min_nits=scene_min, scene_max_nits=scene_max,
                             display_max_nits=display_max_nits)

    # -- tone mapping ---------------------------------------------------
    def tone_map(self, image: Image16K, operator: ToneMapOperator = ToneMapOperator.ACES_FILMIC,
                 exposure: float = 1.0, white_point: float = 4.0) -> Image16K:
        x = np.clip(image.data * exposure, 0.0, None)

        if operator is ToneMapOperator.CLAMP:
            mapped = np.clip(x, 0.0, 1.0)
        elif operator is ToneMapOperator.REINHARD:
            mapped = x / (1.0 + x)
        elif operator is ToneMapOperator.REINHARD_EXTENDED:
            mapped = (x * (1.0 + x / (white_point ** 2))) / (1.0 + x)
        elif operator is ToneMapOperator.ACES_FILMIC:
            a, b, c, d, e = 2.51, 0.03, 2.43, 0.59, 0.14
            mapped = np.clip((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0)
        else:
            raise ValueError(f"Unknown tone map operator: {operator}")

        mapped = np.clip(mapped, 0.0, 1.0).astype(np.float32)
        meta = ImageMetadata(
            bit_depth=image.meta.bit_depth, channel_layout=image.meta.channel_layout,
            colorspace=image.meta.colorspace, name=image.meta.name,
            extra={**image.meta.extra, "tone_mapped": operator.value},
        )
        return Image16K(mapped, meta)

    # -- recovery ---------------------------------------------------------
    def highlight_recovery(self, image: Image16K, threshold: float = 0.9,
                            strength: float = 0.5) -> Image16K:
        """Compress values above `threshold` back toward it, recovering detail
        that would otherwise clip, proportional to `strength`."""
        data = image.data.copy()
        over = data > threshold
        excess = data - threshold
        data[over] = threshold + excess[over] * (1.0 - strength)
        return _rewrap(image, np.clip(data, 0.0, None))

    def shadow_recovery(self, image: Image16K, threshold: float = 0.1,
                         strength: float = 0.5) -> Image16K:
        """Lift values below `threshold` to reveal shadow detail."""
        data = image.data.copy()
        under = data < threshold
        deficit = threshold - data
        data[under] = data[under] + deficit[under] * strength
        return _rewrap(image, np.clip(data, 0.0, None))

    # -- compositing ------------------------------------------------------
    def hdr_composite(self, base: Image16K, overlay: Image16K, alpha: np.ndarray) -> Image16K:
        """Linear-light compositing of two HDR (unclamped) images using a
        per-pixel alpha map, shape (H, W) or (H, W, 1), values in [0, 1]."""
        if base.data.shape != overlay.data.shape:
            raise ValueError("base and overlay must share shape for HDR compositing")
        a = alpha
        if a.ndim == 2:
            a = a[..., None]
        out = base.data * (1 - a) + overlay.data * a
        return _rewrap(base, out.astype(np.float32))

    def merge_exposures(self, images: list, ev_offsets: list) -> Image16K:
        """Simple exposure-fusion style HDR merge: bring each exposure back to a
        common scene-referred scale, then weight by how well-exposed each
        pixel is (down-weighting near-clipped and near-black samples)."""
        if len(images) != len(ev_offsets):
            raise ValueError("images and ev_offsets must be the same length")
        if not images:
            raise ValueError("need at least one image")
        acc = np.zeros_like(images[0].data, dtype=np.float64)
        wsum = np.zeros(images[0].data.shape[:2] + (1,), dtype=np.float64)
        for img, ev in zip(images, ev_offsets):
            linear = img.data.astype(np.float64) / (2.0 ** ev)
            luma = _luma(img.data.astype(np.float32))[..., None]
            weight = np.clip(1.0 - np.abs(luma - 0.5) * 2.0, 1e-3, 1.0) ** 2
            acc += linear * weight
            wsum += weight
        merged = (acc / np.clip(wsum, 1e-9, None)).astype(np.float32)
        return _rewrap(images[0], merged)


def _rewrap(reference: Image16K, data: np.ndarray) -> Image16K:
    meta = ImageMetadata(
        bit_depth=reference.meta.bit_depth, channel_layout=reference.meta.channel_layout,
        colorspace=reference.meta.colorspace, name=reference.meta.name,
        extra=dict(reference.meta.extra),
    )
    return Image16K(data, meta)
