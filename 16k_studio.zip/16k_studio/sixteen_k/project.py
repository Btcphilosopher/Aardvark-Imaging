"""
PROJECT ENGINE / AUTOMATION
Project16K is the top-level automation API tying every engine together:

    project = Project16K()
    project.import_image("master.tiff")
    project.resize(15360, 8640)
    project.exposure(0.4)
    project.sharpen(amount=0.2)
    project.export("output.tiff")

It also defines the PROJECT FILE format: a structured, JSON-serialisable
description of resolution, timeline, assets, layers, effects, colour
settings, camera settings and metadata (pixel data itself is referenced by
path, never embedded, so project files stay small even at 16K).
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional

from .image import Image16K, BitDepth, ChannelLayout, RESOLUTION_PRESETS
from .memory import MemoryEngine
from .resolution import ResolutionEngine, Interpolation
from .processing import ImageProcessingEngine
from .colour import ColourEngine
from .hdr import HDREngine
from .effects import EffectStack
from .export import ExportEngine
from .history import OperationHistory
from .camera import VirtualCamera
from .digital_twin import DigitalTwin


@dataclass
class ProjectFile:
    """Structured, JSON-serialisable project description."""
    name: str = "untitled_project"
    resolution: tuple = RESOLUTION_PRESETS["16K"]
    bit_depth: int = int(BitDepth.BD_16)
    channel_layout: str = ChannelLayout.RGB.label
    colour_settings: Dict[str, Any] = field(default_factory=lambda: {"colorspace": "sRGB"})
    camera_settings: Dict[str, Any] = field(default_factory=dict)
    assets: List[str] = field(default_factory=list)
    layers: List[Dict[str, Any]] = field(default_factory=list)
    effects: List[str] = field(default_factory=list)
    timeline: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2, default=str)

    @classmethod
    def from_json(cls, text: str) -> "ProjectFile":
        data = json.loads(text)
        data["resolution"] = tuple(data.get("resolution", RESOLUTION_PRESETS["16K"]))
        return cls(**data)

    def save(self, path: str) -> str:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w") as f:
            f.write(self.to_json())
        return path

    @classmethod
    def load(cls, path: str) -> "ProjectFile":
        with open(path) as f:
            return cls.from_json(f.read())


class Project16K:
    """High-level automation façade. Wraps the lower-level engines behind a
    fluent, scriptable API and maintains non-destructive edit history."""

    def __init__(self, name: str = "untitled_project", resolution=RESOLUTION_PRESETS["16K"],
                 bit_depth: BitDepth = BitDepth.BD_16, memory_budget_bytes: int = 4 * 1024 ** 3):
        self.file = ProjectFile(name=name, resolution=resolution, bit_depth=int(bit_depth))
        self.memory = MemoryEngine(memory_budget_bytes)
        self._res = ResolutionEngine()
        self._proc = ImageProcessingEngine()
        self._colour = ColourEngine()
        self._hdr = HDREngine()
        self._export = ExportEngine()
        self._twin = DigitalTwin()
        self.image: Optional[Image16K] = None
        self.history: Optional[OperationHistory] = None
        self._created_at = time.time()

    # -- asset I/O -----------------------------------------------------
    def import_image(self, path: str) -> "Project16K":
        self.image = self._export.import_still(path)
        self.history = OperationHistory(self.image)
        self.file.assets.append(path)
        return self

    def new_blank(self, width: int = None, height: int = None, fill: float = 0.0) -> "Project16K":
        w = width or self.file.resolution[0]
        h = height or self.file.resolution[1]
        self.image = Image16K.blank(w, h, fill=fill, bit_depth=BitDepth(self.file.bit_depth))
        self.history = OperationHistory(self.image)
        return self

    def set_image(self, image: Image16K) -> "Project16K":
        self.image = image
        self.history = OperationHistory(self.image)
        return self

    # -- memory awareness --------------------------------------------------
    def memory_report(self) -> dict:
        if self.image is None:
            raise RuntimeError("no image loaded")
        return self.memory.estimate_frame_memory(
            self.image.width, self.image.height, self.image.channels, self.image.meta.bit_depth
        ).as_dict()

    # -- fluent editing (all routed through history) --------------------------
    def _apply(self, label: str, op) -> "Project16K":
        if self.history is None:
            raise RuntimeError("no image loaded -- call import_image() or new_blank() first")
        self.image = self.history.push(label, op)
        return self

    def resize(self, width: int, height: int, method: Interpolation = Interpolation.LANCZOS) -> "Project16K":
        self.file.resolution = (width, height)
        return self._apply(f"resize({width}x{height})", lambda img: self._res.resize(img, width, height, method))

    def crop(self, x: int, y: int, width: int, height: int) -> "Project16K":
        return self._apply(f"crop({x},{y},{width},{height})", lambda img: self._res.crop(img, x, y, width, height))

    def exposure(self, stops: float) -> "Project16K":
        return self._apply(f"exposure({stops})", lambda img: self._proc.exposure(img, stops))

    def brightness(self, amount: float) -> "Project16K":
        return self._apply(f"brightness({amount})", lambda img: self._proc.brightness(img, amount))

    def contrast(self, amount: float) -> "Project16K":
        return self._apply(f"contrast({amount})", lambda img: self._proc.contrast(img, amount))

    def saturation(self, amount: float) -> "Project16K":
        return self._apply(f"saturation({amount})", lambda img: self._proc.saturation(img, amount))

    def sharpen(self, amount: float = 0.5, radius: float = 1.5) -> "Project16K":
        return self._apply(f"sharpen({amount})", lambda img: self._proc.sharpness(img, amount, radius))

    def blur(self, radius: float = 2.0) -> "Project16K":
        return self._apply(f"blur({radius})", lambda img: self._proc.blur(img, radius))

    def convert_colorspace(self, target: str) -> "Project16K":
        self.file.colour_settings["colorspace"] = target
        return self._apply(f"colorspace({target})", lambda img: self._colour.convert_colorspace(img, target))

    def effects(self, build_fn) -> "Project16K":
        """`build_fn(EffectStack) -> EffectStack` lets callers compose an
        arbitrary effects chain; the rendered result becomes a single history entry."""
        label = "effects_stack"
        self.file.effects.append(label)
        return self._apply(label, lambda img: build_fn(EffectStack(img)).render())

    # -- undo/redo passthrough ------------------------------------------------
    def undo(self) -> "Project16K":
        if self.history:
            self.image = self.history.undo()
        return self

    def redo(self) -> "Project16K":
        if self.history:
            self.image = self.history.redo()
        return self

    # -- export --------------------------------------------------------
    def export(self, path: str, fmt: Optional[str] = None, quality: int = 95) -> str:
        if self.image is None:
            raise RuntimeError("no image to export")
        return self._export.export_still(self.image, path, fmt, quality)

    # -- project file persistence --------------------------------------------
    def save_project(self, path: str) -> str:
        self.file.metadata["saved_at"] = time.time()
        if self.image is not None:
            self.file.metadata["current_image_stats"] = self.image.describe()
        return self.file.save(path)

    @classmethod
    def load_project(cls, path: str) -> "Project16K":
        pf = ProjectFile.load(path)
        proj = cls(name=pf.name, resolution=pf.resolution, bit_depth=BitDepth(pf.bit_depth))
        proj.file = pf
        return proj

    def describe(self) -> dict:
        return {
            "name": self.file.name,
            "resolution": self.file.resolution,
            "bit_depth": self.file.bit_depth,
            "history": self.history.timeline_position() if self.history else None,
            "asset_count": len(self.file.assets),
        }
