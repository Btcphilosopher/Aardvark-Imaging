"""
COMPRESSION CALCULATOR
Estimates uncompressed size, compressed size (via typical codec compression
ratios), and bitrate for a frame / second / minute / hour of footage at a
given resolution, bit depth, channel count and compression scheme.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict

from .image import BitDepth

#: approximate typical compression ratios (uncompressed:compressed) for
#: common professional & delivery codecs -- illustrative, not a substitute
#: for measuring real footage, and intentionally conservative.
TYPICAL_COMPRESSION_RATIOS: Dict[str, float] = {
    "uncompressed": 1.0,
    "lossless_png": 2.0,
    "prores_422": 6.5,
    "prores_422_hq": 4.5,
    "prores_4444": 3.5,
    "dnxhr_hq": 6.0,
    "h264_high": 50.0,
    "h265_hevc": 80.0,
    "av1": 100.0,
    "jpeg_q90": 12.0,
    "webp_lossy": 20.0,
}


@dataclass
class CompressionEstimate:
    codec: str
    uncompressed_bytes: int
    compressed_bytes: int
    ratio: float

    def as_dict(self) -> dict:
        return {
            "codec": self.codec,
            "uncompressed_bytes": self.uncompressed_bytes,
            "compressed_bytes": self.compressed_bytes,
            "compressed_mb": round(self.compressed_bytes / (1024 ** 2), 4),
            "ratio": self.ratio,
        }


class CompressionCalculator:
    def frame_bytes(self, width: int, height: int, channels: int, bit_depth: BitDepth) -> int:
        bd = BitDepth(bit_depth)
        return width * height * channels * bd.bytes_per_channel

    def estimate(self, width: int, height: int, channels: int, bit_depth: BitDepth,
                 codec: str = "h265_hevc") -> CompressionEstimate:
        if codec not in TYPICAL_COMPRESSION_RATIOS:
            raise KeyError(f"Unknown codec '{codec}'. Known: {list(TYPICAL_COMPRESSION_RATIOS)}")
        uncompressed = self.frame_bytes(width, height, channels, bit_depth)
        ratio = TYPICAL_COMPRESSION_RATIOS[codec]
        compressed = max(1, round(uncompressed / ratio))
        return CompressionEstimate(codec=codec, uncompressed_bytes=uncompressed,
                                    compressed_bytes=compressed, ratio=ratio)

    def bitrate_mbps(self, width: int, height: int, channels: int, bit_depth: BitDepth,
                     fps: float, codec: str = "h265_hevc") -> float:
        est = self.estimate(width, height, channels, bit_depth, codec)
        bits_per_second = est.compressed_bytes * 8 * fps
        return bits_per_second / 1_000_000.0

    def duration_report(self, width: int, height: int, channels: int, bit_depth: BitDepth,
                        fps: float, codec: str = "h265_hevc") -> dict:
        per_frame = self.estimate(width, height, channels, bit_depth, codec)
        per_second = per_frame.compressed_bytes * fps
        return {
            "codec": codec,
            "resolution": (width, height),
            "fps": fps,
            "bitrate_mbps": round(self.bitrate_mbps(width, height, channels, bit_depth, fps, codec), 3),
            "frame_bytes": per_frame.compressed_bytes,
            "second_bytes": round(per_second),
            "minute_bytes": round(per_second * 60),
            "hour_bytes": round(per_second * 3600),
            "minute_gb": round(per_second * 60 / (1024 ** 3), 3),
            "hour_gb": round(per_second * 3600 / (1024 ** 3), 3),
        }
