"""
COLOUR ENGINE
Professional colour management: gamut/transfer-function conversions between
sRGB, Display P3, Rec.709, Rec.2020 and linear RGB, plus white balance,
gamma, colour temperature and a LUT (3D lookup table) interface.

Matrices are standard CIE-XYZ (D65) primaries; transfer functions follow the
published sRGB / Rec.709 / Rec.2020 EOTF definitions.
"""
from __future__ import annotations

from typing import Callable, Dict

import numpy as np

from .image import Image16K, ImageMetadata

# ---------------------------------------------------------------------------
# RGB -> CIE XYZ (D65) matrices per colour space (linear-light primaries)
# ---------------------------------------------------------------------------
_RGB_TO_XYZ: Dict[str, np.ndarray] = {
    "sRGB": np.array([
        [0.4124564, 0.3575761, 0.1804375],
        [0.2126729, 0.7151522, 0.0721750],
        [0.0193339, 0.1191920, 0.9503041],
    ]),
    "Rec.709": np.array([  # same primaries as sRGB
        [0.4124564, 0.3575761, 0.1804375],
        [0.2126729, 0.7151522, 0.0721750],
        [0.0193339, 0.1191920, 0.9503041],
    ]),
    "Display P3": np.array([
        [0.4865709, 0.2656677, 0.1982173],
        [0.2289746, 0.6917385, 0.0792869],
        [0.0000000, 0.0451134, 1.0439444],
    ]),
    "Rec.2020": np.array([
        [0.6369580, 0.1446169, 0.1688810],
        [0.2627002, 0.6779981, 0.0593017],
        [0.0000000, 0.0280727, 1.0609851],
    ]),
}
_XYZ_TO_RGB: Dict[str, np.ndarray] = {k: np.linalg.inv(v) for k, v in _RGB_TO_XYZ.items()}


def _apply_matrix(data: np.ndarray, m: np.ndarray) -> np.ndarray:
    # data: (H, W, 3); m: (3,3) applied as XYZ = M @ rgb
    return np.einsum("ij,hwj->hwi", m, data).astype(np.float32)


# ---------------------------------------------------------------------------
# Transfer functions (EOTF / OETF pairs)
# ---------------------------------------------------------------------------
def srgb_eotf(v: np.ndarray) -> np.ndarray:
    """gamma-encoded sRGB -> linear."""
    v = np.clip(v, 0.0, None)
    return np.where(v <= 0.04045, v / 12.92, ((v + 0.055) / 1.055) ** 2.4).astype(np.float32)


def srgb_oetf(v: np.ndarray) -> np.ndarray:
    """linear -> gamma-encoded sRGB."""
    v = np.clip(v, 0.0, None)
    return np.where(v <= 0.0031308, v * 12.92, 1.055 * (v ** (1 / 2.4)) - 0.055).astype(np.float32)


def rec709_eotf(v: np.ndarray) -> np.ndarray:
    v = np.clip(v, 0.0, None)
    return np.where(v < 0.081, v / 4.5, ((v + 0.099) / 1.099) ** (1 / 0.45)).astype(np.float32)


def rec709_oetf(v: np.ndarray) -> np.ndarray:
    v = np.clip(v, 0.0, None)
    return np.where(v < 0.018, v * 4.5, 1.099 * (v ** 0.45) - 0.099).astype(np.float32)


def pure_gamma_eotf(v: np.ndarray, gamma: float = 2.2) -> np.ndarray:
    return np.power(np.clip(v, 0.0, None), gamma).astype(np.float32)


def pure_gamma_oetf(v: np.ndarray, gamma: float = 2.2) -> np.ndarray:
    return np.power(np.clip(v, 0.0, None), 1.0 / gamma).astype(np.float32)


_TRANSFER_FUNCTIONS: Dict[str, Dict[str, Callable]] = {
    "sRGB": {"eotf": srgb_eotf, "oetf": srgb_oetf},
    "Rec.709": {"eotf": rec709_eotf, "oetf": rec709_oetf},
    "Rec.2020": {"eotf": rec709_eotf, "oetf": rec709_oetf},  # Rec.2020 shares Rec.709's OETF form
    "Display P3": {"eotf": srgb_eotf, "oetf": srgb_oetf},     # P3 commonly paired with sRGB-like EOTF
}


class ColourEngine:
    SUPPORTED_SPACES = tuple(_RGB_TO_XYZ.keys()) + ("Linear RGB",)

    # -- gamma / transfer -----------------------------------------------------
    def to_linear(self, image: Image16K) -> Image16K:
        cs = image.meta.colorspace
        if cs in ("Linear RGB", "linear"):
            return image.copy()
        tf = _TRANSFER_FUNCTIONS.get(cs, _TRANSFER_FUNCTIONS["sRGB"])
        data = tf["eotf"](image.data)
        return self._with_colorspace(image, data, "Linear RGB")

    def from_linear(self, image: Image16K, target_colorspace: str) -> Image16K:
        if image.meta.colorspace not in ("Linear RGB", "linear"):
            raise ValueError("from_linear expects a linear-light source image")
        tf = _TRANSFER_FUNCTIONS.get(target_colorspace, _TRANSFER_FUNCTIONS["sRGB"])
        data = tf["oetf"](image.data)
        return self._with_colorspace(image, data, target_colorspace)

    def apply_gamma(self, image: Image16K, gamma: float) -> Image16K:
        data = np.power(np.clip(image.data, 0.0, None), 1.0 / gamma).astype(np.float32)
        return self._with_colorspace(image, data, image.meta.colorspace)

    # -- gamut conversion -------------------------------------------------
    def convert_colorspace(self, image: Image16K, target: str) -> Image16K:
        src = image.meta.colorspace
        if src == target:
            return image.copy()
        if image.channels < 3:
            raise ValueError("colour conversion requires >= 3 channels")

        rgb = image.data[..., :3]
        # 1. source gamma -> source linear
        src_tf = _TRANSFER_FUNCTIONS.get(src, _TRANSFER_FUNCTIONS["sRGB"])
        linear_src = rgb if src == "Linear RGB" else src_tf["eotf"](rgb)
        # 2. source linear RGB -> XYZ -> target linear RGB
        m_to_xyz = _RGB_TO_XYZ.get(src, _RGB_TO_XYZ["sRGB"])
        m_from_xyz = _XYZ_TO_RGB.get(target, _XYZ_TO_RGB["sRGB"])
        xyz = _apply_matrix(linear_src, m_to_xyz)
        linear_dst = _apply_matrix(xyz, m_from_xyz)
        # 3. target linear -> target gamma
        dst_tf = _TRANSFER_FUNCTIONS.get(target, _TRANSFER_FUNCTIONS["sRGB"])
        out_rgb = linear_dst if target == "Linear RGB" else dst_tf["oetf"](linear_dst)

        out = image.data.copy()
        out[..., :3] = out_rgb
        return self._with_colorspace(image, out, target)

    # -- white balance / colour temperature -----------------------------------
    def white_balance(self, image: Image16K, r_gain: float = 1.0, g_gain: float = 1.0,
                       b_gain: float = 1.0) -> Image16K:
        if image.channels < 3:
            raise ValueError("white balance requires >= 3 channels")
        data = image.data.copy()
        data[..., 0] *= r_gain
        data[..., 1] *= g_gain
        data[..., 2] *= b_gain
        return self._with_colorspace(image, data, image.meta.colorspace)

    def colour_temperature_to_gains(self, kelvin: float) -> tuple:
        """Approximate blackbody-based white-balance multipliers (Tanner
        Helland's widely-used polynomial fit), normalized so the mid-point
        (6500K, "daylight") yields unity gains."""
        def rgb_for(temp_k: float):
            temp = temp_k / 100.0
            if temp <= 66:
                r = 255.0
            else:
                r = 329.698727446 * ((temp - 60) ** -0.1332047592)
            if temp <= 66:
                g = 99.4708025861 * np.log(temp) - 161.1195681661
            else:
                g = 288.1221695283 * ((temp - 60) ** -0.0755148492)
            if temp >= 66:
                b = 255.0
            elif temp <= 19:
                b = 0.0
            else:
                b = 138.5177312231 * np.log(temp - 10) - 305.0447927307
            return np.clip([r, g, b], 0, 255)

        target = rgb_for(kelvin)
        reference = rgb_for(6500.0)
        gains = reference / np.clip(target, 1e-6, None)
        gains = gains / gains[1]  # normalize to green
        return float(gains[0]), float(gains[1]), float(gains[2])

    def apply_colour_temperature(self, image: Image16K, kelvin: float) -> Image16K:
        r, g, b = self.colour_temperature_to_gains(kelvin)
        return self.white_balance(image, r, g, b)

    def exposure(self, image: Image16K, stops: float) -> Image16K:
        data = (image.data * (2.0 ** stops)).astype(np.float32)
        return self._with_colorspace(image, data, image.meta.colorspace)

    # -- LUT interface ---------------------------------------------------
    def apply_lut_1d(self, image: Image16K, lut: np.ndarray) -> Image16K:
        """Apply a 1D LUT (shape (N,) or (N, C)) per-channel via interpolation."""
        n = lut.shape[0]
        xs = np.linspace(0.0, 1.0, n)
        data = image.data.copy()
        if lut.ndim == 1:
            for c in range(image.channels):
                data[..., c] = np.interp(np.clip(data[..., c], 0, 1), xs, lut).astype(np.float32)
        else:
            for c in range(min(image.channels, lut.shape[1])):
                data[..., c] = np.interp(np.clip(data[..., c], 0, 1), xs, lut[:, c]).astype(np.float32)
        return self._with_colorspace(image, data, image.meta.colorspace)

    def apply_lut_3d(self, image: Image16K, lut: np.ndarray) -> Image16K:
        """Apply a 3D LUT (shape (S, S, S, 3)) with trilinear interpolation."""
        size = lut.shape[0]
        rgb = np.clip(image.data[..., :3], 0.0, 1.0) * (size - 1)
        i0 = np.floor(rgb).astype(np.int32)
        i1 = np.clip(i0 + 1, 0, size - 1)
        frac = (rgb - i0).astype(np.float32)

        def sample(ix):
            r, g, b = ix[..., 0], ix[..., 1], ix[..., 2]
            return lut[r, g, b]

        c000 = sample(np.stack([i0[..., 0], i0[..., 1], i0[..., 2]], -1))
        c100 = sample(np.stack([i1[..., 0], i0[..., 1], i0[..., 2]], -1))
        c010 = sample(np.stack([i0[..., 0], i1[..., 1], i0[..., 2]], -1))
        c110 = sample(np.stack([i1[..., 0], i1[..., 1], i0[..., 2]], -1))
        c001 = sample(np.stack([i0[..., 0], i0[..., 1], i1[..., 2]], -1))
        c101 = sample(np.stack([i1[..., 0], i0[..., 1], i1[..., 2]], -1))
        c011 = sample(np.stack([i0[..., 0], i1[..., 1], i1[..., 2]], -1))
        c111 = sample(np.stack([i1[..., 0], i1[..., 1], i1[..., 2]], -1))

        fx, fy, fz = frac[..., 0:1], frac[..., 1:2], frac[..., 2:3]
        c00 = c000 * (1 - fx) + c100 * fx
        c10 = c010 * (1 - fx) + c110 * fx
        c01 = c001 * (1 - fx) + c101 * fx
        c11 = c011 * (1 - fx) + c111 * fx
        c0 = c00 * (1 - fy) + c10 * fy
        c1 = c01 * (1 - fy) + c11 * fy
        result = (c0 * (1 - fz) + c1 * fz).astype(np.float32)

        out = image.data.copy()
        out[..., :3] = result
        return self._with_colorspace(image, out, image.meta.colorspace)

    @staticmethod
    def identity_lut_3d(size: int = 17) -> np.ndarray:
        ramp = np.linspace(0.0, 1.0, size, dtype=np.float32)
        r, g, b = np.meshgrid(ramp, ramp, ramp, indexing="ij")
        return np.stack([r, g, b], axis=-1)

    # -- helper --------------------------------------------------------
    def _with_colorspace(self, image: Image16K, data: np.ndarray, colorspace: str) -> Image16K:
        meta = ImageMetadata(
            bit_depth=image.meta.bit_depth,
            channel_layout=image.meta.channel_layout,
            colorspace=colorspace,
            name=image.meta.name,
            extra=dict(image.meta.extra),
        )
        return Image16K(data, meta)
