"""
HARDWARE ABSTRACTION
A thin abstraction over CPU / GPU / accelerator execution. The base
implementation is CPU-only (pure NumPy); GPU acceleration is an optional,
detected-at-runtime backend (e.g. CuPy), never a hard requirement.
"""
from __future__ import annotations

import enum
from typing import Callable, Optional

import numpy as np


class DeviceKind(enum.Enum):
    CPU = "cpu"
    GPU = "gpu"
    ACCELERATOR = "accelerator"


class Device:
    def __init__(self, kind: DeviceKind = DeviceKind.CPU, name: str = "cpu-default"):
        self.kind = kind
        self.name = name

    def array_module(self):
        """Return the array module (numpy, or a GPU-compatible drop-in) for
        this device."""
        if self.kind is DeviceKind.CPU:
            return np
        try:
            import cupy as cp  # optional GPU backend
            return cp
        except ImportError:
            return np  # graceful fallback -- GPU acceleration is optional

    def is_available(self) -> bool:
        if self.kind is DeviceKind.CPU:
            return True
        try:
            import cupy  # noqa: F401
            return True
        except ImportError:
            return False


class HardwareAbstraction:
    def __init__(self):
        self.cpu = Device(DeviceKind.CPU, "cpu-default")
        self._active = self.cpu

    def detect_devices(self) -> list:
        devices = [self.cpu]
        gpu = Device(DeviceKind.GPU, "gpu-cupy")
        if gpu.is_available():
            devices.append(gpu)
        return devices

    def set_active(self, device: Device) -> None:
        if not device.is_available():
            raise RuntimeError(f"device {device.name} is not available on this system")
        self._active = device

    @property
    def active(self) -> Device:
        return self._active

    def run(self, fn: Callable, *args, **kwargs):
        """Execute `fn` using the active device's array module context. `fn`
        should accept the array module as its first argument."""
        xp = self._active.array_module()
        return fn(xp, *args, **kwargs)
