"""HISTOGRAM ENGINE -- RGB / luminance / per-channel / HDR histograms + stats."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict

import numpy as np

from .image import Image16K

_LUMA_WEIGHTS = np.array([0.2126, 0.7152, 0.0722], dtype=np.float32)


@dataclass
class ChannelStats:
    mean: float
    median: float
    minimum: float
    maximum: float
    std: float
    percentiles: Dict[int, float] = field(default_factory=dict)

    def as_dict(self) -> dict:
        return {
            "mean": self.mean, "median": self.median, "min": self.minimum,
            "max": self.maximum, "std": self.std, "percentiles": self.percentiles,
        }


class HistogramEngine:
    DEFAULT_PERCENTILES = (1, 5, 25, 50, 75, 95, 99)

    def channel_stats(self, channel: np.ndarray, percentiles=DEFAULT_PERCENTILES) -> ChannelStats:
        flat = channel.reshape(-1)
        pvals = {p: float(np.percentile(flat, p)) for p in percentiles}
        return ChannelStats(
            mean=float(flat.mean()), median=float(np.median(flat)),
            minimum=float(flat.min()), maximum=float(flat.max()),
            std=float(flat.std()), percentiles=pvals,
        )

    def rgb_histogram(self, image: Image16K, bins: int = 256, value_range=(0.0, 1.0)) -> Dict[str, np.ndarray]:
        names = ["R", "G", "B"][:min(3, image.channels)]
        out = {}
        for i, name in enumerate(names):
            hist, _ = np.histogram(image.data[..., i], bins=bins, range=value_range)
            out[name] = hist
        return out

    def luminance_histogram(self, image: Image16K, bins: int = 256, value_range=(0.0, 1.0)) -> np.ndarray:
        luma = self._luma(image)
        hist, _ = np.histogram(luma, bins=bins, range=value_range)
        return hist

    def per_channel_histogram(self, image: Image16K, bins: int = 256, value_range=(0.0, 1.0)) -> Dict[int, np.ndarray]:
        out = {}
        for c in range(image.channels):
            hist, _ = np.histogram(image.data[..., c], bins=bins, range=value_range)
            out[c] = hist
        return out

    def hdr_histogram(self, image: Image16K, bins: int = 256, stops_range=(-6.0, 6.0)) -> np.ndarray:
        """Log2 (stops-based) histogram appropriate for unclamped HDR data."""
        luma = np.clip(self._luma(image), 1e-6, None)
        stops = np.log2(luma)
        hist, _ = np.histogram(stops, bins=bins, range=stops_range)
        return hist

    def full_report(self, image: Image16K) -> dict:
        report = {"channels": {}, "luminance": None}
        names = ["R", "G", "B", "A"]
        for c in range(image.channels):
            label = names[c] if c < len(names) else f"ch{c}"
            report["channels"][label] = self.channel_stats(image.data[..., c]).as_dict()
        report["luminance"] = self.channel_stats(self._luma(image)).as_dict()
        return report

    def _luma(self, image: Image16K) -> np.ndarray:
        c = min(3, image.channels)
        return np.tensordot(image.data[..., :c], _LUMA_WEIGHTS[:c], axes=([2], [0]))
