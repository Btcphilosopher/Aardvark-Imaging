"""OPTICAL calculations underpinning camera.py: thin-lens equations, angular
field of view, depth of field, hyperfocal distance, pixel density."""
from __future__ import annotations

import math


def fov_from_sensor(sensor_dim_mm: float, focal_length_mm: float) -> float:
    """Angular field of view (degrees) for one sensor dimension via the
    standard thin-lens FOV formula: FOV = 2 * atan(sensor / (2f))."""
    if focal_length_mm <= 0:
        raise ValueError("focal_length_mm must be positive")
    return math.degrees(2 * math.atan(sensor_dim_mm / (2 * focal_length_mm)))


def circle_of_confusion_mm(sensor_diagonal_mm: float, divisor: float = 1500.0) -> float:
    """Standard approximation: acceptable CoC ~= sensor diagonal / 1500 (a
    common photographic convention for a normal-sized print/viewing distance)."""
    return sensor_diagonal_mm / divisor


def hyperfocal_distance_mm(focal_length_mm: float, f_number: float, coc_mm: float) -> float:
    if f_number <= 0 or coc_mm <= 0:
        raise ValueError("f_number and coc_mm must be positive")
    return (focal_length_mm ** 2) / (f_number * coc_mm) + focal_length_mm


def depth_of_field_mm(focal_length_mm: float, f_number: float, focus_distance_mm: float,
                       coc_mm: float):
    """Returns (near_limit_mm, far_limit_mm, dof_mm). far_limit may be `inf`
    when the focus distance is beyond the hyperfocal distance."""
    h = hyperfocal_distance_mm(focal_length_mm, f_number, coc_mm)
    if focus_distance_mm <= 0:
        raise ValueError("focus_distance_mm must be positive")
    near = (focus_distance_mm * (h - focal_length_mm)) / (h + focus_distance_mm - 2 * focal_length_mm)
    denom = (h - focus_distance_mm)
    if denom <= 0:
        far = math.inf
    else:
        far = (focus_distance_mm * (h - focal_length_mm)) / denom
    dof = far - near if math.isfinite(far) else math.inf
    return near, far, dof


def pixel_density_ppi(width_px: int, sensor_or_display_width_mm: float) -> float:
    """Pixels per inch given a horizontal pixel count and physical width in mm."""
    inches = sensor_or_display_width_mm / 25.4
    return width_px / inches if inches else 0.0


def motion_blur_streak_px(subject_speed_px_per_sec: float, shutter_speed_sec: float) -> float:
    return subject_speed_px_per_sec * shutter_speed_sec
