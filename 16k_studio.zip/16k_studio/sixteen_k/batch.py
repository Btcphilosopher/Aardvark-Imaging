"""
BATCH PROCESSING
Processes multiple assets through a pipeline of operations, with controlled
concurrency so system memory is never overloaded -- concurrency is capped
using the MemoryEngine's per-asset estimate against the configured budget,
not just a flat worker count.
"""
from __future__ import annotations

import os
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Callable, List, Optional

from .image import Image16K, BitDepth
from .export import ExportEngine
from .memory import MemoryEngine


@dataclass
class BatchResult:
    input_path: str
    output_path: Optional[str]
    success: bool
    error: Optional[str] = None


class BatchProcessor:
    def __init__(self, memory_budget_bytes: int = 4 * 1024 ** 3):
        self._export = ExportEngine()
        self._memory = MemoryEngine(memory_budget_bytes)

    def _safe_worker_count(self, sample_image: Image16K, requested_workers: int) -> int:
        """Never allow more concurrent in-flight assets than the memory budget
        can hold at once (each worker needs roughly one full working copy)."""
        est = self._memory.estimate_frame_memory(
            sample_image.width, sample_image.height, sample_image.channels,
            sample_image.meta.bit_depth, copy_multiplier=1,
        )
        if est.working_bytes <= 0:
            return max(1, requested_workers)
        max_by_memory = max(1, self._memory.budget_bytes // est.working_bytes)
        return max(1, min(requested_workers, int(max_by_memory)))

    def batch_process(self, input_directory: str, output_directory: str,
                      operations: List[Callable[[Image16K], Image16K]],
                      max_workers: int = 4, output_format: str = "PNG",
                      extensions=(".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp")) -> List[BatchResult]:
        os.makedirs(output_directory, exist_ok=True)
        paths = [
            os.path.join(input_directory, f) for f in sorted(os.listdir(input_directory))
            if f.lower().endswith(extensions)
        ]
        if not paths:
            return []

        first = self._export.import_still(paths[0])
        workers = self._safe_worker_count(first, max_workers)

        def process_one(path: str) -> BatchResult:
            try:
                img = self._export.import_still(path)
                for op in operations:
                    img = op(img)
                base = os.path.splitext(os.path.basename(path))[0]
                out_path = os.path.join(output_directory, f"{base}.{output_format.lower()}")
                self._export.export_still(img, out_path, output_format)
                return BatchResult(input_path=path, output_path=out_path, success=True)
            except Exception as exc:
                return BatchResult(input_path=path, output_path=None, success=False,
                                   error=f"{exc}\n{traceback.format_exc()}")

        results: List[BatchResult] = []
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(process_one, p): p for p in paths}
            for fut in as_completed(futures):
                results.append(fut.result())
        results.sort(key=lambda r: r.input_path)
        return results
