"""
SIMULATION MODE
A deterministic simulation environment for exercising camera movement,
lighting changes, resolution changes, exposure changes, lens changes and
scene changes over a sequence of steps, seeded for full reproducibility.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

from .digital_twin import DigitalTwin, Light, SceneObject


@dataclass
class SimulationStep:
    step_index: int
    description: str
    camera_state: dict
    scene_state: dict


class SimulationEngine:
    def __init__(self, twin: Optional[DigitalTwin] = None, seed: Optional[int] = None):
        self.twin = twin or DigitalTwin()
        self.seed = seed
        self._rng = random.Random(seed)
        self.log: List[SimulationStep] = []

    def reset(self, seed: Optional[int] = None) -> None:
        self.seed = seed if seed is not None else self.seed
        self._rng = random.Random(self.seed)
        self.log = []

    def step_camera_move(self, dx: float = 0.0, dy: float = 0.0, dz: float = 0.0,
                         description: str = "camera_move") -> SimulationStep:
        self.twin.camera.move(dx, dy, dz)
        return self._record(description)

    def step_camera_rotate(self, dpitch: float = 0.0, dyaw: float = 0.0, droll: float = 0.0,
                           description: str = "camera_rotate") -> SimulationStep:
        self.twin.camera.rotate(dpitch, dyaw, droll)
        return self._record(description)

    def step_exposure_change(self, delta_stops: float, description: str = "exposure_change") -> SimulationStep:
        # exposure lives on the imaging pipeline, not the camera object itself;
        # tracked here as metadata for downstream rendering to consume.
        return self._record(description, extra={"exposure_delta_stops": delta_stops})

    def step_lens_change(self, focal_length_mm: float = None, aperture_f_number: float = None,
                         description: str = "lens_change") -> SimulationStep:
        if focal_length_mm is not None:
            self.twin.camera.focal_length_mm = focal_length_mm
        if aperture_f_number is not None:
            self.twin.camera.aperture_f_number = aperture_f_number
        return self._record(description)

    def step_resolution_change(self, width: int, height: int, description: str = "resolution_change") -> SimulationStep:
        self.twin.camera.resolution_width = width
        self.twin.camera.resolution_height = height
        return self._record(description)

    def step_lighting_change(self, light_name: str, intensity: float = None,
                             color=None, description: str = "lighting_change") -> SimulationStep:
        light = self.twin.scene.lights.get(light_name)
        if light is None:
            light = self.twin.scene.add_light(Light(name=light_name))
        if intensity is not None:
            light.intensity = intensity
        if color is not None:
            light.color = color
        return self._record(description)

    def step_scene_change(self, object_name: str, description: str = "scene_change", **kwargs) -> SimulationStep:
        obj = self.twin.scene.objects.get(object_name)
        if obj is None:
            obj = self.twin.scene.add_object(SceneObject(name=object_name))
        for k, v in kwargs.items():
            if hasattr(obj, k):
                setattr(obj, k, v)
        return self._record(description)

    def random_walk(self, steps: int, move_scale: float = 1.0, rotate_scale: float = 5.0) -> List[SimulationStep]:
        """Deterministic (seeded) random camera walk -- useful for stress-
        testing rendering/processing pipelines under varied, reproducible
        camera trajectories."""
        out = []
        for i in range(steps):
            dx = (self._rng.random() * 2 - 1) * move_scale
            dy = (self._rng.random() * 2 - 1) * move_scale
            dz = (self._rng.random() * 2 - 1) * move_scale
            out.append(self.step_camera_move(dx, dy, dz, description=f"random_walk_move_{i}"))
            dpitch = (self._rng.random() * 2 - 1) * rotate_scale
            dyaw = (self._rng.random() * 2 - 1) * rotate_scale
            out.append(self.step_camera_rotate(dpitch, dyaw, 0.0, description=f"random_walk_rotate_{i}"))
        return out

    def _record(self, description: str, extra: Dict = None) -> SimulationStep:
        state = self.twin.snapshot_state()
        if extra:
            state["extra"] = extra
        step = SimulationStep(step_index=len(self.log), description=description,
                              camera_state=state["camera"], scene_state=state["scene"])
        self.log.append(step)
        return step

    def replay_summary(self) -> List[dict]:
        return [{"step": s.step_index, "description": s.description,
                "camera_position": s.camera_state["position"],
                "camera_rotation": s.camera_state["rotation_deg"]} for s in self.log]
