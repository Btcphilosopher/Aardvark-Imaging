"""
IMAGE ENGINE
Core data model for ultra-high-resolution (up to 16K+) image buffers.

Internal representation: numpy float32 array, shape (H, W, C), values nominally
in [0, 1] (linear or gamma-encoded depending on `colorspace`). Bit depth is
tracked as metadata describing the *source/target* quantization, not the
in-memory dtype -- this keeps every processing op numerically consistent
regardless of whether the image originated as 8-bit or 32-bit float.
"""
from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import Optional, Tuple

import numpy as np

# ----------------------------------------------------------------------------
# Resolution presets (width, height)
# ----------------------------------------------------------------------------
RESOLUTION_PRESETS = {
    "720p": (1280, 720),
    "1080p": (1920, 1080),
    "4K": (3840, 2160),
    "6K": (6144, 3160),
    "8K": (7680, 4320),
    "12K": (12288, 6480),
    "16K": (15360, 8640),
}

PRIMARY_RESOLUTION = RESOLUTION_PRESETS["16K"]


class BitDepth(enum.IntEnum):
    BD_8 = 8
    BD_10 = 10
    BD_12 = 12
    BD_14 = 14
    BD_16 = 16
    BD_32F = 32

    @property
    def max_value(self) -> float:
        if self is BitDepth.BD_32F:
            return 1.0
        return float((1 << int(self)) - 1)

    @property
    def bytes_per_channel(self) -> int:
        if self is BitDepth.BD_8:
            return 1
        if self in (BitDepth.BD_10, BitDepth.BD_12, BitDepth.BD_14, BitDepth.BD_16):
            return 2
        return 4  # 32-bit float


class ChannelLayout(enum.Enum):
    GRAY = ("Gray", 1)
    RGB = ("RGB", 3)
    RGBA = ("RGBA", 4)
    YCBCR = ("YCbCr", 3)
    LINEAR_RGB = ("LinearRGB", 3)

    def __init__(self, label: str, count: int):
        self.label = label
        self.count = count


@dataclass
class ImageMetadata:
    bit_depth: BitDepth = BitDepth.BD_16
    channel_layout: ChannelLayout = ChannelLayout.RGB
    colorspace: str = "sRGB"
    name: str = "untitled"
    extra: dict = field(default_factory=dict)


class Image16K:
    """A single high-resolution image buffer plus metadata."""

    __slots__ = ("data", "meta")

    def __init__(self, data: np.ndarray, meta: Optional[ImageMetadata] = None):
        if data.ndim != 3:
            raise ValueError(f"Image16K data must be (H, W, C), got shape {data.shape}")
        self.data = data.astype(np.float32, copy=False)
        self.meta = meta or ImageMetadata()
        if self.data.shape[2] != self.meta.channel_layout.count:
            raise ValueError(
                f"Channel mismatch: array has {self.data.shape[2]} channels, "
                f"layout {self.meta.channel_layout.label} expects {self.meta.channel_layout.count}"
            )

    # -- construction -----------------------------------------------------
    @classmethod
    def blank(
        cls,
        width: int = PRIMARY_RESOLUTION[0],
        height: int = PRIMARY_RESOLUTION[1],
        channel_layout: ChannelLayout = ChannelLayout.RGB,
        bit_depth: BitDepth = BitDepth.BD_16,
        fill: float = 0.0,
    ) -> "Image16K":
        arr = np.full((height, width, channel_layout.count), fill, dtype=np.float32)
        return cls(arr, ImageMetadata(bit_depth=bit_depth, channel_layout=channel_layout))

    @classmethod
    def from_array(cls, arr: np.ndarray, **meta_kwargs) -> "Image16K":
        return cls(arr, ImageMetadata(**meta_kwargs))

    @classmethod
    def random(cls, width: int, height: int, seed: Optional[int] = None, **kwargs) -> "Image16K":
        rng = np.random.default_rng(seed)
        layout = kwargs.get("channel_layout", ChannelLayout.RGB)
        arr = rng.random((height, width, layout.count)).astype(np.float32)
        return cls(arr, ImageMetadata(**kwargs))

    # -- geometry / stats ---------------------------------------------------
    @property
    def width(self) -> int:
        return self.data.shape[1]

    @property
    def height(self) -> int:
        return self.data.shape[0]

    @property
    def channels(self) -> int:
        return self.data.shape[2]

    @property
    def pixel_count(self) -> int:
        return self.width * self.height

    @property
    def aspect_ratio(self) -> float:
        return self.width / self.height if self.height else 0.0

    @property
    def bit_depth(self) -> BitDepth:
        return self.meta.bit_depth

    def memory_bytes(self) -> int:
        """Memory required to store this image at its declared bit depth
        (not the in-memory float32 working size -- see MemoryEngine for that)."""
        return self.pixel_count * self.channels * self.meta.bit_depth.bytes_per_channel

    def working_memory_bytes(self) -> int:
        """Actual in-memory footprint of the float32 numpy buffer."""
        return self.data.nbytes

    def quantize(self) -> np.ndarray:
        """Return a copy quantized to the declared bit depth (simulates precision
        loss on export to a fixed-point format)."""
        bd = self.meta.bit_depth
        if bd is BitDepth.BD_32F:
            return self.data.copy()
        maxval = bd.max_value
        clipped = np.clip(self.data, 0.0, 1.0)
        q = np.round(clipped * maxval) / maxval
        return q.astype(np.float32)

    def copy(self) -> "Image16K":
        return Image16K(self.data.copy(), ImageMetadata(
            bit_depth=self.meta.bit_depth,
            channel_layout=self.meta.channel_layout,
            colorspace=self.meta.colorspace,
            name=self.meta.name,
            extra=dict(self.meta.extra),
        ))

    def describe(self) -> dict:
        return {
            "name": self.meta.name,
            "width": self.width,
            "height": self.height,
            "pixel_count": self.pixel_count,
            "aspect_ratio": round(self.aspect_ratio, 6),
            "bit_depth": int(self.meta.bit_depth),
            "channels": self.channels,
            "channel_layout": self.meta.channel_layout.label,
            "colorspace": self.meta.colorspace,
            "declared_memory_bytes": self.memory_bytes(),
            "working_memory_bytes": self.working_memory_bytes(),
        }

    def __repr__(self) -> str:
        return (
            f"Image16K({self.width}x{self.height}, {self.meta.channel_layout.label}, "
            f"{int(self.meta.bit_depth)}-bit, {self.meta.colorspace})"
        )
