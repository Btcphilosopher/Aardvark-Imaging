"""WAVEFORM ENGINE -- luminance & RGB waveform analysis, operating directly on
pixel data (one column of the waveform per image column)."""
from __future__ import annotations

import numpy as np

from .image import Image16K

_LUMA_WEIGHTS = np.array([0.2126, 0.7152, 0.0722], dtype=np.float32)


class WaveformEngine:
    def luminance_waveform(self, image: Image16K, levels: int = 256) -> np.ndarray:
        """Return a (levels, width) 2D histogram: for each column x, how many
        pixels fall at each luminance level -- the classic broadcast waveform."""
        c = min(3, image.channels)
        luma = np.tensordot(image.data[..., :c], _LUMA_WEIGHTS[:c], axes=([2], [0]))
        return self._column_histogram(luma, levels)

    def rgb_waveform(self, image: Image16K, levels: int = 256) -> dict:
        names = ["R", "G", "B"][:min(3, image.channels)]
        return {name: self._column_histogram(image.data[..., i], levels) for i, name in enumerate(names)}

    def _column_histogram(self, plane: np.ndarray, levels: int) -> np.ndarray:
        h, w = plane.shape
        quant = np.clip((plane * (levels - 1)).astype(np.int64), 0, levels - 1)
        out = np.zeros((levels, w), dtype=np.int64)
        col_idx = np.broadcast_to(np.arange(w), (h, w))
        flat_level = quant.reshape(-1)
        flat_col = col_idx.reshape(-1)
        np.add.at(out, (flat_level, flat_col), 1)
        return out
