"""
UNDO / REDO
Operation history for the non-destructive edit stack. Large 16K image
buffers are NOT duplicated on every operation -- instead, each history entry
stores the *operation* (a small, cheap descriptor + callable) rather than a
full pixel copy. The current image is only ever materialised by replaying
the operation stack up to the current pointer, and a lightweight snapshot
cache (every N ops) bounds worst-case replay cost.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, List, Optional

from .image import Image16K


@dataclass
class HistoryEntry:
    label: str
    op: Callable[[Image16K], Image16K]


class OperationHistory:
    def __init__(self, base_image: Image16K, snapshot_interval: int = 10):
        self._base = base_image
        self._entries: List[HistoryEntry] = []
        self._pointer = 0  # number of entries currently "applied"
        self._snapshot_interval = snapshot_interval
        self._snapshots = {0: base_image}  # index -> materialised Image16K

    def push(self, label: str, op: Callable[[Image16K], Image16K]) -> Image16K:
        """Apply a new operation, discarding any redo-able entries beyond the
        current pointer (standard undo-tree truncation on new edits)."""
        del self._entries[self._pointer:]
        # also drop snapshots that are now unreachable
        self._snapshots = {k: v for k, v in self._snapshots.items() if k <= self._pointer}
        self._entries.append(HistoryEntry(label=label, op=op))
        self._pointer += 1
        if self._pointer % self._snapshot_interval == 0:
            self._snapshots[self._pointer] = self._materialise(self._pointer)
        return self.current()

    def undo(self) -> Image16K:
        if self._pointer == 0:
            return self._base
        self._pointer -= 1
        return self.current()

    def redo(self) -> Image16K:
        if self._pointer >= len(self._entries):
            return self.current()
        self._pointer += 1
        return self.current()

    def can_undo(self) -> bool:
        return self._pointer > 0

    def can_redo(self) -> bool:
        return self._pointer < len(self._entries)

    def current(self) -> Image16K:
        return self._materialise(self._pointer)

    def _materialise(self, target_pointer: int) -> Image16K:
        # find the nearest snapshot at or before target_pointer
        nearest = max((k for k in self._snapshots if k <= target_pointer), default=0)
        img = self._snapshots[nearest]
        for entry in self._entries[nearest:target_pointer]:
            img = entry.op(img)
        return img

    def labels(self) -> List[str]:
        return [e.label for e in self._entries]

    def timeline_position(self) -> dict:
        return {"pointer": self._pointer, "total": len(self._entries),
                "can_undo": self.can_undo(), "can_redo": self.can_redo()}
