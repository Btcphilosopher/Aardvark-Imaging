"""
COMPOSITING ENGINE
Layer stack with alpha, masks, blend modes, transparency and overlays. All
blend modes operate at full 16K resolution via vectorised numpy.
"""
from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import List, Optional

import numpy as np

from .image import Image16K, ImageMetadata


class BlendMode(enum.Enum):
    NORMAL = "normal"
    MULTIPLY = "multiply"
    SCREEN = "screen"
    OVERLAY = "overlay"
    ADD = "add"
    SUBTRACT = "subtract"
    DIFFERENCE = "difference"


def _blend(base: np.ndarray, top: np.ndarray, mode: BlendMode) -> np.ndarray:
    if mode is BlendMode.NORMAL:
        return top
    if mode is BlendMode.MULTIPLY:
        return base * top
    if mode is BlendMode.SCREEN:
        return 1.0 - (1.0 - base) * (1.0 - top)
    if mode is BlendMode.OVERLAY:
        return np.where(base <= 0.5, 2 * base * top, 1 - 2 * (1 - base) * (1 - top))
    if mode is BlendMode.ADD:
        return base + top
    if mode is BlendMode.SUBTRACT:
        return base - top
    if mode is BlendMode.DIFFERENCE:
        return np.abs(base - top)
    raise ValueError(f"unknown blend mode {mode}")


@dataclass
class Layer:
    image: Image16K
    opacity: float = 1.0
    blend_mode: BlendMode = BlendMode.NORMAL
    mask: Optional[np.ndarray] = None  # (H, W) in [0, 1]; None = fully opaque
    visible: bool = True


class CompositingEngine:
    def composite_layer(self, base: Image16K, layer: Layer) -> Image16K:
        if not layer.visible:
            return base
        if base.data.shape != layer.image.data.shape:
            raise ValueError("layer must match base image shape to composite")
        blended = _blend(base.data, layer.image.data, layer.blend_mode)
        alpha = layer.opacity
        if layer.mask is not None:
            alpha = alpha * layer.mask[..., None]
        else:
            alpha = np.float32(alpha)
        out = base.data * (1 - alpha) + blended * alpha
        meta = ImageMetadata(
            bit_depth=base.meta.bit_depth, channel_layout=base.meta.channel_layout,
            colorspace=base.meta.colorspace, name=base.meta.name, extra=dict(base.meta.extra),
        )
        return Image16K(out.astype(np.float32), meta)

    def composite_stack(self, base: Image16K, layers: List[Layer]) -> Image16K:
        out = base
        for layer in layers:
            out = self.composite_layer(out, layer)
        return out

    def alpha_over(self, base: Image16K, overlay: Image16K, overlay_alpha: np.ndarray) -> Image16K:
        """Straightforward alpha-over compositing given an explicit (H, W)
        alpha channel for the overlay (e.g. from an RGBA source)."""
        layer = Layer(image=overlay, opacity=1.0, blend_mode=BlendMode.NORMAL, mask=overlay_alpha)
        return self.composite_layer(base, layer)
