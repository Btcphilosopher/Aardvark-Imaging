"""
PAN / SCAN
Turns a single ultra-high-resolution still (e.g. 16K master) into a dynamic
video by panning a smaller virtual window across it over time -- classic
"Ken Burns" style motion graphics, engineered for genuinely huge masters.

A pan/scan move is described by a sorted list of PanScanKeyframe entries
(normalized time in [0,1], normalized window-center x/y in [0,1], and a
zoom level), interpolated linearly between keyframes.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List

from .image import Image16K
from .video import VideoProject
from .resolution import ResolutionEngine


@dataclass
class PanScanKeyframe:
    time: float      # normalized position along the move, in [0, 1]
    x: float         # normalized window-center X within the master, in [0, 1]
    y: float         # normalized window-center Y within the master, in [0, 1]
    zoom: float      # zoom level: window size = output_size / zoom


class PanScanEngine:
    def __init__(self):
        self._res = ResolutionEngine()

    def render(self, master: Image16K, keyframes: List[PanScanKeyframe],
               output_width: int, output_height: int, fps: float,
               duration_seconds: float) -> VideoProject:
        if not keyframes:
            raise ValueError("need at least one keyframe")
        kfs = sorted(keyframes, key=lambda k: k.time)
        frame_count = max(1, round(fps * duration_seconds))
        vp = VideoProject(output_width, output_height, fps=_nearest_standard_fps(fps), name="panscan")

        for i in range(frame_count):
            t = i / (frame_count - 1) if frame_count > 1 else 0.0
            x_frac, y_frac, zoom = self._interpolate(kfs, t)
            window_w = min(master.width, max(1, round(output_width / zoom)))
            window_h = min(master.height, max(1, round(output_height / zoom)))
            cx = x_frac * master.width
            cy = y_frac * master.height
            x = int(round(cx - window_w / 2))
            y = int(round(cy - window_h / 2))
            x = max(0, min(x, master.width - window_w))
            y = max(0, min(y, master.height - window_h))
            window = self._res.crop(master, x, y, window_w, window_h)
            frame = self._res.resize(window, output_width, output_height)
            vp.add_frame(frame)
        return vp

    def _interpolate(self, kfs: List[PanScanKeyframe], t: float):
        if len(kfs) == 1:
            k = kfs[0]
            return k.x, k.y, k.zoom
        if t <= kfs[0].time:
            k = kfs[0]
            return k.x, k.y, k.zoom
        if t >= kfs[-1].time:
            k = kfs[-1]
            return k.x, k.y, k.zoom
        for a, b in zip(kfs, kfs[1:]):
            if a.time <= t <= b.time:
                span = (b.time - a.time) or 1e-9
                frac = (t - a.time) / span
                x = a.x + (b.x - a.x) * frac
                y = a.y + (b.y - a.y) * frac
                zoom = a.zoom + (b.zoom - a.zoom) * frac
                return x, y, zoom
        k = kfs[-1]
        return k.x, k.y, k.zoom

    def suggest_pan_across(self, master: Image16K, zoom: float = 1.5) -> List[PanScanKeyframe]:
        """A sensible default: pan left-to-right across the master at a fixed
        zoom, vertically centered."""
        return [
            PanScanKeyframe(0.0, 0.5 / zoom, 0.5, zoom),
            PanScanKeyframe(1.0, 1.0 - 0.5 / zoom, 0.5, zoom),
        ]


def _nearest_standard_fps(fps: float) -> int:
    from .video import STANDARD_FRAME_RATES
    return min(STANDARD_FRAME_RATES, key=lambda f: abs(f - fps))
