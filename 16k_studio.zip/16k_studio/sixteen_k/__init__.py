"""
16K.STUDIO
A professional-grade Python computational engine for creating, processing,
analysing, simulating, optimising and exporting ultra-high-resolution
(8K / 12K / 16K+) visual media.

    from sixteen_k import Project16K

    project = Project16K()
    project.new_blank(15360, 8640)
    project.exposure(0.4).sharpen(amount=0.2)
    project.export("output.tiff")

This is NOT software for managing 16,000 cameras -- it is a computational
imaging and video engine architected around 16K (15360x8640) visual data.
"""

__version__ = "1.0.0"

# -- IMAGE ENGINE --------------------------------------------------------
from .image import (
    Image16K, ImageMetadata, BitDepth, ChannelLayout,
    RESOLUTION_PRESETS, PRIMARY_RESOLUTION,
)

# -- MEMORY / TILE ENGINE --------------------------------------------------------
from .memory import MemoryEngine, MemoryEstimate
from .tiles import TileEngine, Tile

# -- VIDEO / TIMELINE ENGINE --------------------------------------------------------
from .video import VideoProject, VideoFrame, VIDEO_RESOLUTION_PRESETS, STANDARD_FRAME_RATES
from .timeline import Timeline, Track, TrackType, Clip

# -- RESOLUTION / SUPER-RESOLUTION --------------------------------------------------------
from .resolution import ResolutionEngine, Interpolation
from .superres import SuperResolutionEngine

# -- IMAGE PROCESSING --------------------------------------------------------
from .processing import ImageProcessingEngine

# -- COLOUR / HDR --------------------------------------------------------
from .colour import ColourEngine
from .hdr import HDREngine, ToneMapOperator, DynamicRange

# -- ANALYSIS: HISTOGRAM / WAVEFORM / VECTORSCOPE --------------------------------------------------------
from .histogram import HistogramEngine, ChannelStats
from .waveform import WaveformEngine
from .vectorscope import Vectorscope

# -- SHARPEN / DENOISE / MOTION / INTERPOLATION --------------------------------------------------------
from .sharpen import SharpeningEngine
from .denoise import DenoisingEngine
from .motion import MotionEngine, MotionField
from .interpolation import FrameInterpolationEngine

# -- OPTICAL / CAMERA / DIGITAL TWIN / PROJECTION --------------------------------------------------------
from . import optics
from .camera import VirtualCamera
from .digital_twin import DigitalTwin, Scene, SceneObject, Light, Material, Environment
from .projection import ProjectionEngine, ProjectedPoint, intrinsic_matrix, extrinsic_matrix, projection_matrix

# -- ZOOM / PAN-SCAN / STABILISATION --------------------------------------------------------
from .zoom import DigitalZoomEngine, ZoomStep
from .panscan import PanScanEngine, PanScanKeyframe
from .stabilisation import StabilisationEngine, FrameTransform

# -- EFFECTS / COMPOSITING / MASKS / GRAPHICS --------------------------------------------------------
from .effects import EffectStack
from .compositing import CompositingEngine, Layer, BlendMode
from .masks import MaskEngine
from .graphics import GraphicsEngine, Transform2D

# -- EXPORT --------------------------------------------------------
from .export import ExportEngine, VideoCodecBackend, NullCodecBackend, SUPPORTED_STILL_FORMATS

# -- COMPRESSION / STORAGE / PERFORMANCE / HARDWARE --------------------------------------------------------
from .compression import CompressionCalculator, CompressionEstimate, TYPICAL_COMPRESSION_RATIOS
from .storage import StorageCalculator, StorageReport
from .performance import PerformanceEngine, BenchmarkResult
from .hardware import HardwareAbstraction, Device, DeviceKind

# -- PROJECT / AUTOMATION / HISTORY / BATCH / SIMULATION --------------------------------------------------------
from .history import OperationHistory
from .project import Project16K, ProjectFile
from .batch import BatchProcessor, BatchResult
from .simulation import SimulationEngine, SimulationStep

__all__ = [
    "__version__",
    "Image16K", "ImageMetadata", "BitDepth", "ChannelLayout",
    "RESOLUTION_PRESETS", "PRIMARY_RESOLUTION",
    "MemoryEngine", "MemoryEstimate", "TileEngine", "Tile",
    "VideoProject", "VideoFrame", "VIDEO_RESOLUTION_PRESETS", "STANDARD_FRAME_RATES",
    "Timeline", "Track", "TrackType", "Clip",
    "ResolutionEngine", "Interpolation", "SuperResolutionEngine",
    "ImageProcessingEngine",
    "ColourEngine", "HDREngine", "ToneMapOperator", "DynamicRange",
    "HistogramEngine", "ChannelStats", "WaveformEngine", "Vectorscope",
    "SharpeningEngine", "DenoisingEngine", "MotionEngine", "MotionField", "FrameInterpolationEngine",
    "optics", "VirtualCamera", "DigitalTwin", "Scene", "SceneObject", "Light", "Material", "Environment",
    "ProjectionEngine", "ProjectedPoint", "intrinsic_matrix", "extrinsic_matrix", "projection_matrix",
    "DigitalZoomEngine", "ZoomStep", "PanScanEngine", "PanScanKeyframe",
    "StabilisationEngine", "FrameTransform",
    "EffectStack", "CompositingEngine", "Layer", "BlendMode", "MaskEngine", "GraphicsEngine", "Transform2D",
    "ExportEngine", "VideoCodecBackend", "NullCodecBackend", "SUPPORTED_STILL_FORMATS",
    "CompressionCalculator", "CompressionEstimate", "TYPICAL_COMPRESSION_RATIOS",
    "StorageCalculator", "StorageReport", "PerformanceEngine", "BenchmarkResult",
    "HardwareAbstraction", "Device", "DeviceKind",
    "OperationHistory", "Project16K", "ProjectFile", "BatchProcessor", "BatchResult",
    "SimulationEngine", "SimulationStep",
]
