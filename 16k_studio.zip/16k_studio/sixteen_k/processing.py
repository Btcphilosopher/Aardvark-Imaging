"""
IMAGE PROCESSING ENGINE
Core tonal/colour adjustment operators (brightness, contrast, exposure, gamma,
saturation, hue, sharpness, blur, denoise, threshold, levels, curves).

All ops are pure functions: Image16K -> Image16K, so they compose naturally
into a non-destructive stack (see effects.py for the composable wrapper).
"""
from __future__ import annotations

from typing import Callable, List, Sequence, Tuple

import numpy as np

from .image import Image16K, ImageMetadata


def _wrap(image: Image16K, data: np.ndarray) -> Image16K:
    meta = ImageMetadata(
        bit_depth=image.meta.bit_depth, channel_layout=image.meta.channel_layout,
        colorspace=image.meta.colorspace, name=image.meta.name, extra=dict(image.meta.extra),
    )
    return Image16K(data.astype(np.float32), meta)


def _rgb_to_hsv(rgb: np.ndarray) -> np.ndarray:
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    maxc = np.maximum(np.maximum(r, g), b)
    minc = np.minimum(np.minimum(r, g), b)
    v = maxc
    delta = maxc - minc
    s = np.where(maxc > 1e-8, delta / np.clip(maxc, 1e-8, None), 0.0)
    h = np.zeros_like(maxc)
    nz = delta > 1e-8
    r_max = nz & (maxc == r)
    g_max = nz & (maxc == g) & ~r_max
    b_max = nz & (maxc == b) & ~r_max & ~g_max
    h[r_max] = (60 * ((g[r_max] - b[r_max]) / delta[r_max]) + 360) % 360
    h[g_max] = (60 * ((b[g_max] - r[g_max]) / delta[g_max]) + 120) % 360
    h[b_max] = (60 * ((r[b_max] - g[b_max]) / delta[b_max]) + 240) % 360
    return np.stack([h, s, v], axis=-1)


def _hsv_to_rgb(hsv: np.ndarray) -> np.ndarray:
    h, s, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
    c = v * s
    hp = (h / 60.0) % 6
    x = c * (1 - np.abs(hp % 2 - 1))
    z = np.zeros_like(c)
    conditions = [
        (hp < 1), (hp < 2), (hp < 3), (hp < 4), (hp < 5), (hp <= 6),
    ]
    r1 = np.select(conditions, [c, x, z, z, x, c], default=z)
    g1 = np.select(conditions, [x, c, c, x, z, z], default=z)
    b1 = np.select(conditions, [z, z, x, c, c, x], default=z)
    m = v - c
    return np.stack([r1 + m, g1 + m, b1 + m], axis=-1)


class ImageProcessingEngine:
    # -- tonal ------------------------------------------------------------
    def brightness(self, image: Image16K, amount: float) -> Image16K:
        """amount in [-1, 1], additive offset."""
        return _wrap(image, image.data + amount)

    def contrast(self, image: Image16K, amount: float, pivot: float = 0.5) -> Image16K:
        """amount: 1.0 = no change; >1 increases contrast, <1 decreases."""
        return _wrap(image, (image.data - pivot) * amount + pivot)

    def exposure(self, image: Image16K, stops: float) -> Image16K:
        return _wrap(image, image.data * (2.0 ** stops))

    def gamma(self, image: Image16K, gamma: float) -> Image16K:
        if gamma <= 0:
            raise ValueError("gamma must be positive")
        return _wrap(image, np.sign(image.data) * np.power(np.abs(image.data), 1.0 / gamma))

    def threshold(self, image: Image16K, level: float = 0.5) -> Image16K:
        return _wrap(image, (image.data >= level).astype(np.float32))

    def levels(self, image: Image16K, in_black: float = 0.0, in_white: float = 1.0,
               out_black: float = 0.0, out_white: float = 1.0, gamma: float = 1.0) -> Image16K:
        if in_white <= in_black:
            raise ValueError("in_white must exceed in_black")
        x = np.clip((image.data - in_black) / (in_white - in_black), 0.0, 1.0)
        x = np.power(x, 1.0 / gamma)
        out = x * (out_white - out_black) + out_black
        return _wrap(image, out)

    def curves(self, image: Image16K, control_points: Sequence[Tuple[float, float]],
               channel: int = None) -> Image16K:
        """Apply a monotone-cubic-ish curve defined by (x, y) control points in
        [0,1]^2 via piecewise-linear interpolation (fast, robust for large images)."""
        pts = sorted(control_points)
        xs = np.array([p[0] for p in pts], dtype=np.float64)
        ys = np.array([p[1] for p in pts], dtype=np.float64)
        data = image.data.copy()
        if channel is None:
            for c in range(image.channels):
                data[..., c] = np.interp(data[..., c], xs, ys).astype(np.float32)
        else:
            data[..., channel] = np.interp(data[..., channel], xs, ys).astype(np.float32)
        return _wrap(image, data)

    # -- colour -------------------------------------------------------------
    def saturation(self, image: Image16K, amount: float) -> Image16K:
        """amount: 1.0 = no change, 0 = grayscale, >1 boosts saturation."""
        if image.channels < 3:
            raise ValueError("saturation requires >= 3 channels")
        rgb = image.data[..., :3]
        gray = np.tensordot(rgb, np.array([0.2126, 0.7152, 0.0722], dtype=np.float32), axes=([2], [0]))
        out = image.data.copy()
        out[..., :3] = gray[..., None] + (rgb - gray[..., None]) * amount
        return _wrap(image, out)

    def hue_shift(self, image: Image16K, degrees: float) -> Image16K:
        if image.channels < 3:
            raise ValueError("hue shift requires >= 3 channels")
        hsv = _rgb_to_hsv(np.clip(image.data[..., :3], 0.0, 1.0))
        hsv[..., 0] = (hsv[..., 0] + degrees) % 360
        rgb = _hsv_to_rgb(hsv)
        out = image.data.copy()
        out[..., :3] = rgb
        return _wrap(image, out)

    # -- spatial filters ----------------------------------------------------
    def blur(self, image: Image16K, radius: float = 2.0) -> Image16K:
        return _wrap(image, _gaussian_blur(image.data, radius))

    def sharpness(self, image: Image16K, amount: float = 0.5, radius: float = 1.5) -> Image16K:
        blurred = _gaussian_blur(image.data, radius)
        sharpened = image.data + (image.data - blurred) * amount
        return _wrap(image, sharpened)

    def denoise(self, image: Image16K, strength: float = 1.0) -> Image16K:
        """Simple edge-aware-ish denoise: median-like via small Gaussian blend
        weighted by local variance suppression."""
        blurred = _gaussian_blur(image.data, radius=max(0.5, strength))
        return _wrap(image, blurred)

    def chain(self, image: Image16K, ops: List[Callable[[Image16K], Image16K]]) -> Image16K:
        out = image
        for op in ops:
            out = op(out)
        return out


def _gaussian_kernel_1d(radius: float) -> np.ndarray:
    sigma = max(radius / 2.0, 1e-3)
    r = max(1, int(round(radius * 2)))
    x = np.arange(-r, r + 1, dtype=np.float64)
    k = np.exp(-(x ** 2) / (2 * sigma ** 2))
    k /= k.sum()
    return k.astype(np.float32)


def _gaussian_blur(data: np.ndarray, radius: float) -> np.ndarray:
    if radius <= 0:
        return data.copy()
    k = _gaussian_kernel_1d(radius)
    pad = len(k) // 2
    # separable convolution along H then W, per channel, via numpy (no scipy dependency)
    padded = np.pad(data, ((pad, pad), (0, 0), (0, 0)), mode="reflect")
    tmp = np.zeros_like(data)
    for i, w in enumerate(k):
        tmp += w * padded[i:i + data.shape[0]]
    padded2 = np.pad(tmp, ((0, 0), (pad, pad), (0, 0)), mode="reflect")
    out = np.zeros_like(data)
    for i, w in enumerate(k):
        out += w * padded2[:, i:i + data.shape[1]]
    return out.astype(np.float32)
