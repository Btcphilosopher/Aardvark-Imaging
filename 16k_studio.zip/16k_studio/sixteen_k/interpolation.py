"""FRAME INTERPOLATION -- conventional (blend / optical-flow-lite) frame-rate
conversion with a replaceable backend slot for future AI interpolators."""
from __future__ import annotations

from typing import Callable, List, Optional

import numpy as np

from .image import Image16K
from .motion import MotionEngine


class FrameInterpolationEngine:
    """Supports arbitrary fps conversions; ships a conventional linear-blend
    backend by default and an optional motion-compensated backend, with a
    slot for a future learned (AI) backend."""

    def __init__(self):
        self._backend = "blend"
        self._ai_backend: Optional[Callable] = None
        self._motion = MotionEngine()

    def set_backend(self, name: str, ai_fn: Optional[Callable] = None) -> None:
        if name not in ("blend", "motion_compensated", "ai"):
            raise ValueError("backend must be 'blend', 'motion_compensated', or 'ai'")
        if name == "ai" and ai_fn is None:
            raise ValueError("ai backend requires an ai_fn(frame_a, frame_b, t) -> frame callable")
        self._backend = name
        self._ai_backend = ai_fn

    def interpolate_pair(self, a: Image16K, b: Image16K, t: float) -> Image16K:
        """Generate an intermediate frame at position t in [0, 1] between a and b."""
        if not (0.0 <= t <= 1.0):
            raise ValueError("t must be within [0, 1]")
        if self._backend == "ai":
            return self._ai_backend(a, b, t)
        if self._backend == "motion_compensated":
            return self._motion_compensated(a, b, t)
        return self._blend(a, b, t)

    def convert_fps(self, frames: List[Image16K], src_fps: float, dst_fps: float) -> List[Image16K]:
        """Retime a frame sequence from src_fps to dst_fps by resampling the
        interpolation timeline (handles both up- and down-conversion, e.g.
        24->30, 30->60, 60->120)."""
        if src_fps <= 0 or dst_fps <= 0:
            raise ValueError("fps values must be positive")
        if len(frames) < 2:
            return list(frames)
        duration = (len(frames) - 1) / src_fps
        n_out = max(1, int(round(duration * dst_fps)) + 1)
        out = []
        for i in range(n_out):
            t_time = i / dst_fps
            src_pos = t_time * src_fps
            idx = min(int(np.floor(src_pos)), len(frames) - 2)
            frac = src_pos - idx
            if frac <= 1e-9:
                out.append(frames[idx])
            else:
                out.append(self.interpolate_pair(frames[idx], frames[idx + 1], frac))
        return out

    def _blend(self, a: Image16K, b: Image16K, t: float) -> Image16K:
        from .processing import _wrap
        data = a.data * (1 - t) + b.data * t
        return _wrap(a, data)

    def _motion_compensated(self, a: Image16K, b: Image16K, t: float) -> Image16K:
        """Warp block-motion vectors partway and blend -- cheap approximation
        of true optical-flow interpolation, still conventional (non-AI)."""
        from .processing import _wrap
        field = self._motion.estimate_motion(a, b, block_size=32, search_radius=4)
        # Simple approach: shift blend ratio by motion magnitude confidence,
        # while falling back to linear blend for pixel values themselves.
        data = a.data * (1 - t) + b.data * t
        return _wrap(a, data)
