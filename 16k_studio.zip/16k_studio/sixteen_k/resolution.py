"""
RESOLUTION ENGINE
Scaling, cropping, padding and resizing across the full resolution ladder
(720p through 16K and arbitrary custom resolutions), plus a super-resolution
interface (nearest / bilinear / bicubic / Lanczos, with an extensible slot
for future ML-based upscalers).
"""
from __future__ import annotations

import enum
from typing import Optional, Tuple

import numpy as np

from .image import Image16K, ImageMetadata, RESOLUTION_PRESETS


class Interpolation(enum.Enum):
    NEAREST = "nearest"
    BILINEAR = "bilinear"
    BICUBIC = "bicubic"
    LANCZOS = "lanczos"


def _cubic_kernel(x: np.ndarray, a: float = -0.5) -> np.ndarray:
    x = np.abs(x)
    x2, x3 = x * x, x * x * x
    r = np.where(
        x <= 1,
        (a + 2) * x3 - (a + 3) * x2 + 1,
        np.where(x < 2, a * x3 - 5 * a * x2 + 8 * a * x - 4 * a, 0.0),
    )
    return r


def _lanczos_kernel(x: np.ndarray, a: int = 3) -> np.ndarray:
    x = np.asarray(x, dtype=np.float64)
    out = np.sinc(x) * np.sinc(x / a)
    out = np.where(np.abs(x) < a, out, 0.0)
    return out


def _resample_axis(src: np.ndarray, new_len: int, axis: int, kind: Interpolation) -> np.ndarray:
    """Separable 1D resampling along `axis` using a chosen kernel. Works on
    float32 arrays of arbitrary channel count. This is a from-scratch,
    dependency-free implementation (no PIL/cv2 required for the core algorithm)."""
    old_len = src.shape[axis]
    if old_len == new_len:
        return src

    scale = old_len / new_len
    dst_coords = (np.arange(new_len) + 0.5) * scale - 0.5

    if kind == Interpolation.NEAREST:
        idx = np.clip(np.round(dst_coords).astype(np.int64), 0, old_len - 1)
        return np.take(src, idx, axis=axis)

    if kind == Interpolation.BILINEAR:
        lo = np.clip(np.floor(dst_coords).astype(np.int64), 0, old_len - 1)
        hi = np.clip(lo + 1, 0, old_len - 1)
        frac = np.clip(dst_coords - lo, 0.0, 1.0)
        a = np.take(src, lo, axis=axis)
        b = np.take(src, hi, axis=axis)
        shape = [1] * src.ndim
        shape[axis] = new_len
        frac = frac.reshape(shape).astype(np.float32)
        return a * (1 - frac) + b * frac

    # BICUBIC / LANCZOS: general weighted-kernel resampling
    radius = 2 if kind == Interpolation.BICUBIC else 3
    out_shape = list(src.shape)
    out_shape[axis] = new_len
    out = np.zeros(out_shape, dtype=np.float32)
    kernel_fn = _cubic_kernel if kind == Interpolation.BICUBIC else _lanczos_kernel

    src_moved = np.moveaxis(src, axis, 0)
    out_moved = np.moveaxis(out, axis, 0)
    for i, center in enumerate(dst_coords):
        left = int(np.floor(center)) - radius + 1
        taps = np.arange(left, left + 2 * radius)
        weights = kernel_fn(center - taps).astype(np.float32)
        wsum = weights.sum()
        if wsum != 0:
            weights = weights / wsum
        clipped = np.clip(taps, 0, old_len - 1)
        acc = np.zeros(src_moved.shape[1:], dtype=np.float32)
        for w, t in zip(weights, clipped):
            if w != 0:
                acc += w * src_moved[t]
        out_moved[i] = acc
    return np.moveaxis(out_moved, 0, axis)


class ResolutionEngine:
    """All spatial resampling / cropping / padding operations."""

    PRESETS = RESOLUTION_PRESETS

    def resize(self, image: Image16K, width: int, height: int,
               method: Interpolation = Interpolation.LANCZOS) -> Image16K:
        if width <= 0 or height <= 0:
            raise ValueError("width and height must be positive")
        data = image.data
        data = _resample_axis(data, height, axis=0, kind=method)
        data = _resample_axis(data, width, axis=1, kind=method)
        return Image16K(np.clip(data, 0.0, None), _clone_meta(image))

    def scale(self, image: Image16K, factor: float,
              method: Interpolation = Interpolation.LANCZOS) -> Image16K:
        if factor <= 0:
            raise ValueError("factor must be positive")
        w = max(1, round(image.width * factor))
        h = max(1, round(image.height * factor))
        return self.resize(image, w, h, method)

    def upscale(self, image: Image16K, factor: float,
                method: Interpolation = Interpolation.LANCZOS) -> Image16K:
        if factor < 1:
            raise ValueError("upscale factor must be >= 1")
        return self.scale(image, factor, method)

    def downscale(self, image: Image16K, factor: float,
                  method: Interpolation = Interpolation.LANCZOS) -> Image16K:
        if factor > 1:
            raise ValueError("downscale factor must be <= 1")
        return self.scale(image, factor, method)

    def crop(self, image: Image16K, x: int, y: int, width: int, height: int) -> Image16K:
        if x < 0 or y < 0 or width <= 0 or height <= 0:
            raise ValueError("invalid crop rectangle")
        if x + width > image.width or y + height > image.height:
            raise ValueError("crop rectangle exceeds image bounds")
        patch = image.data[y:y + height, x:x + width].copy()
        return Image16K(patch, _clone_meta(image))

    def pad(self, image: Image16K, left: int, top: int, right: int, bottom: int,
            fill: float = 0.0) -> Image16K:
        for v in (left, top, right, bottom):
            if v < 0:
                raise ValueError("pad amounts must be non-negative")
        padded = np.pad(
            image.data,
            ((top, bottom), (left, right), (0, 0)),
            mode="constant", constant_values=fill,
        )
        return Image16K(padded, _clone_meta(image))

    def resize_to_preset(self, image: Image16K, preset: str,
                          method: Interpolation = Interpolation.LANCZOS) -> Image16K:
        if preset not in self.PRESETS:
            raise KeyError(f"Unknown resolution preset: {preset}")
        w, h = self.PRESETS[preset]
        return self.resize(image, w, h, method)

    def effective_resolution_after_crop(self, source_w: int, source_h: int,
                                         crop_w: int, crop_h: int) -> dict:
        """How much resolving power remains after cropping a region out of a
        larger master frame (used by digital zoom / pan-scan)."""
        return {
            "source": (source_w, source_h),
            "crop": (crop_w, crop_h),
            "retained_fraction_pixels": round((crop_w * crop_h) / (source_w * source_h), 6),
            "linear_zoom_factor": round(source_w / crop_w, 4) if crop_w else float("inf"),
        }


def _clone_meta(image: Image16K) -> ImageMetadata:
    return ImageMetadata(
        bit_depth=image.meta.bit_depth,
        channel_layout=image.meta.channel_layout,
        colorspace=image.meta.colorspace,
        name=image.meta.name,
        extra=dict(image.meta.extra),
    )
