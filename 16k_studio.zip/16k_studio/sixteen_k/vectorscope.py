"""VECTORSCOPE -- hue / saturation / chroma distribution for an image or frame."""
from __future__ import annotations

import numpy as np

from .image import Image16K


class Vectorscope:
    def analyze(self, image: Image16K, bins: int = 360) -> dict:
        if image.channels < 3:
            raise ValueError("vectorscope requires >= 3 channels (RGB)")
        r, g, b = image.data[..., 0], image.data[..., 1], image.data[..., 2]
        maxc = np.maximum(np.maximum(r, g), b)
        minc = np.minimum(np.minimum(r, g), b)
        delta = maxc - minc

        hue = np.zeros_like(maxc)
        nonzero = delta > 1e-8
        r_max = nonzero & (maxc == r)
        g_max = nonzero & (maxc == g) & ~r_max
        b_max = nonzero & (maxc == b) & ~r_max & ~g_max
        hue[r_max] = (60 * ((g[r_max] - b[r_max]) / delta[r_max]) + 360) % 360
        hue[g_max] = (60 * ((b[g_max] - r[g_max]) / delta[g_max]) + 120) % 360
        hue[b_max] = (60 * ((r[b_max] - g[b_max]) / delta[b_max]) + 240) % 360

        saturation = np.where(maxc > 1e-8, delta / np.clip(maxc, 1e-8, None), 0.0)
        chroma = delta

        hue_bins = np.clip((hue / 360.0 * bins).astype(np.int64), 0, bins - 1)
        hist = np.bincount(hue_bins.reshape(-1), minlength=bins)

        return {
            "hue_histogram": hist,
            "mean_hue_deg": float(hue[nonzero].mean()) if nonzero.any() else 0.0,
            "mean_saturation": float(saturation.mean()),
            "mean_chroma": float(chroma.mean()),
            "max_chroma": float(chroma.max()),
            "hue": hue, "saturation": saturation, "chroma": chroma,
        }
