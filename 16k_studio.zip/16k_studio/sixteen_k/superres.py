"""
SUPER-RESOLUTION FRAMEWORK
Conventional upscaling (nearest / bilinear / bicubic / Lanczos) is provided
by ResolutionEngine. This module adds the explicit, extensible interface for
plugging in a future ML-based super-resolution model, and is honest about
the limits of interpolation: conventional resampling cannot synthesize
information that was never captured -- it only estimates plausible values
between known samples.
"""
from __future__ import annotations

from typing import Callable, Dict, Optional

import numpy as np

from .image import Image16K, ImageMetadata
from .resolution import ResolutionEngine, Interpolation


class SuperResolutionEngine:
    """Extensible super-resolution front-end. Ships conventional
    interpolation kernels out of the box; ML backends can be registered at
    runtime and selected explicitly, so the distinction between "resampled"
    and "model-synthesized" output is always clear to the caller."""

    def __init__(self):
        self._res = ResolutionEngine()
        self._ml_backends: Dict[str, Callable[[np.ndarray, float], np.ndarray]] = {}

    def upscale_conventional(self, image: Image16K, factor: float,
                              method: Interpolation = Interpolation.LANCZOS) -> Image16K:
        """Conventional (non-generative) upscaling. Does NOT create genuine
        new information -- it only interpolates between existing samples."""
        return self._res.upscale(image, factor, method)

    def register_ml_backend(self, name: str, fn: Callable[[np.ndarray, float], np.ndarray]) -> None:
        """Register a future learned super-resolution backend. `fn` takes a
        (H, W, C) float32 array in [0, 1] plus a scale factor, and returns
        the upscaled array."""
        self._ml_backends[name] = fn

    def available_ml_backends(self):
        return list(self._ml_backends.keys())

    def upscale_ml(self, image: Image16K, factor: float, backend: str) -> Image16K:
        if backend not in self._ml_backends:
            raise KeyError(
                f"No ML super-resolution backend registered under '{backend}'. "
                f"Available: {self.available_ml_backends()}"
            )
        data = self._ml_backends[backend](image.data, factor)
        meta = ImageMetadata(
            bit_depth=image.meta.bit_depth, channel_layout=image.meta.channel_layout,
            colorspace=image.meta.colorspace, name=image.meta.name,
            extra={**image.meta.extra, "super_resolution_backend": backend},
        )
        return Image16K(data, meta)

    def upscale(self, image: Image16K, factor: float, backend: Optional[str] = None,
                method: Interpolation = Interpolation.LANCZOS) -> Image16K:
        """Convenience dispatcher: uses a registered ML backend if named,
        otherwise falls back to conventional interpolation."""
        if backend is not None:
            return self.upscale_ml(image, factor, backend)
        return self.upscale_conventional(image, factor, method)
