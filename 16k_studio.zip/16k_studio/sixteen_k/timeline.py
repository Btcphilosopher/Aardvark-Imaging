"""
16K TIMELINE
Professional multi-track timeline model: video / image / audio / effect /
overlay tracks, with clip-level cut / trim / split / merge / move / duplicate
/ speed-change / reverse / freeze-frame operations.
"""
from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import List, Optional

from .video import VideoProject


class TrackType(enum.Enum):
    VIDEO = "video"
    IMAGE = "image"
    AUDIO = "audio"
    EFFECT = "effect"
    OVERLAY = "overlay"


@dataclass
class Clip:
    name: str
    source: VideoProject                # underlying frame source
    in_frame: int                       # first source frame index used (inclusive)
    out_frame: int                      # last source frame index used (exclusive)
    start_on_track: int = 0             # position (in track-frames) where clip begins
    speed: float = 1.0                  # playback speed multiplier
    reversed: bool = False
    frozen_at: Optional[int] = None     # if set, clip is a still hold of this source frame

    @property
    def source_length(self) -> int:
        return self.out_frame - self.in_frame

    @property
    def track_length(self) -> int:
        """Length on the track timeline, accounting for speed changes."""
        if self.frozen_at is not None:
            return self.source_length
        return max(1, round(self.source_length / self.speed))

    def resolve_frame(self, track_offset: int):
        """Given a 0-based offset into this clip (in track-frames), return the
        corresponding source frame index."""
        if track_offset < 0 or track_offset >= self.track_length:
            raise IndexError("track_offset out of clip range")
        if self.frozen_at is not None:
            return self.frozen_at
        src_offset = int(round(track_offset * self.speed))
        src_offset = min(src_offset, self.source_length - 1)
        if self.reversed:
            return self.out_frame - 1 - src_offset
        return self.in_frame + src_offset


@dataclass
class Track:
    kind: TrackType
    name: str
    clips: List[Clip] = field(default_factory=list)

    def add_clip(self, clip: Clip) -> None:
        self.clips.append(clip)
        self.clips.sort(key=lambda c: c.start_on_track)

    def clip_at(self, track_frame: int) -> Optional[Clip]:
        for c in self.clips:
            if c.start_on_track <= track_frame < c.start_on_track + c.track_length:
                return c
        return None

    @property
    def length(self) -> int:
        if not self.clips:
            return 0
        return max(c.start_on_track + c.track_length for c in self.clips)


class Timeline:
    def __init__(self, fps: float, name: str = "timeline"):
        self.fps = fps
        self.name = name
        self.tracks: List[Track] = []

    def add_track(self, kind: TrackType, name: str) -> Track:
        t = Track(kind=kind, name=name)
        self.tracks.append(t)
        return t

    @property
    def length_frames(self) -> int:
        return max((t.length for t in self.tracks), default=0)

    @property
    def duration_seconds(self) -> float:
        return self.length_frames / self.fps if self.fps else 0.0

    # -- clip operations -----------------------------------------------------
    def cut(self, track: Track, at_frame: int) -> None:
        """Alias for split at the playhead (non-destructive: produces two clips)."""
        self.split(track, at_frame)

    def trim(self, clip: Clip, new_in: Optional[int] = None, new_out: Optional[int] = None) -> None:
        if new_in is not None:
            if not (0 <= new_in < clip.out_frame):
                raise ValueError("invalid new_in")
            clip.in_frame = new_in
        if new_out is not None:
            if not (clip.in_frame < new_out):
                raise ValueError("invalid new_out")
            clip.out_frame = new_out

    def split(self, track: Track, at_track_frame: int) -> Optional[tuple]:
        clip = track.clip_at(at_track_frame)
        if clip is None:
            return None
        local_offset = at_track_frame - clip.start_on_track
        if local_offset <= 0 or local_offset >= clip.track_length:
            return None
        src_split = clip.resolve_frame(local_offset)

        left = Clip(name=clip.name + "_a", source=clip.source, in_frame=clip.in_frame,
                    out_frame=src_split, start_on_track=clip.start_on_track,
                    speed=clip.speed, reversed=clip.reversed)
        right = Clip(name=clip.name + "_b", source=clip.source, in_frame=src_split,
                     out_frame=clip.out_frame, start_on_track=at_track_frame,
                     speed=clip.speed, reversed=clip.reversed)
        track.clips.remove(clip)
        track.add_clip(left)
        track.add_clip(right)
        return left, right

    def merge(self, track: Track, clip_a: Clip, clip_b: Clip) -> Clip:
        """Merge two adjacent, same-source, same-speed clips into one."""
        if clip_a.source is not clip_b.source:
            raise ValueError("can only merge clips from the same source")
        if clip_a.speed != clip_b.speed or clip_a.reversed != clip_b.reversed:
            raise ValueError("can only merge clips with matching speed/direction")
        first, second = (clip_a, clip_b) if clip_a.start_on_track <= clip_b.start_on_track else (clip_b, clip_a)
        if first.out_frame != second.in_frame:
            raise ValueError("clips are not contiguous in source frames; cannot merge cleanly")
        merged = Clip(name=first.name + "_merged", source=first.source, in_frame=first.in_frame,
                      out_frame=second.out_frame, start_on_track=first.start_on_track,
                      speed=first.speed, reversed=first.reversed)
        track.clips.remove(clip_a)
        track.clips.remove(clip_b)
        track.add_clip(merged)
        return merged

    def move(self, clip: Clip, new_start: int) -> None:
        if new_start < 0:
            raise ValueError("new_start must be non-negative")
        clip.start_on_track = new_start

    def duplicate(self, track: Track, clip: Clip, new_start: int) -> Clip:
        dup = Clip(name=clip.name + "_copy", source=clip.source, in_frame=clip.in_frame,
                   out_frame=clip.out_frame, start_on_track=new_start,
                   speed=clip.speed, reversed=clip.reversed, frozen_at=clip.frozen_at)
        track.add_clip(dup)
        return dup

    def set_speed(self, clip: Clip, speed: float) -> None:
        if speed <= 0:
            raise ValueError("speed must be positive")
        clip.speed = speed

    def reverse(self, clip: Clip) -> None:
        clip.reversed = not clip.reversed

    def freeze_frame(self, clip: Clip, at_source_frame: int, hold_length: int) -> Clip:
        """Insert a still-frame hold clip on the same source, `hold_length`
        track-frames long, positioned right after `clip`."""
        frozen = Clip(name=clip.name + "_freeze", source=clip.source,
                      in_frame=at_source_frame, out_frame=at_source_frame + hold_length,
                      start_on_track=clip.start_on_track + clip.track_length,
                      frozen_at=at_source_frame)
        return frozen
