"""
MASK ENGINE
Rectangular, elliptical, polygon, gradient, and animated masks. All masks
are generated at full source resolution (16K-safe -- pure numpy vectorised
math, no per-pixel Python loops) as (H, W) float32 arrays in [0, 1].
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, List, Tuple

import numpy as np


class MaskEngine:
    def rectangular(self, width: int, height: int, x: int, y: int, w: int, h: int,
                     feather: float = 0.0) -> np.ndarray:
        mask = np.zeros((height, width), dtype=np.float32)
        x0, y0 = max(0, x), max(0, y)
        x1, y1 = min(width, x + w), min(height, y + h)
        if x1 > x0 and y1 > y0:
            mask[y0:y1, x0:x1] = 1.0
        if feather > 0:
            mask = self._feather(mask, feather)
        return mask

    def elliptical(self, width: int, height: int, cx: float, cy: float,
                   rx: float, ry: float, feather: float = 0.0) -> np.ndarray:
        yy, xx = np.mgrid[0:height, 0:width].astype(np.float32)
        norm = ((xx - cx) / max(rx, 1e-6)) ** 2 + ((yy - cy) / max(ry, 1e-6)) ** 2
        if feather > 0:
            edge = feather / max(rx, ry, 1e-6)
            mask = 1.0 - np.clip((np.sqrt(norm) - (1 - edge)) / max(edge, 1e-6), 0.0, 1.0)
            mask = np.clip(mask, 0.0, 1.0)
        else:
            mask = (norm <= 1.0).astype(np.float32)
        return mask

    def polygon(self, width: int, height: int, points: List[Tuple[float, float]],
                feather: float = 0.0) -> np.ndarray:
        """Point-in-polygon test vectorised across the whole raster via the
        standard ray-casting algorithm."""
        yy, xx = np.mgrid[0:height, 0:width].astype(np.float64)
        px = xx.reshape(-1)
        py = yy.reshape(-1)
        n = len(points)
        inside = np.zeros(px.shape, dtype=bool)
        j = n - 1
        for i in range(n):
            xi, yi = points[i]
            xj, yj = points[j]
            cond = ((yi > py) != (yj > py))
            with np.errstate(divide="ignore", invalid="ignore"):
                x_intersect = (xj - xi) * (py - yi) / (yj - yi + 1e-12) + xi
            crosses = cond & (px < x_intersect)
            inside ^= crosses
            j = i
        mask = inside.reshape(height, width).astype(np.float32)
        if feather > 0:
            mask = self._feather(mask, feather)
        return mask

    def linear_gradient(self, width: int, height: int, start: Tuple[float, float],
                         end: Tuple[float, float], start_value: float = 0.0,
                         end_value: float = 1.0) -> np.ndarray:
        yy, xx = np.mgrid[0:height, 0:width].astype(np.float64)
        sx, sy = start
        ex, ey = end
        dx, dy = ex - sx, ey - sy
        length2 = dx ** 2 + dy ** 2
        if length2 < 1e-9:
            return np.full((height, width), start_value, dtype=np.float32)
        t = ((xx - sx) * dx + (yy - sy) * dy) / length2
        t = np.clip(t, 0.0, 1.0)
        return (start_value + (end_value - start_value) * t).astype(np.float32)

    def radial_gradient(self, width: int, height: int, cx: float, cy: float,
                        radius: float, inner_value: float = 1.0, outer_value: float = 0.0) -> np.ndarray:
        yy, xx = np.mgrid[0:height, 0:width].astype(np.float64)
        dist = np.hypot(xx - cx, yy - cy)
        t = np.clip(dist / max(radius, 1e-6), 0.0, 1.0)
        return (inner_value + (outer_value - inner_value) * t).astype(np.float32)

    def animated(self, width: int, height: int, frame_count: int,
                 generator: Callable[[int], np.ndarray]) -> List[np.ndarray]:
        """`generator(frame_index)` returns an (H, W) mask for that frame; this
        is the hook animated masks (tracking, keyframed shapes, etc.) plug into."""
        return [generator(i) for i in range(frame_count)]

    # -- combination -------------------------------------------------------
    def invert(self, mask: np.ndarray) -> np.ndarray:
        return 1.0 - mask

    def combine_and(self, a: np.ndarray, b: np.ndarray) -> np.ndarray:
        return a * b

    def combine_or(self, a: np.ndarray, b: np.ndarray) -> np.ndarray:
        return np.clip(a + b - a * b, 0.0, 1.0)

    def combine_subtract(self, a: np.ndarray, b: np.ndarray) -> np.ndarray:
        return np.clip(a - b, 0.0, 1.0)

    def _feather(self, mask: np.ndarray, radius: float) -> np.ndarray:
        from .processing import _gaussian_blur
        m3 = mask[..., None]
        blurred = _gaussian_blur(m3, radius)
        return np.clip(blurred[..., 0], 0.0, 1.0)
