"""DENOISING ENGINE -- Gaussian, median, bilateral, temporal denoising, plus an
extensible interface for future ML-based denoisers."""
from __future__ import annotations

from typing import Callable, List, Optional

import numpy as np

from .image import Image16K
from .processing import _gaussian_blur, _wrap


class DenoisingEngine:
    #: registry of pluggable ML backends: name -> callable(np.ndarray) -> np.ndarray
    ml_backends: dict = {}

    def gaussian(self, image: Image16K, radius: float = 1.5) -> Image16K:
        return _wrap(image, _gaussian_blur(image.data, radius))

    def median(self, image: Image16K, window: int = 3) -> Image16K:
        if window % 2 == 0 or window < 1:
            raise ValueError("window must be a positive odd integer")
        pad = window // 2
        padded = np.pad(image.data, ((pad, pad), (pad, pad), (0, 0)), mode="reflect")
        h, w, c = image.data.shape
        stack = np.empty((window * window, h, w, c), dtype=np.float32)
        idx = 0
        for dy in range(window):
            for dx in range(window):
                stack[idx] = padded[dy:dy + h, dx:dx + w]
                idx += 1
        out = np.median(stack, axis=0)
        return _wrap(image, out)

    def bilateral(self, image: Image16K, radius: int = 3, sigma_space: float = 3.0,
                  sigma_range: float = 0.15) -> Image16K:
        """Edge-preserving smoothing: nearby AND similar-valued pixels are
        weighted more; dissimilar (edge-crossing) pixels are down-weighted."""
        data = image.data
        h, w, c = data.shape
        padded = np.pad(data, ((radius, radius), (radius, radius), (0, 0)), mode="reflect")
        acc = np.zeros_like(data, dtype=np.float64)
        wsum = np.zeros((h, w, 1), dtype=np.float64)
        for dy in range(-radius, radius + 1):
            for dx in range(-radius, radius + 1):
                neighbor = padded[radius + dy:radius + dy + h, radius + dx:radius + dx + w]
                spatial_w = np.exp(-(dx ** 2 + dy ** 2) / (2 * sigma_space ** 2))
                range_diff = np.sum((neighbor - data) ** 2, axis=-1, keepdims=True)
                range_w = np.exp(-range_diff / (2 * sigma_range ** 2))
                weight = spatial_w * range_w
                acc += neighbor * weight
                wsum += weight
        out = (acc / np.clip(wsum, 1e-9, None)).astype(np.float32)
        return _wrap(image, out)

    def temporal(self, frames: List[Image16K], strength: float = 0.5) -> Image16K:
        """Temporal denoise: blend the center frame with a weighted average of
        its neighbours (odd-length sliding window). `strength` in [0,1] controls
        how much of the temporal average is mixed in vs. the original frame."""
        if len(frames) < 2:
            return frames[0] if frames else None
        center = len(frames) // 2
        stacked = np.stack([f.data for f in frames], axis=0)
        avg = stacked.mean(axis=0)
        out = frames[center].data * (1 - strength) + avg * strength
        return _wrap(frames[center], out)

    def register_ml_backend(self, name: str, fn: Callable[[np.ndarray], np.ndarray]) -> None:
        """Extensible slot for future learned denoisers -- fn takes/returns a
        (H, W, C) float32 array in [0, 1]."""
        self.ml_backends[name] = fn

    def apply_ml_backend(self, image: Image16K, name: str) -> Image16K:
        if name not in self.ml_backends:
            raise KeyError(f"No ML denoise backend registered under '{name}'")
        return _wrap(image, self.ml_backends[name](image.data))
