"""
EFFECTS ENGINE
Non-destructive, composable effects stack: blur, glow, vignette, sharpen,
grain, noise, colour adjustment, distortion, chromatic aberration, lens
effects. Effects are represented as an ordered list of operations that are
only "baked" (applied) on demand, so the source pixels are never mutated
until `render()` is called.

    image_effects = EffectStack(image)
    result = (
        image_effects
        .exposure(0.2)
        .vignette(0.4)
        .sharpen(0.3)
        .render()
    )
"""
from __future__ import annotations

from typing import Callable, List

import numpy as np

from .image import Image16K
from .processing import ImageProcessingEngine, _gaussian_blur, _wrap
from .colour import ColourEngine

_proc = ImageProcessingEngine()
_colour = ColourEngine()


def fx_blur(radius: float = 3.0) -> Callable[[Image16K], Image16K]:
    return lambda img: _proc.blur(img, radius)


def fx_sharpen(amount: float = 0.5, radius: float = 1.5) -> Callable[[Image16K], Image16K]:
    return lambda img: _proc.sharpness(img, amount, radius)


def fx_glow(intensity: float = 0.5, radius: float = 8.0, threshold: float = 0.7) -> Callable[[Image16K], Image16K]:
    def op(img: Image16K) -> Image16K:
        bright = np.clip(img.data - threshold, 0.0, None) / max(1e-6, 1.0 - threshold)
        bloom = _gaussian_blur(bright, radius)
        return _wrap(img, img.data + bloom * intensity)
    return op


def fx_vignette(strength: float = 0.5, radius: float = 0.75, softness: float = 0.4) -> Callable[[Image16K], Image16K]:
    def op(img: Image16K) -> Image16K:
        h, w = img.height, img.width
        yy, xx = np.mgrid[0:h, 0:w]
        cx, cy = w / 2.0, h / 2.0
        max_r = np.hypot(cx, cy)
        dist = np.hypot(xx - cx, yy - cy) / max_r
        falloff = 1.0 - np.clip((dist - radius) / max(1e-6, softness), 0.0, 1.0) * strength
        return _wrap(img, img.data * falloff[..., None])
    return op


def fx_grain(amount: float = 0.05, seed: int = None) -> Callable[[Image16K], Image16K]:
    def op(img: Image16K) -> Image16K:
        rng = np.random.default_rng(seed)
        noise = rng.normal(0.0, amount, size=img.data.shape).astype(np.float32)
        return _wrap(img, img.data + noise)
    return op


def fx_noise(amount: float = 0.05, seed: int = None) -> Callable[[Image16K], Image16K]:
    def op(img: Image16K) -> Image16K:
        rng = np.random.default_rng(seed)
        noise = rng.uniform(-amount, amount, size=img.data.shape).astype(np.float32)
        return _wrap(img, img.data + noise)
    return op


def fx_colour_adjust(exposure: float = 0.0, contrast: float = 1.0, saturation: float = 1.0) -> Callable[[Image16K], Image16K]:
    def op(img: Image16K) -> Image16K:
        out = _proc.exposure(img, exposure)
        out = _proc.contrast(out, contrast)
        out = _proc.saturation(out, saturation)
        return out
    return op


def fx_distortion(k1: float = 0.0, k2: float = 0.0) -> Callable[[Image16K], Image16K]:
    """Radial (barrel/pincushion) lens distortion, Brown-Conrady model, applied
    via inverse mapping + bilinear sampling."""
    def op(img: Image16K) -> Image16K:
        h, w, c = img.data.shape
        cy, cx = h / 2.0, w / 2.0
        yy, xx = np.mgrid[0:h, 0:w].astype(np.float64)
        nx = (xx - cx) / cx
        ny = (yy - cy) / cy
        r2 = nx ** 2 + ny ** 2
        factor = 1 + k1 * r2 + k2 * r2 ** 2
        src_x = nx * factor * cx + cx
        src_y = ny * factor * cy + cy
        src_x = np.clip(src_x, 0, w - 1)
        src_y = np.clip(src_y, 0, h - 1)
        x0 = np.floor(src_x).astype(np.int64)
        y0 = np.floor(src_y).astype(np.int64)
        x1 = np.clip(x0 + 1, 0, w - 1)
        y1 = np.clip(y0 + 1, 0, h - 1)
        fx = (src_x - x0)[..., None]
        fy = (src_y - y0)[..., None]
        d = img.data
        top = d[y0, x0] * (1 - fx) + d[y0, x1] * fx
        bot = d[y1, x0] * (1 - fx) + d[y1, x1] * fx
        out = (top * (1 - fy) + bot * fy).astype(np.float32)
        return _wrap(img, out)
    return op


def fx_chromatic_aberration(shift_px: float = 2.0) -> Callable[[Image16K], Image16K]:
    """Radially-increasing R/B channel shift, mimicking lateral CA."""
    def op(img: Image16K) -> Image16K:
        if img.channels < 3:
            return img
        h, w, c = img.data.shape
        cy, cx = h / 2.0, w / 2.0
        yy, xx = np.mgrid[0:h, 0:w].astype(np.float64)
        dx, dy = xx - cx, yy - cy
        dist = np.hypot(dx, dy)
        max_dist = np.hypot(cx, cy)
        norm = np.where(max_dist > 0, dist / max_dist, 0.0)
        theta = np.arctan2(dy, dx)

        def shifted_channel(channel: np.ndarray, px: float) -> np.ndarray:
            sx = xx + np.cos(theta) * norm * px
            sy = yy + np.sin(theta) * norm * px
            sx = np.clip(sx, 0, w - 1)
            sy = np.clip(sy, 0, h - 1)
            x0 = np.floor(sx).astype(np.int64); x1 = np.clip(x0 + 1, 0, w - 1)
            y0 = np.floor(sy).astype(np.int64); y1 = np.clip(y0 + 1, 0, h - 1)
            fx = sx - x0; fy = sy - y0
            top = channel[y0, x0] * (1 - fx) + channel[y0, x1] * fx
            bot = channel[y1, x0] * (1 - fx) + channel[y1, x1] * fx
            return (top * (1 - fy) + bot * fy).astype(np.float32)

        out = img.data.copy()
        out[..., 0] = shifted_channel(img.data[..., 0], shift_px)
        out[..., 2] = shifted_channel(img.data[..., 2], -shift_px)
        return _wrap(img, out)
    return op


def fx_lens_flare(position=(0.7, 0.3), intensity: float = 0.6, radius: float = 40.0) -> Callable[[Image16K], Image16K]:
    def op(img: Image16K) -> Image16K:
        h, w, c = img.data.shape
        px, py = position[0] * w, position[1] * h
        yy, xx = np.mgrid[0:h, 0:w]
        dist = np.hypot(xx - px, yy - py)
        core = np.exp(-(dist ** 2) / (2 * radius ** 2)) * intensity
        flare = np.stack([core, core * 0.9, core * 0.7], axis=-1) if c >= 3 else core[..., None]
        if flare.shape[-1] < c:
            flare = np.pad(flare, ((0, 0), (0, 0), (0, c - flare.shape[-1])))
        return _wrap(img, img.data + flare[..., :c])
    return op


class EffectStack:
    """A non-destructive, composable chain of effects over a source Image16K."""

    def __init__(self, image: Image16K):
        self._source = image
        self._ops: List[Callable[[Image16K], Image16K]] = []

    def apply(self, op: Callable[[Image16K], Image16K]) -> "EffectStack":
        self._ops.append(op)
        return self

    def blur(self, radius: float = 3.0) -> "EffectStack": return self.apply(fx_blur(radius))
    def sharpen(self, amount: float = 0.5, radius: float = 1.5) -> "EffectStack": return self.apply(fx_sharpen(amount, radius))
    def glow(self, intensity: float = 0.5, radius: float = 8.0, threshold: float = 0.7) -> "EffectStack": return self.apply(fx_glow(intensity, radius, threshold))
    def vignette(self, strength: float = 0.5, radius: float = 0.75, softness: float = 0.4) -> "EffectStack": return self.apply(fx_vignette(strength, radius, softness))
    def grain(self, amount: float = 0.05, seed: int = None) -> "EffectStack": return self.apply(fx_grain(amount, seed))
    def noise(self, amount: float = 0.05, seed: int = None) -> "EffectStack": return self.apply(fx_noise(amount, seed))
    def exposure(self, stops: float) -> "EffectStack": return self.apply(lambda img: _proc.exposure(img, stops))
    def colour_adjust(self, exposure: float = 0.0, contrast: float = 1.0, saturation: float = 1.0) -> "EffectStack":
        return self.apply(fx_colour_adjust(exposure, contrast, saturation))
    def distortion(self, k1: float = 0.0, k2: float = 0.0) -> "EffectStack": return self.apply(fx_distortion(k1, k2))
    def chromatic_aberration(self, shift_px: float = 2.0) -> "EffectStack": return self.apply(fx_chromatic_aberration(shift_px))
    def lens_flare(self, position=(0.7, 0.3), intensity: float = 0.6, radius: float = 40.0) -> "EffectStack":
        return self.apply(fx_lens_flare(position, intensity, radius))

    def render(self) -> Image16K:
        out = self._source
        for op in self._ops:
            out = op(out)
        return out

    def preview_op_count(self) -> int:
        return len(self._ops)
