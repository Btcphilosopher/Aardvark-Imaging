"""
STORAGE CALCULATOR
Given resolution, FPS, bit depth, channels, compression and duration,
calculate total storage requirement across MB / GB / TB / PB.
"""
from __future__ import annotations

from dataclasses import dataclass

from .image import BitDepth
from .compression import CompressionCalculator, TYPICAL_COMPRESSION_RATIOS


@dataclass
class StorageReport:
    total_bytes: int

    @property
    def mb(self) -> float: return self.total_bytes / (1024 ** 2)
    @property
    def gb(self) -> float: return self.total_bytes / (1024 ** 3)
    @property
    def tb(self) -> float: return self.total_bytes / (1024 ** 4)
    @property
    def pb(self) -> float: return self.total_bytes / (1024 ** 5)

    def as_dict(self) -> dict:
        return {
            "bytes": self.total_bytes,
            "mb": round(self.mb, 4),
            "gb": round(self.gb, 6),
            "tb": round(self.tb, 9),
            "pb": round(self.pb, 12),
        }


class StorageCalculator:
    def __init__(self):
        self._compression = CompressionCalculator()

    def calculate(self, width: int, height: int, fps: float, bit_depth: BitDepth,
                  channels: int, compression: str, duration_seconds: float) -> StorageReport:
        if compression not in TYPICAL_COMPRESSION_RATIOS:
            raise KeyError(f"Unknown compression scheme '{compression}'")
        per_frame = self._compression.estimate(width, height, channels, bit_depth, compression)
        total_frames = duration_seconds * fps
        total_bytes = round(per_frame.compressed_bytes * total_frames)
        return StorageReport(total_bytes=total_bytes)

    def full_report(self, width: int, height: int, fps: float, bit_depth: BitDepth,
                    channels: int, compression: str, duration_seconds: float) -> dict:
        report = self.calculate(width, height, fps, bit_depth, channels, compression, duration_seconds)
        return {
            "resolution": (width, height), "fps": fps, "bit_depth": int(BitDepth(bit_depth)),
            "channels": channels, "compression": compression,
            "duration_seconds": duration_seconds,
            **report.as_dict(),
        }
