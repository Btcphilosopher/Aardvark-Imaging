"""
TILE ENGINE
Divides very large image buffers into computational tiles so that operations
which would otherwise require the full frame resident in RAM can run
tile-by-tile, then be losslessly reassembled.

Tiles carry an overlap ("halo") so that spatially-aware filters (blur,
sharpen, denoise, convolution-based effects) do not produce visible seams at
tile boundaries: the halo region is processed but trimmed before stitching.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, List

import numpy as np

from .image import Image16K, ImageMetadata


@dataclass
class Tile:
    data: np.ndarray          # padded (with halo) tile data, (th, tw, C)
    x: int                    # unpadded x origin in the source image
    y: int                    # unpadded y origin in the source image
    width: int                # unpadded width
    height: int               # unpadded height
    halo: int                 # halo size actually applied on each side (clamped at edges)
    halo_left: int
    halo_top: int

    def core(self) -> np.ndarray:
        """Return just the unpadded region of this tile's data (post-processing)."""
        return self.data[self.halo_top:self.halo_top + self.height,
                          self.halo_left:self.halo_left + self.width]


class TileEngine:
    def __init__(self, tile_size: int = 1024, halo: int = 16):
        if tile_size <= 0:
            raise ValueError("tile_size must be positive")
        if halo < 0:
            raise ValueError("halo must be non-negative")
        self.tile_size = tile_size
        self.halo = halo

    def split_into_tiles(self, image: Image16K) -> List[Tile]:
        h, w = image.height, image.width
        ts = self.tile_size
        halo = self.halo
        tiles: List[Tile] = []
        for ty in range(0, h, ts):
            for tx in range(0, w, ts):
                tw = min(ts, w - tx)
                th = min(ts, h - ty)
                halo_left = min(halo, tx)
                halo_top = min(halo, ty)
                halo_right = min(halo, w - (tx + tw))
                halo_bottom = min(halo, h - (ty + th))
                y0, y1 = ty - halo_top, ty + th + halo_bottom
                x0, x1 = tx - halo_left, tx + tw + halo_right
                patch = image.data[y0:y1, x0:x1].copy()
                tiles.append(Tile(
                    data=patch, x=tx, y=ty, width=tw, height=th,
                    halo=halo, halo_left=halo_left, halo_top=halo_top,
                ))
        return tiles

    def process_tile(self, tile: Tile, op: Callable[[np.ndarray], np.ndarray]) -> Tile:
        """Apply `op` (an array -> array function) to the padded tile data, and
        return a new Tile with processed data. `op` may use the halo region for
        context (e.g. a blur kernel) -- it will be trimmed away later."""
        processed = op(tile.data)
        if processed.shape != tile.data.shape:
            raise ValueError(
                f"Tile op must preserve shape: got {processed.shape}, expected {tile.data.shape}"
            )
        return Tile(
            data=processed, x=tile.x, y=tile.y, width=tile.width, height=tile.height,
            halo=tile.halo, halo_left=tile.halo_left, halo_top=tile.halo_top,
        )

    def process_all(self, tiles: List[Tile], op: Callable[[np.ndarray], np.ndarray]) -> List[Tile]:
        return [self.process_tile(t, op) for t in tiles]

    def reassemble_tiles(self, tiles: List[Tile], width: int, height: int,
                          channels: int, meta: ImageMetadata = None) -> Image16K:
        out = np.zeros((height, width, channels), dtype=np.float32)
        for t in tiles:
            core = t.core()
            out[t.y:t.y + t.height, t.x:t.x + t.width] = core
        return Image16K(out, meta or ImageMetadata())

    def process_image(self, image: Image16K, op: Callable[[np.ndarray], np.ndarray]) -> Image16K:
        """Convenience: split -> process -> reassemble in one call."""
        tiles = self.split_into_tiles(image)
        processed = self.process_all(tiles, op)
        return self.reassemble_tiles(processed, image.width, image.height, image.channels, image.meta)
