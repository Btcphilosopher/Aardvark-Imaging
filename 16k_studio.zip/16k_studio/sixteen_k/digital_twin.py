"""
DIGITAL TWIN
A lightweight scene graph representing the virtual camera plus the visual
scene it observes: lights, objects, materials, environment. Provides
camera.move()/rotate()/look_at() (delegated to VirtualCamera) and
scene.add_object()/add_light().
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from .camera import VirtualCamera


@dataclass
class Material:
    name: str = "default"
    albedo: Tuple[float, float, float] = (0.8, 0.8, 0.8)
    roughness: float = 0.5
    metallic: float = 0.0
    emissive: Tuple[float, float, float] = (0.0, 0.0, 0.0)


@dataclass
class SceneObject:
    name: str
    position: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    rotation_deg: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    scale: Tuple[float, float, float] = (1.0, 1.0, 1.0)
    material: Material = field(default_factory=Material)
    bounding_radius: float = 1.0

    def move(self, dx: float = 0.0, dy: float = 0.0, dz: float = 0.0) -> None:
        x, y, z = self.position
        self.position = (x + dx, y + dy, z + dz)


@dataclass
class Light:
    name: str
    kind: str = "point"  # point | directional | spot | area
    position: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    direction: Tuple[float, float, float] = (0.0, -1.0, 0.0)
    color: Tuple[float, float, float] = (1.0, 1.0, 1.0)
    intensity: float = 1.0


@dataclass
class Environment:
    ambient_color: Tuple[float, float, float] = (0.05, 0.05, 0.05)
    background: Optional[Tuple[float, float, float]] = None
    fog_density: float = 0.0


class Scene:
    def __init__(self, name: str = "scene"):
        self.name = name
        self.objects: Dict[str, SceneObject] = {}
        self.lights: Dict[str, Light] = {}
        self.environment = Environment()

    def add_object(self, obj: SceneObject) -> SceneObject:
        self.objects[obj.name] = obj
        return obj

    def add_light(self, light: Light) -> Light:
        self.lights[light.name] = light
        return light

    def remove_object(self, name: str) -> None:
        self.objects.pop(name, None)

    def remove_light(self, name: str) -> None:
        self.lights.pop(name, None)

    def describe(self) -> dict:
        return {
            "name": self.name,
            "object_count": len(self.objects),
            "light_count": len(self.lights),
            "objects": list(self.objects.keys()),
            "lights": list(self.lights.keys()),
        }


class DigitalTwin:
    """Bundles a VirtualCamera with a Scene it observes."""

    def __init__(self, camera: Optional[VirtualCamera] = None, scene: Optional[Scene] = None):
        self.camera = camera or VirtualCamera()
        self.scene = scene or Scene()

    def snapshot_state(self) -> dict:
        return {
            "camera": self.camera.describe(),
            "scene": self.scene.describe(),
        }
