"""SHARPENING ENGINE -- unsharp mask, high-pass, edge enhancement, adaptive sharpening."""
from __future__ import annotations

import numpy as np

from .image import Image16K
from .processing import _gaussian_blur, _wrap


class SharpeningEngine:
    def unsharp_mask(self, image: Image16K, amount: float = 1.0, radius: float = 2.0,
                      threshold: float = 0.0) -> Image16K:
        blurred = _gaussian_blur(image.data, radius)
        diff = image.data - blurred
        if threshold > 0:
            mask = np.abs(diff) >= threshold
            diff = diff * mask
        return _wrap(image, image.data + diff * amount)

    def high_pass(self, image: Image16K, radius: float = 3.0) -> Image16K:
        blurred = _gaussian_blur(image.data, radius)
        hp = (image.data - blurred) + 0.5
        return _wrap(image, np.clip(hp, 0.0, 1.0))

    def edge_enhance(self, image: Image16K, amount: float = 1.0) -> Image16K:
        """Laplacian-style edge enhancement via a discrete kernel."""
        k = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]], dtype=np.float32)
        out = _convolve3x3(image.data, k)
        blended = image.data + (out - image.data) * amount
        return _wrap(image, blended)

    def adaptive_sharpen(self, image: Image16K, amount: float = 1.0, radius: float = 2.0,
                          edge_sensitivity: float = 2.0) -> Image16K:
        """Sharpens more aggressively in high-local-variance (edge/texture)
        regions and less in flat regions, reducing halo/noise amplification."""
        blurred = _gaussian_blur(image.data, radius)
        local_var = _gaussian_blur((image.data - blurred) ** 2, radius)
        weight = np.clip(local_var * edge_sensitivity, 0.0, 1.0)
        diff = image.data - blurred
        return _wrap(image, image.data + diff * amount * weight)


def _convolve3x3(data: np.ndarray, kernel: np.ndarray) -> np.ndarray:
    padded = np.pad(data, ((1, 1), (1, 1), (0, 0)), mode="reflect")
    out = np.zeros_like(data)
    for dy in range(3):
        for dx in range(3):
            w = kernel[dy, dx]
            if w == 0:
                continue
            out += w * padded[dy:dy + data.shape[0], dx:dx + data.shape[1]]
    return out
