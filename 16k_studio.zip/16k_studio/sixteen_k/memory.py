"""
MEMORY ENGINE
16K frames are enormous (15360x8640x3 @ 16-bit ~= 796 MB per frame at working
float32 precision, ~= 398MB at declared 16-bit). This module estimates memory
requirements up front so callers can decide whether an operation is safe to
run entirely in RAM, or whether it must be tiled / streamed / memory-mapped.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .image import BitDepth, ChannelLayout

BYTES_PER_FLOAT32 = 4


@dataclass
class MemoryEstimate:
    width: int
    height: int
    channels: int
    bit_depth: int
    declared_bytes: int          # size at the declared bit depth (e.g. on disk)
    working_bytes: int           # size as an in-memory float32 buffer
    fits_in_budget: bool
    recommended_strategy: str

    def as_dict(self) -> dict:
        return {
            "width": self.width,
            "height": self.height,
            "channels": self.channels,
            "bit_depth": self.bit_depth,
            "declared_bytes": self.declared_bytes,
            "declared_mb": round(self.declared_bytes / (1024 ** 2), 3),
            "working_bytes": self.working_bytes,
            "working_mb": round(self.working_bytes / (1024 ** 2), 3),
            "fits_in_budget": self.fits_in_budget,
            "recommended_strategy": self.recommended_strategy,
        }


class MemoryEngine:
    """Central authority for memory estimation and RAM-safety decisions.

    `budget_bytes` defaults to 4 GiB, a conservative assumption for a single
    processing worker; callers running on bigger machines can raise it.
    """

    #: number of working copies typically alive during a non-destructive op
    #: (source + intermediate + destination is a common worst case)
    DEFAULT_COPY_MULTIPLIER = 3

    def __init__(self, budget_bytes: int = 4 * 1024 ** 3):
        self.budget_bytes = budget_bytes

    # -- single frame -------------------------------------------------------
    def estimate_frame_memory(
        self,
        width: int,
        height: int,
        channels: int = 3,
        bit_depth: BitDepth = BitDepth.BD_16,
        copy_multiplier: Optional[int] = None,
    ) -> MemoryEstimate:
        if width <= 0 or height <= 0 or channels <= 0:
            raise ValueError("width, height, channels must be positive")
        bd = BitDepth(bit_depth)
        pixels = width * height
        declared_bytes = pixels * channels * bd.bytes_per_channel
        working_bytes = pixels * channels * BYTES_PER_FLOAT32
        mult = copy_multiplier if copy_multiplier is not None else self.DEFAULT_COPY_MULTIPLIER
        effective = working_bytes * mult
        fits = effective <= self.budget_bytes
        strategy = self._recommend_strategy(effective)
        return MemoryEstimate(
            width=width, height=height, channels=channels, bit_depth=int(bd),
            declared_bytes=declared_bytes, working_bytes=working_bytes,
            fits_in_budget=fits, recommended_strategy=strategy,
        )

    # alias matching spec naming exactly
    def estimate_memory(self, *args, **kwargs) -> MemoryEstimate:
        return self.estimate_frame_memory(*args, **kwargs)

    # -- video project (many frames) ----------------------------------------
    def estimate_project_memory(
        self,
        width: int,
        height: int,
        channels: int,
        bit_depth: BitDepth,
        frame_count: int,
        streaming: bool = True,
    ) -> dict:
        per_frame = self.estimate_frame_memory(width, height, channels, bit_depth)
        if streaming:
            # Streaming pipelines only hold a small sliding window of frames.
            window = min(frame_count, 4)
            total_working = per_frame.working_bytes * window
        else:
            total_working = per_frame.working_bytes * frame_count
        total_declared = per_frame.declared_bytes * frame_count
        return {
            "frame_count": frame_count,
            "per_frame": per_frame.as_dict(),
            "streaming": streaming,
            "total_declared_bytes": total_declared,
            "total_declared_gb": round(total_declared / (1024 ** 3), 3),
            "total_working_bytes_resident": total_working,
            "total_working_gb_resident": round(total_working / (1024 ** 3), 3),
            "fits_in_budget": total_working <= self.budget_bytes,
            "recommended_strategy": self._recommend_strategy(total_working),
        }

    # -- decision helpers -----------------------------------------------------
    def can_process_in_ram(self, width: int, height: int, channels: int,
                            bit_depth: BitDepth, copy_multiplier: Optional[int] = None) -> bool:
        return self.estimate_frame_memory(width, height, channels, bit_depth, copy_multiplier).fits_in_budget

    def recommend_tile_size(self, width: int, height: int, channels: int,
                             bit_depth: BitDepth = BitDepth.BD_16,
                             max_tile_bytes: int = 64 * 1024 ** 2) -> int:
        """Return a square tile edge length (pixels) that keeps a single tile's
        working footprint under `max_tile_bytes`."""
        bytes_per_pixel = channels * BYTES_PER_FLOAT32
        max_pixels = max(1, max_tile_bytes // bytes_per_pixel)
        edge = int(max_pixels ** 0.5)
        # snap to a friendly power-of-two-ish grid, minimum 64
        for candidate in (2048, 1024, 512, 256, 128, 64):
            if candidate <= edge:
                return candidate
        return 64

    def _recommend_strategy(self, effective_bytes: int) -> str:
        if effective_bytes <= self.budget_bytes * 0.25:
            return "in_ram"
        if effective_bytes <= self.budget_bytes:
            return "in_ram_caution"
        if effective_bytes <= self.budget_bytes * 8:
            return "tiled_processing"
        if effective_bytes <= self.budget_bytes * 64:
            return "streaming_disk_backed"
        return "memory_mapped_chunked"
