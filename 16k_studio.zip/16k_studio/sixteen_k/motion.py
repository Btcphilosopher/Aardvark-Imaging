"""MOTION ENGINE -- motion vectors, frame differences, motion intensity/blur
estimation between consecutive frames."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .image import Image16K


@dataclass
class MotionField:
    vectors_x: np.ndarray   # (blocks_h, blocks_w) horizontal displacement, pixels
    vectors_y: np.ndarray   # (blocks_h, blocks_w) vertical displacement, pixels
    block_size: int

    def magnitude(self) -> np.ndarray:
        return np.sqrt(self.vectors_x ** 2 + self.vectors_y ** 2)


class MotionEngine:
    def frame_difference(self, a: Image16K, b: Image16K) -> np.ndarray:
        if a.data.shape != b.data.shape:
            raise ValueError("frames must share shape for differencing")
        return b.data - a.data

    def motion_intensity(self, a: Image16K, b: Image16K) -> float:
        diff = self.frame_difference(a, b)
        return float(np.abs(diff).mean())

    def estimate_motion(self, a: Image16K, b: Image16K, block_size: int = 16,
                         search_radius: int = 4) -> MotionField:
        """Block-matching motion estimation (sum-of-absolute-differences), the
        classic approach used by video codecs for motion-compensated prediction."""
        if a.data.shape != b.data.shape:
            raise ValueError("frames must share shape")
        h, w = a.height, a.width
        gray_a = a.data.mean(axis=-1)
        gray_b = b.data.mean(axis=-1)
        bh, bw = h // block_size, w // block_size
        vx = np.zeros((bh, bw), dtype=np.float32)
        vy = np.zeros((bh, bw), dtype=np.float32)
        padded_b = np.pad(gray_b, search_radius, mode="edge")

        for by in range(bh):
            for bx in range(bw):
                y0, x0 = by * block_size, bx * block_size
                block_a = gray_a[y0:y0 + block_size, x0:x0 + block_size]
                best_cost = np.inf
                best_dy, best_dx = 0, 0
                for dy in range(-search_radius, search_radius + 1):
                    for dx in range(-search_radius, search_radius + 1):
                        y1 = y0 + dy + search_radius
                        x1 = x0 + dx + search_radius
                        block_b = padded_b[y1:y1 + block_size, x1:x1 + block_size]
                        cost = np.abs(block_a - block_b).sum()
                        if cost < best_cost:
                            best_cost = cost
                            best_dy, best_dx = dy, dx
                vx[by, bx] = best_dx
                vy[by, bx] = best_dy
        return MotionField(vx, vy, block_size)

    def motion_blur_kernel_length(self, motion_field: MotionField, shutter_fraction: float = 0.5) -> float:
        """Given estimated motion (px/frame) and the fraction of the frame
        interval the shutter is open, estimate the expected motion-blur streak
        length in pixels."""
        return float(motion_field.magnitude().mean() * shutter_fraction)
