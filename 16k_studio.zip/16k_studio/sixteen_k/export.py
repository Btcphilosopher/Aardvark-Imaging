"""
EXPORT ENGINE
Still-image export to PNG / JPEG / TIFF / WebP / EXR / BMP via Pillow
(and OpenEXR/imageio when available for true HDR EXR output), plus a
replaceable codec-backend interface for video muxing/encoding -- per the
engineering brief, proprietary video codecs are NOT reimplemented here;
instead this module defines the backend contract that a real encoder
(ffmpeg, a vendor SDK, etc.) would satisfy.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Callable, Dict, Optional

import numpy as np

from .image import Image16K

SUPPORTED_STILL_FORMATS = ("PNG", "JPEG", "TIFF", "WEBP", "EXR", "BMP")


class ExportEngine:
    def export_still(self, image: Image16K, path: str, fmt: Optional[str] = None,
                     quality: int = 95) -> str:
        fmt = (fmt or os.path.splitext(path)[1].lstrip(".")).upper()
        if fmt == "JPG":
            fmt = "JPEG"
        if fmt not in SUPPORTED_STILL_FORMATS:
            raise ValueError(f"Unsupported export format '{fmt}'. Supported: {SUPPORTED_STILL_FORMATS}")

        if fmt == "EXR":
            return self._export_exr(image, path)

        from PIL import Image as PILImage
        data = np.clip(image.quantize(), 0.0, 1.0)
        if image.meta.bit_depth.bytes_per_channel <= 1 or fmt in ("JPEG", "BMP", "WEBP"):
            arr8 = (data * 255.0).round().astype(np.uint8)
            mode = "L" if arr8.shape[-1] == 1 else ("RGBA" if arr8.shape[-1] == 4 else "RGB")
            if fmt == "JPEG" and mode == "RGBA":
                arr8 = arr8[..., :3]
                mode = "RGB"
            pil = PILImage.fromarray(arr8, mode=mode)
            save_kwargs = {"quality": quality} if fmt in ("JPEG", "WEBP") else {}
        else:
            arr16 = (data * 65535.0).round().astype(np.uint16)
            mode = "I;16" if arr16.shape[-1] == 1 else None
            if mode is None:
                # Pillow doesn't support multi-channel 16-bit natively for all
                # formats; TIFF via numpy through tifffile if available, else
                # fall back to 8-bit.
                try:
                    import tifffile
                    tifffile.imwrite(path, arr16)
                    return path
                except ImportError:
                    arr8 = (data * 255.0).round().astype(np.uint8)
                    mode = "RGBA" if arr8.shape[-1] == 4 else "RGB"
                    pil = PILImage.fromarray(arr8, mode=mode)
                    pil.save(path)
                    return path
            pil = PILImage.fromarray(arr16, mode=mode)
            save_kwargs = {}

        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        pil.save(path, format=fmt, **save_kwargs)
        return path

    def _export_exr(self, image: Image16K, path: str) -> str:
        try:
            import OpenEXR  # type: ignore
            import Imath  # type: ignore
            header = OpenEXR.Header(image.width, image.height)
            half = Imath.Channel(Imath.PixelType(Imath.PixelType.FLOAT))
            header["channels"] = {c: half for c in ("R", "G", "B")[:image.channels]}
            exr = OpenEXR.OutputFile(path, header)
            channels = {name: image.data[..., i].astype(np.float32).tobytes()
                        for i, name in enumerate(("R", "G", "B")[:image.channels])}
            exr.writePixels(channels)
            exr.close()
            return path
        except Exception:
            pass
        try:
            import imageio.v3 as iio
            iio.imwrite(path, image.data.astype(np.float32))
            return path
        except Exception:
            # Last-resort: dump raw float32 data + a tiny sidecar header
            # so no data is silently lost even without an EXR backend.
            np.save(path + ".npy", image.data.astype(np.float32))
            return path + ".npy"

    def import_still(self, path: str) -> Image16K:
        from PIL import Image as PILImage
        from .image import ImageMetadata, ChannelLayout, BitDepth
        pil = PILImage.open(path)
        arr = np.asarray(pil)
        if arr.dtype == np.uint8:
            data = arr.astype(np.float32) / 255.0
            bd = BitDepth.BD_8
        elif arr.dtype == np.uint16:
            data = arr.astype(np.float32) / 65535.0
            bd = BitDepth.BD_16
        else:
            data = arr.astype(np.float32)
            bd = BitDepth.BD_32F
        if data.ndim == 2:
            data = data[..., None]
            layout = ChannelLayout.GRAY
        elif data.shape[-1] == 4:
            layout = ChannelLayout.RGBA
        else:
            layout = ChannelLayout.RGB
        return Image16K(data, ImageMetadata(bit_depth=bd, channel_layout=layout,
                                             name=os.path.basename(path)))


# -- video codec backend contract --------------------------------------------
class VideoCodecBackend:
    """Contract a real encoder implementation must satisfy. 16K.STUDIO ships
    no proprietary codec implementations -- this is the seam a production
    deployment plugs ffmpeg / a vendor SDK / a hardware encoder into."""

    def open(self, path: str, width: int, height: int, fps: float, codec: str) -> None:
        raise NotImplementedError

    def write_frame(self, frame: np.ndarray) -> None:
        raise NotImplementedError

    def close(self) -> None:
        raise NotImplementedError


class NullCodecBackend(VideoCodecBackend):
    """Reference backend used by tests / examples: writes each frame out as a
    numbered still image sequence via ExportEngine, rather than muxing an
    actual video container."""

    def __init__(self):
        self._engine = ExportEngine()
        self._dir = None
        self._fmt = "PNG"
        self._count = 0

    def open(self, path: str, width: int, height: int, fps: float, codec: str) -> None:
        os.makedirs(path, exist_ok=True)
        self._dir = path
        self._count = 0

    def write_frame(self, frame: Image16K) -> None:
        out_path = os.path.join(self._dir, f"frame_{self._count:06d}.{self._fmt.lower()}")
        self._engine.export_still(frame, out_path, self._fmt)
        self._count += 1

    def close(self) -> None:
        pass
