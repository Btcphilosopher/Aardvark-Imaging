"""
3D -> 2D PROJECTION
Standard pinhole camera model: intrinsic matrix (from the VirtualCamera's
focal length + sensor + resolution), extrinsic pose (from camera position +
rotation), and full projection of world-space points to 16K pixel
coordinates, with depth and frustum visibility.

Camera convention (matches VirtualCamera.look_at): at zero rotation the
camera looks down world -Z, with +X right and +Y up. Image-space pixel rows
increase downward, so the Y axis and the forward (depth) axis are flipped
relative to the camera's local "world-aligned" axes when converting to pixel
space -- this is the standard OpenGL-camera-to-image-space convention.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

import numpy as np

from .camera import VirtualCamera

# Flips camera-local (right, up, forward-into-scene) coordinates into
# (pixel-x-basis, pixel-y-basis, positive-forward-depth) space.
_IMAGE_FLIP = np.diag([1.0, -1.0, -1.0])


def intrinsic_matrix(camera: VirtualCamera) -> np.ndarray:
    """3x3 intrinsic matrix K mapping camera-space rays to pixel coordinates."""
    fx = camera.focal_length_mm * (camera.resolution_width / camera.sensor_width_mm)
    fy = camera.focal_length_mm * (camera.resolution_height / camera.sensor_height_mm)
    cx = camera.resolution_width / 2.0
    cy = camera.resolution_height / 2.0
    return np.array([
        [fx, 0.0, cx],
        [0.0, fy, cy],
        [0.0, 0.0, 1.0],
    ], dtype=np.float64)


def _rotation_matrix(pitch_deg: float, yaw_deg: float, roll_deg: float) -> np.ndarray:
    """Camera-axes-to-world rotation matrix (Rz * Ry * Rx applied to local axes)."""
    p, y, r = np.radians([pitch_deg, yaw_deg, roll_deg])
    Rx = np.array([[1, 0, 0], [0, np.cos(p), -np.sin(p)], [0, np.sin(p), np.cos(p)]])
    Ry = np.array([[np.cos(y), 0, np.sin(y)], [0, 1, 0], [-np.sin(y), 0, np.cos(y)]])
    Rz = np.array([[np.cos(r), -np.sin(r), 0], [np.sin(r), np.cos(r), 0], [0, 0, 1]])
    return Rz @ Ry @ Rx


def extrinsic_matrix(camera: VirtualCamera) -> np.ndarray:
    """4x4 matrix mapping world-space homogeneous points into camera-local,
    world-aligned-axis coordinates (right, up, and world -Z-forward), BEFORE
    the image-space flip. cam_local = R_wc @ world + t."""
    R = _rotation_matrix(*camera.rotation_deg)
    R_wc = R.T
    t = -R_wc @ np.array(camera.position, dtype=np.float64)
    ext = np.eye(4)
    ext[:3, :3] = R_wc
    ext[:3, 3] = t
    return ext


def projection_matrix(camera: VirtualCamera) -> np.ndarray:
    """3x4 full projection matrix P = K @ F @ [R_wc | t], such that for a
    homogeneous world point w, (P @ w) = [px * depth, py * depth, depth]."""
    K = intrinsic_matrix(camera)
    ext = extrinsic_matrix(camera)
    return K @ _IMAGE_FLIP @ ext[:3, :]


@dataclass
class ProjectedPoint:
    pixel_x: float
    pixel_y: float
    depth: float
    visible: bool


class ProjectionEngine:
    def project_point(self, camera: VirtualCamera, world_xyz: Tuple[float, float, float]) -> ProjectedPoint:
        P = projection_matrix(camera)
        world_h = np.array([*world_xyz, 1.0])
        proj = P @ world_h
        depth = proj[2]
        if abs(depth) < 1e-9:
            return ProjectedPoint(pixel_x=float("nan"), pixel_y=float("nan"), depth=float(depth), visible=False)
        px = proj[0] / depth
        py = proj[1] / depth
        visible = (
            depth > 0
            and 0 <= px < camera.resolution_width
            and 0 <= py < camera.resolution_height
        )
        return ProjectedPoint(pixel_x=float(px), pixel_y=float(py), depth=float(depth), visible=bool(visible))

    def project_points(self, camera: VirtualCamera, points_xyz: np.ndarray) -> np.ndarray:
        """Vectorized projection of an (N, 3) array of world points; returns an
        (N, 4) array of [px, py, depth, visible(0/1)]."""
        P = projection_matrix(camera)
        n = points_xyz.shape[0]
        homo = np.hstack([points_xyz, np.ones((n, 1))])
        proj = (P @ homo.T).T
        depth = proj[:, 2]
        with np.errstate(divide="ignore", invalid="ignore"):
            px = proj[:, 0] / depth
            py = proj[:, 1] / depth
        visible = (
            (depth > 0)
            & (px >= 0) & (px < camera.resolution_width)
            & (py >= 0) & (py < camera.resolution_height)
        )
        return np.stack([px, py, depth, visible.astype(np.float64)], axis=1)
