"""
OPTICAL / CAMERA SIMULATION
A virtual camera with photographic parameters (sensor size, resolution,
focal length, aperture, ISO, shutter speed, focus distance) and derived
quantities (horizontal/vertical FOV, depth of field, hyperfocal distance,
motion blur, pixel density).
"""
from __future__ import annotations

from dataclasses import dataclass, field
import math

from . import optics


@dataclass
class VirtualCamera:
    name: str = "camera"
    sensor_width_mm: float = 36.0       # full-frame default
    sensor_height_mm: float = 24.0
    resolution_width: int = 15360
    resolution_height: int = 8640
    focal_length_mm: float = 50.0
    aperture_f_number: float = 2.8
    iso: int = 100
    shutter_speed_sec: float = 1 / 60
    focus_distance_m: float = 5.0

    # pose (world space)
    position: tuple = (0.0, 0.0, 0.0)
    rotation_deg: tuple = (0.0, 0.0, 0.0)  # (pitch, yaw, roll)

    # -- field of view -----------------------------------------------------
    @property
    def horizontal_fov_deg(self) -> float:
        return optics.fov_from_sensor(self.sensor_width_mm, self.focal_length_mm)

    @property
    def vertical_fov_deg(self) -> float:
        return optics.fov_from_sensor(self.sensor_height_mm, self.focal_length_mm)

    @property
    def diagonal_fov_deg(self) -> float:
        diag = math.hypot(self.sensor_width_mm, self.sensor_height_mm)
        return optics.fov_from_sensor(diag, self.focal_length_mm)

    # -- depth of field -----------------------------------------------------
    @property
    def sensor_diagonal_mm(self) -> float:
        return math.hypot(self.sensor_width_mm, self.sensor_height_mm)

    @property
    def circle_of_confusion_mm(self) -> float:
        return optics.circle_of_confusion_mm(self.sensor_diagonal_mm)

    @property
    def hyperfocal_distance_m(self) -> float:
        mm = optics.hyperfocal_distance_mm(self.focal_length_mm, self.aperture_f_number,
                                            self.circle_of_confusion_mm)
        return mm / 1000.0

    def depth_of_field_m(self):
        near_mm, far_mm, dof_mm = optics.depth_of_field_mm(
            self.focal_length_mm, self.aperture_f_number,
            self.focus_distance_m * 1000.0, self.circle_of_confusion_mm,
        )
        far_m = math.inf if math.isinf(far_mm) else far_mm / 1000.0
        dof_m = math.inf if math.isinf(dof_mm) else dof_mm / 1000.0
        return near_mm / 1000.0, far_m, dof_m

    # -- pixel density / motion blur -----------------------------------------
    @property
    def pixel_density_ppi(self) -> float:
        return optics.pixel_density_ppi(self.resolution_width, self.sensor_width_mm)

    def motion_blur_streak_px(self, subject_speed_px_per_sec: float) -> float:
        return optics.motion_blur_streak_px(subject_speed_px_per_sec, self.shutter_speed_sec)

    # -- pose control --------------------------------------------------------
    def move(self, dx: float = 0.0, dy: float = 0.0, dz: float = 0.0) -> None:
        x, y, z = self.position
        self.position = (x + dx, y + dy, z + dz)

    def move_to(self, x: float, y: float, z: float) -> None:
        self.position = (x, y, z)

    def rotate(self, dpitch: float = 0.0, dyaw: float = 0.0, droll: float = 0.0) -> None:
        p, yaw, r = self.rotation_deg
        self.rotation_deg = (p + dpitch, yaw + dyaw, r + droll)

    def look_at(self, target_x: float, target_y: float, target_z: float) -> None:
        x, y, z = self.position
        dx, dy, dz = target_x - x, target_y - y, target_z - z
        yaw = math.degrees(math.atan2(dx, -dz))
        horiz_dist = math.hypot(dx, dz)
        pitch = math.degrees(math.atan2(dy, horiz_dist))
        self.rotation_deg = (pitch, yaw, self.rotation_deg[2])

    def describe(self) -> dict:
        near, far, dof = self.depth_of_field_m()
        return {
            "name": self.name,
            "resolution": (self.resolution_width, self.resolution_height),
            "sensor_mm": (self.sensor_width_mm, self.sensor_height_mm),
            "focal_length_mm": self.focal_length_mm,
            "aperture_f_number": self.aperture_f_number,
            "iso": self.iso,
            "shutter_speed_sec": self.shutter_speed_sec,
            "focus_distance_m": self.focus_distance_m,
            "horizontal_fov_deg": round(self.horizontal_fov_deg, 3),
            "vertical_fov_deg": round(self.vertical_fov_deg, 3),
            "hyperfocal_distance_m": round(self.hyperfocal_distance_m, 3),
            "depth_of_field_near_m": round(near, 4),
            "depth_of_field_far_m": far if math.isinf(far) else round(far, 4),
            "depth_of_field_m": dof if math.isinf(dof) else round(dof, 4),
            "pixel_density_ppi": round(self.pixel_density_ppi, 2),
            "position": self.position,
            "rotation_deg": self.rotation_deg,
        }
