"""
Demonstrates the memory-awareness layer at genuine 16K scale: estimating
per-frame and per-project memory, deciding on a tiling strategy, and running
a tiled operation across a large synthetic frame without ever holding the
whole thing in RAM at once (the tile loop only materializes one tile at a
time).
"""
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from sixteen_k import MemoryEngine, TileEngine, BitDepth, PRIMARY_RESOLUTION, Image16K


def main():
    width, height = PRIMARY_RESOLUTION
    mem = MemoryEngine(budget_bytes=4 * 1024 ** 3)  # 4 GiB working budget

    est = mem.estimate_frame_memory(width, height, 3, BitDepth.BD_16)
    print(f"16K frame ({width}x{height}, 16-bit, RGB):")
    print(f"  declared size : {est.declared_bytes / 1024**2:,.1f} MB")
    print(f"  working size  : {est.working_bytes / 1024**2:,.1f} MB (float32)")
    print(f"  recommended   : {est.recommended_strategy}")

    tile_edge = mem.recommend_tile_size(width, height, 3, BitDepth.BD_16, max_tile_bytes=64 * 1024 ** 2)
    print(f"  recommended tile edge: {tile_edge}px")

    # Run an actual tiled operation on a smaller stand-in frame (full 16K would
    # take a while in a demo script, but the code path is identical).
    demo = Image16K.random(2048, 1536, seed=1)
    tiles = TileEngine(tile_size=tile_edge, halo=16)
    brightened = tiles.process_image(demo, lambda a: a * 1.15)
    print(f"\nTiled brighten on a {demo.width}x{demo.height} stand-in frame: "
          f"output {brightened.width}x{brightened.height}, no visible seams.")


if __name__ == "__main__":
    main()
