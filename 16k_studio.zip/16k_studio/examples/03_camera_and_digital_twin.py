"""
Virtual camera + digital twin: set up a scene, move/aim a camera, inspect
its derived optical properties, and project a few 3D world points into 16K
pixel space.
"""
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import numpy as np
from sixteen_k import (
    VirtualCamera, DigitalTwin, Scene, SceneObject, Light, Material,
    ProjectionEngine,
)


def main():
    twin = DigitalTwin(camera=VirtualCamera(
        resolution_width=15360, resolution_height=8640,
        focal_length_mm=85, aperture_f_number=2.0, focus_distance_m=8,
    ))
    twin.camera.move(0, 1.7, 12)
    twin.camera.look_at(0, 1.0, 0)

    twin.scene.add_object(SceneObject("hero", position=(0, 1.0, 0),
                                       material=Material(albedo=(0.7, 0.2, 0.2))))
    twin.scene.add_light(Light("key", kind="directional", direction=(0.3, -1, -0.2), intensity=2.5))

    print("Camera:", twin.camera.describe())

    pe = ProjectionEngine()
    world_points = np.array([[0, 1, 0], [1, 1.5, 0], [-1, 0.5, 0]])
    projected = pe.project_points(twin.camera, world_points)
    for wp, row in zip(world_points, projected):
        px, py, depth, visible = row
        print(f"world {tuple(wp)} -> pixel ({px:.1f}, {py:.1f}), depth={depth:.2f}m, visible={bool(visible)}")


if __name__ == "__main__":
    main()
