"""
Basic automation pipeline -- mirrors the exact usage example from the
engineering brief:

    project = Project16K()
    project.import_image("master.tiff")
    project.resize(15360, 8640)
    project.exposure(0.4)
    project.sharpen(amount=0.2)
    project.export("output.tiff")

This example synthesizes a source image instead of requiring a real file on
disk, so it runs standalone.
"""
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from sixteen_k import Project16K, Image16K, BitDepth

OUT_DIR = os.path.join(os.path.dirname(__file__), "_output")
os.makedirs(OUT_DIR, exist_ok=True)


def main():
    # Synthesize a small "master" plate to stand in for a real photograph.
    master = Image16K.random(960, 540, seed=7, bit_depth=BitDepth.BD_16)
    master_path = os.path.join(OUT_DIR, "master.tiff")

    project = Project16K(name="demo_pipeline", resolution=(960, 540))
    project.set_image(master)

    # Scale down for a fast, laptop-friendly demo run (use 15360x8640 for the
    # real 16K target resolution).
    project.resize(1920, 1080)
    project.exposure(0.4)
    project.sharpen(amount=0.2)

    out_path = project.export(os.path.join(OUT_DIR, "output.tiff"))
    print(f"Exported: {out_path}")
    print("Memory report at working resolution:")
    print(project.memory_report())
    print("Edit history:", project.describe()["history"])


if __name__ == "__main__":
    main()
