"""
Turns a single high-resolution still into a short pan/scan video by panning
a smaller virtual window across it -- the classic technique for making
enormous stills feel dynamic on screen.
"""
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from sixteen_k import Image16K, PanScanEngine, PanScanKeyframe


def main():
    # Stand-in "master" plate (use a real 15360x8640 source for genuine 16K).
    master = Image16K.random(3840, 2160, seed=3)

    keyframes = [
        PanScanKeyframe(time=0.0, x=0.25, y=0.5, zoom=1.4),
        PanScanKeyframe(time=1.0, x=0.75, y=0.5, zoom=2.2),
    ]
    ps = PanScanEngine()
    video = ps.render(master, keyframes, output_width=1280, output_height=720,
                       fps=24, duration_seconds=2.0)
    print(f"Rendered pan/scan video: {video.frame_count} frames @ "
          f"{video.width}x{video.height}, {video.fps}fps, "
          f"{video.duration_seconds:.2f}s")


if __name__ == "__main__":
    main()
