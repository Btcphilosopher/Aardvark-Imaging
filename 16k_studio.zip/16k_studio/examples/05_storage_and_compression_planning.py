"""
Storage/compression planning across the resolution ladder -- answers "how
big is an hour of 16K footage at various codecs?" before you ever shoot a
frame.
"""
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from sixteen_k import (
    CompressionCalculator, StorageCalculator, BitDepth, RESOLUTION_PRESETS,
)


def main():
    cc = CompressionCalculator()
    sc = StorageCalculator()
    width, height = RESOLUTION_PRESETS["16K"]

    print(f"{'codec':<15}{'bitrate (Mbps)':>16}{'1 hour size (GB)':>20}")
    for codec in ("uncompressed", "prores_422_hq", "h265_hevc", "av1"):
        bitrate = cc.bitrate_mbps(width, height, 3, BitDepth.BD_10, fps=24, codec=codec)
        report = sc.full_report(width, height, 24, BitDepth.BD_10, 3, codec, duration_seconds=3600)
        print(f"{codec:<15}{bitrate:>16,.1f}{report['gb']:>20,.1f}")


if __name__ == "__main__":
    main()
