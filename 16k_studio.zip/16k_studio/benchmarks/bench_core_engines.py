"""
Benchmark suite for the core 16K.STUDIO engines. Uses PerformanceEngine to
measure throughput (megapixels/second) for the operations that matter most
at 16K scale: resampling, tiling, blur/sharpen, and colour conversion.

Runs at a modest default resolution so it completes quickly on a laptop;
pass --full to benchmark at genuine 16K scale (slow -- minutes, not seconds).
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from sixteen_k import (
    Image16K, BitDepth, PRIMARY_RESOLUTION,
    ResolutionEngine, Interpolation, ImageProcessingEngine, ColourEngine,
    TileEngine, PerformanceEngine,
)


def run(width: int, height: int):
    perf = PerformanceEngine()
    img = Image16K.random(width, height, seed=1, bit_depth=BitDepth.BD_16)
    print(f"Benchmarking at {width}x{height} ({img.pixel_count:,} px)\n")

    res = ResolutionEngine()
    perf.benchmark("resize_lanczos_0.5x", lambda: res.downscale(img, 0.5, Interpolation.LANCZOS),
                    image=img, iterations=3, warmup=1)
    perf.benchmark("resize_bilinear_0.5x", lambda: res.downscale(img, 0.5, Interpolation.BILINEAR),
                    image=img, iterations=3, warmup=1)

    proc = ImageProcessingEngine()
    perf.benchmark("gaussian_blur_r3", lambda: proc.blur(img, 3.0), image=img, iterations=3, warmup=1)
    perf.benchmark("sharpen_r1.5", lambda: proc.sharpness(img, 0.5, 1.5), image=img, iterations=3, warmup=1)

    colour = ColourEngine()
    perf.benchmark("srgb_to_display_p3", lambda: colour.convert_colorspace(img, "Display P3"),
                    image=img, iterations=5, warmup=1)

    tiles = TileEngine(tile_size=512, halo=16)
    perf.benchmark("tiled_blur_512px_tiles", lambda: tiles.process_image(img, lambda a: a * 1.0),
                    image=img, iterations=3, warmup=1)

    for b in perf.history:
        d = b.as_dict()
        print(f"  {d['name']:<28} {d['megapixels_per_second']:>10.2f} MPix/s   "
              f"({d['seconds_per_iteration']*1000:>8.2f} ms/iter)")
    return perf


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--full", action="store_true", help="benchmark at genuine 16K resolution (slow)")
    ap.add_argument("--width", type=int, default=1024)
    ap.add_argument("--height", type=int, default=768)
    args = ap.parse_args()

    if args.full:
        w, h = PRIMARY_RESOLUTION
    else:
        w, h = args.width, args.height
    run(w, h)
