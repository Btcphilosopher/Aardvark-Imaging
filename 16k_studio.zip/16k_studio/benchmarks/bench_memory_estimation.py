"""Quick sweep of MemoryEngine estimates across the full resolution ladder,
useful for capacity-planning conversations ("what RAM headroom do we need
to work in this resolution comfortably?")."""
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from sixteen_k import MemoryEngine, BitDepth, RESOLUTION_PRESETS


def main():
    me = MemoryEngine(budget_bytes=4 * 1024 ** 3)
    print(f"{'preset':<8}{'resolution':<16}{'bit depth':<11}{'working MB':>12}{'strategy':>22}")
    for name, (w, h) in RESOLUTION_PRESETS.items():
        for bd in (BitDepth.BD_8, BitDepth.BD_16):
            est = me.estimate_frame_memory(w, h, 3, bd)
            print(f"{name:<8}{f'{w}x{h}':<16}{int(bd):<11}{est.working_bytes/1024**2:>12,.1f}"
                  f"{est.recommended_strategy:>22}")


if __name__ == "__main__":
    main()
