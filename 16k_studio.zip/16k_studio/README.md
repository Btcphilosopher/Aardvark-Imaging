# 16K.STUDIO

A professional-grade Python computational engine for creating, processing,
analysing, simulating, optimising and exporting ultra-high-resolution visual
media. The primary target resolution is **15360×8640 (16K)**; the
architecture scales cleanly down to 720p and up past 16K to arbitrary custom
resolutions.

> This is **not** software for managing 16,000 cameras — it is a
> computational imaging and video engine architected around 16K pixel data.

Every engine is pure NumPy (no per-pixel Python loops on the hot paths),
modular, and independently testable. Memory awareness is a first-class
citizen throughout: nothing assumes a 16K frame fits comfortably in RAM.

## Quick start

```bash
pip install -r requirements.txt
python -m pytest tests/ -q          # 157 tests
python examples/01_basic_pipeline.py
```

```python
from sixteen_k import Project16K

project = Project16K()
project.new_blank(15360, 8640)      # or project.import_image("master.tiff")
project.resize(15360, 8640)
project.exposure(0.4)
project.sharpen(amount=0.2)
project.export("output.tiff")
```

## Architecture

```
16K.STUDIO
│
├── IMAGE ENGINE            sixteen_k/image.py
├── VIDEO ENGINE            sixteen_k/video.py, timeline.py
├── PIXEL / PROCESSING      sixteen_k/processing.py, sharpen.py, denoise.py
├── COLOUR ENGINE           sixteen_k/colour.py
├── CAMERA ENGINE           sixteen_k/camera.py, optics.py
├── OPTICAL / PROJECTION    sixteen_k/projection.py, digital_twin.py
├── HDR ENGINE               sixteen_k/hdr.py
├── EFFECTS ENGINE           sixteen_k/effects.py, compositing.py, masks.py, graphics.py
├── RESOLUTION ENGINE        sixteen_k/resolution.py, superres.py, zoom.py, panscan.py, stabilisation.py
├── COMPRESSION ENGINE       sixteen_k/compression.py
├── MEMORY ENGINE            sixteen_k/memory.py, tiles.py
├── PERFORMANCE ENGINE       sixteen_k/performance.py, hardware.py
├── DIGITAL TWIN ENGINE      sixteen_k/digital_twin.py, simulation.py
├── EXPORT ENGINE            sixteen_k/export.py
└── PROJECT ENGINE           sixteen_k/project.py, history.py, batch.py
```

## Why memory is a first-class concern

A single 16K RGB frame at 16-bit is ~760 MB declared / ~1.5 GB as a working
float32 buffer. `MemoryEngine` estimates this up front and recommends a
strategy (`in_ram`, `tiled_processing`, `streaming_disk_backed`,
`memory_mapped_chunked`) before any pixels move:

```python
from sixteen_k import MemoryEngine, BitDepth

me = MemoryEngine(budget_bytes=4 * 1024**3)  # 4 GiB working budget
est = me.estimate_frame_memory(15360, 8640, 3, BitDepth.BD_16)
print(est.recommended_strategy)   # -> "tiled_processing"
```

`TileEngine` then splits a frame into overlapping (haloed) tiles, runs any
NumPy op tile-by-tile, and reassembles the result losslessly — verified in
`tests/test_tiles.py` to produce output bit-identical to a full-frame pass
even for spatially-aware filters like Gaussian blur.

## Module tour

| Concern | Module(s) |
|---|---|
| 16K image buffer, bit depth, channel layout | `image.py` |
| Memory estimation & RAM-safety decisions | `memory.py` |
| Tiled/seamless large-frame processing | `tiles.py` |
| Scale / crop / pad / resize, 4 interpolation kernels | `resolution.py` |
| Extensible super-resolution (ML backend slot) | `superres.py` |
| Brightness/contrast/exposure/gamma/curves/levels/etc. | `processing.py` |
| Unsharp mask, high-pass, adaptive sharpening | `sharpen.py` |
| Gaussian/median/bilateral/temporal denoise | `denoise.py` |
| Colour space conversion, white balance, LUTs | `colour.py` |
| HDR tone mapping, highlight/shadow recovery | `hdr.py` |
| Histogram / waveform / vectorscope analysis | `histogram.py`, `waveform.py`, `vectorscope.py` |
| Block-matching motion estimation, frame retiming | `motion.py`, `interpolation.py` |
| Virtual camera (FOV, DOF, hyperfocal) | `camera.py`, `optics.py` |
| Scene graph: objects, lights, materials | `digital_twin.py` |
| Pinhole 3D→2D projection | `projection.py` |
| Digital zoom, crop ladders, pan/scan video from a still | `zoom.py`, `panscan.py` |
| Motion-based stabilisation | `stabilisation.py` |
| Composable non-destructive effects | `effects.py` |
| Layer compositing, blend modes | `compositing.py` |
| Rect/ellipse/polygon/gradient/animated masks | `masks.py` |
| Text & shape rasterisation | `graphics.py` |
| Still export (PNG/JPEG/TIFF/WEBP/EXR/BMP) + video codec backend contract | `export.py` |
| Compression ratio & bitrate estimation | `compression.py` |
| Storage sizing (MB→PB) across duration | `storage.py` |
| Benchmarking harness | `performance.py` |
| CPU/GPU array-module abstraction | `hardware.py` |
| Video project, multi-track timeline, clip ops | `video.py`, `timeline.py` |
| Undo/redo (operation-log, not full-buffer copies) | `history.py` |
| Fluent automation API + project file format | `project.py` |
| Concurrency-safe batch processing | `batch.py` |
| Deterministic, seeded simulation mode | `simulation.py` |

## Design notes

- **No proprietary codec reimplementation.** `export.py` defines a
  `VideoCodecBackend` contract; a real deployment plugs in ffmpeg, a vendor
  SDK, or a hardware encoder. `NullCodecBackend` (used in tests/examples)
  writes an image sequence so the full pipeline is exercisable without an
  external encoder dependency.
- **Interpolation is not generation.** `superres.py` is explicit that
  conventional resampling (nearest/bilinear/bicubic/Lanczos) cannot
  synthesize genuinely new information — it only estimates between known
  samples. A `register_ml_backend()` slot exists for plugging in a real
  learned super-resolution model later.
- **Undo/redo without buffer duplication.** `history.py` stores an
  operation log, not a full pixel-buffer copy per step, with periodic
  snapshots bounding worst-case replay cost — critical at 16K scale where a
  naive copy-per-undo would be enormous.
- **Numpy-first.** Every per-pixel operation is vectorised; the only Python
  `for` loops in hot paths are over small structures (tiles, kernel taps,
  keyframes), never over individual pixels.

## Testing

```bash
python -m pytest tests/ -q
```

157 tests across 20 files cover: 16K dimension/bit-depth/memory correctness,
tiling losslessness, every interpolation kernel, colour space round-trips,
HDR tone-mapping bounds, histogram/waveform/vectorscope numerics, motion
estimation, camera FOV/DOF physics, pinhole projection geometry, timeline
clip operations, zoom/pan-scan/stabilisation, mask/compositing/graphics
primitives, every export format, compression/storage scaling laws, hardware
fallback behaviour, undo/redo semantics (including redo-branch truncation),
the full `Project16K` automation facade, batch processing concurrency
safety, and seeded simulation reproducibility.

## Examples

- `examples/01_basic_pipeline.py` — the spec's canonical automation example
- `examples/02_16k_memory_and_tiling.py` — memory estimation + tiled
  processing at 16K scale
- `examples/03_camera_and_digital_twin.py` — virtual camera, scene graph,
  3D→2D projection
- `examples/04_panscan_from_16k_still.py` — turning a still into pan/scan
  video
- `examples/05_storage_and_compression_planning.py` — codec/storage
  planning across the resolution ladder

## Benchmarks

```bash
python benchmarks/bench_memory_estimation.py
python benchmarks/bench_core_engines.py            # fast, default resolution
python benchmarks/bench_core_engines.py --full     # genuine 16K (slow)
```

## Configuration

`configs/` holds JSON presets for the resolution ladder, memory-budget
profiles (workstation/render-node/CI), codec/export targets, and
`Project16K` defaults — reference data, not code, so they're easy to tune
per deployment without touching engine source.

## Forward-looking interface (intentionally, not accidentally, out of scope)

- Real video muxing/encoding (`VideoCodecBackend` contract, no built-in
  proprietary implementation)
- ML-based super-resolution and denoising (explicit `register_ml_backend()`
  hooks in `superres.py` / `denoise.py`)
- GPU execution (`hardware.py` detects and prefers a CuPy backend when
  present, falls back to NumPy transparently)

## Roadmap: a future Kotlin desktop UI

The engine is deliberately UI-agnostic and speaks in plain NumPy arrays,
dataclasses and JSON-serialisable project files — designed so a future
Kotlin desktop front-end can drive it via a thin IPC/subprocess boundary
without any changes to the Python core.
