"""Motion estimation and frame-rate conversion correctness."""
import numpy as np
from sixteen_k.image import Image16K
from sixteen_k.motion import MotionEngine
from sixteen_k.interpolation import FrameInterpolationEngine


def test_identical_frames_have_zero_motion():
    img = Image16K.random(32, 32, seed=1)
    me = MotionEngine()
    field = me.estimate_motion(img, img, block_size=16, search_radius=4)
    assert np.allclose(field.vectors_x, 0.0)
    assert np.allclose(field.vectors_y, 0.0)


def test_motion_intensity_zero_for_identical_frames():
    img = Image16K.random(32, 32, seed=1)
    me = MotionEngine()
    assert me.motion_intensity(img, img) == 0.0


def test_frame_difference_shape():
    a = Image16K.random(16, 16, seed=1)
    b = Image16K.random(16, 16, seed=2)
    me = MotionEngine()
    diff = me.frame_difference(a, b)
    assert diff.shape == a.data.shape


def test_interpolate_pair_at_endpoints():
    a = Image16K.random(16, 16, seed=1)
    b = Image16K.random(16, 16, seed=2)
    fie = FrameInterpolationEngine()
    at0 = fie.interpolate_pair(a, b, 0.0)
    at1 = fie.interpolate_pair(a, b, 1.0)
    assert np.allclose(at0.data, a.data, atol=1e-5)
    assert np.allclose(at1.data, b.data, atol=1e-5)


def test_convert_fps_24_to_30_produces_more_frames():
    frames = [Image16K.random(8, 8, seed=i) for i in range(25)]  # ~1 sec @ 24fps
    fie = FrameInterpolationEngine()
    out = fie.convert_fps(frames, 24, 30)
    assert len(out) > len(frames)


def test_convert_fps_60_to_30_produces_fewer_frames():
    frames = [Image16K.random(8, 8, seed=i) for i in range(61)]  # ~1 sec @ 60fps
    fie = FrameInterpolationEngine()
    out = fie.convert_fps(frames, 60, 30)
    assert len(out) < len(frames)
