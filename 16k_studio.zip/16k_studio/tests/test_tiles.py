"""Tile split/reassemble must be lossless and seamless for identity and
spatially-aware (blur) operations."""
import numpy as np
from sixteen_k.image import Image16K
from sixteen_k.tiles import TileEngine


def test_split_reassemble_identity(small_image):
    te = TileEngine(tile_size=16, halo=4)
    out = te.process_image(small_image, lambda a: a.copy())
    assert np.allclose(out.data, small_image.data)


def test_split_reassemble_preserves_dimensions(small_image):
    te = TileEngine(tile_size=17, halo=3)  # deliberately non-divisible tile size
    out = te.process_image(small_image, lambda a: a * 1.0)
    assert out.width == small_image.width
    assert out.height == small_image.height


def test_tile_halo_prevents_seams_for_blur():
    from sixteen_k.processing import _gaussian_blur
    img = Image16K.random(80, 64, seed=7)
    full_blur = _gaussian_blur(img.data, radius=3.0)

    te = TileEngine(tile_size=32, halo=12)
    tiled_blur = te.process_image(img, lambda a: _gaussian_blur(a, radius=3.0))

    # With sufficient halo, tiled blur should closely match a full-frame blur
    assert np.allclose(tiled_blur.data, full_blur, atol=1e-4)


def test_tile_op_shape_mismatch_raises():
    import pytest
    te = TileEngine(tile_size=8, halo=2)
    img = Image16K.random(16, 16, seed=1)
    tiles = te.split_into_tiles(img)
    with pytest.raises(ValueError):
        te.process_tile(tiles[0], lambda a: a[:-1])
