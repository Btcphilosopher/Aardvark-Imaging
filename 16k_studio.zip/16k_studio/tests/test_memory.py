"""Memory estimation / tiling-recommendation correctness."""
import pytest
from sixteen_k.memory import MemoryEngine
from sixteen_k.image import BitDepth


def test_estimate_frame_memory_16k():
    me = MemoryEngine()
    est = me.estimate_frame_memory(15360, 8640, 3, BitDepth.BD_16)
    assert est.declared_bytes == 15360 * 8640 * 3 * 2
    assert est.working_bytes == 15360 * 8640 * 3 * 4
    assert est.recommended_strategy in ("tiled_processing", "streaming_disk_backed", "memory_mapped_chunked")


def test_small_image_fits_in_ram():
    me = MemoryEngine(budget_bytes=1024 ** 3)
    est = me.estimate_frame_memory(256, 256, 3, BitDepth.BD_8)
    assert est.fits_in_budget
    assert est.recommended_strategy == "in_ram"


def test_can_process_in_ram_boolean():
    me = MemoryEngine(budget_bytes=10 * 1024 ** 2)
    assert me.can_process_in_ram(64, 64, 3, BitDepth.BD_8)
    assert not me.can_process_in_ram(15360, 8640, 3, BitDepth.BD_16)


def test_estimate_project_memory_streaming_vs_full():
    me = MemoryEngine(budget_bytes=4 * 1024 ** 3)
    streaming = me.estimate_project_memory(1920, 1080, 3, BitDepth.BD_10, frame_count=1000, streaming=True)
    full = me.estimate_project_memory(1920, 1080, 3, BitDepth.BD_10, frame_count=1000, streaming=False)
    assert streaming["total_working_bytes_resident"] < full["total_working_bytes_resident"]
    assert streaming["total_declared_bytes"] == full["total_declared_bytes"]


def test_recommend_tile_size_shrinks_with_larger_frame():
    me = MemoryEngine()
    small_tile = me.recommend_tile_size(1920, 1080, 3, max_tile_bytes=8 * 1024 ** 2)
    big_tile = me.recommend_tile_size(1920, 1080, 3, max_tile_bytes=256 * 1024 ** 2)
    assert small_tile <= big_tile


def test_invalid_dimensions_raise():
    me = MemoryEngine()
    with pytest.raises(ValueError):
        me.estimate_frame_memory(0, 100, 3, BitDepth.BD_8)
