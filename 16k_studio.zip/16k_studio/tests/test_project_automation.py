"""End-to-end Project16K automation API, matching the spec's example usage:

    project = Project16K()
    project.import_image("master.tiff")
    project.resize(15360, 8640)
    project.exposure(0.4)
    project.sharpen(amount=0.2)
    project.export("output.tiff")
"""
import os
import numpy as np
import pytest
from sixteen_k.project import Project16K, ProjectFile


def test_fluent_pipeline_matches_spec_example(tmp_path):
    project = Project16K(name="demo", resolution=(64, 48))
    project.new_blank(64, 48, fill=0.4)
    project.resize(32, 24)
    project.exposure(0.4)
    project.sharpen(amount=0.2)
    out_path = str(tmp_path / "output.tiff")
    result_path = project.export(out_path)
    assert os.path.exists(result_path)
    assert project.image.width == 32 and project.image.height == 24


def test_undo_redo_through_project_facade(tmp_path):
    project = Project16K()
    project.new_blank(16, 16, fill=0.5)
    project.exposure(0.5)
    after_exposure = project.image.data.copy()
    project.contrast(1.5)
    project.undo()
    assert np.allclose(project.image.data, after_exposure, atol=1e-5)


def test_project_file_save_and_reload_roundtrip(tmp_path):
    project = Project16K(name="roundtrip_test", resolution=(100, 100))
    project.new_blank(100, 100)
    path = str(tmp_path / "proj.16kproj")
    project.save_project(path)

    reloaded = ProjectFile.load(path)
    assert reloaded.name == "roundtrip_test"
    assert tuple(reloaded.resolution) == (100, 100)


def test_memory_report_reflects_current_image():
    project = Project16K()
    project.new_blank(15360, 8640)
    report = project.memory_report()
    assert report["width"] == 15360
    assert report["height"] == 8640
    assert report["recommended_strategy"] != "in_ram"


def test_effects_chain_via_automation_api():
    project = Project16K()
    project.new_blank(32, 32, fill=0.5)
    before = project.image.data.copy()
    project.effects(lambda fx: fx.vignette(0.4).grain(0.01, seed=1))
    assert not np.allclose(project.image.data, before)


def test_operations_require_loaded_image():
    project = Project16K()
    with pytest.raises(RuntimeError):
        project.exposure(0.1)
