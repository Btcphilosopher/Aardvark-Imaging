"""Hardware abstraction fallback + performance benchmarking harness."""
from sixteen_k.hardware import HardwareAbstraction, DeviceKind
from sixteen_k.performance import PerformanceEngine
from sixteen_k.image import Image16K


def test_cpu_device_always_available():
    hw = HardwareAbstraction()
    assert hw.cpu.is_available()
    assert hw.active.kind is DeviceKind.CPU


def test_detect_devices_includes_cpu():
    hw = HardwareAbstraction()
    devices = hw.detect_devices()
    assert any(d.kind is DeviceKind.CPU for d in devices)


def test_run_executes_with_active_array_module():
    hw = HardwareAbstraction()
    result = hw.run(lambda xp: xp.array([1, 2, 3]).sum())
    assert result == 6


def test_benchmark_records_history():
    pe = PerformanceEngine()
    img = Image16K.random(64, 64, seed=1)

    def work():
        _ = img.data * 2.0

    result = pe.benchmark("double", work, image=img, iterations=10, warmup=2)
    assert result.iterations == 10
    assert result.fps > 0
    assert len(pe.history) == 1


def test_report_includes_benchmarks():
    pe = PerformanceEngine()
    img = Image16K.random(32, 32, seed=1)
    pe.benchmark("noop", lambda: None, image=img, iterations=3)
    report = pe.report()
    assert len(report["benchmarks"]) == 1
