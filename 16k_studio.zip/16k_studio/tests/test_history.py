"""Undo/redo semantics, including new-edit truncation of redo history."""
import numpy as np
from sixteen_k.image import Image16K
from sixteen_k.history import OperationHistory
from sixteen_k.processing import ImageProcessingEngine

pe = ImageProcessingEngine()


def test_undo_restores_previous_state():
    img = Image16K.blank(8, 8, fill=0.5)
    hist = OperationHistory(img)
    hist.push("brighten", lambda im: pe.brightness(im, 0.1))
    after1 = hist.current()
    hist.push("brighten_more", lambda im: pe.brightness(im, 0.1))
    hist.undo()
    assert np.allclose(hist.current().data, after1.data, atol=1e-6)


def test_redo_reapplies_undone_op():
    img = Image16K.blank(8, 8, fill=0.5)
    hist = OperationHistory(img)
    hist.push("a", lambda im: pe.brightness(im, 0.1))
    hist.push("b", lambda im: pe.brightness(im, 0.1))
    after_both = hist.current()
    hist.undo()
    hist.redo()
    assert np.allclose(hist.current().data, after_both.data, atol=1e-6)


def test_new_edit_truncates_redo_branch():
    img = Image16K.blank(8, 8, fill=0.5)
    hist = OperationHistory(img)
    hist.push("a", lambda im: pe.brightness(im, 0.1))
    hist.push("b", lambda im: pe.brightness(im, 0.1))
    hist.undo()
    hist.push("c", lambda im: pe.brightness(im, -0.1))
    assert not hist.can_redo()


def test_snapshot_interval_still_reproduces_correct_state():
    img = Image16K.blank(8, 8, fill=0.2)
    hist = OperationHistory(img, snapshot_interval=2)
    expected = img
    for i in range(7):
        delta = 0.01 * (i + 1)
        hist.push(f"op{i}", lambda im, d=delta: pe.brightness(im, d))
        expected = pe.brightness(expected, delta)
    assert np.allclose(hist.current().data, expected.data, atol=1e-5)


def test_cannot_undo_past_base():
    img = Image16K.blank(4, 4, fill=0.0)
    hist = OperationHistory(img)
    hist.undo()
    hist.undo()
    assert np.allclose(hist.current().data, img.data)
