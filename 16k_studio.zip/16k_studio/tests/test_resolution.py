"""Resolution engine: scale / crop / pad / resize correctness across all
interpolation kernels."""
import numpy as np
import pytest
from sixteen_k.resolution import ResolutionEngine, Interpolation


@pytest.mark.parametrize("method", list(Interpolation))
def test_resize_produces_target_dimensions(small_image, method):
    re = ResolutionEngine()
    out = re.resize(small_image, 32, 24, method=method)
    assert out.width == 32 and out.height == 24


def test_resize_identity_nearest_matches_original():
    re = ResolutionEngine()
    from sixteen_k.image import Image16K
    img = Image16K.random(20, 20, seed=1)
    out = re.resize(img, 20, 20, method=Interpolation.NEAREST)
    assert np.allclose(out.data, img.data, atol=1e-5)


def test_downscale_then_upscale_preserves_rough_content(small_image):
    re = ResolutionEngine()
    small = re.downscale(small_image, 0.5)
    back = re.resize(small, small_image.width, small_image.height)
    # not pixel-identical (lossy), but should be reasonably close in mean
    assert abs(back.data.mean() - small_image.data.mean()) < 0.2


def test_crop_bounds_validated(small_image):
    re = ResolutionEngine()
    with pytest.raises(ValueError):
        re.crop(small_image, 0, 0, small_image.width + 1, small_image.height)


def test_pad_increases_dimensions(small_image):
    re = ResolutionEngine()
    out = re.pad(small_image, 2, 3, 4, 5)
    assert out.width == small_image.width + 6
    assert out.height == small_image.height + 8


def test_effective_resolution_after_crop_math():
    re = ResolutionEngine()
    res = re.effective_resolution_after_crop(15360, 8640, 7680, 4320)
    assert res["linear_zoom_factor"] == 2.0
    assert abs(res["retained_fraction_pixels"] - 0.25) < 1e-9
