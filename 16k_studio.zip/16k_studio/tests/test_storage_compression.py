"""Compression ratio + storage calculators across the resolution ladder."""
import pytest
from sixteen_k.compression import CompressionCalculator, TYPICAL_COMPRESSION_RATIOS
from sixteen_k.storage import StorageCalculator
from sixteen_k.image import BitDepth


def test_uncompressed_ratio_is_one():
    cc = CompressionCalculator()
    est = cc.estimate(1920, 1080, 3, BitDepth.BD_8, codec="uncompressed")
    assert est.compressed_bytes == est.uncompressed_bytes


def test_higher_ratio_codec_yields_smaller_file():
    cc = CompressionCalculator()
    h264 = cc.estimate(1920, 1080, 3, BitDepth.BD_8, codec="h264_high")
    av1 = cc.estimate(1920, 1080, 3, BitDepth.BD_8, codec="av1")
    assert av1.compressed_bytes < h264.compressed_bytes


def test_unknown_codec_raises():
    cc = CompressionCalculator()
    with pytest.raises(KeyError):
        cc.estimate(100, 100, 3, BitDepth.BD_8, codec="not_a_codec")


def test_bitrate_scales_with_fps():
    cc = CompressionCalculator()
    br30 = cc.bitrate_mbps(1920, 1080, 3, BitDepth.BD_8, fps=30, codec="h265_hevc")
    br60 = cc.bitrate_mbps(1920, 1080, 3, BitDepth.BD_8, fps=60, codec="h265_hevc")
    assert abs(br60 - 2 * br30) < 1e-6


def test_16k_uncompressed_hour_is_multi_petabyte_scale():
    sc = StorageCalculator()
    report = sc.full_report(15360, 8640, 24, BitDepth.BD_16, 3, "uncompressed", duration_seconds=3600)
    # 15360*8640*3*2 bytes/frame * 24 fps * 3600s ~= 68.8 TB -- comfortably sub-petabyte
    assert report["tb"] > 50
    assert report["pb"] < 1


def test_storage_scales_linearly_with_duration():
    sc = StorageCalculator()
    one_min = sc.calculate(1920, 1080, 30, BitDepth.BD_10, 3, "h265_hevc", duration_seconds=60)
    two_min = sc.calculate(1920, 1080, 30, BitDepth.BD_10, 3, "h265_hevc", duration_seconds=120)
    assert abs(two_min.total_bytes - 2 * one_min.total_bytes) <= 2  # rounding tolerance
