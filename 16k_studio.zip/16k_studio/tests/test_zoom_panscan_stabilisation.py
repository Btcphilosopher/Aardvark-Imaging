"""Digital zoom/crop ladder, pan-scan video generation, and stabilisation."""
import numpy as np
from sixteen_k.image import Image16K
from sixteen_k.zoom import DigitalZoomEngine
from sixteen_k.panscan import PanScanEngine, PanScanKeyframe
from sixteen_k.stabilisation import StabilisationEngine


def test_digital_zoom_reduces_window_size():
    master = Image16K.random(400, 300, seed=1)
    dz = DigitalZoomEngine()
    zoomed = dz.digital_zoom(master, factor=4.0)
    assert zoomed.width == master.width // 4
    assert zoomed.height == master.height // 4


def test_crop_ladder_zoom_factors_increase():
    master = Image16K.random(4000, 3000, seed=1)
    dz = DigitalZoomEngine()
    steps = dz.crop_ladder(master, presets=["4K", "1080p", "720p"])
    factors = [s.zoom_factor for s in steps]
    assert factors == sorted(factors)


def test_panscan_produces_correct_frame_count_and_size():
    master = Image16K.random(800, 600, seed=1)
    ps = PanScanEngine()
    kfs = [PanScanKeyframe(0.0, 0.3, 0.3, 1.2), PanScanKeyframe(1.0, 0.7, 0.7, 2.0)]
    video = ps.render(master, kfs, output_width=64, output_height=48, fps=24, duration_seconds=0.25)
    assert video.frame_count == 6
    assert video.width == 64 and video.height == 48


def test_stabilisation_returns_consistent_frame_sizes():
    frames = [Image16K.random(64, 48, seed=i) for i in range(6)]
    se = StabilisationEngine()
    out = se.stabilize(frames, strength=0.5, block_size=16, search_radius=4)
    sizes = {(f.width, f.height) for f in out}
    assert len(sizes) == 1  # all stabilised frames share one crop size


def test_stabilisation_strength_zero_is_near_noop_size():
    frames = [Image16K.random(64, 48, seed=i) for i in range(4)]
    se = StabilisationEngine()
    out = se.stabilize(frames, strength=0.0, block_size=16, search_radius=4)
    # with strength 0, correction is zero everywhere but margin cropping may still apply
    assert out[0].width <= 64 and out[0].height <= 48
