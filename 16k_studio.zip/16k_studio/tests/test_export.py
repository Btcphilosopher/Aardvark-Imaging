"""Export engine round-trips for every supported still format."""
import os
import numpy as np
import pytest
from sixteen_k.export import ExportEngine, NullCodecBackend, SUPPORTED_STILL_FORMATS
from sixteen_k.image import Image16K, BitDepth


@pytest.fixture
def export_dir(tmp_path):
    return str(tmp_path)


@pytest.mark.parametrize("fmt", SUPPORTED_STILL_FORMATS)
def test_export_still_creates_file(tiny_image, export_dir, fmt):
    ee = ExportEngine()
    ext = {"JPEG": "jpg", "WEBP": "webp", "TIFF": "tiff", "PNG": "png", "BMP": "bmp", "EXR": "exr"}[fmt]
    path = os.path.join(export_dir, f"out.{ext}")
    out_path = ee.export_still(tiny_image, path, fmt)
    assert os.path.exists(out_path)


def test_export_reimport_png_close_to_original(tiny_image, export_dir):
    ee = ExportEngine()
    path = os.path.join(export_dir, "out.png")
    ee.export_still(tiny_image, path, "PNG")
    back = ee.import_still(path)
    assert back.width == tiny_image.width
    assert back.height == tiny_image.height
    # PNG at 8-bit will have quantization error but should be close
    assert np.abs(back.data[..., :3] - tiny_image.data[..., :3]).mean() < 0.02


def test_unsupported_format_raises(tiny_image, export_dir):
    ee = ExportEngine()
    with pytest.raises(ValueError):
        ee.export_still(tiny_image, os.path.join(export_dir, "out.xyz"), "XYZ")


def test_null_codec_backend_writes_sequence(export_dir):
    from sixteen_k.video import VideoProject
    vp = VideoProject(16, 12, 24, "seqtest")
    for i in range(4):
        vp.add_frame(Image16K.random(16, 12, seed=i))
    backend = NullCodecBackend()
    seq_dir = os.path.join(export_dir, "seq")
    backend.open(seq_dir, 16, 12, 24, "png")
    for vf in vp.frames:
        backend.write_frame(vf.image)
    backend.close()
    files = sorted(os.listdir(seq_dir))
    assert len(files) == 4
