import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import pytest
import numpy as np
from sixteen_k.image import Image16K, BitDepth, ChannelLayout


@pytest.fixture
def small_image():
    return Image16K.random(64, 48, seed=1234)


@pytest.fixture
def tiny_image():
    return Image16K.random(16, 12, seed=42)


@pytest.fixture(autouse=True)
def _seed_numpy():
    np.random.seed(0)
    yield
