"""Mask generation, layer compositing blend modes, and graphics primitives."""
import numpy as np
import pytest
from sixteen_k.masks import MaskEngine
from sixteen_k.compositing import CompositingEngine, Layer, BlendMode
from sixteen_k.graphics import GraphicsEngine, Transform2D
from sixteen_k.image import Image16K


def test_rectangular_mask_bounds():
    me = MaskEngine()
    mask = me.rectangular(50, 50, 10, 10, 20, 20)
    assert mask[15, 15] == 1.0
    assert mask[0, 0] == 0.0


def test_elliptical_mask_center_is_one():
    me = MaskEngine()
    mask = me.elliptical(50, 50, 25, 25, 10, 10)
    assert mask[25, 25] == 1.0
    assert mask[0, 0] == 0.0


def test_polygon_mask_interior_exterior():
    me = MaskEngine()
    mask = me.polygon(100, 100, [(10, 10), (90, 10), (50, 90)])
    assert mask[20, 50] == 1.0   # inside the triangle
    assert mask[95, 95] == 0.0  # outside


def test_gradient_masks_monotonic():
    me = MaskEngine()
    lin = me.linear_gradient(100, 10, (0, 0), (100, 0))
    assert lin[0, 0] < lin[0, 99]
    rad = me.radial_gradient(100, 100, 50, 50, 40, inner_value=1.0, outer_value=0.0)
    assert rad[50, 50] > rad[0, 0]


def test_mask_combination_ops():
    me = MaskEngine()
    a = me.rectangular(20, 20, 0, 0, 10, 20)
    b = me.rectangular(20, 20, 5, 0, 10, 20)
    inter = me.combine_and(a, b)
    union = me.combine_or(a, b)
    assert inter[0, 7] == 1.0
    assert inter[0, 2] == 0.0
    assert union[0, 2] == 1.0


@pytest.mark.parametrize("mode", list(BlendMode))
def test_all_blend_modes_run(mode):
    ce = CompositingEngine()
    base = Image16K.random(16, 16, seed=1)
    top = Image16K.random(16, 16, seed=2)
    layer = Layer(image=top, opacity=0.6, blend_mode=mode)
    out = ce.composite_layer(base, layer)
    assert out.data.shape == base.data.shape


def test_multiply_blend_darkens():
    ce = CompositingEngine()
    base = Image16K.blank(8, 8, fill=0.8)
    top = Image16K.blank(8, 8, fill=0.3)
    layer = Layer(image=top, opacity=1.0, blend_mode=BlendMode.MULTIPLY)
    out = ce.composite_layer(base, layer)
    assert np.allclose(out.data, 0.24, atol=1e-5)


def test_screen_blend_lightens():
    ce = CompositingEngine()
    base = Image16K.blank(8, 8, fill=0.2)
    top = Image16K.blank(8, 8, fill=0.5)
    layer = Layer(image=top, opacity=1.0, blend_mode=BlendMode.SCREEN)
    out = ce.composite_layer(base, layer)
    assert out.data.mean() > base.data.mean()


def test_graphics_rectangle_fills_region():
    ge = GraphicsEngine()
    canvas = Image16K.blank(50, 50, fill=0.0)
    out = ge.rectangle(canvas, 10, 10, 10, 10, (1.0, 1.0, 1.0))
    assert out.data[15, 15, 0] == 1.0
    assert out.data[0, 0, 0] == 0.0


def test_graphics_circle_center_filled():
    ge = GraphicsEngine()
    canvas = Image16K.blank(50, 50, fill=0.0)
    out = ge.circle(canvas, 25, 25, 10, (1.0, 0.0, 0.0))
    assert out.data[25, 25, 0] == 1.0


def test_graphics_line_draws_pixels():
    ge = GraphicsEngine()
    canvas = Image16K.blank(50, 50, fill=0.0)
    out = ge.line(canvas, 0, 25, 49, 25, (0.0, 1.0, 0.0), thickness=3)
    assert out.data[25, 25, 1] == 1.0


def test_text_renders_non_empty(small_image):
    ge = GraphicsEngine()
    canvas = Image16K.blank(200, 60, fill=0.0)
    out = ge.text(canvas, "16K", 10, 10, (1, 1, 1), font_size=24)
    assert out.data.sum() > 0
