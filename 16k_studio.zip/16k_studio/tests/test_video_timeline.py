"""Video project + timeline (cut/trim/split/merge/move/duplicate/speed/reverse/freeze)."""
import pytest
from sixteen_k.image import Image16K
from sixteen_k.video import VideoProject, STANDARD_FRAME_RATES
from sixteen_k.timeline import Timeline, Track, TrackType, Clip


def _make_project(n_frames=30, w=32, h=24, fps=30):
    vp = VideoProject(w, h, fps, "test")
    for i in range(n_frames):
        vp.add_frame(Image16K.random(w, h, seed=i))
    return vp


def test_invalid_fps_rejected():
    with pytest.raises(ValueError):
        VideoProject(64, 64, 37, "bad")


def test_frame_stepping():
    vp = _make_project()
    stepped = vp.step(5, 3)
    assert stepped.index == 8
    assert vp.step(0, -1) is None


def test_duration_seconds():
    vp = _make_project(n_frames=60, fps=30)
    assert abs(vp.duration_seconds - 2.0) < 1e-9


def test_crop_project_dimensions():
    vp = _make_project(w=64, h=48)
    cropped = vp.crop(0, 0, 32, 24)
    assert cropped.width == 32 and cropped.height == 24
    assert cropped.frame_count == vp.frame_count


def test_split_produces_two_contiguous_clips():
    vp = _make_project()
    tl = Timeline(fps=30)
    track = tl.add_track(TrackType.VIDEO, "V1")
    clip = Clip(name="c1", source=vp, in_frame=0, out_frame=30, start_on_track=0)
    track.add_clip(clip)

    parts = tl.split(track, 10)
    assert parts is not None
    left, right = parts
    assert left.out_frame == right.in_frame
    assert left.start_on_track == 0 and right.start_on_track == 10


def test_merge_requires_contiguous_source():
    vp = _make_project()
    tl = Timeline(fps=30)
    track = tl.add_track(TrackType.VIDEO, "V1")
    a = Clip(name="a", source=vp, in_frame=0, out_frame=10, start_on_track=0)
    b = Clip(name="b", source=vp, in_frame=15, out_frame=20, start_on_track=10)
    track.add_clip(a)
    track.add_clip(b)
    with pytest.raises(ValueError):
        tl.merge(track, a, b)


def test_speed_change_shortens_track_length():
    vp = _make_project()
    tl = Timeline(fps=30)
    track = tl.add_track(TrackType.VIDEO, "V1")
    clip = Clip(name="c", source=vp, in_frame=0, out_frame=30, start_on_track=0)
    track.add_clip(clip)
    original_len = clip.track_length
    tl.set_speed(clip, 2.0)
    assert clip.track_length == max(1, original_len // 2)


def test_reverse_flips_resolved_frames():
    vp = _make_project()
    tl = Timeline(fps=30)
    track = tl.add_track(TrackType.VIDEO, "V1")
    clip = Clip(name="c", source=vp, in_frame=0, out_frame=30, start_on_track=0)
    track.add_clip(clip)
    forward_first = clip.resolve_frame(0)
    tl.reverse(clip)
    reversed_first = clip.resolve_frame(0)
    assert forward_first != reversed_first


def test_freeze_frame_always_resolves_same_source_frame():
    vp = _make_project()
    tl = Timeline(fps=30)
    track = tl.add_track(TrackType.VIDEO, "V1")
    clip = Clip(name="c", source=vp, in_frame=0, out_frame=30, start_on_track=0)
    track.add_clip(clip)
    frozen = tl.freeze_frame(clip, at_source_frame=7, hold_length=10)
    assert frozen.resolve_frame(0) == 7
    assert frozen.resolve_frame(9) == 7


def test_duplicate_creates_independent_clip():
    vp = _make_project()
    tl = Timeline(fps=30)
    track = tl.add_track(TrackType.VIDEO, "V1")
    clip = Clip(name="c", source=vp, in_frame=0, out_frame=30, start_on_track=0)
    track.add_clip(clip)
    dup = tl.duplicate(track, clip, new_start=50)
    assert dup.start_on_track == 50
    assert dup is not clip


def test_transcode_plan_flags_scaling_and_retiming():
    vp = _make_project(w=1920, h=1080, fps=30)
    plan = vp.transcode_plan("8K", 60)
    assert plan["requires_scaling"]
    assert plan["requires_retiming"]
