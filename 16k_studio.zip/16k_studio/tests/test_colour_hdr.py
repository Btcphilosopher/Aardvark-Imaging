"""Colour management and HDR engine numerical validation."""
import numpy as np
import pytest
from sixteen_k.colour import ColourEngine
from sixteen_k.hdr import HDREngine, ToneMapOperator
from sixteen_k.image import Image16K


def test_srgb_linear_roundtrip(small_image):
    ce = ColourEngine()
    lin = ce.to_linear(small_image)
    back = ce.from_linear(lin, "sRGB")
    assert np.allclose(back.data, small_image.data, atol=1e-4)


def test_gamut_roundtrip_low_error(small_image):
    ce = ColourEngine()
    p3 = ce.convert_colorspace(small_image, "Display P3")
    back = ce.convert_colorspace(p3, "sRGB")
    assert np.abs(back.data - small_image.data).max() < 1e-3


def test_colour_temperature_6500k_is_unity_gain():
    ce = ColourEngine()
    r, g, b = ce.colour_temperature_to_gains(6500.0)
    assert abs(r - 1.0) < 1e-6
    assert abs(g - 1.0) < 1e-6
    assert abs(b - 1.0) < 1e-6


def test_warm_temperature_boosts_red_relative_to_blue():
    ce = ColourEngine()
    r, g, b = ce.colour_temperature_to_gains(3200.0)  # tungsten, warm source -> cool the image (boost blue)
    assert b > r


def test_identity_3d_lut_is_noop(small_image):
    ce = ColourEngine()
    lut = ColourEngine.identity_lut_3d(9)
    out = ce.apply_lut_3d(small_image, lut)
    assert np.allclose(out.data[..., :3], small_image.data[..., :3], atol=2e-3)


def test_exposure_doubles_at_one_stop(small_image):
    ce = ColourEngine()
    out = ce.exposure(small_image, 1.0)
    assert np.allclose(out.data, small_image.data * 2.0, atol=1e-5)


def test_tone_map_output_bounded():
    hdr = HDREngine()
    bright = Image16K.random(32, 32, seed=3)
    bright.data *= 5.0
    for op in ToneMapOperator:
        mapped = hdr.tone_map(bright, op)
        assert mapped.data.min() >= -1e-4
        assert mapped.data.max() <= 1.0001


def test_dynamic_range_stops_positive():
    hdr = HDREngine()
    img = Image16K.random(16, 16, seed=4)
    img.data = np.clip(img.data, 0.01, None) * 4.0
    dr = hdr.dynamic_range(img)
    assert dr.scene_stops > 0


def test_highlight_recovery_reduces_extreme_values():
    hdr = HDREngine()
    img = Image16K.blank(8, 8, fill=1.5)
    recovered = hdr.highlight_recovery(img, threshold=0.9, strength=0.8)
    assert recovered.data.mean() < img.data.mean()


def test_shadow_recovery_lifts_dark_values():
    hdr = HDREngine()
    img = Image16K.blank(8, 8, fill=0.02)
    lifted = hdr.shadow_recovery(img, threshold=0.1, strength=0.5)
    assert lifted.data.mean() > img.data.mean()


def test_merge_exposures_shape():
    hdr = HDREngine()
    imgs = [Image16K.random(16, 16, seed=i) for i in range(3)]
    merged = hdr.merge_exposures(imgs, ev_offsets=[-1, 0, 1])
    assert merged.data.shape == imgs[0].data.shape
