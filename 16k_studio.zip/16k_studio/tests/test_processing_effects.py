"""Image processing operators + composable non-destructive effects stack."""
import numpy as np
import pytest
from sixteen_k.processing import ImageProcessingEngine
from sixteen_k.effects import EffectStack
from sixteen_k.sharpen import SharpeningEngine
from sixteen_k.denoise import DenoisingEngine
from sixteen_k.image import Image16K


def test_exposure_stops_are_multiplicative(small_image):
    pe = ImageProcessingEngine()
    out = pe.exposure(small_image, 2.0)
    assert np.allclose(out.data, small_image.data * 4.0, atol=1e-5)


def test_saturation_zero_desaturates(small_image):
    pe = ImageProcessingEngine()
    out = pe.saturation(small_image, 0.0)
    assert np.allclose(out.data[..., 0], out.data[..., 1], atol=1e-4)
    assert np.allclose(out.data[..., 1], out.data[..., 2], atol=1e-4)


def test_threshold_produces_binary_output(small_image):
    pe = ImageProcessingEngine()
    out = pe.threshold(small_image, 0.5)
    unique = np.unique(out.data)
    assert set(unique.tolist()).issubset({0.0, 1.0})


def test_curves_endpoints_preserved(small_image):
    pe = ImageProcessingEngine()
    out = pe.curves(small_image, [(0, 0), (1, 1)])
    assert np.allclose(out.data, small_image.data, atol=1e-4)


def test_gamma_inverse_roundtrip(small_image):
    pe = ImageProcessingEngine()
    up = pe.gamma(small_image, 2.2)
    down = pe.gamma(up, 1 / 2.2)
    assert np.allclose(down.data, small_image.data, atol=1e-3)


def test_effect_stack_is_non_destructive(small_image):
    stack = EffectStack(small_image)
    result = stack.exposure(0.3).blur(2.0).render()
    assert not np.array_equal(result.data, small_image.data)
    assert small_image.data.min() >= 0.0  # source untouched, still original random data


def test_unsharp_mask_increases_local_contrast():
    se = SharpeningEngine()
    img = Image16K.blank(32, 32, fill=0.5)
    img.data[16, 16, :] = 1.0  # a bright point in a flat field
    out = se.unsharp_mask(img, amount=2.0, radius=3.0)
    assert out.data[16, 16, 0] >= img.data[16, 16, 0]


def test_median_denoise_removes_salt_pepper():
    de = DenoisingEngine()
    img = Image16K.blank(16, 16, fill=0.5)
    img.data[3, 3, :] = 1.0  # impulse noise
    out = de.median(img, window=3)
    assert out.data[3, 3, 0] < 1.0


def test_bilateral_preserves_edges_better_than_gaussian():
    de = DenoisingEngine()
    img = Image16K.blank(20, 20, fill=0.1)
    img.data[:, 10:, :] = 0.9  # a hard edge
    gauss = de.gaussian(img, radius=2.0)
    bilat = de.bilateral(img, radius=2, sigma_range=0.1)
    # bilateral should keep the edge sharper (larger local gradient) than gaussian
    edge_gauss = abs(float(gauss.data[10, 9, 0]) - float(gauss.data[10, 11, 0]))
    edge_bilat = abs(float(bilat.data[10, 9, 0]) - float(bilat.data[10, 11, 0]))
    assert edge_bilat >= edge_gauss
