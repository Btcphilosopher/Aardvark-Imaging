"""16K dimension / bit-depth / channel correctness tests."""
import numpy as np
import pytest
from sixteen_k.image import Image16K, BitDepth, ChannelLayout, PRIMARY_RESOLUTION, RESOLUTION_PRESETS


def test_primary_resolution_is_16k():
    assert PRIMARY_RESOLUTION == (15360, 8640)
    assert RESOLUTION_PRESETS["16K"] == (15360, 8640)


def test_16k_pixel_count():
    img = Image16K.blank(15360, 8640)
    assert img.pixel_count == 15360 * 8640 == 132_710_400


def test_aspect_ratio_16k_is_16_by_9():
    img = Image16K.blank(15360, 8640)
    assert abs(img.aspect_ratio - (16 / 9)) < 1e-9


def test_bit_depth_max_values():
    assert BitDepth.BD_8.max_value == 255.0
    assert BitDepth.BD_10.max_value == 1023.0
    assert BitDepth.BD_12.max_value == 4095.0
    assert BitDepth.BD_16.max_value == 65535.0
    assert BitDepth.BD_32F.max_value == 1.0


@pytest.mark.parametrize("bd,bpc", [
    (BitDepth.BD_8, 1), (BitDepth.BD_10, 2), (BitDepth.BD_12, 2),
    (BitDepth.BD_14, 2), (BitDepth.BD_16, 2), (BitDepth.BD_32F, 4),
])
def test_bytes_per_channel(bd, bpc):
    assert bd.bytes_per_channel == bpc


def test_declared_memory_16k_16bit_rgb():
    img = Image16K.blank(15360, 8640, bit_depth=BitDepth.BD_16)
    expected = 15360 * 8640 * 3 * 2
    assert img.memory_bytes() == expected


@pytest.mark.parametrize("layout", list(ChannelLayout))
def test_channel_layouts_construct(layout):
    img = Image16K.blank(8, 8, channel_layout=layout)
    assert img.channels == layout.count


def test_channel_mismatch_raises():
    from sixteen_k.image import ImageMetadata
    with pytest.raises(ValueError):
        Image16K(np.zeros((4, 4, 3), dtype=np.float32), ImageMetadata(channel_layout=ChannelLayout.RGBA))


def test_quantize_roundtrip_8bit():
    img = Image16K.random(16, 16, seed=1, bit_depth=BitDepth.BD_8)
    q = img.quantize()
    # quantizing twice should be idempotent
    img2 = Image16K(q, img.meta)
    assert np.allclose(img2.quantize(), q, atol=1e-6)


def test_copy_is_independent():
    img = Image16K.random(8, 8, seed=2)
    dup = img.copy()
    dup.data[0, 0, 0] = 999.0
    assert img.data[0, 0, 0] != 999.0


def test_describe_contains_expected_fields():
    img = Image16K.blank(100, 50)
    d = img.describe()
    for key in ("width", "height", "pixel_count", "aspect_ratio", "bit_depth", "channels"):
        assert key in d
    assert d["width"] == 100 and d["height"] == 50
