"""Camera geometry (FOV/DOF/hyperfocal) and pinhole projection correctness."""
import math
import numpy as np
import pytest
from sixteen_k.camera import VirtualCamera
from sixteen_k.projection import ProjectionEngine


def test_fov_increases_with_wider_sensor():
    narrow = VirtualCamera(sensor_width_mm=24, focal_length_mm=50)
    wide = VirtualCamera(sensor_width_mm=36, focal_length_mm=50)
    assert wide.horizontal_fov_deg > narrow.horizontal_fov_deg


def test_fov_decreases_with_longer_focal_length():
    short = VirtualCamera(focal_length_mm=24)
    long_ = VirtualCamera(focal_length_mm=200)
    assert long_.horizontal_fov_deg < short.horizontal_fov_deg


def test_shallow_dof_for_telephoto_wide_aperture():
    cam = VirtualCamera(focal_length_mm=200, aperture_f_number=1.4, focus_distance_m=3)
    near, far, dof = cam.depth_of_field_m()
    assert dof < 1.0  # sub-meter DOF expected


def test_deep_dof_for_wide_angle_stopped_down():
    cam = VirtualCamera(focal_length_mm=14, aperture_f_number=11, focus_distance_m=2)
    near, far, dof = cam.depth_of_field_m()
    assert math.isinf(far) or dof > 5.0


def test_hyperfocal_distance_positive():
    cam = VirtualCamera()
    assert cam.hyperfocal_distance_m > 0


def test_camera_move_and_look_at():
    cam = VirtualCamera()
    cam.move(1, 2, 3)
    assert cam.position == (1, 2, 3)
    cam.look_at(0, 0, 0)
    assert cam.rotation_deg != (0.0, 0.0, 0.0)


def test_projection_center_point():
    cam = VirtualCamera(resolution_width=1920, resolution_height=1080, focal_length_mm=50,
                        sensor_width_mm=36, sensor_height_mm=20.25)
    pe = ProjectionEngine()
    pt = pe.project_point(cam, (0, 0, -10))
    assert abs(pt.pixel_x - 960) < 1e-6
    assert abs(pt.pixel_y - 540) < 1e-6
    assert pt.visible


def test_point_behind_camera_not_visible():
    cam = VirtualCamera(resolution_width=1920, resolution_height=1080)
    pe = ProjectionEngine()
    behind = pe.project_point(cam, (0, 0, 10))
    assert not behind.visible
    assert behind.depth < 0


def test_point_above_axis_projects_upper_half():
    cam = VirtualCamera(resolution_width=1920, resolution_height=1080, focal_length_mm=50,
                        sensor_width_mm=36, sensor_height_mm=20.25)
    pe = ProjectionEngine()
    above = pe.project_point(cam, (0, 5, -10))
    assert above.pixel_y < 540


def test_batch_projection_matches_scalar():
    cam = VirtualCamera(resolution_width=1920, resolution_height=1080)
    pe = ProjectionEngine()
    pts = np.array([[0, 0, -10], [3, 0, -10]])
    batch = pe.project_points(cam, pts)
    scalar = pe.project_point(cam, (0, 0, -10))
    assert abs(batch[0, 0] - scalar.pixel_x) < 1e-6
    assert abs(batch[0, 1] - scalar.pixel_y) < 1e-6
