"""Batch processing (concurrency-safe) and deterministic simulation mode."""
import os
import pytest
from sixteen_k.image import Image16K
from sixteen_k.export import ExportEngine
from sixteen_k.batch import BatchProcessor
from sixteen_k.simulation import SimulationEngine
from sixteen_k.processing import ImageProcessingEngine


@pytest.fixture
def sample_asset_dir(tmp_path):
    ee = ExportEngine()
    in_dir = tmp_path / "in"
    in_dir.mkdir()
    for i in range(5):
        img = Image16K.random(20, 16, seed=i)
        ee.export_still(img, str(in_dir / f"img_{i}.png"))
    return str(in_dir)


def test_batch_process_all_succeed(sample_asset_dir, tmp_path):
    pe = ImageProcessingEngine()
    bp = BatchProcessor(memory_budget_bytes=256 * 1024 * 1024)
    out_dir = str(tmp_path / "out")
    results = bp.batch_process(
        sample_asset_dir, out_dir,
        operations=[lambda im: pe.exposure(im, 0.1)],
        max_workers=4,
    )
    assert len(results) == 5
    assert all(r.success for r in results)
    assert len(os.listdir(out_dir)) == 5


def test_batch_worker_count_capped_by_memory(sample_asset_dir, tmp_path):
    bp = BatchProcessor(memory_budget_bytes=1)  # absurdly tight budget
    sample = Image16K.random(20, 16, seed=0)
    workers = bp._safe_worker_count(sample, requested_workers=8)
    assert workers == 1


def test_batch_empty_directory_returns_empty(tmp_path):
    bp = BatchProcessor()
    empty_in = tmp_path / "empty_in"
    empty_in.mkdir()
    results = bp.batch_process(str(empty_in), str(tmp_path / "empty_out"), operations=[])
    assert results == []


def test_simulation_seeded_reproducibility():
    sim1 = SimulationEngine(seed=99)
    walk1 = sim1.random_walk(5)
    sim2 = SimulationEngine(seed=99)
    walk2 = sim2.random_walk(5)
    positions1 = [s.camera_state["position"] for s in walk1]
    positions2 = [s.camera_state["position"] for s in walk2]
    assert positions1 == positions2


def test_simulation_different_seeds_diverge():
    sim1 = SimulationEngine(seed=1)
    sim2 = SimulationEngine(seed=2)
    walk1 = sim1.random_walk(5)
    walk2 = sim2.random_walk(5)
    positions1 = [s.camera_state["position"] for s in walk1]
    positions2 = [s.camera_state["position"] for s in walk2]
    assert positions1 != positions2


def test_simulation_lens_change_applies_to_camera():
    sim = SimulationEngine(seed=1)
    sim.step_lens_change(focal_length_mm=135, aperture_f_number=2.0)
    assert sim.twin.camera.focal_length_mm == 135
    assert sim.twin.camera.aperture_f_number == 2.0


def test_simulation_scene_change_creates_object():
    sim = SimulationEngine(seed=1)
    sim.step_scene_change("hero", position=(1, 2, 3))
    assert "hero" in sim.twin.scene.objects
    assert sim.twin.scene.objects["hero"].position == (1, 2, 3)
