"""Super-resolution framework: conventional upscaling + the ML backend slot."""
import numpy as np
import pytest
from sixteen_k.image import Image16K
from sixteen_k.superres import SuperResolutionEngine


def test_conventional_upscale_doubles_dimensions(small_image):
    sr = SuperResolutionEngine()
    out = sr.upscale_conventional(small_image, 2.0)
    assert out.width == small_image.width * 2
    assert out.height == small_image.height * 2


def test_ml_backend_not_registered_raises(small_image):
    sr = SuperResolutionEngine()
    with pytest.raises(KeyError):
        sr.upscale_ml(small_image, 2.0, "fantasy_model")


def test_ml_backend_registration_and_dispatch(small_image):
    sr = SuperResolutionEngine()

    def fake_backend(data, factor):
        h, w, c = data.shape
        return np.zeros((int(h * factor), int(w * factor), c), dtype=np.float32)

    sr.register_ml_backend("fake_sr", fake_backend)
    assert "fake_sr" in sr.available_ml_backends()
    out = sr.upscale(small_image, 2.0, backend="fake_sr")
    assert out.width == small_image.width * 2
    assert out.meta.extra["super_resolution_backend"] == "fake_sr"


def test_upscale_dispatcher_falls_back_to_conventional(small_image):
    sr = SuperResolutionEngine()
    out = sr.upscale(small_image, 2.0)
    assert out.width == small_image.width * 2
