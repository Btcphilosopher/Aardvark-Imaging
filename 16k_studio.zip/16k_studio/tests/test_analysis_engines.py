"""Histogram / waveform / vectorscope numerical validation."""
import numpy as np
from sixteen_k.histogram import HistogramEngine
from sixteen_k.waveform import WaveformEngine
from sixteen_k.vectorscope import Vectorscope
from sixteen_k.image import Image16K


def test_histogram_bin_counts_sum_to_pixel_count(small_image):
    he = HistogramEngine()
    hist = he.rgb_histogram(small_image, bins=64)
    assert hist["R"].sum() == small_image.pixel_count


def test_full_report_contains_all_channels(small_image):
    he = HistogramEngine()
    report = he.full_report(small_image)
    assert set(report["channels"].keys()) == {"R", "G", "B"}
    assert "luminance" in report


def test_waveform_column_sums_equal_column_height(small_image):
    we = WaveformEngine()
    lw = we.luminance_waveform(small_image, levels=64)
    assert lw.shape == (64, small_image.width)
    assert (lw.sum(axis=0) == small_image.height).all()


def test_vectorscope_saturation_between_0_and_1(small_image):
    vs = Vectorscope()
    result = vs.analyze(small_image)
    assert 0.0 <= result["mean_saturation"] <= 1.0


def test_vectorscope_grayscale_has_zero_saturation():
    img = Image16K.blank(10, 10, fill=0.5)
    vs = Vectorscope()
    result = vs.analyze(img)
    assert result["mean_saturation"] < 1e-6


def test_hdr_histogram_runs_on_bright_data():
    he = HistogramEngine()
    img = Image16K.random(16, 16, seed=1)
    img.data *= 4.0
    hist = he.hdr_histogram(img, bins=32)
    assert hist.sum() > 0
