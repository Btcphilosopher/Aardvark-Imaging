// ============================================================================
// AARDVARK RUNTIME - 2D PHYSICS SIMULATION WORLD
// Velocity verlet/Euler integration with impulse-based collision resolution
// ============================================================================

import { RigidBody } from './rigid-body';
import { testCollision } from './collision';
import { Vec2 } from '../core/math';
import { RuntimeEventBus } from '../core/event-bus';

export class PhysicsWorld {
  public gravity: Vec2 = new Vec2(0, 300); // 300 px/s^2 down
  public bodies: RigidBody[] = [];
  public enabled: boolean = true;
  private eventBus: RuntimeEventBus;

  // World boundary constraints
  public bounds: { minX: number; maxX: number; minY: number; maxY: number } | null = {
    minX: -380,
    maxX: 380,
    minY: -280,
    maxY: 280,
  };

  constructor(eventBus: RuntimeEventBus) {
    this.eventBus = eventBus;
  }

  addBody(body: RigidBody): void {
    if (!this.bodies.includes(body)) {
      this.bodies.push(body);
    }
  }

  removeBody(body: RigidBody): void {
    const idx = this.bodies.indexOf(body);
    if (idx !== -1) {
      this.bodies.splice(idx, 1);
    }
  }

  clear(): void {
    this.bodies = [];
  }

  step(dt: number): void {
    if (!this.enabled || dt <= 0) return;
    dt = Math.min(dt, 0.05); // Clamp dt to prevent tunneling

    // 1. Apply gravity and integrate forces
    for (const b of this.bodies) {
      if (b.type !== 'dynamic') continue;

      b.velocity.x += (b.acceleration.x + this.gravity.x * b.gravityScale) * dt;
      b.velocity.y += (b.acceleration.y + this.gravity.y * b.gravityScale) * dt;

      // Reset accelerations
      b.acceleration.set(0, 0);

      // Dampen velocity slightly with friction
      b.velocity.scale(Math.pow(b.friction, dt * 60));

      // Integrate position
      b.node.transform.x += b.velocity.x * dt;
      b.node.transform.y += b.velocity.y * dt;
      b.node.markDirty();

      // Constrain within world boundaries if set
      if (this.bounds) {
        const rad = b.radius || b.width / 2;
        if (b.node.transform.x - rad < this.bounds.minX) {
          b.node.transform.x = this.bounds.minX + rad;
          b.velocity.x = -b.velocity.x * b.restitution;
        } else if (b.node.transform.x + rad > this.bounds.maxX) {
          b.node.transform.x = this.bounds.maxX - rad;
          b.velocity.x = -b.velocity.x * b.restitution;
        }

        if (b.node.transform.y - rad < this.bounds.minY) {
          b.node.transform.y = this.bounds.minY + rad;
          b.velocity.y = -b.velocity.y * b.restitution;
        } else if (b.node.transform.y + rad > this.bounds.maxY) {
          b.node.transform.y = this.bounds.maxY - rad;
          b.velocity.y = -b.velocity.y * b.restitution;
        }
      }
    }

    // 2. Collision Detection & Resolution
    for (let i = 0; i < this.bodies.length; i++) {
      for (let j = i + 1; j < this.bodies.length; j++) {
        const a = this.bodies[i];
        const b = this.bodies[j];

        if (a.type === 'static' && b.type === 'static') continue;

        const manifold = testCollision(a, b);
        if (manifold) {
          this.resolveCollision(manifold);
          this.eventBus.emit('physics:collision', { bodyA: a, bodyB: b });
        }
      }
    }
  }

  private resolveCollision(m: any): void {
    const a: RigidBody = m.bodyA;
    const b: RigidBody = m.bodyB;
    const normal: Vec2 = m.normal;
    const depth: number = m.depth;

    // Relative velocity
    const rvx = b.velocity.x - a.velocity.x;
    const rvy = b.velocity.y - a.velocity.y;
    const velAlongNormal = rvx * normal.x + rvy * normal.y;

    if (velAlongNormal > 0) return; // Moving apart

    // Restitution
    const e = Math.min(a.restitution, b.restitution);

    // Impulse scalar
    let j = -(1 + e) * velAlongNormal;
    const totalInvMass = a.invMass + b.invMass;
    if (totalInvMass === 0) return;
    j /= totalInvMass;

    // Apply impulse
    const impulseX = normal.x * j;
    const impulseY = normal.y * j;

    if (a.type === 'dynamic') {
      a.velocity.x -= a.invMass * impulseX;
      a.velocity.y -= a.invMass * impulseY;
    }
    if (b.type === 'dynamic') {
      b.velocity.x += b.invMass * impulseX;
      b.velocity.y += b.invMass * impulseY;
    }

    // Positional correction (prevent sinking)
    const percent = 0.5;
    const slop = 0.01;
    const correctionMagnitude = (Math.max(depth - slop, 0) / totalInvMass) * percent;
    const cx = normal.x * correctionMagnitude;
    const cy = normal.y * correctionMagnitude;

    if (a.type === 'dynamic') {
      a.node.transform.x -= a.invMass * cx;
      a.node.transform.y -= a.invMass * cy;
      a.node.markDirty();
    }
    if (b.type === 'dynamic') {
      b.node.transform.x += b.invMass * cx;
      b.node.transform.y += b.invMass * cy;
      b.node.markDirty();
    }
  }
}
