// ============================================================================
// AARDVARK RUNTIME - 2D RIGID BODY
// ============================================================================

import { Vec2 } from '../core/math';
import { SceneNode } from '../scene/node';

export type BodyType = 'dynamic' | 'static' | 'kinematic';
export type ColliderShape = 'circle' | 'box';

export class RigidBody {
  public id: string;
  public node: SceneNode;
  public type: BodyType = 'dynamic';
  public shape: ColliderShape = 'circle';
  public radius: number = 20;
  public width: number = 40;
  public height: number = 40;

  // Physical properties
  public velocity: Vec2 = new Vec2(0, 0);
  public acceleration: Vec2 = new Vec2(0, 0);
  public mass: number = 1.0;
  public invMass: number = 1.0;
  public restitution: number = 0.75; // Bounciness
  public friction: number = 0.98;
  public gravityScale: number = 1.0;

  constructor(node: SceneNode, type: BodyType = 'dynamic', shape: ColliderShape = 'circle') {
    this.id = `body_${Math.random().toString(36).substring(2, 9)}`;
    this.node = node;
    this.type = type;
    this.shape = shape;
    this.setMass(type === 'static' ? 0 : 1.0);
  }

  setMass(m: number): void {
    this.mass = m;
    this.invMass = m > 0 ? 1 / m : 0;
  }

  applyForce(fx: number, fy: number): void {
    if (this.type !== 'dynamic') return;
    this.acceleration.x += fx * this.invMass;
    this.acceleration.y += fy * this.invMass;
  }

  applyImpulse(ix: number, iy: number): void {
    if (this.type !== 'dynamic') return;
    this.velocity.x += ix * this.invMass;
    this.velocity.y += iy * this.invMass;
  }
}
