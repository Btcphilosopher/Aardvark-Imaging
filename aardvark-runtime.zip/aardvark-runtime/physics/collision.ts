// ============================================================================
// AARDVARK RUNTIME - 2D COLLISION DETECTION & MANIFOLD
// Narrowphase collision tests: Circle-Circle, Circle-Box, Box-Box
// ============================================================================

import { RigidBody } from './rigid-body';
import { Vec2 } from '../core/math';

export interface CollisionManifold {
  bodyA: RigidBody;
  bodyB: RigidBody;
  normal: Vec2; // Normal pointing from A to B
  depth: number;
}

export function testCollision(a: RigidBody, b: RigidBody): CollisionManifold | null {
  if (a.shape === 'circle' && b.shape === 'circle') {
    return testCircleCircle(a, b);
  } else if (a.shape === 'circle' && b.shape === 'box') {
    return testCircleBox(a, b);
  } else if (a.shape === 'box' && b.shape === 'circle') {
    const m = testCircleBox(b, a);
    if (m) {
      m.normal.scale(-1);
      return { bodyA: a, bodyB: b, normal: m.normal, depth: m.depth };
    }
    return null;
  }
  return null;
}

function testCircleCircle(a: RigidBody, b: RigidBody): CollisionManifold | null {
  const posA = a.node.transform;
  const posB = b.node.transform;

  const dx = posB.x - posA.x;
  const dy = posB.y - posA.y;
  const distSq = dx * dx + dy * dy;
  const radSum = a.radius + b.radius;

  if (distSq < radSum * radSum) {
    const dist = Math.sqrt(distSq) || 0.0001;
    const depth = radSum - dist;
    const normal = new Vec2(dx / dist, dy / dist);
    return { bodyA: a, bodyB: b, normal, depth };
  }

  return null;
}

function testCircleBox(c: RigidBody, box: RigidBody): CollisionManifold | null {
  const cPos = c.node.transform;
  const bPos = box.node.transform;

  // Box bounds
  const halfW = box.width / 2;
  const halfH = box.height / 2;

  // Closest point on box to circle center
  const closestX = Math.max(bPos.x - halfW, Math.min(bPos.x + halfW, cPos.x));
  const closestY = Math.max(bPos.y - halfH, Math.min(bPos.y + halfH, cPos.y));

  const dx = cPos.x - closestX;
  const dy = cPos.y - closestY;
  const distSq = dx * dx + dy * dy;

  if (distSq < c.radius * c.radius) {
    const dist = Math.sqrt(distSq) || 0.0001;
    const depth = c.radius - dist;
    const normal = new Vec2(dx / dist, dy / dist);
    return { bodyA: c, bodyB: box, normal, depth };
  }

  return null;
}
