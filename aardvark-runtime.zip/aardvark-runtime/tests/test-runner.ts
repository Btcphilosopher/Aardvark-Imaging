// ============================================================================
// AARDVARK RUNTIME - AUTOMATED TEST RUNNER
// In-engine test framework executing subsystem unit & integration assertions
// ============================================================================

export interface TestResult {
  suiteName: string;
  testName: string;
  passed: boolean;
  durationMs: number;
  error?: string;
}

export interface TestSuiteResult {
  suiteName: string;
  totalTests: number;
  passedCount: number;
  failedCount: number;
  durationMs: number;
  results: TestResult[];
}

export class TestAssert {
  static ok(condition: any, message: string = 'Assertion failed'): void {
    if (!condition) {
      throw new Error(message);
    }
  }

  static equal<T>(actual: T, expected: T, message?: string): void {
    if (actual !== expected) {
      throw new Error(message || `Expected ${expected} but received ${actual}`);
    }
  }

  static near(actual: number, expected: number, epsilon: number = 0.001, message?: string): void {
    if (Math.abs(actual - expected) > epsilon) {
      throw new Error(message || `Expected ${actual} to be close to ${expected} (within ${epsilon})`);
    }
  }

  static deepEqual(actual: any, expected: any, message?: string): void {
    const actStr = JSON.stringify(actual);
    const expStr = JSON.stringify(expected);
    if (actStr !== expStr) {
      throw new Error(message || `Objects not equal:\nActual: ${actStr}\nExpected: ${expStr}`);
    }
  }
}

export type TestCase = (assert: typeof TestAssert) => void | Promise<void>;

export class TestRunner {
  private suites: Map<string, Array<{ name: string; fn: TestCase }>> = new Map();

  describe(suiteName: string, defineTests: () => void): void {
    if (!this.suites.has(suiteName)) {
      this.suites.set(suiteName, []);
    }
    this.currentSuiteName = suiteName;
    defineTests();
    this.currentSuiteName = '';
  }

  private currentSuiteName: string = '';

  it(testName: string, testFn: TestCase): void {
    const suiteName = this.currentSuiteName || 'Default Suite';
    if (!this.suites.has(suiteName)) {
      this.suites.set(suiteName, []);
    }
    this.suites.get(suiteName)!.push({ name: testName, fn: testFn });
  }

  async runAll(): Promise<TestSuiteResult[]> {
    const suiteResults: TestSuiteResult[] = [];

    for (const [suiteName, tests] of this.suites.entries()) {
      const suiteStart = performance.now();
      const results: TestResult[] = [];
      let passed = 0;
      let failed = 0;

      for (const test of tests) {
        const start = performance.now();
        try {
          await test.fn(TestAssert);
          const dur = performance.now() - start;
          results.push({ suiteName, testName: test.name, passed: true, durationMs: dur });
          passed++;
        } catch (err: any) {
          const dur = performance.now() - start;
          results.push({
            suiteName,
            testName: test.name,
            passed: false,
            durationMs: dur,
            error: err.message,
          });
          failed++;
        }
      }

      suiteResults.push({
        suiteName,
        totalTests: tests.length,
        passedCount: passed,
        failedCount: failed,
        durationMs: performance.now() - suiteStart,
        results,
      });
    }

    return suiteResults;
  }
}
