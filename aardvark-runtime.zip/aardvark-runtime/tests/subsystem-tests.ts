// ============================================================================
// AARDVARK RUNTIME - SUBSYSTEM TEST SUITES
// Automated verification tests across all core engine modules
// ============================================================================

import { TestRunner } from './test-runner';
import { Vec2, Mat3, Color } from '../core/math';
import { GroupNode, ShapeNode } from '../scene/shapes';
import { Timeline } from '../timeline/timeline';
import { TimelineTrack } from '../timeline/track';
import { RigidBody } from '../physics/rigid-body';
import { testCollision } from '../physics/collision';
import { ParticleEmitterNode } from '../scene/particles';
import { Object3DNode } from '../scene/object3d';
import { RuntimeEventBus } from '../core/event-bus';
import { RuntimeProfiler } from '../core/diagnostics';
import { ProjectSerializer } from '../project/project-serializer';
import { ProjectLoader } from '../project/project-loader';
import { PhysicsWorld } from '../physics/physics-world';
import { ScriptEngine } from '../scripting/script-engine';
import { AudioEngine } from '../audio/audio-engine';
import { Scene } from '../scene/scene';

export function registerSubsystemTests(runner: TestRunner): void {
  // 1. Math & Matrix Transformations
  runner.describe('Subsystem 1: Core Math & Matrix Transforms', () => {
    runner.it('Mat3 identity preserves points', (assert) => {
      const m = new Mat3();
      const p = new Vec2(15, 25);
      const out = m.transformPoint(p);
      assert.equal(out.x, 15);
      assert.equal(out.y, 25);
    });

    runner.it('Mat3 translation and rotation composition', (assert) => {
      const m = new Mat3();
      m.translate(100, 50);
      m.rotate(Math.PI / 2); // 90 deg clockwise
      const out = m.transformPoint(new Vec2(10, 0));
      assert.near(out.x, 100);
      assert.near(out.y, 60);
    });

    runner.it('Mat3 inversion roundtrip', (assert) => {
      const m = new Mat3();
      m.translate(45, -30);
      m.scale(2, 3);
      const inv = m.clone().invert();
      const composed = m.clone().multiply(inv);
      const p = new Vec2(10, 20);
      const out = composed.transformPoint(p);
      assert.near(out.x, 10);
      assert.near(out.y, 20);
    });
  });

  // 2. Scene Graph Hierarchy & Transforms
  runner.describe('Subsystem 2: Scene Graph & Transform Hierarchy', () => {
    runner.it('Parent-child world matrix cascade', (assert) => {
      const parent = new GroupNode('Parent');
      parent.transform.x = 100;
      parent.transform.y = 50;

      const child = new ShapeNode('Child');
      child.transform.x = 20;
      child.transform.y = 10;
      parent.addChild(child);

      parent.updateWorldTransform(true);

      const worldPos = child.localToGlobal(new Vec2(0, 0));
      assert.equal(worldPos.x, 120);
      assert.equal(worldPos.y, 60);
    });

    runner.it('Opacity multiplication down tree', (assert) => {
      const parent = new GroupNode('Parent');
      parent.opacity = 0.5;

      const child = new ShapeNode('Child');
      child.opacity = 0.5;
      parent.addChild(child);

      parent.updateWorldTransform(true);
      assert.near(child.worldOpacity, 0.25);
    });
  });

  // 3. Timeline Engine & Keyframe Interpolation
  runner.describe('Subsystem 3: Timeline Engine & Keyframes', () => {
    runner.it('Linear keyframe interpolation', (assert) => {
      const track = new TimelineTrack('TrackX', 'test_node', 'transform.x');
      track.addKeyframe({ frame: 0, value: 0, easing: 'linear' });
      track.addKeyframe({ frame: 100, value: 200, easing: 'linear' });

      const mid = track.evaluate(50);
      assert.ok(mid !== null);
      assert.near(mid!.value, 100);
    });

    runner.it('Timeline frame step & looping', (assert) => {
      const tl = new Timeline('TestTimeline', 30, 100);
      tl.currentFrame = 95;
      tl.loop = true;
      tl.tick(1.0); // 1.0s = 30 frames -> 95 + 30 = 125 -> wraps to 26
      assert.ok(tl.currentFrame >= 1 && tl.currentFrame <= 100);
    });
  });

  // 4. 2D Physics Engine & Collisions
  runner.describe('Subsystem 4: 2D Rigid Body Physics', () => {
    runner.it('Circle-Circle collision detection', (assert) => {
      const nodeA = new ShapeNode('A');
      nodeA.transform.x = 0;
      nodeA.transform.y = 0;

      const nodeB = new ShapeNode('B');
      nodeB.transform.x = 30; // Within radius sum 20 + 20 = 40
      nodeB.transform.y = 0;

      const bodyA = new RigidBody(nodeA, 'dynamic', 'circle');
      bodyA.radius = 20;

      const bodyB = new RigidBody(nodeB, 'dynamic', 'circle');
      bodyB.radius = 20;

      const manifold = testCollision(bodyA, bodyB);
      assert.ok(manifold !== null);
      assert.near(manifold!.depth, 10);
    });

    runner.it('Physics world gravity step', (assert) => {
      const bus = new RuntimeEventBus();
      const world = new PhysicsWorld(bus);
      world.bounds = null; // No boundary
      world.gravity.set(0, 100);

      const node = new ShapeNode('FallNode');
      node.transform.y = 0;
      const body = new RigidBody(node, 'dynamic', 'circle');
      world.addBody(body);

      world.step(0.1); // 0.1s
      assert.ok(node.transform.y > 0);
    });
  });

  // 5. Particle Simulation Subsystem
  runner.describe('Subsystem 5: Particle Emitter Lifecycle', () => {
    runner.it('Particle burst spawns active particles', (assert) => {
      const emitter = new ParticleEmitterNode('TestEmitter');
      assert.equal(emitter.getActiveCount(), 0);

      emitter.burst(15);
      assert.equal(emitter.getActiveCount(), 15);
    });

    runner.it('Particles age and expire after maxLife', (assert) => {
      const emitter = new ParticleEmitterNode('TestEmitter');
      emitter.burst(5);
      emitter.lifetimeMin = 0.1;
      emitter.lifetimeMax = 0.1;
      // Advance by 0.25 seconds
      emitter.update(0.25);
      assert.equal(emitter.getActiveCount(), 0);
    });
  });

  // 6. 3D Object Subsystem
  runner.describe('Subsystem 6: 3D Mesh & Normal Calculations', () => {
    runner.it('Cube preset builds 8 vertices and 12 faces', (assert) => {
      const cube = new Object3DNode('Cube', 'cube');
      assert.equal(cube.vertices.length, 8);
      assert.equal(cube.faces.length, 12);
    });

    runner.it('Normals are normalized unit vectors', (assert) => {
      const cube = new Object3DNode('Cube', 'cube');
      for (const face of cube.faces) {
        if (face.normal) {
          const len = Math.sqrt(
            face.normal.x * face.normal.x + face.normal.y * face.normal.y + face.normal.z * face.normal.z
          );
          assert.near(len, 1.0);
        }
      }
    });
  });

  // 7. Event Bus & Subsystem Communication
  runner.describe('Subsystem 7: Event Bus Communication', () => {
    runner.it('Dispatches events to registered listeners', (assert) => {
      const bus = new RuntimeEventBus();
      let received = '';
      bus.on('test:event', (data) => {
        received = data.msg;
      });
      bus.emit('test:event', { msg: 'Aardvark Active' });
      assert.equal(received, 'Aardvark Active');
    });

    runner.it('Unsubscribe removes listener cleanly', (assert) => {
      const bus = new RuntimeEventBus();
      let count = 0;
      const sub = bus.on('ping', () => count++);
      bus.emit('ping');
      assert.equal(count, 1);
      sub.unsubscribe();
      bus.emit('ping');
      assert.equal(count, 1);
    });
  });

  // 8. Project Serialization Round-Trip
  runner.describe('Subsystem 8: Project Serialization Round-Trip', () => {
    runner.it('Serializes and deserializes scene graph consistently', (assert) => {
      const bus = new RuntimeEventBus();
      const phys = new PhysicsWorld(bus);
      const audio = new AudioEngine();
      const script = new ScriptEngine(bus, audio, phys);

      const scene = new Scene('OriginalScene');
      const box = new ShapeNode('Box1');
      box.transform.x = 55;
      box.transform.y = 88;
      scene.addNode(box);

      const serialized = ProjectSerializer.serialize(scene, 'Test');
      assert.equal(serialized.scenes[0].name, 'OriginalScene');

      const reloaded = ProjectLoader.loadProject(serialized, phys, script, audio);
      const foundBox = reloaded.findNodeById('Box1');
      assert.ok(foundBox !== null);
      assert.equal(foundBox!.transform.x, 55);
      assert.equal(foundBox!.transform.y, 88);
    });
  });

  // 9. Diagnostics & Profiling
  runner.describe('Subsystem 9: Telemetry & Profiler', () => {
    runner.it('Tracks frame delta and produces JSON report', (assert) => {
      const profiler = new RuntimeProfiler();
      profiler.recordFrame();
      profiler.setRenderStats(42, 120, 15);
      const metrics = profiler.getMetrics();
      assert.equal(metrics.drawCalls, 42);
      assert.equal(metrics.triangles, 120);

      const report = profiler.exportReport();
      assert.ok(report.includes('Aardvark Runtime Engine'));
    });
  });
}
