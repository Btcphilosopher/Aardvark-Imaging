// ============================================================================
// AARDVARK RUNTIME - TIMELINE TRACK
// High-performance property tracks with keyframe interpolation
// ============================================================================

import { Keyframe } from './keyframe';
import { evaluateEasing } from './easing';
import { SceneNode } from '../scene/node';
import { Color } from '../core/math';

export class TimelineTrack {
  public id: string;
  public name: string;
  public targetNodeId: string;
  public propertyPath: string; // e.g. 'transform.x', 'transform.rotation', 'opacity', 'fill.color'
  public keyframes: Keyframe[] = [];
  public enabled: boolean = true;

  constructor(
    name: string,
    targetNodeId: string,
    propertyPath: string,
    id?: string
  ) {
    this.name = name;
    this.targetNodeId = targetNodeId;
    this.propertyPath = propertyPath;
    this.id = id || `track_${Math.random().toString(36).substring(2, 9)}`;
  }

  addKeyframe(kf: Keyframe): this {
    // Insert in sorted frame order
    const existingIdx = this.keyframes.findIndex((k) => k.frame === kf.frame);
    if (existingIdx !== -1) {
      this.keyframes[existingIdx] = kf;
    } else {
      this.keyframes.push(kf);
      this.keyframes.sort((a, b) => a.frame - b.frame);
    }
    return this;
  }

  removeKeyframeAt(frame: number): boolean {
    const idx = this.keyframes.findIndex((k) => k.frame === frame);
    if (idx !== -1) {
      this.keyframes.splice(idx, 1);
      return true;
    }
    return false;
  }

  evaluate(frame: number): { value: any; isBlank: boolean } | null {
    if (!this.enabled || this.keyframes.length === 0) {
      return null;
    }

    // Before first keyframe
    if (frame <= this.keyframes[0].frame) {
      const first = this.keyframes[0];
      return { value: first.value, isBlank: !!first.isBlank };
    }

    // After last keyframe
    const last = this.keyframes[this.keyframes.length - 1];
    if (frame >= last.frame) {
      return { value: last.value, isBlank: !!last.isBlank };
    }

    // Find bounding keyframes [k0, k1]
    let k0 = this.keyframes[0];
    let k1 = this.keyframes[1];
    for (let i = 0; i < this.keyframes.length - 1; i++) {
      if (frame >= this.keyframes[i].frame && frame <= this.keyframes[i + 1].frame) {
        k0 = this.keyframes[i];
        k1 = this.keyframes[i + 1];
        break;
      }
    }

    if (k0.isBlank) {
      return { value: k0.value, isBlank: true };
    }

    if (k0.isHold || k0.frame === k1.frame) {
      return { value: k0.value, isBlank: false };
    }

    // Calculate normalized progress t
    const span = k1.frame - k0.frame;
    const rawT = (frame - k0.frame) / span;
    const easedT = evaluateEasing(rawT, k0.easing || 'linear');

    // Interpolate value based on type
    const val0 = k0.value;
    const val1 = k1.value;

    if (typeof val0 === 'number' && typeof val1 === 'number') {
      const interpolated = val0 + (val1 - val0) * easedT;
      return { value: interpolated, isBlank: false };
    } else if (typeof val0 === 'string' && val0.startsWith('#') && typeof val1 === 'string' && val1.startsWith('#')) {
      const c0 = Color.fromHex(val0);
      const c1 = Color.fromHex(val1);
      const lerped = c0.lerp(c1, easedT);
      return { value: lerped.toHex(), isBlank: false };
    } else {
      // Step value for non-numerics
      return { value: easedT >= 1 ? val1 : val0, isBlank: false };
    }
  }

  applyToNode(root: SceneNode, frame: number): void {
    const res = this.evaluate(frame);
    if (!res) return;

    const node = root.findChildById(this.targetNodeId);
    if (!node) return;

    if (res.isBlank) {
      node.visible = false;
      return;
    } else {
      node.visible = true;
    }

    this.setProperty(node, this.propertyPath, res.value);
    node.markDirty();
  }

  private setProperty(obj: any, path: string, val: any): void {
    const parts = path.split('.');
    let curr = obj;
    for (let i = 0; i < parts.length - 1; i++) {
      if (!curr[parts[i]]) return;
      curr = curr[parts[i]];
    }
    curr[parts[parts.length - 1]] = val;
  }
}
