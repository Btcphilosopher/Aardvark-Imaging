// ============================================================================
// AARDVARK RUNTIME - TIMELINE ENGINE
// Production-grade frame & time-based animation timeline
// ============================================================================

import { TimelineTrack } from './track';
import { SceneNode } from '../scene/node';

export interface FrameMarker {
  frame: number;
  label: string;
  actionScript?: string;
  audioTrigger?: string;
}

export type PlaybackDirection = 'forward' | 'reverse';

export class Timeline {
  public id: string;
  public name: string;
  public tracks: TimelineTrack[] = [];
  public markers: Map<number, FrameMarker> = new Map();

  // Playback parameters
  public fps: number = 30;
  public durationFrames: number = 120;
  public currentFrame: number = 1; // Floating point frame position
  public isPlaying: boolean = true;
  public loop: boolean = true;
  public pingPong: boolean = false;
  public direction: PlaybackDirection = 'forward';
  public playbackSpeed: number = 1.0; // 0.25x to 4.0x
  public subFrameInterpolation: boolean = true;

  // Listeners
  public onFrameChange?: (frame: number, timeline: Timeline) => void;
  public onMarkerReached?: (marker: FrameMarker, timeline: Timeline) => void;

  private lastIntFrame: number = 1;

  constructor(name: string = 'Timeline', fps: number = 30, duration: number = 120) {
    this.name = name;
    this.fps = fps;
    this.durationFrames = duration;
    this.id = `timeline_${Math.random().toString(36).substring(2, 9)}`;
  }

  addTrack(track: TimelineTrack): this {
    this.tracks.push(track);
    return this;
  }

  removeTrack(trackId: string): boolean {
    const idx = this.tracks.findIndex((t) => t.id === trackId);
    if (idx !== -1) {
      this.tracks.splice(idx, 1);
      return true;
    }
    return false;
  }

  addMarker(frame: number, label: string, actionScript?: string, audioTrigger?: string): this {
    this.markers.set(frame, { frame, label, actionScript, audioTrigger });
    return this;
  }

  getMarkerAt(frame: number): FrameMarker | undefined {
    return this.markers.get(Math.round(frame));
  }

  getFrameByLabel(label: string): number | null {
    for (const [frame, marker] of this.markers.entries()) {
      if (marker.label.toLowerCase() === label.toLowerCase()) {
        return frame;
      }
    }
    return null;
  }

  play(): void {
    this.isPlaying = true;
  }

  pause(): void {
    this.isPlaying = false;
  }

  stop(): void {
    this.isPlaying = false;
    this.currentFrame = 1;
    this.direction = 'forward';
  }

  gotoAndPlay(frameOrLabel: number | string): void {
    const target = typeof frameOrLabel === 'string' ? this.getFrameByLabel(frameOrLabel) : frameOrLabel;
    if (target !== null) {
      this.currentFrame = Math.max(1, Math.min(this.durationFrames, target));
      this.isPlaying = true;
    }
  }

  gotoAndStop(frameOrLabel: number | string): void {
    const target = typeof frameOrLabel === 'string' ? this.getFrameByLabel(frameOrLabel) : frameOrLabel;
    if (target !== null) {
      this.currentFrame = Math.max(1, Math.min(this.durationFrames, target));
      this.isPlaying = false;
    }
  }

  step(frames: number = 1): void {
    this.isPlaying = false;
    this.currentFrame = Math.max(1, Math.min(this.durationFrames, this.currentFrame + frames));
  }

  tick(dt: number, sceneRoot?: SceneNode): void {
    if (!this.isPlaying) {
      if (sceneRoot) {
        this.evaluateAt(this.currentFrame, sceneRoot);
      }
      return;
    }

    const frameDelta = dt * this.fps * this.playbackSpeed;
    if (this.direction === 'forward') {
      this.currentFrame += frameDelta;
      if (this.currentFrame >= this.durationFrames) {
        if (this.pingPong) {
          this.currentFrame = this.durationFrames;
          this.direction = 'reverse';
        } else if (this.loop) {
          this.currentFrame = 1 + (this.currentFrame - this.durationFrames);
        } else {
          this.currentFrame = this.durationFrames;
          this.isPlaying = false;
        }
      }
    } else {
      this.currentFrame -= frameDelta;
      if (this.currentFrame <= 1) {
        if (this.pingPong) {
          this.currentFrame = 1;
          this.direction = 'forward';
        } else if (this.loop) {
          this.currentFrame = this.durationFrames - (1 - this.currentFrame);
        } else {
          this.currentFrame = 1;
          this.isPlaying = false;
        }
      }
    }

    // Marker checking
    const intFrame = Math.floor(this.currentFrame);
    if (intFrame !== this.lastIntFrame) {
      const marker = this.markers.get(intFrame);
      if (marker && this.onMarkerReached) {
        this.onMarkerReached(marker, this);
      }
      this.lastIntFrame = intFrame;
    }

    if (sceneRoot) {
      const evalFrame = this.subFrameInterpolation ? this.currentFrame : intFrame;
      this.evaluateAt(evalFrame, sceneRoot);
    }

    if (this.onFrameChange) {
      this.onFrameChange(this.currentFrame, this);
    }
  }

  evaluateAt(frame: number, sceneRoot: SceneNode): void {
    for (let i = 0; i < this.tracks.length; i++) {
      this.tracks[i].applyToNode(sceneRoot, frame);
    }
  }

  toggleLoop(): boolean {
    this.loop = !this.loop;
    return this.loop;
  }

  togglePingPong(): boolean {
    this.pingPong = !this.pingPong;
    return this.pingPong;
  }

  toggleDirection(): string {
    this.direction = this.direction === 'forward' ? 'reverse' : 'forward';
    return this.direction;
  }

  setSpeed(speed: number): void {
    this.playbackSpeed = speed;
  }

  setFps(targetFps: number): void {
    this.fps = targetFps;
  }

  getTimeString(): string {
    const totalSeconds = (this.currentFrame - 1) / this.fps;
    const mins = Math.floor(totalSeconds / 60);
    const secs = Math.floor(totalSeconds % 60);
    const millis = Math.floor((totalSeconds % 1) * 100);
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}.${String(millis).padStart(2, '0')}`;
  }
}
