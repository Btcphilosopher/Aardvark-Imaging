// ============================================================================
// AARDVARK RUNTIME - EASING & INTERPOLATION FUNCTIONS
// Standard and cubic bezier interpolators for timeline keyframes
// ============================================================================

export type EasingType =
  | 'linear'
  | 'easeInQuad'
  | 'easeOutQuad'
  | 'easeInOutQuad'
  | 'easeInCubic'
  | 'easeOutCubic'
  | 'easeInOutCubic'
  | 'easeInBack'
  | 'easeOutBack'
  | 'easeInOutBack'
  | 'easeOutBounce'
  | 'step';

export function evaluateEasing(t: number, type: EasingType = 'linear'): number {
  t = Math.max(0, Math.min(1, t));

  switch (type) {
    case 'linear':
      return t;
    case 'easeInQuad':
      return t * t;
    case 'easeOutQuad':
      return t * (2 - t);
    case 'easeInOutQuad':
      return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
    case 'easeInCubic':
      return t * t * t;
    case 'easeOutCubic':
      return --t * t * t + 1;
    case 'easeInOutCubic':
      return t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1;
    case 'easeInBack': {
      const s = 1.70158;
      return t * t * ((s + 1) * t - s);
    }
    case 'easeOutBack': {
      const s = 1.70158;
      return --t * t * ((s + 1) * t + s) + 1;
    }
    case 'easeInOutBack': {
      let s = 1.70158 * 1.525;
      if ((t *= 2) < 1) return 0.5 * (t * t * ((s + 1) * t - s));
      return 0.5 * ((t -= 2) * t * ((s + 1) * t + s) + 2);
    }
    case 'easeOutBounce': {
      const n1 = 7.5625;
      const d1 = 2.75;
      if (t < 1 / d1) {
        return n1 * t * t;
      } else if (t < 2 / d1) {
        return n1 * (t -= 1.5 / d1) * t + 0.75;
      } else if (t < 2.5 / d1) {
        return n1 * (t -= 2.25 / d1) * t + 0.9375;
      } else {
        return n1 * (t -= 2.625 / d1) * t + 0.984375;
      }
    }
    case 'step':
      return t >= 1 ? 1 : 0;
    default:
      return t;
  }
}
