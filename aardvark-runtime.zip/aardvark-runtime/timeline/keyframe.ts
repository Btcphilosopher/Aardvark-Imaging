// ============================================================================
// AARDVARK RUNTIME - KEYFRAME DEFINITIONS
// ============================================================================

import { EasingType } from './easing';

export interface Keyframe<T = any> {
  id?: string;
  frame: number; // 1-based or 0-based frame index
  value: T;
  easing?: EasingType;
  label?: string; // Marker/label at this keyframe
  isHold?: boolean; // If true, hold value until next keyframe (no interpolation)
  isBlank?: boolean; // Blank keyframe (invisible / unexposed)
  action?: string; // Optional script or event triggered on arrival
}

export interface ExposureSpan {
  startFrame: number;
  endFrame: number;
  visible: boolean;
}
