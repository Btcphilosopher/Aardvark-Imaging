// ============================================================================
// AARDVARK RUNTIME - PROFILER & DIAGNOSTICS
// Real-time telemetry, memory estimation, performance tracking, and export
// ============================================================================

import { PerformanceMetrics } from './types';

export class RuntimeProfiler {
  private metrics: PerformanceMetrics = {
    fps: 60,
    frameTimeMs: 16.6,
    updateTimeMs: 1.0,
    renderTimeMs: 2.0,
    physicsTimeMs: 0.5,
    scriptTimeMs: 0.5,
    drawCalls: 0,
    triangles: 0,
    nodesRendered: 0,
    activeParticles: 0,
    activeAudioVoices: 0,
    physicsBodies: 0,
    memoryEstimateKb: 1024,
  };

  private frameTimes: number[] = [];
  private lastTime: number = performance.now();
  private frameCount: number = 0;
  private fpsUpdateTime: number = performance.now();
  private maxSampleHistory: number = 120;

  // Timers for subsystems
  private phaseStartTimes: Record<string, number> = {};

  startPhase(phase: 'update' | 'render' | 'physics' | 'script'): void {
    this.phaseStartTimes[phase] = performance.now();
  }

  endPhase(phase: 'update' | 'render' | 'physics' | 'script'): void {
    const start = this.phaseStartTimes[phase];
    if (start) {
      const dur = performance.now() - start;
      if (phase === 'update') this.metrics.updateTimeMs = dur;
      else if (phase === 'render') this.metrics.renderTimeMs = dur;
      else if (phase === 'physics') this.metrics.physicsTimeMs = dur;
      else if (phase === 'script') this.metrics.scriptTimeMs = dur;
    }
  }

  recordFrame(): void {
    const now = performance.now();
    const delta = now - this.lastTime;
    this.lastTime = now;

    this.frameTimes.push(delta);
    if (this.frameTimes.length > this.maxSampleHistory) {
      this.frameTimes.shift();
    }

    this.metrics.frameTimeMs = delta;
    this.frameCount++;

    if (now - this.fpsUpdateTime >= 500) {
      const avgDelta = this.frameTimes.reduce((a, b) => a + b, 0) / (this.frameTimes.length || 1);
      this.metrics.fps = Math.round(1000 / (avgDelta || 16.6));
      this.fpsUpdateTime = now;
      this.frameCount = 0;
    }
  }

  setRenderStats(drawCalls: number, triangles: number, nodes: number): void {
    this.metrics.drawCalls = drawCalls;
    this.metrics.triangles = triangles;
    this.metrics.nodesRendered = nodes;
  }

  setSubsystemStats(particles: number, voices: number, bodies: number): void {
    this.metrics.activeParticles = particles;
    this.metrics.activeAudioVoices = voices;
    this.metrics.physicsBodies = bodies;
    this.metrics.memoryEstimateKb = Math.round(
      1024 + nodesEstimate(this.metrics.nodesRendered) + particles * 0.12 + bodies * 0.25
    );
  }

  getMetrics(): PerformanceMetrics {
    return { ...this.metrics };
  }

  get frameTimeHistory(): number[] {
    return this.frameTimes;
  }

  getFrameHistory(): number[] {
    return [...this.frameTimes];
  }

  exportReport(projectMetadata?: any): string {
    const report = {
      runtime: 'Aardvark Runtime Engine v1.0.0',
      timestamp: new Date().toISOString(),
      project: projectMetadata || { name: 'Aardvark Project' },
      metrics: this.metrics,
      frameHistorySamples: this.frameTimes.slice(-30),
      environment: {
        userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : 'Server',
        devicePixelRatio: typeof window !== 'undefined' ? window.devicePixelRatio : 1,
        hardwareConcurrency: typeof navigator !== 'undefined' ? navigator.hardwareConcurrency : 4,
      },
    };
    return JSON.stringify(report, null, 2);
  }
}

function nodesEstimate(count: number): number {
  return count * 1.5; // Estimated memory per node in KB
}
