// ============================================================================
// AARDVARK RUNTIME - CORE TYPES
// Production-grade interactive media runtime
// ============================================================================

export type RuntimeState = 'uninitialized' | 'loading' | 'ready' | 'running' | 'paused' | 'terminated';

export type RendererBackendType = 'canvas2d' | 'webgl';

export type BlendMode =
  | 'source-over'
  | 'lighter'
  | 'multiply'
  | 'screen'
  | 'overlay'
  | 'darken'
  | 'lighten'
  | 'color-dodge'
  | 'color-burn'
  | 'hard-light'
  | 'soft-light'
  | 'difference'
  | 'exclusion';

export interface ViewportConfig {
  width: number;
  height: number;
  scaleMode: 'fit' | 'fill' | 'stretch' | 'none';
  backgroundColor: string;
  pixelRatio: number;
}

export interface RuntimeConfig {
  targetFps: number;
  backend: RendererBackendType;
  debugMode: boolean;
  enableAudio: boolean;
  enablePhysics: boolean;
  enableParticles: boolean;
  maxDeltaTime: number;
}

export interface PerformanceMetrics {
  fps: number;
  frameTimeMs: number;
  updateTimeMs: number;
  renderTimeMs: number;
  physicsTimeMs: number;
  scriptTimeMs: number;
  drawCalls: number;
  triangles: number;
  nodesRendered: number;
  activeParticles: number;
  activeAudioVoices: number;
  physicsBodies: number;
  memoryEstimateKb: number;
}
