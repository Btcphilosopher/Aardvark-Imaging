// ============================================================================
// AARDVARK RUNTIME - SUBSYSTEM EVENT BUS
// Decoupled inter-subsystem pub/sub message backbone
// ============================================================================

export type EventHandler<T = any> = (data: T) => void;

export interface EventSubscription {
  unsubscribe: () => void;
}

export class RuntimeEventBus {
  private handlers = new Map<string, Set<EventHandler>>();
  private eventLog: Array<{ type: string; timestamp: number; data?: any }> = [];
  private maxHistory: number = 100;

  on<T = any>(eventType: string, handler: EventHandler<T>): EventSubscription {
    if (!this.handlers.has(eventType)) {
      this.handlers.set(eventType, new Set());
    }
    const set = this.handlers.get(eventType)!;
    set.add(handler);

    return {
      unsubscribe: () => {
        set.delete(handler);
        if (set.size === 0) {
          this.handlers.delete(eventType);
        }
      },
    };
  }

  once<T = any>(eventType: string, handler: EventHandler<T>): EventSubscription {
    const sub = this.on<T>(eventType, (data) => {
      sub.unsubscribe();
      handler(data);
    });
    return sub;
  }

  emit<T = any>(eventType: string, data?: T): void {
    // Record event for telemetry & diagnostics
    this.eventLog.push({
      type: eventType,
      timestamp: performance.now(),
      data: data ? (typeof data === 'object' ? { ...data } : data) : undefined,
    });
    if (this.eventLog.length > this.maxHistory) {
      this.eventLog.shift();
    }

    const set = this.handlers.get(eventType);
    if (!set) return;

    // Clone set so handlers unregistering during dispatch don't break iteration
    const listeners = Array.from(set);
    for (const listener of listeners) {
      try {
        listener(data);
      } catch (err) {
        console.error(`[Aardvark EventBus] Error in handler for '${eventType}':`, err);
      }
    }
  }

  clear(): void {
    this.handlers.clear();
  }

  getRecentEvents(): Array<{ type: string; timestamp: number; data?: any }> {
    return [...this.eventLog];
  }
}
