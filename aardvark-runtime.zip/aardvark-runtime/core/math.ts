// ============================================================================
// AARDVARK RUNTIME - MATH FOUNDATIONS
// High-performance geometric and algebraic primitives
// ============================================================================

export class Vec2 {
  constructor(public x: number = 0, public y: number = 0) {}

  set(x: number, y: number): this {
    this.x = x;
    this.y = y;
    return this;
  }

  clone(): Vec2 {
    return new Vec2(this.x, this.y);
  }

  copy(v: Vec2): this {
    this.x = v.x;
    this.y = v.y;
    return this;
  }

  add(v: Vec2): this {
    this.x += v.x;
    this.y += v.y;
    return this;
  }

  sub(v: Vec2): this {
    this.x -= v.x;
    this.y -= v.y;
    return this;
  }

  scale(s: number): this {
    this.x *= s;
    this.y *= s;
    return this;
  }

  lengthSq(): number {
    return this.x * this.x + this.y * this.y;
  }

  length(): number {
    return Math.sqrt(this.lengthSq());
  }

  normalize(): this {
    const len = this.length();
    if (len > 0.000001) {
      this.x /= len;
      this.y /= len;
    }
    return this;
  }

  dot(v: Vec2): number {
    return this.x * v.x + this.y * v.y;
  }

  distance(v: Vec2): number {
    const dx = this.x - v.x;
    const dy = this.y - v.y;
    return Math.sqrt(dx * dx + dy * dy);
  }

  lerp(target: Vec2, t: number): this {
    this.x += (target.x - this.x) * t;
    this.y += (target.y - this.y) * t;
    return this;
  }
}

export class Vec3 {
  constructor(public x: number = 0, public y: number = 0, public z: number = 0) {}

  set(x: number, y: number, z: number): this {
    this.x = x;
    this.y = y;
    this.z = z;
    return this;
  }

  clone(): Vec3 {
    return new Vec3(this.x, this.y, this.z);
  }

  add(v: Vec3): this {
    this.x += v.x;
    this.y += v.y;
    this.z += v.z;
    return this;
  }

  scale(s: number): this {
    this.x *= s;
    this.y *= s;
    this.z *= s;
    return this;
  }

  dot(v: Vec3): number {
    return this.x * v.x + this.y * v.y + this.z * v.z;
  }

  cross(v: Vec3): Vec3 {
    return new Vec3(
      this.y * v.z - this.z * v.y,
      this.z * v.x - this.x * v.z,
      this.x * v.y - this.y * v.x
    );
  }

  normalize(): this {
    const len = Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
    if (len > 0.000001) {
      this.x /= len;
      this.y /= len;
      this.z /= len;
    }
    return this;
  }
}

export class Rect {
  constructor(
    public x: number = 0,
    public y: number = 0,
    public width: number = 0,
    public height: number = 0
  ) {}

  clone(): Rect {
    return new Rect(this.x, this.y, this.width, this.height);
  }

  contains(px: number, py: number): boolean {
    return px >= this.x && px <= this.x + this.width && py >= this.y && py <= this.y + this.height;
  }

  intersects(r: Rect): boolean {
    return (
      this.x < r.x + r.width &&
      this.x + this.width > r.x &&
      this.y < r.y + r.height &&
      this.y + this.height > r.y
    );
  }

  union(r: Rect): Rect {
    const minX = Math.min(this.x, r.x);
    const minY = Math.min(this.y, r.y);
    const maxX = Math.max(this.x + this.width, r.x + r.width);
    const maxY = Math.max(this.y + this.height, r.y + r.height);
    return new Rect(minX, minY, maxX - minX, maxY - minY);
  }
}

/**
 * 3x3 Matrix for 2D Affine Transforms [ a, c, tx,
 *                                       b, d, ty,
 *                                       0, 0, 1  ]
 */
export class Mat3 {
  // Elements stored in column-major order or flat standard 2D affine:
  // a: m[0], b: m[1], c: m[2], d: m[3], tx: m[4], ty: m[5]
  public elements: Float32Array;

  constructor() {
    this.elements = new Float32Array([1, 0, 0, 1, 0, 0]);
  }

  identity(): this {
    const m = this.elements;
    m[0] = 1; m[1] = 0;
    m[2] = 0; m[3] = 1;
    m[4] = 0; m[5] = 0;
    return this;
  }

  set(a: number, b: number, c: number, d: number, tx: number, ty: number): this {
    const m = this.elements;
    m[0] = a; m[1] = b;
    m[2] = c; m[3] = d;
    m[4] = tx; m[5] = ty;
    return this;
  }

  copy(other: Mat3): this {
    this.elements.set(other.elements);
    return this;
  }

  clone(): Mat3 {
    const n = new Mat3();
    n.copy(this);
    return n;
  }

  multiply(other: Mat3): this {
    const m1 = this.elements;
    const m2 = other.elements;

    const a0 = m1[0], b0 = m1[1], c0 = m1[2], d0 = m1[3], tx0 = m1[4], ty0 = m1[5];
    const a1 = m2[0], b1 = m2[1], c1 = m2[2], d1 = m2[3], tx1 = m2[4], ty1 = m2[5];

    m1[0] = a0 * a1 + c0 * b1;
    m1[1] = b0 * a1 + d0 * b1;
    m1[2] = a0 * c1 + c0 * d1;
    m1[3] = b0 * c1 + d0 * d1;
    m1[4] = a0 * tx1 + c0 * ty1 + tx0;
    m1[5] = b0 * tx1 + d0 * ty1 + ty0;

    return this;
  }

  translate(x: number, y: number): this {
    const m = this.elements;
    m[4] += m[0] * x + m[2] * y;
    m[5] += m[1] * x + m[3] * y;
    return this;
  }

  rotate(angleRad: number): this {
    const cos = Math.cos(angleRad);
    const sin = Math.sin(angleRad);
    const m = this.elements;

    const a = m[0], b = m[1], c = m[2], d = m[3];
    m[0] = a * cos + c * sin;
    m[1] = b * cos + d * sin;
    m[2] = -a * sin + c * cos;
    m[3] = -b * sin + d * cos;
    return this;
  }

  scale(sx: number, sy: number): this {
    const m = this.elements;
    m[0] *= sx;
    m[1] *= sx;
    m[2] *= sy;
    m[3] *= sy;
    return this;
  }

  invert(): this {
    const m = this.elements;
    const a = m[0], b = m[1], c = m[2], d = m[3], tx = m[4], ty = m[5];
    const det = a * d - b * c;
    if (Math.abs(det) < 1e-10) {
      return this.identity();
    }
    const invDet = 1.0 / det;

    m[0] = d * invDet;
    m[1] = -b * invDet;
    m[2] = -c * invDet;
    m[3] = a * invDet;
    m[4] = (c * ty - d * tx) * invDet;
    m[5] = (b * tx - a * ty) * invDet;

    return this;
  }

  transformPoint(p: Vec2, out?: Vec2): Vec2 {
    const res = out || new Vec2();
    const m = this.elements;
    const x = p.x;
    const y = p.y;
    res.x = m[0] * x + m[2] * y + m[4];
    res.y = m[1] * x + m[3] * y + m[5];
    return res;
  }
}

/**
 * 4x4 Matrix for 3D Projections and Object Transforms
 */
export class Mat4 {
  public elements: Float32Array;

  constructor() {
    this.elements = new Float32Array(16);
    this.identity();
  }

  identity(): this {
    const e = this.elements;
    e.fill(0);
    e[0] = 1; e[5] = 1; e[10] = 1; e[15] = 1;
    return this;
  }

  perspective(fovyRad: number, aspect: number, near: number, far: number): this {
    const e = this.elements;
    e.fill(0);
    const f = 1.0 / Math.tan(fovyRad / 2);
    const nf = 1 / (near - far);

    e[0] = f / aspect;
    e[5] = f;
    e[10] = (far + near) * nf;
    e[11] = -1;
    e[14] = 2 * far * near * nf;
    return this;
  }

  lookAt(eye: Vec3, center: Vec3, up: Vec3): this {
    const z = new Vec3(eye.x - center.x, eye.y - center.y, eye.z - center.z).normalize();
    const x = up.cross(z).normalize();
    const y = z.cross(x).normalize();

    const e = this.elements;
    e[0] = x.x; e[4] = x.y; e[8] = x.z; e[12] = -x.dot(eye);
    e[1] = y.x; e[5] = y.y; e[9] = y.z; e[13] = -y.dot(eye);
    e[2] = z.x; e[6] = z.y; e[10] = z.z; e[14] = -z.dot(eye);
    e[3] = 0;   e[7] = 0;   e[11] = 0;   e[15] = 1;
    return this;
  }

  multiply(other: Mat4): this {
    const a = this.elements;
    const b = other.elements;
    const out = new Float32Array(16);

    for (let r = 0; r < 4; r++) {
      for (let c = 0; c < 4; c++) {
        out[c * 4 + r] =
          a[0 * 4 + r] * b[c * 4 + 0] +
          a[1 * 4 + r] * b[c * 4 + 1] +
          a[2 * 4 + r] * b[c * 4 + 2] +
          a[3 * 4 + r] * b[c * 4 + 3];
      }
    }
    this.elements.set(out);
    return this;
  }

  rotateY(rad: number): this {
    const cos = Math.cos(rad);
    const sin = Math.sin(rad);
    const m = new Mat4();
    m.elements[0] = cos;
    m.elements[2] = -sin;
    m.elements[8] = sin;
    m.elements[10] = cos;
    return this.multiply(m);
  }

  rotateX(rad: number): this {
    const cos = Math.cos(rad);
    const sin = Math.sin(rad);
    const m = new Mat4();
    m.elements[5] = cos;
    m.elements[6] = sin;
    m.elements[9] = -sin;
    m.elements[10] = cos;
    return this.multiply(m);
  }
}

export class Color {
  constructor(
    public r: number = 1,
    public g: number = 1,
    public b: number = 1,
    public a: number = 1
  ) {}

  static fromHex(hex: string): Color {
    let clean = hex.replace('#', '');
    if (clean.length === 3) {
      clean = clean.split('').map(c => c + c).join('');
    }
    const num = parseInt(clean, 16);
    if (clean.length === 6) {
      return new Color(
        ((num >> 16) & 255) / 255,
        ((num >> 8) & 255) / 255,
        (num & 255) / 255,
        1
      );
    }
    if (clean.length === 8) {
      return new Color(
        ((num >> 24) & 255) / 255,
        ((num >> 16) & 255) / 255,
        ((num >> 8) & 255) / 255,
        (num & 255) / 255
      );
    }
    return new Color(1, 1, 1, 1);
  }

  toRgbaString(): string {
    return `rgba(${Math.round(this.r * 255)}, ${Math.round(this.g * 255)}, ${Math.round(this.b * 255)}, ${this.a})`;
  }

  toHex(): string {
    const r = Math.round(this.r * 255).toString(16).padStart(2, '0');
    const g = Math.round(this.g * 255).toString(16).padStart(2, '0');
    const b = Math.round(this.b * 255).toString(16).padStart(2, '0');
    return `#${r}${g}${b}`;
  }

  lerp(target: Color, t: number): Color {
    return new Color(
      this.r + (target.r - this.r) * t,
      this.g + (target.g - this.g) * t,
      this.b + (target.b - this.b) * t,
      this.a + (target.a - this.a) * t
    );
  }

  clone(): Color {
    return new Color(this.r, this.g, this.b, this.a);
  }
}

export function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v));
}

export function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

export function degToRad(deg: number): number {
  return (deg * Math.PI) / 180;
}

export function radToDeg(rad: number): number {
  return (rad * 180) / Math.PI;
}
