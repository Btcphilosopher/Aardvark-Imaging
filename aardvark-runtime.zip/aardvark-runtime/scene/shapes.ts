// ============================================================================
// AARDVARK RUNTIME - GEOMETRIC, VECTOR & TEXT SCENE NODES
// ============================================================================

import { SceneNode } from './node';
import { Rect, Color } from '../core/math';
import { Timeline } from '../timeline/timeline';

export type ShapeGeometry = 'rectangle' | 'rounded_rectangle' | 'circle' | 'ellipse' | 'polygon' | 'star';

export interface FillStyle {
  type: 'solid' | 'linear_gradient' | 'radial_gradient' | 'none';
  color: string;
  gradientColors?: string[];
  gradientStops?: number[];
  gradientAngle?: number;
}

export interface StrokeStyle {
  enabled: boolean;
  color: string;
  width: number;
  lineCap?: 'butt' | 'round' | 'square';
  lineJoin?: 'miter' | 'round' | 'bevel';
  dash?: number[];
}

export class GroupNode extends SceneNode {
  constructor(name: string = 'Group', id?: string) {
    super(name, 'group', id);
  }

  getLocalBounds(): Rect {
    if (this.children.length === 0) {
      return new Rect(0, 0, 0, 0);
    }
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;

    for (const child of this.children) {
      if (!child.visible) continue;
      const b = child.getLocalBounds();
      const t = child.transform;
      const left = t.x + b.x;
      const top = t.y + b.y;
      const right = left + b.width;
      const bottom = top + b.height;

      minX = Math.min(minX, left);
      minY = Math.min(minY, top);
      maxX = Math.max(maxX, right);
      maxY = Math.max(maxY, bottom);
    }

    if (minX === Infinity) return new Rect(0, 0, 0, 0);
    return new Rect(minX, minY, maxX - minX, maxY - minY);
  }
}

export class ShapeNode extends SceneNode {
  public geometry: ShapeGeometry = 'rectangle';
  public width: number = 100;
  public height: number = 100;
  public cornerRadius: number = 0;
  public sides: number = 5; // For polygon or star
  public innerRadiusRatio: number = 0.5; // For star

  public fill: FillStyle = {
    type: 'solid',
    color: '#3b82f6',
  };

  public stroke: StrokeStyle = {
    enabled: false,
    color: '#1d4ed8',
    width: 2,
    lineCap: 'round',
    lineJoin: 'round',
  };

  constructor(name: string = 'Shape', id?: string) {
    super(name, 'shape', id);
  }

  getLocalBounds(): Rect {
    const halfW = this.width * this.transform.anchorX;
    const halfH = this.height * this.transform.anchorY;
    return new Rect(-halfW, -halfH, this.width, this.height);
  }
}

export interface PathCommand {
  type: 'M' | 'L' | 'C' | 'Q' | 'Z';
  x?: number;
  y?: number;
  cp1x?: number;
  cp1y?: number;
  cp2x?: number;
  cp2y?: number;
}

export class PathNode extends SceneNode {
  public commands: PathCommand[] = [];
  public fill: FillStyle = {
    type: 'solid',
    color: '#10b981',
  };
  public stroke: StrokeStyle = {
    enabled: true,
    color: '#059669',
    width: 2,
  };
  private cachedBounds: Rect = new Rect(0, 0, 100, 100);

  constructor(name: string = 'Path', id?: string) {
    super(name, 'path', id);
  }

  setCommandsFromSvg(svgPathStr: string): void {
    // Basic SVG path string parser supporting M, L, C, Q, Z
    const cmds: PathCommand[] = [];
    const tokens = svgPathStr.match(/[a-df-z]|[-+]?(?:\d*\.\d+|\d+)/gi) || [];
    let i = 0;
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;

    const updateBounds = (x: number, y: number) => {
      minX = Math.min(minX, x);
      minY = Math.min(minY, y);
      maxX = Math.max(maxX, x);
      maxY = Math.max(maxY, y);
    };

    while (i < tokens.length) {
      const token = tokens[i];
      if (/^[a-df-z]$/i.test(token)) {
        const cmd = token.toUpperCase();
        i++;
        if (cmd === 'M' || cmd === 'L') {
          const x = parseFloat(tokens[i++]);
          const y = parseFloat(tokens[i++]);
          cmds.push({ type: cmd as any, x, y });
          updateBounds(x, y);
        } else if (cmd === 'C') {
          const cp1x = parseFloat(tokens[i++]);
          const cp1y = parseFloat(tokens[i++]);
          const cp2x = parseFloat(tokens[i++]);
          const cp2y = parseFloat(tokens[i++]);
          const x = parseFloat(tokens[i++]);
          const y = parseFloat(tokens[i++]);
          cmds.push({ type: 'C', cp1x, cp1y, cp2x, cp2y, x, y });
          updateBounds(x, y);
        } else if (cmd === 'Q') {
          const cp1x = parseFloat(tokens[i++]);
          const cp1y = parseFloat(tokens[i++]);
          const x = parseFloat(tokens[i++]);
          const y = parseFloat(tokens[i++]);
          cmds.push({ type: 'Q', cp1x, cp1y, x, y });
          updateBounds(x, y);
        } else if (cmd === 'Z') {
          cmds.push({ type: 'Z' });
        }
      } else {
        i++;
      }
    }

    this.commands = cmds;
    if (minX !== Infinity) {
      this.cachedBounds = new Rect(minX, minY, Math.max(1, maxX - minX), Math.max(1, maxY - minY));
    }
  }

  getLocalBounds(): Rect {
    return this.cachedBounds;
  }
}

export class SpriteNode extends SceneNode {
  public width: number = 100;
  public height: number = 100;
  public textureId: string = '';
  public sourceRect: Rect | null = null;
  public smoothing: boolean = true;
  public proceduralPattern?: 'grid' | 'stripes' | 'checker' | 'circuit' | 'gradient';

  constructor(name: string = 'Sprite', id?: string) {
    super(name, 'sprite', id);
  }

  getLocalBounds(): Rect {
    const halfW = this.width * this.transform.anchorX;
    const halfH = this.height * this.transform.anchorY;
    return new Rect(-halfW, -halfH, this.width, this.height);
  }
}

export class TextNode extends SceneNode {
  public text: string = 'Aardvark';
  public fontSize: number = 24;
  public fontFamily: string = 'system-ui, -apple-system, sans-serif';
  public fontWeight: string = '600';
  public textAlign: 'left' | 'center' | 'right' = 'center';
  public color: string = '#f8fafc';
  public strokeColor: string = '#0f172a';
  public strokeWidth: number = 0;
  public letterSpacing: number = 0;
  public lineHeight: number = 1.2;

  constructor(name: string = 'Text', id?: string) {
    super(name, 'text', id);
  }

  getLocalBounds(): Rect {
    // Approximate metrics based on font size and character count
    const approxCharWidth = this.fontSize * 0.6;
    const lines = this.text.split('\n');
    const maxLineLen = Math.max(...lines.map(l => l.length), 1);
    const width = maxLineLen * approxCharWidth;
    const height = lines.length * this.fontSize * this.lineHeight;

    const halfW = this.textAlign === 'center' ? width / 2 : this.textAlign === 'right' ? width : 0;
    return new Rect(-halfW, -height / 2, width, height);
  }
}

export class SymbolNode extends SceneNode {
  public symbolId: string = '';
  public timeline: Timeline;

  constructor(name: string = 'SymbolInstance', symbolId: string = '', id?: string) {
    super(name, 'symbol', id);
    this.symbolId = symbolId;
    this.timeline = new Timeline(name + '_Timeline');
  }

  update(dt: number): void {
    if (this.timeline.isPlaying) {
      this.timeline.tick(dt, this);
    }
    super.update(dt);
  }

  getLocalBounds(): Rect {
    if (this.children.length === 0) {
      return new Rect(-50, -50, 100, 100);
    }
    return new GroupNode().addChild(this).getLocalBounds();
  }
}
