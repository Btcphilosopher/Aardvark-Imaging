// ============================================================================
// AARDVARK RUNTIME - SCENE CONTAINER
// The root world container managing nodes, cameras, lights, and environmental state
// ============================================================================

import { GroupNode } from './shapes';
import { SceneNode } from './node';
import { CameraNode } from './camera';
import { LightNode } from './light';
import { Timeline } from '../timeline/timeline';

export class Scene {
  public id: string;
  public name: string;
  public root: GroupNode;
  public activeCamera: CameraNode | null = null;
  public lights: LightNode[] = [];
  public backgroundColor: string = '#090d16';
  public timeline: Timeline;
  public metadata: Record<string, any> = {};

  constructor(name: string = 'Main Scene', id?: string) {
    this.name = name;
    this.id = id || `scene_${Math.random().toString(36).substring(2, 9)}`;
    this.root = new GroupNode('SceneRoot', 'root');
    this.timeline = new Timeline(name + '_Timeline');

    // Create default camera
    const defaultCam = new CameraNode('MainCamera', 'cam_default');
    defaultCam.position3D.set(0, 0, 400);
    this.root.addChild(defaultCam);
    this.activeCamera = defaultCam;
  }

  findNodeById(id: string): SceneNode | null {
    return this.root.findChildById(id);
  }

  findNodesByTag(tag: string): SceneNode[] {
    return this.root.findChildrenByTag(tag);
  }

  addNode(node: SceneNode): void {
    this.root.addChild(node);
    if (node instanceof LightNode) {
      this.lights.push(node);
    }
  }

  removeNode(node: SceneNode): void {
    node.removeFromParent();
    if (node instanceof LightNode) {
      const idx = this.lights.indexOf(node);
      if (idx !== -1) this.lights.splice(idx, 1);
    }
  }

  update(dt: number): void {
    // 1. Tick timeline
    if (this.timeline.isPlaying) {
      this.timeline.tick(dt, this.root);
    }

    // 2. Update scene graph nodes
    this.root.update(dt);

    // 3. Update world transforms
    this.root.updateWorldTransform(false);
  }

  countNodes(node: SceneNode = this.root): number {
    let count = 1;
    for (const child of node.children) {
      count += this.countNodes(child);
    }
    return count;
  }
}
