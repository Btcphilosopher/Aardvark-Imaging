// ============================================================================
// AARDVARK RUNTIME - 3D MESH OBJECT NODE
// Lightweight 3D rendering integrated seamlessly with 2D scene graph
// ============================================================================

import { SceneNode } from './node';
import { Vec3, Rect } from '../core/math';

export interface Face3D {
  indices: [number, number, number];
  color?: string;
  normal?: Vec3;
}

export type MeshPreset = 'cube' | 'pyramid' | 'octahedron' | 'cylinder' | 'prism' | 'grid';

export class Object3DNode extends SceneNode {
  public vertices: Vec3[] = [];
  public faces: Face3D[] = [];
  public rotX: number = 0;
  public rotY: number = 0;
  public rotZ: number = 0;
  public scale3D: Vec3 = new Vec3(1, 1, 1);
  public wireframe: boolean = false;
  public shaded: boolean = true;
  public baseColor: string = '#6366f1';
  public strokeColor: string = '#c7d2fe';
  public lineWidth: number = 1.5;

  constructor(name: string = 'Object3D', preset: MeshPreset = 'cube', id?: string) {
    super(name, 'object3d', id);
    this.buildPreset(preset);
  }

  buildPreset(preset: MeshPreset, size: number = 60): void {
    const s = size / 2;
    this.vertices = [];
    this.faces = [];

    if (preset === 'cube') {
      // 8 vertices
      this.vertices = [
        new Vec3(-s, -s, -s),
        new Vec3(s, -s, -s),
        new Vec3(s, s, -s),
        new Vec3(-s, s, -s),
        new Vec3(-s, -s, s),
        new Vec3(s, -s, s),
        new Vec3(s, s, s),
        new Vec3(-s, s, s),
      ];

      // 12 triangles (6 quads)
      const quads: [number, number, number, number, string][] = [
        [0, 1, 2, 3, '#4f46e5'], // Front
        [5, 4, 7, 6, '#6366f1'], // Back
        [4, 0, 3, 7, '#4338ca'], // Left
        [1, 5, 6, 2, '#818cf8'], // Right
        [3, 2, 6, 7, '#3730a3'], // Top
        [4, 5, 1, 0, '#312e81'], // Bottom
      ];

      for (const [a, b, c, d, col] of quads) {
        this.faces.push({ indices: [a, b, c], color: col });
        this.faces.push({ indices: [a, c, d], color: col });
      }
    } else if (preset === 'pyramid' || preset === 'prism') {
      this.vertices = [
        new Vec3(0, -s * 1.2, 0), // Apex
        new Vec3(-s, s, -s),
        new Vec3(s, s, -s),
        new Vec3(s, s, s),
        new Vec3(-s, s, s),
      ];
      this.faces = [
        { indices: [0, 1, 2], color: '#ec4899' },
        { indices: [0, 2, 3], color: '#f43f5e' },
        { indices: [0, 3, 4], color: '#db2777' },
        { indices: [0, 4, 1], color: '#e11d48' },
        { indices: [1, 3, 2], color: '#be123c' },
        { indices: [1, 4, 3], color: '#be123c' },
      ];
    } else if (preset === 'octahedron') {
      this.vertices = [
        new Vec3(0, -s * 1.4, 0),
        new Vec3(s * 1.4, 0, 0),
        new Vec3(0, 0, s * 1.4),
        new Vec3(-s * 1.4, 0, 0),
        new Vec3(0, 0, -s * 1.4),
        new Vec3(0, s * 1.4, 0),
      ];
      this.faces = [
        { indices: [0, 1, 2], color: '#06b6d4' },
        { indices: [0, 2, 3], color: '#0891b2' },
        { indices: [0, 3, 4], color: '#0e7490' },
        { indices: [0, 4, 1], color: '#155e75' },
        { indices: [5, 2, 1], color: '#22d3ee' },
        { indices: [5, 3, 2], color: '#67e8f9' },
        { indices: [5, 4, 3], color: '#a5f3fc' },
        { indices: [5, 1, 4], color: '#cffafe' },
      ];
    }

    this.computeNormals();
  }

  computeNormals(): void {
    for (const face of this.faces) {
      const v0 = this.vertices[face.indices[0]];
      const v1 = this.vertices[face.indices[1]];
      const v2 = this.vertices[face.indices[2]];

      const edge1 = new Vec3(v1.x - v0.x, v1.y - v0.y, v1.z - v0.z);
      const edge2 = new Vec3(v2.x - v0.x, v2.y - v0.y, v2.z - v0.z);
      face.normal = edge1.cross(edge2).normalize();
    }
  }

  getLocalBounds(): Rect {
    return new Rect(-60, -60, 120, 120);
  }
}
