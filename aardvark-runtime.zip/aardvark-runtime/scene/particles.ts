// ============================================================================
// AARDVARK RUNTIME - PARTICLE EMITTER NODE
// High-performance CPU/Canvas particle simulation
// ============================================================================

import { SceneNode } from './node';
import { Vec2, Color, Rect } from '../core/math';

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  startSize: number;
  endSize: number;
  color: Color;
  startColor: Color;
  endColor: Color;
  rotation: number;
  vRot: number;
  active: boolean;
}

export class ParticleEmitterNode extends SceneNode {
  public maxParticles: number = 250;
  public emissionRate: number = 40; // particles per second
  public lifetimeMin: number = 0.8;
  public lifetimeMax: number = 1.8;
  public speedMin: number = 40;
  public speedMax: number = 120;
  public angle: number = -Math.PI / 2; // Radians, default straight up
  public spread: number = Math.PI / 4; // Cone angle
  public startSize: number = 8;
  public endSize: number = 1;
  public startColor: string = '#f59e0b';
  public endColor: string = '#ef4444';
  public gravity: Vec2 = new Vec2(0, 50);
  public emitting: boolean = true;
  public blendModeOverride?: string;

  public particles: Particle[] = [];
  private emissionAccumulator: number = 0;

  constructor(name: string = 'ParticleEmitter', id?: string) {
    super(name, 'particle_emitter', id);
    this.initPool();
  }

  private initPool(): void {
    this.particles = [];
    for (let i = 0; i < this.maxParticles; i++) {
      this.particles.push({
        x: 0,
        y: 0,
        vx: 0,
        vy: 0,
        life: 0,
        maxLife: 1,
        size: 5,
        startSize: 8,
        endSize: 1,
        color: new Color(),
        startColor: new Color(),
        endColor: new Color(),
        rotation: 0,
        vRot: 0,
        active: false,
      });
    }
  }

  burst(count: number): void {
    for (let i = 0; i < count; i++) {
      this.spawnParticle();
    }
  }

  private spawnParticle(): void {
    // Find inactive particle
    const p = this.particles.find((item) => !item.active);
    if (!p) return;

    p.active = true;
    p.x = 0;
    p.y = 0;

    const angle = this.angle + (Math.random() - 0.5) * this.spread;
    const speed = this.speedMin + Math.random() * (this.speedMax - this.speedMin);
    p.vx = Math.cos(angle) * speed;
    p.vy = Math.sin(angle) * speed;

    p.life = 0;
    p.maxLife = this.lifetimeMin + Math.random() * (this.lifetimeMax - this.lifetimeMin);
    p.startSize = this.startSize;
    p.endSize = this.endSize;
    p.size = this.startSize;

    p.startColor = Color.fromHex(this.startColor);
    p.endColor = Color.fromHex(this.endColor);
    p.color = p.startColor.clone();

    p.rotation = Math.random() * Math.PI * 2;
    p.vRot = (Math.random() - 0.5) * 4;
  }

  update(dt: number): void {
    if (this.emitting) {
      this.emissionAccumulator += dt;
      const interval = 1 / Math.max(1, this.emissionRate);
      while (this.emissionAccumulator >= interval) {
        this.spawnParticle();
        this.emissionAccumulator -= interval;
      }
    }

    // Tick active particles
    for (const p of this.particles) {
      if (!p.active) continue;

      p.life += dt;
      if (p.life >= p.maxLife) {
        p.active = false;
        continue;
      }

      const progress = p.life / p.maxLife;

      // Integration
      p.vx += this.gravity.x * dt;
      p.vy += this.gravity.y * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;

      p.rotation += p.vRot * dt;

      // Interpolate size & color
      p.size = p.startSize + (p.endSize - p.startSize) * progress;
      p.color = p.startColor.lerp(p.endColor, progress);
      p.color.a = 1 - progress; // Fade out
    }

    super.update(dt);
  }

  getActiveCount(): number {
    let count = 0;
    for (let i = 0; i < this.particles.length; i++) {
      if (this.particles[i].active) count++;
    }
    return count;
  }

  getLocalBounds(): Rect {
    return new Rect(-100, -100, 200, 200);
  }
}
