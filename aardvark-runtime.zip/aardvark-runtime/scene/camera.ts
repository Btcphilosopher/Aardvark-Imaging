// ============================================================================
// AARDVARK RUNTIME - CAMERA & LIGHTING NODES
// ============================================================================

import { SceneNode } from './node';
import { Vec3, Mat4, Rect } from '../core/math';

export class CameraNode extends SceneNode {
  public projectionMode: 'orthographic' | 'perspective' = 'perspective';
  public fov: number = 60; // in degrees
  public near: number = 0.1;
  public far: number = 1000;
  public zoom: number = 1.0;
  public position3D: Vec3 = new Vec3(0, 0, 500);
  public target3D: Vec3 = new Vec3(0, 0, 0);
  public up3D: Vec3 = new Vec3(0, 1, 0);

  constructor(name: string = 'Camera', id?: string) {
    super(name, 'camera', id);
  }

  getViewMatrix(): Mat4 {
    const mat = new Mat4();
    return mat.lookAt(this.position3D, this.target3D, this.up3D);
  }

  getProjectionMatrix(aspect: number): Mat4 {
    const mat = new Mat4();
    if (this.projectionMode === 'perspective') {
      const fovRad = (this.fov * Math.PI) / 180;
      return mat.perspective(fovRad, aspect, this.near, this.far);
    }
    return mat;
  }

  getLocalBounds(): Rect {
    return new Rect(-10, -10, 20, 20);
  }
}

export type LightType = 'directional' | 'point' | 'ambient';

export class LightNode extends SceneNode {
  public lightType: LightType = 'point';
  public color: string = '#ffffff';
  public intensity: number = 1.0;
  public range: number = 500;
  public position3D: Vec3 = new Vec3(0, 100, 200);

  constructor(name: string = 'Light', id?: string) {
    super(name, 'light', id);
  }

  getLocalBounds(): Rect {
    return new Rect(-15, -15, 30, 30);
  }
}
