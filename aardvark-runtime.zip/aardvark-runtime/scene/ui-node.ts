// ============================================================================
// AARDVARK RUNTIME - UI ELEMENT NODE
// Interactive UI components executed natively within the runtime scene graph
// ============================================================================

import { SceneNode } from './node';
import { Rect } from '../core/math';

export type UIWidgetType = 'button' | 'slider' | 'toggle' | 'badge' | 'panel';

export class UIElementNode extends SceneNode {
  public widgetType: UIWidgetType = 'button';
  public width: number = 140;
  public height: number = 42;
  public label: string = 'Click Me';
  public value: number = 0.5; // for slider: 0..1
  public checked: boolean = false; // for toggle

  // Visual states
  public isHovered: boolean = false;
  public isPressed: boolean = false;

  // Theming
  public primaryColor: string = '#6366f1';
  public hoverColor: string = '#4f46e5';
  public activeColor: string = '#4338ca';
  public textColor: string = '#ffffff';
  public borderRadius: number = 8;

  // Callback
  public onClick?: (node: UIElementNode) => void;
  public onChange?: (value: number | boolean, node: UIElementNode) => void;

  constructor(name: string = 'UIButton', widgetType: UIWidgetType = 'button', id?: string) {
    super(name, 'ui_element', id);
    this.widgetType = widgetType;
  }

  getLocalBounds(): Rect {
    const halfW = this.width * this.transform.anchorX;
    const halfH = this.height * this.transform.anchorY;
    return new Rect(-halfW, -halfH, this.width, this.height);
  }

  onPointerEnter(): void {
    this.isHovered = true;
  }

  onPointerLeave(): void {
    this.isHovered = false;
    this.isPressed = false;
  }

  onPointerDown(): void {
    this.isPressed = true;
  }

  onPointerUp(): void {
    if (this.isPressed) {
      this.isPressed = false;
      if (this.widgetType === 'toggle') {
        this.checked = !this.checked;
        if (this.onChange) this.onChange(this.checked, this);
      } else if (this.widgetType === 'button') {
        if (this.onClick) this.onClick(this);
      }
    }
  }

  handleDrag(localX: number): void {
    if (this.widgetType === 'slider' && this.isPressed) {
      const minX = -this.width * this.transform.anchorX;
      const progress = Math.max(0, Math.min(1, (localX - minX) / this.width));
      this.value = progress;
      if (this.onChange) this.onChange(this.value, this);
    }
  }
}
