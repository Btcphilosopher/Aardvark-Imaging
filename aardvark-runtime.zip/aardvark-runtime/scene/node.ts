// ============================================================================
// AARDVARK RUNTIME - SCENE GRAPH NODE FOUNDATIONS
// ============================================================================

import { Vec2, Mat3, Rect, Color } from '../core/math';
import { BlendMode } from '../core/types';

export type NodeType =
  | 'group'
  | 'shape'
  | 'path'
  | 'sprite'
  | 'text'
  | 'symbol'
  | 'particle_emitter'
  | 'camera'
  | 'light'
  | 'object3d'
  | 'ui_element';

export interface Transform2D {
  x: number;
  y: number;
  scaleX: number;
  scaleY: number;
  rotation: number; // in radians
  anchorX: number; // 0..1 normalized anchor
  anchorY: number;
  skewX: number;
  skewY: number;
}

export interface NodeComponent {
  id: string;
  type: string;
  enabled: boolean;
  onUpdate?: (dt: number, node: SceneNode) => void;
  onDestroy?: (node: SceneNode) => void;
}

export abstract class SceneNode {
  public id: string;
  public name: string;
  public type: NodeType;
  public tags: string[] = [];

  // Hierarchy
  public parent: SceneNode | null = null;
  public children: SceneNode[] = [];

  // Transforms
  public transform: Transform2D = {
    x: 0,
    y: 0,
    scaleX: 1,
    scaleY: 1,
    rotation: 0,
    anchorX: 0.5,
    anchorY: 0.5,
    skewX: 0,
    skewY: 0,
  };

  // Cached matrix and dirty state
  protected localMatrix: Mat3 = new Mat3();
  protected worldMatrix: Mat3 = new Mat3();
  protected isDirtyTransform: boolean = true;

  // Visual Attributes
  public visible: boolean = true;
  public opacity: number = 1.0;
  public worldOpacity: number = 1.0;
  public blendMode: BlendMode = 'source-over';
  public zIndex: number = 0;
  public interactive: boolean = true;

  // Masking and clipping
  public mask: SceneNode | null = null;
  public clipRect: Rect | null = null;

  // Custom components & scripts
  public components: Map<string, NodeComponent> = new Map();
  public customProperties: Record<string, any> = {};

  constructor(name: string, type: NodeType, id?: string) {
    this.name = name;
    this.type = type;
    this.id = id || `node_${Math.random().toString(36).substring(2, 9)}`;
  }

  markDirty(): void {
    this.isDirtyTransform = true;
    for (let i = 0; i < this.children.length; i++) {
      this.children[i].markDirty();
    }
  }

  addChild(child: SceneNode): this {
    if (child.parent) {
      child.parent.removeChild(child);
    }
    child.parent = this;
    this.children.push(child);
    child.markDirty();
    return this;
  }

  removeChild(child: SceneNode): boolean {
    const idx = this.children.indexOf(child);
    if (idx !== -1) {
      child.parent = null;
      this.children.splice(idx, 1);
      child.markDirty();
      return true;
    }
    return false;
  }

  removeFromParent(): void {
    if (this.parent) {
      this.parent.removeChild(this);
    }
  }

  removeAllChildren(): void {
    for (const child of this.children) {
      child.parent = null;
      child.markDirty();
    }
    this.children = [];
  }

  findChildById(id: string): SceneNode | null {
    if (this.id === id) return this;
    for (const child of this.children) {
      const found = child.findChildById(id);
      if (found) return found;
    }
    return null;
  }

  findChildrenByTag(tag: string): SceneNode[] {
    const results: SceneNode[] = [];
    if (this.tags.includes(tag)) results.push(this);
    for (const child of this.children) {
      results.push(...child.findChildrenByTag(tag));
    }
    return results;
  }

  updateLocalMatrix(): void {
    const t = this.transform;
    const m = this.localMatrix;
    m.identity();

    // Position
    m.translate(t.x, t.y);

    // Rotation
    if (t.rotation !== 0) {
      m.rotate(t.rotation);
    }

    // Scale
    if (t.scaleX !== 1 || t.scaleY !== 1) {
      m.scale(t.scaleX, t.scaleY);
    }

    // Skew
    if (t.skewX !== 0 || t.skewY !== 0) {
      const skewMat = new Mat3();
      skewMat.set(1, Math.tan(t.skewY), Math.tan(t.skewX), 1, 0, 0);
      m.multiply(skewMat);
    }
  }

  updateWorldTransform(force: boolean = false): void {
    if (this.isDirtyTransform || force) {
      this.updateLocalMatrix();
      if (this.parent) {
        this.worldMatrix.copy(this.parent.worldMatrix).multiply(this.localMatrix);
        this.worldOpacity = this.parent.worldOpacity * this.opacity;
      } else {
        this.worldMatrix.copy(this.localMatrix);
        this.worldOpacity = this.opacity;
      }
      this.isDirtyTransform = false;
      force = true; // Force cascade to children
    }

    for (let i = 0; i < this.children.length; i++) {
      this.children[i].updateWorldTransform(force);
    }
  }

  getWorldMatrix(): Mat3 {
    if (this.isDirtyTransform) {
      this.updateWorldTransform();
    }
    return this.worldMatrix;
  }

  localToGlobal(p: Vec2, out?: Vec2): Vec2 {
    const wm = this.getWorldMatrix();
    return wm.transformPoint(p, out);
  }

  globalToLocal(p: Vec2, out?: Vec2): Vec2 {
    const wm = this.getWorldMatrix().clone().invert();
    return wm.transformPoint(p, out);
  }

  abstract getLocalBounds(): Rect;

  getWorldBounds(): Rect {
    const local = this.getLocalBounds();
    const wm = this.getWorldMatrix();

    // Transform 4 corners
    const p1 = wm.transformPoint(new Vec2(local.x, local.y));
    const p2 = wm.transformPoint(new Vec2(local.x + local.width, local.y));
    const p3 = wm.transformPoint(new Vec2(local.x + local.width, local.y + local.height));
    const p4 = wm.transformPoint(new Vec2(local.x, local.y + local.height));

    const minX = Math.min(p1.x, p2.x, p3.x, p4.x);
    const maxX = Math.max(p1.x, p2.x, p3.x, p4.x);
    const minY = Math.min(p1.y, p2.y, p3.y, p4.y);
    const maxY = Math.max(p1.y, p2.y, p3.y, p4.y);

    return new Rect(minX, minY, maxX - minX, maxY - minY);
  }

  hitTest(worldX: number, worldY: number): boolean {
    if (!this.visible || !this.interactive || this.worldOpacity <= 0.001) {
      return false;
    }
    const localP = this.globalToLocal(new Vec2(worldX, worldY));
    const bounds = this.getLocalBounds();
    return bounds.contains(localP.x, localP.y);
  }

  update(dt: number): void {
    for (const comp of this.components.values()) {
      if (comp.enabled && comp.onUpdate) {
        comp.onUpdate(dt, this);
      }
    }
    for (let i = 0; i < this.children.length; i++) {
      this.children[i].update(dt);
    }
  }
}
