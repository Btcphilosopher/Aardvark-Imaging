// ============================================================================
// AARDVARK RUNTIME - MASTER ENGINE RUNTIME
// Unified orchestration facade coordinating graphics, audio, physics, scripting & timeline
// ============================================================================

import { RuntimeEventBus } from './core/event-bus';
import { RuntimeProfiler } from './core/diagnostics';
import { RuntimeConfig, RendererBackendType, PerformanceMetrics } from './core/types';
import { Scene } from './scene/scene';
import { SceneNode } from './scene/node';
import { IRenderer } from './renderer/renderer-interface';
import { Canvas2DRenderer } from './renderer/canvas2d-renderer';
import { WebGLRenderer } from './renderer/webgl-renderer';
import { InputManager } from './input/input-manager';
import { AudioEngine } from './audio/audio-engine';
import { PhysicsWorld } from './physics/physics-world';
import { ScriptEngine } from './scripting/script-engine';
import { ProjectLoader } from './project/project-loader';
import { ProjectSerializer } from './project/project-serializer';
import { AardvarkProjectFile } from './project/project-types';
import { SAMPLE_PROJECTS } from './project/sample-projects';
import { ParticleEmitterNode } from './scene/particles';

export class AardvarkRuntime {
  // Core Subsystems
  public readonly eventBus: RuntimeEventBus;
  public readonly profiler: RuntimeProfiler;
  public readonly audioEngine: AudioEngine;
  public readonly physicsWorld: PhysicsWorld;
  public readonly scriptEngine: ScriptEngine;
  public readonly inputManager: InputManager;
  public renderer: IRenderer;

  // Scene & Runtime State
  public scene: Scene;
  public isRunning: boolean = false;
  public currentProjectName: string = 'Orbital Station 9';
  public selectedNode: SceneNode | null = null;

  // Configuration
  public config: RuntimeConfig = {
    targetFps: 60,
    backend: 'canvas2d',
    debugMode: true,
    enableAudio: true,
    enablePhysics: true,
    enableParticles: true,
    maxDeltaTime: 0.1,
  };

  private canvas: HTMLCanvasElement | null = null;
  private animFrameId: number | null = null;
  private lastFrameTimestamp: number = performance.now();

  constructor() {
    this.eventBus = new RuntimeEventBus();
    this.profiler = new RuntimeProfiler();
    this.audioEngine = new AudioEngine();
    this.physicsWorld = new PhysicsWorld(this.eventBus);
    this.scriptEngine = new ScriptEngine(this.eventBus, this.audioEngine, this.physicsWorld);
    this.inputManager = new InputManager(this.eventBus);
    this.renderer = new Canvas2DRenderer();

    // Initialize with first sample project
    const defaultProj = SAMPLE_PROJECTS.orbital_station;
    this.scene = ProjectLoader.loadProject(
      defaultProj,
      this.physicsWorld,
      this.scriptEngine,
      this.audioEngine
    );
    this.currentProjectName = defaultProj.manifest.name;

    this.wireSubsystemEvents();
  }

  private wireSubsystemEvents(): void {
    // Select node on pointer click
    this.eventBus.on('node:pointerdown', ({ node }) => {
      this.setSelectedNode(node);
    });

    // Audio triggers from timeline markers
    this.scene.timeline.onMarkerReached = (marker) => {
      if (marker.audioTrigger) {
        this.audioEngine.playSfx(marker.audioTrigger as any);
      }
    };
  }

  attach(canvas: HTMLCanvasElement): void {
    this.canvas = canvas;
    this.renderer.init(canvas);

    const dpr = typeof window !== 'undefined' ? window.devicePixelRatio || 1 : 1;
    this.renderer.resize(800, 600, dpr);

    this.inputManager.attach(canvas, this.scene);
    this.audioEngine.init();

    this.start();
  }

  detach(): void {
    this.stop();
    this.inputManager.detach();
    this.renderer.destroy();
    this.canvas = null;
  }

  setBackend(backend: RendererBackendType): void {
    if (this.config.backend === backend || !this.canvas) return;
    this.config.backend = backend;

    this.renderer.destroy();
    if (backend === 'webgl') {
      this.renderer = new WebGLRenderer();
    } else {
      this.renderer = new Canvas2DRenderer();
    }

    this.renderer.init(this.canvas);
    const dpr = typeof window !== 'undefined' ? window.devicePixelRatio || 1 : 1;
    this.renderer.resize(this.canvas.clientWidth || 800, this.canvas.clientHeight || 600, dpr);

    if (this.renderer instanceof Canvas2DRenderer) {
      this.renderer.selectedNodeId = this.selectedNode ? this.selectedNode.id : null;
    }
  }

  start(): void {
    if (this.isRunning) return;
    this.isRunning = true;
    this.lastFrameTimestamp = performance.now();
    this.loop(this.lastFrameTimestamp);
    this.eventBus.emit('runtime:start');
  }

  stop(): void {
    this.isRunning = false;
    if (this.animFrameId !== null) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
    this.eventBus.emit('runtime:pause');
  }

  private loop = (timestamp: number) => {
    if (!this.isRunning) return;

    const rawDelta = (timestamp - this.lastFrameTimestamp) / 1000;
    const dt = Math.min(rawDelta, this.config.maxDeltaTime);
    this.lastFrameTimestamp = timestamp;

    this.profiler.recordFrame();

    // 1. Script Engine Update
    this.profiler.startPhase('script');
    this.scriptEngine.update(dt, this.scene, this.scene.timeline);
    this.profiler.endPhase('script');

    // 2. Physics Simulation Step
    if (this.config.enablePhysics) {
      this.profiler.startPhase('physics');
      this.physicsWorld.step(dt);
      this.profiler.endPhase('physics');
    }

    // 3. Scene Graph & Timeline Update
    this.profiler.startPhase('update');
    this.scene.update(dt);
    this.profiler.endPhase('update');

    // 4. Render Pipeline
    this.profiler.startPhase('render');
    this.renderer.beginFrame(this.scene.backgroundColor);
    const stats = this.renderer.renderScene(this.scene);
    this.renderer.endFrame();
    this.profiler.endPhase('render');

    // Telemetry aggregations
    this.profiler.setRenderStats(stats.drawCalls, stats.triangles, stats.nodesRendered);

    let activeParticles = 0;
    const countParticles = (node: SceneNode) => {
      if (node instanceof ParticleEmitterNode) activeParticles += node.getActiveCount();
      for (const child of node.children) countParticles(child);
    };
    countParticles(this.scene.root);

    this.profiler.setSubsystemStats(
      activeParticles,
      this.audioEngine.getActiveVoices(),
      this.physicsWorld.bodies.length
    );

    this.animFrameId = requestAnimationFrame(this.loop);
  };

  loadProject(projectFile: AardvarkProjectFile): void {
    this.scene = ProjectLoader.loadProject(
      projectFile,
      this.physicsWorld,
      this.scriptEngine,
      this.audioEngine
    );
    this.currentProjectName = projectFile.manifest.name;
    this.inputManager.setScene(this.scene);
    this.setSelectedNode(null);

    // Rebind timeline marker audio triggers
    this.scene.timeline.onMarkerReached = (marker) => {
      if (marker.audioTrigger) {
        this.audioEngine.playSfx(marker.audioTrigger as any);
      }
    };

    this.eventBus.emit('project:loaded', { project: projectFile });
  }

  loadSample(key: string): void {
    const proj = SAMPLE_PROJECTS[key];
    if (proj) {
      this.loadProject(proj);
    }
  }

  exportCurrentProject(): string {
    const proj = ProjectSerializer.serialize(this.scene, this.currentProjectName);
    return JSON.stringify(proj, null, 2);
  }

  setSelectedNode(node: SceneNode | null): void {
    this.selectedNode = node;
    if (this.renderer instanceof Canvas2DRenderer) {
      this.renderer.selectedNodeId = node ? node.id : null;
    }
    this.eventBus.emit('node:selected', { node });
  }

  getMetrics(): PerformanceMetrics {
    return this.profiler.getMetrics();
  }
}
