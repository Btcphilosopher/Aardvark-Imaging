// ============================================================================
// AARDVARK RUNTIME - AUDIO SUBSYSTEM ENGINE
// Sound FX synthesizer library, timeline cue hooks & spatial audio bus
// ============================================================================

import { Synthesizer, OscillatorType } from './synthesizer';

export type { OscillatorType };

export type SfxPreset =
  | 'laser'
  | 'jump'
  | 'explosion'
  | 'coin'
  | 'powerup'
  | 'click'
  | 'blip'
  | 'bounce'
  | 'warp'
  | 'drone';

export class AudioEngine {
  public synth: Synthesizer;
  public enabled: boolean = true;
  public volume: number = 0.5;

  constructor() {
    this.synth = new Synthesizer();
  }

  init(): void {
    this.synth.init();
    this.synth.setMasterVolume(this.volume);
  }

  getMasterVolume(): number {
    return this.volume;
  }

  setVolume(vol: number): void {
    this.volume = Math.max(0, Math.min(1, vol));
    this.synth.setMasterVolume(this.volume);
  }

  playSfx(preset: SfxPreset): void {
    if (!this.enabled) return;

    switch (preset) {
      case 'laser':
        this.synth.playTone(880, 0.15, 'sawtooth', { attack: 0.01, decay: 0.1, sustain: 0.1, release: 0.05 });
        break;
      case 'jump':
        this.synth.playTone(320, 0.2, 'triangle', { attack: 0.03, decay: 0.1, sustain: 0.3, release: 0.1 });
        break;
      case 'explosion':
        this.synth.playTone(90, 0.4, 'square', { attack: 0.01, decay: 0.25, sustain: 0.2, release: 0.15 });
        break;
      case 'coin':
        this.synth.playTone(987.77, 0.1, 'sine', { attack: 0.01, decay: 0.05, sustain: 0.5, release: 0.1 });
        setTimeout(() => {
          this.synth.playTone(1318.51, 0.25, 'sine', { attack: 0.01, decay: 0.08, sustain: 0.4, release: 0.15 });
        }, 80);
        break;
      case 'powerup':
        [330, 392, 494, 659].forEach((freq, idx) => {
          setTimeout(() => {
            this.synth.playTone(freq, 0.12, 'triangle');
          }, idx * 60);
        });
        break;
      case 'click':
        this.synth.playTone(1200, 0.03, 'sine', { attack: 0.005, decay: 0.02, sustain: 0.01, release: 0.01 });
        break;
      case 'blip':
        this.synth.playTone(600, 0.05, 'sine');
        break;
      case 'bounce':
        this.synth.playTone(220, 0.15, 'sine', { attack: 0.01, decay: 0.08, sustain: 0.2, release: 0.05 });
        break;
      case 'warp':
        this.synth.playTone(440, 0.25, 'sawtooth', { attack: 0.05, decay: 0.1, sustain: 0.5, release: 0.1 });
        break;
      case 'drone':
        this.synth.playTone(110, 0.8, 'sawtooth', { attack: 0.2, decay: 0.3, sustain: 0.7, release: 0.3 });
        break;
    }
  }

  playTone(frequency: number, duration?: number, waveform: OscillatorType = 'sine'): void {
    if (!this.enabled) return;
    this.synth.playTone(frequency, duration, waveform);
  }

  getActiveVoices(): number {
    return this.synth.getActiveVoices();
  }
}
