// ============================================================================
// AARDVARK RUNTIME - PROCEDURAL SYNTHESIZER
// Real-time Web Audio API polyphonic voice synthesis & DSP chain
// ============================================================================

export type OscillatorType = 'sine' | 'square' | 'sawtooth' | 'triangle';

export interface EnvelopeConfig {
  attack: number; // in seconds
  decay: number;
  sustain: number; // 0..1
  release: number;
}

export class Synthesizer {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private activeVoicesCount: number = 0;

  init(): void {
    if (typeof window === 'undefined') return;
    const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
    if (AudioCtxClass && !this.ctx) {
      this.ctx = new AudioCtxClass();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(0.3, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);
    }
  }

  ensureContext(): AudioContext | null {
    if (!this.ctx) {
      this.init();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  setMasterVolume(volume: number): void {
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(Math.max(0, Math.min(1, volume)), this.ctx.currentTime);
    }
  }

  playTone(
    frequency: number,
    duration: number = 0.3,
    type: OscillatorType = 'sine',
    envelope?: Partial<EnvelopeConfig>
  ): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;

    const env: EnvelopeConfig = {
      attack: envelope?.attack ?? 0.02,
      decay: envelope?.decay ?? 0.08,
      sustain: envelope?.sustain ?? 0.4,
      release: envelope?.release ?? 0.15,
    };

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(frequency, ctx.currentTime);

    const now = ctx.currentTime;
    gain.gain.setValueAtTime(0.0001, now);
    // Attack
    gain.gain.exponentialRampToValueAtTime(0.8, now + env.attack);
    // Decay to sustain
    gain.gain.exponentialRampToValueAtTime(Math.max(0.001, env.sustain * 0.8), now + env.attack + env.decay);
    // Release
    const totalTime = Math.max(now + duration, now + env.attack + env.decay);
    gain.gain.exponentialRampToValueAtTime(0.0001, totalTime + env.release);

    osc.connect(gain);
    gain.connect(this.masterGain);

    this.activeVoicesCount++;
    osc.start(now);
    osc.stop(totalTime + env.release + 0.05);

    osc.onended = () => {
      this.activeVoicesCount = Math.max(0, this.activeVoicesCount - 1);
      osc.disconnect();
      gain.disconnect();
    };
  }

  getActiveVoices(): number {
    return this.activeVoicesCount;
  }
}
