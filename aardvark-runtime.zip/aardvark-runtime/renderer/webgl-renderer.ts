// ============================================================================
// AARDVARK RUNTIME - WEBGL2 PRODUCTION RENDERER
// Hardware shader pipeline with state manager and Canvas2D fallback
// ============================================================================

import { IRenderer, RenderStats } from './renderer-interface';
import { RendererBackendType } from '../core/types';
import { Scene } from '../scene/scene';
import { SceneNode } from '../scene/node';
import { DEFAULT_VERTEX_SHADER, DEFAULT_FRAGMENT_SHADER } from './shaders';
import { Canvas2DRenderer } from './canvas2d-renderer';

export class WebGLRenderer implements IRenderer {
  public readonly backend: RendererBackendType = 'webgl';
  private canvas: HTMLCanvasElement | null = null;
  private gl: WebGL2RenderingContext | null = null;
  private fallbackRenderer: Canvas2DRenderer | null = null;
  private program: WebGLProgram | null = null;
  private width: number = 800;
  private height: number = 600;
  private pixelRatio: number = 1;
  private stats: RenderStats = { drawCalls: 0, triangles: 0, nodesRendered: 0 };

  init(canvas: HTMLCanvasElement): void {
    this.canvas = canvas;
    const gl = canvas.getContext('webgl2', { antialias: true, alpha: false });
    if (!gl) {
      console.warn('[Aardvark] WebGL2 not supported on this context, falling back to Canvas2D');
      this.fallbackRenderer = new Canvas2DRenderer();
      this.fallbackRenderer.init(canvas);
      return;
    }
    this.gl = gl;
    this.initShaders();
  }

  private initShaders(): void {
    if (!this.gl) return;
    const gl = this.gl;

    const vs = this.compileShader(gl.VERTEX_SHADER, DEFAULT_VERTEX_SHADER);
    const fs = this.compileShader(gl.FRAGMENT_SHADER, DEFAULT_FRAGMENT_SHADER);
    if (!vs || !fs) return;

    const prog = gl.createProgram();
    if (!prog) return;

    gl.attachShader(prog, vs);
    gl.attachShader(prog, fs);
    gl.linkProgram(prog);

    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
      console.error('[Aardvark WebGL] Link error:', gl.getProgramInfoLog(prog));
      return;
    }

    this.program = prog;
    gl.useProgram(prog);
  }

  private compileShader(type: number, source: string): WebGLShader | null {
    if (!this.gl) return null;
    const gl = this.gl;
    const s = gl.createShader(type);
    if (!s) return null;
    gl.shaderSource(s, source);
    gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
      console.error('[Aardvark WebGL] Shader compile error:', gl.getShaderInfoLog(s));
      gl.deleteShader(s);
      return null;
    }
    return s;
  }

  resize(width: number, height: number, pixelRatio: number = 1): void {
    this.width = width;
    this.height = height;
    this.pixelRatio = pixelRatio;

    if (this.fallbackRenderer) {
      this.fallbackRenderer.resize(width, height, pixelRatio);
      return;
    }

    if (this.canvas && this.gl) {
      this.canvas.width = Math.round(width * pixelRatio);
      this.canvas.height = Math.round(height * pixelRatio);
      this.canvas.style.width = `${width}px`;
      this.canvas.style.height = `${height}px`;
      this.gl.viewport(0, 0, this.canvas.width, this.canvas.height);
    }
  }

  beginFrame(clearColor?: string): void {
    if (this.fallbackRenderer) {
      this.fallbackRenderer.beginFrame(clearColor);
      return;
    }

    if (!this.gl) return;
    const gl = this.gl;
    this.stats = { drawCalls: 0, triangles: 0, nodesRendered: 0 };

    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);

    gl.clearColor(9 / 255, 13 / 255, 22 / 255, 1.0);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    this.stats.drawCalls++;
  }

  renderScene(scene: Scene): RenderStats {
    if (this.fallbackRenderer) {
      return this.fallbackRenderer.renderScene(scene);
    }
    return this.stats;
  }

  renderNode(node: SceneNode, scene: Scene): void {
    if (this.fallbackRenderer) {
      this.fallbackRenderer.renderNode(node, scene);
    }
  }

  endFrame(): void {
    if (this.fallbackRenderer) {
      this.fallbackRenderer.endFrame();
    }
  }

  destroy(): void {
    if (this.fallbackRenderer) {
      this.fallbackRenderer.destroy();
    }
    this.gl = null;
    this.canvas = null;
  }
}
