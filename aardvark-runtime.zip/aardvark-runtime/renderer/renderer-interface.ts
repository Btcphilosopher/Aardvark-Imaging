// ============================================================================
// AARDVARK RUNTIME - RENDERER INTERFACE
// Unified hardware abstraction layer for Canvas2D and WebGL backends
// ============================================================================

import { Scene } from '../scene/scene';
import { SceneNode } from '../scene/node';
import { RendererBackendType } from '../core/types';

export interface RenderStats {
  drawCalls: number;
  triangles: number;
  nodesRendered: number;
}

export interface IRenderer {
  readonly backend: RendererBackendType;
  init(canvas: HTMLCanvasElement): void;
  resize(width: number, height: number, pixelRatio?: number): void;
  beginFrame(clearColor?: string): void;
  renderScene(scene: Scene): RenderStats;
  renderNode(node: SceneNode, scene: Scene): void;
  endFrame(): void;
  destroy(): void;
}
