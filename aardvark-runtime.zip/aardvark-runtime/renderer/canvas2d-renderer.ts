// ============================================================================
// AARDVARK RUNTIME - CANVAS2D PRODUCTION RENDERER
// Hardware-accelerated 2D/3D visual pipeline with blend modes, vector paths & lighting
// ============================================================================

import { IRenderer, RenderStats } from './renderer-interface';
import { RendererBackendType } from '../core/types';
import { Scene } from '../scene/scene';
import { SceneNode } from '../scene/node';
import { ShapeNode, PathNode, SpriteNode, TextNode, GroupNode, SymbolNode } from '../scene/shapes';
import { ParticleEmitterNode } from '../scene/particles';
import { Object3DNode, Face3D } from '../scene/object3d';
import { UIElementNode } from '../scene/ui-node';
import { CameraNode } from '../scene/camera';
import { Vec3, Vec2, Color, degToRad } from '../core/math';

export class Canvas2DRenderer implements IRenderer {
  public readonly backend: RendererBackendType = 'canvas2d';
  private canvas: HTMLCanvasElement | null = null;
  private ctx: CanvasRenderingContext2D | null = null;
  private width: number = 800;
  private height: number = 600;
  private pixelRatio: number = 1;
  private stats: RenderStats = { drawCalls: 0, triangles: 0, nodesRendered: 0 };
  public selectedNodeId: string | null = null;

  init(canvas: HTMLCanvasElement): void {
    this.canvas = canvas;
    const ctx = canvas.getContext('2d', { alpha: false, desynchronized: true });
    if (!ctx) {
      throw new Error('[Aardvark] Canvas2D context creation failed');
    }
    this.ctx = ctx;
  }

  resize(width: number, height: number, pixelRatio: number = 1): void {
    this.width = width;
    this.height = height;
    this.pixelRatio = pixelRatio;
    if (this.canvas) {
      this.canvas.width = Math.round(width * pixelRatio);
      this.canvas.height = Math.round(height * pixelRatio);
      this.canvas.style.width = `${width}px`;
      this.canvas.style.height = `${height}px`;
    }
  }

  beginFrame(clearColor?: string): void {
    if (!this.ctx || !this.canvas) return;
    this.stats = { drawCalls: 0, triangles: 0, nodesRendered: 0 };

    this.ctx.save();
    this.ctx.setTransform(this.pixelRatio, 0, 0, this.pixelRatio, 0, 0);

    // Clear background
    this.ctx.fillStyle = clearColor || '#090d16';
    this.ctx.fillRect(0, 0, this.width, this.height);
    this.stats.drawCalls++;
  }

  renderScene(scene: Scene): RenderStats {
    if (!this.ctx) return this.stats;

    // Apply camera transform if present
    const camera = scene.activeCamera;
    if (camera) {
      this.ctx.save();
      // Center canvas origin
      this.ctx.translate(this.width / 2, this.height / 2);
      this.ctx.scale(camera.zoom, camera.zoom);
      this.ctx.translate(-camera.transform.x, -camera.transform.y);
      if (camera.transform.rotation !== 0) {
        this.ctx.rotate(camera.transform.rotation);
      }
    }

    // Render scene nodes recursively
    this.renderNodeHierarchy(scene.root, scene);

    if (camera) {
      this.ctx.restore();
    }

    return this.stats;
  }

  private renderNodeHierarchy(node: SceneNode, scene: Scene): void {
    if (!node.visible || node.worldOpacity <= 0.001) return;

    this.renderNode(node, scene);

    // Sort children by zIndex for proper layer compositing
    const sortedChildren = [...node.children].sort((a, b) => a.zIndex - b.zIndex);
    for (const child of sortedChildren) {
      this.renderNodeHierarchy(child, scene);
    }

    // Render selection gizmo if selected
    if (this.selectedNodeId && node.id === this.selectedNodeId) {
      this.renderSelectionGizmo(node);
    }
  }

  renderNode(node: SceneNode, scene: Scene): void {
    if (!this.ctx) return;
    const ctx = this.ctx;

    ctx.save();

    // Set world transformation matrix
    const wm = node.getWorldMatrix().elements;
    ctx.setTransform(
      wm[0] * this.pixelRatio,
      wm[1] * this.pixelRatio,
      wm[2] * this.pixelRatio,
      wm[3] * this.pixelRatio,
      wm[4] * this.pixelRatio,
      wm[5] * this.pixelRatio
    );

    ctx.globalAlpha = node.worldOpacity;
    ctx.globalCompositeOperation = node.blendMode as GlobalCompositeOperation;

    this.stats.nodesRendered++;

    if (node instanceof ShapeNode) {
      this.renderShape(node);
    } else if (node instanceof PathNode) {
      this.renderPath(node);
    } else if (node instanceof SpriteNode) {
      this.renderSprite(node);
    } else if (node instanceof TextNode) {
      this.renderText(node);
    } else if (node instanceof ParticleEmitterNode) {
      this.renderParticles(node);
    } else if (node instanceof Object3DNode) {
      this.renderObject3D(node, scene);
    } else if (node instanceof UIElementNode) {
      this.renderUIElement(node);
    }

    ctx.restore();
  }

  private renderShape(node: ShapeNode): void {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const bounds = node.getLocalBounds();
    const x = bounds.x;
    const y = bounds.y;
    const w = bounds.width;
    const h = bounds.height;

    ctx.beginPath();

    if (node.geometry === 'rectangle') {
      ctx.rect(x, y, w, h);
    } else if (node.geometry === 'rounded_rectangle') {
      const r = Math.min(node.cornerRadius, w / 2, h / 2);
      ctx.roundRect(x, y, w, h, r);
    } else if (node.geometry === 'circle') {
      const radius = Math.min(w, h) / 2;
      ctx.arc(x + w / 2, y + h / 2, radius, 0, Math.PI * 2);
    } else if (node.geometry === 'ellipse') {
      ctx.ellipse(x + w / 2, y + h / 2, w / 2, h / 2, 0, 0, Math.PI * 2);
    } else if (node.geometry === 'polygon' || node.geometry === 'star') {
      this.drawPolygonOrStar(ctx, x + w / 2, y + h / 2, w / 2, node.sides, node.geometry === 'star', node.innerRadiusRatio);
    }

    // Fill
    if (node.fill.type !== 'none') {
      if (node.fill.type === 'solid') {
        ctx.fillStyle = node.fill.color;
      } else if (node.fill.type === 'linear_gradient') {
        const grad = ctx.createLinearGradient(x, y, x + w, y + h);
        const colors = node.fill.gradientColors || ['#6366f1', '#a855f7'];
        const stops = node.fill.gradientStops || [0, 1];
        colors.forEach((c, idx) => grad.addColorStop(stops[idx] || idx / (colors.length - 1), c));
        ctx.fillStyle = grad;
      }
      ctx.fill();
      this.stats.drawCalls++;
      this.stats.triangles += 2;
    }

    // Stroke
    if (node.stroke.enabled) {
      ctx.strokeStyle = node.stroke.color;
      ctx.lineWidth = node.stroke.width;
      if (node.stroke.lineCap) ctx.lineCap = node.stroke.lineCap;
      if (node.stroke.lineJoin) ctx.lineJoin = node.stroke.lineJoin;
      if (node.stroke.dash) ctx.setLineDash(node.stroke.dash);
      ctx.stroke();
      this.stats.drawCalls++;
    }
  }

  private drawPolygonOrStar(
    ctx: CanvasRenderingContext2D,
    cx: number,
    cy: number,
    radius: number,
    points: number,
    isStar: boolean,
    innerRatio: number = 0.5
  ): void {
    const totalPoints = isStar ? points * 2 : points;
    const step = (Math.PI * 2) / totalPoints;

    for (let i = 0; i < totalPoints; i++) {
      const r = isStar && i % 2 === 1 ? radius * innerRatio : radius;
      const angle = i * step - Math.PI / 2;
      const px = cx + Math.cos(angle) * r;
      const py = cy + Math.sin(angle) * r;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
  }

  private renderPath(node: PathNode): void {
    if (!this.ctx || node.commands.length === 0) return;
    const ctx = this.ctx;

    ctx.beginPath();
    for (const cmd of node.commands) {
      if (cmd.type === 'M') {
        ctx.moveTo(cmd.x || 0, cmd.y || 0);
      } else if (cmd.type === 'L') {
        ctx.lineTo(cmd.x || 0, cmd.y || 0);
      } else if (cmd.type === 'C') {
        ctx.bezierCurveTo(cmd.cp1x || 0, cmd.cp1y || 0, cmd.cp2x || 0, cmd.cp2y || 0, cmd.x || 0, cmd.y || 0);
      } else if (cmd.type === 'Q') {
        ctx.quadraticCurveTo(cmd.cp1x || 0, cmd.cp1y || 0, cmd.x || 0, cmd.y || 0);
      } else if (cmd.type === 'Z') {
        ctx.closePath();
      }
    }

    if (node.fill.type !== 'none') {
      ctx.fillStyle = node.fill.color;
      ctx.fill();
      this.stats.drawCalls++;
      this.stats.triangles += 4;
    }

    if (node.stroke.enabled) {
      ctx.strokeStyle = node.stroke.color;
      ctx.lineWidth = node.stroke.width;
      ctx.stroke();
      this.stats.drawCalls++;
    }
  }

  private renderSprite(node: SpriteNode): void {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const b = node.getLocalBounds();

    if (node.proceduralPattern) {
      // Draw procedural texture pattern
      ctx.save();
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(b.x, b.y, b.width, b.height);

      if (node.proceduralPattern === 'grid') {
        ctx.strokeStyle = '#334155';
        ctx.lineWidth = 1;
        const step = 20;
        ctx.beginPath();
        for (let x = b.x; x <= b.x + b.width; x += step) {
          ctx.moveTo(x, b.y);
          ctx.lineTo(x, b.y + b.height);
        }
        for (let y = b.y; y <= b.y + b.height; y += step) {
          ctx.moveTo(b.x, y);
          ctx.lineTo(b.x + b.width, y);
        }
        ctx.stroke();
      }
      ctx.restore();
      this.stats.drawCalls += 2;
      this.stats.triangles += 2;
    } else {
      // Placeholder or raster frame
      ctx.fillStyle = '#38bdf8';
      ctx.fillRect(b.x, b.y, b.width, b.height);
      this.stats.drawCalls++;
      this.stats.triangles += 2;
    }
  }

  private renderText(node: TextNode): void {
    if (!this.ctx || !node.text) return;
    const ctx = this.ctx;

    ctx.font = `${node.fontWeight} ${node.fontSize}px ${node.fontFamily}`;
    ctx.textAlign = node.textAlign;
    ctx.textBaseline = 'middle';

    if (node.strokeWidth > 0) {
      ctx.strokeStyle = node.strokeColor;
      ctx.lineWidth = node.strokeWidth;
      ctx.strokeText(node.text, 0, 0);
      this.stats.drawCalls++;
    }

    ctx.fillStyle = node.color;
    ctx.fillText(node.text, 0, 0);
    this.stats.drawCalls++;
  }

  private renderParticles(node: ParticleEmitterNode): void {
    if (!this.ctx || node.particles.length === 0) return;
    const ctx = this.ctx;

    ctx.save();
    ctx.globalCompositeOperation = (node.blendModeOverride as any) || 'lighter';

    for (const p of node.particles) {
      if (!p.active) continue;

      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rotation);
      ctx.fillStyle = p.color.toRgbaString();

      const halfS = p.size / 2;
      ctx.beginPath();
      ctx.arc(0, 0, halfS, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      this.stats.triangles += 2;
    }

    ctx.restore();
    this.stats.drawCalls++;
  }

  private renderObject3D(node: Object3DNode, scene: Scene): void {
    if (!this.ctx || node.vertices.length === 0) return;
    const ctx = this.ctx;

    // 3D rotation Euler angles
    const cx = Math.cos(node.rotX), sx = Math.sin(node.rotX);
    const cy = Math.cos(node.rotY), sy = Math.sin(node.rotY);
    const cz = Math.cos(node.rotZ), sz = Math.sin(node.rotZ);

    // Light direction
    const lightDir = new Vec3(0.5, -0.8, 1.0).normalize();

    // 1. Transform vertices to camera view space
    const projectedVertices: { x: number; y: number; z: number }[] = [];
    const fov = 400; // Perspective distance

    for (const v of node.vertices) {
      // Scale
      let x = v.x * node.scale3D.x;
      let y = v.y * node.scale3D.y;
      let z = v.z * node.scale3D.z;

      // Rotate Y
      let x1 = x * cy + z * sy;
      let y1 = y;
      let z1 = -x * sy + z * cy;

      // Rotate X
      let x2 = x1;
      let y2 = y1 * cx - z1 * sx;
      let z2 = y1 * sx + z1 * cx;

      // Rotate Z
      let x3 = x2 * cz - y2 * sz;
      let y3 = x2 * sz + y2 * cz;
      let z3 = z2;

      // Perspective projection
      const distance = fov + z3;
      const factor = distance > 10 ? fov / distance : 1;

      projectedVertices.push({
        x: x3 * factor,
        y: y3 * factor,
        z: z3,
      });
    }

    // 2. Sort faces by average Z depth (Painter's Algorithm)
    const sortedFaces = [...node.faces].map((face) => {
      const v0 = projectedVertices[face.indices[0]];
      const v1 = projectedVertices[face.indices[1]];
      const v2 = projectedVertices[face.indices[2]];
      const avgZ = (v0.z + v1.z + v2.z) / 3;

      // Face normal for shading
      const ax = v1.x - v0.x, ay = v1.y - v0.y;
      const bx = v2.x - v0.x, by = v2.y - v0.y;
      // 2D cross product for back-face culling
      const cross = ax * by - ay * bx;

      return { face, avgZ, cross, v0, v1, v2 };
    });

    sortedFaces.sort((a, b) => b.avgZ - a.avgZ);

    // 3. Draw sorted faces
    for (const item of sortedFaces) {
      if (item.cross <= 0 && !node.wireframe) {
        // Backface culling
        continue;
      }

      ctx.beginPath();
      ctx.moveTo(item.v0.x, item.v0.y);
      ctx.lineTo(item.v1.x, item.v1.y);
      ctx.lineTo(item.v2.x, item.v2.y);
      ctx.closePath();

      if (!node.wireframe) {
        // Calculate Lambertian diffuse shading
        const normal = item.face.normal || new Vec3(0, 0, 1);
        // Rotate normal with same Y and X rotations
        let nx = normal.x * cy + normal.z * sy;
        let ny = normal.y;
        let nz = -normal.x * sy + normal.z * cy;
        let ny2 = ny * cx - nz * sx;
        let nz2 = ny * sx + nz * cx;
        const rotNorm = new Vec3(nx, ny2, nz2).normalize();

        const diffuse = Math.max(0.2, rotNorm.dot(lightDir));
        const base = Color.fromHex(item.face.color || node.baseColor);
        ctx.fillStyle = `rgb(${Math.round(base.r * 255 * diffuse)}, ${Math.round(base.g * 255 * diffuse)}, ${Math.round(base.b * 255 * diffuse)})`;
        ctx.fill();
        this.stats.triangles++;
        this.stats.drawCalls++;
      }

      ctx.strokeStyle = node.strokeColor;
      ctx.lineWidth = node.lineWidth;
      ctx.stroke();
      this.stats.drawCalls++;
    }
  }

  private renderUIElement(node: UIElementNode): void {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const b = node.getLocalBounds();

    const color = node.isPressed
      ? node.activeColor
      : node.isHovered
      ? node.hoverColor
      : node.primaryColor;

    if (node.widgetType === 'button') {
      // Rounded card
      ctx.beginPath();
      ctx.roundRect(b.x, b.y, b.width, b.height, node.borderRadius);
      ctx.fillStyle = color;
      ctx.fill();

      // Border highlight
      ctx.strokeStyle = '#818cf8';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Text label
      ctx.fillStyle = node.textColor;
      ctx.font = '600 14px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(node.label, 0, 0);

      this.stats.drawCalls += 3;
      this.stats.triangles += 2;
    } else if (node.widgetType === 'slider') {
      // Slider track
      const trackH = 6;
      ctx.beginPath();
      ctx.roundRect(b.x, -trackH / 2, b.width, trackH, 3);
      ctx.fillStyle = '#334155';
      ctx.fill();

      // Filled progress track
      const filledW = b.width * node.value;
      ctx.beginPath();
      ctx.roundRect(b.x, -trackH / 2, filledW, trackH, 3);
      ctx.fillStyle = color;
      ctx.fill();

      // Slider Thumb
      const thumbX = b.x + filledW;
      ctx.beginPath();
      ctx.arc(thumbX, 0, 9, 0, Math.PI * 2);
      ctx.fillStyle = '#f8fafc';
      ctx.fill();
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.stroke();

      this.stats.drawCalls += 4;
    } else if (node.widgetType === 'toggle') {
      const toggleW = 50;
      const toggleH = 26;
      ctx.beginPath();
      ctx.roundRect(-toggleW / 2, -toggleH / 2, toggleW, toggleH, toggleH / 2);
      ctx.fillStyle = node.checked ? '#10b981' : '#475569';
      ctx.fill();

      const thumbX = node.checked ? toggleW / 2 - 13 : -toggleW / 2 + 13;
      ctx.beginPath();
      ctx.arc(thumbX, 0, 10, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.fill();

      // Text label
      ctx.fillStyle = '#e2e8f0';
      ctx.font = '500 13px system-ui, sans-serif';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      ctx.fillText(node.label, toggleW / 2 + 10, 0);

      this.stats.drawCalls += 3;
    }
  }

  private renderSelectionGizmo(node: SceneNode): void {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const b = node.getLocalBounds();

    ctx.save();
    const wm = node.getWorldMatrix().elements;
    ctx.setTransform(
      wm[0] * this.pixelRatio,
      wm[1] * this.pixelRatio,
      wm[2] * this.pixelRatio,
      wm[3] * this.pixelRatio,
      wm[4] * this.pixelRatio,
      wm[5] * this.pixelRatio
    );

    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([4, 4]);
    ctx.strokeRect(b.x, b.y, b.width, b.height);

    // Corner anchor points
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#0284c7';
    ctx.setLineDash([]);
    const corners = [
      [b.x, b.y],
      [b.x + b.width, b.y],
      [b.x + b.width, b.y + b.height],
      [b.x, b.y + b.height],
    ];
    for (const [cx, cy] of corners) {
      ctx.fillRect(cx - 3, cy - 3, 6, 6);
      ctx.strokeRect(cx - 3, cy - 3, 6, 6);
    }

    ctx.restore();
  }

  endFrame(): void {
    if (!this.ctx) return;
    this.ctx.restore();
  }

  destroy(): void {
    this.canvas = null;
    this.ctx = null;
  }
}
