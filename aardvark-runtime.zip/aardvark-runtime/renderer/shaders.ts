// ============================================================================
// AARDVARK RUNTIME - SHADER DEFINITIONS
// WebGL vertex and fragment shaders for textured quads, batching & color transforms
// ============================================================================

export const DEFAULT_VERTEX_SHADER = `#version 300 es
precision highp float;

in vec2 a_position;
in vec2 a_texCoord;
in vec4 a_color;

uniform mat3 u_matrix;
uniform vec2 u_resolution;

out vec2 v_texCoord;
out vec4 v_color;

void main() {
    // Apply 2D affine matrix
    vec3 pos = u_matrix * vec3(a_position, 1.0);
    // Convert from pixel space to clip space [-1, 1]
    vec2 zeroToOne = pos.xy / u_resolution;
    vec2 zeroToTwo = zeroToOne * 2.0;
    vec2 clipSpace = zeroToTwo - 1.0;

    gl_Position = vec4(clipSpace * vec2(1, -1), 0, 1);
    v_texCoord = a_texCoord;
    v_color = a_color;
}
`;

export const DEFAULT_FRAGMENT_SHADER = `#version 300 es
precision highp float;

in vec2 v_texCoord;
in vec4 v_color;

uniform sampler2D u_texture;
uniform int u_useTexture;

out vec4 fragColor;

void main() {
    if (u_useTexture == 1) {
        fragColor = texture(u_texture, v_texCoord) * v_color;
    } else {
        fragColor = v_color;
    }
}
`;
