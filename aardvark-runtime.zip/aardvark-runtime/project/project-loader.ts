// ============================================================================
// AARDVARK RUNTIME - PROJECT LOADER & PARSER
// Instantiates operational scene graphs, timelines, physics bodies, and scripts
// ============================================================================

import { AardvarkProjectFile, SerializedNode, SerializedScene } from './project-types';
import { Scene } from '../scene/scene';
import { SceneNode } from '../scene/node';
import { GroupNode, ShapeNode, PathNode, SpriteNode, TextNode } from '../scene/shapes';
import { Object3DNode, MeshPreset } from '../scene/object3d';
import { ParticleEmitterNode } from '../scene/particles';
import { UIElementNode, UIWidgetType } from '../scene/ui-node';
import { CameraNode } from '../scene/camera';
import { LightNode } from '../scene/light';
import { Timeline } from '../timeline/timeline';
import { TimelineTrack } from '../timeline/track';
import { PhysicsWorld } from '../physics/physics-world';
import { RigidBody } from '../physics/rigid-body';
import { ScriptEngine } from '../scripting/script-engine';
import { AudioEngine } from '../audio/audio-engine';

export class ProjectLoader {
  static loadProject(
    project: AardvarkProjectFile,
    physicsWorld: PhysicsWorld,
    scriptEngine: ScriptEngine,
    audioEngine: AudioEngine
  ): Scene {
    // 1. Find initial scene
    const initialSceneDef =
      project.scenes.find((s) => s.id === project.manifest.initialSceneId) || project.scenes[0];

    if (!initialSceneDef) {
      throw new Error('[Aardvark ProjectLoader] Project contains no scenes');
    }

    // 2. Clear previous physics bodies & behaviors
    physicsWorld.clear();
    scriptEngine.clear();

    // 3. Build scene
    const scene = new Scene(initialSceneDef.name, initialSceneDef.id);
    scene.backgroundColor = initialSceneDef.backgroundColor || project.manifest.canvas.backgroundColor || '#090d16';

    // 4. Instantiate node hierarchy
    scene.root.removeAllChildren();
    if (initialSceneDef.root.children) {
      for (const childDef of initialSceneDef.root.children) {
        const node = this.instantiateNode(childDef, physicsWorld, scriptEngine, audioEngine);
        scene.root.addChild(node);
      }
    }

    // 5. Build timeline
    const tDef = initialSceneDef.timeline;
    scene.timeline = new Timeline(initialSceneDef.name + '_Timeline', tDef.fps, tDef.durationFrames);
    scene.timeline.loop = tDef.loop !== false;
    scene.timeline.pingPong = !!tDef.pingPong;

    for (const trackDef of tDef.tracks) {
      const track = new TimelineTrack(trackDef.name, trackDef.targetNodeId, trackDef.propertyPath, trackDef.id);
      for (const kf of trackDef.keyframes) {
        track.addKeyframe({
          frame: kf.frame,
          value: kf.value,
          easing: kf.easing as any,
          isHold: kf.isHold,
          isBlank: kf.isBlank,
        });
      }
      scene.timeline.addTrack(track);
    }

    if (tDef.markers) {
      for (const m of tDef.markers) {
        scene.timeline.addMarker(m.frame, m.label, m.actionScript, m.audioTrigger);
      }
    }

    // 6. Evaluate initial frame
    scene.timeline.gotoAndStop(1);
    scene.timeline.evaluateAt(1, scene.root);
    scene.root.updateWorldTransform(true);

    return scene;
  }

  private static instantiateNode(
    def: SerializedNode,
    physicsWorld: PhysicsWorld,
    scriptEngine: ScriptEngine,
    audioEngine: AudioEngine
  ): SceneNode {
    let node: SceneNode;

    switch (def.type) {
      case 'shape': {
        const shape = new ShapeNode(def.name, def.id);
        shape.geometry = (def.geometry as any) || 'rectangle';
        shape.width = def.width || 100;
        shape.height = def.height || 100;
        shape.cornerRadius = def.cornerRadius || 0;
        if (def.fill) shape.fill = { ...shape.fill, ...def.fill };
        if (def.stroke) shape.stroke = { ...shape.stroke, ...def.stroke };
        node = shape;
        break;
      }
      case 'path': {
        const path = new PathNode(def.name, def.id);
        if (def.svgPath) path.setCommandsFromSvg(def.svgPath);
        if (def.fill) path.fill = { ...path.fill, ...def.fill };
        if (def.stroke) path.stroke = { ...path.stroke, ...def.stroke };
        node = path;
        break;
      }
      case 'text': {
        const text = new TextNode(def.name, def.id);
        text.text = def.text || '';
        text.fontSize = def.fontSize || 24;
        text.fontFamily = def.fontFamily || 'system-ui, sans-serif';
        text.color = def.color || '#ffffff';
        node = text;
        break;
      }
      case 'sprite': {
        const sprite = new SpriteNode(def.name, def.id);
        sprite.width = def.width || 100;
        sprite.height = def.height || 100;
        node = sprite;
        break;
      }
      case 'object3d': {
        const obj = new Object3DNode(def.name, (def.preset3D as MeshPreset) || 'cube', def.id);
        obj.wireframe = !!def.wireframe;
        if (def.baseColor) obj.baseColor = def.baseColor;
        node = obj;
        break;
      }
      case 'particle_emitter': {
        const emitter = new ParticleEmitterNode(def.name, def.id);
        if (def.emissionRate) emitter.emissionRate = def.emissionRate;
        if (def.startColor) emitter.startColor = def.startColor;
        if (def.endColor) emitter.endColor = def.endColor;
        node = emitter;
        break;
      }
      case 'ui_element': {
        const ui = new UIElementNode(def.name, (def.widgetType as UIWidgetType) || 'button', def.id);
        if (def.width) ui.width = def.width;
        if (def.height) ui.height = def.height;
        if (def.label) ui.label = def.label;
        node = ui;
        break;
      }
      case 'camera': {
        const cam = new CameraNode(def.name, def.id);
        node = cam;
        break;
      }
      case 'light': {
        const light = new LightNode(def.name, def.id);
        node = light;
        break;
      }
      case 'group':
      default: {
        node = new GroupNode(def.name, def.id);
        break;
      }
    }

    // Apply basic transform properties
    if (def.transform) {
      node.transform.x = def.transform.x || 0;
      node.transform.y = def.transform.y || 0;
      node.transform.scaleX = def.transform.scaleX ?? 1;
      node.transform.scaleY = def.transform.scaleY ?? 1;
      node.transform.rotation = def.transform.rotation || 0;
      node.transform.anchorX = def.transform.anchorX ?? 0.5;
      node.transform.anchorY = def.transform.anchorY ?? 0.5;
    }

    if (def.visible !== undefined) node.visible = def.visible;
    if (def.opacity !== undefined) node.opacity = def.opacity;
    if (def.blendMode) node.blendMode = def.blendMode as any;
    if (def.zIndex !== undefined) node.zIndex = def.zIndex;
    if (def.tags) node.tags = [...def.tags];

    // Physics attachment
    if (def.physics) {
      const body = new RigidBody(node, def.physics.type, def.physics.shape);
      if (def.physics.radius) body.radius = def.physics.radius;
      if (def.physics.width) body.width = def.physics.width;
      if (def.physics.height) body.height = def.physics.height;
      if (def.physics.restitution !== undefined) body.restitution = def.physics.restitution;
      physicsWorld.addBody(body);
    }

    // Script attachment
    if (def.scriptUpdate) {
      scriptEngine.addBehavior({
        nodeId: node.id,
        updateSource: def.scriptUpdate,
      });
    }

    // Recursive children
    if (def.children) {
      for (const childDef of def.children) {
        node.addChild(this.instantiateNode(childDef, physicsWorld, scriptEngine, audioEngine));
      }
    }

    return node;
  }
}
