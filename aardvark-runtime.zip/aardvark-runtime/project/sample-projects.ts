// ============================================================================
// AARDVARK RUNTIME - SAMPLE PROJECTS LIBRARY
// 5 Production-grade .aard projects demonstrating runtime capabilities
// ============================================================================

import { AardvarkProjectFile } from './project-types';

export const SAMPLE_PROJECTS: Record<string, AardvarkProjectFile> = {
  orbital_station: {
    manifest: {
      formatVersion: '1.0.0',
      name: 'Orbital Station 9',
      description: 'Cinematic vector motion graphic with multi-track timeline, thruster particles & docking sequence',
      author: 'Aardvark Motion Studios',
      createdAt: '2026-03-01T00:00:00Z',
      targetFps: 30,
      canvas: {
        width: 800,
        height: 600,
        backgroundColor: '#060913',
        scaleMode: 'fit',
      },
      initialSceneId: 'scene_station',
    },
    scenes: [
      {
        id: 'scene_station',
        name: 'Orbital Approach',
        backgroundColor: '#060913',
        timeline: {
          fps: 30,
          durationFrames: 120,
          loop: true,
          pingPong: false,
          tracks: [
            // Shuttle position X & Y
            {
              id: 'track_shuttle_x',
              name: 'Shuttle X Path',
              targetNodeId: 'node_shuttle',
              propertyPath: 'transform.x',
              keyframes: [
                { frame: 1, value: -280, easing: 'easeInOutQuad' },
                { frame: 45, value: -80, easing: 'easeInOutQuad' },
                { frame: 75, value: 0, easing: 'easeInOutCubic' },
                { frame: 100, value: 0, easing: 'linear' },
                { frame: 120, value: 300, easing: 'easeInQuad' },
              ],
            },
            {
              id: 'track_shuttle_y',
              name: 'Shuttle Y Path',
              targetNodeId: 'node_shuttle',
              propertyPath: 'transform.y',
              keyframes: [
                { frame: 1, value: 140, easing: 'easeInOutQuad' },
                { frame: 45, value: -20, easing: 'easeInOutQuad' },
                { frame: 75, value: -30, easing: 'easeInOutCubic' },
                { frame: 100, value: -30, easing: 'linear' },
                { frame: 120, value: -180, easing: 'easeInQuad' },
              ],
            },
            // Shuttle Rotation
            {
              id: 'track_shuttle_rot',
              name: 'Shuttle Pitch Angle',
              targetNodeId: 'node_shuttle',
              propertyPath: 'transform.rotation',
              keyframes: [
                { frame: 1, value: -0.2, easing: 'easeInOutQuad' },
                { frame: 45, value: 0.1, easing: 'easeInOutQuad' },
                { frame: 75, value: 0, easing: 'linear' },
                { frame: 100, value: 0.3, easing: 'easeInQuad' },
                { frame: 120, value: 0.6, easing: 'linear' },
              ],
            },
            // Station Solar Panel Rotation
            {
              id: 'track_panels_rot',
              name: 'Solar Panels Orbit',
              targetNodeId: 'node_station_core',
              propertyPath: 'transform.rotation',
              keyframes: [
                { frame: 1, value: 0, easing: 'linear' },
                { frame: 120, value: Math.PI * 2, easing: 'linear' },
              ],
            },
            // Docking Beacon Flash
            {
              id: 'track_beacon_scale',
              name: 'Docking Beacon Pulse',
              targetNodeId: 'node_beacon',
              propertyPath: 'transform.scaleX',
              keyframes: [
                { frame: 1, value: 0.8, easing: 'easeInOutQuad' },
                { frame: 30, value: 1.4, easing: 'easeInOutQuad' },
                { frame: 60, value: 0.8, easing: 'easeInOutQuad' },
                { frame: 90, value: 1.4, easing: 'easeInOutQuad' },
                { frame: 120, value: 0.8, easing: 'easeInOutQuad' },
              ],
            },
            {
              id: 'track_beacon_scale_y',
              name: 'Docking Beacon Pulse Y',
              targetNodeId: 'node_beacon',
              propertyPath: 'transform.scaleY',
              keyframes: [
                { frame: 1, value: 0.8, easing: 'easeInOutQuad' },
                { frame: 30, value: 1.4, easing: 'easeInOutQuad' },
                { frame: 60, value: 0.8, easing: 'easeInOutQuad' },
                { frame: 90, value: 1.4, easing: 'easeInOutQuad' },
                { frame: 120, value: 0.8, easing: 'easeInOutQuad' },
              ],
            },
          ],
          markers: [
            { frame: 1, label: 'Approach', audioTrigger: 'drone' },
            { frame: 45, label: 'Alignment', audioTrigger: 'blip' },
            { frame: 75, label: 'Docking Lock', audioTrigger: 'click' },
            { frame: 100, label: 'Disengage', audioTrigger: 'laser' },
          ],
        },
        root: {
          id: 'root',
          name: 'SceneRoot',
          type: 'group',
          transform: { x: 0, y: 0, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
          children: [
            // Background Nebula Glow
            {
              id: 'node_nebula',
              name: 'Nebula Glow',
              type: 'shape',
              geometry: 'ellipse',
              width: 500,
              height: 350,
              transform: { x: 40, y: -20, scaleX: 1, scaleY: 1, rotation: -0.2, anchorX: 0.5, anchorY: 0.5 },
              opacity: 0.35,
              blendMode: 'screen',
              fill: {
                type: 'linear_gradient',
                color: '#4f46e5',
                gradientColors: ['#6366f1', '#a855f7', '#06b6d4'],
                gradientStops: [0, 0.5, 1],
              },
            },
            // Space Station Core
            {
              id: 'node_station_core',
              name: 'Station Core & Panels',
              type: 'group',
              transform: { x: 0, y: -30, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
              children: [
                // Solar Array Left
                {
                  id: 'node_panel_left',
                  name: 'Solar Array Left',
                  type: 'shape',
                  geometry: 'rounded_rectangle',
                  width: 90,
                  height: 28,
                  cornerRadius: 4,
                  transform: { x: -95, y: 0, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
                  fill: { type: 'solid', color: '#1e3a8a' },
                  stroke: { enabled: true, color: '#38bdf8', width: 2 },
                },
                // Solar Array Right
                {
                  id: 'node_panel_right',
                  name: 'Solar Array Right',
                  type: 'shape',
                  geometry: 'rounded_rectangle',
                  width: 90,
                  height: 28,
                  cornerRadius: 4,
                  transform: { x: 95, y: 0, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
                  fill: { type: 'solid', color: '#1e3a8a' },
                  stroke: { enabled: true, color: '#38bdf8', width: 2 },
                },
                // Central Ring
                {
                  id: 'node_ring',
                  name: 'Habitation Ring',
                  type: 'shape',
                  geometry: 'circle',
                  width: 76,
                  height: 76,
                  transform: { x: 0, y: 0, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
                  fill: { type: 'solid', color: '#0f172a' },
                  stroke: { enabled: true, color: '#94a3b8', width: 3 },
                },
                // Docking Hub
                {
                  id: 'node_hub',
                  name: 'Docking Hub',
                  type: 'shape',
                  geometry: 'circle',
                  width: 34,
                  height: 34,
                  transform: { x: 0, y: 0, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
                  fill: { type: 'solid', color: '#38bdf8' },
                  stroke: { enabled: true, color: '#f8fafc', width: 2 },
                },
              ],
            },
            // Docking Beacon
            {
              id: 'node_beacon',
              name: 'Docking Beacon Light',
              type: 'shape',
              geometry: 'circle',
              width: 14,
              height: 14,
              transform: { x: 0, y: -30, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
              fill: { type: 'solid', color: '#f43f5e' },
              stroke: { enabled: true, color: '#fda4af', width: 3 },
            },
            // Vector Transport Shuttle
            {
              id: 'node_shuttle',
              name: 'Vanguard Shuttle',
              type: 'group',
              transform: { x: -280, y: 140, scaleX: 1, scaleY: 1, rotation: -0.2, anchorX: 0.5, anchorY: 0.5 },
              children: [
                // Hull Path (Sleek aerodynamic delta spacecraft)
                {
                  id: 'node_shuttle_hull',
                  name: 'Shuttle Hull',
                  type: 'path',
                  svgPath: 'M 25 0 L -18 -16 L -10 0 L -18 16 Z',
                  transform: { x: 0, y: 0, scaleX: 1.4, scaleY: 1.4, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
                  fill: { type: 'solid', color: '#e2e8f0' },
                  stroke: { enabled: true, color: '#0284c7', width: 2 },
                },
                // Cockpit Glow
                {
                  id: 'node_shuttle_cockpit',
                  name: 'Cockpit Canopy',
                  type: 'shape',
                  geometry: 'circle',
                  width: 10,
                  height: 10,
                  transform: { x: 10, y: 0, scaleX: 1.4, scaleY: 0.7, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
                  fill: { type: 'solid', color: '#06b6d4' },
                },
                // Thruster Plume Particles
                {
                  id: 'node_shuttle_plume',
                  name: 'Ion Thruster Plume',
                  type: 'particle_emitter',
                  transform: { x: -22, y: 0, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
                  emissionRate: 50,
                  startColor: '#38bdf8',
                  endColor: '#4f46e5',
                },
              ],
            },
            // Vector HUD Readout
            {
              id: 'node_hud_title',
              name: 'HUD Title',
              type: 'text',
              text: 'ORBITAL DOCKING PROTOCOL // SECTOR 09',
              fontSize: 13,
              fontFamily: 'monospace',
              color: '#38bdf8',
              transform: { x: 0, y: 240, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
            },
          ],
        },
      },
    ],
  },

  cyber_vanguard: {
    manifest: {
      formatVersion: '1.0.0',
      name: 'Cyber-Vanguard (2D Physics)',
      description: 'Interactive rigid body physics playground with collision restitution, impulse controls & sound triggers',
      author: 'Aardvark Games',
      createdAt: '2026-03-01T00:00:00Z',
      targetFps: 60,
      canvas: {
        width: 800,
        height: 600,
        backgroundColor: '#0a0d18',
        scaleMode: 'fit',
      },
      initialSceneId: 'scene_physics',
    },
    scenes: [
      {
        id: 'scene_physics',
        name: 'Physics Arena',
        backgroundColor: '#0a0d18',
        timeline: {
          fps: 60,
          durationFrames: 60,
          loop: true,
          pingPong: false,
          tracks: [],
        },
        root: {
          id: 'root',
          name: 'SceneRoot',
          type: 'group',
          transform: { x: 0, y: 0, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
          children: [
            // Static Arena Platform
            {
              id: 'node_platform',
              name: 'Arena Ground Barrier',
              type: 'shape',
              geometry: 'rounded_rectangle',
              width: 500,
              height: 24,
              cornerRadius: 6,
              transform: { x: 0, y: 220, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
              fill: { type: 'solid', color: '#1e293b' },
              stroke: { enabled: true, color: '#64748b', width: 2 },
              physics: {
                type: 'static',
                shape: 'box',
                width: 500,
                height: 24,
                restitution: 0.85,
              },
            },
            // Dynamic Physics Bouncing Orbs
            {
              id: 'node_ball_1',
              name: 'Cyan Photon Orb',
              type: 'shape',
              geometry: 'circle',
              width: 44,
              height: 44,
              transform: { x: -80, y: -150, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
              fill: { type: 'solid', color: '#06b6d4' },
              stroke: { enabled: true, color: '#67e8f9', width: 3 },
              physics: {
                type: 'dynamic',
                shape: 'circle',
                radius: 22,
                restitution: 0.88,
              },
            },
            {
              id: 'node_ball_2',
              name: 'Magenta Plasma Orb',
              type: 'shape',
              geometry: 'circle',
              width: 38,
              height: 38,
              transform: { x: 40, y: -210, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
              fill: { type: 'solid', color: '#ec4899' },
              stroke: { enabled: true, color: '#f472b6', width: 3 },
              physics: {
                type: 'dynamic',
                shape: 'circle',
                radius: 19,
                restitution: 0.92,
              },
            },
            {
              id: 'node_ball_3',
              name: 'Amber Solar Orb',
              type: 'shape',
              geometry: 'circle',
              width: 52,
              height: 52,
              transform: { x: 120, y: -120, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
              fill: { type: 'solid', color: '#f59e0b' },
              stroke: { enabled: true, color: '#fbbf24', width: 3 },
              physics: {
                type: 'dynamic',
                shape: 'circle',
                radius: 26,
                restitution: 0.82,
              },
            },
            // Interactive Vessel Body
            {
              id: 'node_vessel',
              name: 'Kinetic Hover Vessel',
              type: 'shape',
              geometry: 'star',
              width: 56,
              height: 56,
              transform: { x: 0, y: -40, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
              fill: { type: 'solid', color: '#8b5cf6' },
              stroke: { enabled: true, color: '#c4b5fd', width: 3 },
              physics: {
                type: 'dynamic',
                shape: 'circle',
                radius: 28,
                restitution: 0.9,
              },
              scriptUpdate: `
                // Smoothly rotate the star
                self.transform.rotation += dt * 1.5;
              `,
            },
            // Instruction HUD
            {
              id: 'node_inst_text',
              name: 'Instruction Text',
              type: 'text',
              text: 'CLICK ORB TO LAUNCH IMPULSE // REAL 2D PHYSICS ENGINE',
              fontSize: 13,
              fontFamily: 'monospace',
              color: '#94a3b8',
              transform: { x: 0, y: -260, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
            },
          ],
        },
      },
    ],
  },

  hyper_prism: {
    manifest: {
      formatVersion: '1.0.0',
      name: 'Hyper-Prism 3D',
      description: 'Hybrid 2D/3D visual execution with Lambertian shading, back-face culling & camera projection',
      author: 'Aardvark Graphics Core',
      createdAt: '2026-03-01T00:00:00Z',
      targetFps: 60,
      canvas: {
        width: 800,
        height: 600,
        backgroundColor: '#080914',
        scaleMode: 'fit',
      },
      initialSceneId: 'scene_3d',
    },
    scenes: [
      {
        id: 'scene_3d',
        name: '3D Polyhedron Orbit',
        backgroundColor: '#080914',
        timeline: {
          fps: 60,
          durationFrames: 120,
          loop: true,
          pingPong: false,
          tracks: [],
        },
        root: {
          id: 'root',
          name: 'SceneRoot',
          type: 'group',
          transform: { x: 0, y: 0, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
          children: [
            // Center Shaded 3D Octahedron
            {
              id: 'node_3d_octa',
              name: 'Primary Shaded Octahedron',
              type: 'object3d',
              preset3D: 'octahedron',
              wireframe: false,
              baseColor: '#6366f1',
              transform: { x: 0, y: 0, scaleX: 1.4, scaleY: 1.4, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
              scriptUpdate: `
                self.rotY += dt * 1.2;
                self.rotX += dt * 0.7;
              `,
            },
            // Left Orbiting 3D Wireframe Cube
            {
              id: 'node_3d_cube_left',
              name: 'Orbiting Wireframe Cube',
              type: 'object3d',
              preset3D: 'cube',
              wireframe: true,
              baseColor: '#06b6d4',
              transform: { x: -190, y: -20, scaleX: 0.9, scaleY: 0.9, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
              scriptUpdate: `
                self.rotY += dt * 0.9;
                self.rotZ += dt * 1.1;
                self.transform.y = -20 + Math.sin(Date.now() * 0.002) * 30;
              `,
            },
            // Right Orbiting 3D Pyramid
            {
              id: 'node_3d_pyr_right',
              name: 'Orbiting Shaded Pyramid',
              type: 'object3d',
              preset3D: 'pyramid',
              wireframe: false,
              baseColor: '#ec4899',
              transform: { x: 190, y: 20, scaleX: 0.9, scaleY: 0.9, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
              scriptUpdate: `
                self.rotY -= dt * 1.4;
                self.rotX -= dt * 0.8;
                self.transform.y = 20 - Math.sin(Date.now() * 0.002) * 30;
              `,
            },
            // 2D Vector Reticle Ring Overlay
            {
              id: 'node_reticle',
              name: 'Targeting Reticle',
              type: 'shape',
              geometry: 'circle',
              width: 280,
              height: 280,
              transform: { x: 0, y: 0, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
              fill: { type: 'none', color: '#000000' },
              stroke: { enabled: true, color: '#312e81', width: 1.5, dash: [8, 6] },
              scriptUpdate: `
                self.transform.rotation -= dt * 0.3;
              `,
            },
            // Readout Header
            {
              id: 'node_header_3d',
              name: 'HUD Telemetry',
              type: 'text',
              text: '3D VECTOR HYBRID RUNTIME // PAINTERS ALGORITHM & DEPTH SHADING',
              fontSize: 12,
              fontFamily: 'monospace',
              color: '#818cf8',
              transform: { x: 0, y: -240, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
            },
          ],
        },
      },
    ],
  },

  ui_studio: {
    manifest: {
      formatVersion: '1.0.0',
      name: 'Aardvark UI Studio',
      description: 'Native UI components, interactive states, layout nesting, and bidirectional reactive data binding',
      author: 'Aardvark UI Framework',
      createdAt: '2026-03-01T00:00:00Z',
      targetFps: 60,
      canvas: {
        width: 800,
        height: 600,
        backgroundColor: '#0f172a',
        scaleMode: 'fit',
      },
      initialSceneId: 'scene_ui',
    },
    scenes: [
      {
        id: 'scene_ui',
        name: 'UI Components Deck',
        backgroundColor: '#0f172a',
        timeline: {
          fps: 60,
          durationFrames: 60,
          loop: true,
          pingPong: false,
          tracks: [],
        },
        root: {
          id: 'root',
          name: 'SceneRoot',
          type: 'group',
          transform: { x: 0, y: 0, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
          children: [
            // Container Panel
            {
              id: 'node_panel',
              name: 'Window Container',
              type: 'shape',
              geometry: 'rounded_rectangle',
              width: 520,
              height: 380,
              cornerRadius: 16,
              transform: { x: 0, y: 0, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
              fill: { type: 'solid', color: '#1e293b' },
              stroke: { enabled: true, color: '#334155', width: 2 },
            },
            // Title Bar
            {
              id: 'node_ui_title',
              name: 'Window Header',
              type: 'text',
              text: 'Aardvark UI Component Engine',
              fontSize: 18,
              fontFamily: 'system-ui, sans-serif',
              color: '#f8fafc',
              transform: { x: 0, y: -150, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
            },
            // Primary Action Button
            {
              id: 'btn_primary',
              name: 'Launch Audio Trigger Button',
              type: 'ui_element',
              widgetType: 'button',
              width: 200,
              height: 44,
              label: 'Trigger Sound Effect',
              transform: { x: -110, y: -80, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
            },
            // Secondary Action Button
            {
              id: 'btn_secondary',
              name: 'Spark Particles Button',
              type: 'ui_element',
              widgetType: 'button',
              width: 200,
              height: 44,
              label: 'Spark Particles',
              transform: { x: 110, y: -80, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
            },
            // Interactive Slider
            {
              id: 'slider_intensity',
              name: 'Intensity Slider',
              type: 'ui_element',
              widgetType: 'slider',
              width: 320,
              height: 30,
              label: 'Scale Slider',
              transform: { x: 0, y: -10, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
            },
            // Toggle Switch
            {
              id: 'toggle_switch',
              name: 'Power Toggle Switch',
              type: 'ui_element',
              widgetType: 'toggle',
              width: 140,
              height: 30,
              label: 'Reactor Core',
              transform: { x: 0, y: 60, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
            },
            // Dynamic Preview Indicator
            {
              id: 'node_reactor_badge',
              name: 'Reactor Visual Indicator',
              type: 'shape',
              geometry: 'circle',
              width: 50,
              height: 50,
              transform: { x: 0, y: 130, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
              fill: { type: 'solid', color: '#10b981' },
              stroke: { enabled: true, color: '#6ee7b7', width: 3 },
              scriptUpdate: `
                // Pulsing animation based on time
                const pulse = 1 + Math.sin(Date.now() * 0.005) * 0.15;
                self.transform.scaleX = pulse;
                self.transform.scaleY = pulse;
              `,
            },
          ],
        },
      },
    ],
  },

  supernova: {
    manifest: {
      formatVersion: '1.0.0',
      name: 'Supernova Generator',
      description: 'High-density particle synthesizer with dual gravitational attractors and audio arpeggiator',
      author: 'Aardvark FX Core',
      createdAt: '2026-03-01T00:00:00Z',
      targetFps: 60,
      canvas: {
        width: 800,
        height: 600,
        backgroundColor: '#04060c',
        scaleMode: 'fit',
      },
      initialSceneId: 'scene_nova',
    },
    scenes: [
      {
        id: 'scene_nova',
        name: 'Supernova Core',
        backgroundColor: '#04060c',
        timeline: {
          fps: 60,
          durationFrames: 60,
          loop: true,
          pingPong: false,
          tracks: [],
        },
        root: {
          id: 'root',
          name: 'SceneRoot',
          type: 'group',
          transform: { x: 0, y: 0, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
          children: [
            // Central Golden Stellar Core
            {
              id: 'emitter_core',
              name: 'Stellar Fusion Emitter',
              type: 'particle_emitter',
              transform: { x: 0, y: 0, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
              emissionRate: 90,
              startColor: '#facc15',
              endColor: '#ef4444',
            },
            // Outer Violet Halo Emitter
            {
              id: 'emitter_halo',
              name: 'Cosmic Ray Emitter',
              type: 'particle_emitter',
              transform: { x: 0, y: 0, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
              emissionRate: 60,
              startColor: '#38bdf8',
              endColor: '#a855f7',
            },
            // Rotating Ring
            {
              id: 'node_nova_ring',
              name: 'Relativistic Ring',
              type: 'shape',
              geometry: 'circle',
              width: 160,
              height: 160,
              transform: { x: 0, y: 0, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
              fill: { type: 'none', color: '#000000' },
              stroke: { enabled: true, color: '#fef08a', width: 2, dash: [12, 8] },
              scriptUpdate: `
                self.transform.rotation += dt * 2.0;
              `,
            },
            // Center Core Flare
            {
              id: 'node_nova_flare',
              name: 'Singularity Center',
              type: 'shape',
              geometry: 'star',
              width: 38,
              height: 38,
              transform: { x: 0, y: 0, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
              fill: { type: 'solid', color: '#ffffff' },
              stroke: { enabled: true, color: '#fef08a', width: 2 },
              scriptUpdate: `
                self.transform.rotation -= dt * 3.0;
              `,
            },
            // Readout
            {
              id: 'node_nova_title',
              name: 'Telemetry Info',
              type: 'text',
              text: 'HIGH-FREQUENCY PARTICLE SYNTHESIZER // CLICK TO TRIGGER BURST',
              fontSize: 12,
              fontFamily: 'monospace',
              color: '#facc15',
              transform: { x: 0, y: 240, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 },
            },
          ],
        },
      },
    ],
  },
};
