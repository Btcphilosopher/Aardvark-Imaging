// ============================================================================
// AARDVARK RUNTIME - PROJECT SERIALIZER
// Serializes runtime scene graphs & timelines to deterministic .aard format
// ============================================================================

import { AardvarkProjectFile, SerializedNode, SerializedScene } from './project-types';
import { Scene } from '../scene/scene';
import { SceneNode } from '../scene/node';
import { ShapeNode, PathNode, TextNode, SpriteNode } from '../scene/shapes';
import { Object3DNode } from '../scene/object3d';
import { ParticleEmitterNode } from '../scene/particles';
import { UIElementNode } from '../scene/ui-node';

export class ProjectSerializer {
  static serialize(scene: Scene, projectName: string = 'Aardvark Project'): AardvarkProjectFile {
    const serializedScene: SerializedScene = {
      id: scene.id,
      name: scene.name,
      backgroundColor: scene.backgroundColor,
      timeline: {
        fps: scene.timeline.fps,
        durationFrames: scene.timeline.durationFrames,
        loop: scene.timeline.loop,
        pingPong: scene.timeline.pingPong,
        tracks: scene.timeline.tracks.map((t) => ({
          id: t.id,
          name: t.name,
          targetNodeId: t.targetNodeId,
          propertyPath: t.propertyPath,
          keyframes: t.keyframes.map((k) => ({
            frame: k.frame,
            value: k.value,
            easing: k.easing,
            isHold: k.isHold,
            isBlank: k.isBlank,
          })),
        })),
        markers: Array.from(scene.timeline.markers.values()).map((m) => ({
          frame: m.frame,
          label: m.label,
          actionScript: m.actionScript,
          audioTrigger: m.audioTrigger,
        })),
      },
      root: this.serializeNode(scene.root),
    };

    return {
      manifest: {
        formatVersion: '1.0.0',
        name: projectName,
        createdAt: new Date().toISOString(),
        targetFps: scene.timeline.fps,
        canvas: {
          width: 800,
          height: 600,
          backgroundColor: scene.backgroundColor,
          scaleMode: 'fit',
        },
        initialSceneId: scene.id,
      },
      scenes: [serializedScene],
    };
  }

  private static serializeNode(node: SceneNode): SerializedNode {
    const res: SerializedNode = {
      id: node.id,
      name: node.name,
      type: node.type,
      tags: node.tags.length > 0 ? [...node.tags] : undefined,
      transform: {
        x: Math.round(node.transform.x * 100) / 100,
        y: Math.round(node.transform.y * 100) / 100,
        scaleX: Math.round(node.transform.scaleX * 100) / 100,
        scaleY: Math.round(node.transform.scaleY * 100) / 100,
        rotation: Math.round(node.transform.rotation * 1000) / 1000,
        anchorX: node.transform.anchorX,
        anchorY: node.transform.anchorY,
      },
      visible: node.visible,
      opacity: Math.round(node.opacity * 100) / 100,
      blendMode: node.blendMode !== 'source-over' ? node.blendMode : undefined,
      zIndex: node.zIndex !== 0 ? node.zIndex : undefined,
    };

    if (node instanceof ShapeNode) {
      res.geometry = node.geometry;
      res.width = node.width;
      res.height = node.height;
      res.cornerRadius = node.cornerRadius;
      res.fill = node.fill;
      res.stroke = node.stroke;
    } else if (node instanceof PathNode) {
      res.fill = node.fill;
      res.stroke = node.stroke;
    } else if (node instanceof TextNode) {
      res.text = node.text;
      res.fontSize = node.fontSize;
      res.fontFamily = node.fontFamily;
      res.color = node.color;
    } else if (node instanceof SpriteNode) {
      res.width = node.width;
      res.height = node.height;
    } else if (node instanceof Object3DNode) {
      res.wireframe = node.wireframe;
      res.baseColor = node.baseColor;
    } else if (node instanceof ParticleEmitterNode) {
      res.emissionRate = node.emissionRate;
      res.startColor = node.startColor;
      res.endColor = node.endColor;
    } else if (node instanceof UIElementNode) {
      res.widgetType = node.widgetType;
      res.width = node.width;
      res.height = node.height;
      res.label = node.label;
    }

    if (node.children.length > 0) {
      res.children = node.children.map((c) => this.serializeNode(c));
    }

    return res;
  }
}
