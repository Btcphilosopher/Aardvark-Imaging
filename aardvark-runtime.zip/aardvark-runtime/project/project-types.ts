// ============================================================================
// AARDVARK RUNTIME - PROJECT FILE FORMAT SPECIFICATION (.aard / .aardpkg)
// Deterministic open project representation for rich interactive media
// ============================================================================

export interface AardvarkProjectManifest {
  formatVersion: string; // e.g. '1.0.0'
  name: string;
  description?: string;
  author?: string;
  createdAt: string;
  targetFps: number;
  canvas: {
    width: number;
    height: number;
    backgroundColor: string;
    scaleMode: 'fit' | 'fill' | 'stretch';
  };
  initialSceneId: string;
}

export interface SerializedNode {
  id: string;
  name: string;
  type: string;
  tags?: string[];
  transform: {
    x: number;
    y: number;
    scaleX: number;
    scaleY: number;
    rotation: number;
    anchorX: number;
    anchorY: number;
    skewX?: number;
    skewY?: number;
  };
  visible?: boolean;
  opacity?: number;
  blendMode?: string;
  zIndex?: number;
  // Node type specific fields
  geometry?: string;
  width?: number;
  height?: number;
  cornerRadius?: number;
  fill?: any;
  stroke?: any;
  svgPath?: string;
  text?: string;
  fontSize?: number;
  fontFamily?: string;
  color?: string;
  preset3D?: string;
  wireframe?: boolean;
  baseColor?: string;
  emissionRate?: number;
  startColor?: string;
  endColor?: string;
  widgetType?: string;
  label?: string;
  scriptUpdate?: string;
  physics?: {
    type: 'dynamic' | 'static';
    shape: 'circle' | 'box';
    radius?: number;
    width?: number;
    height?: number;
    restitution?: number;
  };
  children?: SerializedNode[];
}

export interface SerializedKeyframe {
  frame: number;
  value: any;
  easing?: string;
  isHold?: boolean;
  isBlank?: boolean;
}

export interface SerializedTrack {
  id: string;
  name: string;
  targetNodeId: string;
  propertyPath: string;
  keyframes: SerializedKeyframe[];
}

export interface SerializedMarker {
  frame: number;
  label: string;
  actionScript?: string;
  audioTrigger?: string;
}

export interface SerializedScene {
  id: string;
  name: string;
  backgroundColor?: string;
  timeline: {
    fps: number;
    durationFrames: number;
    loop: boolean;
    pingPong: boolean;
    tracks: SerializedTrack[];
    markers?: SerializedMarker[];
  };
  root: SerializedNode;
}

export interface AardvarkProjectFile {
  manifest: AardvarkProjectManifest;
  scenes: SerializedScene[];
  symbols?: Record<string, any>;
  assets?: Record<string, any>;
}
