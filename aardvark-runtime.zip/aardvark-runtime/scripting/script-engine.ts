// ============================================================================
// AARDVARK RUNTIME - SCRIPTING ENGINE
// Sandboxed JavaScript/TypeScript execution runtime for behaviors and REPL console
// ============================================================================

import { Scene } from '../scene/scene';
import { SceneNode } from '../scene/node';
import { Timeline } from '../timeline/timeline';
import { AudioEngine } from '../audio/audio-engine';
import { PhysicsWorld } from '../physics/physics-world';
import { RuntimeEventBus } from '../core/event-bus';
import { createAardvarkScriptApi, ScriptExecutionContext } from './runtime-api';

export interface ScriptLogEntry {
  type: 'log' | 'info' | 'warn' | 'error';
  message: string;
  timestamp: number;
}

export interface NodeScriptBehavior {
  nodeId: string;
  initSource?: string;
  updateSource?: string;
  compiledUpdate?: (dt: number, aardvark: any) => void;
}

export class ScriptEngine {
  private behaviors: Map<string, NodeScriptBehavior> = new Map();
  private logs: ScriptLogEntry[] = [];
  private state: Record<string, any> = {};
  public maxLogs: number = 100;

  constructor(
    private eventBus: RuntimeEventBus,
    private audioEngine: AudioEngine,
    private physicsWorld: PhysicsWorld
  ) {}

  addBehavior(behavior: NodeScriptBehavior): void {
    if (behavior.updateSource) {
      try {
        // Compile update function
        const fn = new Function('dt', 'aardvark', behavior.updateSource);
        behavior.compiledUpdate = fn as any;
      } catch (err: any) {
        this.addLog('error', `Failed to compile script for ${behavior.nodeId}: ${err.message}`);
      }
    }
    this.behaviors.set(behavior.nodeId, behavior);
  }

  removeBehavior(nodeId: string): void {
    this.behaviors.delete(nodeId);
  }

  clear(): void {
    this.behaviors.clear();
    this.state = {};
  }

  executeREPL(code: string, scene: Scene, timeline: Timeline): any {
    const ctx: ScriptExecutionContext = {
      scene,
      timeline,
      audio: this.audioEngine,
      physics: this.physicsWorld,
      eventBus: this.eventBus,
      state: this.state,
      log: (msg: any) => this.addLog('info', typeof msg === 'object' ? JSON.stringify(msg) : String(msg)),
    };

    const aardvark = createAardvarkScriptApi(ctx);

    try {
      // Evaluate expression or statement block
      const executor = new Function('aardvark', `
        with(aardvark) {
          return (${code});
        }
      `);
      const result = executor(aardvark);
      if (result !== undefined) {
        this.addLog('log', `=> ${typeof result === 'object' ? JSON.stringify(result) : result}`);
      }
      return result;
    } catch (evalErr: any) {
      // Try as multiple statements
      try {
        const statementExecutor = new Function('aardvark', `
          with(aardvark) {
            ${code}
          }
        `);
        statementExecutor(aardvark);
        this.addLog('log', '=> Executed successfully');
      } catch (stmtErr: any) {
        this.addLog('error', `Error: ${stmtErr.message}`);
        throw stmtErr;
      }
    }
  }

  update(dt: number, scene: Scene, timeline: Timeline): void {
    if (this.behaviors.size === 0) return;

    for (const [nodeId, behavior] of this.behaviors.entries()) {
      if (!behavior.compiledUpdate) continue;
      const node = scene.findNodeById(nodeId);
      if (!node || !node.visible) continue;

      const ctx: ScriptExecutionContext = {
        node,
        scene,
        timeline,
        audio: this.audioEngine,
        physics: this.physicsWorld,
        eventBus: this.eventBus,
        state: this.state,
        log: (msg: any) => this.addLog('info', String(msg)),
      };

      const api = createAardvarkScriptApi(ctx);

      try {
        behavior.compiledUpdate(dt, api);
      } catch (err: any) {
        this.addLog('error', `Script runtime error on ${nodeId}: ${err.message}`);
      }
    }
  }

  addLog(type: 'log' | 'info' | 'warn' | 'error', message: string): void {
    this.logs.push({ type, message, timestamp: performance.now() });
    if (this.logs.length > this.maxLogs) {
      this.logs.shift();
    }
    this.eventBus.emit('script:log', { type, message });
  }

  getLogs(): ScriptLogEntry[] {
    return [...this.logs];
  }

  clearLogs(): void {
    this.logs = [];
  }
}
