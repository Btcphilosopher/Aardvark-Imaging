// ============================================================================
// AARDVARK RUNTIME - SCRIPTING VIRTUAL API
// The unified scripting interface for interactive behavior and document logic
// ============================================================================

import { Scene } from '../scene/scene';
import { SceneNode } from '../scene/node';
import { Timeline } from '../timeline/timeline';
import { AudioEngine, SfxPreset } from '../audio/audio-engine';
import { PhysicsWorld } from '../physics/physics-world';
import { RuntimeEventBus } from '../core/event-bus';
import { Vec2, Vec3, lerp, clamp, degToRad } from '../core/math';

export interface ScriptExecutionContext {
  node?: SceneNode;
  scene: Scene;
  timeline: Timeline;
  audio: AudioEngine;
  physics: PhysicsWorld;
  eventBus: RuntimeEventBus;
  state: Record<string, any>;
  log: (msg: any) => void;
}

export function createAardvarkScriptApi(ctx: ScriptExecutionContext) {
  return {
    self: ctx.node,
    scene: {
      find: (id: string) => ctx.scene.findNodeById(id),
      findByTag: (tag: string) => ctx.scene.findNodesByTag(tag),
      root: ctx.scene.root,
      backgroundColor: ctx.scene.backgroundColor,
      setBackgroundColor: (col: string) => {
        ctx.scene.backgroundColor = col;
      },
    },
    timeline: {
      play: () => ctx.timeline.play(),
      pause: () => ctx.timeline.pause(),
      stop: () => ctx.timeline.stop(),
      gotoAndPlay: (target: number | string) => ctx.timeline.gotoAndPlay(target),
      gotoAndStop: (target: number | string) => ctx.timeline.gotoAndStop(target),
      currentFrame: ctx.timeline.currentFrame,
      totalFrames: ctx.timeline.durationFrames,
      setSpeed: (s: number) => {
        ctx.timeline.playbackSpeed = s;
      },
    },
    audio: {
      playSfx: (preset: SfxPreset) => ctx.audio.playSfx(preset),
      playTone: (freq: number, dur?: number) => ctx.audio.playTone(freq, dur),
      setVolume: (vol: number) => ctx.audio.setVolume(vol),
    },
    physics: {
      setGravity: (x: number, y: number) => ctx.physics.gravity.set(x, y),
      applyForceToNode: (nodeId: string, fx: number, fy: number) => {
        const body = ctx.physics.bodies.find((b) => b.node.id === nodeId);
        if (body) body.applyForce(fx, fy);
      },
      applyImpulseToNode: (nodeId: string, ix: number, iy: number) => {
        const body = ctx.physics.bodies.find((b) => b.node.id === nodeId);
        if (body) body.applyImpulse(ix, iy);
      },
    },
    state: {
      get: (key: string) => ctx.state[key],
      set: (key: string, val: any) => {
        ctx.state[key] = val;
        ctx.eventBus.emit('state:change', { key, value: val });
      },
      getAll: () => ({ ...ctx.state }),
    },
    math: {
      Vec2,
      Vec3,
      lerp,
      clamp,
      degToRad,
      randomRange: (min: number, max: number) => min + Math.random() * (max - min),
    },
    emit: (event: string, data?: any) => ctx.eventBus.emit(event, data),
    on: (event: string, handler: (data: any) => void) => ctx.eventBus.on(event, handler),
    log: ctx.log,
  };
}
