// ============================================================================
// AARDVARK RUNTIME - INPUT DISPATCHER & GESTURE MANAGER
// High-frequency pointer, keyboard, and gesture handling with capturing & bubbling
// ============================================================================

import { Scene } from '../scene/scene';
import { SceneNode } from '../scene/node';
import { UIElementNode } from '../scene/ui-node';
import { hitTestScene } from './hit-test';
import { Vec2 } from '../core/math';
import { RuntimeEventBus } from '../core/event-bus';

export interface PointerState {
  x: number;
  y: number;
  isDown: boolean;
  button: number;
  dragTarget: SceneNode | null;
  hoverTarget: SceneNode | null;
}

export class InputManager {
  private canvas: HTMLCanvasElement | null = null;
  private scene: Scene | null = null;
  private eventBus: RuntimeEventBus;

  public pointer: PointerState = {
    x: 0,
    y: 0,
    isDown: false,
    button: 0,
    dragTarget: null,
    hoverTarget: null,
  };

  private keysDown: Set<string> = new Set();

  constructor(eventBus: RuntimeEventBus) {
    this.eventBus = eventBus;
  }

  attach(canvas: HTMLCanvasElement, scene: Scene): void {
    this.canvas = canvas;
    this.scene = scene;

    canvas.addEventListener('pointerdown', this.onPointerDown);
    canvas.addEventListener('pointermove', this.onPointerMove);
    window.addEventListener('pointerup', this.onPointerUp);
    canvas.addEventListener('contextmenu', (e) => e.preventDefault());

    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
  }

  detach(): void {
    if (this.canvas) {
      this.canvas.removeEventListener('pointerdown', this.onPointerDown);
      this.canvas.removeEventListener('pointermove', this.onPointerMove);
    }
    window.removeEventListener('pointerup', this.onPointerUp);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
  }

  setScene(scene: Scene): void {
    this.scene = scene;
  }

  private getCanvasCoords(e: PointerEvent): Vec2 {
    if (!this.canvas) return new Vec2(e.clientX, e.clientY);
    const rect = this.canvas.getBoundingClientRect();
    return new Vec2(e.clientX - rect.left, e.clientY - rect.top);
  }

  private onPointerDown = (e: PointerEvent) => {
    if (!this.scene) return;
    const pos = this.getCanvasCoords(e);
    this.pointer.x = pos.x;
    this.pointer.y = pos.y;
    this.pointer.isDown = true;
    this.pointer.button = e.button;

    const hit = hitTestScene(this.scene, pos.x, pos.y);
    this.pointer.dragTarget = hit;

    if (hit) {
      if (hit instanceof UIElementNode) {
        hit.onPointerDown();
      }
      this.eventBus.emit('node:pointerdown', { node: hit, x: pos.x, y: pos.y, button: e.button });
    }
    this.eventBus.emit('input:pointerdown', { x: pos.x, y: pos.y, target: hit });
  };

  private onPointerMove = (e: PointerEvent) => {
    if (!this.scene) return;
    const pos = this.getCanvasCoords(e);
    this.pointer.x = pos.x;
    this.pointer.y = pos.y;

    const hit = hitTestScene(this.scene, pos.x, pos.y);

    // Hover state transitions
    if (hit !== this.pointer.hoverTarget) {
      if (this.pointer.hoverTarget instanceof UIElementNode) {
        this.pointer.hoverTarget.onPointerLeave();
      }
      if (hit instanceof UIElementNode) {
        hit.onPointerEnter();
      }
      this.pointer.hoverTarget = hit;
    }

    // Dragging UI components like sliders
    if (this.pointer.isDown && this.pointer.dragTarget instanceof UIElementNode) {
      const local = this.pointer.dragTarget.globalToLocal(pos);
      this.pointer.dragTarget.handleDrag(local.x);
    }

    this.eventBus.emit('input:pointermove', { x: pos.x, y: pos.y, target: hit });
  };

  private onPointerUp = (e: PointerEvent) => {
    this.pointer.isDown = false;
    const hit = this.pointer.dragTarget;
    if (hit instanceof UIElementNode) {
      hit.onPointerUp();
    }
    this.eventBus.emit('input:pointerup', { x: this.pointer.x, y: this.pointer.y, target: hit });
    this.pointer.dragTarget = null;
  };

  private onKeyDown = (e: KeyboardEvent) => {
    this.keysDown.add(e.key.toLowerCase());
    this.eventBus.emit('input:keydown', { key: e.key, code: e.code });
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keysDown.delete(e.key.toLowerCase());
    this.eventBus.emit('input:keyup', { key: e.key, code: e.code });
  };

  isKeyDown(key: string): boolean {
    return this.keysDown.has(key.toLowerCase());
  }
}
