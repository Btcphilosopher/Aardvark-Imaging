// ============================================================================
// AARDVARK RUNTIME - SCENE HIT-TESTING
// Inverse world-matrix transformed geometric hit-testing
// ============================================================================

import { SceneNode } from '../scene/node';
import { Scene } from '../scene/scene';
import { Vec2 } from '../core/math';

export function hitTestScene(scene: Scene, screenX: number, screenY: number): SceneNode | null {
  // Convert screen coordinates to world coordinates accounting for camera
  let worldX = screenX;
  let worldY = screenY;

  const camera = scene.activeCamera;
  if (camera) {
    // Inverse camera pan & zoom
    worldX = (screenX - 400) / camera.zoom + camera.transform.x;
    worldY = (screenY - 300) / camera.zoom + camera.transform.y;
  }

  return hitTestNode(scene.root, worldX, worldY);
}

export function hitTestNode(node: SceneNode, worldX: number, worldY: number): SceneNode | null {
  if (!node.visible || !node.interactive || node.worldOpacity <= 0.001) {
    return null;
  }

  // Children tested top-to-bottom (highest zIndex first)
  const sorted = [...node.children].sort((a, b) => b.zIndex - a.zIndex);
  for (const child of sorted) {
    const hit = hitTestNode(child, worldX, worldY);
    if (hit) return hit;
  }

  // Test self
  if (node.hitTest(worldX, worldY)) {
    return node;
  }

  return null;
}
