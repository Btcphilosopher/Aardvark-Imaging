'use client';

// ============================================================================
// AARDVARK RUNTIME - SCENE GRAPH INSPECTOR
// Live node hierarchy navigator & real-time transformation property editor
// ============================================================================

import React from 'react';
import {
  Folder,
  Square,
  Type,
  Box,
  Sparkles,
  MousePointer,
  Camera,
  Sun,
  Eye,
  EyeOff,
  Trash2,
  Plus,
  Compass,
} from 'lucide-react';
import { Scene } from '../aardvark-runtime/scene/scene';
import { SceneNode } from '../aardvark-runtime/scene/node';
import { ShapeNode, TextNode } from '../aardvark-runtime/scene/shapes';
import { Object3DNode } from '../aardvark-runtime/scene/object3d';
import { ParticleEmitterNode } from '../aardvark-runtime/scene/particles';
import { radToDeg, degToRad } from '../aardvark-runtime/core/math';

interface SceneInspectorProps {
  scene: Scene;
  selectedNode: SceneNode | null;
  onSelectNode: (node: SceneNode | null) => void;
  onUpdateNode: (updater: (node: SceneNode) => void) => void;
  onToggleVisibility: (node: SceneNode) => void;
  onDeleteNode: (node: SceneNode) => void;
  onAddShape: () => void;
}

export const SceneInspector: React.FC<SceneInspectorProps> = ({
  scene,
  selectedNode,
  onSelectNode,
  onUpdateNode,
  onToggleVisibility,
  onDeleteNode,
  onAddShape,
}) => {
  const getNodeIcon = (type: string) => {
    switch (type) {
      case 'shape':
        return <Square className="w-3.5 h-3.5 text-blue-400" />;
      case 'text':
        return <Type className="w-3.5 h-3.5 text-amber-400" />;
      case 'object3d':
        return <Box className="w-3.5 h-3.5 text-indigo-400" />;
      case 'particle_emitter':
        return <Sparkles className="w-3.5 h-3.5 text-pink-400" />;
      case 'ui_element':
        return <MousePointer className="w-3.5 h-3.5 text-emerald-400" />;
      case 'camera':
        return <Camera className="w-3.5 h-3.5 text-cyan-400" />;
      case 'light':
        return <Sun className="w-3.5 h-3.5 text-yellow-300" />;
      case 'group':
      default:
        return <Folder className="w-3.5 h-3.5 text-slate-400" />;
    }
  };

  const renderTreeNode = (node: SceneNode, depth: number = 0) => {
    const isSelected = selectedNode?.id === node.id;

    return (
      <div key={node.id} className="flex flex-col">
        <div
          onClick={() => onSelectNode(node)}
          className={`flex items-center justify-between px-2 py-1 cursor-pointer transition-colors text-xs ${
            isSelected
              ? 'bg-indigo-600/30 text-indigo-200 border-l-2 border-indigo-400 font-medium'
              : 'hover:bg-slate-800/70 text-slate-300'
          }`}
          style={{ paddingLeft: `${depth * 14 + 8}px` }}
        >
          <div className="flex items-center gap-1.5 truncate">
            {getNodeIcon(node.type)}
            <span className="truncate">{node.name || node.id}</span>
          </div>

          <div className="flex items-center gap-1 opacity-75 hover:opacity-100">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onToggleVisibility(node);
              }}
              title={node.visible ? 'Hide Node' : 'Show Node'}
              className="p-1 hover:text-white"
            >
              {node.visible ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3 text-slate-500" />}
            </button>
          </div>
        </div>

        {node.children.map((child) => renderTreeNode(child, depth + 1))}
      </div>
    );
  };

  return (
    <div id="aardvark_scene_inspector" className="flex flex-col h-full bg-slate-950 text-slate-300 select-none text-xs border-l border-slate-800">
      {/* Top Header */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-slate-800 bg-slate-900/60">
        <span className="font-semibold text-slate-200 flex items-center gap-1.5">
          <Compass className="w-3.5 h-3.5 text-indigo-400" />
          SCENE HIERARCHY
        </span>
        <button
          onClick={onAddShape}
          title="Add New Shape Node"
          className="flex items-center gap-1 px-2 py-0.5 rounded bg-indigo-600/80 hover:bg-indigo-500 text-white font-medium"
        >
          <Plus className="w-3 h-3" />
          <span>Add</span>
        </button>
      </div>

      {/* Tree View (Upper half) */}
      <div className="h-44 overflow-y-auto border-b border-slate-800 py-1 bg-slate-950/80">
        {renderTreeNode(scene.root)}
      </div>

      {/* Node Properties Inspector (Lower half) */}
      <div className="flex-1 overflow-y-auto p-3 flex flex-col gap-3">
        {selectedNode ? (
          <>
            {/* Header / ID */}
            <div className="flex items-center justify-between pb-2 border-b border-slate-800/80">
              <div className="truncate">
                <span className="font-bold text-slate-100 text-sm">{selectedNode.name}</span>
                <div className="text-[10px] text-slate-500 font-mono">ID: {selectedNode.id}</div>
              </div>

              {selectedNode !== scene.root && (
                <button
                  onClick={() => onDeleteNode(selectedNode)}
                  title="Delete Node"
                  className="p-1.5 text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 rounded transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Transform 2D Section */}
            <div className="flex flex-col gap-2">
              <span className="text-[10px] font-bold tracking-wider text-slate-400 font-mono">TRANSFORM</span>

              {/* Position X / Y */}
              <div className="grid grid-cols-2 gap-2">
                <div className="flex items-center gap-1.5 bg-slate-900 px-2 py-1 rounded border border-slate-800">
                  <span className="text-slate-500 font-mono text-[10px]">X</span>
                  <input
                    type="number"
                    value={Math.round(selectedNode.transform.x)}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value) || 0;
                      onUpdateNode((n) => {
                        n.transform.x = val;
                        n.markDirty();
                      });
                    }}
                    className="w-full bg-transparent text-slate-200 outline-none font-mono text-right"
                  />
                </div>
                <div className="flex items-center gap-1.5 bg-slate-900 px-2 py-1 rounded border border-slate-800">
                  <span className="text-slate-500 font-mono text-[10px]">Y</span>
                  <input
                    type="number"
                    value={Math.round(selectedNode.transform.y)}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value) || 0;
                      onUpdateNode((n) => {
                        n.transform.y = val;
                        n.markDirty();
                      });
                    }}
                    className="w-full bg-transparent text-slate-200 outline-none font-mono text-right"
                  />
                </div>
              </div>

              {/* Scale X / Y */}
              <div className="grid grid-cols-2 gap-2">
                <div className="flex items-center gap-1.5 bg-slate-900 px-2 py-1 rounded border border-slate-800">
                  <span className="text-slate-500 font-mono text-[10px]">SX</span>
                  <input
                    type="number"
                    step="0.1"
                    value={Math.round(selectedNode.transform.scaleX * 100) / 100}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value) || 1;
                      onUpdateNode((n) => {
                        n.transform.scaleX = val;
                        n.markDirty();
                      });
                    }}
                    className="w-full bg-transparent text-slate-200 outline-none font-mono text-right"
                  />
                </div>
                <div className="flex items-center gap-1.5 bg-slate-900 px-2 py-1 rounded border border-slate-800">
                  <span className="text-slate-500 font-mono text-[10px]">SY</span>
                  <input
                    type="number"
                    step="0.1"
                    value={Math.round(selectedNode.transform.scaleY * 100) / 100}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value) || 1;
                      onUpdateNode((n) => {
                        n.transform.scaleY = val;
                        n.markDirty();
                      });
                    }}
                    className="w-full bg-transparent text-slate-200 outline-none font-mono text-right"
                  />
                </div>
              </div>

              {/* Rotation */}
              <div className="flex items-center justify-between bg-slate-900 px-2 py-1 rounded border border-slate-800">
                <span className="text-slate-500 font-mono text-[10px]">ROTATION (deg)</span>
                <input
                  type="number"
                  value={Math.round(radToDeg(selectedNode.transform.rotation))}
                  onChange={(e) => {
                    const deg = parseFloat(e.target.value) || 0;
                    onUpdateNode((n) => {
                      n.transform.rotation = degToRad(deg);
                      n.markDirty();
                    });
                  }}
                  className="w-20 bg-transparent text-slate-200 outline-none font-mono text-right"
                />
              </div>
            </div>

            {/* Visual Styling Section */}
            <div className="flex flex-col gap-2 pt-2 border-t border-slate-800/80">
              <span className="text-[10px] font-bold tracking-wider text-slate-400 font-mono">APPEARANCE</span>

              {/* Opacity */}
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Opacity</span>
                <div className="flex items-center gap-2">
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={selectedNode.opacity}
                    onChange={(e) => {
                      const op = parseFloat(e.target.value);
                      onUpdateNode((n) => {
                        n.opacity = op;
                        n.markDirty();
                      });
                    }}
                    className="w-24 accent-indigo-500"
                  />
                  <span className="font-mono text-slate-300 w-8 text-right">
                    {Math.round(selectedNode.opacity * 100)}%
                  </span>
                </div>
              </div>

              {/* Blend Mode */}
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Blend Mode</span>
                <select
                  value={selectedNode.blendMode}
                  onChange={(e) => {
                    const bm = e.target.value as any;
                    onUpdateNode((n) => {
                      n.blendMode = bm;
                    });
                  }}
                  className="bg-slate-900 border border-slate-800 text-slate-200 px-2 py-1 rounded outline-none font-mono text-[11px]"
                >
                  <option value="source-over">normal</option>
                  <option value="lighter">additive</option>
                  <option value="multiply">multiply</option>
                  <option value="screen">screen</option>
                  <option value="overlay">overlay</option>
                  <option value="difference">difference</option>
                </select>
              </div>
            </div>

            {/* Node Type Specific Parameters */}
            {selectedNode instanceof ShapeNode && (
              <div className="flex flex-col gap-2 pt-2 border-t border-slate-800/80">
                <span className="text-[10px] font-bold tracking-wider text-blue-400 font-mono">SHAPE ATTRIBUTES</span>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Geometry</span>
                  <select
                    value={selectedNode.geometry}
                    onChange={(e) => {
                      const geom = e.target.value as any;
                      onUpdateNode((n) => {
                        if (n instanceof ShapeNode) n.geometry = geom;
                      });
                    }}
                    className="bg-slate-900 border border-slate-800 text-slate-200 px-2 py-1 rounded outline-none"
                  >
                    <option value="rectangle">Rectangle</option>
                    <option value="rounded_rectangle">Rounded Rect</option>
                    <option value="circle">Circle</option>
                    <option value="ellipse">Ellipse</option>
                    <option value="polygon">Polygon</option>
                    <option value="star">Star</option>
                  </select>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Fill Color</span>
                  <input
                    type="color"
                    value={selectedNode.fill.color || '#3b82f6'}
                    onChange={(e) => {
                      const col = e.target.value;
                      onUpdateNode((n) => {
                        if (n instanceof ShapeNode) n.fill.color = col;
                      });
                    }}
                    className="w-7 h-7 rounded border border-slate-700 bg-transparent cursor-pointer"
                  />
                </div>
              </div>
            )}

            {selectedNode instanceof Object3DNode && (
              <div className="flex flex-col gap-2 pt-2 border-t border-slate-800/80">
                <span className="text-[10px] font-bold tracking-wider text-indigo-400 font-mono">3D MESH</span>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Wireframe</span>
                  <input
                    type="checkbox"
                    checked={selectedNode.wireframe}
                    onChange={(e) => {
                      const checked = e.target.checked;
                      onUpdateNode((n) => {
                        if (n instanceof Object3DNode) n.wireframe = checked;
                      });
                    }}
                    className="accent-indigo-500 w-4 h-4"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Base Color</span>
                  <input
                    type="color"
                    value={selectedNode.baseColor}
                    onChange={(e) => {
                      const col = e.target.value;
                      onUpdateNode((n) => {
                        if (n instanceof Object3DNode) n.baseColor = col;
                      });
                    }}
                    className="w-7 h-7 rounded border border-slate-700 bg-transparent cursor-pointer"
                  />
                </div>
              </div>
            )}

            {selectedNode instanceof ParticleEmitterNode && (
              <div className="flex flex-col gap-2 pt-2 border-t border-slate-800/80">
                <span className="text-[10px] font-bold tracking-wider text-pink-400 font-mono">PARTICLES</span>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Rate / Sec</span>
                  <input
                    type="number"
                    value={selectedNode.emissionRate}
                    onChange={(e) => {
                      const rate = parseInt(e.target.value) || 10;
                      onUpdateNode((n) => {
                        if (n instanceof ParticleEmitterNode) n.emissionRate = rate;
                      });
                    }}
                    className="w-16 bg-slate-900 border border-slate-800 px-2 py-1 rounded text-right font-mono"
                  />
                </div>
                <button
                  onClick={() => {
                    onUpdateNode((n) => {
                      if (n instanceof ParticleEmitterNode) n.burst(20);
                    });
                  }}
                  className="w-full py-1.5 rounded bg-pink-600/80 hover:bg-pink-500 text-white font-medium text-xs mt-1"
                >
                  Burst 20 Particles
                </button>
              </div>
            )}
          </>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-slate-500 italic p-6 text-center">
            Click any object on stage or in the hierarchy to inspect and modify properties.
          </div>
        )}
      </div>
    </div>
  );
};
