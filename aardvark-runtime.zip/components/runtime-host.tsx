'use client';

// ============================================================================
// AARDVARK RUNTIME - MASTER HOST WORKSPACE
// High-performance interactive media execution environment
// ============================================================================

import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  ShieldCheck,
  Activity,
  Layers,
  Terminal,
  Music,
  FileCode,
  ChevronRight,
  ChevronLeft,
} from 'lucide-react';
import { AardvarkRuntime } from '../aardvark-runtime/runtime';
import { TimelineDeck } from './timeline-deck';
import { SceneInspector } from './scene-inspector';
import { ScriptConsole } from './script-console';
import { AudioSynthesizerDeck } from './audio-synthesizer-deck';
import { DiagnosticsPanel } from './diagnostics-panel';
import { ProjectEditorDeck } from './project-editor-deck';
import { TestRunnerModal } from './test-runner-modal';
import { SceneNode } from '../aardvark-runtime/scene/node';
import { ShapeNode } from '../aardvark-runtime/scene/shapes';
import { RendererBackendType } from '../aardvark-runtime/core/types';

export const RuntimeHost: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [runtime] = useState<AardvarkRuntime>(() => new AardvarkRuntime());

  const [, setSceneVersion] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [backend, setBackend] = useState<RendererBackendType>('canvas2d');
  const [selectedProject, setSelectedProject] = useState('orbital_station');
  const [activeTab, setActiveTab] = useState<'scene' | 'console' | 'audio' | 'project' | 'diagnostics'>('scene');
  const [isDrawerOpen, setIsDrawerOpen] = useState(true);
  const [selectedNode, setSelectedNode] = useState<SceneNode | null>(null);
  const [isTestModalOpen, setIsTestModalOpen] = useState(false);
  const [metrics, setMetrics] = useState({ fps: 60, drawCalls: 0, activeParticles: 0 });

  // Initialize runtime on mount
  useEffect(() => {
    if (canvasRef.current) {
      runtime.attach(canvasRef.current);
      setIsPlaying(runtime.isRunning);
    }

    // Subscribe to runtime events
    const unsubSelect = runtime.eventBus.on('node:selected', ({ node }) => {
      setSelectedNode(node);
    });

    const unsubStart = runtime.eventBus.on('runtime:start', () => setIsPlaying(true));
    const unsubPause = runtime.eventBus.on('runtime:pause', () => setIsPlaying(false));

    // Periodic metrics poll for top HUD
    const metricsInterval = setInterval(() => {
      const m = runtime.getMetrics();
      setMetrics({
        fps: m.fps,
        drawCalls: m.drawCalls,
        activeParticles: m.activeParticles,
      });
    }, 250);

    // Canvas resize observer
    const handleResize = () => {
      if (canvasRef.current) {
        const rect = canvasRef.current.getBoundingClientRect();
        const dpr = window.devicePixelRatio || 1;
        runtime.renderer.resize(rect.width, rect.height, dpr);
      }
    };
    window.addEventListener('resize', handleResize);
    handleResize();

    return () => {
      window.removeEventListener('resize', handleResize);
      clearInterval(metricsInterval);
      unsubSelect.unsubscribe();
      unsubStart.unsubscribe();
      unsubPause.unsubscribe();
      runtime.detach();
    };
  }, [runtime]);

  const handleProjectSelect = (key: string) => {
    setSelectedProject(key);
    if (runtime) {
      runtime.loadSample(key);
      setSelectedNode(null);
      setSceneVersion((v) => v + 1);
    }
  };

  const handlePlayPause = () => {
    if (!runtime) return;
    if (runtime.isRunning) {
      runtime.stop();
      setIsPlaying(false);
    } else {
      runtime.start();
      setIsPlaying(true);
    }
  };

  const handleResetScene = () => {
    if (!runtime) return;
    runtime.loadSample(selectedProject);
    setSelectedNode(null);
    setSceneVersion((v) => v + 1);
  };

  const handleBackendChange = (newBackend: RendererBackendType) => {
    setBackend(newBackend);
    if (runtime) {
      runtime.setBackend(newBackend);
    }
  };

  // Timeline handlers
  const handleTimelinePlayPause = useCallback(() => {
    if (!runtime) return;
    const tl = runtime.scene.timeline;
    if (tl.isPlaying) tl.pause();
    else tl.play();
  }, [runtime]);

  const handleTimelineStop = useCallback(() => {
    if (!runtime) return;
    const tl = runtime.scene.timeline;
    tl.stop();
    if (runtime.scene.root) {
      tl.evaluateAt(1, runtime.scene.root);
    }
  }, [runtime]);

  const handleTimelineStep = useCallback((frames: number) => {
    if (!runtime) return;
    const tl = runtime.scene.timeline;
    tl.step(frames);
    if (runtime.scene.root) {
      tl.evaluateAt(tl.currentFrame, runtime.scene.root);
    }
  }, [runtime]);

  const handleTimelineScrub = useCallback((frame: number) => {
    if (!runtime) return;
    const tl = runtime.scene.timeline;
    tl.gotoAndStop(frame);
    if (runtime.scene.root) {
      tl.evaluateAt(frame, runtime.scene.root);
    }
  }, [runtime]);

  const handleToggleLoop = useCallback(() => {
    runtime.scene.timeline.toggleLoop();
  }, [runtime]);

  const handleTogglePingPong = useCallback(() => {
    runtime.scene.timeline.togglePingPong();
  }, [runtime]);

  const handleToggleDirection = useCallback(() => {
    runtime.scene.timeline.toggleDirection();
  }, [runtime]);

  const handleSetSpeed = useCallback((spd: number) => {
    runtime.scene.timeline.setSpeed(spd);
  }, [runtime]);

  const handleSetFps = useCallback((targetFps: number) => {
    runtime.scene.timeline.setFps(targetFps);
  }, [runtime]);

  // Node Inspector Handlers
  const handleUpdateNode = useCallback((updater: (node: SceneNode) => void) => {
    if (runtime?.selectedNode) {
      updater(runtime.selectedNode);
      runtime.scene.root.updateWorldTransform(true);
      setSceneVersion((v) => v + 1);
    }
  }, [runtime]);

  const handleToggleVisibility = useCallback((node: SceneNode) => {
    node.visible = !node.visible;
    node.markDirty();
    setSceneVersion((v) => v + 1);
  }, []);

  const handleDeleteNode = useCallback((node: SceneNode) => {
    if (runtime?.scene) {
      runtime.scene.removeNode(node);
      runtime.setSelectedNode(null);
      setSelectedNode(null);
      setSceneVersion((v) => v + 1);
    }
  }, [runtime]);

  const handleAddShape = useCallback(() => {
    if (runtime?.scene) {
      const newShape = new ShapeNode(`Shape_${Math.floor(Math.random() * 1000)}`);
      newShape.transform.x = (Math.random() - 0.5) * 200;
      newShape.transform.y = (Math.random() - 0.5) * 200;
      runtime.scene.addNode(newShape);
      runtime.setSelectedNode(newShape);
      setSelectedNode(newShape);
      setSceneVersion((v) => v + 1);
    }
  }, [runtime]);

  return (
    <div id="aardvark_workspace" className="flex flex-col h-screen w-screen bg-slate-950 text-slate-100 overflow-hidden font-sans select-none">
      {/* Top Application Bar */}
      <header className="h-12 bg-slate-900 border-b border-slate-800 px-4 flex items-center justify-between flex-shrink-0 z-30">
        {/* Left: Branding & Project Selector */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-indigo-600 flex items-center justify-center font-black text-white text-xs shadow-md shadow-indigo-600/30">
              A
            </div>
            <div>
              <span className="font-bold tracking-tight text-sm text-slate-100">Aardvark Runtime</span>
              <span className="text-[10px] font-mono text-indigo-400 ml-1.5 px-1 py-0.5 rounded bg-indigo-950/80 border border-indigo-900/60">
                v1.0.0
              </span>
            </div>
          </div>

          <div className="h-4 w-[1px] bg-slate-800 mx-1" />

          {/* Project Dropdown */}
          <div className="flex items-center gap-1.5 bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 text-xs">
            <span className="text-slate-500 font-mono text-[10px]">PROJECT:</span>
            <select
              id="select_project"
              value={selectedProject}
              onChange={(e) => handleProjectSelect(e.target.value)}
              className="bg-transparent text-slate-200 outline-none font-medium cursor-pointer"
            >
              <option value="orbital_station">Orbital Station 9 (Vector & Timeline)</option>
              <option value="cyber_vanguard">Cyber-Vanguard (2D Physics Arena)</option>
              <option value="hyper_prism">Hyper-Prism 3D (Hybrid 2D/3D Mesh)</option>
              <option value="ui_studio">Aardvark UI Studio (Components & Binding)</option>
              <option value="supernova">Supernova Generator (Particle Symphony)</option>
            </select>
          </div>
        </div>

        {/* Center: Playback / Engine Controls */}
        <div className="flex items-center gap-2">
          <button
            id="btn_main_play_pause"
            onClick={handlePlayPause}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold shadow-sm transition-all ${
              isPlaying
                ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-amber-500/20'
                : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/25'
            }`}
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
            <span>{isPlaying ? 'Pause Runtime' : 'Start Runtime'}</span>
          </button>

          <button
            id="btn_main_reset"
            onClick={handleResetScene}
            title="Reset Scene Graph & Timelines"
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          <div className="h-4 w-[1px] bg-slate-800 mx-1" />

          {/* Backend Selector */}
          <div className="flex items-center bg-slate-950 p-0.5 rounded-lg border border-slate-800 text-[11px] font-mono">
            <button
              onClick={() => handleBackendChange('canvas2d')}
              className={`px-2 py-0.5 rounded ${
                backend === 'canvas2d' ? 'bg-indigo-600 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Canvas2D
            </button>
            <button
              onClick={() => handleBackendChange('webgl')}
              className={`px-2 py-0.5 rounded ${
                backend === 'webgl' ? 'bg-indigo-600 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              WebGL
            </button>
          </div>
        </div>

        {/* Right: Telemetry & Automated Tests */}
        <div className="flex items-center gap-2">
          {/* Real-time FPS & Draw Call Badge */}
          <div className="hidden md:flex items-center gap-2 font-mono text-[11px] bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800">
            <span className="text-emerald-400 font-bold">{metrics.fps} FPS</span>
            <span className="text-slate-600">|</span>
            <span className="text-amber-400">{metrics.drawCalls} DC</span>
            <span className="text-slate-600">|</span>
            <span className="text-pink-400">{metrics.activeParticles} FX</span>
          </div>

          {/* Test Suite Runner Button */}
          <button
            id="btn_run_tests"
            onClick={() => setIsTestModalOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700/60 text-slate-200 text-xs transition-colors"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden sm:inline">Engine Tests</span>
          </button>
        </div>
      </header>

      {/* Main Workspace Body */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Left: Canvas Stage Viewport */}
        <div className="flex-1 flex flex-col bg-slate-950 relative overflow-hidden">
          {/* Main Visual Canvas Container */}
          <div className="flex-1 relative flex items-center justify-center p-2 bg-[#050811] overflow-hidden">
            <canvas
              ref={canvasRef}
              id="aardvark_main_canvas"
              className="max-w-full max-h-full rounded-lg shadow-2xl border border-slate-800/80 cursor-default"
            />

            {/* Stage HUD Overlay */}
            <div className="absolute top-4 left-4 pointer-events-none flex flex-col gap-1 text-[11px] font-mono text-slate-400/80">
              <span className="font-semibold text-slate-300 tracking-wide">
                PROJECT: {runtime?.currentProjectName || 'Loading...'}
              </span>
              <span className="text-[10px] text-slate-500">
                BACKEND: {backend.toUpperCase()} | INTERACTION: ACTIVE
              </span>
            </div>

            {/* Toggle Drawer Handle if closed */}
            {!isDrawerOpen && (
              <button
                onClick={() => setIsDrawerOpen(true)}
                className="absolute top-4 right-4 p-2 rounded-lg bg-slate-900/90 border border-slate-800 text-slate-300 hover:text-white shadow-lg transition-colors z-20"
                title="Open Inspector Drawer"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Frame-Accurate Scrubbing Timeline Deck */}
          {runtime && (
            <TimelineDeck
              timeline={runtime.scene.timeline}
              onPlayPause={handleTimelinePlayPause}
              onStop={handleTimelineStop}
              onStep={handleTimelineStep}
              onScrub={handleTimelineScrub}
              onToggleLoop={handleToggleLoop}
              onTogglePingPong={handleTogglePingPong}
              onToggleDirection={handleToggleDirection}
              onSetSpeed={handleSetSpeed}
              onSetFps={handleSetFps}
            />
          )}
        </div>

        {/* Right: Collapsible Subsystem Tool Drawer */}
        {isDrawerOpen && (
          <aside className="w-84 md:w-96 flex flex-col bg-slate-950 border-l border-slate-800 flex-shrink-0 z-20">
            {/* Drawer Tab Navigation */}
            <div className="flex items-center justify-between px-2 bg-slate-900 border-b border-slate-800 text-xs">
              <div className="flex items-center gap-1 overflow-x-auto py-1">
                <button
                  onClick={() => setActiveTab('scene')}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors ${
                    activeTab === 'scene' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Layers className="w-3 h-3" />
                  <span>Scene</span>
                </button>

                <button
                  onClick={() => setActiveTab('console')}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors ${
                    activeTab === 'console' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Terminal className="w-3 h-3" />
                  <span>Script</span>
                </button>

                <button
                  onClick={() => setActiveTab('audio')}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors ${
                    activeTab === 'audio' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Music className="w-3 h-3" />
                  <span>Audio</span>
                </button>

                <button
                  onClick={() => setActiveTab('project')}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors ${
                    activeTab === 'project' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <FileCode className="w-3 h-3" />
                  <span>.AARD</span>
                </button>

                <button
                  onClick={() => setActiveTab('diagnostics')}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors ${
                    activeTab === 'diagnostics' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Activity className="w-3 h-3" />
                  <span>Telemetry</span>
                </button>
              </div>

              {/* Close Drawer Button */}
              <button
                onClick={() => setIsDrawerOpen(false)}
                title="Collapse Drawer"
                className="p-1 rounded text-slate-400 hover:text-white transition-colors"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* Active Drawer Viewport */}
            <div className="flex-1 overflow-hidden">
              {runtime && activeTab === 'scene' && (
                <SceneInspector
                  scene={runtime.scene}
                  selectedNode={selectedNode}
                  onSelectNode={(node) => runtime.setSelectedNode(node)}
                  onUpdateNode={handleUpdateNode}
                  onToggleVisibility={handleToggleVisibility}
                  onDeleteNode={handleDeleteNode}
                  onAddShape={handleAddShape}
                />
              )}

              {runtime && activeTab === 'console' && (
                <ScriptConsole
                  scriptEngine={runtime.scriptEngine}
                  scene={runtime.scene}
                  timeline={runtime.scene.timeline}
                />
              )}

              {runtime && activeTab === 'audio' && (
                <AudioSynthesizerDeck audioEngine={runtime.audioEngine} />
              )}

              {runtime && activeTab === 'project' && (
                <ProjectEditorDeck
                  runtime={runtime}
                  onProjectReloaded={() => {
                    setSelectedNode(null);
                    setSceneVersion((v) => v + 1);
                  }}
                />
              )}

              {runtime && activeTab === 'diagnostics' && (
                <DiagnosticsPanel profiler={runtime.profiler} />
              )}
            </div>
          </aside>
        )}
      </div>

      {/* In-Engine Automated Subsystem Test Suite Modal */}
      <TestRunnerModal isOpen={isTestModalOpen} onClose={() => setIsTestModalOpen(false)} />
    </div>
  );
};
