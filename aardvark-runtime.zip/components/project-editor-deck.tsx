'use client';

// ============================================================================
// AARDVARK RUNTIME - PROJECT JSON EDITOR & PACKAGE MANAGER
// Inspect, modify, load, and export deterministic .aard project packages
// ============================================================================

import React, { useState, useEffect } from 'react';
import { FileCode, Download, Upload, Check, AlertCircle } from 'lucide-react';
import { AardvarkRuntime } from '../aardvark-runtime/runtime';

interface ProjectEditorDeckProps {
  runtime: AardvarkRuntime;
  onProjectReloaded: () => void;
}

export const ProjectEditorDeck: React.FC<ProjectEditorDeckProps> = ({ runtime, onProjectReloaded }) => {
  const [jsonText, setJsonText] = useState(() => {
    try {
      return runtime.exportCurrentProject();
    } catch (e: any) {
      return `// Failed to export: ${e.message}`;
    }
  });
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleApply = () => {
    try {
      const parsed = JSON.parse(jsonText);
      runtime.loadProject(parsed);
      setStatusMessage({ type: 'success', text: 'Project applied successfully!' });
      onProjectReloaded();
      setTimeout(() => setStatusMessage(null), 3000);
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: `Parse error: ${err.message}` });
    }
  };

  const handleDownload = () => {
    const blob = new Blob([jsonText], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${runtime.currentProjectName.toLowerCase().replace(/\s+/g, '_')}.aard`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      const text = evt.target?.result as string;
      setJsonText(text);
      try {
        const parsed = JSON.parse(text);
        runtime.loadProject(parsed);
        setStatusMessage({ type: 'success', text: `Loaded ${file.name} successfully!` });
        onProjectReloaded();
        setTimeout(() => setStatusMessage(null), 3000);
      } catch (err: any) {
        setStatusMessage({ type: 'error', text: `Failed to load file: ${err.message}` });
      }
    };
    reader.readAsText(file);
  };

  return (
    <div id="aardvark_project_deck" className="flex flex-col h-full bg-slate-950 text-slate-300 text-xs border-l border-slate-800 p-3 gap-3 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-slate-800 flex-shrink-0">
        <span className="font-semibold text-slate-200 flex items-center gap-1.5">
          <FileCode className="w-3.5 h-3.5 text-indigo-400" />
          PROJECT SPECIFICATION (.AARD)
        </span>
        <div className="flex items-center gap-1.5">
          <label className="flex items-center gap-1 px-2 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-800 cursor-pointer text-slate-300 text-[10px] font-mono transition-colors">
            <Upload className="w-3 h-3" />
            <span>Open File</span>
            <input type="file" accept=".aard,.json,.aardpkg" onChange={handleFileUpload} className="hidden" />
          </label>
          <button
            onClick={handleDownload}
            className="flex items-center gap-1 px-2 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-[10px] font-mono transition-colors"
          >
            <Download className="w-3 h-3" />
            <span>Export</span>
          </button>
        </div>
      </div>

      {/* Notification status */}
      {statusMessage && (
        <div
          className={`px-2.5 py-1.5 rounded flex items-center gap-2 text-xs flex-shrink-0 ${
            statusMessage.type === 'success'
              ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800'
              : 'bg-rose-950/60 text-rose-300 border border-rose-800'
          }`}
        >
          {statusMessage.type === 'success' ? <Check className="w-3.5 h-3.5" /> : <AlertCircle className="w-3.5 h-3.5" />}
          <span>{statusMessage.text}</span>
        </div>
      )}

      {/* Code Editor */}
      <div className="flex-1 min-h-0 bg-slate-900 rounded border border-slate-800 overflow-hidden flex flex-col">
        <textarea
          value={jsonText}
          onChange={(e) => setJsonText(e.target.value)}
          spellCheck={false}
          className="w-full h-full bg-slate-950 p-2.5 font-mono text-[11px] text-slate-200 resize-none outline-none leading-relaxed"
        />
      </div>

      {/* Action Footer */}
      <div className="flex items-center justify-between flex-shrink-0 pt-1">
        <span className="text-[10px] text-slate-500 font-mono">Standard deterministic JSON schema</span>
        <button
          onClick={handleApply}
          className="px-3 py-1.5 rounded bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs transition-colors shadow-sm"
        >
          Apply Changes to Runtime
        </button>
      </div>
    </div>
  );
};
