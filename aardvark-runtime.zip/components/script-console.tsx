'use client';

// ============================================================================
// AARDVARK RUNTIME - SCRIPT REPL CONSOLE
// Interactive live code execution & log telemetry terminal
// ============================================================================

import React, { useState, useEffect, useRef } from 'react';
import { Terminal, Play, Trash2, Code2, Zap } from 'lucide-react';
import { ScriptEngine, ScriptLogEntry } from '../aardvark-runtime/scripting/script-engine';
import { Scene } from '../aardvark-runtime/scene/scene';
import { Timeline } from '../aardvark-runtime/timeline/timeline';

interface ScriptConsoleProps {
  scriptEngine: ScriptEngine;
  scene: Scene;
  timeline: Timeline;
}

export const ScriptConsole: React.FC<ScriptConsoleProps> = ({ scriptEngine, scene, timeline }) => {
  const [inputCommand, setInputCommand] = useState('');
  const [logs, setLogs] = useState<ScriptLogEntry[]>(() => scriptEngine.getLogs());
  const logEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setLogs(scriptEngine.getLogs());
    }, 250);
    return () => clearInterval(interval);
  }, [scriptEngine]);

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const handleExecute = (codeToRun?: string) => {
    const code = codeToRun || inputCommand;
    if (!code.trim()) return;

    scriptEngine.addLog('info', `> ${code}`);
    try {
      scriptEngine.executeREPL(code, scene, timeline);
    } catch {
      // Error is already logged in engine
    }

    if (!codeToRun) setInputCommand('');
  };

  const quickSnippets = [
    {
      label: 'Impulse Up',
      code: "physics.applyImpulseToNode('node_ball_1', 0, -450); audio.playSfx('bounce');",
    },
    {
      label: 'Rotate Root',
      code: 'scene.root.transform.rotation += 0.5;',
    },
    {
      label: 'Play Synth Chord',
      code: "audio.playTone(440, 0.2); setTimeout(() => audio.playTone(554.37, 0.2), 120); setTimeout(() => audio.playTone(659.25, 0.3), 240);",
    },
    {
      label: 'Restart Timeline',
      code: "timeline.gotoAndPlay(1); audio.playSfx('warp');",
    },
  ];

  return (
    <div id="aardvark_script_console" className="flex flex-col h-full bg-slate-950 text-slate-300 font-mono text-xs border-l border-slate-800">
      {/* Top Header */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-slate-800 bg-slate-900/60">
        <span className="font-semibold text-slate-200 flex items-center gap-1.5">
          <Terminal className="w-3.5 h-3.5 text-emerald-400" />
          SCRIPT REPL & LOGS
        </span>
        <button
          onClick={() => {
            scriptEngine.clearLogs();
            setLogs([]);
          }}
          title="Clear Console"
          className="p-1 text-slate-500 hover:text-slate-300 hover:bg-slate-800 rounded transition-colors"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Quick Action Badges */}
      <div className="px-3 py-2 border-b border-slate-800/80 bg-slate-950 flex flex-wrap gap-1.5 items-center">
        <span className="text-[10px] text-slate-500 flex items-center gap-1">
          <Zap className="w-2.5 h-2.5 text-amber-400" /> QUICK:
        </span>
        {quickSnippets.map((snip, idx) => (
          <button
            key={idx}
            onClick={() => handleExecute(snip.code)}
            className="px-2 py-0.5 rounded bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-slate-300 text-[10px] transition-colors"
          >
            {snip.label}
          </button>
        ))}
      </div>

      {/* Log Output Stream */}
      <div className="flex-1 overflow-y-auto p-3 flex flex-col gap-1 select-text">
        {logs.length === 0 ? (
          <div className="text-slate-600 italic text-center py-6">
            Aardvark Script Engine active. Enter commands or click quick actions.
          </div>
        ) : (
          logs.map((log, index) => {
            const time = new Date(log.timestamp).toLocaleTimeString();
            let color = 'text-slate-300';
            if (log.type === 'info') color = 'text-indigo-300';
            if (log.type === 'warn') color = 'text-amber-400';
            if (log.type === 'error') color = 'text-rose-400';

            return (
              <div key={index} className="flex items-start gap-2 leading-relaxed">
                <span className="text-slate-600 text-[10px] flex-shrink-0 select-none">[{time}]</span>
                <span className={`break-all ${color}`}>{log.message}</span>
              </div>
            );
          })
        )}
        <div ref={logEndRef} />
      </div>

      {/* REPL Input Line */}
      <div className="p-2 border-t border-slate-800 bg-slate-900/60">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleExecute();
          }}
          className="flex items-center gap-2 bg-slate-950 px-2.5 py-1.5 rounded border border-slate-800 focus-within:border-indigo-500 transition-colors"
        >
          <Code2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
          <input
            type="text"
            value={inputCommand}
            onChange={(e) => setInputCommand(e.target.value)}
            placeholder="e.g. audio.playSfx('laser'); or scene.root.transform.x += 10;"
            className="w-full bg-transparent text-slate-100 outline-none text-xs placeholder:text-slate-600 font-mono"
          />
          <button
            type="submit"
            className="p-1 rounded bg-indigo-600 hover:bg-indigo-500 text-white transition-colors"
            title="Execute (Enter)"
          >
            <Play className="w-3 h-3 fill-current" />
          </button>
        </form>
      </div>
    </div>
  );
};
