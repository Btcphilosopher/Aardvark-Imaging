'use client';

// ============================================================================
// AARDVARK RUNTIME - PROCEDURAL AUDIO SYNTHESIZER DECK
// Interactive procedural sound effects generator & tone synthesizer interface
// ============================================================================

import React, { useState } from 'react';
import { Volume2, VolumeX, Sparkles, Music } from 'lucide-react';
import { AudioEngine, SfxPreset, OscillatorType } from '../aardvark-runtime/audio/audio-engine';

interface AudioSynthesizerDeckProps {
  audioEngine: AudioEngine;
}

export const AudioSynthesizerDeck: React.FC<AudioSynthesizerDeckProps> = ({ audioEngine }) => {
  const [volume, setVolume] = useState(() => audioEngine.getMasterVolume());
  const [muted, setMuted] = useState(false);
  const [waveform, setWaveform] = useState<OscillatorType>('sine');

  const sfxPresets: SfxPreset[] = [
    'laser',
    'explosion',
    'powerup',
    'blip',
    'click',
    'bounce',
    'warp',
    'jump',
    'drone',
  ];

  const notes = [
    { name: 'C4', freq: 261.63 },
    { name: 'D4', freq: 293.66 },
    { name: 'E4', freq: 329.63 },
    { name: 'F4', freq: 349.23 },
    { name: 'G4', freq: 392.0 },
    { name: 'A4', freq: 440.0 },
    { name: 'B4', freq: 493.88 },
    { name: 'C5', freq: 523.25 },
  ];

  return (
    <div id="aardvark_audio_deck" className="flex flex-col h-full bg-slate-950 text-slate-300 text-xs border-l border-slate-800 p-4 gap-4 overflow-y-auto">
      {/* Title */}
      <div className="flex items-center justify-between pb-2 border-b border-slate-800">
        <span className="font-semibold text-slate-200 flex items-center gap-1.5">
          <Music className="w-3.5 h-3.5 text-indigo-400" />
          SYNTHESIZER & SFX ENGINE
        </span>
        <span className="text-[10px] font-mono text-indigo-400 bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-900/50">
          WEB AUDIO API
        </span>
      </div>

      {/* Volume & Mute Controls */}
      <div className="flex items-center justify-between bg-slate-900 p-3 rounded-lg border border-slate-800">
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              const newMuted = !muted;
              setMuted(newMuted);
              audioEngine.setVolume(newMuted ? 0 : volume);
            }}
            className="p-1.5 rounded hover:bg-slate-800 text-slate-300 hover:text-white transition-colors"
          >
            {muted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-indigo-400" />}
          </button>
          <span className="text-slate-400 font-medium">Master Volume</span>
        </div>

        <div className="flex items-center gap-2">
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={muted ? 0 : volume}
            onChange={(e) => {
              const v = parseFloat(e.target.value);
              setVolume(v);
              setMuted(false);
              audioEngine.setVolume(v);
            }}
            className="w-24 accent-indigo-500"
          />
          <span className="font-mono text-[11px] text-slate-300 w-8 text-right">
            {Math.round((muted ? 0 : volume) * 100)}%
          </span>
        </div>
      </div>

      {/* SFX Presets Generator */}
      <div className="flex flex-col gap-2">
        <span className="text-[10px] font-bold tracking-wider text-slate-400 font-mono flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-amber-400" /> PROCEDURAL SFX GENERATORS
        </span>
        <div className="grid grid-cols-3 gap-2">
          {sfxPresets.map((preset) => (
            <button
              key={preset}
              onClick={() => audioEngine.playSfx(preset)}
              className="px-2.5 py-2 rounded bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-indigo-500/50 text-slate-200 text-center font-medium capitalize transition-all hover:scale-105 active:scale-95 shadow-sm"
            >
              {preset}
            </button>
          ))}
        </div>
      </div>

      {/* Live Tone Synthesizer Keyboard */}
      <div className="flex flex-col gap-2 pt-2 border-t border-slate-800">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-bold tracking-wider text-slate-400 font-mono">TONE KEYBOARD</span>
          {/* Waveform Selector */}
          <div className="flex items-center gap-1">
            {(['sine', 'triangle', 'sawtooth', 'square'] as OscillatorType[]).map((wf) => (
              <button
                key={wf}
                onClick={() => setWaveform(wf)}
                className={`px-1.5 py-0.5 rounded text-[10px] font-mono capitalize transition-colors ${
                  waveform === wf
                    ? 'bg-indigo-600 text-white font-medium'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200'
                }`}
              >
                {wf.substring(0, 4)}
              </button>
            ))}
          </div>
        </div>

        {/* Octave Pads */}
        <div className="grid grid-cols-4 gap-2 mt-1">
          {notes.map((note) => (
            <button
              key={note.name}
              onClick={() => audioEngine.playTone(note.freq, 0.35, waveform)}
              className="py-3 rounded bg-indigo-950/50 hover:bg-indigo-900/80 border border-indigo-800/40 hover:border-indigo-600 text-indigo-200 font-mono text-xs font-bold transition-all hover:scale-105 active:scale-95 shadow-sm flex flex-col items-center justify-center gap-0.5"
            >
              <span>{note.name}</span>
              <span className="text-[9px] text-slate-500 font-normal">{Math.round(note.freq)}Hz</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
