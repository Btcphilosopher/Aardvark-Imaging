'use client';

// ============================================================================
// AARDVARK RUNTIME - DIAGNOSTICS & TELEMETRY PROFILER
// Real-time engine performance metrics, frame times, and subsystem breakdowns
// ============================================================================

import React, { useState, useEffect, useRef } from 'react';
import { Activity, Download, Cpu, Monitor } from 'lucide-react';
import { RuntimeProfiler } from '../aardvark-runtime/core/diagnostics';
import { PerformanceMetrics } from '../aardvark-runtime/core/types';

interface DiagnosticsPanelProps {
  profiler: RuntimeProfiler;
}

export const DiagnosticsPanel: React.FC<DiagnosticsPanelProps> = ({ profiler }) => {
  const [metrics, setMetrics] = useState<PerformanceMetrics>(() => profiler.getMetrics());
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      const m = profiler.getMetrics();
      setMetrics(m);

      // Draw frame-time sparkline graph
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          const w = canvas.width;
          const h = canvas.height;
          ctx.clearRect(0, 0, w, h);

          // 16.6ms target 60fps line
          const target60Y = h - (16.6 / 33.3) * h;
          ctx.strokeStyle = '#334155';
          ctx.setLineDash([4, 4]);
          ctx.beginPath();
          ctx.moveTo(0, target60Y);
          ctx.lineTo(w, target60Y);
          ctx.stroke();
          ctx.setLineDash([]);

          // Plot history
          const hist = profiler.frameTimeHistory;
          const step = w / Math.max(1, hist.length - 1);

          ctx.beginPath();
          ctx.strokeStyle = '#6366f1';
          ctx.lineWidth = 1.5;
          hist.forEach((time, idx) => {
            const x = idx * step;
            const y = Math.max(0, Math.min(h, h - (time / 33.3) * h));
            if (idx === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
          });
          ctx.stroke();
        }
      }
    }, 100);

    return () => clearInterval(interval);
  }, [profiler]);

  const handleExportJson = () => {
    const report = profiler.exportReport();
    const blob = new Blob([report], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `aardvark_diagnostics_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div id="aardvark_diagnostics_panel" className="flex flex-col h-full bg-slate-950 text-slate-300 text-xs border-l border-slate-800 p-4 gap-4 overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-slate-800">
        <span className="font-semibold text-slate-200 flex items-center gap-1.5">
          <Activity className="w-3.5 h-3.5 text-indigo-400" />
          ENGINE TELEMETRY & PROFILER
        </span>
        <button
          onClick={handleExportJson}
          className="flex items-center gap-1 px-2 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-[10px] font-mono transition-colors"
        >
          <Download className="w-3 h-3" />
          <span>Export JSON</span>
        </button>
      </div>

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-3 gap-2">
        <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800 flex flex-col">
          <span className="text-[10px] text-slate-500 font-mono">FRAME RATE</span>
          <span className="text-xl font-bold font-mono text-emerald-400 mt-1">
            {metrics.fps} <span className="text-xs text-slate-500 font-normal">FPS</span>
          </span>
        </div>

        <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800 flex flex-col">
          <span className="text-[10px] text-slate-500 font-mono">FRAME TIME</span>
          <span className="text-xl font-bold font-mono text-indigo-400 mt-1">
            {metrics.frameTimeMs} <span className="text-xs text-slate-500 font-normal">ms</span>
          </span>
        </div>

        <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800 flex flex-col">
          <span className="text-[10px] text-slate-500 font-mono">DRAW CALLS</span>
          <span className="text-xl font-bold font-mono text-amber-400 mt-1">
            {metrics.drawCalls} <span className="text-xs text-slate-500 font-normal">calls</span>
          </span>
        </div>
      </div>

      {/* Frame Time History Sparkline */}
      <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 flex flex-col gap-1.5">
        <div className="flex items-center justify-between text-[10px] font-mono text-slate-400">
          <span>FRAME DURATION HISTORY (last 60 frames)</span>
          <span className="text-slate-500">Target: 16.6ms</span>
        </div>
        <canvas ref={canvasRef} width={280} height={56} className="w-full h-14 bg-slate-950 rounded border border-slate-800" />
      </div>

      {/* Subsystem Times Breakdown */}
      <div className="flex flex-col gap-2">
        <span className="text-[10px] font-bold tracking-wider text-slate-400 font-mono flex items-center gap-1">
          <Cpu className="w-3 h-3 text-indigo-400" /> SUBSYSTEM PHASE TIMES
        </span>
        <div className="flex flex-col gap-1.5 bg-slate-900 p-3 rounded-lg border border-slate-800">
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-slate-400">Script Execution</span>
            <span className="font-mono text-slate-200">{Math.round(metrics.scriptTimeMs * 100) / 100} ms</span>
          </div>
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-slate-400">Physics Simulation</span>
            <span className="font-mono text-slate-200">{Math.round(metrics.physicsTimeMs * 100) / 100} ms</span>
          </div>
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-slate-400">Scene Hierarchy & Timeline</span>
            <span className="font-mono text-slate-200">{Math.round(metrics.updateTimeMs * 100) / 100} ms</span>
          </div>
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-slate-400">Raster & Render Pipeline</span>
            <span className="font-mono text-slate-200">{Math.round(metrics.renderTimeMs * 100) / 100} ms</span>
          </div>
        </div>
      </div>

      {/* Subsystem Counts */}
      <div className="flex flex-col gap-2">
        <span className="text-[10px] font-bold tracking-wider text-slate-400 font-mono flex items-center gap-1">
          <Monitor className="w-3 h-3 text-amber-400" /> ACTIVE SUBSYSTEM ENTITIES
        </span>
        <div className="grid grid-cols-3 gap-2">
          <div className="bg-slate-900 p-2 rounded border border-slate-800 text-center">
            <span className="text-[10px] text-slate-500 font-mono block">PARTICLES</span>
            <span className="font-bold font-mono text-pink-400 text-sm mt-0.5 block">{metrics.activeParticles}</span>
          </div>
          <div className="bg-slate-900 p-2 rounded border border-slate-800 text-center">
            <span className="text-[10px] text-slate-500 font-mono block">AUDIO VOICES</span>
            <span className="font-bold font-mono text-cyan-400 text-sm mt-0.5 block">{metrics.activeAudioVoices}</span>
          </div>
          <div className="bg-slate-900 p-2 rounded border border-slate-800 text-center">
            <span className="text-[10px] text-slate-500 font-mono block">RIGID BODIES</span>
            <span className="font-bold font-mono text-emerald-400 text-sm mt-0.5 block">{metrics.physicsBodies}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
