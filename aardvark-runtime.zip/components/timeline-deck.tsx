'use client';

// ============================================================================
// AARDVARK RUNTIME - TIMELINE DECK COMPONENT
// Production-grade frame & time-based scrubbing interface
// ============================================================================

import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  Square,
  SkipBack,
  SkipForward,
  Repeat,
  ArrowLeftRight,
  RotateCcw,
  Clock,
  Layers,
  Sparkles,
  Volume2,
} from 'lucide-react';
import { Timeline } from '../aardvark-runtime/timeline/timeline';

interface TimelineDeckProps {
  timeline: Timeline;
  onPlayPause: () => void;
  onStop: () => void;
  onStep: (frames: number) => void;
  onScrub: (frame: number) => void;
  onToggleLoop: () => void;
  onTogglePingPong: () => void;
  onToggleDirection: () => void;
  onSetSpeed: (speed: number) => void;
  onSetFps: (fps: number) => void;
}

export const TimelineDeck: React.FC<TimelineDeckProps> = ({
  timeline,
  onPlayPause,
  onStop,
  onStep,
  onScrub,
  onToggleLoop,
  onTogglePingPong,
  onToggleDirection,
  onSetSpeed,
  onSetFps,
}) => {
  const [currentFrame, setCurrentFrame] = useState(timeline.currentFrame);
  const [isPlaying, setIsPlaying] = useState(timeline.isPlaying);
  const [loop, setLoop] = useState(timeline.loop);
  const [pingPong, setPingPong] = useState(timeline.pingPong);
  const [direction, setDirection] = useState(timeline.direction);
  const [speed, setSpeed] = useState(timeline.playbackSpeed);
  const [fps, setFps] = useState(timeline.fps);

  const tracksContainerRef = useRef<HTMLDivElement>(null);
  const isScrubbingRef = useRef<boolean>(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentFrame(timeline.currentFrame);
      setIsPlaying(timeline.isPlaying);
      setLoop(timeline.loop);
      setPingPong(timeline.pingPong);
      setDirection(timeline.direction);
      setSpeed(timeline.playbackSpeed);
      setFps(timeline.fps);
    }, 40);

    return () => clearInterval(interval);
  }, [timeline]);

  const handleMouseDownScrub = (e: React.MouseEvent<HTMLDivElement>) => {
    isScrubbingRef.current = true;
    doScrub(e.clientX);

    const onMove = (moveEvt: MouseEvent) => {
      if (!isScrubbingRef.current) return;
      doScrub(moveEvt.clientX);
    };

    const onUp = () => {
      isScrubbingRef.current = false;
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };

    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  };

  const doScrub = (clientX: number) => {
    if (!tracksContainerRef.current) return;
    const rect = tracksContainerRef.current.getBoundingClientRect();
    const clickX = clientX - rect.left;
    const progress = Math.max(0, Math.min(1, clickX / rect.width));
    const targetFrame = Math.max(1, Math.round(1 + progress * (timeline.durationFrames - 1)));
    setCurrentFrame(targetFrame);
    onScrub(targetFrame);
  };

  const playheadPercent = ((currentFrame - 1) / Math.max(1, timeline.durationFrames - 1)) * 100;

  return (
    <div id="aardvark_timeline_deck" className="bg-slate-900 border-t border-slate-800 text-slate-300 select-none flex flex-col h-48">
      {/* Timeline Controls Bar */}
      <div className="flex items-center justify-between px-3 py-2 bg-slate-950/80 border-b border-slate-800/80 text-xs">
        {/* Left: Playback Controls */}
        <div className="flex items-center gap-1.5">
          <button
            id="tl_btn_step_back"
            onClick={() => onStep(-1)}
            title="Step Backward (1 Frame)"
            className="p-1.5 rounded hover:bg-slate-800 text-slate-300 hover:text-white transition-colors"
          >
            <SkipBack className="w-3.5 h-3.5" />
          </button>

          <button
            id="tl_btn_play_pause"
            onClick={onPlayPause}
            title={isPlaying ? 'Pause' : 'Play'}
            className={`p-1.5 rounded font-medium transition-colors ${
              isPlaying ? 'bg-amber-500 text-slate-950' : 'bg-indigo-600 hover:bg-indigo-500 text-white'
            }`}
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
          </button>

          <button
            id="tl_btn_stop"
            onClick={onStop}
            title="Stop & Reset"
            className="p-1.5 rounded hover:bg-slate-800 text-slate-300 hover:text-white transition-colors"
          >
            <Square className="w-3.5 h-3.5 fill-current" />
          </button>

          <button
            id="tl_btn_step_fwd"
            onClick={() => onStep(1)}
            title="Step Forward (1 Frame)"
            className="p-1.5 rounded hover:bg-slate-800 text-slate-300 hover:text-white transition-colors"
          >
            <SkipForward className="w-3.5 h-3.5" />
          </button>

          <div className="h-4 w-[1px] bg-slate-800 mx-1" />

          {/* Loop Mode Toggle */}
          <button
            id="tl_btn_loop"
            onClick={onToggleLoop}
            title={loop ? 'Loop: Enabled' : 'Loop: Disabled'}
            className={`p-1.5 rounded transition-colors ${loop ? 'bg-indigo-950 text-indigo-400 border border-indigo-800/60' : 'hover:bg-slate-800 text-slate-400'}`}
          >
            <Repeat className="w-3.5 h-3.5" />
          </button>

          {/* Ping-Pong Mode Toggle */}
          <button
            id="tl_btn_pingpong"
            onClick={onTogglePingPong}
            title={pingPong ? 'Ping-Pong: Enabled' : 'Ping-Pong: Disabled'}
            className={`p-1.5 rounded transition-colors ${pingPong ? 'bg-indigo-950 text-indigo-400 border border-indigo-800/60' : 'hover:bg-slate-800 text-slate-400'}`}
          >
            <ArrowLeftRight className="w-3.5 h-3.5" />
          </button>

          {/* Reverse Direction Toggle */}
          <button
            id="tl_btn_reverse"
            onClick={onToggleDirection}
            title={`Direction: ${direction}`}
            className={`p-1.5 rounded transition-colors ${direction === 'reverse' ? 'bg-amber-950 text-amber-400 border border-amber-800/60' : 'hover:bg-slate-800 text-slate-400'}`}
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Center: Frame and Timecode Counter */}
        <div className="flex items-center gap-3 font-mono bg-slate-900/90 px-3 py-1 rounded border border-slate-800">
          <span className="text-slate-400 text-[11px]">FRAME</span>
          <span className="text-indigo-400 font-bold min-w-[50px] text-center text-[13px]">
            {Math.floor(currentFrame)}
            <span className="text-slate-600 font-normal text-[11px]"> / {timeline.durationFrames}</span>
          </span>
          <span className="h-3 w-[1px] bg-slate-800" />
          <span className="text-slate-400 text-[11px] flex items-center gap-1">
            <Clock className="w-3 h-3 text-slate-500" />
            {timeline.getTimeString()}
          </span>
        </div>

        {/* Right: Speed & FPS Multipliers */}
        <div className="flex items-center gap-2 text-[11px]">
          <div className="flex items-center gap-1 bg-slate-900 px-2 py-1 rounded border border-slate-800">
            <span className="text-slate-500">SPEED:</span>
            <select
              id="tl_select_speed"
              value={speed}
              onChange={(e) => onSetSpeed(parseFloat(e.target.value))}
              className="bg-transparent text-slate-200 outline-none cursor-pointer"
            >
              <option value="0.25">0.25x</option>
              <option value="0.5">0.5x</option>
              <option value="1.0">1.0x</option>
              <option value="2.0">2.0x</option>
              <option value="4.0">4.0x</option>
            </select>
          </div>

          <div className="flex items-center gap-1 bg-slate-900 px-2 py-1 rounded border border-slate-800">
            <span className="text-slate-500">FPS:</span>
            <select
              id="tl_select_fps"
              value={fps}
              onChange={(e) => onSetFps(parseInt(e.target.value))}
              className="bg-transparent text-slate-200 outline-none cursor-pointer"
            >
              <option value="24">24</option>
              <option value="30">30</option>
              <option value="60">60</option>
            </select>
          </div>
        </div>
      </div>

      {/* Tracks & Ruler Viewport */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Track Names Sidebar */}
        <div className="w-48 bg-slate-950 border-r border-slate-800 overflow-y-auto flex-shrink-0">
          <div className="h-6 border-b border-slate-800 px-2 flex items-center text-[10px] text-slate-500 font-mono tracking-wider">
            <Layers className="w-3 h-3 mr-1.5" />
            TRACKS ({timeline.tracks.length})
          </div>
          {timeline.tracks.length === 0 ? (
            <div className="p-3 text-[11px] text-slate-500 italic">No animated tracks</div>
          ) : (
            timeline.tracks.map((track) => (
              <div
                key={track.id}
                className="h-7 px-2.5 flex items-center justify-between border-b border-slate-800/50 hover:bg-slate-900/80 text-[11px]"
              >
                <span className="truncate font-medium text-slate-300" title={track.name}>
                  {track.name}
                </span>
                <span className="text-[9px] text-indigo-400 font-mono px-1 py-0.5 rounded bg-indigo-950/60 border border-indigo-900/40">
                  {track.keyframes.length} kf
                </span>
              </div>
            ))
          )}
        </div>

        {/* Right Ruler & Keyframe Track Canvas */}
        <div className="flex-1 relative overflow-hidden bg-slate-900/60 flex flex-col">
          {/* Timeline Ruler Header */}
          <div
            ref={tracksContainerRef}
            onMouseDown={handleMouseDownScrub}
            className="h-6 bg-slate-950/60 border-b border-slate-800 relative cursor-pointer select-none"
          >
            {/* Frame Tick Markers */}
            {Array.from({ length: Math.ceil(timeline.durationFrames / 10) + 1 }).map((_, idx) => {
              const frameNum = idx * 10 || 1;
              const leftPercent = ((frameNum - 1) / Math.max(1, timeline.durationFrames - 1)) * 100;
              return (
                <div
                  key={idx}
                  className="absolute top-0 bottom-0 border-l border-slate-700/60 flex flex-col justify-end pb-0.5 pl-1 text-[9px] font-mono text-slate-500 pointer-events-none"
                  style={{ left: `${leftPercent}%` }}
                >
                  {frameNum}
                </div>
              );
            })}

            {/* Marker Flags */}
            {Array.from(timeline.markers.entries()).map(([frame, marker]) => {
              const leftPercent = ((frame - 1) / Math.max(1, timeline.durationFrames - 1)) * 100;
              return (
                <div
                  key={frame}
                  className="absolute top-0.5 -translate-x-1/2 flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-amber-500/20 border border-amber-500/40 text-amber-300 text-[9px] font-mono shadow-sm pointer-events-none"
                  style={{ left: `${leftPercent}%` }}
                  title={`${marker.label} (frame ${frame})`}
                >
                  {marker.audioTrigger ? <Volume2 className="w-2.5 h-2.5" /> : <Sparkles className="w-2.5 h-2.5" />}
                  <span>{marker.label}</span>
                </div>
              );
            })}

            {/* Playhead Head Handle */}
            <div
              className="absolute top-0 bottom-0 w-[2px] bg-amber-400 pointer-events-none z-20"
              style={{ left: `${playheadPercent}%` }}
            >
              <div className="w-3 h-3 -translate-x-1/2 rotate-45 bg-amber-400 rounded-sm -mt-1 shadow-md shadow-amber-500/50" />
            </div>
          </div>

          {/* Keyframe Tracks Body */}
          <div
            onMouseDown={handleMouseDownScrub}
            className="flex-1 overflow-y-auto relative cursor-crosshair bg-slate-900/30"
          >
            {/* Grid vertical frame lines */}
            {Array.from({ length: Math.ceil(timeline.durationFrames / 10) + 1 }).map((_, idx) => {
              const frameNum = idx * 10 || 1;
              const leftPercent = ((frameNum - 1) / Math.max(1, timeline.durationFrames - 1)) * 100;
              return (
                <div
                  key={idx}
                  className="absolute top-0 bottom-0 border-l border-slate-800/40 pointer-events-none"
                  style={{ left: `${leftPercent}%` }}
                />
              );
            })}

            {/* Keyframe Track Rows */}
            {timeline.tracks.map((track) => (
              <div key={track.id} className="h-7 border-b border-slate-800/40 relative">
                {/* Keyframe Diamonds */}
                {track.keyframes.map((kf, kIdx) => {
                  const leftPercent = ((kf.frame - 1) / Math.max(1, timeline.durationFrames - 1)) * 100;
                  return (
                    <div
                      key={kIdx}
                      className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-2.5 h-2.5 rotate-45 bg-indigo-400 hover:bg-indigo-300 border border-indigo-200 shadow-sm cursor-pointer z-10 transition-transform hover:scale-125"
                      style={{ left: `${leftPercent}%` }}
                      title={`Frame ${kf.frame}: ${JSON.stringify(kf.value)} (${kf.easing || 'linear'})`}
                      onClick={(e) => {
                        e.stopPropagation();
                        onScrub(kf.frame);
                      }}
                    />
                  );
                })}
              </div>
            ))}

            {/* Playhead vertical line through all tracks */}
            <div
              className="absolute top-0 bottom-0 w-[2px] bg-amber-400/90 pointer-events-none z-20"
              style={{ left: `${playheadPercent}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
