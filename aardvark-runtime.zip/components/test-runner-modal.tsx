'use client';

// ============================================================================
// AARDVARK RUNTIME - IN-ENGINE TEST SUITE RUNNER MODAL
// Executes live assertions across all engine subsystems
// ============================================================================

import React, { useState } from 'react';
import { CheckCircle2, XCircle, Play, X, ShieldCheck } from 'lucide-react';
import { TestRunner, TestSuiteResult } from '../aardvark-runtime/tests/test-runner';
import { registerSubsystemTests } from '../aardvark-runtime/tests/subsystem-tests';

interface TestRunnerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TestRunnerModal: React.FC<TestRunnerModalProps> = ({ isOpen, onClose }) => {
  const [isRunning, setIsRunning] = useState(false);
  const [suiteResults, setSuiteResults] = useState<TestSuiteResult[]>([]);

  if (!isOpen) return null;

  const handleRunAll = async () => {
    setIsRunning(true);
    const runner = new TestRunner();
    registerSubsystemTests(runner);

    const results = await runner.runAll();
    setSuiteResults(results);
    setIsRunning(false);
  };

  const totalTests = suiteResults.reduce((acc, s) => acc + s.totalTests, 0);
  const totalPassed = suiteResults.reduce((acc, s) => acc + s.passedCount, 0);
  const totalFailed = suiteResults.reduce((acc, s) => acc + s.failedCount, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 select-none">
      <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl w-full max-w-2xl max-h-[85vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800 bg-slate-950/80">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-indigo-400" />
            <h2 className="text-sm font-semibold text-slate-100">Aardvark Runtime Subsystem Test Suite</h2>
          </div>
          <button onClick={onClose} className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Action Bar */}
        <div className="px-4 py-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3 text-xs font-mono">
            {suiteResults.length > 0 ? (
              <>
                <span className="text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> {totalPassed} Passed
                </span>
                {totalFailed > 0 && (
                  <span className="text-rose-400 flex items-center gap-1">
                    <XCircle className="w-3.5 h-3.5" /> {totalFailed} Failed
                  </span>
                )}
                <span className="text-slate-500">({totalTests} assertions)</span>
              </>
            ) : (
              <span className="text-slate-400">Ready to execute automated subsystem tests</span>
            )}
          </div>

          <button
            onClick={handleRunAll}
            disabled={isRunning}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 text-white font-medium text-xs transition-colors shadow-sm"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>{isRunning ? 'Running Tests...' : 'Run All Tests'}</span>
          </button>
        </div>

        {/* Test Suites Result List */}
        <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3 font-mono text-xs">
          {suiteResults.length === 0 && !isRunning && (
            <div className="flex flex-col items-center justify-center py-12 text-slate-500 italic">
              Click &quot;Run All Tests&quot; to verify math matrices, scene graph, timeline, physics, particles, 3D meshes, and event bus.
            </div>
          )}

          {suiteResults.map((suite, idx) => (
            <div key={idx} className="bg-slate-950 rounded-lg border border-slate-800 overflow-hidden">
              <div className="flex items-center justify-between px-3 py-2 bg-slate-900/60 border-b border-slate-800/80">
                <span className="font-semibold text-slate-200">{suite.suiteName}</span>
                <span className="text-[10px] text-slate-400">{Math.round(suite.durationMs * 10) / 10} ms</span>
              </div>

              <div className="p-2 flex flex-col gap-1">
                {suite.results.map((res, rIdx) => (
                  <div key={rIdx} className="flex items-center justify-between px-2 py-1 rounded hover:bg-slate-900/50">
                    <div className="flex items-center gap-2 truncate">
                      {res.passed ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                      ) : (
                        <XCircle className="w-3.5 h-3.5 text-rose-400 flex-shrink-0" />
                      )}
                      <span className={res.passed ? 'text-slate-300 truncate' : 'text-rose-300 font-semibold truncate'}>
                        {res.testName}
                      </span>
                    </div>

                    <span className="text-[10px] text-slate-500 flex-shrink-0">
                      {Math.round(res.durationMs * 100) / 100} ms
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
