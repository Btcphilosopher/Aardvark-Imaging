import { RuntimeHost } from '../components/runtime-host';

export default function Page() {
  return (
    <main className="w-screen h-screen overflow-hidden bg-slate-950">
      <RuntimeHost />
    </main>
  );
}
