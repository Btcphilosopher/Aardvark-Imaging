import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Aardvark Runtime',
  description: 'Production-grade general-purpose interactive media runtime and visual execution engine.',
  openGraph: {
    title: 'Aardvark Runtime',
    description: 'Production-grade general-purpose interactive media runtime and visual execution engine.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Aardvark Runtime',
    description: 'Production-grade general-purpose interactive media runtime and visual execution engine.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
