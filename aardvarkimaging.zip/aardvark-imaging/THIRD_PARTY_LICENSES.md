# Third-party components

## DejaVu Sans (bundled font)

`aardvark/assets/data/fonts/DejaVuSans.ttf` and `DejaVuSans-Bold.ttf` are
bundled as the engine's built-in fallback typeface (`Font.system()`), used
whenever a document doesn't reference its own embedded font.

```
Copyright (c) 2003 by Bitstream, Inc. All Rights Reserved. Bitstream Vera is
a trademark of Bitstream, Inc. DejaVu changes are in the public domain.

Permission is hereby granted, free of charge, to any person obtaining a copy
of the fonts accompanying this license ("Fonts") and associated
documentation files (the "Font Software"), to reproduce and distribute the
Font Software, including without limitation the rights to use, copy, merge,
publish, distribute, and/or sell copies of the Font Software, and to permit
persons to whom the Font Software is furnished to do so, subject to the
conditions in the full Bitstream Vera license (see
https://dejavu-fonts.github.io/License.html).
```

## Python dependencies

This project depends on the following third-party libraries (see
`pyproject.toml` for version constraints); each is distributed under its own
license and is *not* vendored into this repository — they're installed via
`pip`:

| Package     | License        | Used for                                   |
|-------------|----------------|---------------------------------------------|
| numpy       | BSD-3-Clause   | vectorised geometry/raster math              |
| Pillow      | MIT-CMU (PIL)  | raster compositing, PNG/JPEG/WebP codecs     |
| fonttools   | MIT            | font inspection, glyph outlines, subsetting  |
| reportlab   | BSD-3-Clause   | PDF generation                               |
| pyclipper   | BSL-1.0 / MIT  | polygon boolean ops and offsetting (Clipper) |
