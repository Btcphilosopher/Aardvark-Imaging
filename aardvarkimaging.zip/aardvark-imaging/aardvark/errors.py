"""Structured error hierarchy for the Aardvark engine.

Every error carries a machine-readable ``code`` and a ``details`` dict so
that the Kotlin client (or any other consumer of the JSON API) can render a
useful diagnostic instead of a bare string. Nothing in this engine returns a
fake "success" result for a feature that does not work — an unimplemented
or unsupported operation always raises one of these.
"""

from __future__ import annotations

from typing import Any


class AardvarkError(Exception):
    """Base class for all errors raised by the Aardvark engine."""

    code: str = "aardvark_error"

    def __init__(self, message: str, *, details: dict[str, Any] | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.details: dict[str, Any] = details or {}

    def to_dict(self) -> dict[str, Any]:
        return {"error": self.code, "message": self.message, "details": self.details}

    def __str__(self) -> str:
        if self.details:
            return f"{self.message} ({self.details})"
        return self.message


class GeometryError(AardvarkError):
    code = "geometry_error"


class RenderError(AardvarkError):
    code = "render_error"


class ExportError(AardvarkError):
    code = "export_error"


class ImportError(AardvarkError):  # noqa: A001 - intentionally shadows builtin within this module only
    code = "import_error"


# Ergonomic alias so callers can `from aardvark.errors import AardvarkImportError`
# without colliding with the builtin `ImportError` in their own module scope.
AardvarkImportError = ImportError


class DocumentError(AardvarkError):
    code = "document_error"


class FontError(AardvarkError):
    code = "font_error"


class AssetError(AardvarkError):
    code = "asset_error"


class CapabilityError(AardvarkError):
    """Raised when a feature is architected but intentionally not yet implemented.

    This is the *only* acceptable way for a documented-but-unbuilt capability
    to fail: never silently return a placeholder result.
    """

    code = "capability_error"


class SerializationError(AardvarkError):
    code = "serialization_error"


class ValidationError(AardvarkError):
    code = "validation_error"


class CancelledError(AardvarkError):
    code = "cancelled_error"
