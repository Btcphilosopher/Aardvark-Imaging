"""An R-tree spatial index (spec section 28) for accelerating hit testing,
selection, and viewport queries on large documents — so those operations
don't have to walk every object in a 100,000-object document.

A real R-tree (Guttman-style: subtree chosen by least area enlargement,
quadratic-split node overflow), not a flat list pretending to be one.
Removal recomputes ancestor bounds but does not reinsert orphaned entries
from underflowing nodes — a documented simplification (the tree stays
correct and query-accurate; it just doesn't repack itself as tightly as a
textbook R-tree after heavy deletion, which is fine for an interactive
editor's typical add/remove-a-few-objects-at-a-time workload).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Generic, TypeVar

from aardvark.geometry.bounds import Bounds

T = TypeVar("T")

MAX_ENTRIES = 8
MIN_ENTRIES = 4


@dataclass
class _Entry(Generic[T]):
    bounds: Bounds
    item_id: T | None = None  # set on leaf entries
    child: "_Node[T] | None" = None  # set on internal entries


@dataclass
class _Node(Generic[T]):
    is_leaf: bool
    entries: list[_Entry[T]] = field(default_factory=list)
    parent: "_Node[T] | None" = field(default=None, repr=False, compare=False)

    def bounds(self) -> Bounds:
        b = Bounds.empty()
        for e in self.entries:
            b = b.union(e.bounds)
        return b


class RTree(Generic[T]):
    def __init__(self) -> None:
        self._root: _Node[T] = _Node(is_leaf=True)
        self._item_bounds: dict[T, Bounds] = {}
        self._item_leaf: dict[T, _Node[T]] = {}

    def __len__(self) -> int:
        return len(self._item_bounds)

    def insert(self, item_id: T, bounds: Bounds) -> None:
        if item_id in self._item_bounds:
            self.remove(item_id)
        entry = _Entry(bounds=bounds, item_id=item_id)
        leaf = self._choose_leaf(bounds)
        leaf.entries.append(entry)
        self._item_bounds[item_id] = bounds
        self._item_leaf[item_id] = leaf
        self._adjust_tree(leaf)

    def remove(self, item_id: T) -> None:
        leaf = self._item_leaf.get(item_id)
        if leaf is None:
            return
        leaf.entries = [e for e in leaf.entries if e.item_id != item_id]
        del self._item_bounds[item_id]
        del self._item_leaf[item_id]
        self._adjust_bounds_upward(leaf)

    def update(self, item_id: T, bounds: Bounds) -> None:
        self.insert(item_id, bounds)

    def query(self, bounds: Bounds) -> list[T]:
        results: list[T] = []
        self._query_node(self._root, bounds, results)
        return results

    def query_point(self, x: float, y: float) -> list[T]:
        return self.query(Bounds(x, y, x, y))

    def all_ids(self) -> list[T]:
        return list(self._item_bounds.keys())

    # -- internals ------------------------------------------------------
    def _query_node(self, node: _Node[T], bounds: Bounds, out: list[T]) -> None:
        for e in node.entries:
            if not e.bounds.intersects(bounds):
                continue
            if node.is_leaf:
                out.append(e.item_id)  # type: ignore[arg-type]
            else:
                self._query_node(e.child, bounds, out)  # type: ignore[arg-type]

    def _choose_leaf(self, bounds: Bounds) -> _Node[T]:
        node = self._root
        while not node.is_leaf:
            best_entry = min(node.entries, key=lambda e: (_enlargement(e.bounds, bounds), _area(e.bounds)))
            node = best_entry.child  # type: ignore[assignment]
        return node

    def _adjust_tree(self, node: _Node[T]) -> None:
        while True:
            if len(node.entries) > MAX_ENTRIES:
                new_node = self._split_node(node)
                if node.parent is None:
                    new_root = _Node(is_leaf=False)
                    new_root.entries = [
                        _Entry(bounds=node.bounds(), child=node),
                        _Entry(bounds=new_node.bounds(), child=new_node),
                    ]
                    node.parent = new_root
                    new_node.parent = new_root
                    self._root = new_root
                    self._reindex_leaves(node)
                    self._reindex_leaves(new_node)
                    return
                parent = node.parent
                for e in parent.entries:
                    if e.child is node:
                        e.bounds = node.bounds()
                parent.entries.append(_Entry(bounds=new_node.bounds(), child=new_node))
                new_node.parent = parent
                self._reindex_leaves(new_node)
                node = parent
                continue
            if node.parent is not None:
                for e in node.parent.entries:
                    if e.child is node:
                        e.bounds = node.bounds()
                node = node.parent
                continue
            return

    def _adjust_bounds_upward(self, node: _Node[T]) -> None:
        while node.parent is not None:
            parent = node.parent
            for e in parent.entries:
                if e.child is node:
                    e.bounds = node.bounds()
            node = parent

    def _reindex_leaves(self, node: _Node[T]) -> None:
        if node.is_leaf:
            for e in node.entries:
                self._item_leaf[e.item_id] = node  # type: ignore[index]
        else:
            for e in node.entries:
                self._reindex_leaves(e.child)  # type: ignore[arg-type]

    def _split_node(self, node: _Node[T]) -> _Node[T]:
        """Quadratic-cost split (Guttman): pick the pair of entries that
        would waste the most area if grouped together as seeds, then
        greedily assign the rest to whichever group needs less enlargement."""
        entries = node.entries
        seed_a, seed_b = _pick_seeds(entries)
        group_a = [seed_a]
        group_b = [seed_b]
        remaining = [e for e in entries if e is not seed_a and e is not seed_b]

        while remaining:
            if len(group_a) + len(remaining) <= MIN_ENTRIES:
                group_a.extend(remaining)
                remaining = []
                break
            if len(group_b) + len(remaining) <= MIN_ENTRIES:
                group_b.extend(remaining)
                remaining = []
                break
            entry = remaining.pop()
            bounds_a = _union_all(group_a)
            bounds_b = _union_all(group_b)
            enlarge_a = _enlargement(bounds_a, entry.bounds)
            enlarge_b = _enlargement(bounds_b, entry.bounds)
            if enlarge_a < enlarge_b:
                group_a.append(entry)
            elif enlarge_b < enlarge_a:
                group_b.append(entry)
            elif _area(bounds_a) < _area(bounds_b):
                group_a.append(entry)
            else:
                group_b.append(entry)

        node.entries = group_a
        new_node = _Node(is_leaf=node.is_leaf)
        new_node.entries = group_b
        if not node.is_leaf:
            for e in group_b:
                e.child.parent = new_node
        return new_node


def _area(b: Bounds) -> float:
    return 0.0 if b.is_empty else b.width * b.height


def _enlargement(existing: Bounds, added: Bounds) -> float:
    return _area(existing.union(added)) - _area(existing)


def _union_all(entries: list[_Entry]) -> Bounds:
    b = Bounds.empty()
    for e in entries:
        b = b.union(e.bounds)
    return b


def _pick_seeds(entries: list[_Entry]) -> tuple[_Entry, _Entry]:
    best_pair = (entries[0], entries[1])
    best_waste = -1.0
    for i in range(len(entries)):
        for j in range(i + 1, len(entries)):
            combined = entries[i].bounds.union(entries[j].bounds)
            waste = _area(combined) - _area(entries[i].bounds) - _area(entries[j].bounds)
            if waste > best_waste:
                best_waste = waste
                best_pair = (entries[i], entries[j])
    return best_pair
