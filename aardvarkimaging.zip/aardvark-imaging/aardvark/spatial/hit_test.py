"""Hit testing and selection geometry (spec sections 29-30).

Respects transforms, stroke width, visibility, clipping and z-order, and
returns the topmost valid object — exactly the semantics an interactive
editor needs for click-to-select. Uses :class:`~aardvark.spatial.index.RTree`
so a click on a 100,000-object document doesn't walk every object.
"""

from __future__ import annotations

from dataclasses import dataclass

from aardvark.document.page import Page
from aardvark.document.scene import GraphicContainer, GraphicObject
from aardvark.geometry.bounds import Bounds
from aardvark.geometry.point import Point
from aardvark.geometry.rect import Rect
from aardvark.images.image import Image
from aardvark.spatial.index import RTree
from aardvark.text.text import Text


def build_spatial_index(page: Page) -> RTree[str]:
    """Index every object's world *visual* bounds (geometry+stroke+effects),
    keyed by object id. Rebuild (or call ``update``) after edits; this
    function does not track document changes itself."""
    tree: RTree[str] = RTree()
    for layer in page.layers:
        for obj in layer.walk():
            bounds = obj.world_bounds().visual
            if not bounds.is_empty:
                tree.insert(obj.id, bounds)
    return tree


def _ordered_objects(page: Page) -> list[GraphicObject]:
    """Every object in the page, bottom-to-top z-order (layer order, then
    depth-first child order within each layer)."""
    ordered: list[GraphicObject] = []
    for layer in page.layers:
        ordered.append(layer)
        ordered.extend(layer.walk())
    return ordered


def _is_within_clip_chain(obj: GraphicObject, world_point: Point) -> bool:
    # clip_path is authored in each ancestor's own local space, so test the
    # point against it after mapping world -> that ancestor's local frame.
    for ancestor in obj.ancestor_chain():
        if ancestor.clip_path is not None:
            inv = ancestor.world_matrix().inverse()
            lx, ly = inv.apply_xy(world_point.x, world_point.y)
            if not ancestor.clip_path.contains_point(Point(lx, ly)):
                return False
    return True


def _object_hit_at_point(obj: GraphicObject, world_point: Point, *, stroke_tolerance: float = 2.0) -> bool:
    if not obj.visible:
        return False
    inv = obj.world_matrix().inverse()
    lx, ly = inv.apply_xy(world_point.x, world_point.y)
    local = Point(lx, ly)

    if not _is_within_clip_chain(obj, world_point):
        return False

    if obj.style.fill.paint is not None and obj.contains_point_local(lx, ly):
        return True
    if obj.style.stroke is not None and obj.style.stroke.paint is not None:
        half = obj.style.stroke.width / 2.0 + stroke_tolerance
        if obj.to_path().distance_to_point(local) <= half:
            return True
    if isinstance(obj, Image):
        return obj.to_path().contains_point(local)
    return False


def point_hit(
    page: Page, x: float, y: float, *, index: RTree[str] | None = None, include_locked: bool = True
) -> GraphicObject | None:
    """Returns the topmost object under (x, y) in page space, or None."""
    idx = index or build_spatial_index(page)
    candidate_ids = set(idx.query_point(x, y))
    if not candidate_ids:
        return None

    world_point = Point(x, y)
    for obj in reversed(_ordered_objects(page)):
        if obj.id not in candidate_ids:
            continue
        if isinstance(obj, GraphicContainer) and not isinstance(obj, Text):
            continue  # containers (Group/Layer) are not directly selectable leaves
        if not include_locked and obj.locked:
            continue
        if _object_hit_at_point(obj, world_point):
            return obj
    return None


def rect_hit(page: Page, rect: Rect, *, index: RTree[str] | None = None, mode: str = "intersect") -> list[GraphicObject]:
    """Marquee selection: objects whose bounds relate to ``rect`` per ``mode``
    ("intersect": any overlap; "contain": fully inside the marquee)."""
    idx = index or build_spatial_index(page)
    query_bounds = rect.to_bounds()
    candidate_ids = set(idx.query(query_bounds))
    results = []
    for obj in _ordered_objects(page):
        if obj.id not in candidate_ids or isinstance(obj, GraphicContainer):
            continue
        b = obj.world_bounds().visual
        if b.is_empty:
            continue
        if mode == "contain":
            if query_bounds.min_x <= b.min_x and query_bounds.min_y <= b.min_y and b.max_x <= query_bounds.max_x and b.max_y <= query_bounds.max_y:
                results.append(obj)
        else:
            if b.intersects(query_bounds):
                results.append(obj)
    return results


def stroke_hit(obj: GraphicObject, x: float, y: float, tolerance: float = 2.0) -> bool:
    if obj.style.stroke is None or obj.style.stroke.paint is None:
        return False
    inv = obj.world_matrix().inverse()
    local = Point(*inv.apply_xy(x, y))
    half = obj.style.stroke.width / 2.0 + tolerance
    return obj.to_path().distance_to_point(local) <= half


def text_hit(obj: Text, x: float, y: float) -> bool:
    inv = obj.world_matrix().inverse()
    local = Point(*inv.apply_xy(x, y))
    return obj.local_bounds().contains_point(local.x, local.y)


def path_hit(obj: GraphicObject, x: float, y: float) -> bool:
    inv = obj.world_matrix().inverse()
    local = Point(*inv.apply_xy(x, y))
    return obj.contains_point_local(local.x, local.y)


# --------------------------------------------------------- selection geometry
@dataclass(frozen=True, slots=True)
class SelectionHandles:
    """Handle geometry for a selection's bounding box, in the same space as
    the input bounds (typically world/screen space) — the Kotlin UI renders
    these; this only computes where they are (spec section 30)."""

    bounds: Bounds
    corners: tuple[tuple[float, float], tuple[float, float], tuple[float, float], tuple[float, float]]
    edge_midpoints: tuple[tuple[float, float], tuple[float, float], tuple[float, float], tuple[float, float]]
    center: tuple[float, float]
    rotation_handle: tuple[float, float]


def selection_handles(bounds: Bounds, *, rotation_handle_offset: float = 24.0) -> SelectionHandles:
    if bounds.is_empty:
        raise ValueError("Cannot compute selection handles for an empty bounds")
    tl = (bounds.min_x, bounds.min_y)
    tr = (bounds.max_x, bounds.min_y)
    br = (bounds.max_x, bounds.max_y)
    bl = (bounds.min_x, bounds.max_y)
    top_mid = ((tl[0] + tr[0]) / 2, tl[1])
    right_mid = (tr[0], (tr[1] + br[1]) / 2)
    bottom_mid = ((bl[0] + br[0]) / 2, bl[1])
    left_mid = (tl[0], (tl[1] + bl[1]) / 2)
    center = bounds.center
    rotation_handle = (top_mid[0], top_mid[1] - rotation_handle_offset)
    return SelectionHandles(bounds, (tl, tr, br, bl), (top_mid, right_mid, bottom_mid, left_mid), center, rotation_handle)


def selection_bounds(objects: list[GraphicObject]) -> Bounds:
    b = Bounds.empty()
    for obj in objects:
        b = b.union(obj.world_bounds().visual)
    return b
