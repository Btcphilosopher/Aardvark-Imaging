"""The snap engine (spec section 31): grid, object edges/centres, path
nodes, page edges/centre, and guides — snapped per-axis (the convention
every vector editor uses: X and Y snap independently to whichever candidate
is closest on that axis, not to the single closest point in 2D)."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from aardvark.document.page import Grid, Guide, GuideOrientation, Page
from aardvark.document.scene import GraphicObject
from aardvark.geometry.point import Point


class SnapKind(str, Enum):
    GRID = "grid"
    OBJECT_EDGE = "object-edge"
    OBJECT_CENTER = "object-center"
    NODE = "node"
    PAGE_EDGE = "page-edge"
    PAGE_CENTER = "page-center"
    GUIDE = "guide"


@dataclass(frozen=True, slots=True)
class SnapCandidate:
    value: float  # the x or y coordinate this candidate offers
    kind: SnapKind
    source_id: str | None = None


@dataclass(frozen=True, slots=True)
class SnapResult:
    point: Point
    x_snap: SnapCandidate | None
    y_snap: SnapCandidate | None


class SnapEngine:
    def __init__(self, tolerance: float = 6.0) -> None:
        self.tolerance = tolerance

    def _grid_candidates(self, grid: Grid, axis_extent: float) -> list[float]:
        if not grid.visible or grid.spacing <= 0:
            return []
        n = int(axis_extent / grid.spacing) + 2
        return [i * grid.spacing for i in range(-1, n)]

    def _collect_axis_candidates(
        self, page: Page, objects: list[GraphicObject], guides: list[Guide], axis: str
    ) -> list[SnapCandidate]:
        candidates: list[SnapCandidate] = []

        extent = page.width if axis == "x" else page.height
        for v in self._grid_candidates(page.grid, extent):
            candidates.append(SnapCandidate(v, SnapKind.GRID))

        candidates.append(SnapCandidate(0.0, SnapKind.PAGE_EDGE))
        candidates.append(SnapCandidate(extent, SnapKind.PAGE_EDGE))
        candidates.append(SnapCandidate(extent / 2.0, SnapKind.PAGE_CENTER))

        wanted_orientation = GuideOrientation.VERTICAL if axis == "x" else GuideOrientation.HORIZONTAL
        for g in guides:
            if g.orientation == wanted_orientation:
                candidates.append(SnapCandidate(g.position, SnapKind.GUIDE, g.id))

        for obj in objects:
            b = obj.world_bounds().geometry
            if b.is_empty:
                continue
            if axis == "x":
                candidates.append(SnapCandidate(b.min_x, SnapKind.OBJECT_EDGE, obj.id))
                candidates.append(SnapCandidate(b.max_x, SnapKind.OBJECT_EDGE, obj.id))
                candidates.append(SnapCandidate((b.min_x + b.max_x) / 2.0, SnapKind.OBJECT_CENTER, obj.id))
            else:
                candidates.append(SnapCandidate(b.min_y, SnapKind.OBJECT_EDGE, obj.id))
                candidates.append(SnapCandidate(b.max_y, SnapKind.OBJECT_EDGE, obj.id))
                candidates.append(SnapCandidate((b.min_y + b.max_y) / 2.0, SnapKind.OBJECT_CENTER, obj.id))

            try:
                path = obj.to_path()
            except Exception:
                continue
            world = obj.world_matrix()
            for sp in path.subpaths:
                for anchor in sp.anchors():
                    wx, wy = world.apply_xy(anchor.x, anchor.y)
                    candidates.append(SnapCandidate(wx if axis == "x" else wy, SnapKind.NODE, obj.id))

        return candidates

    def snap(
        self, point: Point, page: Page, *, objects: list[GraphicObject] | None = None, exclude_ids: set[str] = frozenset()
    ) -> SnapResult:
        objs = [o for o in (objects or []) if o.id not in exclude_ids]
        x_candidates = self._collect_axis_candidates(page, objs, page.guides, "x")
        y_candidates = self._collect_axis_candidates(page, objs, page.guides, "y")

        best_x = _closest_within(point.x, x_candidates, self.tolerance)
        best_y = _closest_within(point.y, y_candidates, self.tolerance)

        snapped_x = best_x.value if best_x else point.x
        snapped_y = best_y.value if best_y else point.y
        return SnapResult(Point(snapped_x, snapped_y), best_x, best_y)


def _closest_within(value: float, candidates: list[SnapCandidate], tolerance: float) -> SnapCandidate | None:
    best = None
    best_dist = tolerance
    for c in candidates:
        d = abs(c.value - value)
        if d <= best_dist:
            best_dist = d
            best = c
    return best
