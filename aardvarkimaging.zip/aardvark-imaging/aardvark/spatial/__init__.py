"""Spatial indexing, hit testing, selection geometry, and snapping."""

from aardvark.spatial.index import RTree
from aardvark.spatial.hit_test import (
    build_spatial_index,
    path_hit,
    point_hit,
    rect_hit,
    selection_bounds,
    selection_handles,
    stroke_hit,
    text_hit,
)
from aardvark.spatial.snap import SnapCandidate, SnapEngine, SnapKind, SnapResult

__all__ = [
    "RTree",
    "build_spatial_index",
    "point_hit",
    "rect_hit",
    "stroke_hit",
    "text_hit",
    "path_hit",
    "selection_handles",
    "selection_bounds",
    "SnapEngine",
    "SnapCandidate",
    "SnapKind",
    "SnapResult",
]
