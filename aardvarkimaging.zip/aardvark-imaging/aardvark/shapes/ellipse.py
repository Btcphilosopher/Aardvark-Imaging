"""Ellipse and circle primitive shapes."""

from __future__ import annotations

from dataclasses import dataclass

from aardvark.geometry.bounds import Bounds
from aardvark.document.scene import GraphicObject
from aardvark.paths.path import Path

_KAPPA = 0.5522847498307936


@dataclass
class Ellipse(GraphicObject):
    cx: float = 0.0
    cy: float = 0.0
    rx: float = 0.0
    ry: float = 0.0

    def __post_init__(self) -> None:
        self.kind = "ellipse"

    def local_bounds(self) -> Bounds:
        return Bounds(self.cx - self.rx, self.cy - self.ry, self.cx + self.rx, self.cy + self.ry)

    def to_path(self) -> Path:
        cx, cy, rx, ry = self.cx, self.cy, self.rx, self.ry
        kx, ky = rx * _KAPPA, ry * _KAPPA
        path = Path()
        path.move_to(cx + rx, cy)
        path.curve_to(cx + rx, cy + ky, cx + kx, cy + ry, cx, cy + ry)
        path.curve_to(cx - kx, cy + ry, cx - rx, cy + ky, cx - rx, cy)
        path.curve_to(cx - rx, cy - ky, cx - kx, cy - ry, cx, cy - ry)
        path.curve_to(cx + kx, cy - ry, cx + rx, cy - ky, cx + rx, cy)
        path.close()
        return path


@dataclass
class Circle(Ellipse):
    """Convenience shape: an :class:`Ellipse` constrained to rx == ry.

    Accepts the ``radius`` keyword shown in the spec's example API
    (``Circle(cx=400, cy=300, radius=120)``) in addition to ``rx``/``ry``.
    """

    radius: float | None = None

    def __post_init__(self) -> None:
        if self.radius is not None:
            self.rx = self.radius
            self.ry = self.radius
        else:
            self.radius = self.rx
            self.ry = self.rx
        self.kind = "circle"

    def local_bounds(self) -> Bounds:
        return Ellipse.local_bounds(self)

    def to_path(self) -> Path:
        return Ellipse.to_path(self)
