"""Regular polygon primitive shape."""

from __future__ import annotations

import math
from dataclasses import dataclass

from aardvark.errors import ValidationError
from aardvark.geometry.bounds import Bounds
from aardvark.document.scene import GraphicObject
from aardvark.paths.path import Path


@dataclass
class Polygon(GraphicObject):
    cx: float = 0.0
    cy: float = 0.0
    radius: float = 0.0
    sides: int = 5
    rotation: float = -math.pi / 2  # default: point straight up

    def __post_init__(self) -> None:
        self.kind = "polygon"
        if self.sides < 3:
            raise ValidationError("A polygon needs at least 3 sides")

    def vertices(self) -> list[tuple[float, float]]:
        pts = []
        for i in range(self.sides):
            angle = self.rotation + i * (2 * math.pi / self.sides)
            pts.append((self.cx + self.radius * math.cos(angle), self.cy + self.radius * math.sin(angle)))
        return pts

    def local_bounds(self) -> Bounds:
        return Bounds.from_points(self.vertices())

    def to_path(self) -> Path:
        pts = self.vertices()
        path = Path()
        path.move_to(*pts[0])
        for p in pts[1:]:
            path.line_to(*p)
        path.close()
        return path
