"""Star primitive shape (alternating outer/inner radius vertices)."""

from __future__ import annotations

import math
from dataclasses import dataclass

from aardvark.errors import ValidationError
from aardvark.geometry.bounds import Bounds
from aardvark.document.scene import GraphicObject
from aardvark.paths.path import Path


@dataclass
class Star(GraphicObject):
    cx: float = 0.0
    cy: float = 0.0
    outer_radius: float = 0.0
    inner_radius: float = 0.0
    points: int = 5
    rotation: float = -math.pi / 2

    def __post_init__(self) -> None:
        self.kind = "star"
        if self.points < 2:
            raise ValidationError("A star needs at least 2 points")
        if self.inner_radius > self.outer_radius:
            raise ValidationError("inner_radius cannot exceed outer_radius")

    def vertices(self) -> list[tuple[float, float]]:
        pts = []
        step = math.pi / self.points
        for i in range(self.points * 2):
            radius = self.outer_radius if i % 2 == 0 else self.inner_radius
            angle = self.rotation + i * step
            pts.append((self.cx + radius * math.cos(angle), self.cy + radius * math.sin(angle)))
        return pts

    def local_bounds(self) -> Bounds:
        return Bounds.from_points(self.vertices())

    def to_path(self) -> Path:
        pts = self.vertices()
        path = Path()
        path.move_to(*pts[0])
        for p in pts[1:]:
            path.line_to(*p)
        path.close()
        return path
