"""Straight line-segment primitive shape."""

from __future__ import annotations

from dataclasses import dataclass

from aardvark.geometry.bounds import Bounds
from aardvark.document.scene import GraphicObject
from aardvark.paths.path import Path


@dataclass
class Line(GraphicObject):
    x1: float = 0.0
    y1: float = 0.0
    x2: float = 0.0
    y2: float = 0.0

    def __post_init__(self) -> None:
        self.kind = "line"

    def local_bounds(self) -> Bounds:
        return Bounds(min(self.x1, self.x2), min(self.y1, self.y2), max(self.x1, self.x2), max(self.y1, self.y2))

    def to_path(self) -> Path:
        path = Path()
        path.move_to(self.x1, self.y1)
        path.line_to(self.x2, self.y2)
        return path
