"""Rectangle and rounded rectangle primitive shape."""

from __future__ import annotations

from dataclasses import dataclass

from aardvark.errors import ValidationError
from aardvark.geometry.bounds import Bounds
from aardvark.document.scene import GraphicObject
from aardvark.paths.path import Path

# Bezier "kappa" constant for approximating a quarter circle arc with a cubic.
_KAPPA = 0.5522847498307936


@dataclass
class Rectangle(GraphicObject):
    x: float = 0.0
    y: float = 0.0
    width: float = 0.0
    height: float = 0.0
    # Either one uniform radius or (top-left, top-right, bottom-right, bottom-left).
    corner_radius: float | tuple[float, float, float, float] = 0.0

    def __post_init__(self) -> None:
        self.kind = "rectangle"
        if self.width < 0 or self.height < 0:
            raise ValidationError("Rectangle width/height must be non-negative")

    def _radii(self) -> tuple[float, float, float, float]:
        if isinstance(self.corner_radius, tuple):
            radii = self.corner_radius
        else:
            radii = (self.corner_radius,) * 4
        max_r = min(self.width, self.height) / 2.0
        return tuple(max(0.0, min(r, max_r)) for r in radii)  # type: ignore[return-value]

    def local_bounds(self) -> Bounds:
        return Bounds(self.x, self.y, self.x + self.width, self.y + self.height)

    def to_path(self) -> Path:
        tl, tr, br, bl = self._radii()
        x, y, w, h = self.x, self.y, self.width, self.height
        path = Path()
        if tl == tr == br == bl == 0.0:
            path.move_to(x, y).line_to(x + w, y).line_to(x + w, y + h).line_to(x, y + h).close()
            return path

        k = _KAPPA
        path.move_to(x + tl, y)
        path.line_to(x + w - tr, y)
        if tr:
            path.curve_to(x + w - tr + tr * k, y, x + w, y + tr - tr * k, x + w, y + tr)
        path.line_to(x + w, y + h - br)
        if br:
            path.curve_to(x + w, y + h - br + br * k, x + w - br + br * k, y + h, x + w - br, y + h)
        path.line_to(x + bl, y + h)
        if bl:
            path.curve_to(x + bl - bl * k, y + h, x, y + h - bl + bl * k, x, y + h - bl)
        path.line_to(x, y + tl)
        if tl:
            path.curve_to(x, y + tl - tl * k, x + tl - tl * k, y, x + tl, y)
        path.close()
        return path
