"""Import a standalone raster image as a placed :class:`Image` object (spec
section 21) — either into an existing document/layer, or as a new
single-page document sized to the image."""

from __future__ import annotations

from aardvark.document.document import Document
from aardvark.document.layer import Layer
from aardvark.images.image import Image
from aardvark.images.loader import register_image_file


def import_raster_image(path: str, *, document: Document | None = None, layer: Layer | None = None) -> Image:
    if document is None:
        from aardvark.images.loader import probe_image
        from pathlib import Path as FsPath

        meta = probe_image(FsPath(path).read_bytes())
        document = Document(width=meta["width"], height=meta["height"], title=FsPath(path).stem)

    asset_id = register_image_file(document.assets, path)
    meta = document.assets.get(asset_id).metadata
    img = Image(
        asset_id=asset_id, x=0.0, y=0.0, width=meta["width"], height=meta["height"],
        source_width=meta["width"], source_height=meta["height"],
    )
    (layer or document.active_layer).add(img)
    return img
