"""SVG import (spec section 42).

Parses ``path``, ``rect``, ``circle``, ``ellipse``, ``line``, ``polygon``,
``polyline``, ``g``, ``text``, ``image``, fill/stroke/transform/gradient/
clipPath — preserving vector geometry (path data is parsed into real
Bezier/line segments, never flattened or rasterised on import).

Security (spec section 62): the input is treated as untrusted.
  - ``<script>`` elements and ``on*`` event-handler attributes are dropped,
    never evaluated (this parser never evaluates anything — there is no
    embedded interpreter — but they are stripped from the object graph too).
  - A ``<!DOCTYPE`` declaration is rejected outright rather than parsed, as a
    cheap defence against XML entity-expansion attacks.
  - An ``<image>`` with an ``http(s)://`` (or any non-``data:``) href is
    *not* fetched — this importer never makes network requests. Such images
    are skipped and reported as a diagnostic instead.
"""

from __future__ import annotations

import math
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field

from aardvark.document.document import Document
from aardvark.document.scene import Group
from aardvark.errors import AardvarkImportError
from aardvark.geometry.matrix import Matrix
from aardvark.geometry.transform import Transform
from aardvark.images.image import Image
from aardvark.paths.path import Path
from aardvark.style import Color, Fill, GradientStop, LinearGradient, RadialGradient, SpreadMode, Stroke, Style
from aardvark.style.stroke import LineCap, LineJoin
from aardvark.text.text import Text

_SVG_NS = "{http://www.w3.org/2000/svg}"
_XLINK_NS = "{http://www.w3.org/1999/xlink}"

_NAMED_COLORS = {
    "black": "#000000", "white": "#ffffff", "red": "#ff0000", "green": "#008000",
    "blue": "#0000ff", "yellow": "#ffff00", "gray": "#808080", "grey": "#808080",
    "orange": "#ffa500", "purple": "#800080", "none": None, "transparent": None,
}


@dataclass
class ImportDiagnostics:
    warnings: list[str] = field(default_factory=list)

    def warn(self, message: str) -> None:
        self.warnings.append(message)


def _tag(el: ET.Element) -> str:
    t = el.tag
    return t[len(_SVG_NS):] if t.startswith(_SVG_NS) else t


def _num(s: str | None, default: float = 0.0) -> float:
    if s is None:
        return default
    m = re.match(r"[-+]?[0-9]*\.?[0-9]+(?:[eE][-+]?[0-9]+)?", s.strip())
    return float(m.group()) if m else default


def parse_color(value: str | None, opacity_attr: str | None = None) -> Color | None:
    if value is None:
        return None
    value = value.strip()
    if value == "none" or value == "":
        return None
    if value.startswith("url("):
        return None  # gradient/pattern refs are resolved separately
    if value.startswith("#"):
        color = Color.from_hex(value)
    elif value in _NAMED_COLORS:
        hexval = _NAMED_COLORS[value]
        if hexval is None:
            return None
        color = Color.from_hex(hexval)
    elif value.startswith("rgb"):
        nums = [float(n) for n in re.findall(r"[-+]?[0-9]*\.?[0-9]+", value)]
        if len(nums) >= 3:
            r, g, b = nums[0] / 255.0, nums[1] / 255.0, nums[2] / 255.0
            a = nums[3] if len(nums) > 3 else 1.0
            color = Color(r, g, b, a)
        else:
            return None
    else:
        return None
    if opacity_attr:
        color = color.with_alpha(color.a * _num(opacity_attr, 1.0))
    return color


_TRANSFORM_RE = re.compile(r"(\w+)\s*\(([^)]*)\)")


def parse_transform(value: str | None) -> Matrix:
    if not value:
        return Matrix.identity()
    m = Matrix.identity()
    for name, args_str in _TRANSFORM_RE.findall(value):
        args = [float(a) for a in re.findall(r"[-+]?[0-9]*\.?[0-9]+(?:[eE][-+]?[0-9]+)?", args_str)]
        if name == "translate":
            tx, ty = (args + [0.0, 0.0])[:2]
            m = m.compose(Matrix.translation(tx, ty))
        elif name == "scale":
            sx = args[0] if args else 1.0
            sy = args[1] if len(args) > 1 else sx
            m = m.compose(Matrix.scaling(sx, sy))
        elif name == "rotate":
            angle = args[0] if args else 0.0
            origin = (args[1], args[2]) if len(args) >= 3 else (0.0, 0.0)
            m = m.compose(Matrix.rotation_degrees(angle, origin))
        elif name == "skewX":
            m = m.compose(Matrix.skewing(skew_x_radians=math.radians(args[0] if args else 0.0)))
        elif name == "skewY":
            m = m.compose(Matrix.skewing(skew_y_radians=math.radians(args[0] if args else 0.0)))
        elif name == "matrix" and len(args) == 6:
            m = m.compose(Matrix(*args))
    return m


# ---------------------------------------------------------------- path data
_PATH_TOKEN_RE = re.compile(r"([MmLlHhVvCcSsQqTtAaZz])|([-+]?[0-9]*\.?[0-9]+(?:[eE][-+]?[0-9]+)?)")


def parse_path_data(d: str) -> Path:
    tokens = _PATH_TOKEN_RE.findall(d)
    items: list[str] = [t[0] or t[1] for t in tokens]

    path = Path()
    i = 0
    cur = (0.0, 0.0)
    start = (0.0, 0.0)
    last_cubic_ctrl: tuple[float, float] | None = None
    last_quad_ctrl: tuple[float, float] | None = None
    cmd = ""

    def read_nums(n: int) -> list[float]:
        nonlocal i
        vals = [float(items[i + k]) for k in range(n)]
        i += n
        return vals

    while i < len(items):
        tok = items[i]
        if tok.isalpha():
            cmd = tok
            i += 1
        is_rel = cmd.islower()
        C = cmd.upper()
        if C == "M":
            x, y = read_nums(2)
            if is_rel:
                x, y = cur[0] + x, cur[1] + y
            path.move_to(x, y)
            cur = start = (x, y)
            cmd = "l" if is_rel else "L"  # subsequent implicit pairs are lineto
        elif C == "L":
            x, y = read_nums(2)
            if is_rel:
                x, y = cur[0] + x, cur[1] + y
            path.line_to(x, y)
            cur = (x, y)
        elif C == "H":
            (x,) = read_nums(1)
            if is_rel:
                x = cur[0] + x
            path.line_to(x, cur[1])
            cur = (x, cur[1])
        elif C == "V":
            (y,) = read_nums(1)
            if is_rel:
                y = cur[1] + y
            path.line_to(cur[0], y)
            cur = (cur[0], y)
        elif C == "C":
            x1, y1, x2, y2, x, y = read_nums(6)
            if is_rel:
                x1, y1, x2, y2, x, y = cur[0] + x1, cur[1] + y1, cur[0] + x2, cur[1] + y2, cur[0] + x, cur[1] + y
            path.curve_to(x1, y1, x2, y2, x, y)
            cur, last_cubic_ctrl = (x, y), (x2, y2)
        elif C == "S":
            x2, y2, x, y = read_nums(4)
            if is_rel:
                x2, y2, x, y = cur[0] + x2, cur[1] + y2, cur[0] + x, cur[1] + y
            if last_cubic_ctrl:
                x1, y1 = 2 * cur[0] - last_cubic_ctrl[0], 2 * cur[1] - last_cubic_ctrl[1]
            else:
                x1, y1 = cur
            path.curve_to(x1, y1, x2, y2, x, y)
            cur, last_cubic_ctrl = (x, y), (x2, y2)
        elif C == "Q":
            x1, y1, x, y = read_nums(4)
            if is_rel:
                x1, y1, x, y = cur[0] + x1, cur[1] + y1, cur[0] + x, cur[1] + y
            path.quad_to(x1, y1, x, y)
            cur, last_quad_ctrl = (x, y), (x1, y1)
        elif C == "T":
            x, y = read_nums(2)
            if is_rel:
                x, y = cur[0] + x, cur[1] + y
            if last_quad_ctrl:
                x1, y1 = 2 * cur[0] - last_quad_ctrl[0], 2 * cur[1] - last_quad_ctrl[1]
            else:
                x1, y1 = cur
            path.quad_to(x1, y1, x, y)
            cur, last_quad_ctrl = (x, y), (x1, y1)
        elif C == "A":
            rx, ry, rot, large, sweep, x, y = read_nums(7)
            if is_rel:
                x, y = cur[0] + x, cur[1] + y
            _append_arc(path, cur, (rx, ry), rot, bool(large), bool(sweep), (x, y))
            cur = (x, y)
        elif C == "Z":
            path.close()
            cur = start
        else:
            raise AardvarkImportError(f"Unsupported SVG path command: {tok!r}")
    return path


def _append_arc(path: Path, p0, radii, rot_deg, large_arc, sweep, p1) -> None:
    """SVG elliptical-arc-to, converted into cubic Bezier segments via the
    standard endpoint -> centre parameterisation (SVG spec appendix F.6)."""
    rx, ry = abs(radii[0]), abs(radii[1])
    x0, y0 = p0
    x1, y1 = p1
    if rx == 0 or ry == 0 or (x0 == x1 and y0 == y1):
        path.line_to(x1, y1)
        return
    phi = math.radians(rot_deg)
    cos_phi, sin_phi = math.cos(phi), math.sin(phi)
    dx2, dy2 = (x0 - x1) / 2.0, (y0 - y1) / 2.0
    x1p = cos_phi * dx2 + sin_phi * dy2
    y1p = -sin_phi * dx2 + cos_phi * dy2

    lam = (x1p ** 2) / (rx ** 2) + (y1p ** 2) / (ry ** 2)
    if lam > 1:
        s = math.sqrt(lam)
        rx, ry = rx * s, ry * s

    sign = -1 if large_arc == sweep else 1
    num = rx ** 2 * ry ** 2 - rx ** 2 * y1p ** 2 - ry ** 2 * x1p ** 2
    den = rx ** 2 * y1p ** 2 + ry ** 2 * x1p ** 2
    co = sign * math.sqrt(max(0.0, num / den)) if den else 0.0
    cxp = co * (rx * y1p) / ry
    cyp = -co * (ry * x1p) / rx
    cx = cos_phi * cxp - sin_phi * cyp + (x0 + x1) / 2.0
    cy = sin_phi * cxp + cos_phi * cyp + (y0 + y1) / 2.0

    def angle(ux, uy, vx, vy) -> float:
        dot = ux * vx + uy * vy
        length = math.hypot(ux, uy) * math.hypot(vx, vy)
        a = math.acos(max(-1.0, min(1.0, dot / length))) if length else 0.0
        return -a if (ux * vy - uy * vx) < 0 else a

    theta1 = angle(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry)
    dtheta = angle((x1p - cxp) / rx, (y1p - cyp) / ry, (-x1p - cxp) / rx, (-y1p - cyp) / ry)
    if not sweep and dtheta > 0:
        dtheta -= 2 * math.pi
    elif sweep and dtheta < 0:
        dtheta += 2 * math.pi

    n_segments = max(1, int(math.ceil(abs(dtheta) / (math.pi / 2))))
    delta = dtheta / n_segments
    t = theta1
    for _ in range(n_segments):
        t2 = t + delta
        alpha = math.tan(delta / 4.0) * 4.0 / 3.0

        def pt(theta):
            ex = cx + rx * math.cos(theta) * cos_phi - ry * math.sin(theta) * sin_phi
            ey = cy + rx * math.cos(theta) * sin_phi + ry * math.sin(theta) * cos_phi
            return ex, ey

        def deriv(theta):
            dx = -rx * math.sin(theta) * cos_phi - ry * math.cos(theta) * sin_phi
            dy = -rx * math.sin(theta) * sin_phi + ry * math.cos(theta) * cos_phi
            return dx, dy

        p_start = pt(t)
        p_end = pt(t2)
        d_start = deriv(t)
        d_end = deriv(t2)
        c1 = (p_start[0] + alpha * d_start[0], p_start[1] + alpha * d_start[1])
        c2 = (p_end[0] - alpha * d_end[0], p_end[1] - alpha * d_end[1])
        path.curve_to(c1[0], c1[1], c2[0], c2[1], p_end[0], p_end[1])
        t = t2


# ------------------------------------------------------------------ import
class SvgImporter:
    def __init__(self) -> None:
        self.diagnostics = ImportDiagnostics()
        self._gradients: dict[str, LinearGradient | RadialGradient] = {}
        self._clip_paths: dict[str, Path] = {}
        self._document: Document | None = None

    def import_document(self, svg_text: str) -> Document:
        if "<!DOCTYPE" in svg_text[:2000]:
            raise AardvarkImportError(
                "Refusing to parse an SVG with a DOCTYPE declaration (XML entity-expansion risk).",
                details={"capability": "svg-doctype-blocked"},
            )
        root = ET.fromstring(svg_text)
        width = _num(root.get("width"), 800.0)
        height = _num(root.get("height"), 600.0)
        view_box = root.get("viewBox")
        if view_box:
            parts = [float(v) for v in re.findall(r"[-+]?[0-9]*\.?[0-9]+", view_box)]
            if len(parts) == 4:
                width, height = parts[2], parts[3]

        doc = Document(width=width, height=height, title="Imported SVG")
        layer = doc.active_layer
        self._document = doc

        self._collect_defs(root)

        for child in root:
            tag = _tag(child)
            if tag in ("defs", "title", "desc", "metadata", "script", "style"):
                continue
            obj = self._parse_element(child)
            if obj is not None:
                layer.add(obj)
        return doc

    def _collect_defs(self, root: ET.Element) -> None:
        for el in root.iter():
            tag = _tag(el)
            if tag in ("linearGradient", "radialGradient"):
                grad_id = el.get("id")
                if grad_id:
                    self._gradients[grad_id] = self._parse_gradient(el, tag)
            elif tag == "clipPath":
                clip_id = el.get("id")
                if clip_id:
                    subpaths = []
                    for shape_el in el:
                        p = self._element_to_path(shape_el)
                        if p is not None:
                            subpaths.append(p)
                    if subpaths:
                        self._clip_paths[clip_id] = Path.combine(subpaths)

    def _parse_gradient(self, el: ET.Element, tag: str):
        stops = []
        for stop_el in el:
            if _tag(stop_el) != "stop":
                continue
            offset_str = stop_el.get("offset", "0")
            offset = float(offset_str.rstrip("%")) / 100.0 if "%" in offset_str else float(offset_str)
            style = stop_el.get("style", "")
            style_dict = dict(kv.split(":") for kv in style.split(";") if ":" in kv)
            color_str = style_dict.get("stop-color", stop_el.get("stop-color", "#000000"))
            opacity = float(style_dict.get("stop-opacity", stop_el.get("stop-opacity", "1")))
            color = parse_color(color_str) or Color.black()
            stops.append(GradientStop(offset, color, opacity))

        spread = {"pad": SpreadMode.PAD, "reflect": SpreadMode.REFLECT, "repeat": SpreadMode.REPEAT}.get(
            el.get("spreadMethod", "pad"), SpreadMode.PAD
        )
        transform = parse_transform(el.get("gradientTransform"))
        if tag == "linearGradient":
            from aardvark.geometry.point import Point

            x1, y1 = _num(el.get("x1"), 0.0), _num(el.get("y1"), 0.0)
            x2, y2 = _num(el.get("x2"), 100.0), _num(el.get("y2"), 0.0)
            return LinearGradient(Point(x1, y1), Point(x2, y2), tuple(stops), spread, transform)
        from aardvark.geometry.point import Point

        cx, cy, r = _num(el.get("cx"), 50.0), _num(el.get("cy"), 50.0), _num(el.get("r"), 50.0)
        return RadialGradient(Point(cx, cy), r, None, tuple(stops), spread, transform)

    def _resolve_paint(self, value: str | None, opacity_attr: str | None):
        if value is None:
            return None
        m = re.match(r"url\(#([^)]+)\)", value.strip())
        if m:
            return self._gradients.get(m.group(1))
        return parse_color(value, opacity_attr)

    def _element_to_path(self, el: ET.Element) -> Path | None:
        tag = _tag(el)
        if tag == "path":
            d = el.get("d")
            return parse_path_data(d) if d else None
        if tag == "rect":
            x, y = _num(el.get("x")), _num(el.get("y"))
            w, h = _num(el.get("width")), _num(el.get("height"))
            rx, ry = _num(el.get("rx"), 0.0), _num(el.get("ry"), 0.0)
            from aardvark.shapes.rectangle import Rectangle

            return Rectangle(x=x, y=y, width=w, height=h, corner_radius=max(rx, ry)).to_path()
        if tag == "circle":
            from aardvark.shapes.ellipse import Circle

            return Circle(cx=_num(el.get("cx")), cy=_num(el.get("cy")), radius=_num(el.get("r"))).to_path()
        if tag == "ellipse":
            from aardvark.shapes.ellipse import Ellipse

            return Ellipse(cx=_num(el.get("cx")), cy=_num(el.get("cy")), rx=_num(el.get("rx")), ry=_num(el.get("ry"))).to_path()
        if tag == "line":
            p = Path()
            p.move_to(_num(el.get("x1")), _num(el.get("y1")))
            p.line_to(_num(el.get("x2")), _num(el.get("y2")))
            return p
        if tag in ("polygon", "polyline"):
            pts_str = el.get("points", "")
            nums = [float(n) for n in re.findall(r"[-+]?[0-9]*\.?[0-9]+(?:[eE][-+]?[0-9]+)?", pts_str)]
            pts = list(zip(nums[0::2], nums[1::2]))
            if not pts:
                return None
            p = Path()
            p.move_to(*pts[0])
            for pt in pts[1:]:
                p.line_to(*pt)
            if tag == "polygon":
                p.close()
            return p
        return None

    def _parse_style(self, el: ET.Element) -> Style:
        style_attr = el.get("style", "")
        style_dict = dict(kv.split(":", 1) for kv in style_attr.split(";") if ":" in kv)

        def attr(name: str, default: str | None = None) -> str | None:
            return style_dict.get(name, el.get(name, default))

        fill_paint = self._resolve_paint(attr("fill", "#000000"), attr("fill-opacity"))
        fill = Fill(fill_paint, 1.0, attr("fill-rule", "nonzero") or "nonzero")

        stroke = None
        stroke_paint = self._resolve_paint(attr("stroke"), attr("stroke-opacity"))
        if stroke_paint is not None:
            cap_map = {"butt": LineCap.BUTT, "round": LineCap.ROUND, "square": LineCap.SQUARE}
            join_map = {"miter": LineJoin.MITER, "round": LineJoin.ROUND, "bevel": LineJoin.BEVEL}
            dash_str = attr("stroke-dasharray")
            dash = [float(v) for v in re.findall(r"[-+]?[0-9]*\.?[0-9]+", dash_str)] if dash_str and dash_str != "none" else []
            stroke = Stroke(
                stroke_paint, _num(attr("stroke-width"), 1.0), 1.0,
                cap_map.get(attr("stroke-linecap", "butt"), LineCap.BUTT),
                join_map.get(attr("stroke-linejoin", "miter"), LineJoin.MITER),
                _num(attr("stroke-miterlimit"), 4.0), dash, _num(attr("stroke-dashoffset"), 0.0),
            )
        opacity = _num(attr("opacity"), 1.0)
        return Style(fill=fill, stroke=stroke, opacity=opacity)

    def _parse_element(self, el: ET.Element):
        tag = _tag(el)
        if tag in ("script",):
            self.diagnostics.warn("Skipped <script> element (not executed, per import security policy)")
            return None

        transform = parse_transform(el.get("transform"))

        if tag == "g":
            group = Group()
            group.transform = Transform(transform)
            for child in el:
                obj = self._parse_element(child)
                if obj is not None:
                    group.add(obj)
            clip_ref = el.get("clip-path")
            if clip_ref:
                m = re.match(r"url\(#([^)]+)\)", clip_ref)
                if m and m.group(1) in self._clip_paths:
                    group.clip_path = self._clip_paths[m.group(1)]
            return group

        if tag == "image":
            href = el.get(f"{_XLINK_NS}href") or el.get("href")
            if not href or not href.startswith("data:"):
                self.diagnostics.warn(f"Skipped <image> with non-embedded href (no network fetch performed): {href!r}")
                return None
            import base64

            header, b64data = href.split(",", 1)
            data = base64.b64decode(b64data)
            from aardvark.images.loader import probe_image

            meta = probe_image(data)
            asset_id = self._document.assets.register_image(data=data, **meta)
            img = Image(
                asset_id=asset_id, x=_num(el.get("x")), y=_num(el.get("y")), width=_num(el.get("width")), height=_num(el.get("height")),
                source_width=meta["width"], source_height=meta["height"],
            )
            img.transform = Transform(transform)
            return img

        if tag == "text":
            content = "".join(el.itertext()).strip()
            style = self._parse_style(el)
            txt = Text(
                content=content, x=_num(el.get("x")), y=_num(el.get("y")), size=_num(el.get("font-size"), 16.0),
                font_family=el.get("font-family", "DejaVu Sans"),
            )
            txt.style = style
            txt.transform = Transform(transform)
            return txt

        path = self._element_to_path(el)
        if path is None:
            if tag not in ("defs", "clipPath", "linearGradient", "radialGradient", "symbol", "use"):
                self.diagnostics.warn(f"Skipped unsupported element <{tag}>")
            return None

        from aardvark.document.scene import GenericPathObject

        obj = GenericPathObject(path_data=path)
        obj.style = self._parse_style(el)
        obj.transform = Transform(transform)
        return obj


def import_svg(svg_text: str) -> Document:
    return SvgImporter().import_document(svg_text)


def import_svg_file(path: str) -> Document:
    from pathlib import Path as FsPath

    return import_svg(FsPath(path).read_text(encoding="utf-8"))
