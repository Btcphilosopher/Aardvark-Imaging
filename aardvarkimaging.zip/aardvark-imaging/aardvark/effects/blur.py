"""Gaussian blur (spec section 40), built on Pillow's own (real, not faked)
Gaussian blur filter."""

from __future__ import annotations

from PIL import Image as PILImage
from PIL import ImageFilter


def gaussian_blur(image: PILImage.Image, radius: float) -> PILImage.Image:
    if radius <= 0:
        return image
    return image.filter(ImageFilter.GaussianBlur(radius))
