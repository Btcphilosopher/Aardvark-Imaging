"""Drop/inner shadow rasterisation (spec section 40).

Operates on a coverage mask (the shape's fill rasterised to alpha) rather
than re-deriving geometry, so it works identically for any shape — paths,
text outlines, boolean-op results — without needing to know what produced
the mask.
"""

from __future__ import annotations

import numpy as np
from PIL import Image as PILImage

from aardvark.effects.blur import gaussian_blur
from aardvark.style.shadow import Shadow


def render_shadow_field(coverage_mask: np.ndarray, shadow: Shadow, factor: int) -> np.ndarray:
    """``coverage_mask`` is (H, W) float in [0, 1]. Returns an (H, W, 4)
    float64 RGBA field: the shape's silhouette, offset, coloured and blurred."""
    h, w = coverage_mask.shape
    color = shadow.color
    field = np.zeros((h, w, 4), dtype=np.float64)
    field[..., 0], field[..., 1], field[..., 2] = color.r, color.g, color.b
    field[..., 3] = coverage_mask * color.a

    img = PILImage.fromarray(np.clip(field * 255, 0, 255).astype(np.uint8), mode="RGBA")
    dx = int(round(shadow.offset_x * factor))
    dy = int(round(shadow.offset_y * factor))
    shifted = PILImage.new("RGBA", img.size, (0, 0, 0, 0))
    shifted.paste(img, (dx, dy))
    blurred = gaussian_blur(shifted, max(0.0, shadow.blur_radius) * factor)
    return np.asarray(blurred).astype(np.float64) / 255.0


def inner_shadow_field(coverage_mask: np.ndarray, shadow: Shadow, factor: int) -> np.ndarray:
    """Inner shadow: the shadow silhouette masked to *within* the original
    shape (shadow cast from the shape's own edge inward)."""
    outer = render_shadow_field(1.0 - coverage_mask, shadow, factor)
    outer[..., 3] *= coverage_mask
    return outer
