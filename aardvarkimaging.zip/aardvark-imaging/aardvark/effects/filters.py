"""Effect/filter registry (spec sections 40-41).

Blend modes are reported here rather than re-implemented: the actual math
lives in ``aardvark.render.compositor`` (the renderer needs it inline,
per-pixel, for every composite); this module is the capability surface the
API/inspector queries.
"""

from __future__ import annotations

from aardvark.errors import CapabilityError
from aardvark.style.opacity import BlendMode

_KNOWN_FILTERS = {"blur", "drop-shadow", "inner-shadow", "outer-glow", "inner-glow"}


def supported_blend_modes() -> tuple[str, ...]:
    return tuple(m.value for m in BlendMode.supported())


def require_filter_supported(name: str) -> None:
    if name not in _KNOWN_FILTERS:
        raise CapabilityError(f"Unknown or unimplemented filter: {name!r}", details={"filter": name, "known": sorted(_KNOWN_FILTERS)})
