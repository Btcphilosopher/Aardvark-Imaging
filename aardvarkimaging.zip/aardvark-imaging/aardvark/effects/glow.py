"""Outer/inner glow (spec section 40): a zero-offset, optionally-spread
shadow — implemented on the same coverage-mask pipeline as
``aardvark.effects.shadow`` rather than duplicating the blur/composite math.
"""

from __future__ import annotations

import numpy as np
from PIL import Image as PILImage
from PIL import ImageFilter

from aardvark.effects.shadow import inner_shadow_field, render_shadow_field
from aardvark.style.color import Color
from aardvark.style.shadow import Shadow


def glow_field(coverage_mask: np.ndarray, color: Color, radius: float, factor: int, *, spread: float = 0.0, inner: bool = False) -> np.ndarray:
    mask = coverage_mask
    if spread > 0:
        img = PILImage.fromarray((mask * 255).astype(np.uint8), mode="L")
        size = max(1, int(round(spread * factor)))
        img = img.filter(ImageFilter.MaxFilter(size * 2 + 1))
        mask = np.asarray(img).astype(np.float64) / 255.0

    shadow = Shadow(offset_x=0.0, offset_y=0.0, blur_radius=radius, spread=0.0, color=color, inner=inner)
    fn = inner_shadow_field if inner else render_shadow_field
    return fn(mask, shadow, factor)
