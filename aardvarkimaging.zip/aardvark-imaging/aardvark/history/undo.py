"""The undo stack and atomic transactions (spec sections 49-50)."""

from __future__ import annotations

from aardvark.errors import DocumentError
from aardvark.history.command import Command


class Transaction(Command):
    """Groups several commands into one atomic undo step.

    If any sub-command's ``execute()`` raises, every sub-command that
    already ran is undone (in reverse order) before the exception
    propagates — the document is left exactly as it was, matching the
    "Boolean Union either completes or leaves the document unchanged"
    requirement (spec section 50).
    """

    def __init__(self, commands: list[Command], description: str = "") -> None:
        self.commands = commands
        self.description = description or f"{len(commands)} operations"
        self._executed: list[Command] = []

    def execute(self) -> None:
        self._executed = []
        try:
            for cmd in self.commands:
                cmd.execute()
                self._executed.append(cmd)
        except Exception:
            for cmd in reversed(self._executed):
                cmd.undo()
            self._executed = []
            raise

    def undo(self) -> None:
        for cmd in reversed(self.commands):
            cmd.undo()


class UndoStack:
    def __init__(self, limit: int = 500) -> None:
        self.limit = limit
        self._undo: list[Command] = []
        self._redo: list[Command] = []

    def do(self, command: Command) -> None:
        command.execute()
        self._undo.append(command)
        if len(self._undo) > self.limit:
            self._undo.pop(0)
        self._redo.clear()

    def do_many(self, commands: list[Command], description: str = "") -> None:
        self.do(Transaction(commands, description))

    @property
    def can_undo(self) -> bool:
        return bool(self._undo)

    @property
    def can_redo(self) -> bool:
        return bool(self._redo)

    def undo(self) -> Command:
        if not self._undo:
            raise DocumentError("Nothing to undo")
        cmd = self._undo.pop()
        cmd.undo()
        self._redo.append(cmd)
        return cmd

    def redo(self) -> Command:
        if not self._redo:
            raise DocumentError("Nothing to redo")
        cmd = self._redo.pop()
        cmd.execute()
        self._undo.append(cmd)
        return cmd

    def clear(self) -> None:
        self._undo.clear()
        self._redo.clear()

    def history_labels(self) -> list[str]:
        return [c.description for c in self._undo]
