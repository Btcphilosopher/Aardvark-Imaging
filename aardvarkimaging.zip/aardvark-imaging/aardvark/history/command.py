"""The undo/redo command architecture (spec section 49)."""

from __future__ import annotations

import math
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Callable

from aardvark.document.scene import GenericPathObject, GraphicContainer, GraphicObject, Group
from aardvark.errors import DocumentError
from aardvark.geometry.matrix import Matrix
from aardvark.style import Fill, Stroke


class Command(ABC):
    description: str = ""

    @abstractmethod
    def execute(self) -> None: ...

    @abstractmethod
    def undo(self) -> None: ...


# ------------------------------------------------------------- transforms
class _TransformCommand(Command):
    """Base for the Move/Resize/Rotate commands: each subclass computes its
    own ``new_matrix`` in ``__init__`` and shares this execute/undo pair."""

    obj: GraphicObject
    old_matrix: Matrix
    new_matrix: Matrix

    def execute(self) -> None:
        self.obj.transform.matrix = self.new_matrix

    def undo(self) -> None:
        self.obj.transform.matrix = self.old_matrix


class MoveObject(_TransformCommand):
    def __init__(self, obj: GraphicObject, dx: float, dy: float) -> None:
        self.obj = obj
        self.old_matrix = obj.transform.matrix
        self.new_matrix = obj.transform.matrix.compose(Matrix.translation(dx, dy))
        self.description = f"Move {obj.id} by ({dx}, {dy})"


class ResizeObject(_TransformCommand):
    def __init__(self, obj: GraphicObject, sx: float, sy: float, origin: tuple[float, float] = (0.0, 0.0)) -> None:
        self.obj = obj
        self.old_matrix = obj.transform.matrix
        self.new_matrix = obj.transform.matrix.compose(Matrix.scaling(sx, sy, origin))
        self.description = f"Resize {obj.id} by ({sx}, {sy})"


class RotateObject(_TransformCommand):
    def __init__(self, obj: GraphicObject, degrees: float, origin: tuple[float, float] = (0.0, 0.0)) -> None:
        self.obj = obj
        self.old_matrix = obj.transform.matrix
        self.new_matrix = obj.transform.matrix.compose(Matrix.rotation(math.radians(degrees), origin))
        self.description = f"Rotate {obj.id} by {degrees}deg"


class SetTransform(_TransformCommand):
    """Replaces an object's transform matrix outright (rather than composing
    a delta onto it) — what the JSON API's ``transform_object`` uses, since a
    remote client naturally sends the whole new matrix, not a delta."""

    def __init__(self, obj: GraphicObject, new_matrix: Matrix) -> None:
        self.obj = obj
        self.old_matrix = obj.transform.matrix
        self.new_matrix = new_matrix
        self.description = f"Set transform on {obj.id}"


# ------------------------------------------------------------------ style
@dataclass
class ChangeFill(Command):
    obj: GraphicObject
    new_fill: Fill
    old_fill: Fill = field(init=False)

    def __post_init__(self) -> None:
        self.old_fill = self.obj.style.fill
        self.description = f"Change fill on {self.obj.id}"

    def execute(self) -> None:
        self.obj.style.fill = self.new_fill

    def undo(self) -> None:
        self.obj.style.fill = self.old_fill


@dataclass
class ChangeStroke(Command):
    obj: GraphicObject
    new_stroke: Stroke | None
    old_stroke: Stroke | None = field(init=False)

    def __post_init__(self) -> None:
        self.old_stroke = self.obj.style.stroke
        self.description = f"Change stroke on {self.obj.id}"

    def execute(self) -> None:
        self.obj.style.stroke = self.new_stroke

    def undo(self) -> None:
        self.obj.style.stroke = self.old_stroke


# ------------------------------------------------------------- add/delete
@dataclass
class AddObject(Command):
    container: GraphicContainer
    obj: GraphicObject
    index: int | None = None

    def __post_init__(self) -> None:
        self.description = f"Add {self.obj.kind} {self.obj.id}"

    def execute(self) -> None:
        self.container.add(self.obj, self.index)

    def undo(self) -> None:
        self.container.remove(self.obj)


@dataclass
class DeleteObject(Command):
    container: GraphicContainer
    obj: GraphicObject
    _index: int = field(init=False, default=0)

    def __post_init__(self) -> None:
        self.description = f"Delete {self.obj.kind} {self.obj.id}"

    def execute(self) -> None:
        self._index = self.container.index_of(self.obj)
        self.container.remove(self.obj)

    def undo(self) -> None:
        self.container.add(self.obj, self._index)


# --------------------------------------------------------- group/ungroup
@dataclass
class GroupObjects(Command):
    container: GraphicContainer
    objects: list[GraphicObject]
    group: Group = field(init=False)
    _original: list[tuple[GraphicContainer, int]] = field(init=False, default_factory=list)
    _insert_index: int = field(init=False, default=0)

    def __post_init__(self) -> None:
        self.description = f"Group {len(self.objects)} objects"

    def execute(self) -> None:
        if not self.objects:
            raise DocumentError("Cannot group an empty selection")
        self._original = [(obj.parent, obj.parent.index_of(obj)) for obj in self.objects]
        self._insert_index = min(idx for _, idx in self._original)
        self.group = Group()
        # Remove highest-index-first so earlier indices in the same
        # container stay valid while we remove later ones.
        for obj, (parent, _idx) in sorted(zip(self.objects, self._original), key=lambda p: -p[1][1]):
            parent.remove(obj)
        for obj in self.objects:
            self.group.add(obj)
        self.container.add(self.group, self._insert_index)

    def undo(self) -> None:
        self.container.remove(self.group)
        for obj in list(self.group.children):
            self.group.remove(obj)
        for obj, (parent, idx) in sorted(zip(self.objects, self._original), key=lambda p: p[1][1]):
            parent.add(obj, idx)


@dataclass
class UngroupObjects(Command):
    """The exact inverse of :class:`GroupObjects`: removes ``group`` from
    ``container`` and reinserts its children directly into ``container`` at
    the group's former position, in their original order."""

    container: GraphicContainer
    group: Group
    _group_index: int = field(init=False, default=0)
    _children: list[GraphicObject] = field(init=False, default_factory=list)

    def __post_init__(self) -> None:
        self.description = f"Ungroup {self.group.id}"

    def execute(self) -> None:
        self._group_index = self.container.index_of(self.group)
        self._children = list(self.group.children)
        for child in self._children:
            self.group.remove(child)
        self.container.remove(self.group)
        for offset, child in enumerate(self._children):
            self.container.add(child, self._group_index + offset)

    def undo(self) -> None:
        for child in self._children:
            self.container.remove(child)
        self.container.add(self.group, self._group_index)
        for child in self._children:
            self.group.add(child)


# ---------------------------------------------------------- boolean ops
@dataclass
class BooleanOperation(Command):
    """Runs a boolean op (union/difference/intersection/exclusion, from
    ``aardvark.boolean``) across ``objects`` (all sharing one container),
    replacing them with a single :class:`GenericPathObject`. Atomic: if the
    boolean op itself raises, the document is left completely unchanged
    (nothing is removed before the new geometry is successfully computed).
    """

    container: GraphicContainer
    objects: list[GraphicObject]
    op: Callable  # e.g. aardvark.boolean.union.union — (Path, Path) -> Path
    result: GenericPathObject = field(init=False)
    _original: list[tuple[GraphicContainer, int]] = field(init=False, default_factory=list)
    _insert_index: int = field(init=False, default=0)

    def __post_init__(self) -> None:
        self.description = f"Boolean op on {len(self.objects)} objects"

    def execute(self) -> None:
        if len(self.objects) < 2:
            raise DocumentError("Boolean operations need at least two objects")
        world_paths = [obj.to_path().transformed(obj.world_matrix()) for obj in self.objects]
        computed = world_paths[0]
        for p in world_paths[1:]:
            computed = self.op(computed, p)  # may raise — nothing mutated yet if it does

        self._original = [(obj.parent, obj.parent.index_of(obj)) for obj in self.objects]
        self._insert_index = min(idx for _, idx in self._original)
        for obj, (parent, _idx) in sorted(zip(self.objects, self._original), key=lambda p: -p[1][1]):
            parent.remove(obj)

        self.result = GenericPathObject(path_data=computed)
        self.result.style = self.objects[0].style.copy()
        self.container.add(self.result, self._insert_index)

    def undo(self) -> None:
        self.container.remove(self.result)
        for obj, (parent, idx) in sorted(zip(self.objects, self._original), key=lambda p: p[1][1]):
            parent.add(obj, idx)
