"""The rendering pipeline: scene flattening, the CPU raster backend, blend
modes, antialiasing, and the top-level Renderer."""

from aardvark.render.renderer import RenderJob, RenderRequest, Renderer
from aardvark.render.antialias import supersample_factor
from aardvark.render.vector import flatten_document, flatten_page

__all__ = ["Renderer", "RenderRequest", "RenderJob", "supersample_factor", "flatten_document", "flatten_page"]
