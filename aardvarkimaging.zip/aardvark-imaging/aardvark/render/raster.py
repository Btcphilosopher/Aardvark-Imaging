"""The CPU raster backend (spec sections 34-39, 76: "the first implementation
may use a CPU renderer" — GPU/Metal backends are a future addition behind
the same :class:`~aardvark.render.renderer.Renderer` interface).

Antialiasing is done by supersampling: draw at ``factor``x resolution with
exact (hard-edged) polygon fills, then box-filter down (spec section 36).
Fill-rule (nonzero/evenodd) is implemented with a real scanline rasteriser
so holes/self-intersections (glyph counters, star polygons, boolean-op
results) render correctly — Pillow's own polygon fill does not support
winding rules, so it is not used for path fills.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from PIL import Image as PILImage

from aardvark.geometry.matrix import Matrix
from aardvark.images.crop import apply_crop
from aardvark.images.placement import placement_matrix
from aardvark.paths.flatten import flatten_path_closed_rings
from aardvark.paths.path import Path
from aardvark.render.compositor import composite_over, downsample_supersampled
from aardvark.style import Color, LinearGradient, Pattern, RadialGradient
from aardvark.style.gradient import _apply_spread


def polygon_mask(width: int, height: int, rings: list[list[tuple[float, float]]], fill_rule: str = "nonzero") -> np.ndarray:
    """Rasterise ``rings`` (each a closed polygon in pixel space) into a
    (height, width) float32 mask in {0, 1} using a real scanline fill,
    honouring nonzero/evenodd winding across all rings at once."""
    mask = np.zeros((height, width), dtype=np.float32)
    ex0, ey0, ex1, ey1 = [], [], [], []
    for ring in rings:
        n = len(ring)
        if n < 2:
            continue
        for i in range(n):
            x0, y0 = ring[i]
            x1, y1 = ring[(i + 1) % n]
            if y0 != y1:
                ex0.append(x0)
                ey0.append(y0)
                ex1.append(x1)
                ey1.append(y1)
    if not ex0:
        return mask
    ex0a, ey0a, ex1a, ey1a = (np.array(a, dtype=np.float64) for a in (ex0, ey0, ex1, ey1))
    winding = np.where(ey1a > ey0a, 1, -1)
    ymin = np.minimum(ey0a, ey1a)
    ymax = np.maximum(ey0a, ey1a)

    row_lo = max(0, int(math.floor(ymin.min())))
    row_hi = min(height, int(math.ceil(ymax.max())) + 1)

    for row in range(row_lo, row_hi):
        yc = row + 0.5
        active = (ymin <= yc) & (yc < ymax)
        if not np.any(active):
            continue
        t = (yc - ey0a[active]) / (ey1a[active] - ey0a[active])
        xs = ex0a[active] + t * (ex1a[active] - ex0a[active])
        w = winding[active]
        order = np.argsort(xs, kind="stable")
        xs, w = xs[order], w[order]

        if fill_rule == "evenodd":
            inside = np.arange(len(xs)) % 2 == 0
        else:
            cum = np.cumsum(w)
            inside = cum != 0

        row_pixels = mask[row]
        for i in range(len(xs) - 1):
            if inside[i]:
                x_start = max(0, int(math.floor(xs[i] + 0.5)))
                x_end = min(width, int(math.floor(xs[i + 1] + 0.5)))
                if x_end > x_start:
                    row_pixels[x_start:x_end] = 1.0
    return mask


# ---------------------------------------------------------------- paints
def _sample_linear_field(xs: np.ndarray, ys: np.ndarray, g: LinearGradient) -> np.ndarray:
    inv = g.transform.inverse()
    pts = inv.apply_points(np.stack([xs.ravel(), ys.ravel()], axis=-1))
    lx, ly = pts[:, 0], pts[:, 1]
    dx, dy = g.end.x - g.start.x, g.end.y - g.start.y
    denom = dx * dx + dy * dy
    t = np.zeros_like(lx) if denom <= 1e-12 else ((lx - g.start.x) * dx + (ly - g.start.y) * dy) / denom
    return _sample_stops_field(t, g)


def _sample_radial_field(xs: np.ndarray, ys: np.ndarray, g: RadialGradient) -> np.ndarray:
    inv = g.transform.inverse()
    pts = inv.apply_points(np.stack([xs.ravel(), ys.ravel()], axis=-1))
    lx, ly = pts[:, 0], pts[:, 1]
    r = g.radius if g.radius > 1e-9 else 1e-9
    t = np.hypot(lx - g.center.x, ly - g.center.y) / r
    return _sample_stops_field(t, g)


def _sample_stops_field(t: np.ndarray, g: LinearGradient | RadialGradient) -> np.ndarray:
    if not g.stops:
        return np.zeros((t.shape[0], 4), dtype=np.float64)
    spread_t = np.array([_apply_spread(float(v), g.spread) for v in t])
    stops = g.stops
    offsets = np.array([s.offset for s in stops])
    colors = np.array([[s.color.r, s.color.g, s.color.b, s.color.a * s.opacity] for s in stops])
    idx = np.searchsorted(offsets, spread_t, side="right")
    idx = np.clip(idx, 1, len(stops) - 1)
    lo, hi = idx - 1, idx
    span = np.maximum(offsets[hi] - offsets[lo], 1e-9)
    local_t = np.clip((spread_t - offsets[lo]) / span, 0.0, 1.0)
    out = colors[lo] + (colors[hi] - colors[lo]) * local_t[:, None]
    out[..., 3] *= g.opacity
    return out


def paint_to_field(paint, width: int, height: int, bbox_x: int, bbox_y: int) -> np.ndarray:
    """Returns an (height, width, 4) float64 RGBA field for a paint, evaluated
    over pixel centres offset by (bbox_x, bbox_y) in canvas space."""
    ys, xs = np.mgrid[0:height, 0:width]
    xs = (xs + 0.5 + bbox_x).astype(np.float64)
    ys = (ys + 0.5 + bbox_y).astype(np.float64)

    if isinstance(paint, Color):
        field = np.empty((height, width, 4), dtype=np.float64)
        field[..., 0], field[..., 1], field[..., 2], field[..., 3] = paint.r, paint.g, paint.b, paint.a
        return field
    if isinstance(paint, LinearGradient):
        flat = _sample_linear_field(xs, ys, paint)
        return flat.reshape(height, width, 4)
    if isinstance(paint, RadialGradient):
        flat = _sample_radial_field(xs, ys, paint)
        return flat.reshape(height, width, 4)
    if isinstance(paint, Pattern):
        return _sample_pattern_field(paint, xs, ys)
    # None / unrecognised: fully transparent.
    return np.zeros((height, width, 4), dtype=np.float64)


def _sample_pattern_field(pattern: Pattern, xs: np.ndarray, ys: np.ndarray) -> np.ndarray:
    tile_img = render_pattern_tile(pattern)
    tw, th = tile_img.width, tile_img.height
    arr = np.asarray(tile_img).astype(np.float64) / 255.0
    inv = pattern.transform.inverse()
    flat_pts = inv.apply_points(np.stack([xs.ravel(), ys.ravel()], axis=-1))
    lx = flat_pts[:, 0] - pattern.tile_bounds.x
    ly = flat_pts[:, 1] - pattern.tile_bounds.y
    px = np.mod(lx / max(pattern.tile_bounds.width, 1e-6) * tw, tw).astype(np.int64)
    py = np.mod(ly / max(pattern.tile_bounds.height, 1e-6) * th, th).astype(np.int64)
    px = np.clip(px, 0, tw - 1)
    py = np.clip(py, 0, th - 1)
    sampled = arr[py, px]
    sampled[..., 3] *= pattern.opacity
    return sampled.reshape(xs.shape[0], xs.shape[1], 4)


def render_pattern_tile(pattern: Pattern) -> PILImage.Image:
    from aardvark.render.vector import _emit_object

    tw = max(1, int(round(pattern.tile_bounds.width)))
    th = max(1, int(round(pattern.tile_bounds.height)))
    ops = []
    root = Matrix.translation(-pattern.tile_bounds.x, -pattern.tile_bounds.y)
    for obj in pattern.content:
        _emit_object(obj, root, ops)
    backend = RasterBackend(tw, th, supersample=1)
    backend.render_ops(ops)
    return backend.to_image()


# ---------------------------------------------------------------- backend
@dataclass
class _Layer:
    image: np.ndarray  # (H, W, 4) float64
    opacity: float = 1.0
    blend_mode: str = "normal"
    clip_stack_depth: int = 0


class RasterBackend:
    def __init__(self, width: int, height: int, *, supersample: int = 1, background=None, asset_manager=None) -> None:
        self.width, self.height = width, height
        self.factor = supersample
        self.asset_manager = asset_manager
        self.ss_w, self.ss_h = width * supersample, height * supersample
        # float32, not float64: colour/alpha channels in [0, 1] don't need
        # binary64 precision, and this is the single largest allocation in
        # the renderer (canvas width * height * AA-supersample^2 * 4
        # channels) — halving it matters a lot more here than the geometry
        # layer's float64 requirement (spec section 58) does, which is about
        # coordinate precision, not pixel colour storage.
        base = np.zeros((self.ss_h, self.ss_w, 4), dtype=np.float32)
        if background is not None:
            base[..., 0], base[..., 1], base[..., 2], base[..., 3] = (
                background.r, background.g, background.b, background.a
            )
        self._stack: list[_Layer] = [_Layer(base)]
        # Each entry is (x0, y0, x1, y1, array): a clip mask cropped to its
        # own bounding box in canvas pixel space, not a full-canvas array —
        # allocating a full W*H mask per clip (and per *fill*, before this
        # was fixed) made anything beyond a few hundred objects prohibitively
        # slow. See _current_clip_for_region().
        self._clip_masks: list[tuple[int, int, int, int, np.ndarray]] = []

    # -- public ---------------------------------------------------------
    def render_ops(self, ops: list) -> None:
        from aardvark.render.vector import (
            FillOp, ImageOp, PopClipOp, PopLayerOp, PopMaskOp, PushClipOp, PushLayerOp, PushMaskOp, ShadowOp, StrokeOp,
        )

        for op in ops:
            if isinstance(op, PushLayerOp):
                self._stack.append(_Layer(np.zeros_like(self._stack[-1].image), op.opacity, op.blend_mode))
            elif isinstance(op, PopLayerOp):
                popped = self._stack.pop()
                self._composite_layer(popped)
            elif isinstance(op, PushClipOp):
                self._clip_masks.append(self._rasterize_clip(op.path))
            elif isinstance(op, PopClipOp):
                self._clip_masks.pop()
            elif isinstance(op, PushMaskOp):
                self._apply_vector_mask(op)
            elif isinstance(op, PopMaskOp):
                pass  # mask is applied eagerly in PushMaskOp; nothing to undo
            elif isinstance(op, ShadowOp):
                self._draw_shadow(op)
            elif isinstance(op, FillOp):
                self._fill(op.path, op.paint, op.rule, op.opacity)
            elif isinstance(op, StrokeOp):
                self._fill(op.path, op.paint, "nonzero", op.opacity)
            elif isinstance(op, ImageOp):
                self._draw_image(op)

    def to_image(self) -> PILImage.Image:
        final = downsample_supersampled(self._stack[0].image, self.factor)
        arr8 = np.clip(final * 255.0 + 0.5, 0, 255).astype(np.uint8)
        return PILImage.fromarray(arr8, mode="RGBA")

    # -- internals ------------------------------------------------------
    def _ring_pixel_bounds(self, rings: list[list[tuple[float, float]]]) -> tuple[int, int, int, int] | None:
        """The integer pixel bbox covering ``rings``, clamped to the canvas.
        None if there's nothing to draw (empty, or entirely off-canvas)."""
        xs = [x for ring in rings for x, _ in ring]
        ys = [y for ring in rings for _, y in ring]
        if not xs:
            return None
        x0 = max(0, int(math.floor(min(xs))))
        y0 = max(0, int(math.floor(min(ys))))
        x1 = min(self.ss_w, int(math.ceil(max(xs))) + 1)
        y1 = min(self.ss_h, int(math.ceil(max(ys))) + 1)
        if x1 <= x0 or y1 <= y0:
            return None
        return x0, y0, x1, y1

    def _current_clip_for_region(self, x0: int, y0: int, x1: int, y1: int) -> np.ndarray | None:
        """Returns a (y1-y0, x1-x0) coverage array combining every active
        clip over just this region, or None if there are no active clips
        (meaning: fully unclipped, skip the multiply)."""
        if not self._clip_masks:
            return None
        h, w = y1 - y0, x1 - x0
        result = np.ones((h, w), dtype=np.float32)
        for cx0, cy0, cx1, cy1, carr in self._clip_masks:
            ox0, oy0 = max(x0, cx0), max(y0, cy0)
            ox1, oy1 = min(x1, cx1), min(y1, cy1)
            if ox1 <= ox0 or oy1 <= oy0:
                return np.zeros((h, w), dtype=np.float32)  # region is entirely outside this clip
            piece = np.zeros((h, w), dtype=np.float32)
            piece[oy0 - y0 : oy1 - y0, ox0 - x0 : ox1 - x0] = carr[oy0 - cy0 : oy1 - cy0, ox0 - cx0 : ox1 - cx0]
            result *= piece
        return result

    def _rasterize_clip(self, path: Path) -> tuple[int, int, int, int, np.ndarray]:
        rings = [[(p.x * self.factor, p.y * self.factor) for p in ring] for ring in flatten_path_closed_rings(path)]
        bbox = self._ring_pixel_bounds(rings)
        if bbox is None:
            return (0, 0, 0, 0, np.zeros((0, 0), dtype=np.float32))
        x0, y0, x1, y1 = bbox
        local_rings = [[(x - x0, y - y0) for x, y in ring] for ring in rings]
        mask = polygon_mask(x1 - x0, y1 - y0, local_rings, path.fill_rule)
        return (x0, y0, x1, y1, mask)

    def _fill(self, path: Path, paint, rule: str, opacity: float) -> None:
        if paint is None or path.is_empty():
            return
        rings = [[(p.x * self.factor, p.y * self.factor) for p in ring] for ring in flatten_path_closed_rings(path)]
        bbox = self._ring_pixel_bounds(rings)
        if bbox is None:
            return
        x0, y0, x1, y1 = bbox
        local_rings = [[(x - x0, y - y0) for x, y in ring] for ring in rings]
        mask = polygon_mask(x1 - x0, y1 - y0, local_rings, rule)

        clip = self._current_clip_for_region(x0, y0, x1, y1)
        if clip is not None:
            mask = mask * clip
        if not np.any(mask):
            return
        field = paint_to_field(_scaled_paint(paint, self.factor), x1 - x0, y1 - y0, x0, y0)
        field[..., 3] *= mask * opacity
        layer = self._stack[-1]
        region = layer.image[y0:y1, x0:x1]
        layer.image[y0:y1, x0:x1] = composite_over(region, field, "normal", 1.0)

    def _draw_shadow(self, op) -> None:
        from aardvark.effects.shadow import inner_shadow_field, render_shadow_field

        rings = [[(p.x * self.factor, p.y * self.factor) for p in ring] for ring in flatten_path_closed_rings(op.path)]
        # Shadows extend beyond the shape's own geometry (blur/offset), so
        # pad the bbox generously rather than reusing the shape's exact bbox.
        pad = (op.shadow.blur_radius + max(abs(op.shadow.offset_x), abs(op.shadow.offset_y)) + 4) * self.factor
        raw_bbox = self._ring_pixel_bounds(rings)
        if raw_bbox is None:
            return
        x0, y0, x1, y1 = raw_bbox
        x0 = max(0, int(x0 - pad))
        y0 = max(0, int(y0 - pad))
        x1 = min(self.ss_w, int(x1 + pad))
        y1 = min(self.ss_h, int(y1 + pad))
        if x1 <= x0 or y1 <= y0:
            return
        local_rings = [[(x - x0, y - y0) for x, y in ring] for ring in rings]
        mask = polygon_mask(x1 - x0, y1 - y0, local_rings, op.path.fill_rule)
        if not np.any(mask):
            return
        shadow_arr = (inner_shadow_field if op.shadow.inner else render_shadow_field)(mask, op.shadow, self.factor)
        clip = self._current_clip_for_region(x0, y0, x1, y1)
        if clip is not None:
            shadow_arr[..., 3] *= clip
        layer = self._stack[-1]
        region = layer.image[y0:y1, x0:x1]
        layer.image[y0:y1, x0:x1] = composite_over(region, shadow_arr, "normal", 1.0)

    def _draw_image(self, op) -> None:
        from aardvark.assets.manager import AssetManager
        from aardvark.images.loader import decode_image

        img_obj = op.image
        pil_img = None
        try:
            asset_mgr: AssetManager | None = getattr(self, "asset_manager", None)
            if asset_mgr is not None and img_obj.asset_id:
                pil_img = asset_mgr.get_decoded(img_obj.asset_id, decode_image)
        except Exception:
            pil_img = None
        if pil_img is None:
            return
        pil_img = pil_img.convert("RGBA")
        crop = img_obj.effective_crop()
        if img_obj.crop is not None:
            pil_img = apply_crop(pil_img, crop)

        place = placement_matrix(pil_img.width, pil_img.height, img_obj.width, img_obj.height, img_obj.fit)
        full_matrix = place.compose(Matrix.translation(img_obj.x, img_obj.y)).compose(op.world_matrix).compose(
            Matrix.scaling(self.factor, self.factor)
        )

        # Rasterise by inverse-mapping destination pixels back into source space.
        dest_bounds = img_obj.local_bounds()
        from aardvark.geometry.rect import Rect

        world_rect_bounds = Rect.from_bounds(dest_bounds).transformed_bounds(op.world_matrix)
        x0 = max(0, int(math.floor(world_rect_bounds.min_x * self.factor)))
        y0 = max(0, int(math.floor(world_rect_bounds.min_y * self.factor)))
        x1 = min(self.ss_w, int(math.ceil(world_rect_bounds.max_x * self.factor)))
        y1 = min(self.ss_h, int(math.ceil(world_rect_bounds.max_y * self.factor)))
        if x1 <= x0 or y1 <= y0:
            return
        inv = full_matrix.inverse()
        yy, xx = np.mgrid[y0:y1, x0:x1]
        pts = inv.apply_points(np.stack([xx.ravel() + 0.5, yy.ravel() + 0.5], axis=-1))
        src_x, src_y = pts[:, 0], pts[:, 1]
        in_bounds = (src_x >= 0) & (src_x < pil_img.width) & (src_y >= 0) & (src_y < pil_img.height)
        src_arr = np.asarray(pil_img).astype(np.float64) / 255.0
        out = np.zeros((y1 - y0, x1 - x0, 4), dtype=np.float64)
        ix = np.clip(src_x.astype(np.int64), 0, pil_img.width - 1)
        iy = np.clip(src_y.astype(np.int64), 0, pil_img.height - 1)
        sampled = src_arr[iy, ix]
        sampled[~in_bounds] = 0.0
        out = sampled.reshape(y1 - y0, x1 - x0, 4)
        out[..., 3] *= op.opacity
        clip = self._current_clip_for_region(x0, y0, x1, y1)
        if clip is not None:
            out[..., 3] *= clip
        layer = self._stack[-1]
        region = layer.image[y0:y1, x0:x1]
        layer.image[y0:y1, x0:x1] = composite_over(region, out, "normal", 1.0)

    def _apply_vector_mask(self, op) -> None:
        # A mask can, in principle, cover the whole canvas (its content
        # isn't necessarily near the masked object), so this one stays a
        # full-canvas render — masks are far rarer per document than plain
        # fills, so this hasn't been worth the same bbox-cropping treatment.
        sub = RasterBackend(self.width, self.height, supersample=self.factor, asset_manager=self.asset_manager)
        sub.render_ops(op.mask_ops)
        mask_rgba = sub._stack[0].image
        if op.mode == "luminance":
            coverage = (0.2126 * mask_rgba[..., 0] + 0.7152 * mask_rgba[..., 1] + 0.0722 * mask_rgba[..., 2]) * mask_rgba[..., 3]
        else:
            coverage = mask_rgba[..., 3]
        self._clip_masks.append((0, 0, self.ss_w, self.ss_h, coverage.astype(np.float32)))

    def _composite_layer(self, popped: "_Layer") -> None:
        base = self._stack[-1]
        base.image = composite_over(base.image, popped.image, popped.blend_mode, popped.opacity)


def _scaled_paint(paint, factor: int):
    """Carry a (already world-space) paint into supersampled pixel space by
    composing the supersample scale into its *transform* only — the paint's
    own start/end/center/radius/tile_bounds values stay exactly as authored.
    (An earlier version of this function scaled those raw fields *and*
    composed the transform, double-applying the factor; fixed here.)"""
    if factor == 1 or paint is None or isinstance(paint, Color):
        return paint
    s = Matrix.scaling(factor, factor)
    if isinstance(paint, LinearGradient):
        return LinearGradient(paint.start, paint.end, paint.stops, paint.spread, paint.transform.compose(s), paint.opacity)
    if isinstance(paint, RadialGradient):
        return RadialGradient(paint.center, paint.radius, paint.focal, paint.stops, paint.spread, paint.transform.compose(s), paint.opacity)
    if isinstance(paint, Pattern):
        return Pattern(paint.tile_bounds, paint.content, paint.transform.compose(s), paint.extend, paint.opacity, paint.id)
    return paint
