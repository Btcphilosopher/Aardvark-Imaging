"""Antialiasing quality levels (spec section 36) — implemented as raster
supersampling: the scene is rasterised at ``factor``x resolution and box-
filtered down, which is exact for polygon edges and a solid approximation
for everything else this engine draws."""

from __future__ import annotations

from aardvark.config import DEFAULT_CONFIG, ANTIALIAS_SUPERSAMPLE, AntialiasQuality


def supersample_factor(quality: AntialiasQuality | str | None = None) -> int:
    q = AntialiasQuality(quality) if quality is not None else DEFAULT_CONFIG.default_antialias
    return ANTIALIAS_SUPERSAMPLE[q]
