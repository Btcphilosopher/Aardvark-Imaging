"""Scene -> draw-command flattening, shared by the raster renderer and every
vector exporter (SVG/PDF) so "what you see" and "what you export" can never
silently diverge (spec section 35: the render pipeline preserves the scene
graph through Transform -> Clip -> Geometry -> Fill -> Stroke -> Effects ->
Compositing -> Output).

Strokes are converted to their equivalent filled outline (``stroke_to_fill``)
*in the object's local space*, then transformed to world space along with
the fill geometry — the mathematically correct order, since it makes a
stroke's width respond to the object's own transform exactly the way SVG/PDF
renderers behave (a non-uniform scale visibly thins/thickens a stroke; that
is correct, not a bug).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Union

from aardvark.document.document import Document
from aardvark.document.page import Page
from aardvark.document.scene import GraphicObject, Group
from aardvark.geometry.matrix import Matrix
from aardvark.images.image import Image
from aardvark.paths.offset import stroke_to_fill
from aardvark.paths.path import Path
from aardvark.style import Color, LinearGradient, Pattern, RadialGradient, Shadow
from aardvark.text.text import Text


def transform_paint(paint, matrix: Matrix):
    """Carry a paint's own geometry (gradient endpoints, pattern tile) from
    the object's local space into whatever space ``matrix`` maps into, by
    composing ``matrix`` onto the paint's existing transform — without this,
    a gradient defined across a shape's local bounds would render at the
    wrong position/scale once the shape (and hence the fill path) is
    transformed into world space."""
    if paint is None or isinstance(paint, Color):
        return paint
    if isinstance(paint, LinearGradient):
        return LinearGradient(paint.start, paint.end, paint.stops, paint.spread, paint.transform.compose(matrix), paint.opacity)
    if isinstance(paint, RadialGradient):
        return RadialGradient(
            paint.center, paint.radius, paint.focal, paint.stops, paint.spread, paint.transform.compose(matrix), paint.opacity
        )
    if isinstance(paint, Pattern):
        return Pattern(paint.tile_bounds, paint.content, paint.transform.compose(matrix), paint.extend, paint.opacity, paint.id)
    return paint


@dataclass(slots=True)
class FillOp:
    path: Path  # already in world space
    paint: object  # Color | LinearGradient | RadialGradient | Pattern, geometry already in world space
    rule: str
    opacity: float
    object_id: str


@dataclass(slots=True)
class StrokeOp:
    path: Path  # already the stroke outline, in world space, fill-rule nonzero
    paint: object
    opacity: float
    object_id: str


@dataclass(slots=True)
class ShadowOp:
    path: Path  # the shape whose shadow this is (world space)
    shadow: Shadow
    object_id: str


@dataclass(slots=True)
class ImageOp:
    image: Image
    world_matrix: Matrix
    opacity: float
    object_id: str


@dataclass(slots=True)
class PushClipOp:
    path: Path  # world space


@dataclass(slots=True)
class PopClipOp:
    pass


@dataclass(slots=True)
class PushMaskOp:
    mask_ops: list["DrawOp"]
    mode: str


@dataclass(slots=True)
class PopMaskOp:
    pass


@dataclass(slots=True)
class PushLayerOp:
    """Begins an isolated compositing group (spec section 41): everything
    until the matching PopLayerOp is rendered to its own buffer, then
    composited as one unit with ``opacity``/``blend_mode`` — required for
    group opacity to look correct when children overlap."""

    opacity: float
    blend_mode: str
    object_id: str


@dataclass(slots=True)
class PopLayerOp:
    pass


DrawOp = Union[FillOp, StrokeOp, ShadowOp, ImageOp, PushClipOp, PopClipOp, PushMaskOp, PopMaskOp, PushLayerOp, PopLayerOp]


def _emit_object(obj: GraphicObject, parent_matrix: Matrix, ops: list, asset_manager=None) -> None:
    if not obj.visible:
        return
    world_matrix = parent_matrix.compose(obj.transform.matrix)

    needs_layer = obj.style.opacity < 1.0 or obj.style.blend_mode.value != "normal" or isinstance(obj, Group)
    if needs_layer:
        ops.append(PushLayerOp(obj.style.opacity, obj.style.blend_mode.value, obj.id))

    if obj.clip_path is not None:
        ops.append(PushClipOp(obj.clip_path.transformed(world_matrix)))

    if obj.mask is not None:
        mask_ops: list = []
        for child in obj.mask.content:
            _emit_object(child, world_matrix, mask_ops, asset_manager)
        ops.append(PushMaskOp(mask_ops, obj.mask.mode.value))

    for shadow in obj.style.shadows:
        try:
            local_path = obj.to_path()
        except Exception:
            local_path = None
        if local_path is not None and not local_path.is_empty():
            ops.append(ShadowOp(local_path.transformed(world_matrix), shadow, obj.id))

    if isinstance(obj, Image):
        ops.append(ImageOp(obj, world_matrix, 1.0, obj.id))
    elif isinstance(obj, Group):
        for child in obj.children:
            _emit_object(child, world_matrix, ops, asset_manager)
    else:
        local_path = obj.to_path(asset_manager) if isinstance(obj, Text) else obj.to_path()
        if not local_path.is_empty():
            if obj.style.fill.paint is not None:
                fill = obj.style.fill
                ops.append(
                    FillOp(
                        local_path.transformed(world_matrix),
                        transform_paint(fill.paint, world_matrix),
                        rule=fill.rule,
                        opacity=fill.opacity,
                        object_id=obj.id,
                    )
                )
            if obj.style.stroke is not None and obj.style.stroke.paint is not None and obj.style.stroke.width > 0:
                s = obj.style.stroke
                outline = stroke_to_fill(
                    local_path,
                    s.width,
                    cap=s.cap.value,
                    join=s.join.value,
                    miter_limit=s.miter_limit,
                    dash_pattern=s.dash_pattern or None,
                    dash_offset=s.dash_offset,
                )
                if not outline.is_empty():
                    ops.append(
                        StrokeOp(outline.transformed(world_matrix), transform_paint(s.paint, world_matrix), s.opacity, obj.id)
                    )

    if obj.mask is not None:
        ops.append(PopMaskOp())
    if obj.clip_path is not None:
        ops.append(PopClipOp())
    if needs_layer:
        ops.append(PopLayerOp())


def flatten_page(page: Page, asset_manager=None) -> list[DrawOp]:
    ops: list[DrawOp] = []
    root = Matrix.identity()
    for layer in page.layers:
        _emit_object(layer, root, ops, asset_manager)
    return ops


def flatten_document(document: Document, page_index: int = 0) -> list[DrawOp]:
    return flatten_page(document.pages[page_index], document.assets)
