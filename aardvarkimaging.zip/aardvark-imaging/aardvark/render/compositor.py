"""Alpha compositing and blend modes (spec sections 35, 41), implemented per
the W3C Compositing and Blending formulas on non-premultiplied float64 RGBA
arrays. All seven spec-listed blend modes are genuinely computed — none of
them fall back to "normal" silently."""

from __future__ import annotations

import numpy as np

from aardvark.style.opacity import BlendMode


def _blend(mode: BlendMode, cb: np.ndarray, cs: np.ndarray) -> np.ndarray:
    if mode == BlendMode.NORMAL:
        return cs
    if mode == BlendMode.MULTIPLY:
        return cb * cs
    if mode == BlendMode.SCREEN:
        return cb + cs - cb * cs
    if mode == BlendMode.DARKEN:
        return np.minimum(cb, cs)
    if mode == BlendMode.LIGHTEN:
        return np.maximum(cb, cs)
    if mode == BlendMode.DIFFERENCE:
        return np.abs(cb - cs)
    if mode == BlendMode.OVERLAY:
        # Overlay(Cb, Cs) = HardLight(Cs, Cb)
        return np.where(cb <= 0.5, 2 * cb * cs, 1 - 2 * (1 - cb) * (1 - cs))
    raise ValueError(f"Unsupported blend mode: {mode!r}")


def composite_over(
    backdrop_rgba: np.ndarray, source_rgba: np.ndarray, blend_mode: BlendMode | str = BlendMode.NORMAL, opacity: float = 1.0
) -> np.ndarray:
    """Composite ``source_rgba`` over ``backdrop_rgba`` (both (H, W, 4) float64
    in [0, 1], non-premultiplied), applying ``blend_mode`` and an extra
    ``opacity`` multiplier on the source's own alpha."""
    mode = BlendMode(blend_mode)
    cb, ab = backdrop_rgba[..., :3], backdrop_rgba[..., 3:4]
    cs, as_ = source_rgba[..., :3], np.clip(source_rgba[..., 3:4] * opacity, 0.0, 1.0)

    blended = _blend(mode, cb, cs)
    # W3C Compositing and Blending formula (source-over with a blend mode):
    # areas with no backdrop (ab == 0) show the source colour unblended.
    ao = as_ + ab * (1 - as_)
    with np.errstate(invalid="ignore", divide="ignore"):
        co = np.where(
            ao > 1e-9,
            ((1 - ab) * as_ * cs + ab * as_ * blended + ab * (1 - as_) * cb) / np.maximum(ao, 1e-9),
            0.0,
        )
    out = np.concatenate([co, ao], axis=-1)
    return np.clip(out, 0.0, 1.0)


def downsample_supersampled(rgba: np.ndarray, factor: int) -> np.ndarray:
    """Box-filter an (H*factor, W*factor, 4) array down to (H, W, 4) — the
    antialiasing step (spec section 36)."""
    if factor <= 1:
        return rgba
    h, w = rgba.shape[0] // factor, rgba.shape[1] // factor
    reshaped = rgba[: h * factor, : w * factor].reshape(h, factor, w, factor, rgba.shape[2])
    return reshaped.mean(axis=(1, 3))
