"""The top-level Renderer (spec sections 34-39).

Keeps the scene graph intact through the whole pipeline: geometry is only
flattened to pixels at the very end, inside :class:`~aardvark.render.raster.RasterBackend`.
This is also the seam a future GPU/Metal backend attaches to (spec section
76) — everything above :meth:`Renderer.render_page` is backend-agnostic
draw commands (``aardvark.render.vector``).
"""

from __future__ import annotations

from dataclasses import dataclass

from PIL import Image as PILImage

from aardvark.config import DEFAULT_CONFIG, AntialiasQuality
from aardvark.document.document import Document
from aardvark.document.page import Page
from aardvark.errors import CancelledError, RenderError
from aardvark.render.antialias import supersample_factor
from aardvark.render.raster import RasterBackend
from aardvark.render.vector import flatten_page


@dataclass(slots=True)
class RenderRequest:
    page_index: int = 0
    scale: float = 1.0  # device pixel ratio: 1x / 2x / 3x (spec section 37)
    antialias: AntialiasQuality = DEFAULT_CONFIG.default_antialias
    background_override: bool = True  # honour Page.background


class RenderJob:
    """A cancellable handle for one render (spec sections 59-60). Cancellation
    is checked between objects, not mid-object — coarse-grained but real: a
    cancelled job stops doing work rather than merely reporting "cancelled"
    after finishing anyway."""

    def __init__(self) -> None:
        self._cancelled = False

    def cancel(self) -> None:
        self._cancelled = True

    @property
    def is_cancelled(self) -> bool:
        return self._cancelled


class Renderer:
    def render_page(self, page: Page, request: RenderRequest | None = None, *, asset_manager=None, job: RenderJob | None = None) -> PILImage.Image:
        req = request or RenderRequest()
        factor = supersample_factor(req.antialias)
        px_width = max(1, round(page.width * req.scale))
        px_height = max(1, round(page.height * req.scale))

        ops = flatten_page(page, asset_manager)
        if job is not None and job.is_cancelled:
            raise CancelledError("Render job was cancelled before rasterisation began")

        background = page.background if req.background_override else None
        backend = RasterBackend(px_width, px_height, supersample=factor, background=background, asset_manager=asset_manager)

        # Device pixel ratio (1x/2x/3x, spec section 37) is applied by
        # pre-scaling every op's geometry; AA supersampling is then applied
        # independently on top by RasterBackend itself.
        if req.scale != 1.0:
            ops = _scale_ops(ops, req.scale)

        try:
            backend.render_ops(ops)
        except CancelledError:
            raise
        except Exception as exc:
            raise RenderError(f"Rendering failed: {exc}") from exc
        return backend.to_image()

    def render_document(self, document: Document, request: RenderRequest | None = None, *, job: RenderJob | None = None) -> PILImage.Image:
        req = request or RenderRequest()
        page = document.pages[req.page_index]
        return self.render_page(page, req, asset_manager=document.assets, job=job)

    def render_object(self, document: Document, object_id: str, request: RenderRequest | None = None) -> PILImage.Image:
        """Render a single object in isolation (its own visual bounds as the
        canvas) — used by the inspector/thumbnail UI."""
        obj = document.find(object_id)
        if obj is None:
            raise RenderError(f"No object with id {object_id!r}", details={"object_id": object_id})
        bounds = obj.world_bounds().visual
        if bounds.is_empty:
            return PILImage.new("RGBA", (1, 1), (0, 0, 0, 0))
        req = request or RenderRequest()
        factor = supersample_factor(req.antialias)
        width = max(1, round(bounds.width * req.scale))
        height = max(1, round(bounds.height * req.scale))

        from aardvark.geometry.matrix import Matrix
        from aardvark.render.vector import _emit_object

        offset = Matrix.translation(-bounds.min_x, -bounds.min_y).compose(Matrix.scaling(req.scale, req.scale))
        ops: list = []
        _emit_object(obj, offset, ops, document.assets)
        backend = RasterBackend(width, height, supersample=factor, asset_manager=document.assets)
        backend.render_ops(ops)
        return backend.to_image()


def _scale_ops(ops: list, scale: float):
    """Scale every geometric draw op's coordinates by ``scale`` (device pixel
    ratio) without touching AA supersampling, which RasterBackend applies
    separately."""
    from aardvark.geometry.matrix import Matrix
    from aardvark.render.vector import FillOp, ImageOp, PushClipOp, PushMaskOp, ShadowOp, StrokeOp, transform_paint

    m = Matrix.scaling(scale, scale)
    scaled = []
    for op in ops:
        if isinstance(op, FillOp):
            scaled.append(type(op)(op.path.transformed(m), transform_paint(op.paint, m), op.rule, op.opacity, op.object_id))
        elif isinstance(op, StrokeOp):
            scaled.append(type(op)(op.path.transformed(m), transform_paint(op.paint, m), op.opacity, op.object_id))
        elif isinstance(op, ShadowOp):
            scaled.append(type(op)(op.path.transformed(m), op.shadow, op.object_id))
        elif isinstance(op, PushClipOp):
            scaled.append(type(op)(op.path.transformed(m)))
        elif isinstance(op, PushMaskOp):
            scaled.append(type(op)(_scale_ops(op.mask_ops, scale), op.mode))
        elif isinstance(op, ImageOp):
            scaled.append(type(op)(op.image, op.world_matrix.compose(m), op.opacity, op.object_id))
        else:
            scaled.append(op)
    return scaled
