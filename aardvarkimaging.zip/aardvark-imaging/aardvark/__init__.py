"""Aardvark Imaging — a professional-grade vector graphics and rendering
engine: the computational graphics kernel for a future macOS vector
graphics application (see the module docstrings under ``aardvark.*`` for
each subsystem; ``aardvark.engine.Engine`` is the stable façade a UI client
or the ``aardvark`` CLI drives).

Quick start (spec section 69)::

    from aardvark import Document, Rectangle, Circle

    doc = Document(width=1200, height=800)
    doc.add(Rectangle(x=100, y=100, width=400, height=200))
    doc.add(Circle(cx=400, cy=300, radius=120))
    doc.export_svg("example.svg")
"""

from aardvark.config import DEFAULT_CONFIG, AntialiasQuality, EngineConfig
from aardvark.document.document import Document
from aardvark.document.layer import Layer
from aardvark.document.page import Grid, Guide, Page
from aardvark.document.scene import GenericPathObject, Group, GraphicObject, Mask, SymbolDefinition, SymbolInstance
from aardvark.engine import Engine
from aardvark.images.image import Image
from aardvark.paths.path import Path
from aardvark.shapes import Circle, Ellipse, Line, Polygon, Rectangle, Star
from aardvark.style import Color, Fill, LinearGradient, Pattern, RadialGradient, Shadow, Stroke, Style
from aardvark.text.text import Text

__version__ = DEFAULT_CONFIG.engine_version

__all__ = [
    "__version__",
    "DEFAULT_CONFIG",
    "EngineConfig",
    "AntialiasQuality",
    "Engine",
    "Document",
    "Page",
    "Layer",
    "Grid",
    "Guide",
    "GraphicObject",
    "Group",
    "Mask",
    "SymbolDefinition",
    "SymbolInstance",
    "GenericPathObject",
    "Path",
    "Rectangle",
    "Ellipse",
    "Circle",
    "Polygon",
    "Star",
    "Line",
    "Text",
    "Image",
    "Style",
    "Fill",
    "Stroke",
    "Color",
    "LinearGradient",
    "RadialGradient",
    "Pattern",
    "Shadow",
]


def _add_export_convenience_methods() -> None:
    """Attach ``Document.export_svg/export_pdf/export_png/export_jpeg`` —
    thin wrappers over ``aardvark.export.*`` — so the quick-start example in
    this module's docstring (and spec section 69) works as written, without
    ``aardvark.document.document`` needing to import the export package
    (which itself depends on the document/render packages) at module load
    time.
    """

    def export_svg(self: Document, path: str, page_index: int = 0, **kwargs) -> None:
        from aardvark.export.svg import save_svg

        save_svg(self, path, page_index, **kwargs)

    def export_pdf(self: Document, path: str, **kwargs) -> None:
        from aardvark.export.pdf import export_pdf as _export_pdf

        _export_pdf(self, path, **kwargs)

    def export_png(self: Document, path: str, page_index: int = 0, **kwargs) -> None:
        from aardvark.export.png import export_png as _export_png

        _export_png(self, path, page_index, **kwargs)

    def export_jpeg(self: Document, path: str, page_index: int = 0, **kwargs) -> None:
        from aardvark.export.jpeg import export_jpeg as _export_jpeg

        _export_jpeg(self, path, page_index, **kwargs)

    Document.export_svg = export_svg
    Document.export_pdf = export_pdf
    Document.export_png = export_png
    Document.export_jpeg = export_jpeg


_add_export_convenience_methods()
