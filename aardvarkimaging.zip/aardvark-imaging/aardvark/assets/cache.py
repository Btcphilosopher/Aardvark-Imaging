"""A byte-budgeted LRU cache, used by the asset manager and the render tile
cache (spec sections 38-39, 61) to bound memory growth from large imported
images/documents."""

from __future__ import annotations

from collections import OrderedDict
from typing import Callable, Generic, TypeVar

K = TypeVar("K")
V = TypeVar("V")


class LRUCache(Generic[K, V]):
    def __init__(self, capacity_bytes: int, size_of: Callable[[V], int] = lambda v: 1) -> None:
        self.capacity_bytes = capacity_bytes
        self._size_of = size_of
        self._store: OrderedDict[K, V] = OrderedDict()
        self._total_bytes = 0

    def get(self, key: K) -> V | None:
        if key not in self._store:
            return None
        self._store.move_to_end(key)
        return self._store[key]

    def put(self, key: K, value: V) -> None:
        if key in self._store:
            self._total_bytes -= self._size_of(self._store[key])
            del self._store[key]
        size = self._size_of(value)
        self._store[key] = value
        self._total_bytes += size
        self._store.move_to_end(key)
        self._evict_if_needed()

    def _evict_if_needed(self) -> None:
        while self._total_bytes > self.capacity_bytes and self._store:
            _, oldest_value = self._store.popitem(last=False)
            self._total_bytes -= self._size_of(oldest_value)

    def invalidate(self, key: K) -> None:
        if key in self._store:
            self._total_bytes -= self._size_of(self._store[key])
            del self._store[key]

    def clear(self) -> None:
        self._store.clear()
        self._total_bytes = 0

    def __contains__(self, key: K) -> bool:
        return key in self._store

    def __len__(self) -> int:
        return len(self._store)

    @property
    def total_bytes(self) -> int:
        return self._total_bytes
