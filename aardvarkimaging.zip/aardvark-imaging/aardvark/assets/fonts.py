"""Font asset inspection and subsetting, built on fontTools (spec section 18)."""

from __future__ import annotations

import io
from dataclasses import dataclass

from fontTools.subset import Options, Subsetter
from fontTools.ttLib import TTFont

from aardvark.errors import FontError


@dataclass(slots=True)
class FontMetadata:
    family: str
    subfamily: str
    weight: int
    is_italic: bool
    units_per_em: int
    ascender: int
    descender: int
    glyph_count: int
    postscript_name: str


def inspect_font(data: bytes) -> FontMetadata:
    """Read a font's family/weight/style/metrics without rendering anything —
    used by the inspector and by the PDF/SVG exporters to decide how to embed it."""
    try:
        tt = TTFont(io.BytesIO(data), lazy=True)
    except Exception as exc:  # fontTools raises a variety of exception types
        raise FontError(f"Could not parse font: {exc}") from exc

    name_table = tt["name"]

    def name(name_id: int, default: str = "") -> str:
        rec = name_table.getDebugName(name_id)
        return rec if rec else default

    os2 = tt["OS/2"] if "OS/2" in tt else None
    head = tt["head"]
    hhea = tt["hhea"] if "hhea" in tt else None

    weight = os2.usWeightClass if os2 is not None else 400
    is_italic = bool(head.macStyle & 0b10) if hasattr(head, "macStyle") else False

    return FontMetadata(
        family=name(1, "Unknown"),
        subfamily=name(2, "Regular"),
        weight=weight,
        is_italic=is_italic,
        units_per_em=head.unitsPerEm,
        ascender=hhea.ascender if hhea is not None else head.unitsPerEm,
        descender=hhea.descender if hhea is not None else 0,
        glyph_count=tt["maxp"].numGlyphs,
        postscript_name=name(6, name(1, "Unknown")),
    )


def subset_font(data: bytes, text: str) -> bytes:
    """Produce a subsetted font containing only the glyphs needed for ``text``.
    Used for compact PDF/SVG embedding rather than shipping a whole font file."""
    try:
        tt = TTFont(io.BytesIO(data))
        options = Options()
        options.layout_features = ["*"]
        options.name_IDs = ["*"]
        options.notdef_outline = True
        options.recalc_bounds = True
        subsetter = Subsetter(options)
        subsetter.populate(text=text)
        subsetter.subset(tt)
        out = io.BytesIO()
        tt.save(out)
        return out.getvalue()
    except Exception as exc:
        raise FontError(f"Font subsetting failed: {exc}") from exc
