"""The asset manager: a document-scoped registry of images/fonts referenced
by id, so identical bytes are only ever stored once (spec section 21) and
decoded raster data is bounded by an LRU cache (spec section 61).
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from pathlib import Path as FsPath
from typing import Any

from aardvark.assets.cache import LRUCache
from aardvark.config import DEFAULT_CONFIG
from aardvark.errors import AssetError


@dataclass(slots=True)
class AssetRecord:
    id: str
    kind: str  # "image" | "font"
    source_path: str | None = None
    data: bytes | None = None  # embedded bytes; None if the asset is external-file-only
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self, *, embed_data: bool = True) -> dict[str, Any]:
        import base64

        d: dict[str, Any] = {
            "id": self.id,
            "kind": self.kind,
            "source_path": self.source_path,
            "metadata": self.metadata,
        }
        if embed_data and self.data is not None:
            d["data_base64"] = base64.b64encode(self.data).decode("ascii")
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "AssetRecord":
        import base64

        data = base64.b64decode(d["data_base64"]) if "data_base64" in d else None
        return cls(id=d["id"], kind=d["kind"], source_path=d.get("source_path"), data=data, metadata=d.get("metadata", {}))


def _content_id(data: bytes) -> str:
    return "asset_" + hashlib.sha256(data).hexdigest()[:24]


class AssetManager:
    def __init__(self, cache_capacity_bytes: int | None = None) -> None:
        self._records: dict[str, AssetRecord] = {}
        self._decoded_cache: LRUCache[str, Any] = LRUCache(
            cache_capacity_bytes or DEFAULT_CONFIG.asset_cache_capacity_bytes,
            size_of=lambda v: getattr(v, "nbytes", None) or 1_000_000,
        )

    # -- registration -----------------------------------------------------
    def register_image(
        self, *, data: bytes | None = None, source_path: str | None = None, **metadata: Any
    ) -> str:
        if data is None and source_path is None:
            raise AssetError("register_image requires data or source_path")
        if data is not None:
            asset_id = _content_id(data)
        else:
            asset_id = "asset_" + hashlib.sha256(str(source_path).encode()).hexdigest()[:24]
        if asset_id not in self._records:
            self._records[asset_id] = AssetRecord(asset_id, "image", source_path, data, dict(metadata))
        return asset_id

    def register_font(self, *, data: bytes | None = None, source_path: str | None = None, **metadata: Any) -> str:
        if data is None and source_path is None:
            raise AssetError("register_font requires data or source_path")
        if data is not None:
            asset_id = _content_id(data)
        else:
            asset_id = "font_" + hashlib.sha256(str(source_path).encode()).hexdigest()[:24]
        if asset_id not in self._records:
            self._records[asset_id] = AssetRecord(asset_id, "font", source_path, data, dict(metadata))
        return asset_id

    # -- access -------------------------------------------------------
    def get(self, asset_id: str) -> AssetRecord:
        if asset_id not in self._records:
            raise AssetError(f"Unknown asset id: {asset_id!r}", details={"asset_id": asset_id})
        return self._records[asset_id]

    def raw_bytes(self, asset_id: str) -> bytes:
        record = self.get(asset_id)
        if record.data is not None:
            return record.data
        if record.source_path is not None:
            data = FsPath(record.source_path).read_bytes()
            record.data = data  # opportunistically cache once read
            return data
        raise AssetError(f"Asset {asset_id!r} has neither embedded data nor a source path")

    def get_decoded(self, asset_id: str, decoder) -> Any:
        """Return the decoder's result for this asset, using the LRU cache
        to avoid re-decoding large images repeatedly across renders."""
        cached = self._decoded_cache.get(asset_id)
        if cached is not None:
            return cached
        decoded = decoder(self.raw_bytes(asset_id))
        self._decoded_cache.put(asset_id, decoded)
        return decoded

    def invalidate_decoded(self, asset_id: str) -> None:
        self._decoded_cache.invalidate(asset_id)

    def all_ids(self) -> list[str]:
        return list(self._records.keys())

    def gc(self, referenced_ids: set[str]) -> list[str]:
        """Drop any registered asset not present in ``referenced_ids``. Returns
        the ids that were removed."""
        stale = [aid for aid in self._records if aid not in referenced_ids]
        for aid in stale:
            del self._records[aid]
            self._decoded_cache.invalidate(aid)
        return stale

    # -- serialization --------------------------------------------------
    def to_dict(self, *, embed_data: bool = True) -> dict[str, Any]:
        return {aid: rec.to_dict(embed_data=embed_data) for aid, rec in self._records.items()}

    @classmethod
    def from_dict(cls, d: dict[str, Any], cache_capacity_bytes: int | None = None) -> "AssetManager":
        mgr = cls(cache_capacity_bytes)
        for aid, rec_dict in d.items():
            mgr._records[aid] = AssetRecord.from_dict(rec_dict)
        return mgr
