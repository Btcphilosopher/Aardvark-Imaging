"""High-quality SVG export (spec section 43).

Walks the scene graph directly and preserves real Bezier curves, native SVG
gradients/patterns/clipPath/mask/symbol/use — nothing is rasterised. This is
intentionally a *separate* traversal from ``aardvark.render.vector`` (which
flattens strokes to filled polygons for the raster preview): SVG has native
stroking, so exporting through the raster pipeline would just be lossy.
"""

from __future__ import annotations

from xml.sax.saxutils import escape, quoteattr

from aardvark.document.document import Document
from aardvark.document.page import Page
from aardvark.document.scene import GraphicObject, Group, SymbolInstance
from aardvark.errors import ExportError
from aardvark.images.image import Image
from aardvark.paths.path import CurveTo, LineTo, Path, QuadTo
from aardvark.style import Color, LinearGradient, Pattern, RadialGradient, Shadow, Style
from aardvark.text.text import Text


def _num(v: float) -> str:
    s = f"{v:.4f}".rstrip("0").rstrip(".")
    return s if s not in ("", "-0") else "0"


def _path_d(path: Path) -> str:
    parts = []
    for sp in path.subpaths:
        parts.append(f"M{_num(sp.start.x)},{_num(sp.start.y)}")
        for seg in sp.segments:
            if isinstance(seg, LineTo):
                parts.append(f"L{_num(seg.point.x)},{_num(seg.point.y)}")
            elif isinstance(seg, QuadTo):
                parts.append(f"Q{_num(seg.control.x)},{_num(seg.control.y)} {_num(seg.point.x)},{_num(seg.point.y)}")
            elif isinstance(seg, CurveTo):
                parts.append(
                    f"C{_num(seg.control1.x)},{_num(seg.control1.y)} {_num(seg.control2.x)},{_num(seg.control2.y)} {_num(seg.point.x)},{_num(seg.point.y)}"
                )
        if sp.closed:
            parts.append("Z")
    return " ".join(parts)


class SvgExporter:
    def __init__(self, *, text_as_outlines: bool = True) -> None:
        self.text_as_outlines = text_as_outlines
        self.defs: list[str] = []
        self._counter = 0
        self._symbol_defs_emitted: set[str] = set()

    def _new_id(self, prefix: str) -> str:
        self._counter += 1
        return f"{prefix}{self._counter}"

    def export_document(self, document: Document, page_index: int = 0) -> str:
        return self.export_page(document.pages[page_index], document)

    def export_page(self, page: Page, document: Document | None = None) -> str:
        self.defs = []
        self._counter = 0
        body_parts = []
        for layer in page.layers:
            if not layer.visible:
                continue
            body_parts.append(self._object_svg(layer, document))
        bg = ""
        if page.background is not None:
            bg = f'<rect x="0" y="0" width="{_num(page.width)}" height="{_num(page.height)}" fill="{_color_hex(page.background)}"/>'
        defs_block = f"<defs>{''.join(self.defs)}</defs>" if self.defs else ""
        return (
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" '
            f'width="{_num(page.width)}" height="{_num(page.height)}" viewBox="0 0 {_num(page.width)} {_num(page.height)}">'
            f"{defs_block}{bg}{''.join(body_parts)}</svg>"
        )

    # -- paint defs -----------------------------------------------------
    def _register_paint(self, paint) -> str:
        if paint is None:
            return "none"
        if isinstance(paint, Color):
            return _color_hex(paint)
        if isinstance(paint, LinearGradient):
            gid = self._new_id("lg")
            stops = "".join(
                f'<stop offset="{_num(s.offset)}" stop-color="{_color_hex(s.color)}" stop-opacity="{_num(s.opacity * s.color.a)}"/>'
                for s in paint.stops
            )
            self.defs.append(
                f'<linearGradient id="{gid}" gradientUnits="userSpaceOnUse" '
                f'x1="{_num(paint.start.x)}" y1="{_num(paint.start.y)}" x2="{_num(paint.end.x)}" y2="{_num(paint.end.y)}" '
                f'spreadMethod="{paint.spread.value}" gradientTransform="{paint.transform.to_svg_string()}">{stops}</linearGradient>'
            )
            return f"url(#{gid})"
        if isinstance(paint, RadialGradient):
            gid = self._new_id("rg")
            stops = "".join(
                f'<stop offset="{_num(s.offset)}" stop-color="{_color_hex(s.color)}" stop-opacity="{_num(s.opacity * s.color.a)}"/>'
                for s in paint.stops
            )
            fx, fy = (paint.focal.x, paint.focal.y) if paint.focal else (paint.center.x, paint.center.y)
            self.defs.append(
                f'<radialGradient id="{gid}" gradientUnits="userSpaceOnUse" '
                f'cx="{_num(paint.center.x)}" cy="{_num(paint.center.y)}" r="{_num(paint.radius)}" fx="{_num(fx)}" fy="{_num(fy)}" '
                f'spreadMethod="{paint.spread.value}" gradientTransform="{paint.transform.to_svg_string()}">{stops}</radialGradient>'
            )
            return f"url(#{gid})"
        if isinstance(paint, Pattern):
            pid = self._new_id("pat")
            content = "".join(self._object_svg(o, None) for o in paint.content)
            tb = paint.tile_bounds
            self.defs.append(
                f'<pattern id="{pid}" patternUnits="userSpaceOnUse" x="{_num(tb.x)}" y="{_num(tb.y)}" '
                f'width="{_num(tb.width)}" height="{_num(tb.height)}" patternTransform="{paint.transform.to_svg_string()}">{content}</pattern>'
            )
            return f"url(#{pid})"
        raise ExportError(f"Unsupported paint type for SVG export: {type(paint)!r}")

    def _register_shadow_filter(self, shadow: Shadow) -> str:
        fid = self._new_id("shadow")
        color = _color_hex(shadow.color)
        if not shadow.inner:
            self.defs.append(
                f'<filter id="{fid}" x="-50%" y="-50%" width="200%" height="200%">'
                f'<feDropShadow dx="{_num(shadow.offset_x)}" dy="{_num(shadow.offset_y)}" '
                f'stdDeviation="{_num(max(0.0, shadow.blur_radius) / 2.0)}" flood-color="{color}" flood-opacity="{_num(shadow.color.a)}"/>'
                f"</filter>"
            )
        else:
            self.defs.append(
                f'<filter id="{fid}" x="-50%" y="-50%" width="200%" height="200%">'
                f'<feFlood flood-color="{color}" flood-opacity="{_num(shadow.color.a)}" result="flood"/>'
                f'<feComposite in="flood" in2="SourceAlpha" operator="out" result="inverse"/>'
                f'<feGaussianBlur in="inverse" stdDeviation="{_num(max(0.0, shadow.blur_radius) / 2.0)}" result="blurred"/>'
                f'<feOffset in="blurred" dx="{_num(shadow.offset_x)}" dy="{_num(shadow.offset_y)}" result="offset"/>'
                f'<feComposite in="offset" in2="SourceAlpha" operator="in"/>'
                f"</filter>"
            )
        return fid

    # -- object traversal -------------------------------------------------
    def _style_attrs(self, style: Style) -> str:
        attrs = []
        if style.fill.paint is not None:
            # Hex colours carry no alpha channel; fold the colour's own alpha
            # into fill-opacity so translucent solid fills aren't silently
            # rendered fully opaque.
            fill_alpha = style.fill.paint.a if isinstance(style.fill.paint, Color) else 1.0
            attrs.append(f'fill="{self._register_paint(style.fill.paint)}"')
            attrs.append(f'fill-opacity="{_num(style.fill.opacity * fill_alpha)}"')
            attrs.append(f'fill-rule="{style.fill.rule}"')
        else:
            attrs.append('fill="none"')
        if style.stroke is not None and style.stroke.paint is not None:
            s = style.stroke
            stroke_alpha = s.paint.a if isinstance(s.paint, Color) else 1.0
            attrs.append(f'stroke="{self._register_paint(s.paint)}"')
            attrs.append(f'stroke-width="{_num(s.width)}"')
            attrs.append(f'stroke-opacity="{_num(s.opacity * stroke_alpha)}"')
            attrs.append(f'stroke-linecap="{s.cap.value}"')
            attrs.append(f'stroke-linejoin="{s.join.value}"')
            attrs.append(f'stroke-miterlimit="{_num(s.miter_limit)}"')
            if s.dash_pattern:
                attrs.append(f'stroke-dasharray="{",".join(_num(v) for v in s.dash_pattern)}"')
                attrs.append(f'stroke-dashoffset="{_num(s.dash_offset)}"')
        return " ".join(attrs)

    def _object_svg(self, obj: GraphicObject, document: Document | None) -> str:
        if not obj.visible:
            return ""
        attrs = [f'id="{obj.id}"']
        m = obj.transform.matrix
        if not m.is_identity():
            attrs.append(f'transform="{m.to_svg_string()}"')

        style_bits = []
        if obj.style.opacity < 1.0:
            style_bits.append(f"opacity:{_num(obj.style.opacity)}")
        if obj.style.blend_mode.value != "normal":
            style_bits.append(f"mix-blend-mode:{obj.style.blend_mode.value}")
        if style_bits:
            attrs.append(f'style="{";".join(style_bits)}"')

        filter_ids = []
        for shadow in obj.style.shadows:
            filter_ids.append(self._register_shadow_filter(shadow))
        if filter_ids:
            attrs.append(f'filter="{" ".join(f"url(#{fid})" for fid in filter_ids)}"')

        if obj.clip_path is not None:
            cid = self._new_id("clip")
            self.defs.append(f'<clipPath id="{cid}"><path d="{_path_d(obj.clip_path)}"/></clipPath>')
            attrs.append(f'clip-path="url(#{cid})"')

        if obj.mask is not None:
            mid = self._new_id("mask")
            content = "".join(self._object_svg(c, document) for c in obj.mask.content)
            mask_type = ' style="mask-type:alpha"' if obj.mask.mode.value == "alpha" else ""
            self.defs.append(f'<mask id="{mid}"{mask_type}>{content}</mask>')
            attrs.append(f'mask="url(#{mid})"')

        attr_str = " ".join(attrs)

        if isinstance(obj, Image):
            return self._image_svg(obj, attr_str, document)
        if isinstance(obj, SymbolInstance):
            return self._symbol_instance_svg(obj, attr_str, document)
        if isinstance(obj, Group):
            inner = "".join(self._object_svg(c, document) for c in obj.children)
            return f"<g {attr_str}>{inner}</g>"
        if isinstance(obj, Text) and self.text_as_outlines:
            path = obj.to_path(document.assets if document else None)
            return f'<path {attr_str} d="{_path_d(path)}" {self._style_attrs(obj.style)}/>'
        if isinstance(obj, Text):
            return self._text_svg(obj, attr_str)

        path = obj.to_path()
        return f'<path {attr_str} d="{_path_d(path)}" {self._style_attrs(obj.style)}/>'

    def _image_svg(self, obj: Image, attr_str: str, document: Document | None) -> str:
        if document is None:
            raise ExportError("Exporting an Image requires the owning Document (for asset bytes)")
        import base64

        data = document.assets.raw_bytes(obj.asset_id)
        fmt = document.assets.get(obj.asset_id).metadata.get("format", "PNG").lower()
        mime = {"jpeg": "image/jpeg", "jpg": "image/jpeg", "png": "image/png", "webp": "image/webp", "tiff": "image/tiff"}.get(fmt, "image/png")
        b64 = base64.b64encode(data).decode("ascii")
        return (
            f'<image {attr_str} x="{_num(obj.x)}" y="{_num(obj.y)}" width="{_num(obj.width)}" height="{_num(obj.height)}" '
            f'preserveAspectRatio="{"none" if obj.fit.value == "stretch" else "xMidYMid meet"}" '
            f'xlink:href="data:{mime};base64,{b64}"/>'
        )

    def _text_svg(self, obj: Text, attr_str: str) -> str:
        result = obj.layout()
        lines_svg = []
        for line in result.lines:
            x = obj.x + line.x_offset
            y = obj.y + line.baseline_y
            lines_svg.append(f'<tspan x="{_num(x)}" y="{_num(y)}">{escape(line.text)}</tspan>')
        style = self._style_attrs(obj.style)
        italic = ' font-style="italic"' if obj.italic else ""
        return (
            f'<text {attr_str} font-family={quoteattr(obj.font_family)} font-size="{_num(obj.size)}" '
            f'font-weight="{obj.font_weight}"{italic} {style}>{"".join(lines_svg)}</text>'
        )

    def _symbol_instance_svg(self, obj: SymbolInstance, attr_str: str, document: Document | None) -> str:
        if obj.definition is None:
            raise ExportError(f"SymbolInstance {obj.id} has an unresolved definition; call Document.resolve_symbols()")
        sid = f"sym_{obj.definition.id}"
        if sid not in self._symbol_defs_emitted:
            self._symbol_defs_emitted.add(sid)
            inner = "".join(self._object_svg(c, document) for c in obj.definition.children)
            self.defs.append(f'<symbol id="{sid}">{inner}</symbol>')
        return f'<use {attr_str} xlink:href="#{sid}"/>'


def _color_hex(c: Color) -> str:
    return c.to_hex()


def export_svg(document: Document, page_index: int = 0, *, text_as_outlines: bool = True) -> str:
    return SvgExporter(text_as_outlines=text_as_outlines).export_document(document, page_index)


def save_svg(document: Document, path: str, page_index: int = 0, *, text_as_outlines: bool = True) -> None:
    svg = export_svg(document, page_index, text_as_outlines=text_as_outlines)
    from pathlib import Path as FsPath

    FsPath(path).write_text(svg, encoding="utf-8")
