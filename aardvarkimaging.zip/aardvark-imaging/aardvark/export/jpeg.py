"""JPEG export (spec section 46): quality, resolution, and background
flattening — JPEG has no alpha channel, so transparency is always composited
against ``background`` (default white) rather than silently dropped."""

from __future__ import annotations

from PIL import Image as PILImage

from aardvark.document.document import Document
from aardvark.render.renderer import RenderRequest, Renderer
from aardvark.style.color import Color


def export_jpeg(
    document: Document,
    out_path: str,
    page_index: int = 0,
    *,
    scale: float = 1.0,
    quality: int = 90,
    background: Color | None = None,
) -> None:
    bg = background or Color.white()
    # Render with a transparent backdrop regardless of the page's own
    # background, then flatten onto `bg` ourselves below — avoids mutating
    # the caller's document just to change how this one export looks.
    req = RenderRequest(page_index=page_index, scale=scale, background_override=False)
    img = Renderer().render_document(document, req)
    flattened = PILImage.new("RGB", img.size, bg.to_rgb8())
    flattened.paste(img, mask=img.split()[3])
    flattened.save(out_path, format="JPEG", quality=quality)
