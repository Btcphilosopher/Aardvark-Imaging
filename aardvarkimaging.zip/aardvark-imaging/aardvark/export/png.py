"""PNG export (spec section 45): 1x/2x/3x/custom scale, transparent background."""

from __future__ import annotations

import io

from aardvark.config import DEFAULT_CONFIG
from aardvark.document.document import Document
from aardvark.render.renderer import RenderRequest, Renderer


def export_png(
    document: Document,
    out_path: str,
    page_index: int = 0,
    *,
    scale: float = 1.0,
    transparent: bool = True,
    antialias=None,
) -> None:
    req = RenderRequest(
        page_index=page_index,
        scale=scale,
        antialias=antialias or DEFAULT_CONFIG.default_antialias,
        background_override=not transparent,
    )
    img = Renderer().render_document(document, req)
    img.save(out_path, format="PNG")


def export_png_bytes(document: Document, page_index: int = 0, *, scale: float = 1.0, transparent: bool = True) -> bytes:
    req = RenderRequest(page_index=page_index, scale=scale, background_override=not transparent)
    img = Renderer().render_document(document, req)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()
