"""Web/app asset export: batch-export a page at multiple pixel densities and
formats in one call — the common "export for web" workflow (@1x/@2x/@3x PNG,
plus WebP), built entirely on the PNG exporter's renderer."""

from __future__ import annotations

from pathlib import Path

from aardvark.document.document import Document
from aardvark.errors import ExportError
from aardvark.render.renderer import RenderRequest, Renderer

_FORMAT_EXTENSIONS = {"png": "PNG", "webp": "WEBP"}


def export_web_assets(
    document: Document,
    out_dir: str,
    page_index: int = 0,
    *,
    base_name: str = "asset",
    formats: tuple[str, ...] = ("png",),
    scales: tuple[float, ...] = (1.0, 2.0, 3.0),
    transparent: bool = True,
) -> list[str]:
    for fmt in formats:
        if fmt not in _FORMAT_EXTENSIONS:
            raise ExportError(f"Unsupported web export format: {fmt!r}", details={"supported": list(_FORMAT_EXTENSIONS)})

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    renderer = Renderer()
    written: list[str] = []
    for scale in scales:
        req = RenderRequest(page_index=page_index, scale=scale, background_override=not transparent)
        img = renderer.render_document(document, req)
        suffix = "" if scale == 1.0 else f"@{scale:g}x"
        for fmt in formats:
            path = out / f"{base_name}{suffix}.{fmt}"
            img.save(path, format=_FORMAT_EXTENSIONS[fmt])
            written.append(str(path))
    return written
