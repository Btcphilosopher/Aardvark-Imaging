"""How a source image maps into its placement rectangle (spec section 21)."""

from __future__ import annotations

from enum import Enum

from aardvark.geometry.matrix import Matrix


class FitMode(str, Enum):
    STRETCH = "stretch"  # ignore aspect ratio, fill the placement rect exactly
    FIT = "fit"  # contain: scale to fit inside, preserving aspect ratio
    FILL = "fill"  # cover: scale to fill, preserving aspect ratio, may overflow


def placement_matrix(
    natural_width: float, natural_height: float, placement_width: float, placement_height: float, mode: FitMode
) -> Matrix:
    """The matrix mapping source-pixel space (origin top-left, +y down) into
    the object's local placement rect (also origin top-left)."""
    if natural_width <= 0 or natural_height <= 0 or placement_width <= 0 or placement_height <= 0:
        return Matrix.identity()

    sx = placement_width / natural_width
    sy = placement_height / natural_height

    if mode == FitMode.STRETCH:
        return Matrix.scaling(sx, sy)

    scale = min(sx, sy) if mode == FitMode.FIT else max(sx, sy)
    scaled_w = natural_width * scale
    scaled_h = natural_height * scale
    offset_x = (placement_width - scaled_w) / 2.0
    offset_y = (placement_height - scaled_h) / 2.0
    return Matrix.scaling(scale, scale).compose(Matrix.translation(offset_x, offset_y))
