"""Raster image loading (spec section 21). Supports whatever Pillow's own
codecs support at minimum JPEG/PNG/TIFF/WebP; unsupported/corrupt files raise
:class:`~aardvark.errors.AssetError` rather than propagating a raw codec
exception."""

from __future__ import annotations

import io
from pathlib import Path

from PIL import Image as PILImage

from aardvark.assets.manager import AssetManager
from aardvark.errors import AssetError

SUPPORTED_FORMATS = {"JPEG", "PNG", "TIFF", "WEBP", "BMP", "GIF"}


def decode_image(data: bytes) -> PILImage.Image:
    try:
        img = PILImage.open(io.BytesIO(data))
        img.load()
    except Exception as exc:
        raise AssetError(f"Could not decode image data: {exc}") from exc
    return img


def probe_image(data: bytes) -> dict:
    img = decode_image(data)
    return {"width": img.width, "height": img.height, "format": img.format, "mode": img.mode}


def register_image_file(asset_manager: AssetManager, path: str | Path, *, embed: bool = True) -> str:
    """Register an image file with the asset manager. When ``embed`` is True
    (the default) the bytes are read and stored so the resulting
    ``.aardvark`` document is self-contained; when False only the source
    path is kept and bytes are streamed lazily on first use."""
    p = Path(path)
    if not p.exists():
        raise AssetError(f"Image file not found: {p}")
    if embed:
        data = p.read_bytes()
        meta = probe_image(data)
        return asset_manager.register_image(data=data, source_path=str(p), **meta)
    # Probe without embedding, to populate width/height metadata up front.
    meta = probe_image(p.read_bytes())
    return asset_manager.register_image(source_path=str(p), **meta)
