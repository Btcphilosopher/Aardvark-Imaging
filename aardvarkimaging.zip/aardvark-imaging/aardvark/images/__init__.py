"""Placed raster images: the Image scene object, loading, cropping, placement."""

from aardvark.images.image import Image
from aardvark.images.placement import FitMode, placement_matrix
from aardvark.images.loader import decode_image, probe_image, register_image_file
from aardvark.images.crop import apply_crop, validate_crop

__all__ = [
    "Image",
    "FitMode",
    "placement_matrix",
    "decode_image",
    "probe_image",
    "register_image_file",
    "apply_crop",
    "validate_crop",
]
