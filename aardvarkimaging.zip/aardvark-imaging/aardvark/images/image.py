"""The Image scene object (spec section 21): a placed raster asset.

Images reference an asset by id rather than embedding pixel bytes on the
object itself — the same asset can be placed many times without duplicating
data (spec: "do not embed image bytes repeatedly when the same asset is used
multiple times").
"""

from __future__ import annotations

from dataclasses import dataclass

from aardvark.document.scene import GraphicObject
from aardvark.geometry.bounds import Bounds
from aardvark.geometry.rect import Rect
from aardvark.images.placement import FitMode
from aardvark.paths.path import Path


@dataclass
class Image(GraphicObject):
    asset_id: str = ""
    x: float = 0.0
    y: float = 0.0
    width: float = 0.0
    height: float = 0.0
    crop: Rect | None = None  # in source-pixel space; None = whole source image
    fit: FitMode = FitMode.FILL
    source_width: int = 0
    source_height: int = 0

    def __post_init__(self) -> None:
        self.kind = "image"

    def placement_rect(self) -> Rect:
        return Rect(self.x, self.y, self.width, self.height)

    def local_bounds(self) -> Bounds:
        return Bounds(self.x, self.y, self.x + self.width, self.y + self.height)

    def to_path(self) -> Path:
        """The placement rectangle as a path — used uniformly by clipping,
        masking and hit-testing, which don't need to know this object isn't
        vector geometry."""
        path = Path()
        path.move_to(self.x, self.y)
        path.line_to(self.x + self.width, self.y)
        path.line_to(self.x + self.width, self.y + self.height)
        path.line_to(self.x, self.y + self.height)
        path.close()
        return path

    def effective_crop(self) -> Rect:
        return self.crop if self.crop is not None else Rect(0, 0, self.source_width, self.source_height)
