"""Image cropping (spec section 21)."""

from __future__ import annotations

from PIL import Image as PILImage

from aardvark.errors import ValidationError
from aardvark.geometry.rect import Rect


def validate_crop(crop: Rect, natural_width: int, natural_height: int) -> None:
    if crop.x < 0 or crop.y < 0 or crop.right > natural_width or crop.bottom > natural_height:
        raise ValidationError(
            "Crop rect extends outside the source image bounds",
            details={"crop": (crop.x, crop.y, crop.width, crop.height), "natural": (natural_width, natural_height)},
        )


def apply_crop(image: PILImage.Image, crop: Rect) -> PILImage.Image:
    validate_crop(crop, image.width, image.height)
    box = (round(crop.x), round(crop.y), round(crop.right), round(crop.bottom))
    return image.crop(box)
