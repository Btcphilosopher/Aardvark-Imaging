from __future__ import annotations

import pyclipper

from aardvark.boolean import boolean_op
from aardvark.paths.path import Path


def exclusion(subject: Path, clip: Path, *, fill_rule: str = "nonzero", tolerance: float | None = None) -> Path:
    """Symmetric difference (XOR): the area covered by exactly one of the two paths."""
    return boolean_op(subject, clip, pyclipper.CT_XOR, fill_rule=fill_rule, tolerance=tolerance)
