from __future__ import annotations

import pyclipper

from aardvark.boolean import boolean_op, boolean_op_many
from aardvark.paths.path import Path


def union(subject: Path, clip: Path, *, fill_rule: str = "nonzero", tolerance: float | None = None) -> Path:
    return boolean_op(subject, clip, pyclipper.CT_UNION, fill_rule=fill_rule, tolerance=tolerance)


def union_many(paths: list[Path], *, fill_rule: str = "nonzero", tolerance: float | None = None) -> Path:
    return boolean_op_many(paths, pyclipper.CT_UNION, fill_rule=fill_rule, tolerance=tolerance)
