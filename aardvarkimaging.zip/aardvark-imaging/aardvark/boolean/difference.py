from __future__ import annotations

import pyclipper

from aardvark.boolean import boolean_op
from aardvark.paths.path import Path


def difference(subject: Path, clip: Path, *, fill_rule: str = "nonzero", tolerance: float | None = None) -> Path:
    """subject - clip"""
    return boolean_op(subject, clip, pyclipper.CT_DIFFERENCE, fill_rule=fill_rule, tolerance=tolerance)
