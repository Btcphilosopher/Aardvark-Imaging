"""Robust vector boolean operations (spec section 13).

Implemented on top of the Clipper polygon-clipping engine (via
``pyclipper``) — the same algorithm family used by most production vector
tools for boolean ops, rather than any raster/rasterize-and-diff approach.
Curves are flattened to polygons before clipping (Clipper is a polygon
algorithm); this is disclosed, not hidden, and the flatten tolerance is
configurable. Nothing here rasterizes to pixels.
"""

from __future__ import annotations

import pyclipper

from aardvark.errors import GeometryError
from aardvark.paths.flatten import flatten_path_closed_rings
from aardvark.paths.offset import points_from_clipper, points_to_clipper
from aardvark.paths.path import Path

_FILL_TYPES = {
    "nonzero": pyclipper.PFT_NONZERO,
    "evenodd": pyclipper.PFT_EVENODD,
}


def _rings_of(path: Path, tolerance: float | None) -> list[list]:
    rings = []
    for sp, ring in zip(path.subpaths, flatten_path_closed_rings(path, tolerance)):
        pts = ring[:-1] if (ring and ring[0].is_close(ring[-1])) else ring
        if len(pts) >= 3:
            rings.append(pts)
    return rings


def boolean_op(
    subject: Path,
    clip: Path,
    op: int,
    *,
    fill_rule: str = "nonzero",
    tolerance: float | None = None,
) -> Path:
    """Run a Clipper boolean ``op`` (``pyclipper.CT_*``) between two paths."""
    if fill_rule not in _FILL_TYPES:
        raise GeometryError(f"Unknown fill rule: {fill_rule!r}")

    pc = pyclipper.Pyclipper()
    subject_rings = _rings_of(subject, tolerance)
    clip_rings = _rings_of(clip, tolerance)
    if not subject_rings and not clip_rings:
        return Path(fill_rule=fill_rule)

    for ring in subject_rings:
        pc.AddPath(points_to_clipper(ring), pyclipper.PT_SUBJECT, True)
    for ring in clip_rings:
        pc.AddPath(points_to_clipper(ring), pyclipper.PT_CLIP, True)

    solution = pc.Execute(op, _FILL_TYPES[fill_rule], _FILL_TYPES[fill_rule])

    out = Path(fill_rule=fill_rule)
    for ring in solution:
        pts = points_from_clipper(ring)
        if not pts:
            continue
        out.move_to(pts[0].x, pts[0].y)
        for p in pts[1:]:
            out.line_to(p.x, p.y)
        out.close()
    return out


def boolean_op_many(paths: list[Path], op: int, *, fill_rule: str = "nonzero", tolerance: float | None = None) -> Path:
    """Fold a boolean op across more than two paths, left to right."""
    if not paths:
        return Path(fill_rule=fill_rule)
    result = paths[0]
    for p in paths[1:]:
        result = boolean_op(result, p, op, fill_rule=fill_rule, tolerance=tolerance)
    return result
