"""Engine-wide configuration and tunable constants.

Centralising these avoids magic numbers scattered through the geometry,
rendering and export subsystems, and gives the Kotlin client one place to
query defaults via ``capabilities()``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class AntialiasQuality(str, Enum):
    DRAFT = "draft"
    PREVIEW = "preview"
    HIGH = "high"
    PRODUCTION = "production"


# Supersampling factor used by the raster backend per quality level.
ANTIALIAS_SUPERSAMPLE: dict[AntialiasQuality, int] = {
    AntialiasQuality.DRAFT: 1,
    AntialiasQuality.PREVIEW: 2,
    AntialiasQuality.HIGH: 3,
    AntialiasQuality.PRODUCTION: 4,
}


@dataclass(slots=True)
class EngineConfig:
    """Process-wide defaults. A fresh instance is safe to mutate per-session."""

    # Numerical tolerances -------------------------------------------------
    geometry_epsilon: float = 1e-9
    bezier_flatten_tolerance: float = 0.15  # px, in local geometry units
    curve_length_subdivisions: int = 24  # Gauss-Legendre sample count

    # Rendering --------------------------------------------------------
    default_antialias: AntialiasQuality = AntialiasQuality.HIGH
    default_dpi: float = 96.0
    tile_size: int = 256

    # Caching -----------------------------------------------------------
    asset_cache_capacity_bytes: int = 512 * 1024 * 1024  # 512 MiB
    render_tile_cache_entries: int = 2048

    # Format --------------------------------------------------------------
    format_version: int = 1
    engine_version: str = "0.1.0"

    # Capabilities honestly advertised by this build ---------------------
    capabilities: tuple[str, ...] = field(
        default_factory=lambda: (
            "paths",
            "bezier",
            "shapes",
            "boolean-ops",
            "gradients",
            "patterns",
            "strokes",
            "layers",
            "groups",
            "symbols",
            "clipping",
            "masks",
            "text",
            "text-on-path",
            "images",
            "spatial-index",
            "hit-testing",
            "snapping",
            "undo-redo",
            "autosave",
            "svg-import",
            "svg-export",
            "pdf-export",
            "png-export",
            "jpeg-export",
            "native-format",
            "json-api",
            "unix-socket-ipc",
        )
    )


DEFAULT_CONFIG = EngineConfig()
