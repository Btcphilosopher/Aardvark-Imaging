"""2D point in an arbitrary coordinate space.

Points are immutable value objects. All arithmetic uses ``float`` (IEEE-754
binary64 / "float64"), which is the precision mandated for ordinary geometry
by the engineering rules (see docs/PRECISION.md). Coordinates are never
rounded for storage or comparison; rounding, if any, happens only at the
presentation/export boundary.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterator


@dataclass(frozen=True, slots=True)
class Point:
    """An immutable (x, y) coordinate pair."""

    x: float = 0.0
    y: float = 0.0

    def __post_init__(self) -> None:
        # Coerce so callers can pass ints without polluting downstream math.
        object.__setattr__(self, "x", float(self.x))
        object.__setattr__(self, "y", float(self.y))

    # -- arithmetic -------------------------------------------------
    def __add__(self, other: "Point") -> "Point":
        return Point(self.x + other.x, self.y + other.y)

    def __sub__(self, other: "Point") -> "Point":
        return Point(self.x - other.x, self.y - other.y)

    def __mul__(self, scalar: float) -> "Point":
        return Point(self.x * scalar, self.y * scalar)

    __rmul__ = __mul__

    def __truediv__(self, scalar: float) -> "Point":
        return Point(self.x / scalar, self.y / scalar)

    def __neg__(self) -> "Point":
        return Point(-self.x, -self.y)

    def __iter__(self) -> Iterator[float]:
        yield self.x
        yield self.y

    # -- geometry -----------------------------------------------------
    def distance_to(self, other: "Point") -> float:
        return math.hypot(self.x - other.x, self.y - other.y)

    def distance_squared_to(self, other: "Point") -> float:
        dx = self.x - other.x
        dy = self.y - other.y
        return dx * dx + dy * dy

    def lerp(self, other: "Point", t: float) -> "Point":
        """Linear interpolation from self to other at parameter t in [0, 1]."""
        return Point(self.x + (other.x - self.x) * t, self.y + (other.y - self.y) * t)

    def is_close(self, other: "Point", tolerance: float = 1e-9) -> bool:
        return math.isclose(self.x, other.x, abs_tol=tolerance) and math.isclose(
            self.y, other.y, abs_tol=tolerance
        )

    def as_tuple(self) -> tuple[float, float]:
        return (self.x, self.y)

    def normalized_point(self) -> "Point":
        """Unit-length direction from the origin toward this point (as a Point,
        for convenient handle arithmetic). Returns (0, 0) for the zero vector."""
        length = math.hypot(self.x, self.y)
        if length == 0.0:
            return Point(0.0, 0.0)
        return Point(self.x / length, self.y / length)

    @classmethod
    def origin(cls) -> "Point":
        return cls(0.0, 0.0)
