"""Low-level geometric intersection and containment primitives.

These are the building blocks used by hit testing, snapping, and boolean
setup (curve flattening happens before any of these are called — everything
here operates on straight segments and polygons).
"""

from __future__ import annotations


from aardvark.geometry.point import Point


def line_line_intersection(
    p1: Point, p2: Point, p3: Point, p4: Point
) -> Point | None:
    """Intersection of segment p1-p2 with segment p3-p4, or None if they don't cross."""
    x1, y1 = p1.x, p1.y
    x2, y2 = p2.x, p2.y
    x3, y3 = p3.x, p3.y
    x4, y4 = p4.x, p4.y

    denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
    if abs(denom) < 1e-12:
        return None  # parallel or degenerate

    t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denom
    u = ((x1 - x3) * (y1 - y2) - (y1 - y3) * (x1 - x2)) / denom

    if 0.0 <= t <= 1.0 and 0.0 <= u <= 1.0:
        return Point(x1 + t * (x2 - x1), y1 + t * (y2 - y1))
    return None


def line_ray_infinite_intersection(
    p1: Point, p2: Point, p3: Point, p4: Point
) -> Point | None:
    """Intersection of the infinite lines through p1-p2 and p3-p4 (no clamping)."""
    x1, y1 = p1.x, p1.y
    x2, y2 = p2.x, p2.y
    x3, y3 = p3.x, p3.y
    x4, y4 = p4.x, p4.y
    denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
    if abs(denom) < 1e-12:
        return None
    t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denom
    return Point(x1 + t * (x2 - x1), y1 + t * (y2 - y1))


def point_segment_distance(p: Point, a: Point, b: Point) -> float:
    """Shortest distance from point p to segment a-b."""
    dx, dy = b.x - a.x, b.y - a.y
    length_sq = dx * dx + dy * dy
    if length_sq < 1e-18:
        return p.distance_to(a)
    t = ((p.x - a.x) * dx + (p.y - a.y) * dy) / length_sq
    t = max(0.0, min(1.0, t))
    closest = Point(a.x + t * dx, a.y + t * dy)
    return p.distance_to(closest)


def point_in_polygon(p: Point, polygon: list[Point], *, even_odd: bool = True) -> bool:
    """Point-in-polygon test.

    ``even_odd=True`` uses the even-odd fill rule (ray casting); otherwise
    the nonzero winding rule is used, matching SVG's ``fill-rule``.
    """
    if even_odd:
        return _point_in_polygon_even_odd(p, polygon)
    return winding_number(p, polygon) != 0


def _point_in_polygon_even_odd(p: Point, polygon: list[Point]) -> bool:
    n = len(polygon)
    if n < 3:
        return False
    inside = False
    j = n - 1
    for i in range(n):
        xi, yi = polygon[i].x, polygon[i].y
        xj, yj = polygon[j].x, polygon[j].y
        if ((yi > p.y) != (yj > p.y)) and (
            p.x < (xj - xi) * (p.y - yi) / (yj - yi + 1e-300) + xi
        ):
            inside = not inside
        j = i
    return inside


def winding_number(p: Point, polygon: list[Point]) -> int:
    n = len(polygon)
    wn = 0
    for i in range(n):
        a = polygon[i]
        b = polygon[(i + 1) % n]
        if a.y <= p.y:
            if b.y > p.y and _is_left(a, b, p) > 0:
                wn += 1
        else:
            if b.y <= p.y and _is_left(a, b, p) < 0:
                wn -= 1
    return wn


def _is_left(a: Point, b: Point, p: Point) -> float:
    return (b.x - a.x) * (p.y - a.y) - (p.x - a.x) * (b.y - a.y)


def polygon_area(polygon: list[Point]) -> float:
    """Signed area (shoelace formula). Positive = counter-clockwise in math
    convention (clockwise on screen, since y grows downward)."""
    n = len(polygon)
    if n < 3:
        return 0.0
    area = 0.0
    for i in range(n):
        a = polygon[i]
        b = polygon[(i + 1) % n]
        area += a.x * b.y - b.x * a.y
    return area / 2.0


def polygon_perimeter(polygon: list[Point], closed: bool = True) -> float:
    n = len(polygon)
    if n < 2:
        return 0.0
    total = 0.0
    limit = n if closed else n - 1
    for i in range(limit):
        a = polygon[i]
        b = polygon[(i + 1) % n]
        total += a.distance_to(b)
    return total


def segment_intersects_rect(a: Point, b: Point, rx0: float, ry0: float, rx1: float, ry1: float) -> bool:
    """Cohen-Sutherland style segment/AABB intersection test."""
    def out_code(x: float, y: float) -> int:
        code = 0
        if x < rx0:
            code |= 1
        elif x > rx1:
            code |= 2
        if y < ry0:
            code |= 4
        elif y > ry1:
            code |= 8
        return code

    x0, y0, x1, y1 = a.x, a.y, b.x, b.y
    c0, c1 = out_code(x0, y0), out_code(x1, y1)
    while True:
        if not (c0 | c1):
            return True
        if c0 & c1:
            return False
        cout = c0 or c1
        if cout & 8:
            x = x0 + (x1 - x0) * (ry1 - y0) / (y1 - y0)
            y = ry1
        elif cout & 4:
            x = x0 + (x1 - x0) * (ry0 - y0) / (y1 - y0)
            y = ry0
        elif cout & 2:
            y = y0 + (y1 - y0) * (rx1 - x0) / (x1 - x0)
            x = rx1
        else:
            y = y0 + (y1 - y0) * (rx0 - x0) / (x1 - x0)
            x = rx0
        if cout == c0:
            x0, y0 = x, y
            c0 = out_code(x0, y0)
        else:
            x1, y1 = x, y
            c1 = out_code(x1, y1)
