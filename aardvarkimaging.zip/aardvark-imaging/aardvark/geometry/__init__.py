"""Geometry primitives: points, vectors, matrices, transforms, bounds, intersections."""

from aardvark.geometry.point import Point
from aardvark.geometry.vector import Vector2
from aardvark.geometry.matrix import Matrix
from aardvark.geometry.transform import Transform, ViewTransform, compose_chain
from aardvark.geometry.rect import Rect
from aardvark.geometry.bounds import Bounds, BoundsSet

__all__ = [
    "Point",
    "Vector2",
    "Matrix",
    "Transform",
    "ViewTransform",
    "compose_chain",
    "Rect",
    "Bounds",
    "BoundsSet",
]
