"""Axis-aligned rectangles in a *local* coordinate space (as opposed to
:class:`aardvark.geometry.bounds.Bounds`, which is always world/query space).
"""

from __future__ import annotations

from dataclasses import dataclass

from aardvark.geometry.bounds import Bounds
from aardvark.geometry.matrix import Matrix
from aardvark.geometry.point import Point


@dataclass(frozen=True, slots=True)
class Rect:
    x: float = 0.0
    y: float = 0.0
    width: float = 0.0
    height: float = 0.0

    @property
    def left(self) -> float:
        return self.x

    @property
    def top(self) -> float:
        return self.y

    @property
    def right(self) -> float:
        return self.x + self.width

    @property
    def bottom(self) -> float:
        return self.y + self.height

    @property
    def center(self) -> Point:
        return Point(self.x + self.width / 2.0, self.y + self.height / 2.0)

    def corners(self) -> list[Point]:
        return [
            Point(self.left, self.top),
            Point(self.right, self.top),
            Point(self.right, self.bottom),
            Point(self.left, self.bottom),
        ]

    def contains_point(self, p: Point) -> bool:
        return self.left <= p.x <= self.right and self.top <= p.y <= self.bottom

    def union(self, other: "Rect") -> "Rect":
        left = min(self.left, other.left)
        top = min(self.top, other.top)
        right = max(self.right, other.right)
        bottom = max(self.bottom, other.bottom)
        return Rect(left, top, right - left, bottom - top)

    def intersects(self, other: "Rect") -> bool:
        return not (
            self.right < other.left
            or other.right < self.left
            or self.bottom < other.top
            or other.bottom < self.top
        )

    def inflated(self, amount: float) -> "Rect":
        return Rect(self.x - amount, self.y - amount, self.width + 2 * amount, self.height + 2 * amount)

    def to_bounds(self) -> Bounds:
        return Bounds(self.left, self.top, self.right, self.bottom)

    def transformed_bounds(self, matrix: Matrix) -> Bounds:
        """Axis-aligned bounds of this rect after an arbitrary affine transform.

        Correctly handles rotation/skew by transforming all four corners
        rather than just the two extremes (a common source of bugs).
        """
        pts = [matrix.apply_xy(c.x, c.y) for c in self.corners()]
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        return Bounds(min(xs), min(ys), max(xs), max(ys))

    @classmethod
    def from_bounds(cls, b: Bounds) -> "Rect":
        return cls(b.min_x, b.min_y, b.width, b.height)

    @classmethod
    def from_two_points(cls, a: Point, b: Point) -> "Rect":
        x = min(a.x, b.x)
        y = min(a.y, b.y)
        return cls(x, y, abs(b.x - a.x), abs(b.y - a.y))
