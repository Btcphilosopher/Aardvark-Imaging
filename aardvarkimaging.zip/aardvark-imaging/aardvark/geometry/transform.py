"""Affine transform builder and coordinate-space conversions.

Five coordinate spaces are recognised throughout the engine (spec section 7):

``document`` -> ``page`` -> ``layer`` -> ``object`` (local), and orthogonally
``screen`` space, which is document space composed with a view transform
(pan / zoom / DPI scale) used only by the renderer, never stored on objects.

Every scene node (:class:`~aardvark.document.scene.GraphicObject` and its
containers) owns one :class:`Transform` describing its position relative to
its *parent*. Converting between any two spaces is done by composing the
chain of ancestor transforms and, where needed, inverting it.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from aardvark.geometry.matrix import Matrix
from aardvark.geometry.point import Point


@dataclass(slots=True)
class Transform:
    """A mutable convenience wrapper around an immutable :class:`Matrix`.

    Distinct from Matrix itself so scene objects can hold *one* Transform
    and mutate it in place (translate/rotate/scale) without callers having
    to remember to reassign ``obj.matrix = obj.matrix.compose(...)``.
    """

    matrix: Matrix = field(default_factory=Matrix.identity)

    def translate(self, tx: float, ty: float) -> "Transform":
        self.matrix = self.matrix.compose(Matrix.translation(tx, ty))
        return self

    def rotate(self, radians: float, origin: tuple[float, float] = (0.0, 0.0)) -> "Transform":
        self.matrix = self.matrix.compose(Matrix.rotation(radians, origin))
        return self

    def rotate_degrees(self, degrees: float, origin: tuple[float, float] = (0.0, 0.0)) -> "Transform":
        return self.rotate(math.radians(degrees), origin)

    def scale(self, sx: float, sy: float | None = None, origin: tuple[float, float] = (0.0, 0.0)) -> "Transform":
        self.matrix = self.matrix.compose(Matrix.scaling(sx, sy, origin))
        return self

    def skew(self, skew_x_radians: float = 0.0, skew_y_radians: float = 0.0) -> "Transform":
        self.matrix = self.matrix.compose(Matrix.skewing(skew_x_radians, skew_y_radians))
        return self

    def reflect(self, axis: str = "x") -> "Transform":
        self.matrix = self.matrix.compose(Matrix.reflection(axis))
        return self

    def compose(self, other: "Transform | Matrix") -> "Transform":
        m = other.matrix if isinstance(other, Transform) else other
        self.matrix = self.matrix.compose(m)
        return self

    def inverse(self) -> "Transform":
        return Transform(self.matrix.inverse())

    def apply(self, point: Point) -> Point:
        x, y = self.matrix.apply_xy(point.x, point.y)
        return Point(x, y)

    def apply_vector(self, point: Point) -> Point:
        x, y = self.matrix.apply_vector_xy(point.x, point.y)
        return Point(x, y)

    def copy(self) -> "Transform":
        return Transform(self.matrix)

    @classmethod
    def identity(cls) -> "Transform":
        return cls(Matrix.identity())


def compose_chain(matrices: list[Matrix]) -> Matrix:
    """Compose a root-to-leaf list of ancestor matrices into one world matrix."""
    result = Matrix.identity()
    for m in matrices:
        result = result.compose(m)
    return result


@dataclass(frozen=True, slots=True)
class ViewTransform:
    """Document -> screen mapping used only by the renderer/UI, never persisted
    on scene objects. Combines pan, zoom and a device pixel ratio (Retina)."""

    pan_x: float = 0.0
    pan_y: float = 0.0
    zoom: float = 1.0
    device_scale: float = 1.0  # 1x / 2x / 3x, see spec section 37

    def to_matrix(self) -> Matrix:
        s = self.zoom * self.device_scale
        return Matrix(s, 0.0, 0.0, s, -self.pan_x * s, -self.pan_y * s)


def document_to_screen(document_matrix: Matrix, view: ViewTransform) -> Matrix:
    return document_matrix.compose(view.to_matrix())


def screen_to_document(document_matrix: Matrix, view: ViewTransform) -> Matrix:
    return document_to_screen(document_matrix, view).inverse()
