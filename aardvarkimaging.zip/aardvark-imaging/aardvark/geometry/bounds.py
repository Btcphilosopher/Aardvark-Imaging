"""Axis-aligned bounding boxes and the geometry/stroke/visual bounds triad.

A shape distinguishes three kinds of bounds (section 9 of the spec):

- ``geometry``: the raw path/anchor geometry, ignoring stroke and effects.
- ``stroke``: geometry expanded by half the stroke width (plus miter/cap
  allowance), i.e. what actually gets painted by the stroke.
- ``visual``: stroke bounds further expanded by effects (shadow, blur, glow).

:class:`Bounds` itself is just an immutable min/max box; :class:`BoundsSet`
groups the three together for a single query.
"""

from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class Bounds:
    min_x: float = math.inf
    min_y: float = math.inf
    max_x: float = -math.inf
    max_y: float = -math.inf

    @property
    def is_empty(self) -> bool:
        return self.min_x > self.max_x or self.min_y > self.max_y

    @property
    def width(self) -> float:
        return 0.0 if self.is_empty else self.max_x - self.min_x

    @property
    def height(self) -> float:
        return 0.0 if self.is_empty else self.max_y - self.min_y

    @property
    def center(self) -> tuple[float, float]:
        return ((self.min_x + self.max_x) / 2.0, (self.min_y + self.max_y) / 2.0)

    @classmethod
    def empty(cls) -> "Bounds":
        return cls()

    @classmethod
    def from_points(cls, points: list[tuple[float, float]]) -> "Bounds":
        if not points:
            return cls.empty()
        xs = [p[0] for p in points]
        ys = [p[1] for p in points]
        return cls(min(xs), min(ys), max(xs), max(ys))

    def union(self, other: "Bounds") -> "Bounds":
        if self.is_empty:
            return other
        if other.is_empty:
            return self
        return Bounds(
            min(self.min_x, other.min_x),
            min(self.min_y, other.min_y),
            max(self.max_x, other.max_x),
            max(self.max_y, other.max_y),
        )

    def intersects(self, other: "Bounds") -> bool:
        if self.is_empty or other.is_empty:
            return False
        return not (
            self.max_x < other.min_x
            or other.max_x < self.min_x
            or self.max_y < other.min_y
            or other.max_y < self.min_y
        )

    def intersection(self, other: "Bounds") -> "Bounds":
        if not self.intersects(other):
            return Bounds.empty()
        return Bounds(
            max(self.min_x, other.min_x),
            max(self.min_y, other.min_y),
            min(self.max_x, other.max_x),
            min(self.max_y, other.max_y),
        )

    def contains_point(self, x: float, y: float) -> bool:
        return self.min_x <= x <= self.max_x and self.min_y <= y <= self.max_y

    def expanded(self, amount: float) -> "Bounds":
        if self.is_empty:
            return self
        return Bounds(self.min_x - amount, self.min_y - amount, self.max_x + amount, self.max_y + amount)

    def as_xywh(self) -> tuple[float, float, float, float]:
        return (self.min_x, self.min_y, self.width, self.height)


@dataclass(frozen=True, slots=True)
class BoundsSet:
    """Geometry / stroke / visual bounds for one object, in world space."""

    geometry: Bounds
    stroke: Bounds
    visual: Bounds
