"""3x3 homogeneous matrices for 2D affine transforms.

A :class:`Matrix` stores the six degrees of freedom of a 2D affine map
using the standard PostScript/SVG convention::

    | a  c  e |   | x |   | a*x + c*y + e |
    | b  d  f | * | y | = | b*x + d*y + f |
    | 0  0  1 |   | 1 |   |       1       |

The bottom row is always ``[0, 0, 1]`` for an affine map, but it is carried
explicitly (as a 3x3 numpy array) so that composition is a plain matrix
multiplication and inversion is a plain linear-algebra inverse — no special
casing, no drift between a "fast path" and a "correct path".
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from aardvark.errors import GeometryError


@dataclass(frozen=True, slots=True)
class Matrix:
    a: float = 1.0
    b: float = 0.0
    c: float = 0.0
    d: float = 1.0
    e: float = 0.0
    f: float = 0.0

    # -- construction ---------------------------------------------------
    @classmethod
    def identity(cls) -> "Matrix":
        return cls()

    @classmethod
    def translation(cls, tx: float, ty: float) -> "Matrix":
        return cls(1.0, 0.0, 0.0, 1.0, tx, ty)

    @classmethod
    def scaling(cls, sx: float, sy: float | None = None, origin: tuple[float, float] = (0.0, 0.0)) -> "Matrix":
        sy = sx if sy is None else sy
        ox, oy = origin
        m = cls(sx, 0.0, 0.0, sy, ox - sx * ox, oy - sy * oy)
        return m

    @classmethod
    def rotation(cls, radians: float, origin: tuple[float, float] = (0.0, 0.0)) -> "Matrix":
        c, s = math.cos(radians), math.sin(radians)
        ox, oy = origin
        return cls(
            c, s, -s, c,
            ox - c * ox + s * oy,
            oy - s * ox - c * oy,
        )

    @classmethod
    def rotation_degrees(cls, degrees: float, origin: tuple[float, float] = (0.0, 0.0)) -> "Matrix":
        return cls.rotation(math.radians(degrees), origin)

    @classmethod
    def skewing(cls, skew_x_radians: float = 0.0, skew_y_radians: float = 0.0) -> "Matrix":
        return cls(1.0, math.tan(skew_y_radians), math.tan(skew_x_radians), 1.0, 0.0, 0.0)

    @classmethod
    def reflection(cls, axis: str = "x") -> "Matrix":
        if axis == "x":
            return cls(1.0, 0.0, 0.0, -1.0, 0.0, 0.0)
        if axis == "y":
            return cls(-1.0, 0.0, 0.0, 1.0, 0.0, 0.0)
        if axis == "origin":
            return cls(-1.0, 0.0, 0.0, -1.0, 0.0, 0.0)
        raise GeometryError(f"Unknown reflection axis: {axis!r}")

    @classmethod
    def from_numpy(cls, m: np.ndarray) -> "Matrix":
        # Cast back to native Python floats: numpy scalars are not JSON
        # serialisable and silently leak dtype quirks into the pure-Python
        # geometry layer if left as np.float64.
        return cls(
            float(m[0, 0]), float(m[1, 0]), float(m[0, 1]), float(m[1, 1]), float(m[0, 2]), float(m[1, 2])
        )

    def to_numpy(self) -> np.ndarray:
        return np.array(
            [
                [self.a, self.c, self.e],
                [self.b, self.d, self.f],
                [0.0, 0.0, 1.0],
            ],
            dtype=np.float64,
        )

    # -- composition ------------------------------------------------
    def compose(self, other: "Matrix") -> "Matrix":
        """Return ``self`` followed by ``other`` (i.e. ``other @ self``).

        Matches the usual "apply self first, then other" mental model used
        when building up object -> layer -> page -> document transforms.
        """
        m = other.to_numpy() @ self.to_numpy()
        return Matrix.from_numpy(m)

    def __matmul__(self, other: "Matrix") -> "Matrix":
        """``self @ other`` applies ``other`` first, then ``self`` (linear-algebra order)."""
        m = self.to_numpy() @ other.to_numpy()
        return Matrix.from_numpy(m)

    def inverse(self) -> "Matrix":
        det = self.a * self.d - self.b * self.c
        if abs(det) < 1e-12:
            raise GeometryError("Matrix is not invertible (determinant ~= 0)")
        ia = self.d / det
        ib = -self.b / det
        ic = -self.c / det
        id_ = self.a / det
        ie = -(ia * self.e + ic * self.f)
        if_ = -(ib * self.e + id_ * self.f)
        return Matrix(ia, ib, ic, id_, ie, if_)

    def is_identity(self, tolerance: float = 1e-9) -> bool:
        return (
            math.isclose(self.a, 1.0, abs_tol=tolerance)
            and math.isclose(self.b, 0.0, abs_tol=tolerance)
            and math.isclose(self.c, 0.0, abs_tol=tolerance)
            and math.isclose(self.d, 1.0, abs_tol=tolerance)
            and math.isclose(self.e, 0.0, abs_tol=tolerance)
            and math.isclose(self.f, 0.0, abs_tol=tolerance)
        )

    # -- application --------------------------------------------------
    def apply_xy(self, x: float, y: float) -> tuple[float, float]:
        return (self.a * x + self.c * y + self.e, self.b * x + self.d * y + self.f)

    def apply_vector_xy(self, x: float, y: float) -> tuple[float, float]:
        """Apply the linear part only (ignores translation) — for direction vectors."""
        return (self.a * x + self.c * y, self.b * x + self.d * y)

    def apply_points(self, points: np.ndarray) -> np.ndarray:
        """Apply to an (N, 2) numpy array of points, vectorised."""
        ones = np.ones((points.shape[0], 1), dtype=np.float64)
        homogeneous = np.hstack([points, ones])
        transformed = homogeneous @ self.to_numpy().T
        return transformed[:, :2]

    def decompose(self) -> dict[str, float]:
        """Decompose into translate / rotate / scale / skew for inspector UIs.

        Uses Gram-Schmidt orthogonalisation of the matrix's two column
        vectors (the images of the local x- and y-axes) rather than a
        trigonometric identity — the trig-identity approach this used to use
        divided by ``cos(skew)``, which blows up (or divides by a
        near-zero-but-not-exactly-zero float) whenever the skew is close to
        +-90 degrees, including the extremely common case of "no skew at
        all" landing exactly on that singularity after the rotation
        subtraction. Gram-Schmidt has no such singularity.
        """
        a, b, c, d = self.a, self.b, self.c, self.d
        scale_x = math.hypot(a, b)
        if scale_x == 0:
            raise GeometryError("Matrix is singular; cannot decompose scale")
        # x-axis image, normalised.
        x0, x1 = a / scale_x, b / scale_x
        # Component of the y-axis image along the (normalised) x-axis image
        # is the shear; subtract it out (Gram-Schmidt) to get the part of
        # the y-axis image that's orthogonal to the x-axis image.
        skew_dot = x0 * c + x1 * d
        oy0, oy1 = c - skew_dot * x0, d - skew_dot * x1
        scale_y = math.hypot(oy0, oy1)
        if scale_y == 0:
            raise GeometryError("Matrix is singular; cannot decompose scale")
        if (a * d - b * c) < 0:
            # A reflection (negative determinant): hypot() can't tell us
            # which axis flipped, so fold the sign into scale_y by
            # convention — reconstructing via scale/rotate/skew in that
            # order reproduces the original matrix either way.
            scale_y = -scale_y
        skew = math.atan2(skew_dot, abs(scale_y))
        rotation = math.atan2(x1, x0)
        return {
            "translate_x": self.e,
            "translate_y": self.f,
            "rotation": rotation,
            "scale_x": scale_x,
            "scale_y": scale_y,
            "skew": skew,
        }

    def to_svg_string(self) -> str:
        return f"matrix({self.a},{self.b},{self.c},{self.d},{self.e},{self.f})"

    def as_tuple(self) -> tuple[float, float, float, float, float, float]:
        return (self.a, self.b, self.c, self.d, self.e, self.f)
