"""2D free vectors (direction + magnitude, no fixed position)."""

from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class Vector2:
    x: float = 0.0
    y: float = 0.0

    def __post_init__(self) -> None:
        object.__setattr__(self, "x", float(self.x))
        object.__setattr__(self, "y", float(self.y))

    def __add__(self, other: "Vector2") -> "Vector2":
        return Vector2(self.x + other.x, self.y + other.y)

    def __sub__(self, other: "Vector2") -> "Vector2":
        return Vector2(self.x - other.x, self.y - other.y)

    def __mul__(self, scalar: float) -> "Vector2":
        return Vector2(self.x * scalar, self.y * scalar)

    __rmul__ = __mul__

    def __truediv__(self, scalar: float) -> "Vector2":
        return Vector2(self.x / scalar, self.y / scalar)

    def __neg__(self) -> "Vector2":
        return Vector2(-self.x, -self.y)

    def dot(self, other: "Vector2") -> float:
        return self.x * other.x + self.y * other.y

    def cross(self, other: "Vector2") -> float:
        """The z-component of the 3D cross product (a scalar in 2D)."""
        return self.x * other.y - self.y * other.x

    def length(self) -> float:
        return math.hypot(self.x, self.y)

    def length_squared(self) -> float:
        return self.x * self.x + self.y * self.y

    def normalized(self) -> "Vector2":
        length = self.length()
        if length == 0.0:
            return Vector2(0.0, 0.0)
        return Vector2(self.x / length, self.y / length)

    def perpendicular(self) -> "Vector2":
        """A vector rotated +90 degrees (counter-clockwise in y-down space)."""
        return Vector2(-self.y, self.x)

    def angle(self) -> float:
        """Angle in radians, measured from the positive x-axis."""
        return math.atan2(self.y, self.x)

    def angle_to(self, other: "Vector2") -> float:
        return math.atan2(self.cross(other), self.dot(other))

    def rotated(self, radians: float) -> "Vector2":
        c, s = math.cos(radians), math.sin(radians)
        return Vector2(self.x * c - self.y * s, self.x * s + self.y * c)

    @classmethod
    def from_points(cls, a: "object", b: "object") -> "Vector2":
        return cls(b.x - a.x, b.y - a.y)
