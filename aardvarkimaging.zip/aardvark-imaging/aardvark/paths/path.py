"""The core vector path model: subpaths of lines/quadratics/cubics, with a
PostScript-style builder API and a node/handle editing API for interactive
editors (spec sections 11-12).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from aardvark.errors import GeometryError
from aardvark.geometry.bounds import Bounds
from aardvark.geometry.intersections import point_in_polygon, point_segment_distance
from aardvark.geometry.matrix import Matrix
from aardvark.geometry.point import Point
from aardvark.paths.bezier import CubicBezier, QuadraticBezier
from aardvark.paths.segment import ClosePath, CurveTo, LineTo, MoveTo, QuadTo, Segment


class NodeType(str, Enum):
    CORNER = "corner"
    SMOOTH = "smooth"
    SYMMETRIC = "symmetric"


# A subpath vertex is either a straight LineTo, a QuadTo, or a CurveTo,
# addressed relative to the *previous* anchor (which is `start` for index 0).
_VertexSegment = LineTo | QuadTo | CurveTo


@dataclass(slots=True)
class Subpath:
    start: Point
    segments: list[_VertexSegment] = field(default_factory=list)
    closed: bool = False
    node_types: list[NodeType] = field(default_factory=list)

    def __post_init__(self) -> None:
        if not self.node_types:
            self.node_types = [NodeType.CORNER] * (1 + len(self.segments))

    def anchors(self) -> list[Point]:
        pts = [self.start]
        for seg in self.segments:
            pts.append(seg.point)
        return pts

    def bounds(self) -> Bounds:
        b = Bounds.from_points([self.start.as_tuple()])
        cur = self.start
        for seg in self.segments:
            if isinstance(seg, LineTo):
                b = b.union(Bounds.from_points([seg.point.as_tuple()]))
            elif isinstance(seg, QuadTo):
                qb = QuadraticBezier(cur, seg.control, seg.point).bounds()
                b = b.union(qb)
            elif isinstance(seg, CurveTo):
                cb = CubicBezier(cur, seg.control1, seg.control2, seg.point).bounds()
                b = b.union(cb)
            cur = seg.point
        return b

    def length(self) -> float:
        total = 0.0
        cur = self.start
        for seg in self.segments:
            if isinstance(seg, LineTo):
                total += cur.distance_to(seg.point)
            elif isinstance(seg, QuadTo):
                total += QuadraticBezier(cur, seg.control, seg.point).length()
            elif isinstance(seg, CurveTo):
                total += CubicBezier(cur, seg.control1, seg.control2, seg.point).length()
            cur = seg.point
        if self.closed:
            total += cur.distance_to(self.start)
        return total

    def flatten(self, tolerance: float | None = None) -> list[Point]:
        points = [self.start]
        cur = self.start
        for seg in self.segments:
            if isinstance(seg, LineTo):
                points.append(seg.point)
            elif isinstance(seg, QuadTo):
                pts = QuadraticBezier(cur, seg.control, seg.point).flatten(tolerance)
                points.extend(pts[1:])
            elif isinstance(seg, CurveTo):
                pts = CubicBezier(cur, seg.control1, seg.control2, seg.point).flatten(tolerance)
                points.extend(pts[1:])
            cur = seg.point
        return points

    def transformed(self, matrix: Matrix) -> "Subpath":
        def tp(p: Point) -> Point:
            x, y = matrix.apply_xy(p.x, p.y)
            return Point(x, y)

        new_segments: list[_VertexSegment] = []
        for seg in self.segments:
            if isinstance(seg, LineTo):
                new_segments.append(LineTo(tp(seg.point)))
            elif isinstance(seg, QuadTo):
                new_segments.append(QuadTo(tp(seg.control), tp(seg.point)))
            elif isinstance(seg, CurveTo):
                new_segments.append(CurveTo(tp(seg.control1), tp(seg.control2), tp(seg.point)))
        return Subpath(tp(self.start), new_segments, self.closed, list(self.node_types))

    def reversed(self) -> "Subpath":
        anchors = self.anchors()
        n = len(self.segments)
        new_segments: list[_VertexSegment] = []
        for i in range(n - 1, -1, -1):
            seg = self.segments[i]
            end_point = anchors[i]  # becomes the new segment's endpoint
            if isinstance(seg, LineTo):
                new_segments.append(LineTo(end_point))
            elif isinstance(seg, QuadTo):
                new_segments.append(QuadTo(seg.control, end_point))
            elif isinstance(seg, CurveTo):
                new_segments.append(CurveTo(seg.control2, seg.control1, end_point))
        return Subpath(anchors[-1], new_segments, self.closed, list(reversed(self.node_types)))

    def copy(self) -> "Subpath":
        return Subpath(self.start, list(self.segments), self.closed, list(self.node_types))


@dataclass(slots=True)
class Path:
    """A compound vector path: zero or more subpaths, each open or closed."""

    subpaths: list[Subpath] = field(default_factory=list)
    fill_rule: str = "nonzero"  # or "evenodd"

    # -- builder API (spec section 11) --------------------------------
    def move_to(self, x: float, y: float) -> "Path":
        self.subpaths.append(Subpath(Point(x, y)))
        return self

    def line_to(self, x: float, y: float) -> "Path":
        self._require_current().segments.append(LineTo(Point(x, y)))
        self._require_current().node_types.append(NodeType.CORNER)
        return self

    def quad_to(self, cx: float, cy: float, x: float, y: float) -> "Path":
        sp = self._require_current()
        sp.segments.append(QuadTo(Point(cx, cy), Point(x, y)))
        sp.node_types.append(NodeType.CORNER)
        return self

    def curve_to(self, c1x: float, c1y: float, c2x: float, c2y: float, x: float, y: float) -> "Path":
        sp = self._require_current()
        sp.segments.append(CurveTo(Point(c1x, c1y), Point(c2x, c2y), Point(x, y)))
        sp.node_types.append(NodeType.CORNER)
        return self

    def close(self) -> "Path":
        self._require_current().closed = True
        return self

    def _require_current(self) -> Subpath:
        if not self.subpaths:
            raise GeometryError("Path has no current subpath; call move_to() first")
        return self.subpaths[-1]

    @property
    def current_point(self) -> Point | None:
        if not self.subpaths:
            return None
        sp = self.subpaths[-1]
        return sp.segments[-1].point if sp.segments else sp.start

    # -- flat segment interchange --------------------------------------
    def to_segments(self) -> list[Segment]:
        out: list[Segment] = []
        for sp in self.subpaths:
            out.append(MoveTo(sp.start))
            out.extend(sp.segments)
            if sp.closed:
                out.append(ClosePath())
        return out

    @classmethod
    def from_segments(cls, segments: list[Segment], fill_rule: str = "nonzero") -> "Path":
        path = cls(fill_rule=fill_rule)
        for seg in segments:
            if isinstance(seg, MoveTo):
                path.move_to(seg.point.x, seg.point.y)
            elif isinstance(seg, LineTo):
                path.line_to(seg.point.x, seg.point.y)
            elif isinstance(seg, QuadTo):
                path.quad_to(seg.control.x, seg.control.y, seg.point.x, seg.point.y)
            elif isinstance(seg, CurveTo):
                path.curve_to(
                    seg.control1.x, seg.control1.y, seg.control2.x, seg.control2.y, seg.point.x, seg.point.y
                )
            elif isinstance(seg, ClosePath):
                path.close()
        return path

    # -- geometry -------------------------------------------------------
    def bounds(self) -> Bounds:
        b = Bounds.empty()
        for sp in self.subpaths:
            b = b.union(sp.bounds())
        return b

    def length(self) -> float:
        return sum(sp.length() for sp in self.subpaths)

    def flatten(self, tolerance: float | None = None) -> list[list[Point]]:
        """Flatten every subpath into a polyline. Returns one list per subpath."""
        return [sp.flatten(tolerance) for sp in self.subpaths]

    def transformed(self, matrix: Matrix) -> "Path":
        return Path([sp.transformed(matrix) for sp in self.subpaths], self.fill_rule)

    def contains_point(self, p: Point, tolerance: float | None = None) -> bool:
        even_odd = self.fill_rule == "evenodd"
        polygons = self.flatten(tolerance)
        if even_odd:
            # Even-odd across all subpaths: count crossings from every ring.
            crossings = 0
            for poly in polygons:
                if point_in_polygon(p, poly, even_odd=True):
                    crossings += 1
            return crossings % 2 == 1
        # Nonzero: sum of individual winding contributions.
        from aardvark.geometry.intersections import winding_number

        total = sum(winding_number(p, poly) for poly in polygons)
        return total != 0

    def distance_to_point(self, p: Point, tolerance: float | None = None) -> float:
        """Minimum distance from ``p`` to any edge of the flattened path (for stroke hit-testing)."""
        best = float("inf")
        for poly in self.flatten(tolerance):
            n = len(poly)
            limit = n if (n > 0 and self._subpath_closed_flag(poly)) else n - 1
            for i in range(max(0, limit)):
                a = poly[i]
                b = poly[(i + 1) % n]
                d = point_segment_distance(p, a, b)
                if d < best:
                    best = d
        return best

    def _subpath_closed_flag(self, poly: list[Point]) -> bool:
        # flatten() doesn't carry closed-ness with the polyline directly;
        # callers needing exact closure should use distance via subpaths.
        return False

    def reverse(self) -> "Path":
        return Path([sp.reversed() for sp in self.subpaths], self.fill_rule)

    def is_empty(self) -> bool:
        return len(self.subpaths) == 0 or all(not sp.segments for sp in self.subpaths)

    def copy(self) -> "Path":
        return Path([sp.copy() for sp in self.subpaths], self.fill_rule)

    # -- node/handle editing (spec section 12) --------------------------
    def get_node_count(self, subpath_index: int) -> int:
        return len(self.subpaths[subpath_index].anchors())

    def move_node(self, subpath_index: int, node_index: int, dx: float, dy: float) -> None:
        """Rigidly translate an anchor and its two handles by (dx, dy)."""
        sp = self.subpaths[subpath_index]
        delta = Point(dx, dy)
        if node_index == 0:
            sp.start = sp.start + delta
        else:
            seg = sp.segments[node_index - 1]
            sp.segments[node_index - 1] = _with_point(seg, seg.point + delta)
        # Drag the outgoing handle (control1 of the segment leaving this node).
        if node_index < len(sp.segments):
            nxt = sp.segments[node_index]
            if isinstance(nxt, CurveTo):
                sp.segments[node_index] = CurveTo(nxt.control1 + delta, nxt.control2, nxt.point)
            elif isinstance(nxt, QuadTo):
                sp.segments[node_index] = QuadTo(nxt.control + delta, nxt.point)
        # Drag the incoming handle (control2 of the segment arriving at this node).
        if node_index > 0:
            prev = sp.segments[node_index - 1]
            if isinstance(prev, CurveTo):
                sp.segments[node_index - 1] = CurveTo(prev.control1, prev.control2 + delta, prev.point)

    def move_handle(self, subpath_index: int, node_index: int, which: str, dx: float, dy: float) -> None:
        """Move one Bezier handle of a node. ``which`` is 'in' or 'out'.

        Respects the node's :class:`NodeType`: SYMMETRIC mirrors the opposite
        handle with equal length, SMOOTH mirrors direction only, CORNER
        leaves the opposite handle untouched.
        """
        sp = self.subpaths[subpath_index]
        node_type = sp.node_types[node_index]
        anchor = sp.anchors()[node_index]

        if which == "out" and node_index < len(sp.segments):
            seg = sp.segments[node_index]
            if not isinstance(seg, CurveTo):
                raise GeometryError("Node's outgoing segment has no editable handle (not a curve)")
            new_out = seg.control1 + Point(dx, dy)
            sp.segments[node_index] = CurveTo(new_out, seg.control2, seg.point)
            self._mirror_opposite_handle(sp, node_index, anchor, new_out, moved="out", node_type=node_type)
        elif which == "in" and node_index > 0:
            seg = sp.segments[node_index - 1]
            if not isinstance(seg, CurveTo):
                raise GeometryError("Node's incoming segment has no editable handle (not a curve)")
            new_in = seg.control2 + Point(dx, dy)
            sp.segments[node_index - 1] = CurveTo(seg.control1, new_in, seg.point)
            self._mirror_opposite_handle(sp, node_index, anchor, new_in, moved="in", node_type=node_type)
        else:
            raise GeometryError(f"No {which!r} handle at node {node_index}")

    def _mirror_opposite_handle(
        self, sp: Subpath, node_index: int, anchor: Point, moved_handle: Point, moved: str, node_type: NodeType
    ) -> None:
        if node_type == NodeType.CORNER:
            return
        offset = moved_handle - anchor
        if moved == "out" and node_index > 0:
            seg = sp.segments[node_index - 1]
            if isinstance(seg, CurveTo):
                if node_type == NodeType.SYMMETRIC:
                    new_in = anchor - offset
                else:  # SMOOTH: preserve the opposite handle's own length, mirror direction only
                    length = anchor.distance_to(seg.control2)
                    direction = (-offset).normalized_point()
                    new_in = anchor + direction * length
                sp.segments[node_index - 1] = CurveTo(seg.control1, new_in, seg.point)
        elif moved == "in" and node_index < len(sp.segments):
            seg = sp.segments[node_index]
            if isinstance(seg, CurveTo):
                if node_type == NodeType.SYMMETRIC:
                    new_out = anchor - offset
                else:
                    length = anchor.distance_to(seg.control1)
                    direction = (-offset).normalized_point()
                    new_out = anchor + direction * length
                sp.segments[node_index] = CurveTo(new_out, seg.control2, seg.point)

    def convert_node(self, subpath_index: int, node_index: int, node_type: NodeType) -> None:
        """Change a node's editing constraint, adjusting handles to satisfy it immediately."""
        sp = self.subpaths[subpath_index]
        sp.node_types[node_index] = node_type
        if node_type == NodeType.CORNER:
            return
        anchor = sp.anchors()[node_index]
        handle_in = self._handle_in(sp, node_index)
        handle_out = self._handle_out(sp, node_index)
        if handle_in is None or handle_out is None:
            return
        if node_type == NodeType.SYMMETRIC:
            avg_len = (anchor.distance_to(handle_in) + anchor.distance_to(handle_out)) / 2.0
            direction = (handle_out - anchor).normalized_point()
            if node_index > 0:
                seg = sp.segments[node_index - 1]
                if isinstance(seg, CurveTo):
                    sp.segments[node_index - 1] = CurveTo(seg.control1, anchor - direction * avg_len, seg.point)
            if node_index < len(sp.segments):
                seg = sp.segments[node_index]
                if isinstance(seg, CurveTo):
                    sp.segments[node_index] = CurveTo(anchor + direction * avg_len, seg.control2, seg.point)
        elif node_type == NodeType.SMOOTH:
            direction = (handle_out - anchor).normalized_point()
            in_len = anchor.distance_to(handle_in)
            out_len = anchor.distance_to(handle_out)
            if node_index > 0:
                seg = sp.segments[node_index - 1]
                if isinstance(seg, CurveTo):
                    sp.segments[node_index - 1] = CurveTo(seg.control1, anchor - direction * in_len, seg.point)
            if node_index < len(sp.segments):
                seg = sp.segments[node_index]
                if isinstance(seg, CurveTo):
                    sp.segments[node_index] = CurveTo(anchor + direction * out_len, seg.control2, seg.point)

    @staticmethod
    def _handle_in(sp: Subpath, node_index: int) -> Point | None:
        if node_index == 0:
            return None
        seg = sp.segments[node_index - 1]
        return seg.control2 if isinstance(seg, CurveTo) else None

    @staticmethod
    def _handle_out(sp: Subpath, node_index: int) -> Point | None:
        if node_index >= len(sp.segments):
            return None
        seg = sp.segments[node_index]
        return seg.control1 if isinstance(seg, CurveTo) else None

    def add_node(self, subpath_index: int, segment_index: int, t: float) -> None:
        """Insert a new anchor at parameter ``t`` along segment ``segment_index``
        (0-based, the segment leading *into* anchor ``segment_index + 1``),
        splitting it into two equivalent segments so the visible geometry is
        unchanged."""
        sp = self.subpaths[subpath_index]
        seg = sp.segments[segment_index]
        start = sp.start if segment_index == 0 else sp.segments[segment_index - 1].point
        if isinstance(seg, LineTo):
            mid = start.lerp(seg.point, t)
            new_segs = [LineTo(mid), LineTo(seg.point)]
        elif isinstance(seg, QuadTo):
            left, right = QuadraticBezier(start, seg.control, seg.point).split(t)
            new_segs = [QuadTo(left.p1, left.p2), QuadTo(right.p1, right.p2)]
        elif isinstance(seg, CurveTo):
            left, right = CubicBezier(start, seg.control1, seg.control2, seg.point).split(t)
            new_segs = [CurveTo(left.p1, left.p2, left.p3), CurveTo(right.p1, right.p2, right.p3)]
        else:
            raise GeometryError("Unsupported segment type for node insertion")
        sp.segments[segment_index : segment_index + 1] = new_segs
        sp.node_types.insert(segment_index + 1, NodeType.CORNER)

    def delete_node(self, subpath_index: int, node_index: int) -> None:
        """Remove an anchor, welding its neighbours with a straight line."""
        sp = self.subpaths[subpath_index]
        anchors = sp.anchors()
        n = len(anchors)
        if n <= 2:
            raise GeometryError("Cannot delete a node from a subpath with only 2 anchors")
        if node_index == 0:
            sp.start = anchors[1]
            sp.segments.pop(0)
            sp.node_types.pop(0)
        elif node_index == n - 1:
            sp.segments.pop()
            sp.node_types.pop()
        else:
            sp.segments[node_index - 1] = LineTo(anchors[node_index + 1])
            del sp.segments[node_index]
            del sp.node_types[node_index]

    def reverse_subpath(self, subpath_index: int) -> None:
        self.subpaths[subpath_index] = self.subpaths[subpath_index].reversed()

    def close_subpath(self, subpath_index: int) -> None:
        self.subpaths[subpath_index].closed = True

    def open_subpath(self, subpath_index: int) -> None:
        self.subpaths[subpath_index].closed = False

    def break_subpath(self, subpath_index: int, node_index: int) -> None:
        """Split an open subpath into two subpaths at ``node_index``, or open
        a closed subpath at that node (rotating it so it starts there)."""
        sp = self.subpaths[subpath_index]
        anchors = sp.anchors()
        if sp.closed:
            # Rotate the closed loop so node_index becomes the new start, then open it.
            k = node_index
            rotated_segments = sp.segments[k:] + sp.segments[:k]
            new_start = anchors[k]
            self.subpaths[subpath_index] = Subpath(new_start, rotated_segments, closed=False)
            return
        if node_index <= 0 or node_index >= len(sp.segments):
            raise GeometryError("break_subpath needs an interior node on an open subpath")
        first = Subpath(sp.start, sp.segments[:node_index], closed=False)
        second = Subpath(anchors[node_index], sp.segments[node_index:], closed=False)
        self.subpaths[subpath_index : subpath_index + 1] = [first, second]

    def join_subpaths(self, first_index: int, second_index: int) -> None:
        """Join two open subpaths end-to-end with a straight connecting segment."""
        a = self.subpaths[first_index]
        b = self.subpaths[second_index]
        if a.closed or b.closed:
            raise GeometryError("Cannot join a closed subpath")
        end_a = a.anchors()[-1]
        connector = LineTo(b.start) if not end_a.is_close(b.start) else None
        combined_segments = list(a.segments)
        if connector is not None:
            combined_segments.append(connector)
        combined_segments.extend(b.segments)
        combined = Subpath(a.start, combined_segments, closed=False)
        keep_indices = [i for i in (first_index, second_index)]
        lo, hi = min(keep_indices), max(keep_indices)
        self.subpaths[lo] = combined
        del self.subpaths[hi]

    def extend(self, other: "Path") -> "Path":
        """Append another path's subpaths to this one (compound path)."""
        self.subpaths.extend(sp.copy() for sp in other.subpaths)
        return self

    @classmethod
    def combine(cls, paths: list["Path"], fill_rule: str = "nonzero") -> "Path":
        out = cls(fill_rule=fill_rule)
        for p in paths:
            out.extend(p)
        return out


def _with_point(seg: _VertexSegment, new_point: Point) -> _VertexSegment:
    if isinstance(seg, LineTo):
        return LineTo(new_point)
    if isinstance(seg, QuadTo):
        return QuadTo(seg.control, new_point)
    if isinstance(seg, CurveTo):
        return CurveTo(seg.control1, seg.control2, new_point)
    raise GeometryError("Unsupported segment type")
