"""Flat path-command representation (SVG/PostScript style).

:class:`~aardvark.paths.path.Path` stores its geometry as a list of
:class:`Subpath`, but every subpath can be converted to/from this flat
command list — the natural interchange form for SVG ``d`` attributes, PDF
content streams, and the builder API shown in the spec::

    path.move_to(100, 100)
    path.line_to(200, 100)
    path.curve_to(250, 100, 250, 200, 200, 200)
    path.close()
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Union

from aardvark.geometry.point import Point


@dataclass(frozen=True, slots=True)
class MoveTo:
    point: Point


@dataclass(frozen=True, slots=True)
class LineTo:
    point: Point


@dataclass(frozen=True, slots=True)
class QuadTo:
    control: Point
    point: Point


@dataclass(frozen=True, slots=True)
class CurveTo:
    control1: Point
    control2: Point
    point: Point


@dataclass(frozen=True, slots=True)
class ClosePath:
    pass


Segment = Union[MoveTo, LineTo, QuadTo, CurveTo, ClosePath]
