"""Polyline/path simplification (Ramer-Douglas-Peucker)."""

from __future__ import annotations

from aardvark.geometry.intersections import point_segment_distance
from aardvark.geometry.point import Point
from aardvark.paths.path import Path


def simplify_polyline(points: list[Point], tolerance: float = 0.5) -> list[Point]:
    """Ramer-Douglas-Peucker simplification. Keeps endpoints; drops interior
    points whose deviation from the simplified chord is within ``tolerance``."""
    if len(points) < 3:
        return list(points)

    def rdp(pts: list[Point]) -> list[Point]:
        if len(pts) < 3:
            return pts
        first, last = pts[0], pts[-1]
        max_dist = -1.0
        index = -1
        for i in range(1, len(pts) - 1):
            d = point_segment_distance(pts[i], first, last)
            if d > max_dist:
                max_dist, index = d, i
        if max_dist > tolerance:
            left = rdp(pts[: index + 1])
            right = rdp(pts[index:])
            return left[:-1] + right
        return [first, last]

    return rdp(points)


def simplify_path(path: Path, tolerance: float = 0.5, flatten_tolerance: float | None = None) -> Path:
    """Simplify a path by flattening it to polylines, running RDP, and
    rebuilding a new :class:`Path` made of straight line segments.

    This intentionally trades curve fidelity for a smaller node count — it is
    meant for "simplify path" editing operations and export size reduction,
    not as a lossless curve-fitting algorithm.
    """
    out = Path(fill_rule=path.fill_rule)
    for sp, poly in zip(path.subpaths, path.flatten(flatten_tolerance)):
        simplified = simplify_polyline(poly, tolerance)
        if not simplified:
            continue
        out.move_to(simplified[0].x, simplified[0].y)
        for p in simplified[1:]:
            out.line_to(p.x, p.y)
        if sp.closed:
            out.close()
    return out
