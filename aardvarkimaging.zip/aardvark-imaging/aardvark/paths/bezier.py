"""Quadratic and cubic Bezier curve mathematics.

Numerically stable implementations: evaluation uses Horner-form Bernstein
polynomials, subdivision uses de Casteljau's algorithm (never differentiates
a naively-expanded polynomial), and arc length uses Gauss-Legendre
quadrature rather than a fixed polyline sum, so that ``length()`` converges
to the true value as ``config.curve_length_subdivisions`` increases.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from aardvark.config import DEFAULT_CONFIG
from aardvark.geometry.bounds import Bounds
from aardvark.geometry.point import Point

# 5-point Gauss-Legendre nodes/weights on [-1, 1], reused for every curve.
_GL_NODES, _GL_WEIGHTS = np.polynomial.legendre.leggauss(5)


@dataclass(frozen=True, slots=True)
class QuadraticBezier:
    p0: Point
    p1: Point
    p2: Point

    def evaluate(self, t: float) -> Point:
        mt = 1.0 - t
        x = mt * mt * self.p0.x + 2 * mt * t * self.p1.x + t * t * self.p2.x
        y = mt * mt * self.p0.y + 2 * mt * t * self.p1.y + t * t * self.p2.y
        return Point(x, y)

    def derivative(self, t: float) -> Point:
        mt = 1.0 - t
        x = 2 * mt * (self.p1.x - self.p0.x) + 2 * t * (self.p2.x - self.p1.x)
        y = 2 * mt * (self.p1.y - self.p0.y) + 2 * t * (self.p2.y - self.p1.y)
        return Point(x, y)

    def split(self, t: float) -> tuple["QuadraticBezier", "QuadraticBezier"]:
        p01 = self.p0.lerp(self.p1, t)
        p12 = self.p1.lerp(self.p2, t)
        p012 = p01.lerp(p12, t)
        return QuadraticBezier(self.p0, p01, p012), QuadraticBezier(p012, p12, self.p2)

    def to_cubic(self) -> "CubicBezier":
        c1 = self.p0 + (self.p1 - self.p0) * (2.0 / 3.0)
        c2 = self.p2 + (self.p1 - self.p2) * (2.0 / 3.0)
        return CubicBezier(self.p0, c1, c2, self.p2)

    def length(self, subdivisions: int | None = None) -> float:
        return self.to_cubic().length(subdivisions)

    def bounds(self) -> Bounds:
        return self.to_cubic().bounds()

    def flatten(self, tolerance: float | None = None) -> list[Point]:
        return self.to_cubic().flatten(tolerance)

    def nearest_point(self, target: Point, samples: int = 64) -> tuple[float, Point, float]:
        return self.to_cubic().nearest_point(target, samples)


@dataclass(frozen=True, slots=True)
class CubicBezier:
    p0: Point
    p1: Point
    p2: Point
    p3: Point

    def evaluate(self, t: float) -> Point:
        mt = 1.0 - t
        mt2, t2 = mt * mt, t * t
        a = mt2 * mt
        b = 3 * mt2 * t
        c = 3 * mt * t2
        d = t2 * t
        x = a * self.p0.x + b * self.p1.x + c * self.p2.x + d * self.p3.x
        y = a * self.p0.y + b * self.p1.y + c * self.p2.y + d * self.p3.y
        return Point(x, y)

    def derivative(self, t: float) -> Point:
        mt = 1.0 - t
        x = (
            3 * mt * mt * (self.p1.x - self.p0.x)
            + 6 * mt * t * (self.p2.x - self.p1.x)
            + 3 * t * t * (self.p3.x - self.p2.x)
        )
        y = (
            3 * mt * mt * (self.p1.y - self.p0.y)
            + 6 * mt * t * (self.p2.y - self.p1.y)
            + 3 * t * t * (self.p3.y - self.p2.y)
        )
        return Point(x, y)

    def second_derivative(self, t: float) -> Point:
        mt = 1.0 - t
        x = 6 * mt * (self.p2.x - 2 * self.p1.x + self.p0.x) + 6 * t * (self.p3.x - 2 * self.p2.x + self.p1.x)
        y = 6 * mt * (self.p2.y - 2 * self.p1.y + self.p0.y) + 6 * t * (self.p3.y - 2 * self.p2.y + self.p1.y)
        return Point(x, y)

    def split(self, t: float) -> tuple["CubicBezier", "CubicBezier"]:
        p01 = self.p0.lerp(self.p1, t)
        p12 = self.p1.lerp(self.p2, t)
        p23 = self.p2.lerp(self.p3, t)
        p012 = p01.lerp(p12, t)
        p123 = p12.lerp(p23, t)
        p0123 = p012.lerp(p123, t)
        return CubicBezier(self.p0, p01, p012, p0123), CubicBezier(p0123, p123, p23, self.p3)

    def sub_curve(self, t0: float, t1: float) -> "CubicBezier":
        """The portion of this curve between parameters t0 and t1 (t0 < t1)."""
        _, right = self.split(t0)
        # Re-parameterise t1 into the [t0, 1] remainder's local [0, 1] range.
        local_t1 = (t1 - t0) / (1.0 - t0) if t0 < 1.0 else 1.0
        left, _ = right.split(local_t1)
        return left

    def length(self, subdivisions: int | None = None) -> float:
        """Arc length via 5-point Gauss-Legendre quadrature, optionally
        composited over ``subdivisions`` equal sub-intervals for extra
        accuracy on high-curvature curves."""
        n = subdivisions or DEFAULT_CONFIG.curve_length_subdivisions
        n = max(1, n // 5) if n >= 5 else 1
        total = 0.0
        step = 1.0 / n
        half = step / 2.0
        for i in range(n):
            t0 = i * step
            t1 = t0 + step
            mid = (t0 + t1) / 2.0
            for node, weight in zip(_GL_NODES, _GL_WEIGHTS):
                t = mid + half * node
                d = self.derivative(t)
                total += weight * math.hypot(d.x, d.y)
        return total * half

    def bounds(self) -> Bounds:
        xs = [self.p0.x, self.p3.x]
        ys = [self.p0.y, self.p3.y]
        for t in self._extrema_ts_x():
            if 0.0 < t < 1.0:
                xs.append(self.evaluate(t).x)
        for t in self._extrema_ts_y():
            if 0.0 < t < 1.0:
                ys.append(self.evaluate(t).y)
        return Bounds(min(xs), min(ys), max(xs), max(ys))

    def _extrema_ts_x(self) -> list[float]:
        return _quadratic_roots(
            3 * (-self.p0.x + 3 * self.p1.x - 3 * self.p2.x + self.p3.x),
            6 * (self.p0.x - 2 * self.p1.x + self.p2.x),
            3 * (self.p1.x - self.p0.x),
        )

    def _extrema_ts_y(self) -> list[float]:
        return _quadratic_roots(
            3 * (-self.p0.y + 3 * self.p1.y - 3 * self.p2.y + self.p3.y),
            6 * (self.p0.y - 2 * self.p1.y + self.p2.y),
            3 * (self.p1.y - self.p0.y),
        )

    def flatten(self, tolerance: float | None = None) -> list[Point]:
        """Adaptive recursive subdivision into a polyline within ``tolerance``.

        Uses the standard flatness test: the curve is "flat enough" once
        the control points p1/p2 lie within ``tolerance`` of the p0-p3 chord.
        """
        tol = tolerance if tolerance is not None else DEFAULT_CONFIG.bezier_flatten_tolerance
        points: list[Point] = [self.p0]
        self._flatten_recursive(tol, points, depth=0)
        points.append(self.p3)
        return points

    def _flatten_recursive(self, tol: float, out: list[Point], depth: int) -> None:
        if depth >= 24 or self._is_flat(tol):
            return
        left, right = self.split(0.5)
        left._flatten_recursive(tol, out, depth + 1)
        out.append(left.p3)
        right._flatten_recursive(tol, out, depth + 1)

    def _is_flat(self, tol: float) -> bool:
        ux = (3 * self.p1.x - 2 * self.p0.x - self.p3.x)
        uy = (3 * self.p1.y - 2 * self.p0.y - self.p3.y)
        vx = (3 * self.p2.x - self.p0.x - 2 * self.p3.x)
        vy = (3 * self.p2.y - self.p0.y - 2 * self.p3.y)
        ux *= ux
        uy *= uy
        vx *= vx
        vy *= vy
        if ux < vx:
            ux = vx
        if uy < vy:
            uy = vy
        return (ux + uy) <= 16.0 * tol * tol

    def nearest_point(self, target: Point, samples: int = 64) -> tuple[float, Point, float]:
        """Coarse sample + golden-section refinement to find the closest
        point on the curve to ``target``. Returns (t, point, distance)."""
        best_t, best_d2 = 0.0, math.inf
        for i in range(samples + 1):
            t = i / samples
            p = self.evaluate(t)
            d2 = (p.x - target.x) ** 2 + (p.y - target.y) ** 2
            if d2 < best_d2:
                best_d2, best_t = d2, t

        step = 1.0 / samples
        lo = max(0.0, best_t - step)
        hi = min(1.0, best_t + step)

        def dist2(t: float) -> float:
            p = self.evaluate(t)
            return (p.x - target.x) ** 2 + (p.y - target.y) ** 2

        gr = (math.sqrt(5) - 1) / 2
        a, b = lo, hi
        c = b - gr * (b - a)
        d = a + gr * (b - a)
        for _ in range(64):
            if abs(b - a) < 1e-12:
                break
            if dist2(c) < dist2(d):
                b = d
            else:
                a = c
            c = b - gr * (b - a)
            d = a + gr * (b - a)
        t_final = (a + b) / 2.0
        point = self.evaluate(t_final)
        return t_final, point, math.sqrt(dist2(t_final))


def _quadratic_roots(a: float, b: float, c: float) -> list[float]:
    if abs(a) < 1e-12:
        if abs(b) < 1e-12:
            return []
        return [-c / b]
    disc = b * b - 4 * a * c
    if disc < 0:
        return []
    sq = math.sqrt(disc)
    return [(-b + sq) / (2 * a), (-b - sq) / (2 * a)]
