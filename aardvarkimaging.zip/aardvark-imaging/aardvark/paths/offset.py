"""Path offsetting and stroke-to-fill conversion.

Uses the Clipper offsetting engine (via ``pyclipper``) — the same robust,
battle-tested polygon-offsetting algorithm used by most production vector
tools. Curves are flattened to polylines before offsetting (Clipper operates
on polygons); the flatten tolerance is configurable so callers can trade
fidelity for speed. This is disclosed here rather than hidden: the output is
a *polygonal* approximation of the true offset curve, accurate to within the
flatten tolerance.
"""

from __future__ import annotations

import pyclipper

from aardvark.errors import GeometryError
from aardvark.geometry.point import Point
from aardvark.paths.flatten import flatten_path_closed_rings
from aardvark.paths.path import Path

# Clipper's integer engine needs a fixed-point scale. 10_000 gives 4 decimal
# digits of sub-unit precision while staying well inside its 64-bit range
# for documents up to roughly 10^10 units across.
CLIPPER_SCALE = 10_000.0

_JOIN_TYPES = {
    "miter": pyclipper.JT_MITER,
    "round": pyclipper.JT_ROUND,
    "bevel": pyclipper.JT_SQUARE,
}

_OPEN_END_TYPES = {
    "butt": pyclipper.ET_OPENBUTT,
    "round": pyclipper.ET_OPENROUND,
    "square": pyclipper.ET_OPENSQUARE,
}


def points_to_clipper(points: list[Point]) -> list[tuple[int, int]]:
    return [(int(round(p.x * CLIPPER_SCALE)), int(round(p.y * CLIPPER_SCALE))) for p in points]


def points_from_clipper(points: list[tuple[int, int]]) -> list[Point]:
    return [Point(x / CLIPPER_SCALE, y / CLIPPER_SCALE) for x, y in points]


def offset_polygon(
    points: list[Point], delta: float, *, join: str = "round", miter_limit: float = 4.0, closed: bool = True
) -> list[list[Point]]:
    """Offset a single polygon/polyline outward (positive delta) or inward
    (negative). Returns one or more resulting polygons (offsetting can split
    a shape into multiple pieces, e.g. a concave shape offset inward)."""
    if join not in _JOIN_TYPES:
        raise GeometryError(f"Unknown join type: {join!r}")
    pco = pyclipper.PyclipperOffset(miter_limit)
    end_type = pyclipper.ET_CLOSEDPOLYGON if closed else pyclipper.ET_OPENROUND
    pco.AddPath(points_to_clipper(points), _JOIN_TYPES[join], end_type)
    solution = pco.Execute(delta * CLIPPER_SCALE)
    return [points_from_clipper(ring) for ring in solution]


def offset_path(path: Path, delta: float, *, join: str = "round", miter_limit: float = 4.0, tolerance: float | None = None) -> Path:
    """Offset every subpath of ``path`` by ``delta`` and return a new Path of
    straight-line (flattened) closed subpaths."""
    out = Path(fill_rule="nonzero")
    for sp, ring in zip(path.subpaths, flatten_path_closed_rings(path, tolerance)):
        pts = ring[:-1] if (sp.closed and ring and ring[0].is_close(ring[-1])) else ring
        if len(pts) < 2:
            continue
        for result_ring in offset_polygon(pts, delta, join=join, miter_limit=miter_limit, closed=sp.closed):
            if not result_ring:
                continue
            out.move_to(result_ring[0].x, result_ring[0].y)
            for p in result_ring[1:]:
                out.line_to(p.x, p.y)
            out.close()
    return out


def dash_polyline(points: list[Point], pattern: list[float], offset: float = 0.0, closed: bool = False) -> list[list[Point]]:
    """Split a polyline into its "on" dash segments per an SVG-style dash
    pattern (alternating on/off lengths), honouring ``dash_offset``."""
    if not pattern or len(points) < 2:
        return [points] if points else []
    total = sum(pattern)
    if total <= 0:
        return [points]

    segs: list[tuple[Point, Point, float]] = []
    for i in range(len(points) - 1):
        a, b = points[i], points[i + 1]
        segs.append((a, b, a.distance_to(b)))
    if closed and not points[0].is_close(points[-1]):
        a, b = points[-1], points[0]
        segs.append((a, b, a.distance_to(b)))

    dist_into_pattern = offset % total
    idx, acc = 0, 0.0
    while acc + pattern[idx] <= dist_into_pattern:
        acc += pattern[idx]
        idx = (idx + 1) % len(pattern)
    remaining_in_state = acc + pattern[idx] - dist_into_pattern
    on = idx % 2 == 0

    dashes: list[list[Point]] = []
    current: list[Point] = []
    for a, b, seg_len in segs:
        if seg_len <= 1e-12:
            continue
        seg_pos = 0.0
        while seg_pos < seg_len - 1e-9:
            step = min(remaining_in_state, seg_len - seg_pos)
            t0 = seg_pos / seg_len
            t1 = (seg_pos + step) / seg_len
            p0, p1 = a.lerp(b, t0), a.lerp(b, t1)
            if on:
                if not current:
                    current = [p0]
                current.append(p1)
            seg_pos += step
            remaining_in_state -= step
            if remaining_in_state <= 1e-9:
                if on and len(current) >= 2:
                    dashes.append(current)
                current = []
                idx = (idx + 1) % len(pattern)
                remaining_in_state = pattern[idx]
                on = not on
    if on and len(current) >= 2:
        dashes.append(current)
    return dashes


def stroke_to_fill(
    path: Path,
    width: float,
    *,
    cap: str = "butt",
    join: str = "miter",
    miter_limit: float = 4.0,
    tolerance: float | None = None,
    dash_pattern: list[float] | None = None,
    dash_offset: float = 0.0,
) -> Path:
    """Convert a stroked path into the equivalent filled outline path.

    This is what powers "Convert Stroke to Path" style editing operations and
    lets strokes participate correctly in boolean operations (which only
    operate on fills).
    """
    if width <= 0:
        raise GeometryError("Stroke width must be positive")
    if join not in _JOIN_TYPES:
        raise GeometryError(f"Unknown join type: {join!r}")
    if cap not in _OPEN_END_TYPES:
        raise GeometryError(f"Unknown cap type: {cap!r}")

    out = Path(fill_rule="nonzero")
    for sp, ring in zip(path.subpaths, flatten_path_closed_rings(path, tolerance)):
        pts = ring

        if dash_pattern:
            base_for_dash = pts[:-1] if (sp.closed and pts and pts[0].is_close(pts[-1])) else pts
            segments_to_stroke = [
                (seg, False) for seg in dash_polyline(base_for_dash, dash_pattern, dash_offset, closed=sp.closed)
            ]
        elif sp.closed:
            base = pts[:-1] if pts and pts[0].is_close(pts[-1]) else pts
            segments_to_stroke = [(base, True)]
        else:
            segments_to_stroke = [(pts, False)]

        for seg_pts, seg_closed in segments_to_stroke:
            if len(seg_pts) < 2:
                continue
            pco = pyclipper.PyclipperOffset(miter_limit)
            end_type = pyclipper.ET_CLOSEDLINE if seg_closed else _OPEN_END_TYPES[cap]
            pco.AddPath(points_to_clipper(seg_pts), _JOIN_TYPES[join], end_type)
            solution = pco.Execute(width / 2.0 * CLIPPER_SCALE)
            for result_ring in solution:
                poly = points_from_clipper(result_ring)
                if not poly:
                    continue
                out.move_to(poly[0].x, poly[0].y)
                for p in poly[1:]:
                    out.line_to(p.x, p.y)
                out.close()
    return out
