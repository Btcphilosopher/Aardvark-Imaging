"""Standalone flattening helpers shared by the renderer, exporters and
boolean-operation setup."""

from __future__ import annotations

from aardvark.geometry.point import Point
from aardvark.paths.path import Path


def flatten_path(path: Path, tolerance: float | None = None) -> list[list[Point]]:
    """Flatten every subpath of ``path`` into a polyline (list of vertices)."""
    return path.flatten(tolerance)


def flatten_path_closed_rings(path: Path, tolerance: float | None = None) -> list[list[Point]]:
    """Like :func:`flatten_path`, but every ring representing a *closed*
    subpath is guaranteed to end with a vertex equal to its first (useful for
    fill rasterisation and polygon clipping, which expect explicit closure)."""
    rings: list[list[Point]] = []
    for sp, poly in zip(path.subpaths, path.flatten(tolerance)):
        if sp.closed and (not poly or not poly[0].is_close(poly[-1])):
            poly = poly + [poly[0]]
        rings.append(poly)
    return rings
