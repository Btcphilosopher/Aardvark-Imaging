"""The path engine: Bezier math, the compound-path model, flattening,
simplification and offsetting."""

from aardvark.paths.bezier import CubicBezier, QuadraticBezier
from aardvark.paths.segment import ClosePath, CurveTo, LineTo, MoveTo, QuadTo, Segment
from aardvark.paths.path import NodeType, Path, Subpath
from aardvark.paths.flatten import flatten_path, flatten_path_closed_rings
from aardvark.paths.simplify import simplify_path, simplify_polyline
from aardvark.paths.offset import offset_path, offset_polygon, stroke_to_fill

__all__ = [
    "CubicBezier",
    "QuadraticBezier",
    "MoveTo",
    "LineTo",
    "QuadTo",
    "CurveTo",
    "ClosePath",
    "Segment",
    "Path",
    "Subpath",
    "NodeType",
    "flatten_path",
    "flatten_path_closed_rings",
    "simplify_path",
    "simplify_polyline",
    "offset_path",
    "offset_polygon",
    "stroke_to_fill",
]
