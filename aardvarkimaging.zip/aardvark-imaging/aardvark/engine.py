"""The stable Engine facade (spec section 53): every operation the Kotlin
client (or any other consumer) needs, expressed as plain-dict-in/plain-dict-
out methods. Nothing here exposes Python objects across the boundary —
every return value is JSON-serialisable, and every error is a structured
:class:`~aardvark.errors.AardvarkError` subclass, never a bare exception.
"""

from __future__ import annotations

import base64
import io
import sys
from typing import Any

from aardvark.config import DEFAULT_CONFIG, AntialiasQuality, EngineConfig
from aardvark.document.document import Document
from aardvark.document.scene import GraphicContainer, Group
from aardvark.errors import DocumentError, ValidationError
from aardvark.export.jpeg import export_jpeg
from aardvark.export.pdf import export_pdf
from aardvark.export.png import export_png
from aardvark.export.svg import save_svg
from aardvark.history.command import ChangeFill, ChangeStroke
from aardvark.history.undo import UndoStack
from aardvark.images.image import Image
from aardvark.render.renderer import RenderRequest, Renderer
from aardvark.shapes import Circle, Ellipse, Line, Polygon, Rectangle, Star
from aardvark.spatial.hit_test import build_spatial_index, point_hit
from aardvark.spatial.index import RTree
from aardvark.text.text import Text

_OBJECT_TYPE_CTORS: dict[str, type] = {
    "rectangle": Rectangle,
    "circle": Circle,
    "ellipse": Ellipse,
    "polygon": Polygon,
    "star": Star,
    "line": Line,
    "text": Text,
    "image": Image,
    "group": Group,
}


class Engine:
    """One Engine instance can hold many open documents (keyed by id), each
    with its own undo stack — this is what :mod:`aardvark.api.server` wraps
    to serve the Kotlin client over a Unix socket, and what the CLI wraps
    for one-shot commands."""

    def __init__(self, config: EngineConfig | None = None) -> None:
        self.config = config or DEFAULT_CONFIG
        self._documents: dict[str, Document] = {}
        self._undo_stacks: dict[str, UndoStack] = {}
        self._indexes: dict[str, RTree] = {}
        self._renderer = Renderer()

    # -- health/capabilities (spec section 56) ----------------------------
    def health(self) -> dict[str, Any]:
        return {"status": "ok", "open_documents": len(self._documents)}

    def version(self) -> dict[str, Any]:
        return {"engine": "Aardvark Imaging", "version": self.config.engine_version}

    def capabilities(self) -> dict[str, Any]:
        return {
            "engine": "Aardvark Imaging",
            "version": self.config.engine_version,
            "python": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
            "capabilities": list(self.config.capabilities),
        }

    # -- document lifecycle -----------------------------------------------
    def create_document(self, width: float = 1200.0, height: float = 800.0, title: str = "Untitled") -> dict[str, Any]:
        doc = Document(width=width, height=height, title=title)
        return self._register(doc)

    def open_document(self, path: str) -> dict[str, Any]:
        doc = Document.load(path)
        return self._register(doc)

    def close_document(self, document_id: str) -> dict[str, Any]:
        self._documents.pop(document_id, None)
        self._undo_stacks.pop(document_id, None)
        self._indexes.pop(document_id, None)
        return {"status": "ok", "document_id": document_id}

    def save_document(self, document_id: str, path: str) -> dict[str, Any]:
        doc = self._get(document_id)
        doc.save(path)
        return {"status": "ok", "document_id": document_id, "path": path}

    def _register(self, doc: Document) -> dict[str, Any]:
        self._documents[doc.id] = doc
        self._undo_stacks[doc.id] = UndoStack()
        return {"status": "ok", "document_id": doc.id}

    def _get(self, document_id: str) -> Document:
        doc = self._documents.get(document_id)
        if doc is None:
            raise DocumentError(f"No open document with id {document_id!r}", details={"document_id": document_id})
        return doc

    # -- scene editing ------------------------------------------------
    def add_object(self, document_id: str, object_spec: dict[str, Any], layer_id: str | None = None) -> dict[str, Any]:
        """Create and insert an object from a *partial* spec — only ``type``
        is required; every other field falls back to that shape's own
        default (identity transform, no fill/stroke, etc). This is the
        ergonomic API surface for remote clients; it intentionally does not
        require the full base-field set that the strict document-interchange
        path (``document.serialization.object_from_dict``) does."""
        doc = self._get(document_id)
        spec = dict(object_spec)
        kind = spec.pop("type", None)
        cls = _OBJECT_TYPE_CTORS.get(kind)
        if cls is None:
            raise ValidationError(f"Unknown or missing object type: {kind!r}", details={"supported": sorted(_OBJECT_TYPE_CTORS)})
        obj = cls(**spec)
        layer = self._resolve_layer(doc, layer_id)
        from aardvark.history.command import AddObject

        self._undo_stacks[document_id].do(AddObject(layer, obj))
        self.invalidate_spatial_index(document_id)
        return {"status": "ok", "object_id": obj.id}

    def remove_object(self, document_id: str, object_id: str) -> dict[str, Any]:
        doc = self._get(document_id)
        obj = doc.find(object_id)
        if obj is None or obj.parent is None:
            raise DocumentError(f"No object {object_id!r} to remove", details={"object_id": object_id})
        from aardvark.history.command import DeleteObject

        self._undo_stacks[document_id].do(DeleteObject(obj.parent, obj))
        return {"status": "ok", "object_id": object_id}

    def move_object(self, document_id: str, object_id: str, dx: float, dy: float) -> dict[str, Any]:
        doc = self._get(document_id)
        obj = self._find_or_raise(doc, object_id)
        from aardvark.history.command import MoveObject

        self._undo_stacks[document_id].do(MoveObject(obj, dx, dy))
        return {"status": "ok", "object_id": object_id}

    def transform_object(self, document_id: str, object_id: str, matrix: list[float]) -> dict[str, Any]:
        doc = self._get(document_id)
        obj = self._find_or_raise(doc, object_id)
        from aardvark.geometry.matrix import Matrix
        from aardvark.history.command import SetTransform

        self._undo_stacks[document_id].do(SetTransform(obj, Matrix(*matrix)))
        return {"status": "ok", "object_id": object_id}

    def set_style(
        self, document_id: str, object_id: str, *, fill: dict[str, Any] | None = None, stroke: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        doc = self._get(document_id)
        obj = self._find_or_raise(doc, object_id)
        from aardvark.document.serialization import paint_from_dict
        from aardvark.style import Fill, LineCap, LineJoin, Stroke

        commands = []
        if fill is not None:
            commands.append(ChangeFill(obj, Fill(paint_from_dict(fill.get("paint")), fill.get("opacity", 1.0), fill.get("rule", "nonzero"))))
        if stroke is not None:
            commands.append(
                ChangeStroke(
                    obj,
                    Stroke(
                        paint_from_dict(stroke.get("paint")), stroke.get("width", 1.0), stroke.get("opacity", 1.0),
                        LineCap(stroke.get("cap", "butt")), LineJoin(stroke.get("join", "miter")), stroke.get("miter_limit", 4.0),
                        stroke.get("dash_pattern", []), stroke.get("dash_offset", 0.0),
                    ),
                )
            )
        if commands:
            self._undo_stacks[document_id].do_many(commands, "Change style")
        return {"status": "ok", "object_id": object_id}

    def get_bounds(self, document_id: str, object_id: str) -> dict[str, Any]:
        doc = self._get(document_id)
        obj = self._find_or_raise(doc, object_id)
        bset = obj.world_bounds()
        return {b: getattr(bset, b).as_xywh() for b in ("geometry", "stroke", "visual")}

    def hit_test(self, document_id: str, x: float, y: float, page_index: int = 0) -> dict[str, Any]:
        doc = self._get(document_id)
        page = doc.pages[page_index]
        idx = self._indexes.setdefault(document_id, build_spatial_index(page))
        obj = point_hit(page, x, y, index=idx)
        return {"object_id": obj.id if obj else None}

    def invalidate_spatial_index(self, document_id: str) -> None:
        self._indexes.pop(document_id, None)

    # -- rendering/export ------------------------------------------------
    def render(self, document_id: str, page_index: int = 0, scale: float = 1.0, antialias: str | None = None) -> dict[str, Any]:
        doc = self._get(document_id)
        req = RenderRequest(page_index=page_index, scale=scale, antialias=AntialiasQuality(antialias) if antialias else self.config.default_antialias)
        img = self._renderer.render_document(doc, req)
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return {"status": "ok", "width": img.width, "height": img.height, "png_base64": base64.b64encode(buf.getvalue()).decode("ascii")}

    def export(self, document_id: str, fmt: str, path: str, page_index: int = 0, **kwargs: Any) -> dict[str, Any]:
        doc = self._get(document_id)
        fmt = fmt.lower()
        if fmt == "svg":
            save_svg(doc, path, page_index, **kwargs)
        elif fmt == "pdf":
            export_pdf(doc, path, **kwargs)
        elif fmt == "png":
            export_png(doc, path, page_index, **kwargs)
        elif fmt in ("jpeg", "jpg"):
            export_jpeg(doc, path, page_index, **kwargs)
        else:
            raise ValidationError(f"Unsupported export format: {fmt!r}", details={"supported": ["svg", "pdf", "png", "jpeg"]})
        return {"status": "ok", "format": fmt, "path": path}

    # -- undo/redo ------------------------------------------------------
    def undo(self, document_id: str) -> dict[str, Any]:
        cmd = self._undo_stacks[document_id].undo()
        self.invalidate_spatial_index(document_id)
        return {"status": "ok", "undone": cmd.description}

    def redo(self, document_id: str) -> dict[str, Any]:
        cmd = self._undo_stacks[document_id].redo()
        self.invalidate_spatial_index(document_id)
        return {"status": "ok", "redone": cmd.description}

    # -- diagnostics ------------------------------------------------------
    def validate(self, document_id: str) -> dict[str, Any]:
        doc = self._get(document_id)
        return {"issues": doc.validate()}

    # -- helpers ----------------------------------------------------------
    def _resolve_layer(self, doc: Document, layer_id: str | None):
        if layer_id is None:
            return doc.active_layer
        layer = doc.find(layer_id)
        if layer is None or not isinstance(layer, GraphicContainer):
            raise DocumentError(f"No layer/group {layer_id!r}", details={"layer_id": layer_id})
        return layer

    def _find_or_raise(self, doc: Document, object_id: str):
        obj = doc.find(object_id)
        if obj is None:
            raise DocumentError(f"No object with id {object_id!r}", details={"object_id": object_id})
        return obj
