"""The scene graph: the common :class:`GraphicObject` base every drawable
inherits from, plus the container types (:class:`Group`, :class:`Layer`) and
the reusable-content types (:class:`SymbolDefinition`, :class:`SymbolInstance`,
:class:`Mask`) built on top of it (spec sections 6, 24-27).
"""

from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Iterator

from aardvark.errors import DocumentError
from aardvark.geometry.bounds import Bounds, BoundsSet
from aardvark.geometry.matrix import Matrix
from aardvark.geometry.rect import Rect
from aardvark.geometry.transform import Transform, compose_chain
from aardvark.paths.path import Path
from aardvark.style import Style


def new_id() -> str:
    return uuid.uuid4().hex


@dataclass
class GraphicObject(ABC):
    """Base class for every object that can live in the scene graph.

    Subclasses must implement :meth:`local_bounds` and :meth:`to_path`.
    ``transform`` is always relative to the object's *parent* container
    (spec section 7/8) — call :meth:`world_matrix` to get the fully composed
    document-space matrix.
    """

    id: str = field(default_factory=new_id)
    name: str | None = None
    transform: Transform = field(default_factory=Transform.identity)
    style: Style = field(default_factory=Style)
    visible: bool = True
    locked: bool = False
    clip_path: Path | None = None
    mask: "Mask | None" = None
    metadata: dict[str, Any] = field(default_factory=dict)
    parent: "GraphicContainer | None" = field(default=None, repr=False, compare=False)

    kind: str = field(default="object", init=False, repr=False)

    # -- required per-shape implementation ------------------------------
    @abstractmethod
    def local_bounds(self) -> Bounds:
        """Geometry-only bounds in this object's own local coordinate space."""

    @abstractmethod
    def to_path(self) -> Path:
        """This object's geometry as a :class:`Path`, in local space."""

    # -- coordinate spaces (spec section 7) ------------------------------
    def ancestor_chain(self) -> list["GraphicObject"]:
        chain: list[GraphicObject] = []
        node: GraphicObject | None = self
        while node is not None:
            chain.append(node)
            node = node.parent
        chain.reverse()
        return chain

    def world_matrix(self) -> Matrix:
        return compose_chain([n.transform.matrix for n in self.ancestor_chain()])

    def is_effectively_visible(self) -> bool:
        return all(n.visible for n in self.ancestor_chain())

    # -- bounds (spec section 9) -----------------------------------------
    def world_bounds(self) -> BoundsSet:
        geometry_rect_bounds = self.local_bounds()
        world = self.world_matrix()
        geometry = Rect.from_bounds(geometry_rect_bounds).transformed_bounds(world) if not geometry_rect_bounds.is_empty else Bounds.empty()

        stroke_pad = 0.0
        if self.style.stroke is not None and self.style.stroke.paint is not None:
            half = self.style.stroke.width / 2.0
            # Miter joins can extend further than half-width at sharp
            # corners; approximate with the miter limit as a multiplier.
            # Documented approximation — exact miter extent needs per-corner
            # angle analysis, done precisely by the offset/stroke_to_fill path.
            miter_factor = self.style.stroke.miter_limit if self.style.stroke.join.value == "miter" else 1.0
            stroke_pad = half * max(1.0, min(miter_factor, 4.0))
        stroke = geometry.expanded(stroke_pad) if stroke_pad else geometry

        effect_pad = 0.0
        for shadow in self.style.shadows:
            reach = shadow.blur_radius + shadow.spread + max(abs(shadow.offset_x), abs(shadow.offset_y))
            effect_pad = max(effect_pad, reach)
        visual = stroke.expanded(effect_pad) if effect_pad else stroke

        return BoundsSet(geometry=geometry, stroke=stroke, visual=visual)

    def contains_point_local(self, x: float, y: float) -> bool:
        from aardvark.geometry.point import Point

        return self.to_path().contains_point(Point(x, y))

    def copy_style(self) -> Style:
        return self.style.copy()

    # -- fluent designer API (spec section 70) ---------------------------
    def fill(self, paint, *, opacity: float = 1.0, rule: str = "nonzero") -> "GraphicObject":
        from aardvark.style.color import Color
        from aardvark.style.fill import Fill

        color = Color.from_hex(paint) if isinstance(paint, str) else paint
        self.style.fill = Fill(color, opacity, rule)
        return self

    def stroke(self, paint, width: float = 1.0, *, opacity: float = 1.0, **kwargs) -> "GraphicObject":
        from aardvark.style.color import Color
        from aardvark.style.stroke import Stroke

        color = Color.from_hex(paint) if isinstance(paint, str) else paint
        self.style.stroke = Stroke(color, width, opacity, **kwargs)
        return self

    def set_opacity(self, opacity: float) -> "GraphicObject":
        self.style.opacity = max(0.0, min(1.0, opacity))
        return self

    def move_to(self, x: float, y: float) -> "GraphicObject":
        tx, ty = self.transform.matrix.e, self.transform.matrix.f
        self.transform.translate(x - tx, y - ty)
        return self

    def translate(self, dx: float, dy: float) -> "GraphicObject":
        self.transform.translate(dx, dy)
        return self


class MaskMode(str, Enum):
    ALPHA = "alpha"
    LUMINANCE = "luminance"


@dataclass
class Mask:
    """A vector mask attached to a :class:`GraphicObject`. Left as vector
    content (spec section 24: "do not flatten masks prematurely") — it is
    only rasterised on demand by the renderer/compositor."""

    content: list[GraphicObject] = field(default_factory=list)
    mode: MaskMode = MaskMode.ALPHA


class GraphicContainer:
    """Mixin providing child-management for anything holding a list of
    :class:`GraphicObject` (Group, Layer, SymbolDefinition)."""

    children: list[GraphicObject]

    def add(self, obj: GraphicObject, index: int | None = None) -> GraphicObject:
        obj.parent = self  # type: ignore[assignment]
        if index is None:
            self.children.append(obj)
        else:
            self.children.insert(index, obj)
        return obj

    def remove(self, obj: GraphicObject) -> None:
        self.children.remove(obj)
        obj.parent = None

    def index_of(self, obj: GraphicObject) -> int:
        return self.children.index(obj)

    def reorder(self, obj: GraphicObject, new_index: int) -> None:
        self.children.remove(obj)
        self.children.insert(new_index, obj)

    def find(self, object_id: str) -> GraphicObject | None:
        for child in self.children:
            if child.id == object_id:
                return child
            if isinstance(child, GraphicContainer):
                found = child.find(object_id)
                if found is not None:
                    return found
        return None

    def walk(self) -> Iterator[GraphicObject]:
        for child in self.children:
            yield child
            if isinstance(child, GraphicContainer):
                yield from child.walk()


@dataclass
class Group(GraphicObject, GraphicContainer):
    """A grouped set of children, transformed together (spec section 26)."""

    children: list[GraphicObject] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.kind = "group"
        for child in self.children:
            child.parent = self

    def local_bounds(self) -> Bounds:
        b = Bounds.empty()
        for child in self.children:
            if not child.visible:
                continue
            child_bounds = child.local_bounds()
            if child_bounds.is_empty:
                continue
            b = b.union(Rect.from_bounds(child_bounds).transformed_bounds(child.transform.matrix))
        return b

    def to_path(self) -> Path:
        combined = Path()
        for child in self.children:
            if not child.visible:
                continue
            combined.extend(child.to_path().transformed(child.transform.matrix))
        return combined


@dataclass
class SymbolDefinition(GraphicContainer):
    """A reusable piece of content. Not itself placed in the scene — lives in
    ``Document.symbols`` and is referenced by id from one or more
    :class:`SymbolInstance` placements (spec section 27)."""

    id: str = field(default_factory=new_id)
    name: str = "Symbol"
    children: list[GraphicObject] = field(default_factory=list)

    def __post_init__(self) -> None:
        for child in self.children:
            child.parent = self

    def local_bounds(self) -> Bounds:
        b = Bounds.empty()
        for child in self.children:
            child_bounds = child.local_bounds()
            if child_bounds.is_empty:
                continue
            b = b.union(Rect.from_bounds(child_bounds).transformed_bounds(child.transform.matrix))
        return b

    def to_path(self) -> Path:
        combined = Path()
        for child in self.children:
            combined.extend(child.to_path().transformed(child.transform.matrix))
        return combined


@dataclass
class SymbolInstance(GraphicObject):
    """A placement of a :class:`SymbolDefinition`. Editing the definition
    updates every instance because instances never copy its geometry — they
    resolve ``definition`` (a live reference, wired up by
    ``Document.resolve_symbols()`` after load) at bounds/path/render time."""

    definition_id: str = ""
    definition: SymbolDefinition | None = field(default=None, repr=False, compare=False)

    def __post_init__(self) -> None:
        self.kind = "symbol-instance"

    def _require_definition(self) -> SymbolDefinition:
        if self.definition is None:
            raise DocumentError(
                f"SymbolInstance {self.id} references unresolved symbol {self.definition_id!r}; "
                "call Document.resolve_symbols() after loading",
                details={"instance_id": self.id, "definition_id": self.definition_id},
            )
        return self.definition

    def local_bounds(self) -> Bounds:
        return self._require_definition().local_bounds()

    def to_path(self) -> Path:
        return self._require_definition().to_path()


@dataclass
class GenericPathObject(GraphicObject):
    """A shape whose geometry is an explicit, directly-stored :class:`Path`.

    Used by the SVG importer for elements with no dedicated parametric
    representation in ``aardvark.shapes`` (e.g. an arbitrary ``<path>``), and
    generally available as an escape hatch for custom vector geometry that
    doesn't need a named shape type of its own.
    """

    path_data: Path = field(default_factory=Path)

    def __post_init__(self) -> None:
        self.kind = "generic-path"

    def local_bounds(self) -> Bounds:
        return self.path_data.bounds()

    def to_path(self) -> Path:
        return self.path_data
