"""Document layers (spec section 25).

A :class:`Layer` is a :class:`~aardvark.document.scene.Group` with the
editorial metadata a real vector tool attaches to layers. Opacity and blend
mode live on the inherited ``style`` so there is exactly one place that
governs how an object composites, whether it is a Layer or an ordinary Group.
"""

from __future__ import annotations

from dataclasses import dataclass

from aardvark.document.scene import GraphicObject, Group


@dataclass
class Layer(Group):
    def __post_init__(self) -> None:
        super().__post_init__()
        self.kind = "layer"
        if self.name is None:
            self.name = "Layer"

    @property
    def objects(self) -> list[GraphicObject]:
        return self.children

    def duplicate(self) -> "Layer":
        """A shallow structural copy: same object graph shape, new ids are
        assigned by whoever inserts the copy (kept here as a hook so callers
        driving the document/undo layer control id generation centrally)."""
        import copy as _copy

        return _copy.deepcopy(self)
