"""Pages/artboards (spec section 4), plus their editor aids: guides (section
32) and grid (section 33). Guides and the grid are document-level aids that
never export into the final artwork (the exporters simply never look at
``Page.guides`` / ``Page.grid``)."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from aardvark.document.layer import Layer
from aardvark.document.scene import new_id
from aardvark.style.color import Color


class GuideOrientation(str, Enum):
    HORIZONTAL = "horizontal"
    VERTICAL = "vertical"
    ANGLED = "angled"


@dataclass(slots=True)
class Guide:
    orientation: GuideOrientation
    position: float  # x for vertical, y for horizontal, distance-from-origin for angled
    angle: float = 0.0  # radians, only meaningful when orientation is ANGLED
    locked: bool = False
    id: str = field(default_factory=new_id)


class GridKind(str, Enum):
    SQUARE = "square"
    ISOMETRIC = "isometric"


@dataclass(slots=True)
class Grid:
    kind: GridKind = GridKind.SQUARE
    spacing: float = 10.0
    subdivisions: int = 1
    visible: bool = False
    color: Color = field(default_factory=lambda: Color(0.5, 0.5, 0.5, 0.3))


@dataclass(slots=True)
class Page:
    name: str = "Page 1"
    width: float = 1200.0
    height: float = 800.0
    background: Color | None = field(default_factory=Color.white)
    layers: list[Layer] = field(default_factory=list)
    guides: list[Guide] = field(default_factory=list)
    grid: Grid = field(default_factory=Grid)
    id: str = field(default_factory=new_id)

    def add_layer(self, layer: Layer | None = None, *, index: int | None = None) -> Layer:
        if layer is None:
            layer = Layer(name=f"Layer {len(self.layers) + 1}")
        if index is None:
            self.layers.append(layer)
        else:
            self.layers.insert(index, layer)
        return layer

    def remove_layer(self, layer: Layer) -> None:
        self.layers.remove(layer)

    def merge_layers(self, top: Layer, bottom: Layer) -> Layer:
        """Merge ``top`` into ``bottom``: bottom keeps its identity, top's
        children are appended (preserving relative order/z-index) and top is removed."""
        bottom.children.extend(top.children)
        for child in top.children:
            child.parent = bottom
        self.remove_layer(top)
        return bottom

    def all_objects(self):
        for layer in self.layers:
            yield from layer.walk()
