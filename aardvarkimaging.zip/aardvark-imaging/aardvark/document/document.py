"""The central :class:`Document` object (spec sections 4-5, 69-70, 75)."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from aardvark.assets.manager import AssetManager
from aardvark.config import DEFAULT_CONFIG
from aardvark.document.layer import Layer
from aardvark.document.page import Page
from aardvark.document.scene import GraphicContainer, GraphicObject, SymbolDefinition, SymbolInstance, new_id
from aardvark.errors import GeometryError, ValidationError
from aardvark.style import Style


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass(slots=True)
class DocumentMetadata:
    title: str = "Untitled"
    author: str = ""
    description: str = ""
    created_at: str = field(default_factory=_now_iso)
    modified_at: str = field(default_factory=_now_iso)


@dataclass(slots=True)
class DocumentSettings:
    units: str = "px"
    dpi: float = 96.0
    color_mode: str = "rgb"  # architecture hook for future cmyk/lab pipelines


class Document:
    """The document graph: pages -> layers -> objects, plus the document-wide
    asset registry, symbol library, and named/shared style library."""

    def __init__(self, width: float = 1200.0, height: float = 800.0, *, title: str = "Untitled") -> None:
        self.id: str = new_id()
        self.metadata = DocumentMetadata(title=title)
        self.settings = DocumentSettings()
        self.pages: list[Page] = [Page(name="Page 1", width=width, height=height)]
        self.symbols: dict[str, SymbolDefinition] = {}
        self.styles: dict[str, Style] = {}
        self.assets = AssetManager()
        self.format_version: int = DEFAULT_CONFIG.format_version
        self.engine_version: str = DEFAULT_CONFIG.engine_version
        self._active_page_index = 0
        self.pages[0].add_layer(Layer(name="Layer 1"))

    # -- page/layer navigation -------------------------------------------
    @property
    def active_page(self) -> Page:
        return self.pages[self._active_page_index]

    def set_active_page(self, index: int) -> None:
        if not (0 <= index < len(self.pages)):
            raise ValidationError(f"Page index out of range: {index}")
        self._active_page_index = index

    @property
    def active_layer(self) -> Layer:
        page = self.active_page
        if not page.layers:
            page.add_layer(Layer(name="Layer 1"))
        return page.layers[-1]

    def add_page(self, page: Page | None = None, *, width: float | None = None, height: float | None = None) -> Page:
        if page is None:
            page = Page(name=f"Page {len(self.pages) + 1}", width=width or 1200.0, height=height or 800.0)
            page.add_layer(Layer(name="Layer 1"))
        self.pages.append(page)
        return page

    def remove_page(self, page: Page) -> None:
        if len(self.pages) <= 1:
            raise ValidationError("A document must have at least one page")
        self.pages.remove(page)
        self._active_page_index = min(self._active_page_index, len(self.pages) - 1)

    # -- object convenience API (spec sections 69-70) ---------------------
    def add(self, obj: GraphicObject, *, layer: Layer | None = None) -> GraphicObject:
        (layer or self.active_layer).add(obj)
        return obj

    def remove(self, obj: GraphicObject) -> None:
        if obj.parent is not None and isinstance(obj.parent, GraphicContainer):
            obj.parent.remove(obj)

    def rectangle(self, x: float, y: float, width: float, height: float, **kwargs: Any) -> GraphicObject:
        from aardvark.shapes.rectangle import Rectangle

        return self.add(Rectangle(x=x, y=y, width=width, height=height, **kwargs))

    def circle(self, cx: float, cy: float, radius: float, **kwargs: Any) -> GraphicObject:
        from aardvark.shapes.ellipse import Circle

        return self.add(Circle(cx=cx, cy=cy, radius=radius, **kwargs))

    def ellipse(self, cx: float, cy: float, rx: float, ry: float, **kwargs: Any) -> GraphicObject:
        from aardvark.shapes.ellipse import Ellipse

        return self.add(Ellipse(cx=cx, cy=cy, rx=rx, ry=ry, **kwargs))

    def polygon(self, cx: float, cy: float, radius: float, sides: int = 5, **kwargs: Any) -> GraphicObject:
        from aardvark.shapes.polygon import Polygon

        return self.add(Polygon(cx=cx, cy=cy, radius=radius, sides=sides, **kwargs))

    def star(self, cx: float, cy: float, outer_radius: float, inner_radius: float, points: int = 5, **kwargs: Any) -> GraphicObject:
        from aardvark.shapes.star import Star

        return self.add(Star(cx=cx, cy=cy, outer_radius=outer_radius, inner_radius=inner_radius, points=points, **kwargs))

    def line(self, x1: float, y1: float, x2: float, y2: float, **kwargs: Any) -> GraphicObject:
        from aardvark.shapes.line import Line

        return self.add(Line(x1=x1, y1=y1, x2=x2, y2=y2, **kwargs))

    def text(self, content: str, x: float = 0.0, y: float = 0.0, size: float = 16.0, **kwargs: Any) -> GraphicObject:
        from aardvark.text.text import Text

        return self.add(Text(content=content, x=x, y=y, size=size, **kwargs))

    def group(self, objects: list[GraphicObject] | None = None, **kwargs: Any) -> GraphicObject:
        from aardvark.document.scene import Group

        g = Group(**kwargs)
        self.add(g)
        for obj in objects or []:
            self.remove(obj)
            g.add(obj)
        return g

    # -- symbols ------------------------------------------------------
    def define_symbol(self, name: str, children: list[GraphicObject]) -> SymbolDefinition:
        sym = SymbolDefinition(name=name, children=children)
        self.symbols[sym.id] = sym
        return sym

    def instantiate_symbol(self, definition: SymbolDefinition, *, x: float = 0.0, y: float = 0.0) -> SymbolInstance:
        inst = SymbolInstance(definition_id=definition.id, definition=definition)
        inst.transform.translate(x, y)
        return self.add(inst)

    def resolve_symbols(self) -> None:
        """Re-wire every :class:`SymbolInstance` to its live definition object
        by id — required after ``from_dict``/``load`` since serialized
        instances only carry ``definition_id``."""
        for obj in self.all_objects():
            if isinstance(obj, SymbolInstance):
                obj.definition = self.symbols.get(obj.definition_id)

    # -- traversal ------------------------------------------------------
    def all_objects(self):
        for page in self.pages:
            for layer in page.layers:
                yield layer
                yield from layer.walk()

    def find(self, object_id: str) -> GraphicObject | None:
        for obj in self.all_objects():
            if obj.id == object_id:
                return obj
        return None

    # -- validation (spec section 75) ------------------------------------
    def validate(self) -> list[dict[str, Any]]:
        issues: list[dict[str, Any]] = []
        seen_ids: dict[str, int] = {}

        def note(severity: str, code: str, message: str, object_id: str | None = None) -> None:
            issues.append({"severity": severity, "code": code, "message": message, "object_id": object_id})

        for page in self.pages:
            seen_ids[page.id] = seen_ids.get(page.id, 0) + 1

        for obj in self.all_objects():
            seen_ids[obj.id] = seen_ids.get(obj.id, 0) + 1

            try:
                obj.transform.matrix.inverse()
            except GeometryError:
                note("error", "invalid_transform", f"Object {obj.id} has a non-invertible (singular) transform", obj.id)

            if isinstance(obj, SymbolInstance) and obj.definition_id not in self.symbols:
                note("error", "broken_reference", f"SymbolInstance {obj.id} references unknown symbol {obj.definition_id!r}", obj.id)

            from aardvark.images.image import Image

            if isinstance(obj, Image) and obj.asset_id and obj.asset_id not in self.assets.all_ids():
                note("error", "missing_asset", f"Image {obj.id} references missing asset {obj.asset_id!r}", obj.id)

            from aardvark.text.text import Text as _Text

            if isinstance(obj, _Text) and obj.font_asset_id and obj.font_asset_id not in self.assets.all_ids():
                note("error", "missing_asset", f"Text {obj.id} references missing font asset {obj.font_asset_id!r}", obj.id)

            if not isinstance(obj, (type(None),)):
                try:
                    path = obj.to_path()
                except Exception:
                    path = None
                if path is not None:
                    for sp in path.subpaths:
                        for pt in [sp.start] + [s.point for s in sp.segments]:
                            if not (math.isfinite(pt.x) and math.isfinite(pt.y)):
                                note("error", "invalid_path", f"Object {obj.id} has non-finite path coordinates", obj.id)
                                break

        for object_id, count in seen_ids.items():
            if count > 1:
                note("error", "duplicate_id", f"Id {object_id!r} is used {count} times", object_id)

        return issues

    def is_valid(self) -> bool:
        return not any(i["severity"] == "error" for i in self.validate())

    # -- serialization convenience (spec section 51) ----------------------
    def to_dict(self, *, embed_assets: bool = True) -> dict[str, Any]:
        from aardvark.document.serialization import document_to_dict

        return document_to_dict(self, embed_assets=embed_assets)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Document":
        from aardvark.document.serialization import document_from_dict

        return document_from_dict(data)

    def save(self, path: str, *, embed_assets: bool = True) -> None:
        from aardvark.serialization.format import save_document

        save_document(self, path, embed_assets=embed_assets)

    @classmethod
    def load(cls, path: str) -> "Document":
        from aardvark.serialization.format import load_document

        return load_document(path)
