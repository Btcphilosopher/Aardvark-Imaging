"""Document <-> plain-dict conversion (spec section 51).

This is the layer the native ``.aardvark`` format (see
``aardvark.serialization.format``), the JSON API, and the undo/redo system's
snapshotting all sit on top of. Every id here is stable: re-serializing an
unmodified document round-trips to byte-identical structure (module ordering
of dict keys aside).
"""

from __future__ import annotations

from typing import Any

from aardvark.assets.manager import AssetManager
from aardvark.document.document import Document, DocumentMetadata, DocumentSettings
from aardvark.document.layer import Layer
from aardvark.document.page import Grid, GridKind, Guide, GuideOrientation, Page
from aardvark.document.scene import GenericPathObject, Group, Mask, MaskMode, SymbolDefinition, SymbolInstance
from aardvark.errors import SerializationError
from aardvark.geometry.matrix import Matrix
from aardvark.geometry.rect import Rect
from aardvark.geometry.transform import Transform
from aardvark.images.image import Image
from aardvark.images.placement import FitMode
from aardvark.paths.path import NodeType, Path
from aardvark.paths.segment import CurveTo, LineTo, QuadTo
from aardvark.shapes.ellipse import Circle, Ellipse
from aardvark.shapes.line import Line
from aardvark.shapes.polygon import Polygon
from aardvark.shapes.rectangle import Rectangle
from aardvark.shapes.star import Star
from aardvark.style import (
    BlendMode,
    Color,
    Fill,
    GradientStop,
    LinearGradient,
    Pattern,
    PatternExtend,
    RadialGradient,
    Shadow,
    SpreadMode,
    Stroke,
    Style,
)
from aardvark.style.stroke import LineCap, LineJoin
from aardvark.text.text import Text


# ---------------------------------------------------------------- geometry
def matrix_to_dict(m: Matrix) -> list[float]:
    return list(m.as_tuple())


def matrix_from_dict(d: list[float]) -> Matrix:
    return Matrix(*d)


def path_to_dict(path: Path) -> dict[str, Any]:
    subpaths = []
    for sp in path.subpaths:
        segs = []
        for seg, ntype in zip(sp.segments, sp.node_types[1:]):
            if isinstance(seg, LineTo):
                segs.append({"c": "L", "p": [seg.point.x, seg.point.y], "n": ntype.value})
            elif isinstance(seg, QuadTo):
                segs.append({"c": "Q", "ctrl": [seg.control.x, seg.control.y], "p": [seg.point.x, seg.point.y], "n": ntype.value})
            elif isinstance(seg, CurveTo):
                segs.append(
                    {
                        "c": "C",
                        "c1": [seg.control1.x, seg.control1.y],
                        "c2": [seg.control2.x, seg.control2.y],
                        "p": [seg.point.x, seg.point.y],
                        "n": ntype.value,
                    }
                )
        subpaths.append(
            {"start": [sp.start.x, sp.start.y], "closed": sp.closed, "segments": segs, "start_node": sp.node_types[0].value}
        )
    return {"fill_rule": path.fill_rule, "subpaths": subpaths}


def path_from_dict(d: dict[str, Any]) -> Path:
    path = Path(fill_rule=d.get("fill_rule", "nonzero"))
    for sp_d in d["subpaths"]:
        sx, sy = sp_d["start"]
        path.move_to(sx, sy)
        for seg_d in sp_d["segments"]:
            if seg_d["c"] == "L":
                path.line_to(*seg_d["p"])
            elif seg_d["c"] == "Q":
                path.quad_to(*seg_d["ctrl"], *seg_d["p"])
            elif seg_d["c"] == "C":
                path.curve_to(*seg_d["c1"], *seg_d["c2"], *seg_d["p"])
        if sp_d.get("closed"):
            path.close()
        sp = path.subpaths[-1]
        sp.node_types[0] = NodeType(sp_d.get("start_node", "corner"))
        for i, seg_d in enumerate(sp_d["segments"], start=1):
            sp.node_types[i] = NodeType(seg_d.get("n", "corner"))
    return path


# ------------------------------------------------------------------ style
def color_to_dict(c: Color) -> list[float]:
    return [c.r, c.g, c.b, c.a]


def color_from_dict(d: list[float]) -> Color:
    return Color(*d)


def paint_to_dict(paint: Any) -> dict[str, Any] | None:
    if paint is None:
        return None
    if isinstance(paint, Color):
        return {"type": "solid", "color": color_to_dict(paint)}
    if isinstance(paint, LinearGradient):
        return {
            "type": "linear-gradient",
            "start": [paint.start.x, paint.start.y],
            "end": [paint.end.x, paint.end.y],
            "stops": [_stop_to_dict(s) for s in paint.stops],
            "spread": paint.spread.value,
            "transform": matrix_to_dict(paint.transform),
            "opacity": paint.opacity,
        }
    if isinstance(paint, RadialGradient):
        return {
            "type": "radial-gradient",
            "center": [paint.center.x, paint.center.y],
            "radius": paint.radius,
            "focal": [paint.focal.x, paint.focal.y] if paint.focal else None,
            "stops": [_stop_to_dict(s) for s in paint.stops],
            "spread": paint.spread.value,
            "transform": matrix_to_dict(paint.transform),
            "opacity": paint.opacity,
        }
    if isinstance(paint, Pattern):
        return {
            "type": "pattern",
            "tile_bounds": [paint.tile_bounds.x, paint.tile_bounds.y, paint.tile_bounds.width, paint.tile_bounds.height],
            "content": [object_to_dict(o) for o in paint.content],
            "transform": matrix_to_dict(paint.transform),
            "extend": paint.extend.value,
            "opacity": paint.opacity,
            "id": paint.id,
        }
    raise SerializationError(f"Unsupported paint type: {type(paint)!r}")


def _stop_to_dict(s: GradientStop) -> dict[str, Any]:
    return {"offset": s.offset, "color": color_to_dict(s.color), "opacity": s.opacity}


def _stop_from_dict(d: dict[str, Any]) -> GradientStop:
    return GradientStop(d["offset"], color_from_dict(d["color"]), d.get("opacity", 1.0))


def paint_from_dict(d: dict[str, Any] | None) -> Any:
    from aardvark.geometry.point import Point

    if d is None:
        return None
    t = d["type"]
    if t == "solid":
        return color_from_dict(d["color"])
    if t == "linear-gradient":
        return LinearGradient(
            Point(*d["start"]),
            Point(*d["end"]),
            tuple(_stop_from_dict(s) for s in d["stops"]),
            SpreadMode(d.get("spread", "pad")),
            matrix_from_dict(d["transform"]),
            d.get("opacity", 1.0),
        )
    if t == "radial-gradient":
        return RadialGradient(
            Point(*d["center"]),
            d["radius"],
            Point(*d["focal"]) if d.get("focal") else None,
            tuple(_stop_from_dict(s) for s in d["stops"]),
            SpreadMode(d.get("spread", "pad")),
            matrix_from_dict(d["transform"]),
            d.get("opacity", 1.0),
        )
    if t == "pattern":
        x, y, w, h = d["tile_bounds"]
        return Pattern(
            Rect(x, y, w, h),
            [object_from_dict(o) for o in d["content"]],
            matrix_from_dict(d["transform"]),
            PatternExtend(d.get("extend", "repeat")),
            d.get("opacity", 1.0),
            d.get("id"),
        )
    raise SerializationError(f"Unknown paint type: {t!r}")


def style_to_dict(style: Style) -> dict[str, Any]:
    return {
        "fill": {"paint": paint_to_dict(style.fill.paint), "opacity": style.fill.opacity, "rule": style.fill.rule},
        "stroke": (
            {
                "paint": paint_to_dict(style.stroke.paint),
                "width": style.stroke.width,
                "opacity": style.stroke.opacity,
                "cap": style.stroke.cap.value,
                "join": style.stroke.join.value,
                "miter_limit": style.stroke.miter_limit,
                "dash_pattern": list(style.stroke.dash_pattern),
                "dash_offset": style.stroke.dash_offset,
            }
            if style.stroke
            else None
        ),
        "shadows": [
            {
                "offset_x": s.offset_x,
                "offset_y": s.offset_y,
                "blur_radius": s.blur_radius,
                "spread": s.spread,
                "color": color_to_dict(s.color),
                "inner": s.inner,
            }
            for s in style.shadows
        ],
        "opacity": style.opacity,
        "blend_mode": style.blend_mode.value,
    }


def style_from_dict(d: dict[str, Any]) -> Style:
    fill = Fill(paint_from_dict(d["fill"]["paint"]), d["fill"].get("opacity", 1.0), d["fill"].get("rule", "nonzero"))
    stroke = None
    if d.get("stroke"):
        sd = d["stroke"]
        stroke = Stroke(
            paint_from_dict(sd["paint"]),
            sd.get("width", 1.0),
            sd.get("opacity", 1.0),
            LineCap(sd.get("cap", "butt")),
            LineJoin(sd.get("join", "miter")),
            sd.get("miter_limit", 4.0),
            list(sd.get("dash_pattern", [])),
            sd.get("dash_offset", 0.0),
        )
    shadows = [
        Shadow(s["offset_x"], s["offset_y"], s["blur_radius"], s.get("spread", 0.0), color_from_dict(s["color"]), s.get("inner", False))
        for s in d.get("shadows", [])
    ]
    return Style(fill, stroke, shadows, d.get("opacity", 1.0), BlendMode(d.get("blend_mode", "normal")))


# ------------------------------------------------------------- base fields
def _base_fields_to_dict(obj: Any) -> dict[str, Any]:
    return {
        "id": obj.id,
        "type": obj.kind,
        "name": obj.name,
        "transform": matrix_to_dict(obj.transform.matrix),
        "style": style_to_dict(obj.style),
        "visible": obj.visible,
        "locked": obj.locked,
        "clip_path": path_to_dict(obj.clip_path) if obj.clip_path is not None else None,
        "mask": _mask_to_dict(obj.mask) if obj.mask is not None else None,
        "metadata": obj.metadata,
    }


def _mask_to_dict(mask: Mask) -> dict[str, Any]:
    return {"mode": mask.mode.value, "content": [object_to_dict(o) for o in mask.content]}


def _mask_from_dict(d: dict[str, Any] | None) -> Mask | None:
    if d is None:
        return None
    return Mask([object_from_dict(o) for o in d["content"]], MaskMode(d["mode"]))


def _apply_base_fields(obj: Any, d: dict[str, Any]) -> None:
    obj.id = d["id"]
    obj.name = d.get("name")
    obj.transform = Transform(matrix_from_dict(d["transform"]))
    obj.style = style_from_dict(d["style"])
    obj.visible = d.get("visible", True)
    obj.locked = d.get("locked", False)
    obj.clip_path = path_from_dict(d["clip_path"]) if d.get("clip_path") else None
    obj.mask = _mask_from_dict(d.get("mask"))
    obj.metadata = d.get("metadata", {})


# ---------------------------------------------------------------- objects
def object_to_dict(obj: Any) -> dict[str, Any]:
    d = _base_fields_to_dict(obj)
    if isinstance(obj, Circle):
        d.update(cx=obj.cx, cy=obj.cy, radius=obj.radius)
    elif isinstance(obj, Ellipse):
        d.update(cx=obj.cx, cy=obj.cy, rx=obj.rx, ry=obj.ry)
    elif isinstance(obj, Rectangle):
        d.update(x=obj.x, y=obj.y, width=obj.width, height=obj.height, corner_radius=obj.corner_radius)
    elif isinstance(obj, Polygon):
        d.update(cx=obj.cx, cy=obj.cy, radius=obj.radius, sides=obj.sides, rotation=obj.rotation)
    elif isinstance(obj, Star):
        d.update(
            cx=obj.cx, cy=obj.cy, outer_radius=obj.outer_radius, inner_radius=obj.inner_radius,
            points=obj.points, rotation=obj.rotation,
        )
    elif isinstance(obj, Line):
        d.update(x1=obj.x1, y1=obj.y1, x2=obj.x2, y2=obj.y2)
    elif isinstance(obj, Text):
        d.update(
            content=obj.content, x=obj.x, y=obj.y, font_family=obj.font_family, font_weight=obj.font_weight,
            italic=obj.italic, font_asset_id=obj.font_asset_id, size=obj.size, tracking=obj.tracking,
            leading=obj.leading, alignment=obj.alignment, box_width=obj.box_width, box_height=obj.box_height,
            overflow=obj.overflow, path_ref=path_to_dict(obj.path_ref) if obj.path_ref else None,
            path_offset=obj.path_offset, path_alignment=obj.path_alignment, path_reverse=obj.path_reverse,
            baseline_shift=obj.baseline_shift,
        )
    elif isinstance(obj, Image):
        d.update(
            asset_id=obj.asset_id, x=obj.x, y=obj.y, width=obj.width, height=obj.height,
            crop=[obj.crop.x, obj.crop.y, obj.crop.width, obj.crop.height] if obj.crop else None,
            fit=obj.fit.value, source_width=obj.source_width, source_height=obj.source_height,
        )
    elif isinstance(obj, SymbolInstance):
        d.update(definition_id=obj.definition_id)
    elif isinstance(obj, Group):  # covers Layer too (Layer subclasses Group)
        d.update(children=[object_to_dict(c) for c in obj.children])
    elif hasattr(obj, "to_path"):
        # A raw path-based object with no dedicated parametric fields.
        d.update(path=path_to_dict(obj.to_path()))
    return d


_TYPE_CTORS = {
    "circle": Circle,
    "ellipse": Ellipse,
    "rectangle": Rectangle,
    "polygon": Polygon,
    "star": Star,
    "line": Line,
}


def object_from_dict(d: dict[str, Any]) -> Any:
    kind = d["type"]
    if kind in _TYPE_CTORS:
        cls = _TYPE_CTORS[kind]
        if kind == "circle":
            obj = cls(cx=d["cx"], cy=d["cy"], radius=d["radius"])
        elif kind == "ellipse":
            obj = cls(cx=d["cx"], cy=d["cy"], rx=d["rx"], ry=d["ry"])
        elif kind == "rectangle":
            cr = d.get("corner_radius", 0.0)
            obj = cls(x=d["x"], y=d["y"], width=d["width"], height=d["height"], corner_radius=tuple(cr) if isinstance(cr, list) else cr)
        elif kind == "polygon":
            obj = cls(cx=d["cx"], cy=d["cy"], radius=d["radius"], sides=d["sides"], rotation=d.get("rotation", 0.0))
        elif kind == "star":
            obj = cls(
                cx=d["cx"], cy=d["cy"], outer_radius=d["outer_radius"], inner_radius=d["inner_radius"],
                points=d.get("points", 5), rotation=d.get("rotation", 0.0),
            )
        elif kind == "line":
            obj = cls(x1=d["x1"], y1=d["y1"], x2=d["x2"], y2=d["y2"])
    elif kind == "text":
        obj = Text(
            content=d.get("content", ""), x=d.get("x", 0.0), y=d.get("y", 0.0), font_family=d.get("font_family", "DejaVu Sans"),
            font_weight=d.get("font_weight", 400), italic=d.get("italic", False), font_asset_id=d.get("font_asset_id"),
            size=d.get("size", 16.0), tracking=d.get("tracking", 0.0), leading=d.get("leading"), alignment=d.get("alignment", "left"),
            box_width=d.get("box_width"), box_height=d.get("box_height"), overflow=d.get("overflow", "visible"),
            path_ref=path_from_dict(d["path_ref"]) if d.get("path_ref") else None, path_offset=d.get("path_offset", 0.0),
            path_alignment=d.get("path_alignment", "left"), path_reverse=d.get("path_reverse", False),
            baseline_shift=d.get("baseline_shift", 0.0),
        )
    elif kind == "image":
        crop = d.get("crop")
        obj = Image(
            asset_id=d.get("asset_id", ""), x=d.get("x", 0.0), y=d.get("y", 0.0), width=d.get("width", 0.0),
            height=d.get("height", 0.0), crop=Rect(*crop) if crop else None, fit=FitMode(d.get("fit", "fill")),
            source_width=d.get("source_width", 0), source_height=d.get("source_height", 0),
        )
    elif kind == "symbol-instance":
        obj = SymbolInstance(definition_id=d.get("definition_id", ""))
    elif kind in ("group", "layer"):
        cls = Layer if kind == "layer" else Group
        obj = cls(children=[object_from_dict(c) for c in d.get("children", [])])
    elif kind == "generic-path":
        obj = GenericPathObject(path_data=path_from_dict(d["path"]))
    else:
        raise SerializationError(f"Unknown object type: {kind!r}")

    _apply_base_fields(obj, d)
    if kind in ("group", "layer"):
        for child in obj.children:
            child.parent = obj
    return obj


# ------------------------------------------------------------------ pages
def guide_to_dict(g: Guide) -> dict[str, Any]:
    return {"id": g.id, "orientation": g.orientation.value, "position": g.position, "angle": g.angle, "locked": g.locked}


def guide_from_dict(d: dict[str, Any]) -> Guide:
    return Guide(GuideOrientation(d["orientation"]), d["position"], d.get("angle", 0.0), d.get("locked", False), d["id"])


def grid_to_dict(g: Grid) -> dict[str, Any]:
    return {"kind": g.kind.value, "spacing": g.spacing, "subdivisions": g.subdivisions, "visible": g.visible, "color": color_to_dict(g.color)}


def grid_from_dict(d: dict[str, Any]) -> Grid:
    return Grid(GridKind(d.get("kind", "square")), d.get("spacing", 10.0), d.get("subdivisions", 1), d.get("visible", False), color_from_dict(d["color"]) if d.get("color") else Color(0.5, 0.5, 0.5, 0.3))


def page_to_dict(page: Page) -> dict[str, Any]:
    return {
        "id": page.id,
        "name": page.name,
        "width": page.width,
        "height": page.height,
        "background": color_to_dict(page.background) if page.background else None,
        "layers": [object_to_dict(layer) for layer in page.layers],
        "guides": [guide_to_dict(g) for g in page.guides],
        "grid": grid_to_dict(page.grid),
    }


def page_from_dict(d: dict[str, Any]) -> Page:
    page = Page(
        id=d["id"], name=d.get("name", "Page"), width=d.get("width", 1200.0), height=d.get("height", 800.0),
        background=color_from_dict(d["background"]) if d.get("background") else None,
        layers=[object_from_dict(l) for l in d.get("layers", [])],
        guides=[guide_from_dict(g) for g in d.get("guides", [])],
        grid=grid_from_dict(d["grid"]) if d.get("grid") else Grid(),
    )
    return page


# --------------------------------------------------------------- document
def document_to_dict(doc: Document, *, embed_assets: bool = True) -> dict[str, Any]:
    return {
        "format_version": doc.format_version,
        "engine_version": doc.engine_version,
        "id": doc.id,
        "metadata": {
            "title": doc.metadata.title,
            "author": doc.metadata.author,
            "description": doc.metadata.description,
            "created_at": doc.metadata.created_at,
            "modified_at": doc.metadata.modified_at,
        },
        "settings": {"units": doc.settings.units, "dpi": doc.settings.dpi, "color_mode": doc.settings.color_mode},
        "pages": [page_to_dict(p) for p in doc.pages],
        "symbols": {sid: {"id": s.id, "name": s.name, "children": [object_to_dict(c) for c in s.children]} for sid, s in doc.symbols.items()},
        "styles": {name: style_to_dict(s) for name, s in doc.styles.items()},
        "assets": doc.assets.to_dict(embed_data=embed_assets),
    }


def document_from_dict(d: dict[str, Any]) -> Document:
    doc = Document.__new__(Document)
    doc.id = d.get("id", "")
    doc.metadata = DocumentMetadata(**d.get("metadata", {}))
    doc.settings = DocumentSettings(**d.get("settings", {}))
    doc.pages = [page_from_dict(p) for p in d.get("pages", [])] or [Page()]
    doc.symbols = {}
    for sid, sdict in d.get("symbols", {}).items():
        doc.symbols[sid] = SymbolDefinition(id=sdict["id"], name=sdict.get("name", "Symbol"), children=[object_from_dict(c) for c in sdict.get("children", [])])
    doc.styles = {name: style_from_dict(s) for name, s in d.get("styles", {}).items()}
    doc.assets = AssetManager.from_dict(d.get("assets", {}))
    doc.format_version = d.get("format_version", 1)
    doc.engine_version = d.get("engine_version", "0.1.0")
    doc._active_page_index = 0
    doc.resolve_symbols()
    return doc
