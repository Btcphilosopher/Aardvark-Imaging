"""Linear and radial gradients (spec section 16)."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from aardvark.geometry.matrix import Matrix
from aardvark.geometry.point import Point
from aardvark.style.color import Color


class SpreadMode(str, Enum):
    PAD = "pad"
    REFLECT = "reflect"
    REPEAT = "repeat"


@dataclass(frozen=True, slots=True)
class GradientStop:
    offset: float  # 0..1
    color: Color
    opacity: float = 1.0

    def __post_init__(self) -> None:
        object.__setattr__(self, "offset", max(0.0, min(1.0, self.offset)))


def _sorted_stops(stops: list[GradientStop]) -> tuple[GradientStop, ...]:
    return tuple(sorted(stops, key=lambda s: s.offset))


@dataclass(frozen=True, slots=True)
class LinearGradient:
    start: Point
    end: Point
    stops: tuple[GradientStop, ...] = field(default_factory=tuple)
    spread: SpreadMode = SpreadMode.PAD
    transform: Matrix = field(default_factory=Matrix.identity)
    opacity: float = 1.0

    def __post_init__(self) -> None:
        object.__setattr__(self, "stops", _sorted_stops(list(self.stops)))

    def sample(self, t: float) -> Color:
        return _sample_stops(self.stops, t, self.spread)


@dataclass(frozen=True, slots=True)
class RadialGradient:
    center: Point
    radius: float
    focal: Point | None = None
    stops: tuple[GradientStop, ...] = field(default_factory=tuple)
    spread: SpreadMode = SpreadMode.PAD
    transform: Matrix = field(default_factory=Matrix.identity)
    opacity: float = 1.0

    def __post_init__(self) -> None:
        object.__setattr__(self, "stops", _sorted_stops(list(self.stops)))
        if self.focal is None:
            object.__setattr__(self, "focal", self.center)

    def sample(self, t: float) -> Color:
        return _sample_stops(self.stops, t, self.spread)


def _apply_spread(t: float, spread: SpreadMode) -> float:
    if spread == SpreadMode.PAD:
        return max(0.0, min(1.0, t))
    if spread == SpreadMode.REPEAT:
        return t % 1.0
    if spread == SpreadMode.REFLECT:
        period = t % 2.0
        return period if period <= 1.0 else 2.0 - period
    return t


def _sample_stops(stops: tuple[GradientStop, ...], t: float, spread: SpreadMode) -> Color:
    if not stops:
        return Color.transparent()
    t = _apply_spread(t, spread)
    if t <= stops[0].offset:
        s = stops[0]
        return s.color.with_alpha(s.color.a * s.opacity)
    if t >= stops[-1].offset:
        s = stops[-1]
        return s.color.with_alpha(s.color.a * s.opacity)
    for i in range(len(stops) - 1):
        a, b = stops[i], stops[i + 1]
        if a.offset <= t <= b.offset:
            span = b.offset - a.offset
            local_t = 0.0 if span <= 1e-12 else (t - a.offset) / span
            color = a.color.blended_with(b.color, local_t)
            op = a.opacity + (b.opacity - a.opacity) * local_t
            return color.with_alpha(color.a * op)
    return stops[-1].color
