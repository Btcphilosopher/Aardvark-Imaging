"""Stroke paint and geometry parameters (spec section 14)."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from aardvark.style.fill import Paint, _kind_of, FillKind


class LineCap(str, Enum):
    BUTT = "butt"
    ROUND = "round"
    SQUARE = "square"


class LineJoin(str, Enum):
    MITER = "miter"
    ROUND = "round"
    BEVEL = "bevel"


@dataclass(slots=True)
class Stroke:
    paint: Paint = None
    width: float = 1.0
    opacity: float = 1.0
    cap: LineCap = LineCap.BUTT
    join: LineJoin = LineJoin.MITER
    miter_limit: float = 4.0
    dash_pattern: list[float] = field(default_factory=list)
    dash_offset: float = 0.0

    @property
    def kind(self) -> FillKind:
        return _kind_of(self.paint)

    @property
    def is_dashed(self) -> bool:
        return len(self.dash_pattern) > 0
