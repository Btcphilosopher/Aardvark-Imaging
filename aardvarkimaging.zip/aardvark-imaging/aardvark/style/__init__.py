"""The style system: colour, fill, stroke, gradients, patterns, shadows, opacity."""

from __future__ import annotations

from dataclasses import dataclass, field

from aardvark.style.color import Color
from aardvark.style.fill import Fill, FillKind, Paint
from aardvark.style.gradient import GradientStop, LinearGradient, RadialGradient, SpreadMode
from aardvark.style.opacity import BlendMode, clamp_opacity
from aardvark.style.pattern import Pattern, PatternExtend
from aardvark.style.shadow import Shadow
from aardvark.style.stroke import LineCap, LineJoin, Stroke


@dataclass(slots=True)
class Style:
    """The full paint style attached to a :class:`~aardvark.document.scene.GraphicObject`."""

    fill: Fill = field(default_factory=Fill.none)
    stroke: Stroke | None = None
    shadows: list[Shadow] = field(default_factory=list)
    opacity: float = 1.0
    blend_mode: BlendMode = BlendMode.NORMAL

    def __post_init__(self) -> None:
        self.opacity = clamp_opacity(self.opacity)

    def copy(self) -> "Style":
        return Style(
            fill=Fill(self.fill.paint, self.fill.opacity, self.fill.rule),
            stroke=(
                Stroke(
                    self.stroke.paint,
                    self.stroke.width,
                    self.stroke.opacity,
                    self.stroke.cap,
                    self.stroke.join,
                    self.stroke.miter_limit,
                    list(self.stroke.dash_pattern),
                    self.stroke.dash_offset,
                )
                if self.stroke
                else None
            ),
            shadows=list(self.shadows),
            opacity=self.opacity,
            blend_mode=self.blend_mode,
        )


__all__ = [
    "Style",
    "Color",
    "Fill",
    "FillKind",
    "Paint",
    "GradientStop",
    "LinearGradient",
    "RadialGradient",
    "SpreadMode",
    "Pattern",
    "PatternExtend",
    "Shadow",
    "Stroke",
    "LineCap",
    "LineJoin",
    "BlendMode",
    "clamp_opacity",
]
