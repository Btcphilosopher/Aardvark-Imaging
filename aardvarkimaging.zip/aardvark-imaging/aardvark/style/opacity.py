"""Opacity clamping and blend-mode enumeration (spec sections 25, 41)."""

from __future__ import annotations

from enum import Enum


def clamp_opacity(value: float) -> float:
    return max(0.0, min(1.0, float(value)))


class BlendMode(str, Enum):
    NORMAL = "normal"
    MULTIPLY = "multiply"
    SCREEN = "screen"
    OVERLAY = "overlay"
    DARKEN = "darken"
    LIGHTEN = "lighten"
    DIFFERENCE = "difference"

    @classmethod
    def supported(cls) -> tuple["BlendMode", ...]:
        """Every mode this engine can composite correctly with the current
        (Pillow/numpy) raster backend. All seven spec-listed modes are
        genuinely implemented — see ``aardvark.render.compositor`` — so this
        is currently the full set, kept as a hook for a future backend that
        might not support all of them."""
        return tuple(cls)
