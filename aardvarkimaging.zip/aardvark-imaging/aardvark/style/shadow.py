"""Drop/inner shadow style (spec section 40; actual blur math in
``aardvark.effects.shadow``, this module just holds the declarative style)."""

from __future__ import annotations

from dataclasses import dataclass

from aardvark.style.color import Color


@dataclass(frozen=True, slots=True)
class Shadow:
    offset_x: float = 0.0
    offset_y: float = 4.0
    blur_radius: float = 8.0
    spread: float = 0.0
    color: Color = Color(0.0, 0.0, 0.0, 0.5)
    inner: bool = False
