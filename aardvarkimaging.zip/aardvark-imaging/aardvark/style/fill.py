"""Fill paint (spec section 15)."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from aardvark.style.color import Color
from aardvark.style.gradient import LinearGradient, RadialGradient
from aardvark.style.pattern import Pattern

Paint = Color | LinearGradient | RadialGradient | Pattern | None


class FillKind(str, Enum):
    NONE = "none"
    SOLID = "solid"
    LINEAR_GRADIENT = "linear-gradient"
    RADIAL_GRADIENT = "radial-gradient"
    PATTERN = "pattern"


def _kind_of(paint: Paint) -> FillKind:
    if paint is None:
        return FillKind.NONE
    if isinstance(paint, Color):
        return FillKind.SOLID
    if isinstance(paint, LinearGradient):
        return FillKind.LINEAR_GRADIENT
    if isinstance(paint, RadialGradient):
        return FillKind.RADIAL_GRADIENT
    if isinstance(paint, Pattern):
        return FillKind.PATTERN
    raise TypeError(f"Unsupported paint type: {type(paint)!r}")


@dataclass(slots=True)
class Fill:
    paint: Paint = None
    opacity: float = 1.0
    rule: str = "nonzero"  # "nonzero" | "evenodd"

    @property
    def kind(self) -> FillKind:
        return _kind_of(self.paint)

    @classmethod
    def solid(cls, color: Color, opacity: float = 1.0, rule: str = "nonzero") -> "Fill":
        return cls(color, opacity, rule)

    @classmethod
    def none(cls) -> "Fill":
        return cls(None, 1.0)
