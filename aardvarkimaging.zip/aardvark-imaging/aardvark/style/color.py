"""The colour engine (spec section 17).

Canonical storage is straight (non-premultiplied) RGBA in [0, 1] float64.
RGB/HEX/HSL/HSV are fully implemented conversions. CMYK/Lab/ICC are
*architected for* (the API surface exists) but intentionally raise
:class:`~aardvark.errors.CapabilityError` rather than silently pretending to
be colour-managed — see the module docstring in ``aardvark.errors`` for why.
"""

from __future__ import annotations

import colorsys
import re
from dataclasses import dataclass

from aardvark.errors import CapabilityError, ValidationError

_HEX_RE = re.compile(r"^#?([0-9a-fA-F]{3}|[0-9a-fA-F]{4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$")


def _clamp01(v: float) -> float:
    return max(0.0, min(1.0, v))


@dataclass(frozen=True, slots=True)
class Color:
    r: float = 0.0
    g: float = 0.0
    b: float = 0.0
    a: float = 1.0

    def __post_init__(self) -> None:
        for name in ("r", "g", "b", "a"):
            v = getattr(self, name)
            if not (0.0 <= v <= 1.0):
                object.__setattr__(self, name, _clamp01(float(v)))

    # -- constructors -----------------------------------------------------
    @classmethod
    def from_rgb8(cls, r: int, g: int, b: int, a: int = 255) -> "Color":
        return cls(r / 255.0, g / 255.0, b / 255.0, a / 255.0)

    @classmethod
    def from_hex(cls, value: str) -> "Color":
        m = _HEX_RE.match(value.strip())
        if not m:
            raise ValidationError(f"Invalid hex colour: {value!r}")
        h = m.group(1)
        if len(h) == 3:
            h = "".join(c * 2 for c in h)
            h += "ff"
        elif len(h) == 4:
            h = "".join(c * 2 for c in h)
        elif len(h) == 6:
            h += "ff"
        r, g, b, a = (int(h[i : i + 2], 16) for i in (0, 2, 4, 6))
        return cls.from_rgb8(r, g, b, a)

    @classmethod
    def from_hsl(cls, h: float, s: float, l: float, a: float = 1.0) -> "Color":
        """h in [0, 360), s/l/a in [0, 1]."""
        r, g, b = colorsys.hls_to_rgb((h % 360) / 360.0, l, s)
        return cls(r, g, b, a)

    @classmethod
    def from_hsv(cls, h: float, s: float, v: float, a: float = 1.0) -> "Color":
        r, g, b = colorsys.hsv_to_rgb((h % 360) / 360.0, s, v)
        return cls(r, g, b, a)

    # -- conversions --------------------------------------------------
    def to_rgb8(self) -> tuple[int, int, int]:
        return (round(self.r * 255), round(self.g * 255), round(self.b * 255))

    def to_rgba8(self) -> tuple[int, int, int, int]:
        return (*self.to_rgb8(), round(self.a * 255))

    def to_hex(self, *, include_alpha: bool = False) -> str:
        r, g, b, a = self.to_rgba8()
        if include_alpha:
            return f"#{r:02x}{g:02x}{b:02x}{a:02x}"
        return f"#{r:02x}{g:02x}{b:02x}"

    def to_hsl(self) -> tuple[float, float, float]:
        h, l, s = colorsys.rgb_to_hls(self.r, self.g, self.b)
        return (h * 360.0, s, l)

    def to_hsv(self) -> tuple[float, float, float]:
        h, s, v = colorsys.rgb_to_hsv(self.r, self.g, self.b)
        return (h * 360.0, s, v)

    def to_cmyk(self) -> tuple[float, float, float, float]:
        raise CapabilityError(
            "CMYK conversion requires a colour-managed profile (ICC) to be correct "
            "for print; naive RGB->CMYK is not implemented to avoid producing "
            "silently wrong separations. Architected for a future ICC pipeline.",
            details={"capability": "cmyk"},
        )

    def to_lab(self) -> tuple[float, float, float]:
        raise CapabilityError(
            "Lab conversion requires a reference white point / ICC profile; not yet implemented.",
            details={"capability": "lab"},
        )

    # -- editing ------------------------------------------------------
    def with_alpha(self, a: float) -> "Color":
        return Color(self.r, self.g, self.b, _clamp01(a))

    def blended_with(self, other: "Color", t: float) -> "Color":
        """Linear-light-naive lerp in sRGB space (fine for UI colour pickers
        and gradient stop preview; not a colour-managed blend)."""
        return Color(
            self.r + (other.r - self.r) * t,
            self.g + (other.g - self.g) * t,
            self.b + (other.b - self.b) * t,
            self.a + (other.a - self.a) * t,
        )

    def luminance(self) -> float:
        """Relative luminance (Rec. 709 coefficients) — used by luminance masks."""
        return 0.2126 * self.r + 0.7152 * self.g + 0.0722 * self.b

    @classmethod
    def transparent(cls) -> "Color":
        return cls(0.0, 0.0, 0.0, 0.0)

    @classmethod
    def black(cls) -> "Color":
        return cls(0.0, 0.0, 0.0, 1.0)

    @classmethod
    def white(cls) -> "Color":
        return cls(1.0, 1.0, 1.0, 1.0)
