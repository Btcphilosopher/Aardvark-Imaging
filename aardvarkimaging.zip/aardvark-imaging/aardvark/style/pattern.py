"""Tile patterns (spec section 15).

A pattern references a small piece of vector content (its "tile") which is
repeated across the fill region. The tile content lives in the document's
scene graph like any other object; ``Pattern`` only stores the tile size and
a reference to it, so editing the tile content updates every use of the
pattern (the same "definition -> instances" idea used by Symbols).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING

from aardvark.geometry.matrix import Matrix
from aardvark.geometry.rect import Rect

if TYPE_CHECKING:
    from aardvark.document.scene import GraphicObject


class PatternExtend(str, Enum):
    REPEAT = "repeat"
    REPEAT_X = "repeat-x"
    REPEAT_Y = "repeat-y"
    NONE = "none"


@dataclass(slots=True)
class Pattern:
    tile_bounds: Rect
    content: list["GraphicObject"] = field(default_factory=list)
    transform: Matrix = field(default_factory=Matrix.identity)
    extend: PatternExtend = PatternExtend.REPEAT
    opacity: float = 1.0
    id: str | None = None  # asset/definition id when registered on a Document
