"""Text shaping abstraction (spec section 19).

The default :class:`BasicShaper` does simple left-to-right, one-glyph-per-
character placement using the font's own advance widths — correct for Latin
text with no ligatures or complex-script reordering. The
:class:`Shaper` protocol is the seam a real shaping engine (HarfBuzz) plugs
into later without touching layout/rendering code; :class:`HarfBuzzShaper`
is that seam, currently raising :class:`~aardvark.errors.CapabilityError`
rather than pretending to shape correctly.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from aardvark.errors import CapabilityError
from aardvark.text.font import Font


@dataclass(frozen=True, slots=True)
class GlyphPlacement:
    char: str
    x: float
    advance: float


class Shaper(Protocol):
    def shape(self, text: str, font: Font, size: float, tracking: float = 0.0) -> list[GlyphPlacement]: ...


class BasicShaper:
    def shape(self, text: str, font: Font, size: float, tracking: float = 0.0) -> list[GlyphPlacement]:
        placements: list[GlyphPlacement] = []
        x = 0.0
        for ch in text:
            advance = font.advance_width(ch, size)
            placements.append(GlyphPlacement(ch, x, advance))
            x += advance + tracking
        return placements


class HarfBuzzShaper:
    """Reserved integration point for complex-script shaping. Not wired up in
    this build — raises rather than silently falling back so callers never
    mistake unshapen text for shaped text."""

    def shape(self, text: str, font: Font, size: float, tracking: float = 0.0) -> list[GlyphPlacement]:
        raise CapabilityError(
            "HarfBuzz shaping is architected for but not implemented in this build; "
            "use BasicShaper for Latin-script text.",
            details={"capability": "harfbuzz-shaping"},
        )


DEFAULT_SHAPER: Shaper = BasicShaper()
