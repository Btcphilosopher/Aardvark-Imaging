"""The Text scene object: typography + layout + text-on-path (spec sections
18-20), always convertible to real vector outlines via :meth:`Text.to_path`.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from aardvark.assets.manager import AssetManager
from aardvark.document.scene import GraphicObject
from aardvark.geometry.bounds import Bounds
from aardvark.geometry.matrix import Matrix
from aardvark.geometry.point import Point
from aardvark.paths.path import Path
from aardvark.text.font import Font
from aardvark.text.layout import TextLayoutResult, layout_text


@dataclass
class Text(GraphicObject):
    content: str = ""
    x: float = 0.0
    y: float = 0.0
    font_family: str = "DejaVu Sans"
    font_weight: int = 400
    italic: bool = False
    font_asset_id: str | None = None
    size: float = 16.0
    tracking: float = 0.0
    leading: float | None = None
    alignment: str = "left"  # left | center | right | justify
    box_width: float | None = None
    box_height: float | None = None
    overflow: str = "visible"  # visible | clip

    # Text-on-path (spec section 20)
    path_ref: Path | None = None
    path_offset: float = 0.0
    path_alignment: str = "left"
    path_reverse: bool = False
    baseline_shift: float = 0.0

    def __post_init__(self) -> None:
        self.kind = "text"

    # -- font resolution ---------------------------------------------------
    def resolve_font(self, asset_manager: AssetManager | None = None) -> Font:
        if self.font_asset_id and asset_manager is not None:
            data = asset_manager.raw_bytes(self.font_asset_id)
            return Font.from_bytes(data, family=self.font_family, weight=self.font_weight, italic=self.italic)
        return Font.system(self.font_family, self.font_weight, self.italic)

    def layout(self, asset_manager: AssetManager | None = None) -> TextLayoutResult:
        font = self.resolve_font(asset_manager)
        return layout_text(
            self.content,
            font,
            self.size,
            box_width=self.box_width,
            box_height=self.box_height,
            tracking=self.tracking,
            leading=self.leading,
            alignment=self.alignment,
            overflow=self.overflow,
        )

    # -- GraphicObject interface -------------------------------------------
    def local_bounds(self) -> Bounds:
        if self.path_ref is not None:
            return self.path_ref.bounds()
        result = self.layout()
        return Bounds(
            self.x,
            self.y,
            self.x + (self.box_width if self.box_width is not None else result.total_width),
            self.y + (self.box_height if self.box_height is not None else result.total_height),
        )

    def to_path(self, asset_manager: AssetManager | None = None) -> Path:
        font = self.resolve_font(asset_manager)
        if self.path_ref is not None:
            return self._to_path_on_curve(font)
        result = layout_text(
            self.content,
            font,
            self.size,
            box_width=self.box_width,
            box_height=self.box_height,
            tracking=self.tracking,
            leading=self.leading,
            alignment=self.alignment,
            overflow=self.overflow,
        )
        combined = Path()
        for line in result.lines:
            for glyph in line.glyphs:
                outline, _ = font.glyph_path(glyph.char, self.size)
                if outline.is_empty():
                    continue
                gx = self.x + line.x_offset + glyph.x
                gy = self.y + line.baseline_y
                combined.extend(outline.transformed(Matrix.translation(gx, gy)))
        return combined

    def _to_path_on_curve(self, font: Font) -> Path:
        assert self.path_ref is not None
        flat = self.path_ref.flatten()
        polyline: list[Point] = [p for sub in flat for p in sub]
        if self.path_reverse:
            polyline = list(reversed(polyline))
        total_length = sum(polyline[i].distance_to(polyline[i + 1]) for i in range(len(polyline) - 1))

        from aardvark.text.shaping import DEFAULT_SHAPER

        glyphs = DEFAULT_SHAPER.shape(self.content, font, self.size, self.tracking)
        text_width = (glyphs[-1].x + glyphs[-1].advance) if glyphs else 0.0

        if self.path_alignment == "center":
            start = self.path_offset + (total_length - text_width) / 2.0
        elif self.path_alignment == "right":
            start = self.path_offset + (total_length - text_width)
        else:
            start = self.path_offset

        combined = Path()
        for glyph in glyphs:
            outline, advance = font.glyph_path(glyph.char, self.size)
            if outline.is_empty():
                continue
            center_distance = start + glyph.x + advance / 2.0
            point, angle = _sample_polyline(polyline, center_distance)
            if point is None:
                continue
            nx, ny = -math.sin(angle), math.cos(angle)
            px = point.x + nx * self.baseline_shift
            py = point.y + ny * self.baseline_shift
            m = Matrix.translation(-advance / 2.0, 0.0)
            m = m.compose(Matrix.rotation(angle))
            m = m.compose(Matrix.translation(px, py))
            combined.extend(outline.transformed(m))
        return combined


def _sample_polyline(polyline: list[Point], distance: float) -> tuple[Point | None, float]:
    if len(polyline) < 2 or distance < 0:
        return None, 0.0
    remaining = distance
    for i in range(len(polyline) - 1):
        a, b = polyline[i], polyline[i + 1]
        seg_len = a.distance_to(b)
        if seg_len <= 1e-12:
            continue
        if remaining <= seg_len:
            t = remaining / seg_len
            point = a.lerp(b, t)
            angle = math.atan2(b.y - a.y, b.x - a.x)
            return point, angle
        remaining -= seg_len
    # Past the end of the path: clamp to the final point/tangent.
    a, b = polyline[-2], polyline[-1]
    return b, math.atan2(b.y - a.y, b.x - a.x)
