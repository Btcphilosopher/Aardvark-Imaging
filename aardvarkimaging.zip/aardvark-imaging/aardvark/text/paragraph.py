"""Paragraph splitting (spec section 19)."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class Paragraph:
    text: str
    alignment: str = "left"


def split_paragraphs(text: str, alignment: str = "left") -> list[Paragraph]:
    """Split on explicit newlines. A run of text with no ``\\n`` is a single
    paragraph that the layout engine will still soft-wrap to fit a box."""
    return [Paragraph(line, alignment) for line in text.split("\n")]
