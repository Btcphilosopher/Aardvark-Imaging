"""Line breaking and text measurement (spec section 19).

Handles single-line, multi-line and fixed-box text with left/center/right/
justify alignment and visible/clip overflow. Word-wrapping is greedy
(no hyphenation, no line-breaking-algorithm optimisation) — architecture
leaves room for a Knuth-Plass style optimiser later without changing the
public :func:`layout_text` signature.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from aardvark.text.font import Font
from aardvark.text.paragraph import split_paragraphs
from aardvark.text.shaping import DEFAULT_SHAPER, GlyphPlacement, Shaper


@dataclass(slots=True)
class LineLayout:
    text: str
    x_offset: float
    baseline_y: float
    width: float
    glyphs: list[GlyphPlacement] = field(default_factory=list)


@dataclass(slots=True)
class TextLayoutResult:
    lines: list[LineLayout] = field(default_factory=list)
    total_width: float = 0.0
    total_height: float = 0.0
    overflowed: bool = False


def wrap_paragraph(text: str, font: Font, size: float, max_width: float | None, tracking: float) -> list[str]:
    if not max_width or not text:
        return [text]
    words = text.split(" ")
    lines: list[str] = []
    current = ""
    for word in words:
        candidate = word if not current else f"{current} {word}"
        if font.measure(candidate, size, tracking) <= max_width or not current:
            current = candidate
        else:
            lines.append(current)
            current = word
    lines.append(current)
    return lines


def _aligned_glyphs(
    glyphs: list[GlyphPlacement], width: float, box_width: float, alignment: str, is_last_wrapped_line: bool
) -> tuple[list[GlyphPlacement], float, float]:
    """Returns (glyphs, x_offset, effective_width)."""
    if alignment == "justify" and box_width and not is_last_wrapped_line:
        space_count = sum(1 for g in glyphs if g.char == " ")
        if space_count > 0 and width < box_width:
            extra = (box_width - width) / space_count
            new_glyphs: list[GlyphPlacement] = []
            shift = 0.0
            for g in glyphs:
                new_glyphs.append(GlyphPlacement(g.char, g.x + shift, g.advance))
                if g.char == " ":
                    shift += extra
            return new_glyphs, 0.0, box_width
        return glyphs, 0.0, width

    if alignment == "center":
        return glyphs, -width / 2.0, width
    if alignment == "right":
        return glyphs, -width, width
    return glyphs, 0.0, width  # left / unrecognised alignment / justify-fallback


def layout_text(
    text: str,
    font: Font,
    size: float,
    *,
    box_width: float | None = None,
    box_height: float | None = None,
    tracking: float = 0.0,
    leading: float | None = None,
    alignment: str = "left",
    overflow: str = "visible",
    shaper: Shaper = DEFAULT_SHAPER,
) -> TextLayoutResult:
    ascent, descent, line_gap = font.line_metrics()
    line_height = leading if leading is not None else (ascent - descent + line_gap) * size

    lines: list[LineLayout] = []
    baseline_y = ascent * size
    max_width_seen = 0.0
    overflowed = False

    for para in split_paragraphs(text, alignment):
        wrapped = wrap_paragraph(para.text, font, size, box_width, tracking)
        for i, line_text in enumerate(wrapped):
            if box_height is not None and (baseline_y - ascent * size + line_height) > box_height and lines:
                overflowed = True
                if overflow == "clip":
                    return TextLayoutResult(lines, max_width_seen, box_height, True)
            glyphs = shaper.shape(line_text, font, size, tracking)
            width = (glyphs[-1].x + glyphs[-1].advance) if glyphs else 0.0
            is_last_wrapped_line = i == len(wrapped) - 1
            glyphs, x_offset, eff_width = _aligned_glyphs(
                glyphs, width, box_width or 0.0, para.alignment, is_last_wrapped_line
            )
            lines.append(LineLayout(line_text, x_offset, baseline_y, eff_width, glyphs))
            max_width_seen = max(max_width_seen, eff_width)
            baseline_y += line_height

    if lines:
        total_height = (baseline_y - line_height) - (ascent * size) + (ascent - descent) * size
    else:
        total_height = 0.0
    return TextLayoutResult(lines, max_width_seen, total_height, overflowed)
