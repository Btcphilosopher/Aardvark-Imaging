"""Font loading, metrics, and glyph-outline extraction (spec section 18).

Text stays vector: :meth:`Font.glyph_path` walks the font's own outline data
(via fontTools) and returns a real :class:`~aardvark.paths.path.Path` — the
same "Create Outlines" operation a production vector tool exposes — rather
than ever rasterizing glyphs internally. Rasterization only happens at final
PNG/JPEG export, same as every other vector object.
"""

from __future__ import annotations

import io
from dataclasses import dataclass, field
from pathlib import Path as FsPath

from fontTools.pens.basePen import BasePen
from fontTools.ttLib import TTFont

from aardvark.errors import FontError
from aardvark.paths.path import Path

_BUNDLED_FONTS_DIR = FsPath(__file__).resolve().parent.parent / "assets" / "data" / "fonts"

# Synthetic-oblique shear applied when italic text is requested but no
# dedicated italic face is available — an approximation, not a real italic
# design, and treated as such (see Font.is_synthetic_italic).
_SYNTHETIC_ITALIC_SKEW = -0.21


class _OutlinePen(BasePen):
    """Feeds a glyph's outline (TrueType quadratic or CFF cubic — BasePen
    normalises both) into an Aardvark :class:`Path`, in font units."""

    def __init__(self, glyph_set, target: Path) -> None:
        super().__init__(glyph_set)
        self._target = target
        self._started = False

    def _moveTo(self, pt):
        self._target.move_to(pt[0], pt[1])
        self._started = True

    def _lineTo(self, pt):
        self._target.line_to(pt[0], pt[1])

    def _curveToOne(self, p1, p2, p3):
        self._target.curve_to(p1[0], p1[1], p2[0], p2[1], p3[0], p3[1])

    def _qCurveToOne(self, p1, p2):
        self._target.quad_to(p1[0], p1[1], p2[0], p2[1])

    def _closePath(self):
        if self._started:
            self._target.close()
        self._started = False


@dataclass(slots=True)
class Font:
    family: str = "DejaVu Sans"
    weight: int = 400
    italic: bool = False
    file_path: FsPath | None = None
    data: bytes | None = None
    _tt: TTFont | None = field(default=None, repr=False, compare=False)
    _glyph_set: dict | None = field(default=None, repr=False, compare=False)
    _cmap: dict | None = field(default=None, repr=False, compare=False)

    # -- construction -----------------------------------------------------
    @classmethod
    def system(cls, family: str = "DejaVu Sans", weight: int = 400, italic: bool = False) -> "Font":
        bold = weight >= 600
        path = _BUNDLED_FONTS_DIR / ("DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf")
        if not path.exists():
            raise FontError(f"Bundled fallback font missing: {path}")
        return cls(family=family, weight=weight, italic=italic, file_path=path)

    @classmethod
    def from_bytes(cls, data: bytes, *, family: str | None = None, weight: int = 400, italic: bool = False) -> "Font":
        font = cls(family=family or "Embedded", weight=weight, italic=italic, data=data)
        if family is None:
            from aardvark.assets.fonts import inspect_font

            font.family = inspect_font(data).family
        return font

    @property
    def is_synthetic_italic(self) -> bool:
        return self.italic

    # -- internal loading -------------------------------------------------
    def _ttfont(self) -> TTFont:
        if self._tt is None:
            try:
                if self.data is not None:
                    self._tt = TTFont(io.BytesIO(self.data))
                elif self.file_path is not None:
                    self._tt = TTFont(str(self.file_path))
                else:
                    raise FontError("Font has neither embedded data nor a file path")
            except FontError:
                raise
            except Exception as exc:
                raise FontError(f"Failed to load font: {exc}") from exc
        return self._tt

    def _glyphset(self):
        if self._glyph_set is None:
            self._glyph_set = self._ttfont().getGlyphSet()
        return self._glyph_set

    def _cmap_table(self) -> dict:
        if self._cmap is None:
            self._cmap = self._ttfont().getBestCmap()
        return self._cmap

    @property
    def units_per_em(self) -> int:
        return self._ttfont()["head"].unitsPerEm

    def line_metrics(self) -> tuple[float, float, float]:
        """Returns (ascent, descent, line_gap) as fractions of the em square."""
        tt = self._ttfont()
        upm = self.units_per_em
        if "hhea" in tt:
            hhea = tt["hhea"]
            return (hhea.ascender / upm, hhea.descender / upm, hhea.lineGap / upm)
        return (0.8, -0.2, 0.0)

    def glyph_name_for(self, char: str) -> str | None:
        return self._cmap_table().get(ord(char))

    def advance_width(self, char: str, size: float) -> float:
        glyph_name = self.glyph_name_for(char)
        if glyph_name is None:
            return size * 0.5  # missing-glyph fallback advance
        try:
            hmtx = self._ttfont()["hmtx"]
            width_units = hmtx[glyph_name][0]
        except Exception:
            width_units = self.units_per_em * 0.5
        return width_units / self.units_per_em * size

    def measure(self, text: str, size: float, tracking: float = 0.0) -> float:
        if not text:
            return 0.0
        total = sum(self.advance_width(ch, size) for ch in text)
        return total + tracking * max(0, len(text) - 1)

    def glyph_path(self, char: str, size: float) -> tuple[Path, float]:
        """Returns (outline, advance_width) for one character, scaled to
        ``size`` and flipped into a y-down coordinate system (font units are
        y-up), with synthetic-oblique shear applied if requested."""
        glyph_name = self.glyph_name_for(char)
        advance = self.advance_width(char, size)
        if glyph_name is None or char.isspace():
            return Path(), advance

        raw = Path()
        pen = _OutlinePen(self._glyphset(), raw)
        try:
            self._glyphset()[glyph_name].draw(pen)
        except Exception as exc:
            raise FontError(f"Failed to extract outline for glyph {glyph_name!r}: {exc}") from exc

        scale = size / self.units_per_em
        from aardvark.geometry.matrix import Matrix

        m = Matrix.scaling(scale, -scale)  # flip y: font em-space is y-up
        if self.is_synthetic_italic:
            m = m.compose(Matrix.skewing(skew_x_radians=_SYNTHETIC_ITALIC_SKEW))
        return raw.transformed(m), advance
