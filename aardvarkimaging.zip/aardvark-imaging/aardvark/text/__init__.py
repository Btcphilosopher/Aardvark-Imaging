"""Typography: fonts, shaping, layout, paragraphs, and the Text scene object."""

from aardvark.text.font import Font
from aardvark.text.text import Text
from aardvark.text.layout import LineLayout, TextLayoutResult, layout_text
from aardvark.text.paragraph import Paragraph, split_paragraphs
from aardvark.text.shaping import BasicShaper, GlyphPlacement, HarfBuzzShaper, Shaper

__all__ = [
    "Font",
    "Text",
    "LineLayout",
    "TextLayoutResult",
    "layout_text",
    "Paragraph",
    "split_paragraphs",
    "BasicShaper",
    "GlyphPlacement",
    "HarfBuzzShaper",
    "Shaper",
]
