"""The native ``.aardvark`` document format (spec sections 47-48, 52).

A versioned, structured (plain JSON) format rather than a proprietary binary
blob — geometry, layers, styles, text, embedded assets, symbols, guides and
metadata all round-trip through :mod:`aardvark.document.serialization`.
Saves are atomic (write to a temp file, then ``os.replace``): the primary
file is never touched until the new content has been fully and successfully
written, so a crash or a serialization error mid-save can never corrupt the
existing document on disk.
"""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any, Callable

from aardvark.config import DEFAULT_CONFIG
from aardvark.document.document import Document
from aardvark.document.serialization import document_from_dict, document_to_dict
from aardvark.errors import SerializationError

EXTENSION = ".aardvark"
AUTOSAVE_SUFFIX = ".autosave"


# --------------------------------------------------------------- migrations
# Each entry migrates a document dict *from* the keyed version to the next
# one. Empty today (format_version 1 is the only version that has ever
# existed) — this is the real extension point future format changes hook
# into, not a placeholder.
MIGRATIONS: dict[int, Callable[[dict[str, Any]], dict[str, Any]]] = {}


def migrate_to_current(data: dict[str, Any]) -> dict[str, Any]:
    version = data.get("format_version", 1)
    current = DEFAULT_CONFIG.format_version
    if version > current:
        raise SerializationError(
            f"Document format_version {version} is newer than this engine supports ({current}); "
            "upgrade Aardvark Imaging to open it.",
            details={"document_version": version, "engine_supports": current},
        )
    while version < current:
        migration = MIGRATIONS.get(version)
        if migration is None:
            raise SerializationError(f"No migration registered from format_version {version} to {version + 1}")
        data = migration(data)
        version = data.get("format_version", version + 1)
    return data


# ------------------------------------------------------------------- I/O
def _atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_name, path)
    except BaseException:
        try:
            os.unlink(tmp_name)
        except OSError:
            pass
        raise


def save_document(document: Document, path: str | Path, *, embed_assets: bool = True) -> None:
    data = document_to_dict(document, embed_assets=embed_assets)
    text = json.dumps(data, ensure_ascii=False)
    _atomic_write_text(Path(path), text)


def load_document(path: str | Path) -> Document:
    p = Path(path)
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise SerializationError(f"{p} is not a valid Aardvark document (invalid JSON): {exc}") from exc
    data = migrate_to_current(data)
    return document_from_dict(data)


# --------------------------------------------------------------- autosave
def autosave_path(original_path: str | Path) -> Path:
    p = Path(original_path)
    return p.with_name(p.name + AUTOSAVE_SUFFIX)


def autosave(document: Document, original_path: str | Path) -> Path:
    """Write a recovery snapshot alongside ``original_path`` without ever
    touching the primary file itself."""
    target = autosave_path(original_path)
    save_document(document, target)
    return target


def has_autosave(original_path: str | Path) -> bool:
    return autosave_path(original_path).exists()


def recover_from_autosave(original_path: str | Path) -> Document | None:
    target = autosave_path(original_path)
    if not target.exists():
        return None
    return load_document(target)


def discard_autosave(original_path: str | Path) -> None:
    target = autosave_path(original_path)
    if target.exists():
        target.unlink()
