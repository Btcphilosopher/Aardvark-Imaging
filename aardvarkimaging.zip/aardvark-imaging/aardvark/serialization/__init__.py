"""The native ``.aardvark`` document format: versioning, migrations, atomic
save/load, and autosave/recovery."""

from aardvark.serialization.format import (
    EXTENSION,
    MIGRATIONS,
    autosave,
    autosave_path,
    discard_autosave,
    has_autosave,
    load_document,
    migrate_to_current,
    recover_from_autosave,
    save_document,
)

__all__ = [
    "EXTENSION",
    "MIGRATIONS",
    "save_document",
    "load_document",
    "migrate_to_current",
    "autosave",
    "autosave_path",
    "has_autosave",
    "recover_from_autosave",
    "discard_autosave",
]
