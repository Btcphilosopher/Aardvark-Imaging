"""The local IPC service (spec sections 54-55): a Unix domain socket
exposing the exact same operations as :class:`~aardvark.engine.Engine`
through a small newline-delimited JSON protocol.

Never exposed publicly — a Unix socket is filesystem-permission-scoped to
the local machine by construction, which is the whole point of using one
here instead of a TCP/HTTP server (spec: "do not expose the service
publicly"). This is the transport the future Kotlin macOS client speaks to;
the CLI and direct Python use of :class:`Engine` skip this layer entirely.

Protocol: one JSON object per line in, one JSON object per line out::

    {"request": "render", "document_id": "doc-001", "page_index": 0}
    -> {"status": "ok", "width": 1200, "height": 800, "png_base64": "..."}

Every response has a ``"status"`` key: ``"ok"`` or ``"error"`` (with
``"error"``/``"message"``/``"details"`` describing what went wrong — the
same shape :meth:`aardvark.errors.AardvarkError.to_dict` produces).
"""

from __future__ import annotations

import json
import logging
import os
import socketserver
from pathlib import Path

from aardvark.engine import Engine
from aardvark.errors import AardvarkError

logger = logging.getLogger("aardvark.api.server")

# Methods on Engine that are safe to dispatch to over the socket — an
# explicit allowlist so no private/internal attribute is ever reachable
# from the wire, however the request is spelled.
_ALLOWED_REQUESTS = {
    "health",
    "version",
    "capabilities",
    "create_document",
    "open_document",
    "close_document",
    "save_document",
    "add_object",
    "remove_object",
    "move_object",
    "transform_object",
    "set_style",
    "get_bounds",
    "hit_test",
    "render",
    "export",
    "undo",
    "redo",
    "validate",
}


class _RequestHandler(socketserver.StreamRequestHandler):
    def handle(self) -> None:
        engine: Engine = self.server.engine  # type: ignore[attr-defined]
        for raw_line in self.rfile:
            line = raw_line.strip()
            if not line:
                continue
            self._handle_line(engine, line)

    def _handle_line(self, engine: Engine, line: bytes) -> None:
        try:
            request = json.loads(line)
        except json.JSONDecodeError as exc:
            self._send({"status": "error", "error": "invalid_json", "message": str(exc)})
            return

        if not isinstance(request, dict) or "request" not in request:
            self._send({"status": "error", "error": "invalid_request", "message": "Expected {'request': <name>, ...}"})
            return

        method_name = request.pop("request")
        if method_name not in _ALLOWED_REQUESTS:
            self._send({"status": "error", "error": "unknown_request", "message": f"Unknown or disallowed request: {method_name!r}"})
            return

        method = getattr(engine, method_name)
        try:
            result = method(**request)
            self._send(result)
        except AardvarkError as exc:
            payload = exc.to_dict()
            payload["status"] = "error"
            self._send(payload)
            logger.info("request %s failed: %s", method_name, exc)
        except TypeError as exc:
            self._send({"status": "error", "error": "bad_arguments", "message": str(exc)})
        except Exception as exc:  # last-resort: never crash the server on one bad request
            logger.exception("Unhandled error serving %s", method_name)
            self._send({"status": "error", "error": "internal_error", "message": str(exc)})

    def _send(self, obj: dict) -> None:
        self.wfile.write((json.dumps(obj) + "\n").encode("utf-8"))


class AardvarkServer(socketserver.ThreadingUnixStreamServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, socket_path: str | Path, engine: Engine | None = None) -> None:
        self.engine = engine or Engine()
        socket_path = str(socket_path)
        if os.path.exists(socket_path):
            os.unlink(socket_path)
        super().__init__(socket_path, _RequestHandler)
        os.chmod(socket_path, 0o600)  # local-user-only, per "never expose publicly"

    def shutdown_and_cleanup(self) -> None:
        socket_path = self.server_address
        self.shutdown()
        self.server_close()
        if isinstance(socket_path, str) and os.path.exists(socket_path):
            os.unlink(socket_path)


def serve_forever(socket_path: str | Path, engine: Engine | None = None) -> None:
    server = AardvarkServer(socket_path, engine)
    logger.info("Aardvark engine listening on %s", socket_path)
    try:
        server.serve_forever()
    finally:
        server.shutdown_and_cleanup()
