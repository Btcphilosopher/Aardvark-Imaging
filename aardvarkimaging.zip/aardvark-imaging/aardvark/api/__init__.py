"""The local IPC API: a Unix-domain-socket JSON server wrapping ``Engine``."""

from aardvark.api.server import AardvarkServer, serve_forever

__all__ = ["AardvarkServer", "serve_forever"]
