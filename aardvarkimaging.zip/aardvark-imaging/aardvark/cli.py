"""The ``aardvark`` command-line interface (spec sections 78-79).

The Python engine is fully usable standalone through this CLI — no Kotlin
UI required::

    aardvark new design.aardvark --width 1200 --height 800
    aardvark render design.aardvark --out design.png --scale 2
    aardvark export design.aardvark --format svg --out design.svg
    aardvark validate design.aardvark
    aardvark inspect design.aardvark
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from aardvark.document.document import Document
from aardvark.document.scene import Group
from aardvark.errors import AardvarkError
from aardvark.images.image import Image
from aardvark.text.text import Text

_PATH_KINDS = {"rectangle", "circle", "ellipse", "polygon", "star", "line", "generic-path"}


def _cmd_new(args: argparse.Namespace) -> int:
    doc = Document(width=args.width, height=args.height, title=args.title or Path(args.path).stem)
    doc.save(args.path)
    print(f"Created {args.path} ({args.width}x{args.height})")
    return 0


def _cmd_open(args: argparse.Namespace) -> int:
    doc = Document.load(args.path)
    print(f"Opened {args.path}: {doc.metadata.title!r}, {len(doc.pages)} page(s)")
    return 0


def _cmd_render(args: argparse.Namespace) -> int:
    from aardvark.render.renderer import RenderRequest, Renderer

    doc = Document.load(args.path)
    out = args.out or str(Path(args.path).with_suffix(".png"))
    req = RenderRequest(page_index=args.page, scale=args.scale)
    img = Renderer().render_document(doc, req)
    img.save(out, format="PNG")
    print(f"Rendered page {args.page} of {args.path} -> {out} ({img.width}x{img.height})")
    return 0


def _cmd_export(args: argparse.Namespace) -> int:
    doc = Document.load(args.path)
    fmt = args.format.lower()
    out = args.out or str(Path(args.path).with_suffix(f".{fmt}"))
    if fmt == "svg":
        from aardvark.export.svg import save_svg

        save_svg(doc, out, args.page)
    elif fmt == "pdf":
        from aardvark.export.pdf import export_pdf

        export_pdf(doc, out)
    elif fmt == "png":
        from aardvark.export.png import export_png

        export_png(doc, out, args.page, scale=args.scale)
    elif fmt in ("jpeg", "jpg"):
        from aardvark.export.jpeg import export_jpeg

        export_jpeg(doc, out, args.page, scale=args.scale)
    else:
        print(f"Unsupported format: {fmt!r} (supported: svg, pdf, png, jpeg)", file=sys.stderr)
        return 2
    print(f"Exported {args.path} -> {out} ({fmt})")
    return 0


def _cmd_validate(args: argparse.Namespace) -> int:
    doc = Document.load(args.path)
    issues = doc.validate()
    if not issues:
        print(f"{args.path}: valid, no issues found")
        return 0
    for issue in issues:
        print(f"[{issue['severity']}] {issue['code']}: {issue['message']}")
    errors = sum(1 for i in issues if i["severity"] == "error")
    print(f"\n{len(issues)} issue(s), {errors} error(s)")
    return 1 if errors else 0


def _cmd_inspect(args: argparse.Namespace) -> int:
    doc = Document.load(args.path)
    page = doc.pages[args.page]
    objects = [o for o in page.all_objects() if not isinstance(o, Group)]
    paths = sum(1 for o in objects if o.kind in _PATH_KINDS)
    texts = sum(1 for o in objects if isinstance(o, Text))
    images = sum(1 for o in objects if isinstance(o, Image))

    print("Document")
    print(f"Width: {page.width:g}")
    print(f"Height: {page.height:g}")
    print(f"Pages: {len(doc.pages)}")
    print(f"Layers: {len(page.layers)}")
    print(f"Objects: {len(objects):,}")
    print(f"Paths: {paths:,}")
    print(f"Text objects: {texts:,}")
    print(f"Images: {images:,}")
    print(f"Symbols: {len(doc.symbols):,}")
    print(f"Assets: {len(doc.assets.all_ids()):,}")
    return 0


def _cmd_serve(args: argparse.Namespace) -> int:
    from aardvark.api.server import serve_forever

    serve_forever(args.socket)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="aardvark", description="Aardvark Imaging vector graphics engine")
    sub = parser.add_subparsers(dest="command", required=True)

    p_new = sub.add_parser("new", help="Create a new blank document")
    p_new.add_argument("path")
    p_new.add_argument("--width", type=float, default=1200.0)
    p_new.add_argument("--height", type=float, default=800.0)
    p_new.add_argument("--title", default=None)
    p_new.set_defaults(func=_cmd_new)

    p_open = sub.add_parser("open", help="Open a document and print a summary")
    p_open.add_argument("path")
    p_open.set_defaults(func=_cmd_open)

    p_render = sub.add_parser("render", help="Render a page to PNG")
    p_render.add_argument("path")
    p_render.add_argument("--page", type=int, default=0)
    p_render.add_argument("--scale", type=float, default=1.0)
    p_render.add_argument("--out", default=None)
    p_render.set_defaults(func=_cmd_render)

    p_export = sub.add_parser("export", help="Export to SVG/PDF/PNG/JPEG")
    p_export.add_argument("path")
    p_export.add_argument("--format", required=True, choices=["svg", "pdf", "png", "jpeg", "jpg"])
    p_export.add_argument("--page", type=int, default=0)
    p_export.add_argument("--scale", type=float, default=1.0)
    p_export.add_argument("--out", default=None)
    p_export.set_defaults(func=_cmd_export)

    p_validate = sub.add_parser("validate", help="Run document diagnostics")
    p_validate.add_argument("path")
    p_validate.set_defaults(func=_cmd_validate)

    p_inspect = sub.add_parser("inspect", help="Print document statistics")
    p_inspect.add_argument("path")
    p_inspect.add_argument("--page", type=int, default=0)
    p_inspect.set_defaults(func=_cmd_inspect)

    p_serve = sub.add_parser("serve", help="Run the local Unix-socket engine service")
    p_serve.add_argument("--socket", default="/tmp/aardvark.sock")
    p_serve.set_defaults(func=_cmd_serve)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return args.func(args)
    except AardvarkError as exc:
        print(f"error: {exc.message}", file=sys.stderr)
        if exc.details:
            print(f"  details: {exc.details}", file=sys.stderr)
        return 1
    except FileNotFoundError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
