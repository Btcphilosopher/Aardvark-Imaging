import math

from aardvark.text.font import Font
from aardvark.text.layout import layout_text
from aardvark.text.text import Text


def test_font_measure_positive_for_nonempty_text():
    font = Font.system()
    width = font.measure("Hello", 24)
    assert width > 0


def test_font_measure_scales_with_size():
    font = Font.system()
    small = font.measure("Hello", 12)
    large = font.measure("Hello", 24)
    assert math.isclose(large, small * 2, rel_tol=0.05)


def test_glyph_path_nonempty_for_visible_char():
    font = Font.system()
    path, advance = font.glyph_path("A", 24)
    assert not path.is_empty()
    assert advance > 0


def test_glyph_path_empty_for_space():
    font = Font.system()
    path, advance = font.glyph_path(" ", 24)
    assert path.is_empty()
    assert advance > 0


def test_wrap_text_respects_box_width():
    font = Font.system()
    result = layout_text("one two three four five six seven", font, 14, box_width=100)
    assert len(result.lines) > 1
    for line in result.lines:
        assert line.width <= 100 + 1e-6


def test_single_line_no_wrap_without_box_width():
    font = Font.system()
    result = layout_text("A single line of text", font, 14)
    assert len(result.lines) == 1


def test_alignment_center_offsets_negative_half_width():
    font = Font.system()
    result = layout_text("Hi", font, 14, alignment="center")
    line = result.lines[0]
    assert math.isclose(line.x_offset, -line.width / 2, rel_tol=1e-6)


def test_text_object_to_path_matches_layout_width():
    text = Text(content="Hi", x=0, y=0, size=20)
    path = text.to_path()
    result = text.layout()
    assert path.bounds().max_x <= result.total_width + 1  # outlines fit within advance width
