import math

from aardvark.boolean.difference import difference
from aardvark.boolean.exclusion import exclusion
from aardvark.boolean.intersection import intersection
from aardvark.boolean.union import union
from aardvark.shapes.ellipse import Circle
from aardvark.shapes.rectangle import Rectangle


def _overlapping_shapes():
    rect = Rectangle(x=0, y=0, width=100, height=100).to_path()
    circle = Circle(cx=100, cy=50, radius=50).to_path()
    return rect, circle


def test_union_area_less_than_sum():
    rect, circle = _overlapping_shapes()
    result = union(rect, circle)
    # union must cover at least as much area as either input alone, and the
    # result's bounds must span both inputs.
    b = result.bounds()
    assert b.min_x <= 0 and b.max_x >= 100


def test_difference_removes_overlap():
    rect, circle = _overlapping_shapes()
    result = difference(rect, circle)
    b = result.bounds()
    # The right edge should be pulled back from 100 since the circle eats
    # into the rectangle's right side (circle centred at x=100 r=50).
    assert b.max_x <= 100


def test_intersection_is_the_overlap_region():
    rect, circle = _overlapping_shapes()
    result = intersection(rect, circle)
    b = result.bounds()
    assert b.min_x >= 0
    assert not result.is_empty()


def test_exclusion_is_xor():
    rect, circle = _overlapping_shapes()
    result = exclusion(rect, circle)
    # XOR of two overlapping shapes has a hole where they overlap, so it's
    # made of more than one ring.
    assert len(result.subpaths) >= 2


def test_disjoint_shapes_union_keeps_both_rings():
    rect = Rectangle(x=0, y=0, width=10, height=10).to_path()
    circle = Circle(cx=100, cy=100, radius=10).to_path()
    result = union(rect, circle)
    assert len(result.subpaths) == 2


def test_boolean_result_is_a_real_fillable_path():
    rect, circle = _overlapping_shapes()
    result = union(rect, circle)
    from aardvark.geometry.point import Point

    assert result.contains_point(Point(50, 50))  # well inside the rectangle
    assert result.contains_point(Point(100, 50))  # well inside the circle
    assert not result.contains_point(Point(-10, -10))
