import math

from aardvark.paths.offset import dash_polyline, offset_path, stroke_to_fill
from aardvark.paths.path import Path
from aardvark.geometry.point import Point


def _square(size=100.0) -> Path:
    p = Path()
    p.move_to(0, 0).line_to(size, 0).line_to(size, size).line_to(0, size).close()
    return p


def test_offset_grows_closed_shape():
    p = _square(100)
    grown = offset_path(p, 10)
    b = grown.bounds()
    assert b.min_x < 0 and b.max_x > 100
    assert math.isclose(b.width, 120, abs_tol=1.0)


def test_offset_shrinks_with_negative_delta():
    p = _square(100)
    shrunk = offset_path(p, -10)
    b = shrunk.bounds()
    assert b.min_x > 0 and b.max_x < 100


def test_stroke_to_fill_closed_produces_ribbon():
    p = _square(100)
    outline = stroke_to_fill(p, 10, join="miter")
    # A stroked closed square produces two nested rings (outer + inner).
    assert len(outline.subpaths) == 2


def test_stroke_to_fill_open_line():
    p = Path()
    p.move_to(0, 0).line_to(100, 0)
    outline = stroke_to_fill(p, 10, cap="round")
    b = outline.bounds()
    # round caps extend half the width beyond each end
    assert b.min_x < 0 and b.max_x > 100
    assert math.isclose(b.height, 10, abs_tol=1.0)


def test_dash_polyline_produces_expected_segment_count():
    points = [Point(0, 0), Point(100, 0)]
    dashes = dash_polyline(points, [10, 10])
    assert len(dashes) == 5  # 100 / 20 = 5 "on" dashes
