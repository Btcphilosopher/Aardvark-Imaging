import math

from aardvark.geometry.point import Point
from aardvark.paths.bezier import CubicBezier, QuadraticBezier


def test_cubic_evaluate_endpoints():
    c = CubicBezier(Point(0, 0), Point(10, 0), Point(20, 10), Point(30, 10))
    assert c.evaluate(0.0).is_close(Point(0, 0))
    assert c.evaluate(1.0).is_close(Point(30, 10))


def test_cubic_straight_line_length():
    # A "curve" whose control points lie on the straight line from p0 to p3
    # has arc length exactly equal to the chord length.
    c = CubicBezier(Point(0, 0), Point(10, 0), Point(20, 0), Point(30, 0))
    assert math.isclose(c.length(), 30.0, rel_tol=1e-9)


def test_cubic_split_matches_original_endpoints():
    c = CubicBezier(Point(0, 0), Point(0, 10), Point(10, 10), Point(10, 0))
    left, right = c.split(0.5)
    assert left.p0.is_close(c.p0)
    assert right.p3.is_close(c.p3)
    assert left.p3.is_close(right.p0)
    # The split point should equal evaluate(0.5) on the original curve.
    assert left.p3.is_close(c.evaluate(0.5), tolerance=1e-9)


def test_cubic_bounds_extrema():
    # A curve that bulges above its endpoints: bounds must include the bulge,
    # not just the two endpoints.
    c = CubicBezier(Point(0, 0), Point(0, 50), Point(50, 50), Point(50, 0))
    b = c.bounds()
    assert b.max_y > 0  # bulges below in y-down space... just assert > endpoints
    assert b.min_x <= 0 and b.max_x >= 50


def test_flatten_within_tolerance():
    c = CubicBezier(Point(0, 0), Point(0, 100), Point(100, 100), Point(100, 0))
    tol = 0.1
    points = c.flatten(tol)
    assert len(points) > 2
    # Every flattened point should lie on (or extremely close to) the curve.
    for p in points:
        # crude check: nearest-point search should find near-zero distance
        _, _, dist = c.nearest_point(p, samples=200)
        assert dist < 1.0


def test_nearest_point_on_line_like_curve():
    c = CubicBezier(Point(0, 0), Point(10, 0), Point(20, 0), Point(30, 0))
    t, point, dist = c.nearest_point(Point(15, 5))
    assert math.isclose(point.y, 0, abs_tol=1e-6)
    assert math.isclose(dist, 5.0, abs_tol=1e-3)


def test_quadratic_to_cubic_matches_evaluate():
    q = QuadraticBezier(Point(0, 0), Point(5, 10), Point(10, 0))
    c = q.to_cubic()
    for t in (0.0, 0.25, 0.5, 0.75, 1.0):
        assert q.evaluate(t).is_close(c.evaluate(t), tolerance=1e-9)
