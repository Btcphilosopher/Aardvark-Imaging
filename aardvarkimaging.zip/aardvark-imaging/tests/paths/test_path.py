import math

from aardvark.geometry.matrix import Matrix
from aardvark.geometry.point import Point
from aardvark.paths.path import NodeType, Path


def _square() -> Path:
    p = Path()
    p.move_to(0, 0).line_to(10, 0).line_to(10, 10).line_to(0, 10).close()
    return p


def test_builder_api_and_bounds():
    p = _square()
    b = p.bounds()
    assert (b.min_x, b.min_y, b.max_x, b.max_y) == (0, 0, 10, 10)


def test_contains_point():
    p = _square()
    assert p.contains_point(Point(5, 5)) is True
    assert p.contains_point(Point(50, 50)) is False


def test_transformed_path():
    p = _square()
    moved = p.transformed(Matrix.translation(100, 0))
    assert moved.bounds().min_x == 100


def test_reverse_preserves_geometry():
    p = _square()
    reversed_p = p.reverse()
    assert reversed_p.bounds() == p.bounds()
    # reversing twice returns to the original point order
    assert reversed_p.reverse().subpaths[0].anchors() == p.subpaths[0].anchors()


def test_add_node_preserves_shape():
    p = Path()
    p.move_to(0, 0).line_to(100, 0).close()
    before_len = p.length()
    p.add_node(0, 0, 0.5)
    assert p.get_node_count(0) == 3
    assert math.isclose(p.length(), before_len, rel_tol=1e-6)


def test_delete_node():
    p = Path()
    p.move_to(0, 0).line_to(10, 0).line_to(20, 0).close()
    p.delete_node(0, 1)
    assert p.get_node_count(0) == 2


def test_move_node_translates_anchor():
    p = Path()
    p.move_to(0, 0).line_to(10, 0).close()
    p.move_node(0, 0, 5, 5)
    assert p.subpaths[0].start == Point(5, 5)


def test_convert_node_symmetric_makes_collinear_handles():
    p = Path()
    p.move_to(0, 0)
    p.curve_to(0, -10, 20, -10, 20, 0)
    p.curve_to(40, 10, 40, 0, 40, 0)  # arbitrary continuation to have handle_out
    p.convert_node(0, 1, NodeType.SYMMETRIC)
    anchor = p.subpaths[0].anchors()[1]
    handle_in = p.subpaths[0].segments[0].control2
    handle_out = p.subpaths[0].segments[1].control1
    v1 = Point(handle_in.x - anchor.x, handle_in.y - anchor.y)
    v2 = Point(handle_out.x - anchor.x, handle_out.y - anchor.y)
    # symmetric handles point in exactly opposite directions with equal length
    assert math.isclose(v1.distance_to(Point(0, 0)), v2.distance_to(Point(0, 0)), rel_tol=1e-6)
    cross = v1.x * v2.y - v1.y * v2.x
    assert abs(cross) < 1e-6  # collinear


def test_join_and_break_subpaths():
    p = Path()
    p.move_to(0, 0).line_to(10, 0)
    p.move_to(20, 0).line_to(30, 0)
    p.join_subpaths(0, 1)
    assert len(p.subpaths) == 1
    assert p.subpaths[0].anchors()[-1] == Point(30, 0)


def test_break_closed_subpath_opens_it():
    p = _square()
    p.break_subpath(0, 2)
    assert p.subpaths[0].closed is False
