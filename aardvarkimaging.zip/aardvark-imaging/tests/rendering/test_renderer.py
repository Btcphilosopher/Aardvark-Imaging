import math

import numpy as np

from aardvark.document.document import Document
from aardvark.render.compositor import composite_over
from aardvark.render.raster import polygon_mask
from aardvark.render.renderer import RenderRequest, Renderer
from aardvark.style.color import Color


def test_polygon_mask_fills_interior_not_exterior():
    mask = polygon_mask(20, 20, [[(2, 2), (18, 2), (18, 18), (2, 18)]], "nonzero")
    assert mask[10, 10] == 1.0
    assert mask[0, 0] == 0.0


def test_polygon_mask_evenodd_hole():
    outer = [(0, 0), (20, 0), (20, 20), (0, 20)]
    inner = [(5, 5), (15, 5), (15, 15), (5, 15)]  # same winding as outer
    mask = polygon_mask(20, 20, [outer, inner], "evenodd")
    assert mask[2, 2] == 1.0  # between the rings: filled
    assert mask[10, 10] == 0.0  # inside the hole: not filled


def test_render_document_produces_expected_size():
    doc = Document(width=100, height=80)
    doc.rectangle(10, 10, 50, 40).fill("#ff0000")
    img = Renderer().render_document(doc, RenderRequest(scale=2.0))
    assert img.size == (200, 160)
    assert img.mode == "RGBA"


def test_render_pixel_color_matches_fill():
    doc = Document(width=100, height=100, title="t")
    doc.rectangle(0, 0, 100, 100).fill("#ff0000")
    img = Renderer().render_document(doc, RenderRequest(scale=1.0))
    r, g, b, a = img.getpixel((50, 50))
    assert (r, g, b, a) == (255, 0, 0, 255)


def test_transparent_background_default():
    doc = Document(width=10, height=10)
    doc.pages[0].background = None
    img = Renderer().render_document(doc, RenderRequest())
    assert img.getpixel((0, 0))[3] == 0


def test_composite_over_normal_is_alpha_blend():
    backdrop = np.zeros((1, 1, 4))
    backdrop[..., :] = [1, 0, 0, 1]  # opaque red
    source = np.zeros((1, 1, 4))
    source[..., :] = [0, 0, 1, 0.8]  # 80% opaque blue
    out = composite_over(backdrop, source, "normal", 1.0)
    # Porter-Duff source-over onto a fully opaque backdrop: result is a
    # straight (as, 1-as) lerp between source and backdrop colours.
    assert out[0, 0, 3] == 1.0
    assert math.isclose(out[0, 0, 2], 0.8, abs_tol=1e-9)  # blue channel <- source
    assert math.isclose(out[0, 0, 0], 0.2, abs_tol=1e-9)  # red channel <- backdrop residue
    assert out[0, 0, 2] > out[0, 0, 0]  # more blue than red now


def test_composite_multiply_darkens():
    backdrop = np.ones((1, 1, 4))
    source = np.ones((1, 1, 4)) * 0.5
    source[..., 3] = 1.0
    out = composite_over(backdrop, source, "multiply", 1.0)
    assert out[0, 0, 0] < 1.0
