"""SVG round-trip test (spec section 66): Aardvark document -> SVG -> Aardvark
importer -> Document, verifying geometry/styles are equivalent within tolerance.
"""

import math

from aardvark.document.document import Document
from aardvark.export.svg import export_svg
from aardvark.importers.svg import import_svg
from aardvark.document.scene import Group


def test_svg_export_import_preserves_shape_count_and_bounds():
    doc = Document(width=300, height=200)
    doc.pages[0].background = None  # isolate shape fidelity from the page-background rect
    doc.rectangle(10, 10, 80, 60, corner_radius=6).fill("#3366ff").stroke("#000000", 2)
    doc.circle(200, 100, 40).fill("#ff0000")
    doc.star(100, 150, 30, 12, points=5).fill("#ffcc00")

    svg_text = export_svg(doc)
    reimported = import_svg(svg_text)

    original_objects = [o for o in doc.all_objects() if not isinstance(o, Group)]
    reimported_objects = [o for o in reimported.all_objects() if not isinstance(o, Group)]
    assert len(original_objects) == len(reimported_objects)

    for orig, reimp in zip(original_objects, reimported_objects):
        # Compare *tight* geometric bounds (from the actual path), not
        # world_bounds().geometry — some shapes (Star) report a loose,
        # conservative bbox there rather than the tight polygon extent.
        b1 = orig.to_path().transformed(orig.world_matrix()).bounds()
        b2 = reimp.to_path().transformed(reimp.world_matrix()).bounds()
        assert math.isclose(b1.min_x, b2.min_x, abs_tol=0.5)
        assert math.isclose(b1.min_y, b2.min_y, abs_tol=0.5)
        assert math.isclose(b1.width, b2.width, abs_tol=0.5)
        assert math.isclose(b1.height, b2.height, abs_tol=0.5)


def test_svg_import_rejects_doctype():
    from aardvark.errors import AardvarkImportError
    import pytest

    malicious = '<?xml version="1.0"?><!DOCTYPE svg [<!ENTITY x "y">]><svg xmlns="http://www.w3.org/2000/svg"></svg>'
    with pytest.raises(AardvarkImportError):
        import_svg(malicious)


def test_svg_import_skips_external_image_without_fetching():
    svg_text = (
        '<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100">'
        '<image href="https://example.com/evil.png" x="0" y="0" width="10" height="10"/>'
        "</svg>"
    )
    doc = import_svg(svg_text)
    from aardvark.images.image import Image

    images = [o for o in doc.all_objects() if isinstance(o, Image)]
    assert images == []  # skipped, not fetched
