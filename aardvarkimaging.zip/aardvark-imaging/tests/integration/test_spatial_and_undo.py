from aardvark.document.document import Document
from aardvark.geometry.rect import Rect
from aardvark.history.command import BooleanOperation
from aardvark.history.undo import UndoStack
from aardvark.boolean.union import union
from aardvark.spatial.hit_test import build_spatial_index, rect_hit
from aardvark.spatial.index import RTree
from aardvark.geometry.bounds import Bounds


def test_rtree_handles_many_inserts_and_removals():
    tree: RTree[int] = RTree()
    for i in range(500):
        tree.insert(i, Bounds(i, i, i + 1, i + 1))
    assert len(tree) == 500
    for i in range(0, 500, 2):
        tree.remove(i)
    assert len(tree) == 250
    results = tree.query(Bounds(100, 100, 110, 110))
    assert all(r % 2 == 1 for r in results)


def test_marquee_selection_against_many_objects():
    doc = Document(width=1000, height=1000)
    for i in range(50):
        doc.rectangle(i * 15, i * 15, 10, 10)
    idx = build_spatial_index(doc.active_page)
    selected = rect_hit(doc.active_page, Rect(0, 0, 100, 100), index=idx)
    assert 0 < len(selected) < 50


def test_undo_stack_transaction_rollback_on_boolean_failure():
    doc = Document(width=200, height=200)
    rect = doc.rectangle(0, 0, 50, 50)
    stack = UndoStack()
    before = len(doc.active_layer.children)
    try:
        stack.do(BooleanOperation(doc.active_layer, [rect], union))  # needs >= 2 objects
    except Exception:
        pass
    assert len(doc.active_layer.children) == before


def test_undo_redo_history_labels():
    from aardvark.history.command import MoveObject

    doc = Document(width=100, height=100)
    rect = doc.rectangle(0, 0, 10, 10)
    stack = UndoStack()
    stack.do(MoveObject(rect, 5, 0))
    stack.do(MoveObject(rect, 0, 5))
    assert len(stack.history_labels()) == 2
    stack.undo()
    assert stack.can_redo
    stack.undo()
    assert not stack.can_undo
