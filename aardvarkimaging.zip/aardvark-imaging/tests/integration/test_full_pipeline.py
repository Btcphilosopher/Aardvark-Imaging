from aardvark.document.document import Document
from aardvark.engine import Engine
from aardvark.export.pdf import export_pdf
from aardvark.export.png import export_png
from aardvark.export.svg import export_svg
from aardvark.history.undo import UndoStack
from aardvark.history.command import AddObject, ChangeFill, MoveObject
from aardvark.shapes.rectangle import Rectangle
from aardvark.spatial.hit_test import build_spatial_index, point_hit
from aardvark.style import Fill
from aardvark.style.color import Color


def test_create_edit_undo_export_pipeline(tmp_path):
    doc = Document(width=300, height=200, title="Pipeline")
    stack = UndoStack()

    rect = Rectangle(x=10, y=10, width=80, height=60)
    stack.do(AddObject(doc.active_layer, rect))
    stack.do(ChangeFill(rect, Fill(Color.from_hex("#ff0000"))))
    stack.do(MoveObject(rect, 20, 0))

    assert rect.transform.matrix.e == 20
    stack.undo()
    assert rect.transform.matrix.e == 0

    idx = build_spatial_index(doc.active_page)
    hit = point_hit(doc.active_page, 30, 30, index=idx)
    assert hit is rect

    assert doc.is_valid()

    svg = export_svg(doc)
    assert "<svg" in svg and rect.id in svg

    pdf_path = tmp_path / "out.pdf"
    export_pdf(doc, str(pdf_path))
    assert pdf_path.exists() and pdf_path.stat().st_size > 0

    png_path = tmp_path / "out.png"
    export_png(doc, str(png_path), scale=2.0)
    from PIL import Image as PILImage

    with PILImage.open(png_path) as img:
        assert img.size == (600, 400)


def test_engine_end_to_end_matches_direct_api(tmp_path):
    engine = Engine()
    doc_id = engine.create_document(width=200, height=150, title="Engine E2E")["document_id"]
    obj_id = engine.add_object(doc_id, {"type": "circle", "cx": 100, "cy": 75, "radius": 40})["object_id"]
    engine.set_style(doc_id, obj_id, fill={"paint": {"type": "solid", "color": [0, 1, 0, 1]}})

    hit = engine.hit_test(doc_id, 100, 75)
    assert hit["object_id"] == obj_id

    render = engine.render(doc_id, scale=1.0)
    assert render["width"] == 200 and render["height"] == 150

    path = tmp_path / "engine.aardvark"
    engine.save_document(doc_id, str(path))
    assert path.exists()

    reopened = engine.open_document(str(path))
    assert reopened["status"] == "ok"
