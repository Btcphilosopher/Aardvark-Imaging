import math

from aardvark.geometry.bounds import Bounds
from aardvark.geometry.intersections import (
    line_line_intersection,
    point_in_polygon,
    point_segment_distance,
    polygon_area,
    winding_number,
)
from aardvark.geometry.point import Point


def test_circle_bounds_via_bezier():
    from aardvark.shapes.ellipse import Circle

    c = Circle(cx=50, cy=50, radius=25)
    b = c.local_bounds()
    assert b == Bounds(25, 25, 75, 75)


def test_bounds_union_and_intersection():
    a = Bounds(0, 0, 10, 10)
    b = Bounds(5, 5, 15, 15)
    u = a.union(b)
    assert u == Bounds(0, 0, 15, 15)
    i = a.intersection(b)
    assert i == Bounds(5, 5, 10, 10)


def test_bounds_empty_union_identity():
    a = Bounds.empty()
    b = Bounds(1, 1, 2, 2)
    assert a.union(b) == b


def test_line_line_intersection_crossing():
    p = line_line_intersection(Point(0, 0), Point(10, 10), Point(0, 10), Point(10, 0))
    assert p is not None
    assert math.isclose(p.x, 5) and math.isclose(p.y, 5)


def test_line_line_intersection_parallel():
    p = line_line_intersection(Point(0, 0), Point(10, 0), Point(0, 5), Point(10, 5))
    assert p is None


def test_point_in_polygon_square():
    square = [Point(0, 0), Point(10, 0), Point(10, 10), Point(0, 10)]
    assert point_in_polygon(Point(5, 5), square) is True
    assert point_in_polygon(Point(15, 5), square) is False


def test_point_segment_distance():
    d = point_segment_distance(Point(5, 5), Point(0, 0), Point(10, 0))
    assert math.isclose(d, 5.0)


def test_polygon_area_shoelace():
    square = [Point(0, 0), Point(10, 0), Point(10, 10), Point(0, 10)]
    assert math.isclose(abs(polygon_area(square)), 100.0)


def test_star_polygon_nonzero_winding_is_solid_center():
    # A 5-point star's centre has nonzero winding number (it's "inside"
    # under the nonzero fill rule even though the star is self-intersecting).
    import math as _m

    pts = []
    for i in range(10):
        r = 10 if i % 2 == 0 else 4
        a = -_m.pi / 2 + i * _m.pi / 5
        pts.append(Point(r * _m.cos(a), r * _m.sin(a)))
    assert winding_number(Point(0, 0), pts) != 0
