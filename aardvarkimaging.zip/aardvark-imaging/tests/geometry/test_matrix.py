import math

import pytest

from aardvark.errors import GeometryError
from aardvark.geometry.matrix import Matrix
from aardvark.geometry.rect import Rect


def test_identity_is_noop():
    m = Matrix.identity()
    assert m.apply_xy(3, 4) == (3.0, 4.0)
    assert m.is_identity()


def test_translation():
    m = Matrix.translation(10, -5)
    assert m.apply_xy(1, 1) == (11.0, -4.0)


def test_rotation_90_degrees():
    m = Matrix.rotation_degrees(90)
    x, y = m.apply_xy(1, 0)
    assert math.isclose(x, 0, abs_tol=1e-9)
    assert math.isclose(y, 1, abs_tol=1e-9)


def test_scaling():
    m = Matrix.scaling(2, 3)
    assert m.apply_xy(2, 2) == (4.0, 6.0)


def test_compose_order():
    # translate then scale: point (1,0) -> translate -> (2,0) -> scale x2 -> (4,0)
    m = Matrix.translation(1, 0).compose(Matrix.scaling(2, 1))
    assert m.apply_xy(1, 0) == (4.0, 0.0)


def test_inverse_round_trip():
    m = Matrix.rotation_degrees(37).compose(Matrix.translation(5, -3)).compose(Matrix.scaling(2, 0.5))
    inv = m.inverse()
    x, y = inv.apply_xy(*m.apply_xy(11, -7))
    assert math.isclose(x, 11, abs_tol=1e-6)
    assert math.isclose(y, -7, abs_tol=1e-6)


def test_singular_matrix_raises():
    m = Matrix(0, 0, 0, 0, 0, 0)
    with pytest.raises(GeometryError):
        m.inverse()


def test_rotated_rectangle_bounds():
    # A 10x10 square rotated 45 degrees around its center has bounds
    # width/height of 10*sqrt(2).
    rect = Rect(-5, -5, 10, 10)
    m = Matrix.rotation_degrees(45)
    b = rect.transformed_bounds(m)
    expected = 10 * math.sqrt(2)
    assert math.isclose(b.width, expected, rel_tol=1e-6)
    assert math.isclose(b.height, expected, rel_tol=1e-6)


def test_decompose_pure_translate_scale():
    # With no rotation, decompose's translate_x/y is unambiguous: it's just
    # the matrix's own e/f (its image of the origin).
    m = Matrix.scaling(2, 3).compose(Matrix.translation(5, 7))
    d = m.decompose()
    assert math.isclose(d["translate_x"], 5, abs_tol=1e-6)
    assert math.isclose(d["translate_y"], 7, abs_tol=1e-6)
    assert math.isclose(d["scale_x"], 2, abs_tol=1e-6)
    assert math.isclose(d["scale_y"], 3, abs_tol=1e-6)
