import json

import pytest

from aardvark.document.document import Document
from aardvark.errors import SerializationError
from aardvark.serialization.format import (
    autosave,
    autosave_path,
    discard_autosave,
    has_autosave,
    load_document,
    recover_from_autosave,
    save_document,
)


def _doc() -> Document:
    doc = Document(width=200, height=150, title="Format Test")
    doc.rectangle(0, 0, 50, 50).fill("#ff0000")
    return doc


def test_save_load_round_trip(tmp_path):
    path = tmp_path / "doc.aardvark"
    doc = _doc()
    save_document(doc, path)
    loaded = load_document(path)
    assert loaded.metadata.title == "Format Test"
    assert len(list(loaded.all_objects())) == len(list(doc.all_objects()))


def test_save_writes_format_and_engine_version(tmp_path):
    path = tmp_path / "doc.aardvark"
    save_document(_doc(), path)
    data = json.loads(path.read_text())
    assert "format_version" in data
    assert "engine_version" in data


def test_atomic_save_does_not_leave_temp_file(tmp_path):
    path = tmp_path / "doc.aardvark"
    save_document(_doc(), path)
    leftovers = list(tmp_path.glob("*.tmp"))
    assert leftovers == []


def test_load_invalid_json_raises(tmp_path):
    path = tmp_path / "bad.aardvark"
    path.write_text("{not valid json")
    with pytest.raises(SerializationError):
        load_document(path)


def test_autosave_does_not_touch_primary_file(tmp_path):
    path = tmp_path / "doc.aardvark"
    doc = _doc()
    save_document(doc, path)
    original_bytes = path.read_bytes()

    doc.rectangle(60, 60, 10, 10).fill("#00ff00")  # unsaved change
    autosave(doc, path)

    assert path.read_bytes() == original_bytes  # primary untouched
    assert has_autosave(path)
    recovered = recover_from_autosave(path)
    assert len(list(recovered.all_objects())) == len(list(doc.all_objects()))

    discard_autosave(path)
    assert not has_autosave(path)


def test_future_format_version_rejected(tmp_path):
    path = tmp_path / "future.aardvark"
    save_document(_doc(), path)
    data = json.loads(path.read_text())
    data["format_version"] = 999
    path.write_text(json.dumps(data))
    with pytest.raises(SerializationError):
        load_document(path)
