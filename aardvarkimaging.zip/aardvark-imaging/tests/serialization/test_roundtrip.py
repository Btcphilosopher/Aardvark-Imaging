import json

from aardvark.document.document import Document
from aardvark.document.serialization import document_from_dict, document_to_dict
from aardvark.geometry.point import Point
from aardvark.style import Color, GradientStop, LinearGradient, Shadow


def _rich_document() -> Document:
    doc = Document(width=400, height=300, title="Roundtrip")
    rect = doc.rectangle(10, 10, 100, 60, corner_radius=8).fill("#3366ff").stroke("#000000", 3)
    rect.style.shadows.append(Shadow(offset_x=2, offset_y=2, blur_radius=4, color=Color(0, 0, 0, 0.4)))
    circle = doc.circle(200, 100, 40)
    circle.style.fill.paint = LinearGradient(Point(160, 100), Point(240, 100), (GradientStop(0, Color.from_hex("#ff0000")), GradientStop(1, Color.from_hex("#0000ff"))))
    doc.text("Hello", x=10, y=150, size=24).fill("#111111")
    grp = doc.group([rect, circle])
    grp.style.opacity = 0.8
    sym = doc.define_symbol("dot", [doc.circle(0, 0, 5)])
    doc.instantiate_symbol(sym, x=300, y=250)
    doc.resolve_symbols()
    return doc


def test_document_to_dict_is_json_serialisable():
    doc = _rich_document()
    data = document_to_dict(doc)
    text = json.dumps(data)  # must not raise
    assert len(text) > 0


def test_roundtrip_preserves_object_ids_and_count():
    doc = _rich_document()
    data = json.loads(json.dumps(document_to_dict(doc)))
    doc2 = document_from_dict(data)
    ids1 = [o.id for o in doc.all_objects()]
    ids2 = [o.id for o in doc2.all_objects()]
    assert ids1 == ids2


def test_roundtrip_preserves_geometry():
    doc = _rich_document()
    data = json.loads(json.dumps(document_to_dict(doc)))
    doc2 = document_from_dict(data)
    for o1, o2 in zip(doc.all_objects(), doc2.all_objects()):
        b1, b2 = o1.local_bounds(), o2.local_bounds()
        assert (b1.min_x, b1.min_y, b1.max_x, b1.max_y) == (b2.min_x, b2.min_y, b2.max_x, b2.max_y)


def test_roundtrip_preserves_symbol_resolution():
    doc = _rich_document()
    data = json.loads(json.dumps(document_to_dict(doc)))
    doc2 = document_from_dict(data)
    assert len(doc2.symbols) == 1
    from aardvark.document.scene import SymbolInstance

    instances = [o for o in doc2.all_objects() if isinstance(o, SymbolInstance)]
    assert instances and instances[0].definition is not None


def test_roundtrip_preserves_gradient_stops():
    doc = _rich_document()
    data = json.loads(json.dumps(document_to_dict(doc)))
    doc2 = document_from_dict(data)
    from aardvark.shapes.ellipse import Circle

    circles = [o for o in doc2.all_objects() if isinstance(o, Circle)]
    gradient_circle = next(c for c in circles if not isinstance(c.style.fill.paint, type(None)) and hasattr(c.style.fill.paint, "stops"))
    assert len(gradient_circle.style.fill.paint.stops) == 2
