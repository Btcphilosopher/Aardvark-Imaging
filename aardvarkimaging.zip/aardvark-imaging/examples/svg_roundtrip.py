"""Import an SVG, tweak it with the Aardvark object model, and re-export it."""

from aardvark.export.svg import export_svg
from aardvark.importers.svg import import_svg

SOURCE_SVG = """
<svg xmlns="http://www.w3.org/2000/svg" width="240" height="160">
  <rect x="10" y="10" width="100" height="60" rx="8" fill="#3366ff" stroke="#000000" stroke-width="2"/>
  <circle cx="180" cy="80" r="50" fill="#ff0000" fill-opacity="0.7"/>
  <path d="M20,120 L60,120 L40,150 Z" fill="#00aa00"/>
</svg>
"""

doc = import_svg(SOURCE_SVG)
print(f"Imported {len(list(doc.all_objects()))} objects onto a {doc.active_page.width}x{doc.active_page.height} page")

# Recolour everything, using the fluent API on the imported objects.
for obj in doc.all_objects():
    if obj.style.fill.paint is not None and hasattr(obj.style.fill.paint, "r"):
        obj.style.fill.opacity = 1.0

with open("reexported.svg", "w") as f:
    f.write(export_svg(doc))
print("Wrote reexported.svg")
