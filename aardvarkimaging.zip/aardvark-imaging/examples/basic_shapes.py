"""The quick-start example from the spec (section 69) — the plain
object-construction API."""

from aardvark import Circle, Document, Rectangle

doc = Document(width=1200, height=800)

rect = Rectangle(x=100, y=100, width=400, height=200)
circle = Circle(cx=400, cy=300, radius=120)

doc.add(rect)
doc.add(circle)

doc.export_svg("example.svg")
doc.export_pdf("example.pdf")
doc.export_png("example.png")

print("Wrote example.svg, example.pdf, example.png")
