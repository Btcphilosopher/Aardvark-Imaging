"""Benchmark suite (spec section 68): object counts vs. time/memory for the
operations most likely to matter on large documents. Reports operation,
object count, elapsed time, and peak memory.

Usage::

    python benchmark.py                # default sizes: 1,000 / 10,000
    python benchmark.py --sizes 1000 10000 100000
    python benchmark.py --skip-boolean --skip-svg
"""

from __future__ import annotations

import argparse
import time
import tracemalloc
from contextlib import contextmanager

from aardvark.boolean.union import union
from aardvark.document.document import Document
from aardvark.export.svg import export_svg
from aardvark.importers.svg import import_svg
from aardvark.render.renderer import RenderRequest, Renderer
from aardvark.spatial.hit_test import build_spatial_index, point_hit


@contextmanager
def measure():
    tracemalloc.start()
    start = time.perf_counter()
    result = {}
    try:
        yield result
    finally:
        elapsed = time.perf_counter() - start
        _, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()
        result["elapsed_s"] = elapsed
        result["peak_mb"] = peak / (1024 * 1024)


def report(name: str, count: int, result: dict) -> None:
    print(f"{name:<28} n={count:<8,} time={result['elapsed_s']*1000:8.1f}ms  peak_mem={result['peak_mb']:7.2f}MB")


def build_document(n: int) -> Document:
    # A fixed, realistic canvas size (not scaled with n): benchmarking
    # object-count scaling and pixel-count scaling are different questions,
    # and conflating them by growing the canvas with n makes the render
    # numbers below meaningless (dominated by canvas area, not object count).
    doc = Document(width=1200, height=800, title=f"Benchmark {n}")
    cols = max(1, int(n ** 0.5))
    spacing = 1200.0 / max(cols, 1)
    size = max(1.0, spacing * 0.8)
    for i in range(n):
        x = (i % cols) * spacing
        y = (i // cols) * spacing
        doc.rectangle(x, y, size, size).fill("#3366ff" if i % 2 == 0 else "#ff6633")
    return doc


def bench_build(n: int) -> Document:
    with measure() as r:
        doc = build_document(n)
    report("build document", n, r)
    return doc


def bench_spatial_index(doc: Document, n: int) -> None:
    with measure() as r:
        idx = build_spatial_index(doc.active_page)
    report("build spatial index", n, r)

    with measure() as r:
        for _ in range(1000):
            point_hit(doc.active_page, 50, 50, index=idx)
    report("1000 point hit-tests", n, r)


def bench_render(doc: Document, n: int) -> None:
    with measure() as r:
        Renderer().render_document(doc, RenderRequest(scale=1.0))
    report("full-page render", n, r)


def bench_boolean(n: int) -> None:
    from aardvark.shapes.rectangle import Rectangle

    paths = [Rectangle(x=i * 0.5, y=0, width=10, height=10).to_path() for i in range(min(n, 500))]
    with measure() as r:
        result = paths[0]
        for p in paths[1:]:
            result = union(result, p)
    report("chained boolean union", len(paths), r)


def bench_svg(doc: Document, n: int) -> None:
    with measure() as r:
        svg_text = export_svg(doc)
    report("SVG export", n, r)

    with measure() as r:
        import_svg(svg_text)
    report("SVG import", n, r)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sizes", type=int, nargs="+", default=[1_000, 10_000])
    parser.add_argument("--skip-boolean", action="store_true")
    parser.add_argument("--skip-svg", action="store_true")
    args = parser.parse_args()

    for n in args.sizes:
        print(f"\n--- {n:,} objects ---")
        doc = bench_build(n)
        bench_spatial_index(doc, n)
        bench_render(doc, n)
        if not args.skip_svg:
            bench_svg(doc, n)
        if not args.skip_boolean:
            bench_boolean(n)


if __name__ == "__main__":
    main()
