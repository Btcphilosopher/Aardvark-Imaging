"""A richer showcase: gradients, strokes, shadows, groups, boolean ops,
symbols, clipping, and text-on-path — exported to SVG, PDF and PNG so you
can compare the three backends render identically."""

from aardvark import Document
from aardvark.boolean.difference import difference
from aardvark.document.scene import GenericPathObject
from aardvark.geometry.point import Point
from aardvark.paths.path import Path
from aardvark.style import Color, GradientStop, LinearGradient, RadialGradient, Shadow

doc = Document(width=800, height=600, title="Aardvark Showcase")

# A gradient-filled, drop-shadowed rounded rectangle.
card = doc.rectangle(40, 40, 300, 180, corner_radius=20)
card.style.fill.paint = LinearGradient(
    Point(40, 40), Point(340, 220),
    (GradientStop(0.0, Color.from_hex("#6a5acd")), GradientStop(1.0, Color.from_hex("#ff69b4"))),
)
card.style.shadows.append(Shadow(offset_x=8, offset_y=8, blur_radius=16, color=Color(0, 0, 0, 0.35)))

# A radial-gradient circle with a stroke.
sun = doc.circle(600, 130, 90)
sun.style.fill.paint = RadialGradient(
    Point(600, 130), 90, None,
    (GradientStop(0.0, Color.from_hex("#fff2a8")), GradientStop(1.0, Color.from_hex("#ff8c00"))),
)
sun.stroke("#a05a00", 3)

# Boolean difference: a rounded rectangle with a circular bite taken out.
# Compute the result from the two source shapes, then replace them with it.
plate = doc.rectangle(40, 260, 260, 140, corner_radius=12)
bite = doc.circle(300, 260, 60)
notched_path = difference(plate.to_path(), bite.to_path())
doc.remove(plate)
doc.remove(bite)
notch_obj = GenericPathObject(path_data=notched_path)
notch_obj.style.fill.paint = Color.from_hex("#2f9e44")
doc.add(notch_obj)

# A symbol instanced three times — editing `dot`'s definition would move all three.
dot_shape = doc.circle(0, 0, 10)
doc.remove(dot_shape)  # define_symbol takes ownership; it shouldn't also sit in the layer
dot = doc.define_symbol("dot", [dot_shape])
for cx in (450, 480, 510):
    inst = doc.instantiate_symbol(dot, x=cx, y=420)
    inst.style.fill.paint = Color.from_hex("#333333")

# A clipped group: text clipped to a circle.
group = doc.group([])
clip_circle = doc.circle(650, 420, 70)
doc.remove(clip_circle)  # only used for its geometry, not placed as its own object
group.clip_path = clip_circle.to_path()
label = doc.text("CLIP", x=590, y=430, size=48)
label.style.fill.paint = Color.from_hex("#1c7ed6")
doc.remove(label)
group.add(label)

# Text following a wavy path.
wave_path = Path()
wave_path.move_to(40, 560).curve_to(140, 500, 240, 620, 340, 560).curve_to(440, 500, 540, 620, 640, 560)
curved_text = doc.text("Aardvark follows the curve", size=20, path_ref=wave_path)
curved_text.style.fill.paint = Color.from_hex("#111111")

doc.export_svg("showcase.svg")
doc.export_pdf("showcase.pdf")
doc.export_png("showcase.png", scale=2.0)
print("Wrote showcase.svg, showcase.pdf, showcase.png")
