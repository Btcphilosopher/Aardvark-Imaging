"""The fluent "designer" API from the spec (section 70)."""

from aardvark import Document

canvas = Document(1200, 800)

canvas.rectangle(100, 100, 400, 200).fill("#111111")
canvas.circle(400, 300, 100).fill("#ffffff")
canvas.text("AARDVARK IMAGING", x=100, y=500, size=48).fill("#111111")

canvas.save("design.aardvark")
canvas.export_png("design.png", scale=2.0)

print("Wrote design.aardvark, design.png")
