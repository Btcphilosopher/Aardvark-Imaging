# Aardvark Imaging

A professional-grade vector graphics and rendering engine — the
computational graphics kernel intended to power a future macOS vector
graphics application. This repository is the **Python engine**: geometry,
typography, boolean operations, rendering, assets, and production export.
A future Kotlin macOS client is a *client* of this engine, not a dependency
of it — everything here works standalone, from a Python script or the
`aardvark` CLI, with no UI required.

```
                    AARDVARK IMAGING
                           │
             ┌─────────────┴─────────────┐
             │                           │
          KOTLIN (future)             PYTHON (this repo)
       macOS UI                  VECTOR ENGINE
             │                           │
       Canvas/UI                    Geometry
       Tools                       Rendering
       Inspector                   Typography
       Layers                      Boolean Ops
       Panels                      Paths
       Shortcuts                   Assets
       Animation                   Export
             │                           │
             └──────── LOCAL API ────────┘
```

## Design principle: vector first

A document stays editable as geometry + styles + transformations +
relationships until the moment it's actually rendered or exported. Nothing
is rasterised "early" to make an operation easier — boolean ops run on
polygon geometry (via the Clipper library), SVG/PDF export real Bezier
curves and native gradients/strokes, and text stays measurable/editable
right up until it's converted to outline paths for rendering or export.

## Install

```bash
pip install -e .
# or, for the dev/test toolchain too:
pip install -e ".[dev]"
```

Targets Python 3.11+ (developed and tested on 3.13).

## Quick start

```python
from aardvark import Document, Rectangle, Circle

doc = Document(width=1200, height=800)
doc.add(Rectangle(x=100, y=100, width=400, height=200))
doc.add(Circle(cx=400, cy=300, radius=120))

doc.export_svg("example.svg")
doc.export_pdf("example.pdf")
doc.export_png("example.png")
```

Or the fluent "designer" API:

```python
from aardvark import Document

canvas = Document(1200, 800)
canvas.rectangle(100, 100, 400, 200).fill("#111111")
canvas.circle(400, 300, 100).fill("#ffffff")
canvas.text("AARDVARK IMAGING", x=100, y=500, size=48)
canvas.save("design.aardvark")
```

See `examples/` for a richer showcase (gradients, shadows, boolean ops,
symbols, clipping, text-on-path), an SVG round-trip, and a benchmark script.

## CLI

```bash
aardvark new design.aardvark --width 1200 --height 800
aardvark render design.aardvark --out design.png --scale 2
aardvark export design.aardvark --format svg --out design.svg
aardvark validate design.aardvark
aardvark inspect design.aardvark
aardvark serve --socket /tmp/aardvark.sock   # local IPC service
```

## Architecture

```
aardvark/
├── engine.py, config.py, errors.py    # Engine facade, config, error hierarchy
├── document/    # Document, Page, Layer, scene graph, serialization
├── geometry/    # Point, Vector2, Matrix, Transform, Rect, Bounds, intersections
├── paths/       # Bezier math, compound Path model, flatten/simplify/offset/stroke-to-fill
├── shapes/      # Rectangle, Ellipse/Circle, Polygon, Star, Line
├── boolean/     # union/difference/intersection/exclusion (Clipper-backed)
├── style/       # Color, Fill, Stroke, Gradient, Pattern, Shadow, Style
├── text/        # Font (fontTools), shaping, layout, paragraphs, Text object
├── images/      # Image object, loader, crop, placement
├── assets/      # AssetManager (content-hash dedup), LRU decode cache, font inspection
├── render/      # scene -> draw-command flattening, CPU raster backend, compositor
├── effects/     # blur, shadow, glow, blend-mode/filter registry
├── export/      # SVG, PDF (ReportLab), PNG, JPEG, batch web-asset export
├── importers/   # SVG importer (curve-preserving, sandboxed), raster image import
├── history/     # Command pattern, UndoStack, atomic Transactions
├── spatial/     # R-tree index, hit testing, selection geometry, snapping
├── serialization/  # the native .aardvark format: versioning, migrations, atomic I/O
└── api/         # Unix-domain-socket JSON server wrapping Engine
```

Every subsystem's module docstring explains its own design tradeoffs in
more detail than fits here.

## What's real vs. what's an honest boundary

Per the engineering rule this codebase follows throughout: **no function
pretends to work when it doesn't.** Something either works correctly, or it
raises `aardvark.errors.CapabilityError` (or a more specific error) saying
exactly what's missing. A few things worth calling out explicitly:

- **Boolean ops and stroke-to-fill flatten curves** to polygons before
  calling into the Clipper library (the same approach production tools use
  under the hood). This is disclosed in the relevant docstrings, not hidden.
- **CMYK/Lab colour conversion** raises `CapabilityError` rather than
  guessing — a naive RGB→CMYK formula would silently produce wrong
  separations for print, which is worse than refusing.
- **HarfBuzz-quality text shaping** isn't wired up; `BasicShaper` does
  correct Latin-script advance-width shaping (no ligatures/complex-script
  reordering), and the `Shaper` protocol is the seam a real shaping engine
  plugs into later.
- **The PDF backend** doesn't apply blend modes (opacity is applied; PDF's
  `/BM` graphics state isn't wired up), rasterises drop/inner shadows (no
  vector blur primitive in PDF), and approximates pattern fills by
  rasterising just the pattern tile — the rest of the page stays vector.
  Documented in `aardvark/export/pdf.py`.
- **The renderer is a CPU rasteriser** (spec-compliant: "the first
  implementation may use a CPU renderer"). It's a real scanline
  rasteriser with correct nonzero/evenodd fill rules, not a
  Pillow-polygon shortcut — but it's pure Python per scanline, so very
  large full-canvas raster renders (hundreds of thousands of objects) are
  slow; see **Performance** below. SVG/PDF export don't hit this path at
  all (they walk the scene graph directly and emit vector primitives), so
  they stay fast regardless of object count.
- **Undo for group/ungroup/boolean ops is exact**, including atomic
  rollback: `history.Transaction` (and `BooleanOperation`) undo every
  already-applied sub-step if a later one raises, so a failed compound
  operation never leaves the document half-changed.

## Performance

Object-count scaling (fixed 1200x800 canvas, `examples/benchmark.py`):

| objects | build doc | spatial index build | 1,000 hit-tests | full-page render | SVG export | SVG import |
|--------:|----------:|---------------------:|------------------:|-------------------:|-----------:|-----------:|
| 1,000   | 53 ms     | 273 ms                | 215 ms             | 11.7 s              | 75 ms      | 152 ms     |
| 10,000  | 515 ms    | 3.8 s                 | 1.1 s              | 30.8 s              | 795 ms     | 1.7 s      |

Spatial indexing, hit-testing, and vector export (SVG/PDF) scale well and
stay fast even at 10,000 objects. **Full-page raster rendering is the
current bottleneck** — the scanline rasteriser runs its per-scanline loop in
pure Python, so it doesn't vectorise across many small objects the way the
rest of the engine does. This is a real, disclosed performance boundary
(spec section 57: "establish correct performance boundaries from the
beginning" — not "make everything fast before shipping anything"), not a
hidden one: for very large documents, prefer SVG/PDF export (fully vector,
unaffected by this) or render only the current viewport. A vectorised
scanline fill, or a GPU/Metal backend behind the same `Renderer` interface
(spec section 76), are the natural next steps and don't require changing
the document model.

## Testing

```bash
pytest                 # unit + integration tests (geometry, paths, boolean,
                        # rendering, text, serialization, SVG round-trip, ...)
python examples/benchmark.py --sizes 1000 10000
```

## License

MIT (see `LICENSE`). Bundles the DejaVu Sans font and depends on several
third-party libraries — see `THIRD_PARTY_LICENSES.md`.
