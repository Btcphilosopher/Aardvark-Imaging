//! Spatial distance and geometry primitives
pub use crate::numerics::spatial::*;
