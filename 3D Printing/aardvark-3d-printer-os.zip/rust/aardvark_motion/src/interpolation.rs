//! Numerical interpolation and input shaping (ZV, ZVD, MZV)

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub enum ShaperType {
    None,
    ZV,
    ZVD,
    MZV,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InputShaperConfig {
    pub shaper_type: ShaperType,
    pub resonance_freq_hz: f64,
    pub damping_ratio: f64,
}

impl Default for InputShaperConfig {
    fn default() -> Self {
        Self {
            shaper_type: ShaperType::MZV,
            resonance_freq_hz: 48.5,
            damping_ratio: 0.1,
        }
    }
}

pub struct InputShaper;

impl InputShaper {
    pub fn calculate_zv_impulses(freq: f64, zeta: f64) -> Vec<(f64, f64)> {
        let k = (-std::f64::consts::PI * zeta / (1.0 - zeta * zeta).sqrt()).exp();
        let dt = 0.5 / freq;
        let a1 = 1.0 / (1.0 + k);
        let a2 = k / (1.0 + k);
        vec![(0.0, a1), (dt, a2)]
    }

    pub fn calculate_zvd_impulses(freq: f64, zeta: f64) -> Vec<(f64, f64)> {
        let k = (-std::f64::consts::PI * zeta / (1.0 - zeta * zeta).sqrt()).exp();
        let dt = 0.5 / freq;
        let denom = (1.0 + k).powi(2);
        let a1 = 1.0 / denom;
        let a2 = 2.0 * k / denom;
        let a3 = (k * k) / denom;
        vec![(0.0, a1), (dt, a2), (2.0 * dt, a3)]
    }
}
