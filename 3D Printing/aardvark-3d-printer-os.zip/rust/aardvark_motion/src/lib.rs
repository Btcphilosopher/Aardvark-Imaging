//! AARDVARK MOTION — Deterministic Kinematics & Trajectory Engine
//! Core motion primitives, S-curve profiles, input shaping and collision detection.

pub mod kinematics;
pub mod trajectory;
pub mod motion;
pub mod interpolation;
pub mod acceleration;
pub mod jerk;
pub mod collision;
pub mod spatial;
pub mod buffers;
pub mod numerics;
pub mod ffi;

pub use kinematics::{CartesianKinematics, CoreXYKinematics, KinematicsTransform};
pub use trajectory::{Trajectory, TrajectorySegment, TrajectoryPoint, SCurvePlanner};
pub use motion::{MotionConstraints, Vector3D, AxisLimits};
pub use collision::BoundingBox3D;
