//! 3D Motion Primitives, Vectors and Constraints

use std::ops::{Add, Sub, Mul, Div};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Default, Serialize, Deserialize)]
pub struct Vector3D {
    pub x: f64,
    pub y: f64,
    pub z: f64,
}

impl Vector3D {
    pub const fn new(x: f64, y: f64, z: f64) -> Self {
        Self { x, y, z }
    }

    pub const fn zero() -> Self {
        Self { x: 0.0, y: 0.0, z: 0.0 }
    }

    #[inline]
    pub fn magnitude(&self) -> f64 {
        (self.x * self.x + self.y * self.y + self.z * self.z).sqrt()
    }

    #[inline]
    pub fn normalized(&self) -> Self {
        let mag = self.magnitude();
        if mag > 1e-9 {
            *self / mag
        } else {
            Self::zero()
        }
    }

    #[inline]
    pub fn dot(&self, other: &Self) -> f64 {
        self.x * other.x + self.y * other.y + self.z * other.z
    }
}

impl Add for Vector3D {
    type Output = Self;
    fn add(self, rhs: Self) -> Self {
        Self::new(self.x + rhs.x, self.y + rhs.y, self.z + rhs.z)
    }
}

impl Sub for Vector3D {
    type Output = Self;
    fn sub(self, rhs: Self) -> Self {
        Self::new(self.x - rhs.x, self.y - rhs.y, self.z - rhs.z)
    }
}

impl Mul<f64> for Vector3D {
    type Output = Self;
    fn mul(self, scalar: f64) -> Self {
        Self::new(self.x * scalar, self.y * scalar, self.z * scalar)
    }
}

impl Div<f64> for Vector3D {
    type Output = Self;
    fn div(self, scalar: f64) -> Self {
        Self::new(self.x / scalar, self.y / scalar, self.z / scalar)
    }
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct AxisLimits {
    pub min_pos: f64,
    pub max_pos: f64,
    pub max_velocity: f64,
    pub max_acceleration: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MotionConstraints {
    pub max_velocity: f64,
    pub max_acceleration: f64,
    pub max_jerk: f64,
    pub junction_deviation: f64,
    pub x_axis: AxisLimits,
    pub y_axis: AxisLimits,
    pub z_axis: AxisLimits,
    pub e_axis: AxisLimits,
}

impl Default for MotionConstraints {
    fn default() -> Self {
        Self {
            max_velocity: 300.0,
            max_acceleration: 5000.0,
            max_jerk: 15.0,
            junction_deviation: 0.05,
            x_axis: AxisLimits { min_pos: 0.0, max_pos: 300.0, max_velocity: 400.0, max_acceleration: 8000.0 },
            y_axis: AxisLimits { min_pos: 0.0, max_pos: 300.0, max_velocity: 400.0, max_acceleration: 8000.0 },
            z_axis: AxisLimits { min_pos: 0.0, max_pos: 350.0, max_velocity: 30.0, max_acceleration: 500.0 },
            e_axis: AxisLimits { min_pos: -1000.0, max_pos: 10000.0, max_velocity: 60.0, max_acceleration: 3000.0 },
        }
    }
}
