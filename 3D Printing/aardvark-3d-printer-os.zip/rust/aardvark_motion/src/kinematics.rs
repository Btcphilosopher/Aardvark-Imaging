//! Kinematics Transformations for Additive Manufacturing

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct MotorCoordinates {
    pub a: f64,
    pub b: f64,
    pub c: f64,
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct CartesianPoint {
    pub x: f64,
    pub y: f64,
    pub z: f64,
}

pub trait KinematicsTransform {
    fn forward_kinematics(&self, motors: MotorCoordinates) -> CartesianPoint;
    fn inverse_kinematics(&self, cartesian: CartesianPoint) -> MotorCoordinates;
}

/// Standard Orthogonal Cartesian System
#[derive(Debug, Clone, Default)]
pub struct CartesianKinematics;

impl KinematicsTransform for CartesianKinematics {
    #[inline]
    fn forward_kinematics(&self, motors: MotorCoordinates) -> CartesianPoint {
        CartesianPoint {
            x: motors.a,
            y: motors.b,
            z: motors.c,
        }
    }

    #[inline]
    fn inverse_kinematics(&self, cartesian: CartesianPoint) -> MotorCoordinates {
        MotorCoordinates {
            a: cartesian.x,
            b: cartesian.y,
            c: cartesian.z,
        }
    }
}

/// High-Performance Dual-Belt CoreXY System
/// Motor A = X + Y, Motor B = X - Y, Motor C = Z
#[derive(Debug, Clone, Default)]
pub struct CoreXYKinematics;

impl KinematicsTransform for CoreXYKinematics {
    #[inline]
    fn forward_kinematics(&self, motors: MotorCoordinates) -> CartesianPoint {
        CartesianPoint {
            x: 0.5 * (motors.a + motors.b),
            y: 0.5 * (motors.a - motors.b),
            z: motors.c,
        }
    }

    #[inline]
    fn inverse_kinematics(&self, cartesian: CartesianPoint) -> MotorCoordinates {
        MotorCoordinates {
            a: cartesian.x + cartesian.y,
            b: cartesian.x - cartesian.y,
            c: cartesian.z,
        }
    }
}

/// CoreXZ System
#[derive(Debug, Clone, Default)]
pub struct CoreXZKinematics;

impl KinematicsTransform for CoreXZKinematics {
    #[inline]
    fn forward_kinematics(&self, motors: MotorCoordinates) -> CartesianPoint {
        CartesianPoint {
            x: 0.5 * (motors.a + motors.c),
            y: motors.b,
            z: 0.5 * (motors.a - motors.c),
        }
    }

    #[inline]
    fn inverse_kinematics(&self, cartesian: CartesianPoint) -> MotorCoordinates {
        MotorCoordinates {
            a: cartesian.x + cartesian.z,
            b: cartesian.y,
            c: cartesian.x - cartesian.z,
        }
    }
}
