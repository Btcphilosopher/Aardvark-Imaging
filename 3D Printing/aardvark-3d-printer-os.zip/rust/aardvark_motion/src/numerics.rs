//! Motion profiles, jerk calculations, spatial geometry and numerics

pub mod acceleration {
    #[inline]
    pub fn trapezoid_time(distance: f64, v_max: f64, a_max: f64) -> (f64, f64, f64) {
        let t_acc = v_max / a_max;
        let d_acc = 0.5 * a_max * t_acc * t_acc;
        if 2.0 * d_acc >= distance {
            let actual_peak = (distance * a_max).sqrt();
            let actual_t_acc = actual_peak / a_max;
            (actual_t_acc, 0.0, actual_peak)
        } else {
            let d_cruise = distance - 2.0 * d_acc;
            let actual_t_cruise = d_cruise / v_max;
            (t_acc, actual_t_cruise, v_max)
        }
    }
}

pub mod jerk {
    #[inline]
    pub fn calculate_junction_velocity(v1: f64, v2: f64, angle_rad: f64, max_jerk: f64) -> f64 {
        let cos_theta = angle_rad.cos();
        let sin_half = ((1.0 - cos_theta) * 0.5).max(0.0).sqrt();
        if sin_half < 1e-6 {
            return v1.min(v2);
        }
        let junction_v = max_jerk / (2.0 * sin_half);
        junction_v.min(v1).min(v2)
    }
}

pub mod spatial {
    use crate::motion::Vector3D;

    pub fn point_to_segment_distance(p: &Vector3D, a: &Vector3D, b: &Vector3D) -> f64 {
        let ab = *b - *a;
        let ap = *p - *a;
        let ab_len_sq = ab.x * ab.x + ab.y * ab.y + ab.z * ab.z;
        if ab_len_sq < 1e-9 {
            return ap.magnitude();
        }
        let t = (ap.dot(&ab) / ab_len_sq).clamp(0.0, 1.0);
        let projection = *a + ab * t;
        (*p - projection).magnitude()
    }
}

pub mod numerics {
    pub fn clamp(val: f64, min: f64, max: f64) -> f64 {
        if val < min { min } else if val > max { max } else { val }
    }
}
