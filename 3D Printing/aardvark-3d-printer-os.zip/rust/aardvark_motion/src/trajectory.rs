//! Trajectory Generation and S-Curve Motion Profiler

use serde::{Deserialize, Serialize};
use crate::motion::{MotionConstraints, Vector3D};

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct TrajectoryPoint {
    pub timestamp_sec: f64,
    pub position: Vector3D,
    pub velocity: Vector3D,
    pub acceleration: Vector3D,
    pub jerk: Vector3D,
    pub extrusion_position: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TrajectorySegment {
    pub start_pos: Vector3D,
    pub target_pos: Vector3D,
    pub start_e: f64,
    pub target_e: f64,
    pub start_velocity: f64,
    pub target_velocity: f64,
    pub nominal_velocity: f64,
    pub acceleration: f64,
    pub duration_sec: f64,
    pub points: Vec<TrajectoryPoint>,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct Trajectory {
    pub segments: Vec<TrajectorySegment>,
    pub total_duration_sec: f64,
    pub total_extrusion_mm: f64,
}

pub struct SCurvePlanner;

impl SCurvePlanner {
    pub fn plan_linear_segment(
        start: Vector3D,
        target: Vector3D,
        start_e: f64,
        target_e: f64,
        constraints: &MotionConstraints,
        dt: f64,
    ) -> TrajectorySegment {
        let delta = target - start;
        let distance = delta.magnitude();
        let delta_e = target_e - start_e;

        if distance < 1e-7 {
            return TrajectorySegment {
                start_pos: start,
                target_pos: target,
                start_e,
                target_e,
                start_velocity: 0.0,
                target_velocity: 0.0,
                nominal_velocity: 0.0,
                acceleration: 0.0,
                duration_sec: 0.0,
                points: vec![],
            };
        }

        let direction = delta / distance;
        let v_max = constraints.max_velocity.min(500.0);
        let a_max = constraints.max_acceleration.min(10000.0);

        // Calculate symmetric trapezoid profile for sample generation
        let t_acc = v_max / a_max;
        let d_acc = 0.5 * a_max * t_acc * t_acc;

        let (duration, t_cruise, peak_v) = if 2.0 * d_acc >= distance {
            let actual_peak = (distance * a_max).sqrt();
            let actual_t_acc = actual_peak / a_max;
            (2.0 * actual_t_acc, 0.0, actual_peak)
        } else {
            let d_cruise = distance - 2.0 * d_acc;
            let actual_t_cruise = d_cruise / v_max;
            (2.0 * t_acc + actual_t_cruise, actual_t_cruise, v_max)
        };

        let num_steps = (duration / dt).ceil() as usize + 1;
        let mut points = Vec::with_capacity(num_steps);

        for i in 0..=num_steps {
            let t = (i as f64 * dt).min(duration);
            let (dist_t, vel_t, acc_t) = if t <= t_acc {
                (0.5 * a_max * t * t, a_max * t, a_max)
            } else if t <= t_acc + t_cruise {
                let dt_c = t - t_acc;
                (d_acc + peak_v * dt_c, peak_v, 0.0)
            } else {
                let dt_d = t - (t_acc + t_cruise);
                let dist_dec = peak_v * dt_d - 0.5 * a_max * dt_d * dt_d;
                let vel_dec = (peak_v - a_max * dt_d).max(0.0);
                (d_acc + peak_v * t_cruise + dist_dec, vel_dec, -a_max)
            };

            let fraction = (dist_t / distance).clamp(0.0, 1.0);
            let pos = start + direction * (fraction * distance);
            let e_pos = start_e + fraction * delta_e;

            points.push(TrajectoryPoint {
                timestamp_sec: t,
                position: pos,
                velocity: direction * vel_t,
                acceleration: direction * acc_t,
                jerk: Vector3D::zero(),
                extrusion_position: e_pos,
            });
        }

        TrajectorySegment {
            start_pos: start,
            target_pos: target,
            start_e,
            target_e,
            start_velocity: 0.0,
            target_velocity: 0.0,
            nominal_velocity: peak_v,
            acceleration: a_max,
            duration_sec: duration,
            points,
        }
    }
}
