//! Jerk and junction velocity calculations
pub use crate::numerics::jerk::*;
