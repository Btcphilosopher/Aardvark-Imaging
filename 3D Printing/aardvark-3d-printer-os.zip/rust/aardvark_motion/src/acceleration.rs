//! Acceleration calculations
pub use crate::numerics::acceleration::*;
