//! FFI Layer for Python and Embedded C/C++ Hal interfaces

use std::ffi::{CStr, CString};
use std::os::raw::c_char;
use crate::kinematics::{CartesianKinematics, CoreXYKinematics, KinematicsTransform, MotorCoordinates, CartesianPoint};
use crate::trajectory::SCurvePlanner;
use crate::motion::{MotionConstraints, Vector3D};

#[no_mangle]
pub extern "C" fn aardvark_corexy_forward(a: f64, b: f64, c: f64, out_x: *mut f64, out_y: *mut f64, out_z: *mut f64) {
    let k = CoreXYKinematics;
    let pt = k.forward_kinematics(MotorCoordinates { a, b, c });
    unsafe {
        if !out_x.is_null() { *out_x = pt.x; }
        if !out_y.is_null() { *out_y = pt.y; }
        if !out_z.is_null() { *out_z = pt.z; }
    }
}

#[no_mangle]
pub extern "C" fn aardvark_corexy_inverse(x: f64, y: f64, z: f64, out_a: *mut f64, out_b: *mut f64, out_c: *mut f64) {
    let k = CoreXYKinematics;
    let m = k.inverse_kinematics(CartesianPoint { x, y, z });
    unsafe {
        if !out_a.is_null() { *out_a = m.a; }
        if !out_b.is_null() { *out_b = m.b; }
        if !out_c.is_null() { *out_c = m.c; }
    }
}
