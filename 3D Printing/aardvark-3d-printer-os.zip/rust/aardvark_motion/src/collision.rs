//! Spatial Collision Detection and Bounding Box Verification

use serde::{Deserialize, Serialize};
use crate::motion::Vector3D;

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct BoundingBox3D {
    pub min_point: Vector3D,
    pub max_point: Vector3D,
}

impl BoundingBox3D {
    pub fn new(min: Vector3D, max: Vector3D) -> Self {
        Self { min_point: min, max_point: max }
    }

    #[inline]
    pub fn contains(&self, p: &Vector3D) -> bool {
        p.x >= self.min_point.x && p.x <= self.max_point.x &&
        p.y >= self.min_point.y && p.y <= self.max_point.y &&
        p.z >= self.min_point.z && p.z <= self.max_point.z
    }

    #[inline]
    pub fn intersects(&self, other: &Self) -> bool {
        self.min_point.x <= other.max_point.x && self.max_point.x >= other.min_point.x &&
        self.min_point.y <= other.max_point.y && self.max_point.y >= other.min_point.y &&
        self.min_point.z <= other.max_point.z && self.max_point.z >= other.min_point.z
    }
}
