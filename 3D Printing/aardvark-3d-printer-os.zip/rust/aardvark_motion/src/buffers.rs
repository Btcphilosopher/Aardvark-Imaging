//! Real-time ring buffers and FFI bindings for Python and C adapters

use std::collections::VecDeque;
use serde::{Deserialize, Serialize};
use crate::trajectory::TrajectoryPoint;

#[derive(Debug, Clone)]
pub struct RealTimeStepBuffer {
    capacity: usize,
    buffer: VecDeque<TrajectoryPoint>,
}

impl RealTimeStepBuffer {
    pub fn new(capacity: usize) -> Self {
        Self {
            capacity,
            buffer: VecDeque::with_capacity(capacity),
        }
    }

    #[inline]
    pub fn push(&mut self, point: TrajectoryPoint) -> bool {
        if self.buffer.len() < self.capacity {
            self.buffer.push_back(point);
            true
        } else {
            false
        }
    }

    #[inline]
    pub fn pop(&mut self) -> Option<TrajectoryPoint> {
        self.buffer.pop_front()
    }

    #[inline]
    pub fn len(&self) -> usize {
        self.buffer.len()
    }

    #[inline]
    pub fn is_empty(&self) -> bool {
        self.buffer.is_empty()
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FfiMotionPlanRequest {
    pub start_x: f64,
    pub start_y: f64,
    pub start_z: f64,
    pub start_e: f64,
    pub target_x: f64,
    pub target_y: f64,
    pub target_z: f64,
    pub target_e: f64,
    pub feedrate: f64,
}
