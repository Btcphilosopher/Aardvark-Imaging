import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild,
  effect,
  inject,
} from '@angular/core';
import * as THREE from 'three';
import { MachineEngineService } from '../../services/machine-engine.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-machine-3d-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="relative w-full h-full min-h-[420px] rounded-xl overflow-hidden bg-zinc-950 border border-zinc-800 shadow-inner flex flex-col">
      <!-- 3D WebGL Canvas Container -->
      <div #canvasContainer class="relative flex-1 w-full h-full cursor-grab active:cursor-grabbing"></div>

      <!-- Live Overlays & Controls -->
      <div class="absolute top-3 left-3 flex flex-wrap items-center gap-2 pointer-events-none">
        <div class="bg-zinc-900/90 backdrop-blur border border-zinc-700/60 rounded-lg px-3 py-1.5 shadow text-xs font-mono text-zinc-300 flex items-center gap-2">
          <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>X: <strong class="text-white">{{ engine.position().x.toFixed(1) }}</strong></span>
          <span class="text-zinc-600">|</span>
          <span>Y: <strong class="text-white">{{ engine.position().y.toFixed(1) }}</strong></span>
          <span class="text-zinc-600">|</span>
          <span>Z: <strong class="text-white">{{ engine.position().z.toFixed(1) }}</strong></span>
        </div>

        <div class="bg-zinc-900/90 backdrop-blur border border-zinc-700/60 rounded-lg px-3 py-1.5 shadow text-xs font-mono text-zinc-300 flex items-center gap-1.5">
          <mat-icon class="text-xs !text-amber-400 !w-3.5 !h-3.5 !leading-none">speed</mat-icon>
          <span>Feedrate: <strong class="text-amber-300">{{ engine.feedrate().toFixed(0) }} mm/s</strong></span>
        </div>

        @if (engine.simulatedDefect()) {
          <div class="bg-red-950/90 backdrop-blur border border-red-600 rounded-lg px-3 py-1.5 shadow text-xs font-mono text-red-300 flex items-center gap-1.5 animate-bounce">
            <mat-icon class="text-xs !text-red-400 !w-3.5 !h-3.5">warning</mat-icon>
            <span>DEFECT: {{ engine.simulatedDefect() }}</span>
          </div>
        }
      </div>

      <!-- View Presets / Camera Reset Buttons -->
      <div class="absolute top-3 right-3 flex items-center gap-1.5 bg-zinc-900/90 backdrop-blur border border-zinc-700/60 rounded-lg p-1 shadow">
        <button
          (click)="setCameraView('iso')"
          class="px-2.5 py-1 text-xs font-medium rounded hover:bg-zinc-800 text-zinc-300 hover:text-white transition"
          title="Isometric View"
        >
          ISO
        </button>
        <button
          (click)="setCameraView('top')"
          class="px-2.5 py-1 text-xs font-medium rounded hover:bg-zinc-800 text-zinc-300 hover:text-white transition"
          title="Top Down"
        >
          TOP
        </button>
        <button
          (click)="setCameraView('front')"
          class="px-2.5 py-1 text-xs font-medium rounded hover:bg-zinc-800 text-zinc-300 hover:text-white transition"
          title="Front View"
        >
          FRONT
        </button>
        <button
          (click)="resetToolpaths()"
          class="p-1 rounded hover:bg-zinc-800 text-zinc-400 hover:text-white transition ml-1"
          title="Clear 3D Toolpaths"
        >
          <mat-icon class="text-sm !w-4 !h-4">refresh</mat-icon>
        </button>
      </div>

      <!-- Bottom Machine Coordinates Bar -->
      <div class="bg-zinc-900/90 border-t border-zinc-800/80 px-4 py-2 flex items-center justify-between text-xs text-zinc-400 font-mono">
        <div class="flex items-center gap-3">
          <span>Kinematics: <span class="text-emerald-400 font-semibold">{{ engine.kinematics() }}</span></span>
          <span>Bed: <span class="text-zinc-200">300x300mm</span></span>
          <span>Layer Height: <span class="text-zinc-200">0.20mm</span></span>
        </div>
        <div>
          <span>Deposited Points: <span class="text-emerald-300">{{ engine.depositedPaths().length }}</span></span>
        </div>
      </div>
    </div>
  `,
})
export class Machine3dView implements OnInit, OnDestroy {
  @ViewChild('canvasContainer', { static: true }) containerRef!: ElementRef<HTMLDivElement>;
  readonly engine = inject(MachineEngineService);

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private toolheadMesh!: THREE.Group;
  private hotendGlowLight!: THREE.PointLight;
  private pathLineGroup!: THREE.Group;
  private animationFrameId: number | null = null;
  private isMouseDown = false;
  private mousePrevX = 0;
  private mousePrevY = 0;
  private cameraSpherical = { radius: 480, phi: Math.PI / 3.5, theta: Math.PI / 4 };

  constructor() {
    // Reactively update toolhead position in 3D scene
    effect(() => {
      const pos = this.engine.position();
      const hotend = this.engine.hotendZone();
      if (this.toolheadMesh) {
        // Center offset: Bed is 300x300, center at (0,0)
        this.toolheadMesh.position.x = pos.x - 150;
        this.toolheadMesh.position.z = pos.y - 150;
        this.toolheadMesh.position.y = pos.z;
      }
      if (this.hotendGlowLight) {
        const power = hotend.heaterPower;
        this.hotendGlowLight.intensity = power * 2.5;
      }
    });

    // Reactively update deposited lines
    effect(() => {
      const paths = this.engine.depositedPaths();
      if (this.pathLineGroup && paths.length > 0) {
        this.rebuildDepositedGeometry(paths);
      }
    });
  }

  ngOnInit() {
    this.initThree();
    this.setupMouseEvents();
    this.animate();
  }

  ngOnDestroy() {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  private initThree() {
    const width = this.containerRef.nativeElement.clientWidth || 600;
    const height = this.containerRef.nativeElement.clientHeight || 420;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x09090b);

    this.camera = new THREE.PerspectiveCamera(45, width / height, 1, 3000);
    this.updateCameraPosition();

    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.containerRef.nativeElement.appendChild(this.renderer.domElement);

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    this.scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight.position.set(200, 400, 200);
    this.scene.add(dirLight);

    // Heated Build Bed & Grid
    const bedGeo = new THREE.BoxGeometry(300, 8, 300);
    const bedMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.4,
      metalness: 0.8,
    });
    const bedMesh = new THREE.Mesh(bedGeo, bedMat);
    bedMesh.position.y = -4;
    this.scene.add(bedMesh);

    // Bed Grid
    const grid = new THREE.GridHelper(300, 30, 0x10b981, 0x334155);
    grid.position.y = 0.2;
    this.scene.add(grid);

    // Gantry Frame / Aluminum Extrusions
    this.createMachineChassis();

    // Toolhead Assembly
    this.toolheadMesh = new THREE.Group();
    const carriageGeo = new THREE.BoxGeometry(36, 24, 30);
    const carriageMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, metalness: 0.8 });
    const carriage = new THREE.Mesh(carriageGeo, carriageMat);
    this.toolheadMesh.add(carriage);

    // Brass Nozzle
    const nozzleGeo = new THREE.ConeGeometry(4, 12, 16);
    const nozzleMat = new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.9, roughness: 0.2 });
    const nozzle = new THREE.Mesh(nozzleGeo, nozzleMat);
    nozzle.rotation.x = Math.PI;
    nozzle.position.y = -12;
    this.toolheadMesh.add(nozzle);

    // Hotend Glow Light
    this.hotendGlowLight = new THREE.PointLight(0xf59e0b, 0, 80);
    this.hotendGlowLight.position.set(0, -12, 0);
    this.toolheadMesh.add(this.hotendGlowLight);

    // Toolhead position initial
    this.toolheadMesh.position.set(-150, 0, -150);
    this.scene.add(this.toolheadMesh);

    // Group for deposited layers
    this.pathLineGroup = new THREE.Group();
    this.scene.add(this.pathLineGroup);

    // Resize Observer
    const resizeObserver = new ResizeObserver(() => this.onResize());
    resizeObserver.observe(this.containerRef.nativeElement);
  }

  private createMachineChassis() {
    const chassis = new THREE.Group();
    const pillarMat = new THREE.MeshStandardMaterial({ color: 0x27272a, metalness: 0.7 });

    // 4 Corner Pillars
    const pillarGeo = new THREE.BoxGeometry(16, 380, 16);
    const corners = [
      [-160, 190, -160],
      [160, 190, -160],
      [-160, 190, 160],
      [160, 190, 160],
    ];

    corners.forEach(([x, y, z]) => {
      const p = new THREE.Mesh(pillarGeo, pillarMat);
      p.position.set(x, y, z);
      chassis.add(p);
    });

    // Top Rails
    const topRailX = new THREE.BoxGeometry(336, 16, 16);
    const top1 = new THREE.Mesh(topRailX, pillarMat);
    top1.position.set(0, 380, -160);
    const top2 = new THREE.Mesh(topRailX, pillarMat);
    top2.position.set(0, 380, 160);
    chassis.add(top1, top2);

    this.scene.add(chassis);
  }

  private rebuildDepositedGeometry(paths: { x: number; y: number; z: number; layer: number; isDefect?: boolean }[]) {
    // Clear old lines
    while (this.pathLineGroup.children.length > 0) {
      const obj = this.pathLineGroup.children[0];
      this.pathLineGroup.remove(obj);
    }

    if (paths.length < 2) return;

    const points: THREE.Vector3[] = [];
    const colors: number[] = [];

    paths.forEach((p) => {
      points.push(new THREE.Vector3(p.x - 150, p.z, p.y - 150));
      if (p.isDefect) {
        colors.push(1.0, 0.1, 0.1); // Red defect
      } else {
        colors.push(0.06, 0.72, 0.5); // Emerald deposition
      }
    });

    const geo = new THREE.BufferGeometry().setFromPoints(points);
    geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

    const mat = new THREE.LineBasicMaterial({
      vertexColors: true,
      linewidth: 3,
    });

    const line = new THREE.Line(geo, mat);
    this.pathLineGroup.add(line);
  }

  private onResize() {
    if (!this.containerRef || !this.renderer || !this.camera) return;
    const width = this.containerRef.nativeElement.clientWidth;
    const height = this.containerRef.nativeElement.clientHeight;
    if (width === 0 || height === 0) return;

    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  private setupMouseEvents() {
    const el = this.containerRef.nativeElement;

    el.addEventListener('mousedown', (e) => {
      this.isMouseDown = true;
      this.mousePrevX = e.clientX;
      this.mousePrevY = e.clientY;
    });

    window.addEventListener('mouseup', () => {
      this.isMouseDown = false;
    });

    window.addEventListener('mousemove', (e) => {
      if (!this.isMouseDown) return;
      const dx = e.clientX - this.mousePrevX;
      const dy = e.clientY - this.mousePrevY;
      this.mousePrevX = e.clientX;
      this.mousePrevY = e.clientY;

      this.cameraSpherical.theta -= dx * 0.008;
      this.cameraSpherical.phi = Math.max(0.1, Math.min(Math.PI / 2 - 0.05, this.cameraSpherical.phi - dy * 0.008));
      this.updateCameraPosition();
    });

    el.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.cameraSpherical.radius = Math.max(150, Math.min(1000, this.cameraSpherical.radius + e.deltaY * 0.5));
      this.updateCameraPosition();
    }, { passive: false });
  }

  setCameraView(type: 'iso' | 'top' | 'front') {
    if (type === 'iso') {
      this.cameraSpherical = { radius: 480, phi: Math.PI / 3.5, theta: Math.PI / 4 };
    } else if (type === 'top') {
      this.cameraSpherical = { radius: 420, phi: 0.05, theta: 0 };
    } else if (type === 'front') {
      this.cameraSpherical = { radius: 450, phi: Math.PI / 2.2, theta: 0 };
    }
    this.updateCameraPosition();
  }

  resetToolpaths() {
    this.engine.depositedPaths.set([]);
  }

  private updateCameraPosition() {
    const s = this.cameraSpherical;
    this.camera.position.x = s.radius * Math.sin(s.phi) * Math.sin(s.theta);
    this.camera.position.y = s.radius * Math.cos(s.phi);
    this.camera.position.z = s.radius * Math.sin(s.phi) * Math.cos(s.theta);
    this.camera.lookAt(0, 80, 0);
  }

  private animate = () => {
    this.animationFrameId = requestAnimationFrame(this.animate);
    this.renderer.render(this.scene, this.camera);
  };
}
