export enum MachineStateEnum {
  OFFLINE = 'OFFLINE',
  BOOTING = 'BOOTING',
  SELF_TEST = 'SELF_TEST',
  HOMING = 'HOMING',
  CALIBRATING = 'CALIBRATING',
  READY = 'READY',
  LOADING = 'LOADING',
  HEATING = 'HEATING',
  PREHEATING = 'PREHEATING',
  PRINTING = 'PRINTING',
  PAUSED = 'PAUSED',
  COOLING = 'COOLING',
  COMPLETING = 'COMPLETING',
  COMPLETE = 'COMPLETE',
  RECOVERING = 'RECOVERING',
  FAULT = 'FAULT',
  EMERGENCY_STOP = 'EMERGENCY_STOP',
  SHUTDOWN = 'SHUTDOWN',
}

export enum KinematicsEnum {
  CARTESIAN = 'CARTESIAN',
  COREXY = 'COREXY',
  COREXZ = 'COREXZ',
  DELTA = 'DELTA',
  SCARA = 'SCARA',
  HBOT = 'HBOT',
}

export enum QualityActionEnum {
  CONTINUE = 'CONTINUE',
  ADJUST = 'ADJUST',
  SLOW = 'SLOW',
  PAUSE = 'PAUSE',
  INSPECT = 'INSPECT',
  ABORT = 'ABORT',
}

export interface Vector3D {
  x: number;
  y: number;
  z: number;
}

export interface ThermalZoneData {
  name: string;
  targetTemp: number;
  measuredTemp: number;
  heaterPower: number; // 0.0 to 1.0
  kp: number;
  ki: number;
  kd: number;
  maxTemp: number;
  rateOfChange: number;
}

export interface QualityAssessmentData {
  geometryScore: number; // 0..1
  thermalScore: number;
  motionScore: number;
  extrusionScore: number;
  surfaceScore: number;
  overallConfidence: number;
  recommendedAction: QualityActionEnum;
  warnings: string[];
  detectedDefect: string | null;
  layerIndex: number;
  timestamp: number;
}

export interface MachineFault {
  id: string;
  severity: 'INFO' | 'WARNING' | 'ERROR' | 'CRITICAL';
  component: string;
  description: string;
  recommendedAction: string;
  timestamp: number;
  acknowledged: boolean;
  resolved: boolean;
}

export interface AuditRecord {
  id: string;
  timestamp: number;
  operator: string;
  role: 'VIEWER' | 'OPERATOR' | 'ENGINEER' | 'MAINTENANCE' | 'ADMIN';
  action: string;
  details: string;
  sha256Hash: string;
}

export interface MaterialProfileData {
  id: string;
  name: string;
  type: string;
  diameter: number;
  density: number;
  recommendedNozzleTemp: number;
  recommendedBedTemp: number;
  recommendedChamberTemp: number;
  maxTemp: number;
  costPerKg: number;
  colorHex: string;
}

export interface PrintJobData {
  id: string;
  name: string;
  layerCount: number;
  estimatedDurationSec: number;
  estimatedMaterialGrams: number;
  status: 'PENDING' | 'VALIDATED' | 'PRINTING' | 'PAUSED' | 'COMPLETED' | 'FAILED';
  gcodeLines: string[];
  designId: string;
  modelVersion: string;
}

export interface BedMeshCell {
  x: number;
  y: number;
  zError: number;
}

export interface TelemetryPoint {
  time: string;
  hotendTemp: number;
  hotendTarget: number;
  bedTemp: number;
  bedTarget: number;
  vibrationRms: number;
  powerWatts: number;
  flowRate: number;
}
