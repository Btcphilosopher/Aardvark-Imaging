import {
  ChangeDetectionStrategy,
  Component,
  inject,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { MachineEngineService } from './services/machine-engine.service';
import { Machine3dView } from './components/machine-3d-view/machine-3d-view';
import { MachineStateEnum, QualityActionEnum } from './models/machine.model';

@Component({
  selector: 'app-root',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, MatIconModule, Machine3dView],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  readonly engine = inject(MachineEngineService);

  // Navigation Tab Selector
  readonly activeTab = signal<
    'overview' | 'motion' | 'thermal' | 'vision' | 'calibration' | 'materials' | 'sensors' | 'jobs' | 'diagnostics' | 'audit'
  >('overview');

  // Jog increment selection (mm)
  readonly jogStep = signal<number>(10);

  // Acceptance Test Modal
  readonly showAcceptanceModal = signal<boolean>(false);

  // Emergency Stop Confirmation Modal
  readonly showEStopConfirm = signal<boolean>(false);

  // Helper State Enum Access
  readonly StateEnum = MachineStateEnum;
  readonly QualityAction = QualityActionEnum;

  selectTab(tab: 'overview' | 'motion' | 'thermal' | 'vision' | 'calibration' | 'materials' | 'sensors' | 'jobs' | 'diagnostics' | 'audit') {
    this.activeTab.set(tab);
  }

  setJogStep(step: number) {
    this.jogStep.set(step);
  }

  startAcceptanceTest() {
    this.showAcceptanceModal.set(true);
    this.engine.run25StepAcceptanceTest();
  }

  closeAcceptanceModal() {
    this.showAcceptanceModal.set(false);
  }

  confirmEmergencyStop() {
    this.showEStopConfirm.set(false);
    this.engine.triggerEmergencyStop('Manual Operator Touchscreen Emergency Stop');
  }

  formatTime(sec: number): string {
    const mins = Math.floor(sec / 60);
    const s = sec % 60;
    return `${mins}:${s < 10 ? '0' : ''}${s}`;
  }
}
