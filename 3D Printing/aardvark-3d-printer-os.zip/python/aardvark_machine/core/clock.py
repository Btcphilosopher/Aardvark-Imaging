"""
Deterministic Machine Clock and Scheduler
"""
import time

class MachineClock:
    def __init__(self, step_time_us: int = 100):
        self.step_time_us = step_time_us
        self.current_time_sec = 0.0
        self.total_ticks = 0

    def tick(self, dt_sec: float):
        self.current_time_sec += dt_sec
        self.total_ticks += 1

    def now(self) -> float:
        return self.current_time_sec

    def wall_clock_now(self) -> float:
        return time.time()
