"""
Canonical Machine State Model & Core Enumerations
"""
from enum import Enum
from typing import Dict, List, Optional, Any
from pydantic import BaseModel, Field
import time

class MachineOperationalState(str, Enum):
    OFFLINE = "OFFLINE"
    BOOTING = "BOOTING"
    SELF_TEST = "SELF_TEST"
    HOMING = "HOMING"
    CALIBRATING = "CALIBRATING"
    READY = "READY"
    LOADING = "LOADING"
    HEATING = "HEATING"
    PREHEATING = "PREHEATING"
    PRINTING = "PRINTING"
    PAUSED = "PAUSED"
    COOLING = "COOLING"
    COMPLETING = "COMPLETING"
    COMPLETE = "COMPLETE"
    RECOVERING = "RECOVERING"
    FAULT = "FAULT"
    EMERGENCY_STOP = "EMERGENCY_STOP"
    SHUTDOWN = "SHUTDOWN"

class KinematicsType(str, Enum):
    CARTESIAN = "CARTESIAN"
    COREXY = "COREXY"
    COREXZ = "COREXZ"
    DELTA = "DELTA"
    SCARA = "SCARA"
    HBOT = "HBOT"

class QualityAction(str, Enum):
    CONTINUE = "CONTINUE"
    ADJUST = "ADJUST"
    SLOW = "SLOW"
    PAUSE = "PAUSE"
    INSPECT = "INSPECT"
    ABORT = "ABORT"

class Vector3(BaseModel):
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0

class ThermalZoneState(BaseModel):
    name: str
    target_temp: float = 0.0
    measured_temp: float = 22.0
    heater_power: float = 0.0  # 0.0 to 1.0
    rate_of_change: float = 0.0
    fault: bool = False

class AxisState(BaseModel):
    name: str
    position: float = 0.0
    homed: bool = False
    min_limit_triggered: bool = False
    max_limit_triggered: bool = False

class QualityAssessment(BaseModel):
    geometry_score: float = 1.0
    thermal_score: float = 1.0
    motion_score: float = 1.0
    extrusion_score: float = 1.0
    surface_score: float = 1.0
    overall_confidence: float = 1.0
    warnings: List[str] = Field(default_factory=list)
    recommended_action: QualityAction = QualityAction.CONTINUE
    detected_defect: Optional[str] = None
    layer_index: int = 0
    timestamp: float = Field(default_factory=time.time)

class MachineState(BaseModel):
    machine_id: str = "MCH-AARDVARK-PRO-01"
    timestamp: float = Field(default_factory=time.time)
    state: MachineOperationalState = MachineOperationalState.READY
    substate: str = "IDLE"
    position: Vector3 = Field(default_factory=Vector3)
    velocity: Vector3 = Field(default_factory=Vector3)
    acceleration: Vector3 = Field(default_factory=Vector3)
    axis_states: Dict[str, AxisState] = Field(default_factory=dict)
    extrusion_position: float = 0.0
    feedrate: float = 0.0
    flow_multiplier: float = 1.0
    feedrate_multiplier: float = 1.0
    thermal_zones: Dict[str, ThermalZoneState] = Field(default_factory=dict)
    fan_speed_pct: float = 0.0
    safety_interlocks_ok: bool = True
    active_job_id: Optional[str] = None
    current_layer: int = 0
    total_layers: int = 0
    progress_pct: float = 0.0
    quality_state: QualityAssessment = Field(default_factory=QualityAssessment)
    active_faults: List[str] = Field(default_factory=list)
    digital_twin_hash: str = "GEN-001"
