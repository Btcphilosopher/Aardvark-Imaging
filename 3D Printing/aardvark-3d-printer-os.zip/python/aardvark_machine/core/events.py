"""
Typed Event Bus & System Dispatcher
"""
import time
from typing import Callable, Dict, List, Any, Type
from pydantic import BaseModel, Field

class SystemEvent(BaseModel):
    event_id: str
    event_type: str
    timestamp: float = Field(default_factory=time.time)
    payload: Dict[str, Any] = Field(default_factory=dict)

class EventBus:
    def __init__(self):
        self._subscribers: Dict[str, List[Callable[[SystemEvent], None]]] = {}

    def subscribe(self, event_type: str, callback: Callable[[SystemEvent], None]):
        if event_type not in self._subscribers:
            self._subscribers[event_type] = []
        self._subscribers[event_type].append(callback)

    def publish(self, event: SystemEvent):
        handlers = self._subscribers.get(event.event_type, [])
        for handler in handlers:
            try:
                handler(event)
            except Exception as e:
                print(f"[EventBus Error] Error handling event {event.event_type}: {e}")

# Global singleton event bus
event_bus = EventBus()
