"""
Independent Safety Supervisor and Interlock Engine
"""
from typing import List, Optional
from pydantic import BaseModel
from aardvark_machine.core.state import MachineState, MachineOperationalState

class SafetyViolation(BaseModel):
    violation_type: str
    severity: str  # WARNING, FAULT, E_STOP
    message: str
    timestamp: float

class SafetySupervisor:
    def __init__(self, max_hotend_temp: float = 310.0, max_bed_temp: float = 125.0):
        self.max_hotend_temp = max_hotend_temp
        self.max_bed_temp = max_bed_temp
        self.emergency_stop_tripped = False
        self.interlocks_ok = True
        self.violations: List[SafetyViolation] = []

    def evaluate(self, state: MachineState) -> bool:
        """Evaluates hardware safety constraints independently."""
        if self.emergency_stop_tripped:
            state.state = MachineOperationalState.EMERGENCY_STOP
            state.safety_interlocks_ok = False
            return False

        # Check hotend thermal limits
        hotend = state.thermal_zones.get("hotend")
        if hotend:
            if hotend.measured_temp > self.max_hotend_temp:
                self.emergency_stop_tripped = True
                state.state = MachineOperationalState.EMERGENCY_STOP
                state.active_faults.append(f"CRITICAL: Hotend Over-temperature ({hotend.measured_temp:.1f}C)")
                return False

        # Check bed thermal limits
        bed = state.thermal_zones.get("bed")
        if bed:
            if bed.measured_temp > self.max_bed_temp:
                self.emergency_stop_tripped = True
                state.state = MachineOperationalState.EMERGENCY_STOP
                state.active_faults.append(f"CRITICAL: Bed Over-temperature ({bed.measured_temp:.1f}C)")
                return False

        return True

    def trigger_estop(self, reason: str = "Operator manual emergency stop"):
        self.emergency_stop_tripped = True
        self.interlocks_ok = False

    def reset_estop(self):
        self.emergency_stop_tripped = False
        self.interlocks_ok = True
