"""
Deterministic Virtual Printer and Complete Process Simulator
"""
import time
from typing import Optional, Dict
from aardvark_machine.core.state import (
    MachineState, MachineOperationalState, ThermalZoneState, Vector3, QualityAssessment, QualityAction
)
from aardvark_machine.machine.model import MachineConfiguration, MachineLimits
from aardvark_machine.thermal.controller import ThermalZone
from aardvark_machine.motion.planner import MotionPlanner
from aardvark_machine.safety.supervisor import SafetySupervisor
from aardvark_machine.quality.quality_engine import QualityEngine

class VirtualPrinter:
    def __init__(self, config: Optional[MachineConfiguration] = None):
        self.config = config or MachineConfiguration()
        self.state = MachineState(machine_id=self.config.machine_id)
        self.hotend_zone = ThermalZone("hotend", heat_capacity=35.0, thermal_loss_coeff=0.35, rated_power_watts=65.0)
        self.bed_zone = ThermalZone("bed", heat_capacity=180.0, thermal_loss_coeff=1.2, rated_power_watts=350.0)
        self.motion_planner = MotionPlanner(self.config.limits)
        self.safety = SafetySupervisor()
        self.quality = QualityEngine()
        self._init_state()

    def _init_state(self):
        self.state.thermal_zones = {
            "hotend": ThermalZoneState(name="hotend", target_temp=0.0, measured_temp=22.0),
            "bed": ThermalZoneState(name="bed", target_temp=0.0, measured_temp=22.0),
        }
        self.state.position = Vector3(x=0.0, y=0.0, z=0.0)
        self.state.state = MachineOperationalState.READY

    def home(self):
        self.state.state = MachineOperationalState.HOMING
        self.state.position = Vector3(x=0.0, y=0.0, z=0.0)
        self.state.state = MachineOperationalState.READY

    def set_temperatures(self, hotend: float, bed: float):
        self.hotend_zone.target_temp = hotend
        self.bed_zone.target_temp = bed
        self.state.thermal_zones["hotend"].target_temp = hotend
        self.state.thermal_zones["bed"].target_temp = bed

    def step_simulation(self, dt_sec: float = 0.1, defect: Optional[str] = None):
        # Thermodynamic integration
        h_temp = self.hotend_zone.step(dt_sec)
        b_temp = self.bed_zone.step(dt_sec)

        self.state.thermal_zones["hotend"].measured_temp = h_temp
        self.state.thermal_zones["hotend"].heater_power = self.hotend_zone.heater_power_fraction
        self.state.thermal_zones["bed"].measured_temp = b_temp
        self.state.thermal_zones["bed"].heater_power = self.bed_zone.heater_power_fraction

        # Safety evaluation
        self.safety.evaluate(self.state)

        # Quality evaluation
        if self.state.state == MachineOperationalState.PRINTING:
            assessment = self.quality.evaluate_layer(self.state, injected_defect=defect)
            self.state.quality_state = assessment

            if assessment.recommended_action == QualityAction.ADJUST:
                # Closed loop correction applied
                corr, msg = self.quality.compute_bounded_flow_correction(1.0, 0.82)
                self.state.flow_multiplier = 1.0 + corr
            elif assessment.recommended_action == QualityAction.SLOW:
                self.state.feedrate_multiplier = 0.70
            elif assessment.recommended_action == QualityAction.PAUSE:
                self.state.state = MachineOperationalState.PAUSED
