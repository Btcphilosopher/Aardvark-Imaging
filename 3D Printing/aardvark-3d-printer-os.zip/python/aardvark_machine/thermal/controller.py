"""
Thermal Controller with PID, Anti-Windup and Physics Modeling
"""
import time
from typing import Dict
from aardvark_machine.core.state import ThermalZoneState

class PIDController:
    def __init__(self, kp: float, ki: float, kd: float, out_min: float = 0.0, out_max: float = 1.0):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.out_min = out_min
        self.out_max = out_max
        self._integral = 0.0
        self._last_error = 0.0
        self._last_time = time.time()

    def compute(self, setpoint: float, measured: float, dt: float) -> float:
        error = setpoint - measured
        self._integral += error * dt
        # Anti-windup clamping
        integral_max = 1.0 / (self.ki + 1e-9)
        self._integral = max(-integral_max, min(integral_max, self._integral))

        derivative = (error - self._last_error) / (dt + 1e-9)
        self._last_error = error

        u = self.kp * error + self.ki * self._integral + self.kd * derivative
        return max(self.out_min, min(self.out_max, u))

class ThermalZone:
    def __init__(self, name: str, heat_capacity: float = 45.0, thermal_loss_coeff: float = 0.4, rated_power_watts: float = 65.0):
        self.name = name
        self.heat_capacity = heat_capacity
        self.loss_coeff = thermal_loss_coeff
        self.power_watts = rated_power_watts
        self.target_temp = 0.0
        self.current_temp = 22.0
        self.heater_power_fraction = 0.0
        self.pid = PIDController(kp=0.045, ki=0.002, kd=0.12)
        self.ambient_temp = 22.0

    def step(self, dt_sec: float) -> float:
        if self.target_temp > 0.0:
            self.heater_power_fraction = self.pid.compute(self.target_temp, self.current_temp, dt_sec)
        else:
            self.heater_power_fraction = 0.0

        p_in = self.heater_power_fraction * self.power_watts
        p_loss = self.loss_coeff * (self.current_temp - self.ambient_temp)
        dt_temp = ((p_in - p_loss) / self.heat_capacity) * dt_sec
        self.current_temp += dt_temp
        return self.current_temp
