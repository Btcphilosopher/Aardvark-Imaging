"""
AARDVARK 3D PRINTER OS
Software for Additive Manufacturing Machines
"""

__version__ = "1.0.0"
__author__ = "Aardvark Fabrication Systems"
