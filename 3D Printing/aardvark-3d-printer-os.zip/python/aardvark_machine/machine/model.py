"""
Physical Machine Object Model, Toolhead, and Configuration
"""
from typing import Dict, List, Optional
from pydantic import BaseModel, Field
from aardvark_machine.core.state import KinematicsType, Vector3

class AxisConfig(BaseModel):
    name: str
    min_limit_mm: float
    max_limit_mm: float
    max_velocity_mm_s: float
    max_accel_mm_s2: float
    steps_per_mm: float
    microstepping: int = 16

class ToolheadConfig(BaseModel):
    tool_id: str = "T0"
    nozzle_diameter_mm: float = 0.4
    filament_diameter_mm: float = 1.75
    max_temp_c: float = 300.0
    has_part_fan: bool = True
    has_probe: bool = True
    has_camera: bool = True

class BedConfig(BaseModel):
    size_x_mm: float = 300.0
    size_y_mm: float = 300.0
    max_temp_c: float = 120.0
    heated: bool = True

class MachineLimits(BaseModel):
    max_velocity: float = 500.0
    max_acceleration: float = 10000.0
    max_jerk: float = 25.0
    max_extrusion_rate: float = 35.0  # mm3/s
    max_hotend_temp: float = 310.0
    min_hotend_temp: float = 0.0
    max_bed_temp: float = 125.0
    max_chamber_temp: float = 90.0

class MachineConfiguration(BaseModel):
    machine_id: str = "MCH-AARDVARK-PRO-01"
    name: str = "Aardvark Precision Fabricator Mk IV"
    kinematics: KinematicsType = KinematicsType.COREXY
    axes: Dict[str, AxisConfig] = Field(default_factory=dict)
    toolhead: ToolheadConfig = Field(default_factory=ToolheadConfig)
    bed: BedConfig = Field(default_factory=BedConfig)
    limits: MachineLimits = Field(default_factory=MachineLimits)
