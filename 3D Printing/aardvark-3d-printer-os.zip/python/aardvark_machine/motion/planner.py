"""
Real-time Motion Planner and S-Curve Profiler
"""
import math
from typing import List, Tuple
from pydantic import BaseModel
from aardvark_machine.core.state import Vector3
from aardvark_machine.machine.model import MachineLimits

class TrajectoryPoint(BaseModel):
    time_sec: float
    position: Vector3
    velocity: Vector3
    acceleration: Vector3
    extrusion_mm: float

class TrajectorySegment(BaseModel):
    start_pos: Vector3
    end_pos: Vector3
    start_e: float
    end_e: float
    peak_feedrate: float
    duration_sec: float
    points: List[TrajectoryPoint] = []

class MotionPlanner:
    def __init__(self, limits: MachineLimits):
        self.limits = limits

    def plan_segment(
        self,
        start: Vector3,
        target: Vector3,
        start_e: float,
        target_e: float,
        requested_feedrate: float,
        dt: float = 0.05
    ) -> TrajectorySegment:
        dx = target.x - start.x
        dy = target.y - start.y
        dz = target.z - start.z
        dist = math.sqrt(dx*dx + dy*dy + dz*dz)
        delta_e = target_e - start_e

        if dist < 1e-6:
            return TrajectorySegment(
                start_pos=start,
                end_pos=target,
                start_e=start_e,
                end_e=target_e,
                peak_feedrate=0.0,
                duration_sec=0.0,
                points=[]
            )

        v_max = min(requested_feedrate, self.limits.max_velocity)
        a_max = self.limits.max_acceleration

        # Trapezoidal / S-curve duration
        t_acc = v_max / a_max
        d_acc = 0.5 * a_max * t_acc * t_acc

        if 2.0 * d_acc >= dist:
            peak_v = math.sqrt(dist * a_max)
            t_acc = peak_v / a_max
            total_time = 2.0 * t_acc
            t_cruise = 0.0
        else:
            peak_v = v_max
            d_cruise = dist - 2.0 * d_acc
            t_cruise = d_cruise / peak_v
            total_time = 2.0 * t_acc + t_cruise

        points = []
        curr_t = 0.0
        dir_x, dir_y, dir_z = dx / dist, dy / dist, dz / dist

        while curr_t <= total_time + 1e-5:
            if curr_t <= t_acc:
                d = 0.5 * a_max * curr_t * curr_t
                v = a_max * curr_t
                a = a_max
            elif curr_t <= t_acc + t_cruise:
                dt_c = curr_t - t_acc
                d = d_acc + peak_v * dt_c
                v = peak_v
                a = 0.0
            else:
                dt_d = curr_t - (t_acc + t_cruise)
                d = d_acc + peak_v * t_cruise + (peak_v * dt_d - 0.5 * a_max * dt_d * dt_d)
                v = max(0.0, peak_v - a_max * dt_d)
                a = -a_max

            frac = min(1.0, max(0.0, d / dist))
            p_pos = Vector3(
                x=start.x + dir_x * d,
                y=start.y + dir_y * d,
                z=start.z + dir_z * d
            )
            p_vel = Vector3(x=dir_x * v, y=dir_y * v, z=dir_z * v)
            p_acc = Vector3(x=dir_x * a, y=dir_y * a, z=dir_z * a)
            e_val = start_e + frac * delta_e

            points.append(TrajectoryPoint(
                time_sec=curr_t,
                position=p_pos,
                velocity=p_vel,
                acceleration=p_acc,
                extrusion_mm=e_val
            ))
            curr_t += dt

        return TrajectorySegment(
            start_pos=start,
            end_pos=target,
            start_e=start_e,
            end_e=target_e,
            peak_feedrate=peak_v,
            duration_sec=total_time,
            points=points
        )
