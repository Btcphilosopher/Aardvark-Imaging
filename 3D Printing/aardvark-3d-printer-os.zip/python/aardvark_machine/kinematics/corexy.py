"""
Cartesian and CoreXY Kinematics Transformations
"""
from abc import ABC, abstractmethod
from typing import Tuple

class Kinematics(ABC):
    @abstractmethod
    def forward(self, a: float, b: float, c: float) -> Tuple[float, float, float]:
        """Convert motor steps/positions to Cartesian (X, Y, Z)"""
        pass

    @abstractmethod
    def inverse(self, x: float, y: float, z: float) -> Tuple[float, float, float]:
        """Convert Cartesian (X, Y, Z) to motor positions (A, B, C)"""
        pass

class CartesianKinematics(Kinematics):
    def forward(self, a: float, b: float, c: float) -> Tuple[float, float, float]:
        return (a, b, c)

    def inverse(self, x: float, y: float, z: float) -> Tuple[float, float, float]:
        return (x, y, z)

class CoreXYKinematics(Kinematics):
    def forward(self, a: float, b: float, c: float) -> Tuple[float, float, float]:
        x = 0.5 * (a + b)
        y = 0.5 * (a - b)
        z = c
        return (x, y, z)

    def inverse(self, x: float, y: float, z: float) -> Tuple[float, float, float]:
        a = x + y
        b = x - y
        c = z
        return (a, b, c)
