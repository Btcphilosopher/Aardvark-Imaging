plugins {
    kotlin("jvm") version "2.0.0"
    application
}

allprojects {
    repositories {
        mavenCentral()
        google()
    }
}

dependencies {
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.8.1")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.3")
    implementation("io.ktor:ktor-client-core:2.3.11")
    implementation("io.ktor:ktor-client-cio:2.3.11")
    implementation("io.ktor:ktor-client-content-negotiation:2.3.11")
    implementation("io.ktor:ktor-serialization-kotlinx-json:2.3.11")
    testImplementation(kotlin("test"))
}

application {
    mainClass.set("aardvark.machine.MainKt")
}

tasks.test {
    useJUnitPlatform()
}
