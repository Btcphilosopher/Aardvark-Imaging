-- AARDVARK 3D PRINTER OS - Schema 001
-- PostgreSQL DDL for additive manufacturing digital thread

CREATE TABLE IF NOT EXISTS machines (
    machine_id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(128) NOT NULL,
    serial_number VARCHAR(128) UNIQUE NOT NULL,
    kinematics_type VARCHAR(32) NOT NULL, -- CARTESIAN, COREXY, COREXZ, DELTA, SCARA
    build_volume_x DOUBLE PRECISION NOT NULL,
    build_volume_y DOUBLE PRECISION NOT NULL,
    build_volume_z DOUBLE PRECISION NOT NULL,
    max_velocity DOUBLE PRECISION NOT NULL,
    max_acceleration DOUBLE PRECISION NOT NULL,
    max_jerk DOUBLE PRECISION NOT NULL,
    firmware_version VARCHAR(32) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS machine_axes (
    axis_id SERIAL PRIMARY KEY,
    machine_id VARCHAR(64) REFERENCES machines(machine_id),
    axis_name VARCHAR(8) NOT NULL, -- X, Y, Z, E0, E1
    min_limit DOUBLE PRECISION NOT NULL,
    max_limit DOUBLE PRECISION NOT NULL,
    steps_per_mm DOUBLE PRECISION NOT NULL,
    microstepping INT NOT NULL DEFAULT 16,
    max_feedrate DOUBLE PRECISION NOT NULL,
    home_direction INT NOT NULL DEFAULT -1,
    homed BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS materials (
    material_id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(128) NOT NULL,
    polymer_type VARCHAR(64) NOT NULL, -- PLA, PETG, ABS, PEEK, TPU
    filament_diameter DOUBLE PRECISION NOT NULL DEFAULT 1.75,
    density DOUBLE PRECISION NOT NULL DEFAULT 1.24, -- g/cm3
    recommended_nozzle_temp DOUBLE PRECISION NOT NULL,
    recommended_bed_temp DOUBLE PRECISION NOT NULL,
    recommended_chamber_temp DOUBLE PRECISION NOT NULL DEFAULT 25.0,
    max_temp DOUBLE PRECISION NOT NULL,
    viscosity_index DOUBLE PRECISION DEFAULT 1.0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS jobs (
    job_id VARCHAR(64) PRIMARY KEY,
    machine_id VARCHAR(64) REFERENCES machines(machine_id),
    name VARCHAR(256) NOT NULL,
    description TEXT,
    gcode_content TEXT,
    layer_count INT NOT NULL,
    estimated_duration_sec DOUBLE PRECISION NOT NULL,
    estimated_material_grams DOUBLE PRECISION NOT NULL,
    status VARCHAR(32) NOT NULL, -- PENDING, VALIDATED, PRINTING, PAUSED, COMPLETED, FAILED, ABORTED
    design_id VARCHAR(64),
    model_version VARCHAR(32),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS print_attempts (
    attempt_id VARCHAR(64) PRIMARY KEY,
    job_id VARCHAR(64) REFERENCES jobs(job_id),
    machine_id VARCHAR(64) REFERENCES machines(machine_id),
    material_id VARCHAR(64) REFERENCES materials(material_id),
    start_time TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    end_time TIMESTAMPTZ,
    final_status VARCHAR(32) NOT NULL,
    total_energy_kwh DOUBLE PRECISION DEFAULT 0.0,
    total_material_grams DOUBLE PRECISION DEFAULT 0.0,
    average_quality_score DOUBLE PRECISION DEFAULT 1.0
);

CREATE TABLE IF NOT EXISTS print_checkpoints (
    checkpoint_id VARCHAR(64) PRIMARY KEY,
    attempt_id VARCHAR(64) REFERENCES print_attempts(attempt_id),
    layer_index INT NOT NULL,
    command_index INT NOT NULL,
    pos_x DOUBLE PRECISION NOT NULL,
    pos_y DOUBLE PRECISION NOT NULL,
    pos_z DOUBLE PRECISION NOT NULL,
    pos_e DOUBLE PRECISION NOT NULL,
    hotend_temp DOUBLE PRECISION NOT NULL,
    bed_temp DOUBLE PRECISION NOT NULL,
    chamber_temp DOUBLE PRECISION NOT NULL,
    fan_speed INT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS telemetry (
    telemetry_id BIGSERIAL PRIMARY KEY,
    machine_id VARCHAR(64) REFERENCES machines(machine_id),
    attempt_id VARCHAR(64),
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    pos_x DOUBLE PRECISION NOT NULL,
    pos_y DOUBLE PRECISION NOT NULL,
    pos_z DOUBLE PRECISION NOT NULL,
    hotend_temp DOUBLE PRECISION NOT NULL,
    hotend_target DOUBLE PRECISION NOT NULL,
    bed_temp DOUBLE PRECISION NOT NULL,
    bed_target DOUBLE PRECISION NOT NULL,
    extrusion_rate DOUBLE PRECISION NOT NULL,
    vibration_rms DOUBLE PRECISION NOT NULL,
    energy_power_watts DOUBLE PRECISION NOT NULL
);
