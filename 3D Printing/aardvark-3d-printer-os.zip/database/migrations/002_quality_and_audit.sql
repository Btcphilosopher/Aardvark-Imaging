-- AARDVARK 3D PRINTER OS - Schema 002
-- Quality Assessments, Faults, Maintenance and Append-Only Audit Log

CREATE TABLE IF NOT EXISTS quality_assessments (
    assessment_id VARCHAR(64) PRIMARY KEY,
    attempt_id VARCHAR(64) REFERENCES print_attempts(attempt_id),
    layer_index INT NOT NULL,
    geometry_score DOUBLE PRECISION NOT NULL,
    thermal_score DOUBLE PRECISION NOT NULL,
    motion_score DOUBLE PRECISION NOT NULL,
    extrusion_score DOUBLE PRECISION NOT NULL,
    surface_score DOUBLE PRECISION NOT NULL,
    overall_confidence DOUBLE PRECISION NOT NULL,
    recommended_action VARCHAR(32) NOT NULL, -- CONTINUE, ADJUST, SLOW, PAUSE, INSPECT, ABORT
    warnings TEXT[],
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS faults (
    fault_id VARCHAR(64) PRIMARY KEY,
    machine_id VARCHAR(64) REFERENCES machines(machine_id),
    severity VARCHAR(16) NOT NULL, -- INFO, WARNING, ERROR, CRITICAL
    component VARCHAR(64) NOT NULL, -- MOTION, HEATER, SENSOR, SAFETY, EXTRUSION
    description TEXT NOT NULL,
    diagnostic_data JSONB,
    recommended_action TEXT,
    acknowledged BOOLEAN DEFAULT FALSE,
    resolved BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    resolved_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS audit_events (
    audit_id BIGSERIAL PRIMARY KEY,
    machine_id VARCHAR(64) NOT NULL,
    operator_id VARCHAR(64) NOT NULL,
    operator_role VARCHAR(32) NOT NULL,
    action_type VARCHAR(64) NOT NULL, -- JOB_START, E_STOP, THERMAL_SET, CALIBRATION, OVERRIDE
    payload JSONB,
    hash_signature VARCHAR(128) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS maintenance_events (
    event_id VARCHAR(64) PRIMARY KEY,
    machine_id VARCHAR(64) REFERENCES machines(machine_id),
    component VARCHAR(64) NOT NULL,
    hours_logged DOUBLE PRECISION NOT NULL,
    status VARCHAR(32) NOT NULL, -- PENDING, COMPLETED, OVERDUE
    action_description TEXT NOT NULL,
    due_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ
);
