-- AARDVARK 3D PRINTER OS - Seed Data

INSERT INTO machines (
    machine_id, name, serial_number, kinematics_type,
    build_volume_x, build_volume_y, build_volume_z,
    max_velocity, max_acceleration, max_jerk, firmware_version
) VALUES (
    'MCH-AARDVARK-PRO-01',
    'Aardvark Precision Fabricator Mk IV',
    'AVK-2026-X889021',
    'COREXY',
    300.0, 300.0, 350.0,
    500.0, 10000.0, 25.0,
    'v4.2.0-industrial'
) ON CONFLICT (machine_id) DO NOTHING;

INSERT INTO materials (
    material_id, name, polymer_type, filament_diameter, density,
    recommended_nozzle_temp, recommended_bed_temp, recommended_chamber_temp, max_temp
) VALUES 
('MAT-PLA-AERO-01', 'Aardvark Aero PLA+ High-Speed', 'PLA', 1.75, 1.24, 215.0, 60.0, 25.0, 240.0),
('MAT-PETG-IND-02', 'Aardvark Engineering PETG Carbon', 'PETG', 1.75, 1.27, 245.0, 80.0, 35.0, 275.0),
('MAT-PEEK-ULTRA-03', 'Aardvark Ultra PEEK High-Temp', 'PEEK', 1.75, 1.30, 410.0, 140.0, 90.0, 450.0)
ON CONFLICT (material_id) DO NOTHING;

INSERT INTO jobs (
    job_id, machine_id, name, description, layer_count,
    estimated_duration_sec, estimated_material_grams, status, design_id, model_version
) VALUES (
    'JOB-CALIB-001',
    'MCH-AARDVARK-PRO-01',
    'Aardvark Synthetic Calibration Specimen',
    'Deterministic ISO test coupon with step overhangs, micro-towers, and closed-loop vision inspection marks',
    120,
    720.0,
    18.4,
    'VALIDATED',
    'DSN-SPECIMEN-2026',
    'v1.0'
) ON CONFLICT (job_id) DO NOTHING;
