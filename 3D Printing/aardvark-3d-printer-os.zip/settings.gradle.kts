rootProject.name = "aardvark-machine-ui"
include("app")
