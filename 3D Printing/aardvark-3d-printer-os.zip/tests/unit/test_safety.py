import pytest
from aardvark_machine.core.state import MachineState, ThermalZoneState, MachineOperationalState
from aardvark_machine.safety.supervisor import SafetySupervisor
from aardvark_machine.quality.quality_engine import QualityEngine, QualityAction

def test_safety_overtemp_interlock():
    safety = SafetySupervisor(max_hotend_temp=300.0)
    state = MachineState()
    state.thermal_zones["hotend"] = ThermalZoneState(name="hotend", measured_temp=315.0)
    
    assert safety.evaluate(state) is False
    assert state.state == MachineOperationalState.EMERGENCY_STOP

def test_quality_bounded_correction():
    engine = QualityEngine()
    corr, msg = engine.compute_bounded_flow_correction(1.0, 0.8)
    assert abs(corr) <= 0.15
