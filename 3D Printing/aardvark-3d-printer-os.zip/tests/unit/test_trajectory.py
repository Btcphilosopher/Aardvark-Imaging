import pytest
from aardvark_machine.core.state import Vector3
from aardvark_machine.machine.model import MachineLimits
from aardvark_machine.motion.planner import MotionPlanner

def test_motion_planner_velocity_limits():
    limits = MachineLimits(max_velocity=200.0, max_acceleration=3000.0)
    planner = MotionPlanner(limits)
    
    start = Vector3(x=0.0, y=0.0, z=0.0)
    target = Vector3(x=100.0, y=0.0, z=0.0)
    
    # Requesting 500 mm/s should be clamped to max_velocity 200 mm/s
    seg = planner.plan_segment(start, target, 0.0, 5.0, requested_feedrate=500.0)
    assert seg.peak_feedrate <= 200.0 + 1e-5
    assert seg.duration_sec > 0.5
    assert len(seg.points) > 0

def test_motion_planner_zero_distance():
    limits = MachineLimits()
    planner = MotionPlanner(limits)
    start = Vector3(x=50.0, y=50.0, z=10.0)
    seg = planner.plan_segment(start, start, 0.0, 0.0, requested_feedrate=100.0)
    assert seg.duration_sec == 0.0
