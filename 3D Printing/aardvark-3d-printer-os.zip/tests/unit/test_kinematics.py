import pytest
from aardvark_machine.kinematics.corexy import CoreXYKinematics, CartesianKinematics

def test_cartesian_kinematics():
    k = CartesianKinematics()
    assert k.forward(10.0, 20.0, 30.0) == (10.0, 20.0, 30.0)
    assert k.inverse(10.0, 20.0, 30.0) == (10.0, 20.0, 30.0)

def test_corexy_kinematics_roundtrip():
    k = CoreXYKinematics()
    # Target Cartesian (100.0, 50.0, 25.0)
    a, b, c = k.inverse(100.0, 50.0, 25.0)
    assert a == 150.0
    assert b == 50.0
    assert c == 25.0
    
    x, y, z = k.forward(a, b, c)
    assert x == 100.0
    assert y == 50.0
    assert z == 25.0

def test_corexy_diagonal_pure_x():
    k = CoreXYKinematics()
    # Moving along +X only: motor A and B move at equal positive speed
    a, b, c = k.inverse(50.0, 0.0, 0.0)
    assert a == 50.0
    assert b == 50.0
