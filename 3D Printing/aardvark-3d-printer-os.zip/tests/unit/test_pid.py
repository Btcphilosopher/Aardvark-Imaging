import pytest
from aardvark_machine.thermal.controller import PIDController, ThermalZone

def test_pid_convergence():
    pid = PIDController(kp=0.1, ki=0.01, kd=0.05)
    measured = 20.0
    setpoint = 200.0
    
    # Run loop
    for _ in range(100):
        power = pid.compute(setpoint, measured, dt=0.1)
        measured += power * 5.0 - (measured - 20.0) * 0.05
        
    assert measured > 150.0

def test_thermal_zone_physics():
    zone = ThermalZone("hotend", heat_capacity=20.0, thermal_loss_coeff=0.2, rated_power_watts=50.0)
    zone.target_temp = 210.0
    for _ in range(200):
        zone.step(0.1)
    assert zone.current_temp > 180.0
