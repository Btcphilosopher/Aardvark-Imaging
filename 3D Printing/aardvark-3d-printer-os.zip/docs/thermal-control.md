# Thermal Control & Thermal Safety

## 1. Thermodynamic Lumped Parameter Model

The thermal zones (Hotend, Heated Bed, Heated Chamber) are governed by the dynamic equation:
$$\frac{dT(t)}{dt} = \frac{P_{\text{heater}}(t) - P_{\text{loss}}(T, T_{\text{ambient}})}{C_{\text{thermal}}}$$
where:
- $C_{\text{thermal}}$ is the effective lumped heat capacity ($J/K$).
- $P_{\text{heater}}(t) = u(t) \cdot P_{\text{rated}}$ with $u(t) \in [0, 1]$.
- $P_{\text{loss}} = h_{\text{conv}} A (T - T_{\text{amb}}) + \epsilon \sigma A (T^4 - T_{\text{amb}}^4) + \dot{m}_{\text{filament}} c_p (T - T_{\text{amb}})$.

## 2. PID with Anti-Windup

$$u(t) = K_p e(t) + K_i \int_0^t e(\tau) d\tau + K_d \frac{de(t)}{dt}$$
Anti-windup clamps the integral accumulator when the actuator output saturates ($u(t) \ge 1.0$ or $u(t) \le 0.0$).

## 3. Independent Thermal Safety Interlocks

1. **Thermal Runaway**: If power applied $>80\%$ for $>15\text{s}$ and temperature rises $<1.5^\circ\text{C}$, trigger `THERMAL_RUNAWAY` emergency stop.
2. **Sensor Decoupling/Open Circuit**: If reading $< -20^\circ\text{C}$ or resistance $> 5\text{M}\Omega$, immediate heater shutdown.
3. **Over-Temperature Ceiling**: Hardware cutoff at $T_{\max} + 10^\circ\text{C}$.
4. **Thermal Watchdog**: Sensor readings older than $500\text{ms}$ trigger safety fault.
