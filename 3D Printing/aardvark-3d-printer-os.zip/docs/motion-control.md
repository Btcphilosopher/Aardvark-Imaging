# Motion Control & Kinematics Specification

## 1. Kinematics Transformations

### Cartesian Kinematics
$$\begin{bmatrix} X \\ Y \\ Z \end{bmatrix} = \begin{bmatrix} M_x \\ M_y \\ M_z \end{bmatrix}$$

### CoreXY Kinematics
Given two diagonal belt drive motors $A$ and $B$:
$$A = X + Y, \quad B = X - Y$$
Forward kinematics:
$$X = \frac{A + B}{2}, \quad Y = \frac{A - B}{2}, \quad Z = Z$$

## 2. Trajectory Profile Formulation (S-Curve & Jerk Limiting)

A standard trapezoidal profile suffers from infinite jerk at acceleration transitions, inducing severe machine vibration. Aardvark OS implements 7-phase S-curve trajectory planning:

1. **Phase 1**: Linear increase of acceleration ($\text{Jerk} = +J_{\max}$)
2. **Phase 2**: Constant acceleration ($a = a_{\max}, \text{Jerk} = 0$)
3. **Phase 3**: Decreasing acceleration ($\text{Jerk} = -J_{\max}$) to reach feedrate $v_{\text{cruise}}$
4. **Phase 4**: Constant cruise velocity ($a = 0, \text{Jerk} = 0$)
5. **Phase 5**: Increasing deceleration ($\text{Jerk} = -J_{\max}$)
6. **Phase 6**: Constant deceleration ($a = -a_{\max}, \text{Jerk} = 0$)
7. **Phase 7**: Decreasing deceleration ($\text{Jerk} = +J_{\max}$) to final target velocity.

## 3. Input Shaping Subsystem

Aardvark implements three standard analytic shapers:
- **Zero Vibration (ZV)**: 2 impulses
- **Zero Vibration and Derivative (ZVD)**: 3 impulses (more robust to frequency drift)
- **Modified Zero Vibration (MZV)**: optimized for finite jerk systems

Impulse times and amplitudes are parameterized by measured natural resonance frequency $f_n$ and damping ratio $\zeta$.
