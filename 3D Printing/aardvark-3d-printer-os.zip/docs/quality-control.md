# Quality Engine & Closed-Loop Control

## 1. Vision & Sensor Quality Fusion

The Quality Engine aggregates optical inspection (Aardvark Vision Pipeline), extrusion force, accelerometer vibration, and thermal stability.

$$Q_{\text{overall}} = w_g S_{\text{geom}} + w_t S_{\text{thermal}} + w_m S_{\text{motion}} + w_e S_{\text{extrusion}} + w_s S_{\text{surface}}$$

## 2. Bounded Closed-Loop Correction

When a deviation $\Delta e$ is detected:
$$\text{Correction} = \text{clamp}(K_p \cdot \Delta e, -C_{\max}, +C_{\max})$$

- **Feedrate scaling**: $[0.5, 1.25]$ of nominal planned speed.
- **Flow multiplier**: $[0.85, 1.15]$ of nominal volume.
- **Nozzle temperature adjust**: $[\pm 5^\circ\text{C}]$.

Corrections outside these bounds require immediate operator intervention or print pause.
