# Safety Supervisor & Fault Handling Specification

## Safety Architecture

The **Safety Supervisor** is an independent, non-preemptible module with supreme authority over machine motion, heating, and power delivery.

```mermaid
stateDiagram-v2
    [*] --> BOOTING
    BOOTING --> SELF_TEST
    SELF_TEST --> READY : Self-test OK
    SELF_TEST --> FAULT : Error detected
    READY --> HOMING : User / Script Home
    HOMING --> READY
    READY --> HEATING
    HEATING --> PRINTING
    PRINTING --> PAUSED : Pause / Filament Runout
    PAUSED --> PRINTING : Safe Resume
    PRINTING --> COMPLETING --> COMPLETE --> READY
    
    PRINTING --> FAULT : Violation / Warning
    PRINTING --> EMERGENCY_STOP : Critical Interlock
    HEATING --> EMERGENCY_STOP : Thermal Runaway
    FAULT --> RECOVERING
    RECOVERING --> READY
    EMERGENCY_STOP --> SHUTDOWN
```

### Safety Rules Matrix

| Fault ID | Detection Time | Action | Recovery Policy |
|---|---|---|---|
| `THERMAL_RUNAWAY` | < 15.0 s | Immediate Heater Cutoff + E-Stop | Cold Restart + Manual Service Required |
| `MOTION_LIMIT` | < 2.0 ms | Abort Motion Segment + Decel | Re-home Axes |
| `FILAMENT_RUNOUT` | < 100 ms | Controlled Retract + Park + Pause | Operator Load + Temperature Check |
| `DOOR_OPEN` | < 50 ms | Bounded Decel to 20% Speed / Pause | Close Chamber Door + Resume |
| `WATCHDOG_TIMEOUT` | < 250 ms | Hardware Trip | Hard Reset |
