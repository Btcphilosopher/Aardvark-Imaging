# AARDVARK 3D PRINTER OS — System Architecture

## 1. Architectural Philosophy

AARDVARK MACHINE OS treats an additive manufacturing machine not as a simple serial G-code interpreter, but as a **computational, cyber-physical dynamical system**. 

The fundamental control loop is formulated as:
```mermaid
graph LR
    A[Print Job] --> B[Toolpath IR]
    B --> C[Motion & Thermal Planner]
    C --> D[Trajectory Generation]
    D --> E[Real-Time Execution]
    E --> F[Sensor Acquisition]
    F --> G[State Estimation]
    G --> H[Quality Assessment]
    H -->|Bounded Correction| C
    H -->|Interlock Trigger| I[Safety Supervisor]
```

## 2. Nine-Layer System Hierarchy

```mermaid
graph TD
    subgraph NonRealTime [Non-Real-Time Layer - Python / Kotlin / UI / API]
        L8[Layer 8: Closed-Loop Control]
        L7[Layer 7: Quality Engine & Vision]
        L6[Layer 6: State Estimation & Kalman Filter]
        L5[Layer 5: Sensor Acquisition & Fusion]
        L4[Layer 4: Print Execution Pipeline]
        L3[Layer 3: Machine Model & Digital Twin]
    end

    subgraph RealTime [Deterministic Boundary - Rust / MCU Adapter]
        L2[Layer 2: Real-Time Machine Core & S-Curve Planner]
        L1[Layer 1: Hardware Abstraction Layer HAL]
        L0[Layer 0: Physical Hardware & Sensors]
    end

    L8 --> L4
    L7 --> L8
    L6 --> L7
    L5 --> L6
    L4 --> L3
    L3 --> L2
    L2 --> L1
    L1 --> L0
    L0 -.-> L5
```

## 3. Real-Time Separation Boundary

1. **Non-Real-Time Domain**:
   - Job scheduling, slicing inspection, database storage, telemetry logging, operator touchscreen UI, cloud analytics, and high-level closed-loop adaptation policies.
2. **Real-Time Deterministic Domain**:
   - High-frequency step generation, S-curve jerk-limited trajectory math, thermal runaway cutoffs, hardware endstop interrupts, hardware watchdog timers, and hardware emergency stop lines.
