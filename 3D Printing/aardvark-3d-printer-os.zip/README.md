# AARDVARK 3D PRINTER OS
## Software for Additive Manufacturing Machines

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Architecture: Industrial OS](https://img.shields.io/badge/Architecture-Deterministic%20Physical%20Control-emerald.svg)]()
[![Kinematics: Cartesian | CoreXY | Delta | SCARA](https://img.shields.io/badge/Kinematics-Multi--Axis-amber.svg)]()

**AARDVARK MACHINE OS** is a production-grade operating and control platform for industrial additive manufacturing machines. It is the machine-control foundation of the **Aardvark Imaging / Aardvark Fabrication** ecosystem.

Unlike traditional firmware that functions merely as a naive G-code interpreter with timer interrupts, Aardvark represents the 3D printer as a **computational physical system with closed-loop state estimation and vision feedback**.

```
JOB → TOOLPATH → MACHINE STATE → MOTION → MATERIAL DEPOSITION → SENSOR OBSERVATION → STATE ESTIMATION → QUALITY ASSESSMENT → BOUNDED CORRECTION → CONTINUED EXECUTION
```

---

## 1. Core Architecture Layers

| Layer | Subsystem | Description |
|---|---|---|
| **0** | **Hardware** | Steppers, Servos, Heaters, Thermistors, RTDs, Probes, Load Cells, Encoders, Cameras, Runout sensors |
| **1** | **Hardware Abstraction (HAL)** | Standardized driver interfaces (`MotorDriver`, `HeaterDriver`, `SensorDriver`, `CameraDevice`) |
| **2** | **Real-Time Machine Core** | Deterministic scheduler, Motion planner, Trajectory generator, Watchdog, Safety supervisor |
| **3** | **Machine Model** | Digital machine structure, Kinematics (Cartesian, CoreXY, etc.), Multi-zone thermals, Toolheads |
| **4** | **Print Execution** | G-code IR pipeline, Toolpaths, Layers, Retraction, Recovery checkpoints |
| **5** | **Sensing & Observation** | Multi-channel temperature, Vibration (FFT/accelerometer), Optical vision, Extrusion force |
| **6** | **State Estimation** | Kalman-filtered axis position, Thermal dissipation model, Filament melt state, Machine health |
| **7** | **Quality Engine** | Real-time dimensional deviation, Warping indicators, Stringing, Under/Over-extrusion detection |
| **8** | **Closed-Loop Control** | Bounded feed-rate/flow-rate/temperature auto-corrections under strict hardware interlock limits |

---

## 2. Directory Structure

```
aardvark-machine-os/
├── README.md                  # System overview and operational guide
├── LICENSE                    # MIT/Apache 2.0 Open Industry Specification
├── pyproject.toml             # Python machine orchestration package
├── Cargo.toml                 # Rust high-performance deterministic motion crate
├── build.gradle.kts           # Kotlin operator UI build definition
├── docker-compose.yml         # Containerized production stack
├── Makefile                   # Build & test automation targets
├── docs/                      # Architectural & engineering specifications
├── python/aardvark_machine/   # Core Python orchestration, physics & API
├── rust/aardvark_motion/      # Rust deterministic kinematics, S-Curve & collision
├── kotlin/app/                # Kotlin Touchscreen Machine Operator UI
├── database/                  # PostgreSQL schema, migrations & seed data
├── api/openapi.yaml           # REST & WebSocket API specification
├── simulation/                # Synthetic printer configs, materials & scenarios
├── tests/                     # Unit, integration, safety & property tests
└── scripts/                   # Acceptance testing & benchmark tools
```

---

## 3. Technology Stack

- **Rust (`aardvark_motion`)**: High-performance trajectory generation, S-curve/trapezoid math, jerk limits, spatial collision checks, input shaping algorithms (ZV, ZVD, MZV).
- **Python (`aardvark_machine`)**: Machine orchestration, digital twin synchronization, thermal modeling, material rheology, FastAPI service, G-code validation pipeline.
- **Kotlin (`aardvark.machine`)**: Industrial touchscreen operator interface (1080p/4K capacitive touch), diagnostic panels, calibration wizards.
- **PostgreSQL**: Complete digital thread, telemetry time-series, append-only audit trail, quality inspections, print history.
- **Angular / TypeScript / WebGL**: Interactive digital twin UI, 3D gantry visualization, live sensor monitoring, camera defect overlay.

---

## 4. Quick Start & Acceptance Test

Run the full end-to-end acceptance test reproducing the synthetic part manufacturing with intentional closed-loop defect detection and bounded correction:

```bash
# Run acceptance test pipeline
python3 scripts/run_acceptance_test.py

# Run motion & kinematics test suite
pytest tests/
```
