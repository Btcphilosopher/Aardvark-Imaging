"""
Computational Geometry: Point, Vector3D, Segment, BoundingBox, and 3D VoxelGrid.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, List, Tuple, Optional, Set
import math
from aardvark_print_twin.core.units import Units
from aardvark_print_twin.core.state import MaterialPhase

@dataclass
class Point3D:
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0

    def distance_to(self, other: 'Point3D') -> float:
        return math.sqrt((self.x - other.x)**2 + (self.y - other.y)**2 + (self.z - other.z)**2)

    def to_list(self) -> List[float]:
        return [self.x, self.y, self.z]


@dataclass
class Segment3D:
    start: Point3D
    end: Point3D
    width_m: float = Units.mm_to_m(0.4)
    height_m: float = Units.mm_to_m(0.2)
    layer_index: int = 0
    is_extrusion: bool = True

    @property
    def length(self) -> float:
        return self.start.distance_to(self.end)

    @property
    def approximate_volume_m3(self) -> float:
        if not self.is_extrusion:
            return 0.0
        # Rectangular cross-section with rounded edges or flat stadium: V = L * w * h
        return self.length * self.width_m * self.height_m


@dataclass
class VoxelCell:
    """Individual 3D spatial voxel cell tracking thermodynamic & material state."""
    ix: int
    iy: int
    iz: int
    material_state: MaterialPhase = MaterialPhase.EMPTY
    temperature_k: float = Units.c_to_k(22.0)
    deposition_time_s: float = 0.0
    layer_index: int = -1
    mass_kg: float = 0.0
    confidence: float = 1.0
    defect_severity: float = 0.0
    cooling_rate_k_s: float = 0.0
    max_temperature_k: float = Units.c_to_k(22.0)

    def activate(self, temp_k: float, timestamp_s: float, layer: int, mass_kg: float) -> None:
        self.material_state = MaterialPhase.HOT
        self.temperature_k = temp_k
        self.max_temperature_k = max(self.max_temperature_k, temp_k)
        self.deposition_time_s = timestamp_s
        self.layer_index = layer
        self.mass_kg = mass_kg


class VoxelGrid:
    """Adaptive 3D discrete voxel domain for thermal evolution & material deposition."""

    def __init__(
        self,
        resolution_m: float = Units.mm_to_m(0.5), # 0.5 mm voxel pitch
        origin_x: float = 0.0,
        origin_y: float = 0.0,
        origin_z: float = 0.0,
        size_x_m: float = Units.mm_to_m(220.0),
        size_y_m: float = Units.mm_to_m(220.0),
        size_z_m: float = Units.mm_to_m(250.0),
    ):
        self.resolution_m = resolution_m
        self.origin = Point3D(origin_x, origin_y, origin_z)
        self.nx = int(math.ceil(size_x_m / resolution_m))
        self.ny = int(math.ceil(size_y_m / resolution_m))
        self.nz = int(math.ceil(size_z_m / resolution_m))
        
        # Sparse dictionary of active voxels (key: (ix, iy, iz)) for maximum memory efficiency & speed
        self.active_voxels: Dict[Tuple[int, int, int], VoxelCell] = {}
        self.total_deposited_mass_kg: float = 0.0
        self.total_deposited_volume_m3: float = 0.0

    @property
    def voxel_count(self) -> int:
        return len(self.active_voxels)

    def world_to_grid(self, x: float, y: float, z: float) -> Tuple[int, int, int]:
        ix = int((x - self.origin.x) / self.resolution_m)
        iy = int((y - self.origin.y) / self.resolution_m)
        iz = int((z - self.origin.z) / self.resolution_m)
        return ix, iy, iz

    def grid_to_world(self, ix: int, iy: int, iz: int) -> Point3D:
        return Point3D(
            self.origin.x + (ix + 0.5) * self.resolution_m,
            self.origin.y + (iy + 0.5) * self.resolution_m,
            self.origin.z + (iz + 0.5) * self.resolution_m,
        )

    def deposit_segment(
        self,
        seg: Segment3D,
        deposition_temp_k: float,
        timestamp_s: float,
        density_kg_m3: float,
    ) -> List[Tuple[int, int, int]]:
        """Rasterize a line segment deposition into the 3D voxel grid (Bresenham 3D)."""
        if not seg.is_extrusion or seg.length <= 1e-7:
            return []

        p1 = seg.start
        p2 = seg.end
        length = seg.length
        steps = max(1, int(math.ceil(length / (self.resolution_m * 0.5))))
        
        voxel_vol = self.resolution_m ** 3
        cell_mass = density_kg_m3 * voxel_vol
        
        deposited_coords = []
        for step in range(steps + 1):
            t = step / float(steps)
            x = p1.x + t * (p2.x - p1.x)
            y = p1.y + t * (p2.y - p1.y)
            z = p1.z + t * (p2.z - p1.z)
            
            coord = self.world_to_grid(x, y, z)
            if coord not in self.active_voxels:
                cell = VoxelCell(
                    ix=coord[0],
                    iy=coord[1],
                    iz=coord[2],
                )
                cell.activate(deposition_temp_k, timestamp_s, seg.layer_index, cell_mass)
                self.active_voxels[coord] = cell
                self.total_deposited_mass_kg += cell_mass
                self.total_deposited_volume_m3 += voxel_vol
                deposited_coords.append(coord)
            else:
                # Re-heat existing voxel
                self.active_voxels[coord].temperature_k = deposition_temp_k
                self.active_voxels[coord].max_temperature_k = max(self.active_voxels[coord].max_temperature_k, deposition_temp_k)

        return deposited_coords

    def get_layer_voxels(self, layer_index: int) -> List[VoxelCell]:
        return [v for v in self.active_voxels.values() if v.layer_index == layer_index]

    def sample_temperature_at(self, x: float, y: float, z: float, ambient_k: float) -> float:
        coord = self.world_to_grid(x, y, z)
        if coord in self.active_voxels:
            return self.active_voxels[coord].temperature_k
        return ambient_k

    def get_bounding_box(self) -> Tuple[List[float], List[float]]:
        if not self.active_voxels:
            return [0, 0, 0], [0, 0, 0]
        xs = [self.grid_to_world(*c).x for c in self.active_voxels]
        ys = [self.grid_to_world(*c).y for c in self.active_voxels]
        zs = [self.grid_to_world(*c).z for c in self.active_voxels]
        return [min(xs), min(ys), min(zs)], [max(xs), max(ys), max(zs)]
