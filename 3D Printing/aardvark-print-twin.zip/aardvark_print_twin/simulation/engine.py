"""
Simulation Engine orchestrating G-Code execution, real-time stepping, ODE solving, and telemetry logging.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Callable
import time
from aardvark_print_twin.core.units import Units
from aardvark_print_twin.core.state import PrinterState, SimulationMode, DefectType
from aardvark_print_twin.digital_twin.twin import DigitalTwin, TwinTelemetrySample
from aardvark_print_twin.toolpath.parser import GCodeParser, ToolpathMove, ToolpathStatistics, ToolpathAnalyser

@dataclass
class SimulationResult:
    total_time_s: float
    total_moves_executed: int
    final_quality_score: float
    total_energy_wh: float
    deposited_mass_g: float
    total_voxels: int
    detected_defects: List[Dict[str, Any]]
    telemetry_samples: List[Dict[str, Any]]
    toolpath_stats: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_time_s": round(self.total_time_s, 2),
            "total_moves_executed": self.total_moves_executed,
            "final_quality_score": round(self.final_quality_score, 3),
            "total_energy_wh": round(self.total_energy_wh, 3),
            "deposited_mass_g": round(self.deposited_mass_g, 3),
            "total_voxels": self.total_voxels,
            "detected_defects_count": len(self.detected_defects),
            "detected_defects": self.detected_defects,
            "telemetry_samples_count": len(self.telemetry_samples),
            "toolpath_stats": self.toolpath_stats,
        }


class SimulationEngine:
    """Execution engine for driving the Digital Twin through synthetic AM workloads."""

    def __init__(
        self,
        twin: Optional[DigitalTwin] = None,
        dt_s: float = 0.05, # 50ms default simulation resolution
    ):
        self.twin = twin or DigitalTwin()
        self.dt_s = dt_s
        self.is_running = False
        self.is_paused = False
        self.progress_pct = 0.0

    def run_gcode(
        self,
        gcode_text: str,
        time_acceleration: float = 100.0, # 100x faster than real-time
        on_step_callback: Optional[Callable[[TwinTelemetrySample], None]] = None,
        max_moves: Optional[int] = None,
    ) -> SimulationResult:
        """Run complete multi-physics simulation of commanded G-code program."""
        parser = GCodeParser(filament_diameter_m=self.twin.material.filament_diameter_m)
        moves = parser.parse_text(gcode_text)
        
        if max_moves and max_moves > 0:
            moves = moves[:max_moves]

        toolpath_stats = ToolpathAnalyser.analyse(moves, self.twin.material.filament_diameter_m)
        self.twin.state = PrinterState.PRINTING
        self.is_running = True

        samples: List[Dict[str, Any]] = []
        total_moves = len(moves)

        for i, move in enumerate(moves):
            self.progress_pct = (i / float(total_moves)) * 100.0 if total_moves > 0 else 0.0
            
            # Subdivide move into integration steps
            move_duration = max(self.dt_s, move.duration_s)
            steps = max(1, int(move_duration / self.dt_s))
            actual_dt = move_duration / steps

            p_start = move.start_pos
            p_end = move.end_pos
            is_ext = (move.move_type.value == "EXTRUSION")

            for s in range(1, steps + 1):
                alpha = s / float(steps)
                interp_pos = [
                    p_start[0] + alpha * (p_end[0] - p_start[0]),
                    p_start[1] + alpha * (p_end[1] - p_start[1]),
                    p_start[2] + alpha * (p_end[2] - p_start[2]),
                    p_start[3] + alpha * (p_end[3] - p_start[3]),
                ]

                sample = self.twin.update_physics_step(
                    dt=actual_dt,
                    commanded_pos=interp_pos,
                    feedrate_m_s=move.feedrate_m_s,
                    target_hotend_k=move.target_temperature_k,
                    target_bed_k=move.bed_temperature_k,
                    fan_speed_ratio=move.fan_speed_ratio,
                    layer_index=move.layer_index,
                    is_extrusion=is_ext,
                )

                if on_step_callback:
                    on_step_callback(sample)

            # Record sampled telemetry periodically
            if len(self.twin.telemetry_history) > 0:
                samples.append(self.twin.telemetry_history[-1].to_dict())

        self.twin.state = PrinterState.FINISHED
        self.is_running = False
        self.progress_pct = 100.0

        final_quality = self.twin.quality_history[-1].overall_score if self.twin.quality_history else 1.0
        final_energy = self.twin.energy_model.cumulative_joules * (1.0 / 3600.0)

        return SimulationResult(
            total_time_s=self.twin.current_time_s,
            total_moves_executed=total_moves,
            final_quality_score=final_quality,
            total_energy_wh=final_energy,
            deposited_mass_g=self.twin.voxel_grid.total_deposited_mass_kg * 1e3,
            total_voxels=self.twin.voxel_grid.voxel_count,
            detected_defects=self.twin.quality_engine.detected_defects,
            telemetry_samples=samples,
            toolpath_stats=toolpath_stats.to_dict(),
        )
