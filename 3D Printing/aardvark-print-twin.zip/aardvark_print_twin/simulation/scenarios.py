"""
Predefined Synthetic Simulation Scenarios & Benchmark G-Code Generators.
"""

from typing import Dict, Any, List
from aardvark_print_twin.core.state import DefectType
from aardvark_print_twin.digital_twin.twin import DigitalTwin, SimulationMode
from aardvark_print_twin.simulation.engine import SimulationEngine, SimulationResult

def generate_calibration_cube_gcode(size_mm: float = 20.0, layer_height_mm: float = 0.2) -> str:
    """Generate deterministic synthetic G-code for a calibration cube."""
    lines = [
        "; AARDVARK PRINT TWIN - Benchmark Calibration Cube G-Code",
        "M104 S205 ; Set nozzle temp",
        "M140 S60 ; Set bed temp",
        "M109 S205 ; Wait nozzle temp",
        "M190 S60 ; Wait bed temp",
        "G28 ; Home all axes",
        "M83 ; Relative extruder mode",
        "M106 S128 ; 50% fan",
    ]
    
    layers = max(2, int(size_mm / layer_height_mm))
    half = size_mm / 2.0
    x0, y0 = 100.0 - half, 100.0 - half
    x1, y1 = 100.0 + half, 100.0 + half

    e_per_mm = 0.04  # ~0.4mm nozzle, 0.2mm height

    for layer in range(layers):
        z = (layer + 1) * layer_height_mm
        lines.append(f"; LAYER:{layer+1}")
        lines.append(f"G0 X{x0:.2f} Y{y0:.2f} Z{z:.2f} F6000")
        
        # Perimeter
        d_edge = size_mm
        e_edge = d_edge * e_per_mm
        lines.append(f"G1 X{x1:.2f} Y{y0:.2f} E{e_edge:.4f} F3000")
        lines.append(f"G1 X{x1:.2f} Y{y1:.2f} E{e_edge:.4f}")
        lines.append(f"G1 X{x0:.2f} Y{y1:.2f} E{e_edge:.4f}")
        lines.append(f"G1 X{x0:.2f} Y{y0:.2f} E{e_edge:.4f}")
        
        # Infill zig-zag pass
        infill_lines = 4
        spacing = size_mm / (infill_lines + 1)
        for i in range(1, infill_lines + 1):
            ix = x0 + i * spacing
            lines.append(f"G0 X{ix:.2f} Y{y0:.2f} F4500")
            lines.append(f"G1 X{ix:.2f} Y{y1:.2f} E{e_edge:.4f} F3600")

    lines.append("M104 S0 ; Turn off hotend")
    lines.append("M140 S0 ; Turn off bed")
    lines.append("M107 ; Turn off fan")
    lines.append("G0 Z30.0 F3000 ; Lift nozzle")
    lines.append("G28 X0 Y0 ; Home XY")
    return "\n".join(lines)


class BenchmarkScenarios:
    """Pre-configured simulation scenarios for digital twin evaluation."""

    @staticmethod
    def nominal_print(material: str = "AARDVARK PLA") -> SimulationResult:
        twin = DigitalTwin(material_name=material, sim_mode=SimulationMode.PHYSICS_BASED)
        engine = SimulationEngine(twin=twin)
        gcode = generate_calibration_cube_gcode(size_mm=10.0, layer_height_mm=0.2)
        return engine.run_gcode(gcode)

    @staticmethod
    def nozzle_clog_scenario() -> SimulationResult:
        twin = DigitalTwin(material_name="AARDVARK PLA")
        # Inject nozzle clog fault at t = 2.0s
        twin.fault_engine.inject(DefectType.NOZZLE_CLOG, start_time_s=2.0, duration_s=10.0, severity=0.8)
        engine = SimulationEngine(twin=twin)
        gcode = generate_calibration_cube_gcode(size_mm=10.0, layer_height_mm=0.2)
        return engine.run_gcode(gcode)

    @staticmethod
    def overheating_scenario() -> SimulationResult:
        twin = DigitalTwin(material_name="AARDVARK ABS")
        twin.fault_engine.inject(DefectType.OVERHEATING, start_time_s=1.0, duration_s=15.0, severity=0.7)
        engine = SimulationEngine(twin=twin)
        gcode = generate_calibration_cube_gcode(size_mm=10.0, layer_height_mm=0.2)
        return engine.run_gcode(gcode)

    @staticmethod
    def high_speed_vibration_scenario() -> SimulationResult:
        twin = DigitalTwin(material_name="AARDVARK PETG")
        twin.fault_engine.inject(DefectType.BELT_SLIP, start_time_s=1.5, duration_s=8.0, severity=0.9)
        engine = SimulationEngine(twin=twin)
        gcode = generate_calibration_cube_gcode(size_mm=10.0, layer_height_mm=0.2)
        return engine.run_gcode(gcode)
