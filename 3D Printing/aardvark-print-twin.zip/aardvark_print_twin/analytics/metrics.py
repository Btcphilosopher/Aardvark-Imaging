"""
Analytical Aggregation, KPI Summaries, Machine Health Indexing, and Optimization Suggestions.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, List
import math
from aardvark_print_twin.simulation.engine import SimulationResult
from aardvark_print_twin.core.units import Units

@dataclass
class KeyPerformanceIndicators:
    overall_quality_score: float
    total_print_time_min: float
    energy_consumption_kwh: float
    material_deposited_g: float
    volumetric_efficiency_pct: float
    machine_health_index: float
    sustainability_rating: str  # A+, A, B, C, D
    recommendations: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "overall_quality_score": round(self.overall_quality_score, 3),
            "total_print_time_min": round(self.total_print_time_min, 2),
            "energy_consumption_kwh": round(self.energy_consumption_kwh, 4),
            "material_deposited_g": round(self.material_deposited_g, 2),
            "volumetric_efficiency_pct": round(self.volumetric_efficiency_pct, 1),
            "machine_health_index": round(self.machine_health_index, 3),
            "sustainability_rating": self.sustainability_rating,
            "recommendations": self.recommendations,
        }


class AnalyticsEngine:
    """Post-simulation analytical report and machine health diagnostics generator."""

    @staticmethod
    def evaluate_simulation(result: SimulationResult) -> KeyPerformanceIndicators:
        t_min = result.total_time_s / 60.0
        kwh = (result.total_energy_wh / 1000.0)
        mass_g = result.deposited_mass_g

        # Machine health index derived from defects frequency & quality
        defects_cnt = len(result.detected_defects)
        health_index = max(0.0, min(1.0, result.final_quality_score - 0.05 * defects_cnt))

        # Sustainability calculation (g material per Wh)
        eff = (mass_g / max(0.01, result.total_energy_wh)) * 10.0  # scaled score
        if eff > 1.5:
            rating = "A+"
        elif eff > 1.0:
            rating = "A"
        elif eff > 0.6:
            rating = "B"
        elif eff > 0.3:
            rating = "C"
        else:
            rating = "D"

        recommendations = []
        if defects_cnt > 0:
            recommendations.append("Inspect extruder tensioner and verify hotend PID tuning to mitigate flow instability.")
        if kwh > 0.1:
            recommendations.append("Consider reducing heated bed temperature after initial 3 layers to conserve energy.")
        if result.final_quality_score < 0.85:
            recommendations.append("Lower print feedrate by 15-20% on perimeter paths to improve dimensional accuracy.")
        if not recommendations:
            recommendations.append("Nominal print performance achieved. Subsystems operating within optimal physical bounds.")

        vol_eff = min(100.0, max(50.0, result.final_quality_score * 100.0))

        return KeyPerformanceIndicators(
            overall_quality_score=result.final_quality_score,
            total_print_time_min=t_min,
            energy_consumption_kwh=kwh,
            material_deposited_g=mass_g,
            volumetric_efficiency_pct=vol_eff,
            machine_health_index=health_index,
            sustainability_rating=rating,
            recommendations=recommendations,
        )
