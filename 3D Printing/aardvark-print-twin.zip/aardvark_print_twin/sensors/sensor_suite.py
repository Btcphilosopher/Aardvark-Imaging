"""
Virtual Sensor Suite: Synthetic Sensor Digital Twins with Configurable Noise, Bias, Drift & Latency.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional
import random
import math
from aardvark_print_twin.core.units import Units

@dataclass
class SensorReading:
    timestamp_s: float
    sensor_name: str
    value: float
    unit: str
    ground_truth: float
    noise_sigma: float
    bias: float
    confidence: float = 0.98

    def to_dict(self) -> Dict[str, Any]:
        return {
            "timestamp_s": self.timestamp_s,
            "sensor_name": self.sensor_name,
            "value": round(self.value, 4),
            "unit": self.unit,
            "ground_truth": round(self.ground_truth, 4),
            "error": round(self.value - self.ground_truth, 4),
            "confidence": round(self.confidence, 3),
        }


class VirtualSensor:
    """Base virtual sensor with noise, drift, bias, and dropout simulation."""

    def __init__(
        self,
        name: str,
        unit: str,
        noise_sigma: float = 0.0,
        bias: float = 0.0,
        drift_rate_per_s: float = 0.0,
        dropout_probability: float = 0.0,
        ideal_mode: bool = False,
    ):
        self.name = name
        self.unit = unit
        self.noise_sigma = noise_sigma
        self.bias = bias
        self.drift_rate = drift_rate_per_s
        self.dropout_prob = dropout_probability
        self.ideal_mode = ideal_mode
        self.cumulative_drift = 0.0
        self.last_reading: Optional[SensorReading] = None
        self.is_failed: bool = False

    def sample(self, ground_truth: float, timestamp_s: float, dt: float = 0.01) -> SensorReading:
        if self.is_failed or (not self.ideal_mode and random.random() < self.dropout_prob):
            # Failed or dropout
            val = float('nan') if self.is_failed else (self.last_reading.value if self.last_reading else ground_truth)
            reading = SensorReading(
                timestamp_s=timestamp_s,
                sensor_name=self.name,
                value=val,
                unit=self.unit,
                ground_truth=ground_truth,
                noise_sigma=self.noise_sigma,
                bias=self.bias,
                confidence=0.0 if self.is_failed else 0.5,
            )
            self.last_reading = reading
            return reading

        if self.ideal_mode:
            reading = SensorReading(
                timestamp_s=timestamp_s,
                sensor_name=self.name,
                value=ground_truth,
                unit=self.unit,
                ground_truth=ground_truth,
                noise_sigma=0.0,
                bias=0.0,
                confidence=1.0,
            )
            self.last_reading = reading
            return reading

        self.cumulative_drift += self.drift_rate * dt
        noise = random.gauss(0.0, self.noise_sigma) if self.noise_sigma > 0 else 0.0
        measured = ground_truth + self.bias + self.cumulative_drift + noise
        
        reading = SensorReading(
            timestamp_s=timestamp_s,
            sensor_name=self.name,
            value=measured,
            unit=self.unit,
            ground_truth=ground_truth,
            noise_sigma=self.noise_sigma,
            bias=self.bias,
            confidence=max(0.1, 1.0 - (abs(noise) / (abs(ground_truth) + 1e-5))),
        )
        self.last_reading = reading
        return reading


class VirtualSensorSuite:
    """Array of virtual sensors attached to the virtual printer."""

    def __init__(self, ideal_mode: bool = False):
        self.ideal_mode = ideal_mode
        self.hotend_temp_sensor = VirtualSensor("hotend_temp", "°C", noise_sigma=0.4, bias=0.2, ideal_mode=ideal_mode)
        self.bed_temp_sensor = VirtualSensor("bed_temp", "°C", noise_sigma=0.2, bias=-0.1, ideal_mode=ideal_mode)
        self.chamber_temp_sensor = VirtualSensor("chamber_temp", "°C", noise_sigma=0.3, ideal_mode=ideal_mode)
        self.accelerometer_x = VirtualSensor("accel_x", "m/s²", noise_sigma=0.08, ideal_mode=ideal_mode)
        self.accelerometer_y = VirtualSensor("accel_y", "m/s²", noise_sigma=0.08, ideal_mode=ideal_mode)
        self.accelerometer_z = VirtualSensor("accel_z", "m/s²", noise_sigma=0.05, ideal_mode=ideal_mode)
        self.filament_flow_sensor = VirtualSensor("filament_flow", "mm³/s", noise_sigma=0.15, ideal_mode=ideal_mode)
        self.power_sensor = VirtualSensor("total_power", "W", noise_sigma=1.2, bias=0.5, ideal_mode=ideal_mode)

    def sample_all(
        self,
        timestamp_s: float,
        hotend_temp_k: float,
        bed_temp_k: float,
        chamber_temp_k: float,
        accel_xyz: List[float],
        flow_rate_mm3_s: float,
        power_w: float,
        dt: float = 0.01,
    ) -> Dict[str, SensorReading]:
        return {
            "hotend_temp": self.hotend_temp_sensor.sample(Units.k_to_c(hotend_temp_k), timestamp_s, dt),
            "bed_temp": self.bed_temp_sensor.sample(Units.k_to_c(bed_temp_k), timestamp_s, dt),
            "chamber_temp": self.chamber_temp_sensor.sample(Units.k_to_c(chamber_temp_k), timestamp_s, dt),
            "accel_x": self.accelerometer_x.sample(accel_xyz[0], timestamp_s, dt),
            "accel_y": self.accelerometer_y.sample(accel_xyz[1], timestamp_s, dt),
            "accel_z": self.accelerometer_z.sample(accel_xyz[2], timestamp_s, dt),
            "filament_flow": self.filament_flow_sensor.sample(flow_rate_mm3_s, timestamp_s, dt),
            "total_power": self.power_sensor.sample(power_w, timestamp_s, dt),
        }
