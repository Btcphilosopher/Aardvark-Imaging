"""
AARDVARK PRINT TWIN
Digital Twin and Physics-Based Simulator for Additive Manufacturing Machines
Part of the Aardvark Imaging / Aardvark Fabrication ecosystem.
"""

__version__ = "0.1.0"
__author__ = "Aardvark Fabrication / Digital Twin Architect Team"

from aardvark_print_twin.core.units import Units
from aardvark_print_twin.core.clock import SimulationClock
from aardvark_print_twin.core.identifiers import ProvenanceRecord
from aardvark_print_twin.core.state import (
    MachineStatus,
    PrinterState,
    SimulationStatus,
    PrintJobState,
    MaterialPhase,
    DefectType,
    FidelityLevel,
    SimulationMode,
    ComponentHealth,
)
from aardvark_print_twin.digital_twin.twin import DigitalTwin

PrinterDigitalTwin = DigitalTwin

__all__ = [
    "Units",
    "SimulationClock",
    "ProvenanceRecord",
    "MachineStatus",
    "PrinterState",
    "SimulationStatus",
    "PrintJobState",
    "MaterialPhase",
    "DefectType",
    "FidelityLevel",
    "SimulationMode",
    "ComponentHealth",
    "DigitalTwin",
    "PrinterDigitalTwin",
]
