"""
Hotend Extruder Thermal Dynamics and Melt Zone Thermodynamics.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional
from aardvark_print_twin.core.units import Units
from aardvark_print_twin.machine.hotend import HotendAssembly

@dataclass
class HotendParams:
    nozzle_diameter_m: float = Units.mm_to_m(0.4)
    heater_power_w: float = 40.0
    thermal_mass_j_k: float = 18.0
    cooling_coeff_w_k: float = 0.15
    max_temp_k: float = Units.c_to_k(300.0)


@dataclass
class HotendState:
    current_temp_k: float
    target_temp_k: float
    duty_cycle_ratio: float
    electrical_power_w: float
    volumetric_flow_m3_s: float = 0.0


class HotendThermodynamics:
    """Thermodynamics wrapper for hotend heater block and melt zone dynamics."""

    def __init__(self, params: Optional[HotendParams] = None):
        p = params or HotendParams()
        self.assembly = HotendAssembly(
            nozzle_diameter=p.nozzle_diameter_m,
            heater_power_w=p.heater_power_w,
            thermal_mass_j_k=p.thermal_mass_j_k,
            cooling_coeff_w_k=p.cooling_coeff_w_k,
            max_temperature_k=p.max_temp_k,
        )

    @property
    def current_temp_k(self) -> float:
        return self.assembly.temperature_k

    @current_temp_k.setter
    def current_temp_k(self, value_k: float) -> None:
        self.assembly.temperature_k = value_k

    @property
    def volumetric_flow_m3_s(self) -> float:
        return 0.000000005 # ~5 mm³/s default flow

    def step(
        self,
        dt: float,
        target_temp_k: float,
        ambient_temp_k: float,
        fan_speed_ratio: float = 0.0,
    ) -> HotendState:
        self.assembly.target_temperature_k = target_temp_k
        temp = self.assembly.step_thermal(dt, ambient_temp_k, fan_speed_ratio)
        return HotendState(
            current_temp_k=temp,
            target_temp_k=target_temp_k,
            duty_cycle_ratio=self.assembly.heater_duty_cycle,
            electrical_power_w=self.assembly.get_power_w(),
            volumetric_flow_m3_s=0.000000005,
        )
