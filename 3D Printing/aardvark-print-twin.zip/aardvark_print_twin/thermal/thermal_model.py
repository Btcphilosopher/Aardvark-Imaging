"""
Thermal Physics Solver: 3D Heat Diffusion, Convection, Radiation, and Thermal History.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, List, Tuple
import math
from aardvark_print_twin.core.units import Units
from aardvark_print_twin.core.state import MaterialPhase
from aardvark_print_twin.geometry.voxel import VoxelGrid, VoxelCell
from aardvark_print_twin.materials.material import MaterialModel

@dataclass
class ThermalSummary:
    max_temperature_k: float = 0.0
    min_temperature_k: float = 0.0
    avg_temperature_k: float = 0.0
    cooling_voxels_count: int = 0
    solidified_voxels_count: int = 0
    hot_voxels_count: int = 0
    max_cooling_rate_k_s: float = 0.0
    warping_risk_score: float = 0.0  # 0.0 to 1.0
    average_bond_score: float = 1.0  # 0.0 to 1.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "max_temperature_c": Units.k_to_c(self.max_temperature_k) if self.max_temperature_k > 0 else 0.0,
            "min_temperature_c": Units.k_to_c(self.min_temperature_k) if self.min_temperature_k > 0 else 0.0,
            "avg_temperature_c": Units.k_to_c(self.avg_temperature_k) if self.avg_temperature_k > 0 else 0.0,
            "cooling_voxels": self.cooling_voxels_count,
            "solidified_voxels": self.solidified_voxels_count,
            "hot_voxels": self.hot_voxels_count,
            "max_cooling_rate_c_s": round(self.max_cooling_rate_k_s, 2),
            "warping_risk_score": round(self.warping_risk_score, 3),
            "average_bond_score": round(self.average_bond_score, 3),
        }


class ThermalSolver:
    """Explicit 3D finite-difference heat diffusion & environmental loss solver."""

    def __init__(
        self,
        voxel_grid: VoxelGrid,
        material: MaterialModel,
        convection_coeff_w_m2_k: float = 15.0, # Natural / forced convection coefficient h
        stefan_boltzmann: float = 5.67e-8,
    ):
        self.grid = voxel_grid
        self.mat = material
        self.h_conv = convection_coeff_w_m2_k
        self.sigma = stefan_boltzmann
        self.dx = voxel_grid.resolution_m
        self.area_face = self.dx ** 2
        self.vol_cell = self.dx ** 3

    def step_diffusion(
        self,
        dt: float,
        ambient_temp_k: float,
        bed_temp_k: float,
        fan_speed_ratio: float = 0.0,
    ) -> ThermalSummary:
        """Advance thermal field by timestep dt across all active voxels."""
        if not self.grid.active_voxels:
            return ThermalSummary(
                max_temperature_k=ambient_temp_k,
                min_temperature_k=ambient_temp_k,
                avg_temperature_k=ambient_temp_k,
            )

        # Convection multiplier from part cooling fan
        effective_h = self.h_conv * (1.0 + 3.0 * fan_speed_ratio)
        k_cond = self.mat.thermal_conductivity_w_m_k
        rho = self.mat.density_kg_m3
        cp = self.mat.specific_heat_j_kg_k
        tg = self.mat.polymer.glass_transition_temp_k
        t_melt = self.mat.polymer.melting_temp_k

        # Calculate thermal diffusivity alpha = k / (rho * cp)
        alpha = k_cond / (rho * cp)
        
        # 6-neighbour 3D offsets
        offsets = [(1,0,0), (-1,0,0), (0,1,0), (0,-1,0), (0,0,1), (0,0,-1)]
        
        temp_updates: Dict[Tuple[int, int, int], float] = {}
        cooling_rates: Dict[Tuple[int, int, int], float] = {}

        for coord, cell in self.grid.active_voxels.items():
            T_current = cell.temperature_k
            q_conduction = 0.0
            exposed_faces = 0

            # Conduction with direct neighbours
            for ox, oy, oz in offsets:
                n_coord = (coord[0] + ox, coord[1] + oy, coord[2] + oz)
                if n_coord in self.grid.active_voxels:
                    T_neighbour = self.grid.active_voxels[n_coord].temperature_k
                    q_conduction += (k_cond * self.area_face / self.dx) * (T_neighbour - T_current)
                else:
                    exposed_faces += 1

            # Bottom layer direct bed conduction
            if coord[2] == 0:
                q_conduction += (k_cond * self.area_face / (self.dx * 0.5)) * (bed_temp_k - T_current)

            # Convection & radiation on exposed voxel faces
            q_conv = exposed_faces * effective_h * self.area_face * (T_current - ambient_temp_k)
            q_rad = exposed_faces * self.mat.emissivity * self.sigma * self.area_face * (T_current**4 - ambient_temp_k**4)
            
            q_net = q_conduction - q_conv - q_rad
            
            # Update cell temperature: dT = (q_net / (m * cp)) * dt
            m_cell = max(1e-9, cell.mass_kg)
            dT = (q_net / (m_cell * cp)) * dt
            
            # Limit rate of change to maintain numerical stability (Courant-Friedrichs-Lewy criterion)
            new_T = max(ambient_temp_k, T_current + dT)
            temp_updates[coord] = new_T
            cooling_rates[coord] = abs(dT / dt) if dt > 0 else 0.0

        # Apply updates and compute summary metrics
        temps = []
        hot_cnt = 0
        cooling_cnt = 0
        solid_cnt = 0
        bond_scores = []
        thermal_strains = []

        for coord, new_T in temp_updates.items():
            cell = self.grid.active_voxels[coord]
            cell.temperature_k = new_T
            cell.max_temperature_k = max(cell.max_temperature_k, new_T)
            cell.cooling_rate_k_s = cooling_rates[coord]
            temps.append(new_T)

            # Phase state determination
            if new_T >= t_melt:
                cell.material_state = MaterialPhase.HOT
                hot_cnt += 1
            elif new_T > tg:
                cell.material_state = MaterialPhase.COOLING
                cooling_cnt += 1
            else:
                cell.material_state = MaterialPhase.SOLIDIFIED
                solid_cnt += 1

            # Adhesion bond score model based on interface temperature
            if new_T >= tg:
                bond = min(1.0, (new_T - tg) / max(1.0, t_melt - tg))
            else:
                bond = max(0.4, (new_T - ambient_temp_k) / max(1.0, tg - ambient_temp_k))
            bond_scores.append(bond)

            # Warping strain model: epsilon = alpha * delta_T
            strain = self.mat.thermal_expansion_coeff_1_k * abs(cell.max_temperature_k - new_T)
            thermal_strains.append(strain)

        avg_T = sum(temps) / len(temps) if temps else ambient_temp_k
        max_T = max(temps) if temps else ambient_temp_k
        min_T = min(temps) if temps else ambient_temp_k
        max_cr = max(cooling_rates.values()) if cooling_rates else 0.0
        
        # Warping tendency is proportional to thermal gradient between top and bottom layers
        warping_risk = min(1.0, max(thermal_strains) * 500.0) if thermal_strains else 0.0
        avg_bond = sum(bond_scores) / len(bond_scores) if bond_scores else 1.0

        return ThermalSummary(
            max_temperature_k=max_T,
            min_temperature_k=min_T,
            avg_temperature_k=avg_T,
            cooling_voxels_count=cooling_cnt,
            solidified_voxels_count=solid_cnt,
            hot_voxels_count=hot_cnt,
            max_cooling_rate_k_s=max_cr,
            warping_risk_score=warping_risk,
            average_bond_score=avg_bond,
        )
