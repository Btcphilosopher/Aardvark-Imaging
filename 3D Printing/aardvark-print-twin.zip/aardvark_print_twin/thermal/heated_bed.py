"""
Heated Bed Thermal Dynamics and Spatial Surface Temperature Field.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional
from aardvark_print_twin.core.units import Units
from aardvark_print_twin.machine.bed import HeatedBedAssembly

@dataclass
class HeatedBedParams:
    size_x_m: float = Units.mm_to_m(220.0)
    size_y_m: float = Units.mm_to_m(220.0)
    heater_power_w: float = 220.0
    thermal_mass_j_k: float = 450.0
    cooling_coeff_w_k: float = 1.2


@dataclass
class HeatedBedState:
    current_temp_k: float
    target_temp_k: float
    duty_cycle_ratio: float
    electrical_power_w: float


class HeatedBedThermodynamics:
    """Thermodynamics wrapper for heated bed dynamics."""

    def __init__(self, params: Optional[HeatedBedParams] = None):
        p = params or HeatedBedParams()
        self.assembly = HeatedBedAssembly(
            width_x=p.size_x_m,
            length_y=p.size_y_m,
            heater_power_w=p.heater_power_w,
            thermal_mass_j_k=p.thermal_mass_j_k,
            cooling_coeff_w_k=p.cooling_coeff_w_k,
        )

    @property
    def current_temp_k(self) -> float:
        return self.assembly.temperature_k

    @current_temp_k.setter
    def current_temp_k(self, value_k: float) -> None:
        self.assembly.temperature_k = value_k

    def step(self, dt: float, target_temp_k: float, ambient_temp_k: float) -> HeatedBedState:
        self.assembly.target_temperature_k = target_temp_k
        temp = self.assembly.step_thermal(dt, ambient_temp_k)
        return HeatedBedState(
            current_temp_k=temp,
            target_temp_k=target_temp_k,
            duty_cycle_ratio=self.assembly.heater_duty_cycle,
            electrical_power_w=self.assembly.get_power_w(),
        )
