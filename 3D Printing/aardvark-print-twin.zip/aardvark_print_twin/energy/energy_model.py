"""
Energy and Power Model for AM Digital Twin.
Tracks instantaneous electrical power and integrates cumulative Joules ($E = \int P dt$).
"""

from dataclasses import dataclass, field
from typing import Dict, Any
from aardvark_print_twin.core.units import Units

@dataclass
class EnergySnapshot:
    timestamp_s: float = 0.0
    instantaneous_power_w: float = 0.0
    cumulative_energy_j: float = 0.0
    cumulative_energy_wh: float = 0.0
    hotend_energy_j: float = 0.0
    bed_energy_j: float = 0.0
    motors_energy_j: float = 0.0
    fans_energy_j: float = 0.0
    electronics_energy_j: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "timestamp_s": round(self.timestamp_s, 2),
            "instantaneous_power_w": round(self.instantaneous_power_w, 2),
            "cumulative_energy_j": round(self.cumulative_energy_j, 2),
            "cumulative_energy_wh": round(self.cumulative_energy_wh, 3),
            "hotend_energy_j": round(self.hotend_energy_j, 2),
            "bed_energy_j": round(self.bed_energy_j, 2),
            "motors_energy_j": round(self.motors_energy_j, 2),
            "fans_energy_j": round(self.fans_energy_j, 2),
            "electronics_energy_j": round(self.electronics_energy_j, 2),
        }


class EnergyModel:
    """Simulates power draw across all subcomponents and integrates cumulative energy consumption."""

    def __init__(self):
        self.cumulative_joules: float = 0.0
        self.hotend_joules: float = 0.0
        self.bed_joules: float = 0.0
        self.motors_joules: float = 0.0
        self.fans_joules: float = 0.0
        self.electronics_joules: float = 0.0
        self.last_power_w: float = 0.0

    def step(
        self,
        dt: float,
        timestamp_s: float,
        hotend_power_w: float,
        bed_power_w: float,
        motors_power_w: float,
        fans_power_w: float,
        electronics_power_w: float = 15.0,
    ) -> EnergySnapshot:
        p_total = hotend_power_w + bed_power_w + motors_power_w + fans_power_w + electronics_power_w
        self.last_power_w = p_total

        e_hotend = hotend_power_w * dt
        e_bed = bed_power_w * dt
        e_motors = motors_power_w * dt
        e_fans = fans_power_w * dt
        e_elec = electronics_power_w * dt
        e_step = p_total * dt

        self.hotend_joules += e_hotend
        self.bed_joules += e_bed
        self.motors_joules += e_motors
        self.fans_joules += e_fans
        self.electronics_joules += e_elec
        self.cumulative_joules += e_step

        return EnergySnapshot(
            timestamp_s=timestamp_s,
            instantaneous_power_w=p_total,
            cumulative_energy_j=self.cumulative_joules,
            cumulative_energy_wh=Units.j_to_wh(self.cumulative_joules),
            hotend_energy_j=self.hotend_joules,
            bed_energy_j=self.bed_joules,
            motors_energy_j=self.motors_joules,
            fans_energy_j=self.fans_joules,
            electronics_energy_j=self.electronics_joules,
        )
