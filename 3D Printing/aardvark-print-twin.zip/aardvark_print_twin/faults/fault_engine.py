"""
Fault and Defect Injection Engine for AM Physical Simulation.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional
from aardvark_print_twin.core.state import DefectType

@dataclass
class InjectedFault:
    """Descriptor for a controlled simulated defect."""
    fault_type: DefectType
    start_time_s: float
    duration_s: float
    severity: float = 0.5  # 0.0 to 1.0
    parameters: Dict[str, Any] = field(default_factory=dict)
    is_active: bool = False
    has_triggered: bool = False

    def check_active(self, current_time_s: float) -> bool:
        if self.start_time_s <= current_time_s <= (self.start_time_s + self.duration_s):
            self.is_active = True
            self.has_triggered = True
            return True
        self.is_active = False
        return False


class FaultEngine:
    """Manages active and scheduled faults during simulation."""

    def __init__(self):
        self.scheduled_faults: List[InjectedFault] = []
        self.active_faults: List[InjectedFault] = []
        self.fault_history: List[InjectedFault] = []

    def inject(
        self,
        fault_type: DefectType,
        start_time_s: float = 0.0,
        duration_s: float = 60.0,
        severity: float = 0.5,
        parameters: Optional[Dict[str, Any]] = None,
    ) -> InjectedFault:
        fault = InjectedFault(
            fault_type=fault_type,
            start_time_s=start_time_s,
            duration_s=duration_s,
            severity=severity,
            parameters=parameters or {},
        )
        self.scheduled_faults.append(fault)
        return fault

    def step(self, current_time_s: float) -> List[InjectedFault]:
        """Update fault status and return currently active faults."""
        self.active_faults = [f for f in self.scheduled_faults if f.check_active(current_time_s)]
        return self.active_faults

    def has_fault(self, fault_type: DefectType) -> bool:
        return any(f.fault_type == fault_type for f in self.active_faults)

    def get_severity(self, fault_type: DefectType) -> float:
        for f in self.active_faults:
            if f.fault_type == fault_type:
                return f.severity
        return 0.0
