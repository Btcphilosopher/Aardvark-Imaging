"""
Material Physics, Polymer Properties, Rheology, and Synthetic Reference Profiles.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional
import math
from aardvark_print_twin.core.units import Units

@dataclass
class PolymerProperties:
    """Thermophysical polymer parameters in SI units."""
    glass_transition_temp_k: float = Units.c_to_k(60.0)
    melting_temp_k: float = Units.c_to_k(165.0)
    degradation_temp_k: float = Units.c_to_k(250.0)
    crystallinity_pct: float = 10.0
    reptation_time_s: float = 0.5  # Polymer chain diffusion relaxation time


@dataclass
class RheologyModel:
    """Non-Newtonian shear-thinning and temperature-dependent viscosity model:
    Cross-WLF or Power-Law approximation: $\mu(T) = \mu_0 \exp(-b (T - T_0))$.
    """
    zero_shear_viscosity_pa_s: float = 1200.0
    shear_thinning_index: float = 0.45
    temp_sensitivity_k: float = 0.03
    reference_temp_k: float = Units.c_to_k(210.0)

    def calculate_viscosity(self, temp_k: float, shear_rate_s1: float = 100.0) -> float:
        """Calculate dynamic viscosity in Pa·s."""
        dT = temp_k - self.reference_temp_k
        arrhenius = math.exp(-self.temp_sensitivity_k * dT)
        shear_factor = max(1.0, shear_rate_s1) ** (self.shear_thinning_index - 1.0)
        return max(1.0, self.zero_shear_viscosity_pa_s * arrhenius * shear_factor)


@dataclass
class MaterialModel:
    """Comprehensive synthetic material profile for AM digital twin simulation."""
    name: str = "AARDVARK PLA"
    material_id: str = "MAT-PLA-AARDVARK-01"
    density_kg_m3: float = 1240.0         # 1.24 g/cm³
    filament_diameter_m: float = Units.mm_to_m(1.75)
    specific_heat_j_kg_k: float = 1800.0  # c_p ~ 1.8 J/(g·K)
    thermal_conductivity_w_m_k: float = 0.13 # k ~ 0.13 W/(m·K)
    emissivity: float = 0.92
    
    # Recommended operational temperatures
    recommended_nozzle_temp_k: float = Units.c_to_k(205.0)
    recommended_bed_temp_k: float = Units.c_to_k(60.0)
    recommended_chamber_temp_k: float = Units.c_to_k(25.0)
    
    # Warping and mechanical
    thermal_expansion_coeff_1_k: float = 68e-6 # alpha ~ 68 ppm/K
    shrinkage_coefficient: float = 0.004       # 0.4% linear shrinkage
    yield_strength_mpa: float = 60.0
    
    polymer: PolymerProperties = field(default_factory=PolymerProperties)
    rheology: RheologyModel = field(default_factory=RheologyModel)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "material_id": self.material_id,
            "density_g_cm3": self.density_kg_m3 * 1e-3,
            "filament_diameter_mm": Units.m_to_mm(self.filament_diameter_m),
            "specific_heat_j_kg_k": self.specific_heat_j_kg_k,
            "thermal_conductivity_w_m_k": self.thermal_conductivity_w_m_k,
            "recommended_nozzle_c": Units.k_to_c(self.recommended_nozzle_temp_k),
            "recommended_bed_c": Units.k_to_c(self.recommended_bed_temp_k),
            "glass_transition_c": Units.k_to_c(self.polymer.glass_transition_temp_k),
            "shrinkage_pct": self.shrinkage_coefficient * 100.0,
        }


# Standard Synthetic Library
def get_synthetic_material(name_or_id: str) -> MaterialModel:
    """Retrieve reference synthetic AM material profile."""
    n = name_or_id.upper()
    if "PETG" in n:
        return MaterialModel(
            name="AARDVARK PETG",
            material_id="MAT-PETG-AARDVARK-02",
            density_kg_m3=1270.0,
            specific_heat_j_kg_k=1750.0,
            thermal_conductivity_w_m_k=0.19,
            recommended_nozzle_temp_k=Units.c_to_k(240.0),
            recommended_bed_temp_k=Units.c_to_k(80.0),
            thermal_expansion_coeff_1_k=60e-6,
            shrinkage_coefficient=0.005,
            polymer=PolymerProperties(glass_transition_temp_k=Units.c_to_k(85.0), melting_temp_k=Units.c_to_k(220.0)),
        )
    elif "ABS" in n:
        return MaterialModel(
            name="AARDVARK ABS",
            material_id="MAT-ABS-AARDVARK-03",
            density_kg_m3=1040.0,
            specific_heat_j_kg_k=2100.0,
            thermal_conductivity_w_m_k=0.17,
            recommended_nozzle_temp_k=Units.c_to_k(250.0),
            recommended_bed_temp_k=Units.c_to_k(105.0),
            recommended_chamber_temp_k=Units.c_to_k(45.0),
            thermal_expansion_coeff_1_k=90e-6,
            shrinkage_coefficient=0.015, # 1.5% high warping risk
            polymer=PolymerProperties(glass_transition_temp_k=Units.c_to_k(105.0), melting_temp_k=Units.c_to_k(230.0)),
        )
    else:
        # Default PLA
        return MaterialModel()
