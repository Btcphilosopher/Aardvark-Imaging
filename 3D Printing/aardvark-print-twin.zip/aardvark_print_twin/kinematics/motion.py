"""
Kinematics, Trajectory Generation, and Motion Stepping.
"""

from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Any, Optional
import math
from aardvark_print_twin.machine.kinematics import CartesianKinematics as BaseCartesianKinematics

@dataclass
class MotionProfile:
    max_velocity_m_s: float = 0.3        # 300 mm/s
    max_acceleration_m_s2: float = 3.0   # 3000 mm/s²
    jerk_m_s3: float = 20.0             # Jerk threshold
    steps_per_mm_xy: float = 80.0
    steps_per_mm_z: float = 400.0
    steps_per_mm_e: float = 415.0


@dataclass
class KinematicState:
    actual_position_m: List[float]     # [x, y, z, e]
    commanded_position_m: List[float]  # [x, y, z, e]
    velocity_m_s: List[float]         # [vx, vy, vz, ve]
    acceleration_m_s2: List[float]     # [ax, ay, az, ae]
    position_error_m: float
    displacement_m: float
    is_accelerating: bool = False


class CartesianKinematics(BaseCartesianKinematics):
    """Cartesian Kinematic step solver with finite acceleration and positioning error model."""

    def __init__(self, profile: Optional[MotionProfile] = None):
        self.profile = profile or MotionProfile()
        self.current_pos = [0.0, 0.0, 0.0, 0.0]
        self.current_vel = [0.0, 0.0, 0.0, 0.0]
        self.current_acc = [0.0, 0.0, 0.0, 0.0]

    def step(self, dt: float, commanded_pos: List[float], feedrate_m_s: float) -> KinematicState:
        # Calculate displacement vector
        dx = commanded_pos[0] - self.current_pos[0]
        dy = commanded_pos[1] - self.current_pos[1]
        dz = commanded_pos[2] - self.current_pos[2]
        de = commanded_pos[3] - self.current_pos[3]

        dist = math.sqrt(dx**2 + dy**2 + dz**2)

        if dist < 1e-9 or dt <= 0:
            self.current_vel = [0.0, 0.0, 0.0, 0.0]
            self.current_acc = [0.0, 0.0, 0.0, 0.0]
            return KinematicState(
                actual_position_m=list(self.current_pos),
                commanded_position_m=list(commanded_pos),
                velocity_m_s=[0.0, 0.0, 0.0, 0.0],
                acceleration_m_s2=[0.0, 0.0, 0.0, 0.0],
                position_error_m=0.0,
                displacement_m=0.0,
            )

        # Target directional velocity limited by feedrate and motion profile
        target_v = min(feedrate_m_s, self.profile.max_velocity_m_s)
        dir_x, dir_y, dir_z = dx / dist, dy / dist, dz / dist

        # Acceleration towards target velocity: v_new = v_old + a * dt
        v_target_xyz = [target_v * dir_x, target_v * dir_y, target_v * dir_z, (de / dt) if dt > 0 else 0.0]

        new_vel = []
        new_acc = []
        for i in range(4):
            dv = v_target_xyz[i] - self.current_vel[i]
            max_dv = self.profile.max_acceleration_m_s2 * dt
            actual_dv = max(-max_dv, min(max_dv, dv))
            v_i = self.current_vel[i] + actual_dv
            a_i = actual_dv / dt if dt > 0 else 0.0
            new_vel.append(v_i)
            new_acc.append(a_i)

        self.current_vel = new_vel
        self.current_acc = new_acc

        # Position step integration
        new_pos = [
            self.current_pos[0] + self.current_vel[0] * dt,
            self.current_pos[1] + self.current_vel[1] * dt,
            self.current_pos[2] + self.current_vel[2] * dt,
            self.current_pos[3] + self.current_vel[3] * dt,
        ]
        self.current_pos = new_pos

        # Calculate positioning error relative to ideal command
        pos_err = math.sqrt((commanded_pos[0] - new_pos[0])**2 + (commanded_pos[1] - new_pos[1])**2 + (commanded_pos[2] - new_pos[2])**2)

        return KinematicState(
            actual_position_m=list(self.current_pos),
            commanded_position_m=list(commanded_pos),
            velocity_m_s=list(self.current_vel),
            acceleration_m_s2=list(self.current_acc),
            position_error_m=pos_err,
            displacement_m=dist,
            is_accelerating=(abs(new_acc[0]) > 0.1 or abs(new_acc[1]) > 0.1),
        )
