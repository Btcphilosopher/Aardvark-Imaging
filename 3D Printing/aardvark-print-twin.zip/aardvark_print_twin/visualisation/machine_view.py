"""
ASCII & Terminal Visualizer for Spatial Voxel Thermal Gradients and Machine Kinematics.
"""

from typing import List, Dict, Any
from aardvark_print_twin.digital_twin.twin import DigitalTwin, TwinTelemetrySample
from aardvark_print_twin.core.units import Units

class TerminalVisualizer:
    """ASCII/ANSI visualization engine for terminal & CLI feedback."""

    @staticmethod
    def render_layer_slice(twin: DigitalTwin, layer_index: int = 0, width: int = 30, height: int = 15) -> str:
        """Render a 2D ASCII cross-section of temperature voxels for a specific layer."""
        voxels = twin.voxel_grid.get_layer_voxels(layer_index)
        if not voxels:
            return f"[ No active voxels for Layer {layer_index} ]"

        grid = [["." for _ in range(width)] for _ in range(height)]
        
        # Determine bounds
        min_x = min(v.ix for v in voxels)
        max_x = max(v.ix for v in voxels)
        min_y = min(v.iy for v in voxels)
        max_y = max(v.iy for v in voxels)

        dx = max(1, max_x - min_x)
        dy = max(1, max_y - min_y)

        for v in voxels:
            gx = int(((v.ix - min_x) / float(dx)) * (width - 1))
            gy = int(((v.iy - min_y) / float(dy)) * (height - 1))
            
            temp_c = Units.k_to_c(v.temperature_k)
            if temp_c > 180:
                symbol = "#" # Hot nozzle melt zone
            elif temp_c > 100:
                symbol = "*" # Transition cooling zone
            elif temp_c > 50:
                symbol = "+" # Solidifying zone
            else:
                symbol = "o" # Ambient bed cooled zone

            grid[gy][gx] = symbol

        lines = [f"=== AARDVARK DIGITAL TWIN 2D LAYER {layer_index} VOXEL SLICE ==="]
        for row in reversed(grid):
            lines.append("  " + "".join(row))
        lines.append("Legend: '#' >180°C | '*' 100-180°C | '+' 50-100°C | 'o' <50°C | '.' empty")
        return "\n".join(lines)

    @staticmethod
    def render_dashboard_banner(sample: TwinTelemetrySample) -> str:
        """Render concise status dashboard string for live CLI streaming."""
        hotend_c = Units.k_to_c(sample.hotend_temp_k)
        bed_c = Units.k_to_c(sample.bed_temp_k)
        return (
            f"[{sample.state.value}] t={sample.timestamp_s:6.2f}s | "
            f"Pos: ({sample.kinematic_pos[0]*1000:5.1f}, {sample.kinematic_pos[1]*1000:5.1f}, {sample.kinematic_pos[2]*1000:5.1f})mm | "
            f"Nozzle: {hotend_c:5.1f}°C | Bed: {bed_c:5.1f}°C | "
            f"Pwr: {sample.total_power_w:5.1f}W | Q-Score: {sample.quality_score:4.2f} | "
            f"Voxels: {sample.active_voxels}"
        )
