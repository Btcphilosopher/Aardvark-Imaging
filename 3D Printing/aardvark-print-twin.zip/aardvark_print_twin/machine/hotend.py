"""
Hotend Assembly and Melt Zone Thermal Model.
"""

from dataclasses import dataclass
from typing import Dict, Any
from aardvark_print_twin.core.units import Units

@dataclass
class HotendAssembly:
    """Hotend thermal mass and heating cartridge dynamics."""
    nozzle_diameter: float = Units.mm_to_m(0.4)
    temperature_k: float = Units.c_to_k(22.0)
    target_temperature_k: float = Units.c_to_k(22.0)
    heater_power_w: float = 40.0
    thermal_mass_j_k: float = 18.0  # Heat capacity of aluminium heater block
    cooling_coeff_w_k: float = 0.15 # Natural convection heat loss coefficient
    max_temperature_k: float = Units.c_to_k(300.0)
    pid_p: float = 22.2
    pid_i: float = 1.08
    pid_d: float = 114.0
    integral_error: float = 0.0
    last_error: float = 0.0
    heater_duty_cycle: float = 0.0  # 0.0 to 1.0

    def step_thermal(self, dt: float, ambient_k: float, fan_speed_ratio: float = 0.0) -> float:
        """Simulate PID heater control and thermal energy balance."""
        error = self.target_temperature_k - self.temperature_k
        self.integral_error = max(-50.0, min(50.0, self.integral_error + error * dt))
        derivative = (error - self.last_error) / dt if dt > 0 else 0.0
        self.last_error = error

        # PID output (0 to 100% duty cycle)
        if self.target_temperature_k > ambient_k + 5.0:
            raw_output = (self.pid_p * error + self.pid_i * self.integral_error + self.pid_d * derivative) / 100.0
            self.heater_duty_cycle = max(0.0, min(1.0, raw_output))
        else:
            self.heater_duty_cycle = 0.0

        p_heat = self.heater_duty_cycle * self.heater_power_w
        # Convection loss increased by part cooling fan
        effective_h = self.cooling_coeff_w_k * (1.0 + 2.0 * fan_speed_ratio)
        p_loss = effective_h * (self.temperature_k - ambient_k)

        # Explicit Euler thermal mass update
        dT = ((p_heat - p_loss) / self.thermal_mass_j_k) * dt
        self.temperature_k = max(ambient_k, min(self.max_temperature_k, self.temperature_k + dT))
        return self.temperature_k

    def get_power_w(self) -> float:
        return self.heater_duty_cycle * self.heater_power_w

    def to_dict(self) -> Dict[str, Any]:
        return {
            "temperature_c": Units.k_to_c(self.temperature_k),
            "target_temperature_c": Units.k_to_c(self.target_temperature_k),
            "heater_duty_pct": round(self.heater_duty_cycle * 100.0, 1),
            "heater_power_w": self.get_power_w(),
            "nozzle_diameter_mm": Units.m_to_mm(self.nozzle_diameter),
        }
