"""
Kinematics Models: Forward and Inverse Kinematic Solvers.
Supports Cartesian, CoreXY, Delta, and SCARA architectures.
"""

from abc import ABC, abstractmethod
from typing import List, Tuple, Dict, Any
import math

class Kinematics(ABC):
    """Abstract base class for 3D printer kinematic transformations."""

    @abstractmethod
    def forward(self, motor_positions: List[float]) -> List[float]:
        """Convert actuator/motor space [m1, m2, m3] to Cartesian toolhead space [x, y, z]."""
        pass

    @abstractmethod
    def inverse(self, cartesian_position: List[float]) -> List[float]:
        """Convert Cartesian toolhead space [x, y, z] to actuator/motor space [m1, m2, m3]."""
        pass


class CartesianKinematics(Kinematics):
    """Direct 1:1 mapping between motor displacements and Cartesian axes."""

    def forward(self, motor_positions: List[float]) -> List[float]:
        return [float(p) for p in motor_positions[:3]]

    def inverse(self, cartesian_position: List[float]) -> List[float]:
        return [float(p) for p in cartesian_position[:3]]


class CoreXYKinematics(Kinematics):
    """CoreXY differential belt kinematics:
    Motor A (m1) moves (X + Y)
    Motor B (m2) moves (X - Y)
    Motor Z (m3) moves Z directly
    """

    def forward(self, motor_positions: List[float]) -> List[float]:
        ma, mb = motor_positions[0], motor_positions[1]
        z = motor_positions[2] if len(motor_positions) > 2 else 0.0
        x = 0.5 * (ma + mb)
        y = 0.5 * (ma - mb)
        return [x, y, z]

    def inverse(self, cartesian_position: List[float]) -> List[float]:
        x, y = cartesian_position[0], cartesian_position[1]
        z = cartesian_position[2] if len(cartesian_position) > 2 else 0.0
        ma = x + y
        mb = x - y
        return [ma, mb, z]


class DeltaKinematics(Kinematics):
    """Simplified Delta kinematics for 3 vertical towers (A, B, C)."""

    def __init__(self, arm_length_m: float = 0.25, delta_radius_m: float = 0.12):
        self.arm_length = arm_length_m
        self.delta_radius = delta_radius_m
        # 3 tower angles (120 deg apart): 210°, 330°, 90°
        self.tower_angles = [7 * math.pi / 6, 11 * math.pi / 6, math.pi / 2]

    def forward(self, motor_positions: List[float]) -> List[float]:
        # Approximate forward kinematics using geometric height
        avg_z = sum(motor_positions[:3]) / 3.0
        # For small planar displacements:
        x = (motor_positions[1] - motor_positions[0]) * 0.3
        y = (motor_positions[2] - avg_z) * 0.5
        z = avg_z
        return [x, y, z]

    def inverse(self, cartesian_position: List[float]) -> List[float]:
        x, y, z = cartesian_position[:3]
        carriages = []
        for angle in self.tower_angles:
            tx = self.delta_radius * math.cos(angle)
            ty = self.delta_radius * math.sin(angle)
            dx = x - tx
            dy = y - ty
            dist_sq = self.arm_length**2 - dx**2 - dy**2
            c_z = z + math.sqrt(max(0.0, dist_sq))
            carriages.append(c_z)
        return carriages


class SCARAKinematics(Kinematics):
    """2-link SCARA arm in XY plane + linear Z axis."""

    def __init__(self, l1_m: float = 0.15, l2_m: float = 0.15):
        self.l1 = l1_m
        self.l2 = l2_m

    def forward(self, motor_positions: List[float]) -> List[float]:
        theta1, theta2, z = motor_positions[0], motor_positions[1], motor_positions[2]
        x = self.l1 * math.cos(theta1) + self.l2 * math.cos(theta1 + theta2)
        y = self.l1 * math.sin(theta1) + self.l2 * math.sin(theta1 + theta2)
        return [x, y, z]

    def inverse(self, cartesian_position: List[float]) -> List[float]:
        x, y, z = cartesian_position[0], cartesian_position[1], cartesian_position[2]
        r_sq = x**2 + y**2
        cos_theta2 = (r_sq - self.l1**2 - self.l2**2) / (2 * self.l1 * self.l2)
        cos_theta2 = max(-1.0, min(1.0, cos_theta2))
        theta2 = math.acos(cos_theta2)
        theta1 = math.atan2(y, x) - math.atan2(self.l2 * math.sin(theta2), self.l1 + self.l2 * math.cos(theta2))
        return [theta1, theta2, z]
