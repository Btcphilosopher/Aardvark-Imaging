"""
Axis State and Mechanical Kinematic Constraints.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional
from aardvark_print_twin.core.units import Units

@dataclass
class AxisLimits:
    min_position: float = 0.0
    max_position: float = 0.22  # metres
    max_velocity: float = 0.3    # m/s
    max_accel: float = 3.0      # m/s²
    max_jerk: float = 0.01      # m/s

@dataclass
class AxisState:
    """State of an individual machine axis (X, Y, Z, or E)."""
    name: str
    position: float = 0.0         # Current physical position (m)
    target_position: float = 0.0  # Desired target position (m)
    velocity: float = 0.0         # Current velocity (m/s)
    target_velocity: float = 0.0  # Target velocity (m/s)
    acceleration: float = 0.0     # Current acceleration (m/s²)
    jerk: float = 0.0             # Current jerk (m/s³)
    limits: AxisLimits = field(default_factory=AxisLimits)
    is_homed: bool = False
    
    # Imperfections
    position_error: float = 0.0   # Difference between commanded & physical
    backlash: float = 0.0
    last_direction: int = 1       # +1 or -1

    def update_position(self, new_pos: float, dt: float) -> None:
        """Update axis position with kinematic calculations."""
        delta = new_pos - self.position
        direction = 1 if delta >= 0 else -1
        
        # Apply backlash if direction reverses
        effective_delta = delta
        if direction != self.last_direction and self.backlash > 0:
            lost = min(abs(delta), self.backlash)
            effective_delta = delta - (lost if direction > 0 else -lost)
            self.last_direction = direction

        new_vel = (effective_delta / dt) if dt > 0 else 0.0
        self.acceleration = ((new_vel - self.velocity) / dt) if dt > 0 else 0.0
        self.velocity = new_vel
        self.position += effective_delta
        self.position_error = self.target_position - self.position

    def clamp_to_limits(self) -> None:
        """Enforce physical soft limits."""
        if self.position < self.limits.min_position:
            self.position = self.limits.min_position
            self.velocity = 0.0
        elif self.position > self.limits.max_position:
            self.position = self.limits.max_position
            self.velocity = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "position_m": self.position,
            "position_mm": Units.m_to_mm(self.position),
            "velocity_m_s": self.velocity,
            "accel_m_s2": self.acceleration,
            "is_homed": self.is_homed,
            "position_error_um": Units.m_to_um(self.position_error),
        }
