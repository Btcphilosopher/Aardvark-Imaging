"""
Chamber, Toolhead, Extruder, Machine Limits, and Printer Assembly.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional
from aardvark_print_twin.core.units import Units
from aardvark_print_twin.machine.axis import AxisState, AxisLimits
from aardvark_print_twin.machine.motor import StepperMotor
from aardvark_print_twin.machine.hotend import HotendAssembly
from aardvark_print_twin.machine.bed import HeatedBed
from aardvark_print_twin.machine.kinematics import Kinematics, CartesianKinematics

@dataclass
class ExtruderAssembly:
    """Drive gears, pinch roll, and filament feeder mechanics."""
    drive_gear_radius_m: float = Units.mm_to_m(5.0)
    filament_diameter_m: float = Units.mm_to_m(1.75)
    grip_coefficient: float = 0.98  # 1.0 = perfect positive traction
    is_clogged: bool = False
    extrusion_multiplier: float = 1.0

    def calculate_filament_volume_m3(self, feed_length_m: float) -> float:
        """Calculate unextruded filament volume $V = \pi r^2 L$."""
        import math
        r = self.filament_diameter_m / 2.0
        effective_l = feed_length_m * self.grip_coefficient * self.extrusion_multiplier
        if self.is_clogged:
            effective_l = 0.0
        return math.pi * (r ** 2) * effective_l


@dataclass
class EnclosedChamber:
    """Thermal enclosure, internal ambient air and convective circulation."""
    temperature_k: float = Units.c_to_k(25.0)
    target_temperature_k: float = Units.c_to_k(25.0)
    heater_power_w: float = 0.0  # Passive chamber by default
    volume_m3: float = 0.22 * 0.22 * 0.25
    air_heat_capacity_j_k: float = 100.0
    loss_to_ambient_w_k: float = 1.2

    def step_thermal(self, dt: float, ambient_k: float, bed_heat_w: float, hotend_heat_w: float) -> float:
        # Chamber warmed by bed, hotend, and internal heater
        q_in = self.heater_power_w + 0.3 * bed_heat_w + 0.2 * hotend_heat_w
        q_loss = self.loss_to_ambient_w_k * (self.temperature_k - ambient_k)
        dT = ((q_in - q_loss) / self.air_heat_capacity_j_k) * dt
        self.temperature_k = max(ambient_k, self.temperature_k + dT)
        return self.temperature_k


@dataclass
class Toolhead:
    """Carriage toolhead holding hotend and part cooling fan."""
    hotend: HotendAssembly = field(default_factory=HotendAssembly)
    extruder: ExtruderAssembly = field(default_factory=ExtruderAssembly)
    fan_speed_ratio: float = 0.0  # 0.0 to 1.0 (0-255 in G-code)
    fan_power_max_w: float = 5.0

    def get_fan_power_w(self) -> float:
        return self.fan_speed_ratio * self.fan_power_max_w


@dataclass
class MachineLimits:
    """Soft & hard kinematic workspace boundaries."""
    x_min: float = 0.0
    x_max: float = Units.mm_to_m(220.0)
    y_min: float = 0.0
    y_max: float = Units.mm_to_m(220.0)
    z_min: float = 0.0
    z_max: float = Units.mm_to_m(250.0)

    def is_within_bounds(self, x: float, y: float, z: float) -> bool:
        return (self.x_min <= x <= self.x_max and
                self.y_min <= y <= self.y_max and
                self.z_min <= z <= self.z_max)


class PrinterModel:
    """Canonical 3D Printer Hardware Model aggregating all sub-assemblies."""

    def __init__(
        self,
        machine_id: str = "AARDVARK-VP-220",
        manufacturer: str = "Aardvark Fabrication",
        model: str = "Virtual Printer 220",
    ):
        self.machine_id = machine_id
        self.manufacturer = manufacturer
        self.model = model
        self.kinematics: Kinematics = CartesianKinematics()
        self.limits = MachineLimits()
        
        # 4 motion axes
        self.axes: Dict[str, AxisState] = {
            "X": AxisState(name="X", limits=AxisLimits(0.0, self.limits.x_max, Units.mm_s_to_m_s(300), Units.mm_s2_to_m_s2(3000))),
            "Y": AxisState(name="Y", limits=AxisLimits(0.0, self.limits.y_max, Units.mm_s_to_m_s(300), Units.mm_s2_to_m_s2(3000))),
            "Z": AxisState(name="Z", limits=AxisLimits(0.0, self.limits.z_max, Units.mm_s_to_m_s(30), Units.mm_s2_to_m_s2(500))),
            "E": AxisState(name="E", limits=AxisLimits(-10.0, 10000.0, Units.mm_s_to_m_s(50), Units.mm_s2_to_m_s2(5000))),
        }

        # Stepper motors
        self.motors: Dict[str, StepperMotor] = {
            "X": StepperMotor("X"),
            "Y": StepperMotor("Y"),
            "Z": StepperMotor("Z", steps_per_mm=400.0),
            "E": StepperMotor("E", steps_per_mm=93.0),
        }

        self.toolhead = Toolhead()
        self.bed = HeatedBed(width_x=self.limits.x_max, length_y=self.limits.y_max)
        self.chamber = EnclosedChamber()
        self.electronics_power_w = 15.0

    @property
    def position_xyz(self) -> List[float]:
        return [self.axes["X"].position, self.axes["Y"].position, self.axes["Z"].position]

    @property
    def hotend(self) -> HotendAssembly:
        return self.toolhead.hotend

    @property
    def extruder(self) -> ExtruderAssembly:
        return self.toolhead.extruder

    def home_all(self) -> None:
        """Simulate homing sequence."""
        for axis in self.axes.values():
            axis.position = 0.0
            axis.target_position = 0.0
            axis.velocity = 0.0
            axis.is_homed = True

    def calculate_total_instantaneous_power_w(self) -> float:
        """Sum electrical power across hotend, bed, steppers, fans, and controller board."""
        p_hotend = self.hotend.get_power_w()
        p_bed = self.bed.get_power_w()
        p_fan = self.toolhead.get_fan_power_w()
        p_motors = sum(m.calculate_power_w(is_active=True) for m in self.motors.values())
        return p_hotend + p_bed + p_fan + p_motors + self.electronics_power_w

    def to_dict(self) -> Dict[str, Any]:
        return {
            "machine_id": self.machine_id,
            "manufacturer": self.manufacturer,
            "model": self.model,
            "position": {k: v.to_dict() for k, v in self.axes.items()},
            "hotend": self.hotend.to_dict(),
            "bed": self.bed.to_dict(),
            "chamber_temp_c": Units.k_to_c(self.chamber.temperature_k),
            "fan_pct": round(self.toolhead.fan_speed_ratio * 100.0, 1),
            "total_power_w": round(self.calculate_total_instantaneous_power_w(), 2),
        }
