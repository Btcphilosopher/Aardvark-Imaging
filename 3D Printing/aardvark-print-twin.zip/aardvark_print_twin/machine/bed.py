"""
Heated Bed, Thermal Mass, and PID Model.
"""

from dataclasses import dataclass
from typing import Dict, Any
from aardvark_print_twin.core.units import Units

@dataclass
class HeatedBed:
    """Heated print bed with thermal inertia and conduction interface."""
    width_x: float = Units.mm_to_m(220.0)
    length_y: float = Units.mm_to_m(220.0)
    temperature_k: float = Units.c_to_k(22.0)
    target_temperature_k: float = Units.c_to_k(22.0)
    heater_power_w: float = 220.0
    thermal_mass_j_k: float = 850.0  # Large heat capacity of aluminium/glass bed
    cooling_coeff_w_k: float = 1.8   # Natural convection from surface area
    max_temperature_k: float = Units.c_to_k(120.0)
    heater_duty_cycle: float = 0.0

    def step_thermal(self, dt: float, ambient_k: float) -> float:
        """Step bed thermal balance."""
        if self.target_temperature_k > self.temperature_k:
            # Bang-bang or proportional approach
            self.heater_duty_cycle = 1.0 if (self.target_temperature_k - self.temperature_k) > 1.0 else 0.4
        else:
            self.heater_duty_cycle = 0.0

        p_heat = self.heater_duty_cycle * self.heater_power_w
        p_loss = self.cooling_coeff_w_k * (self.temperature_k - ambient_k)

        dT = ((p_heat - p_loss) / self.thermal_mass_j_k) * dt
        self.temperature_k = max(ambient_k, min(self.max_temperature_k, self.temperature_k + dT))
        return self.temperature_k

    def get_power_w(self) -> float:
        return self.heater_duty_cycle * self.heater_power_w

    def to_dict(self) -> Dict[str, Any]:
        return {
            "temperature_c": Units.k_to_c(self.temperature_k),
            "target_temperature_c": Units.k_to_c(self.target_temperature_k),
            "heater_duty_pct": round(self.heater_duty_cycle * 100.0, 1),
            "heater_power_w": self.get_power_w(),
            "dimensions_mm": f"{Units.m_to_mm(self.width_x):.0f}x{Units.m_to_mm(self.length_y):.0f}",
        }

HeatedBedAssembly = HeatedBed
