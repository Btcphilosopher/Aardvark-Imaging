"""
Stepper Motor, Electrical Power and Torque Loss Model.
"""

from dataclasses import dataclass
import math

@dataclass
class StepperMotor:
    """Stepper motor dynamic simulation."""
    axis_name: str
    step_angle_deg: float = 1.8
    microsteps: int = 16
    holding_torque_nm: float = 0.4
    rated_current_a: float = 1.2
    phase_resistance_ohm: float = 2.0
    steps_per_mm: float = 80.0
    steps_lost: int = 0
    current_step_count: int = 0
    temperature_k: float = 298.15

    @property
    def steps_per_m(self) -> float:
        return self.steps_per_mm * 1e3

    def calculate_power_w(self, is_active: bool = True) -> float:
        """Calculate electrical $I^2 R$ power dissipation."""
        if not is_active:
            return 0.1  # quiescent standby
        return 2 * (self.rated_current_a ** 2) * self.phase_resistance_ohm

    def simulate_steps(self, displacement_m: float, torque_demand_nm: float = 0.1) -> float:
        """Simulate microsteps and check for stall/step loss if torque demand exceeds capacity."""
        expected_steps = int(round(displacement_m * self.steps_per_m))
        if torque_demand_nm > self.holding_torque_nm * 0.9:
            # Step loss occurs under excessive dynamic load
            lost = int(expected_steps * 0.05)
            self.steps_lost += lost
            actual_steps = expected_steps - lost
        else:
            actual_steps = expected_steps

        self.current_step_count += actual_steps
        return actual_steps / self.steps_per_m
