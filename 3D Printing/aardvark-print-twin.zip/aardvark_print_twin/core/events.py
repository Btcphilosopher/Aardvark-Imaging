"""
Deterministic Event-Driven System for Simulation & Digital Twin.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, List, Callable, Type
import time

@dataclass
class SimulationEvent:
    """Base event class."""
    timestamp_s: float
    event_type: str
    details: Dict[str, Any] = field(default_factory=dict)

@dataclass
class PrintStarted(SimulationEvent):
    def __init__(self, timestamp_s: float, details: Dict[str, Any] = None):
        super().__init__(timestamp_s, "PrintStarted", details or {})

@dataclass
class LayerStarted(SimulationEvent):
    def __init__(self, timestamp_s: float, layer_index: int, z_height_m: float):
        super().__init__(timestamp_s, "LayerStarted", {"layer_index": layer_index, "z_height_m": z_height_m})

@dataclass
class MoveStarted(SimulationEvent):
    def __init__(self, timestamp_s: float, move_id: int, start_pos: List[float], end_pos: List[float]):
        super().__init__(timestamp_s, "MoveStarted", {"move_id": move_id, "start_pos": start_pos, "end_pos": end_pos})

@dataclass
class MoveCompleted(SimulationEvent):
    def __init__(self, timestamp_s: float, move_id: int, duration_s: float):
        super().__init__(timestamp_s, "MoveCompleted", {"move_id": move_id, "duration_s": duration_s})

@dataclass
class MaterialDeposited(SimulationEvent):
    def __init__(self, timestamp_s: float, mass_kg: float, volume_m3: float, energy_j: float):
        super().__init__(timestamp_s, "MaterialDeposited", {"mass_kg": mass_kg, "volume_m3": volume_m3, "energy_j": energy_j})

@dataclass
class TemperatureChanged(SimulationEvent):
    def __init__(self, timestamp_s: float, component: str, temp_k: float, target_temp_k: float):
        super().__init__(timestamp_s, "TemperatureChanged", {"component": component, "temp_k": temp_k, "target_temp_k": target_temp_k})

@dataclass
class LayerCompleted(SimulationEvent):
    def __init__(self, timestamp_s: float, layer_index: int, duration_s: float):
        super().__init__(timestamp_s, "LayerCompleted", {"layer_index": layer_index, "duration_s": duration_s})

@dataclass
class CoolingStarted(SimulationEvent):
    def __init__(self, timestamp_s: float, ambient_k: float):
        super().__init__(timestamp_s, "CoolingStarted", {"ambient_k": ambient_k})

@dataclass
class DefectDetected(SimulationEvent):
    def __init__(self, timestamp_s: float, defect_type: str, severity: float, confidence: float, location: List[float]):
        super().__init__(timestamp_s, "DefectDetected", {
            "defect_type": defect_type,
            "severity": severity,
            "confidence": confidence,
            "location": location,
        })

@dataclass
class FaultInjected(SimulationEvent):
    def __init__(self, timestamp_s: float, fault_name: str, parameters: Dict[str, Any]):
        super().__init__(timestamp_s, "FaultInjected", {"fault_name": fault_name, "parameters": parameters})

@dataclass
class PrintPaused(SimulationEvent):
    def __init__(self, timestamp_s: float, reason: str = ""):
        super().__init__(timestamp_s, "PrintPaused", {"reason": reason})

@dataclass
class PrintCompleted(SimulationEvent):
    def __init__(self, timestamp_s: float, total_time_s: float, success: bool = True):
        super().__init__(timestamp_s, "PrintCompleted", {"total_time_s": total_time_s, "success": success})


class EventBus:
    """Synchronous, deterministic event dispatcher for digital twin state machines."""

    def __init__(self):
        self._handlers: Dict[Type[SimulationEvent], List[Callable[[SimulationEvent], None]]] = {}
        self.history: List[SimulationEvent] = []

    def subscribe(self, event_type: Type[SimulationEvent], handler: Callable[[SimulationEvent], None]) -> None:
        if event_type not in self._handlers:
            self._handlers[event_type] = []
        self._handlers[event_type].append(handler)

    def publish(self, event: SimulationEvent) -> None:
        self.history.append(event)
        event_cls = type(event)
        if event_cls in self._handlers:
            for handler in self._handlers[event_cls]:
                handler(event)
        # Also notify general SimulationEvent subscribers
        if SimulationEvent in self._handlers and event_cls is not SimulationEvent:
            for handler in self._handlers[SimulationEvent]:
                handler(event)

    def clear(self) -> None:
        self.history.clear()
