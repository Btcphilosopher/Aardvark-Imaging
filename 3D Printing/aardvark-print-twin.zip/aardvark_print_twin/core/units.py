"""
Internal SI Unit Conversion and Validation System.
Internally, all physics calculations use strictly SI units:
- Length: Metres (m)
- Temperature: Kelvin (K)
- Time: Seconds (s)
- Mass: Kilograms (kg)
- Energy: Joules (J)
- Power: Watts (W)
- Pressure: Pascals (Pa)
- Velocity: Metres per second (m/s)
- Acceleration: Metres per second squared (m/s²)
"""

from typing import Union

class Units:
    """Convenience helper functions for explicit unit conversions without silent bugs."""

    # Length conversions
    @staticmethod
    def mm_to_m(mm: float) -> float:
        """Convert millimetres to metres."""
        return mm * 1e-3

    @staticmethod
    def m_to_mm(m: float) -> float:
        """Convert metres to millimetres."""
        return m * 1e3

    @staticmethod
    def um_to_m(um: float) -> float:
        """Convert micrometres (microns) to metres."""
        return um * 1e-6

    @staticmethod
    def m_to_um(m: float) -> float:
        """Convert metres to micrometres (microns)."""
        return m * 1e6

    # Temperature conversions
    @staticmethod
    def c_to_k(celsius: float) -> float:
        """Convert Celsius to Kelvin."""
        return celsius + 273.15

    @staticmethod
    def k_to_c(kelvin: float) -> float:
        """Convert Kelvin to Celsius."""
        return kelvin - 273.15

    # Velocity conversions
    @staticmethod
    def mm_s_to_m_s(mm_per_s: float) -> float:
        """Convert mm/s to m/s."""
        return mm_per_s * 1e-3

    @staticmethod
    def m_s_to_mm_s(m_per_s: float) -> float:
        """Convert m/s to mm/s."""
        return m_per_s * 1e3

    @staticmethod
    def mm_min_to_m_s(mm_per_min: float) -> float:
        """Convert G-code feedrate in mm/min to m/s."""
        return (mm_per_min / 60.0) * 1e-3

    @staticmethod
    def m_s_to_mm_min(m_per_s: float) -> float:
        """Convert m/s to G-code feedrate in mm/min."""
        return (m_per_s * 1e3) * 60.0

    # Acceleration conversions
    @staticmethod
    def mm_s2_to_m_s2(mm_per_s2: float) -> float:
        """Convert mm/s² to m/s²."""
        return mm_per_s2 * 1e-3

    @staticmethod
    def m_s2_to_mm_s2(m_per_s2: float) -> float:
        """Convert m/s² to mm/s²."""
        return m_per_s2 * 1e3

    # Mass conversions
    @staticmethod
    def g_to_kg(g: float) -> float:
        """Convert grams to kilograms."""
        return g * 1e-3

    @staticmethod
    def kg_to_g(kg: float) -> float:
        """Convert kilograms to grams."""
        return kg * 1e3

    @staticmethod
    def mg_to_kg(mg: float) -> float:
        """Convert milligrams to kilograms."""
        return mg * 1e-6

    # Energy conversions
    @staticmethod
    def j_to_wh(joules: float) -> float:
        """Convert Joules to Watt-hours."""
        return joules / 3600.0

    @staticmethod
    def wh_to_j(wh: float) -> float:
        """Convert Watt-hours to Joules."""
        return wh * 3600.0

    @staticmethod
    def j_to_kwh(joules: float) -> float:
        """Convert Joules to Kilowatt-hours."""
        return joules / 3.6e6

    # Pressure conversions
    @staticmethod
    def bar_to_pa(bar: float) -> float:
        """Convert Bar to Pascals."""
        return bar * 1e5

    @staticmethod
    def pa_to_bar(pa: float) -> float:
        """Convert Pascals to Bar."""
        return pa * 1e-5

    @staticmethod
    def mpa_to_pa(mpa: float) -> float:
        """Convert Megapascals to Pascals."""
        return mpa * 1e6

    @staticmethod
    def pa_to_mpa(pa: float) -> float:
        """Convert Pascals to Megapascals."""
        return pa * 1e-6

    # Volume conversions
    @staticmethod
    def mm3_to_m3(mm3: float) -> float:
        """Convert cubic millimetres to cubic metres."""
        return mm3 * 1e-9

    @staticmethod
    def m3_to_mm3(m3: float) -> float:
        """Convert cubic metres to cubic millimetres."""
        return m3 * 1e9

    @staticmethod
    def m3_s_to_mm3_s(m3_s: float) -> float:
        """Convert cubic metres per second to cubic millimetres per second."""
        return m3_s * 1e9

    @staticmethod
    def mm3_s_to_m3_s(mm3_s: float) -> float:
        """Convert cubic millimetres per second to cubic metres per second."""
        return mm3_s * 1e-9
