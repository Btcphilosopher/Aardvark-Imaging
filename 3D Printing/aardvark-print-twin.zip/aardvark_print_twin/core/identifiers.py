"""
Digital Thread and Provenance Identifiers.
Guarantees unbroken lineage from design to quality inspection.
"""

import uuid
import time
from dataclasses import dataclass, field
from typing import Dict, Any, Optional

@dataclass
class ProvenanceRecord:
    """Immutable digital thread record linking design, machine, material, and simulation."""
    design_id: str = "DES-DEFAULT-001"
    design_version: str = "1.0.0"
    machine_id: str = "AARDVARK-VP-220"
    machine_configuration_id: str = "CFG-220-STOCK"
    material_id: str = "MAT-PLA-AARDVARK-01"
    material_batch: str = "BATCH-2026-09A"
    toolpath_id: str = "TP-DEFAULT-001"
    toolpath_version: str = "1.0.0"
    simulation_id: str = field(default_factory=lambda: f"SIM-{uuid.uuid4().hex[:8].upper()}")
    simulation_version: str = "0.1.0"
    random_seed: int = 42
    calibration_version: str = "CALIB-V1"
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "design_id": self.design_id,
            "design_version": self.design_version,
            "machine_id": self.machine_id,
            "machine_configuration_id": self.machine_configuration_id,
            "material_id": self.material_id,
            "material_batch": self.material_batch,
            "toolpath_id": self.toolpath_id,
            "toolpath_version": self.toolpath_version,
            "simulation_id": self.simulation_id,
            "simulation_version": self.simulation_version,
            "random_seed": self.random_seed,
            "calibration_version": self.calibration_version,
            "timestamp": self.timestamp,
        }
