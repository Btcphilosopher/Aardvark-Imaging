"""
Canonical State Enums and Data Models for Aardvark Print Twin.
"""

from enum import Enum, auto
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List

class MachineStatus(str, Enum):
    IDLE = "IDLE"
    HOMING = "HOMING"
    HEATING = "HEATING"
    PRINTING = "PRINTING"
    PAUSED = "PAUSED"
    COOLDOWN = "COOLDOWN"
    FAULT = "FAULT"
    COMPLETED = "COMPLETED"
    FINISHED = "FINISHED"

PrinterState = MachineStatus

class SimulationStatus(str, Enum):
    READY = "READY"
    RUNNING = "RUNNING"
    PAUSED = "PAUSED"
    STEPPING = "STEPPING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    ABORTED = "ABORTED"

PrintJobState = SimulationStatus

class ComponentHealth(str, Enum):
    HEALTHY = "HEALTHY"
    DEGRADED = "DEGRADED"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"
    FAILED = "FAILED"

class MaterialPhase(str, Enum):
    EMPTY = "EMPTY"
    DEPOSITED = "DEPOSITED"
    HOT = "HOT"
    COOLING = "COOLING"
    SOLIDIFIED = "SOLIDIFIED"

class DefectType(str, Enum):
    NONE = "NONE"
    UNDER_EXTRUSION = "UNDER_EXTRUSION"
    OVER_EXTRUSION = "OVER_EXTRUSION"
    LAYER_SHIFT = "LAYER_SHIFT"
    OVERHEATING = "OVERHEATING"
    COOLING_FAILURE = "COOLING_FAILURE"
    FILAMENT_RUNOUT = "FILAMENT_RUNOUT"
    NOZZLE_CLOG = "NOZZLE_CLOG"
    BED_ADHESION_FAILURE = "BED_ADHESION_FAILURE"
    MOTION_ERROR = "MOTION_ERROR"
    THERMAL_SENSOR_FAILURE = "THERMAL_SENSOR_FAILURE"
    CAMERA_FAILURE = "CAMERA_FAILURE"
    BELT_SLIP = "BELT_SLIP"
    THERMAL_RUNAWAY = "THERMAL_RUNAWAY"

class FidelityLevel(int, Enum):
    LEVEL_0 = 0  # Kinematic only
    LEVEL_1 = 1  # Motion + Extrusion mass
    LEVEL_2 = 2  # Thermal lump solver
    LEVEL_3 = 3  # Thermal + Voxel geometry
    LEVEL_4 = 4  # Sensor-aware with realistic noise/bias
    LEVEL_5 = 5  # Closed-loop predictive state estimation

class SimulationMode(str, Enum):
    SIMULATION = "SIMULATION"
    LIVE = "LIVE"
    REPLAY = "REPLAY"
    FAST_FORWARD = "FAST_FORWARD"
    ANALYSIS = "ANALYSIS"
    PHYSICS_BASED = "PHYSICS_BASED"
    IDEAL = "IDEAL"

SystemMode = SimulationMode

@dataclass
class UncertaintyValue:
    """Represents a quantity with explicit error bounds and confidence level."""
    value: float
    lower_bound: float
    upper_bound: float
    confidence: float = 0.95
    unit: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "value": self.value,
            "lower_bound": self.lower_bound,
            "upper_bound": self.upper_bound,
            "confidence": self.confidence,
            "unit": self.unit,
        }

@dataclass
class Position4D:
    """Canonical 4-axis position in SI units (metres)."""
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    e: float = 0.0

    def to_list(self) -> List[float]:
        return [self.x, self.y, self.z, self.e]

    def to_mm_dict(self) -> Dict[str, float]:
        return {
            "x_mm": self.x * 1e3,
            "y_mm": self.y * 1e3,
            "z_mm": self.z * 1e3,
            "e_mm": self.e * 1e3,
        }
