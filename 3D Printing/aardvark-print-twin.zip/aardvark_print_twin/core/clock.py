"""
Simulation Clock for Digital Twin Orchestration.
Tracks simulated virtual time, wall clock time, and supports variable speed multipliers.
"""

import time
from typing import Optional

class SimulationClock:
    """High-precision virtual simulation clock."""

    def __init__(
        self,
        speed_multiplier: float = 1.0,
        initial_time: float = 0.0,
        dt_fixed: Optional[float] = None,
    ):
        self.simulation_time: float = initial_time  # In seconds
        self.wall_time_start: float = time.time()
        self.last_wall_update: float = self.wall_time_start
        self.speed_multiplier: float = speed_multiplier
        self.dt_fixed: Optional[float] = dt_fixed
        self.paused: bool = False
        self.running: bool = False
        self.timestep_count: int = 0

    @property
    def elapsed_wall_time(self) -> float:
        """Elapsed real-world wall clock time in seconds."""
        return time.time() - self.wall_time_start

    def start(self) -> None:
        """Start or resume clock progression."""
        self.running = True
        self.paused = False
        self.last_wall_update = time.time()

    def pause(self) -> None:
        """Pause clock progression."""
        self.paused = True
        self.running = False

    def resume(self) -> None:
        """Resume paused clock."""
        if self.paused:
            self.paused = False
            self.running = True
            self.last_wall_update = time.time()

    def reset(self, initial_time: float = 0.0) -> None:
        """Reset simulation and wall clocks."""
        self.simulation_time = initial_time
        self.wall_time_start = time.time()
        self.last_wall_update = self.wall_time_start
        self.timestep_count = 0
        self.paused = False
        self.running = False

    def advance(self, dt: float) -> float:
        """Advance simulation clock by exact physical delta dt in seconds."""
        if dt < 0:
            raise ValueError(f"Time cannot move backwards! Attempted dt={dt}")
        self.simulation_time += dt
        self.timestep_count += 1
        return self.simulation_time

    def set_speed_multiplier(self, multiplier: float) -> None:
        """Set speed multiplier (1x, 10x, 100x, 1000x)."""
        if multiplier <= 0:
            raise ValueError("Speed multiplier must be strictly positive")
        self.speed_multiplier = multiplier

    def to_dict(self) -> dict:
        """Serialize clock state."""
        return {
            "simulation_time_s": self.simulation_time,
            "elapsed_wall_time_s": self.elapsed_wall_time,
            "speed_multiplier": self.speed_multiplier,
            "timestep_count": self.timestep_count,
            "paused": self.paused,
            "running": self.running,
        }
