"""
Configuration Dataclasses and Defaults for Machine, Simulation, and Twin.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional
from aardvark_print_twin.core.state import FidelityLevel, SimulationMode
from aardvark_print_twin.core.units import Units

@dataclass
class MachineConfig:
    """Hardware specification and physical limits in SI units."""
    machine_id: str = "AARDVARK-VP-220"
    manufacturer: str = "Aardvark Fabrication"
    model: str = "Virtual Printer 220"
    kinematics: str = "Cartesian"
    
    # Build volume (m) -> default 220 x 220 x 250 mm
    build_volume_x: float = Units.mm_to_m(220.0)
    build_volume_y: float = Units.mm_to_m(220.0)
    build_volume_z: float = Units.mm_to_m(250.0)

    # Max velocities (m/s) -> 300 mm/s X/Y, 30 mm/s Z, 50 mm/s E
    max_velocity_x: float = Units.mm_s_to_m_s(300.0)
    max_velocity_y: float = Units.mm_s_to_m_s(300.0)
    max_velocity_z: float = Units.mm_s_to_m_s(30.0)
    max_velocity_e: float = Units.mm_s_to_m_s(50.0)

    # Max accelerations (m/s²) -> 3000 mm/s² X/Y, 500 mm/s² Z, 5000 mm/s² E
    max_accel_x: float = Units.mm_s2_to_m_s2(3000.0)
    max_accel_y: float = Units.mm_s2_to_m_s2(3000.0)
    max_accel_z: float = Units.mm_s2_to_m_s2(500.0)
    max_accel_e: float = Units.mm_s2_to_m_s2(5000.0)

    # Max jerk (m/s³) -> 10 m/s³ (or instantaneous velocity step 8 mm/s)
    max_jerk_xy: float = Units.mm_s_to_m_s(8.0)
    max_jerk_z: float = Units.mm_s_to_m_s(0.4)
    max_jerk_e: float = Units.mm_s_to_m_s(5.0)

    # Toolhead / Extruder
    nozzle_diameter: float = Units.mm_to_m(0.4)
    filament_diameter: float = Units.mm_to_m(1.75)
    hotend_max_temp_k: float = Units.c_to_k(300.0)
    bed_max_temp_k: float = Units.c_to_k(110.0)
    hotend_power_w: float = 40.0
    bed_power_w: float = 220.0
    electronics_idle_w: float = 15.0
    fan_max_power_w: float = 5.0
    motor_power_w_per_axis: float = 8.0

    # Backlash & mechanical imperfection tolerances
    backlash_x: float = 0.0
    backlash_y: float = 0.0
    belt_elasticity: float = 0.0  # 0 = rigid

@dataclass
class SimulationConfig:
    """Simulation control parameters."""
    fidelity: FidelityLevel = FidelityLevel.LEVEL_3
    mode: SimulationMode = SimulationMode.SIMULATION
    dt_default_s: float = 0.01  # 10 ms base timestep
    dt_min_s: float = 0.001
    dt_max_s: float = 0.1
    speed_multiplier: float = 1.0
    voxel_resolution_m: float = Units.mm_to_m(0.5)  # 0.5 mm voxels by default
    random_seed: int = 42
    ideal_sensors: bool = False
    enable_thermal_diffusion: bool = True
    enable_warping_prediction: bool = True
    checkpoint_interval_layers: int = 5
