"""
Digital Twin Model for Additive Manufacturing Machine.
Aggregates state, configuration, kinematics, physics, sensors, quality, and lifecycle history.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional
from aardvark_print_twin.core.units import Units
from aardvark_print_twin.core.state import (
    PrinterState,
    PrintJobState,
    SimulationMode,
    ComponentHealth,
    SystemMode,
)
from aardvark_print_twin.kinematics.motion import CartesianKinematics, MotionProfile
from aardvark_print_twin.thermal.extruder import HotendThermodynamics, HotendParams
from aardvark_print_twin.thermal.heated_bed import HeatedBedThermodynamics, HeatedBedParams
from aardvark_print_twin.materials.material import MaterialModel, get_synthetic_material
from aardvark_print_twin.geometry.voxel import VoxelGrid, Segment3D, Point3D
from aardvark_print_twin.thermal.thermal_model import ThermalSolver, ThermalSummary
from aardvark_print_twin.sensors.sensor_suite import VirtualSensorSuite, SensorReading
from aardvark_print_twin.faults.fault_engine import FaultEngine
from aardvark_print_twin.quality.quality_engine import QualityEngine, QualityAssessment
from aardvark_print_twin.energy.energy_model import EnergyModel, EnergySnapshot

@dataclass
class TwinTelemetrySample:
    """Full time-series snapshot of the physical machine and digital twin state."""
    timestamp_s: float
    state: PrinterState
    mode: SystemMode
    sim_mode: SimulationMode
    kinematic_pos: List[float]       # [x, y, z, e]
    kinematic_velocity: List[float]  # [vx, vy, vz, ve]
    hotend_temp_k: float
    bed_temp_k: float
    chamber_temp_k: float
    fan_speed_ratio: float
    total_power_w: float
    cumulative_energy_wh: float
    deposited_mass_g: float
    active_voxels: int
    quality_score: float
    sensors: Dict[str, Dict[str, Any]]
    active_faults: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "timestamp_s": round(self.timestamp_s, 2),
            "state": self.state.value,
            "mode": self.mode.value,
            "sim_mode": self.sim_mode.value,
            "pos_mm": [Units.m_to_mm(p) for p in self.kinematic_pos[:3]] + [Units.m_to_mm(self.kinematic_pos[3])],
            "hotend_temp_c": round(Units.k_to_c(self.hotend_temp_k), 2),
            "bed_temp_c": round(Units.k_to_c(self.bed_temp_k), 2),
            "chamber_temp_c": round(Units.k_to_c(self.chamber_temp_k), 2),
            "fan_speed_pct": round(self.fan_speed_ratio * 100.0, 1),
            "total_power_w": round(self.total_power_w, 2),
            "cumulative_energy_wh": round(self.cumulative_energy_wh, 3),
            "deposited_mass_g": round(self.deposited_mass_g, 3),
            "active_voxels": self.active_voxels,
            "quality_score": round(self.quality_score, 3),
            "sensors": self.sensors,
            "active_faults": self.active_faults,
        }


class DigitalTwin:
    """Complete multi-physics Digital Twin of an Additive Manufacturing Machine."""

    def __init__(
        self,
        name: str = "AARDVARK PRINT TWIN X-100",
        material_name: str = "AARDVARK PLA",
        sim_mode: SimulationMode = SimulationMode.PHYSICS_BASED,
        voxel_res_mm: float = 0.5,
    ):
        self.name = name
        self.sim_mode = sim_mode
        self.material = get_synthetic_material(material_name)
        
        # Subsystems
        self.kinematics = CartesianKinematics(MotionProfile())
        self.hotend = HotendThermodynamics(HotendParams())
        self.bed = HeatedBedThermodynamics(HeatedBedParams())
        self.voxel_grid = VoxelGrid(resolution_m=Units.mm_to_m(voxel_res_mm))
        self.thermal_solver = ThermalSolver(self.voxel_grid, self.material)
        self.sensors = VirtualSensorSuite(ideal_mode=(sim_mode == SimulationMode.IDEAL))
        self.fault_engine = FaultEngine()
        self.quality_engine = QualityEngine()
        self.energy_model = EnergyModel()
        
        # Environmental state
        self.chamber_temp_k = Units.c_to_k(24.0)
        self.current_time_s = 0.0
        self.state = PrinterState.IDLE
        self.mode = SystemMode.SIMULATION
        
        # Health indicators
        self.component_health: Dict[str, ComponentHealth] = {
            "hotend": ComponentHealth.HEALTHY,
            "bed": ComponentHealth.HEALTHY,
            "x_axis": ComponentHealth.HEALTHY,
            "y_axis": ComponentHealth.HEALTHY,
            "z_axis": ComponentHealth.HEALTHY,
            "extruder": ComponentHealth.HEALTHY,
        }
        
        self.telemetry_history: List[TwinTelemetrySample] = []
        self.quality_history: List[QualityAssessment] = []

    def set_material(self, material_name: str) -> None:
        self.material = get_synthetic_material(material_name)
        self.thermal_solver.mat = self.material

    def update_physics_step(
        self,
        dt: float,
        commanded_pos: List[float],
        feedrate_m_s: float,
        target_hotend_k: float,
        target_bed_k: float,
        fan_speed_ratio: float,
        layer_index: int = 0,
        is_extrusion: bool = False,
    ) -> TwinTelemetrySample:
        """Advance all multi-physics sub-models synchronously by dt."""
        self.current_time_s += dt
        
        # 1. Update Fault Engine
        active_faults = self.fault_engine.step(self.current_time_s)
        active_fault_names = [f.fault_type.value for f in active_faults]
        
        # 2. Update Kinematics
        kin_state = self.kinematics.step(dt, commanded_pos, feedrate_m_s)
        
        # 3. Update Hotend & Bed Thermal States
        hotend_state = self.hotend.step(dt, target_hotend_k, self.chamber_temp_k, fan_speed_ratio)
        bed_state = self.bed.step(dt, target_bed_k, self.chamber_temp_k)
        
        # Apply thermal run-away or heater fault if active
        if "THERMAL_RUNAWAY" in active_fault_names:
            self.hotend.current_temp_k += 5.0 * dt
            hotend_state.current_temp_k = self.hotend.current_temp_k
            self.component_health["hotend"] = ComponentHealth.CRITICAL

        # 4. Material Extrusion and Voxel Deposition
        if is_extrusion and kin_state.displacement_m > 1e-6:
            p_start = Point3D(kin_state.actual_position_m[0] - kin_state.velocity_m_s[0]*dt,
                              kin_state.actual_position_m[1] - kin_state.velocity_m_s[1]*dt,
                              kin_state.actual_position_m[2])
            p_end = Point3D(kin_state.actual_position_m[0], kin_state.actual_position_m[1], kin_state.actual_position_m[2])
            
            # Factor in nozzle clog fault
            extrusion_factor = 1.0
            if "NOZZLE_CLOG" in active_fault_names:
                extrusion_factor = 0.2
            elif "UNDER_EXTRUSION" in active_fault_names:
                extrusion_factor = 0.7
            elif "OVER_EXTRUSION" in active_fault_names:
                extrusion_factor = 1.35

            seg = Segment3D(
                start=p_start,
                end=p_end,
                width_m=Units.mm_to_m(0.4 * extrusion_factor),
                height_m=Units.mm_to_m(0.2),
                layer_index=layer_index,
                is_extrusion=True,
            )
            self.voxel_grid.deposit_segment(
                seg=seg,
                deposition_temp_k=hotend_state.current_temp_k,
                timestamp_s=self.current_time_s,
                density_kg_m3=self.material.density_kg_m3,
            )

        # 5. Spatial Thermal Diffusion Step
        thermal_summary = self.thermal_solver.step_diffusion(
            dt=dt,
            ambient_temp_k=self.chamber_temp_k,
            bed_temp_k=bed_state.current_temp_k,
            fan_speed_ratio=fan_speed_ratio,
        )

        # 6. Virtual Sensor Suite Sampling
        accel_xyz = [kin_state.acceleration_m_s2[0], kin_state.acceleration_m_s2[1], kin_state.acceleration_m_s2[2]]
        flow_rate_mm3_s = Units.m3_s_to_mm3_s(self.hotend.volumetric_flow_m3_s)
        
        # 7. Energy Consumption Step
        p_motors = (abs(kin_state.velocity_m_s[0]) + abs(kin_state.velocity_m_s[1]) + abs(kin_state.velocity_m_s[2])) * 30.0 + 8.0
        p_fans = fan_speed_ratio * 6.0
        energy_snap = self.energy_model.step(
            dt=dt,
            timestamp_s=self.current_time_s,
            hotend_power_w=hotend_state.electrical_power_w,
            bed_power_w=bed_state.electrical_power_w,
            motors_power_w=p_motors,
            fans_power_w=p_fans,
        )

        sensor_readings = self.sensors.sample_all(
            timestamp_s=self.current_time_s,
            hotend_temp_k=hotend_state.current_temp_k,
            bed_temp_k=bed_state.current_temp_k,
            chamber_temp_k=self.chamber_temp_k,
            accel_xyz=accel_xyz,
            flow_rate_mm3_s=flow_rate_mm3_s,
            power_w=energy_snap.instantaneous_power_w,
            dt=dt,
        )

        # 8. Real-Time Quality & Defect Detection
        pos_err = kin_state.position_error_m
        temp_err = Units.k_to_c(hotend_state.current_temp_k) - Units.k_to_c(target_hotend_k)
        ext_ratio = 1.0
        if "NOZZLE_CLOG" in active_fault_names:
            ext_ratio = 0.2
        elif "UNDER_EXTRUSION" in active_fault_names:
            ext_ratio = 0.7
        elif "OVER_EXTRUSION" in active_fault_names:
            ext_ratio = 1.35

        quality_eval = self.quality_engine.evaluate(
            current_time_s=self.current_time_s,
            position_error_m=pos_err,
            hotend_temp_error_k=temp_err,
            extrusion_ratio=ext_ratio,
            vibration_level=abs(kin_state.acceleration_m_s2[0]) + abs(kin_state.acceleration_m_s2[1]),
            layer_bond_score=thermal_summary.average_bond_score,
            active_fault_types=[f.fault_type for f in active_faults],
        )
        self.quality_history.append(quality_eval)

        sample = TwinTelemetrySample(
            timestamp_s=self.current_time_s,
            state=self.state,
            mode=self.mode,
            sim_mode=self.sim_mode,
            kinematic_pos=kin_state.actual_position_m,
            kinematic_velocity=kin_state.velocity_m_s,
            hotend_temp_k=hotend_state.current_temp_k,
            bed_temp_k=bed_state.current_temp_k,
            chamber_temp_k=self.chamber_temp_k,
            fan_speed_ratio=fan_speed_ratio,
            total_power_w=energy_snap.instantaneous_power_w,
            cumulative_energy_wh=energy_snap.cumulative_energy_wh,
            deposited_mass_g=self.voxel_grid.total_deposited_mass_kg * 1e3,
            active_voxels=self.voxel_grid.voxel_count,
            quality_score=quality_eval.overall_score,
            sensors={k: v.to_dict() for k, v in sensor_readings.items()},
            active_faults=active_fault_names,
        )
        self.telemetry_history.append(sample)
        return sample
