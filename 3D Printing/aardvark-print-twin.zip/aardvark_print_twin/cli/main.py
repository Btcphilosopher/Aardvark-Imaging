"""
CLI Interface for AARDVARK PRINT TWIN.
Allows running benchmark simulations, parsing G-code files, generating analytical reports, and inspecting materials.
"""

import sys
import argparse
import json
from aardvark_print_twin.digital_twin.twin import DigitalTwin, SimulationMode
from aardvark_print_twin.simulation.engine import SimulationEngine
from aardvark_print_twin.simulation.scenarios import BenchmarkScenarios, generate_calibration_cube_gcode
from aardvark_print_twin.analytics.metrics import AnalyticsEngine
from aardvark_print_twin.visualisation.machine_view import TerminalVisualizer
from aardvark_print_twin.materials.material import get_synthetic_material

def main():
    parser = argparse.ArgumentParser(
        description="AARDVARK PRINT TWIN: Digital Twin & Physics Simulation Engine for Additive Manufacturing"
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Command: run
    run_parser = subparsers.add_parser("run", help="Run simulation scenario or custom G-code")
    run_parser.add_argument("--material", type=str, default="AARDVARK PLA", help="Material profile name (PLA, PETG, ABS)")
    run_parser.add_argument("--gcode", type=str, help="Path to custom G-code file")
    run_parser.add_argument("--scenario", type=str, choices=["nominal", "clog", "overheating", "vibration"], default="nominal", help="Predefined scenario")
    run_parser.add_argument("--json", action="store_true", help="Output results as JSON")

    # Command: material
    mat_parser = subparsers.add_parser("material", help="Inspect synthetic material profile")
    mat_parser.add_argument("name", type=str, nargs="?", default="AARDVARK PLA", help="Material name")

    args = parser.parse_args()

    if args.command == "material":
        mat = get_synthetic_material(args.name)
        print(json.dumps(mat.to_dict(), indent=2))
        return

    scenario_type = getattr(args, "scenario", "nominal")
    material_name = getattr(args, "material", "AARDVARK PLA")

    if scenario_type == "clog":
        res = BenchmarkScenarios.nozzle_clog_scenario()
    elif scenario_type == "overheating":
        res = BenchmarkScenarios.overheating_scenario()
    elif scenario_type == "vibration":
        res = BenchmarkScenarios.high_speed_vibration_scenario()
    else:
        res = BenchmarkScenarios.nominal_print(material_name)

    kpi = AnalyticsEngine.evaluate_simulation(res)

    if getattr(args, "json", False):
        output = {
            "simulation_results": res.to_dict(),
            "kpis": kpi.to_dict(),
        }
        print(json.dumps(output, indent=2))
        return

    # Standard human-readable terminal output
    print("=" * 70)
    print(" 🚀 AARDVARK PRINT TWIN - AM DIGITAL TWIN PHYSICS SIMULATION")
    print("=" * 70)
    print(f"Executing Scenario: [{scenario_type.upper()}] | Material: [{material_name}]")

    print("\n--- SIMULATION COMPLETED ---")
    print(f"Total Sim Time : {res.total_time_s:.2f} s ({kpi.total_print_time_min:.2f} min)")
    print(f"Moves Executed : {res.total_moves_executed}")
    print(f"Deposited Mass : {res.deposited_mass_g:.3f} g")
    print(f"Active Voxels  : {res.total_voxels}")
    print(f"Energy Used    : {res.total_energy_wh:.3f} Wh ({kpi.energy_consumption_kwh:.4f} kWh)")
    print(f"Final Quality  : {res.final_quality_score:.3f} / 1.000")
    print(f"Health Index   : {kpi.machine_health_index:.3f}")
    print(f"Sustainability : Grade {kpi.sustainability_rating}")

    if res.detected_defects:
        print("\n⚠️ DETECTED ANOMALIES & DEFECTS:")
        for d in res.detected_defects:
            print(f"  - [{d['type']}] Severity: {d['severity']} @ t={d['timestamp_s']:.1f}s: {d['message']}")

    print("\n💡 OPTIMIZATION RECOMMENDATIONS:")
    for rec in kpi.recommendations:
        print(f"  • {rec}")
    print("=" * 70)


if __name__ == "__main__":
    main()
