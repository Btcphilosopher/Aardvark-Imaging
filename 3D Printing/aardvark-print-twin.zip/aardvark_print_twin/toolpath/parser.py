"""
Toolpath, Moves, G-Code Parser, and Kinematic Path Analyser.
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Tuple
import math
from aardvark_print_twin.core.units import Units

class MoveType(str, Enum):
    TRAVEL = "TRAVEL"
    EXTRUSION = "EXTRUSION"
    RETRACTION = "RETRACTION"
    PRIME = "PRIME"
    TOOL_CHANGE = "TOOL_CHANGE"
    DWELL = "DWELL"
    HOMING = "HOMING"

@dataclass
class ToolpathMove:
    """Individual discrete toolpath kinematic move."""
    move_id: int
    move_type: MoveType
    start_pos: List[float]       # [x, y, z, e] in metres
    end_pos: List[float]         # [x, y, z, e] in metres
    feedrate_m_s: float          # Commanded feedrate
    extrusion_delta_m: float     # Delta E (m)
    target_temperature_k: float  # Hotend target (K)
    bed_temperature_k: float     # Bed target (K)
    fan_speed_ratio: float       # 0.0 to 1.0
    layer_index: int = 0
    duration_s: float = 0.0
    is_relative_e: bool = True

    @property
    def displacement_xy_m(self) -> float:
        dx = self.end_pos[0] - self.start_pos[0]
        dy = self.end_pos[1] - self.start_pos[1]
        return math.sqrt(dx**2 + dy**2)

    @property
    def displacement_xyz_m(self) -> float:
        dx = self.end_pos[0] - self.start_pos[0]
        dy = self.end_pos[1] - self.start_pos[1]
        dz = self.end_pos[2] - self.start_pos[2]
        return math.sqrt(dx**2 + dy**2 + dz**2)


@dataclass
class ToolpathStatistics:
    total_moves: int = 0
    total_distance_m: float = 0.0
    travel_distance_m: float = 0.0
    extrusion_distance_m: float = 0.0
    total_extrusion_e_m: float = 0.0
    total_filament_volume_m3: float = 0.0
    estimated_time_s: float = 0.0
    layer_count: int = 0
    average_speed_m_s: float = 0.0
    max_speed_m_s: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_moves": self.total_moves,
            "total_distance_mm": Units.m_to_mm(self.total_distance_m),
            "travel_distance_mm": Units.m_to_mm(self.travel_distance_m),
            "extrusion_distance_mm": Units.m_to_mm(self.extrusion_distance_m),
            "filament_length_mm": Units.m_to_mm(self.total_extrusion_e_m),
            "filament_volume_cm3": self.total_filament_volume_m3 * 1e6,
            "estimated_print_time_s": round(self.estimated_time_s, 2),
            "estimated_print_time_min": round(self.estimated_time_s / 60.0, 2),
            "layer_count": self.layer_count,
            "average_speed_mm_s": Units.m_s_to_mm_s(self.average_speed_m_s),
            "max_speed_mm_s": Units.m_s_to_mm_s(self.max_speed_m_s),
        }


class GCodeParser:
    """Strict typed G-code parser converting standard commands into ToolpathMoves."""

    def __init__(self, filament_diameter_m: float = Units.mm_to_m(1.75)):
        self.filament_diameter_m = filament_diameter_m

    def parse_text(self, gcode_str: str) -> List[ToolpathMove]:
        lines = gcode_str.strip().split("\n")
        moves: List[ToolpathMove] = []
        
        current_pos = [0.0, 0.0, 0.0, 0.0]  # x, y, z, e
        feedrate = Units.mm_min_to_m_s(3000.0) # 50 mm/s default
        hotend_temp = Units.c_to_k(205.0)
        bed_temp = Units.c_to_k(60.0)
        fan_ratio = 0.0
        layer_idx = 0
        relative_e = True
        move_counter = 0

        for raw_line in lines:
            line = raw_line.split(";")[0].strip().upper()
            if not line:
                continue

            tokens = line.split()
            cmd = tokens[0]
            params: Dict[str, float] = {}
            for t in tokens[1:]:
                if len(t) > 1 and t[0] in "XYZFEISTP":
                    try:
                        params[t[0]] = float(t[1:])
                    except ValueError:
                        pass

            if cmd in ["G0", "G1"]:
                # Linear move
                target_x = Units.mm_to_m(params["X"]) if "X" in params else current_pos[0]
                target_y = Units.mm_to_m(params["Y"]) if "Y" in params else current_pos[1]
                target_z = Units.mm_to_m(params["Z"]) if "Z" in params else current_pos[2]
                
                # Check layer change if Z moves up
                if target_z > current_pos[2] + 1e-6:
                    layer_idx += 1

                if "F" in params:
                    feedrate = Units.mm_min_to_m_s(params["F"])

                delta_e = 0.0
                if "E" in params:
                    raw_e = Units.mm_to_m(params["E"])
                    delta_e = raw_e if relative_e else (raw_e - current_pos[3])
                    target_e = current_pos[3] + delta_e
                else:
                    target_e = current_pos[3]

                end_pos = [target_x, target_y, target_z, target_e]
                
                # Classify move type
                if delta_e > 1e-7:
                    m_type = MoveType.EXTRUSION
                elif delta_e < -1e-7:
                    m_type = MoveType.RETRACTION
                elif abs(target_x - current_pos[0]) < 1e-7 and abs(target_y - current_pos[1]) < 1e-7 and abs(target_z - current_pos[2]) < 1e-7:
                    m_type = MoveType.PRIME
                else:
                    m_type = MoveType.TRAVEL

                dx = math.sqrt((target_x - current_pos[0])**2 + (target_y - current_pos[1])**2 + (target_z - current_pos[2])**2)
                duration = (dx / feedrate) if (feedrate > 0 and dx > 0) else 0.01

                move = ToolpathMove(
                    move_id=move_counter,
                    move_type=m_type,
                    start_pos=list(current_pos),
                    end_pos=end_pos,
                    feedrate_m_s=feedrate,
                    extrusion_delta_m=delta_e,
                    target_temperature_k=hotend_temp,
                    bed_temperature_k=bed_temp,
                    fan_speed_ratio=fan_ratio,
                    layer_index=layer_idx,
                    duration_s=duration,
                )
                moves.append(move)
                move_counter += 1
                current_pos = list(end_pos)

            elif cmd == "G28":
                # Homing
                current_pos = [0.0, 0.0, 0.0, 0.0]
                moves.append(ToolpathMove(
                    move_id=move_counter,
                    move_type=MoveType.HOMING,
                    start_pos=[0.0, 0.0, 0.0, 0.0],
                    end_pos=[0.0, 0.0, 0.0, 0.0],
                    feedrate_m_s=Units.mm_s_to_m_s(50.0),
                    extrusion_delta_m=0.0,
                    target_temperature_k=hotend_temp,
                    bed_temperature_k=bed_temp,
                    fan_speed_ratio=fan_ratio,
                    layer_index=layer_idx,
                    duration_s=1.0,
                ))
                move_counter += 1

            elif cmd in ["M104", "M109"]: # Set hotend temperature
                if "S" in params:
                    hotend_temp = Units.c_to_k(params["S"])
            elif cmd in ["M140", "M190"]: # Set bed temperature
                if "S" in params:
                    bed_temp = Units.c_to_k(params["S"])
            elif cmd == "M106": # Set fan speed (0-255)
                val = params.get("S", 255.0)
                fan_ratio = max(0.0, min(1.0, val / 255.0))
            elif cmd == "M107": # Fan off
                fan_ratio = 0.0
            elif cmd == "M82": # Absolute E
                relative_e = False
            elif cmd == "M83": # Relative E
                relative_e = True

        return moves


class ToolpathAnalyser:
    """Pre-simulation statistical and geometric analysis of the toolpath."""

    @staticmethod
    def analyse(moves: List[ToolpathMove], filament_diameter_m: float = Units.mm_to_m(1.75)) -> ToolpathStatistics:
        stats = ToolpathStatistics()
        stats.total_moves = len(moves)
        
        speeds: List[float] = []
        layers = set()
        r = filament_diameter_m / 2.0

        for m in moves:
            layers.add(m.layer_index)
            d = m.displacement_xyz_m
            stats.total_distance_m += d
            if m.move_type == MoveType.EXTRUSION:
                stats.extrusion_distance_m += d
                stats.total_extrusion_e_m += max(0.0, m.extrusion_delta_m)
            elif m.move_type == MoveType.TRAVEL:
                stats.travel_distance_m += d

            stats.estimated_time_s += m.duration_s
            speeds.append(m.feedrate_m_s)

        stats.layer_count = len(layers)
        stats.total_filament_volume_m3 = math.pi * (r ** 2) * stats.total_extrusion_e_m
        if speeds:
            stats.average_speed_m_s = sum(speeds) / len(speeds)
            stats.max_speed_m_s = max(speeds)

        return stats
