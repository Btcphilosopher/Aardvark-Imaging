"""
Composite Quality Assessment, Defect Detection, and Machine Health Indexing.
Calculates multi-criteria score: $Q = w_g G + w_t T + w_e E + w_m M + w_s S + w_l L$.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional
from aardvark_print_twin.core.state import DefectType

@dataclass
class QualityAssessment:
    geometry_score: float = 1.0     # Dimensional fidelity & position error
    thermal_score: float = 1.0      # Temperature stability & cooling bounds
    extrusion_score: float = 1.0    # Flow accuracy & lack of under/over-fill
    motion_score: float = 1.0       # Acceleration/jerk stability & belt stretch
    surface_score: float = 1.0      # Smoothness & lack of banding
    layer_score: float = 1.0        # Inter-layer bond adhesion
    overall_score: float = 1.0      # Weighted composite score (0-1)
    confidence: float = 0.95
    detected_defects: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "geometry_score": round(self.geometry_score, 3),
            "thermal_score": round(self.thermal_score, 3),
            "extrusion_score": round(self.extrusion_score, 3),
            "motion_score": round(self.motion_score, 3),
            "surface_score": round(self.surface_score, 3),
            "layer_score": round(self.layer_score, 3),
            "overall_score": round(self.overall_score, 3),
            "confidence": round(self.confidence, 3),
            "defects_count": len(self.detected_defects),
            "detected_defects": self.detected_defects,
        }


class QualityEngine:
    """Evaluates physical ground truth vs sensor telemetry to compute quality & detect anomalies."""

    def __init__(
        self,
        weight_geometry: float = 0.20,
        weight_thermal: float = 0.20,
        weight_extrusion: float = 0.25,
        weight_motion: float = 0.15,
        weight_surface: float = 0.10,
        weight_layer: float = 0.10,
    ):
        self.wg = weight_geometry
        self.wt = weight_thermal
        self.we = weight_extrusion
        self.wm = weight_motion
        self.ws = weight_surface
        self.wl = weight_layer
        self.detected_defects: List[Dict[str, Any]] = []

    def evaluate(
        self,
        current_time_s: float,
        position_error_m: float,
        hotend_temp_error_k: float,
        extrusion_ratio: float, # actual / commanded
        vibration_level: float,
        layer_bond_score: float,
        active_fault_types: List[DefectType],
    ) -> QualityAssessment:
        # Geometry sub-score: penalize position errors > 50 microns
        g_score = max(0.0, 1.0 - min(1.0, (position_error_m * 1e6) / 200.0))
        
        # Thermal sub-score: penalize temp error > 5 K
        t_score = max(0.0, 1.0 - min(1.0, abs(hotend_temp_error_k) / 20.0))
        
        # Extrusion sub-score: penalize under/over extrusion
        e_score = max(0.0, 1.0 - min(1.0, abs(1.0 - extrusion_ratio) * 2.5))
        
        # Motion sub-score: penalize high vibrations
        m_score = max(0.0, 1.0 - min(1.0, vibration_level * 0.5))
        
        # Surface sub-score
        s_score = (g_score + e_score) / 2.0
        
        # Layer sub-score
        l_score = max(0.0, min(1.0, layer_bond_score))

        # Check for specific defects
        defects = []
        if extrusion_ratio < 0.85:
            defects.append({
                "type": DefectType.UNDER_EXTRUSION.value,
                "severity": round(1.0 - extrusion_ratio, 3),
                "timestamp_s": current_time_s,
                "message": f"Under-extrusion detected: {extrusion_ratio*100:.1f}% flow rate",
            })
        elif extrusion_ratio > 1.15:
            defects.append({
                "type": DefectType.OVER_EXTRUSION.value,
                "severity": round(extrusion_ratio - 1.0, 3),
                "timestamp_s": current_time_s,
                "message": f"Over-extrusion detected: {extrusion_ratio*100:.1f}% flow rate",
            })

        if position_error_m > 0.0005: # > 0.5 mm shift
            defects.append({
                "type": DefectType.LAYER_SHIFT.value,
                "severity": 0.9,
                "timestamp_s": current_time_s,
                "message": f"Severe layer shift detected: {position_error_m*1e3:.2f} mm",
            })

        if abs(hotend_temp_error_k) > 15.0:
            defects.append({
                "type": DefectType.OVERHEATING.value if hotend_temp_error_k > 0 else DefectType.COOLING_FAILURE.value,
                "severity": 0.8,
                "timestamp_s": current_time_s,
                "message": f"Thermal deviation: {hotend_temp_error_k:+.1f} °C",
            })

        self.detected_defects.extend(defects)

        # Composite score
        overall = (
            self.wg * g_score +
            self.wt * t_score +
            self.we * e_score +
            self.wm * m_score +
            self.ws * s_score +
            self.wl * l_score
        )

        return QualityAssessment(
            geometry_score=g_score,
            thermal_score=t_score,
            extrusion_score=e_score,
            motion_score=m_score,
            surface_score=s_score,
            layer_score=l_score,
            overall_score=overall,
            detected_defects=defects,
        )
