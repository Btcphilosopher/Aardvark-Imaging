# Aardvark Print Twin: System Architecture

## 1. Architectural Philosophy
"Do not simulate the picture of the printer. Simulate the state of the printer."

The Aardvark Print Twin is designed as the canonical simulation and digital thread backbone of the additive manufacturing workflow. It bridges the virtual design space and the physical fabrication layer through formal, decoupled state models.

```
       +-------------------------------------------------------------+
       |                     AARDVARK PRINT TWIN                     |
       |                                                             |
       |  +--------------------+             +--------------------+  |
       |  |   Toolpath Model   | ----------> |  Kinematic Engine  |  |
       |  +--------------------+             +--------------------+  |
       |            |                                  |             |
       |            v                                  v             |
       |  +--------------------+             +--------------------+  |
       |  |  Extrusion Physics | ----------> |   Voxel Geometry   |  |
       |  +--------------------+             +--------------------+  |
       |            |                                  |             |
       |            v                                  v             |
       |  +--------------------+             +--------------------+  |
       |  |   Thermal Solver   | <---------> |   Quality Engine   |  |
       |  +--------------------+             +--------------------+  |
       |            |                                  ^             |
       |            v                                  |             |
       |  +--------------------+             +--------------------+  |
       |  |   Virtual Sensor   | ----------> |  State Estimator   |  |
       |  +--------------------+             +--------------------+  |
       +-------------------------------------------------------------+
```

## 2. Core State Separation
To maintain strict digital twin rigor, the architecture partitions state into three mutually distinct layers:
1. **Ground Truth ($S_{true}$)**: The unobservable physical reality of the virtual machine and material.
2. **Observed Telemetry ($Z_{obs}$)**: The noisy, delayed, quantized readings provided by virtual sensors.
3. **Twin Estimation & Prediction ($\hat{S}_{twin}$)**: The internal state reconstructed via estimation filters (Kalman/EMA) and forward simulations.

## 3. Modules Overview
- `core/`: Simulation clock, SI unit conversions, event broker, and configuration.
- `machine/`: Physical component models (kinematics, axes, hotend, bed, chamber, steppers).
- `materials/`: Polymer rheology, thermal conductivity, glass transition, and shrinkage parameters.
- `geometry/`: Continuous vector math, polygon slicing, and adaptive discrete 3D voxel grids.
- `toolpath/`: Deterministic G-code parser and kinematic motion segmenter.
- `motion/`: S-curve / trapezoidal motion planner with jerk and acceleration limits.
- `thermal/`: Explicit finite-difference 3D heat diffusion solver with convection and radiation.
- `extrusion/`: Volumetric deposition and backpressure dynamics.
- `sensors/`: Synthetic sensor models injecting Gaussian noise, drift, bias, and dropouts.
- `quality/`: Defect detection, tolerance scoring, and structural integrity prediction.
- `energy/`: Power integration across all thermal and electro-mechanical consumers.
- `digital_twin/`: Canonical digital twin coordinator, history buffers, and provenance tracking.
