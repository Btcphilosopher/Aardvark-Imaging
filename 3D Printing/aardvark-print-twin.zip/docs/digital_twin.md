# Digital Twin Specification

## Canonical Digital Twin Object: `PrinterDigitalTwin`

The `PrinterDigitalTwin` instance encapsulates:
- `MachineModel`: Hardware kinematic limits, geometry, thermal inertia, heater wattages.
- `MaterialModel`: Thermophysical properties, melt flow index, viscosity, and expansion coefficient.
- `EnvironmentModel`: Ambient temperature, chamber temperature, humidity, and airflow velocity.
- `ToolpathModel`: Ordered list of movement commands, extrusion deltas, feedrates.
- `GeometryModel`: Spatial voxel volume tracking deposition state and coordinates.
- `ThermalModel`: 3D finite-difference temperature field grid.
- `MotionModel`: Multi-axis trajectory executor with jerk constraints.
- `SensorModel`: Virtual sensor array (temperature, encoder, accelerometer, camera, power).
- `QualityModel`: Multi-criteria evaluator for surface, adhesion, dimensional fidelity.
- `EnergyModel`: Integrator for instantaneous power and cumulative Joules.
- `SimulationClock`: Virtual timekeeper with variable speed multiplier ($1\times, 10\times, 100\times, 1000\times$).
- `FaultState`: Active and historical defect/anomaly injections.
- `ProvenanceRecord`: Immutable thread connecting design, machine config, material batch, and toolpath.

## Digital Thread Provenance
Every simulation artifact is stamped with:
```json
{
  "design_id": "DES-7821-CUBE",
  "design_version": "1.0.4",
  "machine_id": "AARDVARK-VP-220",
  "machine_configuration_id": "CFG-SINGLE-0.4-NOZZLE",
  "material_id": "MAT-PLA-AARDVARK-01",
  "material_batch": "BATCH-2026-09A",
  "toolpath_id": "TP-CUBE-20MM",
  "toolpath_version": "2.1.0",
  "simulation_id": "SIM-88329-UUID",
  "random_seed": 42,
  "calibration_version": "CALIB-V1",
  "timestamp": "2026-09-13T12:00:00Z"
}
```
