# Physics, Motion & Thermal Models

## 1. Machine Model (`docs/machine_model.md`)
Reference Machine: **AARDVARK VIRTUAL PRINTER 220**
- Build volume: $220 \times 220 \times 250\text{ mm}$ ($0.22 \times 0.22 \times 0.25\text{ m}$)
- Toolhead: Single direct-drive extruder, $0.4\text{ mm}$ brass nozzle
- Kinematics: Cartesian (X, Y, Z, E) with pluggable CoreXY/Delta/SCARA interfaces
- Heaters: $40\text{ W}$ hotend ($300^\circ\text{C}$ max), $220\text{ W}$ heated bed ($110^\circ\text{C}$ max)
- Steppers: NEMA 17, $1.8^\circ$ step angle, 16x microstepping

## 2. Motion Model (`docs/motion_model.md`)
- Trajectory: S-curve and trapezoidal velocity profiles with configurable maximum acceleration and jerk constraints.
- Multi-Axis Synchronization: Interpolation across 4D $(x, y, z, e)$ maintaining constant feedrates on toolpath linear/arc vectors.
- Machine Imperfections: Configurable backlash ($B_x, B_y$), belt elasticity ($k_{belt}$), and microstepping quantization.

## 3. Thermal Model (`docs/thermal_model.md`)
- 3D Finite-Difference Heat Equation:
  $$\rho c_p \frac{\partial T}{\partial t} = \nabla \cdot (k \nabla T) + q_{deposition} - q_{convection} - q_{radiation}$$
- Boundary Conditions:
  - Heated bed conduction: $T(z=0) = T_{bed}$
  - Convective cooling: $q_{conv} = h A (T - T_{chamber})$
  - Radiation loss: $q_{rad} = \epsilon \sigma A (T^4 - T_{ambient}^4)$
- Thermal Enthalpy Injection upon deposition:
  $$Q_{dep} = m_{voxel} \cdot c_p \cdot (T_{nozzle} - T_{local})$$

## 4. Extrusion Model (`docs/extrusion_model.md`)
- Volumetric Deposition Rate: $\dot{V} = v_{feed} \cdot h_{layer} \cdot w_{line}$
- Filament Consumption: $L_{filament} = \frac{V_{deposited}}{\pi r_{filament}^2}$
- Pressure Dynamic: Poiseuille backpressure $\Delta P \approx \frac{8 \mu L \dot{V}}{\pi r_{nozzle}^4}$ with temperature-dependent polymer viscosity $\mu(T)$.

## 5. Quality & Warping Model (`docs/quality_model.md`)
- Thermal Strain: $\epsilon_{thermal} = \alpha \cdot (T_{deposition} - T_{bed})$
- Inter-Layer Bond Quality:
  $$\text{Bond Score} = \min\left(1.0, \frac{T_{interface} - T_g}{T_{melt} - T_g} \cdot \left(\frac{t_{contact}}{\tau_{reptation}}\right)^{0.25}\right)$$
- Composite Quality Metric:
  $$Q = w_g G + w_t T + w_e E + w_m M + w_s S + w_l L$$
