# AARDVARK PRINT TWIN
**Digital Twin and Physics-Based Simulator for Additive Manufacturing Machines**

Part of the **Aardvark Imaging / Aardvark Fabrication** ecosystem.

AARDVARK PRINT TWIN is a computational digital twin for fused filament fabrication (FFF/FDM) and additive manufacturing processes.

```
DESIGN → TOOLPATH → VIRTUAL MACHINE → VIRTUAL MATERIAL → DEPOSITION → THERMAL STATE → GEOMETRIC STATE → SENSOR OBSERVATION → QUALITY STATE → MACHINE STATE → DIGITAL TWIN
```

---

## 1. Key Capabilities

- **Canonical Digital Twin**: Synchronized state representation maintaining ground-truth physical simulation vs observed telemetry vs state estimation.
- **SI-Unit Internal Physics**: All calculations run in SI units ($m, K, s, kg, J, W, Pa, m/s, m/s^2$) with zero silent unit conversion errors.
- **Kinematic & Trajectory Engine**: S-curve / trapezoidal acceleration, jerk limits, Cartesian/CoreXY forward/inverse kinematics, and axis sync.
- **Thermal & Heat Transfer Solver**: Finite-difference 3D heat diffusion with deposition enthalpy, bed conduction, convective cooling, and radiation loss.
- **Extrusion & Volumetric Model**: Viscous flow approximation, nozzle backpressure, line-width geometry deposition.
- **Voxel Engine & Geometry Evolution**: Adaptive resolution 3D voxel grid tracking material phase, temperature history, and confidence.
- **Warping & Inter-Layer Adhesion**: Empirical thermal strain estimation ($\epsilon = \alpha \Delta T$) and polymer reptation bond scoring.
- **Virtual Sensor Suite**: Temperature thermocouples, 3-axis accelerometer, optical filament sensor, encoder, power monitor, and camera observation with configurable Gaussian noise, bias, drift, and latency.
- **Deterministic Fault Injection**: Under/over-extrusion, layer shifts, thermal runaway/cooling failures, nozzle clogs, bed adhesion detachment, and sensor dropouts.
- **Quality & Health Indexing**: Composite multi-criteria scoring $Q = \sum w_i S_i$ and predictive machine health assessment.
- **What-If & Parameter Optimization**: Multi-scenario sweeps across nozzle temperatures, speeds, and chamber conditions.
- **Digital Thread Provenance**: Unbroken provenance tracking (design_id, machine_id, toolpath_id, material_batch, simulation_id, random_seed).

---

## 2. Quickstart

### Run Master Demonstration
```bash
python examples/aardvark_print_twin_demo.py
```

### Run CLI
```bash
python -m aardvark_print_twin.cli.main --help
python -m aardvark_print_twin.cli.main run --scenario scenarios/cube_pla.json --output report.json
```

### Run Test Suite
```bash
python -m unittest discover tests
```

---

## 3. Architecture Overview

```
aardvark_print_twin/
├── core/             # Simulation clock, events, canonical state, SI units, identifiers
├── machine/          # Axes, motors, kinematics, hotend, bed, chamber, limits
├── materials/        # Rheology, thermal properties, shrinkage, polymer definitions (PLA, PETG, ABS)
├── geometry/         # 3D points, vectors, segments, polygons, meshes, voxel grid
├── toolpath/         # Typed G-code parser (G0/G1/G2/G3/G28/M104/M140/etc.), move planner, statistics
├── motion/           # Trajectory generation, jerk constraints, velocity profiling, error models
├── thermal/          # 3D voxel heat equation solver, deposition heat, convection, radiation
├── extrusion/        # Volumetric deposition, nozzle flow, backpressure model
├── environment/      # Chamber, ambient airflow, humidity, pressure
├── sensors/          # Virtual sensors with realistic noise, bias, drift, latency
├── perception/       # Synthetic camera inspection, layer defect detection
├── quality/          # Composite quality engine, defect identification, tolerances
├── energy/           # Power dissipation model (heaters, steppers, fans, logic)
├── faults/           # Fault injection engine (under-extrusion, layer shift, clog, etc.)
├── simulation/       # Discrete-event engine, adaptive timesteps, checkpoints, replay
├── digital_twin/     # Canonical PrinterDigitalTwin, history ring buffers, snapshots, provenance
├── calibration/      # Machine, thermal, extrusion, and sensor calibration routines
├── analytics/        # Statistical summaries, predictions, comparison engine
├── storage/          # Database schemas, repositories, snapshot persistence
├── api/              # FastAPI REST endpoints for simulation control & telemetry
├── visualisation/    # Python ASCII/VT100, 2D slice, heatmap, and 3D plotter adapters
└── cli/              # Command-line interface
```
