"""
Standalone Demo Script showcasing AARDVARK PRINT TWIN features:
- Multi-physics simulation (kinematics, heat diffusion, voxel activation)
- Virtual sensor telemetry streaming
- Dynamic fault injection
- Analytical KPI scoring
"""

import sys
import os
import json

# Ensure parent directory is in python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from aardvark_print_twin.digital_twin.twin import DigitalTwin, SimulationMode
from aardvark_print_twin.simulation.engine import SimulationEngine
from aardvark_print_twin.simulation.scenarios import generate_calibration_cube_gcode
from aardvark_print_twin.analytics.metrics import AnalyticsEngine
from aardvark_print_twin.visualisation.machine_view import TerminalVisualizer
from aardvark_print_twin.core.state import DefectType

def run_demo():
    print("=" * 80)
    print("  AARDVARK PRINT TWIN: Additive Manufacturing Digital Twin Platform Demo")
    print("=" * 80)

    # 1. Instantiate Digital Twin & Simulation Engine
    twin = DigitalTwin(name="AARDVARK TWIN DEMO-1", material_name="AARDVARK PLA", sim_mode=SimulationMode.PHYSICS_BASED)
    engine = SimulationEngine(twin=twin)

    # 2. Inject a simulated nozzle under-extrusion fault midway
    twin.fault_engine.inject(
        fault_type=DefectType.UNDER_EXTRUSION,
        start_time_s=1.5,
        duration_s=4.0,
        severity=0.6,
    )

    print(f"\n[1] Digital Twin Initialized: {twin.name}")
    print(f"    Material: {twin.material.name} (Density: {twin.material.density_kg_m3} kg/m³)")
    print(f"    Active Fault Injected: UNDER_EXTRUSION @ t=1.5s (duration 4.0s)")

    # 3. Generate benchmark G-Code
    gcode = generate_calibration_cube_gcode(size_mm=8.0, layer_height_mm=0.2)
    print("\n[2] Executing Multi-Physics Simulation...")

    # Define real-time step callback for terminal preview
    step_count = 0
    def on_step(sample):
        nonlocal step_count
        step_count += 1
        if step_count % 10 == 0:
            print(TerminalVisualizer.render_dashboard_banner(sample))

    result = engine.run_gcode(gcode, on_step_callback=on_step, max_moves=25)

    # 4. Render 2D Layer Cross-Section Voxel Map
    print("\n[3] 2D Thermal Voxel Map (Layer 1):")
    print(TerminalVisualizer.render_layer_slice(twin, layer_index=1, width=32, height=12))

    # 5. Evaluate Analytics & KPIs
    kpi = AnalyticsEngine.evaluate_simulation(result)

    print("\n[4] KPI Analytical Summary:")
    print(json.dumps(kpi.to_dict(), indent=2))

    print("\n[5] Detected Defects Log:")
    for defect in result.detected_defects:
        print(f"   ⚠️  [{defect['type']}] t={defect['timestamp_s']:.2f}s: {defect['message']}")

    print("\n" + "=" * 80)
    print("  DEMO EXECUTION SUCCESSFULLY COMPLETED!")
    print("=" * 80)


if __name__ == "__main__":
    run_demo()
