import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';

const execFileAsync = promisify(execFile);
const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

/**
 * REST API Endpoints for AARDVARK PRINT TWIN Python Physics Backend
 */
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', version: '0.1.0', engine: 'Aardvark AM Digital Twin' });
});

app.get('/api/materials', async (req, res) => {
  try {
    const { stdout } = await execFileAsync('python3', ['-m', 'aardvark_print_twin.cli.main', 'material', 'PLA']);
    const pla = JSON.parse(stdout);
    const petg = { ...pla, name: 'AARDVARK PETG', material_id: 'MAT-PETG-02', recommended_nozzle_c: 240, recommended_bed_c: 80 };
    const abs = { ...pla, name: 'AARDVARK ABS', material_id: 'MAT-ABS-03', recommended_nozzle_c: 250, recommended_bed_c: 105 };
    res.json([pla, petg, abs]);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: message });
  }
});

app.post('/api/simulation/run', async (req, res) => {
  try {
    const scenario = req.body.scenario || 'nominal';
    const material = req.body.material || 'AARDVARK PLA';
    const { stdout } = await execFileAsync('python3', [
      '-m',
      'aardvark_print_twin.cli.main',
      'run',
      '--scenario',
      scenario,
      '--material',
      material,
      '--json',
    ]);
    const cleanOutput = stdout.trim();
    const jsonMatch = cleanOutput.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error('No valid JSON object found in simulation output.');
    }
    const data = JSON.parse(jsonMatch[0]);
    res.json(data);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: message || 'Failed to execute simulation' });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
