import { Component, OnInit, signal, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { MatIconModule } from '@angular/material/icon';

export interface TelemetrySample {
  timestamp_s: number;
  state: string;
  mode: string;
  sim_mode: string;
  pos_mm: number[];
  hotend_temp_c: number;
  bed_temp_c: number;
  chamber_temp_c: number;
  fan_speed_pct: number;
  total_power_w: number;
  cumulative_energy_wh: number;
  deposited_mass_g: number;
  active_voxels: number;
  quality_score: number;
  sensors: Record<string, number | string | boolean>;
  active_faults: string[];
}

export interface DefectItem {
  type: string;
  severity: number;
  timestamp_s: number;
  message: string;
}

export interface KPIReport {
  overall_quality_score: number;
  total_print_time_min: number;
  energy_consumption_kwh: number;
  material_deposited_g: number;
  volumetric_efficiency_pct: number;
  machine_health_index: number;
  sustainability_rating: string;
  recommendations: string[];
}

export interface SimulationRunResult {
  simulation_results: {
    total_time_s: number;
    total_moves_executed: number;
    final_quality_score: number;
    total_energy_wh: number;
    deposited_mass_g: number;
    total_voxels: number;
    detected_defects_count: number;
    detected_defects: DefectItem[];
    telemetry_samples: TelemetrySample[];
    toolpath_stats: Record<string, number>;
  };
  kpis: KPIReport;
}

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  templateUrl: './dashboard.html',
})
export class DashboardComponent implements OnInit {
  private http = inject(HttpClient);

  selectedScenario = signal<string>('nominal');
  selectedMaterial = signal<string>('AARDVARK PLA');
  activeTab = signal<'overview' | 'spatial' | 'telemetry' | 'defects' | 'gcode'>('overview');
  
  isLoading = signal<boolean>(false);
  simulationResult = signal<SimulationRunResult | null>(null);

  // Playback state for stepping through telemetry
  playbackIndex = signal<number>(0);
  isPlaying = signal<boolean>(false);
  private timerId: ReturnType<typeof setInterval> | null = null;

  currentSample = computed(() => {
    const res = this.simulationResult();
    const samples = res?.simulation_results?.telemetry_samples;
    if (!samples || samples.length === 0) return null;
    const idx = Math.min(this.playbackIndex(), samples.length - 1);
    return samples[idx];
  });

  totalSamples = computed(() => {
    const res = this.simulationResult();
    return res?.simulation_results?.telemetry_samples?.length || 0;
  });

  kpi = computed(() => this.simulationResult()?.kpis || null);
  defects = computed(() => this.simulationResult()?.simulation_results?.detected_defects || []);

  scenarios = [
    { id: 'nominal', name: 'Nominal Benchmark', desc: 'Optimal print process execution under PLA baseline parameters.' },
    { id: 'clog', name: 'Extruder Clog Fault', desc: 'Simulates 80% flow restriction due to partial nozzle blockage.' },
    { id: 'overheating', name: 'Thermal Runaway', desc: 'Simulates PID thermal overshoot exceeding Tg bounds.' },
    { id: 'vibration', name: 'Belt Slip Vibration', desc: 'High-speed directional acceleration causing positional drift.' },
  ];

  materials = ['AARDVARK PLA', 'AARDVARK PETG', 'AARDVARK ABS'];

  ngOnInit() {
    this.runSimulation();
  }

  runSimulation() {
    this.isLoading.set(true);
    this.pausePlayback();
    
    this.http.post<SimulationRunResult>('/api/simulation/run', {
      scenario: this.selectedScenario(),
      material: this.selectedMaterial(),
    }).subscribe({
      next: (data) => {
        this.simulationResult.set(data);
        const count = data?.simulation_results?.telemetry_samples?.length || 0;
        this.playbackIndex.set(count > 0 ? count - 1 : 0);
        this.isLoading.set(false);
      },
      error: (err) => {
        console.error('Simulation run error:', err);
        this.isLoading.set(false);
      }
    });
  }

  selectScenario(id: string) {
    this.selectedScenario.set(id);
    this.runSimulation();
  }

  selectMaterial(mat: string) {
    this.selectedMaterial.set(mat);
    this.runSimulation();
  }

  onMaterialChange(event: Event) {
    const val = (event.target as HTMLSelectElement).value;
    this.selectMaterial(val);
  }

  togglePlayback() {
    if (this.isPlaying()) {
      this.pausePlayback();
    } else {
      this.startPlayback();
    }
  }

  startPlayback() {
    if (!this.totalSamples()) return;
    if (this.playbackIndex() >= this.totalSamples() - 1) {
      this.playbackIndex.set(0);
    }
    this.isPlaying.set(true);
    this.timerId = setInterval(() => {
      if (this.playbackIndex() < this.totalSamples() - 1) {
        this.playbackIndex.update(i => i + 1);
      } else {
        this.pausePlayback();
      }
    }, 150);
  }

  pausePlayback() {
    this.isPlaying.set(false);
    if (this.timerId) {
      clearInterval(this.timerId);
      this.timerId = null;
    }
  }

  seek(event: Event) {
    const val = Number((event.target as HTMLInputElement).value);
    this.playbackIndex.set(val);
  }

  getQualityClass(score: number): string {
    if (score >= 0.9) return 'text-emerald-600 bg-emerald-50 border-emerald-200';
    if (score >= 0.75) return 'text-amber-600 bg-amber-50 border-amber-200';
    return 'text-rose-600 bg-rose-50 border-rose-200';
  }

  getSeverityBadge(sev: number): string {
    if (sev >= 0.8) return 'bg-rose-500 text-white';
    if (sev >= 0.5) return 'bg-amber-500 text-white';
    return 'bg-blue-500 text-white';
  }
}
