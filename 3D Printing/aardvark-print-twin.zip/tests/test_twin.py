"""
Unit tests for AARDVARK PRINT TWIN Python simulation package.
"""

import unittest
from aardvark_print_twin.core.units import Units
from aardvark_print_twin.materials.material import get_synthetic_material, MaterialModel
from aardvark_print_twin.kinematics.motion import CartesianKinematics, MotionProfile
from aardvark_print_twin.thermal.extruder import HotendThermodynamics, HotendParams
from aardvark_print_twin.thermal.heated_bed import HeatedBedThermodynamics
from aardvark_print_twin.geometry.voxel import VoxelGrid, Segment3D, Point3D
from aardvark_print_twin.sensors.sensor_suite import VirtualSensorSuite
from aardvark_print_twin.digital_twin.twin import DigitalTwin, SimulationMode
from aardvark_print_twin.simulation.engine import SimulationEngine
from aardvark_print_twin.simulation.scenarios import generate_calibration_cube_gcode


class TestUnits(unittest.TestCase):
    def test_unit_conversions(self):
        self.assertAlmostEqual(Units.mm_to_m(100.0), 0.1)
        self.assertAlmostEqual(Units.m_to_mm(0.1), 100.0)
        self.assertAlmostEqual(Units.c_to_k(20.0), 293.15)
        self.assertAlmostEqual(Units.k_to_c(293.15), 20.0)
        self.assertAlmostEqual(Units.mm_s_to_m_s(60.0), 0.06)
        self.assertAlmostEqual(Units.mm_min_to_m_s(3600.0), 0.06)


class TestMaterials(unittest.TestCase):
    def test_material_retrieval(self):
        pla = get_synthetic_material("PLA")
        self.assertEqual(pla.name, "AARDVARK PLA")
        petg = get_synthetic_material("PETG")
        self.assertEqual(petg.name, "AARDVARK PETG")
        abs_mat = get_synthetic_material("ABS")
        self.assertEqual(abs_mat.name, "AARDVARK ABS")


class TestKinematics(unittest.TestCase):
    def test_cartesian_stepping(self):
        kin = CartesianKinematics(MotionProfile(max_velocity_m_s=0.1, max_acceleration_m_s2=2.0))
        target = [0.05, 0.05, 0.0, 0.001]
        state = kin.step(0.1, target, 0.1)
        self.assertGreater(state.displacement_m, 0.0)
        self.assertEqual(len(state.actual_position_m), 4)


class TestHotendAndBed(unittest.TestCase):
    def test_hotend_heating(self):
        hotend = HotendThermodynamics(HotendParams())
        initial_temp = hotend.current_temp_k
        state = hotend.step(1.0, target_temp_k=Units.c_to_k(200.0), ambient_temp_k=Units.c_to_k(20.0))
        self.assertGreater(state.current_temp_k, initial_temp)
        self.assertGreater(state.electrical_power_w, 0.0)

    def test_bed_heating(self):
        bed = HeatedBedThermodynamics()
        initial_temp = bed.current_temp_k
        state = bed.step(1.0, target_temp_k=Units.c_to_k(60.0), ambient_temp_k=Units.c_to_k(20.0))
        self.assertGreater(state.current_temp_k, initial_temp)


class TestVoxelGrid(unittest.TestCase):
    def test_segment_deposition(self):
        grid = VoxelGrid(resolution_m=0.001)
        seg = Segment3D(
            start=Point3D(0.0, 0.0, 0.0),
            end=Point3D(0.01, 0.0, 0.0),
            width_m=0.0004,
            height_m=0.0002,
            is_extrusion=True,
        )
        coords = grid.deposit_segment(seg, deposition_temp_k=473.15, timestamp_s=0.0, density_kg_m3=1240.0)
        self.assertGreater(len(coords), 0)
        self.assertGreater(grid.voxel_count, 0)
        self.assertGreater(grid.total_deposited_mass_kg, 0.0)


class TestDigitalTwinAndSimulation(unittest.TestCase):
    def test_twin_simulation_run(self):
        twin = DigitalTwin(material_name="AARDVARK PLA", sim_mode=SimulationMode.PHYSICS_BASED)
        engine = SimulationEngine(twin=twin)
        gcode = generate_calibration_cube_gcode(size_mm=4.0, layer_height_mm=0.2)
        result = engine.run_gcode(gcode, max_moves=10)
        self.assertGreater(result.total_moves_executed, 0)
        self.assertGreater(result.final_quality_score, 0.0)
        self.assertGreaterEqual(len(result.telemetry_samples), 0)


if __name__ == "__main__":
    unittest.main()
