import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import {GoogleGenAI} from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());
const angularApp = new AngularNodeAppEngine();

// Lazy initialization of Gemini client
let aiClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI | null {
  const apiKey = process.env['GEMINI_API_KEY'];
  if (!apiKey) {
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

/**
 * Adidas Additive Manufacturing Intelligence API
 */
app.post('/api/manufacturing-ai', async (req, res) => {
  try {
    const { prompt, factoryContext, conversationHistory } = req.body;
    const ai = getGenAI();

    if (!ai) {
      // Fallback response if API key is not configured yet
      return res.json({
        success: true,
        source: 'local_expert_engine',
        text: generateLocalManufacturingResponse(prompt),
      });
    }

    const historySummary = Array.isArray(conversationHistory) && conversationHistory.length > 0
      ? `\nPrior Session Dialogue:\n${conversationHistory.map((c: { role: string; text: string }) => `${c.role}: ${c.text}`).join('\n')}`
      : '';

    const systemInstruction = `You are ADIDAS MANUFACTURING INTELLIGENCE (AMI), the premier AI engineering copilot embedded inside Adidas Additive Manufacturing Digital Operating System (Industry 4.0).
You assist Adidas footwear engineers, materials scientists, factory managers, and quality inspectors.
Your tone is precise, technically rigorous, German engineering-inspired, constructive, and concise.

Core domain knowledge:
- 3D Footwear Additive Technologies: Carbon Digital Light Synthesis (DLS), Selective Laser Sintering (SLS), Multi Jet Fusion (MJF), Supercritical Elastomer Foaming.
- Footwear architectures: 4DFWD lattice forward-propulsion kinematics, Adizero Prime X energy rods, Futurecraft 4D midsoles, Ultrabooast Light.
- Materials: EPU 41, EPU 44, Forward AM TPU 88A Pro, Bio-TPU 75B Castor-based, Recycled Ocean TPU, CNT-TPU nanocomposites.
- Root-cause diagnostics: thermal variance, laser scan deviations, resin viscosity drift, layer warpage, lattice pore deformation.
- DO NOT claim to have physically repaired or physically operated machines. Provide diagnosis, engineering calculations, root-cause probability, and explicit RECOMMENDED ACTIONS.

Current Factory Live Context:
${JSON.stringify(factoryContext || {}, null, 2)}${historySummary}
`;

    const chat = ai.chats.create({
      model: 'gemini-3.8-flash',
      config: {
        systemInstruction,
        temperature: 0.3,
      },
    });

    const response = await chat.sendMessage({
      message: prompt,
    });

    return res.json({
      success: true,
      source: 'gemini-3.8-flash',
      text: response.text || 'Analysis complete with no specific deviations.',
    });
  } catch (error: unknown) {
    console.error('Manufacturing AI error:', error);
    return res.json({
      success: true,
      source: 'local_expert_engine_fallback',
      text: generateLocalManufacturingResponse(req.body.prompt),
    });
  }
});

function generateLocalManufacturingResponse(prompt: string): string {
  const q = (prompt || '').toLowerCase();
  if (q.includes('rejection') || q.includes('scrap') || q.includes('defect') || q.includes('variance')) {
    return `### **ANOMALY DIAGNOSTIC REPORT: SCRAP / DEFECT VARIANCE**

**Metric Analysis:**
Rejection rate increased from **2.1% to 3.8%** across active production batches. 
71% of rejected components originated from **Cell AM-042** (Carbon DLS Gen-4) and **Cell AM-051** (MJF TPU-300).

**Root Cause Findings:**
1. **Chamber Thermal Variance:** AM-042 exhibited a ±4.8°C thermal gradient across the print vat perimeter during layers 1,240–1,890, causing localized polyurethane premature curing.
2. **Resin Viscosity Drift:** Batch #R-8842 had a viscosity index of 4,200 cP (tolerance 3,800 ± 250 cP) due to ambient humidity shift at 04:00.

**RECOMMENDED ACTION:**
1. Trigger automatic chamber recalibration on **AM-042** and **AM-051**.
2. Run optical laser pyrometer verification prior to starting Job #PJ-9042.
3. Purge vat resin on AM-042 and replenish with certified batch #R-8845.`;
  }

  if (q.includes('lattice') || q.includes('stiffness') || q.includes('cushion') || q.includes('density') || q.includes('weight')) {
    return `### **GENERATIVE LATTICE OPTIMIZATION SPECIFICATION**

**Engineering Parameters for 4DFWD Midsole v4.8:**
- **Selected Geometry:** Gyroid Triply Periodic Minimal Surface (TPMS) with variable wall thickness (0.8mm to 1.6mm).
- **Target Athlete:** 68–78kg Elite Marathoner (4:00/km pacing profile).
- **Forefoot Zone:** 78% lattice density, 240 N/mm forward-vector stiffness for 15.4% higher mechanical energy return.
- **Midfoot Torsion Bar:** 92% density with Diamond-Octet reinforcement to prevent excessive pronation.
- **Heel Deceleration Zone:** 45% density with progressive gradient (absorbing 1,850 N peak ground reaction force).

**Manufacturing Estimate:**
- Projected Component Weight: **172.4 g / pair** (vs 210g standard foam)
- Print Duration: **1 hr 42 min** on Carbon DLS at 50µm layer resolution
- Estimated Unit Cost: **€14.28** using Forward AM Bio-TPU 75B.`;
  }

  if (q.includes('schedule') || q.includes('printer') || q.includes('optimize') || q.includes('machine')) {
    return `### **PRODUCTION QUEUE OPTIMIZATION ENGINE**

**Optimal Allocation Recommendation:**
- **Recommended Machine:** **Printer AM-042** (Chamber Status: Optimal, Material: EPU 41 Loaded, 89% reservoir)
- **Estimated Completion:** **14:32 UTC**
- **Machine Capacity Utilization:** **87.4%**
- **Calculated Unit Production Cost:** **€18.42**
- **Carbon Footprint:** **0.34 kWh / component** (100% on-site solar renewable bracket)

**Execution Step:**
Dispatching Job #PJ-9104 to AM-042 minimizes wait time by 48 minutes compared to AM-003.`;
  }

  return `### **ADIDAS MANUFACTURING INTELLIGENCE // SYSTEM STATUS**

All 12 additive manufacturing cells are synchronized with the Herzogenaurach central digital twin.
- **Active Printers:** 9 / 12 Operational
- **Overall Equipment Effectiveness (OEE):** 89.4% (Benchmark: >85%)
- **24-Hour Throughput:** 842 / 920 scheduled components
- **Quality Acceptance:** 98.2% first-pass yield

Ask me about:
- Machine telemetry anomalies (e.g. "Check AM-042 thermal variance")
- Generative lattice parameters & biomechanical energy return
- Material selection (Bio-TPU vs EPU 44)
- Scheduling queue optimization`;
}

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, () => {
    console.log(`Adidas Additive Server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);

