export type UserRole = 
  | 'ENGINEER' 
  | 'DESIGNER' 
  | 'FACTORY_MANAGER' 
  | 'QUALITY_MANAGER' 
  | 'MATERIALS_SCIENTIST' 
  | 'EXECUTIVE' 
  | 'ADMINISTRATOR';

export interface UserProfile {
  id: string;
  name: string;
  role: UserRole;
  badgeId: string;
  avatar: string;
  factoryId: string;
  certifications: string[];
}

export type MachineStatus = 'OPERATIONAL' | 'WARNING' | 'FAULT' | 'MAINTENANCE' | 'OFFLINE';

export interface MachineTelemetry {
  timestamp: string;
  chamberTemp: number; // °C
  bedTemp: number; // °C
  headLaserTemp: number; // °C
  resinViscosity?: number; // cP
  laserPowerOutput: number; // W
  inertGasLevel: number; // %
  vibrationLevel: number; // mm/s
}

export interface Machine {
  id: string;
  name: string;
  code: string;
  cellLocation: string;
  manufacturer: string;
  model: string;
  technology: 'Carbon DLS' | 'Selective Laser Sintering (SLS)' | 'HP Multi Jet Fusion (MJF)' | 'Stereolithography (SLA)';
  status: MachineStatus;
  currentJobId?: string;
  currentProduct?: string;
  materialLoaded: string;
  materialRemainingPct: number;
  chamberTemp: number;
  bedTemp: number;
  printHeadTemp: number;
  currentLayer: number;
  totalLayers: number;
  estimatedCompletionTime: string;
  uptimeHours: number;
  oeePct: number;
  lastMaintenanceDate: string;
  nextMaintenanceDate: string;
  telemetryHistory: MachineTelemetry[];
  warnings?: string[];
  gridPos: { x: number; y: number; z: number }; // Factory 3D floor coordinates
}

export type CellGeometry = 'VORONOI' | 'GYROID_TPMS' | 'DIAMOND_OCTET' | 'SCHWARZ_D' | 'ISOTROPIC_LATTICE' | 'HONEYCOMB_GRADIENT';

export interface GenerativeLatticeConfig {
  densityPct: number; // 10% to 95%
  cellGeometry: CellGeometry;
  wallThicknessMm: number; // 0.4 to 3.2mm
  cellSizeMm: number; // 3 to 14mm
  forefootStiffnessNmm: number; // 120 - 320 N/mm
  midfootTorsionLockPct: number; // 50 - 100%
  heelCushioningDeflectionMm: number; // 6 - 22mm
  energyReturnPct: number; // 65 - 94%
  weightGrams: number;
  printTimeHours: number;
  materialCostEur: number;
  feaMaxStressMpa: number;
}

export interface ShoeComponent {
  id: string;
  name: string;
  type: 'UPPER' | 'MIDSOLE' | 'LATTICE_CORE' | 'OUTSOLE' | 'HEEL_CLIP' | 'TORSION_SYSTEM' | 'ENERGY_RODS';
  materialId: string;
  dimensionsMm: { length: number; width: number; height: number };
  densityGcm3: number;
  stiffnessNmm: number;
  tensileStrengthMpa: number;
  weightGrams: number;
  printTimeHours: number;
  materialCostEur: number;
  generativeConfig?: GenerativeLatticeConfig;
  status: 'OPTIMIZED' | 'SIMULATED' | 'READY_FOR_PRINT' | 'IN_PRODUCTION';
  colorHex: string;
}

export type ProductCategory = 'PERFORMANCE_RUNNING' | 'FOOTBALL' | 'BASKETBALL' | 'LIFESTYLE' | 'OUTDOOR' | 'PROTOTYPE_CONCEPT';

export interface Product {
  id: string;
  sku: string;
  name: string;
  category: ProductCategory;
  version: string;
  designer: string;
  releaseYear: number;
  manufacturingMethod: string;
  targetAthleteProfile: string;
  materials: string[];
  status: 'ACTIVE_PRODUCTION' | 'PILOT_RUN' | 'FEA_SIMULATION' | 'R&D_LAB' | 'ARCHIVED';
  sustainabilityScore: number; // 0-100
  recycledMaterialPct: number;
  co2ePerPairKg: number;
  components: ShoeComponent[];
  thumbnailUrl: string;
  cadFileUrl: string;
  batchYieldPct: number;
  totalManufacturedCount: number;
}

export interface Material {
  id: string;
  name: string;
  code: string;
  family: 'TPU' | 'BIO_ELASTOMER' | 'RECYCLED_POLYMER' | 'EPU' | 'PEBAX' | 'CARBON_COMPOSITE';
  supplier: string;
  batchLot: string;
  densityGcm3: number;
  tensileStrengthMpa: number;
  elongationAtBreakPct: number;
  shoreHardness: string; // e.g. "88A" or "54D"
  meltingTempC: number;
  printTempC: number;
  recommendedLayerHeightUm: number;
  recyclabilityRating: '100% CLOSED_LOOP' | 'RECYCLABLE' | 'BIO_DEGRADABLE' | 'TECHNICAL_CYCLE';
  recycledContentPct: number;
  costPerKgEur: number;
  viscosityCp?: number;
  colorOptions: string[];
  description: string;
  carbonFootprintPerKg: number; // kg CO2e
  stockAvailableKg: number;
}

export type JobStatus = 'QUEUED' | 'SLICING' | 'SIMULATING' | 'PRINTING' | 'PAUSED' | 'COMPLETED' | 'FAILED' | 'CANCELLED';

export interface PrintSimulationResult {
  estimatedTimeMinutes: number;
  predictedFailureRiskPct: number;
  thermalHotspotsCount: number;
  maxResidualStressMpa: number;
  estimatedWarpingMm: number;
  materialFlowRateGmin: number;
  totalEnergyConsumptionKwh: number;
  supportVolumeCm3: number;
  layerCount: number;
  slicingStatus: 'READY' | 'COMPUTING' | 'OPTIMAL';
  criticalWarnings: string[];
}

export interface PrintJob {
  id: string;
  jobCode: string;
  title: string;
  productId: string;
  componentId: string;
  materialId: string;
  machineId: string;
  status: JobStatus;
  priority: 'LOW' | 'NORMAL' | 'HIGH' | 'CRITICAL_SPEEDFACTORY';
  layerHeightUm: number;
  latticeDensityPct: number;
  supportType: 'ORGANIC_TREE' | 'SOLID_COLUMN' | 'GYROID_SELF_SUPPORT' | 'NONE';
  buildPlateAngleDeg: number;
  currentLayer: number;
  totalLayers: number;
  progressPct: number;
  estimatedPrintTimeMinutes: number;
  elapsedTimeMinutes: number;
  materialWeightGrams: number;
  energyKwh: number;
  totalCostEur: number;
  createdAt: string;
  startedAt?: string;
  completedAt?: string;
  operator: string;
  simulation: PrintSimulationResult;
}

export interface QualityInspectionMarker {
  id: string;
  name: string;
  coordinate: { x: number; y: number; z: number };
  status: 'PASS' | 'WARNING' | 'FAIL';
  metricName: string;
  measuredValue: string;
  targetTolerance: string;
  deviation: string;
}

export interface ProductionBatch {
  id: string;
  batchNumber: string;
  productId: string;
  productName: string;
  componentName: string;
  machineId: string;
  materialBatch: string;
  operator: string;
  timestamp: string;
  unitsProduced: number;
  unitsPassed: number;
  unitsRejected: number;
  dimensionalAccuracyPct: number;
  surfaceQualityPct: number;
  shoreHardnessMeasured: string;
  tensileModulusMpa: number;
  qaStatus: 'PENDING_INSPECTION' | 'APPROVED' | 'REJECTED' | 'QUARANTINED';
  inspectorNotes: string;
  inspectionMarkers: QualityInspectionMarker[];
  digitalSignature?: string;
}

export interface InventoryItem {
  id: string;
  sku: string;
  name: string;
  category: 'RAW_MATERIAL' | 'MATERIAL_BATCH' | 'FINISHED_COMPONENT' | 'REJECTED_RECYCLING' | 'SPARE_PARTS' | 'CONSUMABLE';
  currentStock: number;
  unit: string;
  location: string;
  dailyConsumptionRate: number;
  projectedDepletionDays: number;
  reorderThreshold: number;
  optimalBatchSize: number;
  supplier: string;
  leadTimeDays: number;
  unitCostEur: number;
  autoReorderStatus: 'SUFFICIENT' | 'REORDER_RECOMMENDED' | 'CRITICAL_LOW' | 'ORDER_PLACED';
}

export interface EnergyDataPoint {
  timestamp: string;
  additiveKwhPerComponent: number;
  traditionalKwhPerComponent: number;
  factoryTotalPowerMw: number;
  solarRenewablePct: number;
  gridPowerCostEur: number;
  co2eAvoidedKg: number;
}

export interface FactoryFacility {
  id: string;
  name: string;
  country: string;
  city: string;
  code: string;
  totalCells: number;
  activeCells: number;
  capacityUtilizationPct: number;
  currentEfficiencyPct: number;
  renewableEnergyPct: number;
  timezone: string;
  activeShift: string;
  todayOutputPairs: number;
}

export interface TraceabilityNode {
  id: string;
  type: 'PRODUCT' | 'COMPONENT' | 'CAD_MODEL' | 'MATERIAL' | 'PRINT_PROFILE' | 'MACHINE' | 'BATCH' | 'QUALITY' | 'WAREHOUSE';
  label: string;
  sublabel: string;
  status: 'VERIFIED' | 'IN_PROCESS' | 'FLAGGED';
  metadata: Record<string, string | number>;
  timestamp: string;
}

export interface AIChatMessage {
  id: string;
  sender: 'USER' | 'AMI_ASSISTANT';
  text: string;
  timestamp: string;
  isStreaming?: boolean;
  recommendations?: string[];
  diagnosticReport?: {
    anomalyMachine?: string;
    rootCause?: string;
    actionableStep?: string;
  };
}

export interface DemoWorkflowStep {
  stepNumber: number;
  title: string;
  route: string;
  actionDescription: string;
  targetObject?: string;
  completed: boolean;
}
