import * as THREE from 'three';
import { Machine } from '../types/additive.types';

export interface FactorySceneOptions {
  container: HTMLElement;
  machines: Machine[];
  onMachineSelected?: (machineId: string) => void;
}

export class Factory3DScene {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer | null = null;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private animFrameId: number | null = null;
  private onMachineSelected?: (machineId: string) => void;

  private machineMeshes = new Map<string, THREE.Group>();
  private agvRobots: THREE.Group[] = [];
  private roboticArms: THREE.Group[] = [];
  private laserPulses: THREE.PointLight[] = [];

  // Interaction
  private isDragging = false;
  private prevMousePos = { x: 0, y: 0 };
  private rotationTarget = { x: 0.65, y: -0.45 };
  private rotationCurrent = { x: 0.65, y: -0.45 };
  private zoomTarget = 19;
  private zoomCurrent = 19;
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();

  constructor(options: FactorySceneOptions) {
    this.container = options.container;
    this.onMachineSelected = options.onMachineSelected;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0a0c10);
    this.scene.fog = new THREE.FogExp2(0x0a0c10, 0.025);

    const width = this.container.clientWidth || 900;
    const height = this.container.clientHeight || 550;

    this.camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 200);
    this.camera.position.set(0, 14, this.zoomCurrent);

    this.initRenderer();
    this.setupLighting();
    this.setupFactoryEnvironment();
    this.buildManufacturingFloor(options.machines);
    this.setupEventListeners();
    this.animate();
  }

  private initRenderer(): void {
    try {
      this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      this.renderer.setSize(this.container.clientWidth, this.container.clientHeight);
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      this.renderer.shadowMap.enabled = true;
      this.container.appendChild(this.renderer.domElement);
    } catch (e) {
      console.warn('Factory WebGL init error:', e);
    }
  }

  private setupLighting(): void {
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    this.scene.add(ambientLight);

    const ceilingKey = new THREE.DirectionalLight(0xffffff, 1.2);
    ceilingKey.position.set(10, 25, 10);
    ceilingKey.castShadow = true;
    this.scene.add(ceilingKey);

    const cyanAccent = new THREE.DirectionalLight(0x00f0ff, 0.8);
    cyanAccent.position.set(-15, 8, -10);
    this.scene.add(cyanAccent);
  }

  private setupFactoryEnvironment(): void {
    // 1. Polished Concrete Industrial Floor with Grid
    const floorGeo = new THREE.PlaneGeometry(50, 40);
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0x10131a,
      roughness: 0.35,
      metalness: 0.3,
    });
    const floorMesh = new THREE.Mesh(floorGeo, floorMat);
    floorMesh.rotation.x = -Math.PI / 2;
    floorMesh.receiveShadow = true;
    this.scene.add(floorMesh);

    // Floor grid markings
    const grid = new THREE.GridHelper(40, 40, 0x00f0ff, 0x1f2633);
    grid.position.y = 0.01;
    this.scene.add(grid);

    // 2. Yellow Hazard Walking Aisles
    this.createAislePath(-12, 0, 12, 0);
    this.createAislePath(0, -10, 0, 10);

    // 3. Automated Overhead Gantry Rail
    this.createGantryRails();

    // 4. Automated Storage and Retrieval System (ASRS) Tower at Back
    this.createAsrsTowers();

    // 5. Automated Inspection Laser Scanner Station
    this.createMetrologyTunnel();

    // 6. Spawn AGVs (Automated Guided Vehicles)
    this.createAgvFleet();
  }

  private createAislePath(x1: number, z1: number, x2: number, z2: number): void {
    const len = Math.hypot(x2 - x1, z2 - z1) || 24;
    const geo = new THREE.PlaneGeometry(1.6, len);
    const mat = new THREE.MeshBasicMaterial({ color: 0x28303f });
    const p = new THREE.Mesh(geo, mat);
    p.rotation.x = -Math.PI / 2;
    p.position.set((x1 + x2) / 2, 0.02, (z1 + z2) / 2);
    this.scene.add(p);
  }

  private createGantryRails(): void {
    const railMat = new THREE.MeshStandardMaterial({ color: 0x485264, metalness: 0.8, roughness: 0.2 });
    const railGeo = new THREE.BoxGeometry(32, 0.4, 0.4);
    
    const rail1 = new THREE.Mesh(railGeo, railMat);
    rail1.position.set(0, 7.5, -6);
    this.scene.add(rail1);

    const rail2 = new THREE.Mesh(railGeo, railMat);
    rail2.position.set(0, 7.5, 6);
    this.scene.add(rail2);
  }

  private createAsrsTowers(): void {
    const towerMat = new THREE.MeshStandardMaterial({ color: 0x181e28, metalness: 0.6, roughness: 0.5 });
    for (let i = -14; i <= 14; i += 7) {
      const rackGeo = new THREE.BoxGeometry(4.8, 8, 2.2);
      const rack = new THREE.Mesh(rackGeo, towerMat);
      rack.position.set(i, 4, -14);
      this.scene.add(rack);

      // Shelving trays
      for (let s = 1; s <= 4; s++) {
        const trayGeo = new THREE.BoxGeometry(4.2, 0.15, 2.0);
        const trayMat = new THREE.MeshStandardMaterial({ color: 0x00f0ff, emissive: 0x004050, emissiveIntensity: 0.3 });
        const tray = new THREE.Mesh(trayGeo, trayMat);
        tray.position.set(i, s * 1.6, -14);
        this.scene.add(tray);
      }
    }
  }

  private createMetrologyTunnel(): void {
    const tunnelGroup = new THREE.Group();
    const archGeo = new THREE.TorusGeometry(1.8, 0.2, 8, 16, Math.PI);
    const archMat = new THREE.MeshStandardMaterial({ color: 0x00e676, emissive: 0x00e676, emissiveIntensity: 0.6 });
    const arch = new THREE.Mesh(archGeo, archMat);
    arch.rotation.y = Math.PI / 2;
    arch.position.set(13, 1.8, 0);
    tunnelGroup.add(arch);

    const laserLineGeo = new THREE.CylinderGeometry(0.02, 0.02, 3.4);
    const laserLineMat = new THREE.MeshBasicMaterial({ color: 0x00e676 });
    const laser = new THREE.Mesh(laserLineGeo, laserLineMat);
    laser.position.set(13, 1.8, 0);
    tunnelGroup.add(laser);

    this.scene.add(tunnelGroup);
  }

  private createAgvFleet(): void {
    const agvMat = new THREE.MeshStandardMaterial({ color: 0xffb300, metalness: 0.5, roughness: 0.4 });
    for (let i = 0; i < 3; i++) {
      const agvGroup = new THREE.Group();
      const body = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.4, 1.0), agvMat);
      body.position.y = 0.25;
      agvGroup.add(body);

      // Flashing beacon
      const beacon = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.15), new THREE.MeshBasicMaterial({ color: 0xff334b }));
      beacon.position.y = 0.5;
      agvGroup.add(beacon);

      // Midsole carrier tray
      const tray = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.1, 0.7), new THREE.MeshStandardMaterial({ color: 0x00f0ff }));
      tray.position.y = 0.55;
      agvGroup.add(tray);

      agvGroup.position.set(-8 + i * 8, 0, (i % 2 === 0 ? 3 : -3));
      this.agvRobots.push(agvGroup);
      this.scene.add(agvGroup);
    }
  }

  private buildManufacturingFloor(machines: Machine[]): void {
    machines.forEach((machine) => {
      const cellGroup = this.createMachineCell(machine);
      this.machineMeshes.set(machine.id, cellGroup);
      this.scene.add(cellGroup);
    });
  }

  private createMachineCell(machine: Machine): THREE.Group {
    const group = new THREE.Group();
    const pos = machine.gridPos || { x: 0, y: 0, z: 0 };
    group.position.set(pos.x, 0, pos.z);
    group.userData = { machineId: machine.id };

    // Status color mapping: GREEN = operational, AMBER = warning, RED = fault, BLUE = maintenance, GREY = offline
    let statusColor = 0x00e676; // GREEN
    if (machine.status === 'WARNING') statusColor = 0xffb300; // AMBER
    if (machine.status === 'FAULT') statusColor = 0xff334b; // RED
    if (machine.status === 'MAINTENANCE') statusColor = 0x2979ff; // BLUE
    if (machine.status === 'OFFLINE') statusColor = 0x64748b; // GREY

    // 1. Industrial Cell Base Plinth
    const plinthGeo = new THREE.BoxGeometry(2.4, 0.3, 2.2);
    const plinthMat = new THREE.MeshStandardMaterial({ color: 0x1a202c, roughness: 0.6 });
    const plinth = new THREE.Mesh(plinthGeo, plinthMat);
    plinth.position.y = 0.15;
    group.add(plinth);

    // 2. Machine Housing & Chamber
    const bodyGeo = new THREE.BoxGeometry(1.9, 2.2, 1.8);
    const bodyMat = new THREE.MeshStandardMaterial({ color: 0xe8ecf2, roughness: 0.3, metalness: 0.4 });
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    body.position.y = 1.35;
    group.add(body);

    // 3. Illuminated Viewing Chamber Window
    const glassGeo = new THREE.PlaneGeometry(1.1, 1.1);
    const glassMat = new THREE.MeshStandardMaterial({
      color: statusColor,
      emissive: statusColor,
      emissiveIntensity: 0.6,
      roughness: 0.1,
      metalness: 0.9,
    });
    const glass = new THREE.Mesh(glassGeo, glassMat);
    glass.position.set(0, 1.45, 0.91);
    group.add(glass);

    // 4. Status Light Beacon Stack (Top of Machine)
    const towerGeo = new THREE.CylinderGeometry(0.06, 0.06, 0.45);
    const towerMat = new THREE.MeshBasicMaterial({ color: statusColor });
    const tower = new THREE.Mesh(towerGeo, towerMat);
    tower.position.set(0.65, 2.65, -0.6);
    group.add(tower);

    // Laser glow point light inside active chambers
    if (machine.status === 'OPERATIONAL') {
      const pulseLight = new THREE.PointLight(statusColor, 1.2, 3.5);
      pulseLight.position.set(0, 1.4, 0.5);
      group.add(pulseLight);
      this.laserPulses.push(pulseLight);
    }

    // 5. Adidas Technical Three-Stripe Decal on side of machine
    for (let s = -1; s <= 1; s++) {
      const stripeGeo = new THREE.PlaneGeometry(0.04, 0.5);
      const stripeMat = new THREE.MeshBasicMaterial({ color: 0x000000 });
      const stripe = new THREE.Mesh(stripeGeo, stripeMat);
      stripe.position.set(0.96, 1.7, s * 0.12);
      stripe.rotation.y = Math.PI / 2;
      stripe.rotation.z = -0.3;
      group.add(stripe);
    }

    return group;
  }

  public updateMachineStatus(machines: Machine[]): void {
    machines.forEach(machine => {
      const mesh = this.machineMeshes.get(machine.id);
      if (mesh) {
        let statusColor = 0x00e676;
        if (machine.status === 'WARNING') statusColor = 0xffb300;
        if (machine.status === 'FAULT') statusColor = 0xff334b;
        if (machine.status === 'MAINTENANCE') statusColor = 0x2979ff;
        if (machine.status === 'OFFLINE') statusColor = 0x64748b;

        mesh.traverse(child => {
          if (child instanceof THREE.Mesh && child.material) {
            if (child.material instanceof THREE.MeshStandardMaterial && child.material.emissiveIntensity > 0) {
              child.material.color.setHex(statusColor);
              child.material.emissive.setHex(statusColor);
            }
          }
        });
      }
    });
  }

  public focusOnMachine(machineId: string): void {
    const mesh = this.machineMeshes.get(machineId);
    if (mesh) {
      this.rotationTarget.y = -Math.atan2(mesh.position.x, mesh.position.z);
      this.zoomTarget = 14;
    }
  }

  private setupEventListeners(): void {
    const el = this.container;

    el.addEventListener('mousedown', (e) => {
      this.isDragging = true;
      this.prevMousePos = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mouseup', () => {
      this.isDragging = false;
    });

    el.addEventListener('mousemove', (e) => {
      const rect = el.getBoundingClientRect();
      this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      if (this.isDragging) {
        const dx = e.clientX - this.prevMousePos.x;
        const dy = e.clientY - this.prevMousePos.y;
        this.rotationTarget.y += dx * 0.006;
        this.rotationTarget.x += dy * 0.006;
        this.rotationTarget.x = Math.max(0.2, Math.min(1.2, this.rotationTarget.x));
        this.prevMousePos = { x: e.clientX, y: e.clientY };
      }
    });

    el.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.zoomTarget += e.deltaY * 0.01;
      this.zoomTarget = Math.max(10, Math.min(32, this.zoomTarget));
    }, { passive: false });

    el.addEventListener('click', (e) => {
      const rect = el.getBoundingClientRect();
      this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      this.raycaster.setFromCamera(this.mouse, this.camera);
      const machineGroups = Array.from(this.machineMeshes.values());
      const intersects = this.raycaster.intersectObjects(machineGroups, true);

      if (intersects.length > 0) {
        let current: THREE.Object3D | null = intersects[0].object;
        while (current && current !== this.scene) {
          if (current.userData && current.userData['machineId']) {
            this.onMachineSelected?.(current.userData['machineId']);
            break;
          }
          current = current.parent;
        }
      }
    });

    window.addEventListener('resize', this.onWindowResize);
  }

  private onWindowResize = (): void => {
    if (!this.container || !this.renderer) return;
    const width = this.container.clientWidth || 900;
    const height = this.container.clientHeight || 550;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  private animate = (): void => {
    this.animFrameId = requestAnimationFrame(this.animate);

    // Subtle automatic camera panning
    if (!this.isDragging) {
      this.rotationTarget.y += 0.0008;
    }

    this.rotationCurrent.x += (this.rotationTarget.x - this.rotationCurrent.x) * 0.05;
    this.rotationCurrent.y += (this.rotationTarget.y - this.rotationCurrent.y) * 0.05;
    this.zoomCurrent += (this.zoomTarget - this.zoomCurrent) * 0.05;

    this.camera.position.x = Math.sin(this.rotationCurrent.y) * this.zoomCurrent * Math.cos(this.rotationCurrent.x);
    this.camera.position.z = Math.cos(this.rotationCurrent.y) * this.zoomCurrent * Math.cos(this.rotationCurrent.x);
    this.camera.position.y = Math.sin(this.rotationCurrent.x) * this.zoomCurrent + 4;
    this.camera.lookAt(0, 2, 0);

    // Animate AGVs along tracks
    const t = Date.now() * 0.001;
    this.agvRobots.forEach((agv, i) => {
      agv.position.x = Math.sin(t * 0.4 + i * 2) * 11;
    });

    // Pulse laser lights
    this.laserPulses.forEach((light, i) => {
      light.intensity = 0.8 + Math.sin(t * 8 + i) * 0.4;
    });

    if (this.renderer) {
      this.renderer.render(this.scene, this.camera);
    }
  };

  public destroy(): void {
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
    }
    window.removeEventListener('resize', this.onWindowResize);
    if (this.renderer && this.renderer.domElement && this.renderer.domElement.parentElement) {
      this.renderer.domElement.parentElement.removeChild(this.renderer.domElement);
      this.renderer.dispose();
    }
  }
}
