import * as THREE from 'three';
import { CellGeometry, GenerativeLatticeConfig } from '../types/additive.types';

export interface FootwearSceneOptions {
  container: HTMLElement;
  onComponentSelected?: (componentType: string) => void;
}

export class Footwear3DScene {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer | null = null;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private animFrameId: number | null = null;
  private onComponentSelected?: (componentType: string) => void;

  // Shoe Component Meshes
  private shoeGroup: THREE.Group;
  private upperMesh!: THREE.Mesh;
  private latticeMidsoleMesh!: THREE.Mesh;
  private outsoleMesh!: THREE.Mesh;
  private heelClipMesh!: THREE.Mesh;
  private torsionRodsMesh!: THREE.Mesh;

  // View settings
  private explodedProgress = 0; // 0 (assembled) to 1 (fully exploded)
  private viewMode: 'REALISTIC' | 'FEA_HEATMAP' | 'WIREFRAME' | 'XRAY' = 'REALISTIC';
  private selectedComponent: string | null = 'MIDSOLE';

  // Mouse interaction & rotation
  private isDragging = false;
  private prevMousePos = { x: 0, y: 0 };
  private rotationTarget = { x: 0.25, y: -0.6 };
  private rotationCurrent = { x: 0.25, y: -0.6 };
  private zoomTarget = 5.8;
  private zoomCurrent = 5.8;
  private autoRotate = true;

  // Raycasting
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();

  constructor(options: FootwearSceneOptions) {
    this.container = options.container;
    this.onComponentSelected = options.onComponentSelected;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0c0d12);

    const width = this.container.clientWidth || 800;
    const height = this.container.clientHeight || 500;

    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    this.camera.position.set(0, 1.2, this.zoomCurrent);

    this.shoeGroup = new THREE.Group();
    this.scene.add(this.shoeGroup);

    this.initRenderer();
    this.setupLights();
    this.setupFloorGrid();
    this.buildShoeComponents();
    this.setupEventListeners();
    this.animate();
  }

  private initRenderer(): void {
    try {
      this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      this.renderer.setSize(this.container.clientWidth, this.container.clientHeight);
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      this.renderer.shadowMap.enabled = true;
      this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      this.container.appendChild(this.renderer.domElement);
    } catch (e) {
      console.warn('WebGL init error:', e);
    }
  }

  private setupLights(): void {
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.85);
    this.scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 1.6);
    keyLight.position.set(5, 8, 5);
    keyLight.castShadow = true;
    this.scene.add(keyLight);

    const cyanRimLight = new THREE.DirectionalLight(0x00f0ff, 1.2);
    cyanRimLight.position.set(-6, -2, -4);
    this.scene.add(cyanRimLight);

    const warmFillLight = new THREE.DirectionalLight(0xffeedd, 0.6);
    warmFillLight.position.set(0, -5, 4);
    this.scene.add(warmFillLight);
  }

  private setupFloorGrid(): void {
    const gridHelper = new THREE.GridHelper(10, 20, 0x00f0ff, 0x1f232d);
    gridHelper.position.y = -1.2;
    this.scene.add(gridHelper);

    // Subtle floor shadow ring
    const shadowGeo = new THREE.RingGeometry(0.1, 3.2, 32);
    const shadowMat = new THREE.MeshBasicMaterial({
      color: 0x000000,
      transparent: true,
      opacity: 0.4,
      side: THREE.DoubleSide,
    });
    const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
    shadowMesh.rotation.x = -Math.PI / 2;
    shadowMesh.position.y = -1.19;
    this.scene.add(shadowMesh);
  }

  private buildShoeComponents(): void {
    // 1. UPPER MESH
    const upperGeo = this.createUpperGeometry();
    const upperMat = new THREE.MeshStandardMaterial({
      color: 0x151820,
      roughness: 0.65,
      metalness: 0.15,
      wireframe: false,
    });
    this.upperMesh = new THREE.Mesh(upperGeo, upperMat);
    this.upperMesh.userData = { componentType: 'UPPER' };
    this.upperMesh.castShadow = true;
    this.shoeGroup.add(this.upperMesh);

    // 2. 3D LATTICE MIDSOLE CORE (Procedural porous additive lattice)
    const midsoleGeo = this.generateLatticeGeometry(58, 'GYROID_TPMS', 1.1);
    const midsoleMat = new THREE.MeshStandardMaterial({
      color: 0x00f0ff,
      roughness: 0.25,
      metalness: 0.4,
      wireframe: false,
    });
    this.latticeMidsoleMesh = new THREE.Mesh(midsoleGeo, midsoleMat);
    this.latticeMidsoleMesh.userData = { componentType: 'MIDSOLE' };
    this.latticeMidsoleMesh.castShadow = true;
    this.shoeGroup.add(this.latticeMidsoleMesh);

    // 3. CONTINENTAL TRACTION OUTSOLE
    const outsoleGeo = this.createOutsoleGeometry();
    const outsoleMat = new THREE.MeshStandardMaterial({
      color: 0x242833,
      roughness: 0.8,
      metalness: 0.1,
    });
    this.outsoleMesh = new THREE.Mesh(outsoleGeo, outsoleMat);
    this.outsoleMesh.userData = { componentType: 'OUTSOLE' };
    this.shoeGroup.add(this.outsoleMesh);

    // 4. ANATOMICAL HEEL STABILITY CLIP
    const heelGeo = this.createHeelClipGeometry();
    const heelMat = new THREE.MeshStandardMaterial({
      color: 0xeeeeee,
      roughness: 0.15,
      metalness: 0.85,
    });
    this.heelClipMesh = new THREE.Mesh(heelGeo, heelMat);
    this.heelClipMesh.userData = { componentType: 'HEEL_CLIP' };
    this.shoeGroup.add(this.heelClipMesh);

    // 5. EMBEDDED TORSION ENERGY RODS
    const rodsGeo = this.createTorsionRodsGeometry();
    const rodsMat = new THREE.MeshStandardMaterial({
      color: 0x00e676,
      roughness: 0.2,
      metalness: 0.9,
    });
    this.torsionRodsMesh = new THREE.Mesh(rodsGeo, rodsMat);
    this.torsionRodsMesh.userData = { componentType: 'ENERGY_RODS' };
    this.shoeGroup.add(this.torsionRodsMesh);

    // Initial center alignment
    this.shoeGroup.position.set(0, -0.2, 0);
  }

  // --- Procedural Geometries ---

  private createUpperGeometry(): THREE.BufferGeometry {
    // Sculpted athletic shoe upper form
    const width = 1.25;
    const height = 1.35;
    const geo = new THREE.CylinderGeometry(width * 0.45, width * 0.55, height, 32, 16, true);
    geo.rotateZ(Math.PI / 2);
    geo.scale(1.4, 0.7, 0.95);
    geo.translate(0, 0.5, 0);

    // Morph vertices to curve like a running shoe toe spring and heel counter
    const pos = geo.attributes['position'];
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const y = pos.getY(i);
      const z = pos.getZ(i);

      // Toe spring curve upward at positive X
      if (x > 0.5) {
        const toeLift = Math.pow((x - 0.5) / 1.2, 2) * 0.35;
        pos.setY(i, y + toeLift);
      }
      // Narrowing at the forefoot
      if (x > 0.8) {
        pos.setZ(i, z * (1 - (x - 0.8) * 0.3));
      }
    }
    geo.computeVertexNormals();
    return geo;
  }

  public generateLatticeGeometry(densityPct: number, geometryType: CellGeometry, wallThickness: number): THREE.BufferGeometry {
    // Generate complex multi-cell lattice grid mesh representing 4DFWD porous bow-tie matrix
    const length = 3.6;
    const width = 1.3;
    const height = 0.55;
    
    // Resolution scales with density
    const segX = Math.round(18 + (densityPct / 100) * 16);
    const segZ = Math.round(10 + (densityPct / 100) * 8);

    const baseGeo = new THREE.BoxGeometry(length, height, width, segX, 6, segZ);
    const pos = baseGeo.attributes['position'];
    const colors: number[] = [];

    // Procedural lattice cell distortion based on selected geometry type
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      let y = pos.getY(i);
      const z = pos.getZ(i);

      // Ergonomic midsole rocker curve
      if (x > 0.4) {
        const toeCurve = Math.pow((x - 0.4) / 1.4, 2) * 0.28;
        y += toeCurve;
      }
      // Heel bevel
      if (x < -0.8) {
        const heelRocker = Math.pow((-x - 0.8) / 1.0, 1.8) * 0.18;
        y += heelRocker;
      }

      // Micro lattice cell ripple pattern depending on cell type
      let cellDisplacement = 0;
      if (geometryType === 'GYROID_TPMS') {
        cellDisplacement = (Math.sin(x * 9) * Math.cos(z * 9) * Math.sin(y * 14)) * (0.04 * wallThickness);
      } else if (geometryType === 'DIAMOND_OCTET') {
        cellDisplacement = (Math.cos(x * 12 + z * 12) * Math.sin(y * 18)) * (0.05 * wallThickness);
      } else if (geometryType === 'VORONOI') {
        cellDisplacement = (Math.sin(x * 7 + y * 9) * Math.cos(z * 11)) * (0.06 * wallThickness);
      } else {
        cellDisplacement = (Math.sin(x * 8) * Math.cos(z * 8)) * 0.03;
      }

      pos.setX(i, x + cellDisplacement);
      pos.setY(i, y + cellDisplacement);
      pos.setZ(i, z + cellDisplacement);

      // Vertex color heatmap computation (FEA stress simulation)
      // Peak stress at heel impact and ball of foot
      const heelStress = Math.max(0, 1 - Math.hypot(x + 1.1, z) / 0.8) * 5.8;
      const forefootStress = Math.max(0, 1 - Math.hypot(x - 0.9, z) / 0.7) * 4.6;
      const totalStress = heelStress + forefootStress + Math.random() * 0.4;

      // Color mapping: 0 MPa (Cyan) -> 3 MPa (Green) -> 6 MPa (Red)
      const r = Math.min(1, Math.max(0, (totalStress - 2.5) / 3.0));
      const g = Math.min(1, Math.max(0, totalStress < 3 ? totalStress / 3 : 1 - (totalStress - 3) / 3));
      const b = Math.min(1, Math.max(0, 1 - totalStress / 3));

      colors.push(r, g, b);
    }

    baseGeo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    baseGeo.computeVertexNormals();
    baseGeo.translate(0, -0.22, 0);
    return baseGeo;
  }

  private createOutsoleGeometry(): THREE.BufferGeometry {
    const geo = new THREE.BoxGeometry(3.7, 0.08, 1.35, 20, 2, 10);
    const pos = geo.attributes['position'];
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      let y = pos.getY(i);
      if (x > 0.4) {
        y += Math.pow((x - 0.4) / 1.4, 2) * 0.28;
        pos.setY(i, y);
      }
    }
    geo.computeVertexNormals();
    geo.translate(0, -0.55, 0);
    return geo;
  }

  private createHeelClipGeometry(): THREE.BufferGeometry {
    const geo = new THREE.TorusGeometry(0.7, 0.12, 16, 24, Math.PI * 0.95);
    geo.rotateY(Math.PI / 2);
    geo.rotateZ(Math.PI / 4);
    geo.translate(-1.25, 0.4, 0);
    return geo;
  }

  private createTorsionRodsGeometry(): THREE.BufferGeometry {
    const group = new THREE.Group();
    // 5 anatomically placed energy propulsion rods
    for (let r = -2; r <= 2; r++) {
      const rodGeo = new THREE.CylinderGeometry(0.04, 0.04, 2.2, 12);
      rodGeo.rotateZ(Math.PI / 2);
      rodGeo.translate(0.2, -0.25, r * 0.18);
      const rodMesh = new THREE.Mesh(rodGeo);
      group.add(rodMesh);
    }
    const mergedGeo = new THREE.CylinderGeometry(0.04, 0.04, 2.2, 12);
    mergedGeo.rotateZ(Math.PI / 2);
    mergedGeo.translate(0.1, -0.25, 0);
    return mergedGeo;
  }

  // --- Dynamic State Updates ---

  public updateLattice(config: GenerativeLatticeConfig): void {
    if (!this.latticeMidsoleMesh) return;
    this.latticeMidsoleMesh.geometry.dispose();
    this.latticeMidsoleMesh.geometry = this.generateLatticeGeometry(
      config.densityPct,
      config.cellGeometry,
      config.wallThicknessMm
    );
  }

  public setExplodedView(progress: number): void {
    this.explodedProgress = Math.min(1, Math.max(0, progress));
    
    // Smooth translation offsets for exploded component inspection
    const p = this.explodedProgress;
    if (this.upperMesh) this.upperMesh.position.set(0, p * 1.8, 0);
    if (this.latticeMidsoleMesh) this.latticeMidsoleMesh.position.set(0, 0, 0);
    if (this.outsoleMesh) this.outsoleMesh.position.set(0, -p * 1.4, 0);
    if (this.heelClipMesh) this.heelClipMesh.position.set(-p * 1.2, p * 0.8, 0);
    if (this.torsionRodsMesh) this.torsionRodsMesh.position.set(0, -p * 0.7, 0);
  }

  public setViewMode(mode: 'REALISTIC' | 'FEA_HEATMAP' | 'WIREFRAME' | 'XRAY'): void {
    this.viewMode = mode;

    if (this.latticeMidsoleMesh) {
      const mat = this.latticeMidsoleMesh.material as THREE.MeshStandardMaterial;
      if (mode === 'FEA_HEATMAP') {
        mat.vertexColors = true;
        mat.wireframe = false;
        mat.transparent = false;
        mat.opacity = 1;
        mat.needsUpdate = true;
      } else if (mode === 'WIREFRAME') {
        mat.vertexColors = false;
        mat.color.setHex(0x00f0ff);
        mat.wireframe = true;
        mat.transparent = false;
        mat.opacity = 1;
        mat.needsUpdate = true;
      } else if (mode === 'XRAY') {
        mat.vertexColors = false;
        mat.color.setHex(0x00f0ff);
        mat.wireframe = false;
        mat.transparent = true;
        mat.opacity = 0.35;
        mat.needsUpdate = true;
      } else {
        mat.vertexColors = false;
        mat.color.setHex(0x00f0ff);
        mat.wireframe = false;
        mat.transparent = false;
        mat.opacity = 1;
        mat.needsUpdate = true;
      }
    }

    if (this.upperMesh) {
      const upperMat = this.upperMesh.material as THREE.MeshStandardMaterial;
      if (mode === 'XRAY') {
        upperMat.transparent = true;
        upperMat.opacity = 0.2;
      } else {
        upperMat.transparent = false;
        upperMat.opacity = 1;
      }
      upperMat.needsUpdate = true;
    }
  }

  public selectComponentByType(type: string): void {
    this.selectedComponent = type;

    // Reset and apply subtle emissive glow to selected component
    [this.upperMesh, this.latticeMidsoleMesh, this.outsoleMesh, this.heelClipMesh, this.torsionRodsMesh].forEach(mesh => {
      if (!mesh) return;
      const mat = mesh.material as THREE.MeshStandardMaterial;
      if (mesh.userData['componentType'] === type) {
        mat.emissive = new THREE.Color(0x00f0ff);
        mat.emissiveIntensity = 0.35;
      } else {
        mat.emissive = new THREE.Color(0x000000);
        mat.emissiveIntensity = 0;
      }
    });
  }

  public resetCamera(): void {
    this.rotationTarget = { x: 0.25, y: -0.6 };
    this.zoomTarget = 5.8;
  }

  public toggleAutoRotate(enabled: boolean): void {
    this.autoRotate = enabled;
  }

  // --- Interaction & Event Handlers ---

  private setupEventListeners(): void {
    const el = this.container;

    el.addEventListener('mousedown', (e) => {
      this.isDragging = true;
      this.prevMousePos = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mouseup', () => {
      this.isDragging = false;
    });

    el.addEventListener('mousemove', (e) => {
      const rect = el.getBoundingClientRect();
      this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      if (this.isDragging) {
        const dx = e.clientX - this.prevMousePos.x;
        const dy = e.clientY - this.prevMousePos.y;
        this.rotationTarget.y += dx * 0.008;
        this.rotationTarget.x += dy * 0.008;
        this.rotationTarget.x = Math.max(-Math.PI / 3, Math.min(Math.PI / 3, this.rotationTarget.x));
        this.prevMousePos = { x: e.clientX, y: e.clientY };
      }
    });

    el.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.zoomTarget += e.deltaY * 0.004;
      this.zoomTarget = Math.max(3.2, Math.min(9.0, this.zoomTarget));
    }, { passive: false });

    el.addEventListener('click', (e) => {
      const rect = el.getBoundingClientRect();
      this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      this.raycaster.setFromCamera(this.mouse, this.camera);
      const intersects = this.raycaster.intersectObjects(this.shoeGroup.children, true);

      if (intersects.length > 0) {
        const hit = intersects[0].object;
        const compType = hit.userData['componentType'];
        if (compType) {
          this.selectComponentByType(compType);
          this.onComponentSelected?.(compType);
        }
      }
    });

    window.addEventListener('resize', this.onWindowResize);
  }

  private onWindowResize = (): void => {
    if (!this.container || !this.renderer) return;
    const width = this.container.clientWidth || 800;
    const height = this.container.clientHeight || 500;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  private animate = (): void => {
    this.animFrameId = requestAnimationFrame(this.animate);

    if (this.autoRotate && !this.isDragging) {
      this.rotationTarget.y += 0.003;
    }

    // Smooth lerp rotation and camera zoom
    this.rotationCurrent.x += (this.rotationTarget.x - this.rotationCurrent.x) * 0.08;
    this.rotationCurrent.y += (this.rotationTarget.y - this.rotationCurrent.y) * 0.08;
    this.zoomCurrent += (this.zoomTarget - this.zoomCurrent) * 0.08;

    this.shoeGroup.rotation.x = this.rotationCurrent.x;
    this.shoeGroup.rotation.y = this.rotationCurrent.y;
    this.camera.position.z = this.zoomCurrent;

    if (this.renderer) {
      this.renderer.render(this.scene, this.camera);
    }
  };

  public destroy(): void {
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
    }
    window.removeEventListener('resize', this.onWindowResize);
    if (this.renderer && this.renderer.domElement && this.renderer.domElement.parentElement) {
      this.renderer.domElement.parentElement.removeChild(this.renderer.domElement);
      this.renderer.dispose();
    }
  }
}
