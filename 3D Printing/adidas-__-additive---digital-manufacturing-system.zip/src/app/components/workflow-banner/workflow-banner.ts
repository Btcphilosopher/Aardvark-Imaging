import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ManufacturingState } from '../../services/manufacturing-state.service';

@Component({
  selector: 'app-workflow-banner',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-[#11141c] border-b border-[#222733] px-4 py-2.5 flex flex-col md:flex-row md:items-center justify-between gap-3 select-none">
      <!-- Left: Step Indicator & Title -->
      <div class="flex items-center gap-3">
        <div class="flex items-center gap-1.5 bg-[#00f0ff]/10 border border-[#00f0ff]/30 px-2.5 py-1 rounded-md">
          <span class="w-2 h-2 rounded-full bg-[#00f0ff] animate-pulse"></span>
          <span class="text-xs font-mono font-bold text-[#00f0ff]">
            {{ state.t('DEMO STEP') }} {{ currentStep().stepNumber }}/16
          </span>
        </div>

        <div class="flex flex-col">
          <div class="flex items-center gap-2">
            <span class="text-xs font-bold text-white uppercase tracking-wide">{{ currentStep().title }}</span>
            <span class="text-xs text-zinc-400 font-mono hidden sm:inline">— {{ currentStep().actionDescription }}</span>
          </div>
        </div>
      </div>

      <!-- Center / Right: Step Pill Controls & Next/Prev -->
      <div class="flex items-center gap-2 self-end md:self-auto">
        <!-- Step Navigation Pill Dots Dropdown / Scroller -->
        <div class="hidden lg:flex items-center gap-1 bg-[#0a0c10] p-1 rounded-lg border border-[#222733]">
          @for (step of state.translatedWorkflowSteps(); track step.stepNumber; let idx = $index) {
            <button
              (click)="state.goToWorkflowStep(idx)"
              [title]="step.stepNumber + '. ' + step.title + ': ' + step.actionDescription"
              class="w-6 h-6 rounded flex items-center justify-center text-[10px] font-mono transition-all font-semibold animate-none"
              [class.bg-[#00f0ff]]="idx === state.currentWorkflowStepIndex()"
              [class.text-black]="idx === state.currentWorkflowStepIndex()"
              [class.bg-[#00e676]/20]="idx < state.currentWorkflowStepIndex()"
              [class.text-[#00e676]]="idx < state.currentWorkflowStepIndex()"
              [class.text-zinc-400]="idx > state.currentWorkflowStepIndex()"
              [class.hover:bg-[#1f2638]]="idx !== state.currentWorkflowStepIndex()"
            >
              {{ step.stepNumber }}
            </button>
          }
        </div>

        <!-- Previous Button -->
        <button
          (click)="prevStep()"
          [disabled]="state.currentWorkflowStepIndex() === 0"
          class="px-2.5 py-1.5 bg-[#171c26] hover:bg-[#202736] disabled:opacity-30 disabled:cursor-not-allowed border border-[#2b3345] rounded-md text-zinc-300 text-xs font-mono flex items-center gap-1 transition-colors"
        >
          <mat-icon class="!text-sm !w-4 !h-4">chevron_left</mat-icon>
          <span class="hidden sm:inline">{{ state.t('PREV') }}</span>
        </button>

        <!-- Next / Advance Button -->
        <button
          (click)="nextStep()"
          class="px-3 py-1.5 bg-[#00f0ff] hover:bg-[#38f4ff] text-black font-bold text-xs font-mono rounded-md flex items-center gap-1 transition-all shadow-sm active:scale-95"
        >
          <span>{{ isLastStep() ? state.t('FINISH') : state.t('NEXT STEP') }}</span>
          <mat-icon class="!text-sm !w-4 !h-4">arrow_forward</mat-icon>
        </button>
      </div>
    </div>
  `,
})
export class WorkflowBannerComponent {
  readonly state = inject(ManufacturingState);

  currentStep() {
    return this.state.translatedWorkflowSteps()[this.state.currentWorkflowStepIndex()];
  }

  isLastStep(): boolean {
    return this.state.currentWorkflowStepIndex() === this.state.translatedWorkflowSteps().length - 1;
  }

  prevStep(): void {
    const cur = this.state.currentWorkflowStepIndex();
    if (cur > 0) {
      this.state.goToWorkflowStep(cur - 1);
    }
  }

  nextStep(): void {
    this.state.advanceWorkflow();
  }
}
