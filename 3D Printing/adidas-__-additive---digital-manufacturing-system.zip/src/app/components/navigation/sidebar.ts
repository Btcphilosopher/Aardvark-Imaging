import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { ManufacturingState } from '../../services/manufacturing-state.service';

interface NavItem {
  path: string;
  label: string;
  sublabel: string;
  icon: string;
  badge?: string;
  activeMatches?: string[];
}

@Component({
  selector: 'app-sidebar',
  imports: [CommonModule, RouterModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <aside class="w-64 bg-[#0d1017] border-r border-[#222733] flex flex-col justify-between select-none h-full z-20">
      <!-- Top Navigation Links -->
      <div class="p-3 space-y-1 overflow-y-auto">
        <div class="px-3 py-2 text-[10px] font-mono font-bold tracking-widest text-zinc-400 uppercase">
          {{ state.t('MANUFACTURING PIPELINE') }}
        </div>

        @for (item of navItems; track item.path) {
          <a
            [routerLink]="item.path"
            routerLinkActive="bg-[#192236] text-white border-l-2 border-[#00f0ff]"
            [routerLinkActiveOptions]="{ exact: item.path === '/command-center' }"
            class="flex items-center justify-between px-3 py-2 rounded-lg text-zinc-300 hover:text-white hover:bg-[#141924] transition-all group border-l-2 border-transparent"
          >
            <div class="flex items-center gap-3">
              <mat-icon class="text-zinc-400 group-hover:text-[#00f0ff] transition-colors !text-xl !w-5 !h-5">
                {{ item.icon }}
              </mat-icon>
              <div class="flex flex-col">
                <span class="text-xs font-semibold tracking-wide">{{ state.t(item.label) }}</span>
                <span class="text-[10px] font-mono text-zinc-400 group-hover:text-zinc-400">{{ state.t(item.sublabel) }}</span>
              </div>
            </div>
            @if (item.badge) {
              <span class="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-[#00f0ff]/10 text-[#00f0ff] border border-[#00f0ff]/30">
                {{ item.badge }}
              </span>
            }
          </a>
        }

        <div class="pt-4 px-3 py-2 text-[10px] font-mono font-bold tracking-widest text-zinc-400 uppercase">
          {{ state.t('GOVERNANCE & SUSTAINABILITY') }}
        </div>

        @for (item of secondaryNavItems; track item.path) {
          <a
            [routerLink]="item.path"
            routerLinkActive="bg-[#192236] text-white border-l-2 border-[#00f0ff]"
            class="flex items-center justify-between px-3 py-2 rounded-lg text-zinc-300 hover:text-white hover:bg-[#141924] transition-all group border-l-2 border-transparent"
          >
            <div class="flex items-center gap-3">
              <mat-icon class="text-zinc-400 group-hover:text-[#00f0ff] transition-colors !text-xl !w-5 !h-5">
                {{ item.icon }}
              </mat-icon>
              <div class="flex flex-col">
                <span class="text-xs font-semibold tracking-wide">{{ state.t(item.label) }}</span>
                <span class="text-[10px] font-mono text-zinc-400">{{ state.t(item.sublabel) }}</span>
              </div>
            </div>
          </a>
        }
      </div>

      <!-- Bottom: Demo Workflow Progress Pill & AI Status -->
      <div class="p-3 border-t border-[#222733] bg-[#0a0c10] space-y-2.5">
        <!-- Guided Demo Workflow Launcher Card -->
        <div class="bg-[#141924] border border-[#2b3345] rounded-xl p-3">
          <div class="flex items-center justify-between mb-1.5">
            <span class="text-[10px] font-mono uppercase tracking-wider text-[#00f0ff] font-bold">{{ state.t('16-STEP DEMO PIPELINE') }}</span>
            <span class="text-[10px] font-mono text-zinc-400">{{ state.t('Step ') }}{{ state.currentWorkflowStepIndex() + 1 }}/16</span>
          </div>
          <p class="text-xs font-semibold text-white truncate">
            {{ state.translatedWorkflowSteps()[state.currentWorkflowStepIndex()].title }}
          </p>
          <div class="w-full bg-[#202738] h-1.5 rounded-full overflow-hidden mt-2">
            <div
              class="bg-gradient-to-r from-[#00f0ff] to-[#00e676] h-full transition-all duration-300"
              [style.width.%]="((state.currentWorkflowStepIndex() + 1) / 16) * 100"
            ></div>
          </div>
          <button
            (click)="state.advanceWorkflow()"
            class="w-full mt-2.5 py-1.5 px-3 bg-[#00f0ff] hover:bg-[#38f4ff] text-black font-mono font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-sm"
          >
            <span>{{ state.t('ADVANCE DEMO') }}</span>
            <mat-icon class="!text-sm !w-4 !h-4">arrow_forward</mat-icon>
          </button>
        </div>

        <!-- Simulation mode indicator -->
        <div class="flex items-center justify-between text-[10px] font-mono px-2 text-zinc-400">
          <span class="flex items-center gap-1.5">
            <span class="w-1.5 h-1.5 rounded-full bg-[#00e676] animate-pulse"></span>
            {{ state.t('INDUSTRY 4.0 ACTIVE') }}
          </span>
          <span class="text-zinc-400">v4.8-PROD</span>
        </div>
      </div>
    </aside>
  `,
})
export class SidebarComponent {
  readonly state = inject(ManufacturingState);

  readonly navItems: NavItem[] = [
    { path: '/command-center', label: 'Command Center', sublabel: 'Factory Floor & Live Twins', icon: 'dashboard', badge: '12 CELLS' },
    { path: '/products', label: 'Footwear Catalog', sublabel: '30 CAD Digital Specs', icon: 'view_in_ar' },
    { path: '/digital-twin', label: '3D Digital Twin', sublabel: 'Generative Lattice Studio', icon: 'view_in_ar', badge: 'FEA' },
    { path: '/materials', label: 'Material Science', sublabel: 'EPU, TPU & Bio-Elastomers', icon: 'science' },
    { path: '/print-jobs', label: 'Print Preparation', sublabel: 'Slicing & Simulation', icon: 'layers' },
    { path: '/machines', label: 'Machine Telemetry', sublabel: 'DLS, SLS & MJF Fleet', icon: 'precision_manufacturing', badge: 'LIVE' },
    { path: '/quality', label: 'Quality Metrology', sublabel: 'Automated 3D Inspection', icon: 'verified' },
    { path: '/inventory', label: 'Inventory & Silos', sublabel: 'Powder, Resins & Parts', icon: 'inventory_2' },
  ];

  readonly secondaryNavItems: NavItem[] = [
    { path: '/traceability', label: 'Traceability Thread', sublabel: 'End-to-End Genealogy', icon: 'account_tree' },
    { path: '/analytics', label: 'Executive Analytics', sublabel: 'OEE, Energy & ESG', icon: 'insights' },
  ];
}
