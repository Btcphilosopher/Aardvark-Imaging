import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ManufacturingState } from '../../services/manufacturing-state.service';
import { UserRole } from '../../types/additive.types';

@Component({
  selector: 'app-top-navbar',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="h-16 bg-[#0a0c10] border-b border-[#222733] px-4 sm:px-6 flex items-center justify-between z-30 select-none">
      <!-- Left: Adidas Brand Mark & Factory Selector -->
      <div class="flex items-center gap-4 lg:gap-6">
        <div class="flex items-center gap-3">
          <!-- Stylized Adidas 3-Bars Icon -->
          <div class="flex items-end gap-1 h-6">
            <div class="w-1.5 h-3 bg-white rounded-xs transform -skew-x-12"></div>
            <div class="w-1.5 h-4.5 bg-white rounded-xs transform -skew-x-12"></div>
            <div class="w-1.5 h-6 bg-[#00f0ff] rounded-xs transform -skew-x-12"></div>
          </div>
          <div class="flex flex-col">
            <div class="flex items-center gap-2">
              <span class="font-extrabold tracking-widest text-white text-sm">ADIDAS</span>
              <span class="text-[#00f0ff] font-mono text-xs tracking-wider font-semibold">// ADDITIVE</span>
            </div>
            <span class="text-[10px] text-zinc-400 font-mono tracking-wider">{{ state.t('DIGITAL MANUFACTURING SYSTEM') }}</span>
          </div>
        </div>

        <div class="hidden md:block h-6 w-px bg-[#262c3a]"></div>

        <!-- Factory Facility Selector Dropdown -->
        <div class="relative hidden sm:block">
          <button
            (click)="toggleFactoryDropdown()"
            class="flex items-center gap-2 bg-[#121620] hover:bg-[#181e2b] text-zinc-200 border border-[#2b3345] px-3 py-1.5 rounded-lg text-xs font-mono transition-colors"
          >
            <span class="w-2 h-2 rounded-full bg-[#00e676] animate-pulse"></span>
            <span class="font-semibold text-white truncate max-w-[200px]">{{ state.currentFactory().code }}</span>
            <span class="text-zinc-400 text-[11px] hidden lg:inline">({{ state.currentFactory().city }})</span>
            <mat-icon class="text-zinc-400 !text-sm !w-3.5 !h-3.5 leading-none">expand_more</mat-icon>
          </button>

          @if (showFactoryMenu()) {
            <div class="absolute left-0 mt-2 w-72 bg-[#121620] border border-[#2b3345] rounded-xl shadow-2xl z-50 py-1.5 overflow-hidden">
              <div class="px-3 py-1.5 text-[10px] font-mono uppercase tracking-wider text-zinc-400 border-b border-[#222733]">
                {{ state.t('Global Manufacturing Nodes') }}
              </div>
              @for (fac of state.factories(); track fac.id) {
                <button
                  (click)="selectFactory(fac.id)"
                  class="w-full text-left px-3 py-2 flex items-center justify-between hover:bg-[#1c2233] transition-colors"
                  [class.bg-[#1a2235]]="fac.id === state.selectedFactoryId()"
                >
                  <div class="flex flex-col">
                    <span class="text-xs font-semibold text-white">{{ fac.name }}</span>
                    <span class="text-[10px] font-mono text-zinc-400">{{ fac.city }}, {{ fac.country }} • {{ fac.totalCells }} {{ state.t('Cells') }}</span>
                  </div>
                  @if (fac.id === state.selectedFactoryId()) {
                    <mat-icon class="text-[#00f0ff] !text-base">check</mat-icon>
                  }
                </button>
              }
            </div>
          }
        </div>
      </div>

      <!-- Center: Industrial Status Indicators -->
      <div class="hidden xl:flex items-center gap-6 text-xs font-mono">
        <div class="flex items-center gap-2 bg-[#121620] border border-[#222733] px-3 py-1.5 rounded-lg">
          <span class="text-zinc-400">{{ state.t('SHIFT:') }}</span>
          <span class="text-zinc-200 font-semibold truncate max-w-[220px]">{{ state.currentFactory().activeShift }}</span>
        </div>
        <div class="flex items-center gap-2 bg-[#121620] border border-[#222733] px-3 py-1.5 rounded-lg">
          <span class="text-zinc-400">{{ state.t('OEE:') }}</span>
          <span class="text-[#00e676] font-bold">{{ state.overallOeePct() }}%</span>
        </div>
        <div class="flex items-center gap-2 bg-[#121620] border border-[#222733] px-3 py-1.5 rounded-lg">
          <span class="text-zinc-400">{{ state.t('OUTPUT TODAY:') }}</span>
          <span class="text-white font-bold">{{ state.totalUnitsCompletedToday() }} {{ state.t('PAIRS') }}</span>
        </div>
      </div>

      <!-- Right: Language Selector, User Persona Selector, Notifications, AI Assistant Trigger -->
      <div class="flex items-center gap-3">
        <!-- Live Clock -->
        <div class="hidden md:flex flex-col text-right font-mono text-xs">
          <span class="text-white font-bold tracking-wider">{{ currentTimeString() }}</span>
          <span class="text-[10px] text-zinc-400">{{ state.t('UTC TELEMETRY LIVE') }}</span>
        </div>

        <!-- Language Switcher Button -->
        <button
          (click)="toggleLanguage()"
          class="flex items-center gap-1.5 bg-[#141924] hover:bg-[#1c2233] border border-[#2b3345] px-2.5 py-1.5 rounded-lg text-xs transition-colors font-mono font-bold text-white shadow-sm active:scale-95"
          [title]="state.language() === 'EN' ? 'Wechseln zu Deutsch' : 'Switch to English'"
        >
          <mat-icon class="!text-sm !w-3.5 !h-3.5 text-[#00f0ff]">language</mat-icon>
          <span>{{ state.language() }}</span>
        </button>

        <!-- Role Switcher -->
        <div class="relative">
          <button
            (click)="toggleRoleDropdown()"
            class="flex items-center gap-2 bg-[#141924] hover:bg-[#1c2233] border border-[#2b3345] px-2.5 py-1.5 rounded-lg text-xs transition-colors"
          >
            <div class="w-6 h-6 rounded bg-[#00f0ff]/20 text-[#00f0ff] font-mono font-bold flex items-center justify-center text-[10px] border border-[#00f0ff]/40">
              {{ state.currentUser().avatar }}
            </div>
            <div class="hidden sm:flex flex-col text-left">
              <span class="text-white text-xs font-semibold leading-tight">{{ state.currentUser().name }}</span>
              <span class="text-[10px] font-mono text-zinc-400 leading-none">{{ state.t(state.currentUser().role) }}</span>
            </div>
            <mat-icon class="text-zinc-400 !text-sm !w-3.5 !h-3.5 leading-none">unfold_more</mat-icon>
          </button>

          @if (showRoleMenu()) {
            <div class="absolute right-0 mt-2 w-64 bg-[#121620] border border-[#2b3345] rounded-xl shadow-2xl z-50 py-1.5 overflow-hidden">
              <div class="px-3 py-1.5 text-[10px] font-mono uppercase tracking-wider text-zinc-400 border-b border-[#222733]">
                {{ state.t('Simulate Role Persona') }}
              </div>
              @for (user of state.users(); track user.id) {
                <button
                  (click)="selectUserRole(user.role)"
                  class="w-full text-left px-3 py-2 flex items-center gap-2.5 hover:bg-[#1c2233] transition-colors"
                  [class.bg-[#1a2235]]="user.role === state.currentUserRole()"
                >
                  <div class="w-7 h-7 rounded bg-[#202738] text-white font-mono text-xs flex items-center justify-center font-bold">
                    {{ user.avatar }}
                  </div>
                  <div class="flex flex-col flex-1">
                    <span class="text-xs font-semibold text-white">{{ user.name }}</span>
                    <span class="text-[10px] font-mono text-[#00f0ff]">{{ state.t(user.role) }}</span>
                  </div>
                  @if (user.role === state.currentUserRole()) {
                    <mat-icon class="text-[#00e676] !text-base">check</mat-icon>
                  }
                </button>
              }
            </div>
          }
        </div>

        <!-- Notifications Bell -->
        <div class="relative">
          <button
            (click)="toggleNotifications()"
            class="relative p-2 text-zinc-300 hover:text-white bg-[#141924] hover:bg-[#1c2233] border border-[#2b3345] rounded-lg transition-colors"
            title="Notifications"
          >
            <mat-icon class="!text-lg !w-5 !h-5">notifications</mat-icon>
            @if (state.notifications().length > 0) {
              <span class="absolute top-1 right-1 w-2 h-2 rounded-full bg-[#00f0ff] animate-ping"></span>
              <span class="absolute top-1 right-1 w-2 h-2 rounded-full bg-[#00f0ff]"></span>
            }
          </button>

          @if (showNotifications()) {
            <div class="absolute right-0 mt-2 w-80 bg-[#121620] border border-[#2b3345] rounded-xl shadow-2xl z-50 py-2 overflow-hidden">
              <div class="px-3 py-1 flex items-center justify-between border-b border-[#222733] pb-2">
                <span class="text-xs font-mono font-bold text-white uppercase tracking-wider">{{ state.t('Telemetry Alerts') }}</span>
                <span class="text-[10px] font-mono text-zinc-400">{{ state.notifications().length }} {{ state.t('active') }}</span>
              </div>
              <div class="max-h-64 overflow-y-auto divide-y divide-[#1e2433]">
                @for (notif of state.notifications(); track notif.id) {
                  <div class="p-3 hover:bg-[#181e2b] transition-colors flex items-start gap-2.5">
                    <div class="mt-0.5">
                      @if (notif.type === 'SUCCESS') {
                        <mat-icon class="text-[#00e676] !text-sm">check_circle</mat-icon>
                      } @else if (notif.type === 'WARNING') {
                        <mat-icon class="text-[#ffb300] !text-sm">warning</mat-icon>
                      } @else {
                        <mat-icon class="text-[#00f0ff] !text-sm">info</mat-icon>
                      }
                    </div>
                    <div class="flex-1">
                      <div class="flex items-center justify-between">
                        <span class="text-xs font-semibold text-white">{{ notif.title }}</span>
                        <span class="text-[9px] font-mono text-zinc-400">{{ state.t(notif.time) }}</span>
                      </div>
                      <p class="text-[11px] text-zinc-300 mt-0.5 leading-snug">{{ notif.message }}</p>
                    </div>
                  </div>
                }
              </div>
            </div>
          }
        </div>
      </div>
    </header>
  `,
})
export class TopNavbarComponent {
  readonly state = inject(ManufacturingState);

  readonly showFactoryMenu = signal<boolean>(false);
  readonly showRoleMenu = signal<boolean>(false);
  readonly showNotifications = signal<boolean>(false);

  currentTimeString(): string {
    const d = this.state.liveTimestamp();
    return d.toISOString().substring(11, 19);
  }

  toggleFactoryDropdown(): void {
    this.showFactoryMenu.update(v => !v);
    this.showRoleMenu.set(false);
    this.showNotifications.set(false);
  }

  toggleRoleDropdown(): void {
    this.showRoleMenu.update(v => !v);
    this.showFactoryMenu.set(false);
    this.showNotifications.set(false);
  }

  toggleNotifications(): void {
    this.showNotifications.update(v => !v);
    this.showFactoryMenu.set(false);
    this.showRoleMenu.set(false);
  }

  toggleLanguage(): void {
    const nextLang = this.state.language() === 'EN' ? 'DE' : 'EN';
    this.state.language.set(nextLang);
    const alertTitle = nextLang === 'EN' ? 'Language Changed' : 'Sprache geändert';
    const alertMsg = nextLang === 'EN' ? 'Interface language set to English.' : 'Benutzeroberfläche auf Deutsch umgestellt.';
    this.state.addNotification(alertTitle, alertMsg, 'SUCCESS');
  }

  selectFactory(factoryId: string): void {
    this.state.setFactory(factoryId);
    this.showFactoryMenu.set(false);
  }

  selectUserRole(role: UserRole): void {
    this.state.setUserRole(role);
    this.showRoleMenu.set(false);
  }
}
