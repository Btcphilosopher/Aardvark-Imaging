import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { GeminiAssistantService } from '../../services/gemini-assistant.service';
import { ManufacturingState } from '../../services/manufacturing-state.service';

@Component({
  selector: 'app-ai-assistant-drawer',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <!-- Floating Trigger Button (Bottom Right) -->
    <button
      (click)="toggleOpen()"
      class="fixed bottom-6 right-6 z-40 bg-[#00f0ff] hover:bg-[#38f4ff] text-black font-mono font-extrabold px-4 py-3 rounded-full shadow-2xl flex items-center gap-2.5 transition-all transform hover:scale-105 active:scale-95 border-2 border-white/20"
      [title]="state.language() === 'EN' ? 'Open Adidas Manufacturing Intelligence (AMI)' : 'Adidas Fertigungs-Intelligenz (AMI) öffnen'"
    >
      <div class="w-2.5 h-2.5 rounded-full bg-black animate-pulse"></div>
      <span class="text-xs tracking-wider">AMI // {{ state.language() === 'EN' ? 'AI COPILOT' : 'KI-COPILOT' }}</span>
      <mat-icon class="!text-lg !w-5 !h-5">smart_toy</mat-icon>
    </button>

    <!-- Slide-Over AI Assistant Panel -->
    @if (isOpen()) {
      <div class="fixed inset-0 z-50 flex justify-end bg-black/50 backdrop-blur-xs transition-opacity animate-fade-in">
        <div class="w-full max-w-lg bg-[#0d1017] border-l border-[#222733] h-full flex flex-col justify-between shadow-2xl">
          <!-- Header -->
          <div class="p-4 border-b border-[#222733] bg-[#0a0c10] flex items-center justify-between">
            <div class="flex items-center gap-3">
              <div class="w-9 h-9 rounded-lg bg-[#00f0ff]/10 text-[#00f0ff] border border-[#00f0ff]/30 flex items-center justify-center">
                <mat-icon class="!text-xl">psychology</mat-icon>
              </div>
              <div class="flex flex-col">
                <div class="flex items-center gap-2">
                  <span class="font-extrabold text-white text-sm tracking-wider">ADIDAS AMI {{ state.language() === 'EN' ? 'COPILOT' : 'KI-COPILOT' }}</span>
                  <span class="text-[9px] font-mono px-1.5 py-0.5 rounded bg-[#00e676]/20 text-[#00e676] border border-[#00e676]/30">
                    GEMINI 2.5 FLASH
                  </span>
                </div>
                <span class="text-[10px] font-mono text-zinc-400">
                  {{ state.language() === 'EN' ? 'Additive Process & Optimization Model' : 'Additive Prozesse & Optimierungsmodell' }}
                </span>
              </div>
            </div>

            <div class="flex items-center gap-1">
              <button
                (click)="ai.clearChat()"
                class="p-1.5 text-zinc-400 hover:text-white rounded hover:bg-[#192030] transition-colors"
                [title]="state.language() === 'EN' ? 'Reset conversation' : 'Unterhaltung zurücksetzen'"
              >
                <mat-icon class="!text-sm !w-4 !h-4">refresh</mat-icon>
              </button>
              <button
                (click)="toggleOpen()"
                class="p-1.5 text-zinc-400 hover:text-white rounded hover:bg-[#192030] transition-colors"
              >
                <mat-icon class="!text-base">close</mat-icon>
              </button>
            </div>
          </div>

          <!-- Quick Suggestion Chips -->
          <div class="px-4 py-2 bg-[#121622] border-b border-[#222733] flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            @for (prompt of promptChips; track prompt) {
              <button
                (click)="submitPrompt(prompt)"
                class="whitespace-nowrap px-2.5 py-1 rounded bg-[#1b2233] hover:bg-[#253047] text-[11px] font-mono text-zinc-300 border border-[#2b354c] transition-colors"
              >
                {{ prompt }}
              </button>
            }
          </div>

          <!-- Messages Container -->
          <div class="flex-1 overflow-y-auto p-4 space-y-4">
            @for (msg of ai.messages(); track msg.id) {
              <div
                class="flex flex-col"
                [class.items-end]="msg.sender === 'USER'"
                [class.items-start]="msg.sender === 'AMI_ASSISTANT'"
              >
                <div class="flex items-center gap-2 mb-1 px-1">
                  <span class="text-[10px] font-mono font-bold" [class.text-[#00f0ff]]="msg.sender === 'AMI_ASSISTANT'" [class.text-zinc-400]="msg.sender === 'USER'">
                    {{ msg.sender === 'AMI_ASSISTANT' 
                      ? (state.language() === 'EN' ? 'AMI MANUFACTURING INTELLIGENCE' : 'AMI PROZESS-INTELLIGENZ') 
                      : (state.language() === 'EN' ? 'ENGINEER // YOU' : 'INGENIEUR // SIE') 
                    }}
                  </span>
                  <span class="text-[9px] font-mono text-zinc-400">{{ msg.timestamp }}</span>
                </div>
                <div
                  class="p-3.5 rounded-xl text-xs max-w-[90%] leading-relaxed"
                  [class.bg-[#192236]]="msg.sender === 'AMI_ASSISTANT'"
                  [class.text-zinc-200]="msg.sender === 'AMI_ASSISTANT'"
                  [class.border]="msg.sender === 'AMI_ASSISTANT'"
                  [class.border-[#2b354c]]="msg.sender === 'AMI_ASSISTANT'"
                  [class.bg-[#00f0ff]]="msg.sender === 'USER'"
                  [class.text-black]="msg.sender === 'USER'"
                  [class.font-medium]="msg.sender === 'USER'"
                >
                  <div class="whitespace-pre-line font-sans">{{ msg.text }}</div>
                </div>
              </div>
            }

            @if (ai.isLoading()) {
              <div class="flex items-center gap-2.5 p-3 rounded-xl bg-[#192236] border border-[#2b354c] max-w-[70%]">
                <div class="w-3 h-3 rounded-full bg-[#00f0ff] animate-ping"></div>
                <span class="text-xs font-mono text-zinc-300">
                  {{ state.language() === 'EN' ? 'AMI synthesizing manufacturing telemetry...' : 'AMI synthetisiert Produktions-Telemetrie...' }}
                </span>
              </div>
            }
          </div>

          <!-- Input Box -->
          <div class="p-3 border-t border-[#222733] bg-[#0a0c10]">
            <form (ngSubmit)="onSend()" class="flex items-center gap-2">
              <input
                type="text"
                [(ngModel)]="userQuery"
                name="userQuery"
                [placeholder]="state.language() === 'EN' 
                  ? 'Ask AMI (e.g. &quot;Optimize lattice for 75kg runner&quot; or &quot;Analyze AM-042&quot;)...' 
                  : 'Fragen Sie AMI (z.B. &quot;Gitter für 75kg Läufer optimieren&quot; oder &quot;AM-042 analysieren&quot;)...'"
                class="flex-1 bg-[#141924] border border-[#2b3345] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder:text-zinc-400 focus:outline-none focus:border-[#00f0ff]"
              />
              <button
                type="submit"
                [disabled]="!userQuery.trim() || ai.isLoading()"
                class="px-4 py-2.5 bg-[#00f0ff] hover:bg-[#38f4ff] disabled:opacity-30 disabled:cursor-not-allowed text-black font-bold text-xs font-mono rounded-xl transition-all flex items-center justify-center"
              >
                <mat-icon class="!text-sm !w-4 !h-4">send</mat-icon>
              </button>
            </form>
          </div>
        </div>
      </div>
    }
  `,
})
export class AIAssistantDrawerComponent {
  readonly ai = inject(GeminiAssistantService);
  readonly state = inject(ManufacturingState);

  readonly isOpen = signal<boolean>(false);
  userQuery = '';

  get promptChips(): string[] {
    if (this.state.language() === 'EN') {
      return [
        'Analyze AM-042 temperature variance',
        'Recommend lattice for 75kg marathoner',
        'Why did scrap rate spike this morning?',
        'Compare Carbon EPU 44 vs Bio-TPU 75B',
      ];
    } else {
      return [
        'AM-042 Temperatur-Abweichung analysieren',
        'Gitterstruktur für 75kg Läufer empfehlen',
        'Warum stieg die Ausschussquote heute Morgen?',
        'Carbon EPU 44 vs Bio-TPU 75B vergleichen',
      ];
    }
  }

  toggleOpen(): void {
    this.isOpen.update(v => !v);
  }

  submitPrompt(prompt: string): void {
    this.ai.sendMessage(prompt);
  }

  onSend(): void {
    if (this.userQuery.trim()) {
      this.ai.sendMessage(this.userQuery);
      this.userQuery = '';
    }
  }
}
