import { ChangeDetectionStrategy, Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { TopNavbarComponent } from './components/navigation/top-navbar';
import { SidebarComponent } from './components/navigation/sidebar';
import { WorkflowBannerComponent } from './components/workflow-banner/workflow-banner';
import { AIAssistantDrawerComponent } from './components/ai-assistant-drawer/ai-assistant-drawer';

@Component({
  selector: 'app-root',
  imports: [
    RouterOutlet,
    TopNavbarComponent,
    SidebarComponent,
    WorkflowBannerComponent,
    AIAssistantDrawerComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {}
