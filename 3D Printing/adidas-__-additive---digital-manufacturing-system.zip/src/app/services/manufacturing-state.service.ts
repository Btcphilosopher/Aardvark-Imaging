import { Injectable, computed, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import {
  MOCK_BATCHES,
  MOCK_ENERGY_METRICS,
  MOCK_FACTORIES,
  MOCK_INVENTORY,
  MOCK_MACHINES,
  MOCK_MATERIALS,
  MOCK_PRINT_JOBS,
  MOCK_PRODUCTS,
  MOCK_TRACEABILITY_NODES,
  MOCK_USERS,
} from '../data/additive-mock-data';
import {
  DemoWorkflowStep,
  EnergyDataPoint,
  FactoryFacility,
  GenerativeLatticeConfig,
  InventoryItem,
  Machine,
  Material,
  PrintJob,
  Product,
  ProductionBatch,
  TraceabilityNode,
  UserProfile,
  UserRole,
} from '../types/additive.types';


const GERMAN_WORKFLOW_STEPS: Record<number, { title: string; actionDescription: string }> = {
  1: { title: 'Leitstand', actionDescription: 'Überprüfen Sie die Fabrik-Telemetrie & das Hallenlayout' },
  2: { title: 'Produkt auswählen', actionDescription: 'Wählen Sie den ULTRABOOST 4DFWD EVO aus dem Schuhkatalog' },
  3: { title: '3D-Zwilling öffnen', actionDescription: 'Starten Sie das 3D-WebGL-Schuhmodell und erkunden Sie die Explosionsansicht' },
  4: { title: 'Zwischensohle auswählen', actionDescription: 'Isolieren Sie den 4DFWD Bow-Tie Gitter-Zwischensohlenkern' },
  5: { title: 'Gitterdichte anpassen', actionDescription: 'Passen Sie die generative Gitterdichte & Zellgeometrie in Echtzeit an' },
  6: { title: 'Schätzung generieren', actionDescription: 'Berechnen Sie Gewicht, Druckzeit und Steifigkeitseigenschaften' },
  7: { title: 'Material auswählen', actionDescription: 'Vergleichen Sie die Leistungsdaten von Carbon EPU 44 und Bio-TPU 75B' },
  8: { title: 'Druckvorbereitung', actionDescription: 'Slicing-Parameter, Schichthöhe und Ausrichtung konfigurieren' },
  9: { title: 'Optimale Druckerzuweisung', actionDescription: 'KI-Scheduler empfiehlt optimale Zuweisung auf Maschine AM-042' },
  10: { title: 'Drucksimulation starten', actionDescription: 'Analysieren Sie thermische Hotspots, Verzugsrisiko & Schichtvorschau' },
  11: { title: 'Produktion starten', actionDescription: 'Auftrag mit Sicherheitsbestätigung an aktive Maschine übermitteln' },
  12: { title: 'Maschinendaten überwachen', actionDescription: 'Verfolgen Sie Schichtfortschritt & Temperaturstabilität auf AM-042 in Echtzeit' },
  13: { title: 'Qualitäts-Messtechnik', actionDescription: 'Prüfen Sie optische 3D-Tomographie-Marker und Maßhaltigkeit' },
  14: { title: 'Charge freigeben', actionDescription: 'Geben Sie die Charge digital frei und buchen Sie diese ins Lager ein' },
  15: { title: 'Lagerbestand aktualisieren', actionDescription: 'Prüfen Sie den Harzverbrauch und die Anzahl fertiger Zwischensohlenpaare' },
  16: { title: 'Unternehmens-Analysen', actionDescription: 'OEE, Energieeinsparungen & CO2-Reduzierung der Fabrik analysieren' },
};

const GERMAN_TRANSLATIONS: Record<string, string> = {
  // Navigation & Headers
  'MANUFACTURING PIPELINE': 'PRODUKTIONS-PIPELINE',
  'GOVERNANCE & SUSTAINABILITY': 'COMPLIANCE & NACHHALTIGKEIT',
  'Command Center': 'Leitstand',
  'Factory Floor & Live Twins': 'Hallenlayout & Live-Zwillinge',
  'Footwear Catalog': 'Schuh-Katalog',
  '30 CAD Digital Specs': '30 CAD-Spezifikationen',
  '3D Digital Twin': '3D-Digitaler Zwilling',
  'Generative Lattice Studio': 'Generatives Gitter-Studio',
  'Material Science': 'Materialwissenschaft',
  'EPU, TPU & Bio-Elastomers': 'EPU, TPU & Bio-Elastomere',
  'Print Preparation': 'Druckvorbereitung',
  'Slicing & Simulation': 'Slicing & Simulation',
  'Machine Telemetry': 'Maschinen-Telemetrie',
  'DLS, SLS & MJF Fleet': 'DLS, SLS & MJF Flotte',
  'Quality Metrology': 'Qualitäts-Messtechnik',
  'Automated 3D Inspection': 'Automatisierte 3D-Inspektion',
  'Inventory & Silos': 'Lagerbestand & Silos',
  'Powder, Resins & Parts': 'Pulver, Harze & Teile',
  'Traceability Thread': 'Rückverfolgbarkeit',
  'End-to-End Genealogy': 'End-to-End-Stammbaum',
  'Executive Analytics': 'Führungs-Analysen',
  'OEE, Energy & ESG': 'OEE, Energie & ESG',
  '16-STEP DEMO PIPELINE': '16-SCHRITT DEMO-PIPELINE',
  'Step ': 'Schritt ',
  'ADVANCE DEMO': 'DEMO FORTFAHREN',
  'INDUSTRY 4.0 ACTIVE': 'INDUSTRIE 4.0 AKTIV',
  'UTC TELEMETRY LIVE': 'UTC TELEMETRIE LIVE',
  'SHIFT:': 'SCHICHT:',
  'OEE:': 'OEE:',
  'OUTPUT TODAY:': 'TAGESPRODUKTION:',
  'PAIRS': 'PAARE',
  'Telemetry Alerts': 'Telemetrie-Alarme',
  'active': 'aktiv',
  'Simulate Role Persona': 'Rollen-Szenario simulieren',
  'Global Manufacturing Nodes': 'Globale Fertigungsstandorte',
  'Telemetry Synced': 'Telemetrie synchronisiert',
  'Optimization Recommender': 'Optimierungs-Empfehlung',
  'Chamber Variance Detected': 'Abweichung in Kammer erkannt',
  'Just now': 'Gerade eben',
  '2m ago': 'Vor 2 Min.',
  '14m ago': 'Vor 14 Min.',
  'PREV': 'ZURÜCK',
  'NEXT STEP': 'NÄCHSTER SCHRITT',
  'FINISH': 'ABSCHLIESSEN',
  'DEMO STEP': 'DEMOSCHRITT',
  'DIGITAL MANUFACTURING SYSTEM': 'DIGITALES FERTIGUNGSSYSTEM',
  'Cells': 'Zellen',

  // Roles
  'ENGINEER': 'Ingenieur',
  'OPERATOR': 'Anlagenführer',
  'QUALITY_INSPECTOR': 'Qualitätsprüfer',
  'EXECUTIVE': 'Standortleiter',
};

@Injectable({
  providedIn: 'root',
})
export class ManufacturingState {
  private router = inject(Router);
  
  // Language Support
  readonly language = signal<'EN' | 'DE'>('EN');

  translate(key: string): string {
    if (this.language() === 'EN') return key;
    return GERMAN_TRANSLATIONS[key] || key;
  }

  t(key: string): string {
    return this.translate(key);
  }

  // Navigation and user context
  readonly factories = signal<FactoryFacility[]>(MOCK_FACTORIES);
  readonly selectedFactoryId = signal<string>('FAC-GER-01');
  readonly currentFactory = computed(() => 
    this.factories().find(f => f.id === this.selectedFactoryId()) || this.factories()[0]
  );

  readonly users = signal<UserProfile[]>(MOCK_USERS);
  readonly currentUserRole = signal<UserRole>('ENGINEER');
  readonly currentUser = computed(() => 
    this.users().find(u => u.role === this.currentUserRole()) || this.users()[0]
  );

  // Core domain data signals
  readonly machines = signal<Machine[]>(MOCK_MACHINES);
  readonly selectedMachineId = signal<string | null>('AM-042');
  readonly selectedMachine = computed(() => 
    this.machines().find(m => m.id === this.selectedMachineId()) || null
  );

  readonly products = signal<Product[]>(MOCK_PRODUCTS);
  readonly selectedProductId = signal<string>('PRD-4DFWD-EVO');
  readonly selectedProduct = computed(() => 
    this.products().find(p => p.id === this.selectedProductId()) || this.products()[0]
  );

  readonly selectedComponentId = signal<string>('CMP-4D-MIDSOLE');
  readonly selectedComponent = computed(() => {
    const prod = this.selectedProduct();
    return prod?.components.find(c => c.id === this.selectedComponentId()) || prod?.components[0] || null;
  });

  readonly materials = signal<Material[]>(MOCK_MATERIALS);
  readonly selectedMaterialId = signal<string>('MAT-EPU-44');
  readonly selectedMaterial = computed(() => 
    this.materials().find(m => m.id === this.selectedMaterialId()) || this.materials()[0]
  );

  readonly printJobs = signal<PrintJob[]>(MOCK_PRINT_JOBS);
  readonly activeJobId = signal<string | null>('PJ-9104');
  readonly activeJob = computed(() => 
    this.printJobs().find(j => j.id === this.activeJobId()) || null
  );

  readonly batches = signal<ProductionBatch[]>(MOCK_BATCHES);
  readonly selectedBatchId = signal<string>('BAT-2028-0914-A');
  readonly selectedBatch = computed(() => 
    this.batches().find(b => b.id === this.selectedBatchId()) || this.batches()[0]
  );

  readonly inventory = signal<InventoryItem[]>(MOCK_INVENTORY);
  readonly energyMetrics = signal<EnergyDataPoint[]>(MOCK_ENERGY_METRICS);
  readonly traceabilityNodes = signal<TraceabilityNode[]>(MOCK_TRACEABILITY_NODES);

  // Real-time production clock & counters
  readonly liveTimestamp = signal<Date>(new Date());
  readonly simulationActive = signal<boolean>(true);
  readonly totalUnitsCompletedToday = signal<number>(842);
  readonly scrapRatePct = signal<number>(1.8);
  readonly overallOeePct = signal<number>(89.4);
  readonly totalPowerConsumptionKwh = signal<number>(1420);

  // Guided demo workflow engine state (16 steps)
  readonly currentWorkflowStepIndex = signal<number>(0);
  readonly workflowCompleted = signal<boolean>(false);

  readonly workflowSteps = signal<DemoWorkflowStep[]>([
    { stepNumber: 1, title: 'Command Center', route: '/command-center', actionDescription: 'Review the high-level factory telemetry & digital twin floor', completed: true },
    { stepNumber: 2, title: 'Select Product', route: '/products', actionDescription: 'Select ULTRABOOST 4DFWD EVO from digital footwear catalog', targetObject: 'PRD-4DFWD-EVO', completed: false },
    { stepNumber: 3, title: 'Open 3D Digital Twin', route: '/digital-twin', actionDescription: 'Launch 3D WebGL footwear model and explore exploded view', completed: false },
    { stepNumber: 4, title: 'Select Midsole Component', route: '/digital-twin', actionDescription: 'Isolate the 4DFWD Bow-Tie Lattice Midsole Core', targetObject: 'CMP-4D-MIDSOLE', completed: false },
    { stepNumber: 5, title: 'Adjust Lattice Density', route: '/digital-twin', actionDescription: 'Modify generative lattice density & cell geometry in real-time', completed: false },
    { stepNumber: 6, title: 'Generate Estimate', route: '/digital-twin', actionDescription: 'Calculate new weight, print time, and stiffness properties', completed: false },
    { stepNumber: 7, title: 'Select Material', route: '/materials', actionDescription: 'Review Carbon EPU 44 vs Bio-TPU 75B performance specs', targetObject: 'MAT-EPU-44', completed: false },
    { stepNumber: 8, title: 'Create Print Job', route: '/print-jobs', actionDescription: 'Configure slicing parameters, layer height and orientation', completed: false },
    { stepNumber: 9, title: 'Optimal Printer Allocation', route: '/production-scheduler', actionDescription: 'AI scheduler recommends optimal Machine AM-042', targetObject: 'AM-042', completed: false },
    { stepNumber: 10, title: 'Run Print Simulation', route: '/print-jobs', actionDescription: 'Analyze thermal hotspots, warping risk & layer-by-layer slice preview', completed: false },
    { stepNumber: 11, title: 'Start Production', route: '/print-jobs', actionDescription: 'Submit job to live machine with confirmation safeguard', completed: false },
    { stepNumber: 12, title: 'Monitor Machine Telemetry', route: '/machines', actionDescription: 'Watch real-time layer progress & temperature stability on AM-042', completed: false },
    { stepNumber: 13, title: 'Quality Metrology', route: '/quality', actionDescription: 'Inspect 3D optical tomography markers and dimensional accuracy', targetObject: 'BAT-2028-0914-A', completed: false },
    { stepNumber: 14, title: 'Approve Batch', route: '/quality', actionDescription: 'Digitally approve batch and release to warehouse inventory', completed: false },
    { stepNumber: 15, title: 'Inventory Update', route: '/inventory', actionDescription: 'Verify raw resin consumption and finished midsole pair count', completed: false },
    { stepNumber: 16, title: 'Executive Analytics', route: '/analytics', actionDescription: 'Inspect factory OEE, energy savings & carbon footprint reduction', completed: false },
  ]);

  readonly translatedWorkflowSteps = computed(() => {
    const steps = this.workflowSteps();
    if (this.language() === 'EN') return steps;
    return steps.map(s => {
      const german = GERMAN_WORKFLOW_STEPS[s.stepNumber];
      if (german) {
        return {
          ...s,
          title: german.title,
          actionDescription: german.actionDescription,
        };
      }
      return s;
    });
  });

  // Notifications toast list
  readonly notifications = signal<{ id: string; title: string; message: string; type: 'INFO' | 'SUCCESS' | 'WARNING' | 'ERROR'; time: string }[]>([
    { id: '1', title: 'Telemetry Synced', message: 'Herzogenaurach Central Cell AM-01..12 online (88.6% Capacity)', type: 'SUCCESS', time: 'Just now' },
    { id: '2', title: 'Optimization Recommender', message: 'Job #PJ-9104 scheduled to AM-042 for optimal thermal balance', type: 'INFO', time: '2m ago' },
    { id: '3', title: 'Chamber Variance Detected', message: 'AM-051 rear bed temperature +3.4°C drift alert', type: 'WARNING', time: '14m ago' },
  ]);

  constructor() {
    // Start continuous realistic telemetry ticker
    if (typeof window !== 'undefined') {
      setInterval(() => {
        this.tickTelemetry();
      }, 2500);
    }
  }

  private tickTelemetry(): void {
    this.liveTimestamp.set(new Date());

    // Jitter machine temperatures and advance current print jobs
    this.machines.update(currentList => 
      currentList.map(m => {
        if (m.status === 'OPERATIONAL') {
          const tempDelta = (Math.random() - 0.5) * 0.4;
          const currentLayer = m.totalLayers > 0 ? Math.min(m.totalLayers, m.currentLayer + Math.floor(Math.random() * 3 + 1)) : 0;
          return {
            ...m,
            chamberTemp: +(m.chamberTemp + tempDelta).toFixed(1),
            bedTemp: +(m.bedTemp + tempDelta * 0.5).toFixed(1),
            currentLayer,
          };
        }
        return m;
      })
    );

    // Update active print jobs progress
    this.printJobs.update(jobs =>
      jobs.map(j => {
        if (j.status === 'PRINTING') {
          const newLayer = Math.min(j.totalLayers, j.currentLayer + 2);
          const progressPct = +((newLayer / j.totalLayers) * 100).toFixed(1);
          return {
            ...j,
            currentLayer: newLayer,
            progressPct,
            elapsedTimeMinutes: j.elapsedTimeMinutes + 0.1,
          };
        }
        return j;
      })
    );
  }

  // Factory & User
  setFactory(factoryId: string): void {
    this.selectedFactoryId.set(factoryId);
    this.addNotification('Factory Switched', `Active manufacturing node: ${this.currentFactory().name}`, 'INFO');
  }

  setUserRole(role: UserRole): void {
    this.currentUserRole.set(role);
    this.addNotification('Role Switched', `Access permissions updated for ${role} profile`, 'INFO');
  }

  // Product Selection & Component
  selectProduct(productId: string): void {
    this.selectedProductId.set(productId);
    const prod = this.selectedProduct();
    if (prod && prod.components.length > 0) {
      this.selectedComponentId.set(prod.components[0].id);
    }
  }

  selectComponent(componentId: string): void {
    this.selectedComponentId.set(componentId);
  }

  // Generative Lattice Updates
  updateGenerativeConfig(componentId: string, partialConfig: Partial<GenerativeLatticeConfig>): void {
    this.products.update(products => 
      products.map(p => ({
        ...p,
        components: p.components.map(c => {
          if (c.id === componentId && c.generativeConfig) {
            const updatedConfig: GenerativeLatticeConfig = {
              ...c.generativeConfig,
              ...partialConfig,
            };
            // Recalculate derived estimates based on density and geometry
            const densityFactor = updatedConfig.densityPct / 58;
            updatedConfig.weightGrams = Math.round(164 * densityFactor);
            updatedConfig.printTimeHours = +(1.7 * (0.6 + 0.4 * densityFactor)).toFixed(1);
            updatedConfig.materialCostEur = +(12.14 * densityFactor).toFixed(2);
            updatedConfig.forefootStiffnessNmm = Math.round(240 * (0.5 + 0.5 * densityFactor));
            updatedConfig.feaMaxStressMpa = +(4.8 * (1.2 - 0.2 * densityFactor)).toFixed(1);

            return {
              ...c,
              weightGrams: updatedConfig.weightGrams,
              printTimeHours: updatedConfig.printTimeHours,
              materialCostEur: updatedConfig.materialCostEur,
              stiffnessNmm: updatedConfig.forefootStiffnessNmm,
              generativeConfig: updatedConfig,
            };
          }
          return c;
        }),
      }))
    );
  }

  // Material Selection
  selectMaterial(materialId: string): void {
    this.selectedMaterialId.set(materialId);
  }

  // Machine Selection
  selectMachine(machineId: string): void {
    this.selectedMachineId.set(machineId);
  }

  // Print Job Lifecycle
  createAndSubmitJob(jobData: Partial<PrintJob>): PrintJob {
    const newJobId = `PJ-${Math.floor(1000 + Math.random() * 9000)}`;
    const newJob: PrintJob = {
      id: newJobId,
      jobCode: `JOB-2028-HZO-${newJobId}`,
      title: jobData.title || '4DFWD Generative Custom Spec Pair',
      productId: jobData.productId || this.selectedProductId(),
      componentId: jobData.componentId || this.selectedComponentId() || 'CMP-4D-MIDSOLE',
      materialId: jobData.materialId || this.selectedMaterialId(),
      machineId: jobData.machineId || 'AM-042',
      status: 'QUEUED',
      priority: jobData.priority || 'HIGH',
      layerHeightUm: jobData.layerHeightUm || 50,
      latticeDensityPct: jobData.latticeDensityPct || 58,
      supportType: jobData.supportType || 'GYROID_SELF_SUPPORT',
      buildPlateAngleDeg: jobData.buildPlateAngleDeg || 22.5,
      currentLayer: 0,
      totalLayers: 3840,
      progressPct: 0,
      estimatedPrintTimeMinutes: 102,
      elapsedTimeMinutes: 0,
      materialWeightGrams: 164,
      energyKwh: 0.38,
      totalCostEur: 18.42,
      createdAt: new Date().toISOString(),
      operator: this.currentUser().name,
      simulation: {
        estimatedTimeMinutes: 102,
        predictedFailureRiskPct: 0.9,
        thermalHotspotsCount: 0,
        maxResidualStressMpa: 4.8,
        estimatedWarpingMm: 0.12,
        materialFlowRateGmin: 2.4,
        totalEnergyConsumptionKwh: 0.38,
        supportVolumeCm3: 4.2,
        layerCount: 3840,
        slicingStatus: 'OPTIMAL',
        criticalWarnings: [],
      },
      ...jobData,
    };

    this.printJobs.update(jobs => [newJob, ...jobs]);
    this.activeJobId.set(newJobId);
    this.addNotification('Job Created', `Job #${newJob.jobCode} queued successfully`, 'SUCCESS');
    return newJob;
  }

  startProduction(jobId: string): void {
    this.printJobs.update(jobs =>
      jobs.map(j => {
        if (j.id === jobId) {
          return {
            ...j,
            status: 'PRINTING',
            startedAt: new Date().toISOString(),
          };
        }
        return j;
      })
    );

    const job = this.printJobs().find(j => j.id === jobId);
    if (job) {
      // Assign machine
      this.machines.update(machines =>
        machines.map(m => {
          if (m.id === job.machineId) {
            return {
              ...m,
              status: 'OPERATIONAL',
              currentJobId: job.id,
              currentProduct: job.title,
              currentLayer: 1,
              totalLayers: job.totalLayers,
            };
          }
          return m;
        })
      );
      this.addNotification('Production Started', `Machine ${job.machineId} initiated laser polymerization for ${job.jobCode}`, 'SUCCESS');
    }
  }

  recalibrateMachine(machineId: string): void {
    this.machines.update(machines =>
      machines.map(m => {
        if (m.id === machineId) {
          return {
            ...m,
            status: 'OPERATIONAL',
            warnings: [],
            chamberTemp: 41.0,
            bedTemp: 38.0,
            printHeadTemp: 43.0,
          };
        }
        return m;
      })
    );
    this.addNotification('Machine Recalibrated', `Cell ${machineId} optical pyrometer and thermal variance recalibrated to standard tolerance.`, 'SUCCESS');
  }

  // Quality Batch Approval
  approveBatch(batchId: string, notes?: string): void {
    this.batches.update(batches =>
      batches.map(b => {
        if (b.id === batchId) {
          return {
            ...b,
            qaStatus: 'APPROVED',
            inspectorNotes: notes || b.inspectorNotes,
            digitalSignature: `SIG_SHA256_${this.currentUser().badgeId}_${Date.now()}`,
          };
        }
        return b;
      })
    );

    // Update finished inventory
    this.inventory.update(items =>
      items.map(item => {
        if (item.category === 'FINISHED_COMPONENT') {
          return {
            ...item,
            currentStock: item.currentStock + 24,
          };
        }
        return item;
      })
    );

    this.totalUnitsCompletedToday.update(c => c + 24);
    this.addNotification('Batch Approved', `Batch #${batchId} passed metrology inspection. 24 pairs released to inventory.`, 'SUCCESS');
  }

  rejectBatch(batchId: string, reason: string): void {
    this.batches.update(batches =>
      batches.map(b => {
        if (b.id === batchId) {
          return {
            ...b,
            qaStatus: 'REJECTED',
            inspectorNotes: reason,
          };
        }
        return b;
      })
    );
    this.scrapRatePct.update(s => +(s + 0.2).toFixed(1));
    this.addNotification('Batch Flagged', `Batch #${batchId} quarantined: ${reason}`, 'WARNING');
  }

  // Inventory reorder
  reorderMaterial(itemId: string): void {
    this.inventory.update(items =>
      items.map(item => {
        if (item.id === itemId) {
          return {
            ...item,
            currentStock: item.currentStock + item.optimalBatchSize,
            autoReorderStatus: 'ORDER_PLACED',
          };
        }
        return item;
      })
    );
    this.addNotification('Order Placed', `Automated purchase order sent to supplier for ${itemId}`, 'SUCCESS');
  }

  // Guided Demo Workflow Navigation
  goToWorkflowStep(stepIndex: number): void {
    if (stepIndex >= 0 && stepIndex < this.workflowSteps().length) {
      this.currentWorkflowStepIndex.set(stepIndex);
      const step = this.workflowSteps()[stepIndex];
      
      // Update completion marks
      this.workflowSteps.update(steps =>
        steps.map((s, idx) => ({
          ...s,
          completed: idx <= stepIndex,
        }))
      );

      // Perform context updates based on step
      if (step.stepNumber === 2 && step.targetObject) {
        this.selectProduct(step.targetObject);
      } else if (step.stepNumber === 4 && step.targetObject) {
        this.selectComponent(step.targetObject);
      } else if (step.stepNumber === 5) {
        this.updateGenerativeConfig('CMP-4D-MIDSOLE', { densityPct: 62 });
      } else if (step.stepNumber === 7 && step.targetObject) {
        this.selectMaterial(step.targetObject);
      } else if (step.stepNumber === 9 && step.targetObject) {
        this.selectMachine(step.targetObject);
      } else if (step.stepNumber === 11) {
        this.startProduction('PJ-9104');
      } else if (step.stepNumber === 14) {
        this.approveBatch('BAT-2028-0914-A');
      }

      this.router.navigateByUrl(step.route);
    }
  }

  advanceWorkflow(): void {
    const nextIdx = this.currentWorkflowStepIndex() + 1;
    if (nextIdx < this.workflowSteps().length) {
      this.goToWorkflowStep(nextIdx);
    } else {
      this.workflowCompleted.set(true);
      this.addNotification('Workflow Complete', 'Completed the full Adidas Additive digital manufacturing pipeline!', 'SUCCESS');
    }
  }

  addNotification(title: string, message: string, type: 'INFO' | 'SUCCESS' | 'WARNING' | 'ERROR' = 'INFO'): void {
    const id = Math.random().toString(36).substring(2, 9);
    this.notifications.update(n => [{ id, title, message, type, time: 'Just now' }, ...n.slice(0, 7)]);
  }

  dismissNotification(id: string): void {
    this.notifications.update(n => n.filter(item => item.id !== id));
  }
}
