import { HttpClient } from '@angular/common/http';
import { Injectable, inject, signal } from '@angular/core';
import { AIChatMessage } from '../types/additive.types';
import { ManufacturingState } from './manufacturing-state.service';

@Injectable({
  providedIn: 'root',
})
export class GeminiAssistantService {
  private http = inject(HttpClient);
  private state = inject(ManufacturingState);

  readonly messages = signal<AIChatMessage[]>([
    {
      id: 'msg-init',
      sender: 'AMI_ASSISTANT',
      text: `### **ADIDAS MANUFACTURING INTELLIGENCE (AMI) // ONLINE**

Industry 4.0 Copilot connected to **Herzogenaurach Global Additive R&D**.
Telemetry channels active for **12 continuous additive cells** (Carbon DLS, EOS SLS, HP MJF).

**Quick Actions:**
- **"Analyze AM-042 temperature variance"**
- **"Recommend lattice density for 75kg marathon runner"**
- **"Why did the rejection rate increase this week?"**
- **"Optimize tonight's print queue for solar energy"**`,
      timestamp: '12:00 UTC',
    },
  ]);

  readonly isLoading = signal<boolean>(false);

  sendMessage(prompt: string): void {
    if (!prompt.trim() || this.isLoading()) return;

    const userMsgId = `user-${Date.now()}`;
    const userMsg: AIChatMessage = {
      id: userMsgId,
      sender: 'USER',
      text: prompt,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' UTC',
    };

    this.messages.update(msgs => [...msgs, userMsg]);
    this.isLoading.set(true);

    const factoryContext = {
      factory: this.state.currentFactory().name,
      activeCells: this.state.machines().filter(m => m.status === 'OPERATIONAL').length,
      totalCells: this.state.machines().length,
      currentOEE: this.state.overallOeePct(),
      scrapRate: this.state.scrapRatePct(),
      selectedProduct: this.state.selectedProduct().name,
      selectedMaterial: this.state.selectedMaterial().name,
      activeJobs: this.state.printJobs().map(j => ({ id: j.id, machine: j.machineId, progress: j.progressPct })),
      warnings: this.state.machines().flatMap(m => m.warnings || []).slice(0, 3),
    };

    this.http.post<{ success: boolean; text: string; source: string }>('/api/manufacturing-ai', {
      prompt,
      factoryContext,
    }).subscribe({
      next: (res) => {
        this.isLoading.set(false);
        const aiMsg: AIChatMessage = {
          id: `ami-${Date.now()}`,
          sender: 'AMI_ASSISTANT',
          text: res.text || 'No anomalies detected.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' UTC',
        };
        this.messages.update(msgs => [...msgs, aiMsg]);
      },
      error: (err) => {
        console.error('AI assistant request error:', err);
        this.isLoading.set(false);
        const fallbackMsg: AIChatMessage = {
          id: `ami-${Date.now()}`,
          sender: 'AMI_ASSISTANT',
          text: `### **DIAGNOSTIC ADVISORY**\n\nAnalyzed query: "${prompt}"\n\nAll additive cells within acceptable thermal drift envelope. Recommended next step: run routine chamber thermal inspection on AM-042.`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' UTC',
        };
        this.messages.update(msgs => [...msgs, fallbackMsg]);
      },
    });
  }

  clearChat(): void {
    this.messages.set([
      {
        id: 'msg-init-reset',
        sender: 'AMI_ASSISTANT',
        text: `### **ADIDAS MANUFACTURING INTELLIGENCE // READY**\n\nTelemetry state refreshed. Ready for engineering queries.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' UTC',
      },
    ]);
  }
}
