import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { ManufacturingState } from '../../services/manufacturing-state.service';
import { ProductionBatch } from '../../types/additive.types';

@Component({
  selector: 'app-quality',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-4 sm:p-6 space-y-6 max-w-7xl mx-auto select-none">
      <!-- Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold text-[#00f0ff] uppercase tracking-wider">QUALITY CONTROL & METROLOGY</span>
            <span class="text-xs font-mono text-zinc-400">// OPTICAL TOMOGRAPHY</span>
          </div>
          <h1 class="text-xl sm:text-2xl font-black text-white tracking-tight mt-1">
            Automated 3D Metrology & Batch Inspection
          </h1>
          <p class="text-xs text-zinc-400 font-mono mt-0.5">
            ISO 17296 additive tolerances • Sub-voxel void detection • Cryptographic quality release certificate
          </p>
        </div>

        <div class="flex items-center gap-2">
          <span class="px-3 py-1.5 rounded-lg bg-[#00e676]/10 text-[#00e676] border border-[#00e676]/30 font-mono text-xs font-bold flex items-center gap-1.5">
            <mat-icon class="!text-sm !w-4 !h-4">verified</mat-icon>
            <span>FACTORY YIELD: 98.4%</span>
          </span>
        </div>
      </div>

      <!-- Main Layout: Batches List + Detailed Metrology Station -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Batches List (Span 5) -->
        <div class="lg:col-span-5 space-y-3">
          <span class="text-xs font-mono font-bold text-white uppercase tracking-wider block">RECENT PRODUCTION BATCHES</span>

          @for (batch of state.batches(); track batch.id) {
            <button
              type="button"
              (click)="selectBatch(batch)"
              class="p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between text-left w-full"
              [class.bg-[#192236]]="batch.id === state.selectedBatchId()"
              [class.border-[#00f0ff]]="batch.id === state.selectedBatchId()"
              [class.shadow-lg]="batch.id === state.selectedBatchId()"
              [class.bg-[#11141c]]="batch.id !== state.selectedBatchId()"
              [class.border-[#222733]]="batch.id !== state.selectedBatchId()"
            >
              <div class="w-full">
                <div class="flex items-center justify-between mb-1.5">
                  <span class="text-xs font-mono font-bold text-white">{{ batch.batchNumber }}</span>
                  <span
                    class="px-2 py-0.5 rounded text-[10px] font-mono font-bold"
                    [class.bg-[#00e676]/20]="batch.qaStatus === 'APPROVED'"
                    [class.text-[#00e676]]="batch.qaStatus === 'APPROVED'"
                    [class.bg-[#ffb300]/20]="batch.qaStatus === 'PENDING_INSPECTION'"
                    [class.text-[#ffb300]]="batch.qaStatus === 'PENDING_INSPECTION'"
                    [class.bg-[#ff334b]/20]="batch.qaStatus === 'REJECTED'"
                    [class.text-[#ff334b]]="batch.qaStatus === 'REJECTED'"
                  >
                    {{ batch.qaStatus }}
                  </span>
                </div>

                <h3 class="text-xs font-bold text-white">{{ batch.productName }}</h3>
                <span class="text-[11px] font-mono text-zinc-400 block">{{ batch.componentName }}</span>

                <div class="grid grid-cols-3 gap-2 mt-3 pt-2.5 border-t border-[#1e2433] text-center font-mono">
                  <div class="bg-[#0c0e14] p-1.5 rounded-lg">
                    <span class="text-[9px] text-zinc-400 block">UNITS</span>
                    <span class="text-xs font-bold text-white">{{ batch.unitsProduced }} pairs</span>
                  </div>
                  <div class="bg-[#0c0e14] p-1.5 rounded-lg">
                    <span class="text-[9px] text-zinc-400 block">ACCURACY</span>
                    <span class="text-xs font-bold text-[#00f0ff]">{{ batch.dimensionalAccuracyPct }}%</span>
                  </div>
                  <div class="bg-[#0c0e14] p-1.5 rounded-lg">
                    <span class="text-[9px] text-zinc-400 block">SURFACE</span>
                    <span class="text-xs font-bold text-[#00e676]">{{ batch.surfaceQualityPct }}%</span>
                  </div>
                </div>
              </div>
            </button>
          }
        </div>

        <!-- Metrology Inspector Viewport (Span 7) -->
        <div class="lg:col-span-7 bg-[#11141c] border border-[#222733] rounded-2xl p-5 space-y-5">
          @if (state.selectedBatch(); as b) {
            <div class="flex items-center justify-between pb-3 border-b border-[#222733]">
              <div>
                <span class="text-[10px] font-mono text-[#00f0ff] font-bold uppercase">OPTICAL METROLOGY INSPECTION</span>
                <h2 class="text-base font-extrabold text-white mt-0.5">{{ b.batchNumber }} // {{ b.productName }}</h2>
              </div>
              <div class="text-right font-mono text-xs">
                <span class="text-zinc-400 block text-[10px]">Machine / Lot:</span>
                <span class="text-white font-bold">{{ b.machineId }} • {{ b.materialBatch }}</span>
              </div>
            </div>

            <!-- Dimensional Markers Table -->
            <div class="space-y-2.5">
              <span class="text-[10px] font-mono font-bold text-zinc-400 uppercase tracking-wider block">
                Critical Anatomical Inspection Points (±0.15 mm Tolerance)
              </span>

              <div class="space-y-2">
                @for (marker of b.inspectionMarkers; track marker.id) {
                  <div class="p-3 bg-[#0c0e14] rounded-xl border border-[#1e2433] flex items-center justify-between font-mono text-xs">
                    <div class="flex items-center gap-3">
                      <div
                        class="w-6 h-6 rounded-full flex items-center justify-center font-bold text-[10px]"
                        [class.bg-[#00e676]/20]="marker.status === 'PASS'"
                        [class.text-[#00e676]]="marker.status === 'PASS'"
                        [class.bg-[#ffb300]/20]="marker.status === 'WARNING'"
                        [class.text-[#ffb300]]="marker.status === 'WARNING'"
                      >
                        {{ marker.status === 'PASS' ? '✓' : '!' }}
                      </div>
                      <div>
                        <span class="font-bold text-white block">{{ marker.name }}</span>
                        <span class="text-[10px] text-zinc-400">{{ marker.metricName }}: {{ marker.measuredValue }} (Target: {{ marker.targetTolerance }})</span>
                      </div>
                    </div>

                    <div class="text-right">
                      <span class="font-bold" [class.text-[#00e676]]="marker.status === 'PASS'" [class.text-[#ffb300]]="marker.status === 'WARNING'">
                        {{ marker.deviation }}
                      </span>
                      <span class="text-[9px] text-zinc-400 block">{{ marker.status }}</span>
                    </div>
                  </div>
                }
              </div>
            </div>

            <!-- Shore Hardness & Mechanical Verification -->
            <div class="grid grid-cols-2 gap-3 text-xs font-mono">
              <div class="p-3 bg-[#0c0e14] rounded-xl border border-[#1e2433]">
                <span class="text-[10px] text-zinc-400 block">MEASURED SHORE HARDNESS</span>
                <span class="text-sm font-bold text-[#00f0ff]">{{ b.shoreHardnessMeasured }}</span>
              </div>
              <div class="p-3 bg-[#0c0e14] rounded-xl border border-[#1e2433]">
                <span class="text-[10px] text-zinc-400 block">TENSILE MODULUS</span>
                <span class="text-sm font-bold text-[#00e676]">{{ b.tensileModulusMpa }} MPa</span>
              </div>
            </div>

            <!-- Notes & Sign-off Actions -->
            <div class="space-y-3 pt-3 border-t border-[#1e2433]">
              <div>
                <label for="inspectorNotes" class="text-[10px] font-mono text-zinc-400 uppercase tracking-wider block mb-1">Quality Inspector Notes:</label>
                <textarea
                  id="inspectorNotes"
                  [(ngModel)]="inspectorNotes"
                  rows="2"
                  class="w-full bg-[#0c0e14] border border-[#1e2433] rounded-xl p-2.5 text-xs text-white placeholder:text-zinc-400 focus:outline-none focus:border-[#00f0ff] font-mono"
                  placeholder="Enter QA observations..."
                ></textarea>
              </div>

              @if (b.digitalSignature) {
                <div class="p-2.5 bg-[#00e676]/10 border border-[#00e676]/30 rounded-xl flex items-center justify-between text-xs font-mono">
                  <span class="text-zinc-300">Cryptographic Seal: <strong class="text-[#00e676]">{{ b.digitalSignature }}</strong></span>
                  <span class="text-[10px] text-zinc-400">PASSED</span>
                </div>
              }

              <div class="flex gap-2">
                <button
                  (click)="approveBatch(b.id)"
                  class="flex-1 py-2.5 bg-[#00e676] hover:bg-[#20f08c] text-black font-mono font-bold text-xs rounded-xl shadow-sm transition-all flex items-center justify-center gap-1.5"
                >
                  <mat-icon class="!text-sm !w-4 !h-4">verified</mat-icon>
                  <span>DIGITALLY APPROVE & RELEASE BATCH</span>
                </button>
                <button
                  (click)="flagBatch(b.id)"
                  class="px-4 py-2.5 bg-[#171c28] hover:bg-red-950/40 text-red-400 border border-red-900/40 font-mono text-xs rounded-xl transition-colors"
                >
                  FLAG FOR RE-SCAN
                </button>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `,
})
export class QualityComponent {
  readonly state = inject(ManufacturingState);

  inspectorNotes = 'Verified against DIN ISO 17296-3. Zero voids on X-ray CT scan.';

  selectBatch(batch: ProductionBatch): void {
    this.state.selectedBatchId.set(batch.id);
  }

  approveBatch(batchId: string): void {
    this.state.approveBatch(batchId, this.inspectorNotes);
  }

  flagBatch(batchId: string): void {
    this.state.rejectBatch(batchId, 'Flagged by operator for secondary laser scan.');
  }
}
