import { Component, ChangeDetectionStrategy, ElementRef, ViewChild, AfterViewInit, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { Factory3DScene } from '../../3d/factory-3d-scene';
import { ManufacturingState } from '../../services/manufacturing-state.service';

@Component({
  selector: 'app-command-center',
  imports: [CommonModule, RouterModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-4 sm:p-6 space-y-6 max-w-7xl mx-auto select-none">
      <!-- Section Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold text-[#00f0ff] uppercase tracking-wider">COMMAND CENTER // INDUSTRY 4.0</span>
            <span class="w-1.5 h-1.5 rounded-full bg-[#00e676] animate-pulse"></span>
          </div>
          <h1 class="text-xl sm:text-2xl font-black text-white tracking-tight mt-1">
            {{ state.currentFactory().name }}
          </h1>
          <p class="text-xs text-zinc-400 font-mono mt-0.5">
            Real-time digital twin monitoring • 12 High-Speed Additive Cells • Automated Robotics Fleet
          </p>
        </div>

        <div class="flex items-center gap-2.5">
          <button
            (click)="triggerEmergencyProtocol()"
            class="px-3 py-1.5 bg-[#1f2638] hover:bg-[#2c364d] text-zinc-300 font-mono text-xs rounded-lg border border-[#2e374c] flex items-center gap-1.5 transition-colors"
          >
            <mat-icon class="text-zinc-400 !text-sm !w-4 !h-4">refresh</mat-icon>
            <span>REFRESH TELEMETRY</span>
          </button>
          <a
            routerLink="/digital-twin"
            class="px-4 py-1.5 bg-[#00f0ff] hover:bg-[#38f4ff] text-black font-mono font-bold text-xs rounded-lg shadow-sm flex items-center gap-1.5 transition-all"
          >
            <span>LAUNCH 3D FOOTWEAR TWIN</span>
            <mat-icon class="!text-sm !w-4 !h-4">arrow_forward</mat-icon>
          </a>
        </div>
      </div>

      <!-- Factory KPI Grid (6 Top Metrics) -->
      <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <!-- KPI 1 -->
        <div class="bg-[#11141c] border border-[#222733] rounded-xl p-3.5 flex flex-col justify-between">
          <span class="text-[10px] font-mono text-zinc-400 uppercase tracking-wider">ACTIVE CELLS</span>
          <div class="flex items-baseline gap-1.5 my-1">
            <span class="text-2xl font-black text-white">{{ operationalMachinesCount() }}</span>
            <span class="text-xs font-mono text-zinc-400">/ {{ state.machines().length }}</span>
          </div>
          <div class="flex items-center gap-1 text-[10px] font-mono text-[#00e676]">
            <mat-icon class="!text-xs !w-3 !h-3">trending_up</mat-icon>
            <span>91.7% Fleet Online</span>
          </div>
        </div>

        <!-- KPI 2 -->
        <div class="bg-[#11141c] border border-[#222733] rounded-xl p-3.5 flex flex-col justify-between">
          <span class="text-[10px] font-mono text-zinc-400 uppercase tracking-wider">OUTPUT TODAY</span>
          <div class="flex items-baseline gap-1.5 my-1">
            <span class="text-2xl font-black text-white">{{ state.totalUnitsCompletedToday() }}</span>
            <span class="text-xs font-mono text-zinc-400">PAIRS</span>
          </div>
          <div class="flex items-center gap-1 text-[10px] font-mono text-[#00e676]">
            <mat-icon class="!text-xs !w-3 !h-3">done_all</mat-icon>
            <span>Target: 1,000 Pairs</span>
          </div>
        </div>

        <!-- KPI 3 -->
        <div class="bg-[#11141c] border border-[#222733] rounded-xl p-3.5 flex flex-col justify-between">
          <span class="text-[10px] font-mono text-zinc-400 uppercase tracking-wider">OVERALL OEE</span>
          <div class="flex items-baseline gap-1.5 my-1">
            <span class="text-2xl font-black text-[#00e676]">{{ state.overallOeePct() }}%</span>
          </div>
          <div class="flex items-center gap-1 text-[10px] font-mono text-zinc-400">
            <span>World-Class Additive</span>
          </div>
        </div>

        <!-- KPI 4 -->
        <div class="bg-[#11141c] border border-[#222733] rounded-xl p-3.5 flex flex-col justify-between">
          <span class="text-[10px] font-mono text-zinc-400 uppercase tracking-wider">SCRAP RATE</span>
          <div class="flex items-baseline gap-1.5 my-1">
            <span class="text-2xl font-black text-white">{{ state.scrapRatePct() }}%</span>
          </div>
          <div class="flex items-center gap-1 text-[10px] font-mono text-[#00e676]">
            <mat-icon class="!text-xs !w-3 !h-3">verified</mat-icon>
            <span>-0.4% vs Last Month</span>
          </div>
        </div>

        <!-- KPI 5 -->
        <div class="bg-[#11141c] border border-[#222733] rounded-xl p-3.5 flex flex-col justify-between">
          <span class="text-[10px] font-mono text-zinc-400 uppercase tracking-wider">ENERGY / PAIR</span>
          <div class="flex items-baseline gap-1.5 my-1">
            <span class="text-2xl font-black text-[#00f0ff]">0.38</span>
            <span class="text-xs font-mono text-zinc-400">kWh</span>
          </div>
          <div class="flex items-center gap-1 text-[10px] font-mono text-[#00f0ff]">
            <span>-46% vs Injection Mold</span>
          </div>
        </div>

        <!-- KPI 6 -->
        <div class="bg-[#11141c] border border-[#222733] rounded-xl p-3.5 flex flex-col justify-between">
          <span class="text-[10px] font-mono text-zinc-400 uppercase tracking-wider">RENEWABLE POWER</span>
          <div class="flex items-baseline gap-1.5 my-1">
            <span class="text-2xl font-black text-[#00e676]">{{ state.currentFactory().renewableEnergyPct }}%</span>
          </div>
          <div class="flex items-center gap-1 text-[10px] font-mono text-[#00e676]">
            <mat-icon class="!text-xs !w-3 !h-3">solar_power</mat-icon>
            <span>On-site Solar Array</span>
          </div>
        </div>
      </div>

      <!-- Main Layout: 3D Factory Floor Digital Twin + Real-time Machine Fleet Sidebar -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- 3D Factory Floor Digital Twin Container (Span 2) -->
        <div class="lg:col-span-2 bg-[#11141c] border border-[#222733] rounded-2xl overflow-hidden flex flex-col">
          <div class="p-3.5 bg-[#0e1118] border-b border-[#222733] flex items-center justify-between">
            <div class="flex items-center gap-2">
              <mat-icon class="text-[#00f0ff] !text-lg !w-5 !h-5">grid_view</mat-icon>
              <span class="text-xs font-mono font-bold text-white uppercase tracking-wider">
                3D FACTORY FLOOR DIGITAL TWIN // LIVE SECTOR A & B
              </span>
            </div>
            <div class="flex items-center gap-3 text-[11px] font-mono text-zinc-400">
              <span class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-[#00e676]"></span> Operational</span>
              <span class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-[#ffb300]"></span> Warning</span>
              <span class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-[#ff334b]"></span> Fault</span>
              <span class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-[#2979ff]"></span> Calibrating</span>
            </div>
          </div>

          <!-- 3D WebGL Canvas Viewport -->
          <div #factoryCanvasContainer class="w-full h-[380px] sm:h-[450px] relative bg-[#0a0c10] cursor-grab active:cursor-grabbing">
            <!-- Canvas Overlay HUD Controls -->
            <div class="absolute bottom-3 left-3 bg-[#11141c]/90 backdrop-blur-xs border border-[#222733] px-3 py-1.5 rounded-lg text-[11px] font-mono text-zinc-300 flex items-center gap-3">
              <span>Interactive 3D: Click machine to inspect • Drag to rotate • Scroll to zoom</span>
            </div>
          </div>
        </div>

        <!-- Right Side: Machine Fleet Health & Active Alerts -->
        <div class="space-y-4">
          <!-- Machine Inspector Card -->
          <div class="bg-[#11141c] border border-[#222733] rounded-2xl p-4">
            <div class="flex items-center justify-between pb-3 border-b border-[#222733]">
              <div class="flex items-center gap-2">
                <mat-icon class="text-[#00f0ff] !text-lg !w-5 !h-5">precision_manufacturing</mat-icon>
                <span class="text-xs font-mono font-bold text-white uppercase">PRIMARY CELL // {{ state.selectedMachine()?.code }}</span>
              </div>
              <span
                class="px-2 py-0.5 rounded text-[10px] font-mono font-bold"
                [class.bg-[#00e676]/20]="state.selectedMachine()?.status === 'OPERATIONAL'"
                [class.text-[#00e676]]="state.selectedMachine()?.status === 'OPERATIONAL'"
                [class.bg-[#ffb300]/20]="state.selectedMachine()?.status === 'WARNING'"
                [class.text-[#ffb300]]="state.selectedMachine()?.status === 'WARNING'"
              >
                {{ state.selectedMachine()?.status }}
              </span>
            </div>

            @if (state.selectedMachine(); as m) {
              <div class="mt-3 space-y-3 text-xs font-mono">
                <div class="flex justify-between">
                  <span class="text-zinc-400">Technology:</span>
                  <span class="text-white font-semibold">{{ m.technology }}</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-zinc-400">Loaded Material:</span>
                  <span class="text-[#00f0ff] font-semibold truncate max-w-[180px]">{{ m.materialLoaded }}</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-zinc-400">Current Job:</span>
                  <span class="text-zinc-200 truncate max-w-[180px]">{{ m.currentProduct || 'STANDBY' }}</span>
                </div>

                <!-- Thermal Readouts -->
                <div class="grid grid-cols-3 gap-2 pt-2 border-t border-[#1e2433]">
                  <div class="bg-[#0c0e14] p-2 rounded-lg border border-[#1e2433] text-center">
                    <span class="text-[9px] text-zinc-400 block">CHAMBER</span>
                    <span class="text-sm font-bold text-white">{{ m.chamberTemp }}°C</span>
                  </div>
                  <div class="bg-[#0c0e14] p-2 rounded-lg border border-[#1e2433] text-center">
                    <span class="text-[9px] text-zinc-400 block">BED TEMP</span>
                    <span class="text-sm font-bold text-white">{{ m.bedTemp }}°C</span>
                  </div>
                  <div class="bg-[#0c0e14] p-2 rounded-lg border border-[#1e2433] text-center">
                    <span class="text-[9px] text-zinc-400 block">HEAD TEMP</span>
                    <span class="text-sm font-bold text-[#00e676]">{{ m.printHeadTemp }}°C</span>
                  </div>
                </div>

                <!-- Print Progress (if printing) -->
                @if (m.totalLayers > 0) {
                  <div class="space-y-1.5 pt-1">
                    <div class="flex justify-between text-[11px]">
                      <span class="text-zinc-400">Layer {{ m.currentLayer }} / {{ m.totalLayers }}</span>
                      <span class="text-[#00f0ff] font-bold">{{ ((m.currentLayer / m.totalLayers) * 100).toFixed(1) }}%</span>
                    </div>
                    <div class="w-full bg-[#1e2433] h-2 rounded-full overflow-hidden">
                      <div
                        class="bg-gradient-to-r from-[#00f0ff] to-[#00e676] h-full transition-all duration-300"
                        [style.width.%]="(m.currentLayer / m.totalLayers) * 100"
                      ></div>
                    </div>
                  </div>
                }

                <div class="pt-2 flex gap-2">
                  <a
                    [routerLink]="['/machines']"
                    class="flex-1 py-1.5 bg-[#192236] hover:bg-[#222e47] text-white font-mono text-center text-xs rounded-lg border border-[#2b354c] transition-colors"
                  >
                    FULL TELEMETRY
                  </a>
                  <button
                    (click)="state.recalibrateMachine(m.id)"
                    class="px-3 py-1.5 bg-[#121620] hover:bg-[#1a202c] text-zinc-300 font-mono text-xs rounded-lg border border-[#2b3345] transition-colors"
                  >
                    RECALIBRATE
                  </button>
                </div>
              </div>
            }
          </div>

          <!-- Active Printing Jobs Widget -->
          <div class="bg-[#11141c] border border-[#222733] rounded-2xl p-4">
            <div class="flex items-center justify-between pb-2 border-b border-[#222733]">
              <span class="text-xs font-mono font-bold text-white uppercase">LIVE PRINT JOBS</span>
              <a routerLink="/print-jobs" class="text-[11px] font-mono text-[#00f0ff] hover:underline">VIEW ALL</a>
            </div>
            <div class="mt-3 space-y-2.5">
              @for (job of state.printJobs(); track job.id) {
                <div class="p-2.5 bg-[#0e1118] border border-[#1e2433] rounded-xl flex items-center justify-between">
                  <div class="flex flex-col max-w-[70%]">
                    <span class="text-xs font-semibold text-white truncate">{{ job.title }}</span>
                    <span class="text-[10px] font-mono text-zinc-400">{{ job.machineId }} • {{ job.materialId }}</span>
                  </div>
                  <div class="text-right">
                    <span class="text-xs font-mono font-bold text-[#00e676]">{{ job.progressPct }}%</span>
                    <span class="text-[9px] font-mono text-zinc-400 block">{{ job.status }}</span>
                  </div>
                </div>
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class CommandCenterComponent implements AfterViewInit, OnDestroy {
  @ViewChild('factoryCanvasContainer') canvasContainer!: ElementRef<HTMLDivElement>;

  readonly state = inject(ManufacturingState);
  private factory3dScene: Factory3DScene | null = null;

  operationalMachinesCount(): number {
    return this.state.machines().filter(m => m.status === 'OPERATIONAL').length;
  }

  ngAfterViewInit(): void {
    if (typeof window !== 'undefined' && this.canvasContainer) {
      this.factory3dScene = new Factory3DScene({
        container: this.canvasContainer.nativeElement,
        machines: this.state.machines(),
        onMachineSelected: (machineId) => {
          this.state.selectMachine(machineId);
        },
      });
    }
  }

  triggerEmergencyProtocol(): void {
    this.state.addNotification('Telemetry Refreshed', 'Synced full status with Herzogenaurach Digital Cell Gateway', 'SUCCESS');
  }

  ngOnDestroy(): void {
    this.factory3dScene?.destroy();
  }
}
