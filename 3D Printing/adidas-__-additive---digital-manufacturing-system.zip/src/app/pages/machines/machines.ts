import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ManufacturingState } from '../../services/manufacturing-state.service';

@Component({
  selector: 'app-machines',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-4 sm:p-6 space-y-6 max-w-7xl mx-auto select-none">
      <!-- Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold text-[#00f0ff] uppercase tracking-wider">MACHINE FLEET TELEMETRY</span>
            <span class="text-xs font-mono text-zinc-400">// 12 HIGH-SPEED CELLS</span>
          </div>
          <h1 class="text-xl sm:text-2xl font-black text-white tracking-tight mt-1">
            Real-Time Hardware & Sensor Telemetry
          </h1>
          <p class="text-xs text-zinc-400 font-mono mt-0.5">
            Carbon DLS Continuous Production • EOS SLS Lasers • HP Multi Jet Fusion • Pyrometer Drift Monitoring
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button
            (click)="state.recalibrateMachine('AM-051')"
            class="px-3 py-1.5 bg-[#192236] hover:bg-[#23304c] text-zinc-200 border border-[#2e3b56] font-mono text-xs rounded-lg flex items-center gap-1.5 transition-colors"
          >
            <mat-icon class="!text-sm !w-4 !h-4">build</mat-icon>
            <span>AUTO-CALIBRATE FLEET</span>
          </button>
        </div>
      </div>

      <!-- Main Layout: Fleet Cards + Deep Inspector -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Machine Fleet Grid (Span 7) -->
        <div class="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-3">
          @for (m of state.machines(); track m.id) {
            <button
              type="button"
              (click)="state.selectMachine(m.id)"
              class="p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between text-left w-full"
              [class.bg-[#192236]]="m.id === state.selectedMachineId()"
              [class.border-[#00f0ff]]="m.id === state.selectedMachineId()"
              [class.shadow-lg]="m.id === state.selectedMachineId()"
              [class.bg-[#11141c]]="m.id !== state.selectedMachineId()"
              [class.border-[#222733]]="m.id !== state.selectedMachineId()"
              [class.hover:border-[#2e374c]]="m.id !== state.selectedMachineId()"
            >
              <div class="w-full">
                <div class="flex items-center justify-between mb-2">
                  <span class="text-xs font-mono font-bold text-white">{{ m.code }}</span>
                  <span
                    class="px-2 py-0.5 rounded text-[10px] font-mono font-bold"
                    [class.bg-[#00e676]/20]="m.status === 'OPERATIONAL'"
                    [class.text-[#00e676]]="m.status === 'OPERATIONAL'"
                    [class.bg-[#ffb300]/20]="m.status === 'WARNING'"
                    [class.text-[#ffb300]]="m.status === 'WARNING'"
                    [class.bg-[#ff334b]/20]="m.status === 'FAULT'"
                    [class.text-[#ff334b]]="m.status === 'FAULT'"
                    [class.bg-[#2979ff]/20]="m.status === 'MAINTENANCE'"
                    [class.text-[#2979ff]]="m.status === 'MAINTENANCE'"
                  >
                    {{ m.status }}
                  </span>
                </div>

                <span class="text-[11px] font-mono text-[#00f0ff] font-semibold block truncate">{{ m.technology }}</span>
                <span class="text-xs text-zinc-300 font-sans block mt-1 truncate">{{ m.currentProduct || 'Standby // Ready for Queue' }}</span>

                <!-- Quick Telemetry Readout -->
                <div class="grid grid-cols-3 gap-1.5 mt-3 pt-2.5 border-t border-[#1e2433] text-center font-mono">
                  <div class="bg-[#0c0e14] p-1.5 rounded-lg">
                    <span class="text-[9px] text-zinc-400 block">CHAMBER</span>
                    <span class="text-xs font-bold text-white">{{ m.chamberTemp }}°C</span>
                  </div>
                  <div class="bg-[#0c0e14] p-1.5 rounded-lg">
                    <span class="text-[9px] text-zinc-400 block">RESIN</span>
                    <span class="text-xs font-bold text-[#00f0ff]">{{ m.materialRemainingPct }}%</span>
                  </div>
                  <div class="bg-[#0c0e14] p-1.5 rounded-lg">
                    <span class="text-[9px] text-zinc-400 block">OEE</span>
                    <span class="text-xs font-bold text-[#00e676]">{{ m.oeePct }}%</span>
                  </div>
                </div>

                <!-- Layer Progress Bar (if running) -->
                @if (m.totalLayers > 0) {
                  <div class="mt-3 space-y-1">
                    <div class="flex justify-between text-[10px] font-mono text-zinc-400">
                      <span>Progress</span>
                      <span class="text-[#00f0ff]">{{ ((m.currentLayer / m.totalLayers) * 100).toFixed(1) }}%</span>
                    </div>
                    <div class="w-full bg-[#1e2433] h-1.5 rounded-full overflow-hidden">
                      <div
                        class="bg-gradient-to-r from-[#00f0ff] to-[#00e676] h-full"
                        [style.width.%]="(m.currentLayer / m.totalLayers) * 100"
                      ></div>
                    </div>
                  </div>
                }
              </div>
            </button>
          }
        </div>

        <!-- Deep Machine Console Inspector (Span 5) -->
        <div class="lg:col-span-5 bg-[#11141c] border border-[#222733] rounded-2xl p-5 space-y-5">
          @if (state.selectedMachine(); as m) {
            <div class="flex items-center justify-between pb-3 border-b border-[#222733]">
              <div>
                <span class="text-[10px] font-mono text-[#00f0ff] font-bold uppercase">CELL CONSOLE</span>
                <h2 class="text-base font-extrabold text-white mt-0.5">{{ m.name }}</h2>
              </div>
              <span class="text-xs font-mono text-zinc-400">{{ m.cellLocation }}</span>
            </div>

            <!-- Active Warnings Banner -->
            @if (m.warnings && m.warnings.length > 0) {
              <div class="p-3 bg-[#ffb300]/10 border border-[#ffb300]/30 rounded-xl space-y-1">
                <div class="flex items-center gap-1.5 text-xs font-mono font-bold text-[#ffb300]">
                  <mat-icon class="!text-sm !w-4 !h-4">warning</mat-icon>
                  <span>ACTIVE TELEMETRY DRIFT NOTICES</span>
                </div>
                @for (w of m.warnings; track w) {
                  <p class="text-xs font-mono text-zinc-300">• {{ w }}</p>
                }
              </div>
            }

            <!-- Live Sensor Indicators -->
            <div class="space-y-3 font-mono text-xs">
              <span class="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">Live Thermal & Physical Readouts</span>

              <div class="grid grid-cols-2 gap-3">
                <div class="p-3 bg-[#0c0e14] rounded-xl border border-[#1e2433]">
                  <span class="text-[10px] text-zinc-400 block">CHAMBER TEMP</span>
                  <span class="text-lg font-bold text-white">{{ m.chamberTemp }}°C</span>
                  <span class="text-[10px] text-[#00e676] block mt-0.5">Tolerance: ±1.2°C</span>
                </div>
                <div class="p-3 bg-[#0c0e14] rounded-xl border border-[#1e2433]">
                  <span class="text-[10px] text-zinc-400 block">BED TEMP</span>
                  <span class="text-lg font-bold text-white">{{ m.bedTemp }}°C</span>
                  <span class="text-[10px] text-[#00e676] block mt-0.5">Stability: 99.8%</span>
                </div>
                <div class="p-3 bg-[#0c0e14] rounded-xl border border-[#1e2433]">
                  <span class="text-[10px] text-zinc-400 block">PRINT HEAD / OPTICS</span>
                  <span class="text-lg font-bold text-[#00f0ff]">{{ m.printHeadTemp }}°C</span>
                  <span class="text-[10px] text-zinc-400 block mt-0.5">Laser Galvo Calibrated</span>
                </div>
                <div class="p-3 bg-[#0c0e14] rounded-xl border border-[#1e2433]">
                  <span class="text-[10px] text-zinc-400 block">RESIN REMAINING</span>
                  <span class="text-lg font-bold text-[#00e676]">{{ m.materialRemainingPct }}%</span>
                  <span class="text-[10px] text-zinc-400 block mt-0.5">Continuous Auto-Feed</span>
                </div>
              </div>
            </div>

            <!-- Manual Control Buttons -->
            <div class="pt-3 border-t border-[#1e2433] space-y-2">
              <span class="text-[10px] font-mono text-zinc-400 uppercase tracking-wider block">Manual Operator Controls</span>
              <div class="grid grid-cols-2 gap-2">
                <button
                  (click)="state.recalibrateMachine(m.id)"
                  class="py-2.5 bg-[#00f0ff] hover:bg-[#38f4ff] text-black font-mono font-bold text-xs rounded-xl shadow-sm transition-all flex items-center justify-center gap-1.5"
                >
                  <mat-icon class="!text-sm !w-4 !h-4">tune</mat-icon>
                  <span>RECALIBRATE CELL</span>
                </button>
                <button
                  (click)="triggerEmergencyStop(m.id)"
                  class="py-2.5 bg-[#171c28] hover:bg-red-950/40 text-red-400 border border-red-900/40 font-mono font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-1.5"
                >
                  <mat-icon class="!text-sm !w-4 !h-4">stop_circle</mat-icon>
                  <span>EMERGENCY PAUSE</span>
                </button>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `,
})
export class MachinesComponent {
  readonly state = inject(ManufacturingState);

  triggerEmergencyStop(machineId: string): void {
    this.state.addNotification('Machine Paused', `Cell ${machineId} safety interlock paused for operator inspection.`, 'WARNING');
  }
}
