import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ManufacturingState } from '../../services/manufacturing-state.service';

@Component({
  selector: 'app-traceability',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-4 sm:p-6 space-y-6 max-w-7xl mx-auto select-none">
      <!-- Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold text-[#00f0ff] uppercase tracking-wider">END-TO-END DIGITAL THREAD</span>
            <span class="text-xs font-mono text-zinc-400">// CRYPTOGRAPHIC TRACEABILITY</span>
          </div>
          <h1 class="text-xl sm:text-2xl font-black text-white tracking-tight mt-1">
            Manufacturing Genealogy & Provenance Chain
          </h1>
          <p class="text-xs text-zinc-400 font-mono mt-0.5">
            Full lifecycle traceability: CAD Geometry → Resin Lot → Machine Laser Profile → Metrology Scan → High-Bay Storage
          </p>
        </div>
      </div>

      <!-- Traceability Pipeline Timeline Flow -->
      <div class="bg-[#11141c] border border-[#222733] rounded-2xl p-6">
        <div class="space-y-6">
          @for (node of state.traceabilityNodes(); track node.id; let idx = $index; let isLast = $last) {
            <div class="relative flex items-start gap-4">
              <!-- Left: Step Node Dot & Vertical Connector Line -->
              <div class="flex flex-col items-center">
                <div class="w-9 h-9 rounded-xl bg-[#00f0ff]/10 border border-[#00f0ff]/40 text-[#00f0ff] font-mono font-bold text-xs flex items-center justify-center z-10">
                  {{ idx + 1 }}
                </div>
                @if (!isLast) {
                  <div class="w-0.5 h-16 bg-gradient-to-b from-[#00f0ff]/40 to-[#222733] my-1"></div>
                }
              </div>

              <!-- Right: Content Node Box -->
              <div class="flex-1 bg-[#0c0e14] border border-[#1e2433] rounded-xl p-4 space-y-2 font-mono text-xs">
                <div class="flex items-center justify-between">
                  <div class="flex items-center gap-2">
                    <span class="px-2 py-0.5 rounded bg-[#192236] text-[#00f0ff] text-[10px] font-bold">
                      {{ node.type }}
                    </span>
                    <h3 class="text-sm font-bold text-white">{{ node.label }}</h3>
                  </div>
                  <span class="text-[10px] text-zinc-400">{{ node.timestamp }}</span>
                </div>

                <span class="text-xs text-zinc-400 block">{{ node.sublabel }}</span>

                <!-- Metadata Key-Value pairs -->
                @if (node.metadata) {
                  <div class="flex flex-wrap gap-3 pt-2 border-t border-[#181d28] text-[11px]">
                    @for (item of node.metadata | keyvalue; track item.key) {
                      <div class="bg-[#121622] px-2.5 py-1 rounded-md border border-[#1e2638]">
                        <span class="text-zinc-400">{{ item.key }}: </span>
                        <strong class="text-zinc-200">{{ item.value }}</strong>
                      </div>
                    }
                  </div>
                }
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `,
})
export class TraceabilityComponent {
  readonly state = inject(ManufacturingState);
}
