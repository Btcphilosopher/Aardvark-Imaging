import { Component, ChangeDetectionStrategy, ElementRef, ViewChild, AfterViewInit, OnDestroy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { Footwear3DScene } from '../../3d/footwear-3d-scene';
import { ManufacturingState } from '../../services/manufacturing-state.service';
import { CellGeometry } from '../../types/additive.types';

@Component({
  selector: 'app-digital-twin',
  imports: [CommonModule, FormsModule, RouterModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-4 sm:p-6 space-y-6 max-w-7xl mx-auto select-none">
      <!-- Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold text-[#00f0ff] uppercase tracking-wider">3D DIGITAL TWIN // GENERATIVE LATTICE STUDIO</span>
            <span class="text-xs font-mono text-zinc-400">// CAD & FEA BIOMECHANICS</span>
          </div>
          <h1 class="text-xl sm:text-2xl font-black text-white tracking-tight mt-1">
            {{ state.selectedProduct().name }}
          </h1>
          <p class="text-xs text-zinc-400 font-mono mt-0.5">
            Parametric TPMS Gyroid Infill • Real-time FEA Stress Solver • Sub-millimeter Tolerance Verification
          </p>
        </div>

        <div class="flex items-center gap-2.5">
          <!-- View Modes -->
          <div class="flex bg-[#121622] p-1 rounded-xl border border-[#2b354d]">
            <button
              (click)="setViewMode('REALISTIC')"
              class="px-2.5 py-1 text-xs font-mono rounded-lg transition-colors"
              [class.bg-[#00f0ff]]="viewMode() === 'REALISTIC'"
              [class.text-black]="viewMode() === 'REALISTIC'"
              [class.font-bold]="viewMode() === 'REALISTIC'"
              [class.text-zinc-300]="viewMode() !== 'REALISTIC'"
            >
              REALISTIC
            </button>
            <button
              (click)="setViewMode('FEA_HEATMAP')"
              class="px-2.5 py-1 text-xs font-mono rounded-lg transition-colors flex items-center gap-1"
              [class.bg-[#00e676]]="viewMode() === 'FEA_HEATMAP'"
              [class.text-black]="viewMode() === 'FEA_HEATMAP'"
              [class.font-bold]="viewMode() === 'FEA_HEATMAP'"
              [class.text-zinc-300]="viewMode() !== 'FEA_HEATMAP'"
            >
              <span class="w-1.5 h-1.5 rounded-full bg-red-500"></span>
              FEA STRESS
            </button>
            <button
              (click)="setViewMode('WIREFRAME')"
              class="px-2.5 py-1 text-xs font-mono rounded-lg transition-colors"
              [class.bg-[#00f0ff]]="viewMode() === 'WIREFRAME'"
              [class.text-black]="viewMode() === 'WIREFRAME'"
              [class.font-bold]="viewMode() === 'WIREFRAME'"
              [class.text-zinc-300]="viewMode() !== 'WIREFRAME'"
            >
              WIREFRAME
            </button>
            <button
              (click)="setViewMode('XRAY')"
              class="px-2.5 py-1 text-xs font-mono rounded-lg transition-colors"
              [class.bg-[#00f0ff]]="viewMode() === 'XRAY'"
              [class.text-black]="viewMode() === 'XRAY'"
              [class.font-bold]="viewMode() === 'XRAY'"
              [class.text-zinc-300]="viewMode() !== 'XRAY'"
            >
              X-RAY
            </button>
          </div>

          <button
            (click)="dispatchToPrintJobs()"
            class="px-4 py-2 bg-[#00f0ff] hover:bg-[#38f4ff] text-black font-mono font-bold text-xs rounded-xl shadow-sm flex items-center gap-1.5 transition-all"
          >
            <span>SEND TO PRINT PREP</span>
            <mat-icon class="!text-sm !w-4 !h-4">arrow_forward</mat-icon>
          </button>
        </div>
      </div>

      <!-- Main Layout: 3D Viewport on Left, Generative Customizer & Metrics on Right -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- 3D Canvas Area (Span 7) -->
        <div class="lg:col-span-7 bg-[#11141c] border border-[#222733] rounded-2xl overflow-hidden flex flex-col">
          <!-- 3D Viewport Top Toolbar -->
          <div class="p-3 bg-[#0c0e14] border-b border-[#222733] flex items-center justify-between">
            <div class="flex items-center gap-2 text-xs font-mono text-zinc-300">
              <mat-icon class="text-[#00f0ff] !text-base">3d_rotation</mat-icon>
              <span>Selected Part: <strong class="text-white">{{ activeComponentType() }}</strong></span>
            </div>

            <!-- Exploded View Slider -->
            <div class="flex items-center gap-2 text-xs font-mono text-zinc-300">
              <span class="text-zinc-400">EXPLODED VIEW:</span>
              <input
                type="range"
                min="0"
                max="100"
                [(ngModel)]="explodedProgress"
                (input)="onExplodedChange()"
                class="w-24 accent-[#00f0ff] cursor-pointer"
              />
              <span class="text-[#00f0ff] font-bold w-7 text-right">{{ explodedProgress }}%</span>
            </div>
          </div>

          <!-- WebGL Canvas Container -->
          <div #shoeCanvasContainer class="w-full h-[450px] sm:h-[520px] relative bg-[#0a0c10] cursor-grab active:cursor-grabbing">
            <!-- FEA Stress Legend (shown in FEA mode) -->
            @if (viewMode() === 'FEA_HEATMAP') {
              <div class="absolute top-4 left-4 bg-[#11141c]/90 backdrop-blur-xs border border-[#222733] p-3 rounded-xl text-[10px] font-mono space-y-1.5">
                <span class="text-white font-bold block uppercase tracking-wider">VON MISES STRESS (MPa)</span>
                <div class="w-32 h-3 rounded bg-gradient-to-r from-[#00f0ff] via-[#00e676] via-yellow-400 to-red-500"></div>
                <div class="flex justify-between text-zinc-400 text-[9px]">
                  <span>0.0 MPa (Idle)</span>
                  <span>3.0 MPa</span>
                  <span class="text-red-400">6.8 MPa (Max)</span>
                </div>
              </div>
            }

            <!-- Canvas Micro Controls (Bottom) -->
            <div class="absolute bottom-4 left-4 right-4 flex items-center justify-between">
              <div class="bg-[#11141c]/90 backdrop-blur-xs border border-[#222733] px-3 py-1.5 rounded-lg text-[10px] font-mono text-zinc-300 flex items-center gap-3">
                <span>Left Click: Rotate</span>
                <span>•</span>
                <span>Scroll: Zoom</span>
                <span>•</span>
                <span>Click Part: Isolate</span>
              </div>

              <div class="flex gap-2">
                <button
                  (click)="toggleAutoRotate()"
                  class="p-2 bg-[#11141c]/90 hover:bg-[#1c2233] border border-[#222733] rounded-lg text-zinc-300 text-xs font-mono"
                  title="Toggle Auto Rotation"
                >
                  <mat-icon class="!text-sm !w-4 !h-4">autorenew</mat-icon>
                </button>
                <button
                  (click)="resetCameraView()"
                  class="p-2 bg-[#11141c]/90 hover:bg-[#1c2233] border border-[#222733] rounded-lg text-zinc-300 text-xs font-mono"
                  title="Reset Camera"
                >
                  <mat-icon class="!text-sm !w-4 !h-4">center_focus_strong</mat-icon>
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- Right Side: Generative Lattice Controls & Manufacturing Predictor (Span 5) -->
        <div class="lg:col-span-5 space-y-4">
          <!-- Component Selector Tabs -->
          <div class="bg-[#11141c] border border-[#222733] rounded-2xl p-4">
            <span class="text-xs font-mono font-bold text-white uppercase tracking-wider block mb-3">
              ISOLATE SHOE SUB-ASSEMBLY
            </span>
            <div class="grid grid-cols-2 gap-2 text-xs font-mono">
              <button
                (click)="selectComponent('MIDSOLE')"
                class="p-2.5 rounded-xl border text-left transition-all"
                [class.bg-[#00f0ff]/10]="activeComponentType() === 'MIDSOLE'"
                [class.border-[#00f0ff]]="activeComponentType() === 'MIDSOLE'"
                [class.text-[#00f0ff]]="activeComponentType() === 'MIDSOLE'"
                [class.bg-[#0d1017]]="activeComponentType() !== 'MIDSOLE'"
                [class.border-[#1e2433]]="activeComponentType() !== 'MIDSOLE'"
                [class.text-zinc-300]="activeComponentType() !== 'MIDSOLE'"
              >
                <span class="font-bold block">3D Lattice Midsole</span>
                <span class="text-[10px] text-zinc-400">Carbon EPU 44 (Additive)</span>
              </button>
              <button
                (click)="selectComponent('UPPER')"
                class="p-2.5 rounded-xl border text-left transition-all"
                [class.bg-[#00f0ff]/10]="activeComponentType() === 'UPPER'"
                [class.border-[#00f0ff]]="activeComponentType() === 'UPPER'"
                [class.text-[#00f0ff]]="activeComponentType() === 'UPPER'"
                [class.bg-[#0d1017]]="activeComponentType() !== 'UPPER'"
                [class.border-[#1e2433]]="activeComponentType() !== 'UPPER'"
                [class.text-zinc-300]="activeComponentType() !== 'UPPER'"
              >
                <span class="font-bold block">Primeknit+ Upper</span>
                <span class="text-[10px] text-zinc-400">Recycled Ocean TPU</span>
              </button>
              <button
                (click)="selectComponent('ENERGY_RODS')"
                class="p-2.5 rounded-xl border text-left transition-all"
                [class.bg-[#00f0ff]/10]="activeComponentType() === 'ENERGY_RODS'"
                [class.border-[#00f0ff]]="activeComponentType() === 'ENERGY_RODS'"
                [class.text-[#00f0ff]]="activeComponentType() === 'ENERGY_RODS'"
                [class.bg-[#0d1017]]="activeComponentType() !== 'ENERGY_RODS'"
                [class.border-[#1e2433]]="activeComponentType() !== 'ENERGY_RODS'"
                [class.text-zinc-300]="activeComponentType() !== 'ENERGY_RODS'"
              >
                <span class="font-bold block">EnergyRods 3.0</span>
                <span class="text-[10px] text-zinc-400">CNT-TPU 95 Nanotube</span>
              </button>
              <button
                (click)="selectComponent('OUTSOLE')"
                class="p-2.5 rounded-xl border text-left transition-all"
                [class.bg-[#00f0ff]/10]="activeComponentType() === 'OUTSOLE'"
                [class.border-[#00f0ff]]="activeComponentType() === 'OUTSOLE'"
                [class.text-[#00f0ff]]="activeComponentType() === 'OUTSOLE'"
                [class.bg-[#0d1017]]="activeComponentType() !== 'OUTSOLE'"
                [class.border-[#1e2433]]="activeComponentType() !== 'OUTSOLE'"
                [class.text-zinc-300]="activeComponentType() !== 'OUTSOLE'"
              >
                <span class="font-bold block">Continental Outsole</span>
                <span class="text-[10px] text-zinc-400">Forward AM TPU 88A</span>
              </button>
            </div>
          </div>

          <!-- Generative Lattice Parametric Controls (Active when Midsole selected) -->
          <div class="bg-[#11141c] border border-[#222733] rounded-2xl p-4 space-y-4">
            <div class="flex items-center justify-between pb-2 border-b border-[#222733]">
              <span class="text-xs font-mono font-bold text-white uppercase">GENERATIVE LATTICE PARAMETERS</span>
              <span class="text-[10px] font-mono text-[#00f0ff]">LIVE COMPUTATION</span>
            </div>

            <!-- Lattice Cell Geometry Selector -->
            <div class="space-y-1.5">
              <div class="text-[11px] font-mono text-zinc-400 flex justify-between">
                <span>Cell Topology:</span>
                <span class="text-[#00f0ff] font-bold">{{ latticeGeometry }}</span>
              </div>
              <div class="grid grid-cols-3 gap-1.5 text-[11px] font-mono">
                <button
                  (click)="setGeometry('GYROID_TPMS')"
                  class="py-1.5 px-2 rounded-lg border text-center transition-colors"
                  [class.bg-[#00f0ff]]="latticeGeometry === 'GYROID_TPMS'"
                  [class.text-black]="latticeGeometry === 'GYROID_TPMS'"
                  [class.font-bold]="latticeGeometry === 'GYROID_TPMS'"
                  [class.bg-[#0d1017]]="latticeGeometry !== 'GYROID_TPMS'"
                  [class.border-[#222733]]="latticeGeometry !== 'GYROID_TPMS'"
                  [class.text-zinc-300]="latticeGeometry !== 'GYROID_TPMS'"
                >
                  Gyroid TPMS
                </button>
                <button
                  (click)="setGeometry('DIAMOND_OCTET')"
                  class="py-1.5 px-2 rounded-lg border text-center transition-colors"
                  [class.bg-[#00f0ff]]="latticeGeometry === 'DIAMOND_OCTET'"
                  [class.text-black]="latticeGeometry === 'DIAMOND_OCTET'"
                  [class.font-bold]="latticeGeometry === 'DIAMOND_OCTET'"
                  [class.bg-[#0d1017]]="latticeGeometry !== 'DIAMOND_OCTET'"
                  [class.border-[#222733]]="latticeGeometry !== 'DIAMOND_OCTET'"
                  [class.text-zinc-300]="latticeGeometry !== 'DIAMOND_OCTET'"
                >
                  Diamond Octet
                </button>
                <button
                  (click)="setGeometry('VORONOI')"
                  class="py-1.5 px-2 rounded-lg border text-center transition-colors"
                  [class.bg-[#00f0ff]]="latticeGeometry === 'VORONOI'"
                  [class.text-black]="latticeGeometry === 'VORONOI'"
                  [class.font-bold]="latticeGeometry === 'VORONOI'"
                  [class.bg-[#0d1017]]="latticeGeometry !== 'VORONOI'"
                  [class.border-[#222733]]="latticeGeometry !== 'VORONOI'"
                  [class.text-zinc-300]="latticeGeometry !== 'VORONOI'"
                >
                  Voronoi
                </button>
              </div>
            </div>

            <!-- Lattice Density Slider -->
            <div class="space-y-1.5">
              <div class="flex justify-between text-xs font-mono">
                <span class="text-zinc-400">Lattice Density:</span>
                <span class="text-[#00f0ff] font-bold">{{ latticeDensityPct }}%</span>
              </div>
              <input
                type="range"
                min="35"
                max="85"
                [(ngModel)]="latticeDensityPct"
                (input)="onLatticeParamChange()"
                class="w-full accent-[#00f0ff] cursor-pointer"
              />
              <div class="flex justify-between text-[10px] font-mono text-zinc-400">
                <span>35% (Ultralight Race)</span>
                <span>58% (Standard 4DFWD)</span>
                <span>85% (High Torsion)</span>
              </div>
            </div>

            <!-- Strut Wall Thickness Slider -->
            <div class="space-y-1.5">
              <div class="flex justify-between text-xs font-mono">
                <span class="text-zinc-400">Strut Wall Thickness:</span>
                <span class="text-white font-bold">{{ wallThicknessMm }} mm</span>
              </div>
              <input
                type="range"
                min="0.7"
                max="2.0"
                step="0.1"
                [(ngModel)]="wallThicknessMm"
                (input)="onLatticeParamChange()"
                class="w-full accent-[#00f0ff] cursor-pointer"
              />
            </div>
          </div>

          <!-- Real-Time Manufacturing & Biomechanics Impact Readouts -->
          <div class="bg-[#11141c] border border-[#222733] rounded-2xl p-4">
            <span class="text-xs font-mono font-bold text-white uppercase tracking-wider block mb-3">
              INSTANT DIGITAL TWIN ESTIMATE
            </span>
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center font-mono">
              <div class="bg-[#0c0e14] p-2.5 rounded-xl border border-[#1e2433]">
                <span class="text-[9px] text-zinc-400 uppercase block">WEIGHT</span>
                <span class="text-base font-black text-white">{{ calculatedWeightGrams() }}g</span>
              </div>
              <div class="bg-[#0c0e14] p-2.5 rounded-xl border border-[#1e2433]">
                <span class="text-[9px] text-zinc-400 uppercase block">PRINT TIME</span>
                <span class="text-base font-black text-[#00f0ff]">{{ calculatedPrintTime() }}h</span>
              </div>
              <div class="bg-[#0c0e14] p-2.5 rounded-xl border border-[#1e2433]">
                <span class="text-[9px] text-zinc-400 uppercase block">STIFFNESS</span>
                <span class="text-base font-black text-[#00e676]">{{ calculatedStiffness() }} N/mm</span>
              </div>
              <div class="bg-[#0c0e14] p-2.5 rounded-xl border border-[#1e2433]">
                <span class="text-[9px] text-zinc-400 uppercase block">ENERGY RET.</span>
                <span class="text-base font-black text-yellow-400">{{ calculatedEnergyReturn() }}%</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class DigitalTwinComponent implements AfterViewInit, OnDestroy {
  @ViewChild('shoeCanvasContainer') canvasContainer!: ElementRef<HTMLDivElement>;

  readonly state = inject(ManufacturingState);
  private router = inject(Router);
  private footwearScene: Footwear3DScene | null = null;

  readonly activeComponentType = signal<string>('MIDSOLE');
  readonly viewMode = signal<'REALISTIC' | 'FEA_HEATMAP' | 'WIREFRAME' | 'XRAY'>('REALISTIC');
  
  explodedProgress = 0;
  latticeDensityPct = 58;
  latticeGeometry: CellGeometry = 'GYROID_TPMS';
  wallThicknessMm = 1.1;
  autoRotate = true;

  calculatedWeightGrams(): number {
    return Math.round(164 * (this.latticeDensityPct / 58));
  }

  calculatedPrintTime(): string {
    return (1.7 * (0.6 + 0.4 * (this.latticeDensityPct / 58))).toFixed(1);
  }

  calculatedStiffness(): number {
    return Math.round(240 * (0.5 + 0.5 * (this.latticeDensityPct / 58)));
  }

  calculatedEnergyReturn(): string {
    return (89.2 + (this.latticeDensityPct > 60 ? 1.4 : -0.8)).toFixed(1);
  }

  ngAfterViewInit(): void {
    if (typeof window !== 'undefined' && this.canvasContainer) {
      this.footwearScene = new Footwear3DScene({
        container: this.canvasContainer.nativeElement,
        onComponentSelected: (type) => {
          this.activeComponentType.set(type);
        },
      });
    }
  }

  setViewMode(mode: 'REALISTIC' | 'FEA_HEATMAP' | 'WIREFRAME' | 'XRAY'): void {
    this.viewMode.set(mode);
    this.footwearScene?.setViewMode(mode);
  }

  selectComponent(type: string): void {
    this.activeComponentType.set(type);
    this.footwearScene?.selectComponentByType(type);
  }

  setGeometry(geom: CellGeometry): void {
    this.latticeGeometry = geom;
    this.onLatticeParamChange();
  }

  onLatticeParamChange(): void {
    this.footwearScene?.updateLattice({
      densityPct: this.latticeDensityPct,
      cellGeometry: this.latticeGeometry,
      wallThicknessMm: this.wallThicknessMm,
      cellSizeMm: 6.5,
      forefootStiffnessNmm: this.calculatedStiffness(),
      midfootTorsionLockPct: 88,
      heelCushioningDeflectionMm: 14.5,
      energyReturnPct: +this.calculatedEnergyReturn(),
      weightGrams: this.calculatedWeightGrams(),
      printTimeHours: +this.calculatedPrintTime(),
      materialCostEur: +(12.14 * (this.latticeDensityPct / 58)).toFixed(2),
      feaMaxStressMpa: 4.8,
    });
    this.state.updateGenerativeConfig('CMP-4D-MIDSOLE', {
      densityPct: this.latticeDensityPct,
      cellGeometry: this.latticeGeometry,
      wallThicknessMm: this.wallThicknessMm,
    });
  }

  onExplodedChange(): void {
    this.footwearScene?.setExplodedView(this.explodedProgress / 100);
  }

  toggleAutoRotate(): void {
    this.autoRotate = !this.autoRotate;
    this.footwearScene?.toggleAutoRotate(this.autoRotate);
  }

  resetCameraView(): void {
    this.footwearScene?.resetCamera();
  }

  dispatchToPrintJobs(): void {
    this.router.navigateByUrl('/print-jobs');
  }

  ngOnDestroy(): void {
    this.footwearScene?.destroy();
  }
}
