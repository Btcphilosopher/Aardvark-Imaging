import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { ManufacturingState } from '../../services/manufacturing-state.service';

@Component({
  selector: 'app-print-jobs',
  imports: [CommonModule, FormsModule, RouterModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-4 sm:p-6 space-y-6 max-w-7xl mx-auto select-none">
      <!-- Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold text-[#00f0ff] uppercase tracking-wider">PRINT PREPARATION & SLICING ENGINE</span>
            <span class="text-xs font-mono text-zinc-400">// DLS & SLS TOOLPATH GENERATOR</span>
          </div>
          <h1 class="text-xl sm:text-2xl font-black text-white tracking-tight mt-1">
            Build Plate Orientation & Machine Dispatch
          </h1>
          <p class="text-xs text-zinc-400 font-mono mt-0.5">
            50µm sub-voxel resolution • Thermal warp risk simulation • Self-supporting gyroid generation
          </p>
        </div>

        <div class="flex items-center gap-3">
          <button
            (click)="runSlicingSimulation()"
            class="px-4 py-2 bg-[#192236] hover:bg-[#23304c] text-[#00f0ff] border border-[#00f0ff]/40 font-mono font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors"
          >
            <mat-icon class="!text-sm !w-4 !h-4">memory</mat-icon>
            <span>RE-RUN FEA SIMULATION</span>
          </button>
          <button
            (click)="startProductionForActiveJob()"
            class="px-4 py-2 bg-[#00f0ff] hover:bg-[#38f4ff] text-black font-mono font-bold text-xs rounded-xl shadow-sm flex items-center gap-1.5 transition-all active:scale-95"
          >
            <mat-icon class="!text-sm !w-4 !h-4">play_arrow</mat-icon>
            <span>SUBMIT TO MACHINE AM-042</span>
          </button>
        </div>
      </div>

      <!-- Main Grid: Slicing Visualizer + Build Parameters -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- 2D / 3D Slicing Layer Toolpath Simulator (Span 7) -->
        <div class="lg:col-span-7 bg-[#11141c] border border-[#222733] rounded-2xl p-5 space-y-4 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between pb-3 border-b border-[#222733]">
              <div class="flex items-center gap-2">
                <mat-icon class="text-[#00f0ff] !text-base">layers</mat-icon>
                <span class="text-xs font-mono font-bold text-white uppercase">LAYER-BY-LAYER TOOLPATH SLICER</span>
              </div>
              <span class="text-xs font-mono text-[#00e676] font-bold">FEA CONVERGED // 0 CRITICAL HOTSPOTS</span>
            </div>

            <!-- Simulated Cross Section Slicing Canvas / Graphic -->
            <div class="mt-4 h-64 bg-[#0a0c10] border border-[#1e2433] rounded-xl relative overflow-hidden flex items-center justify-center p-4">
              <!-- Animated Scanning Laser Line -->
              <div class="absolute top-0 bottom-0 w-1 bg-[#00f0ff] shadow-[0_0_15px_#00f0ff] animate-pulse" [style.left.%]="(layerSliderValue / 3840) * 100"></div>

              <!-- Procedural Lattice Toolpath SVG Vector -->
              <svg class="w-full h-full text-[#00f0ff]" viewBox="0 0 400 180" fill="none" xmlns="http://www.w3.org/2000/svg">
                <!-- Shoe Midsole Cross-Section Contour -->
                <path d="M 20 120 Q 80 130 180 125 Q 320 120 380 90 Q 350 40 280 45 Q 160 55 40 70 Z" stroke="#2a354c" stroke-width="2" fill="#141924" fill-opacity="0.6"/>
                <!-- Porous Gyroid Lattice Vector Hatching -->
                <g stroke="#00f0ff" stroke-width="1.2" opacity="0.85">
                  <path d="M 40 85 Q 60 70 80 90 T 120 85 T 160 90 T 200 80 T 240 90 T 280 80 T 320 85 T 360 80" />
                  <path d="M 45 100 Q 65 85 85 105 T 125 100 T 165 105 T 205 95 T 245 105 T 285 95 T 325 100 T 365 95" />
                  <path d="M 50 115 Q 70 100 90 120 T 130 115 T 170 120 T 210 110 T 250 120 T 290 110 T 330 115" />
                </g>
                <!-- Laser exposure focus head -->
                <circle cx="200" cy="95" r="4" fill="#00e676" />
                <circle cx="200" cy="95" r="8" stroke="#00e676" stroke-width="1" opacity="0.6" />
              </svg>

              <!-- Real-time layer readout overlay -->
              <div class="absolute bottom-3 left-3 bg-[#11141c]/90 border border-[#222733] px-3 py-1 rounded-md text-[11px] font-mono text-zinc-300">
                <span>Z-Height: <strong>{{ ((layerSliderValue * 50) / 1000).toFixed(2) }} mm</strong></span>
                <span class="mx-2">•</span>
                <span>Layer: <strong class="text-[#00f0ff]">{{ layerSliderValue }}</strong> / 3,840</span>
              </div>
            </div>

            <!-- Layer Slider Control -->
            <div class="mt-4 space-y-1.5">
              <div class="flex justify-between text-xs font-mono text-zinc-400">
                <span>Scrub Layer Slice:</span>
                <span class="text-[#00f0ff] font-bold">{{ layerSliderValue }} / 3,840 Layers ({{ ((layerSliderValue / 3840) * 100).toFixed(1) }}%)</span>
              </div>
              <input
                type="range"
                min="1"
                max="3840"
                [(ngModel)]="layerSliderValue"
                class="w-full accent-[#00f0ff] cursor-pointer"
              />
            </div>
          </div>

          <!-- Slicing Simulation Readouts -->
          <div class="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center font-mono pt-3 border-t border-[#1e2433]">
            <div class="bg-[#0c0e14] p-2 rounded-xl border border-[#1e2433]">
              <span class="text-[9px] text-zinc-400 block">EST. TIME</span>
              <span class="text-sm font-bold text-white">1h 42m</span>
            </div>
            <div class="bg-[#0c0e14] p-2 rounded-xl border border-[#1e2433]">
              <span class="text-[9px] text-zinc-400 block">FAILURE RISK</span>
              <span class="text-sm font-bold text-[#00e676]">0.9% (LOW)</span>
            </div>
            <div class="bg-[#0c0e14] p-2 rounded-xl border border-[#1e2433]">
              <span class="text-[9px] text-zinc-400 block">MAX WARPAGE</span>
              <span class="text-sm font-bold text-white">0.12 mm</span>
            </div>
            <div class="bg-[#0c0e14] p-2 rounded-xl border border-[#1e2433]">
              <span class="text-[9px] text-zinc-400 block">ENERGY REQ.</span>
              <span class="text-sm font-bold text-[#00f0ff]">0.38 kWh</span>
            </div>
          </div>
        </div>

        <!-- Right Side: Build Configuration & Target Machine Allocator (Span 5) -->
        <div class="lg:col-span-5 space-y-4">
          <!-- Build Parameters Form -->
          <div class="bg-[#11141c] border border-[#222733] rounded-2xl p-5 space-y-4">
            <span class="text-xs font-mono font-bold text-white uppercase tracking-wider block pb-2 border-b border-[#222733]">
              BUILD PARAMETER SPECIFICATION
            </span>

            <div class="space-y-3 text-xs font-mono">
              <div>
                <label for="machineSelect" class="text-zinc-400 block mb-1">Target Additive Machine:</label>
                <select
                  id="machineSelect"
                  [(ngModel)]="selectedMachine"
                  class="w-full bg-[#121620] border border-[#2b3345] rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#00f0ff]"
                >
                  <option value="AM-042">AM-042 (Carbon DLS Gen-4) — 89% Resin • Ready</option>
                  <option value="AM-008">AM-008 (Carbon DLS High-Volume) — 92% Resin</option>
                  <option value="AM-028">AM-028 (Standby Cell) — 95% Resin</option>
                  <option value="AM-003">AM-003 (EOS Laser Sintering SLS)</option>
                </select>
              </div>

              <div class="grid grid-cols-2 gap-3">
                <div>
                  <label for="layerHeightSelect" class="text-zinc-400 block mb-1">Layer Height:</label>
                  <select
                    id="layerHeightSelect"
                    [(ngModel)]="layerHeight"
                    class="w-full bg-[#121620] border border-[#2b3345] rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#00f0ff]"
                  >
                    <option value="35">35 µm (Ultra-High Def)</option>
                    <option value="50">50 µm (Standard 4DFWD)</option>
                    <option value="75">75 µm (Fast Production)</option>
                  </select>
                </div>
                <div>
                  <label for="tiltAngleSelect" class="text-zinc-400 block mb-1">Plate Tilt Angle:</label>
                  <select
                    id="tiltAngleSelect"
                    [(ngModel)]="tiltAngle"
                    class="w-full bg-[#121620] border border-[#2b3345] rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#00f0ff]"
                  >
                    <option value="15.0">15.0° (Low Peeling Stress)</option>
                    <option value="22.5">22.5° (Optimal Drain)</option>
                    <option value="30.0">30.0° (Max Pack Density)</option>
                  </select>
                </div>
              </div>

              <div>
                <label for="supportStrategySelect" class="text-zinc-400 block mb-1">Support Structure Strategy:</label>
                <select
                  id="supportStrategySelect"
                  [(ngModel)]="supportStrategy"
                  class="w-full bg-[#121620] border border-[#2b3345] rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#00f0ff]"
                >
                  <option value="GYROID_SELF_SUPPORT">Self-Supporting TPMS (0% Scrap Waste)</option>
                  <option value="ORGANIC_TREE">Micro-Tree Struts (Easy Breakaway)</option>
                  <option value="SOLID_BLOCK">Block Scaffolding</option>
                </select>
              </div>
            </div>

            <!-- Cost & Material BOM summary -->
            <div class="p-3 bg-[#0c0e14] rounded-xl border border-[#1e2433] space-y-1.5 text-xs font-mono">
              <div class="flex justify-between">
                <span class="text-zinc-400">Polymer Material:</span>
                <span class="text-[#00f0ff] font-bold">Carbon EPU 44</span>
              </div>
              <div class="flex justify-between">
                <span class="text-zinc-400">Total Resin Required:</span>
                <span class="text-white font-bold">164 grams</span>
              </div>
              <div class="flex justify-between">
                <span class="text-zinc-400">Estimated Unit Cost:</span>
                <span class="text-[#00e676] font-bold">€18.42 EUR</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class PrintJobsComponent {
  readonly state = inject(ManufacturingState);
  private router = inject(Router);

  layerSliderValue = 2480;
  selectedMachine = 'AM-042';
  layerHeight = '50';
  tiltAngle = '22.5';
  supportStrategy = 'GYROID_SELF_SUPPORT';

  runSlicingSimulation(): void {
    this.state.addNotification('Simulation Succeeded', 'Toolpath verified: 0 layer delamination risks detected across 3,840 slices.', 'SUCCESS');
  }

  startProductionForActiveJob(): void {
    this.state.startProduction('PJ-9104');
    this.router.navigateByUrl('/machines');
  }
}
