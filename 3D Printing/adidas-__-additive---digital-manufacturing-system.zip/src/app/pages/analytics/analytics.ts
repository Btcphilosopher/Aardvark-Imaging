import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ManufacturingState } from '../../services/manufacturing-state.service';

@Component({
  selector: 'app-analytics',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-4 sm:p-6 space-y-6 max-w-7xl mx-auto select-none">
      <!-- Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold text-[#00f0ff] uppercase tracking-wider">EXECUTIVE MANUFACTURING ANALYTICS</span>
            <span class="text-xs font-mono text-zinc-400">// ESG & EFFICIENCY INTELLIGENCE</span>
          </div>
          <h1 class="text-xl sm:text-2xl font-black text-white tracking-tight mt-1">
            Factory OEE, Energy & Sustainability Metrics
          </h1>
          <p class="text-xs text-zinc-400 font-mono mt-0.5">
            46% energy reduction vs injection tooling • 100% circular recycled polymer throughput • Zero waste toolless manufacturing
          </p>
        </div>
      </div>

      <!-- Top High-Level Impact Cards -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="p-4 bg-[#11141c] border border-[#222733] rounded-2xl flex flex-col justify-between">
          <span class="text-[10px] font-mono text-zinc-400 uppercase">OVERALL FLEET OEE</span>
          <div class="flex items-baseline gap-2 my-2">
            <span class="text-3xl font-black text-[#00e676]">{{ state.overallOeePct() }}%</span>
            <span class="text-xs font-mono text-zinc-400">Target 85%</span>
          </div>
          <span class="text-[11px] font-mono text-[#00e676]">Availability 95% • Quality 99.4%</span>
        </div>

        <div class="p-4 bg-[#11141c] border border-[#222733] rounded-2xl flex flex-col justify-between">
          <span class="text-[10px] font-mono text-zinc-400 uppercase">ENERGY SAVINGS VS INJECTION</span>
          <div class="flex items-baseline gap-2 my-2">
            <span class="text-3xl font-black text-[#00f0ff]">-46.5%</span>
            <span class="text-xs font-mono text-zinc-400">per pair</span>
          </div>
          <span class="text-[11px] font-mono text-[#00f0ff]">0.38 kWh vs 0.71 kWh Traditional</span>
        </div>

        <div class="p-4 bg-[#11141c] border border-[#222733] rounded-2xl flex flex-col justify-between">
          <span class="text-[10px] font-mono text-zinc-400 uppercase">CO2e AVOIDED TODAY</span>
          <div class="flex items-baseline gap-2 my-2">
            <span class="text-3xl font-black text-white">710</span>
            <span class="text-xs font-mono text-zinc-400">kg CO2e</span>
          </div>
          <span class="text-[11px] font-mono text-[#00e676]">100% Solar-Powered HZO Cell</span>
        </div>

        <div class="p-4 bg-[#11141c] border border-[#222733] rounded-2xl flex flex-col justify-between">
          <span class="text-[10px] font-mono text-zinc-400 uppercase">CLOSED-LOOP RECYCLED SHARE</span>
          <div class="flex items-baseline gap-2 my-2">
            <span class="text-3xl font-black text-yellow-400">64.2%</span>
            <span class="text-xs font-mono text-zinc-400">of total resin</span>
          </div>
          <span class="text-[11px] font-mono text-yellow-400">Parley Ocean TPU + Bio-Castor</span>
        </div>
      </div>

      <!-- Deep Dive Analytics: Hourly Energy & Power Demand Profile -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Energy Profile Chart -->
        <div class="p-5 bg-[#11141c] border border-[#222733] rounded-2xl space-y-4 font-mono text-xs">
          <div class="flex items-center justify-between pb-3 border-b border-[#222733]">
            <span class="font-bold text-white uppercase tracking-wider">HOURLY POWER & SOLAR GENERATION</span>
            <span class="text-[#00e676] font-bold">100% RENEWABLE PEAK</span>
          </div>

          <!-- Bar Chart Visualizer -->
          <div class="space-y-3 pt-2">
            @for (pt of state.energyMetrics(); track pt.timestamp) {
              <div class="space-y-1">
                <div class="flex justify-between text-[11px]">
                  <span class="text-zinc-400">{{ pt.timestamp }} UTC</span>
                  <span class="text-white font-bold">{{ pt.factoryTotalPowerMw }} MW ({{ pt.solarRenewablePct }}% Solar)</span>
                </div>
                <div class="w-full bg-[#0c0e14] h-3 rounded-full overflow-hidden flex">
                  <div class="bg-[#00e676] h-full" [style.width.%]="pt.solarRenewablePct"></div>
                  <div class="bg-[#2a354c] h-full" [style.width.%]="100 - pt.solarRenewablePct"></div>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Additive vs Traditional Tooling Cost & ESG Breakdown -->
        <div class="p-5 bg-[#11141c] border border-[#222733] rounded-2xl space-y-4 font-mono text-xs">
          <div class="flex items-center justify-between pb-3 border-b border-[#222733]">
            <span class="font-bold text-white uppercase tracking-wider">ADDITIVE VS INJECTION TOOLING</span>
            <span class="text-[#00f0ff] font-bold">TOOLLESS SPEEDFACTORY</span>
          </div>

          <div class="space-y-3">
            <div class="p-3 bg-[#0c0e14] rounded-xl border border-[#1e2433] space-y-1">
              <div class="flex justify-between font-bold">
                <span class="text-zinc-300">Tooling & Mold Lead Time:</span>
                <span class="text-[#00e676]">0 DAYS (Direct CAD) vs 60-90 Days</span>
              </div>
              <p class="text-[11px] text-zinc-400 font-sans">Zero metal aluminum molds machined; instant generative iteration.</p>
            </div>

            <div class="p-3 bg-[#0c0e14] rounded-xl border border-[#1e2433] space-y-1">
              <div class="flex justify-between font-bold">
                <span class="text-zinc-300">Material Waste / Flash Scrap:</span>
                <span class="text-[#00e676]">1.8% vs 24.5% Traditional</span>
              </div>
              <p class="text-[11px] text-zinc-400 font-sans">Self-supporting gyroid lattice utilizes 98.2% raw resin with near-zero purge waste.</p>
            </div>

            <div class="p-3 bg-[#0c0e14] rounded-xl border border-[#1e2433] space-y-1">
              <div class="flex justify-between font-bold">
                <span class="text-zinc-300">Minimum Economic Batch Size:</span>
                <span class="text-[#00e676]">1 PAIR vs 10,000 Pairs</span>
              </div>
              <p class="text-[11px] text-zinc-400 font-sans">Enables true on-demand athlete customization with zero warehousing penalty.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class AnalyticsComponent {
  readonly state = inject(ManufacturingState);
}
