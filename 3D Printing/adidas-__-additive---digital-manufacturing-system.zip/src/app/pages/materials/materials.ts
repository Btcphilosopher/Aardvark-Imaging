import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ManufacturingState } from '../../services/manufacturing-state.service';
import { Material } from '../../types/additive.types';

@Component({
  selector: 'app-materials',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-4 sm:p-6 space-y-6 max-w-7xl mx-auto select-none">
      <!-- Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold text-[#00f0ff] uppercase tracking-wider">MATERIALS SCIENCE & RHEOLOGY</span>
            <span class="text-xs font-mono text-zinc-400">// POLYMERS & BIO-ELASTOMERS</span>
          </div>
          <h1 class="text-xl sm:text-2xl font-black text-white tracking-tight mt-1">
            Certified Additive Polymers Database
          </h1>
          <p class="text-xs text-zinc-400 font-mono mt-0.5">
            Elastomeric polyurethanes • Closed-loop ocean TPUs • Nanotube reinforced composites • Bio-polymers
          </p>
        </div>

        <div class="flex items-center gap-2">
          <div class="bg-[#11141c] border border-[#222733] px-3 py-1.5 rounded-lg text-xs font-mono">
            <span class="text-zinc-400">TOTAL STOCK: </span>
            <span class="text-white font-bold">{{ totalStockKg() }} kg</span>
          </div>
        </div>
      </div>

      <!-- Main Layout: Material List & Deep Inspector -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Materials List Grid (Span 7) -->
        <div class="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
          @for (mat of state.materials(); track mat.id) {
            <button
              type="button"
              (click)="selectMaterial(mat)"
              class="p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between text-left w-full"
              [class.bg-[#192236]]="mat.id === state.selectedMaterialId()"
              [class.border-[#00f0ff]]="mat.id === state.selectedMaterialId()"
              [class.shadow-lg]="mat.id === state.selectedMaterialId()"
              [class.bg-[#11141c]]="mat.id !== state.selectedMaterialId()"
              [class.border-[#222733]]="mat.id !== state.selectedMaterialId()"
              [class.hover:border-[#2f394d]]="mat.id !== state.selectedMaterialId()"
            >
              <div class="w-full">
                <div class="flex items-center justify-between mb-2">
                  <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-[#0c0e14] text-[#00f0ff] border border-[#222733] font-bold">
                    {{ mat.family }}
                  </span>
                  <span class="text-[10px] font-mono text-[#00e676] font-semibold">
                    {{ mat.recycledContentPct }}% BIO/RECYCLED
                  </span>
                </div>

                <h3 class="text-sm font-bold text-white leading-snug">{{ mat.name }}</h3>
                <span class="text-[11px] font-mono text-zinc-400 block mt-0.5">{{ mat.supplier }}</span>

                <!-- Quick Specs Table -->
                <div class="grid grid-cols-3 gap-2 mt-3 pt-3 border-t border-[#1e2433] text-center font-mono">
                  <div class="bg-[#0c0e14] p-1.5 rounded-lg border border-[#1e2433]">
                    <span class="text-[9px] text-zinc-400 block">HARDNESS</span>
                    <span class="text-xs font-bold text-white">{{ mat.shoreHardness }}</span>
                  </div>
                  <div class="bg-[#0c0e14] p-1.5 rounded-lg border border-[#1e2433]">
                    <span class="text-[9px] text-zinc-400 block">TENSILE</span>
                    <span class="text-xs font-bold text-[#00f0ff]">{{ mat.tensileStrengthMpa }} MPa</span>
                  </div>
                  <div class="bg-[#0c0e14] p-1.5 rounded-lg border border-[#1e2433]">
                    <span class="text-[9px] text-zinc-400 block">ELONGATION</span>
                    <span class="text-xs font-bold text-[#00e676]">{{ mat.elongationAtBreakPct }}%</span>
                  </div>
                </div>
              </div>

              <div class="w-full mt-4 pt-2 flex items-center justify-between text-xs font-mono text-zinc-400 border-t border-[#1e2433]">
                <span>In Silo: <strong class="text-white">{{ mat.stockAvailableKg }} kg</strong></span>
                <span class="text-[#00f0ff] font-bold">€{{ mat.costPerKgEur }}/kg</span>
              </div>
            </button>
          }
        </div>

        <!-- Selected Material Deep Dive Inspector (Span 5) -->
        <div class="lg:col-span-5 bg-[#11141c] border border-[#222733] rounded-2xl p-5 space-y-5">
          @if (state.selectedMaterial(); as m) {
            <div class="flex items-center justify-between pb-3 border-b border-[#222733]">
              <div>
                <span class="text-[10px] font-mono text-[#00f0ff] font-bold uppercase tracking-wider">SELECTED POLYMER</span>
                <h2 class="text-base font-extrabold text-white mt-0.5">{{ m.name }}</h2>
              </div>
              <span class="text-xs font-mono font-bold px-2.5 py-1 rounded bg-[#00f0ff]/10 text-[#00f0ff] border border-[#00f0ff]/30">
                {{ m.code }}
              </span>
            </div>

            <p class="text-xs text-zinc-300 leading-relaxed font-sans">{{ m.description }}</p>

            <!-- Technical Properties Breakdown -->
            <div class="space-y-2.5 text-xs font-mono">
              <span class="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">Rheological & Physical Properties</span>

              <div class="flex justify-between py-1.5 border-b border-[#1e2433]">
                <span class="text-zinc-400">Current Batch Lot:</span>
                <span class="text-white font-semibold">{{ m.batchLot }}</span>
              </div>
              <div class="flex justify-between py-1.5 border-b border-[#1e2433]">
                <span class="text-zinc-400">Density:</span>
                <span class="text-white font-semibold">{{ m.densityGcm3 }} g/cm³</span>
              </div>
              <div class="flex justify-between py-1.5 border-b border-[#1e2433]">
                <span class="text-zinc-400">Shore Hardness:</span>
                <span class="text-[#00f0ff] font-bold">{{ m.shoreHardness }}</span>
              </div>
              <div class="flex justify-between py-1.5 border-b border-[#1e2433]">
                <span class="text-zinc-400">Tensile Strength:</span>
                <span class="text-white font-semibold">{{ m.tensileStrengthMpa }} MPa</span>
              </div>
              <div class="flex justify-between py-1.5 border-b border-[#1e2433]">
                <span class="text-zinc-400">Elongation at Break:</span>
                <span class="text-[#00e676] font-semibold">{{ m.elongationAtBreakPct }}%</span>
              </div>
              <div class="flex justify-between py-1.5 border-b border-[#1e2433]">
                <span class="text-zinc-400">Optimal Layer Height:</span>
                <span class="text-white font-semibold">{{ m.recommendedLayerHeightUm }} µm</span>
              </div>
              <div class="flex justify-between py-1.5 border-b border-[#1e2433]">
                <span class="text-zinc-400">Carbon Footprint:</span>
                <span class="text-[#00e676] font-bold">{{ m.carbonFootprintPerKg }} kg CO2e / kg</span>
              </div>
            </div>

            <!-- Recyclability Rating Badge -->
            <div class="p-3.5 bg-[#0c0e14] rounded-xl border border-[#1e2433] space-y-1.5">
              <span class="text-[10px] font-mono text-zinc-400 uppercase">Sustainability & Circularity Status:</span>
              <div class="flex items-center gap-2">
                <mat-icon class="text-[#00e676] !text-lg !w-5 !h-5">recycling</mat-icon>
                <span class="text-xs font-mono font-bold text-white">{{ m.recyclabilityRating }}</span>
              </div>
            </div>

            <button
              (click)="state.selectMaterial(m.id)"
              class="w-full py-2.5 bg-[#00f0ff] hover:bg-[#38f4ff] text-black font-mono font-bold text-xs rounded-xl shadow-sm transition-all flex items-center justify-center gap-2"
            >
              <span>SET AS ACTIVE RESIN FOR PRODUCTION</span>
              <mat-icon class="!text-sm !w-4 !h-4">check</mat-icon>
            </button>
          }
        </div>
      </div>
    </div>
  `,
})
export class MaterialsComponent {
  readonly state = inject(ManufacturingState);

  totalStockKg(): number {
    return this.state.materials().reduce((acc, m) => acc + m.stockAvailableKg, 0);
  }

  selectMaterial(mat: Material): void {
    this.state.selectMaterial(mat.id);
  }
}
