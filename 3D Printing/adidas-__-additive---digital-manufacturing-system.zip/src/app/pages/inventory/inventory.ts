import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ManufacturingState } from '../../services/manufacturing-state.service';

@Component({
  selector: 'app-inventory',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-4 sm:p-6 space-y-6 max-w-7xl mx-auto select-none">
      <!-- Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold text-[#00f0ff] uppercase tracking-wider">INVENTORY & SILO WAREHOUSE</span>
            <span class="text-xs font-mono text-zinc-400">// AUTOMATED HIGH-BAY STORAGE</span>
          </div>
          <h1 class="text-xl sm:text-2xl font-black text-white tracking-tight mt-1">
            Raw Polymers, Consumables & Finished Assemblies
          </h1>
          <p class="text-xs text-zinc-400 font-mono mt-0.5">
            Real-time silo level sensing • Depletion forecasting • Automated supplier replenishment triggers
          </p>
        </div>
      </div>

      <!-- Inventory Cards Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        @for (item of state.inventory(); track item.id) {
          <div class="p-5 bg-[#11141c] border border-[#222733] rounded-2xl flex flex-col justify-between space-y-4 hover:border-[#2f3a52] transition-colors">
            <div>
              <div class="flex items-center justify-between mb-2">
                <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-[#0c0e14] text-[#00f0ff] border border-[#222733] font-bold">
                  {{ item.category }}
                </span>
                <span
                  class="text-[10px] font-mono font-bold"
                  [class.text-[#00e676]]="item.autoReorderStatus === 'SUFFICIENT'"
                  [class.text-[#ffb300]]="item.autoReorderStatus === 'REORDER_RECOMMENDED'"
                  [class.text-[#00f0ff]]="item.autoReorderStatus === 'ORDER_PLACED'"
                >
                  {{ item.autoReorderStatus }}
                </span>
              </div>

              <h3 class="text-sm font-bold text-white leading-snug">{{ item.name }}</h3>
              <span class="text-[11px] font-mono text-zinc-400 block mt-0.5">{{ item.location }}</span>

              <!-- Stock Readouts -->
              <div class="mt-4 p-3 bg-[#0c0e14] rounded-xl border border-[#1e2433] space-y-2 font-mono text-xs">
                <div class="flex justify-between items-baseline">
                  <span class="text-zinc-400">Current In-Stock:</span>
                  <span class="text-lg font-black text-white">{{ item.currentStock }} {{ item.unit }}</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-zinc-400">Daily Consumption:</span>
                  <span class="text-zinc-200">{{ item.dailyConsumptionRate }} {{ item.unit }}/day</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-zinc-400">Projected Depletion:</span>
                  <span class="text-[#00f0ff] font-bold">{{ item.projectedDepletionDays }} Days</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-zinc-400">Unit Valuation:</span>
                  <span class="text-[#00e676] font-bold">€{{ item.unitCostEur }} EUR</span>
                </div>
              </div>
            </div>

            <div class="pt-2 border-t border-[#1e2433] flex gap-2">
              <button
                (click)="state.reorderMaterial(item.id)"
                class="w-full py-2 bg-[#192236] hover:bg-[#23304c] text-white font-mono font-bold text-xs rounded-xl border border-[#2b354c] transition-colors flex items-center justify-center gap-1.5"
              >
                <mat-icon class="!text-sm !w-4 !h-4">shopping_cart</mat-icon>
                <span>TRIGGER RE-ORDER (+{{ item.optimalBatchSize }} {{ item.unit }})</span>
              </button>
            </div>
          </div>
        }
      </div>
    </div>
  `,
})
export class InventoryComponent {
  readonly state = inject(ManufacturingState);
}
