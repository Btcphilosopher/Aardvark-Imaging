import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { ManufacturingState } from '../../services/manufacturing-state.service';
import { ProductCategory, Product } from '../../types/additive.types';

@Component({
  selector: 'app-products',
  imports: [CommonModule, RouterModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-4 sm:p-6 space-y-6 max-w-7xl mx-auto select-none">
      <!-- Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold text-[#00f0ff] uppercase tracking-wider">DIGITAL FOOTWEAR CAD REPOSITORY</span>
            <span class="text-xs font-mono text-zinc-400">// 30 ACTIVE DESIGNS</span>
          </div>
          <h1 class="text-xl sm:text-2xl font-black text-white tracking-tight mt-1">
            Additive Footwear Models & Assemblies
          </h1>
          <p class="text-xs text-zinc-400 font-mono mt-0.5">
            Parametric generative lattices • Multi-material assemblies • Finite element analysis convergence
          </p>
        </div>

        <!-- Filter Chips -->
        <div class="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
          <button
            (click)="setCategoryFilter(null)"
            class="px-3 py-1.5 rounded-lg text-xs font-mono transition-colors"
            [class.bg-[#00f0ff]]="selectedCategory() === null"
            [class.text-black]="selectedCategory() === null"
            [class.font-bold]="selectedCategory() === null"
            [class.bg-[#121620]]="selectedCategory() !== null"
            [class.text-zinc-300]="selectedCategory() !== null"
            [class.border]="selectedCategory() !== null"
            [class.border-[#283042]]="selectedCategory() !== null"
          >
            ALL CATEGORIES
          </button>
          <button
            (click)="setCategoryFilter('PERFORMANCE_RUNNING')"
            class="px-3 py-1.5 rounded-lg text-xs font-mono transition-colors"
            [class.bg-[#00f0ff]]="selectedCategory() === 'PERFORMANCE_RUNNING'"
            [class.text-black]="selectedCategory() === 'PERFORMANCE_RUNNING'"
            [class.font-bold]="selectedCategory() === 'PERFORMANCE_RUNNING'"
            [class.bg-[#121620]]="selectedCategory() !== 'PERFORMANCE_RUNNING'"
            [class.text-zinc-300]="selectedCategory() !== 'PERFORMANCE_RUNNING'"
            [class.border]="selectedCategory() !== 'PERFORMANCE_RUNNING'"
            [class.border-[#283042]]="selectedCategory() !== 'PERFORMANCE_RUNNING'"
          >
            RUNNING (4DFWD)
          </button>
          <button
            (click)="setCategoryFilter('FOOTBALL')"
            class="px-3 py-1.5 rounded-lg text-xs font-mono transition-colors"
            [class.bg-[#00f0ff]]="selectedCategory() === 'FOOTBALL'"
            [class.text-black]="selectedCategory() === 'FOOTBALL'"
            [class.font-bold]="selectedCategory() === 'FOOTBALL'"
            [class.bg-[#121620]]="selectedCategory() !== 'FOOTBALL'"
            [class.text-zinc-300]="selectedCategory() !== 'FOOTBALL'"
            [class.border]="selectedCategory() !== 'FOOTBALL'"
            [class.border-[#283042]]="selectedCategory() !== 'FOOTBALL'"
          >
            FOOTBALL
          </button>
          <button
            (click)="setCategoryFilter('PROTOTYPE_CONCEPT')"
            class="px-3 py-1.5 rounded-lg text-xs font-mono transition-colors"
            [class.bg-[#00f0ff]]="selectedCategory() === 'PROTOTYPE_CONCEPT'"
            [class.text-black]="selectedCategory() === 'PROTOTYPE_CONCEPT'"
            [class.font-bold]="selectedCategory() === 'PROTOTYPE_CONCEPT'"
            [class.bg-[#121620]]="selectedCategory() !== 'PROTOTYPE_CONCEPT'"
            [class.text-zinc-300]="selectedCategory() !== 'PROTOTYPE_CONCEPT'"
            [class.border]="selectedCategory() !== 'PROTOTYPE_CONCEPT'"
            [class.border-[#283042]]="selectedCategory() !== 'PROTOTYPE_CONCEPT'"
          >
            FUTURECRAFT CONCEPTS
          </button>
        </div>
      </div>

      <!-- Product Cards Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        @for (product of filteredProducts(); track product.id) {
          <div
            class="bg-[#11141c] border rounded-2xl overflow-hidden flex flex-col justify-between transition-all hover:border-[#00f0ff]/60 group"
            [class.border-[#00f0ff]]="product.id === state.selectedProductId()"
            [class.border-[#222733]]="product.id !== state.selectedProductId()"
          >
            <!-- Card Header & Image Preview -->
            <div>
              <div class="relative h-44 bg-[#0a0c10] overflow-hidden flex items-center justify-center p-4">
                <!-- Three-stripe brand motif in background -->
                <div class="absolute right-4 top-4 flex gap-1 opacity-20">
                  <div class="w-2 h-10 bg-white transform -skew-x-12"></div>
                  <div class="w-2 h-10 bg-white transform -skew-x-12"></div>
                  <div class="w-2 h-10 bg-[#00f0ff] transform -skew-x-12"></div>
                </div>

                <img
                  [src]="product.thumbnailUrl"
                  [alt]="product.name"
                  class="max-h-full max-w-full object-contain filter drop-shadow-2xl transition-transform group-hover:scale-105 duration-300"
                  referrerpolicy="no-referrer"
                />

                <div class="absolute top-3 left-3 flex gap-2">
                  <span class="px-2 py-0.5 rounded bg-black/70 backdrop-blur-xs text-[10px] font-mono text-[#00f0ff] border border-white/10 font-bold">
                    {{ product.version }}
                  </span>
                  <span class="px-2 py-0.5 rounded bg-[#00e676]/20 text-[#00e676] border border-[#00e676]/30 text-[10px] font-mono font-bold">
                    {{ product.status }}
                  </span>
                </div>
              </div>

              <!-- Product Info -->
              <div class="p-4 space-y-3">
                <div>
                  <span class="text-[10px] font-mono text-zinc-400 uppercase tracking-wider">{{ product.category }}</span>
                  <h3 class="text-base font-extrabold text-white tracking-tight mt-0.5 group-hover:text-[#00f0ff] transition-colors">
                    {{ product.name }}
                  </h3>
                  <span class="text-[11px] font-mono text-zinc-400 block">{{ product.sku }}</span>
                </div>

                <!-- Manufacturing & Material Specs -->
                <div class="p-3 bg-[#0d1017] rounded-xl border border-[#1e2433] space-y-2 text-xs font-mono">
                  <div class="flex justify-between">
                    <span class="text-zinc-400">Method:</span>
                    <span class="text-zinc-200 font-medium truncate max-w-[170px]">{{ product.manufacturingMethod }}</span>
                  </div>
                  <div class="flex justify-between">
                    <span class="text-zinc-400">Materials:</span>
                    <span class="text-[#00f0ff] font-semibold truncate max-w-[170px]">{{ product.materials.join(', ') }}</span>
                  </div>
                  <div class="flex justify-between">
                    <span class="text-zinc-400">CO2e / Pair:</span>
                    <span class="text-[#00e676] font-bold">{{ product.co2ePerPairKg }} kg</span>
                  </div>
                  <div class="flex justify-between">
                    <span class="text-zinc-400">Batch Yield:</span>
                    <span class="text-white font-bold">{{ product.batchYieldPct }}%</span>
                  </div>
                </div>

                <!-- Sub-components List -->
                @if (product.components.length > 0) {
                  <div class="space-y-1">
                    <span class="text-[10px] font-mono uppercase text-zinc-400">Additive Assemblies ({{ product.components.length }} Parts):</span>
                    <div class="flex flex-wrap gap-1.5">
                      @for (comp of product.components; track comp.id) {
                        <span class="px-2 py-0.5 bg-[#192236] text-[10px] font-mono rounded text-zinc-300 border border-[#273552]">
                          {{ comp.name }} ({{ comp.weightGrams }}g)
                        </span>
                      }
                    </div>
                  </div>
                }
              </div>
            </div>

            <!-- Footer Actions -->
            <div class="p-4 pt-0 flex gap-2">
              <button
                (click)="openInDigitalTwin(product)"
                class="flex-1 py-2 bg-[#00f0ff] hover:bg-[#38f4ff] text-black font-mono font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-1.5 shadow-sm active:scale-95"
              >
                <mat-icon class="!text-sm !w-4 !h-4">view_in_ar</mat-icon>
                <span>OPEN 3D TWIN</span>
              </button>
              <button
                (click)="selectAndCreateJob(product)"
                class="px-3 py-2 bg-[#171c28] hover:bg-[#222a3d] text-zinc-200 border border-[#2b354d] font-mono text-xs rounded-xl transition-colors"
                title="Create print preparation job"
              >
                <mat-icon class="!text-sm !w-4 !h-4">layers</mat-icon>
              </button>
            </div>
          </div>
        }
      </div>
    </div>
  `,
})
export class ProductsComponent {
  readonly state = inject(ManufacturingState);
  private router = inject(Router);

  readonly selectedCategory = signal<ProductCategory | null>(null);

  setCategoryFilter(cat: ProductCategory | null): void {
    this.selectedCategory.set(cat);
  }

  filteredProducts(): Product[] {
    const cat = this.selectedCategory();
    if (!cat) return this.state.products();
    return this.state.products().filter(p => p.category === cat);
  }

  openInDigitalTwin(product: Product): void {
    this.state.selectProduct(product.id);
    this.router.navigateByUrl('/digital-twin');
  }

  selectAndCreateJob(product: Product): void {
    this.state.selectProduct(product.id);
    this.router.navigateByUrl('/print-jobs');
  }
}
