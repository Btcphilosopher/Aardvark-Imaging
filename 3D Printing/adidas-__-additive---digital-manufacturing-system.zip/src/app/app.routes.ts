import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', redirectTo: 'command-center', pathMatch: 'full' },
  {
    path: 'command-center',
    loadComponent: () => import('./pages/command-center/command-center').then(m => m.CommandCenterComponent),
  },
  {
    path: 'products',
    loadComponent: () => import('./pages/products/products').then(m => m.ProductsComponent),
  },
  {
    path: 'digital-twin',
    loadComponent: () => import('./pages/digital-twin/digital-twin').then(m => m.DigitalTwinComponent),
  },
  {
    path: 'materials',
    loadComponent: () => import('./pages/materials/materials').then(m => m.MaterialsComponent),
  },
  {
    path: 'print-jobs',
    loadComponent: () => import('./pages/print-jobs/print-jobs').then(m => m.PrintJobsComponent),
  },
  {
    path: 'machines',
    loadComponent: () => import('./pages/machines/machines').then(m => m.MachinesComponent),
  },
  {
    path: 'quality',
    loadComponent: () => import('./pages/quality/quality').then(m => m.QualityComponent),
  },
  {
    path: 'inventory',
    loadComponent: () => import('./pages/inventory/inventory').then(m => m.InventoryComponent),
  },
  {
    path: 'traceability',
    loadComponent: () => import('./pages/traceability/traceability').then(m => m.TraceabilityComponent),
  },
  {
    path: 'analytics',
    loadComponent: () => import('./pages/analytics/analytics').then(m => m.AnalyticsComponent),
  },
  { path: '**', redirectTo: 'command-center' },
];
