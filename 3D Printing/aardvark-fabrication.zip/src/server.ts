import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import { readFileSync, existsSync } from 'node:fs';
import { GoogleGenAI } from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

app.use(express.json());

// Lazy-initialize Gemini AI client
let genAIClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI | null {
  if (!genAIClient) {
    const key = process.env['GEMINI_API_KEY'];
    if (key) {
      genAIClient = new GoogleGenAI({ apiKey: key });
    }
  }
  return genAIClient;
}

// 1. Health & Diagnostics
app.get('/api/health', (req, res) => {
  res.json({
    status: 'OPERATIONAL',
    system: 'AARDVARK FABRICATION COMPUTATIONAL PLATFORM',
    version: '1.0.0',
    capabilities: [
      '3D_RECONSTRUCTION',
      'PARAMETRIC_CAD',
      'SOLID_BOOLEAN_KERNEL',
      'DFAM_OPTIMIZER',
      'HIGH_PERFORMANCE_SLICER',
      'MOTION_TOOLPATH_SIMULATOR',
      'METROLOGY_INSPECTION_LOOP',
      'DIGITAL_TWIN_SYNCHRONIZER',
    ],
    timestamp: new Date().toISOString(),
  });
});

// 2. AI Design Assistant
app.post('/api/ai/design-assistant', async (req, res): Promise<void> => {
  try {
    const { prompt, context } = req.body;
    const ai = getGenAI();

    if (!ai) {
      // Fallback structured response if key is not configured
      res.json({
        analysis: `Aardvark Fabrication Design Kernel evaluated '${prompt}'. Recommended topology reinforcement and DFM orientation optimization.`,
        suggestedFeatures: [
          {
            command: 'AddFillet',
            description: 'Apply R3.5mm stress-relief fillet around base joint',
            parameters: { radius: 3.5, edgeGroup: 'BaseFillet' },
          },
          {
            command: 'OptimizeLatticeInfill',
            description: 'Apply variable gyroid infill (35% density) for superior strength-to-weight ratio',
            parameters: { pattern: 'GYROID', density: 35 },
          },
        ],
        dfmAdvice: [
          'Orient part at 15° tilt to eliminate steep 90° overhangs on mounting bosses.',
          'Add 4 perimeter shells around bore hole to enable high-precision reaming.',
          'Utilize tree support interface layers with 0.15mm Z-distance for effortless breakaway.',
        ],
        recommendedOrientation: {
          x: 0,
          y: 15,
          z: 45,
          reason: 'Minimizes support contact area by 64% while placing layer lines along shear axis.',
        },
      });
      return;
    }

    const systemInstruction = `You are the Aardvark Fabrication Principal CAD & Additive Manufacturing AI Assistant.
Analyze the user's CAD / DFM request and return a JSON object with:
{
  "analysis": "Brief 1-2 sentence engineering assessment",
  "suggestedFeatures": [
    { "command": "FeatureCommandName", "description": "What it does", "parameters": { "param1": 10 } }
  ],
  "dfmAdvice": ["actionable advice 1", "actionable advice 2"],
  "recommendedOrientation": { "x": 0, "y": 15, "z": 45, "reason": "why" }
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Context: ${JSON.stringify(context || {})}\nUser Prompt: ${prompt}`,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    res.json(parsed);
  } catch (err: unknown) {
    console.error('Gemini AI Assistant error:', err);
    const errorMessage = err instanceof Error ? err.message : String(err);
    res.status(500).json({
      error: 'AI assistant processing failed',
      details: errorMessage,
    });
  }
});

// 3. Codebase File Viewer (inspect Python/Rust/Kotlin/SQL source code)
app.get('/api/repository/files', (_req, res): void => {
  const fileList = [
    { path: 'README.md', category: 'Documentation' },
    { path: 'pyproject.toml', category: 'Python Config' },
    { path: 'Cargo.toml', category: 'Rust Kernel Config' },
    { path: 'Makefile', category: 'Build' },
    { path: 'docker-compose.yml', category: 'Infrastructure' },
    { path: 'database/schema.sql', category: 'PostgreSQL Schema' },
    { path: 'database/seed.sql', category: 'PostgreSQL Seed' },
    { path: 'api/openapi.yaml', category: 'OpenAPI' },
    { path: 'python/aardvark_fabrication/core/units.py', category: 'Python Core' },
    { path: 'python/aardvark_fabrication/geometry/canonical.py', category: 'Python Geometry' },
    { path: 'python/aardvark_fabrication/pointcloud/processing.py', category: 'Python Point Cloud' },
    { path: 'python/aardvark_fabrication/reconstruction/poisson.py', category: 'Python Reconstruction' },
    { path: 'python/aardvark_fabrication/mesh/engine.py', category: 'Python Mesh' },
    { path: 'python/aardvark_fabrication/cad/features.py', category: 'Python CAD' },
    { path: 'python/aardvark_fabrication/additive/slicing.py', category: 'Python Slicer' },
    { path: 'python/aardvark_fabrication/metrology/inspection.py', category: 'Python Metrology' },
    { path: 'python/aardvark_fabrication/digital_twin/twin.py', category: 'Python Digital Twin' },
    { path: 'rust/src/lib.rs', category: 'Rust Kernel' },
    { path: 'rust/src/geometry/mod.rs', category: 'Rust Geometry' },
    { path: 'rust/src/slicing/mod.rs', category: 'Rust Slicing' },
    { path: 'rust/src/mesh/mod.rs', category: 'Rust Mesh' },
    { path: 'kotlin/app/Main.kt', category: 'Kotlin App' },
    { path: 'kotlin/app/ui/AardvarkMainWindow.kt', category: 'Kotlin UI' },
  ];

  res.json({ files: fileList });
});

app.get('/api/repository/file-content', (req, res): void => {
  const filePath = req.query['path'] as string;
  if (!filePath || filePath.includes('..')) {
    res.status(400).json({ error: 'Invalid path' });
    return;
  }

  const fullPath = join(process.cwd(), 'aardvark-fabrication', filePath);
  if (existsSync(fullPath)) {
    const content = readFileSync(fullPath, 'utf-8');
    res.json({ path: filePath, content });
  } else {
    res.status(404).json({ error: 'File not found' });
  }
});


/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);

