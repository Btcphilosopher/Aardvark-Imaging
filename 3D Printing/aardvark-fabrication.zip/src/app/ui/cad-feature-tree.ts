import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule } from '@angular/forms';
import { CADFeatureItem } from '../core/models/geometry.models';

@Component({
  selector: 'app-cad-feature-tree',
  imports: [CommonModule, MatIconModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-col h-full bg-slate-900/70 backdrop-blur-md border-l border-slate-800 text-xs overflow-hidden">
      <!-- Header -->
      <div class="p-3.5 border-b border-slate-800 flex items-center justify-between">
        <div>
          <div class="font-bold text-slate-100 tracking-wider text-[13px] flex items-center gap-2">
            <mat-icon class="text-sm! w-4! h-4! text-emerald-400">account_tree</mat-icon>
            PARAMETRIC FEATURE TREE
          </div>
          <div class="text-[10px] font-mono text-slate-400 mt-0.5">SOLID MODEL CSG / B-REP KERNEL</div>
        </div>
        <button
          (click)="addFeature.emit()"
          class="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold flex items-center gap-1 border border-slate-700"
        >
          <mat-icon class="text-sm! w-4! h-4!">add</mat-icon>
          <span>Feature</span>
        </button>
      </div>

      <!-- Feature Tree Items -->
      <div class="flex-1 overflow-y-auto p-3 space-y-2.5">
        @for (feat of features; track feat.id; let i = $index) {
          <div
            [class.opacity-50]="feat.suppressed"
            class="p-3 rounded-xl bg-slate-800/60 border border-slate-700/80 hover:border-slate-600 transition-all space-y-2"
          >
            <!-- Feature Header -->
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-2">
                <span class="font-mono text-[10px] text-slate-500">0{{ i + 1 }}</span>
                <mat-icon class="text-sm! w-4! h-4! text-cyan-400">{{ getFeatureIcon(feat.type) }}</mat-icon>
                <span class="font-semibold text-slate-200">{{ feat.name }}</span>
              </div>

              <!-- Controls -->
              <div class="flex items-center gap-1">
                <button
                  (click)="toggleSuppression(feat)"
                  [class.text-amber-400]="feat.suppressed"
                  [class.text-slate-400]="!feat.suppressed"
                  class="p-1 hover:text-white rounded"
                  [title]="feat.suppressed ? 'Unsuppress Feature' : 'Suppress Feature'"
                >
                  <mat-icon class="text-sm! w-4! h-4!">{{ feat.suppressed ? 'visibility_off' : 'visibility' }}</mat-icon>
                </button>
                <span class="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  {{ feat.status }}
                </span>
              </div>
            </div>

            <!-- Parameter Summary / Live Modifiers -->
            <div class="bg-slate-900/80 rounded-lg p-2 font-mono text-[11px] text-slate-300 space-y-1">
              @for (key of getParamKeys(feat.parameters); track key) {
                <div class="flex justify-between">
                  <span class="text-slate-500">{{ key }}:</span>
                  <span class="text-emerald-400 font-semibold">{{ feat.parameters[key] }}</span>
                </div>
              }
            </div>
          </div>
        }
      </div>


      <!-- Feature Evaluation Status -->
      <div class="p-3 border-t border-slate-800 bg-slate-950/70 font-mono text-[11px] flex items-center justify-between">
        <span class="text-slate-400">Total Features: {{ features.length }}</span>
        <span class="text-emerald-400 font-semibold flex items-center gap-1">
          <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
          PARAMETRIC SOLVER: READY
        </span>
      </div>
    </div>
  `,
})
export class CadFeatureTreeComponent {
  @Input() features: CADFeatureItem[] = [];
  @Output() featuresChanged = new EventEmitter<CADFeatureItem[]>();
  @Output() addFeature = new EventEmitter<void>();

  getFeatureIcon(type: string): string {
    switch (type) {
      case 'EXTRUDE': return 'height';
      case 'REVOLVE': return 'rotate_right';
      case 'FILLET': return 'rounded_corner';
      case 'HOLE_PATTERN': return 'blur_circular';
      case 'SHELL': return 'crop_free';
      case 'LATTICE': return 'grain';
      case 'BOOLEAN_CUT': return 'content_cut';
      default: return 'widgets';
    }
  }

  getParamKeys(params: Record<string, unknown>): string[] {
    return Object.keys(params || {});
  }


  toggleSuppression(feat: CADFeatureItem) {
    feat.suppressed = !feat.suppressed;
    this.featuresChanged.emit(this.features);
  }
}
