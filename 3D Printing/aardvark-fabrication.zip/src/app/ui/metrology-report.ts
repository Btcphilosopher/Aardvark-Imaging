import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { InspectionMetrics } from '../core/models/geometry.models';

@Component({
  selector: 'app-metrology-report',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-col h-full bg-slate-900/70 backdrop-blur-md border-l border-slate-800 text-xs overflow-hidden">
      <!-- Header -->
      <div class="p-3.5 border-b border-slate-800 flex items-center justify-between">
        <div>
          <div class="font-bold text-slate-100 tracking-wider text-[13px] flex items-center gap-2">
            <mat-icon class="text-sm! w-4! h-4! text-emerald-400">verified</mat-icon>
            3D METROLOGY & INSPECTION
          </div>
          <div class="text-[10px] font-mono text-slate-400 mt-0.5">GEOMETRIC DEVIATION & GD&T VERIFICATION</div>
        </div>
        <span
          [class.bg-emerald-500/20]="metrics?.qualityStatus === 'PASS'"
          [class.text-emerald-400]="metrics?.qualityStatus === 'PASS'"
          [class.border-emerald-500/30]="metrics?.qualityStatus === 'PASS'"
          [class.bg-amber-500/20]="metrics?.qualityStatus === 'WARNING'"
          [class.text-amber-400]="metrics?.qualityStatus === 'WARNING'"
          [class.border-amber-500/30]="metrics?.qualityStatus === 'WARNING'"
          class="px-2.5 py-1 rounded-lg border font-mono font-bold text-xs"
        >
          {{ metrics?.qualityStatus || 'PENDING' }}
        </span>
      </div>

      <!-- Content -->
      <div class="flex-1 overflow-y-auto p-3 space-y-4">
        <!-- Key Statistical Metrics -->
        <div class="grid grid-cols-2 gap-2 font-mono">
          <div class="p-2.5 bg-slate-800/60 rounded-xl border border-slate-700/80">
            <div class="text-[10px] text-slate-400">RMS DEVIATION</div>
            <div class="text-sm font-bold text-emerald-400 mt-0.5">{{ metrics?.rmsDeviationMm || 0.042 }} mm</div>
          </div>
          <div class="p-2.5 bg-slate-800/60 rounded-xl border border-slate-700/80">
            <div class="text-[10px] text-slate-400">95th PERCENTILE</div>
            <div class="text-sm font-bold text-cyan-400 mt-0.5">{{ metrics?.percentile95Mm || 0.068 }} mm</div>
          </div>
          <div class="p-2.5 bg-slate-800/60 rounded-xl border border-slate-700/80">
            <div class="text-[10px] text-slate-400">MEAN DEVIATION</div>
            <div class="text-sm font-bold text-slate-200 mt-0.5">{{ metrics?.meanDeviationMm || -0.015 }} mm</div>
          </div>
          <div class="p-2.5 bg-slate-800/60 rounded-xl border border-slate-700/80">
            <div class="text-[10px] text-slate-400">MAX PEAK (±)</div>
            <div class="text-sm font-bold text-amber-400 mt-0.5">{{ metrics?.maxDeviationMm || 0.095 }} mm</div>
          </div>
        </div>

        <!-- Deviation Histogram -->
        <div class="p-3 rounded-xl bg-slate-800/60 border border-slate-700/80 space-y-2">
          <div class="font-semibold text-slate-200 flex items-center justify-between">
            <span>Deviation Distribution</span>
            <span class="text-[10px] font-mono text-slate-400">Gaussian fit</span>
          </div>
          <div class="space-y-1.5 font-mono text-[10px]">
            @for (bar of metrics?.histogram; track bar.range) {
              <div class="space-y-0.5">
                <div class="flex justify-between text-slate-400">
                  <span>{{ bar.range }}</span>
                  <span class="text-slate-200 font-bold">{{ bar.count }} pts</span>
                </div>
                <div class="w-full h-2 rounded bg-slate-900 overflow-hidden border border-slate-800">
                  <div
                    class="h-full bg-emerald-400 rounded transition-all duration-500"
                    [style.width.%]="(bar.count / 480) * 100"
                  ></div>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- GD&T Tolerance Feature Checks -->
        <div class="p-3 rounded-xl bg-slate-800/60 border border-slate-700/80 space-y-2.5">
          <span class="font-semibold text-slate-200 flex items-center gap-1.5">
            <mat-icon class="text-sm! w-4! h-4! text-emerald-400">rule</mat-icon>
            GD&T Inspection Features
          </span>

          <div class="space-y-2">
            @for (check of metrics?.toleranceChecks; track check.feature) {
              <div
                class="p-2.5 bg-slate-900/80 rounded-lg border border-slate-800 space-y-1 text-[11px]"
              >
                <div class="flex items-center justify-between">
                  <span class="font-semibold text-slate-200">{{ check.feature }}</span>
                  <span
                    [class.text-emerald-400]="check.status === 'PASS'"
                    [class.text-amber-400]="check.status === 'WARNING'"
                    class="font-mono font-bold text-[10px] px-1.5 py-0.5 rounded bg-slate-800"
                  >
                    {{ check.status }}
                  </span>
                </div>
                <div class="grid grid-cols-3 gap-1 font-mono text-[10px] text-slate-400">
                  <div>Nom: <span class="text-slate-200">{{ check.nominalMm }}mm</span></div>
                  <div>Meas: <span class="text-slate-200">{{ check.measuredMm }}mm</span></div>
                  <div>Dev: <span class="text-emerald-400 font-bold">{{ check.deviationMm > 0 ? '+' : '' }}{{ check.deviationMm }}mm</span></div>
                </div>
              </div>
            }
          </div>
        </div>


        <!-- Digital Twin Closed-Loop Feedforward Compensation -->
        <div class="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/30 space-y-2">
          <div class="flex items-center justify-between">
            <span class="font-semibold text-emerald-400 flex items-center gap-1.5">
              <mat-icon class="text-sm! w-4! h-4!">all_inclusive</mat-icon>
              Digital Twin Compensation
            </span>
            <span class="text-[9px] font-mono px-1.5 py-0.5 bg-emerald-500/20 text-emerald-300 rounded">Active Loop</span>
          </div>
          <div class="text-[11px] text-slate-300">
            Thermal shrinkage of <strong>0.32%</strong> detected on X/Y axis. Digital Twin has generated inverse dimensional scaling matrices for the next manufacturing iteration.
          </div>
          <button
            (click)="applyCompensation.emit()"
            class="w-full py-1.5 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 font-semibold rounded-lg border border-emerald-500/40 transition-all text-xs"
          >
            Apply Inverse Matrix to CAD Model
          </button>
        </div>
      </div>
    </div>
  `,
})
export class MetrologyReportComponent {
  @Input() metrics?: InspectionMetrics;
  @Output() applyCompensation = new EventEmitter<void>();
}
