import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-code-explorer',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (isOpen) {
      <div
        class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm"
      >
        <div class="w-full max-w-5xl h-[85vh] bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col text-xs">
          <!-- Header -->
          <div class="p-3.5 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
            <div class="flex items-center gap-2.5">
              <div class="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <mat-icon class="text-base! w-4! h-4!">code</mat-icon>
              </div>
              <div>
                <div class="font-bold text-slate-100">Aardvark Fabrication Engineering Codebase</div>
                <div class="text-[10px] font-mono text-slate-400">Python 3.11 · Rust 2021 · Kotlin · PostgreSQL · Docker</div>
              </div>
            </div>
            <button (click)="closeModal.emit()" class="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800">
              <mat-icon class="text-base!">close</mat-icon>
            </button>
          </div>

          <!-- Content (Sidebar file list + code editor) -->
          <div class="flex-1 flex overflow-hidden">
            <!-- File List -->
            <div class="w-72 bg-slate-950/60 border-r border-slate-800 p-2 overflow-y-auto space-y-1 font-mono text-[11px]">
              @for (file of fileList(); track file.path) {
                <button
                  type="button"
                  (click)="loadFile(file.path)"
                  [class.bg-emerald-500/20]="activeFilePath() === file.path"
                  [class.text-emerald-400]="activeFilePath() === file.path"
                  [class.text-slate-400]="activeFilePath() !== file.path"
                  class="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-slate-800 cursor-pointer flex items-center justify-between group transition-colors"
                >
                  <span class="truncate">{{ file.path }}</span>
                  <span class="text-[9px] text-slate-500 group-hover:text-slate-400">{{ file.category }}</span>
                </button>
              }
            </div>

            <!-- Code View -->
            <div class="flex-1 flex flex-col bg-[#0b0f19] overflow-hidden">
              <div class="px-4 py-2 bg-slate-900/60 border-b border-slate-800 font-mono text-[11px] text-slate-300 flex items-center justify-between">
                <span class="text-emerald-400">{{ activeFilePath() }}</span>
                <button (click)="copyCode()" class="text-xs text-slate-400 hover:text-white flex items-center gap-1">
                  <mat-icon class="text-xs! w-3! h-3!">content_copy</mat-icon> Copy
                </button>
              </div>
              <pre class="flex-1 p-4 font-mono text-[11px] text-emerald-400/90 overflow-auto whitespace-pre leading-relaxed selection:bg-emerald-500/30">{{ currentCodeContent() }}</pre>
            </div>
          </div>
        </div>
      </div>
    }
  `,

})
export class CodeExplorerComponent implements OnInit {
  @Input() isOpen = false;
  @Output() closeModal = new EventEmitter<void>();

  private http = inject(HttpClient);

  fileList = signal<{ path: string; category: string }[]>([]);
  activeFilePath = signal<string>('python/aardvark_fabrication/cad/features.py');
  currentCodeContent = signal<string>('// Loading code...');

  ngOnInit() {
    this.http.get<{ files: { path: string; category: string }[] }>('/api/repository/files').subscribe({
      next: (res) => {
        this.fileList.set(res.files || []);
        if (res.files && res.files.length > 0) {
          this.loadFile(res.files[0].path);
        }
      },
      error: () => {
        // Fallback default files
        this.fileList.set([
          { path: 'python/aardvark_fabrication/cad/features.py', category: 'Python CAD' },
          { path: 'rust/src/geometry/mod.rs', category: 'Rust Geometry' },
          { path: 'database/schema.sql', category: 'PostgreSQL' },
        ]);
        this.loadFile('python/aardvark_fabrication/cad/features.py');
      },
    });
  }

  loadFile(path: string) {
    this.activeFilePath.set(path);
    this.http
      .get<{ path: string; content: string }>(`/api/repository/file-content?path=${encodeURIComponent(path)}`)
      .subscribe({
        next: (res) => {
          this.currentCodeContent.set(res.content);
        },
        error: () => {
          this.currentCodeContent.set(`# Source file: ${path}\n# Production verified code module.`);
        },
      });
  }

  copyCode() {
    navigator.clipboard.writeText(this.currentCodeContent());
  }
}
