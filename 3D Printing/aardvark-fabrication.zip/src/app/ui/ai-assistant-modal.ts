import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output,
  inject,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule } from '@angular/forms';
import { AICommandResponse, AiAssistantService } from '../core/services/ai-assistant.service';

@Component({
  selector: 'app-ai-assistant-modal',
  imports: [CommonModule, MatIconModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (isOpen) {
      <div
        class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm"
      >
        <div class="w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] text-xs">
          <!-- Header -->
          <div class="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
            <div class="flex items-center gap-2.5">
              <div class="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-500 to-cyan-400 flex items-center justify-center text-slate-950 font-black shadow-md">
                <mat-icon class="text-base! w-5! h-5!">psychology</mat-icon>
              </div>
              <div>
                <div class="font-bold text-sm text-slate-100">Aardvark CAD & DFM AI Engineer</div>
                <div class="text-[10px] font-mono text-emerald-400">Powered by Gemini 2.5 Pro / Flash Model Kernel</div>
              </div>
            </div>
            <button (click)="closeModal.emit()" class="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800">
              <mat-icon class="text-base!">close</mat-icon>
            </button>
          </div>

          <!-- Body & Chat -->
          <div class="flex-1 overflow-y-auto p-4 space-y-4">
            <!-- Quick Prompts -->
            <div class="space-y-1.5">
              <div class="text-[10px] font-mono uppercase tracking-wider text-slate-400">Quick Engineering Prompts:</div>
              <div class="flex flex-wrap gap-1.5">
                @for (qp of quickPrompts; track qp) {
                  <button
                    type="button"
                    (click)="sendQuickPrompt(qp)"
                    class="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700/80 transition-all text-[11px]"
                  >
                    {{ qp }}
                  </button>
                }
              </div>
            </div>

            <!-- AI Response Box -->
            @if (loading()) {
              <div class="p-6 text-center space-y-2">
                <mat-icon class="animate-spin text-emerald-400 text-2xl!">autorenew</mat-icon>
                <div class="font-mono text-slate-400 text-xs">Analyzing 3D Topology & Slicing Constraints...</div>
              </div>
            }

            @if (aiResponse() && !loading()) {
              <div class="space-y-4">
                <!-- Analysis Statement -->
                <div class="p-3.5 bg-slate-800/80 rounded-xl border border-slate-700/80 space-y-2">
                  <div class="font-semibold text-emerald-400 flex items-center gap-1.5 text-xs">
                    <mat-icon class="text-sm! w-4! h-4!">analytics</mat-icon>
                    Topology & Manufacturing Assessment
                  </div>
                  <p class="text-slate-200 leading-relaxed text-xs">{{ aiResponse()?.analysis }}</p>
                </div>

                <!-- Suggested CAD Operations -->
                @if (aiResponse()?.suggestedFeatures?.length) {
                  <div class="space-y-2">
                    <div class="font-semibold text-slate-300 text-xs flex items-center gap-1.5">
                      <mat-icon class="text-sm! w-4! h-4! text-cyan-400">auto_fix_high</mat-icon>
                      Suggested Parametric Features
                    </div>
                    <div class="space-y-2">
                      @for (feat of aiResponse()?.suggestedFeatures; track feat.command) {
                        <div
                          class="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between"
                        >
                          <div>
                            <div class="font-bold text-slate-200">{{ feat.command }}</div>
                            <div class="text-[11px] text-slate-400">{{ feat.description }}</div>
                          </div>
                          <button
                            (click)="applyFeature(feat)"
                            class="px-3 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-lg text-xs"
                          >
                            Apply
                          </button>
                        </div>
                      }
                    </div>
                  </div>
                }

                <!-- DFM & Slicing Guidance -->
                @if (aiResponse()?.dfmAdvice?.length) {
                  <div class="p-3.5 bg-slate-800/80 rounded-xl border border-slate-700/80 space-y-2">
                    <div class="font-semibold text-amber-400 flex items-center gap-1.5 text-xs">
                      <mat-icon class="text-sm! w-4! h-4!">lightbulb</mat-icon>
                      DFAM Guidelines & Slicing Rules
                    </div>
                    <ul class="list-disc list-inside space-y-1 text-slate-300 text-xs">
                      @for (advice of aiResponse()?.dfmAdvice; track advice) {
                        <li>{{ advice }}</li>
                      }
                    </ul>
                  </div>
                }
              </div>
            }
          </div>

          <!-- Input Bar -->
          <div class="p-3 border-t border-slate-800 bg-slate-950 flex items-center gap-2">
            <input
              type="text"
              [(ngModel)]="userPrompt"
              (keyup.enter)="submitPrompt()"
              placeholder="Ask AI Engineer to optimize geometry, reduce weight, or diagnose overhangs..."
              class="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-slate-200 focus:border-emerald-500 outline-none text-xs"
            />
            <button
              (click)="submitPrompt()"
              [disabled]="loading() || !userPrompt.trim()"
              class="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-slate-950 font-bold rounded-xl transition-all flex items-center gap-1 cursor-pointer"
            >
              <mat-icon class="text-sm! w-4! h-4!">send</mat-icon>
              <span>Ask</span>
            </button>
          </div>
        </div>
      </div>
    }
  `,
})
export class AiAssistantModalComponent {
  @Input() isOpen = false;
  @Output() closeModal = new EventEmitter<void>();
  @Output() featureApplied = new EventEmitter<Record<string, unknown>>();

  private aiService = inject(AiAssistantService);

  userPrompt = '';
  loading = signal(false);
  aiResponse = signal<AICommandResponse | null>(null);

  quickPrompts = [
    'Optimize for aerospace lightweighting (Gyroid Lattice)',
    'Add stress-relief fillets to base boss',
    'Diagnose overhang printability in PA-CF',
    'Calculate GD&T thermal shrinkage compensation',
  ];

  sendQuickPrompt(prompt: string) {
    this.userPrompt = prompt;
    this.submitPrompt();
  }

  submitPrompt() {
    if (!this.userPrompt.trim()) return;
    this.loading.set(true);

    this.aiService.askAssistant(this.userPrompt, {}).subscribe({
      next: (res) => {
        this.aiResponse.set(res);
        this.loading.set(false);
      },
      error: () => {
        this.loading.set(false);
      },
    });
  }

  applyFeature(feat: { command: string; description: string; parameters: Record<string, unknown> }) {
    this.featureApplied.emit(feat.parameters);
    this.closeModal.emit();
  }
}
