import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PipelineStageId } from '../core/models/geometry.models';

export interface StageInfo {
  id: PipelineStageId;
  stepNum: number;
  name: string;
  category: string;
  icon: string;
  status: 'PENDING' | 'ACTIVE' | 'COMPLETED' | 'WARNING';
  description: string;
}

@Component({
  selector: 'app-pipeline-runner',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-col h-full bg-slate-900/60 backdrop-blur-md border-r border-slate-800 text-xs overflow-hidden">
      <!-- Header -->
      <div class="p-3.5 border-b border-slate-800 flex items-center justify-between">
        <div>
          <div class="font-bold text-slate-100 tracking-wider text-[13px] flex items-center gap-2">
            <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            MANUFACTURING PIPELINE
          </div>
          <div class="text-[10px] font-mono text-slate-400 mt-0.5">CLOSED-LOOP COMPUTATIONAL CYCLE</div>
        </div>
        <button
          (click)="runFullPipeline.emit()"
          class="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-lg transition-all flex items-center gap-1.5 shadow-md shadow-emerald-500/20 active:scale-95"
          title="Run All 22 Closed-Loop Steps"
        >
          <mat-icon class="text-sm! w-4! h-4!">play_arrow</mat-icon>
          <span>AUTO RUN</span>
        </button>
      </div>

      <!-- Stage List -->
      <div class="flex-1 overflow-y-auto p-2 space-y-1.5">
        @for (stage of stages; track stage.id) {
          <button
            type="button"
            (click)="selectStage.emit(stage.id)"
            [class.bg-slate-800]="activeStage === stage.id"
            [class.border-emerald-500]="activeStage === stage.id"
            [class.border-slate-800]="activeStage !== stage.id"
            class="w-full text-left p-2.5 rounded-xl border transition-all cursor-pointer hover:bg-slate-800/80 group flex items-start gap-2.5"
          >
            <!-- Status Icon -->
            <div
              [class.bg-emerald-500/20]="stage.status === 'COMPLETED'"
              [class.text-emerald-400]="stage.status === 'COMPLETED'"
              [class.bg-amber-500/20]="stage.status === 'ACTIVE'"
              [class.text-amber-400]="stage.status === 'ACTIVE'"
              [class.bg-slate-800]="stage.status === 'PENDING'"
              [class.text-slate-500]="stage.status === 'PENDING'"
              class="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5 transition-colors"
            >
              <mat-icon class="text-sm! w-4! h-4!">
                {{ stage.status === 'COMPLETED' ? 'check_circle' : stage.icon }}
              </mat-icon>
            </div>

            <!-- Stage Info -->
            <div class="flex-1 min-w-0">
              <div class="flex items-center justify-between">
                <span class="font-semibold text-slate-200 truncate group-hover:text-emerald-400 transition-colors">
                  {{ stage.stepNum }}. {{ stage.name }}
                </span>
                @if (stage.status === 'COMPLETED') {
                  <span
                    class="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                  >
                    PASS
                  </span>
                }
              </div>
              <div class="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                {{ stage.description }}
              </div>
            </div>
          </button>
        }
      </div>


      <!-- Footer Diagnostics -->
      <div class="p-3 border-t border-slate-800 bg-slate-950/60 font-mono text-[10px] text-slate-400 space-y-1">
        <div class="flex justify-between">
          <span>Engine Kernel:</span>
          <span class="text-emerald-400">Rust FFI & Python 3.11</span>
        </div>
        <div class="flex justify-between">
          <span>Dimensional State:</span>
          <span class="text-cyan-400">SI Base (Metres)</span>
        </div>
      </div>
    </div>
  `,
})
export class PipelineRunnerComponent {
  @Input() activeStage: PipelineStageId = 'SYNTHETIC_OBJECT';
  @Input() stages: StageInfo[] = [];
  @Output() selectStage = new EventEmitter<PipelineStageId>();
  @Output() runFullPipeline = new EventEmitter<void>();
}
