import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule } from '@angular/forms';
import { MaterialProfile, PrinterProfile } from '../core/models/geometry.models';
import { STANDARD_MATERIALS, STANDARD_PRINTERS } from '../core/services/computational-engine.service';

@Component({
  selector: 'app-fabrication-panel',
  imports: [CommonModule, MatIconModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-col h-full bg-slate-900/70 backdrop-blur-md border-l border-slate-800 text-xs overflow-hidden">
      <!-- Header -->
      <div class="p-3.5 border-b border-slate-800 flex items-center justify-between">
        <div>
          <div class="font-bold text-slate-100 tracking-wider text-[13px] flex items-center gap-2">
            <mat-icon class="text-sm! w-4! h-4! text-emerald-400">precision_manufacturing</mat-icon>
            PRINT PREPARATION & SLICER
          </div>
          <div class="text-[10px] font-mono text-slate-400 mt-0.5">DFAM ORIENTATION & MOTION KERNEL</div>
        </div>
        <button
          (click)="recomputeSlicing.emit()"
          class="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-lg transition-all flex items-center gap-1.5 shadow-md shadow-emerald-500/20 active:scale-95"
        >
          <mat-icon class="text-sm! w-4! h-4!">layers</mat-icon>
          <span>SLICE NOW</span>
        </button>
      </div>

      <!-- Controls & Parameters -->
      <div class="flex-1 overflow-y-auto p-3 space-y-4">
        <!-- Material Selection Card -->
        <div class="p-3 rounded-xl bg-slate-800/60 border border-slate-700/80 space-y-2">
          <div class="flex items-center justify-between">
            <span class="font-semibold text-slate-200 flex items-center gap-1.5">
              <mat-icon class="text-sm! w-4! h-4! text-cyan-400">science</mat-icon>
              Engineering Material
            </span>
            <span class="font-mono text-emerald-400 font-bold">\${{ selectedMaterial.costPerKgUsd }}/kg</span>
          </div>

          <select
            [ngModel]="selectedMaterial.id"
            (ngModelChange)="onMaterialChange($event)"
            class="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-200 focus:border-emerald-500 outline-none"
          >
            @for (m of materials; track m.id) {
              <option [value]="m.id">{{ m.name }} ({{ m.family }})</option>
            }
          </select>

          <div class="grid grid-cols-2 gap-2 pt-1 font-mono text-[10px] text-slate-400">
            <div>Density: <span class="text-slate-200">{{ selectedMaterial.densityGPerCm3 }} g/cm³</span></div>
            <div>Print Temp: <span class="text-slate-200">{{ selectedMaterial.printTempC }}°C</span></div>
            <div>Modulus: <span class="text-slate-200">{{ selectedMaterial.elasticModulusMpa }} MPa</span></div>
            <div>Shrinkage: <span class="text-slate-200">{{ selectedMaterial.shrinkageFactor * 100 }}%</span></div>
          </div>
        </div>

        <!-- Printer Profile Card -->
        <div class="p-3 rounded-xl bg-slate-800/60 border border-slate-700/80 space-y-2">
          <div class="flex items-center justify-between">
            <span class="font-semibold text-slate-200 flex items-center gap-1.5">
              <mat-icon class="text-sm! w-4! h-4! text-cyan-400">print</mat-icon>
              Printer & Dialect
            </span>
            <span class="font-mono text-cyan-400 text-[10px] font-bold">{{ selectedPrinter.firmwareDialect }}</span>
          </div>

          <select
            [ngModel]="selectedPrinter.id"
            (ngModelChange)="onPrinterChange($event)"
            class="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-200 focus:border-emerald-500 outline-none"
          >
            @for (p of printers; track p.id) {
              <option [value]="p.id">{{ p.name }}</option>
            }
          </select>
        </div>

        <!-- Slicer Settings Form -->
        <div class="p-3 rounded-xl bg-slate-800/60 border border-slate-700/80 space-y-3">
          <span class="font-semibold text-slate-200 flex items-center gap-1.5">
            <mat-icon class="text-sm! w-4! h-4! text-amber-400">tune</mat-icon>
            Toolpath Parameters
          </span>

          <div class="space-y-2">
            <div>
              <div class="flex justify-between text-[11px] mb-1">
                <span class="text-slate-400">Layer Height:</span>
                <span class="font-mono text-emerald-400 font-bold">{{ layerHeightMm }} mm</span>
              </div>
              <input
                type="range"
                min="0.08"
                max="0.32"
                step="0.02"
                [(ngModel)]="layerHeightMm"
                (ngModelChange)="settingsChanged()"
                class="w-full accent-emerald-500 cursor-pointer"
              />
            </div>

            <div>
              <div class="flex justify-between text-[11px] mb-1">
                <span class="text-slate-400">Infill Density:</span>
                <span class="font-mono text-emerald-400 font-bold">{{ infillDensityPct }}% (Gyroid)</span>
              </div>
              <input
                type="range"
                min="10"
                max="90"
                step="5"
                [(ngModel)]="infillDensityPct"
                (ngModelChange)="settingsChanged()"
                class="w-full accent-emerald-500 cursor-pointer"
              />
            </div>

            <div>
              <div class="flex justify-between text-[11px] mb-1">
                <span class="text-slate-400">Print Speed:</span>
                <span class="font-mono text-emerald-400 font-bold">{{ printSpeedMmS }} mm/s</span>
              </div>
              <input
                type="range"
                min="40"
                max="300"
                step="10"
                [(ngModel)]="printSpeedMmS"
                (ngModelChange)="settingsChanged()"
                class="w-full accent-emerald-500 cursor-pointer"
              />
            </div>
          </div>
        </div>

        <!-- Slicing Results Summary -->
        <div class="p-3 rounded-xl bg-slate-950/80 border border-emerald-500/30 space-y-2">
          <div class="font-semibold text-emerald-400 flex items-center gap-1.5">
            <mat-icon class="text-sm! w-4! h-4!">assessment</mat-icon>
            Manufacturing Estimates
          </div>
          <div class="grid grid-cols-3 gap-2 font-mono text-center">
            <div class="p-2 bg-slate-900 rounded-lg border border-slate-800">
              <div class="text-[10px] text-slate-500">PRINT TIME</div>
              <div class="text-[13px] font-bold text-slate-100">{{ estimatedTimeMin }} min</div>
            </div>
            <div class="p-2 bg-slate-900 rounded-lg border border-slate-800">
              <div class="text-[10px] text-slate-500">MASS</div>
              <div class="text-[13px] font-bold text-emerald-400">{{ estimatedMaterialG }} g</div>
            </div>
            <div class="p-2 bg-slate-900 rounded-lg border border-slate-800">
              <div class="text-[10px] text-slate-500">COST</div>
              <div class="text-[13px] font-bold text-cyan-400">\${{ estimatedCostUsd }}</div>
            </div>
          </div>
        </div>

        <!-- G-Code Terminal Snippet -->
        <div class="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
          <div class="flex items-center justify-between text-[11px]">
            <span class="font-mono text-slate-400 flex items-center gap-1">
              <mat-icon class="text-sm! w-4! h-4! text-emerald-400">terminal</mat-icon>
              Generated G-Code (Dialect: {{ selectedPrinter.firmwareDialect }})
            </span>
            <button (click)="copyGCode()" class="text-emerald-400 hover:underline">Copy</button>
          </div>
          <pre class="bg-black/80 rounded-lg p-2 font-mono text-[10px] text-emerald-400/90 overflow-x-auto max-h-28">{{ gcodePreview }}</pre>
        </div>
      </div>
    </div>
  `,
})

export class FabricationPanelComponent {
  @Input() selectedMaterial: MaterialProfile = STANDARD_MATERIALS[0];
  @Input() selectedPrinter: PrinterProfile = STANDARD_PRINTERS[0];
  @Input() layerHeightMm = 0.20;
  @Input() infillDensityPct = 25;
  @Input() printSpeedMmS = 150;
  @Input() estimatedTimeMin = 42;
  @Input() estimatedMaterialG = 68.4;
  @Input() estimatedCostUsd = 1.68;
  @Input() gcodePreview = '; G-Code Ready';

  @Output() materialChanged = new EventEmitter<MaterialProfile>();
  @Output() printerChanged = new EventEmitter<PrinterProfile>();
  @Output() recomputeSlicing = new EventEmitter<void>();

  materials = STANDARD_MATERIALS;
  printers = STANDARD_PRINTERS;

  onMaterialChange(id: string) {
    const mat = this.materials.find((m) => m.id === id) || this.materials[0];
    this.materialChanged.emit(mat);
  }

  onPrinterChange(id: string) {
    const p = this.printers.find((pr) => pr.id === id) || this.printers[0];
    this.printerChanged.emit(p);
  }

  settingsChanged() {
    this.recomputeSlicing.emit();
  }

  copyGCode() {
    navigator.clipboard.writeText(this.gcodePreview);
  }
}
