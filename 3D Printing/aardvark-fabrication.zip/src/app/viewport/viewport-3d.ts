import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChanges,
  ViewChild,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { GeometryData, SlicedLayerData, ViewportMode } from '../core/models/geometry.models';

@Component({
  selector: 'app-viewport-3d',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-full bg-[#080c14] overflow-hidden select-none" #canvasContainer>
      <canvas #glCanvas class="w-full h-full block cursor-grab active:cursor-grabbing"></canvas>

      <!-- Viewport Mode Ribbon -->
      <div class="absolute top-3 left-3 z-10 flex flex-wrap items-center gap-1.5 p-1 bg-slate-900/85 backdrop-blur-md rounded-xl border border-slate-800 text-xs shadow-lg">
        @for (m of modes; track m.id) {
          <button
            (click)="setMode(m.id)"
            [class.bg-emerald-500]="activeMode === m.id"
            [class.text-slate-950]="activeMode === m.id"
            [class.font-semibold]="activeMode === m.id"
            [class.text-slate-400]="activeMode !== m.id"
            [class.hover:text-slate-200]="activeMode !== m.id"
            [class.hover:bg-slate-800]="activeMode !== m.id"
            class="px-2.5 py-1.5 rounded-lg transition-all flex items-center gap-1.5"
            [title]="m.description"
          >
            <mat-icon class="text-sm! w-4! h-4! leading-none!">{{ m.icon }}</mat-icon>
            <span>{{ m.label }}</span>
          </button>
        }
      </div>

      <!-- Camera Presets & Section Control Panel -->
      <div class="absolute top-3 right-3 z-10 flex items-center gap-2">
        <!-- Section Plane Slider (When in SECTION mode) -->
        @if (activeMode === 'SECTION') {
          <div class="flex items-center gap-2 bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-800 text-xs">
            <span class="text-slate-400">Clip Z:</span>
            <input
              type="range"
              min="0"
              max="60"
              [value]="sectionPlaneZ()"
              (input)="onSectionSliderChange($event)"
              class="w-28 accent-emerald-500 cursor-pointer"
            />
            <span class="font-mono text-emerald-400 w-10 text-right">{{ sectionPlaneZ() }}mm</span>
          </div>
        }

        <!-- Layer Scrubber (When in LAYER or TOOLPATH mode) -->
        @if (activeMode === 'LAYER' || activeMode === 'TOOLPATH') {
          <div class="flex items-center gap-2 bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-800 text-xs">
            <span class="text-slate-400">Layer:</span>
            <input
              type="range"
              min="0"
              [max]="maxLayers - 1"
              [value]="activeLayerIndex()"
              (input)="onLayerSliderChange($event)"
              class="w-28 accent-cyan-500 cursor-pointer"
            />
            <span class="font-mono text-cyan-400 w-14 text-right">{{ activeLayerIndex() + 1 }} / {{ maxLayers }}</span>
          </div>
        }

        <div class="flex items-center gap-1 bg-slate-900/85 backdrop-blur-md p-1 rounded-xl border border-slate-800 text-xs">
          <button (click)="setCameraView('ISO')" class="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800" title="Isometric View">
            <mat-icon class="text-sm! w-4! h-4!">view_in_ar</mat-icon>
          </button>
          <button (click)="setCameraView('TOP')" class="px-2 py-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 font-mono text-[10px]" title="Top View">TOP</button>
          <button (click)="setCameraView('FRONT')" class="px-2 py-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 font-mono text-[10px]" title="Front View">FRONT</button>
          <button (click)="setCameraView('SIDE')" class="px-2 py-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 font-mono text-[10px]" title="Side View">SIDE</button>
          <div class="h-4 w-[1px] bg-slate-800 mx-1"></div>
          <button (click)="resetCamera()" class="p-1.5 text-slate-400 hover:text-emerald-400 rounded-lg hover:bg-slate-800" title="Fit to Screen">
            <mat-icon class="text-sm! w-4! h-4!">fit_screen</mat-icon>
          </button>
        </div>
      </div>

      <!-- Metrology Heatmap Legend (When in DEVIATION mode) -->
      @if (activeMode === 'DEVIATION') {
        <div class="absolute bottom-6 left-6 z-10 bg-slate-900/90 backdrop-blur-md p-3 rounded-xl border border-slate-800 shadow-xl text-xs flex flex-col gap-2 min-w-[200px]">
          <div class="flex items-center justify-between font-mono text-[11px] text-slate-300">
            <span class="font-semibold text-white">DEVIATION MAP (GD&T)</span>
            <span class="text-emerald-400">±0.20 mm</span>
          </div>
          <div class="w-full h-3.5 rounded-md bg-gradient-to-r from-blue-600 via-emerald-400 to-red-600 border border-slate-700"></div>
          <div class="flex justify-between font-mono text-[10px] text-slate-400">
            <span class="text-blue-400">-0.20 mm (Under)</span>
            <span class="text-emerald-400">0.00 Nominal</span>
            <span class="text-red-400">+0.20 mm (Over)</span>
          </div>
        </div>
      }

      <!-- Toolpath Legend (When in TOOLPATH mode) -->
      @if (activeMode === 'TOOLPATH') {
        <div class="absolute bottom-6 left-6 z-10 bg-slate-900/90 backdrop-blur-md p-3 rounded-xl border border-slate-800 shadow-xl text-xs flex flex-col gap-1.5">
          <div class="font-semibold text-white mb-1">TOOLPATH TYPES</div>
          <div class="flex items-center gap-2 text-slate-300"><span class="w-2.5 h-2.5 rounded-full bg-yellow-400"></span> Outer Perimeter</div>
          <div class="flex items-center gap-2 text-slate-300"><span class="w-2.5 h-2.5 rounded-full bg-orange-500"></span> Inner Walls</div>
          <div class="flex items-center gap-2 text-slate-300"><span class="w-2.5 h-2.5 rounded-full bg-emerald-400"></span> Gyroid/Grid Infill</div>
          <div class="flex items-center gap-2 text-slate-300"><span class="w-2.5 h-2.5 rounded-full bg-cyan-400"></span> Tree Supports</div>
          <div class="flex items-center gap-2 text-slate-400"><span class="w-2.5 h-2.5 rounded-full bg-blue-500"></span> Rapid Travel Move</div>
        </div>
      }

      <!-- Viewport Coordinate Compass Overlay -->
      <div class="absolute bottom-6 right-6 z-10 pointer-events-none bg-slate-900/60 backdrop-blur-sm px-2.5 py-1.5 rounded-lg border border-slate-800 text-[10px] font-mono text-slate-400 flex items-center gap-3">
        <div class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-red-500"></span> X</div>
        <div class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-green-500"></span> Y</div>
        <div class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-blue-500"></span> Z</div>
        <div class="text-slate-500">SI (mm)</div>
      </div>
    </div>
  `,

})
export class Viewport3DComponent implements OnInit, OnChanges, OnDestroy {
  @ViewChild('canvasContainer', { static: true }) containerRef!: ElementRef<HTMLDivElement>;
  @ViewChild('glCanvas', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;

  @Input() activeMode: ViewportMode = 'SOLID';
  @Input() meshData?: GeometryData;
  @Input() pointCloudData?: GeometryData;
  @Input() slicedLayers: SlicedLayerData[] = [];
  @Input() activeLayer = 0;
  @Input() animatedNozzlePos?: { x: number; y: number; z: number };

  sectionPlaneZ = signal(25);
  activeLayerIndex = signal(0);
  maxLayers = 50;

  modes: { id: ViewportMode; label: string; icon: string; description: string }[] = [
    { id: 'SOLID', label: 'Solid', icon: 'view_in_ar', description: 'PBR Shaded CAD Solid' },
    { id: 'WIREFRAME', label: 'Wireframe', icon: 'grid_4x4', description: 'Triangular Topology Edges' },
    { id: 'MESH', label: 'Mesh', icon: 'polyline', description: 'Faceted Triangle Geometry' },
    { id: 'POINT_CLOUD', label: 'Point Cloud', icon: 'grain', description: 'Dense LiDAR / Structured Light Scan' },
    { id: 'SECTION', label: 'Section', icon: 'content_cut', description: 'Interactive Dynamic Cut Plane' },
    { id: 'TRANSPARENT', label: 'X-Ray', icon: 'opacity', description: 'Internal Lattice Cavity Inspection' },
    { id: 'TOOLPATH', label: 'Toolpath', icon: 'route', description: 'Multi-Color G-Code Toolpaths' },
    { id: 'LAYER', label: 'Layer', icon: 'layers', description: 'Single Slice Layer Scrubber' },
    { id: 'DEVIATION', label: 'Deviation', icon: 'speed', description: '3D Metrology Signed Colormap' },
    { id: 'DIGITAL_TWIN', label: 'Digital Twin', icon: 'sync', description: 'Synchronized CAD ↔ Print ↔ Scan' },
  ];

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private mainGroup = new THREE.Group();
  private gridHelper!: THREE.GridHelper;
  private clippingPlane!: THREE.Plane;
  private nozzleMesh?: THREE.Mesh;
  private reqAnimationId?: number;

  // Orbit controls state
  private isDragging = false;
  private prevMouse = { x: 0, y: 0 };
  private spherical = { radius: 120, theta: Math.PI / 4, phi: Math.PI / 3 };
  private target = new THREE.Vector3(0, 0, 15);

  ngOnInit() {
    this.initThree();
    this.setupMouseEvents();
    this.rebuildSceneGeometry();
    this.animate();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['slicedLayers'] && this.slicedLayers.length > 0) {
      this.maxLayers = this.slicedLayers.length;
    }
    if (changes['activeLayer']) {
      this.activeLayerIndex.set(this.activeLayer);
    }
    if (changes['meshData'] || changes['pointCloudData'] || changes['activeMode'] || changes['slicedLayers']) {
      this.rebuildSceneGeometry();
    }
    if (changes['animatedNozzlePos'] && this.nozzleMesh && this.animatedNozzlePos) {
      this.nozzleMesh.position.set(this.animatedNozzlePos.x, this.animatedNozzlePos.y, this.animatedNozzlePos.z);
    }
  }

  ngOnDestroy() {
    if (this.reqAnimationId) {
      cancelAnimationFrame(this.reqAnimationId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  setMode(mode: ViewportMode) {
    this.activeMode = mode;
    this.rebuildSceneGeometry();
  }

  onSectionSliderChange(event: Event) {
    const val = Number((event.target as HTMLInputElement).value);
    this.sectionPlaneZ.set(val);
    this.clippingPlane.constant = val;
  }

  onLayerSliderChange(event: Event) {
    const val = Number((event.target as HTMLInputElement).value);
    this.activeLayerIndex.set(val);
    this.rebuildSceneGeometry();
  }

  setCameraView(view: 'ISO' | 'TOP' | 'FRONT' | 'SIDE') {
    switch (view) {
      case 'ISO':
        this.spherical.theta = Math.PI / 4;
        this.spherical.phi = Math.PI / 3;
        break;
      case 'TOP':
        this.spherical.theta = 0;
        this.spherical.phi = 0.001;
        break;
      case 'FRONT':
        this.spherical.theta = 0;
        this.spherical.phi = Math.PI / 2;
        break;
      case 'SIDE':
        this.spherical.theta = Math.PI / 2;
        this.spherical.phi = Math.PI / 2;
        break;
    }
    this.updateCameraPosition();
  }

  resetCamera() {
    this.target.set(0, 0, 15);
    this.spherical.radius = 120;
    this.spherical.theta = Math.PI / 4;
    this.spherical.phi = Math.PI / 3;
    this.updateCameraPosition();
  }

  private initThree() {
    const width = this.containerRef.nativeElement.clientWidth || 800;
    const height = this.containerRef.nativeElement.clientHeight || 600;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x080c14);

    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 2000);
    this.updateCameraPosition();

    this.renderer = new THREE.WebGLRenderer({
      canvas: this.canvasRef.nativeElement,
      antialias: true,
      powerPreference: 'high-performance',
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.localClippingEnabled = true;

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.85);
    this.scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight1.position.set(100, 150, 200);
    this.scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x38bdf8, 0.6); // Cyan rim light
    dirLight2.position.set(-100, -100, -50);
    this.scene.add(dirLight2);

    // Build Plate Grid (300mm x 300mm)
    this.gridHelper = new THREE.GridHelper(300, 30, 0x1e293b, 0x0f172a);
    this.gridHelper.rotation.x = Math.PI / 2;
    this.scene.add(this.gridHelper);

    // Dynamic Section Clipping Plane
    this.clippingPlane = new THREE.Plane(new THREE.Vector3(0, 0, -1), this.sectionPlaneZ());

    // Coordinate Axes Triad (X=Red, Y=Green, Z=Blue)
    const axes = new THREE.AxesHelper(25);
    this.scene.add(axes);

    this.scene.add(this.mainGroup);

    // Handle container resize
    const resizeObserver = new ResizeObserver(() => {
      const w = this.containerRef.nativeElement.clientWidth;
      const h = this.containerRef.nativeElement.clientHeight;
      if (w > 0 && h > 0) {
        this.camera.aspect = w / h;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(w, h);
      }
    });
    resizeObserver.observe(this.containerRef.nativeElement);
  }

  private rebuildSceneGeometry() {
    if (!this.scene) return;

    // Clear main group
    while (this.mainGroup.children.length > 0) {
      const obj = this.mainGroup.children[0];
      this.mainGroup.remove(obj);
      if (obj instanceof THREE.Mesh || obj instanceof THREE.Points || obj instanceof THREE.LineSegments) {
        obj.geometry.dispose();
      }
    }

    const mesh = this.meshData;

    switch (this.activeMode) {
      case 'SOLID':
      case 'SECTION':
      case 'TRANSPARENT':
        if (mesh && mesh.vertices.length > 0) {
          const geom = this.buildBufferGeometry(mesh);
          let mat: THREE.Material;

          if (this.activeMode === 'TRANSPARENT') {
            mat = new THREE.MeshPhysicalMaterial({
              color: 0x38bdf8,
              metalness: 0.1,
              roughness: 0.2,
              transparent: true,
              opacity: 0.35,
              side: THREE.DoubleSide,
            });
          } else if (this.activeMode === 'SECTION') {
            mat = new THREE.MeshStandardMaterial({
              color: 0x94a3b8,
              metalness: 0.4,
              roughness: 0.3,
              side: THREE.DoubleSide,
              clippingPlanes: [this.clippingPlane],
              clipShadows: true,
            });
          } else {
            mat = new THREE.MeshStandardMaterial({
              color: 0xcbd5e1,
              metalness: 0.2,
              roughness: 0.35,
              side: THREE.DoubleSide,
            });
          }

          const modelMesh = new THREE.Mesh(geom, mat);
          this.mainGroup.add(modelMesh);

          // Subtle edges
          const edgesGeom = new THREE.EdgesGeometry(geom, 25);
          const edgesMat = new THREE.LineBasicMaterial({
            color: this.activeMode === 'TRANSPARENT' ? 0x0284c7 : 0x475569,
            linewidth: 1,
            clippingPlanes: this.activeMode === 'SECTION' ? [this.clippingPlane] : [],
          });
          const edges = new THREE.LineSegments(edgesGeom, edgesMat);
          this.mainGroup.add(edges);
        }
        break;

      case 'WIREFRAME':
        if (mesh && mesh.vertices.length > 0) {
          const geom = this.buildBufferGeometry(mesh);
          const mat = new THREE.MeshBasicMaterial({
            color: 0x10b981,
            wireframe: true,
          });
          const wireMesh = new THREE.Mesh(geom, mat);
          this.mainGroup.add(wireMesh);
        }
        break;

      case 'MESH':
        if (mesh && mesh.vertices.length > 0) {
          const geom = this.buildBufferGeometry(mesh);
          const mat = new THREE.MeshStandardMaterial({
            color: 0x64748b,
            flatShading: true,
            roughness: 0.6,
            side: THREE.DoubleSide,
          });
          const facetedMesh = new THREE.Mesh(geom, mat);
          this.mainGroup.add(facetedMesh);
        }
        break;

      case 'POINT_CLOUD': {
        const pcd = this.pointCloudData || mesh;
        if (pcd && pcd.vertices.length > 0) {
          const pcdGeom = new THREE.BufferGeometry();
          pcdGeom.setAttribute('position', new THREE.Float32BufferAttribute(pcd.vertices, 3));

          if (pcd.pointColors && pcd.pointColors.length === pcd.vertices.length) {
            pcdGeom.setAttribute('color', new THREE.Float32BufferAttribute(pcd.pointColors, 3));
          } else {
            // Default cyan LiDAR colors
            const colors = new Float32Array(pcd.vertices.length);
            for (let i = 0; i < pcd.vertices.length; i += 3) {
              colors[i] = 0.05;
              colors[i + 1] = 0.8;
              colors[i + 2] = 0.95;
            }
            pcdGeom.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
          }

          const pcdMat = new THREE.PointsMaterial({
            size: 2.2,
            vertexColors: true,
            sizeAttenuation: true,
          });
          const points = new THREE.Points(pcdGeom, pcdMat);
          this.mainGroup.add(points);
        }
        break;
      }


      case 'TOOLPATH':
      case 'LAYER':
        this.renderToolpaths();
        break;

      case 'DEVIATION':
        this.renderMetrologyDeviation();
        break;

      case 'DIGITAL_TWIN':
        this.renderDigitalTwinOverlay();
        break;
    }
  }

  private renderToolpaths() {
    if (!this.slicedLayers || this.slicedLayers.length === 0) return;

    const targetLayerIdx = this.activeMode === 'LAYER' ? this.activeLayerIndex() : this.slicedLayers.length;
    const linePositions: { type: string; points: number[] }[] = [
      { type: 'PERIMETER', points: [] },
      { type: 'INFILL', points: [] },
      { type: 'SUPPORT', points: [] },
      { type: 'TRAVEL', points: [] },
    ];

    const layersToDraw = this.activeMode === 'LAYER' ? [this.slicedLayers[targetLayerIdx] || this.slicedLayers[0]] : this.slicedLayers;

    for (const layer of layersToDraw) {
      if (!layer) continue;
      for (const seg of layer.segments) {
        const bucket = linePositions.find((b) => b.type === seg.type) || linePositions[0];
        bucket.points.push(seg.start.x, seg.start.y, seg.start.z);
        bucket.points.push(seg.end.x, seg.end.y, seg.end.z);
      }
    }

    const colorMap: Record<string, number> = {
      PERIMETER: 0xfacc15, // Yellow
      INFILL: 0x34d399,    // Emerald
      SUPPORT: 0x22d3ee,   // Cyan
      TRAVEL: 0x3b82f6,    // Blue
    };

    for (const bucket of linePositions) {
      if (bucket.points.length === 0) continue;
      const geom = new THREE.BufferGeometry();
      geom.setAttribute('position', new THREE.Float32BufferAttribute(bucket.points, 3));
      const mat = new THREE.LineBasicMaterial({
        color: colorMap[bucket.type] || 0xffffff,
        linewidth: bucket.type === 'TRAVEL' ? 1 : 2,
        opacity: bucket.type === 'TRAVEL' ? 0.35 : 0.95,
        transparent: true,
      });
      const lines = new THREE.LineSegments(geom, mat);
      this.mainGroup.add(lines);
    }
  }

  private renderMetrologyDeviation() {
    if (!this.meshData || this.meshData.vertices.length === 0) return;

    const geom = this.buildBufferGeometry(this.meshData);
    const vCount = this.meshData.vertices.length / 3;
    const colors = new Float32Array(vCount * 3);

    // Compute jet colormap for signed deviation (-0.2mm to +0.2mm)
    for (let i = 0; i < vCount; i++) {
      const z = this.meshData.vertices[i * 3 + 2];
      // Simulated physical signed deviation
      const deviation = (Math.sin(z * 0.15 + i * 0.05) * 0.12 - 0.02);
      const normVal = Math.max(-0.2, Math.min(0.2, deviation)) / 0.2; // -1 to +1

      let r = 0, g = 0, b = 0;
      if (normVal < 0) {
        // Blue (undersize) to Green (nominal)
        b = -normVal;
        g = 1 + normVal;
      } else {
        // Green (nominal) to Red (oversize)
        g = 1 - normVal;
        r = normVal;
      }

      colors[i * 3] = r;
      colors[i * 3 + 1] = g;
      colors[i * 3 + 2] = b;
    }

    geom.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    const mat = new THREE.MeshStandardMaterial({
      vertexColors: true,
      roughness: 0.3,
      metalness: 0.1,
      side: THREE.DoubleSide,
    });
    const devMesh = new THREE.Mesh(geom, mat);
    this.mainGroup.add(devMesh);
  }

  private renderDigitalTwinOverlay() {
    // 1. Nominal CAD Shaded
    if (this.meshData) {
      const geom = this.buildBufferGeometry(this.meshData);
      const cadMat = new THREE.MeshStandardMaterial({
        color: 0x334155,
        transparent: true,
        opacity: 0.6,
        wireframe: true,
      });
      this.mainGroup.add(new THREE.Mesh(geom, cadMat));
    }

    // 2. Measured Scan Point Cloud
    const pcd = this.pointCloudData || this.meshData;
    if (pcd) {
      const pcdGeom = new THREE.BufferGeometry();
      pcdGeom.setAttribute('position', new THREE.Float32BufferAttribute(pcd.vertices, 3));
      const pcdMat = new THREE.PointsMaterial({
        color: 0x10b981,
        size: 2.5,
      });
      this.mainGroup.add(new THREE.Points(pcdGeom, pcdMat));
    }
  }

  private buildBufferGeometry(data: GeometryData): THREE.BufferGeometry {
    const geom = new THREE.BufferGeometry();
    geom.setAttribute('position', new THREE.Float32BufferAttribute(data.vertices, 3));

    if (data.indices && data.indices.length > 0) {
      geom.setIndex(data.indices);
    }
    if (data.normals && data.normals.length === data.vertices.length) {
      geom.setAttribute('normal', new THREE.Float32BufferAttribute(data.normals, 3));
    } else {
      geom.computeVertexNormals();
    }
    return geom;
  }

  private setupMouseEvents() {
    const el = this.canvasRef.nativeElement;

    el.addEventListener('mousedown', (e) => {
      this.isDragging = true;
      this.prevMouse = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mousemove', (e) => {
      if (!this.isDragging) return;
      const dx = e.clientX - this.prevMouse.x;
      const dy = e.clientY - this.prevMouse.y;

      if (e.buttons === 1) {
        // Left click = Orbit
        this.spherical.theta -= dx * 0.008;
        this.spherical.phi = Math.max(0.01, Math.min(Math.PI - 0.01, this.spherical.phi - dy * 0.008));
      } else if (e.buttons === 2 || e.buttons === 4) {
        // Right click / Middle = Pan
        const factor = this.spherical.radius * 0.0015;
        this.target.x -= dx * factor * Math.cos(this.spherical.theta);
        this.target.y += dx * factor * Math.sin(this.spherical.theta);
        this.target.z += dy * factor;
      }

      this.prevMouse = { x: e.clientX, y: e.clientY };
      this.updateCameraPosition();
    });

    window.addEventListener('mouseup', () => {
      this.isDragging = false;
    });

    el.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.spherical.radius = Math.max(20, Math.min(500, this.spherical.radius + e.deltaY * 0.15));
      this.updateCameraPosition();
    });

    el.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  private updateCameraPosition() {
    const sinPhiRadius = this.spherical.radius * Math.sin(this.spherical.phi);
    this.camera.position.x = this.target.x + sinPhiRadius * Math.sin(this.spherical.theta);
    this.camera.position.y = this.target.y - sinPhiRadius * Math.cos(this.spherical.theta);
    this.camera.position.z = this.target.z + this.spherical.radius * Math.cos(this.spherical.phi);
    this.camera.lookAt(this.target);
  }

  private animate = () => {
    this.reqAnimationId = requestAnimationFrame(this.animate);
    this.renderer.render(this.scene, this.camera);
  };
}
