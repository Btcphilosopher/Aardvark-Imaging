import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  inject,
  signal,
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { Viewport3DComponent } from './viewport/viewport-3d';
import { PipelineRunnerComponent, StageInfo } from './ui/pipeline-runner';
import { CadFeatureTreeComponent } from './ui/cad-feature-tree';
import { FabricationPanelComponent } from './ui/fabrication-panel';
import { MetrologyReportComponent } from './ui/metrology-report';
import { AiAssistantModalComponent } from './ui/ai-assistant-modal';
import { CodeExplorerComponent } from './ui/code-explorer';
import {
  CADFeatureItem,
  GeometryData,
  InspectionMetrics,
  MaterialProfile,
  PipelineStageId,
  PrinterProfile,
  SlicedLayerData,
  ViewportMode,
} from './core/models/geometry.models';
import {
  ComputationalEngineService,
  STANDARD_MATERIALS,
  STANDARD_PRINTERS,
} from './core/services/computational-engine.service';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    Viewport3DComponent,
    PipelineRunnerComponent,
    CadFeatureTreeComponent,
    FabricationPanelComponent,
    MetrologyReportComponent,
    AiAssistantModalComponent,
    CodeExplorerComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit {
  // State Signals
  activeStage = signal<PipelineStageId>('PARAMETRIC_CAD_SOLID');
  activeViewportMode = signal<ViewportMode>('SOLID');
  activeRightTab = signal<'CAD' | 'FABRICATION' | 'METROLOGY'>('CAD');
  selectedModelType = signal<'BRACKET' | 'IMPELLER' | 'GEAR' | 'LATTICE' | 'HOUSING'>('BRACKET');

  // Geometry Data
  currentMesh = signal<GeometryData | undefined>(undefined);
  currentPointCloud = signal<GeometryData | undefined>(undefined);
  cadFeatures = signal<CADFeatureItem[]>([]);
  slicedLayers = signal<SlicedLayerData[]>([]);
  gcodePreview = signal<string>('; G-Code Ready');
  inspectionMetrics = signal<InspectionMetrics | undefined>(undefined);

  // Slicer & Material Profiles
  selectedMaterial = signal<MaterialProfile>(STANDARD_MATERIALS[0]);
  selectedPrinter = signal<PrinterProfile>(STANDARD_PRINTERS[0]);
  layerHeightMm = signal<number>(0.2);
  infillDensityPct = signal<number>(25);
  printSpeedMmS = signal<number>(150);

  // Slicing Outputs
  estimatedTimeMin = signal<number>(42);
  estimatedMaterialG = signal<number>(68.4);
  estimatedCostUsd = signal<number>(1.68);

  // Simulation Controls
  isSimulating = signal<boolean>(false);
  simCurrentLayer = signal<number>(0);
  simNozzlePos = signal<{ x: number; y: number; z: number }>({ x: 0, y: 0, z: 0.28 });
  simProgress = signal<number>(0);
  simIntervalId?: ReturnType<typeof setInterval>;

  // Modals

  isAiModalOpen = signal<boolean>(false);
  isCodeExplorerOpen = signal<boolean>(false);

  // Pipeline Stages Definition (22 Closed-Loop Engineering Steps mapped to 10 visual phases)
  stages = signal<StageInfo[]>([
    {
      id: 'SYNTHETIC_OBJECT',
      stepNum: 1,
      name: 'Physical / Synthetic Object',
      category: 'Input',
      icon: 'category',
      status: 'COMPLETED',
      description: 'Parametric CSG nominal CAD geometry with SI base units.',
    },
    {
      id: 'SCAN_SIMULATION',
      stepNum: 2,
      name: 'LiDAR / Optical 3D Scan',
      category: 'Metrology',
      icon: 'grain',
      status: 'COMPLETED',
      description: 'Simulate laser line sweep with sensor noise & occlusion.',
    },
    {
      id: 'POINT_CLOUD_FILTERING',
      stepNum: 3,
      name: 'Point Cloud Voxel Filtering',
      category: 'Point Cloud',
      icon: 'filter_alt',
      status: 'COMPLETED',
      description: 'Voxel downsampling & statistical outlier removal filter.',
    },
    {
      id: 'SURFACE_RECONSTRUCTION',
      stepNum: 4,
      name: 'Poisson Surface Mesh',
      category: 'Reconstruction',
      icon: 'polyline',
      status: 'COMPLETED',
      description: 'Screened Poisson surface reconstruction & alpha shapes.',
    },
    {
      id: 'MESH_VALIDATION_REPAIR',
      stepNum: 5,
      name: 'Topological Validation',
      category: 'Mesh Repair',
      icon: 'verified',
      status: 'COMPLETED',
      description: 'Watertight 2-manifold check & self-intersection repair.',
    },
    {
      id: 'FEATURE_REVERSE_ENGINEERING',
      stepNum: 6,
      name: 'RANSAC Feature Extraction',
      category: 'CAD',
      icon: 'view_in_ar',
      status: 'COMPLETED',
      description: 'Reverse-engineer primitive planes, cylinders & hole bores.',
    },
    {
      id: 'PARAMETRIC_CAD_SOLID',
      stepNum: 7,
      name: 'Parametric Feature Tree',
      category: 'CAD',
      icon: 'account_tree',
      status: 'ACTIVE',
      description: 'Editable B-Rep feature tree with sketch, extrude & fillets.',
    },
    {
      id: 'ASSEMBLY_MATERIALS',
      stepNum: 8,
      name: 'Material & Kinematics',
      category: 'Material',
      icon: 'science',
      status: 'COMPLETED',
      description: 'High-modulus PA-CF15 with anisotropic thermal shrinkage.',
    },
    {
      id: 'DFAM_ORIENTATION',
      stepNum: 9,
      name: 'DFAM Build Orientation',
      category: 'DFAM',
      icon: 'rotate_90_degrees_ccw',
      status: 'COMPLETED',
      description: 'Multi-objective Pareto optimization (overhangs & layer shear).',
    },
    {
      id: 'SLICING_TOOLPATH_GCODE',
      stepNum: 10,
      name: 'High-Performance Slicing',
      category: 'Slicing',
      icon: 'layers',
      status: 'COMPLETED',
      description: 'Gyroid infill, adaptive perimeters & Klipper G-Code.',
    },
    {
      id: 'PRINT_SIMULATION',
      stepNum: 11,
      name: '3D Print Kinematic Simulation',
      category: 'Simulation',
      icon: 'motion_photos_on',
      status: 'COMPLETED',
      description: 'Toolhead velocity profile, acceleration & temperature flow.',
    },
    {
      id: 'METROLOGY_INSPECTION_TWIN',
      stepNum: 12,
      name: 'Metrology & Digital Twin',
      category: 'Twin',
      icon: 'sync',
      status: 'COMPLETED',
      description: 'Point-to-surface GD&T deviation analysis & closed loop.',
    },
  ]);

  private engine = inject(ComputationalEngineService);

  ngOnInit() {
    this.rebuildModel(this.selectedModelType());
  }


  rebuildModel(type: 'BRACKET' | 'IMPELLER' | 'GEAR' | 'LATTICE' | 'HOUSING') {
    this.selectedModelType.set(type);
    const { mesh, features } = this.engine.generateSyntheticModel(type);
    this.currentMesh.set(mesh);
    this.cadFeatures.set(features);

    // Generate synthetic scan
    const rawScan = this.engine.generateSyntheticScan(mesh);
    const filteredScan = this.engine.filterPointCloud(rawScan);
    this.currentPointCloud.set(filteredScan);

    // Slicing
    this.recomputeSlicing();

    // Inspection metrics
    const inspection = this.engine.performMetrologyInspection(mesh, filteredScan);
    this.inspectionMetrics.set(inspection);
  }

  onStageSelect(stageId: PipelineStageId) {
    this.activeStage.set(stageId);

    // Update active stages status
    this.stages.update((stages) =>
      stages.map((s) => ({
        ...s,
        status: s.id === stageId ? 'ACTIVE' : 'COMPLETED',
      }))
    );

    // Automatically switch to optimal viewport mode & right tab for selected stage
    switch (stageId) {
      case 'SYNTHETIC_OBJECT':
      case 'PARAMETRIC_CAD_SOLID':
        this.activeViewportMode.set('SOLID');
        this.activeRightTab.set('CAD');
        break;
      case 'SCAN_SIMULATION':
      case 'POINT_CLOUD_FILTERING':
        this.activeViewportMode.set('POINT_CLOUD');
        this.activeRightTab.set('CAD');
        break;
      case 'SURFACE_RECONSTRUCTION':
        this.activeViewportMode.set('MESH');
        this.activeRightTab.set('CAD');
        break;
      case 'MESH_VALIDATION_REPAIR':
        this.activeViewportMode.set('WIREFRAME');
        this.activeRightTab.set('CAD');
        break;
      case 'DFAM_ORIENTATION':
        this.activeViewportMode.set('SECTION');
        this.activeRightTab.set('FABRICATION');
        break;
      case 'SLICING_TOOLPATH_GCODE':
        this.activeViewportMode.set('TOOLPATH');
        this.activeRightTab.set('FABRICATION');
        break;
      case 'PRINT_SIMULATION':
        this.activeViewportMode.set('LAYER');
        this.activeRightTab.set('FABRICATION');
        this.startPrintSimulation();
        break;
      case 'METROLOGY_INSPECTION_TWIN':
        this.activeViewportMode.set('DEVIATION');
        this.activeRightTab.set('METROLOGY');
        break;
    }
  }

  runFullPipeline() {
    let currentIdx = 0;
    const interval = setInterval(() => {
      if (currentIdx < this.stages().length) {
        this.onStageSelect(this.stages()[currentIdx].id);
        currentIdx++;
      } else {
        clearInterval(interval);
      }
    }, 1200);
  }

  recomputeSlicing() {
    const mesh = this.currentMesh();
    if (!mesh) return;

    const result = this.engine.sliceGeometry(mesh, {
      layerHeightMm: this.layerHeightMm(),
      infillDensityPct: this.infillDensityPct(),
      printSpeed: this.printSpeedMmS(),
    });

    this.slicedLayers.set(result.layers);
    this.gcodePreview.set(result.gcode);
    this.estimatedTimeMin.set(result.timeMin);
    this.estimatedMaterialG.set(result.materialG);
    this.estimatedCostUsd.set(result.costUsd);
  }

  onFeaturesChanged(updatedFeatures: CADFeatureItem[]) {
    this.cadFeatures.set(updatedFeatures);
    // Rebuild mesh with applied features
    this.rebuildModel(this.selectedModelType());
  }

  onFeatureAdded() {
    const newFeat: CADFeatureItem = {
      id: `feat_${Date.now()}`,
      name: 'Adaptive Gyroid Infill Core',
      type: 'LATTICE',
      parameters: { relativeDensityPct: 35, unitCell: 'GYROID', wallOffsetMm: 2.0 },
      suppressed: false,
      status: 'VALID',
    };
    this.cadFeatures.update((f) => [...f, newFeat]);
  }

  onAiFeatureApplied(aiFeat: Record<string, unknown>) {
    const newFeat: CADFeatureItem = {
      id: `ai_feat_${Date.now()}`,
      name: (aiFeat['description'] as string) || (aiFeat['command'] as string) || 'AI Feature',
      type: 'FILLET',
      parameters: (aiFeat['parameters'] as Record<string, unknown>) || {},
      suppressed: false,
      status: 'VALID',
    };
    this.cadFeatures.update((f) => [...f, newFeat]);
    this.activeRightTab.set('CAD');
  }


  startPrintSimulation() {
    if (this.isSimulating()) {
      this.pausePrintSimulation();
      return;
    }

    this.isSimulating.set(true);
    const layers = this.slicedLayers();
    if (layers.length === 0) return;

    if (this.simIntervalId) clearInterval(this.simIntervalId);

    this.simIntervalId = setInterval(() => {
      const cur = this.simCurrentLayer();
      if (cur < layers.length - 1) {
        const next = cur + 1;
        this.simCurrentLayer.set(next);
        this.simProgress.set(Math.round((next / layers.length) * 100));

        const lData = layers[next];
        if (lData && lData.segments.length > 0) {
          const seg = lData.segments[Math.floor(lData.segments.length / 2)];
          this.simNozzlePos.set(seg.end);
        }
      } else {
        this.pausePrintSimulation();
      }
    }, 150);
  }

  pausePrintSimulation() {
    this.isSimulating.set(false);
    if (this.simIntervalId) {
      clearInterval(this.simIntervalId);
    }
  }

  applyDigitalTwinCompensation() {
    alert(
      'Digital Twin Closed-Loop Active: Inverted thermal shrinkage matrix [-0.32% X/Y, +0.12% Z] applied to nominal CAD solid model. Rebuilding toolpaths...'
    );
    this.rebuildModel(this.selectedModelType());
    this.onStageSelect('SLICING_TOOLPATH_GCODE');
  }

  exportCurrentModel() {
    const mesh = this.currentMesh();
    if (!mesh) return;

    // Generate ASCII STL file
    let stl = `solid ${mesh.name}\n`;
    const v = mesh.vertices;
    for (let i = 0; i < v.length; i += 9) {
      stl += `  facet normal 0.0 0.0 1.0\n    outer loop\n`;
      stl += `      vertex ${v[i]} ${v[i+1]} ${v[i+2]}\n`;
      stl += `      vertex ${v[i+3]} ${v[i+4]} ${v[i+5]}\n`;
      stl += `      vertex ${v[i+6]} ${v[i+7]} ${v[i+8]}\n`;
      stl += `    endloop\n  endfacet\n`;
    }
    stl += `endsolid ${mesh.name}\n`;

    const blob = new Blob([stl], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${mesh.name.toLowerCase().replace(/\s+/g, '_')}_aardvark.stl`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
