export type PipelineStageId =
  | 'SYNTHETIC_OBJECT'
  | 'SCAN_SIMULATION'
  | 'POINT_CLOUD_FILTERING'
  | 'SURFACE_RECONSTRUCTION'
  | 'MESH_VALIDATION_REPAIR'
  | 'FEATURE_REVERSE_ENGINEERING'
  | 'PARAMETRIC_CAD_SOLID'
  | 'ASSEMBLY_MATERIALS'
  | 'DFAM_ORIENTATION'
  | 'SLICING_TOOLPATH_GCODE'
  | 'PRINT_SIMULATION'
  | 'METROLOGY_INSPECTION_TWIN';

export type ViewportMode =
  | 'SOLID'
  | 'WIREFRAME'
  | 'MESH'
  | 'POINT_CLOUD'
  | 'SECTION'
  | 'TRANSPARENT'
  | 'TOOLPATH'
  | 'LAYER'
  | 'DEVIATION'
  | 'DIGITAL_TWIN';

export interface Point3D {
  x: number;
  y: number;
  z: number;
}

export interface TriangleFace {
  indices: [number, number, number];
  normal?: Point3D;
  color?: string;
}

export interface GeometryData {
  name: string;
  vertices: number[]; // Flat [x,y,z, x,y,z, ...]
  indices?: number[]; // Triangle indices
  normals?: number[]; // Vertex or face normals
  pointColors?: number[]; // Flat [r,g,b, r,g,b, ...] 0-1
  deviations?: number[]; // Signed deviation per vertex/point in mm
  boundingBox: {
    min: Point3D;
    max: Point3D;
    dimensions: Point3D;
    center: Point3D;
  };
}

export interface CADFeatureItem {
  id: string;
  name: string;
  type: 'SKETCH' | 'EXTRUDE' | 'REVOLVE' | 'FILLET' | 'CHAMFER' | 'HOLE_PATTERN' | 'SHELL' | 'BOOLEAN_CUT' | 'LATTICE';
  parameters: Record<string, unknown>;
  suppressed: boolean;
  status: 'VALID' | 'WARNING' | 'ERROR';
}


export interface MaterialProfile {
  id: string;
  name: string;
  family: 'PLA' | 'PETG' | 'ABS' | 'TPU' | 'PA_CF' | 'RESIN' | 'METAL';
  densityGPerCm3: number;
  elasticModulusMpa: number;
  yieldStrengthMpa: number;
  printTempC: number;
  bedTempC: number;
  shrinkageFactor: number;
  costPerKgUsd: number;
  description: string;
}

export interface PrinterProfile {
  id: string;
  name: string;
  buildVolume: { x: number; y: number; z: number };
  nozzleDiameterMm: number;
  maxSpeedMmPerS: number;
  firmwareDialect: 'GENERIC_FDM' | 'KLIPPER' | 'MARLIN' | 'REPRAP' | 'BAMBU';
}

export interface ToolpathSegment {
  type: 'PERIMETER' | 'INNER_WALL' | 'INFILL' | 'SUPPORT' | 'TRAVEL' | 'RETRACT';
  start: Point3D;
  end: Point3D;
  feedrate: number;
  extrusion: number;
  layerIndex: number;
}

export interface SlicedLayerData {
  layerIndex: number;
  zHeightMm: number;
  segmentCount: number;
  segments: ToolpathSegment[];
}

export interface InspectionMetrics {
  meanDeviationMm: number;
  rmsDeviationMm: number;
  maxDeviationMm: number;
  percentile95Mm: number;
  minDeviationMm: number;
  qualityStatus: 'PASS' | 'WARNING' | 'FAIL';
  toleranceChecks: {
    feature: string;
    nominalMm: number;
    upperLimitMm: number;
    lowerLimitMm: number;
    measuredMm: number;
    deviationMm: number;
    status: 'PASS' | 'WARNING' | 'FAIL';
  }[];
  histogram: { range: string; count: number }[];
}

export interface PipelineExecutionState {
  currentStage: PipelineStageId;
  stagesCompleted: Record<PipelineStageId, boolean>;
  syntheticModelType: 'BRACKET' | 'IMPELLER' | 'GEAR' | 'LATTICE' | 'HOUSING';
  rawPointCloud?: GeometryData;
  filteredPointCloud?: GeometryData;
  reconstructedMesh?: GeometryData;
  repairedMesh?: GeometryData;
  cadModel?: {
    features: CADFeatureItem[];
    solidGeometry: GeometryData;
  };
  material: MaterialProfile;
  printer: PrinterProfile;
  dfamScore: {
    overhangAreaMm2: number;
    supportVolumeCm3: number;
    printabilityIndex: number; // 0 - 100
    recommendation: string;
    orientations: { angleX: number; angleY: number; angleZ: number; score: number; supportVol: number }[];
  };
  slicing: {
    layerCount: number;
    totalSegments: number;
    layers: SlicedLayerData[];
    gcodePreview: string;
    estimatedTimeMin: number;
    estimatedMaterialG: number;
    estimatedCostUsd: number;
  };
  simulation: {
    currentLayer: number;
    playbackSpeed: number;
    isPlaying: boolean;
    activeNozzlePos: Point3D;
    progressPercent: number;
  };
  inspection: InspectionMetrics;
  digitalTwin: {
    twinId: string;
    iterations: number;
    compensationX: number;
    compensationY: number;
    compensationZ: number;
    flowMultiplier: number;
    learningNote: string;
  };
}
