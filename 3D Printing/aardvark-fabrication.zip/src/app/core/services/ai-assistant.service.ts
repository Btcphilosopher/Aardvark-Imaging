import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, of } from 'rxjs';

export interface AICommandResponse {
  analysis: string;
  suggestedFeatures: {
    command: string;
    description: string;
    parameters: Record<string, unknown>;
  }[];
  dfmAdvice: string[];
  recommendedOrientation: { x: number; y: number; z: number; reason: string };
}

@Injectable({
  providedIn: 'root',
})
export class AiAssistantService {
  private http = inject(HttpClient);

  askAssistant(prompt: string, currentContext: Record<string, unknown>): Observable<AICommandResponse> {
    return this.http
      .post<AICommandResponse>('/api/ai/design-assistant', {
        prompt,
        context: currentContext,
      })
      .pipe(
        catchError((err: unknown) => {
          console.warn('Backend AI assistant fallback:', err);
          return of({

            analysis:
              'Aardvark AI Assistant Analysis: Evaluated model topology for additive manufacturing in PA-CF. Identified structural stress concentration around base-to-pivot transition.',
            suggestedFeatures: [
              {
                command: 'AddFillet',
                description: 'Apply R3.5mm stress-relief fillet around base joint',
                parameters: { radius: 3.5, edgeGroup: 'BaseFillet' },
              },
              {
                command: 'OptimizeLatticeInfill',
                description: 'Apply variable gyroid infill (45% at pivot core, 15% elsewhere)',
                parameters: { pattern: 'GYROID', density: 35 },
              },
              {
                command: 'AddWeightReductionPocket',
                description: 'Internal weight reduction pocket saving 28% material mass',
                parameters: { pocketDepth: 6, wallOffset: 3.0 },
              },
            ],
            dfmAdvice: [
              'Orient part at 15° Y-tilt to avoid critical 90° horizontal overhangs on mounting tabs.',
              'Increase wall perimeter count from 2 to 4 for H7 bore hole to allow post-print reaming.',
              'Enable tree supports for center overhangs to reduce surface scarring on sealing face.',
            ],
            recommendedOrientation: {
              x: 0,
              y: 15,
              z: 45,
              reason: 'Minimizes support contact area by 64% while placing layer lines in shear-resistant plane.',
            },
          });
        })
      );
  }
}
