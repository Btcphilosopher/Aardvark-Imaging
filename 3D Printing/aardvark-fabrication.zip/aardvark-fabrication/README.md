# AARDVARK FABRICATION

> **"Computational Manufacturing from the Physical World."**
> Production-Grade 3D Reconstruction, CAD, Parametric Modelling, Additive Manufacturing, and Closed-Loop Metrology Platform.
> Part of the Aardvark Imaging Ecosystem.

---

## Architecture Overview

```
PHYSICAL OBJECT
       │
       ▼
 3D SCAN / LIDAR ────────► [ScannerCalibration & Raw Depth]
       │
       ▼
  POINT CLOUD ───────────► [Voxel Downsampling, Statistical Outlier Filter, Normal Estimation]
       │
       ▼
 RECONSTRUCTION ─────────► [Poisson Surface, Ball Pivoting, Alpha Shapes]
       │
       ▼
TRIANGLE / HALF-EDGE ────► [Manifold Check, Watertight Repair, Degenerate Triangle Cleanup]
       │
       ▼
FEATURE EXTRACTION ──────► [RANSAC Planes, Cylinders, Spheres, Cones, Hole Detection]
       │
       ▼
PARAMETRIC CAD / SOLID ──► [Feature Tree: Sketches, Constraints, Extrusions, Fillets, CSG/B-Rep]
       │
       ▼
ASSEMBLIES & MATERIALS ──► [Kinematic Joints, Interference Checks, BOM, Thermal/Mechanical Profiles]
       │
       ▼
   DFAM & ORIENT ────────► [Overhang Analysis, Wall Thickness, Multi-Objective Cost Optimization]
       │
       ▼
 SUPPORT & SLICING ──────► [Tree/Grid Supports, Layer Intersect Z=Z0+nh, Perimeter Offsets, Infill]
       │
       ▼
TOOLPATH & G-CODE ───────► [Machine-Independent Moves, Motion Dynamics, G0/G1/M-Codes Dialects]
       │
       ▼
PRINT SIMULATION ────────► [Toolhead Kinematics, Thermal Deposition, Material & Cost Forecast]
       │
       ▼
PHYSICAL PART (PRINTED) ──► [Synthetic/Physical Part with Shrinkage, Warpage, & Tolerance Variance]
       │
       ▼
METROLOGY & INSPECTION ──► [Point-to-Surface Signed Deviation, RMS, 95th Percentile, GD&T Tolerance Report]
       │
       ▼
  DIGITAL TWIN ──────────► [Nominal Design ↔ Print Execution ↔ Measured Scan Lineage & Learning]
```

---

## Directory Structure

```
aardvark-fabrication/
├── README.md
├── pyproject.toml
├── Cargo.toml
├── Makefile
├── docker-compose.yml
├── configs/
│   ├── printer_profiles.json
│   ├── material_profiles.json
│   └── slice_profiles.json
├── python/aardvark_fabrication/
│   ├── core/
│   ├── geometry/
│   ├── pointcloud/
│   ├── reconstruction/
│   ├── mesh/
│   ├── topology/
│   ├── cad/
│   ├── parametric/
│   ├── solids/
│   ├── assemblies/
│   ├── materials/
│   ├── manufacturing/
│   ├── additive/
│   ├── slicing/
│   ├── toolpath/
│   ├── supports/
│   ├── simulation/
│   ├── inspection/
│   ├── metrology/
│   ├── digital_twin/
│   ├── projects/
│   ├── storage/
│   ├── api/
│   ├── diagnostics/
│   ├── telemetry/
│   ├── security/
│   ├── export/
│   └── cli/
├── rust/src/
│   ├── geometry/
│   ├── mesh/
│   ├── boolean/
│   ├── spatial/
│   ├── voxel/
│   ├── slicing/
│   ├── polygon/
│   ├── toolpath/
│   ├── collision/
│   └── numerics/
├── kotlin/app/
│   ├── ui/
│   ├── viewport/
│   ├── project/
│   ├── model/
│   ├── cad/
│   ├── assembly/
│   ├── materials/
│   ├── fabrication/
│   ├── printer/
│   ├── simulation/
│   ├── inspection/
│   ├── diagnostics/
│   └── settings/
├── database/
│   ├── migrations/
│   ├── schema.sql
│   └── seed.sql
├── api/
│   └── openapi.yaml
├── examples/
├── sample_models/
├── sample_scans/
├── simulations/
├── tests/
├── benchmarks/
├── docs/
└── scripts/
```

---

## Key Modules & Capabilities

1. **Deterministic SI Units Engine**: SI units (`m`, `kg`, `s`, `rad`) internally, displaying customizable engineering units (`mm`, `in`, `cm`).
2. **Reverse Engineering Engine**: RANSAC feature decomposition (planes, hole cylinders, bounding boxes, wall thickness) converting raw scans into editable parametric feature trees.
3. **Parametric CAD & Constraint Engine**: Feature trees (`Sketch`, `Extrude`, `Fillet`, `Chamfer`, `HolePattern`, `Shell`, `BooleanCut`) with geometric constraints (`coincident`, `concentric`, `perpendicular`, `tangent`, `equal`).
4. **DFAM & Multi-Objective Orientation**: Multi-factor orientation score minimizing overhang area, height, support volume, and maximize layer strength.
5. **Real Slicer & Toolpath Engine**: Slices planar intersections, generates outer/inner perimeters, infill (Rectilinear, Grid, Honeycomb, Gyroid, Concentric), travel moves, retractions, and dialect-specific G-Code (Klipper, Marlin, RepRap, Bambu).
6. **Closed-Loop Metrology & Digital Twin**: Computes signed surface deviations ($d = \mathbf{n} \cdot (\mathbf{p}_{\text{meas}} - \mathbf{p}_{\text{ref}})$), RMS deviation, 95th percentile, and GD&T tolerance pass/fail statuses.
7. **AI Design Assistant**: Gemini-powered structured CAD commands and design-for-additive-manufacturing suggestions with strict schema validation.
