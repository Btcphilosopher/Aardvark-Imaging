-- Aardvark Fabrication Canonical PostgreSQL Schema
-- Closed-Loop Physical ↔ Digital ↔ Manufacturing System

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Projects
CREATE TABLE IF NOT EXISTS projects (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    owner_id VARCHAR(128) NOT NULL,
    metadata JSONB DEFAULT '{}'::jsonb
);

-- 2. Model Versions (Immutable lineage)
CREATE TABLE IF NOT EXISTS model_versions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    parent_version_id UUID REFERENCES model_versions(id),
    version_number INT NOT NULL,
    author VARCHAR(128) NOT NULL,
    operation VARCHAR(128) NOT NULL,
    operation_parameters JSONB DEFAULT '{}'::jsonb,
    input_hash VARCHAR(64) NOT NULL,
    output_hash VARCHAR(64) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    provenance JSONB DEFAULT '{}'::jsonb
);

-- 3. Meshes & Point Clouds
CREATE TABLE IF NOT EXISTS meshes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    model_version_id UUID NOT NULL REFERENCES model_versions(id) ON DELETE CASCADE,
    vertex_count INT NOT NULL,
    face_count INT NOT NULL,
    is_watertight BOOLEAN NOT NULL DEFAULT FALSE,
    is_manifold BOOLEAN NOT NULL DEFAULT FALSE,
    volume_mm3 DOUBLE PRECISION,
    surface_area_mm2 DOUBLE PRECISION,
    bounding_box JSONB NOT NULL,
    storage_uri VARCHAR(512) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS point_clouds (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    model_version_id UUID NOT NULL REFERENCES model_versions(id) ON DELETE CASCADE,
    point_count INT NOT NULL,
    has_normals BOOLEAN DEFAULT FALSE,
    has_colors BOOLEAN DEFAULT FALSE,
    has_intensities BOOLEAN DEFAULT FALSE,
    scanner_type VARCHAR(64),
    storage_uri VARCHAR(512) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 4. Solids & Feature Trees
CREATE TABLE IF NOT EXISTS solids (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    model_version_id UUID NOT NULL REFERENCES model_versions(id) ON DELETE CASCADE,
    representation_type VARCHAR(32) NOT NULL, -- CSG, BREP, PARAMETRIC
    feature_tree JSONB NOT NULL,
    mass_kg DOUBLE PRECISION,
    center_of_gravity JSONB,
    moments_of_inertia JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 5. Materials
CREATE TABLE IF NOT EXISTS materials (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(128) NOT NULL,
    family VARCHAR(64) NOT NULL, -- PLA, PETG, ABS, TPU, RESIN, METAL
    density_g_cm3 DOUBLE PRECISION NOT NULL,
    elastic_modulus_mpa DOUBLE PRECISION NOT NULL,
    yield_strength_mpa DOUBLE PRECISION NOT NULL,
    thermal_conductivity_w_mk DOUBLE PRECISION,
    specific_heat_j_kgk DOUBLE PRECISION,
    print_temperature_c DOUBLE PRECISION NOT NULL,
    bed_temperature_c DOUBLE PRECISION NOT NULL,
    shrinkage_factor DOUBLE PRECISION NOT NULL DEFAULT 0.005,
    cost_per_kg_usd DOUBLE PRECISION NOT NULL,
    properties JSONB DEFAULT '{}'::jsonb
);

-- 6. Printers & Profiles
CREATE TABLE IF NOT EXISTS printers (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(128) NOT NULL,
    manufacturer VARCHAR(128) NOT NULL,
    build_volume_x_mm DOUBLE PRECISION NOT NULL,
    build_volume_y_mm DOUBLE PRECISION NOT NULL,
    build_volume_z_mm DOUBLE PRECISION NOT NULL,
    nozzle_diameter_mm DOUBLE PRECISION NOT NULL,
    max_speed_mm_s DOUBLE PRECISION NOT NULL,
    max_accel_mm_s2 DOUBLE PRECISION NOT NULL,
    firmware_dialect VARCHAR(64) NOT NULL DEFAULT 'GENERIC_FDM',
    adapter_class VARCHAR(128) NOT NULL
);

-- 7. Print Jobs & Toolpaths
CREATE TABLE IF NOT EXISTS print_jobs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES projects(id),
    model_version_id UUID NOT NULL REFERENCES model_versions(id),
    printer_id VARCHAR(64) NOT NULL REFERENCES printers(id),
    material_id VARCHAR(64) NOT NULL REFERENCES materials(id),
    status VARCHAR(32) NOT NULL DEFAULT 'CREATED', -- CREATED, SLICING, READY, PRINTING, COMPLETED, FAILED
    layer_count INT NOT NULL DEFAULT 0,
    estimated_time_seconds INT NOT NULL DEFAULT 0,
    estimated_material_g DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    estimated_cost_usd DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    gcode_storage_uri VARCHAR(512),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 8. Inspection Reports & Digital Twin Metrology
CREATE TABLE IF NOT EXISTS inspection_reports (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    print_job_id UUID NOT NULL REFERENCES print_jobs(id),
    nominal_model_version_id UUID NOT NULL REFERENCES model_versions(id),
    measured_scan_id UUID REFERENCES point_clouds(id),
    mean_deviation_mm DOUBLE PRECISION NOT NULL,
    rms_deviation_mm DOUBLE PRECISION NOT NULL,
    max_deviation_mm DOUBLE PRECISION NOT NULL,
    percentile_95_deviation_mm DOUBLE PRECISION NOT NULL,
    quality_status VARCHAR(32) NOT NULL, -- PASS, WARNING, FAIL
    tolerances_evaluated JSONB NOT NULL,
    deviation_histogram JSONB NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 9. Audit Log
CREATE TABLE IF NOT EXISTS audit_log (
    id BIGSERIAL PRIMARY KEY,
    entity_type VARCHAR(64) NOT NULL,
    entity_id UUID NOT NULL,
    action VARCHAR(64) NOT NULL,
    actor VARCHAR(128) NOT NULL,
    details JSONB DEFAULT '{}'::jsonb,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
