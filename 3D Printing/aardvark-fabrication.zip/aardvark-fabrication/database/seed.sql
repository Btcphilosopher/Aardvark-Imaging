-- Aardvark Fabrication Initial Seed Data

-- Standard Engineering Materials
INSERT INTO materials (id, name, family, density_g_cm3, elastic_modulus_mpa, yield_strength_mpa, thermal_conductivity_w_mk, specific_heat_j_kgk, print_temperature_c, bed_temperature_c, shrinkage_factor, cost_per_kg_usd, properties)
VALUES
('mat_pla_plus', 'Aardvark Precision PLA+', 'PLA', 1.24, 3500.0, 60.0, 0.13, 1800.0, 210.0, 60.0, 0.003, 24.50, '{"color": "Industrial Grey", "nozzle_min": 0.2, "nozzle_max": 0.8}'::jsonb),
('mat_petg_pro', 'Aardvark Tough PETG', 'PETG', 1.27, 2100.0, 50.0, 0.20, 1200.0, 240.0, 80.0, 0.004, 28.00, '{"color": "Signal Orange", "chemical_resistance": "High"}'::jsonb),
('mat_abs_aero', 'Aardvark Aerospace ABS', 'ABS', 1.04, 2300.0, 43.0, 0.17, 1400.0, 255.0, 100.0, 0.008, 32.00, '{"color": "Matte Black", "enclosure_required": true}'::jsonb),
('mat_tpu_95a', 'Aardvark Flex TPU 95A', 'TPU', 1.21, 150.0, 25.0, 0.19, 1500.0, 225.0, 50.0, 0.002, 38.00, '{"shore_hardness": "95A", "elongation_at_break": 550}'::jsonb),
('mat_pa_cf', 'Aardvark High-Modulus PA-CF15', 'PA', 1.15, 7800.0, 110.0, 0.28, 1600.0, 280.0, 90.0, 0.002, 75.00, '{"carbon_fiber_fraction": 0.15, "hardened_nozzle_required": true}'::jsonb),
('mat_ti64_metal', 'Ti-6Al-4V Grade 5 (DMLS)', 'METAL', 4.43, 114000.0, 880.0, 6.7, 526.0, 1650.0, 200.0, 0.012, 320.00, '{"process": "DMLS_SLM", "inert_gas": "Argon"}'::jsonb)
ON CONFLICT (id) DO NOTHING;

-- Standard Printer Configurations (Simulated & Production FDM/DMLS)
INSERT INTO printers (id, name, manufacturer, build_volume_x_mm, build_volume_y_mm, build_volume_z_mm, nozzle_diameter_mm, max_speed_mm_s, max_accel_mm_s2, firmware_dialect, adapter_class)
VALUES
('sim_fdm_standard', 'Aardvark Simulated CoreXY 300', 'Aardvark Robotics', 300.0, 300.0, 350.0, 0.4, 300.0, 5000.0, 'KLIPPER', 'SimulatedPrinterAdapter'),
('sim_fdm_micro', 'Aardvark Precision Micro 150', 'Aardvark Robotics', 150.0, 150.0, 150.0, 0.25, 120.0, 3000.0, 'MARLIN', 'SimulatedPrinterAdapter'),
('sim_dmls_industrial', 'Aardvark Metal DMLS-250', 'Aardvark Additive', 250.0, 250.0, 300.0, 0.05, 5000.0, 10000.0, 'GENERIC_DMLS', 'SimulatedPrinterAdapter')
ON CONFLICT (id) DO NOTHING;

-- Default Project
INSERT INTO projects (id, name, description, owner_id, metadata)
VALUES
('a0000000-0000-0000-0000-000000000001', 'Robotic Joint Pivot Bracket', 'Reverse-engineered kinematic mount with optimized lightweight lattice and high-tolerance mounting bushings.', 'lead_engineer@aardvark-imaging.com', '{"category": "Aerospace / Robotics", "target_tolerance_mm": 0.05}'::jsonb)
ON CONFLICT (id) DO NOTHING;
