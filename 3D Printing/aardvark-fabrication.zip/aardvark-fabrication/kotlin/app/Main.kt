package com.aardvark.fabrication

import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import androidx.compose.ui.unit.dp
import com.aardvark.fabrication.ui.AardvarkMainWindow

/**
 * Aardvark Fabrication Professional Desktop Application Entry Point.
 * Built with Kotlin & Compose Desktop / OpenGL 3D Viewport.
 */
fun main() = application {
    val windowState = rememberWindowState(width = 1600.dp, height = 1000.dp)
    Window(
        onCloseRequest = ::exitApplication,
        title = "Aardvark Fabrication | Computational Manufacturing Platform",
        state = windowState
    ) {
        AardvarkMainWindow()
    }
}
