package com.aardvark.fabrication.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

enum class ViewportMode {
    SOLID, WIREFRAME, MESH, POINT_CLOUD, SECTION, TRANSPARENT, TOOLPATH, LAYER, DEVIATION, DIGITAL_TWIN
}

@Composable
fun AardvarkMainWindow() {
    var activeMode by remember { mutableStateOf(ViewportMode.SOLID) }
    var selectedProject by remember { mutableStateOf("Robotic Pivot Mount") }

    MaterialTheme {
        Row(modifier = Modifier.fillMaxSize()) {
            // Left Tool & Model Tree Panel
            Surface(modifier = Modifier.width(320.dp).fillMaxHeight(), elevation = 4.dp) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("AARDVARK FABRICATION", style = MaterialTheme.typography.h6)
                    Text("Active: $selectedProject", style = MaterialTheme.typography.caption)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("PIPELINE STAGES", style = MaterialTheme.typography.subtitle2)
                    // Pipeline buttons
                }
            }

            // Central 3D Viewport
            Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                // High performance 3D Rendering Canvas / OpenGL integration
            }

            // Right Properties & Inspection Panel
            Surface(modifier = Modifier.width(340.dp).fillMaxHeight(), elevation = 4.dp) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("INSPECTION & METROLOGY", style = MaterialTheme.typography.subtitle1)
                    Text("RMS Deviation: 0.042 mm", style = MaterialTheme.typography.body2)
                }
            }
        }
    }
}
