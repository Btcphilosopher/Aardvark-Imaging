"""
Aardvark Fabrication: Production-Grade 3D Reconstruction, CAD, Additive Manufacturing & Metrology Platform.
"""

__version__ = "1.0.0"
__author__ = "Aardvark Imaging Engineering"
