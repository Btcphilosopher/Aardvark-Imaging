"""
Canonical Geometry Data Structures.
Every geometry entity holds strict UUID, version, units, coordinate frame, and provenance history.
"""

from dataclasses import dataclass, field
import datetime
import uuid
import numpy as np
import numpy.typing as npt
from ..core.units import LengthUnit


@dataclass
class CoordinateFrame:
    name: str = "WORLD"
    origin: npt.NDArray[np.float64] = field(default_factory=lambda: np.zeros(3, dtype=np.float64))
    matrix_3x3: npt.NDArray[np.float64] = field(default_factory=lambda: np.eye(3, dtype=np.float64))


@dataclass
class BoundingBox:
    min_point: npt.NDArray[np.float64]
    max_point: npt.NDArray[np.float64]

    @property
    def dimensions(self) -> npt.NDArray[np.float64]:
        return self.max_point - self.min_point

    @property
    def center(self) -> npt.NDArray[np.float64]:
        return (self.min_point + self.max_point) * 0.5


@dataclass
class PointCloud:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    version: int = 1
    points: npt.NDArray[np.float64] = field(default_factory=lambda: np.empty((0, 3), dtype=np.float64))
    normals: npt.NDArray[np.float64] | None = None
    colors: npt.NDArray[np.float64] | None = None
    intensities: npt.NDArray[np.float64] | None = None
    confidences: npt.NDArray[np.float64] | None = None
    units: LengthUnit = LengthUnit.METRE
    frame: CoordinateFrame = field(default_factory=CoordinateFrame)
    created_at: str = field(default_factory=lambda: datetime.datetime.now(datetime.timezone.utc).isoformat())
    provenance: dict[str, str] = field(default_factory=dict)

    @property
    def count(self) -> int:
        return len(self.points)

    def compute_bounding_box(self) -> BoundingBox:
        if len(self.points) == 0:
            return BoundingBox(np.zeros(3), np.zeros(3))
        return BoundingBox(np.min(self.points, axis=0), np.max(self.points, axis=0))


@dataclass
class TriangleMesh:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    version: int = 1
    vertices: npt.NDArray[np.float64] = field(default_factory=lambda: np.empty((0, 3), dtype=np.float64))
    faces: npt.NDArray[np.int32] = field(default_factory=lambda: np.empty((0, 3), dtype=np.int32))
    vertex_normals: npt.NDArray[np.float64] | None = None
    face_normals: npt.NDArray[np.float64] | None = None
    units: LengthUnit = LengthUnit.METRE
    frame: CoordinateFrame = field(default_factory=CoordinateFrame)
    created_at: str = field(default_factory=lambda: datetime.datetime.now(datetime.timezone.utc).isoformat())
    provenance: dict[str, str] = field(default_factory=dict)

    @property
    def vertex_count(self) -> int:
        return len(self.vertices)

    @property
    def face_count(self) -> int:
        return len(self.faces)

    def compute_bounding_box(self) -> BoundingBox:
        if len(self.vertices) == 0:
            return BoundingBox(np.zeros(3), np.zeros(3))
        return BoundingBox(np.min(self.vertices, axis=0), np.max(self.vertices, axis=0))
