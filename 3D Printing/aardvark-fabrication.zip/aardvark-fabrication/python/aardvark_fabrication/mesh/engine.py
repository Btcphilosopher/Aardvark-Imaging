"""
Mesh Engine & Topological Validation:
- Watertightness check
- Non-manifold edge & vertex detection
- Degenerate triangle cleanup
- Surface area & volume computation via Divergence Theorem
"""

from dataclasses import dataclass
import numpy as np
from ..geometry.canonical import TriangleMesh


@dataclass
class MeshValidationReport:
    is_watertight: bool
    is_manifold: bool
    degenerate_face_count: int
    open_boundary_edge_count: int
    non_manifold_edge_count: int
    volume_m3: float
    surface_area_m2: float
    status: str  # VALID, WARNING, INVALID


def analyze_mesh(mesh: TriangleMesh) -> MeshValidationReport:
    """Analyze mesh topological integrity for additive manufacturing suitability."""
    if mesh.vertex_count == 0 or mesh.face_count == 0:
        return MeshValidationReport(
            is_watertight=False,
            is_manifold=False,
            degenerate_face_count=0,
            open_boundary_edge_count=0,
            non_manifold_edge_count=0,
            volume_m3=0.0,
            surface_area_m2=0.0,
            status="INVALID",
        )

    # 1. Check edges
    edges: dict[tuple[int, int], int] = {}
    degenerate_count = 0

    for f in mesh.faces:
        if f[0] == f[1] or f[1] == f[2] or f[2] == f[0]:
            degenerate_count += 1
            continue

        e1 = tuple(sorted((int(f[0]), int(f[1]))))
        e2 = tuple(sorted((int(f[1]), int(f[2]))))
        e3 = tuple(sorted((int(f[2]), int(f[0]))))

        edges[e1] = edges.get(e1, 0) + 1
        edges[e2] = edges.get(e2, 0) + 1
        edges[e3] = edges.get(e3, 0) + 1

    open_edges = sum(1 for count in edges.values() if count == 1)
    non_manifold_edges = sum(1 for count in edges.values() if count > 2)

    is_watertight = open_edges == 0 and degenerate_count == 0
    is_manifold = non_manifold_edges == 0

    # 2. Surface area & signed volume
    v0 = mesh.vertices[mesh.faces[:, 0]]
    v1 = mesh.vertices[mesh.faces[:, 1]]
    v2 = mesh.vertices[mesh.faces[:, 2]]

    cross_prod = np.cross(v1 - v0, v2 - v0)
    face_areas = 0.5 * np.linalg.norm(cross_prod, axis=1)
    surface_area = float(np.sum(face_areas))

    # Divergence theorem volume integral: V = 1/6 sum(v0 . (v1 x v2))
    volumes = np.einsum("ij,ij->i", v0, np.cross(v1, v2))
    volume = float(np.abs(np.sum(volumes)) / 6.0)

    status = "VALID" if (is_watertight and is_manifold) else ("WARNING" if is_manifold else "INVALID")

    return MeshValidationReport(
        is_watertight=is_watertight,
        is_manifold=is_manifold,
        degenerate_face_count=degenerate_count,
        open_boundary_edge_count=open_edges,
        non_manifold_edge_count=non_manifold_edges,
        volume_m3=volume,
        surface_area_m2=surface_area,
        status=status,
    )
