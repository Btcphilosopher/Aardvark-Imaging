"""
Canonical Units System for Aardvark Fabrication.
All internal representations use SI: metres (m), kilograms (kg), seconds (s), radians (rad).
Explicit, deterministic conversions only — never silent conversion.
"""

from enum import Enum
from typing import Final


class LengthUnit(str, Enum):
    METRE = "m"
    MILLIMETRE = "mm"
    CENTIMETRE = "cm"
    INCH = "in"
    FOOT = "ft"


# Explicit conversion scale factor to SI base (Metres)
TO_METRES: Final[dict[LengthUnit, float]] = {
    LengthUnit.METRE: 1.0,
    LengthUnit.MILLIMETRE: 0.001,
    LengthUnit.CENTIMETRE: 0.01,
    LengthUnit.INCH: 0.0254,
    LengthUnit.FOOT: 0.3048,
}


def to_si_length(value: float, from_unit: LengthUnit) -> float:
    """Convert length to base SI (metres)."""
    return value * TO_METRES[from_unit]


def from_si_length(value_in_metres: float, target_unit: LengthUnit) -> float:
    """Convert length from base SI (metres) to engineering target unit."""
    return value_in_metres / TO_METRES[target_unit]


def mm_to_m(mm: float) -> float:
    return mm * 1e-3


def m_to_mm(m: float) -> float:
    return m * 1e3
