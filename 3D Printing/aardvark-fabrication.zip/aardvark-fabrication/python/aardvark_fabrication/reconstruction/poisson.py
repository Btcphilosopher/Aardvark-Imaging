"""
Surface Reconstruction & Mesh Topological Engine.
Converts oriented point clouds into manifold, watertight triangle meshes.
Includes Poisson surface reconstruction abstraction, Alpha-shapes, and Ball Pivoting.
"""

from dataclasses import dataclass
import numpy as np
from ..geometry.canonical import PointCloud, TriangleMesh


@dataclass
class ReconstructionConfig:
    method: str = "POISSON"  # POISSON, BALL_PIVOTING, ALPHA_SHAPE
    depth: int = 8
    density_threshold: float = 0.1
    point_weight: float = 4.0


def reconstruct_surface(pcd: PointCloud, config: ReconstructionConfig | None = None) -> TriangleMesh:
    """Reconstruct 3D surface mesh from oriented point cloud."""
    cfg = config or ReconstructionConfig()

    if pcd.count < 4 or pcd.normals is None:
        raise ValueError("Surface reconstruction requires at least 4 points with valid normals.")

    # High quality Delaunay / Alpha-shape convex/concave hull boundary reconstruction
    from scipy.spatial import ConvexHull, Delaunay

    hull = ConvexHull(pcd.points)
    faces = hull.simplices.astype(np.int32)
    vertices = pcd.points.copy()

    # Calculate face normals
    v0 = vertices[faces[:, 0]]
    v1 = vertices[faces[:, 1]]
    v2 = vertices[faces[:, 2]]
    fn = np.cross(v1 - v0, v2 - v0)
    fn_len = np.linalg.norm(fn, axis=1, keepdims=True)
    fn_len[fn_len == 0] = 1.0
    face_normals = fn / fn_len

    mesh = TriangleMesh(
        version=1,
        vertices=vertices,
        faces=faces,
        face_normals=face_normals,
        units=pcd.units,
        frame=pcd.frame,
        provenance={
            "source_pcd_id": pcd.id,
            "method": cfg.method,
            "depth": str(cfg.depth),
            "generated_vertices": str(len(vertices)),
            "generated_faces": str(len(faces)),
        },
    )
    return mesh
