"""
Point Cloud Processing Pipeline:
- Voxel Downsampling
- Statistical Outlier Removal (k-NN mean distance & standard deviation)
- Radius Outlier Removal
- Normal Estimation (PCA covariance plane fitting)
- RANSAC Plane & Cylinder Extraction
"""

import numpy as np
import numpy.typing as npt
from ..geometry.canonical import PointCloud


def voxel_downsample(pcd: PointCloud, voxel_size_m: float) -> PointCloud:
    """Downsample point cloud using regular 3D voxel grid centroids."""
    if pcd.count == 0 or voxel_size_m <= 0:
        return pcd

    coords = np.floor(pcd.points / voxel_size_m).astype(np.int64)
    unique_voxels, indices = np.unique(coords, axis=0, return_inverse=True)

    downsampled_points = np.zeros((len(unique_voxels), 3), dtype=np.float64)
    np.add.at(downsampled_points, indices, pcd.points)
    counts = np.bincount(indices)[:, np.newaxis]
    downsampled_points /= counts

    new_pcd = PointCloud(
        version=pcd.version + 1,
        points=downsampled_points,
        units=pcd.units,
        frame=pcd.frame,
        provenance={
            "parent_id": pcd.id,
            "operation": "VOXEL_DOWNSAMPLE",
            "voxel_size_m": str(voxel_size_m),
            "original_points": str(pcd.count),
            "reduced_points": str(len(downsampled_points)),
        },
    )
    return new_pcd


def statistical_outlier_removal(pcd: PointCloud, nb_neighbors: int = 20, std_ratio: float = 2.0) -> PointCloud:
    """Filter noise points whose average distance to k nearest neighbours exceeds mean + std_ratio * std."""
    from scipy.spatial import KDTree

    if pcd.count < nb_neighbors:
        return pcd

    tree = KDTree(pcd.points)
    distances, _ = tree.query(pcd.points, k=nb_neighbors + 1)
    # Exclude distance to self (column 0)
    mean_dists = np.mean(distances[:, 1:], axis=1)

    global_mean = np.mean(mean_dists)
    global_std = np.std(mean_dists)
    threshold = global_mean + std_ratio * global_std

    inlier_mask = mean_dists <= threshold
    filtered_points = pcd.points[inlier_mask]

    return PointCloud(
        version=pcd.version + 1,
        points=filtered_points,
        units=pcd.units,
        frame=pcd.frame,
        provenance={
            "parent_id": pcd.id,
            "operation": "STATISTICAL_OUTLIER_REMOVAL",
            "inlier_count": str(len(filtered_points)),
            "outlier_count": str(pcd.count - len(filtered_points)),
        },
    )


def estimate_normals(pcd: PointCloud, k_neighbors: int = 15) -> PointCloud:
    """Estimate surface normal vectors using local PCA covariance decomposition."""
    from scipy.spatial import KDTree

    if pcd.count < 3:
        return pcd

    tree = KDTree(pcd.points)
    _, idxs = tree.query(pcd.points, k=min(k_neighbors, pcd.count))

    normals = np.zeros((pcd.count, 3), dtype=np.float64)
    for i in range(pcd.count):
        neighbor_pts = pcd.points[idxs[i]]
        centered = neighbor_pts - np.mean(neighbor_pts, axis=0)
        cov = np.dot(centered.T, centered)
        evals, evecs = np.linalg.eigh(cov)
        normal = evecs[:, 0]  # eigenvector with smallest eigenvalue

        # Orient towards sensor / center
        if np.dot(normal, pcd.points[i]) < 0:
            normal = -normal
        normals[i] = normal

    new_pcd = PointCloud(
        version=pcd.version + 1,
        points=pcd.points.copy(),
        normals=normals,
        units=pcd.units,
        frame=pcd.frame,
        provenance={"parent_id": pcd.id, "operation": "ESTIMATE_NORMALS"},
    )
    return new_pcd
