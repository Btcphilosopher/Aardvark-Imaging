//! Aardvark High-Performance Computational Geometry Kernel
//! Provides parallelized ray casting, polygon offsetting, mesh manifold verification, and accelerated slicing.

pub mod boolean;
pub mod collision;
pub mod geometry;
pub mod mesh;
pub mod numerics;
pub mod polygon;
pub mod slicing;
pub mod spatial;
pub mod toolpath;
pub mod voxel;

pub use geometry::{Point3D, Triangle3D, Vector3D};
pub use mesh::RawMesh;
pub use slicing::{slice_mesh_parallel, LayerPolygon};
