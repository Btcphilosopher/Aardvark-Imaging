//! Numerics, Collision, Polygon Offsetting, Toolpath and Voxel modules

pub mod collision {
    // Continuous collision detection for multi-axis additive manufacturing
}

pub mod numerics {
    pub const EPSILON: f64 = 1e-9;
}

pub mod polygon {
    // Robust 2D polygon clipping, offsetting, and winding checks
}

pub mod toolpath {
    // Machine independent kinematics and extrusion planner
}

pub mod voxel {
    // Dense/Sparse Voxel Grid representation and Signed Distance Fields (SDF)
}
