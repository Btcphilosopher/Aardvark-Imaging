//! Boolean operations kernel interface (CSG Union, Difference, Intersection)
