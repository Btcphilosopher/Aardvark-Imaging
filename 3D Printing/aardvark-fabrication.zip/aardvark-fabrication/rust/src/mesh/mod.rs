use crate::geometry::{Point3D, Triangle3D};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RawMesh {
    pub vertices: Vec<Point3D>,
    pub indices: Vec<[u32; 3]>,
}

impl RawMesh {
    pub fn new(vertices: Vec<Point3D>, indices: Vec<[u32; 3]>) -> Self {
        Self { vertices, indices }
    }

    pub fn triangle_count(&self) -> usize {
        self.indices.len()
    }

    pub fn to_triangles(&self) -> Vec<Triangle3D> {
        self.indices
            .iter()
            .map(|f| Triangle3D {
                v0: self.vertices[f[0] as usize],
                v1: self.vertices[f[1] as usize],
                v2: self.vertices[f[2] as usize],
            })
            .collect()
    }
}
