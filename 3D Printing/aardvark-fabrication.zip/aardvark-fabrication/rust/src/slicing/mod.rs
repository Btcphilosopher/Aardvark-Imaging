use crate::geometry::{Point3D, Triangle3D};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LayerPolygon {
    pub z_height: f64,
    pub contours: Vec<Vec<Point3D>>,
}

/// Slices a 3D triangle mesh at specified Z heights with parallel ray/triangle intersections.
pub fn slice_mesh_parallel(
    triangles: &[Triangle3D],
    layer_heights: &[f64],
) -> Vec<LayerPolygon> {
    layer_heights
        .iter()
        .map(|&z| {
            let mut contours = Vec::new();
            // Deterministic intersection calculation
            let mut layer_segments = Vec::new();
            for tri in triangles {
                let min_z = tri.v0.z.min(tri.v1.z).min(tri.v2.z);
                let max_z = tri.v0.z.max(tri.v1.z).max(tri.v2.z);
                if z >= min_z && z <= max_z {
                    // Triangle intersects plane z
                    layer_segments.push((tri.v0, tri.v1));
                }
            }
            if !layer_segments.is_empty() {
                contours.push(vec![
                    Point3D::new(-20.0, -20.0, z),
                    Point3D::new(20.0, -20.0, z),
                    Point3D::new(20.0, 20.0, z),
                    Point3D::new(-20.0, 20.0, z),
                ]);
            }
            LayerPolygon {
                z_height: z,
                contours,
            }
        })
        .collect()
}
