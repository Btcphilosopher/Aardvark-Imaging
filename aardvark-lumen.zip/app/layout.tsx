import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'AARDVARK LUMEN',
  description: 'Python-native programmable multicolour lighting, animation & code-controlled illumination engine with 3D volumetric rendering, DMX mapping, procedural fields, and telemetry integration.',
  openGraph: {
    title: 'AARDVARK LUMEN',
    description: 'Python-native programmable multicolour lighting, animation & code-controlled illumination engine with 3D volumetric rendering, DMX mapping, procedural fields, and telemetry integration.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'AARDVARK LUMEN',
    description: 'Python-native programmable multicolour lighting, animation & code-controlled illumination engine with 3D volumetric rendering, DMX mapping, procedural fields, and telemetry integration.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
