'use client';

import React, { useState, useEffect, useRef } from 'react';
import {
  LumenScene,
  LightMatrix,
  LumenLight
} from '@/lib/aardvark_lumen/scene-engine';
import { LumenColor } from '@/lib/aardvark_lumen/color-engine';
import { ParticleLightingSystem } from '@/lib/aardvark_lumen/procedural-engine';
import { AudioAnalyzer, AudioFeatures } from '@/lib/aardvark_lumen/audio-engine';
import { SimulationEngine } from '@/lib/aardvark_lumen/simulation-engine';
import { DMXController } from '@/lib/aardvark_lumen/dmx-engine';
import { NodeGraphEngine } from '@/lib/aardvark_lumen/node-graph-engine';
import { PythonRuntime, PYTHON_PRESETS, PythonPresetScript } from '@/lib/aardvark_lumen/python-runtime';

import { Stage3DViewport } from '@/components/aardvark_lumen/Stage3DViewport';
import { Matrix2DView } from '@/components/aardvark_lumen/Matrix2DView';
import { CodeWorkspace } from '@/components/aardvark_lumen/CodeWorkspace';
import { DmxInspector } from '@/components/aardvark_lumen/DmxInspector';
import { NodeGraphView } from '@/components/aardvark_lumen/NodeGraphView';
import { AudioTelemetryPanel } from '@/components/aardvark_lumen/AudioTelemetryPanel';
import { ColorLabPanel } from '@/components/aardvark_lumen/ColorLabPanel';
import { PythonPackageViewer } from '@/components/aardvark_lumen/PythonPackageViewer';
import { ShowTimelineController } from '@/components/aardvark_lumen/ShowTimelineController';

import {
  Box,
  Grid,
  Share2,
  Radio,
  Music,
  Palette,
  Layers,
  PowerOff,
  Zap,
  Sparkles,
  Cpu,
  Eye,
  Sliders
} from 'lucide-react';

export default function LumenApp() {
  // Core Engine Instances (stable singletons via useMemo)
  const scene = React.useMemo(() => new LumenScene('Aardvark Main Stage'), []);
  const particleSystem = React.useMemo(() => new ParticleLightingSystem(32), []);
  const audioAnalyzer = React.useMemo(() => new AudioAnalyzer(), []);
  const simEngine = React.useMemo(() => new SimulationEngine(), []);
  const dmxController = React.useMemo(() => new DMXController(4), []);
  const graphEngine = React.useMemo(() => new NodeGraphEngine(), []);
  const pythonRuntime = React.useMemo(() => new PythonRuntime(), []);

  // Active View Tab
  const [activeTab, setActiveTab] = useState<
    'stage3d' | 'matrix2d' | 'graph' | 'dmx' | 'audio_telemetry' | 'color_lab' | 'python_package'
  >('stage3d');

  // Compute initial compilation result
  const initialResult = React.useMemo(() => {
    return pythonRuntime.compileAndRun(
      PYTHON_PRESETS[0].code,
      scene,
      audioAnalyzer.currentFeatures,
      simEngine.data
    );
  }, [audioAnalyzer, pythonRuntime, scene, simEngine]);

  // Python Code Editor State
  const [pythonCode, setPythonCode] = useState<string>(PYTHON_PRESETS[0].code);
  const [logs, setLogs] = useState<string[]>(() => initialResult.logs);
  const [execError, setExecError] = useState<string | undefined>(() => initialResult.error);
  const [execTimeMs, setExecTimeMs] = useState<number>(() => initialResult.executionTimeMs);

  // Viewport Settings
  const [showVolumetric, setShowVolumetric] = useState(true);
  const [showTrussGrid, setShowTrussGrid] = useState(true);
  const [selectedLightId, setSelectedLightId] = useState<string | null>(null);

  // Dynamic Tick Trigger for UI updates
  const [, setTickCount] = useState(0);
  const [audioFeaturesState, setAudioFeaturesState] = useState<AudioFeatures>(audioAnalyzer.currentFeatures);

  const runPythonScript = React.useCallback((codeToRun: string) => {
    const audioF = audioAnalyzer.currentFeatures;
    const telem = simEngine.data;
    const res = pythonRuntime.compileAndRun(codeToRun, scene, audioF, telem);
    setLogs(res.logs);
    setExecError(res.error);
    setExecTimeMs(res.executionTimeMs);
  }, [audioAnalyzer, simEngine, pythonRuntime, scene]);

  // 2. Master Animation & Real-Time Sync Loop (60 FPS)
  useEffect(() => {
    let animId: number;
    let lastTime = performance.now();

    const loop = () => {
      animId = requestAnimationFrame(loop);
      const now = performance.now();
      const dt = Math.min(0.1, (now - lastTime) / 1000.0);
      lastTime = now;

      // Update Audio & Telemetry
      const audioF = audioAnalyzer.update(dt);
      const telem = simEngine.update(dt);

      // Advance Clock & Scene
      const t = scene.update();

      // Evaluate Python DSL frame hook
      pythonRuntime.evaluateFrame(t, scene, audioF, telem);

      // Evaluate Node Graph
      graphEngine.evaluate(t, scene, audioF, telem);

      // Update Particle physics
      particleSystem.update(dt, 'fireflies');

      // Update DMX Channels & Art-Net Packet Stream
      dmxController.updateFromScene(scene);

      // Throttle UI re-renders to every 2 frames for silky smooth performance
      if (Math.round(t * 60) % 2 === 0) {
        setTickCount(prev => prev + 1);
        setAudioFeaturesState(audioF);
      }
    };

    loop();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [scene, particleSystem, audioAnalyzer, simEngine, dmxController, graphEngine, pythonRuntime]);

  // Preset switch handler
  const handleSelectPreset = (preset: PythonPresetScript) => {
    setPythonCode(preset.code);
    runPythonScript(preset.code);

    // Auto-switch to matching visualizer for best demonstration
    if (preset.id === 'slice_2_matrix_field') {
      setActiveTab('matrix2d');
    } else if (preset.id === 'slice_3_audio_reactive' || preset.id === 'slice_6_telemetry_rocket') {
      setActiveTab('audio_telemetry');
    } else if (preset.id === 'slice_4_dmx_multiverse') {
      setActiveTab('dmx');
    } else {
      setActiveTab('stage3d');
    }
  };

  const handleBlackoutToggle = () => {
    if (scene.isBlackout) {
      scene.restore();
      dmxController.restore();
    } else {
      scene.blackout();
      dmxController.blackout();
    }
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-[#090b0e] text-zinc-100 select-none overflow-hidden font-sans">
      {/* 1. Header Navigation Bar */}
      <header className="h-13 bg-[#11151d] border-b border-zinc-800 px-4 flex items-center justify-between z-30 shadow-lg">
        {/* Brand & Product Identity */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-500 via-amber-600 to-yellow-600 flex items-center justify-center shadow-lg shadow-amber-500/20">
            <Zap className="w-5 h-5 text-zinc-950 stroke-[2.5]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-mono text-sm font-extrabold tracking-wider text-white">
                AARDVARK LUMEN
              </h1>
              <span className="text-[10px] font-mono bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded border border-amber-500/40">
                v1.0.0 PYTHON-NATIVE
              </span>
            </div>
            <p className="text-[10px] font-mono text-zinc-400 tracking-tight">
              PROGRAMMABLE COMPUTATIONAL LIGHTING & ILLUMINATION MEDIUM
            </p>
          </div>
        </div>

        {/* Mode Navigation Tabs */}
        <div className="flex items-center bg-zinc-900/90 p-1 rounded-lg border border-zinc-800 text-xs">
          <button
            id="tab-stage3d"
            onClick={() => setActiveTab('stage3d')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-mono text-xs transition-all ${
              activeTab === 'stage3d'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Box className="w-3.5 h-3.5" />
            <span>3D Stage Rig</span>
          </button>

          <button
            id="tab-matrix2d"
            onClick={() => setActiveTab('matrix2d')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-mono text-xs transition-all ${
              activeTab === 'matrix2d'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Grid className="w-3.5 h-3.5" />
            <span>20×20 Matrix</span>
          </button>

          <button
            id="tab-graph"
            onClick={() => setActiveTab('graph')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-mono text-xs transition-all ${
              activeTab === 'graph'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>Node Graph</span>
          </button>

          <button
            id="tab-dmx"
            onClick={() => setActiveTab('dmx')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-mono text-xs transition-all ${
              activeTab === 'dmx'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Radio className="w-3.5 h-3.5" />
            <span>DMX / Art-Net</span>
          </button>

          <button
            id="tab-audio-telemetry"
            onClick={() => setActiveTab('audio_telemetry')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-mono text-xs transition-all ${
              activeTab === 'audio_telemetry'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Music className="w-3.5 h-3.5" />
            <span>Audio & Telemetry</span>
          </button>

          <button
            id="tab-color-lab"
            onClick={() => setActiveTab('color_lab')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-mono text-xs transition-all ${
              activeTab === 'color_lab'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>Color Science</span>
          </button>

          <button
            id="tab-python-package"
            onClick={() => setActiveTab('python_package')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-mono text-xs transition-all ${
              activeTab === 'python_package'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Python Source</span>
          </button>
        </div>

        {/* Global Controls */}
        <div className="flex items-center gap-2.5">
          <button
            id="btn-toggle-volumetric"
            onClick={() => setShowVolumetric(!showVolumetric)}
            className={`text-xs font-mono px-2.5 py-1 rounded border transition-colors ${
              showVolumetric
                ? 'bg-zinc-800 text-amber-300 border-amber-500/40'
                : 'bg-zinc-900 text-zinc-500 border-zinc-800'
            }`}
          >
            Volumetric: {showVolumetric ? 'ON' : 'OFF'}
          </button>

          {/* Emergency Blackout Button */}
          <button
            id="btn-global-blackout"
            onClick={handleBlackoutToggle}
            className={`flex items-center gap-1.5 text-xs font-mono font-bold px-3 py-1 rounded-md shadow-md transition-all active:scale-95 ${
              scene.isBlackout
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white animate-pulse'
                : 'bg-red-600/90 hover:bg-red-500 text-white'
            }`}
          >
            <PowerOff className="w-3.5 h-3.5" />
            <span>{scene.isBlackout ? 'RESTORE RIG' : 'BLACKOUT'}</span>
          </button>
        </div>
      </header>

      {/* 2. Main Workstation Body: Split Dual Viewport */}
      <main className="flex-1 flex overflow-hidden p-3 gap-3">
        {/* Left Side: Active Visualizer / Inspector */}
        <div className="flex-1 h-full min-w-0 flex flex-col">
          {activeTab === 'stage3d' && (
            <Stage3DViewport
              scene={scene}
              particleSystem={particleSystem}
              selectedLightId={selectedLightId}
              onSelectLight={setSelectedLightId}
              showVolumetric={showVolumetric}
              showTrussGrid={showTrussGrid}
            />
          )}

          {activeTab === 'matrix2d' && (
            <Matrix2DView matrix={scene.matrix} />
          )}

          {activeTab === 'graph' && (
            <NodeGraphView
              graphEngine={graphEngine}
              onResetGraph={() => graphEngine.createDefaultGraph()}
            />
          )}

          {activeTab === 'dmx' && (
            <DmxInspector
              dmxController={dmxController}
              scene={scene}
              onBlackout={() => {
                scene.blackout();
                dmxController.blackout();
              }}
              onRestore={() => {
                scene.restore();
                dmxController.restore();
              }}
            />
          )}

          {activeTab === 'audio_telemetry' && (
            <AudioTelemetryPanel
              audioAnalyzer={audioAnalyzer}
              audioFeatures={audioFeaturesState}
              telemetry={simEngine.data}
              onToggleMic={async () => {
                if (audioAnalyzer.isUsingMicrophone()) {
                  audioAnalyzer.stopMicrophone();
                } else {
                  await audioAnalyzer.startMicrophone();
                }
              }}
              onSetTrackType={(track) => audioAnalyzer.setTrackType(track)}
            />
          )}

          {activeTab === 'color_lab' && (
            <ColorLabPanel
              onApplyColorToScene={(color) => {
                for (const l of scene.getAllLights()) {
                  l.color = color.clone();
                }
              }}
            />
          )}

          {activeTab === 'python_package' && (
            <PythonPackageViewer />
          )}
        </div>

        {/* Right Side: Live Python Code Workspace & AST Evaluator */}
        <div className="w-[45%] h-full min-w-[380px] max-w-[620px] flex flex-col">
          <CodeWorkspace
            code={pythonCode}
            onChangeCode={setPythonCode}
            onExecute={() => runPythonScript(pythonCode)}
            logs={logs}
            executionError={execError}
            executionTimeMs={execTimeMs}
            onSelectPreset={handleSelectPreset}
          />
        </div>
      </main>

      {/* 3. Bottom Show Timeline & Hardware Telemetry Controller */}
      <footer className="h-16 flex-shrink-0">
        <ShowTimelineController
          clock={scene.clock}
          scene={scene}
          onPlay={() => scene.clock.play()}
          onPause={() => scene.clock.pause()}
          onReset={() => scene.clock.reset()}
          onSeek={(t) => scene.clock.seek(t)}
          onSpeedChange={(speed) => scene.clock.setTimeScale(speed)}
        />
      </footer>
    </div>
  );
}
