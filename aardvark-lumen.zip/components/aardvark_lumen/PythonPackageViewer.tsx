'use client';

import React, { useState } from 'react';
import { AARDVARK_LUMEN_PYTHON_CODEBASE, PythonSourceFile } from '@/lib/aardvark_lumen/python-package-source';
import { Folder, FileCode, Copy, Check, Download, Layers } from 'lucide-react';

export const PythonPackageViewer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<PythonSourceFile>(AARDVARK_LUMEN_PYTHON_CODEBASE[0]);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadFile = () => {
    const blob = new Blob([selectedFile.content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = selectedFile.path.split('/').pop() || 'module.py';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="w-full h-full bg-[#0d1015] rounded-xl border border-zinc-800 p-4 flex flex-col justify-between shadow-2xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-amber-400" />
          <h3 className="text-xs font-mono font-semibold tracking-wider text-zinc-200">
            AARDVARK-LUMEN NATIVE PYTHON 3.13+ PACKAGE FILES
          </h3>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="btn-copy-py-file"
            onClick={handleCopy}
            className="flex items-center gap-1 text-xs text-zinc-300 hover:text-white bg-zinc-900 border border-zinc-700/80 px-2.5 py-1 rounded transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy File'}</span>
          </button>
          <button
            id="btn-dl-py-file"
            onClick={handleDownloadFile}
            className="flex items-center gap-1 text-xs text-zinc-300 hover:text-white bg-zinc-900 border border-zinc-700/80 px-2.5 py-1 rounded transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download</span>
          </button>
        </div>
      </div>

      {/* Main Split: File Tree Sidebar & Code Viewer */}
      <div className="flex-1 my-3 flex gap-3 overflow-hidden">
        {/* Left File Tree */}
        <div className="w-64 bg-zinc-950/80 rounded-lg border border-zinc-800/80 p-2 overflow-auto font-mono text-xs space-y-1">
          <div className="text-[10px] text-zinc-500 font-semibold px-2 py-1 uppercase tracking-wider">
            Package Tree
          </div>
          {AARDVARK_LUMEN_PYTHON_CODEBASE.map((f) => {
            const isSelected = selectedFile.path === f.path;
            return (
              <button
                key={f.path}
                onClick={() => setSelectedFile(f)}
                className={`w-full text-left px-2 py-1.5 rounded flex items-center gap-2 transition-colors ${
                  isSelected
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
                }`}
              >
                <FileCode className="w-3.5 h-3.5 flex-shrink-0" />
                <span className="truncate">{f.path}</span>
              </button>
            );
          })}
        </div>

        {/* Right Code Viewer */}
        <div className="flex-1 bg-zinc-950 rounded-lg border border-zinc-800/80 p-3 overflow-auto font-mono text-xs text-zinc-300 leading-relaxed">
          <div className="pb-2 mb-2 border-b border-zinc-800 text-[11px] text-amber-400 font-bold flex items-center justify-between">
            <span>{selectedFile.path}</span>
            <span className="text-zinc-500 font-normal">Category: {selectedFile.category}</span>
          </div>
          <pre className="whitespace-pre overflow-x-auto text-[11px]">
            {selectedFile.content}
          </pre>
        </div>
      </div>

      {/* Footer Note */}
      <div className="pt-2 border-t border-zinc-800 flex items-center justify-between text-xs font-mono text-zinc-500">
        <span>PyPI Package Architecture Specification: Section 81 Standard</span>
        <span className="text-amber-400/80">NumPy &bull; SciPy &bull; PySide6 &bull; Pydantic</span>
      </div>
    </div>
  );
};
