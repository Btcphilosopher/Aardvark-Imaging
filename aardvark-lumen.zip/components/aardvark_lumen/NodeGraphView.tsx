'use client';

import React from 'react';
import { NodeGraphEngine } from '@/lib/aardvark_lumen/node-graph-engine';
import { Share2, Clock, Volume2, Activity, Cpu, Sparkles } from 'lucide-react';
import { LumenColor } from '@/lib/aardvark_lumen/color-engine';

interface NodeGraphViewProps {
  graphEngine: NodeGraphEngine;
  onResetGraph: () => void;
}

export const NodeGraphView: React.FC<NodeGraphViewProps> = ({ graphEngine, onResetGraph }) => {
  return (
    <div className="w-full h-full bg-[#0a0c10] rounded-xl border border-zinc-800 p-4 flex flex-col justify-between shadow-2xl relative overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
        <div className="flex items-center gap-2">
          <Share2 className="w-4 h-4 text-amber-400" />
          <h3 className="text-xs font-mono font-semibold tracking-wider text-zinc-200">
            COMPUTATIONAL LIGHTING NODE GRAPH
          </h3>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono text-zinc-500">
            TIME / AUDIO / SIM &rarr; SINE / NOISE &rarr; MAP / PALETTE &rarr; ILLUMINATION
          </span>
          <button
            onClick={onResetGraph}
            className="text-xs font-mono text-zinc-400 hover:text-zinc-200 px-2.5 py-1 bg-zinc-900 border border-zinc-800 rounded hover:bg-zinc-800 transition-colors"
          >
            Reset Default Graph
          </button>
        </div>
      </div>

      {/* Node Canvas Area */}
      <div className="flex-1 relative my-3 bg-zinc-950/90 rounded-lg border border-zinc-800/80 p-4 overflow-auto min-h-[300px]">
        {/* Render Connection Lines (SVG) */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none">
          {graphEngine.connections.map((conn) => {
            const fromNode = graphEngine.nodes.find(n => n.id === conn.fromNodeId);
            const toNode = graphEngine.nodes.find(n => n.id === conn.toNodeId);
            if (!fromNode || !toNode) return null;

            const x1 = fromNode.x + 180;
            const y1 = fromNode.y + 40;
            const x2 = toNode.x;
            const y2 = toNode.y + 40;
            const cx1 = x1 + (x2 - x1) * 0.5;
            const cx2 = x2 - (x2 - x1) * 0.5;

            return (
              <path
                key={conn.id}
                d={`M ${x1} ${y1} C ${cx1} ${y1}, ${cx2} ${y2}, ${x2} ${y2}`}
                fill="none"
                stroke="#f59e0b"
                strokeWidth="2"
                strokeDasharray="4,4"
                className="animate-[dash_1.5s_linear_infinite]"
              />
            );
          })}
        </svg>

        {/* Render Graph Nodes */}
        {graphEngine.nodes.map((node) => {
          const isGenerator = node.type === 'TIME' || node.type.startsWith('AUDIO') || node.type === 'TELEMETRY';
          const isOutput = node.type === 'LIGHT_OUTPUT';

          return (
            <div
              key={node.id}
              id={`node-${node.id}`}
              className="absolute w-44 bg-[#141820] rounded-lg border border-zinc-700/80 shadow-xl text-xs overflow-hidden"
              style={{ left: `${node.x}px`, top: `${node.y}px` }}
            >
              {/* Node Title Bar */}
              <div className={`px-2.5 py-1.5 flex items-center justify-between border-b ${
                isGenerator
                  ? 'bg-blue-950/40 border-blue-800/50 text-blue-300'
                  : isOutput
                  ? 'bg-emerald-950/40 border-emerald-800/50 text-emerald-300'
                  : 'bg-amber-950/40 border-amber-800/50 text-amber-300'
              }`}>
                <span className="font-mono font-bold text-[11px] truncate">{node.title}</span>
                <span className="text-[9px] font-mono opacity-60">#{node.type}</span>
              </div>

              {/* Node Body / Value Display */}
              <div className="p-2.5 space-y-1.5 font-mono text-[11px] text-zinc-300">
                {Object.entries(node.outputs).map(([k, v]) => (
                  <div key={k} className="flex items-center justify-between text-zinc-400">
                    <span className="text-[10px] text-zinc-500">out: {k}</span>
                    <span className="text-amber-400 font-semibold truncate max-w-[80px]">
                      {v instanceof LumenColor
                        ? v.to_hex()
                        : typeof v === 'number'
                        ? v.toFixed(2)
                        : String(v)}
                    </span>
                  </div>
                ))}

                {Object.entries(node.inputs).map(([k, v]) => (
                  <div key={k} className="flex items-center justify-between text-zinc-400">
                    <span className="text-[10px] text-zinc-500">in: {k}</span>
                    <span className="text-cyan-400 font-semibold truncate max-w-[80px]">
                      {v instanceof LumenColor
                        ? v.to_hex()
                        : typeof v === 'number'
                        ? v.toFixed(2)
                        : String(v)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer Info */}
      <div className="pt-2 border-t border-zinc-800 flex items-center justify-between text-xs font-mono text-zinc-500">
        <span>Nodes evaluated per tick in real-time execution flow</span>
        <span className="text-amber-400/80">60 Hz Graph Refresh</span>
      </div>
    </div>
  );
};
