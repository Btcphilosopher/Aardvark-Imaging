'use client';

import React, { useState } from 'react';
import { LumenColor, LUMEN_PALETTES, PaletteItem } from '@/lib/aardvark_lumen/color-engine';
import { Palette, Sun, Flame, Sparkles, Copy, Check } from 'lucide-react';

interface ColorLabPanelProps {
  onApplyColorToScene?: (color: LumenColor) => void;
}

export const ColorLabPanel: React.FC<ColorLabPanelProps> = ({ onApplyColorToScene }) => {
  const [kelvin, setKelvin] = useState(3200);
  const [wavelength, setWavelength] = useState(555); // Peak human photopic eye sensitivity 555nm green
  const [selectedPalette, setSelectedPalette] = useState<string>('ANGLO_FUTURIST');
  const [copiedHex, setCopiedHex] = useState<string | null>(null);

  const kelvinColor = LumenColor.from_kelvin(kelvin);
  const wavelengthColor = LumenColor.from_wavelength(wavelength);

  const activePalette = LUMEN_PALETTES[selectedPalette] || LUMEN_PALETTES.ANGLO_FUTURIST;

  const handleCopyHex = (hex: string) => {
    navigator.clipboard.writeText(hex);
    setCopiedHex(hex);
    setTimeout(() => setCopiedHex(null), 1500);
  };

  return (
    <div className="w-full h-full bg-[#0d1015] rounded-xl border border-zinc-800 p-4 flex flex-col justify-between shadow-2xl overflow-auto gap-4">
      {/* 1. Correlated Colour Temperature (CCT) & Kelvin Blackbody Section */}
      <div className="bg-zinc-950/80 rounded-lg p-3 border border-zinc-800/80">
        <div className="flex items-center justify-between pb-2 mb-2 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <Sun className="w-4 h-4 text-amber-400" />
            <h4 className="text-xs font-mono font-semibold text-zinc-200">
              CORRELATED COLOUR TEMPERATURE (PLANCKIAN CCT)
            </h4>
          </div>
          <span className="text-xs font-mono text-amber-300 font-bold bg-amber-950/40 px-2 py-0.5 rounded border border-amber-800/50">
            {kelvin} K ({kelvin <= 2000 ? 'Candle Flame' : kelvin <= 3200 ? 'Warm Tungsten' : kelvin <= 5600 ? 'Daylight Sun' : 'Sky Blue'})
          </span>
        </div>

        <div className="flex items-center gap-3">
          <input
            id="slider-kelvin"
            type="range"
            min={1200}
            max={12000}
            step={100}
            value={kelvin}
            onChange={(e) => setKelvin(Number(e.target.value))}
            aria-label="Correlated Colour Temperature Kelvin"
            className="flex-1 accent-amber-500 cursor-pointer h-2 bg-zinc-800 rounded-lg"
          />
          {/* Swatch */}
          <div
            className="w-12 h-8 rounded-md border border-zinc-700 shadow-md flex items-center justify-center cursor-pointer hover:scale-105 transition-transform"
            style={{ backgroundColor: kelvinColor.to_hex() }}
            onClick={() => onApplyColorToScene && onApplyColorToScene(kelvinColor)}
            title="Click to apply to scene lights"
          >
            <span className="text-[9px] font-mono text-zinc-900 bg-white/80 px-1 rounded font-bold">
              {kelvinColor.to_hex()}
            </span>
          </div>
        </div>

        <div className="flex justify-between text-[10px] font-mono text-zinc-500 mt-1.5">
          <span>1200K (Candle)</span>
          <span>2700K (Tungsten)</span>
          <span>4000K (Neutral)</span>
          <span>5600K (Daylight)</span>
          <span>12000K (Deep Sky)</span>
        </div>
      </div>

      {/* 2. Physical Wavelength Nano-Spectrometry (380nm - 780nm) */}
      <div className="bg-zinc-950/80 rounded-lg p-3 border border-zinc-800/80">
        <div className="flex items-center justify-between pb-2 mb-2 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <Flame className="w-4 h-4 text-cyan-400" />
            <h4 className="text-xs font-mono font-semibold text-zinc-200">
              PHYSICAL WAVELENGTH SPECTROMETRY
            </h4>
          </div>
          <span className="text-xs font-mono text-cyan-300 font-bold bg-cyan-950/40 px-2 py-0.5 rounded border border-cyan-800/50">
            {wavelength} nm ({wavelength < 450 ? 'Violet' : wavelength < 490 ? 'Blue' : wavelength < 560 ? 'Green' : wavelength < 600 ? 'Yellow' : 'Red'})
          </span>
        </div>

        <div className="flex items-center gap-3">
          <input
            id="slider-wavelength"
            type="range"
            min={380}
            max={780}
            step={1}
            value={wavelength}
            onChange={(e) => setWavelength(Number(e.target.value))}
            aria-label="Physical Wavelength in Nanometers"
            className="flex-1 accent-cyan-500 cursor-pointer h-2 bg-gradient-to-r from-purple-600 via-green-500 to-red-600 rounded-lg"
          />
          {/* Swatch */}
          <div
            className="w-12 h-8 rounded-md border border-zinc-700 shadow-md flex items-center justify-center cursor-pointer hover:scale-105 transition-transform"
            style={{ backgroundColor: wavelengthColor.to_hex() }}
            onClick={() => onApplyColorToScene && onApplyColorToScene(wavelengthColor)}
            title="Click to apply to scene lights"
          >
            <span className="text-[9px] font-mono text-zinc-900 bg-white/80 px-1 rounded font-bold">
              {wavelengthColor.to_hex()}
            </span>
          </div>
        </div>
      </div>

      {/* 3. Curated Lighting Palettes & Anglo-Futurist Archetype */}
      <div className="bg-zinc-950/80 rounded-lg p-3 border border-zinc-800/80">
        <div className="flex items-center justify-between pb-2 mb-2 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <Palette className="w-4 h-4 text-amber-400" />
            <h4 className="text-xs font-mono font-semibold text-zinc-200">
              LIGHTING PALETTE LIBRARY
            </h4>
          </div>

          <select
            value={selectedPalette}
            onChange={(e) => setSelectedPalette(e.target.value)}
            aria-label="Select Palette Preset"
            className="bg-zinc-900 border border-zinc-750 text-zinc-200 text-xs px-2 py-0.5 rounded font-mono"
          >
            {Object.values(LUMEN_PALETTES).map((p) => (
              <option key={p.id} value={p.id}>
                {p.name} ({p.category})
              </option>
            ))}
          </select>
        </div>

        <p className="text-[11px] text-zinc-400 mb-2">
          {activePalette.description}
        </p>

        {/* Palette Swatches Bar */}
        <div className="flex items-center gap-2">
          {activePalette.colors.map((c, i) => {
            const hex = c.to_hex();
            return (
              <div
                key={i}
                onClick={() => {
                  handleCopyHex(hex);
                  if (onApplyColorToScene) onApplyColorToScene(c);
                }}
                className="flex-1 h-10 rounded-md border border-zinc-700 shadow-sm flex items-center justify-center cursor-pointer hover:scale-105 transition-transform relative group"
                style={{ backgroundColor: hex }}
                title={`Click to copy: ${hex}`}
              >
                <span className="text-[9px] font-mono text-zinc-900 bg-white/90 px-1 rounded font-bold opacity-0 group-hover:opacity-100 transition-opacity">
                  {copiedHex === hex ? 'Copied' : hex}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
