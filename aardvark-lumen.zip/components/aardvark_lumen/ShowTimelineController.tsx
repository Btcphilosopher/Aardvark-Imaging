'use client';

import React from 'react';
import { Play, Pause, RotateCcw, FastForward, Clock, Zap, Layers, Volume2, Shield } from 'lucide-react';
import { LumenClock, LumenScene } from '@/lib/aardvark_lumen/scene-engine';

interface ShowTimelineControllerProps {
  clock: LumenClock;
  scene: LumenScene;
  onPlay: () => void;
  onPause: () => void;
  onReset: () => void;
  onSeek: (time: number) => void;
  onSpeedChange: (speed: number) => void;
}

export const ShowTimelineController: React.FC<ShowTimelineControllerProps> = ({
  clock,
  scene,
  onPlay,
  onPause,
  onReset,
  onSeek,
  onSpeedChange,
}) => {
  // Format seconds to SMPTE timecode (HH:MM:SS:FF)
  const formatSMPTE = (seconds: number) => {
    const totalFrames = Math.floor(seconds * 30);
    const ff = (totalFrames % 30).toString().padStart(2, '0');
    const totalSecs = Math.floor(seconds);
    const ss = (totalSecs % 60).toString().padStart(2, '0');
    const mm = (Math.floor(totalSecs / 60) % 60).toString().padStart(2, '0');
    const hh = Math.floor(totalSecs / 3600).toString().padStart(2, '0');
    return `${hh}:${mm}:${ss}:${ff}`;
  };

  return (
    <div className="w-full bg-[#12161f] border-t border-zinc-800 px-4 py-2.5 flex flex-col gap-2 shadow-2xl">
      {/* Upper Timeline Row */}
      <div className="flex items-center justify-between gap-4">
        {/* Playback Transport Buttons */}
        <div className="flex items-center gap-2">
          {clock.isRunning ? (
            <button
              id="btn-pause-timeline"
              onClick={onPause}
              className="w-8 h-8 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-amber-400 flex items-center justify-center transition-all shadow-md active:scale-95"
              title="Pause Timeline (Space)"
            >
              <Pause className="w-4 h-4 fill-current" />
            </button>
          ) : (
            <button
              id="btn-play-timeline"
              onClick={onPlay}
              className="w-8 h-8 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 flex items-center justify-center transition-all shadow-md active:scale-95 font-bold"
              title="Play Timeline (Space)"
            >
              <Play className="w-4 h-4 fill-current" />
            </button>
          )}

          <button
            id="btn-reset-timeline"
            onClick={onReset}
            className="w-8 h-8 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200 border border-zinc-800 flex items-center justify-center transition-all"
            title="Rewind to 00:00:00:00"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          {/* Timecode Readout */}
          <div className="bg-zinc-950 px-3 py-1 rounded-md border border-zinc-800/90 font-mono text-xs text-amber-400 font-bold tracking-widest shadow-inner">
            {formatSMPTE(clock.time)}
          </div>

          {/* Speed Multiplier */}
          <div className="flex items-center bg-zinc-900 rounded-md border border-zinc-800 p-0.5 text-[11px] font-mono">
            {[0.5, 1.0, 2.0].map((s) => (
              <button
                key={s}
                onClick={() => onSpeedChange(s)}
                className={`px-2 py-0.5 rounded transition-colors ${
                  clock.timeScale === s
                    ? 'bg-amber-500/20 text-amber-300 font-bold'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {s}x
              </button>
            ))}
          </div>
        </div>

        {/* Center Scrub Track */}
        <div className="flex-1 flex items-center gap-3">
          <span className="text-[10px] font-mono text-zinc-500">0.0s</span>
          <input
            id="timeline-scrubber"
            type="range"
            min={0}
            max={60}
            step={0.05}
            value={clock.time % 60}
            onChange={(e) => onSeek(Number(e.target.value))}
            aria-label="Timeline Scrub Bar"
            className="flex-1 accent-amber-500 h-2 bg-zinc-900 rounded-lg cursor-pointer"
          />
          <span className="text-[10px] font-mono text-zinc-500">60.0s</span>
        </div>

        {/* Right Rig Stats */}
        <div className="flex items-center gap-4 text-xs font-mono text-zinc-400">
          <div className="flex items-center gap-1.5 bg-zinc-950 px-2.5 py-1 rounded border border-zinc-800">
            <Zap className="w-3 h-3 text-amber-400" />
            <span>Power: <strong className="text-zinc-200">{scene.getTotalPowerWatts().toFixed(0)} W</strong></span>
          </div>

          <div className="flex items-center gap-1.5 bg-zinc-950 px-2.5 py-1 rounded border border-zinc-800">
            <Layers className="w-3 h-3 text-cyan-400" />
            <span>Fixtures: <strong className="text-zinc-200">{scene.getAllLights().length}</strong></span>
          </div>

          <div className="text-emerald-400 bg-emerald-950/40 px-2 py-1 rounded border border-emerald-800/60 font-bold text-[11px]">
            60 FPS SYNC
          </div>
        </div>
      </div>
    </div>
  );
};
