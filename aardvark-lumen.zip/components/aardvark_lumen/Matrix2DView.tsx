'use client';

import React, { useState } from 'react';
import { LightMatrix } from '@/lib/aardvark_lumen/scene-engine';
import { Grid, Sparkles, Sliders } from 'lucide-react';

interface Matrix2DViewProps {
  matrix: LightMatrix | null;
}

export const Matrix2DView: React.FC<Matrix2DViewProps> = ({ matrix }) => {
  const [hoveredCell, setHoveredCell] = useState<{ row: number; col: number; hex: string; intensity: number; dmx: string } | null>(null);

  if (!matrix) {
    return (
      <div className="w-full h-full flex flex-col items-center justify-center bg-zinc-950/80 rounded-xl border border-zinc-800/80 p-6 text-zinc-400">
        <Grid className="w-10 h-10 text-zinc-600 mb-2 stroke-[1.5]" />
        <p className="text-sm font-medium">No 2D Matrix Initialized</p>
        <p className="text-xs text-zinc-500 mt-1">Load Preset 2 or create with `scene.create_matrix(20, 20)`</p>
      </div>
    );
  }

  return (
    <div className="w-full h-full bg-[#0a0c10] rounded-xl border border-zinc-800 p-4 flex flex-col justify-between shadow-2xl relative">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-zinc-800/80">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
          <h3 className="text-xs font-mono font-semibold tracking-wider text-zinc-200">
            20×20 LED MATRIX SPATIAL FIELD ({matrix.rows * matrix.cols} PIXELS)
          </h3>
        </div>
        <div className="text-[11px] font-mono text-zinc-400">
          Pitch: <span className="text-amber-300">{matrix.spacing * 1000}mm</span> | 60 FPS
        </div>
      </div>

      {/* LED Grid Container */}
      <div className="flex-1 flex items-center justify-center p-2 overflow-auto">
        <div
          className="grid gap-[3px] p-3 bg-zinc-950 rounded-lg border border-zinc-800/90 shadow-inner"
          style={{
            gridTemplateColumns: `repeat(${matrix.cols}, minmax(0, 1fr))`,
          }}
        >
          {matrix.lights.map((row, rIdx) =>
            row.map((pixel, cIdx) => {
              const hex = pixel.color.to_hex();
              const intensity = pixel.getEffectiveIntensity();
              const glow = Math.min(1.0, intensity);

              return (
                <div
                  key={`p_${rIdx}_${cIdx}`}
                  id={`matrix-pixel-${rIdx}-${cIdx}`}
                  onMouseEnter={() => {
                    setHoveredCell({
                      row: rIdx,
                      col: cIdx,
                      hex,
                      intensity: pixel.intensity,
                      dmx: `U${pixel.dmxUniverse}:${pixel.dmxAddress}`
                    });
                  }}
                  onMouseLeave={() => setHoveredCell(null)}
                  className="w-3.5 h-3.5 sm:w-4 sm:h-4 md:w-4.5 md:h-4.5 rounded-[3px] transition-transform duration-75 hover:scale-125 cursor-crosshair relative group"
                  style={{
                    backgroundColor: hex,
                    opacity: 0.15 + glow * 0.85,
                    boxShadow: glow > 0.3 ? `0 0 ${glow * 8}px ${hex}` : 'none',
                  }}
                />
              );
            })
          )}
        </div>
      </div>

      {/* Footer Info Bar */}
      <div className="pt-3 border-t border-zinc-800/80 flex items-center justify-between text-xs font-mono text-zinc-400">
        {hoveredCell ? (
          <div className="flex items-center gap-3 text-amber-300">
            <span>Coord: [{hoveredCell.row}, {hoveredCell.col}]</span>
            <span>Color: {hoveredCell.hex}</span>
            <span>Intensity: {(hoveredCell.intensity * 100).toFixed(0)}%</span>
            <span>DMX: {hoveredCell.dmx}</span>
          </div>
        ) : (
          <div className="text-zinc-500 text-[11px]">
            Hover over any LED pixel to inspect coordinate, photometric intensity, and DMX patch.
          </div>
        )}

        <div className="flex items-center gap-2">
          <span className="text-[11px] text-zinc-500">Spatial Equation:</span>
          <code className="text-[10px] bg-zinc-900 px-1.5 py-0.5 rounded text-cyan-400 border border-zinc-800">
            field(x, y, z, t)
          </code>
        </div>
      </div>
    </div>
  );
};
