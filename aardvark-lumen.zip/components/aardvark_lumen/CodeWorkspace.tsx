'use client';

import React, { useState, useEffect } from 'react';
import { Play, Code, CheckCircle2, AlertTriangle, Download, Sparkles, Terminal, Copy, Check } from 'lucide-react';
import { PYTHON_PRESETS, PythonPresetScript } from '@/lib/aardvark_lumen/python-runtime';

interface CodeWorkspaceProps {
  code: string;
  onChangeCode: (newCode: string) => void;
  onExecute: () => void;
  logs: string[];
  executionError?: string;
  executionTimeMs?: number;
  onSelectPreset: (preset: PythonPresetScript) => void;
}

export const CodeWorkspace: React.FC<CodeWorkspaceProps> = ({
  code,
  onChangeCode,
  onExecute,
  logs,
  executionError,
  executionTimeMs = 0,
  onSelectPreset
}) => {
  const [copied, setCopied] = useState(false);
  const [selectedPresetId, setSelectedPresetId] = useState('slice_1_wave_lights');
  const [showConsole, setShowConsole] = useState(true);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([code], { type: 'text/x-python' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'aardvark_lumen_show.py';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="w-full h-full flex flex-col bg-[#0f1217] rounded-xl border border-zinc-800 shadow-2xl overflow-hidden">
      {/* Top Action Bar */}
      <div className="flex items-center justify-between px-3.5 py-2.5 bg-[#141820] border-b border-zinc-800/90 text-xs">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-amber-400" />
            <span className="font-mono font-semibold tracking-wider text-zinc-200">PYTHON LUMEN DSL</span>
          </div>

          {/* Preset Selector Dropdown */}
          <select
            id="select-preset-script"
            value={selectedPresetId}
            onChange={(e) => {
              setSelectedPresetId(e.target.value);
              const p = PYTHON_PRESETS.find(item => item.id === e.target.value);
              if (p) onSelectPreset(p);
            }}
            aria-label="Select Vertical Slice Preset"
            className="bg-zinc-900 border border-zinc-700/80 text-zinc-200 text-xs px-2.5 py-1 rounded-md focus:outline-none focus:border-amber-500 font-mono"
          >
            {PYTHON_PRESETS.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          <button
            id="btn-copy-code"
            onClick={handleCopyCode}
            className="flex items-center gap-1 text-zinc-400 hover:text-zinc-200 px-2 py-1 rounded hover:bg-zinc-800 transition-colors"
            title="Copy Python Code"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span className="text-[11px]">{copied ? 'Copied' : 'Copy'}</span>
          </button>

          <button
            id="btn-download-py"
            onClick={handleDownload}
            className="flex items-center gap-1 text-zinc-400 hover:text-zinc-200 px-2 py-1 rounded hover:bg-zinc-800 transition-colors"
            title="Export .py script"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="text-[11px]">.py</span>
          </button>

          <button
            id="btn-run-code"
            onClick={onExecute}
            className="flex items-center gap-1.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-zinc-950 font-semibold px-3 py-1 rounded-md shadow-md transition-all active:scale-95"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>RUN SCRIPT</span>
          </button>
        </div>
      </div>

      {/* Editor & Console Split */}
      <div className="flex-1 flex flex-col overflow-hidden relative">
        {/* Code Input Area */}
        <div className="flex-1 flex overflow-hidden font-mono text-xs">
          {/* Line Numbers Bar */}
          <div className="w-10 bg-[#0d1015] border-r border-zinc-800/80 text-zinc-600 text-right pr-2.5 pt-3 select-none text-[11px] leading-[19.2px] overflow-hidden">
            {code.split('\n').map((_, idx) => (
              <div key={`line-${idx}`}>{idx + 1}</div>
            ))}
          </div>

          {/* Textarea */}
          <textarea
            id="lumen-python-code-editor"
            value={code}
            onChange={(e) => onChangeCode(e.target.value)}
            onKeyDown={(e) => {
              // Quick Ctrl+Enter or Cmd+Enter to run
              if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
                e.preventDefault();
                onExecute();
              }
            }}
            spellCheck={false}
            className="flex-1 h-full bg-[#0f1217] text-zinc-200 p-3 pt-3 outline-none resize-none overflow-auto font-mono text-xs leading-[19.2px] whitespace-pre"
            placeholder="# Write Python Lumen illumination code here..."
          />
        </div>

        {/* Live Execution Status / Console Tray */}
        <div className="border-t border-zinc-800 bg-[#0c0e12] flex flex-col">
          <div className="flex items-center justify-between px-3 py-1.5 bg-[#12161f] border-b border-zinc-800/60 text-[11px]">
            <div className="flex items-center gap-2">
              <Terminal className="w-3.5 h-3.5 text-amber-400" />
              <span className="font-mono text-zinc-300 font-medium">LUMEN RUNTIME LOGS</span>
              {executionError ? (
                <span className="flex items-center gap-1 text-red-400 font-mono">
                  <AlertTriangle className="w-3 h-3" /> Error
                </span>
              ) : (
                <span className="flex items-center gap-1 text-emerald-400 font-mono">
                  <CheckCircle2 className="w-3 h-3" /> {executionTimeMs.toFixed(2)}ms
                </span>
              )}
            </div>

            <button
              onClick={() => setShowConsole(!showConsole)}
              className="text-zinc-500 hover:text-zinc-300 text-[10px] font-mono"
            >
              {showConsole ? 'Hide Console' : 'Show Console'}
            </button>
          </div>

          {showConsole && (
            <div className="max-h-24 overflow-auto p-2.5 font-mono text-[11px] text-zinc-400 space-y-0.5">
              {executionError ? (
                <div className="text-red-400 bg-red-950/30 p-1.5 rounded border border-red-900/50">
                  {executionError}
                </div>
              ) : (
                logs.map((log, i) => (
                  <div key={i} className="text-zinc-400 flex items-start gap-1.5">
                    <span className="text-zinc-600 select-none">&gt;</span>
                    <span>{log}</span>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
