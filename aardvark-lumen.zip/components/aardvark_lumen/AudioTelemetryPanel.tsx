'use client';

import React from 'react';
import { AudioAnalyzer, AudioFeatures } from '@/lib/aardvark_lumen/audio-engine';
import { TelemetryDataStream } from '@/lib/aardvark_lumen/types';
import { Mic, MicOff, Music, Gauge, Rocket, Flame, Activity, Zap } from 'lucide-react';

interface AudioTelemetryPanelProps {
  audioAnalyzer: AudioAnalyzer;
  audioFeatures: AudioFeatures;
  telemetry: TelemetryDataStream;
  onToggleMic: () => void;
  onSetTrackType: (type: 'techno' | 'synthwave' | 'ambient') => void;
}

export const AudioTelemetryPanel: React.FC<AudioTelemetryPanelProps> = ({
  audioAnalyzer,
  audioFeatures,
  telemetry,
  onToggleMic,
  onSetTrackType,
}) => {
  const isMic = audioAnalyzer.isUsingMicrophone();

  return (
    <div className="w-full h-full bg-[#0d1015] rounded-xl border border-zinc-800 p-4 flex flex-col justify-between shadow-2xl overflow-auto gap-4">
      {/* 1. Audio Reactor Section */}
      <div className="bg-zinc-950/80 rounded-lg p-3 border border-zinc-800/80">
        <div className="flex items-center justify-between pb-2 mb-2 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <Music className="w-4 h-4 text-amber-400" />
            <h4 className="text-xs font-mono font-semibold text-zinc-200">
              AUDIO SPECTRUM & BEAT DETECTOR
            </h4>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="btn-toggle-mic"
              onClick={onToggleMic}
              className={`flex items-center gap-1 text-[11px] px-2 py-1 rounded font-mono transition-all ${
                isMic
                  ? 'bg-red-500/20 text-red-300 border border-red-500/40 font-semibold'
                  : 'bg-zinc-900 text-zinc-400 hover:text-zinc-200 border border-zinc-800'
              }`}
            >
              {isMic ? <Mic className="w-3 h-3 text-red-400" /> : <MicOff className="w-3 h-3" />}
              <span>{isMic ? 'Live Mic ON' : 'Enable Mic'}</span>
            </button>

            {!isMic && (
              <div className="flex items-center gap-1 bg-zinc-900 p-0.5 rounded border border-zinc-800 text-[10px] font-mono">
                {(['techno', 'synthwave', 'ambient'] as const).map((track) => (
                  <button
                    key={track}
                    onClick={() => onSetTrackType(track)}
                    className="px-2 py-0.5 rounded text-zinc-400 hover:text-zinc-200 capitalize hover:bg-zinc-800"
                  >
                    {track}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* FFT Spectrum Display */}
        <div className="h-16 flex items-end gap-[2px] bg-black/40 p-2 rounded border border-zinc-900">
          {Array.from(audioFeatures.frequencyData.slice(0, 32)).map((val, idx) => {
            const pct = (val / 255) * 100;
            return (
              <div
                key={idx}
                className="flex-1 bg-gradient-to-t from-amber-600 via-amber-400 to-cyan-400 rounded-t-[1px] transition-all duration-75"
                style={{ height: `${Math.max(4, pct)}%` }}
              />
            );
          })}
        </div>

        {/* Audio Feature Meters */}
        <div className="grid grid-cols-4 gap-2 mt-3 text-center font-mono text-xs">
          <div className="bg-zinc-900/90 p-2 rounded border border-zinc-800/80">
            <span className="text-[10px] text-zinc-500 block">SUB-BASS</span>
            <span className="text-amber-400 font-bold">{(audioFeatures.subBass * 100).toFixed(0)}%</span>
            <div className="w-full h-1 bg-zinc-800 rounded-full mt-1 overflow-hidden">
              <div className="h-full bg-amber-400" style={{ width: `${audioFeatures.subBass * 100}%` }} />
            </div>
          </div>

          <div className="bg-zinc-900/90 p-2 rounded border border-zinc-800/80">
            <span className="text-[10px] text-zinc-500 block">BASS</span>
            <span className="text-amber-400 font-bold">{(audioFeatures.bass * 100).toFixed(0)}%</span>
            <div className="w-full h-1 bg-zinc-800 rounded-full mt-1 overflow-hidden">
              <div className="h-full bg-amber-400" style={{ width: `${audioFeatures.bass * 100}%` }} />
            </div>
          </div>

          <div className="bg-zinc-900/90 p-2 rounded border border-zinc-800/80">
            <span className="text-[10px] text-zinc-500 block">MID-RANGE</span>
            <span className="text-cyan-400 font-bold">{(audioFeatures.mid * 100).toFixed(0)}%</span>
            <div className="w-full h-1 bg-zinc-800 rounded-full mt-1 overflow-hidden">
              <div className="h-full bg-cyan-400" style={{ width: `${audioFeatures.mid * 100}%` }} />
            </div>
          </div>

          <div className={`p-2 rounded border transition-all ${
            audioFeatures.isBeat
              ? 'bg-amber-500/30 border-amber-400 text-amber-300 shadow-md shadow-amber-500/20'
              : 'bg-zinc-900/90 border-zinc-800/80 text-zinc-500'
          }`}>
            <span className="text-[10px] block">BEAT ONSET</span>
            <span className="font-bold flex items-center justify-center gap-1">
              <Zap className={`w-3 h-3 ${audioFeatures.isBeat ? 'text-amber-300 animate-bounce' : 'text-zinc-600'}`} />
              {audioFeatures.isBeat ? 'PULSE' : 'IDLE'}
            </span>
          </div>
        </div>
      </div>

      {/* 2. Simulation Telemetry Section */}
      <div className="bg-zinc-950/80 rounded-lg p-3 border border-zinc-800/80">
        <div className="flex items-center justify-between pb-2 mb-2 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <Rocket className="w-4 h-4 text-cyan-400" />
            <h4 className="text-xs font-mono font-semibold text-zinc-200">
              AARDVARK SIMULATION TELEMETRY (ROCKETML / TURBOMACH)
            </h4>
          </div>
          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-800/50">
            IPC STREAM ACTIVE
          </span>
        </div>

        <div className="grid grid-cols-3 gap-2 font-mono text-xs">
          <div className="bg-zinc-900/90 p-2 rounded border border-zinc-800/80">
            <span className="text-[10px] text-zinc-500 block">ALTITUDE</span>
            <span className="text-zinc-200 font-bold">{telemetry.rocketAltitudeMeters.toLocaleString()} m</span>
            <span className="text-[9px] text-zinc-600 block mt-0.5">&rarr; Z-Axis Position</span>
          </div>

          <div className="bg-zinc-900/90 p-2 rounded border border-zinc-800/80">
            <span className="text-[10px] text-zinc-500 block">AIRSPEED</span>
            <span className="text-zinc-200 font-bold">{telemetry.rocketSpeedMps} m/s</span>
            <span className="text-[9px] text-zinc-600 block mt-0.5">&rarr; Rig Intensity</span>
          </div>

          <div className="bg-zinc-900/90 p-2 rounded border border-zinc-800/80">
            <span className="text-[10px] text-zinc-500 block">CHAMBER TEMP</span>
            <span className="text-amber-400 font-bold">{telemetry.engineTemperatureC} °C</span>
            <span className="text-[9px] text-zinc-600 block mt-0.5">&rarr; Blackbody Kelvin</span>
          </div>

          <div className="bg-zinc-900/90 p-2 rounded border border-zinc-800/80">
            <span className="text-[10px] text-zinc-500 block">TRAJECTORY ERROR</span>
            <span className={`font-bold ${telemetry.trajectoryErrorDegrees > 1.0 ? 'text-red-400' : 'text-emerald-400'}`}>
              {telemetry.trajectoryErrorDegrees}°
            </span>
            <span className="text-[9px] text-zinc-600 block mt-0.5">&rarr; Alert Redness</span>
          </div>

          <div className="bg-zinc-900/90 p-2 rounded border border-zinc-800/80">
            <span className="text-[10px] text-zinc-500 block">TURBOMACH RPM</span>
            <span className="text-zinc-200 font-bold">{telemetry.turbomachineryRpm.toLocaleString()}</span>
            <span className="text-[9px] text-zinc-600 block mt-0.5">&rarr; Pulse Frequency</span>
          </div>

          <div className="bg-zinc-900/90 p-2 rounded border border-zinc-800/80">
            <span className="text-[10px] text-zinc-500 block">REFINERY PRESS</span>
            <span className="text-zinc-200 font-bold">{telemetry.refineryPressureBar} bar</span>
            <span className="text-[9px] text-zinc-600 block mt-0.5">&rarr; Pressure Wash</span>
          </div>
        </div>
      </div>
    </div>
  );
};
