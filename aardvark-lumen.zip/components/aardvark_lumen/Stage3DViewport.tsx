'use client';

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { LumenScene, LumenLight } from '@/lib/aardvark_lumen/scene-engine';
import { ParticleLightingSystem } from '@/lib/aardvark_lumen/procedural-engine';
import { Eye, Camera, RefreshCw, ZoomIn, SunMedium, Flame } from 'lucide-react';

interface Stage3DViewportProps {
  scene: LumenScene;
  particleSystem?: ParticleLightingSystem;
  selectedLightId: string | null;
  onSelectLight: (id: string | null) => void;
  showVolumetric: boolean;
  showTrussGrid: boolean;
}

export const Stage3DViewport: React.FC<Stage3DViewportProps> = ({
  scene,
  particleSystem,
  selectedLightId,
  onSelectLight,
  showVolumetric,
  showTrussGrid
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const threeSceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Mesh registries for fast update
  const fixtureMeshesRef = useRef<Map<string, {
    group: THREE.Group;
    headMesh: THREE.Mesh;
    beamMesh?: THREE.Mesh;
    spotLight?: THREE.SpotLight;
    pointLight?: THREE.PointLight;
    groundMarker: THREE.Mesh;
  }>>(new Map());

  const particleMeshRef = useRef<THREE.InstancedMesh | null>(null);
  const [cameraPreset, setCameraPreset] = useState<'perspective' | 'front' | 'top' | 'rig'>('perspective');
  const [hoveredFixture, setHoveredFixture] = useState<string | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    const width = containerRef.current.clientWidth;
    const height = containerRef.current.clientHeight;

    // 1. Initialize Three.js Scene & Camera
    const threeScene = new THREE.Scene();
    threeScene.background = new THREE.Color(0x0c0e12); // Deep graphite stage darkness
    threeScene.fog = new THREE.FogExp2(0x0c0e12, scene.fogDensity);
    threeSceneRef.current = threeScene;

    const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 100);
    camera.position.set(0, 6.5, 12.0);
    camera.lookAt(0, 1.5, 0);
    cameraRef.current = camera;

    // 2. Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    containerRef.current.innerHTML = '';
    containerRef.current.appendChild(renderer.domElement);

    // 3. Stage Floor
    const floorGeo = new THREE.PlaneGeometry(36, 24);
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0x141820,
      roughness: 0.35,
      metalness: 0.7,
    });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = 0;
    floor.receiveShadow = true;
    threeScene.add(floor);

    // Subtle stage grid
    const grid = new THREE.GridHelper(30, 30, 0x2a3342, 0x18202c);
    grid.position.y = 0.01;
    threeScene.add(grid);

    // 4. Overhead Stage Truss Rigging
    const trussGroup = new THREE.Group();
    const trussMat = new THREE.MeshStandardMaterial({ color: 0x3b4455, metalness: 0.85, roughness: 0.3 });

    // Main horizontal truss bar
    const trussBarGeo = new THREE.BoxGeometry(22, 0.25, 0.25);
    const trussBar = new THREE.Mesh(trussBarGeo, trussMat);
    trussBar.position.set(0, 5.2, 0);
    trussGroup.add(trussBar);

    // Side pillars
    const pillarGeo = new THREE.CylinderGeometry(0.12, 0.12, 5.2, 8);
    const pillarL = new THREE.Mesh(pillarGeo, trussMat);
    pillarL.position.set(-10, 2.6, 0);
    trussGroup.add(pillarL);

    const pillarR = new THREE.Mesh(pillarGeo, trussMat);
    pillarR.position.set(10, 2.6, 0);
    trussGroup.add(pillarR);

    threeScene.add(trussGroup);

    // Ambient fill light for stage visibility
    const ambientLight = new THREE.AmbientLight(0x222a38, 0.6);
    threeScene.add(ambientLight);

    // 5. Particles Instanced Mesh (Fireflies / Sparks)
    if (particleSystem) {
      const pGeo = new THREE.SphereGeometry(0.08, 8, 8);
      const pMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.85 });
      const pMesh = new THREE.InstancedMesh(pGeo, pMat, particleSystem.maxParticles);
      pMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      particleMeshRef.current = pMesh;
      threeScene.add(pMesh);
    }

    // 6. Interaction: Orbit Drag
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;
    let spherical = { radius: 14, theta: 0, phi: Math.PI / 3 };

    const updateCameraFromSpherical = () => {
      if (!cameraRef.current) return;
      const x = spherical.radius * Math.sin(spherical.phi) * Math.sin(spherical.theta);
      const y = spherical.radius * Math.cos(spherical.phi);
      const z = spherical.radius * Math.sin(spherical.phi) * Math.cos(spherical.theta);
      cameraRef.current.position.set(x, Math.max(0.8, y), z);
      cameraRef.current.lookAt(0, 1.8, 0);
    };

    const onMouseDown = (e: MouseEvent) => {
      isDragging = true;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      const dx = e.clientX - prevMouseX;
      const dy = e.clientY - prevMouseY;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;

      spherical.theta -= dx * 0.008;
      spherical.phi = Math.max(0.1, Math.min(Math.PI / 2 - 0.05, spherical.phi - dy * 0.008));
      updateCameraFromSpherical();
    };

    const onMouseUp = () => { isDragging = false; };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      spherical.radius = Math.max(4, Math.min(30, spherical.radius + e.deltaY * 0.015));
      updateCameraFromSpherical();
    };

    const dom = renderer.domElement;
    dom.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    dom.addEventListener('wheel', onWheel, { passive: false });

    // 7. Resize Observer
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const w = entry.contentRect.width;
        const h = entry.contentRect.height;
        if (w > 0 && h > 0 && cameraRef.current && rendererRef.current) {
          cameraRef.current.aspect = w / h;
          cameraRef.current.updateProjectionMatrix();
          rendererRef.current.setSize(w, h);
        }
      }
    });
    resizeObserver.observe(containerRef.current);

    // Synchronize LumenScene light states to Three.js objects
    const syncLightsToThree = (threeScene: THREE.Scene) => {
      const allLights = scene.getAllLights();
      const activeIds = new Set<string>();

      for (const light of allLights) {
        activeIds.add(light.id);
        let entry = fixtureMeshesRef.current.get(light.id);

        const [r, g, b] = [light.color.r, light.color.g, light.color.b];
        const effIntensity = light.getEffectiveIntensity();
        const threeColor = new THREE.Color(r, g, b);

        if (!entry) {
          // Create new Three representation for fixture
          const group = new THREE.Group();
          group.position.set(light.position.x, light.position.y, light.position.z);

          // Fixture Body / Yoke Housing
          const bodyMat = new THREE.MeshStandardMaterial({ color: 0x1f242e, roughness: 0.4, metalness: 0.9 });
          const headGeo = light.type === 'BEAM' || light.type === 'SPOT'
            ? new THREE.CylinderGeometry(0.18, 0.28, 0.55, 16)
            : light.type === 'AREA' || light.type === 'PANEL'
            ? new THREE.BoxGeometry(0.8, 0.4, 0.15)
            : new THREE.SphereGeometry(0.18, 12, 12);

          const headMesh = new THREE.Mesh(headGeo, bodyMat);
          headMesh.castShadow = true;
          group.add(headMesh);

          // Volumetric Cone Shaft (Cylinder / Cone with alpha gradient)
          let beamMesh: THREE.Mesh | undefined;
          let spotLight: THREE.SpotLight | undefined;
          let pointLight: THREE.PointLight | undefined;

          if (light.type === 'SPOT' || light.type === 'BEAM' || light.type === 'WASH') {
            const coneLength = Math.min(10.0, light.range * 0.45);
            const coneRadius = coneLength * Math.tan(THREE.MathUtils.degToRad(light.beamAngle / 2));
            const coneGeo = new THREE.ConeGeometry(coneRadius, coneLength, 24, 1, true);
            coneGeo.translate(0, -coneLength / 2, 0);

            const beamMat = new THREE.MeshBasicMaterial({
              color: threeColor,
              transparent: true,
              opacity: 0.22,
              side: THREE.DoubleSide,
              depthWrite: false,
              blending: THREE.AdditiveBlending
            });

            beamMesh = new THREE.Mesh(coneGeo, beamMat);
            group.add(beamMesh);

            // Real Three.js SpotLight for dynamic illumination & shadow casting
            spotLight = new THREE.SpotLight(threeColor, effIntensity * 15, light.range, THREE.MathUtils.degToRad(light.beamAngle), light.beamSoftness, 2.0);
            spotLight.position.set(0, 0, 0);
            spotLight.target.position.set(light.target.x, light.target.y, light.target.z);
            spotLight.castShadow = true;
            threeScene.add(spotLight.target);
            group.add(spotLight);
          } else {
            pointLight = new THREE.PointLight(threeColor, effIntensity * 8, light.range, 2.0);
            group.add(pointLight);
          }

          // Ground Spot Ring Indicator
          const ringGeo = new THREE.RingGeometry(0.15, 0.25, 24);
          const ringMat = new THREE.MeshBasicMaterial({ color: threeColor, transparent: true, opacity: 0.4, side: THREE.DoubleSide });
          const groundMarker = new THREE.Mesh(ringGeo, ringMat);
          groundMarker.rotation.x = -Math.PI / 2;
          groundMarker.position.set(light.target.x, 0.02, light.target.z);
          threeScene.add(groundMarker);

          threeScene.add(group);
          entry = { group, headMesh, beamMesh, spotLight, pointLight, groundMarker };
          fixtureMeshesRef.current.set(light.id, entry);
        }

        // Update position & dynamic properties
        entry.group.position.set(light.position.x, light.position.y, light.position.z);
        
        // Aim head towards target or apply rotation
        if (light.type === 'SPOT' || light.type === 'BEAM') {
          const targetVec = new THREE.Vector3(light.target.x, light.target.y, light.target.z);
          entry.group.lookAt(targetVec);
          // Adjust default orientation for cone
          entry.group.rotateX(-Math.PI / 2);

          if (entry.spotLight) {
            entry.spotLight.color.setRGB(r, g, b);
            entry.spotLight.intensity = effIntensity * 18;
            entry.spotLight.angle = THREE.MathUtils.degToRad(light.beamAngle);
            entry.spotLight.penumbra = light.beamSoftness;
            entry.spotLight.target.position.set(light.target.x, light.target.y, light.target.z);
          }
        }

        if (entry.pointLight) {
          entry.pointLight.color.setRGB(r, g, b);
          entry.pointLight.intensity = effIntensity * 12;
        }

        if (entry.beamMesh) {
          entry.beamMesh.visible = showVolumetric && light.enabled && effIntensity > 0.01;
          (entry.beamMesh.material as THREE.MeshBasicMaterial).color.setRGB(r, g, b);
          (entry.beamMesh.material as THREE.MeshBasicMaterial).opacity = Math.min(0.5, effIntensity * 0.35);
        }

        // Ground marker ring
        entry.groundMarker.position.set(light.target.x, 0.02, light.target.z);
        entry.groundMarker.visible = light.enabled && effIntensity > 0.02;
        (entry.groundMarker.material as THREE.MeshBasicMaterial).color.setRGB(r, g, b);
        (entry.groundMarker.material as THREE.MeshBasicMaterial).opacity = Math.min(0.8, effIntensity * 0.5);
      }

      // Cleanup deleted lights
      for (const [id, entry] of fixtureMeshesRef.current.entries()) {
        if (!activeIds.has(id)) {
          threeScene.remove(entry.group);
          threeScene.remove(entry.groundMarker);
          if (entry.spotLight) threeScene.remove(entry.spotLight.target);
          fixtureMeshesRef.current.delete(id);
        }
      }
    };

    // 8. Render Loop
    const animate = () => {
      animationFrameRef.current = requestAnimationFrame(animate);

      if (threeSceneRef.current && cameraRef.current && rendererRef.current) {
        // Synchronize lights with Three.js objects
        syncLightsToThree(threeSceneRef.current);

        // Synchronize particles
        if (particleSystem && particleMeshRef.current) {
          const dummy = new THREE.Object3D();
          const pColor = new THREE.Color();
          for (let i = 0; i < particleSystem.particles.length; i++) {
            const p = particleSystem.particles[i];
            dummy.position.set(p.position.x, p.position.y, p.position.z);
            dummy.scale.setScalar(p.size * Math.min(1.5, p.intensity));
            dummy.updateMatrix();
            particleMeshRef.current.setMatrixAt(i, dummy.matrix);

            pColor.setRGB(p.color.r, p.color.g, p.color.b);
            particleMeshRef.current.setColorAt(i, pColor);
          }
          particleMeshRef.current.instanceMatrix.needsUpdate = true;
          if (particleMeshRef.current.instanceColor) {
            particleMeshRef.current.instanceColor.needsUpdate = true;
          }
        }

        rendererRef.current.render(threeSceneRef.current, cameraRef.current);
      }
    };

    animate();

    return () => {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      resizeObserver.disconnect();
      dom.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      dom.removeEventListener('wheel', onWheel);
      if (rendererRef.current) {
        rendererRef.current.dispose();
      }
    };
  }, [particleSystem, scene, showVolumetric, showTrussGrid]);

  const handleCameraPreset = (preset: 'perspective' | 'front' | 'top' | 'rig') => {
    setCameraPreset(preset);
    if (!cameraRef.current) return;

    if (preset === 'perspective') {
      cameraRef.current.position.set(0, 6.5, 12.0);
      cameraRef.current.lookAt(0, 1.5, 0);
    } else if (preset === 'front') {
      cameraRef.current.position.set(0, 2.5, 13.5);
      cameraRef.current.lookAt(0, 2.5, 0);
    } else if (preset === 'top') {
      cameraRef.current.position.set(0, 16.0, 0.1);
      cameraRef.current.lookAt(0, 0, 0);
    } else if (preset === 'rig') {
      cameraRef.current.position.set(-8.0, 6.0, 7.0);
      cameraRef.current.lookAt(0, 2.0, 0);
    }
  };

  return (
    <div className="relative w-full h-full min-h-[380px] bg-[#0c0e12] overflow-hidden rounded-xl border border-zinc-800 shadow-2xl flex flex-col">
      {/* 3D WebGL Canvas Mount */}
      <div ref={containerRef} className="w-full flex-1 cursor-grab active:cursor-grabbing" />

      {/* Floating HUD Controls */}
      <div className="absolute top-3 left-3 flex items-center gap-1.5 bg-zinc-950/80 backdrop-blur-md px-2.5 py-1.5 rounded-lg border border-zinc-800/80 text-xs text-zinc-300 shadow-lg">
        <span className="font-mono text-amber-400 font-medium tracking-wide">3D STAGE VIEWPORT</span>
        <span className="text-zinc-600">|</span>
        <span className="text-zinc-400 font-mono">{scene.getAllLights().length} Fixtures</span>
      </div>

      {/* Camera Switcher Buttons */}
      <div className="absolute top-3 right-3 flex items-center gap-1 bg-zinc-950/80 backdrop-blur-md p-1 rounded-lg border border-zinc-800/80 text-xs">
        <button
          id="btn-cam-persp"
          onClick={() => handleCameraPreset('perspective')}
          className={`px-2 py-1 rounded font-medium transition-all ${
            cameraPreset === 'perspective' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          Perspective
        </button>
        <button
          id="btn-cam-front"
          onClick={() => handleCameraPreset('front')}
          className={`px-2 py-1 rounded font-medium transition-all ${
            cameraPreset === 'front' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          Front Stage
        </button>
        <button
          id="btn-cam-top"
          onClick={() => handleCameraPreset('top')}
          className={`px-2 py-1 rounded font-medium transition-all ${
            cameraPreset === 'top' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          Top Down
        </button>
        <button
          id="btn-cam-rig"
          onClick={() => handleCameraPreset('rig')}
          className={`px-2 py-1 rounded font-medium transition-all ${
            cameraPreset === 'rig' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          Rig Wing
        </button>
      </div>

      {/* Bottom Stage Telemetry Bar */}
      <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between pointer-events-none">
        <div className="flex items-center gap-3 bg-zinc-950/85 backdrop-blur-md px-3 py-1.5 rounded-lg border border-zinc-800 text-[11px] font-mono text-zinc-400 pointer-events-auto shadow-md">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-zinc-300">OPENGL / WEBGL ACCELERATED</span>
          </div>
          <span className="text-zinc-700">/</span>
          <span>Volumetric Cone Shading: <strong className="text-amber-300">{showVolumetric ? 'ON' : 'OFF'}</strong></span>
          <span className="text-zinc-700">/</span>
          <span>Power: <strong className="text-zinc-200">{scene.getTotalPowerWatts().toFixed(0)} W</strong></span>
        </div>

        <div className="text-[11px] font-mono text-zinc-500 bg-zinc-950/80 px-2 py-1 rounded border border-zinc-800/80">
          Orbit: Drag | Zoom: Scroll
        </div>
      </div>
    </div>
  );
};
