'use client';

import React, { useState } from 'react';
import { DMXController } from '@/lib/aardvark_lumen/dmx-engine';
import { LumenScene } from '@/lib/aardvark_lumen/scene-engine';
import { ShieldAlert, Radio, Activity, CheckCircle, PowerOff, Zap } from 'lucide-react';

interface DmxInspectorProps {
  dmxController: DMXController;
  scene: LumenScene;
  onBlackout: () => void;
  onRestore: () => void;
}

export const DmxInspector: React.FC<DmxInspectorProps> = ({
  dmxController,
  scene,
  onBlackout,
  onRestore,
}) => {
  const [selectedUniverse, setSelectedUniverse] = useState(1);
  const uState = dmxController.universes.get(selectedUniverse);
  const channels = uState ? Array.from(uState.channels) : [];
  const isBlackout = dmxController.isBlackout || scene.isBlackout;

  return (
    <div className="w-full h-full bg-[#0d1015] rounded-xl border border-zinc-800 p-4 flex flex-col justify-between shadow-2xl">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-amber-400" />
            <h3 className="text-xs font-mono font-semibold tracking-wider text-zinc-200">
              DMX512 / ART-NET MULTI-UNIVERSE ENGINE
            </h3>
          </div>

          {/* Universe Tab Switcher */}
          <div className="flex items-center gap-1 bg-zinc-900 p-1 rounded-lg border border-zinc-800 text-xs">
            {[1, 2, 3, 4].map((u) => (
              <button
                key={u}
                onClick={() => setSelectedUniverse(u)}
                className={`px-2.5 py-1 rounded font-mono text-[11px] transition-all ${
                  selectedUniverse === u
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                U{u} (512ch)
              </button>
            ))}
          </div>
        </div>

        {/* Hardware Safety & Emergency Blackout */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-[11px] font-mono text-zinc-400 bg-zinc-900/90 px-2.5 py-1 rounded border border-zinc-800">
            <Activity className="w-3 h-3 text-emerald-400" />
            <span>Art-Net: 44.1 Hz</span>
            <span className="text-zinc-600">|</span>
            <span>Total: {dmxController.packetsSentTotal} pkts</span>
          </div>

          {isBlackout ? (
            <button
              id="btn-restore-dmx"
              onClick={onRestore}
              className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold px-3 py-1.5 rounded-lg shadow-md transition-all active:scale-95"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>RESTORE RIG</span>
            </button>
          ) : (
            <button
              id="btn-blackout-dmx"
              onClick={onBlackout}
              className="flex items-center gap-1.5 bg-red-600 hover:bg-red-500 text-white text-xs font-semibold px-3 py-1.5 rounded-lg shadow-md transition-all active:scale-95"
            >
              <PowerOff className="w-3.5 h-3.5" />
              <span>EMERGENCY BLACKOUT</span>
            </button>
          )}
        </div>
      </div>

      {/* DMX Channel Grid View (First 128 channels displayed in high density, scrollable to 512) */}
      <div className="flex-1 my-3 overflow-auto bg-zinc-950/70 rounded-lg p-3 border border-zinc-800/80">
        <div className="grid grid-cols-8 sm:grid-cols-16 md:grid-cols-32 gap-1 text-center font-mono">
          {channels.slice(0, 256).map((val, idx) => {
            const chNum = idx + 1;
            const norm = val / 255;
            const hasSignal = val > 0;

            return (
              <div
                key={idx}
                id={`dmx-ch-${chNum}`}
                className={`p-1 rounded flex flex-col items-center justify-center border transition-all ${
                  hasSignal
                    ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                    : 'bg-zinc-900/50 border-zinc-800/60 text-zinc-600'
                }`}
                title={`Channel ${chNum}: ${val} (${(norm * 100).toFixed(0)}%)`}
              >
                <span className="text-[9px] text-zinc-500">{chNum}</span>
                <span className="text-[10px] font-bold">{val}</span>
                {/* Mini Level Bar */}
                <div className="w-full h-1 bg-zinc-800 rounded-full mt-0.5 overflow-hidden">
                  <div
                    className="h-full bg-amber-400"
                    style={{ width: `${norm * 100}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Footer Info & Fixture Patch Table */}
      <div className="pt-2 border-t border-zinc-800 flex items-center justify-between text-xs font-mono text-zinc-400">
        <div className="flex items-center gap-3">
          <span className="text-zinc-500">Active Fixture Addresses:</span>
          {scene.getAllLights().slice(0, 5).map((l, idx) => (
            <span key={l.id} className="text-amber-300 bg-zinc-900 px-2 py-0.5 rounded border border-zinc-800">
              {l.name} → U{l.dmxUniverse}:{l.dmxAddress} ({l.channelMode})
            </span>
          ))}
        </div>

        <div className="flex items-center gap-2 text-[11px] text-zinc-500">
          <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
          <span>Physical safety rate limiter capped at 25 Hz strobe</span>
        </div>
      </div>
    </div>
  );
};
