// AARDVARK LUMEN - Type Definitions & Interfaces
import { LumenColor } from './color-engine';

export type LightType =
  | 'POINT'
  | 'SPOT'
  | 'AREA'
  | 'DIRECTIONAL'
  | 'EMISSIVE'
  | 'LASER_SIMULATION'
  | 'PIXEL'
  | 'STRIP'
  | 'PANEL'
  | 'WASH'
  | 'BEAM';

export type DimmingCurve = 'linear' | 's_curve' | 'gamma' | 'exponential' | 'logarithmic' | 'smoothstep';

export type FalloffType = 'inverse_square' | 'linear' | 'smooth' | 'none';

export type FixtureChannelMode = 'RGB' | 'RGBW' | 'RGBA' | 'RGBAW' | 'RGBWW' | 'MOVING_HEAD_16CH' | 'DIMMER_ONLY';

export interface Vector3D {
  x: number;
  y: number;
  z: number;
}

export interface EulerRotation {
  x: number; // Pitch in degrees
  y: number; // Yaw in degrees
  z: number; // Roll in degrees
}

export interface LightState {
  id: string;
  name: string;
  type: LightType;
  position: Vector3D;
  target?: Vector3D;
  rotation: EulerRotation;
  color: LumenColor;
  intensity: number; // Continuous 0.0 - >1.0 for HDR
  temperature?: number; // Kelvin (e.g. 2700, 5600)
  range: number; // In meters / world units
  beamAngle: number; // In degrees (e.g. 15 for narrow beam, 60 for wash)
  beamSoftness: number; // 0.0 (hard edge) to 1.0 (smooth gaussian)
  falloff: FalloffType;
  dimmingCurve: DimmingCurve;
  enabled: boolean;
  opacity: number;
  channelMode: FixtureChannelMode;
  dmxUniverse: number;
  dmxAddress: number; // 1 - 512
  metadata?: Record<string, any>;
  // Dynamic runtime metrics
  currentEnergyWatts?: number;
  isStrobing?: boolean;
}

export interface EffectParameters {
  type: 'wave' | 'pulse' | 'flash' | 'strobe' | 'flicker' | 'chase' | 'fire' | 'lightning' | 'noise' | 'rainbow' | 'aurora' | 'twinkle';
  speed: number;
  frequency: number;
  amplitude: number;
  phase: number;
  colorA?: LumenColor;
  colorB?: LumenColor;
  decay?: number;
  rateLimitHz?: number;
  seed?: number;
}

export interface NodeGraphConnection {
  id: string;
  fromNodeId: string;
  fromPort: string;
  toNodeId: string;
  toPort: string;
}

export interface ComputationalNode {
  id: string;
  type: 'TIME' | 'AUDIO_BASS' | 'AUDIO_TREBLE' | 'TELEMETRY' | 'SINE' | 'NOISE' | 'MAP' | 'COLOR_GRADIENT' | 'MIX' | 'INTENSITY' | 'LIGHT_OUTPUT';
  title: string;
  x: number;
  y: number;
  inputs: { [key: string]: any };
  outputs: { [key: string]: any };
  parameters: Record<string, any>;
}

export interface ShowCue {
  id: string;
  name: string;
  timeStart: number; // In seconds
  duration: number; // In seconds
  fadeTime: number;
  description: string;
  codeSnippet: string;
  paletteId: string;
  active: boolean;
}

export interface TelemetryDataStream {
  timestamp: number;
  rocketAltitudeMeters: number;
  rocketSpeedMps: number;
  engineTemperatureC: number;
  trajectoryErrorDegrees: number;
  turbomachineryRpm: number;
  refineryPressureBar: number;
  batteryHealthPercent: number;
  civitasTrafficDensity: number;
}

export interface DMXUniverseState {
  universeNumber: number; // 1 - 4
  channels: Uint8Array; // 512 bytes (0-255)
  fps: number;
  packetsSent: number;
  isBlackout: boolean;
  safetyLimited: boolean;
}
