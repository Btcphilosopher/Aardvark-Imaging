// AARDVARK LUMEN - Python-Native Code Execution Engine & DSL Interpreter
import { LumenScene, LumenLight, LightMatrix } from './scene-engine';
import { LumenColor, LUMEN_PALETTES, LumenGradient } from './color-engine';
import { AudioFeatures } from './audio-engine';
import { TelemetryDataStream } from './types';
import { FastNoise, ProceduralWaves, ProceduralFire, ProceduralLightning } from './procedural-engine';

export interface ExecutionResult {
  success: boolean;
  logs: string[];
  error?: string;
  executionTimeMs: number;
}

export interface PythonPresetScript {
  id: string;
  name: string;
  category: string;
  description: string;
  code: string;
}

export const PYTHON_PRESETS: PythonPresetScript[] = [
  {
    id: 'slice_1_wave_lights',
    name: '1. Ten-Light Math Wave (Slice 1)',
    category: 'Vertical Slice',
    description: '10 spotlights positioned along the X-axis animated with phase-shifted sine waves and spectrum cycling.',
    code: `# AARDVARK LUMEN - VERTICAL SLICE 1: 10-LIGHT MATHEMATICAL WAVE
# light.color = spectrum(t) | light.intensity = pulse(t) | light.position = orbit(t)

scene = LumenScene("Wave Rig")

# Create 10 architectural spotlights across stage
lights = []
for i in range(10):
    light = scene.create_light(f"spot_{i}", f"Spot #{i+1}", "SPOT")
    light.position = ( (i - 4.5) * 1.2, 4.0, 0.0 )
    light.target = ( (i - 4.5) * 0.8, 0.0, 0.0 )
    light.beam_angle = 24.0
    light.beam_softness = 0.5
    light.falloff = "inverse_square"
    light.dimming_curve = "gamma"
    lights.append(light)

def frame(t):
    for i, light in enumerate(lights):
        # Continuous phase-shifted oscillation
        phase = i * 0.55
        
        # Colour calculation in HSV hue space
        hue = (t * 0.12 + i * 0.08) % 1.0
        light.color = Color.from_hsv(hue, 0.95, 1.0)
        
        # Mathematical intensity pulse with S-curve response
        light.intensity = 0.4 + 0.6 * np.sin(t * 3.2 - phase)
        
        # Dynamic spatial beam tracking
        light.target = (
            (i - 4.5) * 0.8 + 0.6 * np.sin(t * 2.0 + phase),
            0.0,
            1.2 * np.cos(t * 2.0 + phase)
        )
`
  },
  {
    id: 'slice_2_matrix_field',
    name: '2. 20x20 LED Matrix Procedural Field (Slice 2)',
    category: 'Vertical Slice',
    description: '400 LED pixels modulated in real-time by a continuous 2D procedural field and radial wave function.',
    code: `# AARDVARK LUMEN - VERTICAL SLICE 2: 20x20 PROCEDURAL FIELD
# pixel.color = field(x, y, z, t)

scene = LumenScene("LED Matrix Field")
matrix = scene.create_matrix(rows=20, cols=20, spacing=0.38)

palette = get_palette("ANGLO_FUTURIST")

def frame(t):
    for r in range(matrix.rows):
        for c in range(matrix.cols):
            pixel = matrix.get(r, c)
            if not pixel:
                continue
                
            x, y = pixel.position.x, pixel.position.y
            dist = np.sqrt(x*x + y*y)
            
            # Procedural radial ripple + continuous noise
            ripple = np.sin(dist * 2.4 - t * 4.0)
            noise_val = noise2d(x * 0.8, y * 0.8 + t * 0.5)
            field = 0.5 + 0.5 * (ripple * 0.6 + noise_val * 0.4)
            
            # Map field to palette gradient
            pixel.color = palette.evaluate(field, space="LAB")
            pixel.intensity = 0.2 + 0.8 * (field ** 1.8)
`
  },
  {
    id: 'slice_3_audio_reactive',
    name: '3. Audio Spectrum & Beat Rig (Slice 3)',
    category: 'Vertical Slice',
    description: 'Real-time FFT audio analysis driving sub-bass kicks, mid-range washes, and treble strobe bursts.',
    code: `# AARDVARK LUMEN - VERTICAL SLICE 3: AUDIO-REACTIVE ILLUMINATION
# kick -> flash | bass -> intensity | snare -> colour change | treble -> beam

scene = LumenScene("Audio Arena")

# Stage configuration: 4 Moving Beams + Center Wash + 2 Blinders
beams = [scene.create_light(f"beam_{i}", f"Beam {i}", "BEAM") for i in range(4)]
for i, b in enumerate(beams):
    b.position = ((i - 1.5) * 2.8, 5.0, -1.0)
    b.beam_angle = 12.0

center_wash = scene.create_light("center_wash", "Center Wash", "WASH")
center_wash.position = (0.0, 5.5, 0.0)
center_wash.beam_angle = 75.0

blinder_left = scene.create_light("blinder_l", "Blinder Left", "AREA")
blinder_left.position = (-5.0, 3.0, 0.0)

blinder_right = scene.create_light("blinder_r", "Blinder Right", "AREA")
blinder_right.position = (5.0, 3.0, 0.0)

def frame(t):
    # Retrieve real-time audio features (mic or synthesizer)
    bass = audio.bass
    mid = audio.mid
    treble = audio.treble
    is_beat = audio.is_beat
    centroid = audio.spectral_centroid
    
    # Bass drives moving head position & intensity
    for i, b in enumerate(beams):
        pan = np.sin(t * 1.5 + i * 0.8) * 45
        tilt = -15 + np.cos(t * 2.0 + i * 0.8) * 35
        b.rotation = (tilt, pan, 0)
        b.intensity = 0.3 + bass * 1.5
        b.color = Color.from_hsv((centroid + i * 0.25) % 1.0, 1.0, 1.0)
        
    # Mid-range drives ambient wash color temperature & brightness
    wash_kelvin = 2700 + mid * 4000
    center_wash.color = Color.from_kelvin(wash_kelvin)
    center_wash.intensity = 0.5 + mid * 0.9
    
    # Transient Beat Onset triggers blinder flashes
    if is_beat:
        blinder_left.intensity = 2.5
        blinder_left.color = Color.from_kelvin(3200)
        blinder_right.intensity = 2.5
        blinder_right.color = Color.from_kelvin(3200)
    else:
        blinder_left.intensity *= 0.82
        blinder_right.intensity *= 0.82
`
  },
  {
    id: 'slice_4_dmx_multiverse',
    name: '4. Physical DMX Multi-Universe Rig (Slice 4)',
    category: 'Vertical Slice',
    description: 'DMX512 universe patching with 16-channel moving heads, RGBW washes, and Art-Net packet dispatcher.',
    code: `# AARDVARK LUMEN - VERTICAL SLICE 4: MULTI-UNIVERSE DMX RIG
# Virtual Light -> Colour Transform -> Fixture Profile -> DMX Channels

scene = LumenScene("DMX Main Stage")

# Patch 6 Moving Heads across Universe 1 (16 channels each)
moving_heads = []
for i in range(6):
    mh = scene.create_light(f"mh_{i}", f"Robe Pointe #{i+1}", "SPOT")
    mh.channel_mode = "MOVING_HEAD_16CH"
    mh.dmx_universe = 1
    mh.dmx_address = 1 + (i * 16)
    mh.position = ((i - 2.5) * 1.8, 4.5, 0.5)
    mh.beam_angle = 16.0
    moving_heads.append(mh)

def frame(t):
    for i, mh in enumerate(moving_heads):
        # Coordinated aerial ballyhoo fan motion
        fan_offset = (i - 2.5) * 18.0
        pan = np.sin(t * 1.8) * 40.0 + fan_offset
        tilt = np.cos(t * 2.2 + i * 0.4) * 35.0 - 20.0
        mh.rotation = (tilt, pan, 0)
        
        # Color chase across universe
        chase_phase = (t * 2.0 - i * 0.6) % 6.0
        if chase_phase < 1.0:
            mh.color = Color.rgb(255, 0, 100) # Hot Pink
            mh.intensity = 1.4
        else:
            mh.color = Color.rgb(0, 220, 255) # Cyan Wash
            mh.intensity = 0.6
`
  },
  {
    id: 'slice_5_anglo_futurist',
    name: '5. Anglo-Futurist Architectural Rig (Slice 5)',
    category: 'Design Archetype',
    description: 'Curated architectural lighting using graphite, brushed aluminium, warm ivory, deep blue, and radiant amber.',
    code: `# AARDVARK LUMEN - ANGLO-FUTURIST ILLUMINATION ARCHETYPE
# Graphite, Brushed Aluminium, Warm Ivory, Deep Royal Blue, Radiant Amber

scene = LumenScene("Anglo-Futurist Pavilion")

palette = get_palette("ANGLO_FUTURIST")

# Ceiling Pylons (Ivory & Amber)
ceiling_lights = [scene.create_light(f"pylon_{i}", f"Pylon {i}", "AREA") for i in range(4)]
for i, cl in enumerate(ceiling_lights):
    cl.position = ((i - 1.5) * 3.2, 5.2, (i % 2 - 0.5) * 2.0)
    cl.beam_angle = 90.0

# Accent Spotlights (Royal Blue & Amber)
accent_spots = [scene.create_light(f"accent_{i}", f"Accent {i}", "SPOT") for i in range(4)]
for i, ac in enumerate(accent_spots):
    ac.position = ((i - 1.5) * 2.6, 3.8, 2.5)
    ac.target = ((i - 1.5) * 1.8, 0.0, -1.0)
    ac.beam_angle = 20.0
    ac.beam_softness = 0.6

def frame(t):
    # Elegant, slow rhythmic breathing
    breathe = 0.5 + 0.5 * np.sin(t * 0.8)
    
    # Ceiling pylons bathed in warm ivory and deep tungsten
    for i, cl in enumerate(ceiling_lights):
        cl.color = Color.from_kelvin(2400 + 800 * np.sin(t * 0.5 + i))
        cl.intensity = 0.6 + 0.3 * np.cos(t * 0.7 + i)
        
    # High-contrast architectural accents in Royal Blue and Amber
    for i, ac in enumerate(accent_spots):
        if i % 2 == 0:
            ac.color = Color.rgb(14, 56, 122) # Deep Royal Blue
            ac.intensity = 0.8 + 0.4 * np.sin(t * 1.2 + i)
        else:
            ac.color = Color.rgb(235, 150, 35) # Radiant Amber
            ac.intensity = 0.9 + 0.3 * np.cos(t * 1.2 + i)
`
  },
  {
    id: 'slice_6_telemetry_rocket',
    name: '6. ROCKETML Telemetry Reactor (Slice 6)',
    category: 'Vertical Slice',
    description: 'Live simulation state mapped to lighting (altitude -> position, speed -> intensity, chamber temp -> Kelvin).',
    code: `# AARDVARK LUMEN - VERTICAL SLICE 6: SIMULATION TELEMETRY
# ROCKET ALTITUDE -> POSITION | ENGINE TEMP -> KELVIN | ERROR -> ALERT RED

scene = LumenScene("Rocket Telemetry Rig")

# Chamber Exhaust Light (High-energy plasma)
exhaust_light = scene.create_light("exhaust", "Rocket Exhaust Plume", "SPOT")
exhaust_light.position = (0.0, 0.5, 0.0)
exhaust_light.beam_angle = 45.0

# Telemetry Status Perimeter
status_ring = [scene.create_light(f"status_{i}", f"Status {i}", "PIXEL") for i in range(8)]
for i, sl in enumerate(status_ring):
    angle = (i / 8.0) * np.pi * 2
    sl.position = (np.cos(angle) * 3.5, 3.5, np.sin(angle) * 3.5)

def frame(t):
    # Read live telemetry from ROCKETML.OS
    alt = telemetry.rocket_altitude_m
    speed = telemetry.rocket_speed_mps
    temp_c = telemetry.engine_temp_c
    traj_err = telemetry.trajectory_error_deg
    
    # Rocket exhaust color driven by combustion temperature
    kelvin = np.clip(temp_c + 273, 1600, 6500)
    exhaust_light.color = Color.from_kelvin(kelvin)
    exhaust_light.intensity = 0.8 + (speed / 2400.0) * 1.8
    
    # Exhaust position rises with rocket ascent phase
    exhaust_light.position = (0.0, 1.0 + (alt % 10000) / 2500.0, 0.0)
    
    # Perimeter status lights indicate trajectory health
    for i, sl in enumerate(status_ring):
        if traj_err > 1.2:
            # Trajectory deviation alert strobe
            sl.color = Color.rgb(255, 30, 30)
            sl.intensity = 1.8 if (int(t * 10) % 2 == 0) else 0.1
        else:
            # Nominal ascent cyan-green chase
            phase = (t * 4.0 - i) % 8.0
            sl.color = Color.rgb(0, 255, 140)
            sl.intensity = 1.0 if phase < 1.5 else 0.2
`
  },
  {
    id: 'slice_7_fire_lightning',
    name: '7. Atmospheric Fire & Lightning (Physics)',
    category: 'Simulation',
    description: 'Dual-frequency noise Planckian fire combustion coupled with deterministic lightning strikes.',
    code: `# AARDVARK LUMEN - PROCEDURAL FIRE & LIGHTNING SIMULATION

scene = LumenScene("Atmospheric Forge")

# Fire emitters
fire_main = scene.create_light("fire_main", "Braziers Flame", "POINT")
fire_main.position = (-1.5, 1.2, 0.0)
fire_main.range = 8.0

fire_secondary = scene.create_light("fire_sec", "Secondary Flame", "POINT")
fire_secondary.position = (1.5, 1.2, 0.0)

# Sky lightning overhead blinder
sky_lightning = scene.create_light("lightning", "Sky Discharge", "DIRECTIONAL")
sky_lightning.position = (0.0, 8.0, 0.0)

def frame(t):
    # Procedural Fire (dual frequency noise + Kelvin blackbody 1600-2600K)
    f1 = procedural_fire(base_intensity=1.1, t=t, flicker_amp=0.4, freq=14.0)
    fire_main.intensity = f1["intensity"]
    fire_main.color = Color.from_kelvin(f1["kelvin"])
    
    f2 = procedural_fire(base_intensity=0.9, t=t + 5.2, flicker_amp=0.35, freq=11.0)
    fire_secondary.intensity = f2["intensity"]
    fire_secondary.color = Color.from_kelvin(f2["kelvin"])
    
    # Procedural Lightning (deterministic pre-flash, main discharge, secondary dart)
    bolt = procedural_lightning(t=t, strike_interval=5.0)
    if bolt["is_active"]:
        sky_lightning.enabled = True
        sky_lightning.intensity = bolt["intensity"]
        sky_lightning.color = bolt["color"]
    else:
        sky_lightning.enabled = False
`
  }
];

export class PythonRuntime {
  private compiledFrameFn: ((t: number) => void) | null = null;
  public lastLogs: string[] = [];

  compileAndRun(
    code: string,
    scene: LumenScene,
    audioFeatures: AudioFeatures,
    telemetry: TelemetryDataStream
  ): ExecutionResult {
    const startTime = performance.now();
    const logs: string[] = [];
    this.lastLogs = logs;

    try {
      // Clear existing scene state if new setup is defined
      const log = (msg: any) => {
        logs.push(typeof msg === 'object' ? JSON.stringify(msg) : String(msg));
      };

      // Math helper namespace
      const np = {
        sin: Math.sin,
        cos: Math.cos,
        tan: Math.tan,
        sqrt: Math.sqrt,
        abs: Math.abs,
        clip: (v: number, min: number, max: number) => Math.max(min, Math.min(max, v)),
        pi: Math.PI,
      };

      // Transpile Python syntax nuances into runnable JS/TS
      // 1. Convert `range(n)` to JS Array
      // 2. Convert `f"..."` formatting or Python tuples/dictionaries
      // 3. Convert `for x in range(y):` to JS loops or use an evaluation sandbox
      
      const jsTranspiled = this.transpilePythonToJS(code);

      // Create evaluation context
      const context = {
        scene,
        LumenScene: (name: string) => {
          scene.name = name;
          scene.lights.clear();
          return scene;
        },
        Color: LumenColor,
        rgb: (r: number, g: number, b: number, a: number = 1) => LumenColor.rgb(r, g, b, a),
        from_hsv: (h: number, s: number, v: number) => LumenColor.from_hsv(h, s, v),
        from_kelvin: (k: number) => LumenColor.from_kelvin(k),
        from_wavelength: (wl: number) => LumenColor.from_wavelength(wl),
        get_palette: (id: string) => {
          const pal = LUMEN_PALETTES[id] || LUMEN_PALETTES.ANGLO_FUTURIST;
          const stops = pal.colors.map((c, i) => ({ pos: i / (pal.colors.length - 1), color: c }));
          return new LumenGradient(stops);
        },
        noise2d: (x: number, y: number) => {
          const fn = new FastNoise();
          return fn.noise2D(x, y);
        },
        procedural_fire: (opts: any) => {
          const res = ProceduralFire.evaluate(opts.base_intensity || 1.0, opts.t || 0, opts.flicker_amp || 0.35, opts.freq || 12.0);
          return { intensity: res.intensity, kelvin: res.kelvin, color: res.color };
        },
        procedural_lightning: (opts: any) => {
          const res = ProceduralLightning.evaluate(opts.t || 0, opts.strike_interval || 6.0);
          return { is_active: res.isActive, intensity: res.intensity, color: res.ambientColor };
        },
        audio: {
          rms: audioFeatures.rms,
          bass: audioFeatures.bass,
          mid: audioFeatures.mid,
          treble: audioFeatures.treble,
          is_beat: audioFeatures.isBeat,
          spectral_centroid: audioFeatures.spectralCentroid,
        },
        telemetry: {
          rocket_altitude_m: telemetry.rocketAltitudeMeters,
          rocket_speed_mps: telemetry.rocketSpeedMps,
          engine_temp_c: telemetry.engineTemperatureC,
          trajectory_error_deg: telemetry.trajectoryErrorDegrees,
          turbomach_rpm: telemetry.turbomachineryRpm,
          refinery_pressure_bar: telemetry.refineryPressureBar,
        },
        np,
        print: log,
        console: { log }
      };

      // Wrap and evaluate setup
      const runner = new Function(...Object.keys(context), `
        "use strict";
        let frameFn = null;
        ${jsTranspiled}
        if (typeof frame === 'function') {
          frameFn = frame;
        }
        return frameFn;
      `);

      const frameFn = runner(...Object.values(context));
      this.compiledFrameFn = frameFn;

      const elapsed = performance.now() - startTime;
      logs.push(`Compilation successful in ${elapsed.toFixed(2)}ms. Active fixtures: ${scene.getAllLights().length}`);

      return {
        success: true,
        logs,
        executionTimeMs: elapsed
      };
    } catch (err: any) {
      const elapsed = performance.now() - startTime;
      logs.push(`Runtime Error: ${err.message}`);
      return {
        success: false,
        logs,
        error: err.message,
        executionTimeMs: elapsed
      };
    }
  }

  evaluateFrame(
    t: number,
    scene: LumenScene,
    audioFeatures: AudioFeatures,
    telemetry: TelemetryDataStream
  ) {
    if (!this.compiledFrameFn) return;

    try {
      const np = {
        sin: Math.sin,
        cos: Math.cos,
        tan: Math.tan,
        sqrt: Math.sqrt,
        abs: Math.abs,
        clip: (v: number, min: number, max: number) => Math.max(min, Math.min(max, v)),
        pi: Math.PI,
      };

      // Call the compiled frame function
      this.compiledFrameFn(t);
    } catch (err) {
      // Avoid spamming frame errors on every tick
    }
  }

  private transpilePythonToJS(pyCode: string): string {
    // Simple robust Python DSL transpiler to Javascript
    let js = pyCode;

    // Convert comments
    js = js.replace(/#.*$/gm, (match) => `// ${match.slice(1)}`);

    // Convert True / False / None
    js = js.replace(/\bTrue\b/g, 'true')
           .replace(/\bFalse\b/g, 'false')
           .replace(/\bNone\b/g, 'null');

    // Convert range(N) or range(A, B) in for loops
    // for i in range(10): -> for (let i = 0; i < 10; i++) {
    js = js.replace(/for\s+([a-zA-Z0-9_]+)\s+in\s+range\(([^)]+)\):/g, (match, varName, rangeArgs) => {
      const args = rangeArgs.split(',').map((s: string) => s.trim());
      if (args.length === 1) {
        return `for (let ${varName} = 0; ${varName} < ${args[0]}; ${varName}++) {`;
      } else if (args.length === 2) {
        return `for (let ${varName} = ${args[0]}; ${varName} < ${args[1]}; ${varName}++) {`;
      }
      return match;
    });

    // for i, item in enumerate(list): -> for (let i = 0; i < list.length; i++) { const item = list[i];
    js = js.replace(/for\s+([a-zA-Z0-9_]+),\s*([a-zA-Z0-9_]+)\s+in\s+enumerate\(([^)]+)\):/g, (match, idxVar, itemVar, listVar) => {
      return `for (let ${idxVar} = 0; ${idxVar} < ${listVar}.length; ${idxVar}++) { const ${itemVar} = ${listVar}[${idxVar}];`;
    });

    // for item in list: -> for (const item of list) {
    js = js.replace(/for\s+([a-zA-Z0-9_]+)\s+in\s+([a-zA-Z0-9_\.]+):/g, (match, itemVar, listVar) => {
      return `for (const ${itemVar} of ${listVar}) {`;
    });

    // Convert if / elif / else
    js = js.replace(/elif\s+([^:]+):/g, '} else if ($1) {')
           .replace(/if\s+([^:]+):/g, 'if ($1) {')
           .replace(/else\s*:/g, '} else {');

    // Convert def frame(t): -> function frame(t) {
    js = js.replace(/def\s+([a-zA-Z0-9_]+)\(([^)]*)\):/g, 'function $1($2) {');

    // Convert Python tuple coordinates to object or arrays: (x, y, z)
    // light.position = (1, 2, 3) -> light.position = { x: 1, y: 2, z: 3 }
    js = js.replace(/\.position\s*=\s*\(\s*([^,]+),\s*([^,]+),\s*([^)]+)\)/g, '.position = { x: $1, y: $2, z: $3 }');
    js = js.replace(/\.target\s*=\s*\(\s*([^,]+),\s*([^,]+),\s*([^)]+)\)/g, '.target = { x: $1, y: $2, z: $3 }');
    js = js.replace(/\.rotation\s*=\s*\(\s*([^,]+),\s*([^,]+),\s*([^)]+)\)/g, '.rotation = { x: $1, y: $2, z: $3 }');

    // Python power operator ** -> Math.pow
    js = js.replace(/([a-zA-Z0-9_\.]+)\s*\*\*\s*([a-zA-Z0-9_\.]+)/g, 'Math.pow($1, $2)');

    // Indentation block closer heuristic for Python blocks
    const lines = js.split('\n');
    const resultLines: string[] = [];
    const indentStack: number[] = [0];

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (!line.trim()) {
        resultLines.push(line);
        continue;
      }

      const indent = line.search(/\S/);
      while (indentStack.length > 1 && indent < indentStack[indentStack.length - 1]) {
        indentStack.pop();
        resultLines.push(' '.repeat(indentStack[indentStack.length - 1]) + '}');
      }

      resultLines.push(line);

      if (line.trim().endsWith('{')) {
        indentStack.push(indent + 4);
      }
    }

    while (indentStack.length > 1) {
      indentStack.pop();
      resultLines.push('}');
    }

    return resultLines.join('\n');
  }
}
