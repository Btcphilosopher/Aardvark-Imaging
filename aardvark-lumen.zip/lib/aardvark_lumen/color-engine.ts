// AARDVARK LUMEN - Color Science & Colorimetric Engine
// Supports: RGB, RGBA, HSV, HSL, HSLuv, CIE XYZ, CIE Lab, CCT/Kelvin, Wavelength (380-780nm), Palettes, Gradients, RGBW/RGBAW

export interface RGB {
  r: number; // 0 - 255 or 0 - 1
  g: number;
  b: number;
  a?: number;
}

export interface HSV {
  h: number; // 0 - 360
  s: number; // 0 - 1
  v: number; // 0 - 1
}

export interface HSL {
  h: number; // 0 - 360
  s: number; // 0 - 1
  l: number; // 0 - 1
}

export interface XYZ {
  x: number;
  y: number;
  z: number;
}

export interface Lab {
  l: number; // 0 - 100
  a: number; // -128 to 127
  b: number; // -128 to 127
}

export interface FixtureChannels {
  red: number;
  green: number;
  blue: number;
  white?: number;
  amber?: number;
  uv?: number;
  dimmer?: number;
}

export class LumenColor {
  public r: number; // 0.0 - 1.0 (linear internal)
  public g: number; // 0.0 - 1.0
  public b: number; // 0.0 - 1.0
  public a: number; // 0.0 - 1.0

  constructor(r: number = 1, g: number = 1, b: number = 1, a: number = 1) {
    this.r = Math.max(0, r);
    this.g = Math.max(0, g);
    this.b = Math.max(0, b);
    this.a = Math.max(0, Math.min(1, a));
  }

  static rgb(r: number, g: number, b: number, a: number = 1): LumenColor {
    // If integer 0-255 passed
    const rf = r > 1 ? r / 255.0 : r;
    const gf = g > 1 ? g / 255.0 : g;
    const bf = b > 1 ? b / 255.0 : b;
    return new LumenColor(rf, gf, bf, a);
  }

  static rgba(r: number, g: number, b: number, a: number): LumenColor {
    return LumenColor.rgb(r, g, b, a);
  }

  static from_hsv(h: number, s: number, v: number, a: number = 1): LumenColor {
    // h in [0, 1] or [0, 360]
    let hNorm = h > 1 ? (h % 360) / 360 : h % 1;
    if (hNorm < 0) hNorm += 1;
    const sClamped = Math.max(0, Math.min(1, s));
    const vClamped = Math.max(0, Math.min(1, v));

    const i = Math.floor(hNorm * 6);
    const f = hNorm * 6 - i;
    const p = vClamped * (1 - sClamped);
    const q = vClamped * (1 - f * sClamped);
    const t = vClamped * (1 - (1 - f) * sClamped);

    let r = 0, g = 0, b = 0;
    switch (i % 6) {
      case 0: r = vClamped; g = t; b = p; break;
      case 1: r = q; g = vClamped; b = p; break;
      case 2: r = p; g = vClamped; b = t; break;
      case 3: r = p; g = q; b = vClamped; break;
      case 4: r = t; g = p; b = vClamped; break;
      case 5: r = vClamped; g = p; b = q; break;
    }
    return new LumenColor(r, g, b, a);
  }

  static from_hsl(h: number, s: number, l: number, a: number = 1): LumenColor {
    let hNorm = h > 1 ? (h % 360) / 360 : h % 1;
    if (hNorm < 0) hNorm += 1;
    const sC = Math.max(0, Math.min(1, s));
    const lC = Math.max(0, Math.min(1, l));

    if (sC === 0) {
      return new LumenColor(lC, lC, lC, a);
    }

    const hue2rgb = (p: number, q: number, t: number) => {
      let tc = t;
      if (tc < 0) tc += 1;
      if (tc > 1) tc -= 1;
      if (tc < 1 / 6) return p + (q - p) * 6 * tc;
      if (tc < 1 / 2) return q;
      if (tc < 2 / 3) return p + (q - p) * (2 / 3 - tc) * 6;
      return p;
    };

    const q = lC < 0.5 ? lC * (1 + sC) : lC + sC - lC * sC;
    const p = 2 * lC - q;
    const r = hue2rgb(p, q, hNorm + 1 / 3);
    const g = hue2rgb(p, q, hNorm);
    const b = hue2rgb(p, q, hNorm - 1 / 3);
    return new LumenColor(r, g, b, a);
  }

  // Correlated Colour Temperature (Kelvin blackbody approximation - Tanner Helland algorithm / Planckian)
  static from_kelvin(kelvin: number, a: number = 1): LumenColor {
    const temp = Math.max(1000, Math.min(40000, kelvin)) / 100;
    let r = 0;
    let g = 0;
    let b = 0;

    // Red calculation
    if (temp <= 66) {
      r = 255;
    } else {
      r = temp - 60;
      r = 329.698727446 * Math.pow(r, -0.1332047592);
      if (r < 0) r = 0;
      if (r > 255) r = 255;
    }

    // Green calculation
    if (temp <= 66) {
      g = temp;
      g = 99.4708025861 * Math.log(g) - 161.1195681661;
      if (g < 0) g = 0;
      if (g > 255) g = 255;
    } else {
      g = temp - 60;
      g = 288.1221695283 * Math.pow(g, -0.0755148492);
      if (g < 0) g = 0;
      if (g > 255) g = 255;
    }

    // Blue calculation
    if (temp >= 66) {
      b = 255;
    } else if (temp <= 19) {
      b = 0;
    } else {
      b = temp - 10;
      b = 138.5177312231 * Math.log(b) - 305.0447927307;
      if (b < 0) b = 0;
      if (b > 255) b = 255;
    }

    return new LumenColor(r / 255.0, g / 255.0, b / 255.0, a);
  }

  // Physical wavelength approximation (380nm to 780nm)
  static from_wavelength(wavelengthNm: number, a: number = 1): LumenColor {
    const wl = Math.max(380, Math.min(780, wavelengthNm));
    let r = 0, g = 0, b = 0;

    if (wl >= 380 && wl < 440) {
      r = -(wl - 440) / (440 - 380);
      g = 0.0;
      b = 1.0;
    } else if (wl >= 440 && wl < 490) {
      r = 0.0;
      g = (wl - 440) / (490 - 440);
      b = 1.0;
    } else if (wl >= 490 && wl < 510) {
      r = 0.0;
      g = 1.0;
      b = -(wl - 510) / (510 - 490);
    } else if (wl >= 510 && wl < 580) {
      r = (wl - 510) / (580 - 510);
      g = 1.0;
      b = 0.0;
    } else if (wl >= 580 && wl < 645) {
      r = 1.0;
      g = -(wl - 645) / (645 - 580);
      b = 0.0;
    } else if (wl >= 645 && wl <= 780) {
      r = 1.0;
      g = 0.0;
      b = 0.0;
    }

    // Intensity falloff at the visual limits of human retina
    let factor = 0;
    if (wl >= 380 && wl < 420) {
      factor = 0.3 + (0.7 * (wl - 380)) / (420 - 380);
    } else if (wl >= 420 && wl <= 700) {
      factor = 1.0;
    } else if (wl > 700 && wl <= 780) {
      factor = 0.3 + (0.7 * (780 - wl)) / (780 - 700);
    }

    return new LumenColor(r * factor, g * factor, b * factor, a);
  }

  // CIE XYZ space conversion
  static from_xyz(x: number, y: number, z: number, a: number = 1): LumenColor {
    // sRGB matrix transformation from D65
    const r = x * 3.2406 + y * -1.5372 + z * -0.4986;
    const g = x * -0.9689 + y * 1.8758 + z * 0.0415;
    const b = x * 0.0557 + y * -0.2040 + z * 1.0570;
    return new LumenColor(Math.max(0, r), Math.max(0, g), Math.max(0, b), a);
  }

  // CIE Lab conversion
  static from_lab(l: number, aVal: number, bVal: number, alpha: number = 1): LumenColor {
    let y = (l + 16) / 116;
    let x = aVal / 500 + y;
    let z = y - bVal / 200;

    const x3 = Math.pow(x, 3);
    const y3 = Math.pow(y, 3);
    const z3 = Math.pow(z, 3);

    x = x3 > 0.008856 ? x3 : (x - 16 / 116) / 7.787;
    y = y3 > 0.008856 ? y3 : (y - 16 / 116) / 7.787;
    z = z3 > 0.008856 ? z3 : (z - 16 / 116) / 7.787;

    // D65 reference white
    x *= 0.95047;
    y *= 1.00000;
    z *= 1.08883;

    return LumenColor.from_xyz(x, y, z, alpha);
  }

  // Mixing in linear space
  mix(other: LumenColor, factor: number = 0.5): LumenColor {
    const t = Math.max(0, Math.min(1, factor));
    return new LumenColor(
      this.r * (1 - t) + other.r * t,
      this.g * (1 - t) + other.g * t,
      this.b * (1 - t) + other.b * t,
      this.a * (1 - t) + other.a * t
    );
  }

  // Perceptual Lab mixing
  mix_lab(other: LumenColor, factor: number = 0.5): LumenColor {
    const lab1 = this.to_lab();
    const lab2 = other.to_lab();
    const t = Math.max(0, Math.min(1, factor));
    const mixL = lab1.l * (1 - t) + lab2.l * t;
    const mixA = lab1.a * (1 - t) + lab2.a * t;
    const mixB = lab1.b * (1 - t) + lab2.b * t;
    return LumenColor.from_lab(mixL, mixA, mixB, this.a * (1 - t) + other.a * t);
  }

  // HSV interpolation for smooth hue rotations
  mix_hsv(other: LumenColor, factor: number = 0.5): LumenColor {
    const hsv1 = this.to_hsv();
    const hsv2 = other.to_hsv();
    const t = Math.max(0, Math.min(1, factor));

    // Shortest hue arc
    let dh = hsv2.h - hsv1.h;
    if (dh > 180) dh -= 360;
    if (dh < -180) dh += 360;
    const h = (hsv1.h + dh * t + 360) % 360;
    const s = hsv1.s * (1 - t) + hsv2.s * t;
    const v = hsv1.v * (1 - t) + hsv2.v * t;
    return LumenColor.from_hsv(h / 360, s, v, this.a * (1 - t) + other.a * t);
  }

  scale(factor: number): LumenColor {
    return new LumenColor(this.r * factor, this.g * factor, this.b * factor, this.a);
  }

  to_hex(): string {
    const r8 = Math.min(255, Math.max(0, Math.round(this.r * 255)));
    const g8 = Math.min(255, Math.max(0, Math.round(this.g * 255)));
    const b8 = Math.min(255, Math.max(0, Math.round(this.b * 255)));
    return `#${r8.toString(16).padStart(2, '0')}${g8.toString(16).padStart(2, '0')}${b8.toString(16).padStart(2, '0')}`;
  }

  to_rgb_array(): [number, number, number] {
    return [
      Math.min(255, Math.max(0, Math.round(this.r * 255))),
      Math.min(255, Math.max(0, Math.round(this.g * 255))),
      Math.min(255, Math.max(0, Math.round(this.b * 255)))
    ];
  }

  to_float_array(): [number, number, number, number] {
    return [this.r, this.g, this.b, this.a];
  }

  to_hsv(): HSV {
    const r = this.r, g = this.g, b = this.b;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    const d = max - min;
    let h = 0;
    const s = max === 0 ? 0 : d / max;
    const v = max;

    if (max !== min) {
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        case b: h = (r - g) / d + 4; break;
      }
      h /= 6;
    }
    return { h: h * 360, s, v };
  }

  to_lab(): Lab {
    // sRGB -> Linear -> XYZ -> Lab
    const toLinear = (c: number) => c > 0.04045 ? Math.pow((c + 0.055) / 1.055, 2.4) : c / 12.92;
    const lr = toLinear(this.r);
    const lg = toLinear(this.g);
    const lb = toLinear(this.b);

    const x = (lr * 0.4124 + lg * 0.3576 + lb * 0.1805) / 0.95047;
    const y = (lr * 0.2126 + lg * 0.7152 + lb * 0.0722) / 1.00000;
    const z = (lr * 0.0193 + lg * 0.1192 + lb * 0.9505) / 1.08883;

    const f = (t: number) => t > 0.008856 ? Math.pow(t, 1 / 3) : 7.787 * t + 16 / 116;
    const fx = f(x), fy = f(y), fz = f(z);

    return {
      l: 116 * fy - 16,
      a: 500 * (fx - fy),
      b: 200 * (fy - fz)
    };
  }

  // Multi-channel fixture translation (e.g. RGB to RGBW or RGBAW)
  to_fixture_channels(mode: 'RGB' | 'RGBW' | 'RGBA' | 'RGBAW' | 'RGBWW'): FixtureChannels {
    const r = Math.min(255, Math.round(this.r * 255));
    const g = Math.min(255, Math.round(this.g * 255));
    const b = Math.min(255, Math.round(this.b * 255));

    if (mode === 'RGB') {
      return { red: r, green: g, blue: b };
    }
    if (mode === 'RGBW') {
      // Extract white component (minimum of R, G, B)
      const w = Math.min(r, g, b);
      return {
        red: r - w,
        green: g - w,
        blue: b - w,
        white: w
      };
    }
    if (mode === 'RGBA') {
      // Amber component extraction
      const amber = Math.min(r, Math.round(g * 0.6));
      return {
        red: r - amber,
        green: Math.max(0, g - Math.round(amber * 0.6)),
        blue: b,
        amber: amber
      };
    }
    if (mode === 'RGBAW' || mode === 'RGBWW') {
      const minVal = Math.min(r, g, b);
      const w = Math.round(minVal * 0.8);
      const amber = Math.max(0, Math.min(r - w, Math.round(g * 0.5)));
      return {
        red: Math.max(0, r - w - amber),
        green: Math.max(0, g - w - Math.round(amber * 0.5)),
        blue: Math.max(0, b - w),
        white: w,
        amber: amber
      };
    }
    return { red: r, green: g, blue: b };
  }

  clone(): LumenColor {
    return new LumenColor(this.r, this.g, this.b, this.a);
  }
}

// Built-in Curated Palettes (Anglo-Futurist, Sunset, Neon City, Aerospace, Cyber, etc.)
export interface PaletteItem {
  id: string;
  name: string;
  category: string;
  description: string;
  colors: LumenColor[];
}

export const LUMEN_PALETTES: Record<string, PaletteItem> = {
  ANGLO_FUTURIST: {
    id: 'ANGLO_FUTURIST',
    name: 'Anglo-Futurist',
    category: 'Architectural',
    description: 'Graphite, brushed aluminium, warm ivory, deep royal blue, muted red and radiant amber.',
    colors: [
      LumenColor.rgb(26, 28, 32),    // Graphite Dark
      LumenColor.rgb(198, 204, 212), // Brushed Aluminium
      LumenColor.rgb(245, 240, 228), // Warm Ivory
      LumenColor.rgb(14, 56, 122),   // Deep Royal Blue
      LumenColor.rgb(180, 42, 42),   // Muted Heritage Red
      LumenColor.rgb(235, 150, 35),  // Radiant Amber
    ]
  },
  NEON_CITY: {
    id: 'NEON_CITY',
    name: 'Neon City',
    category: 'Cybernetic',
    description: 'High-contrast cyan, magenta, electric violet, deep obsidian, and solar flare.',
    colors: [
      LumenColor.rgb(0, 245, 255),   // Electric Cyan
      LumenColor.rgb(255, 0, 128),   // Hot Magenta
      LumenColor.rgb(140, 0, 255),   // Ultraviolet
      LumenColor.rgb(10, 10, 20),    // Obsidian
      LumenColor.rgb(255, 220, 0),   // Solar Yellow
    ]
  },
  BLUE_HOUR: {
    id: 'BLUE_HOUR',
    name: 'Blue Hour (L\'Heure Bleue)',
    category: 'Atmospheric',
    description: 'Deep twilight indigo, cobalt, horizon lavender, and dusk amber accent.',
    colors: [
      LumenColor.rgb(10, 18, 50),
      LumenColor.rgb(28, 52, 110),
      LumenColor.rgb(65, 95, 160),
      LumenColor.rgb(130, 125, 175),
      LumenColor.rgb(230, 140, 60),
    ]
  },
  AEROSPACE: {
    id: 'AEROSPACE',
    name: 'Aerospace & Telemetry',
    category: 'Industrial',
    description: 'Cockpit HUD green, caution amber, cryo blue, warning crimson, titanium grey.',
    colors: [
      LumenColor.rgb(0, 255, 136),   // HUD Green
      LumenColor.rgb(0, 170, 255),   // Cryo Oxygen Blue
      LumenColor.rgb(255, 170, 0),   // Caution Amber
      LumenColor.rgb(255, 40, 40),   // Warning Abort Red
      LumenColor.rgb(170, 180, 195), // Titanium Matrix
    ]
  },
  SUNSET: {
    id: 'SUNSET',
    name: 'Solar Sunset',
    category: 'Natural',
    description: 'Crimson sun, burnished copper, dusk gold, and violet stratosphere.',
    colors: [
      LumenColor.rgb(255, 60, 40),
      LumenColor.rgb(240, 120, 30),
      LumenColor.rgb(255, 195, 50),
      LumenColor.rgb(120, 40, 110),
      LumenColor.rgb(35, 15, 60),
    ]
  },
  CONCERT_RIG: {
    id: 'CONCERT_RIG',
    name: 'Concert Stage & Tour',
    category: 'Entertainment',
    description: 'Blinder warm-white 3200K, beam strobe white, pure wash cyan, and arena laser magenta.',
    colors: [
      LumenColor.from_kelvin(3200),
      LumenColor.rgb(255, 255, 255),
      LumenColor.rgb(0, 210, 255),
      LumenColor.rgb(255, 0, 90),
      LumenColor.rgb(255, 160, 0),
    ]
  },
  BLACKBODY_SPECTRUM: {
    id: 'BLACKBODY_SPECTRUM',
    name: 'Kelvin Blackbody Progression',
    category: 'Physical',
    description: 'Candle 1800K -> Warm Tungsten 2700K -> Halogen 3200K -> Daylight 5600K -> Blue Sky 10000K.',
    colors: [
      LumenColor.from_kelvin(1800),
      LumenColor.from_kelvin(2700),
      LumenColor.from_kelvin(3200),
      LumenColor.from_kelvin(5600),
      LumenColor.from_kelvin(10000),
    ]
  }
};

export class LumenGradient {
  public stops: { pos: number; color: LumenColor }[];

  constructor(stops: { pos: number; color: LumenColor }[]) {
    this.stops = [...stops].sort((a, b) => a.pos - b.pos);
  }

  evaluate(t: number, space: 'RGB' | 'HSV' | 'LAB' = 'RGB'): LumenColor {
    const clampedT = Math.max(0, Math.min(1, t));
    if (this.stops.length === 0) return new LumenColor(0, 0, 0);
    if (this.stops.length === 1) return this.stops[0].color.clone();

    if (clampedT <= this.stops[0].pos) return this.stops[0].color.clone();
    if (clampedT >= this.stops[this.stops.length - 1].pos) return this.stops[this.stops.length - 1].color.clone();

    for (let i = 0; i < this.stops.length - 1; i++) {
      const s0 = this.stops[i];
      const s1 = this.stops[i + 1];
      if (clampedT >= s0.pos && clampedT <= s1.pos) {
        const factor = (clampedT - s0.pos) / (s1.pos - s0.pos);
        if (space === 'LAB') return s0.color.mix_lab(s1.color, factor);
        if (space === 'HSV') return s0.color.mix_hsv(s1.color, factor);
        return s0.color.mix(s1.color, factor);
      }
    }
    return this.stops[0].color.clone();
  }
}
