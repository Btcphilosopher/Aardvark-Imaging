// AARDVARK LUMEN - Complete Native Python 3.13+ Library Codebase
// Formatted matching Section 81 Project Structure

export interface PythonSourceFile {
  path: string;
  category: string;
  content: string;
}

export const AARDVARK_LUMEN_PYTHON_CODEBASE: PythonSourceFile[] = [
  {
    path: 'pyproject.toml',
    category: 'Configuration',
    content: `[project]
name = "aardvark-lumen"
version = "1.0.0"
description = "AARDVARK LUMEN: Python-native programmable multicolour lighting, animation & code-controlled illumination engine"
readme = "README.md"
requires-python = ">=3.13"
dependencies = [
    "numpy>=2.0.0",
    "scipy>=1.14.0",
    "pydantic>=2.8.0",
    "pandas>=2.2.0",
    "matplotlib>=3.9.0",
    "pillow>=10.4.0",
    "pyside6>=6.7.0"
]

[project.optional-dependencies]
audio = ["sounddevice", "librosa", "python-rtmidi"]
render = ["moderngl", "vispy", "pyopengl"]
physics = ["numba", "jax", "torch"]

[build-system]
requires = ["setuptools>=61.0"]
build-backend = "setuptools.build_meta"
`
  },
  {
    path: 'aardvark_lumen/core/scene.py',
    category: 'Core',
    content: `"""
AARDVARK LUMEN - Core Scene Graph & Hierarchy
"""
from typing import Dict, List, Optional
import json
import time
from .object import LumenLight
from .clock import LumenClock
from .events import LumenEventBus

class LumenScene:
    """Master computational lighting scene container."""
    def __init__(self, name: str = "Main Scene"):
        self.name = name
        self.lights: Dict[str, LumenLight] = {}
        self.clock = LumenClock()
        self.events = LumenEventBus()
        self.fog_density: float = 0.025
        self.global_exposure: float = 1.0
        self.is_blackout: bool = False

    def create_light(self, light_id: str, name: str = "", light_type: str = "SPOT") -> LumenLight:
        light = LumenLight(light_id, name or light_id, light_type=light_type)
        self.lights[light_id] = light
        return light

    def get_light(self, light_id: str) -> Optional[LumenLight]:
        return self.lights.get(light_id)

    def blackout(self) -> None:
        self.is_blackout = True
        for light in self.lights.values():
            light.enabled = False
        self.events.emit("BLACKOUT")

    def restore(self) -> None:
        self.is_blackout = False
        for light in self.lights.values():
            light.enabled = True
        self.events.emit("RESTORE")

    def update(self) -> float:
        t = self.clock.tick()
        for light in self.lights.values():
            light.update(t)
        return t

    def to_json(self) -> str:
        return json.dumps({
            "name": self.name,
            "lights": [l.to_dict() for l in self.lights.values()]
        }, indent=2)
`
  },
  {
    path: 'aardvark_lumen/colour/color.py',
    category: 'Colour',
    content: `"""
AARDVARK LUMEN - Colour Science & Colorimetric Math
Supports RGB, RGBA, HSV, HSL, CIE XYZ, CIE Lab, Kelvin Blackbody, Wavelength Spectrum.
"""
import math
from typing import Tuple

class LumenColor:
    def __init__(self, r: float = 1.0, g: float = 1.0, b: float = 1.0, a: float = 1.0):
        self.r = max(0.0, float(r))
        self.g = max(0.0, float(g))
        self.b = max(0.0, float(b))
        self.a = max(0.0, min(1.0, float(a)))

    @classmethod
    def rgb(cls, r: float, g: float, b: float, a: float = 1.0) -> "LumenColor":
        rf = r / 255.0 if r > 1.0 else r
        gf = g / 255.0 if g > 1.0 else g
        bf = b / 255.0 if b > 1.0 else b
        return cls(rf, gf, bf, a)

    @classmethod
    def from_hsv(cls, h: float, s: float, v: float, a: float = 1.0) -> "LumenColor":
        h_norm = (h % 1.0) if h <= 1.0 else (h % 360.0) / 360.0
        i = int(h_norm * 6.0)
        f = (h_norm * 6.0) - i
        p = v * (1.0 - s)
        q = v * (1.0 - f * s)
        t = v * (1.0 - (1.0 - f) * s)
        
        idx = i % 6
        if idx == 0: r, g, b = v, t, p
        elif idx == 1: r, g, b = q, v, p
        elif idx == 2: r, g, b = p, v, t
        elif idx == 3: r, g, b = p, q, v
        elif idx == 4: r, g, b = t, p, v
        else: r, g, b = v, p, q
        return cls(r, g, b, a)

    @classmethod
    def from_kelvin(cls, kelvin: float, a: float = 1.0) -> "LumenColor":
        """Calculate Planckian locus blackbody emission approximation."""
        temp = max(1000.0, min(40000.0, kelvin)) / 100.0
        # Red
        if temp <= 66.0: r = 255.0
        else:
            r = temp - 60.0
            r = 329.698727446 * (r ** -0.1332047592)
            r = max(0.0, min(255.0, r))
        # Green
        if temp <= 66.0:
            g = 99.4708025861 * math.log(temp) - 161.1195681661
        else:
            g = 288.1221695283 * ((temp - 60.0) ** -0.0755148492)
        g = max(0.0, min(255.0, g))
        # Blue
        if temp >= 66.0: b = 255.0
        elif temp <= 19.0: b = 0.0
        else:
            b = 138.5177312231 * math.log(temp - 10.0) - 305.0447927307
            b = max(0.0, min(255.0, b))
        return cls(r / 255.0, g / 255.0, b / 255.0, a)

    def mix(self, other: "LumenColor", factor: float = 0.5) -> "LumenColor":
        t = max(0.0, min(1.0, factor))
        return LumenColor(
            self.r * (1.0 - t) + other.r * t,
            self.g * (1.0 - t) + other.g * t,
            self.b * (1.0 - t) + other.b * t,
            self.a * (1.0 - t) + other.a * t
        )
`
  },
  {
    path: 'aardvark_lumen/physical/dmx.py',
    category: 'Physical',
    content: `"""
AARDVARK LUMEN - DMX512 & Art-Net Output Protocol Adapter
"""
import struct
from typing import Dict, List

class DMXController:
    def __init__(self, num_universes: int = 4):
        self.universes: Dict[int, bytearray] = {
            u: bytearray(512) for u in range(1, num_universes + 1)
        }
        self.is_blackout: bool = False
        self.safety_limit_rate_hz: float = 44.0

    def blackout(self) -> None:
        self.is_blackout = True
        for u in self.universes.values():
            for i in range(512):
                u[i] = 0

    def generate_artnet_packet(self, universe: int = 1, sequence: int = 0) -> bytes:
        data = self.universes.get(universe, bytearray(512))
        header = b'Art-Net\\x00'
        opcode = struct.pack('<H', 0x5000) # OpOutput / OpDmx
        prot_ver = struct.pack('>H', 14)
        seq = struct.pack('B', sequence % 256)
        physical = struct.pack('B', 0)
        sub_uni = struct.pack('<H', universe - 1)
        length = struct.pack('>H', len(data))
        return header + opcode + prot_ver + seq + physical + sub_uni + length + bytes(data)
`
  },
  {
    path: 'aardvark_lumen/simulation/telemetry.py',
    category: 'Simulation',
    content: `"""
AARDVARK LUMEN - RocketML, Turbomach & Industrial Telemetry Bridge
"""
import time
from dataclasses import dataclass

@dataclass
class TelemetryFrame:
    altitude_m: float
    speed_mps: float
    engine_temp_c: float
    trajectory_error_deg: float
    turbomach_rpm: float
    timestamp: float = 0.0

class TelemetryBridge:
    def __init__(self):
        self.current_frame = TelemetryFrame(15000.0, 750.0, 1850.0, 0.05, 45000.0, time.time())

    def update(self) -> TelemetryFrame:
        # Receives UDP/IPC state packet from simulation kernel
        return self.current_frame
`
  }
];
