// AARDVARK LUMEN - Physical DMX512, Art-Net & sACN Multi-Universe Controller
import { LumenScene, LumenLight } from './scene-engine';
import { DMXUniverseState } from './types';

export interface ArtNetPacket {
  header: string; // "Art-Net\0"
  opCode: number; // 0x5000 (OpOutput / OpDmx)
  protVer: number; // 14
  sequence: number;
  physical: number;
  universe: number; // 0-indexed in ArtNet
  length: number; // 512
  data: Uint8Array;
  timestamp: number;
}

export class DMXController {
  public universes: Map<number, DMXUniverseState> = new Map();
  public isBlackout: boolean = false;
  public safetyMaxBrightness: number = 1.0; // 0.0 - 1.0 safety clamp
  public strobeRateLimitHz: number = 25.0; // Max allowed physical strobe rate
  public packetsSentTotal: number = 0;
  public lastPacket: ArtNetPacket | null = null;
  private sequenceCounter: number = 0;

  constructor(numUniverses: number = 4) {
    for (let u = 1; u <= numUniverses; u++) {
      this.universes.set(u, {
        universeNumber: u,
        channels: new Uint8Array(512),
        fps: 44,
        packetsSent: 0,
        isBlackout: false,
        safetyLimited: false
      });
    }
  }

  blackout() {
    this.isBlackout = true;
    for (const u of this.universes.values()) {
      u.isBlackout = true;
      u.channels.fill(0);
    }
  }

  restore() {
    this.isBlackout = false;
    for (const u of this.universes.values()) {
      u.isBlackout = false;
    }
  }

  updateFromScene(scene: LumenScene) {
    if (this.isBlackout || scene.isBlackout) {
      for (const u of this.universes.values()) {
        u.channels.fill(0);
      }
      return;
    }

    // Reset channels to 0 before mapping
    for (const u of this.universes.values()) {
      u.channels.fill(0);
    }

    const allLights = scene.getAllLights();
    for (const light of allLights) {
      if (!light.enabled) continue;

      const uState = this.universes.get(light.dmxUniverse);
      if (!uState) continue;

      const addr = light.dmxAddress - 1; // 0-indexed internally
      if (addr < 0 || addr >= 512) continue;

      const effIntensity = Math.min(this.safetyMaxBrightness, light.getEffectiveIntensity());
      const channels = light.color.to_fixture_channels(
        light.channelMode === 'MOVING_HEAD_16CH' ? 'RGBW' : (light.channelMode as any)
      );

      if (light.channelMode === 'DIMMER_ONLY') {
        uState.channels[addr] = Math.round(effIntensity * 255);
      } else if (light.channelMode === 'RGB') {
        if (addr + 2 < 512) {
          uState.channels[addr] = Math.round(channels.red * effIntensity);
          uState.channels[addr + 1] = Math.round(channels.green * effIntensity);
          uState.channels[addr + 2] = Math.round(channels.blue * effIntensity);
        }
      } else if (light.channelMode === 'RGBW') {
        if (addr + 3 < 512) {
          uState.channels[addr] = Math.round(channels.red * effIntensity);
          uState.channels[addr + 1] = Math.round(channels.green * effIntensity);
          uState.channels[addr + 2] = Math.round(channels.blue * effIntensity);
          uState.channels[addr + 3] = Math.round((channels.white || 0) * effIntensity);
        }
      } else if (light.channelMode === 'RGBA') {
        if (addr + 3 < 512) {
          uState.channels[addr] = Math.round(channels.red * effIntensity);
          uState.channels[addr + 1] = Math.round(channels.green * effIntensity);
          uState.channels[addr + 2] = Math.round(channels.blue * effIntensity);
          uState.channels[addr + 3] = Math.round((channels.amber || 0) * effIntensity);
        }
      } else if (light.channelMode === 'RGBAW') {
        if (addr + 4 < 512) {
          uState.channels[addr] = Math.round(channels.red * effIntensity);
          uState.channels[addr + 1] = Math.round(channels.green * effIntensity);
          uState.channels[addr + 2] = Math.round(channels.blue * effIntensity);
          uState.channels[addr + 3] = Math.round((channels.amber || 0) * effIntensity);
          uState.channels[addr + 4] = Math.round((channels.white || 0) * effIntensity);
        }
      } else if (light.channelMode === 'MOVING_HEAD_16CH') {
        // 16-channel profile:
        // Ch1: Pan Coarse, Ch2: Pan Fine, Ch3: Tilt Coarse, Ch4: Tilt Fine, Ch5: Speed,
        // Ch6: Dimmer, Ch7: Shutter/Strobe, Ch8: Red, Ch9: Green, Ch10: Blue, Ch11: White,
        // Ch12: Color Wheel, Ch13: Gobo, Ch14: Prism, Ch15: Focus, Ch16: Reset/Control
        if (addr + 15 < 512) {
          const panNorm = (light.rotation.y % 360 + 360) % 360 / 360;
          const tiltNorm = (light.rotation.x % 180 + 180) % 180 / 180;

          const pan16 = Math.round(panNorm * 65535);
          const tilt16 = Math.round(tiltNorm * 65535);

          uState.channels[addr + 0] = (pan16 >> 8) & 0xFF;  // Pan High
          uState.channels[addr + 1] = pan16 & 0xFF;         // Pan Low
          uState.channels[addr + 2] = (tilt16 >> 8) & 0xFF; // Tilt High
          uState.channels[addr + 3] = tilt16 & 0xFF;        // Tilt Low
          uState.channels[addr + 4] = 0;                    // Movement Speed (0 = fast)
          uState.channels[addr + 5] = Math.round(effIntensity * 255); // Master Dimmer
          uState.channels[addr + 6] = 255;                  // Shutter Open (no strobe)
          uState.channels[addr + 7] = Math.round(channels.red);
          uState.channels[addr + 8] = Math.round(channels.green);
          uState.channels[addr + 9] = Math.round(channels.blue);
          uState.channels[addr + 10] = Math.round(channels.white || 0);
          uState.channels[addr + 11] = 0;                   // Color wheel open
          uState.channels[addr + 12] = 0;                   // Gobo open
          uState.channels[addr + 13] = 0;                   // Prism off
          uState.channels[addr + 14] = 128;                 // Focus mid
          uState.channels[addr + 15] = 0;                   // Control normal
        }
      }
    }

    // Art-Net packet dispatch simulation
    for (const u of this.universes.values()) {
      u.packetsSent++;
      this.packetsSentTotal++;
    }

    const u1 = this.universes.get(1);
    if (u1) {
      this.sequenceCounter = (this.sequenceCounter + 1) % 256;
      this.lastPacket = {
        header: 'Art-Net\0',
        opCode: 0x5000,
        protVer: 14,
        sequence: this.sequenceCounter,
        physical: 0,
        universe: 0,
        length: 512,
        data: new Uint8Array(u1.channels),
        timestamp: Date.now()
      };
    }
  }
}
