// AARDVARK LUMEN - Simulation & Data Stream Integration
// Connects telemetry from ROCKETML.OS, TURBOMACH.OS, REFINERYCORE.OS, CIVITAS.OS to lighting parameters
import { TelemetryDataStream } from './types';
import { LumenColor } from './color-engine';

export class SimulationEngine {
  public data: TelemetryDataStream;
  public isSimulating: boolean = true;
  private time: number = 0;

  constructor() {
    this.data = {
      timestamp: Date.now(),
      rocketAltitudeMeters: 12000,
      rocketSpeedMps: 840,
      engineTemperatureC: 1850,
      trajectoryErrorDegrees: 0.12,
      turbomachineryRpm: 48500,
      refineryPressureBar: 42.4,
      batteryHealthPercent: 94.2,
      civitasTrafficDensity: 0.65
    };
  }

  update(dt: number): TelemetryDataStream {
    if (!this.isSimulating) return this.data;

    this.time += dt;

    // Rocket ascent physics profile
    const alt = (15000 + Math.sin(this.time * 0.2) * 12000 + this.time * 400) % 85000;
    const speed = 600 + Math.sin(this.time * 0.3) * 400 + (alt / 85000) * 1800;
    const temp = 1400 + Math.sin(this.time * 0.8) * 600 + (speed / 2400) * 800;
    const error = Math.abs(Math.sin(this.time * 0.5) * 1.8 * Math.cos(this.time * 1.2));
    const rpm = 35000 + Math.sin(this.time * 1.4) * 22000;
    const pressure = 30 + Math.sin(this.time * 0.6) * 25;
    const traffic = 0.3 + 0.6 * (0.5 + 0.5 * Math.sin(this.time * 0.4));

    this.data = {
      timestamp: Date.now(),
      rocketAltitudeMeters: Math.round(alt),
      rocketSpeedMps: Math.round(speed),
      engineTemperatureC: Math.round(temp),
      trajectoryErrorDegrees: Number(error.toFixed(3)),
      turbomachineryRpm: Math.round(rpm),
      refineryPressureBar: Number(pressure.toFixed(1)),
      batteryHealthPercent: Math.max(10, 100 - (this.time * 0.2) % 90),
      civitasTrafficDensity: Number(traffic.toFixed(2))
    };

    return this.data;
  }

  // Helper mappings
  getEngineThermalColor(): LumenColor {
    // 1000C -> 3000C mapped to Kelvin
    const kelvin = Math.max(1500, Math.min(6500, this.data.engineTemperatureC + 273));
    return LumenColor.from_kelvin(kelvin);
  }

  getTrajectoryAlertColor(): LumenColor {
    // 0 deg -> Green / Cyan, > 1.5 deg -> Alert Amber / Red
    const err = Math.min(2.0, this.data.trajectoryErrorDegrees) / 2.0;
    const safeColor = LumenColor.rgb(0, 255, 140);
    const dangerColor = LumenColor.rgb(255, 20, 20);
    return safeColor.mix(dangerColor, err);
  }
}
