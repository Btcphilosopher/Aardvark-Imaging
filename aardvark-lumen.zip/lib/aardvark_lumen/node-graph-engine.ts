// AARDVARK LUMEN - Computational Lighting Node Graph Engine
import { ComputationalNode, NodeGraphConnection } from './types';
import { LumenScene } from './scene-engine';
import { LumenColor, LUMEN_PALETTES, LumenGradient } from './color-engine';
import { AudioFeatures } from './audio-engine';
import { TelemetryDataStream } from './types';
import { globalNoise } from './procedural-engine';

export class NodeGraphEngine {
  public nodes: ComputationalNode[] = [];
  public connections: NodeGraphConnection[] = [];

  constructor() {
    this.createDefaultGraph();
  }

  createDefaultGraph() {
    this.nodes = [
      {
        id: 'node_time',
        type: 'TIME',
        title: 'Timeline Clock',
        x: 40,
        y: 60,
        inputs: {},
        outputs: { time: 0 },
        parameters: { speed: 1.0 }
      },
      {
        id: 'node_audio_bass',
        type: 'AUDIO_BASS',
        title: 'Audio FFT Bass',
        x: 40,
        y: 220,
        inputs: {},
        outputs: { bass: 0, isBeat: false },
        parameters: { sensitivity: 1.2 }
      },
      {
        id: 'node_sine',
        type: 'SINE',
        title: 'Sine Oscillator',
        x: 280,
        y: 60,
        inputs: { in: 0 },
        outputs: { out: 0 },
        parameters: { frequency: 2.0, phase: 0.0 }
      },
      {
        id: 'node_map',
        type: 'MAP',
        title: 'Linear Remap [0..1]',
        x: 500,
        y: 60,
        inputs: { in: 0 },
        outputs: { out: 0 },
        parameters: { inMin: -1, inMax: 1, outMin: 0.2, outMax: 1.5 }
      },
      {
        id: 'node_color',
        type: 'COLOR_GRADIENT',
        title: 'Palette Evaluator',
        x: 500,
        y: 220,
        inputs: { position: 0 },
        outputs: { color: LumenColor.rgb(255, 0, 0) },
        parameters: { paletteId: 'ANGLO_FUTURIST' }
      },
      {
        id: 'node_output',
        type: 'LIGHT_OUTPUT',
        title: 'Target Fixture Rig',
        x: 750,
        y: 120,
        inputs: { intensity: 1.0, color: LumenColor.rgb(255, 255, 255) },
        outputs: {},
        parameters: { targetType: 'ALL_SPOTS' }
      }
    ];

    this.connections = [
      { id: 'c1', fromNodeId: 'node_time', fromPort: 'time', toNodeId: 'node_sine', toPort: 'in' },
      { id: 'c2', fromNodeId: 'node_sine', fromPort: 'out', toNodeId: 'node_map', toPort: 'in' },
      { id: 'c3', fromNodeId: 'node_map', fromPort: 'out', toNodeId: 'node_output', toPort: 'intensity' },
      { id: 'c4', fromNodeId: 'node_time', fromPort: 'time', toNodeId: 'node_color', toPort: 'position' },
      { id: 'c5', fromNodeId: 'node_color', fromPort: 'color', toNodeId: 'node_output', toPort: 'color' },
    ];
  }

  evaluate(
    time: number,
    scene: LumenScene,
    audioFeatures: AudioFeatures,
    telemetry: TelemetryDataStream
  ) {
    const nodeMap = new Map<string, ComputationalNode>();
    for (const node of this.nodes) {
      nodeMap.set(node.id, node);
    }

    // Step 1: Process Generator Nodes
    for (const node of this.nodes) {
      if (node.type === 'TIME') {
        const speed = node.parameters.speed || 1.0;
        node.outputs.time = time * speed;
      } else if (node.type === 'AUDIO_BASS') {
        const sens = node.parameters.sensitivity || 1.0;
        node.outputs.bass = Math.min(1.0, audioFeatures.bass * sens);
        node.outputs.isBeat = audioFeatures.isBeat;
      } else if (node.type === 'AUDIO_TREBLE') {
        node.outputs.treble = audioFeatures.treble;
      } else if (node.type === 'TELEMETRY') {
        node.outputs.altitude = telemetry.rocketAltitudeMeters;
        node.outputs.temp = telemetry.engineTemperatureC;
        node.outputs.error = telemetry.trajectoryErrorDegrees;
      }
    }

    // Step 2: Propagate Connections & Process Math Nodes
    for (const conn of this.connections) {
      const from = nodeMap.get(conn.fromNodeId);
      const to = nodeMap.get(conn.toNodeId);
      if (from && to && from.outputs[conn.fromPort] !== undefined) {
        to.inputs[conn.toPort] = from.outputs[conn.fromPort];
      }
    }

    for (const node of this.nodes) {
      if (node.type === 'SINE') {
        const inputVal = typeof node.inputs.in === 'number' ? node.inputs.in : time;
        const freq = node.parameters.frequency || 1.0;
        const phase = node.parameters.phase || 0.0;
        node.outputs.out = Math.sin(inputVal * freq + phase);
      } else if (node.type === 'NOISE') {
        const inputVal = typeof node.inputs.in === 'number' ? node.inputs.in : time;
        node.outputs.out = globalNoise.noise2D(inputVal * (node.parameters.scale || 1.0), 0);
      } else if (node.type === 'MAP') {
        const inVal = typeof node.inputs.in === 'number' ? node.inputs.in : 0;
        const { inMin = -1, inMax = 1, outMin = 0, outMax = 1 } = node.parameters;
        const norm = (inVal - inMin) / (inMax - inMin);
        node.outputs.out = outMin + norm * (outMax - outMin);
      } else if (node.type === 'COLOR_GRADIENT') {
        const pId = node.parameters.paletteId || 'ANGLO_FUTURIST';
        const pal = LUMEN_PALETTES[pId] || LUMEN_PALETTES.ANGLO_FUTURIST;
        const pos = typeof node.inputs.position === 'number' ? (node.inputs.position * 0.2) % 1.0 : 0;
        const stops = pal.colors.map((c, i) => ({ pos: i / (pal.colors.length - 1), color: c }));
        const grad = new LumenGradient(stops);
        node.outputs.color = grad.evaluate(pos, 'LAB');
      }
    }

    // Step 3: Propagate to Output Nodes and Scene
    for (const conn of this.connections) {
      const from = nodeMap.get(conn.fromNodeId);
      const to = nodeMap.get(conn.toNodeId);
      if (from && to && from.outputs[conn.fromPort] !== undefined) {
        to.inputs[conn.toPort] = from.outputs[conn.fromPort];
      }
    }

    for (const node of this.nodes) {
      if (node.type === 'LIGHT_OUTPUT') {
        const intensity = typeof node.inputs.intensity === 'number' ? node.inputs.intensity : 1.0;
        const color = node.inputs.color instanceof LumenColor ? node.inputs.color : LumenColor.rgb(255, 255, 255);

        // Apply to scene lights
        for (const light of scene.getAllLights()) {
          light.intensity = intensity;
          light.color = color.clone();
        }
      }
    }
  }
}
