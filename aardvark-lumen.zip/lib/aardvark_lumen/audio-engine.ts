// AARDVARK LUMEN - Audio Reactive Lighting Engine & Synthesized Audio Simulator
// Extracts: RMS, Bass, Mid, Treble, Beat / Onset, Spectral Centroid, Frequency Bands

export interface AudioFeatures {
  rms: number;             // 0.0 - 1.0 (overall volume)
  bass: number;            // 0.0 - 1.0 (20Hz - 250Hz)
  subBass: number;         // 0.0 - 1.0 (20Hz - 60Hz)
  mid: number;             // 0.0 - 1.0 (250Hz - 2000Hz)
  treble: number;          // 0.0 - 1.0 (2000Hz - 10000Hz)
  spectralCentroid: number;// 0.0 - 1.0 (brightness of timbre)
  isBeat: boolean;         // Transient peak detector
  frequencyData: Uint8Array;
}

export class AudioAnalyzer {
  private audioCtx: AudioContext | null = null;
  private analyzer: AnalyserNode | null = null;
  private source: MediaStreamAudioSourceNode | AudioBufferSourceNode | OscillatorNode | null = null;
  private isLiveMic: boolean = false;
  private isSimulated: boolean = true;
  private synthInterval: any = null;
  private bpm: number = 124;
  private lastBeatTime: number = 0;
  private beatThreshold: number = 0.65;
  private beatDecay: number = 0.95;
  private beatLevel: number = 0;

  // Synthesizer simulation parameters
  private simTime: number = 0;
  private trackType: 'techno' | 'synthwave' | 'ambient' = 'techno';

  public currentFeatures: AudioFeatures = {
    rms: 0,
    bass: 0,
    subBass: 0,
    mid: 0,
    treble: 0,
    spectralCentroid: 0.3,
    isBeat: false,
    frequencyData: new Uint8Array(64)
  };

  constructor() {
    // Initialized in simulated mode by default
    this.initSimulatedMode();
  }

  private initSimulatedMode() {
    this.isSimulated = true;
  }

  setTrackType(type: 'techno' | 'synthwave' | 'ambient') {
    this.trackType = type;
    if (type === 'techno') this.bpm = 130;
    if (type === 'synthwave') this.bpm = 110;
    if (type === 'ambient') this.bpm = 75;
  }

  async startMicrophone(): Promise<boolean> {
    try {
      if (typeof window === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
        return false;
      }
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      this.audioCtx = new AudioCtxClass();
      this.analyzer = this.audioCtx.createAnalyser();
      this.analyzer.fftSize = 128;
      this.analyzer.smoothingTimeConstant = 0.8;

      this.source = this.audioCtx.createMediaStreamSource(stream);
      this.source.connect(this.analyzer);

      this.isLiveMic = true;
      this.isSimulated = false;
      return true;
    } catch (err) {
      console.warn('Microphone access unavailable or denied, falling back to simulated audio synthesizer:', err);
      this.isLiveMic = false;
      this.isSimulated = true;
      return false;
    }
  }

  stopMicrophone() {
    this.isLiveMic = false;
    this.isSimulated = true;
    if (this.audioCtx && this.audioCtx.state !== 'closed') {
      this.audioCtx.close();
    }
    this.audioCtx = null;
    this.analyzer = null;
  }

  update(dt: number): AudioFeatures {
    if (this.isLiveMic && this.analyzer) {
      const bufferLength = this.analyzer.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);
      this.analyzer.getByteFrequencyData(dataArray);

      // Extract frequency bins
      let sum = 0;
      let weightedSum = 0;
      let subBassSum = 0;
      let bassSum = 0;
      let midSum = 0;
      let trebleSum = 0;

      for (let i = 0; i < bufferLength; i++) {
        const val = dataArray[i] / 255.0;
        sum += val;
        weightedSum += val * i;

        if (i < 2) subBassSum += val;
        else if (i < 8) bassSum += val;
        else if (i < 24) midSum += val;
        else trebleSum += val;
      }

      const rms = sum / bufferLength;
      const subBass = Math.min(1.0, subBassSum / 2);
      const bass = Math.min(1.0, bassSum / 6);
      const mid = Math.min(1.0, midSum / 16);
      const treble = Math.min(1.0, trebleSum / (bufferLength - 24));
      const centroid = sum > 0 ? (weightedSum / sum) / bufferLength : 0.3;

      // Onset / Beat detection
      this.beatLevel *= this.beatDecay;
      let isBeat = false;
      if (bass > this.beatThreshold && bass > this.beatLevel) {
        isBeat = true;
        this.beatLevel = bass;
      }

      this.currentFeatures = {
        rms,
        subBass,
        bass,
        mid,
        treble,
        spectralCentroid: centroid,
        isBeat,
        frequencyData: dataArray
      };

      return this.currentFeatures;
    }

    // High quality mathematical algorithmic music synthesizer
    this.simTime += dt;
    const beatInterval = 60.0 / this.bpm;
    const beatPhase = (this.simTime % beatInterval) / beatInterval;
    const barPhase = (this.simTime % (beatInterval * 4)) / (beatInterval * 4);

    // Kick transient (exponential decay)
    const kick = Math.pow(Math.max(0, 1 - beatPhase * 3.5), 2.5);
    // Snare / clap on beats 2 & 4
    const isSnareBeat = (this.simTime % (beatInterval * 2)) >= beatInterval;
    const snare = isSnareBeat ? Math.pow(Math.max(0, 1 - beatPhase * 2.8), 2.0) * 0.8 : 0;
    // Hi-hat 16th groove
    const hatPhase = (this.simTime % (beatInterval / 4)) / (beatInterval / 4);
    const hihat = Math.pow(Math.max(0, 1 - hatPhase * 4), 3.0) * 0.45;

    // Bassline wobble
    const bassMod = 0.5 + 0.5 * Math.sin(this.simTime * (this.bpm / 60) * Math.PI * 2);
    const subBass = Math.min(1.0, kick * 0.95 + 0.15 * bassMod);
    const bass = Math.min(1.0, kick * 0.8 + 0.4 * bassMod);
    const mid = Math.min(1.0, snare * 0.7 + 0.3 * Math.sin(this.simTime * 1.5));
    const treble = Math.min(1.0, hihat + 0.2 * Math.cos(this.simTime * 4.0));
    const rms = (subBass * 0.4 + bass * 0.3 + mid * 0.2 + treble * 0.1);

    const isBeat = kick > 0.75;

    // Populate fake 64-bin FFT spectrum
    const freq = new Uint8Array(64);
    for (let i = 0; i < 64; i++) {
      let v = 0;
      if (i < 4) v = subBass * 255;
      else if (i < 14) v = bass * 230 * (1 - (i - 4) / 10);
      else if (i < 36) v = mid * 200 * (0.5 + 0.5 * Math.sin(i + this.simTime * 3));
      else v = treble * 180 * (0.4 + 0.6 * Math.sin(i * 2 + this.simTime * 5));
      freq[i] = Math.max(0, Math.min(255, Math.round(v)));
    }

    this.currentFeatures = {
      rms,
      subBass,
      bass,
      mid,
      treble,
      spectralCentroid: 0.2 + 0.6 * barPhase,
      isBeat,
      frequencyData: freq
    };

    return this.currentFeatures;
  }

  isUsingMicrophone(): boolean {
    return this.isLiveMic;
  }
}
