// AARDVARK LUMEN - Procedural Light Fields, Waves, Chases, Fire, Lightning & Particle System
import { LumenColor } from './color-engine';
import { Vector3D } from './types';

// Simple deterministic Fast Simplex Noise 2D / 3D approximation
export class FastNoise {
  private p: Uint8Array = new Uint8Array(512);

  constructor(seed: number = 42) {
    const perm = new Uint8Array(256);
    for (let i = 0; i < 256; i++) perm[i] = i;

    // Shuffle with seed
    let s = seed;
    for (let i = 255; i > 0; i--) {
      s = (s * 1664525 + 1013904223) >>> 0;
      const j = s % (i + 1);
      const tmp = perm[i];
      perm[i] = perm[j];
      perm[j] = tmp;
    }

    for (let i = 0; i < 512; i++) {
      this.p[i] = perm[i & 255];
    }
  }

  private fade(t: number): number {
    return t * t * t * (t * (t * 6 - 15) + 10);
  }

  private lerp(t: number, a: number, b: number): number {
    return a + t * (b - a);
  }

  private grad(hash: number, x: number, y: number, z: number): number {
    const h = hash & 15;
    const u = h < 8 ? x : y;
    const v = h < 4 ? y : h === 12 || h === 14 ? x : z;
    return ((h & 1) === 0 ? u : -u) + ((h & 2) === 0 ? v : -v);
  }

  noise2D(x: number, y: number): number {
    return this.noise3D(x, y, 0);
  }

  noise3D(x: number, y: number, z: number): number {
    const X = Math.floor(x) & 255;
    const Y = Math.floor(y) & 255;
    const Z = Math.floor(z) & 255;

    const xf = x - Math.floor(x);
    const yf = y - Math.floor(y);
    const zf = z - Math.floor(z);

    const u = this.fade(xf);
    const v = this.fade(yf);
    const w = this.fade(zf);

    const A = this.p[X] + Y;
    const AA = this.p[A] + Z;
    const AB = this.p[A + 1] + Z;
    const B = this.p[X + 1] + Y;
    const BA = this.p[B] + Z;
    const BB = this.p[B + 1] + Z;

    return this.lerp(w,
      this.lerp(v,
        this.lerp(u, this.grad(this.p[AA], xf, yf, zf), this.grad(this.p[BA], xf - 1, yf, zf)),
        this.lerp(u, this.grad(this.p[AB], xf, yf - 1, zf), this.grad(this.p[BB], xf - 1, yf - 1, zf))
      ),
      this.lerp(v,
        this.lerp(u, this.grad(this.p[AA + 1], xf, yf, zf - 1), this.grad(this.p[BA + 1], xf - 1, yf, zf - 1)),
        this.lerp(u, this.grad(this.p[AB + 1], xf, yf - 1, zf - 1), this.grad(this.p[BB + 1], xf - 1, yf - 1, zf - 1))
      )
    );
  }

  fbm(x: number, y: number, z: number, octaves: number = 3): number {
    let total = 0;
    let frequency = 1;
    let amplitude = 1;
    let maxValue = 0;

    for (let i = 0; i < octaves; i++) {
      total += this.noise3D(x * frequency, y * frequency, z * frequency) * amplitude;
      maxValue += amplitude;
      amplitude *= 0.5;
      frequency *= 2;
    }

    return (total / maxValue + 1) * 0.5; // Normalized 0..1
  }
}

export const globalNoise = new FastNoise(12345);

// Spatial Wave Generators
export class ProceduralWaves {
  static linearWave(pos: Vector3D, t: number, frequency: number = 1.0, speed: number = 2.0, axis: 'x' | 'y' | 'z' = 'x'): number {
    const coord = pos[axis];
    return 0.5 + 0.5 * Math.sin(coord * frequency - t * speed);
  }

  static radialWave(pos: Vector3D, t: number, center: Vector3D = { x: 0, y: 0, z: 0 }, frequency: number = 1.5, speed: number = 3.0): number {
    const dx = pos.x - center.x;
    const dy = pos.y - center.y;
    const dz = pos.z - center.z;
    const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
    return 0.5 + 0.5 * Math.sin(dist * frequency - t * speed);
  }

  static spiralWave(pos: Vector3D, t: number, frequency: number = 2.0, speed: number = 2.5): number {
    const angle = Math.atan2(pos.y, pos.x);
    const radius = Math.sqrt(pos.x * pos.x + pos.y * pos.y);
    return 0.5 + 0.5 * Math.sin(angle * 3 + radius * frequency - t * speed);
  }

  static noiseWave(pos: Vector3D, t: number, scale: number = 0.5, speed: number = 0.8): number {
    return globalNoise.fbm(pos.x * scale, pos.y * scale, t * speed + pos.z * scale, 3);
  }
}

// Procedural Fire Simulation Model
export class ProceduralFire {
  static evaluate(baseIntensity: number = 0.8, t: number, flickerAmp: number = 0.35, freq: number = 12.0): {
    intensity: number;
    color: LumenColor;
    kelvin: number;
  } {
    // Low frequency roar + high frequency crackle
    const lf = globalNoise.noise2D(t * (freq * 0.2), 0.5) * 0.6;
    const hf = globalNoise.noise2D(t * freq, 8.2) * 0.4;
    const combined = lf + hf;

    const intensity = Math.max(0.1, baseIntensity + combined * flickerAmp);
    // Dynamic Kelvin temperature shifting between 1600K (deep ember) to 2600K (bright combustion flame)
    const kelvin = 1600 + Math.max(0, Math.min(1000, (combined + 0.5) * 1000));
    const color = LumenColor.from_kelvin(kelvin);

    return { intensity, color, kelvin };
  }
}

// Procedural Lightning Model (Deterministic from seed & timeline)
export class ProceduralLightning {
  static evaluate(t: number, strikeInterval: number = 6.0, seed: number = 99): {
    isActive: boolean;
    intensity: number;
    ambientColor: LumenColor;
  } {
    const cycle = t % strikeInterval;
    const strikeDuration = 0.45; // total lightning burst length

    if (cycle < strikeDuration) {
      const p = cycle / strikeDuration;
      let intensity = 0;

      // Pre-flash step (leader)
      if (p < 0.15) {
        intensity = Math.sin(p / 0.15 * Math.PI) * 0.4;
      }
      // Main return stroke
      else if (p < 0.4) {
        const strokeP = (p - 0.15) / 0.25;
        intensity = Math.pow(1 - strokeP, 3) * 3.5; // High HDR peak
      }
      // Secondary dart flashes
      else if (p < 0.7) {
        const secP = (p - 0.4) / 0.3;
        intensity = Math.sin(secP * Math.PI * 4) * Math.pow(1 - secP, 2) * 1.5;
      }
      // Rapid atmospheric decay
      else {
        const decayP = (p - 0.7) / 0.3;
        intensity = Math.max(0, (1 - decayP) * 0.2);
      }

      const color = LumenColor.rgb(200, 230, 255); // Electric violet-blue ionization
      return { isActive: intensity > 0.05, intensity, ambientColor: color };
    }

    return { isActive: false, intensity: 0, ambientColor: LumenColor.rgb(0, 0, 0) };
  }
}

// Particle Lighting System (Fireflies, Sparks, Cosmic Energy Fields)
export interface LightParticle {
  id: number;
  position: Vector3D;
  velocity: Vector3D;
  color: LumenColor;
  intensity: number;
  size: number;
  lifetime: number;
  age: number;
}

export class ParticleLightingSystem {
  public particles: LightParticle[] = [];
  public maxParticles: number = 64;
  private nextId: number = 1;

  constructor(count: number = 32) {
    this.maxParticles = count;
    for (let i = 0; i < count; i++) {
      this.spawnParticle(true);
    }
  }

  private spawnParticle(initialRandomAge: boolean = false) {
    const angle = Math.random() * Math.PI * 2;
    const radius = 1.0 + Math.random() * 4.0;
    const height = 0.5 + Math.random() * 3.0;

    const particle: LightParticle = {
      id: this.nextId++,
      position: {
        x: Math.cos(angle) * radius,
        y: height,
        z: Math.sin(angle) * radius,
      },
      velocity: {
        x: (Math.random() - 0.5) * 0.4,
        y: (Math.random() - 0.5) * 0.3,
        z: (Math.random() - 0.5) * 0.4,
      },
      // Firefly bio-luminescence or warm ember / cold plasma
      color: Math.random() > 0.4 ? LumenColor.rgb(180, 255, 60) : LumenColor.rgb(0, 220, 255),
      intensity: 0.8 + Math.random() * 0.8,
      size: 0.15 + Math.random() * 0.25,
      lifetime: 3.0 + Math.random() * 4.0,
      age: initialRandomAge ? Math.random() * 3.0 : 0
    };
    this.particles.push(particle);
  }

  update(dt: number, mode: 'fireflies' | 'sparks' | 'orbit' = 'fireflies') {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.age += dt;

      if (p.age >= p.lifetime) {
        this.particles.splice(i, 1);
        this.spawnParticle(false);
        continue;
      }

      if (mode === 'fireflies') {
        // Wandering organic motion with subtle noise acceleration
        p.velocity.x += (Math.random() - 0.5) * 0.5 * dt;
        p.velocity.y += (Math.random() - 0.5) * 0.4 * dt;
        p.velocity.z += (Math.random() - 0.5) * 0.5 * dt;
        // Dampen
        p.velocity.x *= 0.98;
        p.velocity.y *= 0.98;
        p.velocity.z *= 0.98;

        // Gentle sinusoidal bio-pulse
        const pulse = 0.5 + 0.5 * Math.sin(p.age * 3.5 + p.id);
        p.intensity = pulse * 1.2;
      } else if (mode === 'orbit') {
        const speed = 1.2;
        const currentAngle = Math.atan2(p.position.z, p.position.x) + speed * dt;
        const r = Math.sqrt(p.position.x * p.position.x + p.position.z * p.position.z);
        p.position.x = Math.cos(currentAngle) * r;
        p.position.z = Math.sin(currentAngle) * r;
        p.position.y += Math.sin(p.age * 2) * 0.01;
      }

      p.position.x += p.velocity.x * dt;
      p.position.y += p.velocity.y * dt;
      p.position.z += p.velocity.z * dt;
    }

    while (this.particles.length < this.maxParticles) {
      this.spawnParticle(false);
    }
  }
}
