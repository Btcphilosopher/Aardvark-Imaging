// AARDVARK LUMEN - Scene Graph, Canonical Light Object, Groups, Clock & Dimming Engine
import { LumenColor } from './color-engine';
import {
  LightState,
  LightType,
  DimmingCurve,
  FalloffType,
  FixtureChannelMode,
  Vector3D,
  EulerRotation,
  ShowCue,
} from './types';

// Dimming curve transforms
export function applyDimmingCurve(rawIntensity: number, curve: DimmingCurve): number {
  const i = Math.max(0, rawIntensity);
  switch (curve) {
    case 'linear':
      return i;
    case 's_curve': {
      // Smooth sigmoid curve for cinematic dimming
      const norm = Math.min(1, i);
      const sig = norm * norm * (3 - 2 * norm);
      return i > 1 ? i : sig;
    }
    case 'gamma': {
      // Gamma 2.2 perceptual correction
      return Math.pow(Math.min(1, i), 2.2) * (i > 1 ? i : 1);
    }
    case 'exponential': {
      return (Math.exp(Math.min(1, i) * 2) - 1) / (Math.exp(2) - 1) * (i > 1 ? i : 1);
    }
    case 'logarithmic': {
      const norm = Math.min(1, i);
      return norm === 0 ? 0 : (Math.log10(1 + 9 * norm)) * (i > 1 ? i : 1);
    }
    case 'smoothstep': {
      const x = Math.min(1, Math.max(0, i));
      return x * x * (3 - 2 * x);
    }
    default:
      return i;
  }
}

export class LumenLight {
  public id: string;
  public name: string;
  public type: LightType;
  public position: Vector3D;
  public target: Vector3D;
  public rotation: EulerRotation;
  public color: LumenColor;
  public intensity: number;
  public temperature: number; // in Kelvin
  public range: number;
  public beamAngle: number;
  public beamSoftness: number;
  public falloff: FalloffType;
  public dimmingCurve: DimmingCurve;
  public enabled: boolean;
  public opacity: number;
  public channelMode: FixtureChannelMode;
  public dmxUniverse: number;
  public dmxAddress: number;
  public metadata: Record<string, any>;
  public maxPowerWatts: number;

  // Animation helper state
  private fadeTargetColor: LumenColor | null = null;
  private fadeColorStart: LumenColor | null = null;
  private fadeColorStartTime: number = 0;
  private fadeColorDuration: number = 0;

  private fadeTargetIntensity: number | null = null;
  private fadeIntensityStart: number = 0;
  private fadeIntensityStartTime: number = 0;
  private fadeIntensityDuration: number = 0;

  constructor(id: string, name: string = '', type: LightType = 'SPOT') {
    this.id = id;
    this.name = name || id;
    this.type = type;
    this.position = { x: 0, y: 3.5, z: 0 };
    this.target = { x: 0, y: 0, z: 0 };
    this.rotation = { x: 0, y: 0, z: 0 };
    this.color = LumenColor.rgb(255, 255, 255);
    this.intensity = 1.0;
    this.temperature = 4000;
    this.range = 25.0;
    this.beamAngle = type === 'SPOT' ? 30 : type === 'BEAM' ? 8 : type === 'WASH' ? 65 : 45;
    this.beamSoftness = 0.4;
    this.falloff = 'inverse_square';
    this.dimmingCurve = 'gamma';
    this.enabled = true;
    this.opacity = 1.0;
    this.channelMode = 'RGBW';
    this.dmxUniverse = 1;
    this.dmxAddress = 1;
    this.metadata = {};
    this.maxPowerWatts = type === 'WASH' ? 450 : type === 'BEAM' ? 300 : type === 'PANEL' ? 200 : 150;
  }

  fade_to(color: LumenColor, duration: number, currentTime: number = 0) {
    this.fadeColorStart = this.color.clone();
    this.fadeTargetColor = color.clone();
    this.fadeColorStartTime = currentTime;
    this.fadeColorDuration = Math.max(0.001, duration);
  }

  fade_intensity(target: number, duration: number, currentTime: number = 0) {
    this.fadeIntensityStart = this.intensity;
    this.fadeTargetIntensity = target;
    this.fadeIntensityStartTime = currentTime;
    this.fadeIntensityDuration = Math.max(0.001, duration);
  }

  update(currentTime: number) {
    // Process active fades
    if (this.fadeTargetColor && this.fadeColorStart) {
      const elapsed = currentTime - this.fadeColorStartTime;
      const progress = Math.min(1.0, elapsed / this.fadeColorDuration);
      this.color = this.fadeColorStart.mix(this.fadeTargetColor, progress);
      if (progress >= 1.0) {
        this.fadeTargetColor = null;
        this.fadeColorStart = null;
      }
    }

    if (this.fadeTargetIntensity !== null) {
      const elapsed = currentTime - this.fadeIntensityStartTime;
      const progress = Math.min(1.0, elapsed / this.fadeIntensityDuration);
      this.intensity = this.fadeIntensityStart + (this.fadeTargetIntensity - this.fadeIntensityStart) * progress;
      if (progress >= 1.0) {
        this.fadeTargetIntensity = null;
      }
    }
  }

  getEffectiveIntensity(): number {
    if (!this.enabled) return 0;
    return applyDimmingCurve(this.intensity, this.dimmingCurve) * this.opacity;
  }

  getCurrentPowerWatts(): number {
    if (!this.enabled) return 0.5; // Standby quiescent power
    const eff = Math.min(1.0, this.intensity);
    return 8.0 + (this.maxPowerWatts - 8.0) * eff;
  }

  toState(): LightState {
    return {
      id: this.id,
      name: this.name,
      type: this.type,
      position: { ...this.position },
      target: { ...this.target },
      rotation: { ...this.rotation },
      color: this.color.clone(),
      intensity: this.intensity,
      temperature: this.temperature,
      range: this.range,
      beamAngle: this.beamAngle,
      beamSoftness: this.beamSoftness,
      falloff: this.falloff,
      dimmingCurve: this.dimmingCurve,
      enabled: this.enabled,
      opacity: this.opacity,
      channelMode: this.channelMode,
      dmxUniverse: this.dmxUniverse,
      dmxAddress: this.dmxAddress,
      metadata: { ...this.metadata },
      currentEnergyWatts: this.getCurrentPowerWatts()
    };
  }

  fromState(state: Partial<LightState>) {
    if (state.id) this.id = state.id;
    if (state.name) this.name = state.name;
    if (state.type) this.type = state.type;
    if (state.position) this.position = { ...state.position };
    if (state.target) this.target = { ...state.target };
    if (state.rotation) this.rotation = { ...state.rotation };
    if (state.color) this.color = state.color.clone();
    if (state.intensity !== undefined) this.intensity = state.intensity;
    if (state.temperature !== undefined) this.temperature = state.temperature;
    if (state.range !== undefined) this.range = state.range;
    if (state.beamAngle !== undefined) this.beamAngle = state.beamAngle;
    if (state.beamSoftness !== undefined) this.beamSoftness = state.beamSoftness;
    if (state.falloff) this.falloff = state.falloff;
    if (state.dimmingCurve) this.dimmingCurve = state.dimmingCurve;
    if (state.enabled !== undefined) this.enabled = state.enabled;
    if (state.opacity !== undefined) this.opacity = state.opacity;
    if (state.channelMode) this.channelMode = state.channelMode;
    if (state.dmxUniverse !== undefined) this.dmxUniverse = state.dmxUniverse;
    if (state.dmxAddress !== undefined) this.dmxAddress = state.dmxAddress;
    if (state.metadata) this.metadata = { ...state.metadata };
  }
}

export class LumenGroup {
  public name: string;
  public lights: LumenLight[] = [];
  public subGroups: LumenGroup[] = [];

  constructor(name: string) {
    this.name = name;
  }

  add(light: LumenLight) {
    this.lights.push(light);
  }

  set color(c: LumenColor) {
    for (const l of this.lights) {
      l.color = c.clone();
    }
    for (const g of this.subGroups) {
      g.color = c;
    }
  }

  set intensity(val: number) {
    for (const l of this.lights) {
      l.intensity = val;
    }
    for (const g of this.subGroups) {
      g.intensity = val;
    }
  }

  fade_to(c: LumenColor, duration: number, time: number = 0) {
    for (const l of this.lights) {
      l.fade_to(c, duration, time);
    }
  }

  flash(color: LumenColor = LumenColor.rgb(255, 255, 255), duration: number = 0.1, intensity: number = 1.0) {
    for (const l of this.lights) {
      const origColor = l.color.clone();
      const origInt = l.intensity;
      l.color = color;
      l.intensity = intensity;
      setTimeout(() => {
        l.color = origColor;
        l.intensity = origInt;
      }, duration * 1000);
    }
  }
}

export class LightMatrix {
  public rows: number;
  public cols: number;
  public spacing: number;
  public lights: LumenLight[][] = [];
  public allLights: LumenLight[] = [];

  constructor(rows: number = 20, cols: number = 20, spacing: number = 0.35, origin: Vector3D = { x: -3.5, y: 3.5, z: -4 }) {
    this.rows = rows;
    this.cols = cols;
    this.spacing = spacing;

    let dmxAddr = 1;
    let universe = 1;

    for (let r = 0; r < rows; r++) {
      const rowArr: LumenLight[] = [];
      for (let c = 0; c < cols; c++) {
        const id = `matrix_r${r}_c${c}`;
        const light = new LumenLight(id, `LED [${r},${c}]`, 'PIXEL');
        light.position = {
          x: origin.x + c * spacing,
          y: origin.y - r * spacing,
          z: origin.z
        };
        light.beamAngle = 120;
        light.beamSoftness = 0.8;
        light.range = 3.0;
        light.channelMode = 'RGB';
        light.dmxUniverse = universe;
        light.dmxAddress = dmxAddr;
        light.color = LumenColor.rgb(10, 15, 25);
        light.intensity = 0.5;

        dmxAddr += 3;
        if (dmxAddr > 510) {
          dmxAddr = 1;
          universe++;
        }

        rowArr.push(light);
        this.allLights.push(light);
      }
      this.lights.push(rowArr);
    }
  }

  get(row: number, col: number): LumenLight | null {
    if (row >= 0 && row < this.rows && col >= 0 && col < this.cols) {
      return this.lights[row][col];
    }
    return null;
  }

  applyField(fieldFn: (x: number, y: number, r: number, c: number) => { color?: LumenColor; intensity?: number }) {
    for (let r = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++) {
        const light = this.lights[r][c];
        const res = fieldFn(light.position.x, light.position.y, r, c);
        if (res.color) light.color = res.color;
        if (res.intensity !== undefined) light.intensity = res.intensity;
      }
    }
  }
}

export class LumenClock {
  public time: number = 0; // Elapsed virtual time in seconds
  public isRunning: boolean = true;
  public timeScale: number = 1.0;
  public fps: number = 60;
  private lastPerfTime: number = 0;

  constructor() {
    this.lastPerfTime = typeof performance !== 'undefined' ? performance.now() : Date.now();
  }

  tick(): number {
    const now = typeof performance !== 'undefined' ? performance.now() : Date.now();
    const dt = Math.min(0.1, (now - this.lastPerfTime) / 1000.0);
    this.lastPerfTime = now;

    if (this.isRunning) {
      this.time += dt * this.timeScale;
    }
    return this.time;
  }

  seek(newTime: number) {
    this.time = Math.max(0, newTime);
  }

  setTimeScale(scale: number) {
    this.timeScale = Math.max(0.1, Math.min(10, scale));
  }

  play() {
    this.isRunning = true;
    this.lastPerfTime = typeof performance !== 'undefined' ? performance.now() : Date.now();
  }

  pause() {
    this.isRunning = false;
  }

  reset() {
    this.time = 0;
  }
}

export class LumenEventBus {
  private listeners: Map<string, Array<(payload?: any) => void>> = new Map();

  on(event: string, callback: (payload?: any) => void) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, []);
    }
    this.listeners.get(event)!.push(callback);
  }

  emit(event: string, payload?: any) {
    const list = this.listeners.get(event);
    if (list) {
      for (const cb of list) {
        cb(payload);
      }
    }
  }

  clear() {
    this.listeners.clear();
  }
}

export class LumenScene {
  public id: string;
  public name: string;
  public lights: Map<string, LumenLight> = new Map();
  public groups: Map<string, LumenGroup> = new Map();
  public matrix: LightMatrix | null = null;
  public clock: LumenClock;
  public events: LumenEventBus;
  public cues: ShowCue[] = [];
  public fogDensity: number = 0.025;
  public ambientIllumination: LumenColor = LumenColor.rgb(18, 22, 30);
  public globalExposure: number = 1.0;
  public isBlackout: boolean = false;

  constructor(name: string = 'Main Scene') {
    this.id = `scene_${Date.now()}`;
    this.name = name;
    this.clock = new LumenClock();
    this.events = new LumenEventBus();
  }

  create_light(id: string, name: string = '', type: LightType = 'SPOT'): LumenLight {
    if (this.lights.has(id)) {
      return this.lights.get(id)!;
    }
    const light = new LumenLight(id, name || id, type);
    this.lights.set(id, light);
    return light;
  }

  get_light(id: string): LumenLight | undefined {
    return this.lights.get(id);
  }

  remove_light(id: string) {
    this.lights.delete(id);
  }

  create_group(name: string): LumenGroup {
    if (this.groups.has(name)) {
      return this.groups.get(name)!;
    }
    const group = new LumenGroup(name);
    this.groups.set(name, group);
    return group;
  }

  create_matrix(rows: number = 20, cols: number = 20, spacing: number = 0.35): LightMatrix {
    this.matrix = new LightMatrix(rows, cols, spacing);
    return this.matrix;
  }

  blackout() {
    this.isBlackout = true;
    for (const light of this.lights.values()) {
      light.enabled = false;
    }
    if (this.matrix) {
      for (const light of this.matrix.allLights) {
        light.enabled = false;
      }
    }
    this.events.emit('BLACKOUT');
  }

  restore() {
    this.isBlackout = false;
    for (const light of this.lights.values()) {
      light.enabled = true;
    }
    if (this.matrix) {
      for (const light of this.matrix.allLights) {
        light.enabled = true;
      }
    }
    this.events.emit('RESTORE');
  }

  getAllLights(): LumenLight[] {
    const list = Array.from(this.lights.values());
    if (this.matrix) {
      list.push(...this.matrix.allLights);
    }
    return list;
  }

  update(): number {
    const t = this.clock.tick();
    for (const light of this.lights.values()) {
      light.update(t);
    }
    if (this.matrix) {
      for (const light of this.matrix.allLights) {
        light.update(t);
      }
    }
    return t;
  }

  getTotalPowerWatts(): number {
    let total = 0;
    for (const light of this.getAllLights()) {
      total += light.getCurrentPowerWatts();
    }
    return total;
  }

  serializeToJSON(): string {
    return JSON.stringify({
      format: 'aardlumen_v1',
      version: '1.0.0',
      scene: {
        id: this.id,
        name: this.name,
        fogDensity: this.fogDensity,
        ambientIllumination: this.ambientIllumination.to_hex(),
        globalExposure: this.globalExposure,
      },
      lights: Array.from(this.lights.values()).map(l => l.toState()),
      matrixConfig: this.matrix ? {
        rows: this.matrix.rows,
        cols: this.matrix.cols,
        spacing: this.matrix.spacing
      } : null,
      cues: this.cues
    }, null, 2);
  }
}
