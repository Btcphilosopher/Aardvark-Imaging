"""
chroma.variation.grid
========================

Multidimensional colour generation (project spec sections 32-33):
given ranges over several channels at once (e.g. 12 hues x 10
saturations x 10 lightnesses = 1,200 candidate colours), generate the
corresponding lattice -- LAZILY. Nothing in this module materialises
a big list unless the caller explicitly asks for one (``list(grid)``);
:class:`ColourGrid` and :class:`ColourVolume` are both iterables that
yield colours one at a time (project spec section 58: "use
generators/iterators/lazy evaluation... do not create millions of
Colour objects unnecessarily").
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass
from typing import Iterator

from chroma.core.colour import Colour
from chroma.core.spaces import ColourSpace, channel_names


def _axis_values(start: float, end: float, count: int) -> tuple[float, ...]:
    if count < 1:
        raise ValueError("axis count must be >= 1")
    if count == 1:
        return (start,)
    return tuple(start + (end - start) * i / (count - 1) for i in range(count))


@dataclass(frozen=True)
class ColourGrid:
    """
    A lazy Cartesian-product lattice over named channels of ``space``.
    ``axes`` maps channel name -> the tuple of values to take on that
    axis (build these with :func:`axis_range`, or supply your own).
    """

    space: ColourSpace
    axes: dict[str, tuple[float, ...]]

    def __len__(self) -> int:
        n = 1
        for values in self.axes.values():
            n *= len(values)
        return n

    def __iter__(self) -> Iterator[Colour]:
        names = channel_names(self.space)
        # Preserve the space's own channel order regardless of the
        # order axes were supplied in.
        ordered_axis_names = [n for n in names if n in self.axes]
        value_lists = [self.axes[n] for n in ordered_axis_names]
        for combo in itertools.product(*value_lists):
            channel_values = dict(zip(ordered_axis_names, combo))
            # Any channel not swept takes its midpoint as a sensible default.
            full = []
            for i, name in enumerate(names):
                if name in channel_values:
                    full.append(channel_values[name])
                else:
                    from chroma.core.spaces import metadata_for

                    lo, hi = metadata_for(self.space).channel_ranges[i]
                    full.append((lo + hi) / 2.0)
            yield Colour(self.space, tuple(full))


def axis_range(start: float, end: float, steps: int) -> tuple[float, ...]:
    """Build one axis for :class:`ColourGrid`: ``steps`` evenly spaced values from ``start`` to ``end`` inclusive."""
    return _axis_values(start, end, steps)


def colour_grid(space: ColourSpace | str = ColourSpace.HSL, **axis_specs: tuple[float, float, int]) -> ColourGrid:
    """
    Convenience constructor: ``colour_grid("hsl", h=(0, 330, 12), s=(0.3, 1.0, 10), l=(0.2, 0.8, 10))``
    builds the 12 x 10 x 10 = 1,200-colour lattice from project spec section 32's example.
    """
    space = ColourSpace(space)
    axes = {name: axis_range(*spec) for name, spec in axis_specs.items()}
    return ColourGrid(space, axes)


@dataclass(frozen=True)
class ColourVolume:
    """
    An abstract sampleable region of a colour space (project spec
    section 33). This engine ships one concrete shape -- a cylindrical
    volume over a polar space (OKLCh/LCh/LChuv/HSL/HSV), which is the
    natural "cube/cylinder/polar space" shape for those spaces -- via
    :func:`cylindrical_volume`. A Cartesian cube volume is just a
    :class:`ColourGrid` over srgb/linear_rgb/lab/oklab axes and does
    not need a separate type.
    """

    space: ColourSpace
    l_range: tuple[float, float]
    c_range: tuple[float, float]
    h_range: tuple[float, float]

    def sample(self, l_steps: int, c_steps: int, h_steps: int) -> Iterator[Colour]:
        """Lazily yield every (L, C, h) combination in the swept ranges."""
        names = channel_names(self.space)
        l_idx, c_idx, h_idx = names.index("L") if "L" in names else names.index("l"), names.index("C") if "C" in names else names.index("s"), names.index("h")
        for L in _axis_values(*self.l_range, l_steps):
            for C in _axis_values(*self.c_range, c_steps):
                for h in _axis_values(*self.h_range, h_steps):
                    values = [0.0] * len(names)
                    values[l_idx], values[c_idx], values[h_idx] = L, C, h
                    yield Colour(self.space, tuple(values))


def cylindrical_volume(
    space: ColourSpace | str = ColourSpace.OKLCH,
    l_range: tuple[float, float] = (0.0, 1.0),
    c_range: tuple[float, float] = (0.0, 0.4),
    h_range: tuple[float, float] = (0.0, 360.0),
) -> ColourVolume:
    """E.g. ``cylindrical_volume("oklch", l_range=(0,1), c_range=(0,0.4), h_range=(0,360))`` -- project spec section 33's own example."""
    return ColourVolume(ColourSpace(space), l_range, c_range, h_range)
