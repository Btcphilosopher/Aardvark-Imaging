"""chroma.variation -- systematic colour-family generation."""

from chroma.variation.engine import (
    ColourSeries,
    ColourVariationSet,
    chroma_series,
    darken,
    desaturate,
    generate_variation_set,
    hue_rotation_series,
    hue_sweep,
    lighten,
    lightness_series,
    rotate_hue,
    saturate,
    shades,
    temperature_series,
    tints,
    tones,
)
from chroma.variation.grid import ColourGrid, ColourVolume, axis_range, colour_grid, cylindrical_volume

__all__ = [
    "ColourSeries", "ColourVariationSet", "generate_variation_set",
    "lighten", "darken", "rotate_hue", "saturate", "desaturate",
    "hue_sweep", "hue_rotation_series", "lightness_series", "chroma_series",
    "tints", "shades", "tones", "temperature_series",
    "ColourGrid", "axis_range", "colour_grid", "ColourVolume", "cylindrical_volume",
]
