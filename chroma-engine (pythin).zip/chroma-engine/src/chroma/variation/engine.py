"""
chroma.variation.engine
==========================

The central feature of Chroma Engine (project spec section 18): given
one colour, generate systematic, LABELLED families of related
colours. Every generator here returns a :class:`ColourSeries` (or a
:class:`ColourVariationSet` bundling several) rather than a bare list,
because a family of colours without a label for what varies and in
which space is not reproducible or explainable -- exactly the "fake
science" this engine is trying to avoid (section 76: do not pretend
HSV/HSL saturation and OKLCh chroma are the same operation just
because both are colloquially "saturation").
"""

from __future__ import annotations

from dataclasses import dataclass, field

from chroma.core.colour import Colour
from chroma.core.spaces import ColourSpace, channel_names

Triple = tuple[float, float, float]


@dataclass(frozen=True)
class ColourSeries:
    """A labelled, ordered family of colours plus the parameter values that produced them."""

    label: str
    space: ColourSpace
    colours: tuple[Colour, ...]
    parameter_values: tuple[float, ...] = field(default_factory=tuple)

    def __len__(self) -> int:
        return len(self.colours)

    def __iter__(self):
        return iter(self.colours)

    def hex_list(self) -> list[str]:
        return [c.hex() for c in self.colours]


def _clamp(value: float, lo: float, hi: float) -> float:
    return lo if value < lo else (hi if value > hi else value)


def _hue_index(space: ColourSpace) -> int:
    return channel_names(space).index("h")


# ---------------------------------------------------------------------------
# Single-step convenience operations (also exposed as Colour methods)
# ---------------------------------------------------------------------------
def lighten(colour: Colour, amount: float) -> Colour:
    """Increase OKLCh lightness by ``amount`` (additive, 0..1 scale), clamped to [0, 1]."""
    oklch = colour.convert(ColourSpace.OKLCH)
    L, C, h = oklch.channels
    result = Colour.from_space("oklch", L=_clamp(L + amount, 0.0, 1.0), C=C, h=h, alpha=colour.alpha)
    return result.convert(colour.space, white=colour.white)


def darken(colour: Colour, amount: float) -> Colour:
    return lighten(colour, -amount)


def rotate_hue(colour: Colour, degrees: float) -> Colour:
    """Rotate hue by ``degrees`` in OKLCh, preserving L and C exactly."""
    oklch = colour.convert(ColourSpace.OKLCH)
    L, C, h = oklch.channels
    result = Colour.from_space("oklch", L=L, C=C, h=(h + degrees) % 360.0, alpha=colour.alpha)
    return result.convert(colour.space, white=colour.white)


def saturate(colour: Colour, amount: float, space: ColourSpace | str = ColourSpace.OKLCH) -> Colour:
    """
    Increase saturation/chroma multiplicatively by ``amount`` (e.g.
    ``amount=0.2`` -> chroma * 1.2) in the given ``space``. Explicitly
    NOT assumed equivalent across spaces -- see project spec section 20.
    """
    space = ColourSpace(space)
    conv = colour.convert(space)
    names = channel_names(space)
    values = list(conv.channels)
    if "s" in names:
        idx = names.index("s")
        values[idx] = _clamp(values[idx] * (1.0 + amount), 0.0, 1.0)
    elif "C" in names:
        idx = names.index("C")
        values[idx] = max(0.0, values[idx] * (1.0 + amount))
    else:
        raise ValueError(f"{space.value} has no saturation/chroma channel to adjust.")
    result = Colour(space, tuple(values), white=conv.white, alpha=colour.alpha)
    return result.convert(colour.space, white=colour.white)


def desaturate(colour: Colour, amount: float, space: ColourSpace | str = ColourSpace.OKLCH) -> Colour:
    return saturate(colour, -amount, space)


# ---------------------------------------------------------------------------
# Hue sweep (project spec section 19)
# ---------------------------------------------------------------------------
def hue_sweep(
    colour: Colour,
    step: float = 5.0,
    space: ColourSpace | str = ColourSpace.OKLCH,
    start: float = 0.0,
    end: float = 360.0,
) -> ColourSeries:
    """
    Absolute hue sweep: every hue from ``start`` to ``end`` (exclusive)
    in steps of ``step`` degrees, holding every OTHER channel of
    ``colour`` (as expressed in ``space``) fixed.
    """
    space = ColourSpace(space)
    conv = colour.convert(space)
    idx = _hue_index(space)
    hues: list[float] = []
    h = start
    while h < end - 1e-9:
        hues.append(h % 360.0)
        h += step
    colours = []
    for hue in hues:
        values = list(conv.channels)
        values[idx] = hue
        c = Colour(space, tuple(values), white=conv.white, alpha=colour.alpha).convert(colour.space, white=colour.white)
        colours.append(c)
    return ColourSeries(f"hue sweep [{space.value}, step={step}]", space, tuple(colours), tuple(hues))


def hue_rotation_series(colour: Colour, step: float = 30.0, count: int = 12) -> ColourSeries:
    """RELATIVE hue rotation: ``count`` colours, each ``step`` degrees further around the wheel from ``colour``."""
    oklch = colour.convert(ColourSpace.OKLCH)
    L, C, h0 = oklch.channels
    hues = tuple((h0 + i * step) % 360.0 for i in range(count))
    colours = tuple(
        Colour.from_space("oklch", L=L, C=C, h=h, alpha=colour.alpha).convert(colour.space, white=colour.white)
        for h in hues
    )
    return ColourSeries(f"hue rotation [oklch, step={step}]", ColourSpace.OKLCH, colours, hues)


# ---------------------------------------------------------------------------
# Lightness series (project spec section 21) -- only spaces with an "L"/"l" channel
# ---------------------------------------------------------------------------
def lightness_series(
    colour: Colour,
    space: ColourSpace | str = ColourSpace.OKLCH,
    start: float | None = None,
    end: float | None = None,
    step: float | None = None,
    steps: int | None = None,
) -> ColourSeries:
    """
    Systematic lightness variation in ``space`` (one of oklab, oklch,
    lab, lch, luv, lchuv, hsl). Either give ``step`` (increment) or
    ``steps`` (a fixed count spanning ``start``..``end``); not both.
    """
    space = ColourSpace(space)
    names = channel_names(space)
    lightness_channel = "L" if "L" in names else ("l" if "l" in names else None)
    if lightness_channel is None:
        raise ValueError(f"{space.value} has no lightness channel.")
    idx = names.index(lightness_channel)
    lo, hi = channel_names_range(space, idx) if (start is None or end is None) else (start, end)
    if start is not None:
        lo = start
    if end is not None:
        hi = end

    if steps is not None:
        values_l = [lo + (hi - lo) * i / (steps - 1) for i in range(steps)] if steps > 1 else [lo]
    else:
        step = step or (hi - lo) / 20.0
        values_l = []
        v = lo
        while v <= hi + 1e-9:
            values_l.append(v)
            v += step

    conv = colour.convert(space)
    colours = []
    for v in values_l:
        chans = list(conv.channels)
        chans[idx] = v
        c = Colour(space, tuple(chans), white=conv.white, alpha=colour.alpha).convert(colour.space, white=colour.white)
        colours.append(c)
    return ColourSeries(f"lightness series [{space.value}]", space, tuple(colours), tuple(values_l))


def channel_names_range(space: ColourSpace, idx: int) -> tuple[float, float]:
    from chroma.core.spaces import metadata_for

    return metadata_for(space).channel_ranges[idx]


# ---------------------------------------------------------------------------
# Chroma series (project spec section 22) -- searches the real gamut
# boundary via chroma.gamut.strategies rather than clamping.
# ---------------------------------------------------------------------------
def chroma_series(
    colour: Colour,
    steps: int = 10,
    target: str = "srgb",
) -> ColourSeries:
    """
    OKLCh chroma from 0 (grey) up to the ACTUAL maximum in-gamut
    chroma for this lightness and hue against ``target`` (found via
    binary search, see :func:`chroma.gamut.strategies.max_chroma_at`)
    -- never a guessed or clamped ceiling.
    """
    from chroma.gamut.strategies import max_chroma_at

    oklch = colour.convert(ColourSpace.OKLCH)
    L, _, h = oklch.channels
    boundary = max_chroma_at(L, h, target)
    values_c = [boundary * i / (steps - 1) for i in range(steps)] if steps > 1 else [0.0]
    colours = tuple(
        Colour.from_space("oklch", L=L, C=c, h=h, alpha=colour.alpha).convert(colour.space, white=colour.white)
        for c in values_c
    )
    return ColourSeries(f"chroma series [oklch, boundary={target}]", ColourSpace.OKLCH, colours, tuple(values_c))


# ---------------------------------------------------------------------------
# Tints, shades, tones (project spec section 18)
# ---------------------------------------------------------------------------
def _mix_oklab(a: Colour, b: Colour, t: float) -> Colour:
    ca, cb = a.convert(ColourSpace.OKLAB), b.convert(ColourSpace.OKLAB)
    mixed = tuple(x + (y - x) * t for x, y in zip(ca.channels, cb.channels))
    alpha = a.alpha + (b.alpha - a.alpha) * t
    return Colour(ColourSpace.OKLAB, mixed, alpha=alpha).convert(a.space, white=a.white)


def tints(colour: Colour, steps: int = 10) -> ColourSeries:
    """Mix towards white in OKLab, t = 0 (base) .. 1 (white)."""
    white = Colour.named("white")
    ts = [i / (steps - 1) for i in range(steps)] if steps > 1 else [0.0]
    colours = tuple(_mix_oklab(colour, white, t) for t in ts)
    return ColourSeries("tints [mix toward white, oklab]", ColourSpace.OKLAB, colours, tuple(ts))


def shades(colour: Colour, steps: int = 10) -> ColourSeries:
    """Mix towards black in OKLab, t = 0 (base) .. 1 (black)."""
    black = Colour.named("black")
    ts = [i / (steps - 1) for i in range(steps)] if steps > 1 else [0.0]
    colours = tuple(_mix_oklab(colour, black, t) for t in ts)
    return ColourSeries("shades [mix toward black, oklab]", ColourSpace.OKLAB, colours, tuple(ts))


def tones(colour: Colour, steps: int = 10) -> ColourSeries:
    """
    Reduce OKLCh chroma toward 0 while holding L and h fixed -- the
    traditional-colour-theory notion of "toning" a hue with grey,
    expressed directly in a perceptual space instead of via pigment
    mixing (see chroma.material for an actual pigment-mixing model).
    """
    oklch = colour.convert(ColourSpace.OKLCH)
    L, C, h = oklch.channels
    ts = [i / (steps - 1) for i in range(steps)] if steps > 1 else [0.0]
    colours = tuple(
        Colour.from_space("oklch", L=L, C=C * (1.0 - t), h=h, alpha=colour.alpha).convert(colour.space, white=colour.white)
        for t in ts
    )
    return ColourSeries("tones [chroma -> 0, oklch]", ColourSpace.OKLCH, colours, tuple(ts))


# ---------------------------------------------------------------------------
# Temperature (project spec section 50) -- PERCEPTUAL warmth, explicitly
# not a physical correlated-colour-temperature computation. See
# chroma.spectral for the physically-grounded CCT estimation instead.
# ---------------------------------------------------------------------------
_WARM_ANCHOR_HUE = 40.0    # OKLCh hue, orange
_COOL_ANCHOR_HUE = 250.0   # OKLCh hue, blue


def temperature_series(colour: Colour, steps: int = 11) -> ColourSeries:
    """
    A perceptual warm<->cool sweep: hue is interpolated (shortest arc)
    between a fixed cool anchor and a fixed warm anchor, passing
    through ``colour``'s own hue at the series midpoint, at constant L
    and C. This is a PERCEPTUAL WARMTH operation, not a physical
    colour-temperature (CCT) computation -- see docs/VARIATION_ENGINE.md.
    """
    oklch = colour.convert(ColourSpace.OKLCH)
    L, C, h0 = oklch.channels
    ts = [i / (steps - 1) for i in range(steps)] if steps > 1 else [0.5]
    colours = []
    for t in ts:
        if t <= 0.5:
            frac = t / 0.5
            h = _interp_hue_shortest(_COOL_ANCHOR_HUE, h0, frac)
        else:
            frac = (t - 0.5) / 0.5
            h = _interp_hue_shortest(h0, _WARM_ANCHOR_HUE, frac)
        colours.append(Colour.from_space("oklch", L=L, C=C, h=h, alpha=colour.alpha).convert(colour.space, white=colour.white))
    return ColourSeries("temperature series [perceptual warmth, oklch]", ColourSpace.OKLCH, tuple(colours), tuple(ts))


def _interp_hue_shortest(h1: float, h2: float, t: float) -> float:
    diff = ((h2 - h1 + 180.0) % 360.0) - 180.0
    return (h1 + diff * t) % 360.0


# ---------------------------------------------------------------------------
# The bundled ColourVariationSet (project spec sections 18, 64)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class ColourVariationSet:
    base: Colour
    hue: ColourSeries
    lightness: ColourSeries
    chroma: ColourSeries
    saturation_hsv: ColourSeries
    saturation_hsl: ColourSeries
    tints: ColourSeries
    shades: ColourSeries
    tones: ColourSeries
    temperature: ColourSeries
    complement: Colour
    analogous: tuple[Colour, ...]
    triadic: tuple[Colour, ...]
    tetradic: tuple[Colour, ...]
    split_complementary: tuple[Colour, ...]
    monochromatic: ColourSeries


def generate_variation_set(
    colour: Colour,
    *,
    hue_step: float = 15.0,
    lightness_steps: int = 12,
    chroma_steps: int = 12,
    saturation_steps: int = 11,
    tint_shade_tone_steps: int = 8,
    temperature_steps: int = 11,
) -> ColourVariationSet:
    """
    Build the full flagship "Colour Variation Lab" bundle (project spec
    section 64) for ``colour`` in one call.
    """
    from chroma.harmony.engine import (
        analogous,
        complementary,
        monochromatic,
        split_complementary,
        tetradic,
        triadic,
    )

    return ColourVariationSet(
        base=colour,
        hue=hue_sweep(colour, step=hue_step),
        lightness=lightness_series(colour, steps=lightness_steps),
        chroma=chroma_series(colour, steps=chroma_steps),
        saturation_hsv=_saturation_series(colour, ColourSpace.HSV, saturation_steps),
        saturation_hsl=_saturation_series(colour, ColourSpace.HSL, saturation_steps),
        tints=tints(colour, tint_shade_tone_steps),
        shades=shades(colour, tint_shade_tone_steps),
        tones=tones(colour, tint_shade_tone_steps),
        temperature=temperature_series(colour, temperature_steps),
        complement=complementary(colour),
        analogous=analogous(colour),
        triadic=triadic(colour),
        tetradic=tetradic(colour),
        split_complementary=split_complementary(colour),
        monochromatic=monochromatic(colour, steps=8),
    )


def _saturation_series(colour: Colour, space: ColourSpace, steps: int) -> ColourSeries:
    conv = colour.convert(space)
    names = channel_names(space)
    idx = names.index("s")
    ts = [i / (steps - 1) for i in range(steps)] if steps > 1 else [0.0]
    colours = []
    for s in ts:
        chans = list(conv.channels)
        chans[idx] = s
        colours.append(Colour(space, tuple(chans), alpha=colour.alpha).convert(colour.space, white=colour.white))
    return ColourSeries(f"saturation series [{space.value}]", space, tuple(colours), tuple(ts))
