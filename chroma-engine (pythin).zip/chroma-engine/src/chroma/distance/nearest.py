"""
chroma.distance.nearest
==========================

Given a target colour and a catalogue (any iterable of ``Colour``),
find the nearest one under a chosen metric. Kept metric-explicit
throughout, because "nearest" is metric-dependent (project spec
section 28) -- two calls with the same catalogue and different
metrics can legitimately return different answers, and that is
demonstrated, not hidden, in ``examples/nearest_colour_demo.py``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from chroma.core.colour import Colour
from chroma.distance.metrics import DistanceMethod, distance


@dataclass(frozen=True)
class NearestMatch:
    colour: Colour
    distance: float
    method: DistanceMethod
    source: Colour | None = None  # the original catalogue item, if it carried metadata the match discarded


def nearest(
    target: Colour,
    candidates: Iterable[Colour],
    method: DistanceMethod | str = DistanceMethod.CIEDE2000,
) -> NearestMatch:
    """Return the single closest candidate to ``target``."""
    method = DistanceMethod(method)
    best: NearestMatch | None = None
    for candidate in candidates:
        d = distance(target, candidate, method)
        if best is None or d < best.distance:
            best = NearestMatch(colour=candidate, distance=d, method=method, source=candidate)
    if best is None:
        raise ValueError("nearest() called with an empty candidate set.")
    return best


def k_nearest(
    target: Colour,
    candidates: Iterable[Colour],
    k: int = 5,
    method: DistanceMethod | str = DistanceMethod.CIEDE2000,
) -> list[NearestMatch]:
    """Return the ``k`` closest candidates to ``target``, sorted ascending by distance."""
    method = DistanceMethod(method)
    scored = [
        NearestMatch(colour=c, distance=distance(target, c, method), method=method, source=c)
        for c in candidates
    ]
    scored.sort(key=lambda m: m.distance)
    return scored[:k]
