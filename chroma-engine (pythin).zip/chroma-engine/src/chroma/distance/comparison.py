"""
chroma.distance.comparison
=============================

:class:`ColourComparison` bundles every distance metric plus
per-channel (hue/lightness/chroma/gamut) differences for a pair of
colours into one structured report (project spec section 54), so
"how different are these two colours" doesn't require five separate
function calls.
"""

from __future__ import annotations

from dataclasses import dataclass

from chroma.core.colour import Colour
from chroma.core.spaces import ColourSpace
from chroma.distance.metrics import delta_e_1976, delta_e_1994, delta_e_2000, oklab_euclidean, rgb_euclidean
from chroma.gamut.detection import TargetGamut, is_in_gamut


@dataclass(frozen=True)
class ColourComparison:
    a: Colour
    b: Colour
    rgb_euclidean: float
    cie76: float
    cie94: float
    ciede2000: float
    oklab_euclidean: float
    hue_difference: float
    lightness_difference: float
    chroma_difference: float
    gamut_agreement: dict[str, bool]  # target -> "both colours share the same in/out-of-gamut status"


def compare(a: Colour, b: Colour) -> ColourComparison:
    lab_a, lab_b = a.convert(ColourSpace.LAB).channels, b.convert(ColourSpace.LAB).channels
    rgb_a, rgb_b = a.convert(ColourSpace.SRGB).channels, b.convert(ColourSpace.SRGB).channels
    oklab_a, oklab_b = a.convert(ColourSpace.OKLAB).channels, b.convert(ColourSpace.OKLAB).channels
    oklch_a, oklch_b = a.convert(ColourSpace.OKLCH).channels, b.convert(ColourSpace.OKLCH).channels

    hue_diff = abs(((oklch_a[2] - oklch_b[2] + 180.0) % 360.0) - 180.0)

    gamut_agreement = {}
    for target in TargetGamut:
        gamut_agreement[target.value] = is_in_gamut(a, target) == is_in_gamut(b, target)

    return ColourComparison(
        a=a, b=b,
        rgb_euclidean=rgb_euclidean(rgb_a, rgb_b),
        cie76=delta_e_1976(lab_a, lab_b),
        cie94=delta_e_1994(lab_a, lab_b),
        ciede2000=delta_e_2000(lab_a, lab_b),
        oklab_euclidean=oklab_euclidean(oklab_a, oklab_b),
        hue_difference=hue_diff,
        lightness_difference=abs(oklch_a[0] - oklch_b[0]),
        chroma_difference=abs(oklch_a[1] - oklch_b[1]),
        gamut_agreement=gamut_agreement,
    )
