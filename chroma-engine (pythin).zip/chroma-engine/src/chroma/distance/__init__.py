"""chroma.distance -- perceptual and geometric colour-difference metrics."""

from chroma.distance.metrics import (
    DistanceMethod,
    delta_e_1976,
    delta_e_1994,
    delta_e_2000,
    distance,
    distance_matrix,
    oklab_euclidean,
    rgb_euclidean,
)
from chroma.distance.comparison import ColourComparison, compare
from chroma.distance.nearest import NearestMatch, k_nearest, nearest

__all__ = [
    "DistanceMethod", "distance", "distance_matrix",
    "rgb_euclidean", "delta_e_1976", "delta_e_1994", "delta_e_2000", "oklab_euclidean",
    "nearest", "k_nearest", "NearestMatch",
    "compare", "ColourComparison",
]
