"""
chroma.distance.metrics
==========================

Distance is always relative to a METRIC, and different metrics
disagree about what "close" means (project spec section 28 makes this
an explicit, testable claim: "nearest" depends on the metric). This
module implements:

- Euclidean RGB distance (naive, device-space, NOT perceptual)
- CIE76 (plain Euclidean distance in L*a*b*)
- CIE94 (graphic-arts weighting constants)
- CIEDE2000 (Sharma, Wu & Dalal's reference algorithm, CIE 15:2004 eq. 8.24 ff.)
- OKLab Euclidean distance

All of Delta E 1994's and 2000's weighting constants are the published
graphic-arts defaults (kL=kC=kH=1); see the docstrings for citations.
"""

from __future__ import annotations

import math
from enum import Enum

from chroma.core.colour import Colour
from chroma.core.spaces import ColourSpace

Triple = tuple[float, float, float]


class DistanceMethod(str, Enum):
    RGB_EUCLIDEAN = "rgb_euclidean"
    CIE76 = "cie76"
    CIE94 = "cie94"
    CIEDE2000 = "ciede2000"
    OKLAB_EUCLIDEAN = "oklab_euclidean"


# ---------------------------------------------------------------------------
# Raw-tuple implementations (unit-testable independent of Colour)
# ---------------------------------------------------------------------------
def rgb_euclidean(rgb1: Triple, rgb2: Triple) -> float:
    """Naive Euclidean distance in gamma-encoded sRGB. Fast, NOT perceptual."""
    return math.sqrt(sum((a - b) ** 2 for a, b in zip(rgb1, rgb2)))


def delta_e_1976(lab1: Triple, lab2: Triple) -> float:
    """Plain Euclidean distance in CIE L*a*b* (CIE 15:2004 eq. 8.13)."""
    return math.sqrt(sum((a - b) ** 2 for a, b in zip(lab1, lab2)))


def delta_e_1994(lab1: Triple, lab2: Triple, *, textiles: bool = False) -> float:
    """
    CIE94 colour difference. ``lab1`` is treated as the reference
    ("standard") sample, per convention, since the C1-dependent
    weighting functions are order-sensitive.

    Constants: graphic-arts application (default) uses
    kL=kC=kH=1, K1=0.045, K2=0.015; textiles application uses kL=2,
    K1=0.048, K2=0.014. Source: CIE Technical Report 116-1995.
    """
    L1, a1, b1 = lab1
    L2, a2, b2 = lab2
    kL = 2.0 if textiles else 1.0
    K1 = 0.048 if textiles else 0.045
    K2 = 0.014 if textiles else 0.015
    kC = kH = 1.0

    C1 = math.hypot(a1, b1)
    C2 = math.hypot(a2, b2)
    delta_L = L1 - L2
    delta_C = C1 - C2
    delta_a = a1 - a2
    delta_b = b1 - b2
    delta_h_sq = delta_a ** 2 + delta_b ** 2 - delta_C ** 2
    delta_H = math.sqrt(delta_h_sq) if delta_h_sq > 0.0 else 0.0

    SL = 1.0
    SC = 1.0 + K1 * C1
    SH = 1.0 + K2 * C1

    return math.sqrt(
        (delta_L / (kL * SL)) ** 2
        + (delta_C / (kC * SC)) ** 2
        + (delta_H / (kH * SH)) ** 2
    )


def delta_e_2000(lab1: Triple, lab2: Triple, *, kL: float = 1.0, kC: float = 1.0, kH: float = 1.0) -> float:
    """
    CIEDE2000. Reference algorithm: Sharma, Wu & Dalal (2005), "The
    CIEDE2000 Color-Difference Formula: Implementation Notes,
    Supplementary Test Data, and Mathematical Observations", Color
    Research & Application 30(1):21-30 -- the paper written explicitly
    to resolve implementation ambiguity in the original CIE formula,
    and the version this function follows step for step.
    """
    L1, a1, b1 = lab1
    L2, a2, b2 = lab2

    C1 = math.hypot(a1, b1)
    C2 = math.hypot(a2, b2)
    Cbar = (C1 + C2) / 2.0

    G = 0.5 * (1.0 - math.sqrt((Cbar ** 7) / (Cbar ** 7 + 25.0 ** 7)))
    a1p = (1.0 + G) * a1
    a2p = (1.0 + G) * a2

    C1p = math.hypot(a1p, b1)
    C2p = math.hypot(a2p, b2)

    def _hue_deg(a: float, b: float) -> float:
        if a == 0.0 and b == 0.0:
            return 0.0
        return math.degrees(math.atan2(b, a)) % 360.0

    h1p = _hue_deg(a1p, b1)
    h2p = _hue_deg(a2p, b2)

    delta_Lp = L2 - L1
    delta_Cp = C2p - C1p

    if C1p * C2p == 0.0:
        delta_hp = 0.0
    else:
        diff = h2p - h1p
        if abs(diff) <= 180.0:
            delta_hp = diff
        elif diff > 180.0:
            delta_hp = diff - 360.0
        else:
            delta_hp = diff + 360.0

    delta_Hp = 2.0 * math.sqrt(C1p * C2p) * math.sin(math.radians(delta_hp) / 2.0)

    Lbar_p = (L1 + L2) / 2.0
    Cbar_p = (C1p + C2p) / 2.0

    if C1p * C2p == 0.0:
        hbar_p = h1p + h2p
    else:
        diff = abs(h1p - h2p)
        summed = h1p + h2p
        if diff <= 180.0:
            hbar_p = summed / 2.0
        elif summed < 360.0:
            hbar_p = (summed + 360.0) / 2.0
        else:
            hbar_p = (summed - 360.0) / 2.0

    T = (
        1.0
        - 0.17 * math.cos(math.radians(hbar_p - 30.0))
        + 0.24 * math.cos(math.radians(2.0 * hbar_p))
        + 0.32 * math.cos(math.radians(3.0 * hbar_p + 6.0))
        - 0.20 * math.cos(math.radians(4.0 * hbar_p - 63.0))
    )

    delta_theta = 30.0 * math.exp(-(((hbar_p - 275.0) / 25.0) ** 2))
    RC = 2.0 * math.sqrt((Cbar_p ** 7) / (Cbar_p ** 7 + 25.0 ** 7))
    SL = 1.0 + (0.015 * (Lbar_p - 50.0) ** 2) / math.sqrt(20.0 + (Lbar_p - 50.0) ** 2)
    SC = 1.0 + 0.045 * Cbar_p
    SH = 1.0 + 0.015 * Cbar_p * T
    RT = -math.sin(math.radians(2.0 * delta_theta)) * RC

    term_L = delta_Lp / (kL * SL)
    term_C = delta_Cp / (kC * SC)
    term_H = delta_Hp / (kH * SH)

    return math.sqrt(term_L ** 2 + term_C ** 2 + term_H ** 2 + RT * term_C * term_H)


def oklab_euclidean(oklab1: Triple, oklab2: Triple) -> float:
    """Euclidean distance in OKLab. Cheap and, in practice, a good perceptual proxy."""
    return math.sqrt(sum((a - b) ** 2 for a, b in zip(oklab1, oklab2)))


# ---------------------------------------------------------------------------
# Colour-level dispatcher
# ---------------------------------------------------------------------------
def distance(a: Colour, b: Colour, method: DistanceMethod | str = DistanceMethod.CIEDE2000) -> float:
    """
    Compute the distance between two :class:`Colour` objects under
    ``method``. Handles the space conversion for you.
    """
    method = DistanceMethod(method)
    if method == DistanceMethod.RGB_EUCLIDEAN:
        ca, cb = a.convert(ColourSpace.SRGB), b.convert(ColourSpace.SRGB)
        return rgb_euclidean(ca.channels, cb.channels)  # type: ignore[arg-type]
    if method == DistanceMethod.CIE76:
        ca, cb = a.convert(ColourSpace.LAB), b.convert(ColourSpace.LAB)
        return delta_e_1976(ca.channels, cb.channels)  # type: ignore[arg-type]
    if method == DistanceMethod.CIE94:
        ca, cb = a.convert(ColourSpace.LAB), b.convert(ColourSpace.LAB)
        return delta_e_1994(ca.channels, cb.channels)  # type: ignore[arg-type]
    if method == DistanceMethod.CIEDE2000:
        ca, cb = a.convert(ColourSpace.LAB), b.convert(ColourSpace.LAB)
        return delta_e_2000(ca.channels, cb.channels)  # type: ignore[arg-type]
    if method == DistanceMethod.OKLAB_EUCLIDEAN:
        ca, cb = a.convert(ColourSpace.OKLAB), b.convert(ColourSpace.OKLAB)
        return oklab_euclidean(ca.channels, cb.channels)  # type: ignore[arg-type]
    raise ValueError(f"Unhandled distance method: {method!r}")  # pragma: no cover


def distance_matrix(colours: list[Colour], method: DistanceMethod | str = DistanceMethod.CIEDE2000) -> list[list[float]]:
    """
    N x N distance matrix for a list of colours (project spec section
    55). Computed lazily-ish: only the upper triangle is calculated,
    then mirrored, since distance is symmetric for every metric here.
    """
    n = len(colours)
    matrix = [[0.0] * n for _ in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            d = distance(colours[i], colours[j], method)
            matrix[i][j] = d
            matrix[j][i] = d
    return matrix
