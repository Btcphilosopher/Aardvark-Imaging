"""
chroma.conversion.graph
=========================

Instead of hand-writing O(n^2) direct conversion functions between
every pair of colour spaces, Chroma Engine declares a small set of
direct EDGES (the conversions that are actually mathematically direct,
e.g. XYZ<->Lab) and finds a PATH through them for anything else, e.g.::

    srgb -> linear_rgb -> xyz -> oklab -> oklch

:func:`convert` is the public entry point. It is deliberately white
point aware: white-point-carrying spaces (XYZ, xyY, Lab, LCh, Luv,
LChuv) can be converted at an explicit target white point, and moving
between a white-point-carrying space and a device space (which is
always referenced to D65 in this engine, matching the sRGB/Display P3/
Rec.2020 standards) triggers an automatic, EXPLICIT Bradford adaptation
step rather than a silent numerical error.

See docs/CONVERSION_PIPELINE.md for the worked-through algorithm and
why it is correct for this specific graph topology (a star centred on
XYZ for white-point spaces, matched to a star centred on each of
linear_rgb / linear_display_p3 / linear_rec2020 for device spaces).
"""

from __future__ import annotations

from collections import deque
from typing import Callable

from chroma.conversion import functions as fn
from chroma.conversion.adaptation import AdaptationMethod, bradford_adapt
from chroma.core.exceptions import NoConversionPathError
from chroma.core.illuminants import D65, WhitePoint, get_white_point
from chroma.core.spaces import ColourSpace, metadata_for

StepFn = Callable[[tuple, WhitePoint], tuple]

# ---------------------------------------------------------------------------
# Directed step registry: (source, dest) -> conversion function.
# Every entry here is a genuinely direct mathematical relationship: no
# entry silently pre-composes two edges.
# ---------------------------------------------------------------------------
_STEPS: dict[tuple[ColourSpace, ColourSpace], StepFn] = {
    (ColourSpace.SRGB, ColourSpace.LINEAR_RGB): fn.srgb_to_linear_rgb,
    (ColourSpace.LINEAR_RGB, ColourSpace.SRGB): fn.linear_rgb_to_srgb,

    (ColourSpace.DISPLAY_P3, ColourSpace.LINEAR_DISPLAY_P3): fn.p3_to_linear_p3,
    (ColourSpace.LINEAR_DISPLAY_P3, ColourSpace.DISPLAY_P3): fn.linear_p3_to_p3,

    (ColourSpace.REC2020, ColourSpace.LINEAR_REC2020): fn.rec2020_to_linear_rec2020,
    (ColourSpace.LINEAR_REC2020, ColourSpace.REC2020): fn.linear_rec2020_to_rec2020,

    (ColourSpace.LINEAR_RGB, ColourSpace.XYZ): fn.linear_srgb_to_xyz,
    (ColourSpace.XYZ, ColourSpace.LINEAR_RGB): fn.xyz_to_linear_srgb,

    (ColourSpace.LINEAR_DISPLAY_P3, ColourSpace.XYZ): fn.linear_p3_to_xyz,
    (ColourSpace.XYZ, ColourSpace.LINEAR_DISPLAY_P3): fn.xyz_to_linear_p3,

    (ColourSpace.LINEAR_REC2020, ColourSpace.XYZ): fn.linear_rec2020_to_xyz,
    (ColourSpace.XYZ, ColourSpace.LINEAR_REC2020): fn.xyz_to_linear_rec2020,

    (ColourSpace.XYZ, ColourSpace.XYY): fn.xyz_to_xyy,
    (ColourSpace.XYY, ColourSpace.XYZ): fn.xyy_to_xyz,

    (ColourSpace.XYZ, ColourSpace.LAB): fn.xyz_to_lab,
    (ColourSpace.LAB, ColourSpace.XYZ): fn.lab_to_xyz,
    (ColourSpace.LAB, ColourSpace.LCH): fn.lab_to_lch,
    (ColourSpace.LCH, ColourSpace.LAB): fn.lch_to_lab,

    (ColourSpace.XYZ, ColourSpace.LUV): fn.xyz_to_luv,
    (ColourSpace.LUV, ColourSpace.XYZ): fn.luv_to_xyz,
    (ColourSpace.LUV, ColourSpace.LCHUV): fn.luv_to_lchuv,
    (ColourSpace.LCHUV, ColourSpace.LUV): fn.lchuv_to_luv,

    (ColourSpace.LINEAR_RGB, ColourSpace.OKLAB): fn.linear_rgb_to_oklab,
    (ColourSpace.OKLAB, ColourSpace.LINEAR_RGB): fn.oklab_to_linear_rgb,
    (ColourSpace.OKLAB, ColourSpace.OKLCH): fn.oklab_to_oklch,
    (ColourSpace.OKLCH, ColourSpace.OKLAB): fn.oklch_to_oklab,

    (ColourSpace.SRGB, ColourSpace.HSV): fn.srgb_to_hsv,
    (ColourSpace.HSV, ColourSpace.SRGB): fn.hsv_to_srgb,
    (ColourSpace.SRGB, ColourSpace.HSL): fn.srgb_to_hsl,
    (ColourSpace.HSL, ColourSpace.SRGB): fn.hsl_to_srgb,
    (ColourSpace.SRGB, ColourSpace.YIQ): fn.srgb_to_yiq,
    (ColourSpace.YIQ, ColourSpace.SRGB): fn.yiq_to_srgb,
    (ColourSpace.SRGB, ColourSpace.CMY): fn.srgb_to_cmy,
    (ColourSpace.CMY, ColourSpace.SRGB): fn.cmy_to_srgb,
    (ColourSpace.CMY, ColourSpace.CMYK): fn.cmy_to_cmyk,
    (ColourSpace.CMYK, ColourSpace.CMY): fn.cmyk_to_cmy,

    (ColourSpace.LINEAR_RGB, ColourSpace.GRAYSCALE): fn.linear_rgb_to_grayscale,
    (ColourSpace.GRAYSCALE, ColourSpace.LINEAR_RGB): fn.grayscale_to_linear_rgb,
}

# Undirected adjacency, derived from the directed steps above, used for
# breadth-first pathfinding.
_ADJACENCY: dict[ColourSpace, set[ColourSpace]] = {}
for (_a, _b) in _STEPS:
    _ADJACENCY.setdefault(_a, set()).add(_b)
    _ADJACENCY.setdefault(_b, set()).add(_a)


def find_path(source: ColourSpace, dest: ColourSpace) -> list[ColourSpace]:
    """
    Breadth-first search for the shortest edge-path from ``source`` to
    ``dest`` over the conversion graph. Returns the list of nodes
    visited (including both endpoints); ``[source]`` if they are equal.
    """
    source, dest = ColourSpace(source), ColourSpace(dest)
    if source == dest:
        return [source]
    if source not in _ADJACENCY or dest not in _ADJACENCY:
        raise NoConversionPathError(f"No known edges touch {source!r} or {dest!r}.")

    visited = {source}
    queue: deque[list[ColourSpace]] = deque([[source]])
    while queue:
        path = queue.popleft()
        node = path[-1]
        for neighbour in sorted(_ADJACENCY.get(node, ()), key=lambda s: s.value):
            if neighbour in visited:
                continue
            new_path = path + [neighbour]
            if neighbour == dest:
                return new_path
            visited.add(neighbour)
            queue.append(new_path)
    raise NoConversionPathError(
        f"No conversion path found from {source.value!r} to {dest.value!r}."
    )


def explain_path(source: ColourSpace, dest: ColourSpace) -> str:
    """Human-readable rendering of the path, e.g. 'SRGB -> LINEAR_RGB -> XYZ -> OKLAB -> OKLCH'."""
    path = find_path(source, dest)
    return " -> ".join(node.name for node in path)


def _walk(channels: tuple, path: list[ColourSpace], working_white: WhitePoint) -> tuple:
    """
    Apply every edge in ``path`` in order. ``working_white`` is a
    SINGLE white point used for every white-dependent step along the
    way; the caller (:func:`convert`) is responsible for ensuring this
    is valid for the whole path (see module docstring / design doc).
    """
    current = channels
    for a, b in zip(path, path[1:]):
        step = _STEPS.get((a, b))
        if step is None:
            raise NoConversionPathError(f"No direct step registered for {a} -> {b}.")
        current = step(current, working_white)
    return current


def convert(
    channels: tuple,
    source_space: ColourSpace | str,
    dest_space: ColourSpace | str,
    source_white: WhitePoint | str | None = None,
    dest_white: WhitePoint | str | None = None,
    adaptation_method: AdaptationMethod | str = AdaptationMethod.BRADFORD,
) -> tuple[tuple, WhitePoint]:
    """
    Convert raw channel values from ``source_space`` to ``dest_space``,
    performing an explicit Bradford (or other) chromatic adaptation
    whenever the source's natural white point differs from the
    destination's required/requested white point.

    Returns ``(new_channels, resulting_white_point)``. The resulting
    white point is always returned (even for device spaces, where it
    is simply D65) so callers never have to special-case "did this
    space have a white point".
    """
    source_space = ColourSpace(source_space)
    dest_space = ColourSpace(dest_space)

    if isinstance(source_white, str):
        source_white = get_white_point(source_white)
    if isinstance(dest_white, str):
        dest_white = get_white_point(dest_white)

    source_requires_white = metadata_for(source_space).requires_white_point
    dest_requires_white = metadata_for(dest_space).requires_white_point

    resolved_source_white = source_white if (source_requires_white and source_white) else D65

    if dest_white is not None:
        target_white = dest_white
    elif dest_requires_white:
        # Preserve the caller's white point when moving between two
        # white-point-carrying spaces without an explicit override.
        target_white = resolved_source_white
    else:
        # Device / OKLab family destinations are always D65-referenced
        # in this engine (see docs/COLOUR_SPACES.md).
        target_white = D65

    if resolved_source_white.name != target_white.name:
        # Route explicitly through XYZ with one adaptation step. This
        # is correct for every path in this graph because XYZ is the
        # unique articulation point between the "device, fixed D65"
        # side of the graph and the "explicit white point" side.
        xyz_channels = _walk(channels, find_path(source_space, ColourSpace.XYZ), resolved_source_white)
        xyz_channels = bradford_adapt(xyz_channels, resolved_source_white, target_white, adaptation_method)
        final_channels = _walk(xyz_channels, find_path(ColourSpace.XYZ, dest_space), target_white)
    else:
        final_channels = _walk(channels, find_path(source_space, dest_space), target_white)

    result_white = target_white if dest_requires_white else D65
    return final_channels, result_white
