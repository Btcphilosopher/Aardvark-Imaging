"""
chroma.conversion.adaptation
==============================

Chromatic adaptation transforms: given an XYZ tristimulus computed
under one reference white, estimate the XYZ that would represent the
"same" colour appearance under a different reference white.

All methods here follow the same general recipe (a linearised von
Kries model): transform XYZ into a "cone response" space via a 3x3
matrix, scale each of the three responses by the ratio between the
two white points' responses in that space, then transform back.
Methods differ only in which 3x3 matrix they use -- Bradford's matrix
is "sharpened" beyond the literal cone fundamentals to better match
observed adaptation data, which is why it is the default recommended
by CIE and used throughout ICC colour management.

Architecture note: adding a new method is exactly "add a 3x3 matrix
and its inverse to :mod:`chroma.core.constants`, then add one entry to
``_METHODS`` below" -- no other code changes needed, per the project's
requirement that adaptation methods be extensible.
"""

from __future__ import annotations

from enum import Enum

from chroma.core.constants import (
    BRADFORD_MATRIX,
    BRADFORD_MATRIX_INV,
    VON_KRIES_MATRIX,
    VON_KRIES_MATRIX_INV,
    XYZ_SCALING_MATRIX,
    XYZ_SCALING_MATRIX_INV,
)
from chroma.core.illuminants import WhitePoint

Triple = tuple[float, float, float]
Matrix3 = tuple[Triple, Triple, Triple]


class AdaptationMethod(str, Enum):
    BRADFORD = "bradford"
    VON_KRIES = "von_kries"
    XYZ_SCALING = "xyz_scaling"


_METHODS: dict[AdaptationMethod, tuple[Matrix3, Matrix3]] = {
    AdaptationMethod.BRADFORD: (BRADFORD_MATRIX, BRADFORD_MATRIX_INV),
    AdaptationMethod.VON_KRIES: (VON_KRIES_MATRIX, VON_KRIES_MATRIX_INV),
    AdaptationMethod.XYZ_SCALING: (XYZ_SCALING_MATRIX, XYZ_SCALING_MATRIX_INV),
}


def _matmul(matrix: Matrix3, vec: Triple) -> Triple:
    a, b, c = vec
    return tuple(row[0] * a + row[1] * b + row[2] * c for row in matrix)  # type: ignore[return-value]


def adaptation_matrix(
    source: WhitePoint,
    target: WhitePoint,
    method: AdaptationMethod | str = AdaptationMethod.BRADFORD,
) -> Matrix3:
    """
    Build the full 3x3 XYZ(source) -> XYZ(target) adaptation matrix for
    ``method``. Exposed directly so callers who need to adapt many
    colours between the same two white points can build the matrix
    once (see :mod:`chroma.image` bulk operations).
    """
    method = AdaptationMethod(method)
    m, m_inv = _METHODS[method]

    src_cone = _matmul(m, source.xyz)
    dst_cone = _matmul(m, target.xyz)

    # Guard against division by zero for a pathological (black) white
    # point -- not physically meaningful, but fail predictably rather
    # than raising ZeroDivisionError deep in a matrix multiply.
    scale = tuple(
        (d / s) if s != 0.0 else 1.0 for s, d in zip(src_cone, dst_cone)
    )

    # Compose: M_inv * diag(scale) * M, expressed as explicit row
    # operations rather than materialising an intermediate diag matrix,
    # to keep this dependency-free and easy to read.
    scaled_rows = tuple(
        tuple(m[row][col] * scale[row] for col in range(3)) for row in range(3)
    )
    # scaled_rows is (diag(scale) @ M); now left-multiply by m_inv.
    result_rows = []
    for i in range(3):
        row = tuple(
            sum(m_inv[i][k] * scaled_rows[k][col] for k in range(3))
            for col in range(3)
        )
        result_rows.append(row)
    return tuple(result_rows)  # type: ignore[return-value]


def bradford_adapt(
    xyz: Triple,
    source: WhitePoint,
    target: WhitePoint,
    method: AdaptationMethod | str = AdaptationMethod.BRADFORD,
) -> Triple:
    """
    Adapt an XYZ triple from ``source`` white to ``target`` white.

    Despite the name (kept for readability at call sites, since
    Bradford is overwhelmingly the common case), ``method`` selects
    among all registered adaptation transforms.
    """
    if source.name == target.name:
        return xyz
    matrix = adaptation_matrix(source, target, method)
    return _matmul(matrix, xyz)
