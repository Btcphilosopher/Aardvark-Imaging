"""
chroma.conversion.functions
=============================

The actual colour mathematics. Every function here is pure: given
plain ``tuple[float, ...]`` channel values (and, where relevant, a
:class:`~chroma.core.illuminants.WhitePoint`), it returns new channel
values. Nothing here touches the :class:`~chroma.core.colour.Colour`
object -- that indirection lives in :mod:`chroma.conversion.graph`, so
that this module can be unit-tested (and read) as plain numerical code.

Every function's docstring states, per the project's engineering
standard:

    SOURCE SPACE, DESTINATION SPACE, WHITE POINT, TRANSFER FUNCTION, ENCODING

so nobody has to guess what a conversion assumes.
"""

from __future__ import annotations

import math

from chroma.core.constants import (
    BRADFORD_MATRIX,
    BRADFORD_MATRIX_INV,
    CIE_EPSILON,
    CIE_KAPPA,
    OKLAB_LINEAR_SRGB_TO_LMS,
    OKLAB_LMS_TO_LINEAR_SRGB,
    OKLAB_M2,
    OKLAB_M2_INV,
    P3_TO_XYZ_D65,
    REC2020_ALPHA,
    REC2020_BETA,
    REC2020_TO_XYZ_D65,
    SRGB_A,
    SRGB_ENCODED_THRESHOLD,
    SRGB_GAMMA,
    SRGB_LINEAR_THRESHOLD,
    SRGB_PHI,
    SRGB_TO_XYZ_D65,
    VON_KRIES_MATRIX,
    VON_KRIES_MATRIX_INV,
    XYZ_SCALING_MATRIX,
    XYZ_TO_P3_D65,
    XYZ_TO_REC2020_D65,
    XYZ_TO_SRGB_D65,
    YIQ_FROM_RGB,
    YIQ_TO_RGB,
)
from chroma.core.illuminants import WhitePoint

Triple = tuple[float, float, float]


def _matmul(matrix: tuple[tuple[float, float, float], ...], vec: Triple) -> Triple:
    """3x3 matrix times a 3-vector. Kept as an explicit, readable loop
    rather than any external linear-algebra dependency -- this is the
    kind of thing the "pure Python core" requirement is protecting."""
    a, b, c = vec
    return tuple(row[0] * a + row[1] * b + row[2] * c for row in matrix)  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# sRGB encoded <-> linear RGB
# SOURCE: srgb (gamma-encoded, 0..1)         DEST: linear_rgb (0..1)
# WHITE POINT: n/a (per-channel transfer function, independent of white)
# TRANSFER FUNCTION: IEC 61966-2-1:1999 piecewise gamma ~2.4
# ENCODING: sRGB <-> linear-light sRGB primaries
# ---------------------------------------------------------------------------
def srgb_encode_channel(linear: float) -> float:
    if linear <= SRGB_LINEAR_THRESHOLD:
        return linear * SRGB_PHI
    return (1.0 + SRGB_A) * (linear ** (1.0 / SRGB_GAMMA)) - SRGB_A


def srgb_decode_channel(encoded: float) -> float:
    if encoded <= SRGB_ENCODED_THRESHOLD:
        return encoded / SRGB_PHI
    return ((encoded + SRGB_A) / (1.0 + SRGB_A)) ** SRGB_GAMMA


def srgb_to_linear_rgb(rgb: Triple, white: WhitePoint | None = None) -> Triple:
    return tuple(srgb_decode_channel(c) for c in rgb)  # type: ignore[return-value]


def linear_rgb_to_srgb(rgb: Triple, white: WhitePoint | None = None) -> Triple:
    return tuple(srgb_encode_channel(c) for c in rgb)  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# Display P3 encoded <-> linear Display P3
# SOURCE: display_p3          DEST: linear_display_p3
# WHITE POINT: n/a
# TRANSFER FUNCTION: identical piecewise curve to sRGB (SMPTE EG 432-1
# reuses the sRGB opto-electronic transfer function; only the PRIMARIES
# differ from sRGB, not the transfer function).
# ---------------------------------------------------------------------------
def p3_to_linear_p3(rgb: Triple, white: WhitePoint | None = None) -> Triple:
    return tuple(srgb_decode_channel(c) for c in rgb)  # type: ignore[return-value]


def linear_p3_to_p3(rgb: Triple, white: WhitePoint | None = None) -> Triple:
    return tuple(srgb_encode_channel(c) for c in rgb)  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# Rec.2020 encoded <-> linear Rec.2020
# SOURCE: rec2020             DEST: linear_rec2020
# WHITE POINT: n/a
# TRANSFER FUNCTION: ITU-R BT.2020-2 section 4 (its own piecewise curve,
# NOT the sRGB curve -- close but numerically distinct).
# ---------------------------------------------------------------------------
def _rec2020_encode_channel(linear: float) -> float:
    if linear < REC2020_BETA:
        return 4.5 * linear
    return REC2020_ALPHA * (linear ** 0.45) - (REC2020_ALPHA - 1.0)


def _rec2020_decode_channel(encoded: float) -> float:
    threshold = 4.5 * REC2020_BETA
    if encoded < threshold:
        return encoded / 4.5
    return ((encoded + (REC2020_ALPHA - 1.0)) / REC2020_ALPHA) ** (1.0 / 0.45)


def rec2020_to_linear_rec2020(rgb: Triple, white: WhitePoint | None = None) -> Triple:
    return tuple(_rec2020_decode_channel(c) for c in rgb)  # type: ignore[return-value]


def linear_rec2020_to_rec2020(rgb: Triple, white: WhitePoint | None = None) -> Triple:
    return tuple(_rec2020_encode_channel(c) for c in rgb)  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# Linear RGB <-> XYZ (always D65 -- the matrices are derived from the
# sRGB/P3/Rec.2020 primaries, each of which is defined relative to D65).
# SOURCE: linear_rgb / linear_display_p3 / linear_rec2020   DEST: xyz@D65
# WHITE POINT: fixed at D65 by the definition of the primaries.
# TRANSFER FUNCTION: none (already linear-light); pure 3x3 matrix.
# ---------------------------------------------------------------------------
def linear_srgb_to_xyz(rgb: Triple, white: WhitePoint | None = None) -> Triple:
    return _matmul(SRGB_TO_XYZ_D65, rgb)


def xyz_to_linear_srgb(xyz: Triple, white: WhitePoint | None = None) -> Triple:
    return _matmul(XYZ_TO_SRGB_D65, xyz)


def linear_p3_to_xyz(rgb: Triple, white: WhitePoint | None = None) -> Triple:
    return _matmul(P3_TO_XYZ_D65, rgb)


def xyz_to_linear_p3(xyz: Triple, white: WhitePoint | None = None) -> Triple:
    return _matmul(XYZ_TO_P3_D65, xyz)


def linear_rec2020_to_xyz(rgb: Triple, white: WhitePoint | None = None) -> Triple:
    return _matmul(REC2020_TO_XYZ_D65, rgb)


def xyz_to_linear_rec2020(xyz: Triple, white: WhitePoint | None = None) -> Triple:
    return _matmul(XYZ_TO_REC2020_D65, xyz)


# ---------------------------------------------------------------------------
# XYZ <-> xyY
# SOURCE: xyz@W               DEST: xyY@W  (same white, re-parameterisation)
# WHITE POINT: carried through unchanged; xyY's own (x, y) *is* a
# chromaticity coordinate but the transform itself needs no white point.
# ---------------------------------------------------------------------------
def xyz_to_xyy(xyz: Triple, white: WhitePoint) -> Triple:
    x, y, z = xyz
    total = x + y + z
    if total <= 0.0:
        # Degenerate (pure black): fall back to the reference white's
        # own chromaticity, which is the conventional choice (there is
        # no hue information in zero luminance).
        wx, wy, wz = white.xyz
        wtotal = wx + wy + wz
        return (wx / wtotal, wy / wtotal, 0.0)
    return (x / total, y / total, y)


def xyy_to_xyz(xyy: Triple, white: WhitePoint) -> Triple:
    cx, cy, big_y = xyy
    if cy <= 0.0:
        return (0.0, 0.0, 0.0)
    x = (cx * big_y) / cy
    y = big_y
    z = ((1.0 - cx - cy) * big_y) / cy
    return (x, y, z)


# ---------------------------------------------------------------------------
# XYZ <-> CIE L*a*b*
# SOURCE: xyz@W                DEST: lab@W
# WHITE POINT: REQUIRED, explicit (Xn, Yn, Zn from `white`)
# TRANSFER FUNCTION: CIE 1976 cube-root-like lightness function with a
# linear toe below CIE_EPSILON (CIE 15:2004 eq. 8.3-8.6).
# ---------------------------------------------------------------------------
def _lab_f(t: float) -> float:
    if t > CIE_EPSILON:
        return t ** (1.0 / 3.0)
    return (CIE_KAPPA * t + 16.0) / 116.0


def _lab_f_inv(t: float) -> float:
    t3 = t ** 3
    if t3 > CIE_EPSILON:
        return t3
    return (116.0 * t - 16.0) / CIE_KAPPA


def xyz_to_lab(xyz: Triple, white: WhitePoint) -> Triple:
    x, y, z = xyz
    xn, yn, zn = white.xyz
    fx, fy, fz = _lab_f(x / xn), _lab_f(y / yn), _lab_f(z / zn)
    L = 116.0 * fy - 16.0
    a = 500.0 * (fx - fy)
    b = 200.0 * (fy - fz)
    return (L, a, b)


def lab_to_xyz(lab: Triple, white: WhitePoint) -> Triple:
    L, a, b = lab
    xn, yn, zn = white.xyz
    fy = (L + 16.0) / 116.0
    fx = fy + a / 500.0
    fz = fy - b / 200.0
    return (xn * _lab_f_inv(fx), yn * _lab_f_inv(fy), zn * _lab_f_inv(fz))


# ---------------------------------------------------------------------------
# Lab <-> LCh(ab)      (polar form; white carried through unchanged)
# ---------------------------------------------------------------------------
def lab_to_lch(lab: Triple, white: WhitePoint | None = None) -> Triple:
    L, a, b = lab
    c = math.hypot(a, b)
    h = math.degrees(math.atan2(b, a)) % 360.0
    return (L, c, h)


def lch_to_lab(lch: Triple, white: WhitePoint | None = None) -> Triple:
    L, c, h = lch
    rad = math.radians(h)
    return (L, c * math.cos(rad), c * math.sin(rad))


# ---------------------------------------------------------------------------
# XYZ <-> CIE L*u*v*
# SOURCE: xyz@W                DEST: luv@W
# WHITE POINT: REQUIRED, explicit
# TRANSFER FUNCTION: CIE 1976 (u', v') projective transform + the same
# lightness curve as Lab (CIE 15:2004 eq. 8.15-8.24).
# ---------------------------------------------------------------------------
def _uv_prime(xyz: Triple) -> tuple[float, float]:
    x, y, z = xyz
    denom = x + 15.0 * y + 3.0 * z
    if denom <= 0.0:
        return (0.0, 0.0)
    return (4.0 * x / denom, 9.0 * y / denom)


def xyz_to_luv(xyz: Triple, white: WhitePoint) -> Triple:
    x, y, z = xyz
    xn, yn, zn = white.xyz
    u_p, v_p = _uv_prime(xyz)
    un_p, vn_p = _uv_prime((xn, yn, zn))
    yr = y / yn
    L = 116.0 * (yr ** (1.0 / 3.0)) - 16.0 if yr > CIE_EPSILON else CIE_KAPPA * yr
    u = 13.0 * L * (u_p - un_p)
    v = 13.0 * L * (v_p - vn_p)
    return (L, u, v)


def luv_to_xyz(luv: Triple, white: WhitePoint) -> Triple:
    L, u, v = luv
    xn, yn, zn = white.xyz
    if L <= 0.0:
        return (0.0, 0.0, 0.0)
    un_p, vn_p = _uv_prime((xn, yn, zn))
    u_p = u / (13.0 * L) + un_p
    v_p = v / (13.0 * L) + vn_p
    y = yn * (((L + 16.0) / 116.0) ** 3) if L > 8.0 else yn * L / CIE_KAPPA
    if v_p == 0.0:
        return (0.0, y, 0.0)
    x = y * (9.0 * u_p) / (4.0 * v_p)
    z = y * (12.0 - 3.0 * u_p - 20.0 * v_p) / (4.0 * v_p)
    return (x, y, z)


# ---------------------------------------------------------------------------
# Luv <-> LChuv (polar form; white carried through unchanged)
# ---------------------------------------------------------------------------
def luv_to_lchuv(luv: Triple, white: WhitePoint | None = None) -> Triple:
    L, u, v = luv
    c = math.hypot(u, v)
    h = math.degrees(math.atan2(v, u)) % 360.0
    return (L, c, h)


def lchuv_to_luv(lchuv: Triple, white: WhitePoint | None = None) -> Triple:
    L, c, h = lchuv
    rad = math.radians(h)
    return (L, c * math.cos(rad), c * math.sin(rad))


# ---------------------------------------------------------------------------
# Linear sRGB <-> OKLab
# SOURCE: linear_rgb (D65)     DEST: oklab (D65, fixed)
# WHITE POINT: fixed at D65 (OKLab is defined directly on linear sRGB in
# Ottosson's derivation; it is not independently parameterisable by an
# arbitrary white point in this engine).
# TRANSFER FUNCTION: two 3x3 matrices around a per-channel cube root
# (a deliberately simple, invertible non-linearity -- not a physical
# transfer function, a numerical fit).
# ---------------------------------------------------------------------------
def _cbrt(x: float) -> float:
    # math.pow can't take a negative base to a fractional exponent;
    # OKLab's intermediate values are normally >= 0 for in-gamut
    # colours but can go slightly negative for wide-gamut/out-of-gamut
    # inputs, so a signed cube root is required for round-trip safety.
    return math.copysign(abs(x) ** (1.0 / 3.0), x)


def linear_rgb_to_oklab(rgb: Triple, white: WhitePoint | None = None) -> Triple:
    l, m, s = _matmul(OKLAB_LINEAR_SRGB_TO_LMS, rgb)
    l_, m_, s_ = _cbrt(l), _cbrt(m), _cbrt(s)
    return _matmul(OKLAB_M2, (l_, m_, s_))


def oklab_to_linear_rgb(lab: Triple, white: WhitePoint | None = None) -> Triple:
    l_, m_, s_ = _matmul(OKLAB_M2_INV, lab)
    l, m, s = l_ ** 3, m_ ** 3, s_ ** 3
    return _matmul(OKLAB_LMS_TO_LINEAR_SRGB, (l, m, s))


# ---------------------------------------------------------------------------
# OKLab <-> OKLCh (polar form)
# ---------------------------------------------------------------------------
def oklab_to_oklch(lab: Triple, white: WhitePoint | None = None) -> Triple:
    L, a, b = lab
    c = math.hypot(a, b)
    h = math.degrees(math.atan2(b, a)) % 360.0
    return (L, c, h)


def oklch_to_oklab(lch: Triple, white: WhitePoint | None = None) -> Triple:
    L, c, h = lch
    rad = math.radians(h)
    return (L, c * math.cos(rad), c * math.sin(rad))


# ---------------------------------------------------------------------------
# sRGB (encoded, 0..1) <-> HSV
# SOURCE: srgb                 DEST: hsv (h in [0,360), s,v in [0,1])
# WHITE POINT: n/a -- device-space geometric transform, NOT perceptual.
# ---------------------------------------------------------------------------
def srgb_to_hsv(rgb: Triple, white: WhitePoint | None = None) -> Triple:
    r, g, b = rgb
    maxc, minc = max(r, g, b), min(r, g, b)
    v = maxc
    delta = maxc - minc
    s = 0.0 if maxc == 0.0 else delta / maxc
    if delta == 0.0:
        h = 0.0
    elif maxc == r:
        h = 60.0 * (((g - b) / delta) % 6.0)
    elif maxc == g:
        h = 60.0 * (((b - r) / delta) + 2.0)
    else:
        h = 60.0 * (((r - g) / delta) + 4.0)
    return (h % 360.0, s, v)


def hsv_to_srgb(hsv: Triple, white: WhitePoint | None = None) -> Triple:
    h, s, v = hsv
    h = h % 360.0
    c = v * s
    x = c * (1.0 - abs((h / 60.0) % 2.0 - 1.0))
    m = v - c
    if h < 60.0:
        rp, gp, bp = c, x, 0.0
    elif h < 120.0:
        rp, gp, bp = x, c, 0.0
    elif h < 180.0:
        rp, gp, bp = 0.0, c, x
    elif h < 240.0:
        rp, gp, bp = 0.0, x, c
    elif h < 300.0:
        rp, gp, bp = x, 0.0, c
    else:
        rp, gp, bp = c, 0.0, x
    return (rp + m, gp + m, bp + m)


# ---------------------------------------------------------------------------
# sRGB (encoded, 0..1) <-> HSL
# SOURCE: srgb                 DEST: hsl (h in [0,360), s,l in [0,1])
# WHITE POINT: n/a -- device-space geometric transform, NOT perceptual.
# ---------------------------------------------------------------------------
def srgb_to_hsl(rgb: Triple, white: WhitePoint | None = None) -> Triple:
    r, g, b = rgb
    maxc, minc = max(r, g, b), min(r, g, b)
    l = (maxc + minc) / 2.0
    delta = maxc - minc
    if delta == 0.0:
        return (0.0, 0.0, l)
    s = delta / (2.0 - maxc - minc) if l > 0.5 else delta / (maxc + minc)
    if maxc == r:
        h = 60.0 * (((g - b) / delta) % 6.0)
    elif maxc == g:
        h = 60.0 * (((b - r) / delta) + 2.0)
    else:
        h = 60.0 * (((r - g) / delta) + 4.0)
    return (h % 360.0, s, l)


def hsl_to_srgb(hsl: Triple, white: WhitePoint | None = None) -> Triple:
    h, s, l = hsl
    h = h % 360.0
    c = (1.0 - abs(2.0 * l - 1.0)) * s
    x = c * (1.0 - abs((h / 60.0) % 2.0 - 1.0))
    m = l - c / 2.0
    if h < 60.0:
        rp, gp, bp = c, x, 0.0
    elif h < 120.0:
        rp, gp, bp = x, c, 0.0
    elif h < 180.0:
        rp, gp, bp = 0.0, c, x
    elif h < 240.0:
        rp, gp, bp = 0.0, x, c
    elif h < 300.0:
        rp, gp, bp = x, 0.0, c
    else:
        rp, gp, bp = c, 0.0, x
    return (rp + m, gp + m, bp + m)


# ---------------------------------------------------------------------------
# sRGB (encoded) <-> YIQ
# SOURCE: srgb                 DEST: yiq
# WHITE POINT: n/a
# NOTE: historically YIQ is derived from *gamma-corrected* ("gamma RGB",
# not linear-light) NTSC RGB, which is why this edge hangs off srgb
# rather than linear_rgb -- kept explicit rather than silently guessed.
# ---------------------------------------------------------------------------
def srgb_to_yiq(rgb: Triple, white: WhitePoint | None = None) -> Triple:
    return _matmul(YIQ_FROM_RGB, rgb)


def yiq_to_srgb(yiq: Triple, white: WhitePoint | None = None) -> Triple:
    return _matmul(YIQ_TO_RGB, yiq)


# ---------------------------------------------------------------------------
# sRGB (encoded) <-> CMY (naive subtractive complement)
# SOURCE: srgb                 DEST: cmy
# WHITE POINT: n/a
# NOTE: this is NOT a print/process model. See chroma.material for a
# profile-aware extension point.
# ---------------------------------------------------------------------------
def srgb_to_cmy(rgb: Triple, white: WhitePoint | None = None) -> Triple:
    return tuple(1.0 - c for c in rgb)  # type: ignore[return-value]


def cmy_to_srgb(cmy: Triple, white: WhitePoint | None = None) -> Triple:
    return tuple(1.0 - c for c in cmy)  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# CMY <-> CMYK (naive K-extraction)
# SOURCE: cmy                  DEST: cmyk
# WHITE POINT: n/a
# NOTE: real print workflows need an ICC / CMYKProfile-driven separation
# (GCR/UCR curves, total-ink limits, dot gain). This is the textbook
# "generic" K-extraction only -- see chroma.material.pigment.
# ---------------------------------------------------------------------------
def cmy_to_cmyk(cmy: Triple, white: WhitePoint | None = None) -> tuple[float, float, float, float]:
    c, m, y = cmy
    k = min(c, m, y)
    if k >= 1.0:
        return (0.0, 0.0, 0.0, 1.0)
    denom = 1.0 - k
    return ((c - k) / denom, (m - k) / denom, (y - k) / denom, k)


def cmyk_to_cmy(cmyk: tuple[float, float, float, float], white: WhitePoint | None = None) -> Triple:
    c, m, y, k = cmyk
    return (c * (1.0 - k) + k, m * (1.0 - k) + k, y * (1.0 - k) + k)


# ---------------------------------------------------------------------------
# Linear RGB <-> grayscale (single-channel luminance)
# SOURCE: linear_rgb            DEST: grayscale (1 channel)
# WHITE POINT: n/a
# WEIGHTS: Rec.709/sRGB luma coefficients (== the Y row of SRGB_TO_XYZ_D65,
# which is the physically correct way to derive luminance -- these are
# NOT the same as the "perceptual" 0.299/0.587/0.114 NTSC weights used
# by YIQ above; conflating the two is a common and documented mistake).
# ---------------------------------------------------------------------------
_LUMA_WEIGHTS = SRGB_TO_XYZ_D65[1]  # (0.2126729, 0.7151522, 0.0721750)


def linear_rgb_to_grayscale(rgb: Triple, white: WhitePoint | None = None) -> tuple[float]:
    r, g, b = rgb
    wr, wg, wb = _LUMA_WEIGHTS
    return (wr * r + wg * g + wb * b,)


def grayscale_to_linear_rgb(gray: tuple[float], white: WhitePoint | None = None) -> Triple:
    (v,) = gray
    return (v, v, v)
