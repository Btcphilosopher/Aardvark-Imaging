"""
chroma.contrast.wcag
=======================

WCAG 2.x relative luminance and contrast ratio (project spec section
39). The luminance transfer function is intentionally kept separate
from the sRGB decode used elsewhere (:func:`chroma.conversion.functions.srgb_decode_channel`)
even though the two are numerically almost identical -- WCAG defines
its own constant (0.03928 vs sRGB's 0.04045), and this engine does not
silently substitute one spec's constant for another's (see
docs/PERCEPTUAL_DISTANCE.md and CONTRAST.md).
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from chroma.core.colour import Colour
from chroma.core.constants import (
    WCAG_AA_LARGE,
    WCAG_AA_NORMAL,
    WCAG_AAA_LARGE,
    WCAG_AAA_NORMAL,
    WCAG_LINEAR_THRESHOLD,
)
from chroma.core.spaces import ColourSpace


class TextSize(str, Enum):
    NORMAL = "normal"
    LARGE = "large"  # WCAG: >=18pt, or >=14pt bold


def _wcag_linearise(channel: float) -> float:
    if channel <= WCAG_LINEAR_THRESHOLD:
        return channel / 12.92
    return ((channel + 0.055) / 1.055) ** 2.4


def relative_luminance(colour: Colour) -> float:
    """WCAG 2.x relative luminance, 0 (black) .. 1 (white)."""
    r, g, b = colour.convert(ColourSpace.SRGB).channels
    rl, gl, bl = _wcag_linearise(r), _wcag_linearise(g), _wcag_linearise(b)
    return 0.2126 * rl + 0.7152 * gl + 0.0722 * bl


def contrast_ratio(a: Colour, b: Colour) -> float:
    """WCAG contrast ratio, always >= 1.0 (1.0 = identical luminance)."""
    la, lb = relative_luminance(a), relative_luminance(b)
    lighter, darker = max(la, lb), min(la, lb)
    return (lighter + 0.05) / (darker + 0.05)


@dataclass(frozen=True)
class ContrastReport:
    foreground: Colour
    background: Colour
    ratio: float
    passes_aa: bool
    passes_aaa: bool
    text_size: TextSize


def evaluate_contrast(foreground: Colour, background: Colour, text_size: TextSize | str = TextSize.NORMAL) -> ContrastReport:
    """Full WCAG pass/fail report for a foreground/background pair (project spec section 39)."""
    text_size = TextSize(text_size)
    ratio = contrast_ratio(foreground, background)
    aa_threshold = WCAG_AA_LARGE if text_size == TextSize.LARGE else WCAG_AA_NORMAL
    aaa_threshold = WCAG_AAA_LARGE if text_size == TextSize.LARGE else WCAG_AAA_NORMAL
    return ContrastReport(
        foreground=foreground, background=background, ratio=ratio,
        passes_aa=ratio >= aa_threshold, passes_aaa=ratio >= aaa_threshold,
        text_size=text_size,
    )


def best_text_colour(background: Colour, candidates: tuple[Colour, Colour] | None = None) -> Colour:
    """
    Pick whichever of two candidate text colours (default black/white)
    has the higher contrast ratio against ``background`` -- the classic
    "auto text colour" utility, implemented as a continuous ratio
    comparison rather than a fixed luminance-midpoint heuristic.
    """
    black, white = candidates if candidates else (Colour.named("black"), Colour.named("white"))
    return black if contrast_ratio(black, background) >= contrast_ratio(white, background) else white
