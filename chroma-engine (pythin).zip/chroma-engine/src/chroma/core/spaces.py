"""
chroma.core.spaces
====================

Declares every colour space Chroma Engine understands, plus enough
metadata about each one (channel names, nominal ranges, whether it
needs a white point, whether it needs a target gamut/encoding) for the
rest of the engine -- especially the conversion graph and the
formatting layer -- to treat spaces generically instead of via a wall
of if/elif on strings.

This module intentionally does NOT contain conversion math. See
:mod:`chroma.conversion` for that. Keeping "what a space IS" separate
from "how to get in and out of it" is what lets the conversion graph
in :mod:`chroma.conversion.graph` reason about paths generically.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class ColourSpace(str, Enum):
    """
    Every colour space/model Chroma Engine can represent a
    :class:`~chroma.core.colour.Colour` in.

    This is a ``str`` Enum so that ``ColourSpace.SRGB == "srgb"`` holds,
    which keeps serialisation (JSON, ``.chroma`` files) trivial while
    still giving IDEs and type checkers a closed, discoverable set of
    valid values.
    """

    SRGB = "srgb"                    # gamma-encoded sRGB, 0..1 per channel
    LINEAR_RGB = "linear_rgb"        # linear-light sRGB primaries, 0..1
    DISPLAY_P3 = "display_p3"        # gamma-encoded Display P3, 0..1
    LINEAR_DISPLAY_P3 = "linear_display_p3"
    REC2020 = "rec2020"              # Rec.2020 transfer function, 0..1
    LINEAR_REC2020 = "linear_rec2020"
    XYZ = "xyz"                      # CIE 1931 XYZ, white-point dependent
    XYY = "xyy"                      # CIE xyY chromaticity + luminance
    LAB = "lab"                      # CIE 1976 L*a*b*
    LCH = "lch"                      # CIE 1976 L*C*h(ab), polar Lab
    LUV = "luv"                      # CIE 1976 L*u*v*
    LCHUV = "lchuv"                  # polar Luv
    HSV = "hsv"                      # hue/saturation/value (device RGB derived)
    HSL = "hsl"                      # hue/saturation/lightness (device RGB derived)
    OKLAB = "oklab"                  # Ottosson OKLab
    OKLCH = "oklch"                  # polar OKLab
    YIQ = "yiq"                      # NTSC composite
    CMY = "cmy"                      # naive subtractive, device independent
    CMYK = "cmyk"                    # process-dependent; see material.pigment
    GRAYSCALE = "grayscale"          # single-channel luminance


@dataclass(frozen=True)
class SpaceMetadata:
    """Static facts about one colour space."""

    space: ColourSpace
    channel_names: tuple[str, ...]
    channel_ranges: tuple[tuple[float, float], ...]
    requires_white_point: bool
    is_polar: bool = False
    is_device_dependent: bool = False
    is_gamma_encoded: bool = False
    notes: str = ""


_METADATA: dict[ColourSpace, SpaceMetadata] = {
    ColourSpace.SRGB: SpaceMetadata(
        ColourSpace.SRGB, ("r", "g", "b"), ((0.0, 1.0),) * 3,
        requires_white_point=False, is_device_dependent=True,
        is_gamma_encoded=True,
        notes="Gamma-encoded (companded) sRGB, IEC 61966-2-1. This is the "
              "space of #RRGGBB hex strings and most 8-bit image files.",
    ),
    ColourSpace.LINEAR_RGB: SpaceMetadata(
        ColourSpace.LINEAR_RGB, ("r", "g", "b"), ((0.0, 1.0),) * 3,
        requires_white_point=False, is_device_dependent=True,
        notes="Linear-light sRGB primaries (no transfer function applied). "
              "The correct space for physically meaningful blending.",
    ),
    ColourSpace.DISPLAY_P3: SpaceMetadata(
        ColourSpace.DISPLAY_P3, ("r", "g", "b"), ((0.0, 1.0),) * 3,
        requires_white_point=False, is_device_dependent=True,
        is_gamma_encoded=True,
        notes="Gamma-encoded Display P3 (SMPTE EG 432-1 primaries, sRGB-shaped TRC).",
    ),
    ColourSpace.LINEAR_DISPLAY_P3: SpaceMetadata(
        ColourSpace.LINEAR_DISPLAY_P3, ("r", "g", "b"), ((0.0, 1.0),) * 3,
        requires_white_point=False, is_device_dependent=True,
    ),
    ColourSpace.REC2020: SpaceMetadata(
        ColourSpace.REC2020, ("r", "g", "b"), ((0.0, 1.0),) * 3,
        requires_white_point=False, is_device_dependent=True,
        is_gamma_encoded=True,
        notes="Gamma-encoded Rec.2020 (ITU-R BT.2020-2), its own transfer function.",
    ),
    ColourSpace.LINEAR_REC2020: SpaceMetadata(
        ColourSpace.LINEAR_REC2020, ("r", "g", "b"), ((0.0, 1.0),) * 3,
        requires_white_point=False, is_device_dependent=True,
    ),
    ColourSpace.XYZ: SpaceMetadata(
        ColourSpace.XYZ, ("x", "y", "z"), ((0.0, 1.0),) * 3,
        requires_white_point=True,
        notes="CIE 1931 XYZ. The hub of the conversion graph. Meaningless "
              "without a stated white point.",
    ),
    ColourSpace.XYY: SpaceMetadata(
        ColourSpace.XYY, ("x", "y", "Y"), ((0.0, 1.0), (0.0, 1.0), (0.0, 1.0)),
        requires_white_point=True,
        notes="CIE xyY: chromaticity (x, y) plus luminance Y.",
    ),
    ColourSpace.LAB: SpaceMetadata(
        ColourSpace.LAB, ("L", "a", "b"), ((0.0, 100.0), (-160.0, 160.0), (-160.0, 160.0)),
        requires_white_point=True,
        notes="CIE 1976 L*a*b*. Only APPROXIMATELY perceptually uniform "
              "(see docs/PERCEPTUAL_DISTANCE.md) -- do not treat Euclidean "
              "distance in Lab as a ground truth without caveats.",
    ),
    ColourSpace.LCH: SpaceMetadata(
        ColourSpace.LCH, ("L", "C", "h"), ((0.0, 100.0), (0.0, 230.0), (0.0, 360.0)),
        requires_white_point=True, is_polar=True,
        notes="Polar form of Lab. h is in degrees, 0 <= h < 360.",
    ),
    ColourSpace.LUV: SpaceMetadata(
        ColourSpace.LUV, ("L", "u", "v"), ((0.0, 100.0), (-134.0, 224.0), (-140.0, 122.0)),
        requires_white_point=True,
        notes="CIE 1976 L*u*v*. Additive-mixture lines are straight in "
              "this space, unlike Lab -- useful for some lighting/display work.",
    ),
    ColourSpace.LCHUV: SpaceMetadata(
        ColourSpace.LCHUV, ("L", "C", "h"), ((0.0, 100.0), (0.0, 180.0), (0.0, 360.0)),
        requires_white_point=True, is_polar=True,
    ),
    ColourSpace.HSV: SpaceMetadata(
        ColourSpace.HSV, ("h", "s", "v"), ((0.0, 360.0), (0.0, 1.0), (0.0, 1.0)),
        requires_white_point=False, is_polar=True, is_device_dependent=True,
        notes="Derived directly from (gamma-encoded) sRGB. NOT perceptually "
              "uniform -- provided for UI colour pickers and classic "
              "colour-wheel operations, not perceptual measurement.",
    ),
    ColourSpace.HSL: SpaceMetadata(
        ColourSpace.HSL, ("h", "s", "l"), ((0.0, 360.0), (0.0, 1.0), (0.0, 1.0)),
        requires_white_point=False, is_polar=True, is_device_dependent=True,
        notes="Derived directly from (gamma-encoded) sRGB. NOT perceptually uniform.",
    ),
    ColourSpace.OKLAB: SpaceMetadata(
        ColourSpace.OKLAB, ("L", "a", "b"), ((0.0, 1.0), (-0.5, 0.5), (-0.5, 0.5)),
        requires_white_point=False,
        notes="Ottosson's OKLab, fit to CAM16/IPT-style perceptual data. "
              "Much better perceptual uniformity than Lab in practice, but "
              "it is a numerical fit, not a first-principles physical model "
              "-- do not describe it as 'physically exact'.",
    ),
    ColourSpace.OKLCH: SpaceMetadata(
        ColourSpace.OKLCH, ("L", "C", "h"), ((0.0, 1.0), (0.0, 0.5), (0.0, 360.0)),
        requires_white_point=False, is_polar=True,
        notes="Polar form of OKLab. The engine's default working space for "
              "perceptual variation and interpolation.",
    ),
    ColourSpace.YIQ: SpaceMetadata(
        ColourSpace.YIQ, ("y", "i", "q"), ((0.0, 1.0), (-0.5957, 0.5957), (-0.5226, 0.5226)),
        requires_white_point=False, is_device_dependent=True,
        notes="Classic NTSC composite-video space. Historical/compatibility use.",
    ),
    ColourSpace.CMY: SpaceMetadata(
        ColourSpace.CMY, ("c", "m", "y"), ((0.0, 1.0),) * 3,
        requires_white_point=False, is_device_dependent=True,
        notes="Naive subtractive complement of RGB (c=1-r etc). Not a print model.",
    ),
    ColourSpace.CMYK: SpaceMetadata(
        ColourSpace.CMYK, ("c", "m", "y", "k"), ((0.0, 1.0),) * 4,
        requires_white_point=False, is_device_dependent=True,
        notes="Device/process-dependent. The built-in conversion is a naive "
              "K-extraction, NOT a substitute for an ICC CMYK profile. See "
              "chroma.material for the CMYKProfile extension point.",
    ),
    ColourSpace.GRAYSCALE: SpaceMetadata(
        ColourSpace.GRAYSCALE, ("v",), ((0.0, 1.0),),
        requires_white_point=False,
        notes="Single-channel luminance (Rec.709 luma weights on linear RGB).",
    ),
}


def metadata_for(space: ColourSpace) -> SpaceMetadata:
    """Return the :class:`SpaceMetadata` describing ``space``."""
    return _METADATA[ColourSpace(space)]


def channel_names(space: ColourSpace) -> tuple[str, ...]:
    return metadata_for(space).channel_names


def arity(space: ColourSpace) -> int:
    return len(metadata_for(space).channel_names)
