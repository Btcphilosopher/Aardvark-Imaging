"""
chroma.core.colour
=====================

:class:`Colour` is the single value type every part of Chroma Engine
passes around. It is immutable (a frozen, slotted dataclass) -- every
operation that "changes" a colour returns a NEW ``Colour``, which is
what makes the engine safe to use inside an undo/redo stack (see
project spec section 5).

A colour never loses precision silently: internally everything is a
Python ``float`` (full double precision), and rounding only happens in
the explicit formatting methods (:meth:`Colour.hex`, :meth:`Colour.rgb8`
...), never in the constructors or in ``.convert()``.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Mapping

from chroma.core._named_colours import CSS4_NAMED_COLOURS
from chroma.core.exceptions import InvalidChannelError
from chroma.core.illuminants import D65, WhitePoint, get_white_point
from chroma.core.spaces import ColourSpace, arity, channel_names, metadata_for

_HEX_RE = re.compile(r"^#?([0-9a-fA-F]{3,8})$")


def _clamp01(x: float) -> float:
    return 0.0 if x < 0.0 else (1.0 if x > 1.0 else x)


class _DualDescriptor:
    """
    Generic version of the class/instance dual-purpose spelling trick
    (see the ``hex`` docstring note below): accessed on the class it
    returns ``objtype.<classmethod_attr>``; accessed on an instance it
    returns ``obj.<instance_attr>``. Used for both ``hex`` and
    ``rgb_float``, which the project spec asks to spell identically
    for construction (``Colour.hex(...)``, ``Colour.rgb_float(...)``)
    and formatting (``colour.hex()``, ``colour.rgb_float()``).
    """

    def __init__(self, classmethod_attr: str, instance_attr: str) -> None:
        self._classmethod_attr = classmethod_attr
        self._instance_attr = instance_attr

    def __get__(self, obj, objtype=None):
        if obj is None:
            return getattr(objtype, self._classmethod_attr)
        return getattr(obj, self._instance_attr)


@dataclass(frozen=True, slots=True)
class Colour:
    """
    An immutable point in colour space.

    Attributes
    ----------
    space:
        Which :class:`~chroma.core.spaces.ColourSpace` ``channels`` are
        expressed in.
    channels:
        The raw channel values, in the order given by
        :func:`chroma.core.spaces.channel_names` for ``space``. Full
        float precision, NOT clamped or rounded.
    white:
        The reference white this colour is expressed relative to.
        Meaningful (and load-bearing) for XYZ/xyY/Lab/LCh/Luv/LChuv;
        stored (as D65) but inert for device/OKLab-family spaces,
        which this engine always treats as D65-referenced.
    alpha:
        Opacity, 0..1. Straight (unassociated) alpha unless otherwise
        stated -- see :mod:`chroma.algorithms` for premultiplied
        compositing.
    name:
        Optional human-assigned or catalogue name.
    source_encoding:
        Free-text provenance note ("hex", "rgb8", "css", "computed",
        "measured", "catalogue:<id>", ...) -- metadata, not used by any
        maths, but useful for debugging pipelines and for Aardvark's
        undo/redo history.
    metadata:
        Arbitrary extra tags (immutable mapping).
    """

    space: ColourSpace
    channels: tuple[float, ...]
    white: WhitePoint = D65
    alpha: float = 1.0
    name: str | None = None
    source_encoding: str = "computed"
    metadata: Mapping[str, Any] = field(default_factory=lambda: MappingProxyType({}))

    def __post_init__(self) -> None:
        space = ColourSpace(self.space)
        object.__setattr__(self, "space", space)
        expected = arity(space)
        if len(self.channels) != expected:
            raise InvalidChannelError(
                f"{space.value} expects {expected} channel(s), got {len(self.channels)}."
            )
        for c in self.channels:
            if not isinstance(c, (int, float)) or c != c or c in (float("inf"), float("-inf")):
                raise InvalidChannelError(f"Invalid (NaN/inf/non-numeric) channel value: {c!r}")
        object.__setattr__(self, "channels", tuple(float(c) for c in self.channels))
        if not isinstance(self.metadata, MappingProxyType):
            object.__setattr__(self, "metadata", MappingProxyType(dict(self.metadata)))

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------
    @classmethod
    def rgb(cls, r: int, g: int, b: int, a: int = 255) -> "Colour":
        """Construct from 8-bit-per-channel integer sRGB, e.g. ``Colour.rgb(255, 0, 0)``."""
        return cls(
            ColourSpace.SRGB,
            (r / 255.0, g / 255.0, b / 255.0),
            alpha=a / 255.0,
            source_encoding="rgb8",
        )

    rgb_float = _DualDescriptor("_rgb_float_from_values", "_rgb_float_format")

    @classmethod
    def _rgb_float_from_values(cls, r: float, g: float, b: float, a: float = 1.0) -> "Colour":
        """Construct from normalised (0..1) float sRGB. Reachable as ``Colour.rgb_float(...)``."""
        return cls(ColourSpace.SRGB, (r, g, b), alpha=a, source_encoding="rgb_float")

    hex = _DualDescriptor("_hex_from_string", "_hex_format")  # noqa: A003 -- Colour.hex("#RGB") to construct, colour.hex() to format

    @classmethod
    def _hex_from_string(cls, value: str) -> "Colour":
        """
        Parse a ``#RGB``, ``#RGBA``, ``#RRGGBB`` or ``#RRGGBBAA`` hex
        string as sRGB. Reachable as ``Colour.hex(...)`` -- see
        :class:`_HexDescriptor`.
        """
        match = _HEX_RE.match(value.strip())
        if not match:
            raise InvalidChannelError(f"Not a valid hex colour: {value!r}")
        digits = match.group(1)
        if len(digits) == 3:
            digits = "".join(ch * 2 for ch in digits) + "ff"
        elif len(digits) == 4:
            digits = "".join(ch * 2 for ch in digits)
        elif len(digits) == 6:
            digits += "ff"
        elif len(digits) != 8:
            raise InvalidChannelError(f"Not a valid hex colour: {value!r}")
        r, g, b, a = (int(digits[i:i + 2], 16) for i in range(0, 8, 2))
        return cls(
            ColourSpace.SRGB,
            (r / 255.0, g / 255.0, b / 255.0),
            alpha=a / 255.0,
            source_encoding="hex",
        )

    @classmethod
    def named(cls, name: str) -> "Colour":
        """Look up a CSS Color Module Level 4 named colour (case-insensitive)."""
        key = name.strip().lower()
        if key == "transparent":
            return cls(ColourSpace.SRGB, (0.0, 0.0, 0.0), alpha=0.0, source_encoding="named")
        try:
            hex_value = CSS4_NAMED_COLOURS[key]
        except KeyError as exc:
            raise InvalidChannelError(
                f"{name!r} is not a recognised CSS4 named colour. "
                "Register a custom naming dictionary via chroma.catalogue.naming "
                "for Aardvark-specific names."
            ) from exc
        colour = cls._hex_from_string(hex_value)
        return cls(colour.space, colour.channels, alpha=colour.alpha, source_encoding="named", name=key)

    @classmethod
    def from_space(
        cls,
        space: ColourSpace | str,
        white: WhitePoint | str = D65,
        alpha: float = 1.0,
        **channel_values: float,
    ) -> "Colour":
        """
        Construct directly in any space by keyword, e.g.::

            Colour.from_space("oklch", L=0.62, C=0.25, h=30)
        """
        space = ColourSpace(space)
        names = channel_names(space)
        try:
            values = tuple(float(channel_values[n]) for n in names)
        except KeyError as exc:
            raise InvalidChannelError(
                f"{space.value} requires channels {names}; got {tuple(channel_values)}."
            ) from exc
        wp = get_white_point(white) if isinstance(white, str) else white
        return cls(space, values, white=wp, alpha=alpha, source_encoding="from_space")

    @classmethod
    def from_css(cls, css: str) -> "Colour":
        """Parse ``rgb()``, ``rgba()``, ``hsl()``, ``hsla()``, ``#hex`` or a named colour."""
        text = css.strip()
        low = text.lower()
        if low.startswith("#"):
            return cls._hex_from_string(text)
        func_match = re.match(r"^(rgba?|hsla?)\(([^)]*)\)$", low)
        if func_match:
            func, body = func_match.groups()
            parts = [p.strip() for p in re.split(r"[,\s/]+", body) if p.strip()]

            def _num(token: str, *, is_alpha: bool = False) -> float:
                if token.endswith("%"):
                    return float(token[:-1]) / 100.0
                val = float(token)
                return val

            if func.startswith("rgb"):
                def channel(token: str) -> float:
                    return _num(token) if token.endswith("%") else _num(token) / 255.0
                r, g, b = channel(parts[0]), channel(parts[1]), channel(parts[2])
                a = float(parts[3]) if len(parts) > 3 and not parts[3].endswith("%") else (
                    float(parts[3][:-1]) / 100.0 if len(parts) > 3 else 1.0
                )
                return cls(ColourSpace.SRGB, (r, g, b), alpha=a, source_encoding="css")
            else:  # hsl / hsla
                h = float(parts[0].rstrip("deg"))
                s = _num(parts[1])
                l = _num(parts[2])
                a = float(parts[3]) if len(parts) > 3 and not parts[3].endswith("%") else (
                    float(parts[3][:-1]) / 100.0 if len(parts) > 3 else 1.0
                )
                return cls(ColourSpace.HSL, (h, s, l), alpha=a, source_encoding="css")
        return cls.named(text)

    # ------------------------------------------------------------------
    # Conversion
    # ------------------------------------------------------------------
    def convert(self, space: ColourSpace | str, white: WhitePoint | str | None = None) -> "Colour":
        """
        Convert to another colour space, following the shortest path in
        the conversion graph (see :mod:`chroma.conversion.graph`) and
        performing an explicit chromatic adaptation whenever needed.
        """
        from chroma.conversion.graph import convert as _graph_convert

        dest = ColourSpace(space)
        new_channels, new_white = _graph_convert(
            self.channels, self.space, dest, source_white=self.white, dest_white=white,
        )
        return Colour(
            dest, new_channels, white=new_white, alpha=self.alpha,
            name=self.name, source_encoding=f"converted:{self.space.value}->{dest.value}",
        )

    def in_space(self, space: ColourSpace | str) -> "Colour":
        """Alias for :meth:`convert`, reads better in fluent chains."""
        return self.convert(space)

    # ------------------------------------------------------------------
    # Channel access
    # ------------------------------------------------------------------
    def channel(self, name: str) -> float:
        """Look up a single channel by its name in the current space."""
        names = channel_names(self.space)
        try:
            return self.channels[names.index(name)]
        except ValueError as exc:
            raise InvalidChannelError(
                f"{self.space.value} has no channel {name!r}; channels are {names}."
            ) from exc

    def as_dict(self) -> dict[str, float]:
        """``{channel_name: value, ...}`` for the current space."""
        return dict(zip(channel_names(self.space), self.channels))

    # ------------------------------------------------------------------
    # Formatting (explicit, never silent, never mutating precision)
    # ------------------------------------------------------------------
    def _as_srgb_channels(self) -> tuple[float, float, float]:
        c = self if self.space == ColourSpace.SRGB else self.convert(ColourSpace.SRGB)
        return c.channels  # type: ignore[return-value]

    def rgb8(self) -> tuple[int, int, int]:
        """8-bit-per-channel sRGB, clamped and rounded (display/export use only)."""
        r, g, b = self._as_srgb_channels()
        return tuple(round(_clamp01(v) * 255) for v in (r, g, b))  # type: ignore[return-value]

    def rgba8(self) -> tuple[int, int, int, int]:
        r, g, b = self.rgb8()
        return (r, g, b, round(_clamp01(self.alpha) * 255))

    def _rgb_float_format(self) -> tuple[float, float, float]:
        """Normalised (0..1) sRGB floats, clamped but NOT rounded. Reachable as ``colour.rgb_float()``."""
        r, g, b = self._as_srgb_channels()
        return (_clamp01(r), _clamp01(g), _clamp01(b))

    def _hex_format(self) -> str:
        r, g, b = self.rgb8()
        return f"#{r:02x}{g:02x}{b:02x}"

    def hex8(self) -> str:
        r, g, b, a = self.rgba8()
        return f"#{r:02x}{g:02x}{b:02x}{a:02x}"

    def css_rgb(self) -> str:
        r, g, b = self.rgb8()
        if self.alpha >= 1.0:
            return f"rgb({r}, {g}, {b})"
        return f"rgba({r}, {g}, {b}, {round(self.alpha, 4)})"

    def css_hsl(self) -> str:
        c = self if self.space == ColourSpace.HSL else self.convert(ColourSpace.HSL)
        h, s, l = c.channels
        if self.alpha >= 1.0:
            return f"hsl({h:.1f}, {s * 100:.1f}%, {l * 100:.1f}%)"
        return f"hsla({h:.1f}, {s * 100:.1f}%, {l * 100:.1f}%, {round(self.alpha, 4)})"

    def css(self) -> str:
        """Best default CSS representation (hex, or rgba() when alpha < 1)."""
        return self.css_rgb() if self.alpha < 1.0 else self._hex_format()

    def to_dict(self) -> dict[str, Any]:
        """Full-precision, JSON-serialisable representation."""
        return {
            "space": self.space.value,
            "channels": list(self.channels),
            "white": self.white.name,
            "alpha": self.alpha,
            "name": self.name,
            "source_encoding": self.source_encoding,
            "metadata": dict(self.metadata),
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "Colour":
        return cls(
            ColourSpace(data["space"]),
            tuple(data["channels"]),
            white=get_white_point(data.get("white", "D65")),
            alpha=float(data.get("alpha", 1.0)),
            name=data.get("name"),
            source_encoding=data.get("source_encoding", "from_dict"),
            metadata=data.get("metadata", {}),
        )

    def json(self) -> str:
        import json as _json

        return _json.dumps(self.to_dict())

    # ------------------------------------------------------------------
    # Convenience operations (thin wrappers; the real logic lives in
    # chroma.variation / chroma.distance / chroma.interpolation -- kept
    # separate to avoid this module becoming the "giant file" the
    # engineering standard warns against). Imports are local to avoid
    # an import cycle (those modules import Colour).
    # ------------------------------------------------------------------
    def lighten(self, amount: float) -> "Colour":
        """Increase OKLCh lightness by ``amount`` (0..1 scale), clamped to [0, 1]."""
        from chroma.variation.engine import lighten as _lighten

        return _lighten(self, amount)

    def darken(self, amount: float) -> "Colour":
        from chroma.variation.engine import darken as _darken

        return _darken(self, amount)

    def rotate_hue(self, degrees: float) -> "Colour":
        """Rotate hue by ``degrees`` in OKLCh, preserving L and C."""
        from chroma.variation.engine import rotate_hue as _rotate_hue

        return _rotate_hue(self, degrees)

    def saturate(self, amount: float) -> "Colour":
        from chroma.variation.engine import saturate as _saturate

        return _saturate(self, amount)

    def desaturate(self, amount: float) -> "Colour":
        from chroma.variation.engine import desaturate as _desaturate

        return _desaturate(self, amount)

    def mix(self, other: "Colour", t: float = 0.5, space: ColourSpace | str = ColourSpace.OKLAB) -> "Colour":
        from chroma.interpolation.engine import interpolate as _interpolate

        return _interpolate(self, other, t, space=space)

    def distance(self, other: "Colour", method: str = "ciede2000") -> float:
        from chroma.distance.metrics import distance as _distance

        return _distance(self, other, method=method)

    def is_in_gamut(self, target: str = "srgb", tolerance: float = 1e-4) -> bool:
        from chroma.gamut.detection import is_in_gamut as _is_in_gamut

        return _is_in_gamut(self, target=target, tolerance=tolerance)

    def map_to_gamut(self, target: str = "srgb", method: str = "compress_chroma") -> "Colour":
        from chroma.gamut.mapping import map_to_gamut as _map_to_gamut

        return _map_to_gamut(self, target=target, method=method)

    def generate_variations(self, **kwargs) -> "chroma.variation.engine.ColourVariationSet":  # noqa: F821
        """See :func:`chroma.variation.engine.generate_variation_set` for accepted keyword arguments."""
        from chroma.variation.engine import generate_variation_set

        return generate_variation_set(self, **kwargs)

    def generate_palette(self, method: str = "analogous", size: int = 5, target: str = "srgb") -> "chroma.palette.palette.Palette":  # noqa: F821
        from chroma.palette.generator import generate_palette as _generate_palette

        return _generate_palette(self, method=method, size=size, target=target)

    def nearest(self, candidates, method: str = "ciede2000"):
        """
        Nearest colour to ``self`` among ``candidates``: a plain
        iterable of Colour, a :class:`~chroma.palette.palette.Palette`,
        or a :class:`~chroma.catalogue.database.Catalogue`.
        """
        from chroma.distance.nearest import nearest as _nearest

        if hasattr(candidates, "nearest") and callable(candidates.nearest):
            return candidates.nearest(self, method=method)
        if hasattr(candidates, "colours") and callable(candidates.colours):
            candidates = candidates.colours()
        return _nearest(self, candidates, method=method)

    def approx_equal(self, other: "Colour", tolerance: float = 1e-6) -> bool:
        """Compare in a shared space (this colour's space) within ``tolerance`` per channel."""
        other_here = other if other.space == self.space else other.convert(self.space)
        return all(abs(a - b) <= tolerance for a, b in zip(self.channels, other_here.channels))

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        names = channel_names(self.space)
        body = ", ".join(f"{n}={v:.6g}" for n, v in zip(names, self.channels))
        wp = f", white={self.white.name}" if metadata_for(self.space).requires_white_point else ""
        a = f", alpha={self.alpha:.4g}" if self.alpha != 1.0 else ""
        return f"Colour({self.space.value}: {body}{wp}{a})"
