"""
chroma.core.exceptions
=======================

All exceptions raised by Chroma Engine derive from :class:`ChromaError`,
so callers can catch the whole family with one except-clause while still
being able to discriminate failure modes precisely when they need to.

We deliberately do NOT reuse built-in exceptions (``ValueError``,
``KeyError`` ...) for domain errors. A colour engine has a lot of ways
to fail that are semantically distinct from "bad Python argument", and
giving each one a name makes calling code self-documenting:

    try:
        colour.convert("display-p3")
    except OutOfGamutError as exc:
        ...
"""

from __future__ import annotations


class ChromaError(Exception):
    """Base class for every exception raised by Chroma Engine."""


class UnknownColourSpaceError(ChromaError):
    """Raised when a colour-space name is not registered in the engine."""


class UnknownWhitePointError(ChromaError):
    """Raised when a white point / illuminant name is not registered."""


class NoConversionPathError(ChromaError):
    """
    Raised when the conversion graph cannot find any sequence of edges
    connecting the requested source and destination spaces.
    """


class InvalidChannelError(ChromaError):
    """
    Raised when a channel value is structurally invalid for its space
    (wrong arity, wrong type, NaN/inf where a finite number is required).

    This is distinct from :class:`OutOfGamutError`: a channel can be a
    perfectly valid *number* (e.g. OKLCh chroma = 3.0) while still being
    unreachable by any real display. That is a gamut problem, not a
    channel problem.
    """


class OutOfGamutError(ChromaError):
    """
    Raised (only where the caller has explicitly asked for strict
    behaviour) when a colour cannot be represented inside a target
    gamut without mapping. By default Chroma Engine does NOT raise this
    silently during conversion -- gamut status is normally reported as
    data (see :mod:`chroma.gamut.detection`), because silently throwing
    away out-of-gamut information is exactly the kind of "fake science"
    this engine tries to avoid. This exception exists for call sites
    that opt into strict mode.
    """


class AmbiguousReferenceWhiteError(ChromaError):
    """
    Raised when an operation requires a single reference white but the
    operands disagree (e.g. comparing two Lab colours computed against
    different illuminants without an explicit adaptation step).
    """


class SpectralDataError(ChromaError):
    """Raised for malformed or out-of-range spectral data."""


class CatalogueError(ChromaError):
    """Raised for catalogue lookup / persistence failures."""


class GamutSearchDidNotConvergeError(ChromaError):
    """
    Raised when a numerical search (e.g. maximum in-gamut chroma via
    binary search) fails to converge within the configured iteration
    budget. This should be exceedingly rare and indicates a bug or a
    pathological input rather than an expected "out of gamut" result.
    """
