"""
chroma.core.constants
=======================

Every numerical constant in this module is documented with its source.
Chroma Engine's engineering standard (see project README, "No Fake
Science") forbids unexplained magic numbers in colour mathematics --
so if you add a constant here, add its provenance as a comment.

Nothing in this module depends on anything else in the package; it is
deliberately a leaf module so that every other module can import it
without risking a cycle.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# CIE 1976 L*a*b* / L*u*v* companding constants
# ---------------------------------------------------------------------------
# The piecewise-linear "toe" near black that both CIELAB and CIELUV use
# to avoid an infinite derivative (and division by zero) at Y = 0.
# Source: CIE 15:2004, "Colorimetry", 3rd edition, section 8.2.1.
# kappa = 24389/27, epsilon = 216/24389 exactly (rational, not decimal
# approximations) -- these are the values published by the CIE and
# reproduced in ASTM E308.
CIE_EPSILON = 216.0 / 24389.0          # ≈ 0.008856451679...
CIE_KAPPA = 24389.0 / 27.0             # ≈ 903.2962962...

# ---------------------------------------------------------------------------
# sRGB transfer function (IEC 61966-2-1:1999)
# ---------------------------------------------------------------------------
SRGB_LINEAR_THRESHOLD = 0.0031308      # encoded->linear breakpoint (linear side)
SRGB_ENCODED_THRESHOLD = 0.04045       # linear->encoded breakpoint (encoded side)
SRGB_GAMMA = 2.4
SRGB_A = 0.055
SRGB_PHI = 12.92

# ---------------------------------------------------------------------------
# WCAG relative-luminance transfer function (W3C WCAG 2.x, "Relative
# Luminance" definition). Numerically very close to sRGB's own transfer
# function but the WCAG spec defines its own threshold constant
# (0.03928, not sRGB's 0.04045); we keep it distinct rather than
# silently reusing the sRGB constant, because the two standards are
# not formally the same document and a future WCAG erratum should not
# silently change colour-space math.
# ---------------------------------------------------------------------------
WCAG_LINEAR_THRESHOLD = 0.03928

# ---------------------------------------------------------------------------
# RGB <-> XYZ matrices, sRGB/Rec.709 primaries, D65 white point
# ---------------------------------------------------------------------------
# Source: IEC 61966-2-1:1999, Annex G. These are the standard 6-digit
# matrices reproduced in most colour-science references (e.g. Bruce
# Lindbloom's site, which cites the same IEC derivation).
SRGB_TO_XYZ_D65 = (
    (0.4124564, 0.3575761, 0.1804375),
    (0.2126729, 0.7151522, 0.0721750),
    (0.0193339, 0.1191920, 0.9503041),
)
XYZ_TO_SRGB_D65 = (
    (3.2404542, -1.5371385, -0.4985314),
    (-0.9692660, 1.8760108, 0.0415560),
    (0.0556434, -0.2040259, 1.0572252),
)

# ---------------------------------------------------------------------------
# Display P3 primaries (SMPTE EG 432-1 / Apple Display P3), D65 white.
# Derived analytically from the standard chromaticities:
#   R (0.680, 0.320)  G (0.265, 0.690)  B (0.150, 0.060)  W = D65
# via the standard primary-matrix construction (Lindbloom's method).
# ---------------------------------------------------------------------------
P3_TO_XYZ_D65 = (
    (0.4865709, 0.2656677, 0.1982173),
    (0.2289746, 0.6917385, 0.0792869),
    (0.0000000, 0.0451134, 1.0439444),
)
XYZ_TO_P3_D65 = (
    (2.4934969, -0.9313836, -0.4027108),
    (-0.8294890, 1.7626641, 0.0236247),
    (0.0358458, -0.0761724, 0.9568845),
)

# ---------------------------------------------------------------------------
# Rec. 2020 / BT.2020 primaries, D65 white.
#   R (0.708, 0.292)  G (0.170, 0.797)  B (0.131, 0.046)  W = D65
# Source: ITU-R BT.2020-2, Table 3.
# ---------------------------------------------------------------------------
REC2020_TO_XYZ_D65 = (
    (0.6369580, 0.1446169, 0.1688810),
    (0.2627002, 0.6779981, 0.0593017),
    (0.0000000, 0.0280727, 1.0609851),
)
XYZ_TO_REC2020_D65 = (
    (1.7166512, -0.3556708, -0.2533663),
    (-0.6666844, 1.6164812, 0.0157685),
    (0.0176399, -0.0427706, 0.9421031),
)

# Rec.2020 uses its own non-linear transfer function (a slightly
# different piecewise curve from sRGB). Source: ITU-R BT.2020-2 §4.
REC2020_ALPHA = 1.09929682680944
REC2020_BETA = 0.018053968510807

# ---------------------------------------------------------------------------
# Bradford chromatic-adaptation matrix
# ---------------------------------------------------------------------------
# Source: Lam (1985) / Lindbloom's widely-cited reproduction. The
# Bradford matrix transforms XYZ into a cone-response-like "sharpened"
# space (rho, gamma, beta) in which a simple per-channel (von Kries)
# scale between two white points gives a good perceptual adaptation.
BRADFORD_MATRIX = (
    (0.8951000, 0.2664000, -0.1614000),
    (-0.7502000, 1.7135000, 0.0367000),
    (0.0389000, -0.0685000, 1.0296000),
)
BRADFORD_MATRIX_INV = (
    (0.9869929, -0.1470543, 0.1599627),
    (0.4323053, 0.5183603, 0.0492912),
    (-0.0085287, 0.0400428, 0.9684867),
)

# von Kries matrix (Hunt-Pointer-Estevez, normalised to D65), provided
# as a second, simpler adaptation method per the "architecture should
# allow additional adaptation methods" requirement.
# Source: Hunt-Pointer-Estevez cone fundamentals, as tabulated in
# Fairchild, "Color Appearance Models", 3rd ed., Table 9.1.
VON_KRIES_MATRIX = (
    (0.4002400, 0.7076000, -0.0808100),
    (-0.2263000, 1.1653200, 0.0457000),
    (0.0000000, 0.0000000, 0.9182200),
)
VON_KRIES_MATRIX_INV = (
    (1.8599364, -1.1293816, 0.2198974),
    (0.3611914, 0.6388125, -0.0000064),
    (0.0000000, 0.0000000, 1.0890636),
)

# XYZ Scaling ("wrong von Kries") -- identity cone matrix, included
# purely as the degenerate/reference case some pipelines expect.
XYZ_SCALING_MATRIX = (
    (1.0, 0.0, 0.0),
    (0.0, 1.0, 0.0),
    (0.0, 0.0, 1.0),
)
XYZ_SCALING_MATRIX_INV = XYZ_SCALING_MATRIX

# ---------------------------------------------------------------------------
# OKLab (Björn Ottosson, 2020) matrices
# ---------------------------------------------------------------------------
# Source: https://bottosson.github.io/posts/oklab/ (public domain /
# CC0-equivalent derivation notes published by the author). Operates
# on LINEAR sRGB, not XYZ directly, though it is conventionally drawn
# hanging off the XYZ node in the conversion graph because the author's
# reference derivation goes linear-sRGB -> LMS -> OKLab and the LMS
# step is itself a linear transform of CIE XYZ with D65 white.
OKLAB_M1 = (
    (0.8189330101, 0.3618667424, -0.1288597137),
    (0.0329845436, 0.9293118715, 0.0361456387),
    (0.0482003018, 0.2643662691, 0.6338517070),
)
OKLAB_M1_INV = (
    (1.2270138511, -0.5577999807, 0.2812561490),
    (-0.0405801784, 1.1122568696, -0.0716766787),
    (-0.0763812845, -0.4214819784, 1.5861632204),
)
OKLAB_M2 = (
    (0.2104542553, 0.7936177850, -0.0040720468),
    (1.9779984951, -2.4285922050, 0.4505937099),
    (0.0259040371, 0.7827717662, -0.8086757660),
)
OKLAB_M2_INV = (
    (1.0000000000, 0.3963377774, 0.2158037573),
    (1.0000000000, -0.1055613458, -0.0638541728),
    (1.0000000000, -0.0894841775, -1.2914855480),
)
# Convenience: linear-sRGB -> LMS in one matrix (M1 above is expressed
# in XYZ terms in Ottosson's derivation; this is the direct linear-RGB
# shortcut matrix he also publishes, and the one this engine actually
# uses for the RGB<->OKLab edge for speed and to avoid compounding
# rounding error through XYZ).
OKLAB_LINEAR_SRGB_TO_LMS = (
    (0.4122214708, 0.5363325363, 0.0514459929),
    (0.2119034982, 0.6806995451, 0.1073969566),
    (0.0883024619, 0.2817188376, 0.6299787005),
)
OKLAB_LMS_TO_LINEAR_SRGB = (
    (4.0767416621, -3.3077115913, 0.2309699292),
    (-1.2684380046, 2.6097574011, -0.3413193965),
    (-0.0041960863, -0.7034186147, 1.7076147010),
)

# ---------------------------------------------------------------------------
# YIQ (NTSC composite colour), source: SMPTE / classic NTSC encoding
# matrix as reproduced in Poynton, "Digital Video and HD", Table 4.3.
# ---------------------------------------------------------------------------
YIQ_FROM_RGB = (
    (0.299, 0.587, 0.114),
    (0.595716, -0.274453, -0.321263),
    (0.211456, -0.522591, 0.311135),
)
YIQ_TO_RGB = (
    (1.0, 0.956295719758948, 0.621024416465261),
    (1.0, -0.272122099319508, -0.647380596825695),
    (1.0, -1.106989016736491, 1.704614998364648),
)

# ---------------------------------------------------------------------------
# WCAG 2.x contrast thresholds (W3C, "Understanding Success Criterion
# 1.4.3 / 1.4.6").
# ---------------------------------------------------------------------------
WCAG_AA_NORMAL = 4.5
WCAG_AA_LARGE = 3.0
WCAG_AAA_NORMAL = 7.0
WCAG_AAA_LARGE = 4.5

# ---------------------------------------------------------------------------
# Visible spectrum bounds used by the spectral subsystem.
# ---------------------------------------------------------------------------
SPECTRAL_MIN_NM = 380.0
SPECTRAL_MAX_NM = 780.0

# General-purpose floating point tolerance for round-trip tests /
# gamut-boundary searches. Not a "physical" constant -- an engineering
# choice, documented here so it is not hard-coded redundantly.
DEFAULT_EPSILON = 1e-9
