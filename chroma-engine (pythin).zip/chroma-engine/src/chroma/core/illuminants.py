"""
chroma.core.illuminants
=========================

A white point (reference white / illuminant) is the XYZ tristimulus
value that a conversion pipeline treats as "white". Every conversion
into or out of XYZ, Lab, LCh, Luv or LChuv is only meaningful relative
to an explicit white point -- this module is what makes that
explicit instead of implicit.

Values below are the standard CIE 1931 2-degree observer tristimulus
values for each illuminant, as published in CIE 15:2004 ("Colorimetry",
3rd edition), Table T.3, and reproduced consistently across reference
sources (ASTM E308-01, Lindbloom). They are given here to 6 decimal
places, Y normalised to 1.0.
"""

from __future__ import annotations

from dataclasses import dataclass

from chroma.core.exceptions import UnknownWhitePointError


@dataclass(frozen=True, slots=True)
class WhitePoint:
    """
    An immutable reference white.

    Attributes
    ----------
    name:
        Short canonical name, e.g. ``"D65"``.
    x, y, z:
        CIE XYZ tristimulus values, Y = 1.0.
    description:
        Human-readable description of the illuminant this represents.
    """

    name: str
    x: float
    y: float
    z: float
    description: str

    @property
    def xyz(self) -> tuple[float, float, float]:
        return (self.x, self.y, self.z)


# CIE 1931 2-degree standard observer tristimulus values.
# Source: CIE 15:2004, Table T.3.
_WHITE_POINTS: dict[str, WhitePoint] = {
    "D50": WhitePoint(
        "D50", 0.964220, 1.000000, 0.825210,
        "CIE Standard Illuminant D50 (horizon light, ~5003K CCT); "
        "conventional reference white for graphic-arts / print workflows.",
    ),
    "D55": WhitePoint(
        "D55", 0.956820, 1.000000, 0.921490,
        "CIE Standard Illuminant D55 (~5503K CCT); mid-morning/afternoon daylight.",
    ),
    "D60": WhitePoint(
        "D60", 0.952646, 1.000000, 1.008825,
        "CIE-derived Illuminant D60 (~6000K CCT); used in ACES colour workflows.",
    ),
    "D65": WhitePoint(
        "D65", 0.950470, 1.000000, 1.088830,
        "CIE Standard Illuminant D65 (average noon daylight, ~6504K CCT); "
        "reference white for sRGB, Display P3 and Rec.2020.",
    ),
    "D75": WhitePoint(
        "D75", 0.949720, 1.000000, 1.226380,
        "CIE Standard Illuminant D75 (~7504K CCT); north-sky daylight.",
    ),
    "E": WhitePoint(
        "E", 1.000000, 1.000000, 1.000000,
        "CIE Standard Illuminant E (equal-energy illuminant); a "
        "mathematical idealisation, not a physically realisable source.",
    ),
    "A": WhitePoint(
        "A", 1.098500, 1.000000, 0.355850,
        "CIE Standard Illuminant A (tungsten-filament incandescent, ~2856K CCT).",
    ),
    "C": WhitePoint(
        "C", 0.980700, 1.000000, 1.182250,
        "CIE Standard Illuminant C (average daylight, obsolete predecessor "
        "of the D-series; ~6774K CCT).",
    ),
}


def get_white_point(name: str) -> WhitePoint:
    """
    Look up a registered white point by name (case-insensitive).

    Raises
    ------
    UnknownWhitePointError
        If ``name`` is not registered. Use :func:`register_white_point`
        to add custom/measured white points (e.g. a characterised
        studio monitor's native white) before referencing them.
    """
    key = name.strip().upper()
    try:
        return _WHITE_POINTS[key]
    except KeyError as exc:
        known = ", ".join(sorted(_WHITE_POINTS))
        raise UnknownWhitePointError(
            f"Unknown white point {name!r}. Known white points: {known}."
        ) from exc


def register_white_point(white_point: WhitePoint, *, overwrite: bool = False) -> None:
    """
    Register a new white point (e.g. a spectrally-measured custom
    illuminant) in the module-level registry.

    This is how Aardvark Imaging can plug in a characterised display's
    native white, or a scanned light source, without modifying Chroma
    Engine's source.
    """
    key = white_point.name.strip().upper()
    if key in _WHITE_POINTS and not overwrite:
        raise ValueError(
            f"White point {white_point.name!r} is already registered; "
            "pass overwrite=True to replace it."
        )
    _WHITE_POINTS[key] = white_point


def list_white_points() -> tuple[str, ...]:
    """Return the names of every registered white point, sorted."""
    return tuple(sorted(_WHITE_POINTS))


# Convenience module-level constants for the most common white points.
D50 = _WHITE_POINTS["D50"]
D55 = _WHITE_POINTS["D55"]
D60 = _WHITE_POINTS["D60"]
D65 = _WHITE_POINTS["D65"]
D75 = _WHITE_POINTS["D75"]
E = _WHITE_POINTS["E"]
A = _WHITE_POINTS["A"]
C = _WHITE_POINTS["C"]
