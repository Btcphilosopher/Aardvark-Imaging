"""
chroma.gamut.strategies
==========================

The signature Chroma Engine query (project spec section 25):

    "Give me the most saturated displayable colour at this lightness
     and hue."

:func:`max_chroma_at` answers it with a numerically robust binary
search rather than a guess or a fixed table, for any of sRGB,
Display P3 or Rec.2020.
"""

from __future__ import annotations

from chroma.core.exceptions import GamutSearchDidNotConvergeError
from chroma.gamut.detection import TargetGamut, in_gamut_channels_oklch

# OKLCh chroma essentially never exceeds this for any physically
# realisable surface colour under D65, so it is a safe search ceiling;
# the search still verifies rather than assuming, expanding further if
# a pathological hue/lightness combination needs it.
_INITIAL_CHROMA_CEILING = 0.5
_ABSOLUTE_CHROMA_CEILING = 4.0


def max_chroma_at(
    lightness: float,
    hue: float,
    target: TargetGamut | str = TargetGamut.SRGB,
    tolerance: float = 1e-5,
    max_iterations: int = 64,
) -> float:
    """
    Binary-search the maximum OKLCh chroma at the given ``lightness``
    (0..1) and ``hue`` (degrees) that remains inside ``target``'s
    displayable gamut.

    Returns 0.0 if even the achromatic point at this lightness is
    already out of gamut (this can legitimately happen only at the
    extreme ends, L=0 or L=1, due to floating-point edge behaviour;
    it is reported rather than silently clamped).
    """
    if not in_gamut_channels_oklch(lightness, 0.0, hue, target):
        return 0.0

    hi = _INITIAL_CHROMA_CEILING
    while in_gamut_channels_oklch(lightness, hi, hue, target):
        hi *= 1.5
        if hi > _ABSOLUTE_CHROMA_CEILING:
            raise GamutSearchDidNotConvergeError(
                f"max_chroma_at(L={lightness}, h={hue}) did not leave gamut "
                f"{target!r} even at chroma={hi:.3f}; this indicates a bug "
                "in the gamut matrices, not a real colour."
            )
    lo = 0.0
    for _ in range(max_iterations):
        mid = (lo + hi) / 2.0
        if in_gamut_channels_oklch(lightness, mid, hue, target):
            lo = mid
        else:
            hi = mid
        if hi - lo < tolerance:
            break
    return lo


def max_chroma_series(
    hue: float,
    target: TargetGamut | str = TargetGamut.SRGB,
    lightness_steps: int = 21,
) -> list[tuple[float, float]]:
    """
    The maximum in-gamut chroma at each of ``lightness_steps`` evenly
    spaced lightness values (0..1) for a fixed ``hue`` -- i.e. a single
    slice through the gamut-boundary "tongue" shape, useful for
    rendering a gamut cross-section (see chroma.render.gamut_map).
    """
    if lightness_steps < 2:
        raise ValueError("lightness_steps must be >= 2")
    step = 1.0 / (lightness_steps - 1)
    return [
        (i * step, max_chroma_at(i * step, hue, target))
        for i in range(lightness_steps)
    ]
