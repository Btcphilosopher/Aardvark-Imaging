"""chroma.gamut -- gamut membership testing, mapping strategies, and maximum-chroma search."""

from chroma.gamut.clipping import clip_to_gamut
from chroma.gamut.detection import GamutReport, TargetGamut, gamut_report, is_in_gamut
from chroma.gamut.mapping import GamutMappingMethod, GamutMappingResult, map_to_gamut, map_to_gamut_report
from chroma.gamut.strategies import max_chroma_at, max_chroma_series

__all__ = [
    "TargetGamut", "GamutReport", "gamut_report", "is_in_gamut",
    "clip_to_gamut",
    "GamutMappingMethod", "GamutMappingResult", "map_to_gamut", "map_to_gamut_report",
    "max_chroma_at", "max_chroma_series",
]
