"""
chroma.gamut.detection
=========================

A colour is only "in gamut" RELATIVE TO a specific target device
gamut -- there is no such thing as a colour being universally
displayable (project spec section 76). This module makes that
relationship explicit rather than assumed.

We check gamut membership by converting to the target's gamma-encoded
RGB representation and testing whether every channel lands in
``[0 - tolerance, 1 + tolerance]``. The tolerance exists purely to
absorb floating-point round-trip noise (typically < 1e-10 in practice
for well-conditioned matrices); it is NOT a perceptual fudge factor.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from chroma.core.colour import Colour
from chroma.core.spaces import ColourSpace


class TargetGamut(str, Enum):
    SRGB = "srgb"
    DISPLAY_P3 = "display-p3"
    REC2020 = "rec2020"


_ENCODED_SPACE_FOR: dict[TargetGamut, ColourSpace] = {
    TargetGamut.SRGB: ColourSpace.SRGB,
    TargetGamut.DISPLAY_P3: ColourSpace.DISPLAY_P3,
    TargetGamut.REC2020: ColourSpace.REC2020,
}


@dataclass(frozen=True)
class GamutReport:
    """The result of a gamut membership check."""

    target: TargetGamut
    in_gamut: bool
    channel_values: tuple[float, ...]
    excess: tuple[float, float, float]  # how far each channel is below 0 or above 1 (0 if in range)
    max_excess: float


def _excess(values: tuple[float, ...]) -> tuple[tuple[float, ...], float]:
    excesses = tuple(max(0.0 - v, v - 1.0, 0.0) for v in values)
    return excesses, max(excesses) if excesses else 0.0


def gamut_report(colour: Colour, target: TargetGamut | str = TargetGamut.SRGB, tolerance: float = 1e-4) -> GamutReport:
    """Full diagnostic report of ``colour`` against ``target``'s encoded RGB cube."""
    target = TargetGamut(target)
    encoded_space = _ENCODED_SPACE_FOR[target]
    encoded = colour.convert(encoded_space)
    excesses, max_exc = _excess(encoded.channels)
    return GamutReport(
        target=target,
        in_gamut=max_exc <= tolerance,
        channel_values=encoded.channels,
        excess=excesses,  # type: ignore[arg-type]
        max_excess=max_exc,
    )


def is_in_gamut(colour: Colour, target: TargetGamut | str = TargetGamut.SRGB, tolerance: float = 1e-4) -> bool:
    """``True`` if ``colour`` lies inside ``target``'s displayable RGB cube."""
    return gamut_report(colour, target, tolerance).in_gamut


def in_gamut_channels_oklch(L: float, C: float, h: float, target: TargetGamut | str = TargetGamut.SRGB, tolerance: float = 1e-4) -> bool:
    """
    Convenience used heavily by :mod:`chroma.gamut.strategies` for the
    maximum-chroma binary search: build an OKLCh colour directly and
    test gamut membership without going through a full ``Colour``
    round trip each time (kept as a thin wrapper for readability, not
    a meaningfully different code path).
    """
    colour = Colour.from_space("oklch", L=L, C=C, h=h)
    return is_in_gamut(colour, target, tolerance)
