"""
chroma.gamut.clipping
========================

The crudest possible gamut-mapping strategy: clamp each encoded RGB
channel independently into [0, 1]. Cheap, fast, and can visibly shift
hue and chroma in ways :mod:`chroma.gamut.mapping`'s other strategies
avoid -- kept as an explicit, honestly-named baseline rather than a
hidden default.
"""

from __future__ import annotations

from chroma.core.colour import Colour
from chroma.gamut.detection import TargetGamut, _ENCODED_SPACE_FOR


def clip_to_gamut(colour: Colour, target: TargetGamut | str = TargetGamut.SRGB) -> Colour:
    target = TargetGamut(target)
    encoded_space = _ENCODED_SPACE_FOR[target]
    encoded = colour.convert(encoded_space)
    clipped = tuple(min(1.0, max(0.0, v)) for v in encoded.channels)
    result = Colour(encoded.space, clipped, white=encoded.white, alpha=colour.alpha)
    return result.convert(colour.space, white=colour.white if colour.white else None)
