"""
chroma.gamut.mapping
=======================

Several gamut-mapping strategies, all reachable through one entry
point, :func:`map_to_gamut`, so callers can compare them directly
(project spec section 24)::

    mapped = colour.map_to_gamut("srgb", method="compress_chroma")

Every strategy returns a :class:`GamutMappingResult` carrying the
original colour, the mapped colour, and the perceptual delta between
them (OKLab Euclidean distance), so "how much did this cost me" is
always visible rather than hidden.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Callable

from chroma.core.colour import Colour
from chroma.core.spaces import ColourSpace
from chroma.gamut.clipping import clip_to_gamut
from chroma.gamut.detection import TargetGamut, _ENCODED_SPACE_FOR, gamut_report
from chroma.gamut.strategies import max_chroma_at


class GamutMappingMethod(str, Enum):
    CLIP = "clip"
    SCALE = "scale"
    COMPRESS_CHROMA = "compress_chroma"
    PRESERVE_LIGHTNESS = "preserve_lightness"
    PERCEPTUAL_COMPRESS = "perceptual_compress"


@dataclass(frozen=True)
class GamutMappingResult:
    original: Colour
    mapped: Colour
    method: GamutMappingMethod
    target: TargetGamut
    delta_oklab: float


def _oklab_delta(a: Colour, b: Colour) -> float:
    import math

    ca, cb = a.convert(ColourSpace.OKLAB), b.convert(ColourSpace.OKLAB)
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(ca.channels, cb.channels)))


def _scale_strategy(colour: Colour, target: TargetGamut) -> Colour:
    """
    Uniformly scale linear-light RGB so the single most out-of-range
    channel lands exactly at 1.0, preserving channel RATIOS (hence hue
    in a loose RGB sense) rather than clamping independently. Applied
    in LINEAR RGB, never in gamma-encoded RGB (scaling gamma-encoded
    values is not physically meaningful -- see project spec section 7).
    """
    encoded_space = _ENCODED_SPACE_FOR[target]
    linear_space = {
        ColourSpace.SRGB: ColourSpace.LINEAR_RGB,
        ColourSpace.DISPLAY_P3: ColourSpace.LINEAR_DISPLAY_P3,
        ColourSpace.REC2020: ColourSpace.LINEAR_REC2020,
    }[encoded_space]
    linear = colour.convert(linear_space)
    highest = max(linear.channels)
    lowest = min(linear.channels)
    if highest <= 1.0 and lowest >= 0.0:
        return colour
    scale = 1.0 / highest if highest > 1.0 else 1.0
    scaled = tuple(max(0.0, v * scale) for v in linear.channels)
    result = Colour(linear.space, scaled, alpha=colour.alpha)
    return result.convert(colour.space, white=colour.white)


def _compress_chroma_strategy(colour: Colour, target: TargetGamut) -> Colour:
    """
    Convert to OKLCh, keep L and h fixed, and reduce C to the exact
    in-gamut boundary found by :func:`chroma.gamut.strategies.max_chroma_at`.
    "preserve_lightness" is an alias of this strategy in the current
    implementation: holding L (and h) fixed while searching C IS what
    preserving lightness means here. They are named separately because
    a future, more sophisticated implementation (e.g. one that also
    permits small, perceptually-bounded lightness shifts near the
    gamut cusp, as CSS Color 4's algorithm does) would meaningfully
    split them -- see docs/GAMUT.md.
    """
    oklch = colour.convert(ColourSpace.OKLCH)
    L, C, h = oklch.channels
    boundary = max_chroma_at(L, h, target)
    if C <= boundary:
        return colour
    mapped = Colour.from_space("oklch", L=L, C=boundary, h=h, alpha=colour.alpha)
    return mapped.convert(colour.space, white=colour.white)


def _perceptual_compress_strategy(colour: Colour, target: TargetGamut) -> Colour:
    """
    A simplified relative of the CSS Color 4 "css-gamut-map" algorithm:
    binary-search chroma reduction (as in ``compress_chroma``) but stop
    just short of the hard boundary, then finish with a very small
    clip pass to absorb the residual. In practice this differs from
    ``compress_chroma`` only by a fraction of a `just-noticeable
    difference` and is provided mainly as an extension point for a
    fuller CSS4-style algorithm (soft cusp handling, per-channel JND
    tolerance) -- see docs/GAMUT.md for exactly what is and is not
    implemented here. Do not treat this as a certified CSS Color 4
    implementation.
    """
    oklch = colour.convert(ColourSpace.OKLCH)
    L, C, h = oklch.channels
    boundary = max_chroma_at(L, h, target)
    if C <= boundary:
        return colour
    # Back off by a small epsilon fraction of the boundary rather than
    # landing exactly on it, then let a final clip mop up any residual
    # floating-point excursion -- a cheap stand-in for CSS4's more
    # careful "epsilon" convergence criterion.
    epsilon_fraction = 0.998
    mapped = Colour.from_space("oklch", L=L, C=boundary * epsilon_fraction, h=h, alpha=colour.alpha)
    mapped = mapped.convert(colour.space, white=colour.white)
    return clip_to_gamut(mapped, target)


_STRATEGIES: dict[GamutMappingMethod, Callable[[Colour, TargetGamut], Colour]] = {
    GamutMappingMethod.CLIP: lambda c, t: clip_to_gamut(c, t),
    GamutMappingMethod.SCALE: _scale_strategy,
    GamutMappingMethod.COMPRESS_CHROMA: _compress_chroma_strategy,
    GamutMappingMethod.PRESERVE_LIGHTNESS: _compress_chroma_strategy,
    GamutMappingMethod.PERCEPTUAL_COMPRESS: _perceptual_compress_strategy,
}


def map_to_gamut(
    colour: Colour,
    target: TargetGamut | str = TargetGamut.SRGB,
    method: GamutMappingMethod | str = GamutMappingMethod.COMPRESS_CHROMA,
) -> Colour:
    """Map ``colour`` into ``target``'s gamut using ``method``. See module docstring."""
    target = TargetGamut(target)
    method = GamutMappingMethod(method)
    if gamut_report(colour, target).in_gamut:
        return colour
    return _STRATEGIES[method](colour, target)


def map_to_gamut_report(
    colour: Colour,
    target: TargetGamut | str = TargetGamut.SRGB,
    method: GamutMappingMethod | str = GamutMappingMethod.COMPRESS_CHROMA,
) -> GamutMappingResult:
    """Like :func:`map_to_gamut` but returns the full before/after/delta report."""
    target = TargetGamut(target)
    method = GamutMappingMethod(method)
    mapped = map_to_gamut(colour, target, method)
    return GamutMappingResult(
        original=colour, mapped=mapped, method=method, target=target,
        delta_oklab=_oklab_delta(colour, mapped),
    )
