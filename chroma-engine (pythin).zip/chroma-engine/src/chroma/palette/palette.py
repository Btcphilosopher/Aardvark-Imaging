"""
chroma.palette.palette
=========================

A :class:`Palette` is a named, orderable, role-tagged collection of
colours (project spec section 37) -- not just a bare list. Roles let
Aardvark Imaging ask "what's the accent colour in this palette"
instead of "index 3".
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from types import MappingProxyType
from typing import Any, Mapping

from chroma.core.colour import Colour


class Role(str, Enum):
    PRIMARY = "primary"
    SECONDARY = "secondary"
    ACCENT = "accent"
    BACKGROUND = "background"
    FOREGROUND = "foreground"
    SHADOW = "shadow"
    HIGHLIGHT = "highlight"
    WARNING = "warning"
    SUCCESS = "success"
    INFO = "info"


@dataclass(frozen=True)
class PaletteEntry:
    colour: Colour
    name: str | None = None
    role: Role | None = None
    metadata: Mapping[str, Any] = field(default_factory=lambda: MappingProxyType({}))


@dataclass(frozen=True)
class Palette:
    entries: tuple[PaletteEntry, ...]
    name: str | None = None
    source: str | None = None

    def __len__(self) -> int:
        return len(self.entries)

    def __iter__(self):
        return iter(self.entries)

    def colours(self) -> tuple[Colour, ...]:
        return tuple(e.colour for e in self.entries)

    def by_role(self, role: Role | str) -> tuple[PaletteEntry, ...]:
        role = Role(role)
        return tuple(e for e in self.entries if e.role == role)

    def with_roles(self, roles: list[Role | str | None]) -> "Palette":
        """Return a new Palette with roles assigned positionally from ``roles``."""
        if len(roles) != len(self.entries):
            raise ValueError(f"Expected {len(self.entries)} roles, got {len(roles)}.")
        new_entries = tuple(
            PaletteEntry(e.colour, e.name, Role(r) if r is not None else None, e.metadata)
            for e, r in zip(self.entries, roles)
        )
        return Palette(new_entries, name=self.name, source=self.source)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "source": self.source,
            "entries": [
                {
                    "colour": e.colour.to_dict(),
                    "name": e.name,
                    "role": e.role.value if e.role else None,
                    "metadata": dict(e.metadata),
                }
                for e in self.entries
            ],
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "Palette":
        entries = tuple(
            PaletteEntry(
                Colour.from_dict(e["colour"]),
                name=e.get("name"),
                role=Role(e["role"]) if e.get("role") else None,
                metadata=e.get("metadata", {}),
            )
            for e in data["entries"]
        )
        return cls(entries, name=data.get("name"), source=data.get("source"))

    @classmethod
    def from_colours(cls, colours: list[Colour], name: str | None = None, source: str | None = None) -> "Palette":
        return cls(tuple(PaletteEntry(c) for c in colours), name=name, source=source)
