"""chroma.palette -- palette data model and algorithmic generation."""

from chroma.palette.generator import PaletteMethod, generate_palette
from chroma.palette.palette import Palette, PaletteEntry, Role

__all__ = ["Palette", "PaletteEntry", "Role", "generate_palette", "PaletteMethod"]
