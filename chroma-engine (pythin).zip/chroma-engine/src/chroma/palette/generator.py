"""
chroma.palette.generator
===========================

Algorithmic palette generation from one seed colour (project spec
section 38). Every method is deterministic given the same seed and
parameters -- no hidden randomness (see project spec section 57,
"Reproducibility": methods that DO use randomness, like
``chroma.palette.clustering``, take an explicit ``seed``).
"""

from __future__ import annotations

from enum import Enum

from chroma.contrast.wcag import contrast_ratio
from chroma.core.colour import Colour
from chroma.core.spaces import ColourSpace
from chroma.gamut.detection import TargetGamut
from chroma.gamut.strategies import max_chroma_at
from chroma.palette.palette import Palette


class PaletteMethod(str, Enum):
    MONOCHROMATIC = "monochromatic"
    ANALOGOUS = "analogous"
    COMPLEMENTARY = "complementary"
    TRIADIC = "triadic"
    PERCEPTUAL = "perceptual"          # maximally hue-distinct at fixed L, C
    CONTRAST_OPTIMISED = "contrast_optimised"
    GAMUT_AWARE = "gamut_aware"        # every colour sits exactly on the gamut boundary


def _oklch(colour: Colour) -> tuple[float, float, float]:
    return colour.convert(ColourSpace.OKLCH).channels  # type: ignore[return-value]


def _from_oklch(L: float, C: float, h: float, alpha: float = 1.0) -> Colour:
    return Colour.from_space("oklch", L=L, C=C, h=h % 360.0, alpha=alpha)


def generate_palette(
    base: Colour,
    method: PaletteMethod | str = PaletteMethod.ANALOGOUS,
    size: int = 5,
    target: TargetGamut | str = TargetGamut.SRGB,
) -> Palette:
    """Generate a ``size``-colour :class:`Palette` from ``base`` using ``method``."""
    method = PaletteMethod(method)
    L, C, h = _oklch(base)

    if method == PaletteMethod.MONOCHROMATIC:
        lo, hi = 0.08, 0.92
        colours = [
            _from_oklch(lo + (hi - lo) * i / max(size - 1, 1), C, h)
            for i in range(size)
        ]
    elif method == PaletteMethod.ANALOGOUS:
        span = 60.0
        colours = [
            _from_oklch(L, C, h - span / 2 + span * i / max(size - 1, 1))
            for i in range(size)
        ]
    elif method == PaletteMethod.COMPLEMENTARY:
        colours = []
        for i in range(size):
            hue = h if i % 2 == 0 else h + 180.0
            lightness_shift = (i // 2) * 0.12
            colours.append(_from_oklch(min(0.95, L + lightness_shift), C, hue))
    elif method == PaletteMethod.TRIADIC:
        colours = [_from_oklch(L, C, h + 120.0 * i) for i in range(size)]
    elif method == PaletteMethod.PERCEPTUAL:
        colours = [_from_oklch(L, C, h + 360.0 * i / size) for i in range(size)]
    elif method == PaletteMethod.CONTRAST_OPTIMISED:
        colours = _contrast_optimised(base, size)
    elif method == PaletteMethod.GAMUT_AWARE:
        colours = []
        for i in range(size):
            hue = h + 360.0 * i / size
            boundary = max_chroma_at(L, hue, target)
            colours.append(_from_oklch(L, boundary, hue))
    else:  # pragma: no cover
        raise ValueError(f"Unhandled palette method: {method!r}")

    palette_colours = [c.convert(base.space, white=base.white) for c in colours]
    return Palette.from_colours(palette_colours, name=f"{method.value} from {base.hex()}", source=method.value)


def _contrast_optimised(base: Colour, size: int, candidate_count: int = 72) -> list[Colour]:
    """
    Greedy max-min WCAG contrast selection: start from ``base``, then
    repeatedly add whichever of ``candidate_count`` evenly spaced hue
    candidates maximises the MINIMUM pairwise contrast ratio against
    every colour already chosen. A simple, honest greedy heuristic --
    not a claim of global optimality.
    """
    L, C, h0 = _oklch(base)
    candidates = [_from_oklch(L, C, h0 + 360.0 * i / candidate_count) for i in range(candidate_count)]
    chosen = [base]
    while len(chosen) < size and candidates:
        best_candidate = None
        best_score = -1.0
        for cand in candidates:
            score = min(contrast_ratio(cand, c) for c in chosen)
            if score > best_score:
                best_score = score
                best_candidate = cand
        chosen.append(best_candidate)
        candidates.remove(best_candidate)
    return chosen
