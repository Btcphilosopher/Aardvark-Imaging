"""
chroma.gradient.gradient
===========================

A :class:`Gradient` is an ordered list of :class:`Stop` (position,
colour) pairs plus an easing function. Sampling at any ``t`` finds the
two bracketing stops and interpolates between them (project spec
section 31).

Linear, radial and angular gradients are all the SAME 1-D machinery
underneath -- what differs is only how a 2-D point gets turned into a
scalar ``t`` before sampling. :func:`radial_t` and :func:`angular_t`
provide that mapping; :meth:`Gradient.sample_point` combines them so a
caller doing per-pixel rendering doesn't have to.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import Enum

from chroma.core.colour import Colour
from chroma.core.spaces import ColourSpace
from chroma.interpolation.engine import HueInterpolationMode, interpolate


@dataclass(frozen=True)
class Stop:
    position: float  # 0..1
    colour: Colour


class Easing(str, Enum):
    LINEAR = "linear"
    SMOOTHSTEP = "smoothstep"
    EASE_IN = "ease_in"
    EASE_OUT = "ease_out"
    EASE_IN_OUT = "ease_in_out"


def _ease(t: float, easing: Easing) -> float:
    t = 0.0 if t < 0.0 else (1.0 if t > 1.0 else t)
    if easing == Easing.LINEAR:
        return t
    if easing == Easing.SMOOTHSTEP:
        return t * t * (3.0 - 2.0 * t)
    if easing == Easing.EASE_IN:
        return t * t
    if easing == Easing.EASE_OUT:
        return 1.0 - (1.0 - t) * (1.0 - t)
    if easing == Easing.EASE_IN_OUT:
        return 0.5 * (1.0 - math.cos(math.pi * t))
    raise ValueError(f"Unknown easing: {easing!r}")  # pragma: no cover


def cubic_bezier_easing(p1x: float, p1y: float, p2x: float, p2y: float):
    """
    Build a CSS-style cubic-bezier(p1x, p1y, p2x, p2y) easing function
    (the same 4-parameter form as CSS ``transition-timing-function``).
    Solved numerically (bisection on the bezier's x(u) = t) rather than
    via a closed form, since cubic bezier easing curves have no simple
    algebraic inverse in general.
    """

    def bezier(u: float, a: float, b: float) -> float:
        return 3 * (1 - u) ** 2 * u * a + 3 * (1 - u) * u ** 2 * b + u ** 3

    def curve(t: float) -> float:
        lo, hi = 0.0, 1.0
        for _ in range(40):
            mid = (lo + hi) / 2.0
            x = bezier(mid, p1x, p2x)
            if x < t:
                lo = mid
            else:
                hi = mid
        u = (lo + hi) / 2.0
        return bezier(u, p1y, p2y)

    return curve


@dataclass(frozen=True)
class Gradient:
    stops: tuple[Stop, ...]
    space: ColourSpace = ColourSpace.OKLAB
    hue_mode: HueInterpolationMode = HueInterpolationMode.SHORTEST
    easing: Easing = Easing.LINEAR

    def __post_init__(self) -> None:
        if len(self.stops) < 2:
            raise ValueError("A gradient needs at least 2 stops.")
        ordered = tuple(sorted(self.stops, key=lambda s: s.position))
        object.__setattr__(self, "stops", ordered)

    @classmethod
    def from_colours(
        cls,
        colours: list[Colour],
        space: ColourSpace | str = ColourSpace.OKLAB,
        hue_mode: HueInterpolationMode | str = HueInterpolationMode.SHORTEST,
        easing: Easing | str = Easing.LINEAR,
    ) -> "Gradient":
        """Evenly-spaced stops from a plain list of colours."""
        n = len(colours)
        positions = [i / (n - 1) for i in range(n)] if n > 1 else [0.0]
        return cls(
            tuple(Stop(p, c) for p, c in zip(positions, colours)),
            space=ColourSpace(space), hue_mode=HueInterpolationMode(hue_mode), easing=Easing(easing),
        )

    def sample(self, t: float) -> Colour:
        """Sample the gradient at ``t`` (0..1, clamped)."""
        t = 0.0 if t < 0.0 else (1.0 if t > 1.0 else t)
        stops = self.stops
        if t <= stops[0].position:
            return stops[0].colour
        if t >= stops[-1].position:
            return stops[-1].colour
        for left, right in zip(stops, stops[1:]):
            if left.position <= t <= right.position:
                span = right.position - left.position
                local_t = 0.0 if span == 0 else (t - left.position) / span
                eased = _ease(local_t, self.easing) if isinstance(self.easing, Easing) else local_t
                return interpolate(left.colour, right.colour, eased, self.space, self.hue_mode)
        return stops[-1].colour  # pragma: no cover - defensive

    def sample_series(self, steps: int) -> list[Colour]:
        """``steps`` evenly spaced samples across the full gradient, inclusive of both ends."""
        if steps < 2:
            raise ValueError("sample_series needs steps >= 2")
        return [self.sample(i / (steps - 1)) for i in range(steps)]

    # -- coordinate-space helpers for radial / angular rendering -----
    def sample_radial(self, x: float, y: float, cx: float = 0.5, cy: float = 0.5, radius: float = 0.5) -> Colour:
        return self.sample(radial_t(x, y, cx, cy, radius))

    def sample_angular(self, x: float, y: float, cx: float = 0.5, cy: float = 0.5, start_degrees: float = 0.0) -> Colour:
        return self.sample(angular_t(x, y, cx, cy, start_degrees))


def radial_t(x: float, y: float, cx: float = 0.5, cy: float = 0.5, radius: float = 0.5) -> float:
    """Map a 2-D point to ``t`` = normalised distance from ``(cx, cy)``, for radial gradients."""
    dist = math.hypot(x - cx, y - cy)
    return 0.0 if radius == 0.0 else dist / radius


def angular_t(x: float, y: float, cx: float = 0.5, cy: float = 0.5, start_degrees: float = 0.0) -> float:
    """Map a 2-D point to ``t`` = normalised angle around ``(cx, cy)``, for angular (conic) gradients."""
    angle = (math.degrees(math.atan2(y - cy, x - cx)) - start_degrees) % 360.0
    return angle / 360.0
