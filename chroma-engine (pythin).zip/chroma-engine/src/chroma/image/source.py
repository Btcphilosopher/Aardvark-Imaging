"""
chroma.image.source
======================

Chroma Engine's core never imports Pillow, OpenCV or NumPy (project
spec section 44). Instead, anything that can hand back a
:class:`~chroma.core.colour.Colour` for an (x, y) pixel implements
:class:`ImageColourSource`, and every function in :mod:`chroma.image`
is written against that interface. Aardvark Imaging (or any adapter
package) implements this once against its real decoded-image buffer;
:class:`ListImageSource` here is a dependency-free reference
implementation used by the engine's own tests/examples.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from chroma.core.colour import Colour


class ImageColourSource(ABC):
    """The minimal interface :mod:`chroma.image`'s analysis functions need from an image."""

    @property
    @abstractmethod
    def width(self) -> int: ...

    @property
    @abstractmethod
    def height(self) -> int: ...

    @abstractmethod
    def get_pixel(self, x: int, y: int) -> Colour: ...

    def iter_pixels(self):
        for y in range(self.height):
            for x in range(self.width):
                yield self.get_pixel(x, y)


class ListImageSource(ImageColourSource):
    """A plain ``list[list[Colour]]`` (row-major) wrapped as an :class:`ImageColourSource`. No dependencies -- used by tests, examples, and as a template for real adapters."""

    def __init__(self, rows: list[list[Colour]]) -> None:
        if not rows or not rows[0]:
            raise ValueError("ListImageSource needs at least one row and column.")
        row_len = len(rows[0])
        if any(len(r) != row_len for r in rows):
            raise ValueError("All rows must have the same length.")
        self._rows = rows

    @property
    def width(self) -> int:
        return len(self._rows[0])

    @property
    def height(self) -> int:
        return len(self._rows)

    def get_pixel(self, x: int, y: int) -> Colour:
        return self._rows[y][x]
