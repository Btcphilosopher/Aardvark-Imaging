"""
chroma.image.histogram
=========================

A histogram over any single scalar channel of an image (project spec
section 45): RGB, HSV, Lab, OKLab channels, luminance, or hue. Bin
count is caller-configurable; the standard descriptive statistics
(mean, median, mode, variance, standard deviation, percentiles,
Shannon entropy) are all computed directly from the binned data using
only the ``statistics``/``math`` standard-library modules.
"""

from __future__ import annotations

import math
import statistics as _stats
from dataclasses import dataclass

from chroma.contrast.wcag import relative_luminance
from chroma.core.colour import Colour
from chroma.core.spaces import ColourSpace
from chroma.image.source import ImageColourSource

_CHANNEL_SPECS: dict[str, tuple[ColourSpace | None, str | None, tuple[float, float]]] = {
    "r": (ColourSpace.SRGB, "r", (0.0, 1.0)),
    "g": (ColourSpace.SRGB, "g", (0.0, 1.0)),
    "b": (ColourSpace.SRGB, "b", (0.0, 1.0)),
    "hue": (ColourSpace.OKLCH, "h", (0.0, 360.0)),
    "chroma": (ColourSpace.OKLCH, "C", (0.0, 0.4)),
    "lightness": (ColourSpace.OKLCH, "L", (0.0, 1.0)),
    "luminance": (None, None, (0.0, 1.0)),  # special-cased: WCAG relative luminance
}


def _extract(colour: Colour, channel: str) -> float:
    if channel == "luminance":
        return relative_luminance(colour)
    space, name, _range = _CHANNEL_SPECS[channel]
    return colour.convert(space).channel(name)


@dataclass(frozen=True)
class Histogram:
    channel: str
    bin_edges: tuple[float, ...]
    counts: tuple[int, ...]

    def total(self) -> int:
        return sum(self.counts)

    def normalised(self) -> tuple[float, ...]:
        total = self.total()
        return tuple(c / total for c in self.counts) if total else tuple(0.0 for _ in self.counts)

    def entropy(self) -> float:
        """Shannon entropy in bits over the binned distribution."""
        probs = [p for p in self.normalised() if p > 0.0]
        return -sum(p * math.log2(p) for p in probs)

    def bin_centre(self, i: int) -> float:
        return (self.bin_edges[i] + self.bin_edges[i + 1]) / 2.0

    def mode_bin_centre(self) -> float:
        return self.bin_centre(max(range(len(self.counts)), key=lambda i: self.counts[i]))


def build_histogram(source: ImageColourSource, channel: str = "luminance", bins: int = 32) -> Histogram:
    if channel not in _CHANNEL_SPECS:
        raise ValueError(f"Unknown histogram channel {channel!r}. Known: {sorted(_CHANNEL_SPECS)}")
    lo, hi = _CHANNEL_SPECS[channel][2]
    width = (hi - lo) / bins
    counts = [0] * bins
    for px in source.iter_pixels():
        v = _extract(px, channel)
        idx = min(bins - 1, max(0, int((v - lo) / width))) if width else 0
        counts[idx] += 1
    edges = tuple(lo + i * width for i in range(bins + 1))
    return Histogram(channel, edges, tuple(counts))


def channel_values(source: ImageColourSource, channel: str) -> list[float]:
    """Raw per-pixel scalar values (not binned) -- used for exact mean/median/percentiles rather than bin-approximated ones."""
    return [_extract(px, channel) for px in source.iter_pixels()]


@dataclass(frozen=True)
class ChannelStatistics:
    channel: str
    mean: float
    median: float
    mode: float
    variance: float
    std_dev: float
    percentiles: dict[int, float]
    entropy_bits: float


def channel_statistics(source: ImageColourSource, channel: str = "luminance", bins: int = 32, percentiles: tuple[int, ...] = (5, 25, 50, 75, 95)) -> ChannelStatistics:
    values = channel_values(source, channel)
    hist = build_histogram(source, channel, bins)
    sorted_values = sorted(values)

    def percentile(p: int) -> float:
        if not sorted_values:
            return 0.0
        k = (len(sorted_values) - 1) * (p / 100.0)
        f, c = math.floor(k), math.ceil(k)
        if f == c:
            return sorted_values[int(k)]
        return sorted_values[int(f)] * (c - k) + sorted_values[int(c)] * (k - f)

    return ChannelStatistics(
        channel=channel,
        mean=_stats.fmean(values) if values else 0.0,
        median=_stats.median(values) if values else 0.0,
        mode=hist.mode_bin_centre(),
        variance=_stats.pvariance(values) if len(values) > 1 else 0.0,
        std_dev=_stats.pstdev(values) if len(values) > 1 else 0.0,
        percentiles={p: percentile(p) for p in percentiles},
        entropy_bits=hist.entropy(),
    )
