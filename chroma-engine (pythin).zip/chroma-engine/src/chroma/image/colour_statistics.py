"""
chroma.image.colour_statistics
=================================

Bundles :mod:`chroma.image.histogram` per-channel statistics across
the channels that matter for describing an image's colour content
(project spec sections 44 & 47): luminance, hue, chroma, lightness,
and raw R/G/B.
"""

from __future__ import annotations

from dataclasses import dataclass

from chroma.image.histogram import ChannelStatistics, channel_statistics
from chroma.image.source import ImageColourSource

_CHANNELS = ("luminance", "hue", "chroma", "lightness", "r", "g", "b")


@dataclass(frozen=True)
class ImageColourStatistics:
    per_channel: dict[str, ChannelStatistics]

    @property
    def colour_entropy(self) -> float:
        """Mean of R/G/B channel entropies -- a simple proxy for "how varied is the colour content"."""
        return sum(self.per_channel[c].entropy_bits for c in ("r", "g", "b")) / 3.0

    @property
    def luminance_entropy(self) -> float:
        return self.per_channel["luminance"].entropy_bits

    @property
    def hue_entropy(self) -> float:
        return self.per_channel["hue"].entropy_bits

    @property
    def chroma_entropy(self) -> float:
        return self.per_channel["chroma"].entropy_bits


def colour_statistics(source: ImageColourSource, bins: int = 32) -> ImageColourStatistics:
    return ImageColourStatistics({ch: channel_statistics(source, ch, bins) for ch in _CHANNELS})
