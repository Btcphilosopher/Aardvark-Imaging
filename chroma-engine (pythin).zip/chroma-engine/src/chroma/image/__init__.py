"""
chroma.image -- Pillow/NumPy-free image colour analysis (project spec
section 44). Everything here works against the
:class:`~chroma.image.source.ImageColourSource` interface; real
adapters (Pillow, a decoded frame buffer, ...) implement that
interface and every function below works unmodified.
"""

from __future__ import annotations

from chroma.algorithms.quantisation import nearest_colour_quantiser
from chroma.core.colour import Colour
from chroma.distance.metrics import DistanceMethod
from chroma.distance.nearest import NearestMatch, nearest
from chroma.image.colour_statistics import ImageColourStatistics, colour_statistics
from chroma.image.dominant import DominantColour, DominantMethod, dominant_colours
from chroma.image.histogram import ChannelStatistics, Histogram, build_histogram, channel_statistics, channel_values
from chroma.image.sampling import sample_grid, sample_pixel, sample_region
from chroma.image.source import ImageColourSource, ListImageSource
from chroma.palette.palette import Palette


def palette_from_image(source: ImageColourSource, size: int = 8, method: DominantMethod | str = DominantMethod.KMEANS) -> Palette:
    """The dominant colours of ``source``, packaged as a :class:`~chroma.palette.palette.Palette`."""
    dominant = dominant_colours(source, n=size, method=method)
    return Palette.from_colours([d.colour for d in dominant], name="palette from image", source="chroma.image.palette_from_image")


def nearest_palette_colour(colour: Colour, palette: Palette, method: DistanceMethod | str = DistanceMethod.CIEDE2000) -> NearestMatch:
    return nearest(colour, palette.colours(), method)


def quantise_image_colours(source: ImageColourSource, palette: Palette) -> list[list[Colour]]:
    """Snap every pixel of ``source`` to its nearest colour in ``palette``."""
    quantiser = nearest_colour_quantiser(palette.colours())
    return [[quantiser(source.get_pixel(x, y)) for x in range(source.width)] for y in range(source.height)]


__all__ = [
    "ImageColourSource", "ListImageSource",
    "sample_pixel", "sample_region", "sample_grid",
    "Histogram", "build_histogram", "channel_values", "ChannelStatistics", "channel_statistics",
    "ImageColourStatistics", "colour_statistics",
    "DominantColour", "DominantMethod", "dominant_colours",
    "palette_from_image", "nearest_palette_colour", "quantise_image_colours",
]
