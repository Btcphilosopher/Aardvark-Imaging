"""
chroma.image.dominant
========================

Dominant-colour extraction (project spec section 46) over any
:class:`~chroma.image.source.ImageColourSource`, via three methods:
exact-frequency counting, uniform-quantisation bucketing, or the
pure-Python k-means clustering in :mod:`chroma.algorithms.quantisation`.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from enum import Enum

from chroma.algorithms.quantisation import kmeans_quantise, uniform_quantise_in_space
from chroma.core.colour import Colour
from chroma.core.spaces import ColourSpace
from chroma.distance.metrics import DistanceMethod, distance
from chroma.image.source import ImageColourSource


class DominantMethod(str, Enum):
    FREQUENCY = "frequency"
    QUANTISE = "quantise"
    KMEANS = "kmeans"


@dataclass(frozen=True)
class DominantColour:
    colour: Colour
    weight: int
    percentage: float


def dominant_colours(
    source: ImageColourSource,
    n: int = 5,
    method: DominantMethod | str = DominantMethod.QUANTISE,
    bins_per_channel: int = 4,
    seed: int = 0,
) -> list[DominantColour]:
    method = DominantMethod(method)
    pixels = list(source.iter_pixels())
    total = len(pixels)
    if total == 0:
        return []

    if method == DominantMethod.FREQUENCY:
        counter = Counter(p.hex() for p in pixels)
        return [DominantColour(Colour.hex(h), cnt, cnt / total) for h, cnt in counter.most_common(n)]

    if method == DominantMethod.QUANTISE:
        counter = Counter(uniform_quantise_in_space(p, bins_per_channel, ColourSpace.SRGB).hex() for p in pixels)
        return [DominantColour(Colour.hex(h), cnt, cnt / total) for h, cnt in counter.most_common(n)]

    if method == DominantMethod.KMEANS:
        centres = kmeans_quantise(pixels, n, seed=seed)
        counts = [0] * len(centres)
        for p in pixels:
            idx = min(range(len(centres)), key=lambda i: distance(p, centres[i], DistanceMethod.OKLAB_EUCLIDEAN))
            counts[idx] += 1
        pairs = sorted(zip(centres, counts), key=lambda item: -item[1])
        return [DominantColour(c, cnt, cnt / total) for c, cnt in pairs if cnt > 0]

    raise ValueError(f"Unhandled dominant-colour method: {method!r}")  # pragma: no cover
