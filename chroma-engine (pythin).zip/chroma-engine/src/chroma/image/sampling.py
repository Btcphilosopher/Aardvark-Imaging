"""
chroma.image.sampling
========================

Pixel- and region-level sampling over any
:class:`~chroma.image.source.ImageColourSource` (project spec section 44).
"""

from __future__ import annotations

from chroma.core.colour import Colour
from chroma.core.spaces import ColourSpace
from chroma.image.source import ImageColourSource


def sample_pixel(source: ImageColourSource, x: int, y: int) -> Colour:
    return source.get_pixel(x, y)


def sample_region(source: ImageColourSource, x0: int, y0: int, x1: int, y1: int) -> Colour:
    """Mean colour (in linear RGB, then converted back to sRGB) over the rectangle ``[x0, x1) x [y0, y1)``."""
    x0, x1 = max(0, x0), min(source.width, x1)
    y0, y1 = max(0, y0), min(source.height, y1)
    if x1 <= x0 or y1 <= y0:
        raise ValueError("Empty sampling region.")
    total = [0.0, 0.0, 0.0]
    count = 0
    for y in range(y0, y1):
        for x in range(x0, x1):
            r, g, b = source.get_pixel(x, y).convert(ColourSpace.LINEAR_RGB).channels
            total[0] += r
            total[1] += g
            total[2] += b
            count += 1
    mean = tuple(v / count for v in total)
    return Colour(ColourSpace.LINEAR_RGB, mean).convert(ColourSpace.SRGB)


def sample_grid(source: ImageColourSource, cols: int, rows: int) -> list[list[Colour]]:
    """Downsample ``source`` to a ``cols`` x ``rows`` grid of region-mean colours."""
    cell_w = max(1, source.width // cols)
    cell_h = max(1, source.height // rows)
    grid = []
    for row in range(rows):
        y0, y1 = row * cell_h, min(source.height, (row + 1) * cell_h)
        out_row = []
        for col in range(cols):
            x0, x1 = col * cell_w, min(source.width, (col + 1) * cell_w)
            out_row.append(sample_region(source, x0, y0, x1, y1))
        grid.append(out_row)
    return grid
