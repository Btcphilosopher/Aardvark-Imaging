"""
chroma.material.surface
==========================

A deliberately simple surface-finish approximation: as a surface
becomes glossier, more of what you see is the specular reflection of
the illuminant (approximately the illuminant's own colour/white)
rather than the diffuse body colour. This module mixes toward that
specular estimate in LINEAR light -- NOT a BRDF simulation, NOT
Fresnel-accurate, and it says so.
"""

from __future__ import annotations

from chroma.core.colour import Colour
from chroma.core.spaces import ColourSpace


def apply_gloss(colour: Colour, gloss: float, specular_colour: Colour | None = None) -> Colour:
    """
    ``gloss`` in 0 (fully matte/diffuse -- returns ``colour``
    unchanged) .. 1 (fully mirror-like -- returns ``specular_colour``,
    default white) mixed in LINEAR RGB. A simplified stand-in for
    specular admixture, not a physically based render.
    """
    if not (0.0 <= gloss <= 1.0):
        raise ValueError("gloss must be in [0, 1]")
    specular = specular_colour or Colour.named("white")
    base_lin = colour.convert(ColourSpace.LINEAR_RGB)
    spec_lin = specular.convert(ColourSpace.LINEAR_RGB)
    mixed = tuple(b + (s - b) * gloss for b, s in zip(base_lin.channels, spec_lin.channels))
    return Colour(ColourSpace.LINEAR_RGB, mixed, alpha=colour.alpha).convert(colour.space, white=colour.white)
