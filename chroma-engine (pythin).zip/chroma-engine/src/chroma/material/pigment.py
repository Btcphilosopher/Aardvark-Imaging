"""
chroma.material.pigment
==========================

CMYK is device/process-dependent (project spec section 13): the naive
K-extraction built into :mod:`chroma.conversion.functions` is NOT a
substitute for a real ICC CMYK profile, a press's total-ink-limit
rules, or a Gray Component Replacement (GCR) curve. This module
defines the extensible interface the spec asks for, plus two concrete
implementations: the engine's built-in naive maths (wrapped so it's
swappable), and a simple, explicitly-approximate GCR model.

Neither implementation here is a substitute for a measured ICC
profile. Aardvark Imaging is expected to add an ``IccCMYKProfile``
implementing this same interface once ICC parsing is in scope.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from chroma.conversion.functions import cmy_to_cmyk as _naive_cmy_to_cmyk
from chroma.conversion.functions import cmyk_to_cmy as _naive_cmyk_to_cmy

Triple = tuple[float, float, float]
Quad = tuple[float, float, float, float]


class CMYKProfile(ABC):
    """Interface every colour-to-process-ink model implements."""

    name: str = "unnamed"

    @abstractmethod
    def to_cmyk(self, cmy: Triple) -> Quad: ...

    @abstractmethod
    def to_cmy(self, cmyk: Quad) -> Triple: ...


class NaiveCMYKProfile(CMYKProfile):
    """The engine's built-in generic K-extraction, wrapped behind :class:`CMYKProfile` so it is swappable for a real profile without changing calling code."""

    name = "naive"

    def to_cmyk(self, cmy: Triple) -> Quad:
        return _naive_cmy_to_cmyk(cmy)

    def to_cmy(self, cmyk: Quad) -> Triple:
        return _naive_cmyk_to_cmy(cmyk)


class GCRProfile(CMYKProfile):
    """
    A simple, explicitly approximate Gray Component Replacement model:
    after naive K-extraction, some fraction (``gcr_amount``) of the
    black channel is used to REPLACE equal parts of C, M and Y (the
    basic principle behind GCR -- less coloured ink, more black ink,
    for the same visual result), and total ink coverage is capped at
    ``total_ink_limit`` (a common press constraint, typically 240-320%
    for offset litho; default here is a conservative 280%).

    This is a textbook approximation for illustrating the *idea* of
    GCR/total-ink-limiting, not a press-calibrated curve.
    """

    def __init__(self, gcr_amount: float = 0.5, total_ink_limit: float = 2.8, name: str = "gcr") -> None:
        self.gcr_amount = gcr_amount
        self.total_ink_limit = total_ink_limit
        self.name = name

    def to_cmyk(self, cmy: Triple) -> Quad:
        c, m, y, k = _naive_cmy_to_cmyk(cmy)
        reduction = self.gcr_amount * k
        c2, m2, y2 = (max(0.0, v - reduction) for v in (c, m, y))
        total = c2 + m2 + y2 + k
        if total > self.total_ink_limit:
            scale = self.total_ink_limit / total
            c2, m2, y2, k = c2 * scale, m2 * scale, y2 * scale, k * scale
        return (c2, m2, y2, k)

    def to_cmy(self, cmyk: Quad) -> Triple:
        # Not a true inverse of to_cmyk (GCR is lossy by design); this
        # applies the same standard CMY = C*(1-K) + K re-composition
        # naive CMYK conversion uses, which is the conventional
        # approximate inverse for on-screen preview purposes.
        return _naive_cmyk_to_cmy(cmyk)


def convert_to_cmyk(cmy: Triple, profile: CMYKProfile | None = None) -> Quad:
    return (profile or NaiveCMYKProfile()).to_cmyk(cmy)


def convert_from_cmyk(cmyk: Quad, profile: CMYKProfile | None = None) -> Triple:
    return (profile or NaiveCMYKProfile()).to_cmy(cmyk)
