"""chroma.material -- pigment/process (CMYK) profiles, and simplified reflectance/transmission/surface models."""

from chroma.material.pigment import CMYKProfile, GCRProfile, NaiveCMYKProfile, convert_from_cmyk, convert_to_cmyk
from chroma.material.reflectance import preview_under_illuminant, render_under_illuminant
from chroma.material.surface import apply_gloss
from chroma.material.transmission import apply_thickness, stack_transmissions

__all__ = [
    "CMYKProfile", "NaiveCMYKProfile", "GCRProfile", "convert_to_cmyk", "convert_from_cmyk",
    "render_under_illuminant", "preview_under_illuminant",
    "apply_gloss",
    "apply_thickness", "stack_transmissions",
]
