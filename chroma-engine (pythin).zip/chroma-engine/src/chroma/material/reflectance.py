"""
chroma.material.reflectance
==============================

Bridges :mod:`chroma.material.pigment`/:mod:`chroma.spectral` for the
common "what does this reflectance look like under this illuminant"
question -- a thin, explicit composition of
:func:`chroma.spectral.reconstruction.reflectance_from_rgb` and
:meth:`chroma.spectral.spectrum.Spectrum.to_colour`, kept as its own
named function because "render a reflectance under an illuminant" is
a materially different question from "reconstruct a plausible
reflectance from RGB" even though the second is usually a step
towards the first.
"""

from __future__ import annotations

from chroma.core.colour import Colour
from chroma.core.illuminants import D65, WhitePoint
from chroma.spectral.reconstruction import reflectance_from_rgb
from chroma.spectral.spectrum import Spectrum


def render_under_illuminant(reflectance: Spectrum, illuminant: Spectrum, white: WhitePoint = D65) -> Colour:
    """The perceived colour of ``reflectance`` (0..1 per wavelength) lit by ``illuminant``."""
    return reflectance.to_colour(white=white, illuminant=illuminant)


def preview_under_illuminant(colour: Colour, illuminant: Spectrum, white: WhitePoint = D65) -> Colour:
    """
    Approximate how ``colour`` (an sRGB colour, not a measured
    reflectance) would look under a non-neutral ``illuminant``, by
    round-tripping through :func:`chroma.spectral.reconstruction.reflectance_from_rgb`.
    Inherits that function's "synthetic metamer" caveat -- see its docstring.
    """
    return render_under_illuminant(reflectance_from_rgb(colour), illuminant, white)
