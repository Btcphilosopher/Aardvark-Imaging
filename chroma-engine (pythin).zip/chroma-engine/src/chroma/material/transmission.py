"""
chroma.material.transmission
===============================

Simple Beer-Lambert-style spectral transmission: for a homogeneous
absorbing medium (a coloured gel, glass, or liquid), transmittance
through ``n`` times the reference thickness is (approximately)
``T(1)^n`` at every wavelength -- the standard exponential
attenuation law, applied per-wavelength to a measured/synthetic
transmittance :class:`~chroma.spectral.spectrum.Spectrum`.

This is a real, if simplified, physical model (it assumes a
non-scattering, homogeneous medium and ignores surface reflection
losses) -- not a full radiative-transfer simulation.
"""

from __future__ import annotations

from chroma.spectral.spectrum import Spectrum


def apply_thickness(transmittance: Spectrum, thickness_multiple: float) -> Spectrum:
    """Beer-Lambert scaling: transmittance at ``thickness_multiple`` times the reference thickness."""
    values = tuple(max(0.0, v) ** thickness_multiple for v in transmittance.values)
    return Spectrum(transmittance.wavelengths, values, label=f"{transmittance.label} x{thickness_multiple}")


def stack_transmissions(spectra: list[Spectrum]) -> Spectrum:
    """Combine several filters/media in series: transmittances multiply at each wavelength."""
    if not spectra:
        raise ValueError("stack_transmissions needs at least one spectrum.")
    base = spectra[0]
    values = list(base.values)
    for other in spectra[1:]:
        values = [v * other.at(w) for v, w in zip(values, base.wavelengths)]
    return Spectrum(base.wavelengths, tuple(values), label="stacked transmission")
