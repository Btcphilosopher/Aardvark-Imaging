"""
chroma.algorithms.quantisation
=================================

Reduce a colour (or a whole set of colours) down to a fixed palette.
Every method here is pure Python (project spec section 36: "Do not
make machine-learning libraries mandatory").
"""

from __future__ import annotations

import random
from typing import Callable, Sequence

from chroma.core.colour import Colour
from chroma.core.spaces import ColourSpace
from chroma.distance.metrics import DistanceMethod, distance


def nearest_colour_quantiser(palette: Sequence[Colour], method: DistanceMethod | str = DistanceMethod.OKLAB_EUCLIDEAN) -> Callable[[Colour], Colour]:
    """Build a quantiser function that snaps any colour to its nearest member of ``palette``."""
    method = DistanceMethod(method)
    palette = list(palette)

    def quantise(colour: Colour) -> Colour:
        best, best_d = palette[0], distance(colour, palette[0], method)
        for candidate in palette[1:]:
            d = distance(colour, candidate, method)
            if d < best_d:
                best, best_d = candidate, d
        return best

    return quantise


def uniform_quantise(colour: Colour, levels_per_channel: int = 6) -> Colour:
    """
    Uniform quantisation: round each linear-RGB channel to the nearest
    of ``levels_per_channel`` evenly spaced levels. The classic "web
    safe palette" (216 colours) is ``levels_per_channel=6`` applied to
    gamma-encoded sRGB instead -- pass ``space=srgb`` via
    :func:`uniform_quantise_in_space` for that specific case.
    """
    return uniform_quantise_in_space(colour, levels_per_channel, ColourSpace.LINEAR_RGB)


def uniform_quantise_in_space(colour: Colour, levels_per_channel: int, space: ColourSpace | str) -> Colour:
    space = ColourSpace(space)
    conv = colour.convert(space)
    step = 1.0 / (levels_per_channel - 1) if levels_per_channel > 1 else 1.0
    quantised = tuple(round(c / step) * step for c in conv.channels)
    return Colour(space, quantised, white=conv.white, alpha=colour.alpha).convert(colour.space, white=colour.white)


def median_cut(colours: Sequence[Colour], target_size: int, space: ColourSpace | str = ColourSpace.OKLAB) -> list[Colour]:
    """
    Classic median-cut quantisation (Heckbert, 1982): recursively
    split the working colour set along its largest-range channel at
    the median, until there are ``target_size`` buckets, then return
    each bucket's mean colour. Operates in ``space`` (OKLab by
    default, which gives noticeably better results than the
    algorithm's original RGB-cube formulation).
    """
    space = ColourSpace(space)
    points = [colour.convert(space).channels for colour in colours]
    if not points:
        return []

    buckets: list[list[tuple[float, ...]]] = [points]
    while len(buckets) < target_size and any(len(b) > 1 for b in buckets):
        buckets.sort(key=len)
        bucket = buckets.pop()  # largest bucket
        arity = len(bucket[0])
        ranges = [
            (max(p[i] for p in bucket) - min(p[i] for p in bucket))
            for i in range(arity)
        ]
        split_channel = max(range(arity), key=lambda i: ranges[i])
        bucket_sorted = sorted(bucket, key=lambda p: p[split_channel])
        mid = len(bucket_sorted) // 2
        left, right = bucket_sorted[:mid], bucket_sorted[mid:]
        if left:
            buckets.append(left)
        if right:
            buckets.append(right)

    result = []
    for bucket in buckets:
        if not bucket:
            continue
        arity = len(bucket[0])
        mean = tuple(sum(p[i] for p in bucket) / len(bucket) for i in range(arity))
        result.append(Colour(space, mean).convert(ColourSpace.SRGB))
    return result


def kmeans_quantise(
    colours: Sequence[Colour],
    k: int,
    space: ColourSpace | str = ColourSpace.OKLAB,
    seed: int = 0,
    max_iterations: int = 50,
) -> list[Colour]:
    """
    Pure-Python k-means clustering in ``space`` (project spec section
    36's "k-means adapter architecture"). Deterministic given ``seed``
    (project spec section 57: reproducibility). Returns the ``k``
    cluster-centre colours.
    """
    space = ColourSpace(space)
    points = [colour.convert(space).channels for colour in colours]
    if not points:
        return []
    k = min(k, len(points))
    rng = random.Random(seed)
    centres = list(rng.sample(points, k))

    for _ in range(max_iterations):
        clusters: list[list[tuple[float, ...]]] = [[] for _ in range(k)]
        for p in points:
            nearest_idx = min(range(k), key=lambda i: sum((p[d] - centres[i][d]) ** 2 for d in range(len(p))))
            clusters[nearest_idx].append(p)
        new_centres = []
        changed = False
        for i, cluster in enumerate(clusters):
            if not cluster:
                new_centres.append(centres[i])
                continue
            arity = len(cluster[0])
            mean = tuple(sum(p[d] for p in cluster) / len(cluster) for d in range(arity))
            if mean != centres[i]:
                changed = True
            new_centres.append(mean)
        centres = new_centres
        if not changed:
            break

    return [Colour(space, c).convert(ColourSpace.SRGB) for c in centres]
