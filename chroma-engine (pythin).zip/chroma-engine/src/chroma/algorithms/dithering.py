"""
chroma.algorithms.dithering
==============================

Pure-Python dithering over an abstract pixel grid (``list[list[Colour]]``
or any indexable 2-D sequence) -- no Pillow/NumPy dependency (project
spec section 42). :mod:`chroma.image` provides adapters that convert a
real image library's buffer into this shape and back.

Both algorithms need a "quantise a single colour to the target
palette" function -- see :mod:`chroma.algorithms.quantisation` for the
nearest-colour quantiser normally passed in here.
"""

from __future__ import annotations

from typing import Callable, Sequence

from chroma.core.colour import Colour
from chroma.core.spaces import ColourSpace

Grid = list[list[Colour]]
Quantiser = Callable[[Colour], Colour]

# Standard 4x4 Bayer ordered-dither threshold matrix, values 0..15.
# Source: the classic Bayer (1973) recursive construction, reproduced
# in essentially every dithering reference (e.g. Ulichney, "Digital
# Halftoning", MIT Press 1987, Fig. 5.2 for the 4x4 case).
BAYER_4X4: tuple[tuple[int, ...], ...] = (
    (0, 8, 2, 10),
    (12, 4, 14, 6),
    (3, 11, 1, 9),
    (15, 7, 13, 5),
)


def ordered_dither(grid: Grid, quantiser: Quantiser, matrix: tuple[tuple[int, ...], ...] = BAYER_4X4) -> Grid:
    """
    Ordered (Bayer) dithering: perturb each pixel's linear-light
    luminance by a per-position threshold from ``matrix`` before
    quantising, so quantisation error is spread as a repeating
    pattern rather than concentrated in flat bands.
    """
    size = len(matrix)
    levels = size * size
    out: Grid = []
    for y, row in enumerate(grid):
        out_row = []
        for x, colour in enumerate(row):
            threshold = (matrix[y % size][x % size] + 0.5) / levels - 0.5  # centred around 0
            linear = colour.convert(ColourSpace.LINEAR_RGB)
            nudged = Colour(
                ColourSpace.LINEAR_RGB,
                tuple(max(0.0, min(1.0, c + threshold / levels)) for c in linear.channels),
                alpha=colour.alpha,
            ).convert(colour.space, white=colour.white)
            out_row.append(quantiser(nudged))
        out.append(out_row)
    return out


# Floyd-Steinberg error-diffusion kernel: (dx, dy, weight/16)
FLOYD_STEINBERG_KERNEL: tuple[tuple[int, int, float], ...] = (
    (1, 0, 7 / 16),
    (-1, 1, 3 / 16),
    (0, 1, 5 / 16),
    (1, 1, 1 / 16),
)


def error_diffusion_dither(
    grid: Grid,
    quantiser: Quantiser,
    kernel: tuple[tuple[int, int, float], ...] = FLOYD_STEINBERG_KERNEL,
) -> Grid:
    """
    Error-diffusion dithering (Floyd-Steinberg by default, but any
    kernel of ``(dx, dy, weight)`` triples works -- e.g. swap in the
    Jarvis-Judice-Ninke or Atkinson kernels). Error is propagated in
    LINEAR RGB, which is the physically meaningful space for this
    (propagating error in gamma-encoded RGB visibly skews the result
    -- see project spec section 7).
    """
    height = len(grid)
    width = len(grid[0]) if height else 0
    # Working buffer of linear-RGB floats (can go outside [0, 1] mid-diffusion).
    buffer: list[list[list[float]]] = [
        [list(px.convert(ColourSpace.LINEAR_RGB).channels) for px in row] for row in grid
    ]
    alphas = [[px.alpha for px in row] for row in grid]
    space = grid[0][0].space if height and width else ColourSpace.SRGB
    white = grid[0][0].white if height and width else None

    out: Grid = [[None] * width for _ in range(height)]  # type: ignore[list-item]
    for y in range(height):
        for x in range(width):
            old = buffer[y][x]
            clamped = [max(0.0, min(1.0, c)) for c in old]
            original_colour = Colour(ColourSpace.LINEAR_RGB, tuple(clamped), alpha=alphas[y][x])
            quantised = quantiser(original_colour.convert(space, white=white))
            out[y][x] = quantised
            q_linear = quantised.convert(ColourSpace.LINEAR_RGB).channels
            error = [o - q for o, q in zip(clamped, q_linear)]
            for dx, dy, weight in kernel:
                nx, ny = x + dx, y + dy
                if 0 <= nx < width and 0 <= ny < height:
                    for c in range(3):
                        buffer[ny][nx][c] += error[c] * weight
    return out
