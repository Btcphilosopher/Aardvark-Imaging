"""chroma.algorithms -- pure-Python dithering, quantisation, posterisation, blending and alpha compositing."""

from chroma.algorithms.blending import BlendMode, blend
from chroma.algorithms.compositing import CompositingOperator, composite, premultiply, unpremultiply
from chroma.algorithms.dithering import BAYER_4X4, FLOYD_STEINBERG_KERNEL, error_diffusion_dither, ordered_dither
from chroma.algorithms.posterisation import posterise
from chroma.algorithms.quantisation import kmeans_quantise, median_cut, nearest_colour_quantiser, uniform_quantise, uniform_quantise_in_space

__all__ = [
    "ordered_dither", "BAYER_4X4", "error_diffusion_dither", "FLOYD_STEINBERG_KERNEL",
    "nearest_colour_quantiser", "uniform_quantise", "uniform_quantise_in_space",
    "median_cut", "kmeans_quantise", "posterise",
    "BlendMode", "blend",
    "CompositingOperator", "composite", "premultiply", "unpremultiply",
]
