"""
chroma.algorithms.compositing
================================

Porter-Duff alpha compositing (project spec section 41): source-over,
destination-over, source-in, source-out, source-atop, destination-in,
destination-out, destination-atop, xor.

Internally this ALWAYS works in premultiplied alpha (the only
representation in which the classic Porter & Duff (1984) factors are
correct), converting from/to straight alpha at the boundary so the
public API keeps taking/returning ordinary (straight-alpha)
:class:`~chroma.core.colour.Colour` objects, per project spec section
41's "use straight alpha / premultiplied alpha with explicit
representation".
"""

from __future__ import annotations

from enum import Enum

from chroma.core.colour import Colour
from chroma.core.spaces import ColourSpace


class CompositingOperator(str, Enum):
    SOURCE_OVER = "source-over"
    DESTINATION_OVER = "destination-over"
    SOURCE_IN = "source-in"
    SOURCE_OUT = "source-out"
    SOURCE_ATOP = "source-atop"
    DESTINATION_IN = "destination-in"
    DESTINATION_OUT = "destination-out"
    DESTINATION_ATOP = "destination-atop"
    XOR = "xor"


def _factors(op: CompositingOperator, alpha_s: float, alpha_d: float) -> tuple[float, float]:
    return {
        CompositingOperator.SOURCE_OVER: (1.0, 1.0 - alpha_s),
        CompositingOperator.DESTINATION_OVER: (1.0 - alpha_d, 1.0),
        CompositingOperator.SOURCE_IN: (alpha_d, 0.0),
        CompositingOperator.SOURCE_OUT: (1.0 - alpha_d, 0.0),
        CompositingOperator.SOURCE_ATOP: (alpha_d, 1.0 - alpha_s),
        CompositingOperator.DESTINATION_IN: (0.0, alpha_s),
        CompositingOperator.DESTINATION_OUT: (0.0, 1.0 - alpha_s),
        CompositingOperator.DESTINATION_ATOP: (1.0 - alpha_d, alpha_s),
        CompositingOperator.XOR: (1.0 - alpha_d, 1.0 - alpha_s),
    }[op]


def composite(
    source: Colour,
    destination: Colour,
    operator: CompositingOperator | str = CompositingOperator.SOURCE_OVER,
    space: ColourSpace | str = ColourSpace.LINEAR_RGB,
) -> Colour:
    """
    Composite ``source`` over/under/in/out/atop ``destination`` under
    ``operator`` (Porter & Duff, 1984, "Compositing Digital Images").
    Colour maths happens in linear light (``space``, RGB-like only) so
    that partially transparent edges do not pick up the gamma-encoding
    halo classic naive (gamma-space) compositing produces.
    """
    operator = CompositingOperator(operator)
    space = ColourSpace(space)

    cs = source.convert(space)
    cd = destination.convert(space)
    alpha_s, alpha_d = source.alpha, destination.alpha

    factor_s, factor_d = _factors(operator, alpha_s, alpha_d)
    premul_s = tuple(c * alpha_s for c in cs.channels)
    premul_d = tuple(c * alpha_d for c in cd.channels)
    out_premul = tuple(factor_s * ps + factor_d * pd for ps, pd in zip(premul_s, premul_d))
    out_alpha = factor_s * alpha_s + factor_d * alpha_d

    out_straight = tuple(c / out_alpha for c in out_premul) if out_alpha > 0.0 else tuple(0.0 for _ in out_premul)
    return Colour(space, out_straight, alpha=max(0.0, min(1.0, out_alpha))).convert(source.space, white=source.white)


def premultiply(colour: Colour, space: ColourSpace | str = ColourSpace.LINEAR_RGB) -> tuple[float, ...]:
    """Return ``colour``'s channels in ``space``, each multiplied by alpha -- the premultiplied representation."""
    conv = colour.convert(space)
    return tuple(c * colour.alpha for c in conv.channels)


def unpremultiply(premultiplied_channels: tuple[float, ...], alpha: float, space: ColourSpace | str = ColourSpace.LINEAR_RGB) -> Colour:
    """Inverse of :func:`premultiply`: build a straight-alpha Colour from premultiplied channel values."""
    space = ColourSpace(space)
    straight = tuple(c / alpha for c in premultiplied_channels) if alpha > 0.0 else tuple(0.0 for _ in premultiplied_channels)
    return Colour(space, straight, alpha=alpha)
