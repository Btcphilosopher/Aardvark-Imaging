"""
chroma.algorithms.posterisation
==================================

Posterisation: reduce the number of distinct tonal levels per channel.
A thin, explicitly-named special case of
:func:`chroma.algorithms.quantisation.uniform_quantise_in_space` (kept
as its own module because it is a distinct creative/production
operation, not just an internal implementation detail).
"""

from __future__ import annotations

from chroma.core.colour import Colour
from chroma.core.spaces import ColourSpace
from chroma.algorithms.quantisation import uniform_quantise_in_space


def posterise(colour: Colour, levels: int = 4, space: ColourSpace | str = ColourSpace.SRGB) -> Colour:
    """Reduce ``colour`` to ``levels`` evenly spaced tones per channel in ``space`` (gamma-encoded sRGB by default, matching the classic photo-editing effect)."""
    return uniform_quantise_in_space(colour, levels, space)
