"""chroma.algorithms.error_diffusion -- named re-export of the error-diffusion dithering implementation in dithering.py."""

from chroma.algorithms.dithering import FLOYD_STEINBERG_KERNEL, error_diffusion_dither

__all__ = ["error_diffusion_dither", "FLOYD_STEINBERG_KERNEL"]
