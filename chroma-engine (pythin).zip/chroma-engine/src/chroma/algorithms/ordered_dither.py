"""chroma.algorithms.ordered_dither -- named re-export of the Bayer ordered-dither implementation in dithering.py."""

from chroma.algorithms.dithering import BAYER_4X4, ordered_dither

__all__ = ["ordered_dither", "BAYER_4X4"]
