"""
chroma.algorithms.blending
=============================

Blend modes (project spec section 40). Every blend mode is defined in
terms of two SCALARS per channel, ``a`` (base) and ``b`` (blend); the
formulas below are the standard ones from the CSS Compositing and
Blending spec / classic Porter-Duff-adjacent literature.

``space`` defaults to linear RGB, and the function REFUSES to guess
gamma-encoded blending is fine (project spec section 40: "Never
silently blend gamma-encoded values") -- pass ``space="srgb"``
explicitly if you specifically want the (very common, but physically
questionable) gamma-encoded look most image editors default to.
"""

from __future__ import annotations

from enum import Enum

from chroma.core.colour import Colour
from chroma.core.spaces import ColourSpace


class BlendMode(str, Enum):
    NORMAL = "normal"
    MULTIPLY = "multiply"
    SCREEN = "screen"
    OVERLAY = "overlay"
    DARKEN = "darken"
    LIGHTEN = "lighten"
    DIFFERENCE = "difference"
    ADD = "add"
    SUBTRACT = "subtract"


def _blend_channel(a: float, b: float, mode: BlendMode) -> float:
    if mode == BlendMode.NORMAL:
        return b
    if mode == BlendMode.MULTIPLY:
        return a * b
    if mode == BlendMode.SCREEN:
        return 1.0 - (1.0 - a) * (1.0 - b)
    if mode == BlendMode.OVERLAY:
        return (2.0 * a * b) if a <= 0.5 else (1.0 - 2.0 * (1.0 - a) * (1.0 - b))
    if mode == BlendMode.DARKEN:
        return min(a, b)
    if mode == BlendMode.LIGHTEN:
        return max(a, b)
    if mode == BlendMode.DIFFERENCE:
        return abs(a - b)
    if mode == BlendMode.ADD:
        return min(1.0, a + b)
    if mode == BlendMode.SUBTRACT:
        return max(0.0, a - b)
    raise ValueError(f"Unhandled blend mode: {mode!r}")  # pragma: no cover


_RGB_LIKE_SPACES = (
    ColourSpace.SRGB, ColourSpace.LINEAR_RGB,
    ColourSpace.DISPLAY_P3, ColourSpace.LINEAR_DISPLAY_P3,
    ColourSpace.REC2020, ColourSpace.LINEAR_REC2020,
)


def blend(a: Colour, b: Colour, mode: BlendMode | str = BlendMode.NORMAL, space: ColourSpace | str = ColourSpace.LINEAR_RGB) -> Colour:
    """
    Blend ``a`` (base) with ``b`` (blend) using ``mode``, computed in
    ``space``. Alpha is not composited here -- see
    :mod:`chroma.algorithms.compositing` for that. ``space`` must be
    one of the RGB-like spaces (srgb, linear_rgb, display_p3,
    linear_display_p3, rec2020, linear_rec2020): these blend formulas
    are defined for [0, 1]-range channels and are not meaningful
    applied to Lab/LCh/OKLab/etc channels, so other spaces are
    rejected rather than silently producing a number.
    """
    mode = BlendMode(mode)
    space = ColourSpace(space)
    if space not in _RGB_LIKE_SPACES:
        raise ValueError(
            f"blend() requires an RGB-like space, got {space.value!r}. "
            f"Choose one of: {[s.value for s in _RGB_LIKE_SPACES]}."
        )
    ca, cb = a.convert(space), b.convert(space)
    blended = tuple(max(0.0, min(1.0, _blend_channel(x, y, mode))) for x, y in zip(ca.channels, cb.channels))
    return Colour(space, blended, alpha=a.alpha).convert(a.space, white=a.white)
