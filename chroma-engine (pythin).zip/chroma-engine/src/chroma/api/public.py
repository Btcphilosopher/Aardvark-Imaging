"""
chroma.api.public
====================

The single, flat, stable surface Aardvark Imaging (or any other
embedder) is meant to import against (project spec section 60):

    from chroma import Colour

    colour = Colour.hex("#2457A6")
    colour_oklch = colour.convert("oklch")
    variations = colour.generate_variations(hue_step=15, lightness_steps=20, chroma_steps=20)
    palette = colour.generate_palette(method="perceptual", size=12)
    nearest = colour.nearest(catalogue)

Everything reachable from here is considered part of Chroma Engine's
STABLE public API -- internal modules are free to be reorganised
between versions, but names re-exported from ``chroma`` or
``chroma.api.public`` will only change with a version bump documented
in the changelog. Aardvark Imaging should import from here (or the
top-level ``chroma`` package, which re-exports the same names) rather
than reaching into ``chroma.<submodule>`` internals directly.
"""

from __future__ import annotations

# Core
from chroma.core.colour import Colour
from chroma.core.illuminants import WhitePoint, get_white_point, list_white_points
from chroma.core.spaces import ColourSpace

# Conversion
from chroma.conversion.adaptation import AdaptationMethod, bradford_adapt
from chroma.conversion.graph import explain_path, find_path

# Gamut
from chroma.gamut.detection import GamutReport, TargetGamut, gamut_report, is_in_gamut
from chroma.gamut.mapping import GamutMappingMethod, GamutMappingResult, map_to_gamut, map_to_gamut_report
from chroma.gamut.strategies import max_chroma_at, max_chroma_series

# Variation
from chroma.variation.engine import ColourSeries, ColourVariationSet, generate_variation_set

# Harmony
from chroma.harmony.engine import analogous, complementary, monochromatic, split_complementary, tetradic, triadic

# Distance
from chroma.distance.comparison import ColourComparison, compare
from chroma.distance.metrics import DistanceMethod, distance, distance_matrix
from chroma.distance.nearest import NearestMatch, k_nearest, nearest

# Interpolation & gradients
from chroma.interpolation.engine import HueInterpolationMode, interpolate, interpolate_series
from chroma.gradient.gradient import Easing, Gradient, Stop

# Contrast
from chroma.contrast.wcag import ContrastReport, TextSize, best_text_colour, contrast_ratio, evaluate_contrast, relative_luminance

# Palette
from chroma.palette.generator import PaletteMethod, generate_palette
from chroma.palette.palette import Palette, PaletteEntry, Role

# Catalogue
from chroma.catalogue.database import Catalogue, CatalogueEntry
from chroma.catalogue.naming import name_colour, name_colour_top_n
from chroma.catalogue.universe import enumerate_rgb8, nearest_in_rgb8, sample_rgb8

# Spectral
from chroma.spectral.colour_temperature import cct_from_colour, cct_from_xy
from chroma.spectral.spectrum import Spectrum

# Material
from chroma.material.pigment import CMYKProfile, GCRProfile, NaiveCMYKProfile

# Algorithms (blending / compositing -- the two operations spec section
# 60's integration story most directly needs at the flat API level)
from chroma.algorithms.blending import BlendMode, blend
from chroma.algorithms.compositing import CompositingOperator, composite

__all__ = [
    "Colour", "ColourSpace", "WhitePoint", "get_white_point", "list_white_points",
    "AdaptationMethod", "bradford_adapt", "find_path", "explain_path",
    "TargetGamut", "GamutReport", "gamut_report", "is_in_gamut",
    "GamutMappingMethod", "GamutMappingResult", "map_to_gamut", "map_to_gamut_report",
    "max_chroma_at", "max_chroma_series",
    "ColourSeries", "ColourVariationSet", "generate_variation_set",
    "complementary", "analogous", "triadic", "tetradic", "split_complementary", "monochromatic",
    "DistanceMethod", "distance", "distance_matrix", "nearest", "k_nearest", "NearestMatch",
    "compare", "ColourComparison",
    "HueInterpolationMode", "interpolate", "interpolate_series",
    "Gradient", "Stop", "Easing",
    "relative_luminance", "contrast_ratio", "evaluate_contrast", "ContrastReport", "TextSize", "best_text_colour",
    "Palette", "PaletteEntry", "Role", "generate_palette", "PaletteMethod",
    "Catalogue", "CatalogueEntry", "name_colour", "name_colour_top_n",
    "enumerate_rgb8", "sample_rgb8", "nearest_in_rgb8",
    "Spectrum", "cct_from_xy", "cct_from_colour",
    "CMYKProfile", "NaiveCMYKProfile", "GCRProfile",
    "BlendMode", "blend", "CompositingOperator", "composite",
]
