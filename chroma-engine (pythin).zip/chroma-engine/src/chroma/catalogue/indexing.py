"""
chroma.catalogue.indexing
============================

A simple bucketed hue index for fast-ish approximate range queries
over a large :class:`~chroma.catalogue.database.Catalogue` without
scanning every entry -- a genuinely small, honest data structure
(NOT a k-d tree / spatial index; for catalogues in the thousands-of-
entries range a linear scan is already fast enough in pure Python,
and this exists mainly as an extension seam for a real spatial index
later).
"""

from __future__ import annotations

from chroma.catalogue.database import Catalogue, CatalogueEntry
from chroma.core.spaces import ColourSpace


class HueIndex:
    """Buckets catalogue entries by OKLCh hue into ``bucket_count`` equal-width bins."""

    def __init__(self, catalogue: Catalogue, bucket_count: int = 36) -> None:
        self.bucket_count = bucket_count
        self._buckets: list[list[CatalogueEntry]] = [[] for _ in range(bucket_count)]
        width = 360.0 / bucket_count
        for entry in catalogue:
            hue = entry.colour.convert(ColourSpace.OKLCH).channel("h")
            self._buckets[int(hue // width) % bucket_count].append(entry)

    def entries_near_hue(self, hue: float, span: float = 15.0) -> list[CatalogueEntry]:
        """Every entry whose hue falls within +/- ``span`` degrees of ``hue`` (wraparound-aware)."""
        width = 360.0 / self.bucket_count
        span_buckets = max(1, int(span // width) + 1)
        centre = int(hue // width) % self.bucket_count
        seen: list[CatalogueEntry] = []
        for offset in range(-span_buckets, span_buckets + 1):
            seen.extend(self._buckets[(centre + offset) % self.bucket_count])
        return seen
