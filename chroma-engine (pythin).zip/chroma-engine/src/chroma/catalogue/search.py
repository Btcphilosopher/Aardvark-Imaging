"""
chroma.catalogue.search
==========================

A small, extensible predicate-based query language for catalogues
(project spec section 53), e.g.::

    catalogue.search(hue_range=(20, 40), chroma_gt=0.15)
    catalogue.search(lightness_between=(0.4, 0.7))
    catalogue.search(nearest="#2457A6", within=10.0)
    catalogue.search(contrast_against="#FFFFFF", contrast_gt=7.0)
    catalogue.search(gamut="display-p3")

Each supported keyword maps to a predicate FACTORY in ``_PREDICATES``;
adding a new query keyword is exactly "add one entry to that dict" --
no changes needed anywhere else (project spec section 53:
"Make the query system extensible").
"""

from __future__ import annotations

from typing import Callable

from chroma.contrast.wcag import contrast_ratio
from chroma.core.colour import Colour
from chroma.core.spaces import ColourSpace
from chroma.distance.metrics import DistanceMethod, distance
from chroma.gamut.detection import TargetGamut, is_in_gamut

Predicate = Callable[[Colour], bool]
PredicateFactory = Callable[..., Predicate]


def _as_colour(value) -> Colour:
    return value if isinstance(value, Colour) else Colour.hex(value)


def _hue(colour: Colour) -> float:
    return colour.convert(ColourSpace.OKLCH).channel("h")


def _chroma(colour: Colour) -> float:
    return colour.convert(ColourSpace.OKLCH).channel("C")


def _lightness(colour: Colour) -> float:
    return colour.convert(ColourSpace.OKLCH).channel("L")


_PREDICATES: dict[str, PredicateFactory] = {
    "hue": lambda value: (lambda c: abs(_hue(c) - value) < 1e-6),
    "hue_range": lambda value: (lambda c, lo=value[0], hi=value[1]: lo <= _hue(c) <= hi),
    "chroma_gt": lambda value: (lambda c: _chroma(c) > value),
    "chroma_lt": lambda value: (lambda c: _chroma(c) < value),
    "chroma_between": lambda value: (lambda c, lo=value[0], hi=value[1]: lo <= _chroma(c) <= hi),
    "lightness_gt": lambda value: (lambda c: _lightness(c) > value),
    "lightness_lt": lambda value: (lambda c: _lightness(c) < value),
    "lightness_between": lambda value: (lambda c, lo=value[0], hi=value[1]: lo <= _lightness(c) <= hi),
    "gamut": lambda value: (lambda c: is_in_gamut(c, TargetGamut(value))),
}


def _nearest_predicate(target, within: float | None = None, method: DistanceMethod | str = DistanceMethod.CIEDE2000) -> Predicate:
    target_colour = _as_colour(target)
    threshold = within if within is not None else float("inf")

    def predicate(c: Colour) -> bool:
        return distance(target_colour, c, method) <= threshold

    return predicate


def _contrast_predicate(against, contrast_gt: float = 0.0) -> Predicate:
    background = _as_colour(against)

    def predicate(c: Colour) -> bool:
        return contrast_ratio(c, background) > contrast_gt

    return predicate


def build_query(**kwargs) -> Predicate:
    """
    Combine every recognised keyword in ``kwargs`` into a single AND-ed
    predicate. ``nearest``/``within``/``method`` are handled together
    (they describe one predicate), as are ``contrast_against``/``contrast_gt``.
    """
    predicates: list[Predicate] = []
    remaining = dict(kwargs)

    if "nearest" in remaining:
        predicates.append(
            _nearest_predicate(
                remaining.pop("nearest"),
                within=remaining.pop("within", None),
                method=remaining.pop("method", DistanceMethod.CIEDE2000),
            )
        )
    if "contrast_against" in remaining:
        predicates.append(
            _contrast_predicate(remaining.pop("contrast_against"), contrast_gt=remaining.pop("contrast_gt", 0.0))
        )

    for key, value in remaining.items():
        if key not in _PREDICATES:
            raise ValueError(f"Unknown catalogue search predicate: {key!r}. Known: {sorted(_PREDICATES)}")
        predicates.append(_PREDICATES[key](value))

    def combined(c: Colour) -> bool:
        return all(p(c) for p in predicates)

    return combined


def register_predicate(name: str, factory: PredicateFactory, *, overwrite: bool = False) -> None:
    """Register a custom query keyword, e.g. an Aardvark-specific tag filter."""
    if name in _PREDICATES and not overwrite:
        raise ValueError(f"Predicate {name!r} already registered; pass overwrite=True to replace it.")
    _PREDICATES[name] = factory
