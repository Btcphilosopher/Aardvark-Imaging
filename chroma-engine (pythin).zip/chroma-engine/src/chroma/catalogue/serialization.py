"""
chroma.catalogue.serialization
=================================

The ``.chroma`` native project format (project spec section 67):
a small, versioned JSON envelope. This module is the single place
that knows the on-disk shape, so the version number only has to be
bumped in one spot when the format changes.
"""

from __future__ import annotations

import json
from typing import Any

from chroma.catalogue.database import Catalogue
from chroma.core.colour import Colour
from chroma.palette.palette import Palette

CHROMA_FILE_VERSION = 1


def save_chroma_file(path: str, *, colour: Colour | None = None, palette: Palette | None = None,
                      catalogue: Catalogue | None = None, name: str = "", metadata: dict[str, Any] | None = None) -> None:
    """Write a ``.chroma`` project file. Exactly one of colour/palette/catalogue is the typical case, but any combination is allowed."""
    payload: dict[str, Any] = {"format": "chroma", "version": CHROMA_FILE_VERSION, "name": name, "metadata": metadata or {}}
    if colour is not None:
        payload["colour"] = colour.to_dict()
    if palette is not None:
        payload["palette"] = palette.to_dict()
    if catalogue is not None:
        payload["catalogue"] = catalogue.to_dict()
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)


def load_chroma_file(path: str) -> dict[str, Any]:
    """
    Read a ``.chroma`` project file back into
    ``{"colour": Colour | None, "palette": Palette | None, "catalogue": Catalogue | None,
      "name": str, "metadata": dict, "version": int}``.
    """
    with open(path, encoding="utf-8") as f:
        raw = json.load(f)
    if raw.get("format") != "chroma":
        raise ValueError(f"{path} is not a Chroma Engine .chroma file (missing/wrong 'format' field).")
    return {
        "version": raw.get("version"),
        "name": raw.get("name", ""),
        "metadata": raw.get("metadata", {}),
        "colour": Colour.from_dict(raw["colour"]) if "colour" in raw else None,
        "palette": Palette.from_dict(raw["palette"]) if "palette" in raw else None,
        "catalogue": Catalogue.from_dict(raw["catalogue"]) if "catalogue" in raw else None,
    }
