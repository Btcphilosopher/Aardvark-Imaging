"""
chroma.catalogue.universe
============================

"All possible colours", interpreted mathematically rather than by
attempting to store every RGB8 triplet in memory (project spec
sections 34-35, 65): the 8-bit RGB space has exactly
256 x 256 x 256 = 16,777,216 discrete colours, and this module treats
that as a searchable space rather than a materialised list.

:func:`enumerate_rgb8` is a LAZY generator (``lazy=True`` is the only
mode -- see project spec section 34: "Do not allocate the entire
universe in memory", so there is no non-lazy option to opt out into).
Streaming all 16.7M :class:`~chroma.core.colour.Colour` objects
through pure-Python distance functions is inherently slow (tens of
seconds, not milliseconds) -- :func:`nearest_in_rgb8` defaults to a
bounded neighbourhood search around the direct per-channel rounding of
the target, which is exact for the RGB-Euclidean metric and an
extremely close approximation for the perceptual metrics (they are
locally smooth, so the true global optimum is essentially always
within a small cube of the naive rounding); pass ``exhaustive=True``
for a guaranteed-correct but slow full scan.
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Iterator

from chroma.core.colour import Colour
from chroma.distance.metrics import DistanceMethod, distance


def enumerate_rgb8() -> Iterator[Colour]:
    """Every one of the 16,777,216 RGB8 colours, lazily, in (r, g, b) lexicographic order."""
    for r in range(256):
        for g in range(256):
            for b in range(256):
                yield Colour.rgb(r, g, b)


def sample_rgb8(n: int, seed: int = 0) -> list[Colour]:
    """``n`` distinct RGB8 colours chosen uniformly at random, deterministic given ``seed`` (project spec section 57)."""
    if not (0 < n <= 256 ** 3):
        raise ValueError("n must be between 1 and 16,777,216.")
    rng = random.Random(seed)
    seen: set[int] = set()
    result: list[Colour] = []
    while len(result) < n:
        packed = rng.randrange(256 ** 3)
        if packed in seen:
            continue
        seen.add(packed)
        r, g, b = (packed >> 16) & 0xFF, (packed >> 8) & 0xFF, packed & 0xFF
        result.append(Colour.rgb(r, g, b))
    return result


def within_distance_rgb8(
    target: Colour,
    threshold: float,
    method: DistanceMethod | str = DistanceMethod.CIEDE2000,
    limit: int | None = None,
) -> Iterator[Colour]:
    """Lazily stream every RGB8 colour within ``threshold`` of ``target`` under ``method`` -- a full 16.7M-colour scan, so expect it to take real time; use ``limit`` to cap how many results you actually need."""
    method = DistanceMethod(method)
    count = 0
    for candidate in enumerate_rgb8():
        if distance(target, candidate, method) <= threshold:
            yield candidate
            count += 1
            if limit is not None and count >= limit:
                return


@dataclass(frozen=True)
class UniverseMatch:
    colour: Colour
    distance: float
    method: DistanceMethod
    exhaustive: bool


def nearest_in_rgb8(
    target: Colour,
    method: DistanceMethod | str = DistanceMethod.CIEDE2000,
    exhaustive: bool = False,
    search_radius: int = 12,
) -> UniverseMatch:
    """See module docstring for the bounded-vs-exhaustive tradeoff."""
    method = DistanceMethod(method)
    if exhaustive:
        best, best_d = None, float("inf")
        for candidate in enumerate_rgb8():
            d = distance(target, candidate, method)
            if d < best_d:
                best, best_d = candidate, d
        return UniverseMatch(best, best_d, method, exhaustive=True)

    r0, g0, b0 = target.rgb8()
    best, best_d = None, float("inf")
    for dr in range(-search_radius, search_radius + 1):
        r = r0 + dr
        if not (0 <= r <= 255):
            continue
        for dg in range(-search_radius, search_radius + 1):
            g = g0 + dg
            if not (0 <= g <= 255):
                continue
            for db in range(-search_radius, search_radius + 1):
                b = b0 + db
                if not (0 <= b <= 255):
                    continue
                candidate = Colour.rgb(r, g, b)
                d = distance(target, candidate, method)
                if d < best_d:
                    best, best_d = candidate, d
    return UniverseMatch(best, best_d, method, exhaustive=False)
