"""
chroma.catalogue.database
============================

The Aardvark Colour Library (project spec section 52): a collection of
:class:`CatalogueEntry` records (id, colour, name, tags, metadata)
supporting save/load/search/filter/sort/compare.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Iterator, Mapping

from chroma.catalogue.search import build_query
from chroma.core.colour import Colour
from chroma.core.exceptions import CatalogueError
from chroma.distance.metrics import DistanceMethod
from chroma.distance.nearest import NearestMatch, k_nearest, nearest as _nearest


@dataclass(frozen=True)
class CatalogueEntry:
    id: str
    colour: Colour
    name: str | None = None
    tags: tuple[str, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=lambda: MappingProxyType({}))

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id, "colour": self.colour.to_dict(), "name": self.name,
            "tags": list(self.tags), "metadata": dict(self.metadata),
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "CatalogueEntry":
        return cls(
            id=data["id"], colour=Colour.from_dict(data["colour"]), name=data.get("name"),
            tags=tuple(data.get("tags", ())), metadata=data.get("metadata", {}),
        )


class Catalogue:
    """An in-memory, JSON-persistable colour catalogue."""

    def __init__(self, entries: list[CatalogueEntry] | None = None, name: str | None = None) -> None:
        self.name = name
        self._entries: dict[str, CatalogueEntry] = {}
        for e in entries or ():
            self.add(e)

    def add(self, entry: CatalogueEntry) -> None:
        if entry.id in self._entries:
            raise CatalogueError(f"Duplicate catalogue id: {entry.id!r}")
        self._entries[entry.id] = entry

    def add_colour(self, id: str, colour: Colour, name: str | None = None, tags: tuple[str, ...] = ()) -> CatalogueEntry:
        entry = CatalogueEntry(id=id, colour=colour, name=name, tags=tags)
        self.add(entry)
        return entry

    def get(self, id: str) -> CatalogueEntry:
        try:
            return self._entries[id]
        except KeyError as exc:
            raise CatalogueError(f"No catalogue entry with id {id!r}") from exc

    def remove(self, id: str) -> None:
        self._entries.pop(id, None)

    def all(self) -> tuple[CatalogueEntry, ...]:
        return tuple(self._entries.values())

    def __len__(self) -> int:
        return len(self._entries)

    def __iter__(self) -> Iterator[CatalogueEntry]:
        return iter(self._entries.values())

    def by_tag(self, tag: str) -> tuple[CatalogueEntry, ...]:
        return tuple(e for e in self._entries.values() if tag in e.tags)

    def search(self, **kwargs) -> list[CatalogueEntry]:
        """See :mod:`chroma.catalogue.search` for the supported query keywords."""
        predicate = build_query(**kwargs)
        return [e for e in self._entries.values() if predicate(e.colour)]

    def sort_by(self, key: str = "lightness", reverse: bool = False) -> list[CatalogueEntry]:
        from chroma.core.spaces import ColourSpace

        keyfuncs = {
            "lightness": lambda e: e.colour.convert(ColourSpace.OKLCH).channel("L"),
            "chroma": lambda e: e.colour.convert(ColourSpace.OKLCH).channel("C"),
            "hue": lambda e: e.colour.convert(ColourSpace.OKLCH).channel("h"),
            "name": lambda e: e.name or "",
            "id": lambda e: e.id,
        }
        if key not in keyfuncs:
            raise ValueError(f"Unknown sort key {key!r}; choose from {sorted(keyfuncs)}")
        return sorted(self._entries.values(), key=keyfuncs[key], reverse=reverse)

    def nearest(self, target: Colour, method: DistanceMethod | str = DistanceMethod.CIEDE2000) -> NearestMatch:
        if not self._entries:
            raise CatalogueError("nearest() called on an empty catalogue.")
        by_colour = {id(e.colour): e for e in self._entries.values()}
        match = _nearest(target, (e.colour for e in self._entries.values()), method)
        entry = by_colour[id(match.colour)]
        return NearestMatch(colour=match.colour, distance=match.distance, method=match.method, source=entry)

    def k_nearest(self, target: Colour, k: int = 5, method: DistanceMethod | str = DistanceMethod.CIEDE2000) -> list[NearestMatch]:
        return k_nearest(target, (e.colour for e in self._entries.values()), k, method)

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "entries": [e.to_dict() for e in self._entries.values()]}

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "Catalogue":
        return cls([CatalogueEntry.from_dict(e) for e in data["entries"]], name=data.get("name"))

    def save_json(self, path: str) -> None:
        import json

        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2)

    @classmethod
    def load_json(cls, path: str) -> "Catalogue":
        import json

        with open(path, encoding="utf-8") as f:
            return cls.from_dict(json.load(f))
