"""chroma.catalogue -- the Aardvark Colour Library: named/tagged colour database, naming engine, search, .chroma serialization, and the RGB8 colour universe."""

from chroma.catalogue.database import Catalogue, CatalogueEntry
from chroma.catalogue.indexing import HueIndex
from chroma.catalogue.naming import NameMatch, NamingDictionary, name_colour, name_colour_top_n, register_dictionary
from chroma.catalogue.search import build_query, register_predicate
from chroma.catalogue.serialization import load_chroma_file, save_chroma_file
from chroma.catalogue.universe import UniverseMatch, enumerate_rgb8, nearest_in_rgb8, sample_rgb8, within_distance_rgb8

__all__ = [
    "Catalogue", "CatalogueEntry", "HueIndex",
    "name_colour", "name_colour_top_n", "NameMatch", "NamingDictionary", "register_dictionary",
    "build_query", "register_predicate",
    "save_chroma_file", "load_chroma_file",
    "enumerate_rgb8", "sample_rgb8", "within_distance_rgb8", "nearest_in_rgb8", "UniverseMatch",
]
