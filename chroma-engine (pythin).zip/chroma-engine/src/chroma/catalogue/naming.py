"""
chroma.catalogue.naming
==========================

Given a colour, return the nearest name(s) from one or more registered
naming DICTIONARIES (project spec section 51). Colour names are
emphatically not universal or objective -- this module never claims a
single "true" name, only "nearest name under dictionary X and metric
Y", both stated explicitly in the result.
"""

from __future__ import annotations

from dataclasses import dataclass

from chroma.core._named_colours import CSS4_NAMED_COLOURS
from chroma.core.colour import Colour
from chroma.distance.metrics import DistanceMethod, distance


@dataclass(frozen=True)
class NamingDictionary:
    name: str
    entries: dict[str, str]  # colour-name -> "#rrggbb"


_REGISTRY: dict[str, NamingDictionary] = {
    "css4": NamingDictionary("css4", dict(CSS4_NAMED_COLOURS)),
}


def register_dictionary(dictionary: NamingDictionary, *, overwrite: bool = False) -> None:
    """Register a custom naming dictionary, e.g. Aardvark's own house palette names."""
    if dictionary.name in _REGISTRY and not overwrite:
        raise ValueError(f"Naming dictionary {dictionary.name!r} already registered; pass overwrite=True to replace it.")
    _REGISTRY[dictionary.name] = dictionary


def list_dictionaries() -> tuple[str, ...]:
    return tuple(sorted(_REGISTRY))


@dataclass(frozen=True)
class NameMatch:
    name: str
    colour: Colour
    distance: float
    dictionary: str
    method: DistanceMethod


def name_colour(colour: Colour, dictionary: str = "css4", method: DistanceMethod | str = DistanceMethod.CIEDE2000) -> NameMatch:
    """The single nearest name for ``colour`` in ``dictionary``."""
    method = DistanceMethod(method)
    try:
        entries = _REGISTRY[dictionary].entries
    except KeyError as exc:
        raise ValueError(f"Unknown naming dictionary {dictionary!r}. Known: {list_dictionaries()}") from exc

    best_name, best_colour, best_d = None, None, float("inf")
    for name, hex_value in entries.items():
        candidate = Colour.hex(hex_value)
        d = distance(colour, candidate, method)
        if d < best_d:
            best_name, best_colour, best_d = name, candidate, d
    return NameMatch(name=best_name, colour=best_colour, distance=best_d, dictionary=dictionary, method=method)


def name_colour_top_n(
    colour: Colour, n: int = 3, dictionary: str = "css4", method: DistanceMethod | str = DistanceMethod.CIEDE2000
) -> list[NameMatch]:
    """The ``n`` nearest names for ``colour`` in ``dictionary``, closest first."""
    method = DistanceMethod(method)
    entries = _REGISTRY[dictionary].entries
    scored = [
        NameMatch(name=name, colour=Colour.hex(hexv), distance=distance(colour, Colour.hex(hexv), method), dictionary=dictionary, method=method)
        for name, hexv in entries.items()
    ]
    scored.sort(key=lambda m: m.distance)
    return scored[:n]
