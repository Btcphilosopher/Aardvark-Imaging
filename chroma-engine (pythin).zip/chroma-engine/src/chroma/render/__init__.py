"""chroma.render -- pure-Python SVG rendering: swatches, strips, wheels, the RGB cube, gamut boundaries, simple charts."""

from chroma.render.chart import bar_chart_svg, line_chart_svg
from chroma.render.cube import cube_svg
from chroma.render.gamut_map import gamut_boundary_svg
from chroma.render.swatch import grid_svg, strip_svg, swatch_svg
from chroma.render.wheel import wheel_svg

__all__ = [
    "swatch_svg", "strip_svg", "grid_svg",
    "wheel_svg", "gamut_boundary_svg", "cube_svg",
    "bar_chart_svg", "line_chart_svg",
]
