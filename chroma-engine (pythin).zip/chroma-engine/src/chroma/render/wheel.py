"""
chroma.render.wheel
======================

An SVG hue wheel: ``segments`` wedges sweeping 0-360 degrees of hue in
a chosen working space (OKLCh by default), at fixed lightness and
chroma (or with chroma following the real gamut boundary -- see
``chroma_mode="max"``). Pure string/geometry, no drawing library.
"""

from __future__ import annotations

import math

from chroma.core.colour import Colour
from chroma.gamut.strategies import max_chroma_at


def wheel_svg(
    segments: int = 48,
    lightness: float = 0.7,
    chroma: float = 0.15,
    chroma_mode: str = "fixed",  # "fixed" or "max" (uses the real sRGB gamut boundary per segment)
    size: int = 400,
    inner_radius_fraction: float = 0.15,
) -> str:
    """Render a full hue wheel as an SVG string."""
    cx = cy = size / 2.0
    outer_r = size / 2.0 * 0.95
    inner_r = outer_r * inner_radius_fraction
    step = 360.0 / segments

    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="0 0 {size} {size}">']
    for i in range(segments):
        h0, h1 = i * step, (i + 1) * step
        hue_mid = (h0 + h1) / 2.0
        c = max_chroma_at(lightness, hue_mid, "srgb") if chroma_mode == "max" else chroma
        colour = Colour.from_space("oklch", L=lightness, C=c, h=hue_mid)
        path = _wedge_path(cx, cy, inner_r, outer_r, h0, h1)
        parts.append(f'<path d="{path}" fill="{colour.hex()}" stroke="none"/>')
    parts.append("</svg>")
    return "".join(parts)


def _polar(cx: float, cy: float, r: float, degrees: float) -> tuple[float, float]:
    # SVG y-axis points down; degrees measured from 3 o'clock, increasing clockwise on screen.
    rad = math.radians(degrees)
    return (cx + r * math.cos(rad), cy + r * math.sin(rad))


def _wedge_path(cx: float, cy: float, r_in: float, r_out: float, a0: float, a1: float) -> str:
    x0o, y0o = _polar(cx, cy, r_out, a0)
    x1o, y1o = _polar(cx, cy, r_out, a1)
    x1i, y1i = _polar(cx, cy, r_in, a1)
    x0i, y0i = _polar(cx, cy, r_in, a0)
    large_arc = 1 if (a1 - a0) > 180.0 else 0
    return (
        f"M {x0o:.2f},{y0o:.2f} "
        f"A {r_out:.2f},{r_out:.2f} 0 {large_arc} 1 {x1o:.2f},{y1o:.2f} "
        f"L {x1i:.2f},{y1i:.2f} "
        f"A {r_in:.2f},{r_in:.2f} 0 {large_arc} 0 {x0i:.2f},{y0i:.2f} Z"
    )
