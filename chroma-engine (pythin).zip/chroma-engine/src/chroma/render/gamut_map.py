"""
chroma.render.gamut_map
==========================

Renders the actual searched gamut boundary (via
:func:`chroma.gamut.strategies.max_chroma_series`) as an SVG "tongue"
shape -- lightness on one axis, maximum in-gamut OKLCh chroma at a
fixed hue on the other. This is a measurement plot, not decoration:
every point on the boundary line came from a real binary search
against the target gamut's matrices.
"""

from __future__ import annotations

from chroma.gamut.detection import TargetGamut
from chroma.gamut.strategies import max_chroma_series


def gamut_boundary_svg(
    hue: float,
    target: TargetGamut | str = TargetGamut.SRGB,
    lightness_steps: int = 41,
    width: int = 400,
    height: int = 300,
    max_chroma_axis: float = 0.4,
) -> str:
    """SVG plot of the sRGB/P3/Rec.2020 gamut boundary at a fixed hue, coloured along the boundary itself."""
    from chroma.core.colour import Colour

    series = max_chroma_series(hue, target, lightness_steps)
    margin = 24
    plot_w, plot_h = width - 2 * margin, height - 2 * margin

    def to_xy(lightness: float, chroma: float) -> tuple[float, float]:
        x = margin + (chroma / max_chroma_axis) * plot_w
        y = margin + (1.0 - lightness) * plot_h
        return x, y

    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">']
    parts.append(f'<rect x="0" y="0" width="{width}" height="{height}" fill="#111111"/>')

    # Boundary as small coloured circles (each one an actual measured point).
    points_str = []
    for L, C in series:
        x, y = to_xy(L, C)
        points_str.append(f"{x:.1f},{y:.1f}")
        colour = Colour.from_space("oklch", L=L, C=C, h=hue).map_to_gamut(target, "clip")
        parts.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="3" fill="{colour.hex()}"/>')

    # Boundary outline.
    origin_x, origin_y = to_xy(0.0, 0.0)
    top_x, top_y = to_xy(1.0, 0.0)
    outline = f"M {origin_x:.1f},{origin_y:.1f} L " + " L ".join(points_str) + f" L {top_x:.1f},{top_y:.1f} Z"
    parts.append(f'<path d="{outline}" fill="none" stroke="#ffffff" stroke-width="1" stroke-opacity="0.4"/>')

    parts.append("</svg>")
    return "".join(parts)
