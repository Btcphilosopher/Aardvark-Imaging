"""
chroma.render.swatch
=======================

Pure-Python SVG generation for single swatches and swatch strips. No
graphics library dependency -- SVG is just XML, and colour swatches
are rectangles, so a small, careful string template is both simpler
and more transparent than pulling in a drawing library for this.
"""

from __future__ import annotations

from chroma.core.colour import Colour

_SVG_HEADER = '<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">'


def swatch_svg(colour: Colour, size: int = 100) -> str:
    """A single square swatch, ``size`` x ``size`` px."""
    fill = colour.hex()
    opacity = f' fill-opacity="{colour.alpha:.4g}"' if colour.alpha < 1.0 else ""
    return (
        f'{_SVG_HEADER.format(w=size, h=size)}'
        f'<rect width="{size}" height="{size}" fill="{fill}"{opacity}/>'
        f"</svg>"
    )


def strip_svg(colours: list[Colour], swatch_width: int = 60, swatch_height: int = 100, labels: bool = False) -> str:
    """
    A horizontal strip of equal-width swatches -- the workhorse for
    rendering a :class:`~chroma.variation.engine.ColourSeries` or a
    :class:`~chroma.palette.palette.Palette`.
    """
    total_width = swatch_width * len(colours)
    parts = [_SVG_HEADER.format(w=total_width, h=swatch_height)]
    for i, colour in enumerate(colours):
        x = i * swatch_width
        fill = colour.hex()
        opacity = f' fill-opacity="{colour.alpha:.4g}"' if colour.alpha < 1.0 else ""
        parts.append(f'<rect x="{x}" y="0" width="{swatch_width}" height="{swatch_height}" fill="{fill}"{opacity}/>')
        if labels:
            text_colour = "#000000" if colour.convert("oklch").channel("L") > 0.6 else "#ffffff"
            parts.append(
                f'<text x="{x + swatch_width / 2:.1f}" y="{swatch_height - 8}" '
                f'font-size="10" font-family="monospace" text-anchor="middle" fill="{text_colour}">{fill}</text>'
            )
    parts.append("</svg>")
    return "".join(parts)


def grid_svg(colours: list[list[Colour]], cell_size: int = 40) -> str:
    """A 2-D grid of swatches (e.g. a hue x lightness CHROMA MATRIX slice, project spec section 62)."""
    rows = len(colours)
    cols = max((len(r) for r in colours), default=0)
    width, height = cols * cell_size, rows * cell_size
    parts = [_SVG_HEADER.format(w=width, h=height)]
    for y, row in enumerate(colours):
        for x, colour in enumerate(row):
            parts.append(
                f'<rect x="{x * cell_size}" y="{y * cell_size}" width="{cell_size}" height="{cell_size}" fill="{colour.hex()}"/>'
            )
    parts.append("</svg>")
    return "".join(parts)
