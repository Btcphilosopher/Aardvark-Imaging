"""
chroma.render.chart
======================

Minimal SVG bar/line chart rendering -- just enough to visualise a
:class:`chroma.image.histogram.Histogram` or any plain numeric series,
without pulling in a plotting library.
"""

from __future__ import annotations


def bar_chart_svg(values: list[float], colours: list[str] | None = None, width: int = 400, height: int = 200) -> str:
    """A simple bar chart. ``colours`` (hex strings), if given, must match ``len(values)``."""
    if not values:
        return f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}"></svg>'
    peak = max(values) or 1.0
    bar_w = width / len(values)
    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">']
    for i, v in enumerate(values):
        bar_h = (v / peak) * height
        fill = colours[i] if colours else "#888888"
        parts.append(f'<rect x="{i * bar_w:.2f}" y="{height - bar_h:.2f}" width="{max(bar_w - 1, 0.5):.2f}" height="{bar_h:.2f}" fill="{fill}"/>')
    parts.append("</svg>")
    return "".join(parts)


def line_chart_svg(values: list[float], width: int = 400, height: int = 200, stroke: str = "#4da3ff") -> str:
    """A simple single-series line chart."""
    if len(values) < 2:
        return f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}"></svg>'
    lo, hi = min(values), max(values)
    span = (hi - lo) or 1.0
    step_x = width / (len(values) - 1)
    points = []
    for i, v in enumerate(values):
        x = i * step_x
        y = height - ((v - lo) / span) * height
        points.append(f"{x:.2f},{y:.2f}")
    polyline = " ".join(points)
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">'
        f'<polyline points="{polyline}" fill="none" stroke="{stroke}" stroke-width="2"/>'
        f"</svg>"
    )
