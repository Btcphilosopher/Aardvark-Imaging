"""
chroma.render.cube
=====================

A schematic isometric rendering of the RGB unit cube's three faces
nearest the (1,1,1) white corner (project spec section 78's "CUBE"
render target). Each face is drawn as a grid of small parallelograms
rather than one flat fill, so the actual colour at each grid point is
visible -- this is meant as a diagnostic/teaching view of the cube,
not a photorealistic render.
"""

from __future__ import annotations

import math

from chroma.core.colour import Colour

_COS30 = math.cos(math.radians(30))
_SIN30 = math.sin(math.radians(30))


def _project(r: float, g: float, b: float, scale: float) -> tuple[float, float]:
    x = (r - b) * _COS30 * scale
    y = (r + b) * _SIN30 * scale - g * scale
    return x, y


def cube_svg(resolution: int = 8, scale: int = 200, size: int = 500) -> str:
    """Isometric render of the RGB cube's R=1, G=1 and B=1 faces, each subdivided into ``resolution`` x ``resolution`` cells."""
    cx, cy = size / 2.0, size / 2.0
    step = 1.0 / resolution

    def cell_polygon(corners: list[tuple[float, float, float]]) -> str:
        pts = []
        for r, g, b in corners:
            x, y = _project(r, g, b, scale)
            pts.append(f"{cx + x:.2f},{cy + y:.2f}")
        return " ".join(pts)

    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="0 0 {size} {size}">']
    parts.append(f'<rect width="{size}" height="{size}" fill="#1a1a1a"/>')

    faces = [
        ("R", lambda i, j: [(1.0, i * step, j * step), (1.0, (i + 1) * step, j * step), (1.0, (i + 1) * step, (j + 1) * step), (1.0, i * step, (j + 1) * step)]),
        ("G", lambda i, j: [(i * step, 1.0, j * step), ((i + 1) * step, 1.0, j * step), ((i + 1) * step, 1.0, (j + 1) * step), (i * step, 1.0, (j + 1) * step)]),
        ("B", lambda i, j: [(i * step, j * step, 1.0), ((i + 1) * step, j * step, 1.0), ((i + 1) * step, (j + 1) * step, 1.0), (i * step, (j + 1) * step, 1.0)]),
    ]
    for _label, face in faces:
        for i in range(resolution):
            for j in range(resolution):
                corners = face(i, j)
                cr, cg, cb = corners[0]  # sample colour at the cell's near corner
                r2, g2, b2 = [(a + b) / 2.0 for a, b in zip(corners[0], corners[2])]
                colour = Colour.rgb_float(r2, g2, b2)
                poly = cell_polygon(corners)
                parts.append(f'<polygon points="{poly}" fill="{colour.hex()}" stroke="{colour.hex()}" stroke-width="0.5"/>')

    parts.append("</svg>")
    return "".join(parts)
