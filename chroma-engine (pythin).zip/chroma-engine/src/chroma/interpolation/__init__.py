"""chroma.interpolation -- hue-aware colour interpolation."""

from chroma.interpolation.engine import HueInterpolationMode, interpolate, interpolate_series

__all__ = ["interpolate", "interpolate_series", "HueInterpolationMode"]
