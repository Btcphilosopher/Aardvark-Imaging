"""
chroma.interpolation.engine
==============================

Linear interpolation between two colours, in any space, with correct
hue wrapping for polar spaces (project spec section 30: "350 -> 10
should not accidentally interpolate through the entire colour wheel").

:func:`interpolate` is the single entry point; :func:`interpolate_series`
builds an N-step gradient from it. See :mod:`chroma.gradient` for
multi-stop gradients with easing curves built on top of this.
"""

from __future__ import annotations

from enum import Enum

from chroma.core.colour import Colour
from chroma.core.spaces import ColourSpace, channel_names, metadata_for


class HueInterpolationMode(str, Enum):
    SHORTEST = "shortest"
    LONGEST = "longest"
    CLOCKWISE = "clockwise"        # hue increases (mod 360) from h1 towards h2
    COUNTERCLOCKWISE = "counterclockwise"  # hue decreases (mod 360) from h1 towards h2


def _interp_hue(h1: float, h2: float, t: float, mode: HueInterpolationMode) -> float:
    if mode == HueInterpolationMode.SHORTEST:
        diff = ((h2 - h1 + 180.0) % 360.0) - 180.0
        return (h1 + diff * t) % 360.0
    if mode == HueInterpolationMode.LONGEST:
        diff = ((h2 - h1 + 180.0) % 360.0) - 180.0
        diff = (diff - 360.0) if diff >= 0.0 else (diff + 360.0)
        return (h1 + diff * t) % 360.0
    if mode == HueInterpolationMode.CLOCKWISE:
        diff = (h2 - h1) % 360.0
        return (h1 + diff * t) % 360.0
    if mode == HueInterpolationMode.COUNTERCLOCKWISE:
        diff = ((h2 - h1) % 360.0) - 360.0
        return (h1 + diff * t) % 360.0
    raise ValueError(f"Unknown hue interpolation mode: {mode!r}")  # pragma: no cover


def interpolate(
    a: Colour,
    b: Colour,
    t: float,
    space: ColourSpace | str = ColourSpace.OKLAB,
    hue_mode: HueInterpolationMode | str = HueInterpolationMode.SHORTEST,
) -> Colour:
    """
    Interpolate between ``a`` and ``b`` at parameter ``t`` (0 = ``a``,
    1 = ``b``) in ``space``. Any channel named ``"h"`` is interpolated
    with wraparound according to ``hue_mode``; every other channel is
    plain linear interpolation. Alpha is interpolated linearly
    regardless of space. The result is converted back to ``a``'s space.
    """
    space = ColourSpace(space)
    hue_mode = HueInterpolationMode(hue_mode)
    requires_white = metadata_for(space).requires_white_point

    ca = a.convert(space)
    cb = b.convert(space, white=ca.white if requires_white else None)

    names = channel_names(space)
    values = []
    for i, name in enumerate(names):
        va, vb = ca.channels[i], cb.channels[i]
        values.append(_interp_hue(va, vb, t, hue_mode) if name == "h" else va + (vb - va) * t)

    alpha = a.alpha + (b.alpha - a.alpha) * t
    result = Colour(space, tuple(values), white=ca.white, alpha=alpha)
    return result.convert(a.space, white=a.white if metadata_for(a.space).requires_white_point else None)


def interpolate_series(
    a: Colour,
    b: Colour,
    steps: int,
    space: ColourSpace | str = ColourSpace.OKLAB,
    hue_mode: HueInterpolationMode | str = HueInterpolationMode.SHORTEST,
) -> "ColourSeries":  # noqa: F821
    """``steps`` colours evenly spaced from ``a`` (t=0) to ``b`` (t=1) inclusive."""
    from chroma.variation.engine import ColourSeries

    space = ColourSpace(space)
    if steps < 2:
        raise ValueError("interpolate_series needs steps >= 2")
    ts = [i / (steps - 1) for i in range(steps)]
    colours = tuple(interpolate(a, b, t, space, hue_mode) for t in ts)
    return ColourSeries(f"interpolation [{space.value}, {steps} steps]", a.space, colours, tuple(ts))
