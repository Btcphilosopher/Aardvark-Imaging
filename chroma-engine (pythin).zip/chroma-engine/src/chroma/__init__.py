"""
CHROMA ENGINE
=============

A computational colour engine for Aardvark Imaging.

Treat colour as a computational space, not a hex string. See
``README.md`` and ``docs/`` for the full picture; the short version::

    from chroma import Colour

    blue = Colour.hex("#2457A6")
    print(blue.convert("oklch"))
    print(blue.distance(Colour.named("navy")))

    variations = blue.generate_variations(hue_step=15)
    palette = blue.generate_palette(method="perceptual", size=12)

Everything importable from this top-level package is the STABLE
public API (see :mod:`chroma.api.public`). Submodules
(``chroma.conversion``, ``chroma.gamut``, ...) are also directly
importable for anyone who wants finer-grained control.
"""

from chroma.api.public import *  # noqa: F401,F403
from chroma.api.public import __all__ as _public_all

__version__ = "0.1.0"
__all__ = list(_public_all)
