"""
chroma.analysis.gamut
========================

"What fraction of this palette/catalogue is actually displayable on
sRGB / Display P3 / Rec.2020" -- an aggregate view built directly on
:mod:`chroma.gamut.detection`, kept honest by construction: it can
only ever report what the per-colour gamut check reports, nothing is
estimated or interpolated.
"""

from __future__ import annotations

from dataclasses import dataclass

from chroma.core.colour import Colour
from chroma.gamut.detection import TargetGamut, is_in_gamut


@dataclass(frozen=True)
class GamutCoverage:
    target: TargetGamut
    total: int
    in_gamut_count: int
    out_of_gamut: tuple[Colour, ...]

    @property
    def in_gamut_fraction(self) -> float:
        return self.in_gamut_count / self.total if self.total else 0.0


def gamut_coverage(colours: list[Colour], target: TargetGamut | str = TargetGamut.SRGB) -> GamutCoverage:
    target = TargetGamut(target)
    out_of_gamut = tuple(c for c in colours if not is_in_gamut(c, target))
    return GamutCoverage(target=target, total=len(colours), in_gamut_count=len(colours) - len(out_of_gamut), out_of_gamut=out_of_gamut)


def gamut_coverage_report(colours: list[Colour]) -> dict[str, GamutCoverage]:
    """Coverage against all three built-in target gamuts at once."""
    return {t.value: gamut_coverage(colours, t) for t in TargetGamut}
