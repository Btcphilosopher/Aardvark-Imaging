"""
chroma.analysis -- statistics, distributions, and gamut-coverage
analysis over plain colour lists (palettes, catalogues, swatch sets).
Entropy is available via Histogram.entropy() (see
chroma.image.histogram and chroma.analysis.distributions); there is
no separate entropy.py -- consolidated here rather than split into an
empty extra file.
"""

from chroma.analysis.distributions import chroma_distribution, hue_distribution, hue_statistics, lightness_distribution
from chroma.analysis.gamut import GamutCoverage, gamut_coverage, gamut_coverage_report
from chroma.analysis.statistics import ColourSetStatistics, colour_set_statistics

__all__ = [
    "colour_set_statistics", "ColourSetStatistics",
    "hue_distribution", "lightness_distribution", "chroma_distribution", "hue_statistics",
    "gamut_coverage", "gamut_coverage_report", "GamutCoverage",
]
