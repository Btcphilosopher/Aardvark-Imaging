"""
chroma.analysis.statistics
=============================

Descriptive statistics over a plain list of :class:`~chroma.core.colour.Colour`
objects -- a palette, a catalogue's contents, a sampled swatch set.
This is the same underlying maths as :mod:`chroma.image.histogram`,
but for cases where there is no pixel grid, just a set of colours.
"""

from __future__ import annotations

import statistics as _stats
from dataclasses import dataclass

from chroma.core.colour import Colour
from chroma.core.spaces import ColourSpace


@dataclass(frozen=True)
class ColourSetStatistics:
    count: int
    mean_oklab: tuple[float, float, float]
    stdev_oklab: tuple[float, float, float]
    mean_lightness: float
    mean_chroma: float
    lightness_range: tuple[float, float]
    chroma_range: tuple[float, float]


def colour_set_statistics(colours: list[Colour]) -> ColourSetStatistics:
    if not colours:
        raise ValueError("colour_set_statistics needs at least one colour.")
    oklab = [c.convert(ColourSpace.OKLAB).channels for c in colours]
    oklch = [c.convert(ColourSpace.OKLCH).channels for c in colours]
    means = tuple(_stats.fmean(v[i] for v in oklab) for i in range(3))
    stdevs = tuple(_stats.pstdev(v[i] for v in oklab) if len(oklab) > 1 else 0.0 for i in range(3))
    lightness_vals = [v[0] for v in oklch]
    chroma_vals = [v[1] for v in oklch]
    return ColourSetStatistics(
        count=len(colours),
        mean_oklab=means,  # type: ignore[arg-type]
        stdev_oklab=stdevs,  # type: ignore[arg-type]
        mean_lightness=_stats.fmean(lightness_vals),
        mean_chroma=_stats.fmean(chroma_vals),
        lightness_range=(min(lightness_vals), max(lightness_vals)),
        chroma_range=(min(chroma_vals), max(chroma_vals)),
    )
