"""
chroma.analysis.distributions
================================

Hue, lightness and chroma distributions (histograms + Shannon entropy)
for a plain colour list, reusing :mod:`chroma.image.histogram`'s
machinery via a trivial one-row :class:`~chroma.image.source.ListImageSource`
adapter rather than re-implementing binning twice.
"""

from __future__ import annotations

from chroma.core.colour import Colour
from chroma.image.histogram import ChannelStatistics, Histogram, build_histogram, channel_statistics
from chroma.image.source import ListImageSource


def _as_source(colours: list[Colour]) -> ListImageSource:
    return ListImageSource([list(colours)])


def hue_distribution(colours: list[Colour], bins: int = 24) -> Histogram:
    return build_histogram(_as_source(colours), "hue", bins)


def lightness_distribution(colours: list[Colour], bins: int = 20) -> Histogram:
    return build_histogram(_as_source(colours), "lightness", bins)


def chroma_distribution(colours: list[Colour], bins: int = 20) -> Histogram:
    return build_histogram(_as_source(colours), "chroma", bins)


def hue_statistics(colours: list[Colour], bins: int = 24) -> ChannelStatistics:
    return channel_statistics(_as_source(colours), "hue", bins)
