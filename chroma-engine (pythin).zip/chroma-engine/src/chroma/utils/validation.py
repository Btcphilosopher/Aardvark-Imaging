"""chroma.utils.validation -- shared, explicit input-validation helpers."""

from __future__ import annotations

from chroma.core.exceptions import InvalidChannelError


def ensure_finite(value: float, label: str = "value") -> float:
    if value != value or value in (float("inf"), float("-inf")):
        raise InvalidChannelError(f"{label} must be finite, got {value!r}.")
    return value


def ensure_in_range(value: float, lo: float, hi: float, label: str = "value") -> float:
    if not (lo <= value <= hi):
        raise InvalidChannelError(f"{label} must be in [{lo}, {hi}], got {value!r}.")
    return value


def ensure_arity(values: tuple, expected: int, label: str = "channels") -> tuple:
    if len(values) != expected:
        raise InvalidChannelError(f"{label} expects {expected} value(s), got {len(values)}.")
    return values
