"""chroma.utils.numeric -- small, dependency-free numeric helpers shared across the engine."""

from __future__ import annotations


def clamp(value: float, lo: float, hi: float) -> float:
    return lo if value < lo else (hi if value > hi else value)


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def remap(value: float, in_lo: float, in_hi: float, out_lo: float, out_hi: float) -> float:
    """Linearly remap ``value`` from ``[in_lo, in_hi]`` to ``[out_lo, out_hi]`` (not clamped)."""
    if in_hi == in_lo:
        return out_lo
    t = (value - in_lo) / (in_hi - in_lo)
    return out_lo + t * (out_hi - out_lo)


def wrap_degrees(degrees: float) -> float:
    return degrees % 360.0


def is_close(a: float, b: float, tolerance: float = 1e-9) -> bool:
    return abs(a - b) <= tolerance
