"""chroma.utils -- shared numeric/validation/formatting helpers."""

from chroma.utils.formatting import format_channels, format_degrees, format_percentage
from chroma.utils.numeric import clamp, is_close, lerp, remap, wrap_degrees
from chroma.utils.validation import ensure_arity, ensure_finite, ensure_in_range

__all__ = [
    "clamp", "lerp", "remap", "wrap_degrees", "is_close",
    "ensure_finite", "ensure_in_range", "ensure_arity",
    "format_percentage", "format_degrees", "format_channels",
]
