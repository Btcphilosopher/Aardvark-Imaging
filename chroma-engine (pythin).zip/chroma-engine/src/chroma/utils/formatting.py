"""chroma.utils.formatting -- small display-formatting helpers used by the CLI and examples."""

from __future__ import annotations


def format_percentage(fraction: float, decimals: int = 1) -> str:
    return f"{fraction * 100:.{decimals}f}%"


def format_degrees(degrees: float, decimals: int = 1) -> str:
    return f"{degrees:.{decimals}f}\u00b0"


def format_channels(values: tuple[float, ...], decimals: int = 4) -> str:
    return ", ".join(f"{v:.{decimals}f}" for v in values)
