"""
chroma.harmony.engine
========================

Classic colour-wheel harmonies, computed as hue-angle offsets. Every
function accepts a ``space`` parameter (project spec section 26: "Allow
the user to compare the same harmony generated in different spaces")
because HSV, HSL, LCh and OKLCh do not agree on where a given hue
angle actually sits perceptually -- a "triadic" scheme in HSV and the
same angles in OKLCh can look noticeably different. Default is OKLCh,
the engine's recommended perceptual working space.
"""

from __future__ import annotations

from chroma.core.colour import Colour
from chroma.core.spaces import ColourSpace, channel_names


def _hue_index(space: ColourSpace) -> int:
    return channel_names(space).index("h")


def _at_hue(colour: Colour, space: ColourSpace, hue: float) -> Colour:
    conv = colour.convert(space)
    idx = _hue_index(space)
    values = list(conv.channels)
    values[idx] = hue % 360.0
    return Colour(space, tuple(values), white=conv.white, alpha=colour.alpha).convert(colour.space, white=colour.white)


def angular_harmony(
    colour: Colour,
    offsets_degrees: tuple[float, ...],
    space: ColourSpace | str = ColourSpace.OKLCH,
) -> tuple[Colour, ...]:
    """
    Custom angular harmony (project spec section 26): a colour for
    every offset in ``offsets_degrees``, added to ``colour``'s own hue
    in ``space``. ``offsets_degrees=(0.0,)`` returns just ``colour``
    itself (re-expressed via a round trip through ``space``).
    """
    space = ColourSpace(space)
    base_hue = colour.convert(space).channels[_hue_index(space)]
    return tuple(_at_hue(colour, space, base_hue + off) for off in offsets_degrees)


def complementary(colour: Colour, space: ColourSpace | str = ColourSpace.OKLCH) -> Colour:
    """The single colour 180 degrees opposite ``colour`` on the hue wheel."""
    return angular_harmony(colour, (180.0,), space)[0]


def analogous(colour: Colour, angle: float = 30.0, space: ColourSpace | str = ColourSpace.OKLCH) -> tuple[Colour, Colour, Colour]:
    """``(colour - angle, colour, colour + angle)`` -- the classic 3-colour analogous scheme."""
    return angular_harmony(colour, (-angle, 0.0, angle), space)


def triadic(colour: Colour, space: ColourSpace | str = ColourSpace.OKLCH) -> tuple[Colour, Colour, Colour]:
    """Three colours 120 degrees apart, including ``colour`` itself."""
    return angular_harmony(colour, (0.0, 120.0, 240.0), space)


def tetradic(
    colour: Colour,
    angle: float = 90.0,
    space: ColourSpace | str = ColourSpace.OKLCH,
) -> tuple[Colour, Colour, Colour, Colour]:
    """
    Four colours: ``colour``, its complement, and a second
    complementary pair offset by ``angle`` (default 90 -> square
    tetradic; a smaller angle gives a "rectangle" tetradic scheme).
    """
    return angular_harmony(colour, (0.0, angle, 180.0, 180.0 + angle), space)


def split_complementary(
    colour: Colour,
    angle: float = 30.0,
    space: ColourSpace | str = ColourSpace.OKLCH,
) -> tuple[Colour, Colour, Colour]:
    """``colour`` plus the two hues adjacent to its complement."""
    return angular_harmony(colour, (0.0, 180.0 - angle, 180.0 + angle), space)


def double_complementary(
    colour: Colour,
    angle: float = 30.0,
    space: ColourSpace | str = ColourSpace.OKLCH,
) -> tuple[Colour, Colour, Colour, Colour]:
    """
    Also known as "tetradic (adjacent pairs)": ``colour``, a near
    neighbour ``angle`` away, and both of their complements.
    """
    return angular_harmony(colour, (0.0, angle, 180.0, 180.0 + angle), space)


def monochromatic(
    colour: Colour,
    steps: int = 8,
    space: ColourSpace | str = ColourSpace.OKLCH,
    lightness_range: tuple[float, float] | None = None,
) -> "ColourSeries":  # noqa: F821 -- see chroma.variation.engine.ColourSeries
    """
    A single-hue lightness sweep (project spec section 18): same hue
    and chroma as ``colour``, lightness varied across
    ``lightness_range`` (defaults to the space's own nominal L range).
    """
    from chroma.core.spaces import metadata_for
    from chroma.variation.engine import ColourSeries

    space = ColourSpace(space)
    names = channel_names(space)
    l_channel = "L" if "L" in names else "l"
    l_idx = names.index(l_channel)
    lo, hi = lightness_range if lightness_range else metadata_for(space).channel_ranges[l_idx]

    conv = colour.convert(space)
    values_l = [lo + (hi - lo) * i / (steps - 1) for i in range(steps)] if steps > 1 else [conv.channels[l_idx]]
    colours = []
    for v in values_l:
        chans = list(conv.channels)
        chans[l_idx] = v
        colours.append(Colour(space, tuple(chans), white=conv.white, alpha=colour.alpha).convert(colour.space, white=colour.white))
    return ColourSeries(f"monochromatic [{space.value}]", space, tuple(colours), tuple(values_l))
