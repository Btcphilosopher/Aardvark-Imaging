"""
chroma.cli
============

The ``chroma`` command (project spec section 71). Thin argparse
wrapper around the public API -- no logic lives here that isn't
already in the library; the CLI exists purely to make the engine
usable from a shell/script without writing Python.
"""

from __future__ import annotations

import argparse
import json
import sys

from chroma.core.colour import Colour
from chroma.core.spaces import ColourSpace


def _parse_colour(text: str) -> Colour:
    return Colour.from_css(text) if not text.startswith("#") else Colour.hex(text)


def cmd_inspect(args: argparse.Namespace) -> None:
    c = _parse_colour(args.colour)
    spaces = ["srgb", "linear_rgb", "hsv", "hsl", "xyz", "lab", "lch", "oklab", "oklch"]
    print(f"Input: {args.colour}  ->  {c.hex()}")
    for space in spaces:
        conv = c.convert(space)
        body = ", ".join(f"{n}={v:.4f}" for n, v in conv.as_dict().items())
        print(f"  {space.upper():<11} {body}")
    print(f"  In sRGB gamut: {c.is_in_gamut('srgb')}   In Display P3: {c.is_in_gamut('display-p3')}   In Rec.2020: {c.is_in_gamut('rec2020')}")


def cmd_convert(args: argparse.Namespace) -> None:
    c = _parse_colour(args.colour).convert(args.space)
    if args.json:
        print(json.dumps(c.to_dict(), indent=2))
    else:
        body = ", ".join(f"{n}={v:.6g}" for n, v in c.as_dict().items())
        print(f"{args.space}: {body}")


def cmd_variations(args: argparse.Namespace) -> None:
    c = _parse_colour(args.colour)
    vs = c.generate_variations(hue_step=args.hue_step, lightness_steps=args.steps, chroma_steps=args.steps)
    print(f"Base: {c.hex()}")
    print(f"Hue sweep ({len(vs.hue)}): " + " ".join(vs.hue.hex_list()))
    print(f"Lightness series ({len(vs.lightness)}): " + " ".join(vs.lightness.hex_list()))
    print(f"Chroma series ({len(vs.chroma)}): " + " ".join(vs.chroma.hex_list()))
    print(f"Tints: " + " ".join(vs.tints.hex_list()))
    print(f"Shades: " + " ".join(vs.shades.hex_list()))
    print(f"Tones: " + " ".join(vs.tones.hex_list()))
    print(f"Complement: {vs.complement.hex()}")
    print(f"Analogous: " + " ".join(x.hex() for x in vs.analogous))
    print(f"Triadic: " + " ".join(x.hex() for x in vs.triadic))
    print(f"Tetradic: " + " ".join(x.hex() for x in vs.tetradic))


def cmd_harmony(args: argparse.Namespace) -> None:
    from chroma import harmony as harmony_mod  # local import: keep CLI import time light

    c = _parse_colour(args.colour)
    fn = {
        "complementary": lambda: (harmony_mod.complementary(c),),
        "analogous": lambda: harmony_mod.analogous(c),
        "triadic": lambda: harmony_mod.triadic(c),
        "tetradic": lambda: harmony_mod.tetradic(c),
        "split_complementary": lambda: harmony_mod.split_complementary(c),
    }.get(args.type)
    if fn is None:
        print(f"Unknown harmony type: {args.type}", file=sys.stderr)
        sys.exit(1)
    result = fn()
    print(" ".join(x.hex() for x in result))


def cmd_gradient(args: argparse.Namespace) -> None:
    from chroma import Gradient

    a, b = _parse_colour(args.start), _parse_colour(args.end)
    g = Gradient.from_colours([a, b], space=args.space)
    print(" ".join(c.hex() for c in g.sample_series(args.steps)))


def cmd_gamut(args: argparse.Namespace) -> None:
    from chroma.gamut.mapping import map_to_gamut_report

    c = _parse_colour(args.colour)
    report = map_to_gamut_report(c, target=args.target, method=args.method)
    print(f"Original: {report.original.hex()}   In gamut ({args.target}): {c.is_in_gamut(args.target)}")
    print(f"Mapped:   {report.mapped.hex()}   Delta (OKLab): {report.delta_oklab:.5f}")


def cmd_distance(args: argparse.Namespace) -> None:
    a, b = _parse_colour(args.a), _parse_colour(args.b)
    for method in ("rgb_euclidean", "cie76", "cie94", "ciede2000", "oklab_euclidean"):
        print(f"  {method:<16} {a.distance(b, method):.4f}")


def cmd_palette(args: argparse.Namespace) -> None:
    c = _parse_colour(args.colour)
    pal = c.generate_palette(method=args.method, size=args.size)
    print(" ".join(x.hex() for x in pal.colours()))


def cmd_catalogue(args: argparse.Namespace) -> None:
    from chroma.catalogue.database import Catalogue

    if args.catalogue_command == "search":
        cat = Catalogue.load_json(args.file)
        kwargs = {}
        if args.hue_range:
            lo, hi = args.hue_range
            kwargs["hue_range"] = (lo, hi)
        if args.chroma_gt is not None:
            kwargs["chroma_gt"] = args.chroma_gt
        for entry in cat.search(**kwargs):
            print(f"{entry.id}\t{entry.colour.hex()}\t{entry.name or ''}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="chroma", description="Chroma Engine -- a computational colour engine for Aardvark Imaging.")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("inspect", help="Show a colour's coordinates across every major colour space.")
    p.add_argument("colour")
    p.set_defaults(func=cmd_inspect)

    p = sub.add_parser("convert", help="Convert a colour to another space.")
    p.add_argument("colour")
    p.add_argument("--space", required=True, choices=[s.value for s in ColourSpace])
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_convert)

    p = sub.add_parser("variations", help="Print the full variation set for a colour.")
    p.add_argument("colour")
    p.add_argument("--hue-step", type=float, default=30.0)
    p.add_argument("--steps", type=int, default=8)
    p.set_defaults(func=cmd_variations)

    p = sub.add_parser("harmony", help="Print a harmony scheme.")
    p.add_argument("colour")
    p.add_argument("--type", default="complementary", choices=["complementary", "analogous", "triadic", "tetradic", "split_complementary"])
    p.set_defaults(func=cmd_harmony)

    p = sub.add_parser("gradient", help="Sample a gradient between two colours.")
    p.add_argument("start")
    p.add_argument("end")
    p.add_argument("--steps", type=int, default=10)
    p.add_argument("--space", default="oklab")
    p.set_defaults(func=cmd_gradient)

    p = sub.add_parser("gamut", help="Check/map a colour against a target gamut.")
    p.add_argument("colour")
    p.add_argument("--target", default="srgb", choices=["srgb", "display-p3", "rec2020"])
    p.add_argument("--method", default="compress_chroma")
    p.set_defaults(func=cmd_gamut)

    p = sub.add_parser("distance", help="Compare two colours under every distance metric.")
    p.add_argument("a")
    p.add_argument("b")
    p.set_defaults(func=cmd_distance)

    p = sub.add_parser("palette", help="Generate a palette from a seed colour.")
    p.add_argument("colour")
    p.add_argument("--size", type=int, default=5)
    p.add_argument("--method", default="analogous")
    p.set_defaults(func=cmd_palette)

    p = sub.add_parser("catalogue", help="Query a .json catalogue file.")
    csub = p.add_subparsers(dest="catalogue_command", required=True)
    ps = csub.add_parser("search")
    ps.add_argument("file")
    ps.add_argument("--hue-range", type=float, nargs=2, metavar=("LO", "HI"))
    ps.add_argument("--chroma-gt", type=float)
    p.set_defaults(func=cmd_catalogue)

    return parser


def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
