"""
chroma.io.css
================

Export a palette or gradient as CSS: custom properties
(``:root { --name: #hex; }``) or a ``linear-gradient()`` value
(project spec section 66).
"""

from __future__ import annotations

import re

from chroma.core.colour import Colour
from chroma.palette.palette import Palette


def _slugify(name: str, fallback: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug or fallback


def export_css_variables(palette: Palette, prefix: str = "--chroma") -> str:
    lines = [":root {"]
    for i, entry in enumerate(palette.entries):
        base = entry.role.value if entry.role else (entry.name or f"colour-{i}")
        slug = _slugify(base, f"colour-{i}")
        lines.append(f"  {prefix}-{slug}: {entry.colour.css()};")
    lines.append("}")
    return "\n".join(lines)


def export_css_gradient(colours: list[Colour], angle_degrees: float = 90.0) -> str:
    stops = ", ".join(c.css() for c in colours)
    angle = int(angle_degrees) if float(angle_degrees).is_integer() else angle_degrees
    return f"linear-gradient({angle}deg, {stops})"
