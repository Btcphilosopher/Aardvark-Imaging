"""
chroma.io.svg
================

Write a palette to an SVG swatch-strip FILE (project spec section 66).
The actual SVG string-building lives in :mod:`chroma.render.swatch`;
this module is purely the "and now save it to disk" step, kept
separate because :mod:`chroma.render` is about generating visuals for
display/embedding and :mod:`chroma.io` is about file I/O -- the same
distinction as :mod:`chroma.catalogue.serialization` vs. the
in-memory :class:`~chroma.catalogue.database.Catalogue`.
"""

from __future__ import annotations

from chroma.palette.palette import Palette
from chroma.render.swatch import strip_svg


def export_palette_svg(palette: Palette, path: str, swatch_width: int = 60, swatch_height: int = 100, labels: bool = True) -> None:
    svg = strip_svg([e.colour for e in palette.entries], swatch_width, swatch_height, labels)
    with open(path, "w", encoding="utf-8") as f:
        f.write(svg)
