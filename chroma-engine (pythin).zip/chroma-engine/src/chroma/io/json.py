"""
chroma.io.json
=================

JSON export/import for the engine's core types. Thin by design --
Colour, Palette and Catalogue already know how to serialise
themselves (``to_dict``/``from_dict``); this module is the "write it
to a file" / "read it from a file" convenience layer project spec
section 66 asks for.
"""

from __future__ import annotations

import json as _json
from typing import Any

from chroma.core.colour import Colour
from chroma.catalogue.database import Catalogue
from chroma.palette.palette import Palette


def export_json(obj: Colour | Palette | Catalogue, path: str | None = None, *, indent: int = 2) -> str:
    """Serialise ``obj`` to a JSON string, optionally also writing it to ``path``."""
    data: dict[str, Any] = obj.to_dict()
    text = _json.dumps(data, indent=indent)
    if path is not None:
        with open(path, "w", encoding="utf-8") as f:
            f.write(text)
    return text


def import_colour_json(path: str) -> Colour:
    with open(path, encoding="utf-8") as f:
        return Colour.from_dict(_json.load(f))


def import_palette_json(path: str) -> Palette:
    with open(path, encoding="utf-8") as f:
        return Palette.from_dict(_json.load(f))


def import_catalogue_json(path: str) -> Catalogue:
    return Catalogue.load_json(path)
