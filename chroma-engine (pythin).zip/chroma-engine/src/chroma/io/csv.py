"""
chroma.io.csv
================

CSV export/import for palettes and catalogues (project spec section
66), using only the standard library ``csv`` module. Columns:
``name, hex, r, g, b, alpha, role`` -- deliberately simple and
spreadsheet-friendly rather than round-tripping every colour space.
"""

from __future__ import annotations

import csv as _csv

from chroma.core.colour import Colour
from chroma.palette.palette import Palette, PaletteEntry, Role

_FIELDNAMES = ["name", "hex", "r", "g", "b", "alpha", "role"]


def export_palette_csv(palette: Palette, path: str) -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = _csv.DictWriter(f, fieldnames=_FIELDNAMES)
        writer.writeheader()
        for entry in palette.entries:
            r, g, b = entry.colour.rgb8()
            writer.writerow({
                "name": entry.name or "", "hex": entry.colour.hex(),
                "r": r, "g": g, "b": b, "alpha": entry.colour.alpha,
                "role": entry.role.value if entry.role else "",
            })


def import_palette_csv(path: str, name: str | None = None) -> Palette:
    entries = []
    with open(path, newline="", encoding="utf-8") as f:
        for row in _csv.DictReader(f):
            colour = Colour.hex(row["hex"]) if row.get("hex") else Colour.rgb(int(row["r"]), int(row["g"]), int(row["b"]))
            if row.get("alpha"):
                colour = Colour(colour.space, colour.channels, white=colour.white, alpha=float(row["alpha"]))
            role = Role(row["role"]) if row.get("role") else None
            entries.append(PaletteEntry(colour, name=row.get("name") or None, role=role))
    return Palette(tuple(entries), name=name, source=path)
