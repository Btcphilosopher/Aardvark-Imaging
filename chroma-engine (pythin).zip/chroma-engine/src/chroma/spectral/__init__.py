"""chroma.spectral -- experimental spectral-distribution subsystem (see spectrum.py's docstring for scope)."""

from chroma.spectral.colour_temperature import NotNearPlanckianLocusError, cct_from_colour, cct_from_xy
from chroma.spectral.reconstruction import reflectance_from_rgb
from chroma.spectral.sampling import resample_to_match, resample_uniform
from chroma.spectral.spectrum import Spectrum
from chroma.spectral.wavelength import wavelength_to_colour, wavelength_to_xyz

__all__ = [
    "Spectrum", "wavelength_to_xyz", "wavelength_to_colour",
    "reflectance_from_rgb", "resample_uniform", "resample_to_match",
    "cct_from_xy", "cct_from_colour", "NotNearPlanckianLocusError",
]
