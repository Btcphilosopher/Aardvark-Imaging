"""
chroma.spectral.sampling
===========================

Thin, explicitly named wrappers around Spectrum's own resampling, kept
as a separate module (per the project's file layout) so "how do I
resample a spectrum onto a new grid" has an obvious place to look
without needing to know it is a Spectrum method.
"""

from __future__ import annotations

from chroma.spectral.spectrum import Spectrum


def resample_uniform(spectrum: Spectrum, start: float, end: float, step: float) -> Spectrum:
    """Resample onto a uniform ``start:step:end`` grid (see :meth:`Spectrum.resample`)."""
    return spectrum.resample(start, end, step)


def resample_to_match(spectrum: Spectrum, other: Spectrum) -> Spectrum:
    """Resample ``spectrum`` onto ``other``'s exact wavelength grid, for direct comparison."""
    return Spectrum(other.wavelengths, tuple(spectrum.at(w) for w in other.wavelengths), label=spectrum.label)
