"""
chroma.spectral.colour_temperature
=====================================

Correlated colour temperature (CCT) estimation (project spec section
50) -- a PHYSICAL quantity computed from CIE xy chromaticity, entirely
distinct from the PERCEPTUAL "warm/cool" hue-shift utilities in
:mod:`chroma.variation.engine` (:func:`~chroma.variation.engine.temperature_series`).
Conflating the two is exactly the kind of "fake science" project spec
section 76 asks this engine to avoid, so they live in different
modules with different return types (Kelvin vs. a colour series).

Method: McCamy's cubic approximation (McCamy, C.S. (1992), "Correlated
color temperature as an explicit function of chromaticity
coordinates", Color Research & Application, 17(2), 142-144) -- a
widely used closed-form fit, NOT an iterative Planckian-locus search.
It is only valid for chromaticities reasonably close to the Planckian
locus in roughly the 2856K-6504K range; well off the locus (strongly
tinted colours) "CCT" is not a meaningful physical quantity at all,
and this module says so rather than returning a confident-looking
wrong number.
"""

from __future__ import annotations

import math

from chroma.core.colour import Colour
from chroma.core.exceptions import ChromaError
from chroma.core.spaces import ColourSpace


class NotNearPlanckianLocusError(ChromaError):
    """Raised when a chromaticity is far enough from the Planckian locus that CCT is not a meaningful description."""


# McCamy's fit is documented as reliable within this distance of the
# locus in (x, y) terms; beyond it we refuse to report a number rather
# than silently extrapolating (see module docstring).
_MAX_DUV_FOR_RELIABLE_CCT = 0.05


def cct_from_xy(x: float, y: float, *, strict: bool = True) -> float:
    """
    McCamy's approximation of correlated colour temperature (Kelvin)
    from CIE 1931 (x, y) chromaticity.
    """
    n = (x - 0.3320) / (0.1858 - y)
    cct = 449.0 * n ** 3 + 3525.0 * n ** 2 + 6823.3 * n + 5520.33
    if strict and not (1000.0 <= cct <= 20000.0):
        raise NotNearPlanckianLocusError(
            f"Chromaticity ({x:.4f}, {y:.4f}) gives an implausible CCT "
            f"({cct:.0f}K); it is not close enough to the Planckian locus "
            "for McCamy's approximation to be meaningful. Pass strict=False "
            "to get the raw (unreliable) number anyway."
        )
    return cct


def cct_from_colour(colour: Colour, *, strict: bool = True) -> float:
    """Correlated colour temperature (Kelvin) of ``colour``'s own chromaticity, treating it AS a light source/white point (not a surface colour)."""
    x, y, _big_y = colour.convert(ColourSpace.XYY).channels
    return cct_from_xy(x, y, strict=strict)
