"""
chroma.spectral.spectrum
===========================

:class:`Spectrum` represents a sampled spectral power/reflectance
distribution over wavelength (project spec section 48). It is the
"experimental" subsystem the spec explicitly allows to be partial --
what IS implemented here (linear interpolation, normalisation,
integration, CIE XYZ conversion against the bundled CIE 1931 2-degree
observer) is real, tested maths; what is NOT implemented (a bundled
illuminant SPD library beyond flat/D65-XYZ-only, non-linear spectral
upsampling) is left as clearly-labelled extension points rather than
faked.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from chroma.core.colour import Colour
from chroma.core.constants import SPECTRAL_MAX_NM, SPECTRAL_MIN_NM
from chroma.core.exceptions import SpectralDataError
from chroma.core.illuminants import D65, WhitePoint
from chroma.core.spaces import ColourSpace
from chroma.spectral.data.cie1931_2deg_5nm import STEP_NM as _CMF_STEP
from chroma.spectral.data.cie1931_2deg_5nm import WAVELENGTHS_NM as _CMF_WAVELENGTHS
from chroma.spectral.data.cie1931_2deg_5nm import X_BAR as _CMF_X
from chroma.spectral.data.cie1931_2deg_5nm import Y_BAR as _CMF_Y
from chroma.spectral.data.cie1931_2deg_5nm import Z_BAR as _CMF_Z


@dataclass(frozen=True)
class Spectrum:
    """
    A sampled spectral distribution: parallel ``wavelengths`` (nm,
    strictly increasing) and ``values`` (arbitrary units -- radiance,
    reflectance 0..1, transmittance 0..1, whatever the caller means by
    it; this class does not enforce a unit).
    """

    wavelengths: tuple[float, ...]
    values: tuple[float, ...]
    label: str = ""

    def __post_init__(self) -> None:
        if len(self.wavelengths) != len(self.values):
            raise SpectralDataError("wavelengths and values must be the same length.")
        if len(self.wavelengths) < 2:
            raise SpectralDataError("A Spectrum needs at least 2 samples.")
        if any(b <= a for a, b in zip(self.wavelengths, self.wavelengths[1:])):
            raise SpectralDataError("wavelengths must be strictly increasing.")

    @classmethod
    def flat(cls, value: float = 1.0, start: float = SPECTRAL_MIN_NM, end: float = SPECTRAL_MAX_NM, step: float = 5.0, label: str = "flat") -> "Spectrum":
        """A constant-value spectrum (e.g. the equal-energy illuminant E, or a neutral 100% reflector)."""
        n = int(round((end - start) / step)) + 1
        wl = tuple(start + i * step for i in range(n))
        return cls(wl, tuple(value for _ in wl), label=label)

    def at(self, nm: float) -> float:
        """Linearly interpolated value at an arbitrary wavelength (0 outside the sampled range)."""
        wl = self.wavelengths
        if nm <= wl[0]:
            return self.values[0] if nm == wl[0] else 0.0
        if nm >= wl[-1]:
            return self.values[-1] if nm == wl[-1] else 0.0
        # Linear scan is fine: spectra here are tens to low hundreds of
        # samples, not a hot inner loop -- clarity over premature
        # optimisation (a bisect-based version would be a drop-in
        # replacement if profiling ever shows this matters).
        for i in range(len(wl) - 1):
            if wl[i] <= nm <= wl[i + 1]:
                span = wl[i + 1] - wl[i]
                frac = 0.0 if span == 0 else (nm - wl[i]) / span
                return self.values[i] * (1.0 - frac) + self.values[i + 1] * frac
        return 0.0  # pragma: no cover - unreachable given the bounds checks above

    def resample(self, start: float, end: float, step: float) -> "Spectrum":
        """A new :class:`Spectrum` re-sampled onto a uniform grid via linear interpolation."""
        n = int(round((end - start) / step)) + 1
        wl = tuple(start + i * step for i in range(n))
        return Spectrum(wl, tuple(self.at(w) for w in wl), label=self.label)

    def normalised(self, target: float = 1.0) -> "Spectrum":
        """Scale so the maximum value is ``target``."""
        peak = max(self.values)
        if peak == 0.0:
            return self
        scale = target / peak
        return Spectrum(self.wavelengths, tuple(v * scale for v in self.values), label=self.label)

    def integrate(self) -> float:
        """Trapezoidal-rule integral of the spectrum over its sampled range."""
        total = 0.0
        for i in range(len(self.wavelengths) - 1):
            dx = self.wavelengths[i + 1] - self.wavelengths[i]
            total += dx * (self.values[i] + self.values[i + 1]) / 2.0
        return total

    def compare(self, other: "Spectrum") -> float:
        """RMS difference between two spectra, resampling ``other`` onto this spectrum's grid."""
        return math.sqrt(
            sum((v - other.at(w)) ** 2 for w, v in zip(self.wavelengths, self.values)) / len(self.wavelengths)
        )

    def to_xyz(self, illuminant: "Spectrum | None" = None) -> tuple[float, float, float]:
        """
        Convert to CIE XYZ against the bundled CIE 1931 2-degree
        colour-matching functions (see
        :mod:`chroma.spectral.data.cie1931_2deg_5nm` for provenance).

        If ``illuminant`` is given, this spectrum is treated as a
        REFLECTANCE/TRANSMITTANCE curve (0..1) and is multiplied by the
        illuminant's spectral power distribution before integrating
        (the standard ASTM E308 procedure); otherwise this spectrum is
        treated as already being a radiance/emission curve.
        """
        x = y = z = 0.0
        k_norm = 0.0
        for wl, xb, yb, zb in zip(_CMF_WAVELENGTHS, _CMF_X, _CMF_Y, _CMF_Z):
            s = self.at(wl) * (illuminant.at(wl) if illuminant is not None else 1.0)
            x += s * xb
            y += s * yb
            z += s * zb
            if illuminant is not None:
                k_norm += illuminant.at(wl) * yb
        step = _CMF_STEP
        if illuminant is not None and k_norm > 0.0:
            k = 100.0 / (k_norm * step)
            return (x * step * k / 100.0, y * step * k / 100.0, z * step * k / 100.0)
        return (x * step, y * step, z * step)

    def to_colour(self, white: WhitePoint = D65, illuminant: "Spectrum | None" = None) -> Colour:
        """Convert to a :class:`Colour` in XYZ@``white`` (see :meth:`to_xyz` for the illuminant argument)."""
        return Colour(ColourSpace.XYZ, self.to_xyz(illuminant), white=white)
