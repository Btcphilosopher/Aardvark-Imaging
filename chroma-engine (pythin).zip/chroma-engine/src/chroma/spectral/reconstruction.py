"""
chroma.spectral.reconstruction
=================================

Going from RGB to a plausible reflectance SPECTRUM is fundamentally
under-determined: infinitely many spectra ("metamers") produce the
same RGB. Anything in this module produces SYNTHETIC data (per the
REFERENCE / USER-SUPPLIED / SYNTHETIC distinction in project spec
section 49) -- a plausible-looking curve consistent with the input
colour, not a measurement, and not claimed to be THE spectrum of
anything real.

The method implemented here is deliberately the simplest defensible
one: a piecewise-constant three-band reflectance curve (kept flat
across long-wave/mid/short-wave thirds of the visible range), the same
approach used by early spectral ray tracers for exactly this purpose
(e.g. Hall, "Illumination and Color in Computer Generated Imagery",
1989, reproduced in BRL-CAD's ``rt_spect_reflectance_rgb``). It is
crude -- production work wanting smoother, more physically plausible
metamers should implement Smits (1999), "An RGB-to-Spectrum Conversion
for Reflectances", or a Meng et al. (2015) sigmoid-basis reconstruction
instead; this module is an honest, simple starting point and an
extension seam, not a claim of photometric accuracy.
"""

from __future__ import annotations

from chroma.core.colour import Colour
from chroma.core.spaces import ColourSpace
from chroma.spectral.spectrum import Spectrum

# Band edges follow Hall/BRL-CAD's own choice: blue covers everything
# below 492nm, green 492-572nm, red 572nm and above.
_BLUE_MAX_NM = 492.0
_GREEN_MAX_NM = 572.0


def reflectance_from_rgb(colour: Colour, step: float = 5.0, start: float = 380.0, end: float = 780.0) -> Spectrum:
    """
    Build a synthetic, piecewise-constant reflectance :class:`Spectrum`
    (values in 0..1) whose three bands equal ``colour``'s linear-light
    R, G, B. See module docstring for the method's real limitations.
    """
    r, g, b = colour.convert(ColourSpace.LINEAR_RGB).channels
    n = int(round((end - start) / step)) + 1
    wavelengths = tuple(start + i * step for i in range(n))
    values = tuple(
        b if wl < _BLUE_MAX_NM else (g if wl < _GREEN_MAX_NM else r)
        for wl in wavelengths
    )
    return Spectrum(wavelengths, values, label=f"synthetic 3-band reflectance from {colour.hex()}")
