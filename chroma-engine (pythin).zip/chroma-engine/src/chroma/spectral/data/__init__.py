"""Reference spectral datasets (CMF tables, ...) with documented provenance. See cie1931_2deg_5nm.py."""
