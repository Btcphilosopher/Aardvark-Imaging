"""
chroma.spectral.wavelength
=============================

Utilities for a single monochromatic wavelength, e.g. "what colour is
590nm light" -- as opposed to :mod:`chroma.spectral.spectrum`, which
handles full spectral power distributions.
"""

from __future__ import annotations

from chroma.core.colour import Colour
from chroma.core.constants import SPECTRAL_MAX_NM, SPECTRAL_MIN_NM
from chroma.core.exceptions import SpectralDataError
from chroma.core.illuminants import D65, WhitePoint
from chroma.core.spaces import ColourSpace
from chroma.spectral.data.cie1931_2deg_5nm import STEP_NM, WAVELENGTHS_NM, X_BAR, Y_BAR, Z_BAR


def _interp(table: tuple[float, ...], nm: float) -> float:
    if nm < WAVELENGTHS_NM[0] or nm > WAVELENGTHS_NM[-1]:
        return 0.0
    pos = (nm - WAVELENGTHS_NM[0]) / STEP_NM
    i = int(pos)
    if i >= len(table) - 1:
        return table[-1]
    frac = pos - i
    return table[i] * (1.0 - frac) + table[i + 1] * frac


def wavelength_to_xyz(nm: float) -> tuple[float, float, float]:
    """
    CIE XYZ tristimulus values of monochromatic light at ``nm``,
    normalised so that the integral of y-bar over the visible range is
    unity-scaled per the standard convention (NOT normalised to any
    particular luminance -- multiply by a radiance/power value for a
    physically scaled result).
    """
    if not (SPECTRAL_MIN_NM <= nm <= SPECTRAL_MAX_NM):
        raise SpectralDataError(
            f"{nm}nm is outside the tabulated visible range "
            f"[{SPECTRAL_MIN_NM}, {SPECTRAL_MAX_NM}]nm."
        )
    return (_interp(X_BAR, nm), _interp(Y_BAR, nm), _interp(Z_BAR, nm))


def wavelength_to_colour(nm: float, white: WhitePoint = D65, luminance: float = 1.0) -> Colour:
    """
    Approximate sRGB rendering of monochromatic light at ``nm``,
    scaled so Y = ``luminance``. Many pure spectral colours (especially
    saturated blue-violets and deep reds) are OUTSIDE the sRGB gamut;
    the returned colour is gamut-mapped (compress_chroma against
    sRGB) rather than silently clipped, and callers who need the
    un-mapped value should call :func:`wavelength_to_xyz` directly.
    """
    x, y, z = wavelength_to_xyz(nm)
    total_y = sum(Y_BAR) * STEP_NM
    scale = (luminance / total_y) if total_y else 0.0
    colour = Colour(ColourSpace.XYZ, (x * scale, y * scale, z * scale), white=white)
    from chroma.gamut.mapping import map_to_gamut

    return map_to_gamut(colour.convert("srgb"), "srgb", "compress_chroma")
