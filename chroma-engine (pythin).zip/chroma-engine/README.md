# CHROMA ENGINE

**A computational colour engine for Aardvark Imaging.**

Chroma Engine is not a colour picker. It treats colour as a point in a
multidimensional, mathematically explicit space, and gives you the tools to
move between spaces, generate families of related colours, search enormous
colour spaces, measure perceptual distance, map between gamuts, and analyse
the colour content of images — all in **pure Python**, with **zero runtime
dependencies**.

```python
from chroma import Colour

blue = Colour.hex("#2457A6")
print(blue.convert("oklch"))              # Colour(oklch: L=0.4671, C=0.1387, h=259.10)
print(blue.distance(Colour.named("navy"))) # CIEDE2000 by default

variations = blue.generate_variations(hue_step=15)
palette = blue.generate_palette(method="perceptual", size=12)
mapped = blue.map_to_gamut("display-p3")
```

## Why pure Python?

So the engine is understandable, portable, and embeddable anywhere Aardvark
Imaging needs it — a desktop app, a build script, a headless render farm —
without dragging in NumPy, OpenCV or Pillow as a hard requirement. Optional
acceleration adapters (`chroma[numpy]`, `chroma[pillow]`) are planned as thin
*additions*, never replacements, for the core maths — see
[`docs/PERFORMANCE.md`](docs/PERFORMANCE.md).

## Install

```bash
pip install -e .            # from a checkout of this repository
pip install -e ".[dev]"     # + pytest, for running the test suite
```

This installs the `chroma` package and a `chroma` command-line tool (see
`docs/API.md` and `chroma --help`).

## What's in here

| Area | What it does |
|---|---|
| `chroma.core` | The immutable `Colour` object, white points, colour-space metadata |
| `chroma.conversion` | The conversion graph: sRGB, linear RGB, Display P3, Rec.2020, XYZ, xyY, Lab, LCh, Luv, LChuv, OKLab, OKLCh, HSV, HSL, YIQ, CMY(K), grayscale — plus Bradford chromatic adaptation |
| `chroma.gamut` | In/out-of-gamut detection, maximum-chroma search, gamut mapping (clip / scale / compress-chroma / perceptual) |
| `chroma.variation` | Systematic colour families: hue/lightness/chroma/saturation sweeps, tints/shades/tones, perceptual "temperature", multidimensional grids |
| `chroma.harmony` | Complementary, analogous, triadic, tetradic, split-complementary, monochromatic, custom angular |
| `chroma.distance` | CIE76/94/2000, OKLab Euclidean, RGB Euclidean, nearest-colour search, N×N distance matrices |
| `chroma.interpolation` / `chroma.gradient` | Hue-aware interpolation, multi-stop gradients with easing, linear/radial/angular sampling |
| `chroma.contrast` | WCAG relative luminance and contrast ratio |
| `chroma.palette` | Named, role-tagged palettes; seven generation methods |
| `chroma.catalogue` | A searchable colour database, a colour-naming engine, and lazy enumeration/search of the full 16.7M-colour RGB8 space |
| `chroma.spectral` | Spectral power distributions, CIE-CMF-based XYZ conversion, correlated colour temperature (McCamy), a naive RGB→reflectance reconstruction |
| `chroma.material` | Pluggable CMYK separation profiles, simplified transmission/reflectance/surface-gloss models |
| `chroma.image` | Pillow-free image colour analysis: histograms, statistics, dominant-colour extraction, over a small adapter interface |
| `chroma.algorithms` | Ordered & error-diffusion dithering, quantisation (uniform / median-cut / k-means), posterisation, blend modes, Porter-Duff alpha compositing |
| `chroma.render` | Pure-Python SVG rendering: swatches, strips, hue wheels, the RGB cube, gamut-boundary plots, simple charts |
| `chroma.io` | JSON / CSV / CSS / SVG export and import |

See [`docs/`](docs/) for the full picture, [`examples/`](examples/) for
runnable demonstrations (including the four flagship ones — the Aardvark
Blue colour family, the 16.7-million-colour search, the gamut explorer, and
the image colour lab), and [`tests/`](tests/) for the test suite (`pytest`).

## Engineering standard

- **No fake science.** RGB is not perceptually uniform. HSV is not
  perceptually uniform. Lab is only approximately perceptually uniform.
  OKLab is a numerical fit, not a physically exact model. CMYK is
  device/process-dependent. A colour name is not objective. A display gamut
  does not represent all human-visible colours. This engine says so, in the
  docstrings, rather than pretending otherwise.
- **Every conversion is explicit** about its source space, destination
  space, white point, transfer function and encoding — see
  `docs/CONVERSION_PIPELINE.md`.
- **Nothing is silently thrown away.** Gamut status, gamut-mapping deltas,
  and adaptation white points are all reported as data you can inspect, not
  hidden inside a clamp.

## License

MIT — see [`LICENSE`](LICENSE).
