# Integrating with Aardvark Imaging

## The integration surface

Aardvark Imaging should import from `chroma` (or `chroma.api.public`, which
is the same names) rather than reaching into submodules directly:

```python
from chroma import Colour

colour = Colour.hex("#2457A6")
colour_oklch = colour.convert("oklch")
variations = colour.generate_variations(hue_step=15, lightness_steps=20, chroma_steps=20)
palette = colour.generate_palette(method="perceptual", size=12)
nearest = colour.nearest(catalogue)   # works with a plain list, a Palette, or a Catalogue
```

Everything reachable from the top-level `chroma` package is the **stable**
API — internal modules can be reorganised between versions without notice,
but names re-exported from `chroma` only change with a version bump and a
changelog entry.

## Suggested panel → module mapping (project spec section 61)

| Aardvark panel | Backing module(s) |
|---|---|
| COLOUR VARIATIONS | `chroma.variation` |
| HARMONY | `chroma.harmony` |
| GAMUT | `chroma.gamut`, `chroma.render.gamut_map` |
| GRADIENT | `chroma.gradient`, `chroma.interpolation` |
| PALETTE | `chroma.palette` |
| HISTOGRAM | `chroma.image.histogram`, `chroma.render.chart` |
| SPECTRUM | `chroma.spectral` |
| COMPARE | `chroma.distance.comparison` |
| CATALOGUE | `chroma.catalogue` |
| CHROMA MATRIX (section 62) | `chroma.variation.grid.colour_grid` + `chroma.render.swatch.grid_svg` |

## Selecting one colour → generating its neighbourhood

The pattern every panel above needs at some point:

```python
from chroma import generate_variation_set

vs = generate_variation_set(colour)
vs.hue          # ColourSeries: hue sweep
vs.lightness    # ColourSeries: lightness sweep
vs.chroma       # ColourSeries: 0 -> real gamut boundary
vs.complement, vs.analogous, vs.triadic, vs.tetradic, vs.split_complementary, vs.monochromatic
```

## Image analysis without a hard Pillow dependency

Implement `chroma.image.source.ImageColourSource` (two properties, one
method) against Aardvark's real decoded-image buffer, and every function in
`chroma.image` — histograms, dominant-colour extraction, region sampling,
palette-from-image — works unmodified. `chroma.image.source.ListImageSource`
is the reference implementation to copy the shape of.

## Rendering

`chroma.render` produces plain SVG strings (swatches, strips, hue wheels,
gamut-boundary plots, the RGB cube, simple bar/line charts) with **no**
drawing-library dependency — safe to embed directly in a Qt/web/native UI
that can render SVG, or rasterise separately if Aardvark needs bitmaps.

## `.chroma` project files

`chroma.catalogue.serialization` reads/writes a small, versioned JSON
envelope that can carry a colour, a palette, and/or a catalogue in one file
— the native save format for an Aardvark colour-workspace document.

## What Aardvark still needs to add

- A real `CMYKProfile` backed by parsed ICC data (the interface is in
  `chroma.material.pigment`; only a naive and a simple GCR implementation
  ship here).
- A Pillow/NumPy `ImageColourSource` adapter for real image files.
- Optional NumPy/GPU acceleration adapters behind the same public API (see
  `PERFORMANCE.md`) — the core module never imports either.
