# The variation engine

Given one colour, generate systematic, **labelled** families of related
colours — the central feature of Chroma Engine.

Every generator returns a `ColourSeries` (label, space, colours, the
parameter value behind each one) rather than a bare list, because a family
of colours without a record of what varied, and in which space, isn't
reproducible.

```python
from chroma.variation.engine import hue_sweep, lightness_series, chroma_series, tints, shades, tones

hue_sweep(colour, step=15.0)                      # absolute hue sweep, OKLCh by default
lightness_series(colour, space="oklch", steps=20) # only spaces with an L/l channel
chroma_series(colour, steps=20, target="srgb")     # 0 up to the REAL gamut boundary (see GAMUT.md)
tints(colour, steps=10)                            # mix toward white, in OKLab
shades(colour, steps=10)                           # mix toward black, in OKLab
tones(colour, steps=10)                             # chroma -> 0 at fixed L, h
```

## Saturation is not one thing

`chroma.variation.engine.saturate(colour, amount, space)` explicitly takes a
`space` argument and adjusts whichever channel means "saturation" there (`s`
for HSV/HSL, `C` for LCh/OKLCh) — **HSV/HSL saturation and OKLCh chroma are
not the same operation**, and generating "the saturation series" separately
in each space (as `generate_variation_set` does) is how the engine avoids
quietly treating them as interchangeable.

## Perceptual warmth vs. physical colour temperature

`chroma.variation.engine.temperature_series` shifts hue between fixed warm
(~40°) and cool (~250°) OKLCh anchors — a **perceptual** warm/cool sweep.
This is a different thing from `chroma.spectral.colour_temperature`'s
McCamy-based correlated colour temperature in Kelvin, which is a **physical**
quantity computed from chromaticity. They live in different modules and
return different types on purpose.

## The full bundle

```python
from chroma.variation.engine import generate_variation_set
vs = generate_variation_set(colour, hue_step=15, lightness_steps=20, chroma_steps=20)
```
returns hue/lightness/chroma/saturation(HSV)/saturation(HSL)/tints/shades/
tones/temperature series plus the standard harmony set (complement,
analogous, triadic, tetradic, split-complementary, monochromatic) in one
call — the "Colour Variation Lab" flagship view.

## Multidimensional grids and volumes

```python
from chroma.variation.grid import colour_grid, cylindrical_volume

grid = colour_grid("hsl", h=(0, 330, 12), s=(0.3, 1.0, 10), l=(0.2, 0.8, 10))  # 1,200 colours
len(grid)     # 1200 -- computed, not materialised
list(grid)    # only NOW does it actually build 1,200 Colour objects

volume = cylindrical_volume("oklch", l_range=(0, 1), c_range=(0, 0.4), h_range=(0, 360))
for colour in volume.sample(l_steps=10, c_steps=10, h_steps=36):
    ...       # streamed, one Colour at a time
```

Both are lazy: iterating is a generator, so nothing is allocated until you
actually consume it (`list(...)`, a `for` loop, `itertools.islice`, ...).
