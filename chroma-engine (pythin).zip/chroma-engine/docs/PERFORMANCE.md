# Performance

Chroma Engine is pure Python by requirement (project spec section 2), so
"fast" here means "fast for pure Python": good algorithms and laziness, not
vectorisation.

## What's already lazy

- `chroma.catalogue.universe.enumerate_rgb8()` — a generator over all
  16,777,216 RGB8 colours; nothing is materialised unless you `list()` it or
  otherwise consume it fully.
- `chroma.variation.grid.ColourGrid` / `ColourVolume` — `len()` is computed
  from the axis sizes without iterating; actually building `Colour` objects
  only happens as you iterate.
- `chroma.gamut.strategies.max_chroma_at` — binary search, not a table scan
  or a fixed-resolution sample grid.

## Where pure Python is genuinely slow, and what to do about it

- **Full RGB8-universe scans** (`within_distance_rgb8` with no `limit`, or
  `nearest_in_rgb8(..., exhaustive=True)`) touch up to 16.7M `Colour`
  objects and perceptual-distance calls. Expect real wall-clock time (tens
  of seconds), not milliseconds. `nearest_in_rgb8`'s default
  (`exhaustive=False`) instead searches a bounded cube around the direct
  per-channel rounding of the target — exact for `rgb_euclidean`, and an
  extremely close approximation for the perceptual metrics (they're locally
  smooth, so the true global optimum is essentially always within a small
  neighbourhood of the naive rounding). Use `limit=` on `within_distance_rgb8`
  whenever you don't need every match.
- **k-means** (`chroma.algorithms.quantisation.kmeans_quantise`) is a plain
  Lloyd's-algorithm implementation with no spatial index — fine for palette
  sizes and image sample counts in the thousands, not for millions of
  points without downsampling first.
- **CIEDE2000** is the most expensive per-call metric (several trig calls
  per comparison). Prefer `oklab_euclidean` for large batch comparisons
  (nearest-neighbour search, dithering quantisers, ...) where a good
  perceptual proxy is enough, and reserve CIEDE2000 for final,
  small-N comparisons.

## Object creation

`Colour` is a frozen `slots=True` dataclass — cheap to construct, no
`__dict__` overhead. Still, avoid creating millions of `Colour` objects when
you only need scalars: e.g. `chroma.spectral.spectrum.Spectrum` and the
image-analysis functions in `chroma.image` work on plain floats/tuples
internally and only wrap a `Colour` at the boundary.

## Optional acceleration adapters (not yet implemented)

The `pyproject.toml` reserves `chroma[numpy]` and `chroma[pillow]` extras
for future adapters that:

- vectorise the conversion matrices over a NumPy array of pixels instead of
  looping in Python, and
- implement `chroma.image.source.ImageColourSource` against a real decoded
  Pillow image,

without changing the public `Colour`/`chroma.image` API. Nothing in
`chroma.core` or `chroma.conversion` may import either dependency — that
boundary is what keeps this possible without a breaking change later.
