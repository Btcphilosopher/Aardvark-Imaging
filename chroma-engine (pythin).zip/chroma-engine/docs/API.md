# API reference (high level)

Full detail lives in each module's own docstrings (every public function has
one); this is the map. See `docs/AARDVARK_INTEGRATION.md` for the "what
should I import" guidance.

## Constructing a `Colour`

```python
Colour.rgb(255, 0, 0)                       # 8-bit int RGB(A)
Colour.rgb_float(1.0, 0.0, 0.0)             # normalised float RGB(A)
Colour.hex("#FF0000")                       # #rgb / #rgba / #rrggbb / #rrggbbaa
Colour.named("cornflowerblue")              # CSS Color Level 4 keyword
Colour.from_space("oklch", L=0.62, C=0.25, h=30)   # any space, by keyword
Colour.from_css("rgba(255, 0, 0, 0.5)")     # rgb()/rgba()/hsl()/hsla()/#hex/name
Colour.from_dict(json.load(f))              # from the .to_dict() shape
```

## Formatting

```python
colour.hex(); colour.hex8()
colour.rgb8(); colour.rgba8(); colour.rgb_float()
colour.css(); colour.css_rgb(); colour.css_hsl()
colour.to_dict(); colour.json()
```
None of these round internally except the ones whose name says they do
(`hex`, `rgb8`, `rgba8`) — see `CONVERSION_PIPELINE.md`, "Precision".

## The most-used entry points, by task

| Task | Call |
|---|---|
| Convert space | `colour.convert("oklch")`, optionally `white="D50"` |
| Lighten/darken/rotate hue | `colour.lighten(0.1)`, `.darken(0.1)`, `.rotate_hue(30)` |
| Perceptual distance | `colour.distance(other, method="ciede2000")` |
| Mix two colours | `colour.mix(other, t=0.5, space="oklab")` |
| Gamut check / map | `colour.is_in_gamut("display-p3")`, `.map_to_gamut("srgb")` |
| Full variation set | `colour.generate_variations(...)` |
| Palette from a seed | `colour.generate_palette(method="perceptual", size=12)` |
| Nearest in a list/Palette/Catalogue | `colour.nearest(candidates)` |

## Command line

```bash
chroma inspect "#2457A6"
chroma convert "#2457A6" --space oklch
chroma variations "#2457A6" --hue-step 15 --steps 10
chroma harmony "#2457A6" --type triadic
chroma gradient "#FF0000" "#0000FF" --steps 10
chroma gamut "#2457A6" --target display-p3 --method compress_chroma
chroma distance "#FF0000" "#FE0101"
chroma palette "#2457A6" --size 12 --method perceptual
chroma catalogue search my_catalogue.json --chroma-gt 0.15
```

## Versioning

Names re-exported from the top-level `chroma` package (equivalently,
`chroma.api.public.__all__`) are the stable surface. `chroma.__version__` is
the current release. Anything reached only via a specific submodule path not
re-exported at the top level should be treated as more likely to move.
