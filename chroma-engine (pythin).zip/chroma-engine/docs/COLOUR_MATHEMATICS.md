# Colour mathematics

The core formulas Chroma Engine implements, in enough detail to check
against a reference yourself. Full derivations live in the cited sources;
this is the "what does the code actually compute" summary.

## sRGB transfer function (IEC 61966-2-1)

Encode (linear → gamma):
```
c_encoded = 12.92 * c_linear                              if c_linear <= 0.0031308
          = 1.055 * c_linear^(1/2.4) - 0.055               otherwise
```
Decode is the algebraic inverse, with its own breakpoint at `c_encoded = 0.04045`.

## RGB ↔ XYZ

A fixed 3×3 matrix per primary set (sRGB/Rec.709, Display P3, Rec.2020),
each derived for a D65 white point (see `chroma/core/constants.py` for the
exact matrices and their sources). Going from XYZ at a *different* white
point into RGB always routes through an explicit Bradford adaptation to D65
first — see `CONVERSION_PIPELINE.md`.

## CIE L\*a\*b\*

```
f(t) = t^(1/3)                          if t > (6/29)^3
     = t/(3*(6/29)^2) + 4/29            otherwise

L* = 116*f(Y/Yn) - 16
a* = 500*(f(X/Xn) - f(Y/Yn))
b* = 200*(f(Y/Yn) - f(Z/Zn))
```
`(Xn, Yn, Zn)` is the reference white's tristimulus. Source: CIE 15:2004
§8.2.1. The `216/24389` and `24389/27` constants (`CIE_EPSILON`,
`CIE_KAPPA`) are the CIE's own published rational values, not decimal
approximations.

## CIE L\*u\*v\*

Via the projective (u′, v′) chromaticity:
```
u' = 4X / (X + 15Y + 3Z)
v' = 9Y / (X + 15Y + 3Z)
```
then the same lightness curve as Lab, and
```
u* = 13*L* * (u' - un')
v* = 13*L* * (v' - vn')
```

## OKLab (Ottosson, 2020)

Linear sRGB → LMS-like values via a fixed 3×3 matrix, a per-channel cube
root, then another fixed 3×3 matrix into L, a, b. See
`chroma/core/constants.py` for the exact matrices (transcribed from
Ottosson's own published derivation). The cube root is signed
(`copysign(abs(x)**(1/3), x)`) so out-of-gamut/negative intermediate values
still round-trip.

## Bradford chromatic adaptation

```
cone = M_bradford @ XYZ
scale = cone_destination_white / cone_source_white     (per-component)
XYZ_adapted = M_bradford^-1 @ diag(scale) @ M_bradford @ XYZ_source
```
`M_bradford` is the standard "sharpened" cone-response matrix (Lam, 1985).
Von Kries and XYZ-scaling variants are also implemented, sharing the same
recipe with a different matrix — see `chroma/conversion/adaptation.py`.

## CIEDE2000

Implemented exactly per Sharma, Wu & Dalal (2005), "The CIEDE2000
Color-Difference Formula: Implementation Notes, Supplementary Test Data,
and Mathematical Observations" — the paper written specifically to resolve
ambiguities in the original CIE formula. See
`chroma/distance/metrics.py::delta_e_2000` for the full step-by-step
implementation with every intermediate quantity named after the paper's own
notation (`Cbar`, `G`, `h1p`, `h2p`, `T`, `RT`, ...).

## WCAG contrast

```
L = 0.2126*R_lin + 0.7152*G_lin + 0.0722*B_lin
contrast_ratio = (max(L1, L2) + 0.05) / (min(L1, L2) + 0.05)
```
using WCAG's own linearisation threshold (0.03928), kept deliberately
distinct from sRGB's own (0.04045) — see `chroma/contrast/wcag.py`.

## McCamy's CCT approximation

```
n = (x - 0.3320) / (0.1858 - y)
CCT = 449*n^3 + 3525*n^2 + 6823.3*n + 5520.33
```
Source: McCamy, C.S. (1992), *Color Research & Application*, 17(2),
142-144. A closed-form fit, valid near the Planckian locus — see
`chroma/spectral/colour_temperature.py`.
