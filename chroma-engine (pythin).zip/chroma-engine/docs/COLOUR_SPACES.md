# Colour spaces

Every space Chroma Engine represents a `Colour` in, what it means, and what
it does *not* mean.

## Device / encoded spaces

- **sRGB** (`srgb`) — gamma-encoded, 0..1 per channel, IEC 61966-2-1. This is
  the space of `#RRGGBB` hex strings and almost all 8-bit images.
- **Linear RGB** (`linear_rgb`) — the same sRGB primaries, but with the
  transfer function undone. The only correct space for physically
  meaningful blending, averaging, or lighting math. **Never** average or
  blend gamma-encoded values directly — a 50/50 mix of black and white in
  gamma space is *not* the same colour as a 50/50 mix in linear light (the
  gamma-space mix looks too dark).
- **Display P3** / **Rec.2020** — wider-gamut RGB spaces, each with their
  own primaries and (for Rec.2020) their own transfer function. Also have
  linear counterparts (`linear_display_p3`, `linear_rec2020`).
- **HSV**, **HSL** — derived directly from *gamma-encoded* sRGB by a
  geometric (not perceptual) transform. Useful for UI colour pickers and
  classic colour-wheel operations. **Not perceptually uniform** — equal
  steps in H, S or V do not look like equal perceptual steps.
- **YIQ** — the classic NTSC composite-video space. Historical/compatibility
  use only.
- **CMY** / **CMYK** — a naive subtractive complement and a generic
  K-extraction. **Not a print model.** Real print work needs a real ICC
  profile or at least a calibrated `CMYKProfile` (see `chroma.material`).
- **Grayscale** — single-channel luminance (Rec.709 luma weights on
  *linear* RGB). Converting a colour to grayscale and back does **not**
  reproduce the original — this is a documented, intentional lossy
  conversion (see `tests/test_conversion/test_round_trips.py`).

## White-point-carrying (device-independent) spaces

These are only meaningful *relative to a stated reference white*. Chroma
Engine always tracks a `Colour`'s white point explicitly (`colour.white`).

- **XYZ** — the CIE 1931 hub of the whole conversion graph.
- **xyY** — chromaticity (x, y) plus luminance Y; a re-parameterisation of
  XYZ, same white.
- **Lab** / **LCh** — CIE 1976 L\*a\*b\* and its polar form. Only
  *approximately* perceptually uniform — see `PERCEPTUAL_DISTANCE.md`.
- **Luv** / **LChuv** — CIE 1976 L\*u\*v\* and its polar form. Additive
  mixtures of lights are straight lines in this space (unlike Lab), which
  is useful for some lighting/display work.

## OKLab family

- **OKLab** / **OKLCh** — Björn Ottosson's 2020 perceptual space, fixed to
  D65 in this engine (it is defined directly on linear sRGB, not on
  arbitrary-white XYZ). Much better perceptual uniformity than Lab in
  practice, and the engine's default working space for variation,
  interpolation and gamut search — but it is a **numerical fit** to
  perceptual data, not a first-principles physical model. Do not describe
  it as "physically exact".

## What none of these claim

No space here is claimed to be perceptually uniform in an absolute sense, to
represent every humanly visible colour, or to be device-independent in a way
that bypasses the need for a stated white point and gamut. See the top-level
README's "Engineering standard" section.
