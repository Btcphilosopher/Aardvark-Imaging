# The conversion pipeline

## The graph

Instead of one function per pair of spaces, Chroma Engine declares a small
set of genuinely *direct* edges and finds a path through them:

```
SRGB <-> LINEAR_RGB <-> XYZ <-> OKLAB <-> OKLCH
                          |  \
                        LAB  XYY
                          |
                         LCH
```

(`chroma.conversion.graph.explain_path(source, dest)` prints the exact path
for any pair — this is never hidden.) `colour.convert("oklch")` runs a
breadth-first search over this graph and applies each edge's forward
function in turn.

## White points are explicit, not implicit

XYZ, xyY, Lab, LCh, Luv and LChuv are only meaningful relative to a stated
reference white. Device spaces (sRGB, Display P3, Rec.2020, HSV, HSL, YIQ,
CMY(K), grayscale) and the OKLab family are always treated as D65-referenced
in this engine — that matches how sRGB/P3/Rec.2020 and OKLab are actually
defined.

The conversion algorithm (`chroma.conversion.graph.convert`):

1. Work out the *source's* natural white (its own `.white` if the source
   space carries one, otherwise D65).
2. Work out the *target* white: an explicit `dest_white` argument if given;
   otherwise the source's white if the destination carries a white point
   (i.e. "preserve it by default"); otherwise D65 (device destinations are
   always D65).
3. If those two differ, route explicitly through XYZ: convert to XYZ at the
   source white, apply one Bradford adaptation step to the target white,
   then continue from XYZ to the destination. If they're the same, walk the
   graph directly with no adaptation.

This is correct for this specific graph topology because XYZ is the unique
articulation point between the "device, fixed-D65" side of the graph and the
"explicit white point" side — every path that needs to change white passes
through XYZ exactly once, so one adaptation step there is always enough.

```python
colour.convert("lab")                 # Lab @ colour's own white (D65 for an sRGB source)
colour.convert("lab", white="D50")    # explicit Bradford adaptation to D50 along the way
colour.convert("lab").convert("srgb") # adapts back to D65 automatically if needed
```

## Precision

Conversions never round or clamp internally — every channel stays a full
Python `float` until you call an explicit formatting method (`.hex()`,
`.rgb8()`, ...). `Colour` objects are immutable; every operation returns a
new one.

## Extending the graph

Add a new space: give it an entry in `chroma.core.spaces.ColourSpace` and
`_METADATA`, then add whichever direct edges make mathematical sense to
`chroma.conversion.graph._STEPS` (as a pair of pure functions in
`chroma.conversion.functions`). You do **not** need to add an edge to every
other space — the graph search finds a path through whatever you connect it
to.
