# Perceptual distance

"Nearest colour" depends on which metric you ask — this is demonstrated,
not hidden (see `examples/colour_universe.py`, Demonstration 2).

## The metrics

| Metric | Space | Notes |
|---|---|---|
| `rgb_euclidean` | gamma-encoded sRGB | Fast, device-space, **not** perceptual. |
| `cie76` | Lab | Plain Euclidean distance in L\*a\*b\*. Simple, but known to weight some hue/chroma regions inconsistently with perception. |
| `cie94` | Lab | Adds chroma/hue-dependent weighting (CIE TC 1-29, 1995). **Intentionally asymmetric**: the weighting functions depend on the *reference* sample's chroma specifically, so `cie94(a, b) != cie94(b, a)` in general — this is documented CIE94 behaviour, and `tests/test_distance/test_metrics.py::test_cie94_is_intentionally_asymmetric` exists precisely so a future change doesn't accidentally symmetrise it. |
| `ciede2000` | Lab | The current best-practice CIE formula (Sharma, Wu & Dalal, 2005 reference implementation). Symmetric. The engine's default. |
| `oklab_euclidean` | OKLab | Cheap, and in practice a good perceptual proxy — OKLab was fit specifically so Euclidean distance in it behaves reasonably. |

## Why Lab-based metrics aren't "the truth"

CIELAB is only *approximately* perceptually uniform — equal Euclidean
distances in Lab do not correspond to exactly equal perceived differences
across the whole space, which is precisely why CIE94 and CIEDE2000 exist
(as increasingly complex corrections), and why OKLab exists as a different,
more modern fit to perceptual data. None of these is claimed to be
perceptually exact anywhere in this codebase.

## Nearest-colour search and comparison

```python
from chroma.distance.nearest import nearest, k_nearest
from chroma.distance.comparison import compare

match = nearest(target, catalogue_colours, method="ciede2000")
top5 = k_nearest(target, catalogue_colours, k=5)
report = compare(a, b)   # every metric + hue/lightness/chroma deltas + gamut agreement, in one call
```

`chroma.distance.metrics.distance_matrix(colours, method)` builds the full
N×N comparison matrix for a set of colours (only the upper triangle is
computed; every implemented metric is symmetric except CIE94, and the
matrix mirrors accordingly for the symmetric ones).

## The 16.7-million-colour case

`chroma.catalogue.universe.nearest_in_rgb8` demonstrates the point directly:
searching for the nearest *displayable 8-bit* colour to an arbitrary target
under `rgb_euclidean` vs. `ciede2000` vs. `oklab_euclidean` can legitimately
return different answers — see `examples/colour_universe.py`.
