# Gamut

A colour is only "in gamut" **relative to a specific target device gamut**
— sRGB, Display P3, and Rec.2020 are all implemented, each is a real,
different set of primaries, and none of them represents "all colours
displays can show" in general, let alone all colours humans can see.

## Detection

`chroma.gamut.detection.is_in_gamut(colour, target)` converts to the
target's encoded RGB and checks every channel lands in `[0, 1]` (within a
floating-point tolerance, not a perceptual one). `gamut_report` gives the
full diagnostic: which channels are out, and by how much.

## Maximum-chroma search

The engine's signature query — *"give me the most saturated displayable
colour at this lightness and hue"* — is answered by real binary search, not
a table or a guess:

```python
from chroma.gamut.strategies import max_chroma_at
max_chroma_at(lightness=0.6, hue=30.0, target="srgb")  # -> a real boundary chroma
```

The search expands an upper bound until it's provably out of gamut, then
bisects. It typically converges to `1e-5` chroma units in under 20
iterations. `max_chroma_series` sweeps this across a lightness range to
trace the full gamut-boundary "tongue" shape for one hue (see
`chroma.render.gamut_map` for a plot of exactly that).

**A documented quirk**: OKLab's `L=0` (or `L=1`) plane does not perfectly
coincide with the sRGB cube's black (white) corner at every hue, so
`max_chroma_at(0.0, hue, "srgb")` is small but not always *exactly* zero.
This is a real property of OKLab's construction, not a search bug — see
`tests/test_gamut/test_gamut.py::test_max_chroma_shrinks_towards_the_extremes`.

## Mapping strategies

```python
colour.map_to_gamut("srgb", method="compress_chroma")
```

| Method | What it does |
|---|---|
| `clip` | Naive per-channel clamp in the destination RGB. Fast, can visibly shift hue. |
| `scale` | Uniformly scale **linear-light** RGB so the highest channel lands at 1.0 — never applied to gamma-encoded values (see `COLOUR_SPACES.md` on why that would be physically meaningless). |
| `compress_chroma` | Hold OKLCh L and h fixed, reduce C to the real gamut boundary found by the search above. |
| `preserve_lightness` | Currently an alias of `compress_chroma` — holding L (and h) fixed while reducing C *is* what preserving lightness means in this implementation. Kept as a separate name because a more sophisticated future version (permitting small, perceptually-bounded lightness shifts near the gamut cusp, as CSS Color 4's algorithm does) would meaningfully split them. |
| `perceptual_compress` | A simplified relative of the CSS Color 4 gamut-mapping algorithm: the same chroma search, backed off slightly short of the boundary plus a small final clip. Not a certified CSS4 implementation — see the function's own docstring for exactly what's simplified. |

Every mapping call can also return a `GamutMappingResult` with the OKLab
distance between the original and mapped colour, so "how much did this
cost perceptually" is always visible (`map_to_gamut_report`).

## Aggregate coverage

`chroma.analysis.gamut.gamut_coverage(colours, target)` reports what
fraction of a palette/catalogue is actually displayable, plus the specific
out-of-gamut members — built directly on the same per-colour check, so it
can only ever report what that check reports.
