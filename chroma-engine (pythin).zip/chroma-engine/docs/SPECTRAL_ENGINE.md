# The spectral subsystem

Explicitly experimental, per the project brief — and explicit about which
parts are **REFERENCE**, **USER-SUPPLIED**, or **SYNTHETIC** data at every
point, per the project's "no fake science" standard.

## `Spectrum`

A sampled spectral distribution: parallel `wavelengths` (nm) and `values`
(whatever unit you mean — radiance, reflectance 0..1, transmittance 0..1;
the class doesn't enforce one). Supports linear interpolation (`.at(nm)`),
resampling onto a new grid, normalisation, trapezoidal integration, RMS
comparison between two spectra, and conversion to XYZ.

```python
from chroma.spectral.spectrum import Spectrum

flat = Spectrum.flat(1.0)             # the equal-energy illuminant
x, y, z = flat.to_xyz()               # integrates against the bundled CMF table
```

## Where the CMF table comes from — REFERENCE data

`chroma/spectral/data/cie1931_2deg_5nm.py` is the CIE 1931 2-degree standard
observer, 380–780nm at 5nm intervals, transcribed from Judd & Wyszecki
(1975), *Color in Business, Science and Industry*, Table 2.6, via the
public-domain BRL-CAD ray tracer's spectral module. Full citation is in that
file's own docstring. It is **not** invented, and `tests/test_spectral/`
checks it against a definitional fact (a flat spectrum integrates to exactly
the equal-energy chromaticity) rather than hand-copied numbers — see
`tests/reference/README.md` for why.

If your work needs the CIE's current officially published dataset or finer
wavelength resolution, that file documents exactly how to swap it out.

## Correlated colour temperature — a real, cited formula

```python
from chroma.spectral.colour_temperature import cct_from_colour
cct_from_colour(some_white_ish_colour)   # Kelvin, via McCamy's (1992) approximation
```

This is a **physical** quantity computed from chromaticity, is only
meaningful near the Planckian locus, and raises
`NotNearPlanckianLocusError` rather than returning a confident-looking wrong
number for chromaticities far from it. It is unrelated to
`chroma.variation.engine.temperature_series`'s perceptual warm/cool sweep —
see `VARIATION_ENGINE.md`.

## Reflectance reconstruction — explicitly SYNTHETIC data

Going from RGB to a plausible reflectance spectrum is fundamentally
under-determined (infinitely many spectra — "metamers" — produce the same
RGB under a given illuminant).
`chroma.spectral.reconstruction.reflectance_from_rgb` implements the
simplest defensible method (a piecewise-constant three-band curve, the same
approach early spectral ray tracers used for this exact purpose) and its
own docstring says plainly that production work wanting smoother, more
physically plausible metamers should implement Smits (1999) or a
Meng et al. (2015) sigmoid-basis reconstruction instead. Nothing produced by
this function is claimed to be a measurement.

## Material models built on top

`chroma.material.transmission` (Beer-Lambert-style filter stacking) and
`chroma.material.reflectance` (rendering a reflectance spectrum under a
given illuminant) are thin, explicit compositions of `Spectrum` — see
`docs/AARDVARK_INTEGRATION.md` for how these fit into a larger imaging
pipeline.
