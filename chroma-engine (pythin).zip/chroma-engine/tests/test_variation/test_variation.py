"""tests/test_variation/test_variation.py"""

from __future__ import annotations

import pytest

from chroma.core.colour import Colour
from chroma.variation.engine import (
    chroma_series,
    darken,
    generate_variation_set,
    hue_sweep,
    lighten,
    lightness_series,
    rotate_hue,
    shades,
    tints,
    tones,
)
from chroma.variation.grid import axis_range, colour_grid, cylindrical_volume


def test_lighten_darken_are_inverses_within_range() -> None:
    c = Colour.hex("#2457A6")
    lighter = lighten(c, 0.1)
    back = darken(lighter, 0.1)
    assert back.approx_equal(c, tolerance=1e-6)


def test_lighten_clamps_at_white() -> None:
    c = Colour.named("white")
    assert lighten(c, 0.5).approx_equal(c, tolerance=1e-3)


def test_rotate_hue_360_is_identity() -> None:
    c = Colour.hex("#2457A6")
    assert rotate_hue(c, 360.0).approx_equal(c, tolerance=1e-6)


def test_hue_sweep_covers_full_circle() -> None:
    c = Colour.hex("#2457A6")
    series = hue_sweep(c, step=90.0)
    assert len(series) == 4


def test_lightness_series_is_monotonic_in_lightness() -> None:
    c = Colour.hex("#2457A6")
    series = lightness_series(c, space="oklch", steps=10)
    lightness_values = [x.convert("oklch").channel("L") for x in series]
    assert lightness_values == sorted(lightness_values)


def test_chroma_series_starts_at_grey_and_ends_at_boundary() -> None:
    c = Colour.hex("#2457A6")
    series = chroma_series(c, steps=5)
    first = series.colours[0].convert("oklch")
    assert first.channel("C") == pytest.approx(0.0, abs=1e-6)


def test_tints_end_at_white_and_shades_end_at_black() -> None:
    c = Colour.hex("#2457A6")
    assert tints(c, steps=5).colours[-1].approx_equal(Colour.named("white"), tolerance=1e-4)
    assert shades(c, steps=5).colours[-1].approx_equal(Colour.named("black"), tolerance=1e-4)


def test_tones_reduce_chroma_to_zero() -> None:
    c = Colour.hex("#2457A6")
    last = tones(c, steps=5).colours[-1]
    assert last.convert("oklch").channel("C") == pytest.approx(0.0, abs=1e-6)


def test_generate_variation_set_bundles_everything() -> None:
    c = Colour.hex("#2457A6")
    vs = generate_variation_set(c, hue_step=90, lightness_steps=3, chroma_steps=3, saturation_steps=3, tint_shade_tone_steps=3, temperature_steps=3)
    assert vs.base is c
    assert len(vs.hue) == 4
    assert len(vs.triadic) == 3
    assert len(vs.tetradic) == 4


def test_colour_grid_length_and_iteration() -> None:
    grid = colour_grid("hsl", h=(0, 330, 12), s=(0.3, 1.0, 2), l=(0.3, 0.7, 2))
    assert len(grid) == 12 * 2 * 2
    materialised = list(grid)
    assert len(materialised) == len(grid)
    assert all(isinstance(c, Colour) for c in materialised)


def test_cylindrical_volume_sample_count() -> None:
    volume = cylindrical_volume("oklch", l_range=(0.2, 0.8), c_range=(0.0, 0.2), h_range=(0.0, 360.0))
    samples = list(volume.sample(l_steps=3, c_steps=3, h_steps=4))
    assert len(samples) == 3 * 3 * 4
