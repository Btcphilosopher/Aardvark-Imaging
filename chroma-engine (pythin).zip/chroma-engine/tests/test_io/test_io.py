"""tests/test_io/test_io.py"""

from __future__ import annotations

import os
import tempfile

import pytest

from chroma.core.colour import Colour
from chroma.io.css import export_css_gradient, export_css_variables
from chroma.io.csv import export_palette_csv, import_palette_csv
from chroma.io.json import export_json, import_colour_json
from chroma.io.svg import export_palette_svg
from chroma.palette.palette import Palette, PaletteEntry, Role


def test_json_round_trip_colour() -> None:
    c = Colour.hex("#2457A6")
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "c.json")
        export_json(c, path)
        restored = import_colour_json(path)
        assert restored.approx_equal(c, tolerance=1e-9)


def test_csv_round_trip_palette() -> None:
    palette = Palette((
        PaletteEntry(Colour.named("red"), name="Red", role=Role.PRIMARY),
        PaletteEntry(Colour.named("blue"), name="Blue", role=Role.SECONDARY),
    ))
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "p.csv")
        export_palette_csv(palette, path)
        restored = import_palette_csv(path)
        assert len(restored) == 2
        assert restored.entries[0].colour.approx_equal(Colour.named("red"))
        assert restored.entries[0].role == Role.PRIMARY


def test_css_variables_contain_every_entry() -> None:
    palette = Palette.from_colours([Colour.named("red"), Colour.named("blue")], name="test")
    css = export_css_variables(palette)
    assert css.count("--chroma-") == 2
    assert "#ff0000" in css
    assert "#0000ff" in css


def test_css_gradient_string() -> None:
    gradient = export_css_gradient([Colour.named("red"), Colour.named("blue")], angle_degrees=45.0)
    assert gradient.startswith("linear-gradient(45deg,")
    assert "#ff0000" in gradient


def test_svg_export_writes_a_file_with_every_swatch() -> None:
    palette = Palette.from_colours([Colour.named("red"), Colour.named("green"), Colour.named("blue")])
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "p.svg")
        export_palette_svg(palette, path)
        assert os.path.exists(path)
        content = open(path).read()
        assert content.count("<rect") >= 3
