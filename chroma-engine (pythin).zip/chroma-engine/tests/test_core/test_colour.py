"""tests/test_core/test_colour.py"""

from __future__ import annotations

import pytest

from chroma.core.colour import Colour
from chroma.core.exceptions import InvalidChannelError


def test_colour_is_immutable() -> None:
    c = Colour.hex("#2457A6")
    lighter = c.lighten(0.1)
    assert c.hex() == "#2457a6"          # original untouched
    assert lighter.hex() != c.hex()       # a genuinely new object came back


def test_rgb_int_and_float_constructors_agree() -> None:
    from_int = Colour.rgb(36, 87, 166)
    from_float = Colour.rgb_float(36 / 255, 87 / 255, 166 / 255)
    assert from_int.approx_equal(from_float, tolerance=1e-6)


def test_hex_dual_purpose_spelling() -> None:
    """Colour.hex(...) constructs; colour.hex() formats -- see _DualDescriptor."""
    c = Colour.hex("#2457A6")
    assert isinstance(c, Colour)
    assert c.hex() == "#2457a6"


def test_rgb_float_dual_purpose_spelling() -> None:
    c = Colour.rgb_float(0.5, 0.25, 0.75)
    assert isinstance(c, Colour)
    r, g, b = c.rgb_float()
    assert (r, g, b) == pytest.approx((0.5, 0.25, 0.75), abs=1e-9)


def test_from_space_constructor() -> None:
    c = Colour.from_space("oklch", L=0.62, C=0.25, h=30.0)
    assert c.space.value == "oklch"
    assert c.channels == pytest.approx((0.62, 0.25, 30.0))


def test_invalid_channel_arity_raises() -> None:
    with pytest.raises(InvalidChannelError):
        Colour(Colour.hex("#fff").space, (1.0, 2.0))  # srgb needs 3 channels


def test_invalid_hex_raises() -> None:
    with pytest.raises(InvalidChannelError):
        Colour.hex("not-a-colour")


def test_from_css_variants() -> None:
    assert Colour.from_css("#ff0000").hex() == "#ff0000"
    assert Colour.from_css("rgb(255, 0, 0)").hex() == "#ff0000"
    assert Colour.from_css("rgba(255, 0, 0, 0.5)").alpha == pytest.approx(0.5, abs=1e-6)
    assert Colour.from_css("red").hex() == "#ff0000"


def test_to_dict_from_dict_round_trip() -> None:
    c = Colour.hex("#2457A6")
    restored = Colour.from_dict(c.to_dict())
    assert restored.approx_equal(c, tolerance=1e-9)
    assert restored.space == c.space


def test_json_round_trip() -> None:
    import json

    c = Colour.hex("#2457A6")
    restored = Colour.from_dict(json.loads(c.json()))
    assert restored.approx_equal(c, tolerance=1e-9)


def test_css_output_formats() -> None:
    c = Colour.rgb(36, 87, 166)
    assert c.css_rgb() == "rgb(36, 87, 166)"
    translucent = Colour.rgb(36, 87, 166, a=128)
    assert translucent.css_rgb().startswith("rgba(")


def test_channel_accessor() -> None:
    c = Colour.from_space("oklch", L=0.5, C=0.1, h=90.0)
    assert c.channel("h") == pytest.approx(90.0)
    with pytest.raises(InvalidChannelError):
        c.channel("nonexistent")
