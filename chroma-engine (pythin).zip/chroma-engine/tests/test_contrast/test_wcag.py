"""tests/test_contrast/test_wcag.py"""

from __future__ import annotations

import pytest

from chroma.contrast.wcag import best_text_colour, contrast_ratio, evaluate_contrast, relative_luminance
from chroma.core.colour import Colour


def test_black_on_white_contrast_is_exactly_21_to_1() -> None:
    """
    SOURCE: definitional -- WCAG contrast ratio is (L1+0.05)/(L2+0.05);
    for black (L=0) and white (L=1) this is exactly (1+0.05)/(0+0.05) = 21.0.
    EXPECTED: 21.0 exactly (up to floating point).
    """
    ratio = contrast_ratio(Colour.named("black"), Colour.named("white"))
    assert ratio == pytest.approx(21.0, abs=1e-9)


def test_contrast_ratio_is_symmetric() -> None:
    a, b = Colour.hex("#2457A6"), Colour.named("white")
    assert contrast_ratio(a, b) == pytest.approx(contrast_ratio(b, a), abs=1e-9)


def test_contrast_ratio_with_self_is_1() -> None:
    c = Colour.hex("#2457A6")
    assert contrast_ratio(c, c) == pytest.approx(1.0, abs=1e-9)


def test_relative_luminance_of_white_is_1_and_black_is_0() -> None:
    assert relative_luminance(Colour.named("white")) == pytest.approx(1.0, abs=1e-9)
    assert relative_luminance(Colour.named("black")) == pytest.approx(0.0, abs=1e-9)


def test_evaluate_contrast_pass_fail_thresholds() -> None:
    report = evaluate_contrast(Colour.named("black"), Colour.named("white"))
    assert report.passes_aa
    assert report.passes_aaa
    low_contrast = evaluate_contrast(Colour.rgb(120, 120, 120), Colour.rgb(140, 140, 140))
    assert not low_contrast.passes_aa


def test_best_text_colour_picks_higher_contrast_option() -> None:
    assert best_text_colour(Colour.named("black")).hex() == "#ffffff"
    assert best_text_colour(Colour.named("white")).hex() == "#000000"
