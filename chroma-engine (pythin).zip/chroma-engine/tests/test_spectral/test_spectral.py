"""tests/test_spectral/test_spectral.py"""

from __future__ import annotations

import pytest

from chroma.core.colour import Colour
from chroma.core.illuminants import D50, D65, get_white_point
from chroma.spectral.colour_temperature import cct_from_xy
from chroma.spectral.spectrum import Spectrum


def test_flat_spectrum_integrates_to_equal_energy_chromaticity() -> None:
    """
    SOURCE: definitional -- Illuminant E is BY DEFINITION the
    equal-energy illuminant with chromaticity x=y=1/3; integrating a
    flat (constant-value) spectrum against the CMF table must recover
    exactly that chromaticity, since that IS what "equal energy" means.
    EXPECTED: x = y = 1/3. TOLERANCE: 1e-3 (5nm-interval trapezoidal
    integration of a table digitised to 4 decimal places).
    """
    flat = Spectrum.flat(1.0)
    x, y, z = flat.to_xyz()
    total = x + y + z
    assert x / total == pytest.approx(1.0 / 3.0, abs=1e-3)
    assert y / total == pytest.approx(1.0 / 3.0, abs=1e-3)


def test_spectrum_at_interpolates_linearly() -> None:
    s = Spectrum((400.0, 500.0, 600.0), (0.0, 1.0, 0.0))
    assert s.at(450.0) == pytest.approx(0.5, abs=1e-9)
    assert s.at(400.0) == pytest.approx(0.0, abs=1e-9)
    assert s.at(500.0) == pytest.approx(1.0, abs=1e-9)


def test_spectrum_outside_range_is_zero() -> None:
    s = Spectrum((400.0, 500.0), (1.0, 1.0))
    assert s.at(300.0) == 0.0
    assert s.at(600.0) == 0.0


def test_spectrum_integrate_of_flat_unit_spectrum() -> None:
    s = Spectrum.flat(1.0, start=400.0, end=500.0, step=10.0)
    assert s.integrate() == pytest.approx(100.0, abs=1e-6)


@pytest.mark.parametrize("white_name,expected_kelvin", [("D65", 6504), ("D50", 5003), ("A", 2856)])
def test_cct_matches_standard_illuminant_labels(white_name: str, expected_kelvin: int) -> None:
    """
    SOURCE: the standard illuminants are conventionally NAMED after
    their approximate CCT (D65 ~ 6504K, D50 ~ 5003K, A ~ 2856K -- these
    names are how CIE/ISO documents refer to them). McCamy's
    approximation applied to each illuminant's own chromaticity should
    recover a number close to its name.
    TOLERANCE: 50K (McCamy's fit is an approximation, not exact inversion).
    """
    wp = get_white_point(white_name)
    x, y, z = wp.xyz
    total = x + y + z
    cct = cct_from_xy(x / total, y / total)
    assert cct == pytest.approx(expected_kelvin, abs=50)


def test_reflectance_from_rgb_round_trip_is_plausible() -> None:
    from chroma.spectral.reconstruction import reflectance_from_rgb

    colour = Colour.hex("#2457A6")
    spectrum = reflectance_from_rgb(colour)
    recovered = spectrum.to_colour(illuminant=Spectrum.flat(1.0)).convert("srgb")
    # Not an exact round trip (this is a synthetic/naive reconstruction,
    # documented as such) -- but should be in the right ballpark perceptually.
    assert recovered.distance(colour, method="oklab_euclidean") < 0.25
