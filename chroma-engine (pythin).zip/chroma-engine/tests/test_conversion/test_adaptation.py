"""tests/test_conversion/test_adaptation.py -- Bradford chromatic adaptation."""

from __future__ import annotations

import pytest

from chroma.conversion.adaptation import bradford_adapt
from chroma.core.colour import Colour
from chroma.core.illuminants import D50, D65, get_white_point
from chroma.core.spaces import ColourSpace


def test_adaptation_to_same_white_is_identity() -> None:
    xyz = (0.4, 0.3, 0.2)
    assert bradford_adapt(xyz, D65, D65) == xyz


def test_adaptation_round_trip() -> None:
    """D65 -> D50 -> D65 must return (very close to) the original XYZ."""
    xyz = (0.4124, 0.2127, 0.0193)  # sRGB red's linear XYZ
    to_d50 = bradford_adapt(xyz, D65, D50)
    back = bradford_adapt(to_d50, D50, D65)
    for a, b in zip(xyz, back):
        assert a == pytest.approx(b, abs=1e-6)


def test_lab_white_point_conversion_changes_white_but_not_appearance_much() -> None:
    """Converting a colour's Lab representation to a different white point should adapt, not just relabel."""
    colour = Colour.hex("#2457A6")
    lab_d65 = colour.convert("lab", white="D65")
    lab_d50 = colour.convert("lab", white="D50")
    assert lab_d65.white.name == "D65"
    assert lab_d50.white.name == "D50"
    # They should differ (adaptation actually happened)...
    assert lab_d65.channels != lab_d50.channels
    # ...but represent very close to the same underlying sRGB colour
    # when converted back (adaptation should round-trip through sRGB
    # to within gamut-mapping-free tolerance).
    back_from_d65 = lab_d65.convert("srgb")
    back_from_d50 = lab_d50.convert("srgb")
    for a, b in zip(back_from_d65.channels, back_from_d50.channels):
        assert a == pytest.approx(b, abs=1e-6)


def test_device_space_conversion_from_non_d65_lab_adapts_automatically() -> None:
    """Converting Lab@D50 directly to sRGB (which is D65-referenced) must implicitly Bradford-adapt, not silently misinterpret D50 numbers as D65."""
    colour = Colour.hex("#2457A6")
    lab_d50 = colour.convert("lab", white="D50")
    back = lab_d50.convert("srgb")
    for a, b in zip(colour.channels, back.channels):
        assert a == pytest.approx(b, abs=1e-6)
