"""
tests/test_conversion/test_reference_values.py
==================================================

Tests against values that are exact or near-exact BY DEFINITION or by
extremely well-established convention, rather than transcribed from a
specific external table (see tests/reference/README.md for the full
policy on why this suite favours self-consistent/definitional
reference points over hand-copied numbers).
"""

from __future__ import annotations

import pytest

from chroma.core.colour import Colour
from chroma.core.illuminants import D50, D65
from chroma.core.spaces import ColourSpace


def test_d65_white_is_lab_100_0_0() -> None:
    """
    SOURCE: definitional (CIE 15:2004) -- a patch whose XYZ exactly
    equals the reference white's XYZ must convert to L*=100, a*=0,
    b*=0 for that same reference white, by the defining equations of
    CIELAB (f(1) = 1 for every channel).
    EXPECTED: (100.0, 0.0, 0.0)
    TOLERANCE: 1e-6 (pure arithmetic, no iterative solving involved)
    """
    white_xyz = Colour(ColourSpace.XYZ, D65.xyz, white=D65)
    lab = white_xyz.convert("lab")
    assert lab.channels[0] == pytest.approx(100.0, abs=1e-6)
    assert lab.channels[1] == pytest.approx(0.0, abs=1e-6)
    assert lab.channels[2] == pytest.approx(0.0, abs=1e-6)


def test_d50_white_is_lab_100_0_0_under_d50() -> None:
    white_xyz = Colour(ColourSpace.XYZ, D50.xyz, white=D50)
    lab = white_xyz.convert("lab")
    assert lab.channels[0] == pytest.approx(100.0, abs=1e-6)
    assert lab.channels[1] == pytest.approx(0.0, abs=1e-6)
    assert lab.channels[2] == pytest.approx(0.0, abs=1e-6)


def test_srgb_black_and_white_are_luv_extremes() -> None:
    """Pure black is L*=0 in every CIE lightness-based space; pure white is L*=100 for its own white point."""
    black = Colour.hex("#000000")
    white = Colour.hex("#ffffff")
    assert black.convert("luv").channels[0] == pytest.approx(0.0, abs=1e-6)
    assert white.convert("luv").channels[0] == pytest.approx(100.0, abs=1e-4)


def test_named_colours_match_css4_hex() -> None:
    """SOURCE: W3C CSS Color Module Level 4 named-colour table (see chroma/core/_named_colours.py)."""
    assert Colour.named("red").hex() == "#ff0000"
    assert Colour.named("blue").hex() == "#0000ff"
    assert Colour.named("lime").hex() == "#00ff00"
    assert Colour.named("black").hex() == "#000000"
    assert Colour.named("white").hex() == "#ffffff"
    assert Colour.named("rebeccapurple").hex() == "#663399"


def test_hex_parsing_shorthand_and_alpha() -> None:
    assert Colour.hex("#fff").hex() == "#ffffff"
    assert Colour.hex("#f00").rgb8() == (255, 0, 0)
    assert Colour.hex("#ff000080").rgba8()[3] == pytest.approx(128, abs=1)


def test_oklab_grey_axis_has_near_zero_chroma() -> None:
    """SOURCE: definitional property of OKLab -- any R=G=B grey has a=b=0 exactly up to floating-point rounding through the matrix/cube-root/matrix pipeline (tolerance reflects that pipeline, not a physical uncertainty)."""
    for level in (0, 64, 128, 192, 255):
        grey = Colour.rgb(level, level, level)
        _l, a, b = grey.convert("oklab").channels
        assert a == pytest.approx(0.0, abs=1e-6)
        assert b == pytest.approx(0.0, abs=1e-6)
