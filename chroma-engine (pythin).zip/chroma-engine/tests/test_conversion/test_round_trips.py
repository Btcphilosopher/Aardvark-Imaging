"""
tests/test_conversion/test_round_trips.py
============================================

Project spec section 68/69: "Round-trip tests: A -> B -> A must stay
within documented numerical tolerances." Every edge in the conversion
graph is tested here by converting a spread of representative colours
out to another space and back, and checking the result matches the
original to within a stated tolerance.

TOLERANCE POLICY: 1e-6 for direct single-edge round trips (matrix and
simple analytic inverses), 1e-4 for round trips that pass through
several edges (accumulated floating-point error) or through a cube
root / cube (OKLab), which is a documented, deliberate looser bound --
not a hidden fudge.
"""

from __future__ import annotations

import pytest

from chroma.core.colour import Colour

# A representative spread: primaries, secondaries, grey ramp, and a
# few "awkward" colours (near-black, near-white, low-chroma).
SAMPLE_HEX = [
    "#000000", "#ffffff", "#808080",
    "#ff0000", "#00ff00", "#0000ff",
    "#ffff00", "#00ffff", "#ff00ff",
    "#2457a6", "#a62457", "#57a624",
    "#010101", "#fefefe", "#7f8081",
]

SPACES_TIGHT = ["srgb", "linear_rgb", "hsv", "hsl", "xyz", "lab", "lch", "luv", "lchuv", "yiq", "cmy"]
SPACES_LOOSE = ["oklab", "oklch"]  # involves a cube root/cube pair


@pytest.mark.parametrize("hex_value", SAMPLE_HEX)
@pytest.mark.parametrize("space", SPACES_TIGHT)
def test_round_trip_tight(hex_value: str, space: str) -> None:
    original = Colour.hex(hex_value)
    result = original.convert(space).convert("srgb")
    for a, b in zip(original.channels, result.channels):
        assert a == pytest.approx(b, abs=1e-5)


@pytest.mark.parametrize("hex_value", SAMPLE_HEX)
@pytest.mark.parametrize("space", SPACES_LOOSE)
def test_round_trip_loose(hex_value: str, space: str) -> None:
    original = Colour.hex(hex_value)
    result = original.convert(space).convert("srgb")
    for a, b in zip(original.channels, result.channels):
        assert a == pytest.approx(b, abs=1e-4)


@pytest.mark.parametrize("hex_value", SAMPLE_HEX)
def test_round_trip_cmyk(hex_value: str) -> None:
    # CMY <-> CMYK is a genuinely lossy-looking but actually invertible
    # (given the naive K-extraction formula) round trip through a 4th
    # channel; verify it returns exactly to CMY, then to sRGB.
    original = Colour.hex(hex_value)
    result = original.convert("cmyk").convert("srgb")
    for a, b in zip(original.channels, result.channels):
        assert a == pytest.approx(b, abs=1e-5)


def test_round_trip_grayscale_is_lossy_by_design() -> None:
    # Grayscale collapses 3 channels to 1 -- round-tripping through it
    # should NOT reproduce a non-grey original; this test documents
    # that expectation rather than silently assuming grayscale is
    # invertible.
    red = Colour.hex("#ff0000")
    via_gray = red.convert("linear_rgb").convert("grayscale").convert("srgb")
    assert via_gray.hex() != red.hex()
    r, g, b = via_gray.channels
    assert r == pytest.approx(g, abs=1e-9) and g == pytest.approx(b, abs=1e-9)
