"""tests/test_algorithms/test_algorithms.py"""

from __future__ import annotations

import pytest

from chroma.algorithms.blending import BlendMode, blend
from chroma.algorithms.compositing import CompositingOperator, composite
from chroma.algorithms.dithering import error_diffusion_dither, ordered_dither
from chroma.algorithms.quantisation import kmeans_quantise, median_cut, nearest_colour_quantiser, uniform_quantise
from chroma.core.colour import Colour


def test_nearest_colour_quantiser_snaps_exactly_to_palette_members() -> None:
    palette = [Colour.named(n) for n in ("red", "green", "blue")]
    quantiser = nearest_colour_quantiser(palette)
    for p in palette:
        assert quantiser(p).approx_equal(p, tolerance=1e-9)


def test_uniform_quantise_reduces_distinct_levels() -> None:
    a = uniform_quantise(Colour.rgb(10, 10, 10), levels_per_channel=2)
    b = uniform_quantise(Colour.rgb(20, 20, 20), levels_per_channel=2)
    # Both close to black should collapse to the same quantised level.
    assert a.approx_equal(b, tolerance=1e-6)


def test_median_cut_returns_requested_bucket_count_or_fewer() -> None:
    colours = [Colour.hex(h) for h in ("#ff0000", "#fe0101", "#00ff00", "#01fe01", "#0000ff", "#0101fe")]
    result = median_cut(colours, target_size=3)
    assert 1 <= len(result) <= 3


def test_kmeans_is_deterministic_given_seed() -> None:
    colours = [Colour.hex(h) for h in ("#ff0000", "#00ff00", "#0000ff", "#ffff00", "#00ffff")]
    a = kmeans_quantise(colours, k=3, seed=7)
    b = kmeans_quantise(colours, k=3, seed=7)
    assert [c.hex() for c in a] == [c.hex() for c in b]


def test_ordered_dither_and_error_diffusion_produce_only_palette_colours() -> None:
    palette = [Colour.named("black"), Colour.named("white")]
    quantiser = nearest_colour_quantiser(palette)
    grid = [[Colour.rgb(128, 128, 128) for _ in range(6)] for _ in range(6)]

    dithered = ordered_dither(grid, quantiser)
    for row in dithered:
        for px in row:
            assert any(px.approx_equal(p, tolerance=1e-9) for p in palette)

    diffused = error_diffusion_dither(grid, quantiser)
    for row in diffused:
        for px in row:
            assert any(px.approx_equal(p, tolerance=1e-9) for p in palette)


def test_error_diffusion_averages_to_roughly_the_source_grey() -> None:
    """
    Error diffusion should distribute roughly the right proportion of
    black/white pixels to approximate the source grey -- IN LINEAR
    LIGHT, per this module's documented design (project spec section
    7: never propagate error in gamma-encoded RGB). Gamma-encoded 128
    (~0.502 in 0..1 sRGB) decodes to ~0.216 in linear light, so the
    expected white fraction is ~22%, not ~50%.
    """
    palette = [Colour.named("black"), Colour.named("white")]
    quantiser = nearest_colour_quantiser(palette)
    grid = [[Colour.rgb(128, 128, 128) for _ in range(20)] for _ in range(20)]
    diffused = error_diffusion_dither(grid, quantiser)
    white_count = sum(1 for row in diffused for px in row if px.hex() == "#ffffff")
    fraction = white_count / (20 * 20)
    assert 0.12 < fraction < 0.32


@pytest.mark.parametrize("mode", list(BlendMode))
def test_blend_modes_run_and_stay_in_range(mode: BlendMode) -> None:
    a, b = Colour.rgb(200, 100, 50), Colour.rgb(50, 150, 220)
    result = blend(a, b, mode, space="srgb")
    r, g, bch = result.channels
    assert all(0.0 <= c <= 1.0 for c in (r, g, bch))


def test_blend_normal_mode_returns_the_blend_colour() -> None:
    a, b = Colour.rgb(200, 100, 50), Colour.rgb(50, 150, 220)
    assert blend(a, b, "normal", space="srgb").approx_equal(b, tolerance=1e-6)


@pytest.mark.parametrize("op", list(CompositingOperator))
def test_composite_alpha_is_in_range(op: CompositingOperator) -> None:
    src = Colour.rgb(255, 0, 0, a=128)
    dst = Colour.rgb(0, 0, 255, a=255)
    result = composite(src, dst, op)
    assert 0.0 <= result.alpha <= 1.0


def test_source_over_opaque_source_fully_covers_destination() -> None:
    src = Colour.rgb(255, 0, 0, a=255)
    dst = Colour.rgb(0, 0, 255, a=255)
    result = composite(src, dst, "source-over")
    assert result.approx_equal(src, tolerance=1e-6)
    assert result.alpha == pytest.approx(1.0, abs=1e-9)


def test_source_in_with_transparent_destination_is_transparent() -> None:
    src = Colour.rgb(255, 0, 0, a=255)
    dst = Colour.rgb(0, 0, 255, a=0)
    result = composite(src, dst, "source-in")
    assert result.alpha == pytest.approx(0.0, abs=1e-9)
