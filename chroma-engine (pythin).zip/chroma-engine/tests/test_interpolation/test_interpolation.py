"""tests/test_interpolation/test_interpolation.py"""

from __future__ import annotations

import pytest

from chroma.core.colour import Colour
from chroma.interpolation.engine import HueInterpolationMode, interpolate, interpolate_series


def test_interpolate_endpoints_return_the_originals() -> None:
    a, b = Colour.named("red"), Colour.named("blue")
    assert interpolate(a, b, 0.0, "oklab").approx_equal(a, tolerance=1e-6)
    assert interpolate(a, b, 1.0, "oklab").approx_equal(b, tolerance=1e-6)


def test_hue_wrap_shortest_does_not_cross_the_whole_wheel() -> None:
    """Project spec section 30: 350 -> 10 should go the short way (through 0/360), not through 180."""
    a = Colour.from_space("oklch", L=0.6, C=0.1, h=350.0)
    b = Colour.from_space("oklch", L=0.6, C=0.1, h=10.0)
    mid = interpolate(a, b, 0.5, "oklch", hue_mode=HueInterpolationMode.SHORTEST)
    h = mid.convert("oklch").channel("h")
    # The short way's midpoint is 0 (=360); the long way's midpoint would be 180.
    assert (h < 5.0 or h > 355.0)


def test_hue_wrap_longest_goes_the_other_way() -> None:
    a = Colour.from_space("oklch", L=0.6, C=0.1, h=350.0)
    b = Colour.from_space("oklch", L=0.6, C=0.1, h=10.0)
    mid = interpolate(a, b, 0.5, "oklch", hue_mode=HueInterpolationMode.LONGEST)
    h = mid.convert("oklch").channel("h")
    assert 170.0 < h < 190.0


def test_interpolate_series_length_and_endpoints() -> None:
    a, b = Colour.named("black"), Colour.named("white")
    series = interpolate_series(a, b, steps=5, space="oklab")
    assert len(series) == 5
    assert series.colours[0].approx_equal(a, tolerance=1e-6)
    assert series.colours[-1].approx_equal(b, tolerance=1e-6)


def test_interpolate_alpha() -> None:
    red = Colour.named("red")
    a = Colour(red.space, red.channels, alpha=0.0)
    b = Colour(red.space, red.channels, alpha=1.0)
    mid = interpolate(a, b, 0.5, "oklab")
    assert mid.alpha == pytest.approx(0.5, abs=1e-6)
