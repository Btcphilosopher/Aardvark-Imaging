"""tests/test_spaces/test_spaces.py"""

from __future__ import annotations

import pytest

from chroma.core.spaces import ColourSpace, arity, channel_names, metadata_for


@pytest.mark.parametrize("space", list(ColourSpace))
def test_every_space_has_metadata(space: ColourSpace) -> None:
    meta = metadata_for(space)
    assert meta.channel_names
    assert len(meta.channel_ranges) == len(meta.channel_names)
    assert arity(space) == len(meta.channel_names)


def test_white_point_requirement_flags_are_sensible() -> None:
    assert metadata_for(ColourSpace.XYZ).requires_white_point
    assert metadata_for(ColourSpace.LAB).requires_white_point
    assert not metadata_for(ColourSpace.SRGB).requires_white_point
    assert not metadata_for(ColourSpace.OKLAB).requires_white_point


def test_polar_spaces_have_a_hue_channel() -> None:
    for space in (ColourSpace.HSV, ColourSpace.HSL, ColourSpace.LCH, ColourSpace.LCHUV, ColourSpace.OKLCH):
        assert metadata_for(space).is_polar
        assert "h" in channel_names(space)


def test_cmyk_has_four_channels() -> None:
    assert arity(ColourSpace.CMYK) == 4


def test_grayscale_has_one_channel() -> None:
    assert arity(ColourSpace.GRAYSCALE) == 1
