"""tests/test_catalogue/test_catalogue.py"""

from __future__ import annotations

import itertools

import pytest

from chroma.catalogue.database import Catalogue
from chroma.catalogue.naming import name_colour
from chroma.catalogue.universe import enumerate_rgb8, nearest_in_rgb8, sample_rgb8, within_distance_rgb8
from chroma.core.colour import Colour
from chroma.core.exceptions import CatalogueError


def test_catalogue_rejects_duplicate_ids() -> None:
    cat = Catalogue()
    cat.add_colour("a", Colour.named("red"))
    with pytest.raises(CatalogueError):
        cat.add_colour("a", Colour.named("blue"))


def test_catalogue_search_hue_range() -> None:
    cat = Catalogue()
    cat.add_colour("red", Colour.named("red"))
    cat.add_colour("green", Colour.named("green"))
    cat.add_colour("blue", Colour.named("blue"))
    red_hue = Colour.named("red").convert("oklch").channel("h")
    results = cat.search(hue_range=(red_hue - 10, red_hue + 10))
    assert [e.id for e in results] == ["red"]


def test_catalogue_nearest_finds_exact_match() -> None:
    cat = Catalogue()
    cat.add_colour("blue", Colour.named("blue"))
    cat.add_colour("red", Colour.named("red"))
    match = cat.nearest(Colour.named("blue"))
    assert match.source.id == "blue"
    assert match.distance == pytest.approx(0.0, abs=1e-6)


def test_name_colour_returns_exact_match_for_a_css_colour() -> None:
    match = name_colour(Colour.named("cornflowerblue"))
    assert match.name == "cornflowerblue"
    assert match.distance == pytest.approx(0.0, abs=1e-6)


def test_enumerate_rgb8_starts_at_black_and_increments_b_fastest() -> None:
    """Full 16.7M-element exhaustion would be needlessly slow for a test; check the documented lexicographic (r, g, b) order on a small prefix instead."""
    first_five = list(itertools.islice(enumerate_rgb8(), 5))
    assert [c.rgb8() for c in first_five] == [(0, 0, 0), (0, 0, 1), (0, 0, 2), (0, 0, 3), (0, 0, 4)]
    # After 256 elements, b has wrapped and g increments.
    at_256 = next(itertools.islice(enumerate_rgb8(), 256, 257))
    assert at_256.rgb8() == (0, 1, 0)
    # After 256*256 elements, g has wrapped and r increments.
    at_65536 = next(itertools.islice(enumerate_rgb8(), 256 * 256, 256 * 256 + 1))
    assert at_65536.rgb8() == (1, 0, 0)


def test_sample_rgb8_returns_distinct_colours() -> None:
    sample = sample_rgb8(50, seed=3)
    hexes = {c.hex() for c in sample}
    assert len(hexes) == 50


def test_sample_rgb8_is_deterministic() -> None:
    a = sample_rgb8(10, seed=99)
    b = sample_rgb8(10, seed=99)
    assert [c.hex() for c in a] == [c.hex() for c in b]


def test_nearest_in_rgb8_bounded_matches_the_target_when_it_is_already_rgb8() -> None:
    target = Colour.rgb(36, 87, 166)
    match = nearest_in_rgb8(target, method="ciede2000")
    assert match.colour.rgb8() == (36, 87, 166)
    assert match.distance == pytest.approx(0.0, abs=1e-6)


def test_within_distance_rgb8_respects_the_limit() -> None:
    # Use a target near the start of the (r, g, b) lexicographic
    # enumeration order so this test finds its matches quickly rather
    # than scanning a large fraction of the 16.7M-colour space.
    target = Colour.rgb(2, 2, 3)
    results = list(within_distance_rgb8(target, threshold=3.0, limit=10))
    assert len(results) <= 10
    for c in results:
        assert c.distance(target, method="ciede2000") <= 3.0 + 1e-6
