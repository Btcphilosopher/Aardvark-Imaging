"""tests/test_harmony/test_harmony.py"""

from __future__ import annotations

import pytest

from chroma.core.colour import Colour
from chroma.harmony.engine import analogous, complementary, monochromatic, split_complementary, tetradic, triadic


def test_complementary_is_180_degrees_in_oklch() -> None:
    c = Colour.hex("#2457A6")
    comp = complementary(c)
    h1 = c.convert("oklch").channel("h")
    h2 = comp.convert("oklch").channel("h")
    assert (h2 - h1) % 360.0 == pytest.approx(180.0, abs=1e-4)


def test_triadic_is_three_colours_120_apart() -> None:
    c = Colour.hex("#2457A6")
    t = triadic(c)
    assert len(t) == 3
    hues = [x.convert("oklch").channel("h") for x in t]
    assert (hues[1] - hues[0]) % 360.0 == pytest.approx(120.0, abs=1e-4)
    assert (hues[2] - hues[1]) % 360.0 == pytest.approx(120.0, abs=1e-4)


def test_tetradic_is_four_colours() -> None:
    assert len(tetradic(Colour.hex("#2457A6"))) == 4


def test_analogous_is_symmetric_around_base() -> None:
    c = Colour.hex("#2457A6")
    lo, base, hi = analogous(c, angle=30.0)
    assert base.approx_equal(c, tolerance=1e-6)


def test_split_complementary_avoids_exact_complement() -> None:
    c = Colour.hex("#2457A6")
    base, s1, s2 = split_complementary(c, angle=30.0)
    comp_hue = (c.convert("oklch").channel("h") + 180.0) % 360.0
    h1 = s1.convert("oklch").channel("h")
    assert abs(((h1 - comp_hue + 180.0) % 360.0) - 180.0) == pytest.approx(30.0, abs=1e-4)


def test_monochromatic_keeps_hue_and_chroma_fixed() -> None:
    c = Colour.hex("#2457A6")
    series = monochromatic(c, steps=6)
    base_h = c.convert("oklch").channel("h")
    base_c = c.convert("oklch").channel("C")
    for colour in series:
        oklch = colour.convert("oklch")
        assert oklch.channel("h") == pytest.approx(base_h, abs=1e-4)
        assert oklch.channel("C") == pytest.approx(base_c, abs=1e-4)
