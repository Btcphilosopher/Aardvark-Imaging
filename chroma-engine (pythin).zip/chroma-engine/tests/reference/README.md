# Reference value policy

Project spec section 69 asks that every test using a "reference value" state
its **source**, the **expected** value, and the **tolerance**, and that
reference values not be invented.

This test suite leans on three kinds of reference value, in order of
preference:

1. **Definitional facts.** Things that are true by the *definition* of a
   colour space or formula, independent of any external table -- e.g. "a
   patch whose XYZ equals the reference white's XYZ converts to Lab
   `(100, 0, 0)`" (this falls directly out of CIELAB's defining equations),
   or "black vs. white WCAG contrast is exactly 21:1" (falls directly out of
   the contrast-ratio formula: `(1 + 0.05) / (0 + 0.05) = 21`). These need no
   citation beyond the spec they're defined in, and admit essentially no
   tolerance.

2. **Widely-published, stable conventions.** E.g. the CCT "names" of the
   standard illuminants (D65 ≈ 6504 K, D50 ≈ 5003 K, illuminant A ≈ 2856 K) --
   these are how the illuminants are referred to throughout colorimetry
   literature, not a single paper's specific measurement, so a ±50 K
   tolerance against McCamy's approximation is appropriate and honestly
   reflects that this is a convention check, not a precision test of
   McCamy's formula itself.

3. **Internal self-consistency.** Round-trips (`A -> B -> A` within a stated
   tolerance), symmetry (`distance(a, b) == distance(b, a)` -- except where a
   metric is deliberately asymmetric, e.g. CIE94, which is tested for that
   instead), and closed-form identities (e.g. CIEDE2000 reduces to a known
   simpler expression when two colours differ only in lightness). These
   don't depend on any external number at all -- they test that the
   *implementation* is mathematically consistent with itself.

We deliberately did **not** hand-transcribe a large third-party CIEDE2000 or
CIE94 test-vector table into this suite from memory, because doing so risks
enshrining a subtly wrong "reference" value with a misleadingly precise
tolerance -- which is worse than not having the test at all. If you have
access to a citable machine-readable test-vector file (e.g. Gaurav Sharma's
published CIEDE2000 test data), dropping it into this directory as its own
fixture file and wiring up `tests/test_distance/test_ciede2000_reference.py`
against it is one of the highest-value follow-ups to this test suite.

## Where the spectral CMF data comes from

`chroma/spectral/data/cie1931_2deg_5nm.py` is transcribed from a named,
citable source (Judd & Wyszecki via the public-domain BRL-CAD ray tracer's
spectral module) -- see that file's own docstring for the full citation.
`tests/test_spectral/test_spectral.py` checks it against a definitional fact
(a flat spectrum integrates to the equal-energy chromaticity) rather than
against hand-copied XYZ values, for the same reason as above.
