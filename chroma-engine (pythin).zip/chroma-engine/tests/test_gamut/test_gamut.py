"""tests/test_gamut/test_gamut.py"""

from __future__ import annotations

import pytest

from chroma.core.colour import Colour
from chroma.gamut.detection import is_in_gamut
from chroma.gamut.mapping import GamutMappingMethod, map_to_gamut, map_to_gamut_report
from chroma.gamut.strategies import max_chroma_at


@pytest.mark.parametrize("hex_value", ["#000000", "#ffffff", "#ff0000", "#00ff00", "#0000ff", "#808080"])
def test_srgb_primaries_are_in_srgb_gamut(hex_value: str) -> None:
    assert is_in_gamut(Colour.hex(hex_value), "srgb")


def test_wide_gamut_oklch_colour_is_out_of_srgb() -> None:
    wide = Colour.from_space("oklch", L=0.6, C=0.35, h=30.0)
    assert not is_in_gamut(wide, "srgb")


def test_max_chroma_boundary_is_actually_in_gamut_just_past_is_not() -> None:
    """The whole point of max_chroma_at is that it finds a REAL boundary, not a guess."""
    boundary = max_chroma_at(0.6, 30.0, "srgb")
    just_inside = Colour.from_space("oklch", L=0.6, C=boundary * 0.999, h=30.0)
    just_outside = Colour.from_space("oklch", L=0.6, C=boundary * 1.05, h=30.0)
    assert is_in_gamut(just_inside, "srgb")
    assert not is_in_gamut(just_outside, "srgb")


def test_max_chroma_shrinks_towards_the_extremes() -> None:
    """
    Near L=0 and L=1, in-gamut chroma must be much smaller than at
    mid-lightness -- NOT exactly zero, because OKLab's L=0 (and L=1)
    plane does not perfectly coincide with the sRGB cube's black (or
    white) corner at every hue; this is a real, documented property of
    OKLab's construction, not a search bug (see docs/GAMUT.md).
    """
    mid_boundary = max_chroma_at(0.6, 30.0, "srgb")
    assert max_chroma_at(0.0, 30.0, "srgb") < mid_boundary * 0.3
    assert max_chroma_at(1.0, 30.0, "srgb") < mid_boundary * 0.3


def test_p3_gamut_is_a_superset_of_srgb_at_saturated_hues() -> None:
    """Display P3's primaries are chosen to be wider than sRGB, so its max chroma at a saturated hue must be >= sRGB's."""
    for hue in (0, 60, 120, 180, 240, 300):
        srgb_max = max_chroma_at(0.6, hue, "srgb")
        p3_max = max_chroma_at(0.6, hue, "display-p3")
        assert p3_max >= srgb_max - 1e-6


@pytest.mark.parametrize("method", list(GamutMappingMethod))
def test_gamut_mapping_always_lands_in_gamut(method: GamutMappingMethod) -> None:
    wide = Colour.from_space("oklch", L=0.6, C=0.35, h=30.0)
    mapped = map_to_gamut(wide, "srgb", method)
    assert is_in_gamut(mapped, "srgb", tolerance=1e-3)


def test_gamut_mapping_is_a_no_op_for_already_in_gamut_colours() -> None:
    colour = Colour.hex("#2457A6")
    for method in GamutMappingMethod:
        mapped = map_to_gamut(colour, "srgb", method)
        assert mapped.approx_equal(colour, tolerance=1e-6)


def test_gamut_mapping_report_delta_is_zero_when_unchanged() -> None:
    colour = Colour.hex("#2457A6")
    report = map_to_gamut_report(colour, "srgb", "compress_chroma")
    assert report.delta_oklab == pytest.approx(0.0, abs=1e-9)
