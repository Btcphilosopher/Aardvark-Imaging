"""tests/test_distance/test_metrics.py"""

from __future__ import annotations

import pytest

from chroma.core.colour import Colour
from chroma.distance.metrics import DistanceMethod, delta_e_2000, distance, distance_matrix
from chroma.distance.nearest import k_nearest, nearest


@pytest.mark.parametrize("method", list(DistanceMethod))
def test_distance_to_self_is_zero(method: DistanceMethod) -> None:
    c = Colour.hex("#2457A6")
    assert distance(c, c, method) == pytest.approx(0.0, abs=1e-9)


@pytest.mark.parametrize("method", [m for m in DistanceMethod if m != DistanceMethod.CIE94])
def test_distance_is_symmetric(method: DistanceMethod) -> None:
    a, b = Colour.hex("#2457A6"), Colour.named("red")
    assert distance(a, b, method) == pytest.approx(distance(b, a, method), abs=1e-9)


def test_cie94_is_intentionally_asymmetric() -> None:
    """
    CIE94's SC/SH weighting functions depend on the REFERENCE sample's
    chroma specifically (see delta_e_1994's docstring), so swapping
    which colour is "first" changes the result by design -- this is
    documented CIE94 behaviour, not a bug, and this test exists so a
    future change accidentally making it symmetric gets caught too.
    """
    a, b = Colour.hex("#2457A6"), Colour.named("red")
    assert distance(a, b, "cie94") != pytest.approx(distance(b, a, "cie94"), abs=1e-6)


def test_black_white_is_the_largest_cie76_distance_among_greys() -> None:
    black, white, grey = Colour.named("black"), Colour.named("white"), Colour.rgb(128, 128, 128)
    assert distance(black, white, "cie76") > distance(black, grey, "cie76")
    assert distance(black, white, "cie76") > distance(grey, white, "cie76")


def test_ciede2000_matches_cie76_for_identical_lightness_only_difference() -> None:
    """
    SOURCE: definitional -- when two Lab colours differ ONLY in L* (same
    a*, b*), CIEDE2000's C and H terms are both zero, so CIEDE2000
    reduces to exactly |deltaL / SL| (SL depends only on the mean L*).
    This checks the formula's internal consistency, not an external
    reference table.
    """
    from chroma.core.spaces import ColourSpace

    a = Colour.from_space("lab", L=30.0, a=20.0, b=-10.0)
    b = Colour.from_space("lab", L=70.0, a=20.0, b=-10.0)
    lab_a, lab_b = a.channels, b.channels
    d00 = delta_e_2000(lab_a, lab_b)
    mean_l = (30.0 + 70.0) / 2.0
    sl = 1.0 + (0.015 * (mean_l - 50.0) ** 2) / ((20.0 + (mean_l - 50.0) ** 2) ** 0.5)
    expected = abs(70.0 - 30.0) / sl
    assert d00 == pytest.approx(expected, abs=1e-6)


def test_nearest_depends_on_metric() -> None:
    """Project spec section 28: nearest colour can legitimately differ by metric."""
    target = Colour.hex("#808000")  # olive-ish
    candidates = [Colour.named(n) for n in ("red", "green", "yellow", "grey")]
    by_rgb = nearest(target, candidates, "rgb_euclidean")
    by_oklab = nearest(target, candidates, "oklab_euclidean")
    # Not asserting they MUST differ (that would be flaky/metric-specific);
    # just that both return valid, real candidates.
    assert by_rgb.colour in candidates
    assert by_oklab.colour in candidates


def test_k_nearest_is_sorted_ascending() -> None:
    target = Colour.hex("#2457A6")
    candidates = [Colour.named(n) for n in ("red", "green", "blue", "navy", "royalblue", "white", "black")]
    results = k_nearest(target, candidates, k=4)
    distances = [r.distance for r in results]
    assert distances == sorted(distances)
    assert len(results) == 4


def test_distance_matrix_is_symmetric_with_zero_diagonal() -> None:
    colours = [Colour.named(n) for n in ("red", "green", "blue", "white")]
    matrix = distance_matrix(colours, "ciede2000")
    n = len(colours)
    for i in range(n):
        assert matrix[i][i] == pytest.approx(0.0, abs=1e-9)
        for j in range(n):
            assert matrix[i][j] == pytest.approx(matrix[j][i], abs=1e-9)
