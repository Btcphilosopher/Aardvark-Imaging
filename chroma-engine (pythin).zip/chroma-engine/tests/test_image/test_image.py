"""tests/test_image/test_image.py"""

from __future__ import annotations

import pytest

from chroma.core.colour import Colour
from chroma.image.dominant import DominantMethod, dominant_colours
from chroma.image.histogram import build_histogram, channel_statistics
from chroma.image.sampling import sample_region
from chroma.image.source import ListImageSource


def _uniform_source(colour: Colour, width: int = 4, height: int = 4) -> ListImageSource:
    return ListImageSource([[colour for _ in range(width)] for _ in range(height)])


def test_sample_region_of_uniform_image_returns_that_colour() -> None:
    colour = Colour.hex("#2457A6")
    source = _uniform_source(colour)
    mean = sample_region(source, 0, 0, source.width, source.height)
    assert mean.approx_equal(colour, tolerance=1e-4)


def test_histogram_of_uniform_image_is_a_single_spike() -> None:
    source = _uniform_source(Colour.named("white"))
    hist = build_histogram(source, "luminance", bins=16)
    assert hist.total() == 16
    assert max(hist.counts) == 16
    assert hist.entropy() == pytest.approx(0.0, abs=1e-9)  # a single spike has zero entropy


def test_histogram_entropy_increases_with_variety() -> None:
    mixed_rows = [[Colour.named(n) for n in ("red", "green", "blue", "white")] for _ in range(4)]
    source = ListImageSource(mixed_rows)
    hist = build_histogram(source, "hue", bins=8)
    assert hist.entropy() > 0.0


def test_dominant_colours_frequency_finds_the_majority_colour() -> None:
    rows = [[Colour.named("red")] * 3 + [Colour.named("blue")] for _ in range(4)]
    source = ListImageSource(rows)
    dominant = dominant_colours(source, n=2, method=DominantMethod.FREQUENCY)
    assert dominant[0].colour.hex() == "#ff0000"
    assert dominant[0].weight > dominant[1].weight


def test_channel_statistics_mean_of_uniform_image() -> None:
    source = _uniform_source(Colour.rgb(100, 100, 100))
    stats = channel_statistics(source, "r", bins=8)
    assert stats.mean == pytest.approx(100 / 255, abs=1e-6)
    assert stats.std_dev == pytest.approx(0.0, abs=1e-9)
