"""tests/test_palette/test_palette.py"""

from __future__ import annotations

import pytest

from chroma.core.colour import Colour
from chroma.palette.generator import PaletteMethod, generate_palette
from chroma.palette.palette import Palette, PaletteEntry, Role


@pytest.mark.parametrize("method", list(PaletteMethod))
@pytest.mark.parametrize("size", [1, 5, 12])
def test_generate_palette_has_requested_size(method: PaletteMethod, size: int) -> None:
    palette = generate_palette(Colour.hex("#2457A6"), method=method, size=size)
    assert len(palette) == size


def test_palette_roles_round_trip_through_dict() -> None:
    colours = [Colour.named(n) for n in ("red", "green", "blue")]
    palette = Palette.from_colours(colours, name="test").with_roles([Role.PRIMARY, Role.SECONDARY, Role.ACCENT])
    data = palette.to_dict()
    restored = Palette.from_dict(data)
    assert [e.role for e in restored.entries] == [Role.PRIMARY, Role.SECONDARY, Role.ACCENT]
    assert restored.by_role(Role.PRIMARY)[0].colour.approx_equal(colours[0])


def test_gamut_aware_palette_sits_on_the_boundary() -> None:
    from chroma.gamut.detection import is_in_gamut
    from chroma.gamut.strategies import max_chroma_at

    palette = generate_palette(Colour.hex("#2457A6"), method="gamut_aware", size=6, target="srgb")
    for colour in palette.colours():
        assert is_in_gamut(colour, "srgb", tolerance=1e-3)


def test_contrast_optimised_palette_entries_are_distinguishable() -> None:
    from chroma.contrast.wcag import contrast_ratio

    palette = generate_palette(Colour.hex("#2457A6"), method="contrast_optimised", size=5)
    colours = palette.colours()
    # Every pair should have SOME contrast (not identical colours).
    for i in range(len(colours)):
        for j in range(i + 1, len(colours)):
            assert contrast_ratio(colours[i], colours[j]) > 1.0
