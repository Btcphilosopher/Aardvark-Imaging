"""
examples/image_analysis.py
=============================

DEMONSTRATION 4 -- IMAGE COLOUR LAB (project spec section 75).

Uses the dependency-free ListImageSource adapter (no Pillow) to build
a small synthetic "image", then runs dominant-colour extraction,
histograms, mean/median colour, colour entropy, hue distribution and
palette export against it -- exactly the pipeline a real Pillow/NumPy
adapter would feed into unmodified.

Run with:  python examples/image_analysis.py
"""

from __future__ import annotations

import random

from chroma import Colour
from chroma.image import (
    DominantMethod,
    build_histogram,
    colour_statistics,
    dominant_colours,
    palette_from_image,
    sample_region,
)
from chroma.image.source import ListImageSource


def make_synthetic_image(width: int = 40, height: int = 40, seed: int = 0) -> ListImageSource:
    """A small synthetic 'sky over sea' gradient-plus-noise image -- no external image file needed."""
    rng = random.Random(seed)
    sky = Colour.hex("#4a90d9")
    sea = Colour.hex("#1a3f6b")
    sun = Colour.hex("#ffd27a")
    rows = []
    for y in range(height):
        row = []
        for x in range(width):
            base = sky if y < height // 2 else sea
            if (x - width * 0.75) ** 2 + (y - height * 0.25) ** 2 < 20:
                base = sun
            jitter = rng.uniform(-0.03, 0.03)
            row.append(base.lighten(jitter))
        rows.append(row)
    return ListImageSource(rows)


def main() -> None:
    image = make_synthetic_image()
    print(f"IMAGE COLOUR LAB -- synthetic {image.width}x{image.height} image\n")

    mean_colour = sample_region(image, 0, 0, image.width, image.height)
    print(f"Mean colour: {mean_colour.hex()}")

    stats = colour_statistics(image)
    print(f"Colour entropy:     {stats.colour_entropy:.3f} bits")
    print(f"Luminance entropy:  {stats.luminance_entropy:.3f} bits")
    print(f"Hue entropy:        {stats.hue_entropy:.3f} bits")
    print(f"Luminance mean/median: {stats.per_channel['luminance'].mean:.3f} / {stats.per_channel['luminance'].median:.3f}")

    hue_hist = build_histogram(image, "hue", bins=12)
    print("\nHue distribution (12 bins):")
    for i, count in enumerate(hue_hist.counts):
        if count:
            print(f"  {hue_hist.bin_centre(i):6.1f}deg: {'#' * count} ({count})")

    print("\nDominant colours (k-means, k=4):")
    for d in dominant_colours(image, n=4, method=DominantMethod.KMEANS):
        print(f"  {d.colour.hex()}  weight={d.weight}  ({d.percentage:.1%})")

    palette = palette_from_image(image, size=4)
    print("\nExported palette:", " ".join(c.hex() for c in palette.colours()))


if __name__ == "__main__":
    main()
