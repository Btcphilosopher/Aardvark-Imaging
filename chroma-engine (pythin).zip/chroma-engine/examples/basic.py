"""
examples/basic.py
====================

The five-minute tour of Chroma Engine.

Run with:  python examples/basic.py
"""

from __future__ import annotations

from chroma import Colour


def main() -> None:
    # Construction: hex, RGB8, RGB float, named, or directly in any space.
    blue = Colour.hex("#2457A6")
    also_blue = Colour.rgb(36, 87, 166)
    print("Constructed the same colour two ways:", blue.hex(), also_blue.hex())

    # Colour is immutable -- every operation returns a new Colour.
    lighter = blue.lighten(0.15)
    print(f"\nblue           = {blue.hex()}")
    print(f"blue.lighten() = {lighter.hex()}   (blue itself is unchanged: {blue.hex()})")

    # Explicit, labelled conversion -- never a silent reinterpretation.
    oklch = blue.convert("oklch")
    print(f"\nblue in OKLCh: L={oklch.channel('L'):.4f} C={oklch.channel('C'):.4f} h={oklch.channel('h'):.2f}deg")

    # Perceptual distance, with the metric always explicit.
    red = Colour.named("red")
    print(f"\nCIEDE2000 distance blue<->red:      {blue.distance(red, 'ciede2000'):.3f}")
    print(f"OKLab Euclidean distance blue<->red: {blue.distance(red, 'oklab_euclidean'):.4f}")

    # Gamut status is data, not an assumption.
    wide = Colour.from_space("oklch", L=0.6, C=0.35, h=30.0)
    print(f"\nA wide-gamut orange is in sRGB? {wide.is_in_gamut('srgb')}")
    print(f"Mapped into sRGB: {wide.map_to_gamut('srgb').hex()}")

    # One seed colour, a whole family.
    palette = blue.generate_palette(method="analogous", size=5)
    print("\nA 5-colour analogous palette from blue:", " ".join(c.hex() for c in palette.colours()))


if __name__ == "__main__":
    main()
