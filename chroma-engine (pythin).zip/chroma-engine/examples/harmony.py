"""
examples/harmony.py
======================

Compare the SAME harmony scheme generated in different working
spaces (project spec section 26) -- HSV, HSL and OKLCh disagree about
where a hue angle sits, so a "triadic" scheme looks different in each.

Run with:  python examples/harmony.py
"""

from __future__ import annotations

from chroma import Colour
from chroma.harmony.engine import triadic

BASE_HEX = "#2457A6"


def main() -> None:
    base = Colour.hex(BASE_HEX)
    print(f"Triadic scheme from {base.hex()}, compared across working spaces:\n")
    for space in ("hsv", "hsl", "lch", "oklch"):
        scheme = triadic(base, space=space)
        print(f"  {space.upper():<6} " + " ".join(c.hex() for c in scheme))


if __name__ == "__main__":
    main()
