"""
examples/variations.py
=========================

DEMONSTRATION 1 -- THE AARDVARK BLUE COLOUR FAMILY (project spec
section 72).

Base colour: #2457A6. Generates 360 hue variations, 100 lightness
variations and 100 chroma variations, the standard harmony set, and
prints the base colour's coordinates across five spaces plus its
CIEDE2000/OKLab distance to its own complement and its sRGB gamut
status.

Run with:  python examples/variations.py
"""

from __future__ import annotations

from chroma import Colour
from chroma.harmony.engine import analogous, complementary, monochromatic, tetradic, triadic
from chroma.variation.engine import chroma_series, hue_sweep, lightness_series

BASE_HEX = "#2457A6"


def main() -> None:
    base = Colour.hex(BASE_HEX)
    print(f"AARDVARK BLUE COLOUR FAMILY -- base {base.hex()}\n")

    print("Coordinates:")
    for space in ("srgb", "lab", "lch", "oklab", "oklch"):
        c = base.convert(space)
        print(f"  {space.upper():<6} " + "  ".join(f"{n}={v:.4f}" for n, v in c.as_dict().items()))

    hues = hue_sweep(base, step=1.0)  # 360 steps
    lightnesses = lightness_series(base, space="oklch", steps=100)
    chromas = chroma_series(base, steps=100)
    print(f"\n360 hue variations generated: {len(hues)}")
    print(f"100 lightness variations generated: {len(lightnesses)}")
    print(f"100 chroma variations generated (up to the real sRGB gamut boundary): {len(chromas)}")
    print(f"  chroma range: 0.0 .. {chromas.parameter_values[-1]:.4f}")

    comp = complementary(base)
    print(f"\nComplementary: {comp.hex()}")
    print(f"Analogous:     {' '.join(c.hex() for c in analogous(base))}")
    print(f"Triadic:       {' '.join(c.hex() for c in triadic(base))}")
    print(f"Tetradic:      {' '.join(c.hex() for c in tetradic(base))}")
    print(f"Monochromatic: {' '.join(c.hex() for c in monochromatic(base, steps=6))}")

    print(f"\nCIEDE2000 distance to complement:      {base.distance(comp, 'ciede2000'):.3f}")
    print(f"OKLab Euclidean distance to complement: {base.distance(comp, 'oklab_euclidean'):.4f}")
    print(f"Base colour in sRGB gamut: {base.is_in_gamut('srgb')}")
    print(f"Complement in sRGB gamut:  {comp.is_in_gamut('srgb')}")


if __name__ == "__main__":
    main()
