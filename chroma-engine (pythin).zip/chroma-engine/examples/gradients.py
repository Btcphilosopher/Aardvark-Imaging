"""
examples/gradients.py
========================

Interpolating between two colours in different spaces gives visibly
different midpoints -- and hue wrapping matters (project spec sections
29-31).

Run with:  python examples/gradients.py
"""

from __future__ import annotations

from chroma import Colour, Gradient
from chroma.interpolation.engine import HueInterpolationMode, interpolate

RED = Colour.named("red")
BLUE = Colour.named("blue")


def main() -> None:
    print(f"Interpolating {RED.hex()} -> {BLUE.hex()} at t=0.5, by space:")
    for space in ("srgb", "linear_rgb", "hsl", "lab", "oklab"):
        mid = interpolate(RED, BLUE, 0.5, space=space)
        print(f"  {space:<11} -> {mid.hex()}")

    print("\nHue wrapping (350deg -> 10deg at t=0.5):")
    a = Colour.from_space("oklch", L=0.6, C=0.15, h=350.0)
    b = Colour.from_space("oklch", L=0.6, C=0.15, h=10.0)
    for mode in HueInterpolationMode:
        mid = interpolate(a, b, 0.5, space="oklch", hue_mode=mode)
        print(f"  {mode.value:<16} h={mid.convert('oklch').channel('h'):.1f}deg -> {mid.hex()}")

    print("\nA 3-stop gradient (red -> white -> blue), sampled at 9 points:")
    gradient = Gradient.from_colours([RED, Colour.named("white"), BLUE], space="oklab")
    print("  " + " ".join(c.hex() for c in gradient.sample_series(9)))


if __name__ == "__main__":
    main()
