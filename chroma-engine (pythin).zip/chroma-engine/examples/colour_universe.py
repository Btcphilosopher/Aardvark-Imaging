"""
examples/colour_universe.py
==============================

DEMONSTRATION 2 -- THE 16.7 MILLION COLOUR SEARCH (project spec
section 73).

The full 8-bit RGB space is 256 x 256 x 256 = 16,777,216 discrete
colours. This demonstrates lazy enumeration of that space, and shows
that "nearest colour" genuinely depends on which distance metric you
ask -- RGB Euclidean, Lab (CIE76), CIEDE2000 and OKLab Euclidean can
each pick a different "closest" colour to the same target.

Run with:  python examples/colour_universe.py
(the bounded nearest-neighbour search is fast; the full-scan option is
deliberately opt-in because scanning all 16.7M colours in pure Python
takes real wall-clock time -- see the module docstring in
chroma.catalogue.universe)
"""

from __future__ import annotations

import itertools
import time

from chroma import Colour
from chroma.catalogue.universe import enumerate_rgb8, nearest_in_rgb8, sample_rgb8

TARGET_HEX = "#2457A6"


def main() -> None:
    print("THE 16.7 MILLION COLOUR SEARCH\n")
    print("Total RGB8 colours: 256 x 256 x 256 =", 256 ** 3)

    # Lazy enumeration -- nothing is materialised in memory.
    first_ten = list(itertools.islice(enumerate_rgb8(), 10))
    print("\nFirst 10 colours in lexicographic order:", " ".join(c.hex() for c in first_ten))

    sample = sample_rgb8(5, seed=42)
    print("5 uniformly random RGB8 colours (seed=42):", " ".join(c.hex() for c in sample))

    target = Colour.hex(TARGET_HEX)
    print(f"\nNearest RGB8 colour to {target.hex()} under each metric (bounded search):")
    for method in ("rgb_euclidean", "cie76", "ciede2000", "oklab_euclidean"):
        start = time.perf_counter()
        match = nearest_in_rgb8(target, method=method)
        elapsed = time.perf_counter() - start
        print(f"  {method:<16} -> {match.colour.hex()}   distance={match.distance:.5f}   ({elapsed * 1000:.1f}ms)")

    print(
        "\n(Nearest is the target itself here, since the target is already an "
        "RGB8 colour -- try a non-integer OKLCh colour to see the metrics "
        "genuinely disagree on which neighbour is closest.)"
    )
    off_grid = Colour.from_space("oklch", L=0.52, C=0.12, h=250.0)
    print(f"\nNearest RGB8 colour to off-grid {off_grid.hex()} under each metric:")
    for method in ("rgb_euclidean", "cie76", "ciede2000", "oklab_euclidean"):
        match = nearest_in_rgb8(off_grid, method=method)
        print(f"  {method:<16} -> {match.colour.hex()}   distance={match.distance:.5f}")


if __name__ == "__main__":
    main()
