"""
examples/palettes.py
=======================

Every built-in palette-generation method, from one seed colour
(project spec section 38).

Run with:  python examples/palettes.py
"""

from __future__ import annotations

from chroma import Colour
from chroma.palette.generator import PaletteMethod, generate_palette

SEED = "#2457A6"


def main() -> None:
    base = Colour.hex(SEED)
    print(f"Palettes generated from {base.hex()}:\n")
    for method in PaletteMethod:
        palette = generate_palette(base, method=method, size=8)
        print(f"  {method.value:<20} " + " ".join(c.hex() for c in palette.colours()))


if __name__ == "__main__":
    main()
