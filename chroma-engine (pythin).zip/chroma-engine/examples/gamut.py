"""
examples/gamut.py
====================

DEMONSTRATION 3 -- GAMUT EXPLORER (project spec section 74).

Takes a high-chroma OKLCh colour and finds the maximum chroma actually
achievable at the same lightness and hue in sRGB, Display P3 and
Rec.2020 (via real binary search against each gamut's matrices, not a
guess), then shows the original colour mapped into each.

Run with:  python examples/gamut.py
"""

from __future__ import annotations

from chroma import Colour
from chroma.gamut.mapping import map_to_gamut_report
from chroma.gamut.strategies import max_chroma_at

LIGHTNESS = 0.65
CHROMA = 0.35
HUE = 25.0  # a saturated orange-red


def main() -> None:
    original = Colour.from_space("oklch", L=LIGHTNESS, C=CHROMA, h=HUE)
    print(f"GAMUT EXPLORER -- OKLCh(L={LIGHTNESS}, C={CHROMA}, h={HUE})\n")
    print(f"ORIGINAL (unmapped):      {original.hex()}  "
          f"(in sRGB: {original.is_in_gamut('srgb')}, "
          f"in P3: {original.is_in_gamut('display-p3')}, "
          f"in Rec.2020: {original.is_in_gamut('rec2020')})\n")

    for target in ("srgb", "display-p3", "rec2020"):
        boundary = max_chroma_at(LIGHTNESS, HUE, target)
        report = map_to_gamut_report(original, target, "compress_chroma")
        print(f"{target.upper():<12} max in-gamut chroma at this L,h: {boundary:.4f}")
        print(f"{'':<12} mapped colour: {report.mapped.hex()}   delta (OKLab): {report.delta_oklab:.5f}")
        print()


if __name__ == "__main__":
    main()
