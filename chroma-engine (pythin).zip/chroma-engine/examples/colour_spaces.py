"""
examples/colour_spaces.py
============================

For a selected colour, show its coordinates in every space Chroma
Engine understands, and print the exact conversion PATH used to reach
each one -- nothing about a conversion is implicit (project spec
section 63, "Colour Space Explorer").

Run with:  python examples/colour_spaces.py
"""

from __future__ import annotations

from chroma import Colour
from chroma.conversion.graph import explain_path
from chroma.core.spaces import ColourSpace


def main() -> None:
    colour = Colour.hex("#2457A6")
    print(f"COLOUR SPACE EXPLORER -- {colour.hex()}\n")

    spaces = [
        ColourSpace.SRGB, ColourSpace.LINEAR_RGB,
        ColourSpace.HSV, ColourSpace.HSL,
        ColourSpace.XYZ, ColourSpace.XYY,
        ColourSpace.LAB, ColourSpace.LCH,
        ColourSpace.LUV, ColourSpace.LCHUV,
        ColourSpace.OKLAB, ColourSpace.OKLCH,
        ColourSpace.YIQ, ColourSpace.CMYK,
    ]

    for space in spaces:
        converted = colour.convert(space)
        body = "  ".join(f"{name}={value:.4f}" for name, value in converted.as_dict().items())
        path = explain_path(colour.space, space)
        print(f"{space.value.upper():<12} {body}")
        print(f"{'':<12} via {path}")
        print()

    print("White point used for Lab/LCh/Luv/LChuv/XYZ/xyY above:", colour.convert("lab").white.name)
    print("(Ask for a different one explicitly: colour.convert('lab', white='D50'))")


if __name__ == "__main__":
    main()
