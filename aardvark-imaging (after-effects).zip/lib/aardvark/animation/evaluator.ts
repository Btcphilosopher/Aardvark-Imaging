/**
 * AARDVARK IMAGING - ANIMATION & EXPRESSIONS ENGINE
 * High-precision interpolation, cubic Bezier solver, and expression runtime.
 */

import { AnimatableProperty, Keyframe, Vector2D, Vector3D } from '../types';

/**
 * Cubic Bezier solver for keyframe temporal tangents.
 * Solves y(t) given Bezier control points P0(0,0), P1(x1, y1), P2(x2, y2), P3(1,1)
 */
export function solveCubicBezier(
  t: number,
  x1: number,
  y1: number,
  x2: number,
  y2: number
): number {
  if (t <= 0) return 0;
  if (t >= 1) return 1;

  // Newton-Raphson iteration to find parameter u such that Bx(u) = t
  let u = t;
  for (let i = 0; i < 8; i++) {
    const currentX =
      3 * (1 - u) * (1 - u) * u * x1 + 3 * (1 - u) * u * u * x2 + u * u * u;
    const dx =
      3 * (1 - u) * (1 - u) * x1 +
      6 * (1 - u) * u * (x2 - x1) +
      3 * u * u * (1 - x2);
    if (Math.abs(currentX - t) < 0.0001 || Math.abs(dx) < 1e-6) break;
    u -= (currentX - t) / dx;
    u = Math.max(0, Math.min(1, u));
  }

  // Calculate By(u)
  return 3 * (1 - u) * (1 - u) * u * y1 + 3 * (1 - u) * u * u * y2 + u * u * u;
}

/**
 * Calculate easing factor between two keyframes based on interpolation mode and tangents
 */
export function getInterpolationFactor(
  progress: number,
  kfA: Keyframe<any>,
  kfB: Keyframe<any>
): number {
  const mode = kfA.outInterpolation || 'linear';

  if (mode === 'hold') {
    return progress < 1 ? 0 : 1;
  }

  if (mode === 'linear') {
    return progress;
  }

  if (mode === 'ease-in') {
    // Quad ease in
    return progress * progress;
  }

  if (mode === 'ease-out') {
    // Quad ease out
    return progress * (2 - progress);
  }

  if (mode === 'ease-in-out') {
    return progress < 0.5
      ? 2 * progress * progress
      : -1 + (4 - 2 * progress) * progress;
  }

  if (mode === 'bezier') {
    const outX = kfA.outTangent ? Math.min(1, Math.max(0, kfA.outTangent.x)) : 0.33;
    const outY = kfA.outTangent ? kfA.outTangent.y : 0.33;
    const inX = kfB.inTangent ? Math.min(1, Math.max(0, 1 - kfB.inTangent.x)) : 0.67;
    const inY = kfB.inTangent ? 1 - kfB.inTangent.y : 0.67;
    return solveCubicBezier(progress, outX, outY, inX, inY);
  }

  return progress;
}

/**
 * Interpolates single numeric values
 */
export function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

/**
 * Interpolates vector values
 */
export function lerpVector(a: number[], b: number[], t: number): number[] {
  return a.map((val, idx) => lerp(val, b[idx] !== undefined ? b[idx] : val, t));
}

/**
 * Simple pseudo-random seeded noise for expressions (wiggle/noise)
 */
function pseudoNoise(seed: number, t: number): number {
  const x = Math.sin(seed + t * 12.9898) * 43758.5453;
  return (x - Math.floor(x)) * 2 - 1; // -1 to 1
}

function smoothWiggle(seed: number, freq: number, amp: number, time: number): number {
  const t = time * freq;
  const i0 = Math.floor(t);
  const i1 = i0 + 1;
  const f = t - i0;
  // Smoothstep
  const u = f * f * (3.0 - 2.0 * f);
  const n0 = pseudoNoise(seed, i0);
  const n1 = pseudoNoise(seed, i1);
  return (n0 + (n1 - n0) * u) * amp;
}

export interface ExpressionContext {
  time: number; // seconds
  frame: number;
  fps: number;
  compWidth: number;
  compHeight: number;
  layerIndex: number;
  value: any;
}

/**
 * Safe expression evaluation runtime
 */
export function evaluateExpression(
  expression: string,
  baseValue: any,
  context: ExpressionContext
): any {
  try {
    const { time, frame, fps, compWidth, compHeight, layerIndex } = context;

    // Helper utilities inside expressions
    const wiggle = (freq: number, amp: number) => {
      if (Array.isArray(baseValue)) {
        return baseValue.map((v, i) => v + smoothWiggle(layerIndex * 100 + i * 37, freq, amp, time));
      }
      return (typeof baseValue === 'number' ? baseValue : 0) + smoothWiggle(layerIndex * 100, freq, amp, time);
    };

    const clamp = (val: number, min: number, max: number) => Math.min(Math.max(val, min), max);
    const linearInterp = (t: number, tMin: number, tMax: number, val1: number, val2: number) => {
      const p = clamp((t - tMin) / (tMax - tMin), 0, 1);
      return val1 + (val2 - val1) * p;
    };
    const easeInterp = (t: number, tMin: number, tMax: number, val1: number, val2: number) => {
      const p = clamp((t - tMin) / (tMax - tMin), 0, 1);
      const eased = p * p * (3 - 2 * p);
      return val1 + (val2 - val1) * eased;
    };

    // Sandboxed evaluator function
    const evaluator = new Function(
      'time',
      'frame',
      'fps',
      'width',
      'height',
      'index',
      'value',
      'wiggle',
      'clamp',
      'linear',
      'ease',
      'Math',
      `"use strict"; return (${expression});`
    );

    const result = evaluator(
      time,
      frame,
      fps,
      compWidth,
      compHeight,
      layerIndex,
      baseValue,
      wiggle,
      clamp,
      linearInterp,
      easeInterp,
      Math
    );

    return result !== undefined && !Number.isNaN(result) ? result : baseValue;
  } catch (err) {
    // If expression fails, return raw evaluated base value
    return baseValue;
  }
}

/**
 * Evaluates any AnimatableProperty at an arbitrary frame number
 */
export function evaluateProperty<T = any>(
  prop: AnimatableProperty<T>,
  frame: number,
  context?: Partial<ExpressionContext>
): T {
  if (!prop) return 0 as unknown as T;

  let computedValue: T = prop.value;

  if (prop.animated && prop.keyframes && prop.keyframes.length > 0) {
    const kfs = [...prop.keyframes].sort((a, b) => a.frame - b.frame);

    if (frame <= kfs[0].frame) {
      computedValue = kfs[0].value;
    } else if (frame >= kfs[kfs.length - 1].frame) {
      computedValue = kfs[kfs.length - 1].value;
    } else {
      // Find pair of surrounding keyframes
      let kfA = kfs[0];
      let kfB = kfs[1];

      for (let i = 0; i < kfs.length - 1; i++) {
        if (frame >= kfs[i].frame && frame <= kfs[i + 1].frame) {
          kfA = kfs[i];
          kfB = kfs[i + 1];
          break;
        }
      }

      const frameRange = kfB.frame - kfA.frame;
      const rawProgress = frameRange === 0 ? 0 : (frame - kfA.frame) / frameRange;
      const easedProgress = getInterpolationFactor(rawProgress, kfA, kfB);

      if (typeof kfA.value === 'number' && typeof kfB.value === 'number') {
        computedValue = lerp(kfA.value, kfB.value, easedProgress) as unknown as T;
      } else if (Array.isArray(kfA.value) && Array.isArray(kfB.value)) {
        computedValue = lerpVector(kfA.value as number[], kfB.value as number[], easedProgress) as unknown as T;
      } else {
        computedValue = easedProgress < 0.5 ? kfA.value : kfB.value;
      }
    }
  }

  // Handle Expression if present and enabled
  if (prop.expression && prop.expressionEnabled !== false && context) {
    const fullContext: ExpressionContext = {
      time: frame / (context.fps || 30),
      frame,
      fps: context.fps || 30,
      compWidth: context.compWidth || 1920,
      compHeight: context.compHeight || 1080,
      layerIndex: context.layerIndex || 0,
      value: computedValue,
      ...context,
    };
    computedValue = evaluateExpression(prop.expression, computedValue, fullContext);
  }

  return computedValue;
}

/**
 * Creates an AnimatableProperty helper with initial default value
 */
export function createAnimProperty<T>(value: T, animated = false): AnimatableProperty<T> {
  return {
    value,
    animated,
    keyframes: [],
    expression: '',
    expressionEnabled: false,
  };
}
