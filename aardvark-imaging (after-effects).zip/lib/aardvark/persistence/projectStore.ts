/**
 * AARDVARK IMAGING - PROJECT PERSISTENCE & SAMPLE TEMPLATES
 * Native .aardvark project JSON format and starter projects.
 */

import {
  AardvarkProject,
  AardvarkComposition,
  AardvarkLayer,
  AardvarkAsset,
} from '../types';
import { createAnimProperty } from '../animation/evaluator';

export function createDefaultProject(): AardvarkProject {
  const compId = 'comp_main_01';
  const textLayerId = 'layer_title_01';
  const shapeLayerId = 'layer_shape_01';
  const bgLayerId = 'layer_bg_01';
  const adjustLayerId = 'layer_adj_01';
  const cameraLayerId = 'layer_cam_01';

  const defaultComp: AardvarkComposition = {
    id: compId,
    name: 'Main Composition',
    width: 1920,
    height: 1080,
    fps: 30,
    durationFrames: 150, // 5 seconds
    pixelAspectRatio: 1.0,
    colorSpace: 'sRGB',
    bitDepth: '8-bit',
    backgroundColor: '#0a0d14',
    motionBlur: {
      enabled: true,
      shutterAngle: 180,
      shutterPhase: -90,
      samples: 16,
    },
    selectedLayerIds: [textLayerId],
    layers: [
      // 1. Adjustment Layer (Top FX)
      {
        id: adjustLayerId,
        name: 'Master Grade & Glow',
        type: 'adjustment',
        inPoint: 0,
        outPoint: 150,
        startFrame: 0,
        colorTag: '#8b5cf6',
        is3D: false,
        blendMode: 'normal',
        visible: true,
        solo: false,
        locked: false,
        motionBlur: false,
        masks: [],
        transform: {
          position: createAnimProperty([960, 540, 0]),
          scale: createAnimProperty([100, 100, 100]),
          rotation: createAnimProperty([0, 0, 0]),
          orientation: createAnimProperty([0, 0, 0]),
          anchorPoint: createAnimProperty([0, 0, 0]),
          opacity: createAnimProperty(100),
        },
        effects: [
          {
            id: 'fx_glow_1',
            effectId: 'glow',
            name: 'Optical Glow',
            enabled: true,
            parameters: {
              radius: createAnimProperty(35),
              intensity: createAnimProperty(1.6),
              threshold: createAnimProperty(50),
              colorTint: createAnimProperty('#38bdf8'),
              blendMode: createAnimProperty('screen'),
            },
          },
          {
            id: 'fx_chroma_1',
            effectId: 'chromatic_aberration',
            name: 'Chromatic Aberration',
            enabled: true,
            parameters: {
              amount: createAnimProperty(4),
              angle: createAnimProperty(45),
            },
          },
          {
            id: 'fx_vignette_1',
            effectId: 'vignette',
            name: 'Vignette',
            enabled: true,
            parameters: {
              amount: createAnimProperty(45),
              radius: createAnimProperty(80),
              feather: createAnimProperty(60),
              color: createAnimProperty('#000000'),
            },
          },
        ],
      },

      // 2. 3D Camera
      {
        id: cameraLayerId,
        name: 'Cinema Camera 35mm',
        type: 'camera',
        inPoint: 0,
        outPoint: 150,
        startFrame: 0,
        colorTag: '#ef4444',
        is3D: true,
        blendMode: 'normal',
        visible: true,
        solo: false,
        locked: false,
        motionBlur: false,
        masks: [],
        cameraData: {
          cameraType: 'two-node',
          fov: 48,
          focalLength: 35,
          focusDistance: 1000,
          aperture: 2.8,
          dofEnabled: true,
          blurLevel: 50,
        },
        transform: {
          position: {
            value: [960, 540, -1100],
            animated: true,
            keyframes: [
              {
                id: 'kf_cam_1',
                frame: 0,
                value: [960, 540, -1400],
                inInterpolation: 'bezier',
                outInterpolation: 'bezier',
                outTangent: { x: 0.25, y: 0.1 },
              },
              {
                id: 'kf_cam_2',
                frame: 150,
                value: [960, 540, -900],
                inInterpolation: 'bezier',
                outInterpolation: 'bezier',
                inTangent: { x: 0.25, y: 1.0 },
              },
            ],
          },
          scale: createAnimProperty([100, 100, 100]),
          rotation: {
            value: [0, 0, 0],
            animated: true,
            keyframes: [
              { id: 'kf_rot_1', frame: 0, value: [-8, 12, -2], inInterpolation: 'bezier', outInterpolation: 'bezier' },
              { id: 'kf_rot_2', frame: 150, value: [4, -10, 2], inInterpolation: 'bezier', outInterpolation: 'bezier' },
            ],
          },
          orientation: createAnimProperty([0, 0, 0]),
          anchorPoint: createAnimProperty([960, 540, 0]),
          opacity: createAnimProperty(100),
        },
        effects: [],
      },

      // 3. Text Title (Animated 3D)
      {
        id: textLayerId,
        name: 'AARDVARK TITLE',
        type: 'text',
        inPoint: 0,
        outPoint: 150,
        startFrame: 0,
        colorTag: '#3b82f6',
        is3D: true,
        blendMode: 'normal',
        visible: true,
        solo: false,
        locked: false,
        motionBlur: true,
        masks: [],
        textData: {
          text: 'AARDVARK IMAGING',
          fontFamily: 'Inter, system-ui, sans-serif',
          fontSize: 88,
          fontWeight: '900',
          tracking: 140,
          leading: 1.1,
          alignment: 'center',
          fillColor: '#38bdf8',
          strokeColor: '#ffffff',
          strokeWidth: 2,
          strokeOverFill: false,
          perCharAnim: {
            enabled: true,
            offset: createAnimProperty(0),
            charDelay: 3,
            charScale: createAnimProperty(1),
            charOpacity: createAnimProperty(1),
          },
        },
        transform: {
          position: {
            value: [560, 480, 0],
            animated: true,
            keyframes: [
              { id: 'kf_pos_1', frame: 0, value: [560, 520, 150], inInterpolation: 'ease-out', outInterpolation: 'ease-out' },
              { id: 'kf_pos_2', frame: 60, value: [560, 480, 0], inInterpolation: 'bezier', outInterpolation: 'bezier' },
            ],
          },
          scale: createAnimProperty([100, 100, 100]),
          rotation: {
            value: [0, 0, 0],
            animated: true,
            keyframes: [
              { id: 'kf_trot_1', frame: 0, value: [15, -25, 0], inInterpolation: 'ease-out', outInterpolation: 'ease-out' },
              { id: 'kf_trot_2', frame: 75, value: [0, 0, 0], inInterpolation: 'ease-in-out', outInterpolation: 'ease-in-out' },
            ],
          },
          orientation: createAnimProperty([0, 0, 0]),
          anchorPoint: createAnimProperty([0, 0, 0]),
          opacity: {
            value: 100,
            animated: true,
            keyframes: [
              { id: 'kf_topac_1', frame: 0, value: 0, inInterpolation: 'linear', outInterpolation: 'linear' },
              { id: 'kf_topac_2', frame: 20, value: 100, inInterpolation: 'linear', outInterpolation: 'linear' },
            ],
          },
        },
        effects: [],
      },

      // 4. Vector HUD Ring & Star Shape
      {
        id: shapeLayerId,
        name: 'Cyber HUD Ring',
        type: 'shape',
        inPoint: 0,
        outPoint: 150,
        startFrame: 0,
        colorTag: '#10b981',
        is3D: true,
        blendMode: 'screen',
        visible: true,
        solo: false,
        locked: false,
        motionBlur: true,
        masks: [],
        shapeData: {
          shapeType: 'star',
          fillColor: 'rgba(56, 189, 248, 0.12)',
          fillEnabled: true,
          strokeColor: '#38bdf8',
          strokeWidth: 3,
          strokeEnabled: true,
          cornerRadius: 8,
          starPoints: 8,
          starInnerRadius: 0.65,
          trimStart: createAnimProperty(0),
          trimEnd: createAnimProperty(100),
          trimOffset: createAnimProperty(0),
          repeaterCount: 1,
          repeaterOffset: [0, 0],
          repeaterScale: [100, 100],
          repeaterRotation: 0,
        },
        transform: {
          position: createAnimProperty([960, 540, 100]),
          scale: {
            value: [140, 140, 140],
            animated: true,
            keyframes: [
              { id: 'kf_ss_1', frame: 0, value: [60, 60, 60], inInterpolation: 'ease-out', outInterpolation: 'ease-out' },
              { id: 'kf_ss_2', frame: 60, value: [140, 140, 140], inInterpolation: 'ease-out', outInterpolation: 'ease-out' },
            ],
          },
          rotation: {
            value: [0, 0, 0],
            animated: true,
            expression: '[0, 0, frame * 1.5]',
            expressionEnabled: true,
            keyframes: [],
          },
          orientation: createAnimProperty([0, 0, 0]),
          anchorPoint: createAnimProperty([0, 0, 0]),
          opacity: createAnimProperty(85),
        },
        effects: [
          {
            id: 'fx_ripple_1',
            effectId: 'ripple_wave',
            name: 'Wave Warp',
            enabled: true,
            parameters: {
              height: createAnimProperty(12),
              width: createAnimProperty(80),
              speed: createAnimProperty(3),
            },
          },
        ],
      },

      // 5. Solid Deep Background with Procedural Gradient
      {
        id: bgLayerId,
        name: 'Dark Cyber Backdrop',
        type: 'solid',
        solidColor: '#0a0d18',
        inPoint: 0,
        outPoint: 150,
        startFrame: 0,
        colorTag: '#64748b',
        is3D: false,
        blendMode: 'normal',
        visible: true,
        solo: false,
        locked: true,
        motionBlur: false,
        masks: [],
        transform: {
          position: createAnimProperty([960, 540, 0]),
          scale: createAnimProperty([100, 100, 100]),
          rotation: createAnimProperty([0, 0, 0]),
          orientation: createAnimProperty([0, 0, 0]),
          anchorPoint: createAnimProperty([0, 0, 0]),
          opacity: createAnimProperty(100),
        },
        effects: [
          {
            id: 'fx_noise_bg',
            effectId: 'fractal_noise',
            name: 'Fractal Nebulae',
            enabled: true,
            parameters: {
              scale: createAnimProperty(220),
              complexity: createAnimProperty(4),
              contrast: createAnimProperty(110),
              color1: createAnimProperty('#020617'),
              color2: createAnimProperty('#0f2444'),
            },
          },
        ],
      },
    ],
  };

  return {
    version: '1.0.0',
    id: 'proj_default_01',
    name: 'Aardvark VFX Sequence',
    settings: {
      name: 'Aardvark VFX Sequence',
      colorSpace: 'sRGB',
      bitDepth: '8-bit',
      timecodeDisplay: 'timecode',
      gpuAcceleration: true,
      cacheSizeMB: 2048,
      autosaveIntervalMinutes: 2,
    },
    assets: [
      {
        id: 'asset_banner_sample',
        name: 'Aardvark_Tech_Plate.png',
        type: 'image',
        url: 'https://picsum.photos/seed/aardvarkvfx/1920/1080',
        width: 1920,
        height: 1080,
        colorSpace: 'sRGB',
        bitDepth: '8-bit',
        fileSize: 1450200,
        mimeType: 'image/png',
        thumbnailUrl: 'https://picsum.photos/seed/aardvarkvfx/320/180',
      },
    ],
    compositions: [defaultComp],
    activeCompId: compId,
    renderQueue: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

/**
 * Serialize project to JSON string
 */
export function serializeProject(project: AardvarkProject): string {
  return JSON.stringify(project, null, 2);
}

/**
 * Deserialize and validate project JSON
 */
export function deserializeProject(jsonStr: string): AardvarkProject {
  const parsed = JSON.parse(jsonStr);
  if (!parsed.compositions || !Array.isArray(parsed.compositions)) {
    throw new Error('Invalid Aardvark project: missing compositions array.');
  }
  return parsed;
}
