/**
 * AARDVARK IMAGING - MEDIA & ASSET MANAGER
 * Asset decoding, audio waveforms, video frame extraction, and local file import.
 */

import { AardvarkAsset } from '../types';

export class MediaManager {
  private static assetCache = new Map<string, HTMLImageElement | HTMLVideoElement | HTMLCanvasElement>();
  private static audioCtx: AudioContext | null = null;

  public static getAudioContext(): AudioContext {
    if (!this.audioCtx) {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      this.audioCtx = new AudioCtxClass();
    }
    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
    return this.audioCtx;
  }

  /**
   * Preloads an image or video asset into the cache
   */
  public static async loadAsset(asset: AardvarkAsset): Promise<HTMLImageElement | HTMLVideoElement | HTMLCanvasElement> {
    if (this.assetCache.has(asset.id)) {
      return this.assetCache.get(asset.id)!;
    }

    if (asset.type === 'video') {
      return new Promise((resolve, reject) => {
        const video = document.createElement('video');
        video.crossOrigin = 'anonymous';
        video.src = asset.url;
        video.muted = true;
        video.playsInline = true;
        video.onloadeddata = () => {
          this.assetCache.set(asset.id, video);
          resolve(video);
        };
        video.onerror = () => reject(new Error(`Failed to load video asset ${asset.name}`));
      });
    }

    // Image asset
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.src = asset.url;
      img.onload = () => {
        this.assetCache.set(asset.id, img);
        resolve(img);
      };
      img.onerror = () => {
        // Create fallback gradient canvas
        const fallback = document.createElement('canvas');
        fallback.width = asset.width || 800;
        fallback.height = asset.height || 600;
        const ctx = fallback.getContext('2d');
        if (ctx) {
          ctx.fillStyle = '#1e293b';
          ctx.fillRect(0, 0, fallback.width, fallback.height);
          ctx.fillStyle = '#64748b';
          ctx.font = '24px sans-serif';
          ctx.fillText(asset.name, 40, 60);
        }
        this.assetCache.set(asset.id, fallback);
        resolve(fallback);
      };
    });
  }

  /**
   * Decodes an audio file and generates a normalized waveform array (e.g. 100 peaks)
   */
  public static async decodeAudio(file: File): Promise<{ buffer: AudioBuffer; waveform: number[]; duration: number }> {
    const ctx = this.getAudioContext();
    const arrayBuffer = await file.arrayBuffer();
    const audioBuffer = await ctx.decodeAudioData(arrayBuffer);

    // Generate waveform peak data (200 bars)
    const rawData = audioBuffer.getChannelData(0);
    const samples = 200;
    const blockSize = Math.floor(rawData.length / samples);
    const waveform: number[] = [];

    for (let i = 0; i < samples; i++) {
      let sum = 0;
      for (let j = 0; j < blockSize; j++) {
        sum += Math.abs(rawData[i * blockSize + j]);
      }
      waveform.push(sum / blockSize);
    }

    // Normalize 0 to 1
    const maxVal = Math.max(...waveform, 0.01);
    const normalizedWaveform = waveform.map((v) => v / maxVal);

    return {
      buffer: audioBuffer,
      waveform: normalizedWaveform,
      duration: audioBuffer.duration,
    };
  }

  /**
   * Reads a user-uploaded file (Image, Video, Audio, or SVG) and constructs an AardvarkAsset
   */
  public static async importFile(file: File): Promise<AardvarkAsset> {
    const id = 'asset_' + Math.random().toString(36).substring(2, 9);
    const name = file.name;
    const mimeType = file.type;
    const fileSize = file.size;

    if (file.type.startsWith('audio/')) {
      const { buffer, waveform, duration } = await this.decodeAudio(file);
      const url = URL.createObjectURL(file);
      return {
        id,
        name,
        type: 'audio',
        url,
        width: 0,
        height: 0,
        durationSeconds: duration,
        fileSize,
        mimeType,
        waveform,
      };
    }

    if (file.type.startsWith('video/')) {
      const url = URL.createObjectURL(file);
      const video = document.createElement('video');
      video.src = url;
      await new Promise((res) => {
        video.onloadedmetadata = () => res(true);
      });
      return {
        id,
        name,
        type: 'video',
        url,
        width: video.videoWidth || 1920,
        height: video.videoHeight || 1080,
        durationSeconds: video.duration || 5,
        fps: 30,
        frameCount: Math.round((video.duration || 5) * 30),
        fileSize,
        mimeType,
        thumbnailUrl: url,
      };
    }

    // Standard Image or SVG
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.src = url;
    await new Promise((res) => {
      img.onload = () => res(true);
    });

    return {
      id,
      name,
      type: file.type.includes('svg') ? 'svg' : 'image',
      url,
      width: img.naturalWidth || 1920,
      height: img.naturalHeight || 1080,
      fileSize,
      mimeType,
      thumbnailUrl: url,
    };
  }

  public static getAssetElement(assetId: string) {
    return this.assetCache.get(assetId);
  }
}
