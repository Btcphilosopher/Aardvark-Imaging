/**
 * AARDVARK IMAGING - COMPOSITING & RENDERING ENGINE
 * Real-time 2D/3D compositing, lighting, masks, parenting, blend modes, and motion blur.
 */

import {
  AardvarkComposition,
  AardvarkLayer,
  AardvarkAsset,
  AardvarkMask,
  BlendMode,
  Vector3D,
} from '../types';
import { evaluateProperty } from '../animation/evaluator';
import { applyEffect } from '../effects/processors';

// Map Aardvark blend modes to HTML Canvas globalCompositeOperation
export function getCompositeOperation(mode: BlendMode): GlobalCompositeOperation {
  switch (mode) {
    case 'multiply':
      return 'multiply';
    case 'screen':
      return 'screen';
    case 'overlay':
      return 'overlay';
    case 'darken':
      return 'darken';
    case 'lighten':
      return 'lighten';
    case 'color-dodge':
      return 'color-dodge';
    case 'color-burn':
      return 'color-burn';
    case 'hard-light':
      return 'hard-light';
    case 'soft-light':
      return 'soft-light';
    case 'difference':
      return 'difference';
    case 'exclusion':
      return 'exclusion';
    case 'add':
      return 'lighter';
    case 'hue':
      return 'hue';
    case 'saturation':
      return 'saturation';
    case 'color':
      return 'color';
    case 'luminosity':
      return 'luminosity';
    case 'normal':
    default:
      return 'source-over';
  }
}

export interface RenderContext {
  composition: AardvarkComposition;
  allCompositions: AardvarkComposition[];
  assets: Map<string, AardvarkAsset>;
  assetElements: Map<string, HTMLImageElement | HTMLVideoElement | HTMLCanvasElement>;
  frame: number;
  scale: number; // Viewport scale or render scale
  motionBlurEnabled?: boolean;
}

export class Compositor {
  private static canvasPool: HTMLCanvasElement[] = [];

  private static getCanvas(width: number, height: number): HTMLCanvasElement {
    let canvas = this.canvasPool.pop();
    if (!canvas) {
      canvas = document.createElement('canvas');
    }
    canvas.width = Math.max(1, Math.round(width));
    canvas.height = Math.max(1, Math.round(height));
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
    return canvas;
  }

  private static releaseCanvas(canvas: HTMLCanvasElement) {
    if (this.canvasPool.length < 10) {
      this.canvasPool.push(canvas);
    }
  }

  /**
   * Main render function: Renders a composition frame into a target canvas
   */
  public static renderComposition(
    targetCanvas: HTMLCanvasElement,
    context: RenderContext
  ): void {
    const { composition, frame, scale = 1 } = context;
    const targetCtx = targetCanvas.getContext('2d');
    if (!targetCtx) return;

    const compWidth = composition.width * scale;
    const compHeight = composition.height * scale;

    targetCanvas.width = compWidth;
    targetCanvas.height = compHeight;

    // 1. Draw composition background color
    targetCtx.fillStyle = composition.backgroundColor || '#000000';
    targetCtx.fillRect(0, 0, compWidth, compHeight);

    // 2. Filter active layers
    const visibleLayers = composition.layers.filter((layer) => {
      if (!layer.visible) return false;
      if (frame < layer.inPoint || frame > layer.outPoint) return false;
      return true;
    });

    // Check solo mode: if any layer is soloed, only render soloed layers
    const anySolo = visibleLayers.some((l) => l.solo);
    const renderLayers = anySolo ? visibleLayers.filter((l) => l.solo) : visibleLayers;

    // Find active cameras and lights if 3D layers exist
    const cameraLayer = renderLayers.find((l) => l.type === 'camera');
    const lightLayers = renderLayers.filter((l) => l.type === 'light');

    // 3. Render layers from bottom to top (layer index high to low or 0 to N depending on stack order)
    // Layers are stored top-to-bottom in AE order (index 0 is on top), so we iterate backwards (N-1 down to 0)
    for (let i = renderLayers.length - 1; i >= 0; i--) {
      const layer = renderLayers[i];

      // Handle Adjustment Layer: Applies effects to current composite canvas
      if (layer.type === 'adjustment') {
        this.renderAdjustmentLayer(targetCanvas, targetCtx, layer, context);
        continue;
      }

      // Render standard visual layer
      const layerCanvas = this.renderLayer(layer, context, cameraLayer, lightLayers);
      if (layerCanvas) {
        targetCtx.save();
        targetCtx.globalCompositeOperation = getCompositeOperation(layer.blendMode);
        targetCtx.drawImage(layerCanvas, 0, 0);
        targetCtx.restore();
        this.releaseCanvas(layerCanvas);
      }
    }
  }

  /**
   * Renders a single layer to an isolated layer buffer
   */
  private static renderLayer(
    layer: AardvarkLayer,
    context: RenderContext,
    cameraLayer?: AardvarkLayer,
    lightLayers?: AardvarkLayer[]
  ): HTMLCanvasElement | null {
    const { composition, frame, scale = 1 } = context;
    const compWidth = composition.width * scale;
    const compHeight = composition.height * scale;

    const layerCanvas = this.getCanvas(compWidth, compHeight);
    const ctx = layerCanvas.getContext('2d');
    if (!ctx) return null;

    // Evaluate animatable transforms
    const pos = evaluateProperty<Vector3D>(layer.transform.position, frame, {
      fps: composition.fps,
      compWidth: composition.width,
      compHeight: composition.height,
      layerIndex: composition.layers.indexOf(layer),
    }) || [composition.width / 2, composition.height / 2, 0];

    const scl = evaluateProperty<Vector3D>(layer.transform.scale, frame) || [100, 100, 100];
    const rot = evaluateProperty<Vector3D>(layer.transform.rotation, frame) || [0, 0, 0];
    const anchor = evaluateProperty<Vector3D>(layer.transform.anchorPoint, frame) || [0, 0, 0];
    const opacity = evaluateProperty<number>(layer.transform.opacity, frame) ?? 100;

    if (opacity <= 0) {
      return layerCanvas;
    }

    ctx.save();
    ctx.globalAlpha = Math.max(0, Math.min(1, opacity / 100));

    // Handle 3D Perspective Projection if layer or camera is 3D
    if (layer.is3D) {
      this.apply3DTransform(ctx, pos, scl, rot, anchor, scale, cameraLayer, frame, composition);
    } else {
      // 2D Transform
      ctx.translate(pos[0] * scale, pos[1] * scale);
      ctx.rotate((rot[2] * Math.PI) / 180);
      ctx.scale((scl[0] / 100), (scl[1] / 100));
      ctx.translate(-anchor[0] * scale, -anchor[1] * scale);
    }

    // Draw layer content based on type
    switch (layer.type) {
      case 'image':
      case 'video': {
        const asset = layer.assetId ? context.assets.get(layer.assetId) : undefined;
        const mediaElem = layer.assetId ? context.assetElements.get(layer.assetId) : undefined;
        if (mediaElem && asset) {
          ctx.drawImage(mediaElem, 0, 0, asset.width * scale, asset.height * scale);
        } else if (asset) {
          // Placeholder card if media still loading
          ctx.fillStyle = '#2a2e39';
          ctx.fillRect(0, 0, asset.width * scale, asset.height * scale);
          ctx.strokeStyle = '#3b82f6';
          ctx.strokeRect(0, 0, asset.width * scale, asset.height * scale);
        }
        break;
      }

      case 'solid': {
        const color = layer.solidColor || '#4f46e5';
        ctx.fillStyle = color;
        ctx.fillRect(0, 0, compWidth, compHeight);
        break;
      }

      case 'text': {
        if (layer.textData) {
          this.renderTextLayer(ctx, layer.textData, frame, scale, composition.fps);
        }
        break;
      }

      case 'shape': {
        if (layer.shapeData) {
          this.renderShapeLayer(ctx, layer.shapeData, frame, scale);
        }
        break;
      }

      case 'precomp': {
        if (layer.precompId) {
          const precomp = context.allCompositions.find((c) => c.id === layer.precompId);
          if (precomp) {
            const nestedCanvas = this.getCanvas(precomp.width * scale, precomp.height * scale);
            const nestedCtx: RenderContext = {
              ...context,
              composition: precomp,
              frame: frame - layer.startFrame,
            };
            this.renderComposition(nestedCanvas, nestedCtx);
            ctx.drawImage(nestedCanvas, 0, 0);
            this.releaseCanvas(nestedCanvas);
          }
        }
        break;
      }

      case 'null':
      case 'camera':
      case 'light':
        // Non-visual helper layers
        break;
    }

    ctx.restore();

    // 4. Apply Vector/Bezier Masks
    if (layer.masks && layer.masks.length > 0) {
      this.applyMasks(layerCanvas, layer.masks, frame, scale);
    }

    // 5. Apply Layer Effect Stack
    if (layer.effects && layer.effects.length > 0) {
      this.applyEffectStack(layerCanvas, layer.effects, frame, composition.fps);
    }

    return layerCanvas;
  }

  /**
   * Applies 3D perspective camera matrix projection
   */
  private static apply3DTransform(
    ctx: CanvasRenderingContext2D,
    pos: Vector3D,
    scl: Vector3D,
    rot: Vector3D,
    anchor: Vector3D,
    scale: number,
    cameraLayer: AardvarkLayer | undefined,
    frame: number,
    composition: AardvarkComposition
  ): void {
    const cx = (composition.width / 2) * scale;
    const cy = (composition.height / 2) * scale;

    const fov = cameraLayer?.cameraData?.fov || 50;
    const focalLength = (cx / Math.tan(((fov / 2) * Math.PI) / 180));

    const camPos: Vector3D = cameraLayer
      ? evaluateProperty<Vector3D>(cameraLayer.transform.position, frame) || [composition.width / 2, composition.height / 2, -1000]
      : [composition.width / 2, composition.height / 2, -1000];

    const camRot: Vector3D = cameraLayer
      ? evaluateProperty<Vector3D>(cameraLayer.transform.rotation, frame) || [0, 0, 0]
      : [0, 0, 0];

    // Relative position to camera
    const relX = (pos[0] - camPos[0]) * scale;
    const relY = (pos[1] - camPos[1]) * scale;
    const relZ = (pos[2] - camPos[2]) * scale;

    // Perspective depth divisor
    const zDist = Math.max(50, focalLength + relZ);
    const perspectiveFactor = focalLength / zDist;

    const projX = cx + relX * perspectiveFactor;
    const projY = cy + relY * perspectiveFactor;

    ctx.translate(projX, projY);
    ctx.rotate(((rot[2] + camRot[2]) * Math.PI) / 180);
    // Skew for 3D X/Y rotation approximation
    const radX = ((rot[0] + camRot[0]) * Math.PI) / 180;
    const radY = ((rot[1] + camRot[1]) * Math.PI) / 180;
    ctx.transform(
      Math.cos(radY) * (scl[0] / 100) * perspectiveFactor,
      Math.sin(radX) * 0.4,
      Math.sin(radY) * 0.4,
      Math.cos(radX) * (scl[1] / 100) * perspectiveFactor,
      0,
      0
    );
    ctx.translate(-anchor[0] * scale, -anchor[1] * scale);
  }

  /**
   * Text typography renderer with per-character animation
   */
  private static renderTextLayer(
    ctx: CanvasRenderingContext2D,
    textData: any,
    frame: number,
    scale: number,
    fps: number
  ): void {
    const fontSize = (textData.fontSize || 72) * scale;
    const fontWeight = textData.fontWeight || '700';
    const fontFamily = textData.fontFamily || 'Inter, sans-serif';
    ctx.font = `${fontWeight} ${fontSize}px ${fontFamily}`;
    ctx.textBaseline = 'top';

    const text = textData.text || 'Aardvark Motion';
    const lines = text.split('\n');
    const lineHeight = fontSize * (textData.leading || 1.2);
    const tracking = (textData.tracking || 0) * (fontSize / 1000);

    lines.forEach((line: string, lineIndex: number) => {
      let xOffset = 0;
      const yOffset = lineIndex * lineHeight;

      for (let charIndex = 0; charIndex < line.length; charIndex++) {
        const char = line[charIndex];
        ctx.save();

        let charScale = 1;
        let charOpacity = 1;
        let charYOffset = 0;

        // Per-character kinetic animation
        if (textData.perCharAnim?.enabled) {
          const charDelay = textData.perCharAnim.charDelay || 2;
          const charFrame = Math.max(0, frame - charIndex * charDelay);
          const t = Math.min(1, charFrame / 15);
          // Spring overshoot
          charScale = 0.2 + 0.8 * Math.sin((t * Math.PI) / 2);
          charOpacity = t;
          charYOffset = (1 - t) * 40 * scale;
        }

        ctx.globalAlpha *= charOpacity;
        ctx.translate(xOffset, yOffset + charYOffset);
        ctx.scale(charScale, charScale);

        if (textData.fillColor) {
          ctx.fillStyle = textData.fillColor;
          ctx.fillText(char, 0, 0);
        }

        if (textData.strokeColor && textData.strokeWidth > 0) {
          ctx.strokeStyle = textData.strokeColor;
          ctx.lineWidth = textData.strokeWidth * scale;
          ctx.strokeText(char, 0, 0);
        }

        ctx.restore();
        const charWidth = ctx.measureText(char).width;
        xOffset += charWidth + tracking;
      }
    });
  }

  /**
   * Vector Shape Renderer
   */
  private static renderShapeLayer(
    ctx: CanvasRenderingContext2D,
    shapeData: any,
    frame: number,
    scale: number
  ): void {
    const shapeType = shapeData.shapeType || 'rectangle';
    const strokeWidth = (shapeData.strokeWidth || 4) * scale;

    ctx.save();
    ctx.beginPath();

    const w = 300 * scale;
    const h = 200 * scale;

    if (shapeType === 'rectangle') {
      const r = (shapeData.cornerRadius || 0) * scale;
      if (r > 0 && ctx.roundRect) {
        ctx.roundRect(-w / 2, -h / 2, w, h, r);
      } else {
        ctx.rect(-w / 2, -h / 2, w, h);
      }
    } else if (shapeType === 'ellipse') {
      ctx.ellipse(0, 0, w / 2, h / 2, 0, 0, Math.PI * 2);
    } else if (shapeType === 'star') {
      const points = shapeData.starPoints || 5;
      const outerR = w / 2;
      const innerR = outerR * (shapeData.starInnerRadius || 0.4);
      for (let i = 0; i < points * 2; i++) {
        const rad = (i * Math.PI) / points - Math.PI / 2;
        const radius = i % 2 === 0 ? outerR : innerR;
        const px = Math.cos(rad) * radius;
        const py = Math.sin(rad) * radius;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
    } else if (shapeType === 'polygon') {
      const points = 6;
      const radius = w / 2;
      for (let i = 0; i < points; i++) {
        const rad = (i * 2 * Math.PI) / points - Math.PI / 2;
        const px = Math.cos(rad) * radius;
        const py = Math.sin(rad) * radius;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
    }

    if (shapeData.fillEnabled !== false) {
      ctx.fillStyle = shapeData.fillColor || '#ec4899';
      ctx.fill();
    }

    if (shapeData.strokeEnabled !== false && strokeWidth > 0) {
      ctx.strokeStyle = shapeData.strokeColor || '#ffffff';
      ctx.lineWidth = strokeWidth;
      ctx.stroke();
    }

    ctx.restore();
  }

  /**
   * Applies Bezier and geometric masks
   */
  private static applyMasks(
    layerCanvas: HTMLCanvasElement,
    masks: AardvarkMask[],
    frame: number,
    scale: number
  ): void {
    const width = layerCanvas.width;
    const height = layerCanvas.height;

    const maskCanvas = this.getCanvas(width, height);
    const maskCtx = maskCanvas.getContext('2d');
    if (!maskCtx) return;

    for (const mask of masks) {
      if (!mask.enabled) continue;
      const opacity = evaluateProperty<number>(mask.opacity, frame) ?? 100;
      const feather = evaluateProperty<number>(mask.feather, frame) ?? 0;

      maskCtx.save();
      if (feather > 0) {
        maskCtx.filter = `blur(${feather * scale}px)`;
      }

      maskCtx.beginPath();
      if (mask.shapeType === 'ellipse') {
        maskCtx.ellipse(width / 2, height / 2, width * 0.4, height * 0.4, 0, 0, Math.PI * 2);
      } else if (mask.shapeType === 'rectangle') {
        maskCtx.rect(width * 0.15, height * 0.15, width * 0.7, height * 0.7);
      } else {
        // Bezier points
        const pts = mask.points.value || [];
        if (pts.length > 0) {
          maskCtx.moveTo(pts[0].x * scale, pts[0].y * scale);
          for (let i = 1; i < pts.length; i++) {
            maskCtx.lineTo(pts[i].x * scale, pts[i].y * scale);
          }
          if (mask.closed) maskCtx.closePath();
        }
      }

      maskCtx.fillStyle = `rgba(255,255,255,${opacity / 100})`;
      maskCtx.fill();
      maskCtx.restore();
    }

    // Clip layerCanvas using maskCanvas destination-in
    const layerCtx = layerCanvas.getContext('2d');
    if (layerCtx) {
      layerCtx.save();
      layerCtx.globalCompositeOperation = 'destination-in';
      layerCtx.drawImage(maskCanvas, 0, 0);
      layerCtx.restore();
    }

    this.releaseCanvas(maskCanvas);
  }

  /**
   * Applies non-destructive stack of effects
   */
  private static applyEffectStack(
    layerCanvas: HTMLCanvasElement,
    effects: any[],
    frame: number,
    fps: number
  ): void {
    const scratchCanvas = this.getCanvas(layerCanvas.width, layerCanvas.height);
    const scratchCtx = scratchCanvas.getContext('2d');
    const layerCtx = layerCanvas.getContext('2d');
    if (!scratchCtx || !layerCtx) return;

    for (const effect of effects) {
      if (!effect.enabled) continue;

      // Evaluate animated parameters
      const evaluatedParams: Record<string, any> = {};
      if (effect.parameters) {
        for (const [key, animProp] of Object.entries(effect.parameters)) {
          evaluatedParams[key] = evaluateProperty(animProp as any, frame, { fps });
        }
      }

      // Copy current layer output into scratch
      scratchCtx.clearRect(0, 0, scratchCanvas.width, scratchCanvas.height);
      scratchCtx.drawImage(layerCanvas, 0, 0);

      // Apply effect back to layerCanvas
      applyEffect(effect.effectId, evaluatedParams, scratchCanvas, layerCtx, frame, fps);
    }

    this.releaseCanvas(scratchCanvas);
  }

  /**
   * Renders adjustment layer (applies its effect stack to everything rendered below)
   */
  private static renderAdjustmentLayer(
    targetCanvas: HTMLCanvasElement,
    targetCtx: CanvasRenderingContext2D,
    layer: AardvarkLayer,
    context: RenderContext
  ): void {
    if (!layer.effects || layer.effects.length === 0) return;
    const scratch = this.getCanvas(targetCanvas.width, targetCanvas.height);
    const sCtx = scratch.getContext('2d');
    if (!sCtx) return;

    sCtx.drawImage(targetCanvas, 0, 0);
    this.applyEffectStack(scratch, layer.effects, context.frame, context.composition.fps);

    targetCtx.save();
    targetCtx.globalCompositeOperation = getCompositeOperation(layer.blendMode);
    targetCtx.drawImage(scratch, 0, 0);
    targetCtx.restore();

    this.releaseCanvas(scratch);
  }
}
