/**
 * AARDVARK IMAGING - CORE PROJECT MODEL & TYPE DEFINITIONS
 * Professional Motion Graphics, Compositing & Visual Effects
 */

export type ColorSpace = 'sRGB' | 'Rec.709' | 'Display P3' | 'Rec.2020' | 'ACEScg' | 'Linear sRGB';
export type BitDepth = '8-bit' | '16-bit float' | '32-bit float';
export type BlendMode =
  | 'normal'
  | 'multiply'
  | 'screen'
  | 'overlay'
  | 'darken'
  | 'lighten'
  | 'color-dodge'
  | 'color-burn'
  | 'hard-light'
  | 'soft-light'
  | 'difference'
  | 'exclusion'
  | 'add'
  | 'hue'
  | 'saturation'
  | 'color'
  | 'luminosity';

export type KeyframeInterpolation = 'linear' | 'hold' | 'bezier' | 'ease-in' | 'ease-out' | 'ease-in-out';

export interface KeyframeTangent {
  x: number; // Normalized horizontal time distance (-1 to 1 or frame delta)
  y: number; // Value influence delta
}

export interface Keyframe<T = number> {
  id: string;
  frame: number;
  value: T;
  inInterpolation: KeyframeInterpolation;
  outInterpolation: KeyframeInterpolation;
  inTangent?: KeyframeTangent;
  outTangent?: KeyframeTangent;
}

export interface AnimatableProperty<T = number> {
  value: T;
  animated: boolean;
  keyframes: Keyframe<T>[];
  expression?: string;
  expressionEnabled?: boolean;
}

export type Vector2D = [number, number];
export type Vector3D = [number, number, number];
export type ColorRGBA = [number, number, number, number]; // 0-1 range or 0-255

export interface LayerTransform {
  position: AnimatableProperty<Vector3D>;
  scale: AnimatableProperty<Vector3D>;
  rotation: AnimatableProperty<Vector3D>; // [X, Y, Z] Euler angles in degrees
  orientation: AnimatableProperty<Vector3D>;
  anchorPoint: AnimatableProperty<Vector3D>;
  opacity: AnimatableProperty<number>; // 0 to 100
}

export type MaskMode = 'add' | 'subtract' | 'intersect' | 'difference' | 'none';
export type MaskShapeType = 'bezier' | 'rectangle' | 'ellipse' | 'polygon';

export interface MaskPoint {
  x: number;
  y: number;
  inHandle?: [number, number];
  outHandle?: [number, number];
}

export interface AardvarkMask {
  id: string;
  name: string;
  enabled: boolean;
  mode: MaskMode;
  shapeType: MaskShapeType;
  points: AnimatableProperty<MaskPoint[]>;
  closed: boolean;
  feather: AnimatableProperty<number>; // px
  expansion: AnimatableProperty<number>; // px
  opacity: AnimatableProperty<number>; // 0 - 100
  inverted: boolean;
}

export interface EffectParameterDef {
  key: string;
  name: string;
  type: 'float' | 'int' | 'color' | 'point' | 'select' | 'boolean' | 'curve' | 'angle';
  defaultValue: any;
  min?: number;
  max?: number;
  step?: number;
  options?: { label: string; value: any }[];
}

export interface EffectDefinition {
  id: string;
  name: string;
  category: 'Blur' | 'Color' | 'Distortion' | 'Stylize' | 'Keying' | 'Generative';
  description: string;
  parameters: EffectParameterDef[];
}

export interface AardvarkLayerEffect {
  id: string;
  effectId: string;
  name: string;
  enabled: boolean;
  parameters: Record<string, AnimatableProperty<any>>;
}

export type LayerType =
  | 'image'
  | 'video'
  | 'solid'
  | 'text'
  | 'shape'
  | 'adjustment'
  | 'camera'
  | 'light'
  | 'null'
  | 'precomp';

export interface TextLayerData {
  text: string;
  fontFamily: string;
  fontSize: number;
  fontWeight: string;
  tracking: number; // Letter-spacing in em/1000
  leading: number; // Line-height multiplier
  alignment: 'left' | 'center' | 'right' | 'justify';
  fillColor: string;
  strokeColor: string;
  strokeWidth: number;
  strokeOverFill: boolean;
  perCharAnim?: {
    enabled: boolean;
    offset: AnimatableProperty<number>;
    charDelay: number;
    charScale: AnimatableProperty<number>;
    charOpacity: AnimatableProperty<number>;
  };
}

export type ShapeType = 'rectangle' | 'ellipse' | 'polygon' | 'star' | 'line' | 'path';

export interface ShapeLayerData {
  shapeType: ShapeType;
  fillColor: string;
  fillEnabled: boolean;
  strokeColor: string;
  strokeWidth: number;
  strokeEnabled: boolean;
  strokeDash?: number[];
  cornerRadius: number;
  points?: Vector2D[];
  starPoints?: number;
  starInnerRadius?: number;
  trimStart: AnimatableProperty<number>; // 0 - 100
  trimEnd: AnimatableProperty<number>; // 0 - 100
  trimOffset: AnimatableProperty<number>; // 0 - 360 deg
  repeaterCount: number;
  repeaterOffset: Vector2D;
  repeaterScale: Vector2D;
  repeaterRotation: number;
}

export interface CameraLayerData {
  cameraType: 'one-node' | 'two-node';
  fov: number; // degrees
  focalLength: number; // mm
  focusDistance: number; // px
  aperture: number; // mm
  dofEnabled: boolean;
  blurLevel: number; // %
}

export interface LightLayerData {
  lightType: 'point' | 'directional' | 'spot' | 'ambient';
  color: string;
  intensity: number; // 0 - 500%
  radius: number; // px
  coneAngle?: number; // deg for spot
  coneFeather?: number; // %
  castShadows: boolean;
  shadowDarkness: number;
}

export interface AardvarkLayer {
  id: string;
  name: string;
  type: LayerType;
  assetId?: string;
  precompId?: string;
  inPoint: number; // frame
  outPoint: number; // frame
  startFrame: number; // frame offset
  transform: LayerTransform;
  is3D: boolean;
  blendMode: BlendMode;
  visible: boolean;
  solo: boolean;
  locked: boolean;
  motionBlur: boolean;
  parentId?: string;
  colorTag: string;
  masks: AardvarkMask[];
  effects: AardvarkLayerEffect[];
  // Layer-specific data
  solidColor?: string;
  textData?: TextLayerData;
  shapeData?: ShapeLayerData;
  cameraData?: CameraLayerData;
  lightData?: LightLayerData;
}

export interface MotionBlurSettings {
  enabled: boolean;
  shutterAngle: number; // 0 to 720 deg (180 is default standard)
  shutterPhase: number; // -360 to 360
  samples: number; // 4 to 64
}

export interface AardvarkComposition {
  id: string;
  name: string;
  width: number;
  height: number;
  fps: number;
  durationFrames: number;
  pixelAspectRatio: number; // 1.0 (square)
  colorSpace: ColorSpace;
  bitDepth: BitDepth;
  backgroundColor: string;
  motionBlur: MotionBlurSettings;
  layers: AardvarkLayer[];
  selectedLayerIds: string[];
}

export interface AardvarkAsset {
  id: string;
  name: string;
  type: 'image' | 'video' | 'audio' | 'sequence' | 'svg' | 'solid';
  url: string;
  width: number;
  height: number;
  durationSeconds?: number;
  fps?: number;
  frameCount?: number;
  colorSpace?: ColorSpace;
  bitDepth?: BitDepth;
  fileSize?: number; // bytes
  mimeType?: string;
  thumbnailUrl?: string;
  audioBuffer?: AudioBuffer;
  waveform?: number[];
  metadata?: Record<string, any>;
}

export type RenderFormat = 'webm' | 'mp4' | 'png-sequence' | 'single-png' | 'gif';
export type RenderStatus = 'queued' | 'rendering' | 'completed' | 'paused' | 'failed' | 'cancelled';

export interface RenderJob {
  id: string;
  compositionId: string;
  compositionName: string;
  outputName: string;
  format: RenderFormat;
  resolutionScale: 1 | 0.5 | 0.25;
  startFrame: number;
  endFrame: number;
  fps: number;
  quality: 'draft' | 'good' | 'best';
  colorSpace: ColorSpace;
  status: RenderStatus;
  progress: number; // 0 to 100
  currentFrame: number;
  totalFrames: number;
  startTime?: number;
  elapsedTimeSeconds?: number;
  estimatedRemainingSeconds?: number;
  outputUrl?: string;
  error?: string;
}

export interface ProjectSettings {
  name: string;
  colorSpace: ColorSpace;
  bitDepth: BitDepth;
  timecodeDisplay: 'timecode' | 'frames';
  gpuAcceleration: boolean;
  cacheSizeMB: number;
  autosaveIntervalMinutes: number;
}

export interface AardvarkProject {
  version: string;
  id: string;
  name: string;
  settings: ProjectSettings;
  assets: AardvarkAsset[];
  compositions: AardvarkComposition[];
  activeCompId: string;
  renderQueue: RenderJob[];
  createdAt: string;
  updatedAt: string;
}
