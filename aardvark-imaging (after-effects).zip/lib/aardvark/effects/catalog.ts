/**
 * AARDVARK IMAGING - EFFECT DEFINITIONS CATALOG
 * Plugin-oriented architecture with full parameter schemas.
 */

import { EffectDefinition } from '../types';

export const EFFECT_CATALOG: EffectDefinition[] = [
  // ================= BLUR =================
  {
    id: 'gaussian_blur',
    name: 'Gaussian Blur',
    category: 'Blur',
    description: 'Blurs and softens the image using a multi-pass separable Gaussian kernel.',
    parameters: [
      { key: 'radius', name: 'Blur Radius', type: 'float', defaultValue: 15, min: 0, max: 150, step: 0.5 },
      {
        key: 'direction',
        name: 'Direction',
        type: 'select',
        defaultValue: 'both',
        options: [
          { label: 'Horizontal and Vertical', value: 'both' },
          { label: 'Horizontal Only', value: 'horizontal' },
          { label: 'Vertical Only', value: 'vertical' },
        ],
      },
      { key: 'repeatEdgePixels', name: 'Repeat Edge Pixels', type: 'boolean', defaultValue: true },
    ],
  },
  {
    id: 'directional_blur',
    name: 'Directional Blur',
    category: 'Blur',
    description: 'Blurs pixels along a specified angular direction vector.',
    parameters: [
      { key: 'length', name: 'Blur Length', type: 'float', defaultValue: 25, min: 0, max: 150, step: 1 },
      { key: 'angle', name: 'Direction Angle', type: 'angle', defaultValue: 45, min: 0, max: 360, step: 1 },
    ],
  },
  {
    id: 'radial_blur',
    name: 'Radial / Zoom Blur',
    category: 'Blur',
    description: 'Creates zoom or spin blur radiating from a focal center point.',
    parameters: [
      { key: 'amount', name: 'Amount', type: 'float', defaultValue: 20, min: 0, max: 100, step: 1 },
      {
        key: 'type',
        name: 'Type',
        type: 'select',
        defaultValue: 'zoom',
        options: [
          { label: 'Zoom Blur', value: 'zoom' },
          { label: 'Spin Blur', value: 'spin' },
        ],
      },
      { key: 'centerX', name: 'Center X', type: 'float', defaultValue: 0.5, min: 0, max: 1, step: 0.01 },
      { key: 'centerY', name: 'Center Y', type: 'float', defaultValue: 0.5, min: 0, max: 1, step: 0.01 },
    ],
  },

  // ================= COLOR =================
  {
    id: 'exposure',
    name: 'Exposure',
    category: 'Color',
    description: 'Adjusts tonal exposure in photographic stops with offset and gamma correction.',
    parameters: [
      { key: 'exposure', name: 'Exposure (Stops)', type: 'float', defaultValue: 0, min: -5, max: 5, step: 0.05 },
      { key: 'offset', name: 'Offset', type: 'float', defaultValue: 0, min: -0.5, max: 0.5, step: 0.005 },
      { key: 'gamma', name: 'Gamma Correction', type: 'float', defaultValue: 1.0, min: 0.2, max: 3.0, step: 0.05 },
    ],
  },
  {
    id: 'brightness_contrast',
    name: 'Brightness & Contrast',
    category: 'Color',
    description: 'Adjusts the luminance and dynamic range of the layer.',
    parameters: [
      { key: 'brightness', name: 'Brightness', type: 'float', defaultValue: 0, min: -100, max: 100, step: 1 },
      { key: 'contrast', name: 'Contrast', type: 'float', defaultValue: 0, min: -100, max: 100, step: 1 },
      { key: 'useLegacy', name: 'Use Legacy Algorithm', type: 'boolean', defaultValue: false },
    ],
  },
  {
    id: 'hue_saturation',
    name: 'Hue / Saturation',
    category: 'Color',
    description: 'Modifies master or individual color range hue, saturation, and lightness.',
    parameters: [
      { key: 'hue', name: 'Master Hue', type: 'float', defaultValue: 0, min: -180, max: 180, step: 1 },
      { key: 'saturation', name: 'Master Saturation', type: 'float', defaultValue: 0, min: -100, max: 100, step: 1 },
      { key: 'lightness', name: 'Master Lightness', type: 'float', defaultValue: 0, min: -100, max: 100, step: 1 },
      { key: 'colorize', name: 'Colorize Mode', type: 'boolean', defaultValue: false },
      { key: 'colorizeHue', name: 'Colorize Hue', type: 'float', defaultValue: 30, min: 0, max: 360, step: 1 },
    ],
  },
  {
    id: 'levels',
    name: 'Levels',
    category: 'Color',
    description: 'Compresses or expands tonal ranges via input/output black, white, and gamma.',
    parameters: [
      { key: 'inputBlack', name: 'Input Black', type: 'float', defaultValue: 0, min: 0, max: 255, step: 1 },
      { key: 'inputWhite', name: 'Input White', type: 'float', defaultValue: 255, min: 0, max: 255, step: 1 },
      { key: 'gamma', name: 'Input Gamma', type: 'float', defaultValue: 1.0, min: 0.1, max: 4.0, step: 0.05 },
      { key: 'outputBlack', name: 'Output Black', type: 'float', defaultValue: 0, min: 0, max: 255, step: 1 },
      { key: 'outputWhite', name: 'Output White', type: 'float', defaultValue: 255, min: 0, max: 255, step: 1 },
    ],
  },
  {
    id: 'curves',
    name: 'Curves',
    category: 'Color',
    description: 'Precise spline curve tonal adjustment for RGB, Red, Green, and Blue channels.',
    parameters: [
      { key: 'contrastS', name: 'S-Curve Contrast', type: 'float', defaultValue: 0, min: -50, max: 50, step: 1 },
      { key: 'redLift', name: 'Red Channel Lift', type: 'float', defaultValue: 0, min: -50, max: 50, step: 1 },
      { key: 'greenLift', name: 'Green Channel Lift', type: 'float', defaultValue: 0, min: -50, max: 50, step: 1 },
      { key: 'blueLift', name: 'Blue Channel Lift', type: 'float', defaultValue: 0, min: -50, max: 50, step: 1 },
    ],
  },
  {
    id: 'color_balance',
    name: 'Color Balance',
    category: 'Color',
    description: 'Adjusts RGB color balance in Shadows, Midtones, and Highlights separately.',
    parameters: [
      { key: 'shadowRed', name: 'Shadow Red Balance', type: 'float', defaultValue: 0, min: -100, max: 100, step: 1 },
      { key: 'shadowGreen', name: 'Shadow Green Balance', type: 'float', defaultValue: 0, min: -100, max: 100, step: 1 },
      { key: 'shadowBlue', name: 'Shadow Blue Balance', type: 'float', defaultValue: 0, min: -100, max: 100, step: 1 },
      { key: 'midRed', name: 'Midtone Red Balance', type: 'float', defaultValue: 0, min: -100, max: 100, step: 1 },
      { key: 'midGreen', name: 'Midtone Green Balance', type: 'float', defaultValue: 0, min: -100, max: 100, step: 1 },
      { key: 'midBlue', name: 'Midtone Blue Balance', type: 'float', defaultValue: 0, min: -100, max: 100, step: 1 },
      { key: 'highRed', name: 'Highlight Red Balance', type: 'float', defaultValue: 0, min: -100, max: 100, step: 1 },
      { key: 'highGreen', name: 'Highlight Green Balance', type: 'float', defaultValue: 0, min: -100, max: 100, step: 1 },
      { key: 'highBlue', name: 'Highlight Blue Balance', type: 'float', defaultValue: 0, min: -100, max: 100, step: 1 },
      { key: 'preserveLuminosity', name: 'Preserve Luminosity', type: 'boolean', defaultValue: true },
    ],
  },
  {
    id: 'temperature_tint',
    name: 'Temperature & Tint',
    category: 'Color',
    description: 'Photographic white balance adjustment with Kelvin warmth and green/magenta tint.',
    parameters: [
      { key: 'temperature', name: 'Temperature (Warm/Cool)', type: 'float', defaultValue: 0, min: -100, max: 100, step: 1 },
      { key: 'tint', name: 'Tint (Green/Magenta)', type: 'float', defaultValue: 0, min: -100, max: 100, step: 1 },
    ],
  },
  {
    id: 'threshold',
    name: 'Threshold',
    category: 'Color',
    description: 'Converts grayscale image into high-contrast black-and-white mask at threshold.',
    parameters: [
      { key: 'level', name: 'Threshold Level', type: 'float', defaultValue: 128, min: 1, max: 254, step: 1 },
    ],
  },
  {
    id: 'invert',
    name: 'Invert Color',
    category: 'Color',
    description: 'Inverts RGB colors and optionally alpha channel.',
    parameters: [
      { key: 'invertRGB', name: 'Invert RGB', type: 'boolean', defaultValue: true },
      { key: 'invertAlpha', name: 'Invert Alpha', type: 'boolean', defaultValue: false },
      { key: 'blend', name: 'Blend With Original (%)', type: 'float', defaultValue: 100, min: 0, max: 100, step: 1 },
    ],
  },

  // ================= STYLIZE =================
  {
    id: 'glow',
    name: 'Optical Glow / Bloom',
    category: 'Stylize',
    description: 'Simulates lens bloom and radiant diffusion around bright luminance highlights.',
    parameters: [
      { key: 'threshold', name: 'Glow Threshold', type: 'float', defaultValue: 60, min: 0, max: 100, step: 1 },
      { key: 'radius', name: 'Glow Radius', type: 'float', defaultValue: 30, min: 1, max: 150, step: 1 },
      { key: 'intensity', name: 'Glow Intensity', type: 'float', defaultValue: 1.5, min: 0.1, max: 5.0, step: 0.1 },
      { key: 'colorTint', name: 'Glow Color Tint', type: 'color', defaultValue: '#ffffff' },
      {
        key: 'blendMode',
        name: 'Composite Mode',
        type: 'select',
        defaultValue: 'screen',
        options: [
          { label: 'Screen', value: 'screen' },
          { label: 'Add (Linear)', value: 'add' },
          { label: 'Glow Only (A & B)', value: 'only' },
        ],
      },
    ],
  },
  {
    id: 'chromatic_aberration',
    name: 'Chromatic Aberration',
    category: 'Stylize',
    description: 'Separates RGB spectrum channels simulating optical lens dispersion.',
    parameters: [
      { key: 'amount', name: 'Aberration Distance', type: 'float', defaultValue: 8, min: 0, max: 50, step: 0.5 },
      { key: 'angle', name: 'Separation Angle', type: 'angle', defaultValue: 0, min: 0, max: 360, step: 1 },
      { key: 'radial', name: 'Radial Lens Mode', type: 'boolean', defaultValue: true },
    ],
  },
  {
    id: 'edge_detection',
    name: 'Find Edges / Sobel',
    category: 'Stylize',
    description: 'High-contrast edge detection filter with gradient direction extraction.',
    parameters: [
      { key: 'intensity', name: 'Edge Intensity', type: 'float', defaultValue: 100, min: 0, max: 300, step: 1 },
      { key: 'invert', name: 'Invert Edges (Dark on Light)', type: 'boolean', defaultValue: false },
    ],
  },
  {
    id: 'vignette',
    name: 'Vignette',
    category: 'Stylize',
    description: 'Applies smooth photographic lens corner falloff and edge shading.',
    parameters: [
      { key: 'amount', name: 'Amount', type: 'float', defaultValue: 50, min: 0, max: 100, step: 1 },
      { key: 'radius', name: 'Radius / Size', type: 'float', defaultValue: 75, min: 10, max: 150, step: 1 },
      { key: 'feather', name: 'Feather Softness', type: 'float', defaultValue: 60, min: 10, max: 100, step: 1 },
      { key: 'color', name: 'Vignette Color', type: 'color', defaultValue: '#000000' },
    ],
  },
  {
    id: 'noise_grain',
    name: 'Film Grain & Noise',
    category: 'Stylize',
    description: 'Adds procedural 35mm film grain or digital sensor noise.',
    parameters: [
      { key: 'amount', name: 'Noise Amount (%)', type: 'float', defaultValue: 15, min: 0, max: 100, step: 1 },
      { key: 'monochrome', name: 'Monochromatic Grain', type: 'boolean', defaultValue: true },
      { key: 'animated', name: 'Animate Seed Per Frame', type: 'boolean', defaultValue: true },
    ],
  },

  // ================= DISTORTION =================
  {
    id: 'displacement_map',
    name: 'Displacement / Glitch',
    category: 'Distortion',
    description: 'Distorts layer pixels horizontally and vertically via procedural noise or channel values.',
    parameters: [
      { key: 'maxHorizontal', name: 'Max Horiz Displacement', type: 'float', defaultValue: 25, min: -150, max: 150, step: 1 },
      { key: 'maxVertical', name: 'Max Vert Displacement', type: 'float', defaultValue: 0, min: -150, max: 150, step: 1 },
      { key: 'frequency', name: 'Warp Frequency', type: 'float', defaultValue: 4, min: 0.5, max: 20, step: 0.1 },
    ],
  },
  {
    id: 'ripple_wave',
    name: 'Wave Warp / Ripple',
    category: 'Distortion',
    description: 'Simulates fluid sinusoidal wave displacement across the image plane.',
    parameters: [
      { key: 'height', name: 'Wave Height (Amplitude)', type: 'float', defaultValue: 15, min: 0, max: 100, step: 1 },
      { key: 'width', name: 'Wave Width (Wavelength)', type: 'float', defaultValue: 60, min: 5, max: 300, step: 1 },
      { key: 'speed', name: 'Wave Speed', type: 'float', defaultValue: 2.0, min: -10, max: 10, step: 0.1 },
      { key: 'direction', name: 'Wave Direction (Deg)', type: 'angle', defaultValue: 0, min: 0, max: 360, step: 1 },
    ],
  },
  {
    id: 'lens_distortion',
    name: 'Lens Distortion / Bulge',
    category: 'Distortion',
    description: 'Applies spherical barrel or pincushion optical lens curvature.',
    parameters: [
      { key: 'curvature', name: 'Curvature (Barrel/Pincushion)', type: 'float', defaultValue: 20, min: -100, max: 100, step: 1 },
      { key: 'centerX', name: 'Optical Center X', type: 'float', defaultValue: 0.5, min: 0, max: 1, step: 0.01 },
      { key: 'centerY', name: 'Optical Center Y', type: 'float', defaultValue: 0.5, min: 0, max: 1, step: 0.01 },
    ],
  },

  // ================= KEYING =================
  {
    id: 'chroma_key',
    name: 'Chroma Key (Green/Blue Screen)',
    category: 'Keying',
    description: 'Extracts subjects from green or blue cyclorama backdrops with spill suppression.',
    parameters: [
      { key: 'keyColor', name: 'Key Color', type: 'color', defaultValue: '#00ff00' },
      { key: 'tolerance', name: 'Color Tolerance', type: 'float', defaultValue: 40, min: 0, max: 100, step: 1 },
      { key: 'softness', name: 'Edge Softness', type: 'float', defaultValue: 20, min: 0, max: 100, step: 1 },
      { key: 'spillSuppression', name: 'Spill Suppression (%)', type: 'float', defaultValue: 75, min: 0, max: 100, step: 1 },
      { key: 'edgeChoke', name: 'Edge Choke (px)', type: 'float', defaultValue: 0, min: -10, max: 10, step: 0.5 },
    ],
  },
  {
    id: 'luma_key',
    name: 'Luma Key',
    category: 'Keying',
    description: 'Keys out regions based on brightness thresholds (e.g. black fire/smoke composites).',
    parameters: [
      { key: 'threshold', name: 'Luma Threshold', type: 'float', defaultValue: 25, min: 0, max: 255, step: 1 },
      { key: 'tolerance', name: 'Tolerance', type: 'float', defaultValue: 20, min: 0, max: 100, step: 1 },
      {
        key: 'keyType',
        name: 'Key Out',
        type: 'select',
        defaultValue: 'darker',
        options: [
          { label: 'Key Darker (Key Black)', value: 'darker' },
          { label: 'Key Brighter (Key White)', value: 'brighter' },
        ],
      },
    ],
  },

  // ================= GENERATIVE =================
  {
    id: 'fractal_noise',
    name: 'Fractal Noise',
    category: 'Generative',
    description: 'Generates procedural multi-octave Perlin/Simplex turbulence textures.',
    parameters: [
      { key: 'scale', name: 'Noise Scale', type: 'float', defaultValue: 100, min: 10, max: 500, step: 5 },
      { key: 'complexity', name: 'Complexity (Octaves)', type: 'int', defaultValue: 4, min: 1, max: 6, step: 1 },
      { key: 'contrast', name: 'Noise Contrast', type: 'float', defaultValue: 100, min: 0, max: 200, step: 1 },
      { key: 'brightness', name: 'Noise Brightness', type: 'float', defaultValue: 0, min: -100, max: 100, step: 1 },
      { key: 'evolution', name: 'Evolution (Cycle)', type: 'angle', defaultValue: 0, min: 0, max: 1440, step: 1 },
      { key: 'color1', name: 'Low Color', type: 'color', defaultValue: '#000000' },
      { key: 'color2', name: 'High Color', type: 'color', defaultValue: '#ffffff' },
    ],
  },
  {
    id: 'gradient_ramp',
    name: 'Gradient Ramp',
    category: 'Generative',
    description: 'Generates linear or radial multi-point spectral color gradients.',
    parameters: [
      { key: 'colorStart', name: 'Start Color', type: 'color', defaultValue: '#ff4b2b' },
      { key: 'colorEnd', name: 'End Color', type: 'color', defaultValue: '#ff416c' },
      {
        key: 'shape',
        name: 'Ramp Shape',
        type: 'select',
        defaultValue: 'linear',
        options: [
          { label: 'Linear Ramp', value: 'linear' },
          { label: 'Radial Ramp', value: 'radial' },
        ],
      },
      { key: 'angle', name: 'Linear Angle', type: 'angle', defaultValue: 90, min: 0, max: 360, step: 1 },
      { key: 'blend', name: 'Blend With Original (%)', type: 'float', defaultValue: 0, min: 0, max: 100, step: 1 },
    ],
  },
];
