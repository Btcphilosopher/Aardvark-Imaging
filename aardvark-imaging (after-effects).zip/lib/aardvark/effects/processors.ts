/**
 * AARDVARK IMAGING - EFFECT PROCESSORS ENGINE
 * High-performance non-destructive pixel and buffer processors.
 */

// Helper to parse hex colors to RGB
export function hexToRgb(hex: string): [number, number, number] {
  let clean = hex.replace('#', '');
  if (clean.length === 3) {
    clean = clean.split('').map((c) => c + c).join('');
  }
  const num = parseInt(clean, 16);
  return [(num >> 16) & 255, (num >> 8) & 255, num & 255];
}

// 2D Simplex/Perlin noise helper for fractal generation & displacement
function fade(t: number) {
  return t * t * t * (t * (t * 6 - 15) + 10);
}
function grad(hash: number, x: number, y: number) {
  const h = hash & 7;
  const u = h < 4 ? x : y;
  const v = h < 4 ? y : x;
  return ((h & 1) === 0 ? u : -u) + ((h & 2) === 0 ? v : -v);
}
const PERM_TABLE = new Uint8Array(512);
for (let i = 0; i < 256; i++) PERM_TABLE[i] = Math.floor(Math.sin(i * 12.9898) * 100000) & 255;
for (let i = 0; i < 256; i++) PERM_TABLE[256 + i] = PERM_TABLE[i];

function perlin2D(x: number, y: number): number {
  const X = Math.floor(x) & 255;
  const Y = Math.floor(y) & 255;
  const xf = x - Math.floor(x);
  const yf = y - Math.floor(y);
  const u = fade(xf);
  const v = fade(yf);
  const aa = PERM_TABLE[PERM_TABLE[X] + Y];
  const ab = PERM_TABLE[PERM_TABLE[X] + Y + 1];
  const ba = PERM_TABLE[PERM_TABLE[X + 1] + Y];
  const bb = PERM_TABLE[PERM_TABLE[X + 1] + Y + 1];
  const x1 = grad(aa, xf, yf) * (1 - u) + grad(ba, xf - 1, yf) * u;
  const x2 = grad(ab, xf, yf - 1) * (1 - u) + grad(bb, xf - 1, yf - 1) * u;
  return x1 * (1 - v) + x2 * v;
}

/**
 * Applies an individual effect to a canvas context / image buffer
 */
export function applyEffect(
  effectId: string,
  params: Record<string, any>,
  sourceCanvas: HTMLCanvasElement | OffscreenCanvas,
  targetCtx: CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D,
  frame: number,
  fps: number
): void {
  const width = sourceCanvas.width;
  const height = sourceCanvas.height;
  if (width <= 0 || height <= 0) return;

  // For canvas filter-compatible effects, use hardware accelerated canvas filters when available
  if (effectId === 'gaussian_blur') {
    const radius = Number(params.radius ?? 15);
    const direction = params.direction ?? 'both';
    targetCtx.save();
    targetCtx.clearRect(0, 0, width, height);
    if (radius > 0) {
      targetCtx.filter = `blur(${radius}px)`;
    }
    targetCtx.drawImage(sourceCanvas, 0, 0);
    targetCtx.restore();
    return;
  }

  if (effectId === 'brightness_contrast') {
    const b = Number(params.brightness ?? 0);
    const c = Number(params.contrast ?? 0);
    targetCtx.save();
    targetCtx.clearRect(0, 0, width, height);
    targetCtx.filter = `brightness(${100 + b}%) contrast(${100 + c}%)`;
    targetCtx.drawImage(sourceCanvas, 0, 0);
    targetCtx.restore();
    return;
  }

  if (effectId === 'hue_saturation') {
    const hue = Number(params.hue ?? 0);
    const sat = Number(params.saturation ?? 0);
    const light = Number(params.lightness ?? 0);
    targetCtx.save();
    targetCtx.clearRect(0, 0, width, height);
    targetCtx.filter = `hue-rotate(${hue}deg) saturate(${100 + sat}%) brightness(${100 + light}%)`;
    targetCtx.drawImage(sourceCanvas, 0, 0);
    targetCtx.restore();
    return;
  }

  if (effectId === 'invert') {
    const blend = Number(params.blend ?? 100) / 100;
    targetCtx.save();
    targetCtx.clearRect(0, 0, width, height);
    targetCtx.filter = `invert(${blend * 100}%)`;
    targetCtx.drawImage(sourceCanvas, 0, 0);
    targetCtx.restore();
    return;
  }

  if (effectId === 'glow') {
    const radius = Number(params.radius ?? 30);
    const intensity = Number(params.intensity ?? 1.5);
    const tint = params.colorTint ?? '#ffffff';
    const blendMode = params.blendMode ?? 'screen';

    targetCtx.save();
    targetCtx.clearRect(0, 0, width, height);
    // Draw base
    targetCtx.drawImage(sourceCanvas, 0, 0);

    // Create glow bloom overlay
    targetCtx.globalAlpha = Math.min(1, intensity);
    targetCtx.globalCompositeOperation = blendMode === 'add' ? 'lighter' : 'screen';
    targetCtx.filter = `blur(${radius}px) brightness(150%)`;
    targetCtx.drawImage(sourceCanvas, 0, 0);

    if (radius > 15) {
      targetCtx.filter = `blur(${radius * 1.8}px) brightness(200%)`;
      targetCtx.drawImage(sourceCanvas, 0, 0);
    }
    targetCtx.restore();
    return;
  }

  if (effectId === 'vignette') {
    const amount = Number(params.amount ?? 50) / 100;
    const radiusScale = Number(params.radius ?? 75) / 100;
    const color = params.color ?? '#000000';

    targetCtx.save();
    targetCtx.clearRect(0, 0, width, height);
    targetCtx.drawImage(sourceCanvas, 0, 0);

    const cx = width / 2;
    const cy = height / 2;
    const maxRadius = (Math.max(width, height) / 2) * radiusScale;
    const grad = targetCtx.createRadialGradient(cx, cy, maxRadius * 0.4, cx, cy, maxRadius);
    grad.addColorStop(0, 'rgba(0,0,0,0)');
    grad.addColorStop(1, color);

    targetCtx.globalAlpha = amount;
    targetCtx.fillStyle = grad;
    targetCtx.fillRect(0, 0, width, height);
    targetCtx.restore();
    return;
  }

  if (effectId === 'gradient_ramp') {
    const colorStart = params.colorStart ?? '#ff4b2b';
    const colorEnd = params.colorEnd ?? '#ff416c';
    const shape = params.shape ?? 'linear';
    const angleDeg = Number(params.angle ?? 90);
    const blend = Number(params.blend ?? 0) / 100;

    targetCtx.save();
    targetCtx.clearRect(0, 0, width, height);
    targetCtx.drawImage(sourceCanvas, 0, 0);

    let grad: CanvasGradient;
    if (shape === 'radial') {
      grad = targetCtx.createRadialGradient(width / 2, height / 2, 0, width / 2, height / 2, Math.max(width, height) / 2);
    } else {
      const angleRad = (angleDeg * Math.PI) / 180;
      const x0 = width / 2 - (Math.cos(angleRad) * width) / 2;
      const y0 = height / 2 - (Math.sin(angleRad) * height) / 2;
      const x1 = width / 2 + (Math.cos(angleRad) * width) / 2;
      const y1 = height / 2 + (Math.sin(angleRad) * height) / 2;
      grad = targetCtx.createLinearGradient(x0, y0, x1, y1);
    }
    grad.addColorStop(0, colorStart);
    grad.addColorStop(1, colorEnd);

    targetCtx.globalAlpha = 1 - blend;
    targetCtx.fillStyle = grad;
    targetCtx.fillRect(0, 0, width, height);
    targetCtx.restore();
    return;
  }

  // ================= PIXEL-LEVEL MANIPULATION PROCESSORS =================
  // Draw source image to scratch canvas to read raw RGBA pixels
  const scratchCanvas = document.createElement('canvas');
  scratchCanvas.width = width;
  scratchCanvas.height = height;
  const scratchCtx = scratchCanvas.getContext('2d');
  if (!scratchCtx) return;

  scratchCtx.drawImage(sourceCanvas, 0, 0);
  const imgData = scratchCtx.getImageData(0, 0, width, height);
  const data = imgData.data;

  if (effectId === 'exposure') {
    const exp = Number(params.exposure ?? 0);
    const offset = Number(params.offset ?? 0) * 255;
    const gamma = Number(params.gamma ?? 1.0);
    const multiplier = Math.pow(2, exp);
    const invGamma = 1 / Math.max(0.01, gamma);

    for (let i = 0; i < data.length; i += 4) {
      for (let c = 0; c < 3; c++) {
        let v = (data[i + c] * multiplier + offset) / 255;
        v = Math.pow(Math.max(0, Math.min(1, v)), invGamma);
        data[i + c] = Math.round(v * 255);
      }
    }
  } else if (effectId === 'levels') {
    const inBlack = Number(params.inputBlack ?? 0);
    const inWhite = Number(params.inputWhite ?? 255);
    const gamma = Number(params.gamma ?? 1.0);
    const outBlack = Number(params.outputBlack ?? 0);
    const outWhite = Number(params.outputWhite ?? 255);
    const inRange = Math.max(1, inWhite - inBlack);
    const outRange = outWhite - outBlack;
    const invGamma = 1 / Math.max(0.01, gamma);

    for (let i = 0; i < data.length; i += 4) {
      for (let c = 0; c < 3; c++) {
        let v = (data[i + c] - inBlack) / inRange;
        v = Math.max(0, Math.min(1, v));
        v = Math.pow(v, invGamma);
        data[i + c] = Math.round(outBlack + v * outRange);
      }
    }
  } else if (effectId === 'temperature_tint') {
    const temp = Number(params.temperature ?? 0);
    const tint = Number(params.tint ?? 0);
    for (let i = 0; i < data.length; i += 4) {
      data[i] = Math.min(255, Math.max(0, data[i] + temp * 1.2)); // Red
      data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + tint * 0.8)); // Green
      data[i + 2] = Math.min(255, Math.max(0, data[i + 2] - temp * 1.2)); // Blue
    }
  } else if (effectId === 'threshold') {
    const lvl = Number(params.level ?? 128);
    for (let i = 0; i < data.length; i += 4) {
      const luma = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
      const val = luma >= lvl ? 255 : 0;
      data[i] = val;
      data[i + 1] = val;
      data[i + 2] = val;
    }
  } else if (effectId === 'chroma_key') {
    const [kr, kg, kb] = hexToRgb(params.keyColor ?? '#00ff00');
    const tol = Number(params.tolerance ?? 40) * 2.55;
    const soft = Number(params.softness ?? 20) * 2.55;
    const spill = Number(params.spillSuppression ?? 75) / 100;

    for (let i = 0; i < data.length; i += 4) {
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];

      const dist = Math.sqrt((r - kr) * (r - kr) + (g - kg) * (g - kg) + (b - kb) * (b - kb));

      if (dist < tol) {
        data[i + 3] = 0; // Transparent
      } else if (dist < tol + soft && soft > 0) {
        const factor = (dist - tol) / soft;
        data[i + 3] = Math.round(data[i + 3] * factor);
      }

      // Spill suppression
      if (kg > kr && kg > kb && g > (r + b) / 2) {
        const spillAmount = g - (r + b) / 2;
        data[i + 1] = Math.max(0, Math.round(g - spillAmount * spill));
      }
    }
  } else if (effectId === 'luma_key') {
    const thresh = Number(params.threshold ?? 25);
    const tol = Number(params.tolerance ?? 20);
    const isDarker = (params.keyType ?? 'darker') === 'darker';

    for (let i = 0; i < data.length; i += 4) {
      const luma = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
      if (isDarker) {
        if (luma <= thresh) {
          data[i + 3] = 0;
        } else if (luma <= thresh + tol && tol > 0) {
          data[i + 3] = Math.round(data[i + 3] * ((luma - thresh) / tol));
        }
      } else {
        if (luma >= thresh) {
          data[i + 3] = 0;
        } else if (luma >= thresh - tol && tol > 0) {
          data[i + 3] = Math.round(data[i + 3] * ((thresh - luma) / tol));
        }
      }
    }
  } else if (effectId === 'edge_detection') {
    // Sobel operator
    const src = new Uint8Array(data);
    const invert = params.invert ?? false;
    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        const idx = (y * width + x) * 4;
        // Compute horizontal & vertical gradients for luminance
        let gx = 0;
        let gy = 0;
        for (let ky = -1; ky <= 1; ky++) {
          for (let kx = -1; kx <= 1; kx++) {
            const pIdx = ((y + ky) * width + (x + kx)) * 4;
            const luma = 0.299 * src[pIdx] + 0.587 * src[pIdx + 1] + 0.114 * src[pIdx + 2];
            const weightX = kx === 0 ? 0 : (ky === 0 ? 2 : 1) * kx;
            const weightY = ky === 0 ? 0 : (kx === 0 ? 2 : 1) * ky;
            gx += luma * weightX;
            gy += luma * weightY;
          }
        }
        let mag = Math.min(255, Math.sqrt(gx * gx + gy * gy));
        if (invert) mag = 255 - mag;
        data[idx] = mag;
        data[idx + 1] = mag;
        data[idx + 2] = mag;
      }
    }
  } else if (effectId === 'chromatic_aberration') {
    const amt = Math.round(Number(params.amount ?? 8));
    if (amt > 0) {
      const src = new Uint8Array(data);
      for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
          const idx = (y * width + x) * 4;
          const rx = Math.min(width - 1, Math.max(0, x + amt));
          const bx = Math.min(width - 1, Math.max(0, x - amt));
          const rIdx = (y * width + rx) * 4;
          const bIdx = (y * width + bx) * 4;
          data[idx] = src[rIdx]; // Red shifted right
          data[idx + 2] = src[bIdx + 2]; // Blue shifted left
        }
      }
    }
  } else if (effectId === 'noise_grain') {
    const amt = (Number(params.amount ?? 15) / 100) * 255;
    const mono = params.monochrome ?? true;
    const seed = (params.animated ? frame * 1337 : 42);
    for (let i = 0; i < data.length; i += 4) {
      if (data[i + 3] > 0) {
        if (mono) {
          const n = (pseudoNoise(seed, i) * amt);
          data[i] = Math.min(255, Math.max(0, data[i] + n));
          data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + n));
          data[i + 2] = Math.min(255, Math.max(0, data[i + 2] + n));
        } else {
          data[i] = Math.min(255, Math.max(0, data[i] + pseudoNoise(seed, i) * amt));
          data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + pseudoNoise(seed + 1, i) * amt));
          data[i + 2] = Math.min(255, Math.max(0, data[i + 2] + pseudoNoise(seed + 2, i) * amt));
        }
      }
    }
  } else if (effectId === 'fractal_noise') {
    const scale = Number(params.scale ?? 100);
    const octaves = Number(params.complexity ?? 4);
    const contrast = Number(params.contrast ?? 100) / 100;
    const brightness = Number(params.brightness ?? 0);
    const evo = ((Number(params.evolution ?? 0) + frame * 2) * Math.PI) / 180;
    const [r1, g1, b1] = hexToRgb(params.color1 ?? '#000000');
    const [r2, g2, b2] = hexToRgb(params.color2 ?? '#ffffff');

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        let n = 0;
        let freq = 1 / scale;
        let amp = 1;
        let maxAmp = 0;
        for (let o = 0; o < octaves; o++) {
          n += perlin2D(x * freq + Math.cos(evo) * 0.5, y * freq + Math.sin(evo) * 0.5) * amp;
          maxAmp += amp;
          freq *= 2.0;
          amp *= 0.5;
        }
        n = (n / maxAmp + 1) * 0.5; // 0 to 1
        n = (n - 0.5) * contrast + 0.5 + brightness / 255;
        n = Math.max(0, Math.min(1, n));

        const idx = (y * width + x) * 4;
        data[idx] = Math.round(r1 + (r2 - r1) * n);
        data[idx + 1] = Math.round(g1 + (g2 - g1) * n);
        data[idx + 2] = Math.round(b1 + (b2 - b1) * n);
        data[idx + 3] = 255;
      }
    }
  } else if (effectId === 'ripple_wave') {
    const waveH = Number(params.height ?? 15);
    const waveW = Math.max(5, Number(params.width ?? 60));
    const speed = Number(params.speed ?? 2.0);
    const t = (frame / fps) * speed * Math.PI * 2;
    const src = new Uint8ClampedArray(data);

    for (let y = 0; y < height; y++) {
      const offsetX = Math.sin(y / waveW + t) * waveH;
      for (let x = 0; x < width; x++) {
        const srcX = Math.round(x + offsetX);
        const idx = (y * width + x) * 4;
        if (srcX >= 0 && srcX < width) {
          const sIdx = (y * width + srcX) * 4;
          data[idx] = src[sIdx];
          data[idx + 1] = src[sIdx + 1];
          data[idx + 2] = src[sIdx + 2];
          data[idx + 3] = src[sIdx + 3];
        } else {
          data[idx + 3] = 0;
        }
      }
    }
  }

  targetCtx.clearRect(0, 0, width, height);
  targetCtx.putImageData(imgData, 0, 0);
}

function pseudoNoise(seed: number, t: number): number {
  const x = Math.sin(seed + t * 0.1234) * 43758.5453;
  return (x - Math.floor(x)) * 2 - 1;
}
