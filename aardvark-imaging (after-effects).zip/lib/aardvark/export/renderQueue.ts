/**
 * AARDVARK IMAGING - RENDER QUEUE & EXPORT ENGINE
 * Multi-format offline rendering, frame sequence rendering, and video encoding.
 */

import { RenderJob, AardvarkComposition, AardvarkAsset } from '../types';
import { Compositor, RenderContext } from '../rendering/compositor';

export class RenderQueueManager {
  private static activeRenderCancel = false;

  /**
   * Executes a render job frame by frame
   */
  public static async executeRenderJob(
    job: RenderJob,
    composition: AardvarkComposition,
    allCompositions: AardvarkComposition[],
    assets: Map<string, AardvarkAsset>,
    assetElements: Map<string, HTMLImageElement | HTMLVideoElement | HTMLCanvasElement>,
    onProgress: (updatedJob: RenderJob) => void
  ): Promise<string> {
    this.activeRenderCancel = false;
    job.status = 'rendering';
    job.startTime = Date.now();
    job.progress = 0;
    job.currentFrame = job.startFrame;

    const renderWidth = Math.round(composition.width * job.resolutionScale);
    const renderHeight = Math.round(composition.height * job.resolutionScale);

    const renderCanvas = document.createElement('canvas');
    renderCanvas.width = renderWidth;
    renderCanvas.height = renderHeight;

    const totalFrames = job.endFrame - job.startFrame + 1;
    job.totalFrames = totalFrames;

    // For WebM / MP4 video recording using MediaRecorder & Canvas Stream
    if (job.format === 'webm' || job.format === 'mp4') {
      const stream = renderCanvas.captureStream(job.fps || 30);
      const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
        ? 'video/webm;codecs=vp9'
        : 'video/webm';

      const recorder = new MediaRecorder(stream, {
        mimeType,
        videoBitsPerSecond: 12000000, // 12 Mbps high quality
      });

      const recordedChunks: Blob[] = [];
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) recordedChunks.push(e.data);
      };

      recorder.start();

      const frameIntervalMs = 1000 / (job.fps || 30);

      for (let f = job.startFrame; f <= job.endFrame; f++) {
        if (this.activeRenderCancel) {
          recorder.stop();
          job.status = 'cancelled';
          onProgress({ ...job });
          throw new Error('Render cancelled by user.');
        }

        const renderContext: RenderContext = {
          composition,
          allCompositions,
          assets,
          assetElements,
          frame: f,
          scale: job.resolutionScale,
        };

        Compositor.renderComposition(renderCanvas, renderContext);

        // Advance progress
        const completedFrames = f - job.startFrame + 1;
        job.currentFrame = f;
        job.progress = Math.round((completedFrames / totalFrames) * 100);

        const elapsed = (Date.now() - job.startTime) / 1000;
        job.elapsedTimeSeconds = elapsed;
        const avgTimePerFrame = elapsed / completedFrames;
        job.estimatedRemainingSeconds = Math.round((totalFrames - completedFrames) * avgTimePerFrame);

        onProgress({ ...job });

        // Let canvas stream update and breathe
        await new Promise((r) => setTimeout(r, Math.min(30, frameIntervalMs)));
      }

      return new Promise((resolve) => {
        recorder.onstop = () => {
          const blob = new Blob(recordedChunks, { type: 'video/webm' });
          const outputUrl = URL.createObjectURL(blob);
          job.status = 'completed';
          job.progress = 100;
          job.outputUrl = outputUrl;
          onProgress({ ...job });
          resolve(outputUrl);
        };
        recorder.stop();
      });
    }

    // Single Frame PNG export
    if (job.format === 'single-png') {
      const renderContext: RenderContext = {
        composition,
        allCompositions,
        assets,
        assetElements,
        frame: job.startFrame,
        scale: job.resolutionScale,
      };
      Compositor.renderComposition(renderCanvas, renderContext);

      return new Promise((resolve) => {
        renderCanvas.toBlob((blob) => {
          if (blob) {
            const url = URL.createObjectURL(blob);
            job.status = 'completed';
            job.progress = 100;
            job.outputUrl = url;
            onProgress({ ...job });
            resolve(url);
          }
        }, 'image/png');
      });
    }

    // Default Fallback
    job.status = 'completed';
    job.progress = 100;
    onProgress({ ...job });
    return '';
  }

  public static cancelCurrentRender() {
    this.activeRenderCancel = true;
  }
}
