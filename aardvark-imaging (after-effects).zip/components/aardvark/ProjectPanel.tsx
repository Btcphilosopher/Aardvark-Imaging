'use client';

import React, { useState, useRef } from 'react';
import {
  Folder,
  Film,
  Image as ImageIcon,
  Music,
  Video,
  Plus,
  Upload,
  Search,
  Sparkles,
  Layers,
  Trash2,
  Sliders,
} from 'lucide-react';
import { AardvarkProject, AardvarkAsset, AardvarkComposition } from '@/lib/aardvark/types';
import { EFFECT_CATALOG } from '@/lib/aardvark/effects/catalog';
import { MediaManager } from '@/lib/aardvark/media/mediaManager';

interface ProjectPanelProps {
  project: AardvarkProject;
  activeComp: AardvarkComposition | null;
  onSelectComp: (id: string) => void;
  onNewComp: () => void;
  onAddAsset: (asset: AardvarkAsset) => void;
  onDeleteAsset: (id: string) => void;
  onAddAssetToComp: (assetId: string) => void;
  onAddEffectToSelected: (effectId: string) => void;
  selectedLayerName?: string;
}

export const ProjectPanel: React.FC<ProjectPanelProps> = ({
  project,
  activeComp,
  onSelectComp,
  onNewComp,
  onAddAsset,
  onDeleteAsset,
  onAddAssetToComp,
  onAddEffectToSelected,
  selectedLayerName,
}) => {
  const [activeTab, setActiveTab] = useState<'project' | 'compositions' | 'effects'>('project');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      try {
        const newAsset = await MediaManager.importFile(file);
        await MediaManager.loadAsset(newAsset);
        onAddAsset(newAsset);
      } catch (err) {
        console.error('Failed to import file:', err);
      }
    }
  };

  const filteredAssets = project.assets.filter((a) =>
    a.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredEffects = EFFECT_CATALOG.filter((ef) => {
    const matchesCategory = selectedCategory === 'All' || ef.category === selectedCategory;
    const matchesSearch =
      ef.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ef.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div
      id="aardvark-project-panel"
      className="w-full h-full bg-[#13161f] border-r border-[#222736] flex flex-col text-xs text-neutral-300 select-none overflow-hidden"
    >
      {/* Tab Navigation Header */}
      <div className="flex items-center border-b border-[#222736] bg-[#10121a]">
        <button
          onClick={() => setActiveTab('project')}
          className={`flex-1 py-2 text-center text-[11px] font-semibold border-b-2 transition-colors flex items-center justify-center gap-1.5 ${
            activeTab === 'project'
              ? 'border-cyan-400 text-cyan-300 bg-[#161a25]'
              : 'border-transparent text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Folder className="w-3.5 h-3.5" />
          <span>Project</span>
        </button>
        <button
          onClick={() => setActiveTab('compositions')}
          className={`flex-1 py-2 text-center text-[11px] font-semibold border-b-2 transition-colors flex items-center justify-center gap-1.5 ${
            activeTab === 'compositions'
              ? 'border-cyan-400 text-cyan-300 bg-[#161a25]'
              : 'border-transparent text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Film className="w-3.5 h-3.5" />
          <span>Comps ({project.compositions.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('effects')}
          className={`flex-1 py-2 text-center text-[11px] font-semibold border-b-2 transition-colors flex items-center justify-center gap-1.5 ${
            activeTab === 'effects'
              ? 'border-cyan-400 text-cyan-300 bg-[#161a25]'
              : 'border-transparent text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Effects</span>
        </button>
      </div>

      {/* Search Input Bar */}
      <div className="p-2 border-b border-[#222736] bg-[#141722] flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="w-3.5 h-3.5 absolute left-2 top-2 text-neutral-500" />
          <input
            type="text"
            placeholder={
              activeTab === 'project'
                ? 'Search media assets...'
                : activeTab === 'compositions'
                ? 'Search compositions...'
                : 'Search visual effects...'
            }
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#1b202c] border border-[#2b3345] rounded pl-7 pr-2 py-1 text-[11px] text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        {activeTab === 'project' && (
          <>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              multiple
              accept="image/*,video/*,audio/*,.svg"
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              title="Import Footage or Audio"
              className="p-1.5 bg-[#1f2636] hover:bg-cyan-600/30 hover:text-cyan-300 rounded border border-[#2e374a] transition-colors"
            >
              <Upload className="w-3.5 h-3.5 text-cyan-400" />
            </button>
          </>
        )}

        {activeTab === 'compositions' && (
          <button
            onClick={onNewComp}
            title="Create New Composition"
            className="p-1.5 bg-[#1f2636] hover:bg-cyan-600/30 hover:text-cyan-300 rounded border border-[#2e374a] transition-colors"
          >
            <Plus className="w-3.5 h-3.5 text-cyan-400" />
          </button>
        )}
      </div>

      {/* Tab Content Body */}
      <div className="flex-1 overflow-y-auto p-2 space-y-1">
        {/* TAB 1: PROJECT ASSETS */}
        {activeTab === 'project' && (
          <div className="space-y-1.5">
            {filteredAssets.length === 0 ? (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="p-6 text-center border border-dashed border-[#293245] rounded-lg cursor-pointer hover:border-cyan-500/50 hover:bg-[#161a26] transition-colors group my-4"
              >
                <Upload className="w-6 h-6 mx-auto text-neutral-500 group-hover:text-cyan-400 mb-2 transition-colors" />
                <p className="text-xs text-neutral-300 font-semibold">Drop Footage / Media Here</p>
                <p className="text-[10px] text-neutral-500 mt-1">PNG, JPG, SVG, MP4, WebM, WAV, MP3</p>
              </div>
            ) : (
              filteredAssets.map((asset) => (
                <div
                  key={asset.id}
                  className="p-2 rounded bg-[#171b26] border border-[#232938] hover:border-cyan-500/40 hover:bg-[#1b202e] transition-all flex items-center justify-between group"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    {/* Thumbnail / Icon */}
                    <div className="w-10 h-8 rounded bg-[#10131a] border border-[#232938] flex items-center justify-center overflow-hidden flex-shrink-0">
                      {asset.thumbnailUrl ? (
                        <img
                          src={asset.thumbnailUrl}
                          alt={asset.name}
                          className="w-full h-full object-cover"
                        />
                      ) : asset.type === 'video' ? (
                        <Video className="w-4 h-4 text-purple-400" />
                      ) : asset.type === 'audio' ? (
                        <Music className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <ImageIcon className="w-4 h-4 text-blue-400" />
                      )}
                    </div>

                    {/* Metadata Specs */}
                    <div className="min-w-0">
                      <p className="text-[11px] font-semibold text-neutral-200 truncate group-hover:text-cyan-300">
                        {asset.name}
                      </p>
                      <div className="flex items-center gap-1.5 text-[9px] text-neutral-500 font-mono">
                        {asset.width > 0 && (
                          <span>
                            {asset.width}×{asset.height}
                          </span>
                        )}
                        {asset.durationSeconds && (
                          <span>• {asset.durationSeconds.toFixed(1)}s</span>
                        )}
                        <span>• {(asset.fileSize ? asset.fileSize / 1024 : 0).toFixed(0)} KB</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => onAddAssetToComp(asset.id)}
                      title="Add to Active Composition"
                      className="p-1 hover:bg-cyan-600/30 text-cyan-400 rounded"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => onDeleteAsset(asset.id)}
                      title="Delete Asset"
                      className="p-1 hover:bg-red-600/30 text-red-400 rounded"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* TAB 2: COMPOSITIONS */}
        {activeTab === 'compositions' && (
          <div className="space-y-1.5">
            {project.compositions.map((comp) => {
              const isActive = activeComp?.id === comp.id;
              return (
                <div
                  key={comp.id}
                  onClick={() => onSelectComp(comp.id)}
                  className={`p-2.5 rounded border transition-all cursor-pointer flex items-center justify-between ${
                    isActive
                      ? 'bg-cyan-950/40 border-cyan-500/60 shadow-sm'
                      : 'bg-[#171b26] border-[#232938] hover:border-neutral-600'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Film className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-neutral-400'}`} />
                    <div>
                      <p className={`text-[11px] font-bold ${isActive ? 'text-cyan-300' : 'text-neutral-200'}`}>
                        {comp.name}
                      </p>
                      <p className="text-[9px] text-neutral-500 font-mono mt-0.5">
                        {comp.width}×{comp.height} @ {comp.fps}fps • {comp.durationFrames}f (
                        {(comp.durationFrames / comp.fps).toFixed(1)}s)
                      </p>
                    </div>
                  </div>

                  <span className="text-[10px] text-neutral-400 font-mono px-1.5 py-0.5 rounded bg-[#10131c]">
                    {comp.layers.length} layers
                  </span>
                </div>
              );
            })}
          </div>
        )}

        {/* TAB 3: EFFECTS BROWSER */}
        {activeTab === 'effects' && (
          <div className="space-y-2">
            {/* Category Filter Pills */}
            <div className="flex flex-wrap gap-1 pb-1 border-b border-[#222736]">
              {['All', 'Blur', 'Color', 'Stylize', 'Distortion', 'Keying', 'Generative'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-2 py-0.5 text-[10px] rounded-full transition-colors ${
                    selectedCategory === cat
                      ? 'bg-cyan-600 text-slate-950 font-bold'
                      : 'bg-[#1a202d] text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {selectedLayerName && (
              <div className="p-1.5 bg-cyan-950/50 border border-cyan-800/40 rounded text-[10px] text-cyan-300 flex items-center justify-between">
                <span>Selected: <strong>{selectedLayerName}</strong></span>
                <span className="text-neutral-400 text-[9px]">Click + to apply</span>
              </div>
            )}

            {filteredEffects.map((ef) => (
              <div
                key={ef.id}
                className="p-2 rounded bg-[#171b26] border border-[#232938] hover:border-cyan-500/40 hover:bg-[#1b202e] transition-all group"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] px-1 py-0.2 rounded bg-[#1f2533] text-cyan-400 font-mono">
                      {ef.category}
                    </span>
                    <span className="text-[11px] font-bold text-neutral-200 group-hover:text-cyan-300">
                      {ef.name}
                    </span>
                  </div>
                  <button
                    onClick={() => onAddEffectToSelected(ef.id)}
                    title="Apply Effect to Selected Layer"
                    className="p-1 bg-[#202737] hover:bg-cyan-600 hover:text-slate-950 text-cyan-400 rounded transition-colors"
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                </div>
                <p className="text-[10px] text-neutral-400 mt-1 line-clamp-2 leading-relaxed">
                  {ef.description}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
