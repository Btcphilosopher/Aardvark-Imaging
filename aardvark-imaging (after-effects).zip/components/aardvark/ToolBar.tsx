'use client';

import React from 'react';
import {
  MousePointer,
  Hand,
  Search,
  RotateCw,
  Camera,
  Crosshair,
  Square,
  Circle,
  Star,
  PenTool,
  Type,
  Magnet,
  Grid,
  Maximize2,
  Tv,
} from 'lucide-react';

export type ActiveTool =
  | 'select'
  | 'hand'
  | 'zoom'
  | 'rotate'
  | 'camera'
  | 'anchor'
  | 'rect'
  | 'ellipse'
  | 'star'
  | 'pen'
  | 'type';

interface ToolBarProps {
  activeTool: ActiveTool;
  onSelectTool: (tool: ActiveTool) => void;
  snapping: boolean;
  onToggleSnapping: () => void;
  resolution: number; // 1 = Full, 0.5 = Half, 0.25 = Quarter
  onSelectResolution: (res: number) => void;
  channel: 'rgb' | 'alpha' | 'red' | 'green' | 'blue';
  onSelectChannel: (ch: 'rgb' | 'alpha' | 'red' | 'green' | 'blue') => void;
  showSafeMargins: boolean;
  onToggleSafeMargins: () => void;
  showGrid: boolean;
  onToggleGrid: () => void;
}

export const ToolBar: React.FC<ToolBarProps> = ({
  activeTool,
  onSelectTool,
  snapping,
  onToggleSnapping,
  resolution,
  onSelectResolution,
  channel,
  onSelectChannel,
  showSafeMargins,
  onToggleSafeMargins,
  showGrid,
  onToggleGrid,
}) => {
  const tools: { id: ActiveTool; label: string; icon: React.ReactNode; shortcut: string }[] = [
    { id: 'select', label: 'Selection Tool', icon: <MousePointer className="w-3.5 h-3.5" />, shortcut: 'V' },
    { id: 'hand', label: 'Hand Tool', icon: <Hand className="w-3.5 h-3.5" />, shortcut: 'H' },
    { id: 'zoom', label: 'Zoom Tool', icon: <Search className="w-3.5 h-3.5" />, shortcut: 'Z' },
    { id: 'rotate', label: 'Rotation Tool', icon: <RotateCw className="w-3.5 h-3.5" />, shortcut: 'W' },
    { id: 'camera', label: 'Camera Orbit / Pan', icon: <Camera className="w-3.5 h-3.5" />, shortcut: 'C' },
    { id: 'anchor', label: 'Pan Behind / Anchor Point', icon: <Crosshair className="w-3.5 h-3.5" />, shortcut: 'Y' },
    { id: 'rect', label: 'Rectangle Shape', icon: <Square className="w-3.5 h-3.5" />, shortcut: 'Q' },
    { id: 'star', label: 'Star / Polygon Shape', icon: <Star className="w-3.5 h-3.5" />, shortcut: 'Q' },
    { id: 'pen', label: 'Pen / Bezier Mask Tool', icon: <PenTool className="w-3.5 h-3.5" />, shortcut: 'G' },
    { id: 'type', label: 'Horizontal Type Tool', icon: <Type className="w-3.5 h-3.5" />, shortcut: 'T' },
  ];

  return (
    <div
      id="aardvark-toolbar"
      className="h-8 bg-[#151922] border-b border-[#232836] flex items-center justify-between px-3 text-xs text-neutral-300 select-none"
    >
      {/* Tool Icons */}
      <div className="flex items-center gap-1">
        {tools.map((t) => {
          const isActive = activeTool === t.id;
          return (
            <button
              key={t.id}
              id={`tool-${t.id}`}
              onClick={() => onSelectTool(t.id)}
              title={`${t.label} (${t.shortcut})`}
              className={`w-7 h-6 flex items-center justify-center rounded transition-colors ${
                isActive
                  ? 'bg-cyan-600/30 text-cyan-300 border border-cyan-500/50 shadow-sm'
                  : 'text-neutral-400 hover:text-neutral-100 hover:bg-[#202636]'
              }`}
            >
              {t.icon}
            </button>
          );
        })}

        <div className="h-4 w-px bg-[#262e3e] mx-1" />

        {/* Snapping */}
        <button
          id="btn-toggle-snapping"
          onClick={onToggleSnapping}
          title={`Snapping: ${snapping ? 'ON' : 'OFF'} (Ctrl+Shift+;) `}
          className={`w-7 h-6 flex items-center justify-center rounded transition-colors ${
            snapping
              ? 'bg-cyan-600/30 text-cyan-300 border border-cyan-500/50'
              : 'text-neutral-400 hover:text-neutral-100 hover:bg-[#202636]'
          }`}
        >
          <Magnet className="w-3.5 h-3.5" />
        </button>

        {/* Safe Margins */}
        <button
          id="btn-toggle-safemargins"
          onClick={onToggleSafeMargins}
          title="Title / Action Safe Guides"
          className={`w-7 h-6 flex items-center justify-center rounded transition-colors ${
            showSafeMargins
              ? 'bg-cyan-600/30 text-cyan-300 border border-cyan-500/50'
              : 'text-neutral-400 hover:text-neutral-100 hover:bg-[#202636]'
          }`}
        >
          <Tv className="w-3.5 h-3.5" />
        </button>

        {/* Grid */}
        <button
          id="btn-toggle-grid"
          onClick={onToggleGrid}
          title="Proportional Grid Overlay"
          className={`w-7 h-6 flex items-center justify-center rounded transition-colors ${
            showGrid
              ? 'bg-cyan-600/30 text-cyan-300 border border-cyan-500/50'
              : 'text-neutral-400 hover:text-neutral-100 hover:bg-[#202636]'
          }`}
        >
          <Grid className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Viewport Render Controls: Resolution & Channels */}
      <div className="flex items-center gap-3 text-[11px]">
        {/* Channel Dropdown */}
        <div className="flex items-center gap-1.5">
          <span className="text-neutral-500 text-[10px] uppercase">Channel:</span>
          <select
            value={channel}
            onChange={(e) => onSelectChannel(e.target.value as any)}
            className="bg-[#1a1f2c] border border-[#2b3345] rounded px-2 py-0.5 text-neutral-200 text-[11px] focus:outline-none focus:border-cyan-500"
          >
            <option value="rgb">RGB Color</option>
            <option value="alpha">Alpha Channel</option>
            <option value="red">Red Channel</option>
            <option value="green">Green Channel</option>
            <option value="blue">Blue Channel</option>
          </select>
        </div>

        {/* Resolution Dropdown */}
        <div className="flex items-center gap-1.5">
          <span className="text-neutral-500 text-[10px] uppercase">Resolution:</span>
          <select
            value={resolution}
            onChange={(e) => onSelectResolution(Number(e.target.value))}
            className="bg-[#1a1f2c] border border-[#2b3345] rounded px-2 py-0.5 text-neutral-200 text-[11px] focus:outline-none focus:border-cyan-500"
          >
            <option value={1}>Full (100%)</option>
            <option value={0.5}>Half (50%)</option>
            <option value={0.25}>Quarter (25%)</option>
          </select>
        </div>
      </div>
    </div>
  );
};
