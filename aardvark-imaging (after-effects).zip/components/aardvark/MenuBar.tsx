'use client';

import React, { useState } from 'react';
import {
  FolderOpen,
  Save,
  Film,
  Layers,
  Sparkles,
  Play,
  Download,
  RotateCcw,
  RotateCw,
  Plus,
  Tv,
  Eye,
  Settings,
  HelpCircle,
  FileVideo,
  Monitor,
  LayoutTemplate,
} from 'lucide-react';
import { AardvarkProject, AardvarkComposition, LayerType } from '@/lib/aardvark/types';

interface MenuBarProps {
  project: AardvarkProject;
  activeComp: AardvarkComposition | null;
  onSaveProject: () => void;
  onOpenProject: () => void;
  onNewProject: () => void;
  onNewComp: () => void;
  onAddLayer: (type: LayerType) => void;
  onAddEffectToSelected: (effectId: string) => void;
  onUndo: () => void;
  onRedo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  onOpenRenderQueue: () => void;
  currentWorkspace: string;
  onSelectWorkspace: (ws: string) => void;
  onImportMedia: () => void;
}

export const MenuBar: React.FC<MenuBarProps> = ({
  project,
  activeComp,
  onSaveProject,
  onOpenProject,
  onNewProject,
  onNewComp,
  onAddLayer,
  onAddEffectToSelected,
  onUndo,
  onRedo,
  canUndo,
  canRedo,
  onOpenRenderQueue,
  currentWorkspace,
  onSelectWorkspace,
  onImportMedia,
}) => {
  const [activeMenu, setActiveMenu] = useState<string | null>(null);

  const toggleMenu = (menu: string) => {
    setActiveMenu(activeMenu === menu ? null : menu);
  };

  const closeMenu = () => setActiveMenu(null);

  return (
    <div
      id="aardvark-menubar"
      className="h-9 bg-[#12151c] border-b border-[#242936] flex items-center justify-between px-3 text-xs text-neutral-300 select-none z-50 relative"
      onClick={(e) => {
        if ((e.target as HTMLElement).tagName !== 'BUTTON') {
          closeMenu();
        }
      }}
    >
      {/* Left: Brand & Menu Items */}
      <div className="flex items-center gap-1">
        {/* Brand Icon & Title */}
        <div className="flex items-center gap-2 pr-3 border-r border-[#242936] mr-1">
          <div className="w-5 h-5 rounded bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-sm">
            <span className="font-mono font-black text-slate-950 text-[11px] leading-none">A</span>
          </div>
          <span className="font-bold tracking-wider text-neutral-100 uppercase text-[11px]">
            Aardvark
          </span>
          <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-950/80 text-cyan-400 font-mono border border-cyan-800/40">
            PRO
          </span>
        </div>

        {/* Menu Buttons */}
        <div className="flex items-center gap-0.5">
          {/* FILE */}
          <div className="relative">
            <button
              id="menu-btn-file"
              onClick={() => toggleMenu('file')}
              className={`px-2.5 py-1 rounded hover:bg-[#1f2533] transition-colors ${
                activeMenu === 'file' ? 'bg-[#1f2533] text-cyan-400' : ''
              }`}
            >
              File
            </button>
            {activeMenu === 'file' && (
              <div className="absolute top-full left-0 mt-1 w-52 bg-[#171b24] border border-[#2b3345] rounded-md shadow-2xl py-1 z-50 text-neutral-200 backdrop-blur-md">
                <button
                  onClick={() => {
                    onNewProject();
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-cyan-600/20 hover:text-cyan-300 flex items-center justify-between"
                >
                  <span>New Project</span>
                  <span className="text-[10px] text-neutral-400 font-mono">Ctrl+N</span>
                </button>
                <button
                  onClick={() => {
                    onOpenProject();
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-cyan-600/20 hover:text-cyan-300 flex items-center justify-between"
                >
                  <span>Open .aardvark...</span>
                  <span className="text-[10px] text-neutral-400 font-mono">Ctrl+O</span>
                </button>
                <button
                  onClick={() => {
                    onSaveProject();
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-cyan-600/20 hover:text-cyan-300 flex items-center justify-between"
                >
                  <span>Save Project</span>
                  <span className="text-[10px] text-neutral-400 font-mono">Ctrl+S</span>
                </button>
                <div className="h-px bg-[#262e3e] my-1" />
                <button
                  onClick={() => {
                    onImportMedia();
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-cyan-600/20 hover:text-cyan-300 flex items-center justify-between"
                >
                  <span>Import Footage / Media...</span>
                  <span className="text-[10px] text-neutral-400 font-mono">Ctrl+I</span>
                </button>
                <div className="h-px bg-[#262e3e] my-1" />
                <button
                  onClick={() => {
                    onOpenRenderQueue();
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-cyan-600/20 hover:text-cyan-300 flex items-center justify-between"
                >
                  <span>Export & Render Queue...</span>
                  <span className="text-[10px] text-neutral-400 font-mono">Ctrl+M</span>
                </button>
              </div>
            )}
          </div>

          {/* EDIT */}
          <div className="relative">
            <button
              id="menu-btn-edit"
              onClick={() => toggleMenu('edit')}
              className={`px-2.5 py-1 rounded hover:bg-[#1f2533] transition-colors ${
                activeMenu === 'edit' ? 'bg-[#1f2533] text-cyan-400' : ''
              }`}
            >
              Edit
            </button>
            {activeMenu === 'edit' && (
              <div className="absolute top-full left-0 mt-1 w-48 bg-[#171b24] border border-[#2b3345] rounded-md shadow-2xl py-1 z-50 text-neutral-200">
                <button
                  disabled={!canUndo}
                  onClick={() => {
                    onUndo();
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-cyan-600/20 hover:text-cyan-300 flex items-center justify-between disabled:opacity-40"
                >
                  <span>Undo</span>
                  <span className="text-[10px] text-neutral-400 font-mono">Ctrl+Z</span>
                </button>
                <button
                  disabled={!canRedo}
                  onClick={() => {
                    onRedo();
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-cyan-600/20 hover:text-cyan-300 flex items-center justify-between disabled:opacity-40"
                >
                  <span>Redo</span>
                  <span className="text-[10px] text-neutral-400 font-mono">Ctrl+Y</span>
                </button>
                <div className="h-px bg-[#262e3e] my-1" />
                <button
                  onClick={closeMenu}
                  className="w-full text-left px-3 py-1.5 hover:bg-cyan-600/20 hover:text-cyan-300 flex items-center justify-between"
                >
                  <span>Project Settings</span>
                </button>
              </div>
            )}
          </div>

          {/* COMPOSITION */}
          <div className="relative">
            <button
              id="menu-btn-comp"
              onClick={() => toggleMenu('comp')}
              className={`px-2.5 py-1 rounded hover:bg-[#1f2533] transition-colors ${
                activeMenu === 'comp' ? 'bg-[#1f2533] text-cyan-400' : ''
              }`}
            >
              Composition
            </button>
            {activeMenu === 'comp' && (
              <div className="absolute top-full left-0 mt-1 w-56 bg-[#171b24] border border-[#2b3345] rounded-md shadow-2xl py-1 z-50 text-neutral-200">
                <button
                  onClick={() => {
                    onNewComp();
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-cyan-600/20 hover:text-cyan-300 flex items-center justify-between"
                >
                  <span>New Composition...</span>
                  <span className="text-[10px] text-neutral-400 font-mono">Ctrl+K</span>
                </button>
                <button
                  onClick={() => {
                    onOpenRenderQueue();
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-cyan-600/20 hover:text-cyan-300 flex items-center justify-between"
                >
                  <span>Add to Render Queue</span>
                  <span className="text-[10px] text-neutral-400 font-mono">Ctrl+Shift+M</span>
                </button>
              </div>
            )}
          </div>

          {/* LAYER */}
          <div className="relative">
            <button
              id="menu-btn-layer"
              onClick={() => toggleMenu('layer')}
              className={`px-2.5 py-1 rounded hover:bg-[#1f2533] transition-colors ${
                activeMenu === 'layer' ? 'bg-[#1f2533] text-cyan-400' : ''
              }`}
            >
              Layer
            </button>
            {activeMenu === 'layer' && (
              <div className="absolute top-full left-0 mt-1 w-52 bg-[#171b24] border border-[#2b3345] rounded-md shadow-2xl py-1 z-50 text-neutral-200">
                <div className="px-3 py-1 text-[10px] font-semibold text-neutral-400 uppercase tracking-wider">
                  New Layer
                </div>
                <button
                  onClick={() => {
                    onAddLayer('text');
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-cyan-600/20 hover:text-cyan-300 flex items-center gap-2"
                >
                  <span className="text-cyan-400 font-bold">T</span>
                  <span>Text Layer</span>
                </button>
                <button
                  onClick={() => {
                    onAddLayer('solid');
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-cyan-600/20 hover:text-cyan-300 flex items-center gap-2"
                >
                  <span className="w-3 h-3 rounded bg-indigo-500 inline-block" />
                  <span>Solid Layer...</span>
                </button>
                <button
                  onClick={() => {
                    onAddLayer('shape');
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-cyan-600/20 hover:text-cyan-300 flex items-center gap-2"
                >
                  <span className="text-pink-400">★</span>
                  <span>Shape Layer</span>
                </button>
                <button
                  onClick={() => {
                    onAddLayer('adjustment');
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-cyan-600/20 hover:text-cyan-300 flex items-center gap-2"
                >
                  <span className="text-amber-400">FX</span>
                  <span>Adjustment Layer</span>
                </button>
                <button
                  onClick={() => {
                    onAddLayer('camera');
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-cyan-600/20 hover:text-cyan-300 flex items-center gap-2"
                >
                  <span className="text-red-400">📹</span>
                  <span>3D Camera</span>
                </button>
                <button
                  onClick={() => {
                    onAddLayer('null');
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-cyan-600/20 hover:text-cyan-300 flex items-center gap-2"
                >
                  <span className="text-emerald-400">⊞</span>
                  <span>Null Object</span>
                </button>
              </div>
            )}
          </div>

          {/* EFFECT */}
          <div className="relative">
            <button
              id="menu-btn-effect"
              onClick={() => toggleMenu('effect')}
              className={`px-2.5 py-1 rounded hover:bg-[#1f2533] transition-colors ${
                activeMenu === 'effect' ? 'bg-[#1f2533] text-cyan-400' : ''
              }`}
            >
              Effect
            </button>
            {activeMenu === 'effect' && (
              <div className="absolute top-full left-0 mt-1 w-64 bg-[#171b24] border border-[#2b3345] rounded-md shadow-2xl py-1 z-50 text-neutral-200 max-h-96 overflow-y-auto">
                <div className="px-3 py-1 text-[10px] font-semibold text-cyan-400 uppercase tracking-wider">
                  Blur & Sharpen
                </div>
                <button
                  onClick={() => {
                    onAddEffectToSelected('gaussian_blur');
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1 hover:bg-cyan-600/20 hover:text-cyan-300"
                >
                  Gaussian Blur
                </button>
                <button
                  onClick={() => {
                    onAddEffectToSelected('directional_blur');
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1 hover:bg-cyan-600/20 hover:text-cyan-300"
                >
                  Directional Blur
                </button>
                <div className="px-3 py-1 text-[10px] font-semibold text-cyan-400 uppercase tracking-wider mt-1 border-t border-[#262e3e]">
                  Color Correction
                </div>
                <button
                  onClick={() => {
                    onAddEffectToSelected('exposure');
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1 hover:bg-cyan-600/20 hover:text-cyan-300"
                >
                  Exposure
                </button>
                <button
                  onClick={() => {
                    onAddEffectToSelected('brightness_contrast');
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1 hover:bg-cyan-600/20 hover:text-cyan-300"
                >
                  Brightness & Contrast
                </button>
                <button
                  onClick={() => {
                    onAddEffectToSelected('hue_saturation');
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1 hover:bg-cyan-600/20 hover:text-cyan-300"
                >
                  Hue / Saturation
                </button>
                <button
                  onClick={() => {
                    onAddEffectToSelected('levels');
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1 hover:bg-cyan-600/20 hover:text-cyan-300"
                >
                  Levels
                </button>
                <div className="px-3 py-1 text-[10px] font-semibold text-cyan-400 uppercase tracking-wider mt-1 border-t border-[#262e3e]">
                  Stylize & Optical
                </div>
                <button
                  onClick={() => {
                    onAddEffectToSelected('glow');
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1 hover:bg-cyan-600/20 hover:text-cyan-300"
                >
                  Optical Glow / Bloom
                </button>
                <button
                  onClick={() => {
                    onAddEffectToSelected('chromatic_aberration');
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1 hover:bg-cyan-600/20 hover:text-cyan-300"
                >
                  Chromatic Aberration
                </button>
                <button
                  onClick={() => {
                    onAddEffectToSelected('vignette');
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1 hover:bg-cyan-600/20 hover:text-cyan-300"
                >
                  Vignette
                </button>
                <div className="px-3 py-1 text-[10px] font-semibold text-cyan-400 uppercase tracking-wider mt-1 border-t border-[#262e3e]">
                  Keying & VFX
                </div>
                <button
                  onClick={() => {
                    onAddEffectToSelected('chroma_key');
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1 hover:bg-cyan-600/20 hover:text-cyan-300"
                >
                  Chroma Key (Green/Blue Screen)
                </button>
                <button
                  onClick={() => {
                    onAddEffectToSelected('fractal_noise');
                    closeMenu();
                  }}
                  className="w-full text-left px-3 py-1 hover:bg-cyan-600/20 hover:text-cyan-300"
                >
                  Fractal Noise
                </button>
              </div>
            )}
          </div>

          {/* VIEW / WINDOW */}
          <div className="relative">
            <button
              id="menu-btn-window"
              onClick={() => toggleMenu('window')}
              className={`px-2.5 py-1 rounded hover:bg-[#1f2533] transition-colors ${
                activeMenu === 'window' ? 'bg-[#1f2533] text-cyan-400' : ''
              }`}
            >
              Workspace
            </button>
            {activeMenu === 'window' && (
              <div className="absolute top-full left-0 mt-1 w-52 bg-[#171b24] border border-[#2b3345] rounded-md shadow-2xl py-1 z-50 text-neutral-200">
                <div className="px-3 py-1 text-[10px] font-semibold text-neutral-400 uppercase tracking-wider">
                  Layouts
                </div>
                {['Standard', 'VFX & Compositing', 'Motion Graphics', 'Color Grading'].map((ws) => (
                  <button
                    key={ws}
                    onClick={() => {
                      onSelectWorkspace(ws);
                      closeMenu();
                    }}
                    className={`w-full text-left px-3 py-1.5 hover:bg-cyan-600/20 hover:text-cyan-300 flex items-center justify-between ${
                      currentWorkspace === ws ? 'text-cyan-400 font-semibold' : ''
                    }`}
                  >
                    <span>{ws}</span>
                    {currentWorkspace === ws && <span className="text-cyan-400">✓</span>}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Center: Active Composition Title & Specs */}
      {activeComp && (
        <div className="hidden md:flex items-center gap-2 text-[11px] text-neutral-400 font-mono bg-[#181c26] px-3 py-1 rounded border border-[#252c3c]">
          <span className="text-cyan-300 font-semibold">{activeComp.name}</span>
          <span className="text-neutral-500">•</span>
          <span>
            {activeComp.width}×{activeComp.height}
          </span>
          <span className="text-neutral-500">•</span>
          <span>{activeComp.fps} fps</span>
          <span className="text-neutral-500">•</span>
          <span>{activeComp.colorSpace}</span>
        </div>
      )}

      {/* Right: Quick Action Controls */}
      <div className="flex items-center gap-2">
        <button
          onClick={onSaveProject}
          title="Save Project (Ctrl+S)"
          className="flex items-center gap-1.5 px-2.5 py-1 bg-[#1e2433] hover:bg-[#283145] text-neutral-200 hover:text-white rounded border border-[#303b52] transition-colors"
        >
          <Save className="w-3.5 h-3.5 text-cyan-400" />
          <span className="hidden sm:inline">Save</span>
        </button>

        <button
          onClick={onOpenRenderQueue}
          title="Render Queue"
          className="flex items-center gap-1.5 px-3 py-1 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-slate-950 font-bold rounded shadow-sm transition-all"
        >
          <Film className="w-3.5 h-3.5" />
          <span>Render</span>
        </button>
      </div>
    </div>
  );
};
