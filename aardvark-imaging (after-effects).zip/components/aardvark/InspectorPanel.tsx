'use client';

import React, { useState } from 'react';
import {
  Sliders,
  Sparkles,
  Type,
  Film,
  Activity,
  Plus,
  Trash2,
  ChevronUp,
  ChevronDown,
  RotateCcw,
  Play,
  Download,
  Code,
  Check,
  AlertCircle,
} from 'lucide-react';
import {
  AardvarkComposition,
  AardvarkLayer,
  AardvarkAsset,
  RenderJob,
  RenderFormat,
  Vector3D,
} from '@/lib/aardvark/types';
import { EFFECT_CATALOG } from '@/lib/aardvark/effects/catalog';

interface InspectorPanelProps {
  composition: AardvarkComposition;
  allCompositions: AardvarkComposition[];
  assets: Map<string, AardvarkAsset>;
  selectedLayer: AardvarkLayer | null;
  onUpdateLayer: (layerId: string, updates: Partial<AardvarkLayer>) => void;
  onAddEffect: (layerId: string, effectId: string) => void;
  renderQueue: RenderJob[];
  onAddRenderJob: (format: RenderFormat, resolutionScale: 1 | 0.5 | 0.25) => void;
  onStartRender: (jobId: string) => void;
  onCancelRender: (jobId: string) => void;
}

export const InspectorPanel: React.FC<InspectorPanelProps> = ({
  composition,
  allCompositions,
  assets,
  selectedLayer,
  onUpdateLayer,
  onAddEffect,
  renderQueue,
  onAddRenderJob,
  onStartRender,
  onCancelRender,
}) => {
  const [activeTab, setActiveTab] = useState<'properties' | 'effects' | 'character' | 'render' | 'scopes'>('properties');
  const [expressionModalProp, setExpressionModalProp] = useState<string | null>(null);
  const [expressionCode, setExpressionCode] = useState<string>('');

  // Handle numerical transform updates
  const handleTransformNumberChange = (
    propName: 'position' | 'scale' | 'rotation' | 'anchorPoint',
    index: number,
    value: number
  ) => {
    if (!selectedLayer) return;
    const currentArr = [...(selectedLayer.transform[propName].value as Vector3D)];
    currentArr[index] = value;
    onUpdateLayer(selectedLayer.id, {
      transform: {
        ...selectedLayer.transform,
        [propName]: {
          ...selectedLayer.transform[propName],
          value: currentArr as Vector3D,
        },
      },
    });
  };

  const handleOpacityChange = (value: number) => {
    if (!selectedLayer) return;
    onUpdateLayer(selectedLayer.id, {
      transform: {
        ...selectedLayer.transform,
        opacity: {
          ...selectedLayer.transform.opacity,
          value,
        },
      },
    });
  };

  // Handle effect parameter changes
  const handleEffectParamChange = (effectId: string, paramKey: string, value: any) => {
    if (!selectedLayer || !selectedLayer.effects) return;
    const updatedEffects = selectedLayer.effects.map((ef) => {
      if (ef.id === effectId) {
        return {
          ...ef,
          parameters: {
            ...ef.parameters,
            [paramKey]: {
              ...(ef.parameters[paramKey] || { animated: false, keyframes: [] }),
              value,
            },
          },
        };
      }
      return ef;
    });
    onUpdateLayer(selectedLayer.id, { effects: updatedEffects });
  };

  // Remove effect
  const handleRemoveEffect = (effectId: string) => {
    if (!selectedLayer || !selectedLayer.effects) return;
    const updated = selectedLayer.effects.filter((ef) => ef.id !== effectId);
    onUpdateLayer(selectedLayer.id, { effects: updated });
  };

  // Toggle effect enabled
  const handleToggleEffectEnabled = (effectId: string) => {
    if (!selectedLayer || !selectedLayer.effects) return;
    const updated = selectedLayer.effects.map((ef) =>
      ef.id === effectId ? { ...ef, enabled: !ef.enabled } : ef
    );
    onUpdateLayer(selectedLayer.id, { effects: updated });
  };

  return (
    <div
      id="aardvark-inspector-panel"
      className="w-full h-full bg-[#13161f] border-l border-[#222736] flex flex-col text-xs text-neutral-300 select-none overflow-hidden"
    >
      {/* Tab Navigation Header */}
      <div className="flex items-center border-b border-[#222736] bg-[#10121a]">
        <button
          onClick={() => setActiveTab('properties')}
          className={`flex-1 py-2 text-center text-[10px] font-semibold border-b-2 transition-colors flex items-center justify-center gap-1 ${
            activeTab === 'properties'
              ? 'border-cyan-400 text-cyan-300 bg-[#161a25]'
              : 'border-transparent text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>Properties</span>
        </button>

        <button
          onClick={() => setActiveTab('effects')}
          className={`flex-1 py-2 text-center text-[10px] font-semibold border-b-2 transition-colors flex items-center justify-center gap-1 ${
            activeTab === 'effects'
              ? 'border-cyan-400 text-cyan-300 bg-[#161a25]'
              : 'border-transparent text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Effects ({selectedLayer?.effects?.length || 0})</span>
        </button>

        <button
          onClick={() => setActiveTab('character')}
          className={`flex-1 py-2 text-center text-[10px] font-semibold border-b-2 transition-colors flex items-center justify-center gap-1 ${
            activeTab === 'character'
              ? 'border-cyan-400 text-cyan-300 bg-[#161a25]'
              : 'border-transparent text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Type className="w-3.5 h-3.5" />
          <span>Type</span>
        </button>

        <button
          onClick={() => setActiveTab('render')}
          className={`flex-1 py-2 text-center text-[10px] font-semibold border-b-2 transition-colors flex items-center justify-center gap-1 ${
            activeTab === 'render'
              ? 'border-cyan-400 text-cyan-300 bg-[#161a25]'
              : 'border-transparent text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Film className="w-3.5 h-3.5" />
          <span>Queue ({renderQueue.length})</span>
        </button>
      </div>

      {/* Panel Body Content */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        {/* ================= TAB 1: PROPERTIES ================= */}
        {activeTab === 'properties' && (
          <>
            {selectedLayer ? (
              <div className="space-y-4">
                {/* Layer Identification Card */}
                <div className="p-2.5 rounded bg-[#171b26] border border-[#232938] flex items-center justify-between">
                  <div>
                    <span className="text-[9px] uppercase font-mono text-neutral-500">
                      Layer Type: {selectedLayer.type}
                    </span>
                    <input
                      type="text"
                      value={selectedLayer.name}
                      onChange={(e) => onUpdateLayer(selectedLayer.id, { name: e.target.value })}
                      className="bg-transparent text-xs font-bold text-cyan-300 focus:outline-none focus:border-b border-cyan-400 block w-full mt-0.5"
                    />
                  </div>
                  <input
                    type="color"
                    value={selectedLayer.colorTag || '#3b82f6'}
                    onChange={(e) => onUpdateLayer(selectedLayer.id, { colorTag: e.target.value })}
                    className="w-5 h-5 rounded cursor-pointer bg-transparent border-0"
                    title="Change Label Color"
                  />
                </div>

                {/* Transform Section */}
                <div className="p-3 rounded bg-[#161a25] border border-[#222736] space-y-2.5">
                  <div className="flex items-center justify-between text-[11px] font-bold text-neutral-200 border-b border-[#232938] pb-1.5">
                    <span>Transform</span>
                    <span className="text-[10px] text-neutral-500 font-mono">
                      {selectedLayer.is3D ? '3D Space (X, Y, Z)' : '2D Plane (X, Y)'}
                    </span>
                  </div>

                  {/* Position (X, Y, Z) */}
                  <div>
                    <label className="text-[10px] font-semibold text-neutral-400 block mb-1">
                      Position
                    </label>
                    <div className="grid grid-cols-3 gap-1.5 font-mono text-[11px]">
                      <div className="flex items-center bg-[#1c2230] px-2 py-1 rounded border border-[#2b3345]">
                        <span className="text-red-400 mr-1 text-[10px]">X</span>
                        <input
                          type="number"
                          value={Math.round(selectedLayer.transform.position.value[0])}
                          onChange={(e) =>
                            handleTransformNumberChange('position', 0, parseFloat(e.target.value) || 0)
                          }
                          className="w-full bg-transparent text-neutral-200 focus:outline-none"
                        />
                      </div>
                      <div className="flex items-center bg-[#1c2230] px-2 py-1 rounded border border-[#2b3345]">
                        <span className="text-emerald-400 mr-1 text-[10px]">Y</span>
                        <input
                          type="number"
                          value={Math.round(selectedLayer.transform.position.value[1])}
                          onChange={(e) =>
                            handleTransformNumberChange('position', 1, parseFloat(e.target.value) || 0)
                          }
                          className="w-full bg-transparent text-neutral-200 focus:outline-none"
                        />
                      </div>
                      <div className="flex items-center bg-[#1c2230] px-2 py-1 rounded border border-[#2b3345]">
                        <span className="text-blue-400 mr-1 text-[10px]">Z</span>
                        <input
                          type="number"
                          value={Math.round(selectedLayer.transform.position.value[2])}
                          onChange={(e) =>
                            handleTransformNumberChange('position', 2, parseFloat(e.target.value) || 0)
                          }
                          className="w-full bg-transparent text-neutral-200 focus:outline-none"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Scale (X, Y, Z) */}
                  <div>
                    <label className="text-[10px] font-semibold text-neutral-400 block mb-1">
                      Scale (%)
                    </label>
                    <div className="grid grid-cols-3 gap-1.5 font-mono text-[11px]">
                      <div className="flex items-center bg-[#1c2230] px-2 py-1 rounded border border-[#2b3345]">
                        <span className="text-red-400 mr-1 text-[10px]">X</span>
                        <input
                          type="number"
                          value={Math.round(selectedLayer.transform.scale.value[0])}
                          onChange={(e) =>
                            handleTransformNumberChange('scale', 0, parseFloat(e.target.value) || 0)
                          }
                          className="w-full bg-transparent text-neutral-200 focus:outline-none"
                        />
                      </div>
                      <div className="flex items-center bg-[#1c2230] px-2 py-1 rounded border border-[#2b3345]">
                        <span className="text-emerald-400 mr-1 text-[10px]">Y</span>
                        <input
                          type="number"
                          value={Math.round(selectedLayer.transform.scale.value[1])}
                          onChange={(e) =>
                            handleTransformNumberChange('scale', 1, parseFloat(e.target.value) || 0)
                          }
                          className="w-full bg-transparent text-neutral-200 focus:outline-none"
                        />
                      </div>
                      <div className="flex items-center bg-[#1c2230] px-2 py-1 rounded border border-[#2b3345]">
                        <span className="text-blue-400 mr-1 text-[10px]">Z</span>
                        <input
                          type="number"
                          value={Math.round(selectedLayer.transform.scale.value[2])}
                          onChange={(e) =>
                            handleTransformNumberChange('scale', 2, parseFloat(e.target.value) || 0)
                          }
                          className="w-full bg-transparent text-neutral-200 focus:outline-none"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Rotation (X, Y, Z) */}
                  <div>
                    <label className="text-[10px] font-semibold text-neutral-400 block mb-1">
                      Rotation (Degrees)
                    </label>
                    <div className="grid grid-cols-3 gap-1.5 font-mono text-[11px]">
                      <div className="flex items-center bg-[#1c2230] px-2 py-1 rounded border border-[#2b3345]">
                        <span className="text-red-400 mr-1 text-[10px]">X</span>
                        <input
                          type="number"
                          value={Math.round(selectedLayer.transform.rotation.value[0])}
                          onChange={(e) =>
                            handleTransformNumberChange('rotation', 0, parseFloat(e.target.value) || 0)
                          }
                          className="w-full bg-transparent text-neutral-200 focus:outline-none"
                        />
                      </div>
                      <div className="flex items-center bg-[#1c2230] px-2 py-1 rounded border border-[#2b3345]">
                        <span className="text-emerald-400 mr-1 text-[10px]">Y</span>
                        <input
                          type="number"
                          value={Math.round(selectedLayer.transform.rotation.value[1])}
                          onChange={(e) =>
                            handleTransformNumberChange('rotation', 1, parseFloat(e.target.value) || 0)
                          }
                          className="w-full bg-transparent text-neutral-200 focus:outline-none"
                        />
                      </div>
                      <div className="flex items-center bg-[#1c2230] px-2 py-1 rounded border border-[#2b3345]">
                        <span className="text-blue-400 mr-1 text-[10px]">Z</span>
                        <input
                          type="number"
                          value={Math.round(selectedLayer.transform.rotation.value[2])}
                          onChange={(e) =>
                            handleTransformNumberChange('rotation', 2, parseFloat(e.target.value) || 0)
                          }
                          className="w-full bg-transparent text-neutral-200 focus:outline-none"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Opacity Slider */}
                  <div>
                    <div className="flex justify-between text-[10px] font-semibold text-neutral-400 mb-1">
                      <span>Opacity</span>
                      <span className="text-cyan-300 font-mono">
                        {selectedLayer.transform.opacity.value}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={100}
                      value={selectedLayer.transform.opacity.value}
                      onChange={(e) => handleOpacityChange(parseFloat(e.target.value))}
                      className="w-full h-1 bg-[#232938] rounded-lg appearance-none cursor-pointer accent-cyan-400"
                    />
                  </div>
                </div>

                {/* Layer-Specific Controls (Shape/Solid/Camera) */}
                {selectedLayer.type === 'solid' && (
                  <div className="p-3 rounded bg-[#161a25] border border-[#222736] space-y-2">
                    <span className="text-[11px] font-bold text-neutral-200 block">Solid Color</span>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={selectedLayer.solidColor || '#4f46e5'}
                        onChange={(e) => onUpdateLayer(selectedLayer.id, { solidColor: e.target.value })}
                        className="w-8 h-8 rounded bg-transparent border-0 cursor-pointer"
                      />
                      <span className="font-mono text-neutral-300 text-xs">
                        {selectedLayer.solidColor}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-8 text-center text-neutral-500">
                <Sliders className="w-8 h-8 mx-auto mb-2 opacity-40" />
                <p>Select a layer to inspect properties</p>
              </div>
            )}
          </>
        )}

        {/* ================= TAB 2: EFFECT CONTROLS ================= */}
        {activeTab === 'effects' && (
          <div className="space-y-3">
            {selectedLayer && selectedLayer.effects && selectedLayer.effects.length > 0 ? (
              selectedLayer.effects.map((effect) => {
                const def = EFFECT_CATALOG.find((d) => d.id === effect.effectId);
                return (
                  <div
                    key={effect.id}
                    className="p-3 rounded bg-[#161a25] border border-[#222736] space-y-3 shadow-md"
                  >
                    {/* Effect Header */}
                    <div className="flex items-center justify-between border-b border-[#232938] pb-2">
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={effect.enabled}
                          onChange={() => handleToggleEffectEnabled(effect.id)}
                          className="rounded accent-cyan-400 cursor-pointer"
                        />
                        <span className="font-bold text-xs text-neutral-200">{effect.name}</span>
                      </div>

                      <button
                        onClick={() => handleRemoveEffect(effect.id)}
                        title="Delete Effect"
                        className="p-1 hover:bg-red-950/40 text-neutral-500 hover:text-red-400 rounded"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Dynamic Parameter Sliders / Inputs */}
                    {def?.parameters.map((param) => {
                      const curVal =
                        effect.parameters[param.key]?.value ?? param.defaultValue;

                      return (
                        <div key={param.key} className="space-y-1">
                          <div className="flex justify-between text-[10px] text-neutral-400">
                            <span>{param.name}</span>
                            <span className="text-cyan-300 font-mono">
                              {typeof curVal === 'number' ? curVal.toFixed(1) : curVal}
                            </span>
                          </div>

                          {param.type === 'color' ? (
                            <input
                              type="color"
                              value={curVal}
                              onChange={(e) =>
                                handleEffectParamChange(effect.id, param.key, e.target.value)
                              }
                              className="w-full h-6 rounded bg-[#1e2433] border border-[#2b3345] cursor-pointer"
                            />
                          ) : param.type === 'select' ? (
                            <select
                              value={curVal}
                              onChange={(e) =>
                                handleEffectParamChange(effect.id, param.key, e.target.value)
                              }
                              className="w-full bg-[#1e2433] border border-[#2b3345] rounded px-2 py-1 text-neutral-200 text-xs focus:outline-none"
                            >
                              {param.options?.map((opt) => (
                                <option key={opt.value} value={opt.value}>
                                  {opt.label}
                                </option>
                              ))}
                            </select>
                          ) : param.type === 'boolean' ? (
                            <label className="flex items-center gap-2 cursor-pointer text-xs text-neutral-300">
                              <input
                                type="checkbox"
                                checked={!!curVal}
                                onChange={(e) =>
                                  handleEffectParamChange(effect.id, param.key, e.target.checked)
                                }
                                className="rounded accent-cyan-400"
                              />
                              <span>Enabled</span>
                            </label>
                          ) : (
                            <input
                              type="range"
                              min={param.min ?? 0}
                              max={param.max ?? 100}
                              step={param.step ?? 1}
                              value={curVal}
                              onChange={(e) =>
                                handleEffectParamChange(
                                  effect.id,
                                  param.key,
                                  parseFloat(e.target.value)
                                )
                              }
                              className="w-full h-1 bg-[#232938] rounded-lg appearance-none cursor-pointer accent-cyan-400"
                            />
                          )}
                        </div>
                      );
                    })}
                  </div>
                );
              })
            ) : (
              <div className="p-8 text-center text-neutral-500">
                <Sparkles className="w-8 h-8 mx-auto mb-2 opacity-40" />
                <p>No effects applied to this layer.</p>
                <p className="text-[10px] text-neutral-600 mt-1">
                  Choose an effect from the Project &gt; Effects panel.
                </p>
              </div>
            )}
          </div>
        )}

        {/* ================= TAB 3: CHARACTER / TEXT ================= */}
        {activeTab === 'character' && (
          <div className="space-y-4">
            {selectedLayer && selectedLayer.type === 'text' && selectedLayer.textData ? (
              <div className="p-3 rounded bg-[#161a25] border border-[#222736] space-y-3">
                <span className="text-[11px] font-bold text-neutral-200 block border-b border-[#232938] pb-1.5">
                  Typography Controls
                </span>

                {/* Text String Input */}
                <div>
                  <label className="text-[10px] text-neutral-400 block mb-1">Text Content</label>
                  <textarea
                    rows={2}
                    value={selectedLayer.textData.text}
                    onChange={(e) =>
                      onUpdateLayer(selectedLayer.id, {
                        textData: { ...selectedLayer.textData!, text: e.target.value },
                      })
                    }
                    className="w-full bg-[#1b202c] border border-[#2b3345] rounded p-2 text-xs text-neutral-200 focus:outline-none focus:border-cyan-500"
                  />
                </div>

                {/* Font Size & Weight */}
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-neutral-400 block mb-1">Font Size (px)</label>
                    <input
                      type="number"
                      value={selectedLayer.textData.fontSize}
                      onChange={(e) =>
                        onUpdateLayer(selectedLayer.id, {
                          textData: {
                            ...selectedLayer.textData!,
                            fontSize: parseFloat(e.target.value) || 12,
                          },
                        })
                      }
                      className="w-full bg-[#1b202c] border border-[#2b3345] rounded px-2 py-1 text-xs text-neutral-200 font-mono"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] text-neutral-400 block mb-1">Tracking (Kerning)</label>
                    <input
                      type="number"
                      value={selectedLayer.textData.tracking}
                      onChange={(e) =>
                        onUpdateLayer(selectedLayer.id, {
                          textData: {
                            ...selectedLayer.textData!,
                            tracking: parseFloat(e.target.value) || 0,
                          },
                        })
                      }
                      className="w-full bg-[#1b202c] border border-[#2b3345] rounded px-2 py-1 text-xs text-neutral-200 font-mono"
                    />
                  </div>
                </div>

                {/* Colors (Fill & Stroke) */}
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-neutral-400 block mb-1">Fill Color</label>
                    <input
                      type="color"
                      value={selectedLayer.textData.fillColor || '#ffffff'}
                      onChange={(e) =>
                        onUpdateLayer(selectedLayer.id, {
                          textData: { ...selectedLayer.textData!, fillColor: e.target.value },
                        })
                      }
                      className="w-full h-8 rounded bg-[#1b202c] border border-[#2b3345] cursor-pointer"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] text-neutral-400 block mb-1">Stroke Color</label>
                    <input
                      type="color"
                      value={selectedLayer.textData.strokeColor || '#000000'}
                      onChange={(e) =>
                        onUpdateLayer(selectedLayer.id, {
                          textData: { ...selectedLayer.textData!, strokeColor: e.target.value },
                        })
                      }
                      className="w-full h-8 rounded bg-[#1b202c] border border-[#2b3345] cursor-pointer"
                    />
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-8 text-center text-neutral-500">
                <Type className="w-8 h-8 mx-auto mb-2 opacity-40" />
                <p>Select a Text Layer to edit typography.</p>
              </div>
            )}
          </div>
        )}

        {/* ================= TAB 4: RENDER QUEUE ================= */}
        {activeTab === 'render' && (
          <div className="space-y-3">
            <div className="p-3 rounded bg-[#161a25] border border-[#222736] space-y-2.5">
              <span className="text-[11px] font-bold text-neutral-200 block border-b border-[#232938] pb-1.5">
                Export Composition
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => onAddRenderJob('webm', 1)}
                  className="flex-1 py-1.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-slate-950 font-bold rounded shadow-sm flex items-center justify-center gap-1.5 text-xs transition-all"
                >
                  <Film className="w-3.5 h-3.5" />
                  <span>Queue 1080p WebM Video</span>
                </button>

                <button
                  onClick={() => onAddRenderJob('single-png', 1)}
                  title="Export Current Frame Snapshot"
                  className="px-3 py-1.5 bg-[#202738] hover:bg-[#2a344a] text-neutral-200 rounded border border-[#303c54] text-xs transition-colors"
                >
                  PNG Frame
                </button>
              </div>
            </div>

            {/* Active Render Jobs List */}
            <div className="space-y-2">
              {renderQueue.map((job) => (
                <div
                  key={job.id}
                  className="p-3 rounded bg-[#171b26] border border-[#232938] space-y-2 shadow-md"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-bold text-xs text-neutral-200">{job.outputName}</p>
                      <p className="text-[10px] text-neutral-500 font-mono">
                        {job.format.toUpperCase()} • {job.totalFrames} frames • {job.status}
                      </p>
                    </div>

                    {job.status === 'completed' && job.outputUrl && (
                      <a
                        href={job.outputUrl}
                        download={job.outputName}
                        className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold rounded flex items-center gap-1 text-[11px]"
                      >
                        <Download className="w-3 h-3" />
                        <span>Download</span>
                      </a>
                    )}

                    {job.status === 'queued' && (
                      <button
                        onClick={() => onStartRender(job.id)}
                        className="px-2.5 py-1 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded flex items-center gap-1 text-[11px]"
                      >
                        <Play className="w-3 h-3 fill-current" />
                        <span>Render</span>
                      </button>
                    )}

                    {job.status === 'rendering' && (
                      <button
                        onClick={() => onCancelRender(job.id)}
                        className="px-2 py-1 bg-red-600/80 hover:bg-red-500 text-white rounded text-[10px]"
                      >
                        Cancel
                      </button>
                    )}
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full bg-[#11131c] h-2 rounded-full overflow-hidden border border-[#232938]">
                    <div
                      style={{ width: `${job.progress}%` }}
                      className={`h-full transition-all duration-100 ${
                        job.status === 'completed'
                          ? 'bg-emerald-400'
                          : job.status === 'failed'
                          ? 'bg-red-400'
                          : 'bg-cyan-400 animate-pulse'
                      }`}
                    />
                  </div>

                  {job.status === 'rendering' && (
                    <div className="flex justify-between text-[9px] font-mono text-neutral-400">
                      <span>
                        Frame: {job.currentFrame} / {job.totalFrames} ({job.progress}%)
                      </span>
                      <span>ETA: {job.estimatedRemainingSeconds || 0}s</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
