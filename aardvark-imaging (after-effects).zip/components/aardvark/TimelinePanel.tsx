'use client';

import React, { useState, useRef, useEffect } from 'react';
import {
  Eye,
  EyeOff,
  Volume2,
  VolumeX,
  Lock,
  Unlock,
  ChevronRight,
  ChevronDown,
  Box,
  Wind,
  Plus,
  Trash2,
  Clock,
  Sparkles,
  Sliders,
  Maximize2,
  ZoomIn,
  ZoomOut,
  TrendingUp,
} from 'lucide-react';
import {
  AardvarkComposition,
  AardvarkLayer,
  Keyframe,
  KeyframeInterpolation,
  AnimatableProperty,
  BlendMode,
} from '@/lib/aardvark/types';

interface TimelinePanelProps {
  composition: AardvarkComposition;
  currentFrame: number;
  onSeekFrame: (frame: number) => void;
  selectedLayerIds: string[];
  onSelectLayer: (layerId: string, multiSelect?: boolean) => void;
  onUpdateLayer: (layerId: string, updates: Partial<AardvarkLayer>) => void;
  onDeleteLayer: (layerId: string) => void;
  onAddKeyframe: (layerId: string, propertyPath: string, value: any) => void;
  onUpdateKeyframe: (
    layerId: string,
    propertyPath: string,
    keyframeId: string,
    updates: Partial<Keyframe>
  ) => void;
  onRemoveKeyframe: (layerId: string, propertyPath: string, keyframeId: string) => void;
}

export const TimelinePanel: React.FC<TimelinePanelProps> = ({
  composition,
  currentFrame,
  onSeekFrame,
  selectedLayerIds,
  onSelectLayer,
  onUpdateLayer,
  onDeleteLayer,
  onAddKeyframe,
  onUpdateKeyframe,
  onRemoveKeyframe,
}) => {
  const [zoom, setZoom] = useState<number>(1.2); // px per frame
  const [expandedLayers, setExpandedLayers] = useState<Record<string, boolean>>({});
  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({});
  const [isGraphEditor, setIsGraphEditor] = useState(false);
  const [selectedKeyframe, setSelectedKeyframe] = useState<{
    layerId: string;
    propPath: string;
    keyframeId: string;
  } | null>(null);

  const rulerRef = useRef<HTMLDivElement>(null);
  const tracksScrollRef = useRef<HTMLDivElement>(null);
  const isDraggingPlayhead = useRef(false);

  const toggleLayerExpand = (layerId: string) => {
    setExpandedLayers((prev) => ({ ...prev, [layerId]: !prev[layerId] }));
  };

  const toggleGroupExpand = (key: string) => {
    setExpandedGroups((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  // Dragging Playhead on Time Ruler
  const handleRulerMouseDown = (e: React.MouseEvent) => {
    isDraggingPlayhead.current = true;
    updatePlayheadFromMouse(e);
  };

  const updatePlayheadFromMouse = (e: React.MouseEvent | MouseEvent) => {
    if (!rulerRef.current) return;
    const rect = rulerRef.current.getBoundingClientRect();
    const scrollLeft = tracksScrollRef.current?.scrollLeft || 0;
    const clickX = e.clientX - rect.left + scrollLeft;
    const newFrame = Math.max(0, Math.min(composition.durationFrames, Math.round(clickX / zoom)));
    onSeekFrame(newFrame);
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDraggingPlayhead.current) {
        updatePlayheadFromMouse(e);
      }
    };
    const handleMouseUp = () => {
      isDraggingPlayhead.current = false;
    };
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [zoom, composition.durationFrames]);

  const totalWidthPx = composition.durationFrames * zoom + 200;

  // Frame tick marks
  const tickInterval = zoom < 0.8 ? 30 : zoom < 2 ? 10 : 5;
  const ticks = [];
  for (let f = 0; f <= composition.durationFrames; f += tickInterval) {
    ticks.push(f);
  }

  return (
    <div
      id="aardvark-timeline-panel"
      className="w-full h-full bg-[#11131b] border-t border-[#222736] flex flex-col text-xs text-neutral-300 select-none overflow-hidden"
    >
      {/* Timeline Top Control Header */}
      <div className="h-8 bg-[#151822] border-b border-[#232836] px-3 flex items-center justify-between text-[11px]">
        {/* Left: Switches & Graph Editor toggle */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsGraphEditor(!isGraphEditor)}
            title="Toggle Graph Editor (Animation Curves)"
            className={`px-2.5 py-1 rounded flex items-center gap-1.5 transition-colors ${
              isGraphEditor
                ? 'bg-cyan-600 text-slate-950 font-bold shadow-sm'
                : 'bg-[#1b202c] hover:bg-[#232a3b] text-neutral-300'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>Graph Editor</span>
          </button>

          <span className="text-neutral-500 font-mono text-[10px]">
            {composition.layers.length} Layers • {composition.durationFrames} Frames
          </span>
        </div>

        {/* Right: Zoom slider */}
        <div className="flex items-center gap-2">
          <ZoomOut className="w-3.5 h-3.5 text-neutral-500" />
          <input
            type="range"
            min={0.3}
            max={6.0}
            step={0.1}
            value={zoom}
            onChange={(e) => setZoom(parseFloat(e.target.value))}
            className="w-24 h-1 bg-[#232938] rounded-lg appearance-none cursor-pointer accent-cyan-400"
          />
          <ZoomIn className="w-3.5 h-3.5 text-neutral-500" />
        </div>
      </div>

      {/* Main Timeline Workspace Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* LEFT COLUMN: Layer Switches & Hierarchy (Fixed Width ~360px) */}
        <div className="w-[380px] bg-[#131620] border-r border-[#232836] flex flex-col flex-shrink-0 z-20">
          {/* Header Row */}
          <div className="h-7 bg-[#161a25] border-b border-[#222736] px-2 flex items-center justify-between text-[10px] font-mono text-neutral-400 uppercase">
            <div className="flex items-center gap-2">
              <span>#</span>
              <span>Layer Name</span>
            </div>
            <div className="flex items-center gap-3 pr-2">
              <span title="Parent Layer">Parent</span>
              <span title="Blend Mode">Mode</span>
              <span title="3D Layer">3D</span>
              <span title="Motion Blur">MB</span>
            </div>
          </div>

          {/* Layer List Rows */}
          <div className="flex-1 overflow-y-auto overflow-x-hidden">
            {composition.layers.map((layer, index) => {
              const isSelected = selectedLayerIds.includes(layer.id);
              const isExpanded = expandedLayers[layer.id];

              return (
                <div key={layer.id} className="border-b border-[#1c212e]">
                  {/* Master Layer Row */}
                  <div
                    onClick={(e) => onSelectLayer(layer.id, e.shiftKey || e.metaKey)}
                    className={`h-7 px-2 flex items-center justify-between cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-cyan-950/50 text-cyan-200 border-l-2 border-cyan-400'
                        : 'hover:bg-[#181d2a] text-neutral-200'
                    }`}
                  >
                    {/* Left: Expand, Color Tag, Name */}
                    <div className="flex items-center gap-1.5 min-w-0">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleLayerExpand(layer.id);
                        }}
                        className="p-0.5 text-neutral-400 hover:text-white"
                      >
                        {isExpanded ? (
                          <ChevronDown className="w-3.5 h-3.5" />
                        ) : (
                          <ChevronRight className="w-3.5 h-3.5" />
                        )}
                      </button>

                      <span className="text-[9px] font-mono text-neutral-500 w-3 text-right">
                        {index + 1}
                      </span>

                      {/* Color Tag */}
                      <span
                        style={{ backgroundColor: layer.colorTag || '#3b82f6' }}
                        className="w-2 h-2 rounded-full flex-shrink-0"
                      />

                      {/* Eye (Visibility) */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onUpdateLayer(layer.id, { visible: !layer.visible });
                        }}
                        title="Toggle Visibility"
                        className="p-0.5 text-neutral-400 hover:text-cyan-400"
                      >
                        {layer.visible ? (
                          <Eye className="w-3 h-3 text-cyan-400" />
                        ) : (
                          <EyeOff className="w-3 h-3 text-neutral-600" />
                        )}
                      </button>

                      {/* Lock */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onUpdateLayer(layer.id, { locked: !layer.locked });
                        }}
                        title="Lock Layer"
                        className="p-0.5 text-neutral-400 hover:text-amber-400"
                      >
                        {layer.locked ? (
                          <Lock className="w-3 h-3 text-amber-400" />
                        ) : (
                          <Unlock className="w-3 h-3 text-neutral-600 opacity-40 hover:opacity-100" />
                        )}
                      </button>

                      <span className="text-[11px] font-semibold truncate ml-1">
                        {layer.name}
                      </span>
                    </div>

                    {/* Right: Switches (Blend Mode, 3D Cube, Motion Blur) */}
                    <div className="flex items-center gap-2 pr-1" onClick={(e) => e.stopPropagation()}>
                      {/* Blend Mode Dropdown */}
                      <select
                        value={layer.blendMode}
                        onChange={(e) =>
                          onUpdateLayer(layer.id, { blendMode: e.target.value as BlendMode })
                        }
                        className="bg-[#181d28] border border-[#262f40] rounded px-1 py-0.2 text-[9px] text-neutral-300 focus:outline-none"
                      >
                        <option value="normal">Normal</option>
                        <option value="multiply">Multiply</option>
                        <option value="screen">Screen</option>
                        <option value="overlay">Overlay</option>
                        <option value="add">Add</option>
                        <option value="difference">Diff</option>
                      </select>

                      {/* 3D Switch */}
                      <button
                        onClick={() => onUpdateLayer(layer.id, { is3D: !layer.is3D })}
                        title="Toggle 3D Layer"
                        className={`p-1 rounded ${
                          layer.is3D
                            ? 'text-cyan-400 bg-cyan-950/60 border border-cyan-800/40'
                            : 'text-neutral-600 hover:text-neutral-300'
                        }`}
                      >
                        <Box className="w-3 h-3" />
                      </button>

                      {/* Motion Blur Switch */}
                      <button
                        onClick={() => onUpdateLayer(layer.id, { motionBlur: !layer.motionBlur })}
                        title="Toggle Motion Blur"
                        className={`p-1 rounded ${
                          layer.motionBlur
                            ? 'text-cyan-400 bg-cyan-950/60 border border-cyan-800/40'
                            : 'text-neutral-600 hover:text-neutral-300'
                        }`}
                      >
                        <Wind className="w-3 h-3" />
                      </button>
                    </div>
                  </div>

                  {/* Expanded Property Sub-rows */}
                  {isExpanded && (
                    <div className="bg-[#0f1118] text-[10px] font-mono text-neutral-400 pl-6 divide-y divide-[#181c26]">
                      {/* Transform Group */}
                      <div className="py-1">
                        <div
                          onClick={() => toggleGroupExpand(`${layer.id}_transform`)}
                          className="flex items-center gap-1.5 py-0.5 text-neutral-300 font-semibold cursor-pointer hover:text-cyan-300"
                        >
                          <ChevronDown className="w-3 h-3" />
                          <span>Transform</span>
                        </div>

                        <div className="pl-4 space-y-0.5 mt-0.5">
                          {/* Position */}
                          <div className="flex items-center justify-between pr-2 py-0.5 hover:bg-[#171b26]">
                            <div className="flex items-center gap-1.5">
                              <button
                                onClick={() =>
                                  onAddKeyframe(
                                    layer.id,
                                    'transform.position',
                                    layer.transform.position.value
                                  )
                                }
                                title="Toggle Keyframe Stopwatch"
                                className={`w-3 h-3 rounded-full flex items-center justify-center border ${
                                  layer.transform.position.animated
                                    ? 'bg-cyan-500 border-cyan-400'
                                    : 'border-neutral-500 hover:border-cyan-400'
                                }`}
                              >
                                <span className="w-1 h-1 bg-slate-950 rounded-full" />
                              </button>
                              <span>Position</span>
                            </div>
                            <span className="text-cyan-300">
                              {layer.transform.position.value.map((v) => Math.round(v)).join(', ')}
                            </span>
                          </div>

                          {/* Scale */}
                          <div className="flex items-center justify-between pr-2 py-0.5 hover:bg-[#171b26]">
                            <div className="flex items-center gap-1.5">
                              <button
                                onClick={() =>
                                  onAddKeyframe(
                                    layer.id,
                                    'transform.scale',
                                    layer.transform.scale.value
                                  )
                                }
                                className={`w-3 h-3 rounded-full flex items-center justify-center border ${
                                  layer.transform.scale.animated
                                    ? 'bg-cyan-500 border-cyan-400'
                                    : 'border-neutral-500 hover:border-cyan-400'
                                }`}
                              >
                                <span className="w-1 h-1 bg-slate-950 rounded-full" />
                              </button>
                              <span>Scale</span>
                            </div>
                            <span className="text-cyan-300">
                              {layer.transform.scale.value[0]}%
                            </span>
                          </div>

                          {/* Rotation */}
                          <div className="flex items-center justify-between pr-2 py-0.5 hover:bg-[#171b26]">
                            <div className="flex items-center gap-1.5">
                              <button
                                onClick={() =>
                                  onAddKeyframe(
                                    layer.id,
                                    'transform.rotation',
                                    layer.transform.rotation.value
                                  )
                                }
                                className={`w-3 h-3 rounded-full flex items-center justify-center border ${
                                  layer.transform.rotation.animated
                                    ? 'bg-cyan-500 border-cyan-400'
                                    : 'border-neutral-500 hover:border-cyan-400'
                                }`}
                              >
                                <span className="w-1 h-1 bg-slate-950 rounded-full" />
                              </button>
                              <span>Rotation</span>
                            </div>
                            <span className="text-cyan-300">
                              {layer.transform.rotation.value[2]}°
                            </span>
                          </div>

                          {/* Opacity */}
                          <div className="flex items-center justify-between pr-2 py-0.5 hover:bg-[#171b26]">
                            <div className="flex items-center gap-1.5">
                              <button
                                onClick={() =>
                                  onAddKeyframe(
                                    layer.id,
                                    'transform.opacity',
                                    layer.transform.opacity.value
                                  )
                                }
                                className={`w-3 h-3 rounded-full flex items-center justify-center border ${
                                  layer.transform.opacity.animated
                                    ? 'bg-cyan-500 border-cyan-400'
                                    : 'border-neutral-500 hover:border-cyan-400'
                                }`}
                              >
                                <span className="w-1 h-1 bg-slate-950 rounded-full" />
                              </button>
                              <span>Opacity</span>
                            </div>
                            <span className="text-cyan-300">
                              {layer.transform.opacity.value}%
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Effects Group */}
                      {layer.effects && layer.effects.length > 0 && (
                        <div className="py-1">
                          <div className="flex items-center gap-1.5 py-0.5 text-cyan-400 font-semibold">
                            <Sparkles className="w-3 h-3" />
                            <span>Effects ({layer.effects.length})</span>
                          </div>
                          {layer.effects.map((ef) => (
                            <div key={ef.id} className="pl-4 py-0.5 text-neutral-300 flex justify-between pr-2">
                              <span>{ef.name}</span>
                              <span className="text-neutral-500">{ef.enabled ? 'ON' : 'OFF'}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* RIGHT COLUMN: Time Ruler & Keyframe Tracks */}
        <div
          ref={tracksScrollRef}
          className="flex-1 bg-[#0e1017] overflow-x-auto overflow-y-auto relative"
        >
          <div style={{ width: `${totalWidthPx}px` }} className="h-full relative">
            {/* 1. Time Ruler Bar */}
            <div
              ref={rulerRef}
              onMouseDown={handleRulerMouseDown}
              className="h-7 bg-[#141722] border-b border-[#222736] relative cursor-pointer select-none"
            >
              {ticks.map((frame) => (
                <div
                  key={frame}
                  style={{ left: `${frame * zoom}px` }}
                  className="absolute top-0 bottom-0 border-l border-[#262e3f] pl-1 pt-1 text-[9px] font-mono text-neutral-500 pointer-events-none"
                >
                  {frame}f
                </div>
              ))}
            </div>

            {/* 2. Red / Cyan Playhead Indicator Line */}
            <div
              style={{ left: `${currentFrame * zoom}px` }}
              className="absolute top-0 bottom-0 w-px bg-cyan-400 z-30 pointer-events-none shadow-[0_0_8px_rgba(56,189,248,0.8)]"
            >
              <div className="w-3 h-3 bg-cyan-400 -translate-x-1/2 rotate-45 rounded-sm shadow-md" />
            </div>

            {/* 3. Layer Track Bars & Keyframes Canvas */}
            <div className="divide-y divide-[#1a1f2b]">
              {composition.layers.map((layer) => {
                const isExpanded = expandedLayers[layer.id];
                const layerStartPx = layer.inPoint * zoom;
                const layerWidthPx = (layer.outPoint - layer.inPoint) * zoom;

                return (
                  <div key={layer.id}>
                    {/* Master Layer Bar Row */}
                    <div className="h-7 relative flex items-center">
                      {/* Layer Span Bar */}
                      <div
                        style={{
                          left: `${layerStartPx}px`,
                          width: `${layerWidthPx}px`,
                          backgroundColor: `${layer.colorTag || '#3b82f6'}33`,
                          borderColor: layer.colorTag || '#3b82f6',
                        }}
                        className="h-5 rounded-sm border flex items-center justify-between px-2 text-[10px] font-semibold text-neutral-100 shadow-sm"
                      >
                        <span className="truncate">{layer.name}</span>
                        <span className="text-[9px] font-mono text-neutral-400">
                          {layer.outPoint - layer.inPoint}f
                        </span>
                      </div>
                    </div>

                    {/* Expanded Property Keyframe Sub-rows */}
                    {isExpanded && (
                      <div className="bg-[#0b0d13] divide-y divide-[#151822]">
                        {/* Position Property Row */}
                        <div className="h-5 relative flex items-center">
                          {layer.transform.position.keyframes?.map((kf) => (
                            <button
                              key={kf.id}
                              style={{ left: `${kf.frame * zoom}px` }}
                              onClick={() =>
                                setSelectedKeyframe({
                                  layerId: layer.id,
                                  propPath: 'transform.position',
                                  keyframeId: kf.id,
                                })
                              }
                              title={`Keyframe at frame ${kf.frame}`}
                              className="absolute -translate-x-1/2 w-2.5 h-2.5 bg-cyan-400 hover:bg-white rotate-45 shadow-md transition-colors"
                            />
                          ))}
                        </div>

                        {/* Scale Property Row */}
                        <div className="h-5 relative flex items-center">
                          {layer.transform.scale.keyframes?.map((kf) => (
                            <button
                              key={kf.id}
                              style={{ left: `${kf.frame * zoom}px` }}
                              className="absolute -translate-x-1/2 w-2.5 h-2.5 bg-cyan-400 hover:bg-white rotate-45 shadow-md"
                            />
                          ))}
                        </div>

                        {/* Rotation Property Row */}
                        <div className="h-5 relative flex items-center">
                          {layer.transform.rotation.keyframes?.map((kf) => (
                            <button
                              key={kf.id}
                              style={{ left: `${kf.frame * zoom}px` }}
                              className="absolute -translate-x-1/2 w-2.5 h-2.5 bg-cyan-400 hover:bg-white rotate-45 shadow-md"
                            />
                          ))}
                        </div>

                        {/* Opacity Property Row */}
                        <div className="h-5 relative flex items-center">
                          {layer.transform.opacity.keyframes?.map((kf) => (
                            <button
                              key={kf.id}
                              style={{ left: `${kf.frame * zoom}px` }}
                              className="absolute -translate-x-1/2 w-2.5 h-2.5 bg-cyan-400 hover:bg-white rotate-45 shadow-md"
                            />
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
