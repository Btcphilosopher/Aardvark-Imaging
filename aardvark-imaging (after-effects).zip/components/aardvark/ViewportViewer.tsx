'use client';

import React, { useRef, useEffect, useState, useCallback } from 'react';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Repeat,
  RotateCcw,
  Maximize,
  Tv,
  Grid as GridIcon,
  ZoomIn,
  Move,
} from 'lucide-react';
import {
  AardvarkComposition,
  AardvarkAsset,
  AardvarkLayer,
  Vector3D,
} from '@/lib/aardvark/types';
import { Compositor, RenderContext } from '@/lib/aardvark/rendering/compositor';
import { ActiveTool } from './ToolBar';
import { evaluateProperty } from '@/lib/aardvark/animation/evaluator';

interface ViewportViewerProps {
  composition: AardvarkComposition | null;
  allCompositions: AardvarkComposition[];
  assets: Map<string, AardvarkAsset>;
  assetElements: Map<string, HTMLImageElement | HTMLVideoElement | HTMLCanvasElement>;
  currentFrame: number;
  onSeekFrame: (frame: number) => void;
  isPlaying: boolean;
  onTogglePlay: () => void;
  selectedLayerIds: string[];
  activeTool: ActiveTool;
  showSafeMargins: boolean;
  showGrid: boolean;
  resolution: number;
  channel: 'rgb' | 'alpha' | 'red' | 'green' | 'blue';
  onUpdateLayerTransform: (layerId: string, transformUpdates: any) => void;
}

export const ViewportViewer: React.FC<ViewportViewerProps> = ({
  composition,
  allCompositions,
  assets,
  assetElements,
  currentFrame,
  onSeekFrame,
  isPlaying,
  onTogglePlay,
  selectedLayerIds,
  activeTool,
  showSafeMargins,
  showGrid,
  resolution,
  channel,
  onUpdateLayerTransform,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [containerSize, setContainerSize] = useState<{ width: number; height: number }>({
    width: 800,
    height: 600,
  });
  const [zoomLevel, setZoomLevel] = useState<number | 'fit'>('fit');
  const [panOffset, setPanOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDraggingGizmo, setIsDraggingGizmo] = useState<string | null>(null);
  const [gizmoDragStart, setGizmoDragStart] = useState<{ x: number; y: number; origPos: Vector3D }>({
    x: 0,
    y: 0,
    origPos: [0, 0, 0],
  });

  // Track container size with ResizeObserver
  useEffect(() => {
    if (!containerRef.current) return;
    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        if (entry.contentRect) {
          setContainerSize({
            width: entry.contentRect.width,
            height: entry.contentRect.height,
          });
        }
      }
    });
    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  // Calculate actual display scale
  const scale = React.useMemo(() => {
    if (!composition) return 0.5;
    if (typeof zoomLevel === 'number') return zoomLevel;

    const containerW = containerSize.width - 48;
    const containerH = containerSize.height - 80;
    if (containerW <= 0 || containerH <= 0) return 0.5;

    const scaleX = containerW / composition.width;
    const scaleY = containerH / composition.height;
    return Math.min(scaleX, scaleY, 1.0);
  }, [composition, zoomLevel, containerSize]);

  // Main Render Loop
  useEffect(() => {
    if (!composition || !canvasRef.current) return;

    const renderCtx: RenderContext = {
      composition,
      allCompositions,
      assets,
      assetElements,
      frame: currentFrame,
      scale: resolution,
    };

    Compositor.renderComposition(canvasRef.current, renderCtx);
  }, [composition, allCompositions, assets, assetElements, currentFrame, resolution]);

  // Format SMPTE Timecode: HH:MM:SS:FF
  const formatTimecode = (frame: number, fps: number = 30) => {
    const totalSeconds = Math.floor(frame / fps);
    const frames = Math.floor(frame % fps);
    const seconds = totalSeconds % 60;
    const minutes = Math.floor(totalSeconds / 60) % 60;
    const hours = Math.floor(totalSeconds / 3600);

    const pad = (n: number) => n.toString().padStart(2, '0');
    return `${pad(hours)}:${pad(minutes)}:${pad(seconds)}:${pad(frames)}`;
  };

  // Selected layer for gizmo
  const selectedLayer = composition?.layers.find((l) => selectedLayerIds.includes(l.id));

  // Transform evaluation for gizmo display
  const selectedPos = selectedLayer
    ? evaluateProperty<Vector3D>(selectedLayer.transform.position, currentFrame) || [
        composition?.width ? composition.width / 2 : 0,
        composition?.height ? composition.height / 2 : 0,
        0,
      ]
    : [0, 0, 0];

  // Mouse Handlers for Viewport Interactivity
  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button === 1 || activeTool === 'hand' || (e.altKey && activeTool === 'camera')) {
      // Middle button or Hand tool: Pan
      setIsPanning(true);
      setPanStart({ x: e.clientX - panOffset.x, y: e.clientY - panOffset.y });
      return;
    }

    // Layer transform drag
    if (selectedLayer && activeTool === 'select') {
      setIsDraggingGizmo('position');
      setGizmoDragStart({
        x: e.clientX,
        y: e.clientY,
        origPos: [...selectedPos] as Vector3D,
      });
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isPanning) {
      setPanOffset({
        x: e.clientX - panStart.x,
        y: e.clientY - panStart.y,
      });
      return;
    }

    if (isDraggingGizmo === 'position' && selectedLayer && composition) {
      const dx = (e.clientX - gizmoDragStart.x) / scale;
      const dy = (e.clientY - gizmoDragStart.y) / scale;

      const newPos: Vector3D = [
        Math.round(gizmoDragStart.origPos[0] + dx),
        Math.round(gizmoDragStart.origPos[1] + dy),
        gizmoDragStart.origPos[2],
      ];

      onUpdateLayerTransform(selectedLayer.id, {
        position: {
          ...selectedLayer.transform.position,
          value: newPos,
        },
      });
    }
  };

  const handleMouseUp = () => {
    setIsPanning(false);
    setIsDraggingGizmo(null);
  };

  if (!composition) {
    return (
      <div className="w-full h-full bg-[#0d0f15] flex items-center justify-center text-neutral-500">
        No active composition
      </div>
    );
  }

  const dispWidth = composition.width * scale;
  const dispHeight = composition.height * scale;

  return (
    <div
      id="aardvark-viewport-panel"
      ref={containerRef}
      className="w-full h-full bg-[#0b0d13] flex flex-col relative select-none overflow-hidden"
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
    >
      {/* Viewport Top Header Information */}
      <div className="h-7 bg-[#12151d] border-b border-[#202533] px-3 flex items-center justify-between text-[11px] text-neutral-400 z-10">
        <div className="flex items-center gap-2">
          <span className="text-cyan-400 font-bold">{composition.name}</span>
          <span>(Composition View)</span>
        </div>

        {/* Zoom selector */}
        <div className="flex items-center gap-2">
          <span className="text-neutral-500">Zoom:</span>
          <select
            value={zoomLevel === 'fit' ? 'fit' : zoomLevel}
            onChange={(e) => {
              const val = e.target.value;
              setZoomLevel(val === 'fit' ? 'fit' : parseFloat(val));
              if (val === 'fit') setPanOffset({ x: 0, y: 0 });
            }}
            className="bg-[#181c26] border border-[#2b3345] rounded px-1.5 py-0.5 text-neutral-200 text-[10px]"
          >
            <option value="fit">Fit (Auto)</option>
            <option value={0.25}>25%</option>
            <option value={0.5}>50%</option>
            <option value={0.75}>75%</option>
            <option value={1.0}>100%</option>
            <option value={1.5}>150%</option>
            <option value={2.0}>200%</option>
          </select>
          <button
            onClick={() => {
              setZoomLevel('fit');
              setPanOffset({ x: 0, y: 0 });
            }}
            title="Reset View (Fit to Screen)"
            className="p-1 hover:bg-[#1f2533] text-neutral-400 hover:text-cyan-400 rounded"
          >
            <Maximize className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Main Canvas Canvas Stage */}
      <div className="flex-1 relative flex items-center justify-center overflow-hidden bg-[radial-gradient(#1a202c_1px,transparent_1px)] [background-size:16px_16px]">
        <div
          style={{
            transform: `translate(${panOffset.x}px, ${panOffset.y}px)`,
            width: `${dispWidth}px`,
            height: `${dispHeight}px`,
          }}
          className="relative shadow-2xl transition-transform duration-75 flex-shrink-0"
        >
          {/* Main Renderer Canvas */}
          <canvas
            ref={canvasRef}
            style={{
              width: `${dispWidth}px`,
              height: `${dispHeight}px`,
            }}
            className="w-full h-full block bg-black border border-[#252b3b] shadow-2xl"
          />

          {/* Action / Title Safe Guides Overlay */}
          {showSafeMargins && (
            <div className="absolute inset-0 pointer-events-none border border-cyan-500/20">
              {/* Action Safe (90%) */}
              <div className="absolute inset-[5%] border border-cyan-400/40 border-dashed" />
              {/* Title Safe (80%) */}
              <div className="absolute inset-[10%] border border-cyan-400/60" />
              {/* Center Crosshair */}
              <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4">
                <div className="absolute top-1/2 left-0 right-0 h-px bg-cyan-400/80" />
                <div className="absolute left-1/2 top-0 bottom-0 w-px bg-cyan-400/80" />
              </div>
            </div>
          )}

          {/* Grid Overlay */}
          {showGrid && (
            <div className="absolute inset-0 pointer-events-none grid grid-cols-4 grid-rows-4 border border-cyan-500/20 divide-x divide-y divide-cyan-500/10" />
          )}

          {/* Interactive Selected Layer Gizmo */}
          {selectedLayer && selectedPos && (
            <div
              style={{
                left: `${selectedPos[0] * scale}px`,
                top: `${selectedPos[1] * scale}px`,
              }}
              className="absolute -translate-x-1/2 -translate-y-1/2 pointer-events-none"
            >
              {/* Anchor Point Crosshair */}
              <div className="w-5 h-5 rounded-full border-2 border-cyan-400 flex items-center justify-center shadow-lg bg-cyan-950/40">
                <div className="w-1.5 h-1.5 bg-cyan-300 rounded-full" />
              </div>

              {/* Layer Title Label */}
              <div className="absolute left-6 top-0 px-1.5 py-0.5 bg-cyan-950/90 border border-cyan-500/60 text-cyan-300 font-mono text-[9px] rounded whitespace-nowrap shadow-md">
                {selectedLayer.name} ({Math.round(selectedPos[0])}, {Math.round(selectedPos[1])})
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Viewport Bottom Transport Controls */}
      <div
        id="aardvark-transport-bar"
        className="h-10 bg-[#12151d] border-t border-[#202533] px-3 flex items-center justify-between text-xs text-neutral-300 z-10"
      >
        {/* Left: SMPTE Timecode & Frame Number */}
        <div className="flex items-center gap-3 font-mono">
          <div className="flex items-center gap-1.5 bg-[#181c26] px-2 py-0.5 rounded border border-[#262f42]">
            <span className="text-[10px] text-neutral-500 uppercase">TC</span>
            <span className="text-cyan-400 font-bold text-xs tracking-wider">
              {formatTimecode(currentFrame, composition.fps)}
            </span>
          </div>

          <div className="flex items-center gap-1.5 bg-[#181c26] px-2 py-0.5 rounded border border-[#262f42]">
            <span className="text-[10px] text-neutral-500 uppercase">FR</span>
            <span className="text-neutral-200 font-bold text-xs">
              {currentFrame} / {composition.durationFrames}
            </span>
          </div>
        </div>

        {/* Center: Transport Playback Buttons */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onSeekFrame(0)}
            title="Go to Beginning (Home)"
            className="p-1.5 hover:bg-[#1f2533] text-neutral-400 hover:text-cyan-400 rounded transition-colors"
          >
            <SkipBack className="w-4 h-4" />
          </button>

          <button
            onClick={() => onSeekFrame(Math.max(0, currentFrame - 1))}
            title="Previous Frame (Left Arrow)"
            className="p-1.5 hover:bg-[#1f2533] text-neutral-400 hover:text-cyan-400 rounded transition-colors text-xs font-mono"
          >
            -1f
          </button>

          <button
            id="btn-transport-play"
            onClick={onTogglePlay}
            title="Play / Stop (Spacebar)"
            className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
              isPlaying
                ? 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-md'
            }`}
          >
            {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
          </button>

          <button
            onClick={() => onSeekFrame(Math.min(composition.durationFrames, currentFrame + 1))}
            title="Next Frame (Right Arrow)"
            className="p-1.5 hover:bg-[#1f2533] text-neutral-400 hover:text-cyan-400 rounded transition-colors text-xs font-mono"
          >
            +1f
          </button>

          <button
            onClick={() => onSeekFrame(composition.durationFrames)}
            title="Go to End (End)"
            className="p-1.5 hover:bg-[#1f2533] text-neutral-400 hover:text-cyan-400 rounded transition-colors"
          >
            <SkipForward className="w-4 h-4" />
          </button>
        </div>

        {/* Right: Motion Blur & FPS Indicator */}
        <div className="flex items-center gap-3 text-[11px] font-mono text-neutral-400">
          <div className="flex items-center gap-1.5">
            <span
              className={`w-2 h-2 rounded-full ${
                isPlaying ? 'bg-emerald-400 animate-pulse' : 'bg-neutral-600'
              }`}
            />
            <span className="text-neutral-300 font-bold">{composition.fps} FPS</span>
          </div>

          <span className="px-1.5 py-0.5 rounded bg-[#181c26] text-neutral-400 text-[10px] border border-[#2b3345]">
            {composition.colorSpace}
          </span>
        </div>
      </div>
    </div>
  );
};
