'use client';

import React, { useState } from 'react';
import { X, Code, Check, Sparkles, AlertCircle } from 'lucide-react';

interface ExpressionModalProps {
  isOpen: boolean;
  onClose: () => void;
  propertyName: string;
  initialExpression: string;
  onSaveExpression: (expression: string) => void;
}

export const ExpressionModal: React.FC<ExpressionModalProps> = ({
  isOpen,
  onClose,
  propertyName,
  initialExpression,
  onSaveExpression,
}) => {
  const [expression, setExpression] = useState(initialExpression || '');
  const [testResult, setTestResult] = useState<string | null>(null);

  if (!isOpen) return null;

  const presets = [
    { label: 'Wiggle / Shake', code: 'wiggle(2, 40)' },
    { label: 'Continuous Rotation', code: '[0, 0, time * 90]' },
    { label: 'Sinusoidal Hover', code: '[value[0], value[1] + Math.sin(time * 4) * 35, value[2]]' },
    { label: 'Pulse Scale Bounce', code: '[100 + Math.sin(time * 6) * 15, 100 + Math.sin(time * 6) * 15, 100]' },
    { label: 'Linear Time Ramp', code: 'time * 100' },
  ];

  const handleTest = () => {
    try {
      const wiggle = (f: number, a: number) => a * 0.5;
      const clamp = (v: number, min: number, max: number) => Math.min(Math.max(v, min), max);
      const evalFn = new Function('time', 'frame', 'fps', 'value', 'wiggle', 'clamp', 'Math', `return (${expression});`);
      const res = evalFn(1.0, 30, 30, [960, 540, 0], wiggle, clamp, Math);
      setTestResult(`Valid Syntax! Evaluates to: ${JSON.stringify(res)}`);
    } catch (err: any) {
      setTestResult(`Syntax Error: ${err.message}`);
    }
  };

  const handleSave = () => {
    onSaveExpression(expression);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-[#151824] border border-[#2b3345] rounded-xl shadow-2xl w-full max-w-lg overflow-hidden text-xs text-neutral-200">
        <div className="px-4 py-3 bg-[#11131c] border-b border-[#232838] flex items-center justify-between">
          <div className="flex items-center gap-2 font-bold text-sm text-cyan-300">
            <Code className="w-4 h-4 text-cyan-400" />
            <span>Expression Editor: {propertyName}</span>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-[#1f2533] text-neutral-400 hover:text-white rounded">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 space-y-3">
          <div>
            <label className="text-[11px] text-neutral-400 block mb-1 font-semibold">
              Expression Code (JavaScript Math Sandboxed)
            </label>
            <textarea
              rows={4}
              value={expression}
              onChange={(e) => setExpression(e.target.value)}
              placeholder="e.g. wiggle(3, 50) or [value[0], value[1] + Math.sin(time*2)*40, 0]"
              className="w-full bg-[#10121a] border border-[#262e3e] rounded p-2.5 font-mono text-xs text-cyan-300 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Quick Snippet Pills */}
          <div>
            <span className="text-[10px] text-neutral-500 uppercase font-mono block mb-1">
              Expression Presets:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {presets.map((p) => (
                <button
                  key={p.label}
                  type="button"
                  onClick={() => setExpression(p.code)}
                  className="px-2 py-0.5 rounded bg-[#1c2230] hover:bg-cyan-600/30 text-[10px] text-cyan-400 border border-[#2b3548]"
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {testResult && (
            <div
              className={`p-2 rounded font-mono text-[10px] ${
                testResult.includes('Error')
                  ? 'bg-red-950/40 text-red-300 border border-red-800/40'
                  : 'bg-emerald-950/40 text-emerald-300 border border-emerald-800/40'
              }`}
            >
              {testResult}
            </div>
          )}

          <div className="pt-2 border-t border-[#232838] flex items-center justify-between">
            <button
              type="button"
              onClick={handleTest}
              className="px-3 py-1 bg-[#1e2536] hover:bg-[#283248] text-neutral-300 rounded text-xs"
            >
              Test Syntax
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3 py-1.5 bg-[#1f2533] hover:bg-[#283145] text-neutral-300 rounded text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSave}
                className="px-4 py-1.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-slate-950 font-bold rounded text-xs flex items-center gap-1.5"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Apply Expression</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
