'use client';

import React, { useState } from 'react';
import { X, Film, Check } from 'lucide-react';
import { AardvarkComposition, ColorSpace, BitDepth } from '@/lib/aardvark/types';

interface NewCompModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateComp: (compData: Partial<AardvarkComposition>) => void;
}

export const NewCompModal: React.FC<NewCompModalProps> = ({
  isOpen,
  onClose,
  onCreateComp,
}) => {
  const [name, setName] = useState('New Composition');
  const [preset, setPreset] = useState('1080p');
  const [width, setWidth] = useState(1920);
  const [height, setHeight] = useState(1080);
  const [fps, setFps] = useState(30);
  const [durationSeconds, setDurationSeconds] = useState(5);
  const [backgroundColor, setBackgroundColor] = useState('#000000');
  const [colorSpace, setColorSpace] = useState<ColorSpace>('sRGB');
  const [bitDepth, setBitDepth] = useState<BitDepth>('8-bit');

  if (!isOpen) return null;

  const handlePresetChange = (presetKey: string) => {
    setPreset(presetKey);
    if (presetKey === '1080p') {
      setWidth(1920);
      setHeight(1080);
      setFps(30);
    } else if (presetKey === '4k') {
      setWidth(3840);
      setHeight(2160);
      setFps(30);
    } else if (presetKey === '2k_cinema') {
      setWidth(2048);
      setHeight(1080);
      setFps(24);
    } else if (presetKey === 'social_vertical') {
      setWidth(1080);
      setHeight(1920);
      setFps(30);
    } else if (presetKey === '8k') {
      setWidth(7680);
      setHeight(4320);
      setFps(60);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onCreateComp({
      name,
      width,
      height,
      fps,
      durationFrames: Math.round(durationSeconds * fps),
      pixelAspectRatio: 1.0,
      colorSpace,
      bitDepth,
      backgroundColor,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-[#151824] border border-[#2b3345] rounded-xl shadow-2xl w-full max-w-lg overflow-hidden text-xs text-neutral-200">
        {/* Header */}
        <div className="px-4 py-3 bg-[#11131c] border-b border-[#232838] flex items-center justify-between">
          <div className="flex items-center gap-2 font-bold text-sm text-neutral-100">
            <Film className="w-4 h-4 text-cyan-400" />
            <span>Composition Settings</span>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-[#1f2533] text-neutral-400 hover:text-white rounded">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          {/* Name */}
          <div>
            <label className="text-[11px] font-semibold text-neutral-400 block mb-1">
              Composition Name
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-[#1c2230] border border-[#2b3345] rounded p-2 text-xs text-neutral-100 focus:outline-none focus:border-cyan-500 font-semibold"
            />
          </div>

          {/* Preset Selector */}
          <div>
            <label className="text-[11px] font-semibold text-neutral-400 block mb-1">
              Resolution Preset
            </label>
            <select
              value={preset}
              onChange={(e) => handlePresetChange(e.target.value)}
              className="w-full bg-[#1c2230] border border-[#2b3345] rounded p-2 text-xs text-neutral-100 focus:outline-none focus:border-cyan-500"
            >
              <option value="1080p">HD 1080p (1920 × 1080 @ 30fps)</option>
              <option value="4k">4K UHD (3840 × 2160 @ 30fps)</option>
              <option value="2k_cinema">2K DCI Cinema (2048 × 1080 @ 24fps)</option>
              <option value="social_vertical">Vertical Social 9:16 (1080 × 1920 @ 30fps)</option>
              <option value="8k">8K Ultra HD (7680 × 4320 @ 60fps)</option>
              <option value="custom">Custom Dimensions</option>
            </select>
          </div>

          {/* Dimensions */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-semibold text-neutral-400 block mb-1">
                Width (px)
              </label>
              <input
                type="number"
                min={64}
                max={8192}
                value={width}
                onChange={(e) => setWidth(parseInt(e.target.value) || 1920)}
                className="w-full bg-[#1c2230] border border-[#2b3345] rounded p-2 text-xs text-neutral-100 font-mono"
              />
            </div>
            <div>
              <label className="text-[11px] font-semibold text-neutral-400 block mb-1">
                Height (px)
              </label>
              <input
                type="number"
                min={64}
                max={8192}
                value={height}
                onChange={(e) => setHeight(parseInt(e.target.value) || 1080)}
                className="w-full bg-[#1c2230] border border-[#2b3345] rounded p-2 text-xs text-neutral-100 font-mono"
              />
            </div>
          </div>

          {/* Frame Rate & Duration */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-semibold text-neutral-400 block mb-1">
                Frame Rate (FPS)
              </label>
              <select
                value={fps}
                onChange={(e) => setFps(parseInt(e.target.value))}
                className="w-full bg-[#1c2230] border border-[#2b3345] rounded p-2 text-xs text-neutral-100 font-mono"
              >
                <option value={24}>24 fps (Film)</option>
                <option value={25}>25 fps (PAL)</option>
                <option value={30}>30 fps (Standard)</option>
                <option value={60}>60 fps (Smooth High-Frame Rate)</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] font-semibold text-neutral-400 block mb-1">
                Duration (Seconds)
              </label>
              <input
                type="number"
                min={1}
                max={120}
                value={durationSeconds}
                onChange={(e) => setDurationSeconds(parseFloat(e.target.value) || 5)}
                className="w-full bg-[#1c2230] border border-[#2b3345] rounded p-2 text-xs text-neutral-100 font-mono"
              />
            </div>
          </div>

          {/* Color Space & Background Color */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-semibold text-neutral-400 block mb-1">
                Color Pipeline
              </label>
              <select
                value={colorSpace}
                onChange={(e) => setColorSpace(e.target.value as ColorSpace)}
                className="w-full bg-[#1c2230] border border-[#2b3345] rounded p-2 text-xs text-neutral-100 font-mono"
              >
                <option value="sRGB">sRGB Standard</option>
                <option value="Rec.709">Rec.709 Broadcast</option>
                <option value="Display P3">Display P3 Wide Gamut</option>
                <option value="Linear sRGB">Linear sRGB (32-bit Float)</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] font-semibold text-neutral-400 block mb-1">
                Background Color
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={backgroundColor}
                  onChange={(e) => setBackgroundColor(e.target.value)}
                  className="w-8 h-8 rounded bg-transparent border-0 cursor-pointer"
                />
                <span className="font-mono text-neutral-300">{backgroundColor}</span>
              </div>
            </div>
          </div>

          {/* Footer Actions */}
          <div className="pt-2 border-t border-[#232838] flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 bg-[#1f2533] hover:bg-[#283145] text-neutral-300 rounded text-xs"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-slate-950 font-bold rounded text-xs flex items-center gap-1.5 shadow-md"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Create Composition</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
