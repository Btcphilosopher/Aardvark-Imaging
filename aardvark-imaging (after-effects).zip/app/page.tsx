'use client';

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { MenuBar } from '@/components/aardvark/MenuBar';
import { ToolBar, ActiveTool } from '@/components/aardvark/ToolBar';
import { ProjectPanel } from '@/components/aardvark/ProjectPanel';
import { ViewportViewer } from '@/components/aardvark/ViewportViewer';
import { TimelinePanel } from '@/components/aardvark/TimelinePanel';
import { InspectorPanel } from '@/components/aardvark/InspectorPanel';
import { NewCompModal } from '@/components/aardvark/Modals/NewCompModal';
import {
  AardvarkProject,
  AardvarkComposition,
  AardvarkLayer,
  AardvarkAsset,
  RenderJob,
  RenderFormat,
  LayerType,
} from '@/lib/aardvark/types';
import {
  createDefaultProject,
  serializeProject,
  deserializeProject,
} from '@/lib/aardvark/persistence/projectStore';
import { createAnimProperty } from '@/lib/aardvark/animation/evaluator';
import { RenderQueueManager } from '@/lib/aardvark/export/renderQueue';
import { MediaManager } from '@/lib/aardvark/media/mediaManager';

export default function AardvarkApp() {
  const [project, setProject] = useState<AardvarkProject>(createDefaultProject());
  const [history, setHistory] = useState<AardvarkProject[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);

  // Playback & Viewport state
  const [currentFrame, setCurrentFrame] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [activeTool, setActiveTool] = useState<ActiveTool>('select');
  const [snapping, setSnapping] = useState<boolean>(true);
  const [resolution, setResolution] = useState<number>(1);
  const [channel, setChannel] = useState<'rgb' | 'alpha' | 'red' | 'green' | 'blue'>('rgb');
  const [showSafeMargins, setShowSafeMargins] = useState<boolean>(false);
  const [showGrid, setShowGrid] = useState<boolean>(false);
  const [currentWorkspace, setCurrentWorkspace] = useState<string>('Standard');

  // Modals state
  const [isNewCompModalOpen, setIsNewCompModalOpen] = useState(false);

  // Asset Elements Map (Image/Video elements)
  const [assetElements, setAssetElements] = useState<
    Map<string, HTMLImageElement | HTMLVideoElement | HTMLCanvasElement>
  >(new Map());

  const animFrameIdRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number>(0);

  // Active Composition
  const activeComp =
    project.compositions.find((c) => c.id === project.activeCompId) ||
    project.compositions[0] ||
    null;

  const assetsMap = new Map<string, AardvarkAsset>(project.assets.map((a) => [a.id, a]));

  // Selected Layer
  const selectedLayer =
    activeComp?.layers.find((l) => activeComp.selectedLayerIds.includes(l.id)) || null;

  // Initialize and Preload Default Assets
  useEffect(() => {
    project.assets.forEach(async (asset) => {
      try {
        const elem = await MediaManager.loadAsset(asset);
        setAssetElements((prev) => new Map(prev).set(asset.id, elem));
      } catch (err) {
        console.error('Failed to preload asset:', err);
      }
    });
  }, []);

  // Push State to Undo History
  const pushHistory = useCallback((newProject: AardvarkProject) => {
    setHistory((prev) => [...prev.slice(0, historyIndex + 1), newProject]);
    setHistoryIndex((prev) => prev + 1);
    setProject(newProject);
  }, [historyIndex]);

  const handleUndo = useCallback(() => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      setProject(history[historyIndex - 1]);
    }
  }, [historyIndex, history]);

  const handleRedo = useCallback(() => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
      setProject(history[historyIndex + 1]);
    }
  }, [historyIndex, history]);

  const handleSaveProject = useCallback(() => {
    const json = serializeProject(project);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${project.name.replace(/\s+/g, '_')}.aardvark`;
    a.click();
  }, [project]);

  // Playback Loop via requestAnimationFrame
  useEffect(() => {
    if (!isPlaying || !activeComp) {
      if (animFrameIdRef.current) cancelAnimationFrame(animFrameIdRef.current);
      return;
    }

    const fps = activeComp.fps || 30;
    const frameIntervalMs = 1000 / fps;

    const loop = (timestamp: number) => {
      if (!lastTimeRef.current) lastTimeRef.current = timestamp;
      const elapsed = timestamp - lastTimeRef.current;

      if (elapsed >= frameIntervalMs) {
        setCurrentFrame((prev) => (prev >= activeComp.durationFrames ? 0 : prev + 1));
        lastTimeRef.current = timestamp;
      }
      animFrameIdRef.current = requestAnimationFrame(loop);
    };

    animFrameIdRef.current = requestAnimationFrame(loop);

    return () => {
      if (animFrameIdRef.current) cancelAnimationFrame(animFrameIdRef.current);
    };
  }, [isPlaying, activeComp]);

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Avoid hotkeys when typing in inputs/textareas
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement).tagName)) {
        return;
      }

      if (e.code === 'Space') {
        e.preventDefault();
        setIsPlaying((p) => !p);
      } else if (e.key === 'v' || e.key === 'V') {
        setActiveTool('select');
      } else if (e.key === 'h' || e.key === 'H') {
        setActiveTool('hand');
      } else if (e.key === 'z' || e.key === 'Z') {
        setActiveTool('zoom');
      } else if (e.key === 'w' || e.key === 'W') {
        setActiveTool('rotate');
      } else if (e.key === 'c' || e.key === 'C') {
        setActiveTool('camera');
      } else if (e.key === 'y' || e.key === 'Y') {
        setActiveTool('anchor');
      } else if (e.key === 'g' || e.key === 'G') {
        setActiveTool('pen');
      } else if (e.key === 't' || e.key === 'T') {
        setActiveTool('type');
      } else if ((e.ctrlKey || e.metaKey) && (e.key === 'z' || e.key === 'Z')) {
        e.preventDefault();
        if (e.shiftKey) handleRedo();
        else handleUndo();
      } else if ((e.ctrlKey || e.metaKey) && (e.key === 's' || e.key === 'S')) {
        e.preventDefault();
        handleSaveProject();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleUndo, handleRedo, handleSaveProject]);

  // ================= PROJECT ACTIONS =================

  const handleOpenProject = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.aardvark,application/json';
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const text = await file.text();
        try {
          const loaded = deserializeProject(text);
          pushHistory(loaded);
        } catch (err: any) {
          alert(`Error loading .aardvark project: ${err.message}`);
        }
      }
    };
    input.click();
  };

  const handleNewProject = () => {
    const newProj = createDefaultProject();
    pushHistory(newProj);
  };

  // ================= COMPOSITION ACTIONS =================
  const handleCreateComp = (compData: Partial<AardvarkComposition>) => {
    const newComp: AardvarkComposition = {
      id: 'comp_' + Math.random().toString(36).substring(2, 9),
      name: compData.name || 'New Composition',
      width: compData.width || 1920,
      height: compData.height || 1080,
      fps: compData.fps || 30,
      durationFrames: compData.durationFrames || 150,
      pixelAspectRatio: 1.0,
      colorSpace: compData.colorSpace || 'sRGB',
      bitDepth: compData.bitDepth || '8-bit',
      backgroundColor: compData.backgroundColor || '#000000',
      motionBlur: { enabled: true, shutterAngle: 180, shutterPhase: -90, samples: 16 },
      layers: [],
      selectedLayerIds: [],
    };

    const updatedComps = [...project.compositions, newComp];
    pushHistory({
      ...project,
      compositions: updatedComps,
      activeCompId: newComp.id,
    });
  };

  const handleSelectComp = (compId: string) => {
    setProject((prev) => ({ ...prev, activeCompId: compId }));
    setCurrentFrame(0);
  };

  // ================= LAYER ACTIONS =================
  const handleSelectLayer = (layerId: string, multiSelect = false) => {
    if (!activeComp) return;
    const selected = multiSelect
      ? activeComp.selectedLayerIds.includes(layerId)
        ? activeComp.selectedLayerIds.filter((id) => id !== layerId)
        : [...activeComp.selectedLayerIds, layerId]
      : [layerId];

    const updatedComps = project.compositions.map((c) =>
      c.id === activeComp.id ? { ...c, selectedLayerIds: selected } : c
    );
    setProject((prev) => ({ ...prev, compositions: updatedComps }));
  };

  const handleUpdateLayer = (layerId: string, updates: Partial<AardvarkLayer>) => {
    if (!activeComp) return;
    const updatedLayers = activeComp.layers.map((l) =>
      l.id === layerId ? { ...l, ...updates } : l
    );
    const updatedComps = project.compositions.map((c) =>
      c.id === activeComp.id ? { ...c, layers: updatedLayers } : c
    );
    pushHistory({ ...project, compositions: updatedComps });
  };

  const handleDeleteLayer = (layerId: string) => {
    if (!activeComp) return;
    const updatedLayers = activeComp.layers.filter((l) => l.id !== layerId);
    const updatedComps = project.compositions.map((c) =>
      c.id === activeComp.id
        ? {
            ...c,
            layers: updatedLayers,
            selectedLayerIds: c.selectedLayerIds.filter((id) => id !== layerId),
          }
        : c
    );
    pushHistory({ ...project, compositions: updatedComps });
  };

  const handleAddLayer = (type: LayerType) => {
    if (!activeComp) return;
    const id = 'layer_' + Math.random().toString(36).substring(2, 9);
    const name =
      type === 'text'
        ? 'Text Layer'
        : type === 'shape'
        ? 'Shape Layer'
        : type === 'solid'
        ? 'Solid Layer'
        : type === 'adjustment'
        ? 'Adjustment FX'
        : type === 'camera'
        ? 'Camera 35mm'
        : 'Null Object';

    const newLayer: AardvarkLayer = {
      id,
      name,
      type,
      inPoint: 0,
      outPoint: activeComp.durationFrames,
      startFrame: 0,
      colorTag:
        type === 'text'
          ? '#3b82f6'
          : type === 'shape'
          ? '#ec4899'
          : type === 'camera'
          ? '#ef4444'
          : '#10b981',
      is3D: type === 'camera',
      blendMode: 'normal',
      visible: true,
      solo: false,
      locked: false,
      motionBlur: true,
      masks: [],
      effects: [],
      transform: {
        position: createAnimProperty([activeComp.width / 2, activeComp.height / 2, 0]),
        scale: createAnimProperty([100, 100, 100]),
        rotation: createAnimProperty([0, 0, 0]),
        orientation: createAnimProperty([0, 0, 0]),
        anchorPoint: createAnimProperty([0, 0, 0]),
        opacity: createAnimProperty(100),
      },
      textData:
        type === 'text'
          ? {
              text: 'AARDVARK TEXT',
              fontFamily: 'Inter, sans-serif',
              fontSize: 72,
              fontWeight: '800',
              tracking: 50,
              leading: 1.2,
              alignment: 'center',
              fillColor: '#38bdf8',
              strokeColor: '#ffffff',
              strokeWidth: 0,
              strokeOverFill: false,
            }
          : undefined,
      shapeData:
        type === 'shape'
          ? {
              shapeType: 'rectangle',
              fillColor: '#ec4899',
              fillEnabled: true,
              strokeColor: '#ffffff',
              strokeWidth: 4,
              strokeEnabled: true,
              cornerRadius: 12,
              trimStart: createAnimProperty(0),
              trimEnd: createAnimProperty(100),
              trimOffset: createAnimProperty(0),
              repeaterCount: 1,
              repeaterOffset: [0, 0],
              repeaterScale: [100, 100],
              repeaterRotation: 0,
            }
          : undefined,
      solidColor: type === 'solid' ? '#4f46e5' : undefined,
    };

    const updatedLayers = [newLayer, ...activeComp.layers];
    const updatedComps = project.compositions.map((c) =>
      c.id === activeComp.id ? { ...c, layers: updatedLayers, selectedLayerIds: [newLayer.id] } : c
    );
    pushHistory({ ...project, compositions: updatedComps });
  };

  // Add Asset into Composition as a visual layer
  const handleAddAssetToComp = (assetId: string) => {
    const asset = assetsMap.get(assetId);
    if (!asset || !activeComp) return;

    const id = 'layer_' + Math.random().toString(36).substring(2, 9);
    const newLayer: AardvarkLayer = {
      id,
      name: asset.name,
      type: asset.type === 'video' ? 'video' : 'image',
      assetId: asset.id,
      inPoint: 0,
      outPoint: activeComp.durationFrames,
      startFrame: 0,
      colorTag: '#3b82f6',
      is3D: false,
      blendMode: 'normal',
      visible: true,
      solo: false,
      locked: false,
      motionBlur: false,
      masks: [],
      effects: [],
      transform: {
        position: createAnimProperty([
          activeComp.width / 2 - asset.width / 2,
          activeComp.height / 2 - asset.height / 2,
          0,
        ]),
        scale: createAnimProperty([100, 100, 100]),
        rotation: createAnimProperty([0, 0, 0]),
        orientation: createAnimProperty([0, 0, 0]),
        anchorPoint: createAnimProperty([0, 0, 0]),
        opacity: createAnimProperty(100),
      },
    };

    const updatedLayers = [newLayer, ...activeComp.layers];
    const updatedComps = project.compositions.map((c) =>
      c.id === activeComp.id ? { ...c, layers: updatedLayers, selectedLayerIds: [newLayer.id] } : c
    );
    pushHistory({ ...project, compositions: updatedComps });
  };

  // Add Effect to Selected Layer
  const handleAddEffectToSelected = (effectId: string) => {
    if (!selectedLayer || !activeComp) return;
    const newEffect = {
      id: 'fx_' + Math.random().toString(36).substring(2, 9),
      effectId,
      name: effectId.replace('_', ' ').toUpperCase(),
      enabled: true,
      parameters: {},
    };

    const currentEffects = selectedLayer.effects || [];
    handleUpdateLayer(selectedLayer.id, {
      effects: [...currentEffects, newEffect],
    });
  };

  // Add Keyframe on property
  const handleAddKeyframe = (layerId: string, propPath: string, value: any) => {
    const layer = activeComp?.layers.find((l) => l.id === layerId);
    if (!layer) return;

    const propName = propPath.split('.')[1] as keyof typeof layer.transform;
    const targetProp = layer.transform[propName];
    if (!targetProp) return;

    const newKf = {
      id: 'kf_' + Math.random().toString(36).substring(2, 9),
      frame: currentFrame,
      value: JSON.parse(JSON.stringify(value)),
      inInterpolation: 'bezier' as const,
      outInterpolation: 'bezier' as const,
    };

    const updatedKeyframes = [
      ...targetProp.keyframes.filter((k) => k.frame !== currentFrame),
      newKf,
    ].sort((a, b) => a.frame - b.frame);

    handleUpdateLayer(layerId, {
      transform: {
        ...layer.transform,
        [propName]: {
          ...targetProp,
          animated: true,
          keyframes: updatedKeyframes,
        },
      },
    });
  };

  // ================= RENDER QUEUE ACTIONS =================
  const handleAddRenderJob = (format: RenderFormat, resolutionScale: 1 | 0.5 | 0.25) => {
    if (!activeComp) return;
    const newJob: RenderJob = {
      id: 'job_' + Math.random().toString(36).substring(2, 9),
      compositionId: activeComp.id,
      compositionName: activeComp.name,
      outputName: `${activeComp.name.replace(/\s+/g, '_')}_render.${
        format === 'webm' ? 'webm' : format === 'mp4' ? 'mp4' : 'png'
      }`,
      format,
      resolutionScale,
      startFrame: 0,
      endFrame: activeComp.durationFrames,
      fps: activeComp.fps,
      quality: 'best',
      colorSpace: activeComp.colorSpace,
      status: 'queued',
      progress: 0,
      currentFrame: 0,
      totalFrames: activeComp.durationFrames,
    };

    setProject((prev) => ({
      ...prev,
      renderQueue: [newJob, ...prev.renderQueue],
    }));
  };

  const handleStartRender = async (jobId: string) => {
    const job = project.renderQueue.find((j) => j.id === jobId);
    if (!job || !activeComp) return;

    try {
      await RenderQueueManager.executeRenderJob(
        job,
        activeComp,
        project.compositions,
        assetsMap,
        assetElements,
        (updatedJob) => {
          setProject((prev) => ({
            ...prev,
            renderQueue: prev.renderQueue.map((j) => (j.id === updatedJob.id ? { ...updatedJob } : j)),
          }));
        }
      );
    } catch (err) {
      console.error('Render error:', err);
    }
  };

  const handleCancelRender = (jobId: string) => {
    RenderQueueManager.cancelCurrentRender();
  };

  return (
    <div className="flex flex-col w-screen h-screen bg-[#0d0f15] text-neutral-200 overflow-hidden font-sans">
      {/* 1. TOP MENU BAR */}
      <MenuBar
        project={project}
        activeComp={activeComp}
        onSaveProject={handleSaveProject}
        onOpenProject={handleOpenProject}
        onNewProject={handleNewProject}
        onNewComp={() => setIsNewCompModalOpen(true)}
        onAddLayer={handleAddLayer}
        onAddEffectToSelected={handleAddEffectToSelected}
        onUndo={handleUndo}
        onRedo={handleRedo}
        canUndo={historyIndex > 0}
        canRedo={historyIndex < history.length - 1}
        onOpenRenderQueue={() => {}}
        currentWorkspace={currentWorkspace}
        onSelectWorkspace={setCurrentWorkspace}
        onImportMedia={() => {}}
      />

      {/* 2. PRECISION TOOLBAR */}
      <ToolBar
        activeTool={activeTool}
        onSelectTool={setActiveTool}
        snapping={snapping}
        onToggleSnapping={() => setSnapping(!snapping)}
        resolution={resolution}
        onSelectResolution={setResolution}
        channel={channel}
        onSelectChannel={setChannel}
        showSafeMargins={showSafeMargins}
        onToggleSafeMargins={() => setShowSafeMargins(!showSafeMargins)}
        showGrid={showGrid}
        onToggleGrid={() => setShowGrid(!showGrid)}
      />

      {/* 3. MAIN WORKSPACE (DOCKABLE PANELS) */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* UPPER HALF: LEFT BIN | CENTER VIEWPORT | RIGHT INSPECTOR */}
        <div className="flex-1 flex overflow-hidden min-h-[320px]">
          {/* Left Panel: Project Assets & Comps (~280px) */}
          <div className="w-72 flex-shrink-0">
            <ProjectPanel
              project={project}
              activeComp={activeComp}
              onSelectComp={handleSelectComp}
              onNewComp={() => setIsNewCompModalOpen(true)}
              onAddAsset={(newAsset) => {
                pushHistory({
                  ...project,
                  assets: [newAsset, ...project.assets],
                });
              }}
              onDeleteAsset={(id) => {
                pushHistory({
                  ...project,
                  assets: project.assets.filter((a) => a.id !== id),
                });
              }}
              onAddAssetToComp={handleAddAssetToComp}
              onAddEffectToSelected={handleAddEffectToSelected}
              selectedLayerName={selectedLayer?.name}
            />
          </div>

          {/* Center Panel: Viewport Viewer (Fluid) */}
          <div className="flex-1 overflow-hidden">
            <ViewportViewer
              composition={activeComp}
              allCompositions={project.compositions}
              assets={assetsMap}
              assetElements={assetElements}
              currentFrame={currentFrame}
              onSeekFrame={setCurrentFrame}
              isPlaying={isPlaying}
              onTogglePlay={() => setIsPlaying(!isPlaying)}
              selectedLayerIds={activeComp?.selectedLayerIds || []}
              activeTool={activeTool}
              showSafeMargins={showSafeMargins}
              showGrid={showGrid}
              resolution={resolution}
              channel={channel}
              onUpdateLayerTransform={(layerId, transformUpdates) => {
                const layer = activeComp?.layers.find((l) => l.id === layerId);
                if (layer) {
                  handleUpdateLayer(layerId, {
                    transform: { ...layer.transform, ...transformUpdates },
                  });
                }
              }}
            />
          </div>

          {/* Right Panel: Properties & Effect Controls (~340px) */}
          <div className="w-80 flex-shrink-0">
            {activeComp && (
              <InspectorPanel
                composition={activeComp}
                allCompositions={project.compositions}
                assets={assetsMap}
                selectedLayer={selectedLayer}
                onUpdateLayer={handleUpdateLayer}
                onAddEffect={handleAddEffectToSelected}
                renderQueue={project.renderQueue}
                onAddRenderJob={handleAddRenderJob}
                onStartRender={handleStartRender}
                onCancelRender={handleCancelRender}
              />
            )}
          </div>
        </div>

        {/* LOWER HALF: PROFESSIONAL TIMELINE (Height ~280px) */}
        <div className="h-72 flex-shrink-0">
          {activeComp && (
            <TimelinePanel
              composition={activeComp}
              currentFrame={currentFrame}
              onSeekFrame={setCurrentFrame}
              selectedLayerIds={activeComp.selectedLayerIds}
              onSelectLayer={handleSelectLayer}
              onUpdateLayer={handleUpdateLayer}
              onDeleteLayer={handleDeleteLayer}
              onAddKeyframe={handleAddKeyframe}
              onUpdateKeyframe={() => {}}
              onRemoveKeyframe={() => {}}
            />
          )}
        </div>
      </div>

      {/* MODALS */}
      <NewCompModal
        isOpen={isNewCompModalOpen}
        onClose={() => setIsNewCompModalOpen(false)}
        onCreateComp={handleCreateComp}
      />
    </div>
  );
}
