import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Aardvark Imaging | Professional Motion Graphics & VFX Workstation',
  description: 'Professional Desktop Motion Graphics, Compositing, Animation and Visual Effects Workstation',
  openGraph: {
    title: 'Aardvark Imaging | Professional Motion Graphics & VFX Workstation',
    description: 'Professional Desktop Motion Graphics, Compositing, Animation and Visual Effects Workstation',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Aardvark Imaging | Professional Motion Graphics & VFX Workstation',
    description: 'Professional Desktop Motion Graphics, Compositing, Animation and Visual Effects Workstation',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
