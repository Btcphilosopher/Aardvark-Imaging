/**
 * THERMAL ARRAY.OS - Type Definitions
 * Industrial R-Centric Thermal Sensor Array Platform
 */

export type ResolutionPreset =
  | '8x8'
  | '16x16'
  | '32x32'
  | '64x64'
  | '128x128'
  | '256x192'
  | '320x256'
  | '640x512';

export type DisplayMode = 'RAW' | 'CALIBRATED' | 'FILTERED' | 'RECONSTRUCTED';

export type PaletteName = 'Iron' | 'Inferno' | 'Viridis' | 'Plasma' | 'Grayscale' | 'Blue-Red';

export type PixelStatus = 'GOOD' | 'WARNING' | 'BAD';

export type BadPixelType = 'NONE' | 'DEAD' | 'STUCK' | 'HOT' | 'NOISY' | 'DRIFTING';

export type InterpolationMethod =
  | 'nearest'
  | 'bilinear'
  | 'bicubic'
  | 'lanczos'
  | 'spline'
  | 'edge_aware';

export type TemporalFilterType =
  | 'none'
  | 'moving_average'
  | 'ema'
  | 'median'
  | 'savitzky_golay'
  | 'kalman'
  | 'adaptive';

export type SpatialFilterType =
  | 'none'
  | 'gaussian'
  | 'median'
  | 'bilateral'
  | 'laplacian'
  | 'edge_preserving';

export type CalibrationMethod =
  | 'two_point'
  | 'multi_point_poly'
  | 'robust_regression'
  | 'lookup_table';

export type AnomalyMethod =
  | 'z_score'
  | 'robust_z_score'
  | 'mad'
  | 'ewma'
  | 'cusum'
  | 'pca_error';

export type ScenarioType =
  | 'motor_bearing'
  | 'battery_pack'
  | 'electrical_panel'
  | 'building_facade'
  | 'industrial_pipe'
  | 'uniform_blackbody';

export type ActiveTab =
  | 'live_array'
  | 'sensor_config'
  | 'calibration'
  | 'filters'
  | 'reconstruction'
  | 'thermal_analysis'
  | 'detection'
  | 'time_series'
  | 'simulation'
  | 'r_architecture'
  | 'reports';

export interface SensorConfig {
  sensorId: string;
  width: number;
  height: number;
  samplingRate: number; // Hz (10, 25, 50, 100)
  integrationTime: number; // ms
  netd: number; // mK (Noise Equivalent Temperature Difference, e.g. 50 mK)
  snr: number; // dB
  noiseFloor: number; // °C
  adcResolution: number; // bits (e.g. 14-bit: 0 - 16383)
  ambientTemp: number; // °C
  referenceTemp: number; // °C
  emissivity: number; // 0.1 - 1.0
  reflectedTemp: number; // °C
  thermalConductivity: number; // W/(m*K)
  surfaceDistance: number; // m
}

export interface ThermalFrame {
  frameId: number;
  timestamp: number;
  sensorId: string;
  width: number;
  height: number;
  rawValues: Float32Array;
  calibratedValues: Float32Array;
  filteredValues: Float32Array;
  reconstructedValues?: Float32Array;
  reconstructedWidth?: number;
  reconstructedHeight?: number;
  qualityMask: Uint8Array; // 0: GOOD, 1: WARNING, 2: BAD
  badPixelTypes?: Uint8Array;
  ambientTemp: number;
  referenceTemp: number;
  emissivity: number;
  integrationTime: number;
  gain: number;
  offset: number;
  noiseEstimate: number;
  provenance: string[];
}

export interface FrameStatistics {
  min: number;
  max: number;
  mean: number;
  median: number;
  stdDev: number;
  p10: number;
  p25: number;
  p75: number;
  p90: number;
  range: number;
  estimatedNoise: number;
  badPixelCount: number;
}

export interface CalibrationModelData {
  method: CalibrationMethod;
  gainMap: Float32Array;
  offsetMap: Float32Array;
  gainMatrix?: Float32Array;
  offsetMatrix?: Float32Array;
  residuals: Float32Array;
  rmse: number;
  mae: number;
  r2: number;
  maxError: number;
  bias: number;
  referencePoints?: { refTemp: number; rawMean: number }[];
  isCalibrated?: boolean;
  calibratedAt?: string;
}

export interface PipelineConfig {
  enableCalibration: boolean;
  enableBadPixelCorrection: boolean;
  badPixelMethod: 'nearest' | 'bilinear' | 'local_median' | 'local_weighted_mean';
  enableNuc: boolean;
  temporalFilter: TemporalFilterType;
  temporalWindow: number;
  temporalAlpha: number;
  temporalProcessNoise: number;
  temporalMeasNoise: number;
  spatialFilter: SpatialFilterType;
  spatialKernelSize: number;
  spatialSigma: number;
  spatialSigmaColor: number;
  enableEmissivityCorrection: boolean;
  enableAmbientCompensation: boolean;
  reconstructionMethod: InterpolationMethod;
  reconstructionScale: 1 | 2 | 4;
}

export interface Hotspot {
  id: string;
  centroid: { x: number; y: number };
  area: number; // pixels
  maxTemp: number;
  meanTemp: number;
  tempGradient: number;
  confidence: number;
  persistence: number; // seconds
  baselineTemp: number;
  tempRise: number;
  boundingBox: { minX: number; minY: number; maxX: number; maxY: number };
}

export interface AnomalyResult {
  anomalyCount: number;
  method: AnomalyMethod;
  threshold: number;
  mask: Uint8Array;
  anomalousPixels: { x: number; y: number; temp: number; score: number }[];
  description: string;
}

export interface ROI {
  id: string;
  label: string;
  type: 'rectangle' | 'circle' | 'polygon';
  points: { x: number; y: number }[];
  color: string;
  stats?: {
    min: number;
    max: number;
    mean: number;
    stdDev: number;
    pixelCount: number;
    riseRate: number; // °C/s
    history: number[]; // last 50 timestamps
  };
}

export interface PixelInspection {
  x: number;
  y: number;
  raw: number;
  calibrated: number;
  filtered: number;
  reconstructed?: number;
  quality: PixelStatus;
  badType: BadPixelType;
  gain: number;
  offset: number;
  noise: number;
  residual: number;
  history: { timestamp: number; temp: number; raw: number }[];
}

export interface MaterialEmissivity {
  name: string;
  category: string;
  emissivity: number;
}

export interface RPackageDoc {
  name: string;
  description: string;
  exports: string[];
}
