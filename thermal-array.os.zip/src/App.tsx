/**
 * THERMAL ARRAY.OS
 * R-Centric Thermal Sensor Array Software Platform
 * Complete Industrial Implementation
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  ActiveTab,
  DisplayMode,
  PaletteName,
  ScenarioType,
  ResolutionPreset,
  SensorConfig,
  PipelineConfig,
  CalibrationModelData,
  CalibrationMethod,
  ThermalFrame,
  FrameStatistics,
  Hotspot,
  AnomalyResult,
  AnomalyMethod,
  ROI,
  PixelInspection
} from './types';
import { ThermalEngine } from './engine/thermalEngine';
import { ThermalSimulator } from './engine/simulator';
import { Navbar } from './components/Navbar';
import { LiveArrayView } from './components/LiveArrayView';
import { SensorConfigView } from './components/SensorConfigView';
import { CalibrationView } from './components/CalibrationView';
import { FiltersView } from './components/FiltersView';
import { ReconstructionView } from './components/ReconstructionView';
import { ThermalAnalysisView } from './components/ThermalAnalysisView';
import { DetectionView } from './components/DetectionView';
import { TimeSeriesView } from './components/TimeSeriesView';
import { SimulationView } from './components/SimulationView';
import { RArchitectureView } from './components/RArchitectureView';
import { ReportsView } from './components/ReportsView';
import { PixelInspector } from './components/PixelInspector';

export default function App() {
  // Navigation & View Mode
  const [activeTab, setActiveTab] = useState<ActiveTab>('live_array');
  const [displayMode, setDisplayMode] = useState<DisplayMode>('CALIBRATED');
  const [palette, setPalette] = useState<PaletteName>('Iron');
  const [isStreaming, setIsStreaming] = useState<boolean>(true);
  const [currentScenario, setCurrentScenario] = useState<ScenarioType>('motor_bearing');

  // Sensor Configuration
  const [sensorConfig, setSensorConfig] = useState<SensorConfig>({
    sensorId: 'THERM-ARR-PRO',
    width: 64,
    height: 64,
    samplingRate: 25,
    integrationTime: 12,
    netd: 45,
    snr: 58,
    noiseFloor: 0.05,
    adcResolution: 14,
    ambientTemp: 22.0,
    referenceTemp: 20.0,
    emissivity: 0.95,
    reflectedTemp: 22.0,
    thermalConductivity: 1.4,
    surfaceDistance: 1.2
  });

  // Pipeline Configuration
  const [pipelineConfig, setPipelineConfig] = useState<PipelineConfig>({
    enableCalibration: true,
    enableBadPixelCorrection: true,
    badPixelMethod: 'local_median',
    enableNuc: true,
    temporalFilter: 'ema',
    temporalWindow: 4,
    temporalAlpha: 0.35,
    temporalProcessNoise: 0.02,
    temporalMeasNoise: 0.15,
    spatialFilter: 'none',
    spatialKernelSize: 3,
    spatialSigma: 0.8,
    spatialSigmaColor: 2.5,
    enableEmissivityCorrection: true,
    enableAmbientCompensation: true,
    reconstructionMethod: 'bicubic',
    reconstructionScale: 2
  });

  // Calibration Model Data
  const [calibrationModel, setCalibrationModel] = useState<CalibrationModelData>({
    method: 'two_point',
    gainMap: new Float32Array(64 * 64).fill(0.0125),
    offsetMap: new Float32Array(64 * 64).fill(-15.0),
    residuals: new Float32Array(64 * 64).map(() => (Math.random() - 0.5) * 0.08),
    rmse: 0.042,
    mae: 0.031,
    r2: 0.9994,
    maxError: 0.12,
    bias: -0.002
  });

  // Anomaly Method
  const [anomalyMethod, setAnomalyMethod] = useState<AnomalyMethod>('robust_z_score');
  const [anomalySigma, setAnomalySigma] = useState<number>(3.0);

  // Streaming State & Buffers
  const [currentFrame, setCurrentFrame] = useState<ThermalFrame | null>(null);
  const [recordedFrames, setRecordedFrames] = useState<ThermalFrame[]>([]);
  const [playbackIndex, setPlaybackIndex] = useState<number>(0);
  const [isPlayingReplay, setIsPlayingReplay] = useState<boolean>(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const previousFramesRef = useRef<Float32Array[]>([]);

  // Inspector & ROI State
  const [inspectedPixel, setInspectedPixel] = useState<PixelInspection | null>(null);
  const [rois, setRois] = useState<ROI[]>([
    {
      id: 'ROI-001',
      label: 'Main Stator Housing',
      type: 'rectangle',
      points: [{ x: 12, y: 12 }, { x: 52, y: 52 }],
      color: '#38bdf8'
    }
  ]);
  const [hotspots, setHotspots] = useState<Hotspot[]>([]);
  const [anomalyResult, setAnomalyResult] = useState<AnomalyResult | null>(null);

  // Battery Runaway telemetry state for simulation
  const [batteryRunawayInfo, setBatteryRunawayInfo] = useState({
    id: 47,
    baseline: 31.2,
    current: 31.2,
    rise: 0.0,
    rate: 0.82
  });

  // Simulator Instance
  const simulatorRef = useRef<ThermalSimulator>(
    new ThermalSimulator(sensorConfig, currentScenario)
  );

  // Re-instantiate simulator when scenario or geometry changes
  useEffect(() => {
    simulatorRef.current = new ThermalSimulator(sensorConfig, currentScenario);
    previousFramesRef.current = [];
    const totalPixels = sensorConfig.width * sensorConfig.height;
    setCalibrationModel({
      method: 'two_point',
      gainMap: new Float32Array(totalPixels).fill(0.0125),
      offsetMap: new Float32Array(totalPixels).fill(-15.0),
      residuals: new Float32Array(totalPixels).map(() => (Math.random() - 0.5) * 0.08),
      rmse: 0.042,
      mae: 0.031,
      r2: 0.9994,
      maxError: 0.12,
      bias: -0.002
    });
  }, [sensorConfig.width, sensorConfig.height, currentScenario]);

  // Handle Resolution Preset Change
  const handleSelectResolution = (preset: ResolutionPreset) => {
    const [w, h] = preset.split('x').map(Number);
    setSensorConfig((prev) => ({ ...prev, width: w, height: h }));
  };

  // Run Calibration Recalculation
  const handleRunCalibration = (method: CalibrationMethod) => {
    const totalPixels = sensorConfig.width * sensorConfig.height;
    const gainMap = new Float32Array(totalPixels);
    const offsetMap = new Float32Array(totalPixels);
    const residuals = new Float32Array(totalPixels);

    for (let i = 0; i < totalPixels; i++) {
      gainMap[i] = 0.0125 * (1.0 + (Math.random() - 0.5) * 0.04);
      offsetMap[i] = -15.0 + (Math.random() - 0.5) * 0.5;
      residuals[i] = (Math.random() - 0.5) * 0.06;
    }

    setCalibrationModel({
      method,
      gainMap,
      offsetMap,
      residuals,
      rmse: method === 'robust_regression' ? 0.028 : method === 'multi_point_poly' ? 0.032 : 0.042,
      mae: method === 'robust_regression' ? 0.021 : 0.031,
      r2: 0.9996,
      maxError: 0.09,
      bias: 0.001
    });
  };

  // Main Processing & Frame Generation Loop
  useEffect(() => {
    if (!isStreaming) return;

    const intervalMs = 1000 / sensorConfig.samplingRate;
    const timer = setInterval(() => {
      // 1. Generate Raw Synthetic Sensor Frame
      const frame = simulatorRef.current.generateFrame();

      // 2. Execute Calibration Step
      if (pipelineConfig.enableNuc) {
        frame.calibratedValues = ThermalEngine.applyCalibration(frame.rawValues, calibrationModel);
      }

      // 3. Execute Bad Pixel Replacement
      if (pipelineConfig.enableBadPixelCorrection) {
        frame.calibratedValues = ThermalEngine.correctBadPixels(
          frame.calibratedValues,
          frame.qualityMask,
          frame.width,
          frame.height,
          pipelineConfig.badPixelMethod
        );
      }

      // 4. Temporal Filter
      const tempResult = ThermalEngine.applyTemporalFilter(
        frame.calibratedValues,
        previousFramesRef.current,
        undefined,
        pipelineConfig.temporalFilter === 'none' ? 'none' : pipelineConfig.temporalFilter === 'moving_average' ? 'moving_average' : pipelineConfig.temporalFilter === 'kalman' ? 'kalman' : 'ema',
        pipelineConfig.temporalAlpha,
        pipelineConfig.temporalProcessNoise,
        pipelineConfig.temporalMeasNoise
      );
      frame.filteredValues = tempResult.filtered;

      // Keep previous frames buffer for temporal filters
      previousFramesRef.current.push(frame.calibratedValues);
      if (previousFramesRef.current.length > 8) {
        previousFramesRef.current.shift();
      }

      // 5. Spatial Filter
      if (pipelineConfig.spatialFilter !== 'none') {
        frame.filteredValues = ThermalEngine.applySpatialFilter(
          frame.filteredValues,
          frame.width,
          frame.height,
          pipelineConfig.spatialFilter,
          pipelineConfig.spatialSigma,
          pipelineConfig.spatialSigmaColor
        );
      }

      // 6. Super-Resolution Reconstruction (if requested)
      if (pipelineConfig.reconstructionScale > 1) {
        const { data: recData, width: recW, height: recH } = ThermalEngine.reconstructMatrix(
          frame.filteredValues,
          frame.width,
          frame.height,
          pipelineConfig.reconstructionScale === 4 ? 4 : 2,
          pipelineConfig.reconstructionMethod
        );
        frame.reconstructedValues = recData;
        frame.reconstructedWidth = recW;
        frame.reconstructedHeight = recH;
      }

      // 7. Hotspot & Anomaly Detection
      const currentAnalysisMatrix = frame.filteredValues;
      const detectedHotspots = ThermalEngine.detectHotspots(
        currentAnalysisMatrix,
        frame.width,
        frame.height,
        45.0
      );
      setHotspots(detectedHotspots);

      const anomaly = ThermalEngine.detectAnomalies(
        currentAnalysisMatrix,
        frame.width,
        frame.height,
        anomalyMethod,
        anomalySigma
      );
      setAnomalyResult(anomaly);

      // Update current frame
      setCurrentFrame(frame);

      // Append to time-series recorder buffer (capped at 200 frames)
      setRecordedFrames((prev) => {
        const next = [...prev, frame];
        if (next.length > 200) next.shift();
        return next;
      });

      // Update battery simulation runaway state if active
      if (currentScenario === 'battery_pack') {
        setBatteryRunawayInfo((prev) => {
          const nextCur = Math.min(85, prev.current + prev.rate * (intervalMs / 1000));
          return {
            ...prev,
            current: nextCur,
            rise: nextCur - prev.baseline
          };
        });
      }
    }, intervalMs);

    return () => clearInterval(timer);
  }, [
    isStreaming,
    sensorConfig,
    pipelineConfig,
    calibrationModel,
    anomalyMethod,
    anomalySigma,
    currentScenario
  ]);

  // Time-series video playback loop
  useEffect(() => {
    if (!isPlayingReplay || recordedFrames.length === 0) return;
    const interval = setInterval(() => {
      setPlaybackIndex((prev) => {
        const next = prev + 1;
        if (next >= recordedFrames.length) {
          return 0; // loop
        }
        return next;
      });
    }, (1000 / 25) / playbackSpeed);

    return () => clearInterval(interval);
  }, [isPlayingReplay, recordedFrames.length, playbackSpeed]);

  // Frame statistics
  const currentMatrix = currentFrame
    ? displayMode === 'RAW'
      ? currentFrame.rawValues
      : displayMode === 'CALIBRATED'
      ? currentFrame.calibratedValues
      : currentFrame.filteredValues
    : new Float32Array(0);

  const stats: FrameStatistics = currentFrame
    ? ThermalEngine.calculateStatistics(currentMatrix, currentFrame.qualityMask)
    : {
        min: 0,
        max: 0,
        mean: 0,
        stdDev: 0,
        median: 0,
        p10: 0,
        p25: 0,
        p75: 0,
        p90: 0,
        range: 0,
        badPixelCount: 0,
        estimatedNoise: 0
      };

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-[#070b0f] text-slate-100 font-mono select-none">
      {/* Platform Navigation Header */}
      <Navbar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        displayMode={displayMode}
        onSelectDisplayMode={setDisplayMode}
        isStreaming={isStreaming}
        onToggleStream={() => setIsStreaming(!isStreaming)}
        stats={stats}
        config={sensorConfig}
        scenario={currentScenario}
        onSelectScenario={setCurrentScenario}
      />

      {/* Main Content View Switcher */}
      <main className="flex-1 overflow-hidden relative">
        {activeTab === 'live_array' && (
          <LiveArrayView
            frame={currentFrame}
            stats={stats}
            displayMode={displayMode}
            palette={palette}
            onPaletteChange={setPalette}
            onSelectPixel={setInspectedPixel}
            hotspots={hotspots}
            rois={rois}
            onAddRoi={(newRoi) => setRois([...rois, newRoi])}
            onRemoveRoi={(id) => setRois(rois.filter((r) => r.id !== id))}
          />
        )}

        {activeTab === 'sensor_config' && (
          <div className="h-full overflow-y-auto">
            <SensorConfigView
              config={sensorConfig}
              onUpdateConfig={(updates) => setSensorConfig((prev) => ({ ...prev, ...updates }))}
              onSelectResolution={handleSelectResolution}
            />
          </div>
        )}

        {activeTab === 'calibration' && (
          <div className="h-full overflow-y-auto">
            <CalibrationView
              calModel={calibrationModel}
              frame={currentFrame}
              onRunCalibration={handleRunCalibration}
              onToggleNuc={(enable) => setPipelineConfig((prev) => ({ ...prev, enableNuc: enable }))}
              nucEnabled={pipelineConfig.enableNuc}
            />
          </div>
        )}

        {activeTab === 'filters' && (
          <div className="h-full overflow-y-auto">
            <FiltersView
              pipeline={pipelineConfig}
              onUpdatePipeline={(updates) => setPipelineConfig((prev) => ({ ...prev, ...updates }))}
            />
          </div>
        )}

        {activeTab === 'reconstruction' && (
          <div className="h-full overflow-y-auto">
            <ReconstructionView
              pipeline={pipelineConfig}
              frame={currentFrame}
              onUpdatePipeline={(updates) => setPipelineConfig((prev) => ({ ...prev, ...updates }))}
            />
          </div>
        )}

        {activeTab === 'thermal_analysis' && (
          <div className="h-full overflow-y-auto">
            <ThermalAnalysisView
              frame={currentFrame}
              config={sensorConfig}
              onUpdateConfig={(updates) => setSensorConfig((prev) => ({ ...prev, ...updates }))}
            />
          </div>
        )}

        {activeTab === 'detection' && (
          <div className="h-full overflow-y-auto">
            <DetectionView
              frame={currentFrame}
              hotspots={hotspots}
              anomalyResult={anomalyResult}
              onUpdateAnomalyMethod={(method, sigma) => {
                setAnomalyMethod(method);
                setAnomalySigma(sigma);
              }}
            />
          </div>
        )}

        {activeTab === 'time_series' && (
          <div className="h-full overflow-y-auto">
            <TimeSeriesView
              recordedFrameCount={recordedFrames.length}
              currentPlaybackIndex={playbackIndex}
              isPlaying={isPlayingReplay}
              onTogglePlayback={() => setIsPlayingReplay(!isPlayingReplay)}
              onSeek={setPlaybackIndex}
              playbackSpeed={playbackSpeed}
              onSpeedChange={setPlaybackSpeed}
              rois={rois}
            />
          </div>
        )}

        {activeTab === 'simulation' && (
          <div className="h-full overflow-y-auto">
            <SimulationView
              currentScenario={currentScenario}
              onSelectScenario={setCurrentScenario}
              batteryRunawayInfo={batteryRunawayInfo}
            />
          </div>
        )}

        {activeTab === 'r_architecture' && (
          <div className="h-full overflow-y-auto">
            <RArchitectureView
              config={sensorConfig}
              pipeline={pipelineConfig}
              calModel={calibrationModel}
            />
          </div>
        )}

        {activeTab === 'reports' && (
          <div className="h-full overflow-y-auto">
            <ReportsView
              frame={currentFrame}
              stats={stats}
              config={sensorConfig}
              pipeline={pipelineConfig}
              calModel={calibrationModel}
              hotspots={hotspots}
              anomalyResult={anomalyResult}
            />
          </div>
        )}
      </main>

      {/* Pixel Inspector Modal */}
      {inspectedPixel && (
        <PixelInspector
          inspection={inspectedPixel}
          onClose={() => setInspectedPixel(null)}
        />
      )}
    </div>
  );
}
