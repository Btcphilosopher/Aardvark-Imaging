/**
 * THERMAL ARRAY.OS - Scientific Thermal Palettes
 * Exact RGB mappings for Iron, Inferno, Viridis, Plasma, Grayscale, Blue-Red
 */

import { PaletteName } from '../types';

export interface RGBColor {
  r: number;
  g: number;
  b: number;
}

export class ThermalPalettes {
  // Key color control points for standard scientific palettes
  private static readonly PALETTE_STOPS: Record<PaletteName, { pos: number; r: number; g: number; b: number }[]> = {
    Iron: [
      { pos: 0.0, r: 0, g: 0, b: 0 },
      { pos: 0.2, r: 40, g: 10, b: 80 },
      { pos: 0.4, r: 160, g: 20, b: 90 },
      { pos: 0.6, r: 230, g: 90, b: 20 },
      { pos: 0.8, r: 255, g: 200, b: 20 },
      { pos: 1.0, r: 255, g: 255, b: 255 }
    ],
    Inferno: [
      { pos: 0.0, r: 0, g: 0, b: 4 },
      { pos: 0.25, r: 87, g: 16, b: 110 },
      { pos: 0.5, r: 187, g: 55, b: 84 },
      { pos: 0.75, r: 249, g: 142, b: 9 },
      { pos: 1.0, r: 252, g: 255, b: 164 }
    ],
    Viridis: [
      { pos: 0.0, r: 68, g: 1, b: 84 },
      { pos: 0.25, r: 59, g: 82, b: 139 },
      { pos: 0.5, r: 33, g: 145, b: 140 },
      { pos: 0.75, r: 94, g: 201, b: 98 },
      { pos: 1.0, r: 253, g: 231, b: 37 }
    ],
    Plasma: [
      { pos: 0.0, r: 13, g: 8, b: 135 },
      { pos: 0.25, r: 126, g: 3, b: 168 },
      { pos: 0.5, r: 204, g: 71, b: 120 },
      { pos: 0.75, r: 248, g: 149, b: 64 },
      { pos: 1.0, r: 240, g: 249, b: 33 }
    ],
    Grayscale: [
      { pos: 0.0, r: 0, g: 0, b: 0 },
      { pos: 0.5, r: 128, g: 128, b: 128 },
      { pos: 1.0, r: 255, g: 255, b: 255 }
    ],
    'Blue-Red': [
      { pos: 0.0, r: 30, g: 60, b: 220 },
      { pos: 0.25, r: 80, g: 180, b: 240 },
      { pos: 0.5, r: 240, g: 240, b: 240 },
      { pos: 0.75, r: 240, g: 140, b: 50 },
      { pos: 1.0, r: 220, g: 30, b: 30 }
    ]
  };

  /**
   * Maps a normalized value [0, 1] to RGB colour in the specified palette
   */
  public static getColor(normalized: number, palette: PaletteName = 'Iron'): RGBColor {
    const clamped = Math.max(0, Math.min(1, normalized));
    const stops = this.PALETTE_STOPS[palette] || this.PALETTE_STOPS.Iron;

    // Find bounding stops
    for (let i = 0; i < stops.length - 1; i++) {
      const s0 = stops[i];
      const s1 = stops[i + 1];
      if (clamped >= s0.pos && clamped <= s1.pos) {
        const factor = (clamped - s0.pos) / (s1.pos - s0.pos);
        return {
          r: Math.round(s0.r + factor * (s1.r - s0.r)),
          g: Math.round(s0.g + factor * (s1.g - s0.g)),
          b: Math.round(s0.b + factor * (s1.b - s0.b))
        };
      }
    }

    const last = stops[stops.length - 1];
    return { r: last.r, g: last.g, b: last.b };
  }

  /**
   * Generates a 256-entry Uint8Array LUT for rapid canvas rendering [r, g, b, 255, ...]
   */
  public static generateLUT(palette: PaletteName = 'Iron'): Uint8Array {
    const lut = new Uint8Array(256 * 4);
    for (let i = 0; i < 256; i++) {
      const c = this.getColor(i / 255, palette);
      lut[i * 4] = c.r;
      lut[i * 4 + 1] = c.g;
      lut[i * 4 + 2] = c.b;
      lut[i * 4 + 3] = 255;
    }
    return lut;
  }
}
