/**
 * THERMAL ARRAY.OS - Deterministic Physical Thermal Simulator
 * Generates synthetic thermal scenes with realistic physics, noise, drift, and non-uniformity.
 */

import { ScenarioType, SensorConfig, ThermalFrame } from '../types';
import { ThermalEngine } from './thermalEngine';

export class ThermalSimulator {
  private config: SensorConfig;
  private currentFrameIndex: number = 0;
  private scenario: ScenarioType = 'motor_bearing';
  private frameRate: number = 25; // Hz
  private startTime: number = Date.now();
  private gainPattern: Float32Array;
  private offsetPattern: Float32Array;
  private fixedDeadPixels: Set<number> = new Set();
  private fixedHotPixels: Set<number> = new Set();

  // Battery pack runaway tracking
  private batteryCellTemperatures: number[] = [];
  private batteryRunawayCellIndex: number = 47; // Cell 47 runaway demo
  private batteryRunawayElapsed: number = 0;

  // Electrical panel persistence
  private electricalHotspotElapsed: number = 0;

  constructor(config: SensorConfig, scenario: ScenarioType = 'motor_bearing') {
    this.config = config;
    this.scenario = scenario;
    this.gainPattern = new Float32Array(config.width * config.height);
    this.offsetPattern = new Float32Array(config.width * config.height);
    this.initializeNonUniformity();
    this.initializeBatteryPack();
  }

  public setScenario(scenario: ScenarioType) {
    this.scenario = scenario;
    this.currentFrameIndex = 0;
    this.batteryRunawayElapsed = 0;
    this.electricalHotspotElapsed = 0;
    this.initializeBatteryPack();
  }

  public setResolution(width: number, height: number) {
    this.config.width = width;
    this.config.height = height;
    this.gainPattern = new Float32Array(width * height);
    this.offsetPattern = new Float32Array(width * height);
    this.initializeNonUniformity();
  }

  public updateConfig(newConfig: Partial<SensorConfig>) {
    Object.assign(this.config, newConfig);
    if (newConfig.width || newConfig.height) {
      this.gainPattern = new Float32Array(this.config.width * this.config.height);
      this.offsetPattern = new Float32Array(this.config.width * this.config.height);
      this.initializeNonUniformity();
    }
  }

  private initializeNonUniformity() {
    const total = this.config.width * this.config.height;
    this.fixedDeadPixels.clear();
    this.fixedHotPixels.clear();

    // Pseudo-random deterministic noise pattern based on sensor seed
    for (let i = 0; i < total; i++) {
      // Gain non-uniformity: standard normal around 1.0 (± 2.5%)
      const gNoise = (Math.sin(i * 12.9898 + 78.233) * 43758.5453) % 1;
      this.gainPattern[i] = 1.0 + gNoise * 0.035;

      // Offset non-uniformity: ± 150 ADC counts
      const oNoise = (Math.cos(i * 39.346 + 11.135) * 23421.631) % 1;
      this.offsetPattern[i] = oNoise * 180.0;
    }

    // Inject fixed bad pixels (0.3% of pixels)
    const badCount = Math.max(2, Math.floor(total * 0.003));
    for (let k = 0; k < badCount; k++) {
      const pIdx = Math.floor(((k * 9301 + 49297) % 233280) / 233280 * total);
      if (k % 2 === 0) {
        this.fixedDeadPixels.add(pIdx);
      } else {
        this.fixedHotPixels.add(pIdx);
      }
    }
  }

  private initializeBatteryPack() {
    this.batteryCellTemperatures = [];
    const cellCount = 8 * 12; // 96 cells
    for (let i = 0; i < cellCount; i++) {
      // Baseline cell temperatures around 31.5°C ± 0.6°C
      this.batteryCellTemperatures.push(31.2 + (Math.sin(i * 1.7) * 0.5));
    }
  }

  /**
   * Generates next thermal ground truth field (°C)
   */
  public generateGroundTruth(tSeconds: number): Float32Array {
    const { width, height, ambientTemp } = this.config;
    const total = width * height;
    const truth = new Float32Array(total);

    if (this.scenario === 'motor_bearing') {
      // SYNTHETIC INDUSTRIAL MOTOR DEMO:
      // Ambient: 22°C
      // Motor housing: 38°C (central cylindrical profile)
      // Bearing Hotspot: 72°C (offset right shaft bearing with thermal dissipation gradient)
      const centerX = width * 0.45;
      const centerY = height * 0.5;
      const bearingX = width * 0.68;
      const bearingY = height * 0.5;

      for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
          const idx = y * width + x;
          const nx = (x - centerX) / (width * 0.35);
          const ny = (y - centerY) / (height * 0.3);
          const distHousing = Math.sqrt(nx * nx + ny * ny);

          // Base ambient
          let temp = ambientTemp;

          // Motor Housing thermal envelope
          if (distHousing < 1.0) {
            const profile = Math.cos(distHousing * Math.PI * 0.5);
            temp = ambientTemp + (38.0 - ambientTemp) * profile;
          }

          // Motor Stator Fins pattern
          const finMod = Math.sin(x * 0.6) * 1.2;
          if (distHousing < 0.8) {
            temp += finMod;
          }

          // Bearing Hotspot at 72°C with radial conduction decay
          const bDist = Math.sqrt(Math.pow(x - bearingX, 2) + Math.pow(y - bearingY, 2));
          const bearingRadius = Math.max(2, width * 0.08);
          if (bDist < bearingRadius * 3.5) {
            const bProfile = Math.exp(-0.5 * Math.pow(bDist / (bearingRadius * 1.1), 2));
            const bearingPeak = 72.4 + Math.sin(tSeconds * 0.8) * 0.6;
            temp = Math.max(temp, ambientTemp + (bearingPeak - ambientTemp) * bProfile);
          }

          truth[idx] = temp;
        }
      }
    } else if (this.scenario === 'battery_pack') {
      // BATTERY PACK DEMO:
      // 8 × 12 battery cell matrix (96 cells)
      // Cell 47 gradually undergoes thermal runaway: 31°C -> 55.2°C at +0.82°C/s
      this.batteryRunawayElapsed += (1 / this.frameRate);
      const runawayRise = Math.min(24.5, this.batteryRunawayElapsed * 0.82);
      this.batteryCellTemperatures[this.batteryRunawayCellIndex] = 32.1 + runawayRise;

      const cols = 12;
      const rows = 8;
      const cellW = width / cols;
      const cellH = height / rows;

      for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
          const idx = y * width + x;
          const cellCol = Math.min(cols - 1, Math.floor(x / cellW));
          const cellRow = Math.min(rows - 1, Math.floor(y / cellH));
          const cellId = cellRow * cols + cellCol;

          // Distance from cell center (cylindrical cell look)
          const cellCenterX = (cellCol + 0.5) * cellW;
          const cellCenterY = (cellRow + 0.5) * cellH;
          const dx = (x - cellCenterX) / (cellW * 0.42);
          const dy = (y - cellCenterY) / (cellH * 0.42);
          const cellRadius = Math.sqrt(dx * dx + dy * dy);

          let cellTemp = this.batteryCellTemperatures[cellId] || 31.5;

          if (cellRadius <= 1.0) {
            // Inside cell body
            const radialDecay = 1.0 - 0.15 * cellRadius;
            truth[idx] = cellTemp * radialDecay;
          } else {
            // Gap / cooling channel between cells
            const gapTemp = ambientTemp + 3.0;
            truth[idx] = gapTemp;
          }
        }
      }
    } else if (this.scenario === 'electrical_panel') {
      // ELECTRICAL PANEL DEMO:
      // Busbars (41.8°C baseline), Breakers, loose connector overheating at 72.4°C (+30.6°C rise, 14.2s persistence)
      this.electricalHotspotElapsed += (1 / this.frameRate);

      for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
          const idx = y * width + x;
          let temp = ambientTemp + 4.0; // cabinet ambient 26°C

          // Three vertical 3-phase busbars (L1, L2, L3)
          const bar1 = Math.abs(x - width * 0.28) < width * 0.05;
          const bar2 = Math.abs(x - width * 0.50) < width * 0.05;
          const bar3 = Math.abs(x - width * 0.72) < width * 0.05;

          if (bar1 || bar2 || bar3) {
            temp = 41.8; // baseline nominal loaded busbar
          }

          // Faulty Overheating L2 Lug / Connector at (0.50 * W, 0.38 * H)
          const connDist = Math.sqrt(Math.pow(x - width * 0.50, 2) + Math.pow(y - height * 0.38, 2));
          if (connDist < width * 0.14) {
            const profile = Math.exp(-0.5 * Math.pow(connDist / (width * 0.045), 2));
            temp = 41.8 + 30.6 * profile; // Reaches 72.4°C peak!
          }

          truth[idx] = temp;
        }
      }
    } else if (this.scenario === 'building_facade') {
      // BUILDING FACADE DEMO:
      // Wall (14°C cold exterior), Window (18°C), Door (16°C), Roof (12°C), Major insulation thermal leakage zone (26°C leak)
      for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
          const idx = y * width + x;
          let temp = 14.2; // cold outer concrete wall

          // Roof upper 20%
          if (y < height * 0.22) {
            temp = 11.8;
          }

          // Windows (2 windows)
          const win1 = (x > width * 0.15 && x < width * 0.38 && y > height * 0.32 && y < height * 0.58);
          const win2 = (x > width * 0.62 && x < width * 0.85 && y > height * 0.32 && y < height * 0.58);
          if (win1 || win2) {
            temp = 18.5; // thermal glass radiative loss
          }

          // Insulation Leak / Fault around window 1 corner
          const leakDist = Math.sqrt(Math.pow(x - width * 0.38, 2) + Math.pow(y - height * 0.34, 2));
          if (leakDist < width * 0.12) {
            const leakProfile = Math.exp(-0.5 * Math.pow(leakDist / (width * 0.04), 2));
            temp = Math.max(temp, 14.2 + 12.8 * leakProfile); // 27°C heat leakage
          }

          truth[idx] = temp;
        }
      }
    } else if (this.scenario === 'industrial_pipe') {
      // INDUSTRIAL PIPE DEMO:
      // High pressure steam pipe with thermal conduction gradient and localized insulation degradation
      for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
          const idx = y * width + x;
          const pipeCenterY = height * 0.5;
          const distFromPipe = Math.abs(y - pipeCenterY) / (height * 0.22);

          let temp = ambientTemp;
          if (distFromPipe <= 1.0) {
            // Internal fluid heat (95°C steam decaying along length x)
            const fluidGradient = 95.0 - (x / width) * 22.0;
            const radialWall = Math.cos(distFromPipe * Math.PI * 0.5);
            temp = ambientTemp + (fluidGradient - ambientTemp) * radialWall;

            // Insulation crack at x = 0.55
            const crackDist = Math.sqrt(Math.pow(x - width * 0.55, 2) + Math.pow(y - pipeCenterY, 2));
            if (crackDist < width * 0.1) {
              temp += (102.0 - temp) * Math.exp(-crackDist / (width * 0.03));
            }
          }

          truth[idx] = temp;
        }
      }
    } else {
      // Uniform Blackbody Reference (e.g. 35.0°C)
      for (let i = 0; i < total; i++) truth[i] = 35.0;
    }

    return truth;
  }

  /**
   * Simulates full sensor transduction:
   * Raw ADC = Gain_ij * (Truth_ij - Offset_ij) / scale + SensorNoise + BadPixels
   */
  public generateFrame(): ThermalFrame {
    this.currentFrameIndex++;
    const tSeconds = this.currentFrameIndex / this.frameRate;
    const { width, height, ambientTemp, referenceTemp, emissivity, integrationTime, netd } = this.config;
    const total = width * height;

    const truth = this.generateGroundTruth(tSeconds);
    const rawValues = new Float32Array(total);
    const qualityMask = new Uint8Array(total);
    const badPixelTypes = new Uint8Array(total);

    // ADC Transfer characteristics: e.g. -20°C -> 1000 counts, 150°C -> 15000 counts (~82 counts/°C)
    const countsPerDeg = 80.0;
    const zeroDegOffset = 2600.0;
    const netdCounts = (netd / 1000.0) * countsPerDeg; // NETD in ADC counts

    for (let i = 0; i < total; i++) {
      const tempTruth = truth[i];

      // 1. Ideal linear transduction
      let adcIdeal = zeroDegOffset + tempTruth * countsPerDeg;

      // 2. Non-uniformity response (FPN)
      adcIdeal = adcIdeal * this.gainPattern[i] + this.offsetPattern[i];

      // 3. Temporal Gaussian thermal noise (NETD proxy)
      const u1 = Math.random() || 0.0001;
      const u2 = Math.random() || 0.0001;
      const gNoise = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2) * netdCounts;

      let adcRaw = adcIdeal + gNoise;

      // 4. Quantisation & ADC clamping (14-bit ADC: 0 - 16383)
      adcRaw = Math.max(0, Math.min(16383, Math.round(adcRaw)));

      // 5. Bad pixel corruption
      if (this.fixedDeadPixels.has(i)) {
        adcRaw = 0;
        qualityMask[i] = 2;
        badPixelTypes[i] = 1; // DEAD
      } else if (this.fixedHotPixels.has(i)) {
        adcRaw = 16383;
        qualityMask[i] = 2;
        badPixelTypes[i] = 3; // HOT
      }

      rawValues[i] = adcRaw;
    }

    // Default basic calibrated value for un-calibrated fallback: (raw - zeroDegOffset) / countsPerDeg
    const calibratedValues = new Float32Array(total);
    for (let i = 0; i < total; i++) {
      calibratedValues[i] = (rawValues[i] - zeroDegOffset) / countsPerDeg;
    }

    return {
      frameId: this.currentFrameIndex,
      timestamp: Date.now(),
      sensorId: this.config.sensorId,
      width,
      height,
      rawValues,
      calibratedValues,
      filteredValues: new Float32Array(calibratedValues),
      qualityMask,
      badPixelTypes,
      ambientTemp,
      referenceTemp,
      emissivity,
      integrationTime,
      gain: 1.0,
      offset: 0.0,
      noiseEstimate: netd / 1000.0, // in °C
      provenance: ['RAW_SENSOR_ACQUISITION']
    };
  }

  public getBatteryCellTemperatures(): number[] {
    return [...this.batteryCellTemperatures];
  }

  public getBatteryRunawayCell(): { id: number; baseline: number; current: number; rise: number; rate: number } {
    const current = this.batteryCellTemperatures[this.batteryRunawayCellIndex] || 55.2;
    const baseline = 32.1;
    return {
      id: this.batteryRunawayCellIndex,
      baseline,
      current: Number(current.toFixed(1)),
      rise: Number((current - baseline).toFixed(1)),
      rate: 0.82
    };
  }
}
