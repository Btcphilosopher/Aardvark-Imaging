/**
 * THERMAL ARRAY.OS - Thermal Gradient & Heat-Flow Proxy Analysis
 */

import React, { useState } from 'react';
import { ThermalFrame, SensorConfig, MaterialEmissivity } from '../types';
import { ThermalEngine } from '../engine/thermalEngine';
import { TrendingUp, Flame, Info, AlertTriangle, Layers } from 'lucide-react';

interface ThermalAnalysisViewProps {
  frame: ThermalFrame | null;
  config: SensorConfig;
  onUpdateConfig: (updates: Partial<SensorConfig>) => void;
}

export const ThermalAnalysisView: React.FC<ThermalAnalysisViewProps> = ({
  frame,
  config,
  onUpdateConfig
}) => {
  const [selectedGradientView, setSelectedGradientView] = useState<'mag' | 'dx' | 'dy' | 'heat_flow'>('mag');

  // Standard engineering emissivity library
  const materials: MaterialEmissivity[] = [
    { name: 'Matte Black / Radiometric Paint', category: 'Coating', emissivity: 0.98 },
    { name: 'Rough Concrete / Masonry', category: 'Building', emissivity: 0.94 },
    { name: 'Human Skin / Organic Surface', category: 'Biological', emissivity: 0.98 },
    { name: 'ABS Plastic / Polymer Shell', category: 'Plastic', emissivity: 0.92 },
    { name: 'Window Float Glass', category: 'Glass', emissivity: 0.85 },
    { name: 'Oxidized Steel / Iron Cast', category: 'Metal', emissivity: 0.78 },
    { name: 'Anodized Aluminum Stator', category: 'Metal', emissivity: 0.77 },
    { name: 'Polished Copper Busbar', category: 'Metal', emissivity: 0.15 }
  ];

  const currentMatrix = frame?.filteredValues || frame?.calibratedValues || new Float32Array(0);
  const width = frame?.width || 32;
  const height = frame?.height || 32;

  // Calculate gradients and heat-flow proxy
  const grad = ThermalEngine.calculateGradients(
    currentMatrix,
    width,
    height,
    config.surfaceDistance * 0.002, // estimated pixel pitch
    config.thermalConductivity
  );

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6 font-mono text-xs text-slate-200">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#1f2937] pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-cyan-400" />
            <h1 className="text-base font-bold text-slate-100">THERMAL GRADIENT & HEAT-FLOW PROXY ENGINE</h1>
          </div>
          <p className="text-slate-400 text-xs mt-1">
            Compute spatial partial derivatives (dT/dx, dT/dy, |∇T|) and Fourier heat flux proxy vector fields.
          </p>
        </div>
      </div>

      {/* Mandatory Disclaimer */}
      <div className="bg-[#121a24] border border-cyan-500/40 p-3 rounded-lg flex items-start space-x-3 text-cyan-200">
        <Info className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
        <div className="text-xs space-y-1">
          <span className="font-bold text-cyan-300">PHYSICAL QUANTITY CLASSIFICATION:</span>
          <p className="text-[11px] text-cyan-200/90 leading-relaxed">
            Temperature gradients are direct spatial finite differences (°C/m). Heat-flux is explicitly classified as an
            <strong> estimated heat-flow proxy</strong> based on user-supplied material thermal conductivity (k = {config.thermalConductivity} W/(m·K)) and Fourier conduction assumption.
          </p>
        </div>
      </div>

      {/* Gradient Telemetry & Views */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-[#121a24] border border-[#233142] p-3 rounded">
          <span className="text-slate-400 text-[10px] block">MAX GRADIENT (|∇T|_max)</span>
          <span className="text-xl font-bold text-red-400">{grad.maxGradient.toFixed(1)} °C/m</span>
          <span className="text-slate-500 text-[10px] block mt-1">Local edge intensity</span>
        </div>

        <div className="bg-[#121a24] border border-[#233142] p-3 rounded">
          <span className="text-slate-400 text-[10px] block">MEAN SPATIAL GRADIENT</span>
          <span className="text-xl font-bold text-cyan-400">{grad.meanGradient.toFixed(1)} °C/m</span>
          <span className="text-slate-500 text-[10px] block mt-1">Focal-plane boundary average</span>
        </div>

        <div className="bg-[#121a24] border border-[#233142] p-3 rounded">
          <span className="text-slate-400 text-[10px] block">ESTIMATED HEAT FLUX (PROXY)</span>
          <span className="text-xl font-bold text-orange-400">
            {(grad.maxGradient * config.thermalConductivity).toFixed(1)} W/m²
          </span>
          <span className="text-slate-500 text-[10px] block mt-1">q = -k·∇T approximation</span>
        </div>

        <div className="bg-[#121a24] border border-[#233142] p-3 rounded">
          <span className="text-slate-400 text-[10px] block">ACTIVE EMISSIVITY (ε)</span>
          <span className="text-xl font-bold text-emerald-400">{config.emissivity.toFixed(2)}</span>
          <span className="text-slate-500 text-[10px] block mt-1">Planck radiation law applied</span>
        </div>
      </div>

      {/* Controls Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Panel 1: Emissivity Material Library */}
        <div className="bg-[#121a24] border border-[#233142] p-4 rounded-lg space-y-4">
          <h3 className="font-bold text-slate-100 text-xs border-b border-[#233142] pb-2 flex items-center space-x-2">
            <Flame className="w-4 h-4 text-orange-400" />
            <span>MATERIAL EMISSIVITY (ε) LIBRARY</span>
          </h3>

          <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
            {materials.map((mat) => {
              const isSelected = Math.abs(config.emissivity - mat.emissivity) < 0.005;
              return (
                <button
                  key={mat.name}
                  onClick={() => onUpdateConfig({ emissivity: mat.emissivity })}
                  className={`w-full p-2 rounded border text-left flex items-center justify-between transition-all ${
                    isSelected
                      ? 'bg-orange-950/40 border-orange-500 text-white'
                      : 'bg-[#16202c] border-[#2d3d4f] text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <div>
                    <span className="font-bold text-xs block">{mat.name}</span>
                    <span className="text-[10px] text-slate-500">{mat.category}</span>
                  </div>
                  <span className="font-mono font-bold text-orange-400 text-xs">ε = {mat.emissivity.toFixed(2)}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Panel 2: Heat Conduction Physical Parameters */}
        <div className="bg-[#121a24] border border-[#233142] p-4 rounded-lg space-y-4">
          <h3 className="font-bold text-slate-100 text-xs border-b border-[#233142] pb-2 flex items-center space-x-2">
            <Layers className="w-4 h-4 text-cyan-400" />
            <span>HEAT FLUX CONDUCTION PARAMETERS</span>
          </h3>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>THERMAL CONDUCTIVITY (k):</span>
                <span className="text-cyan-400 font-bold">{config.thermalConductivity.toFixed(2)} W/(m·K)</span>
              </div>
              <input
                type="range"
                min="0.1"
                max="50.0"
                step="0.5"
                value={config.thermalConductivity}
                onChange={(e) => onUpdateConfig({ thermalConductivity: parseFloat(e.target.value) })}
                className="w-full accent-cyan-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                <span>Insulation (0.1)</span>
                <span>Steel / Metal (50.0)</span>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>REFLECTED APPARENT TEMP:</span>
                <span className="text-cyan-400 font-bold">{config.reflectedTemp.toFixed(1)} °C</span>
              </div>
              <input
                type="range"
                min="0"
                max="60"
                step="0.5"
                value={config.reflectedTemp}
                onChange={(e) => onUpdateConfig({ reflectedTemp: parseFloat(e.target.value) })}
                className="w-full accent-cyan-500 cursor-pointer"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
