/**
 * THERMAL ARRAY.OS - Sensor Driver & Configuration View
 */

import React from 'react';
import { SensorConfig, ResolutionPreset } from '../types';
import { Cpu, Sliders, Info, ShieldCheck } from 'lucide-react';

interface SensorConfigViewProps {
  config: SensorConfig;
  onUpdateConfig: (updates: Partial<SensorConfig>) => void;
  onSelectResolution: (preset: ResolutionPreset) => void;
}

export const SensorConfigView: React.FC<SensorConfigViewProps> = ({
  config,
  onUpdateConfig,
  onSelectResolution
}) => {
  const resolutionPresets: { preset: ResolutionPreset; label: string; desc: string }[] = [
    { preset: '8x8', label: '8 × 8 (64 px)', desc: 'Low-cost industrial thermopile array (e.g., Grid-EYE)' },
    { preset: '16x16', label: '16 × 16 (256 px)', desc: 'Compact thermal presence & gesture array' },
    { preset: '32x32', label: '32 × 32 (1,024 px)', desc: 'Process control & HVAC monitoring array' },
    { preset: '64x64', label: '64 × 64 (4,096 px)', desc: 'Standard industrial predictive maintenance array' },
    { preset: '128x128', label: '128 × 128 (16,384 px)', desc: 'High-density aerospace & semiconductor test' },
    { preset: '256x192', label: '256 × 192 (49,152 px)', desc: 'Commercial radiometric microbolometer format' },
    { preset: '320x256', label: '320 × 256 (81,920 px)', desc: 'Scientific grade uncooled LWIR sensor' },
    { preset: '640x512', label: '640 × 512 (327,680 px)', desc: 'Ultra high-definition military/R&D focal plane' }
  ];

  const currentPresetStr = `${config.width}x${config.height}` as ResolutionPreset;

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6 font-mono text-xs text-slate-200">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#1f2937] pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <Cpu className="w-5 h-5 text-orange-400" />
            <h1 className="text-base font-bold text-slate-100">SENSOR HARDWARE ABSTRACTION & GEOMETRY</h1>
          </div>
          <p className="text-slate-400 text-xs mt-1">
            Configure detector focal plane array dimensions, transduction parameters, NETD, and integration time.
          </p>
        </div>

        <div className="bg-[#121a24] border border-[#233142] px-3 py-1.5 rounded text-[11px]">
          <span className="text-slate-400">DRIVER: </span>
          <span className="text-emerald-400 font-bold">SyntheticSensorDriver (R-Native)</span>
        </div>
      </div>

      {/* Resolution Presets Grid */}
      <div className="space-y-3">
        <label className="text-slate-300 font-bold text-xs flex items-center space-x-2">
          <span>ARRAY RESOLUTION MATRIX PRESETS</span>
          <span className="text-orange-400">[{config.width} × {config.height}]</span>
        </label>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {resolutionPresets.map((r) => {
            const isSelected = currentPresetStr === r.preset;
            return (
              <button
                key={r.preset}
                onClick={() => onSelectResolution(r.preset)}
                className={`p-3 rounded border text-left transition-all ${
                  isSelected
                    ? 'bg-orange-950/40 border-orange-500 shadow-md ring-1 ring-orange-500'
                    : 'bg-[#121a24] border-[#233142] hover:border-slate-500 hover:bg-[#16202c]'
                }`}
              >
                <div className="flex justify-between items-center mb-1">
                  <span className={`font-bold text-sm ${isSelected ? 'text-orange-400' : 'text-slate-200'}`}>
                    {r.label}
                  </span>
                  {isSelected && <span className="w-2 h-2 rounded-full bg-orange-400" />}
                </div>
                <p className="text-slate-400 text-[10px] leading-relaxed">{r.desc}</p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Transduction & Noise Parameters */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Panel 1: Physical Sampling */}
        <div className="bg-[#121a24] border border-[#233142] p-4 rounded-lg space-y-4">
          <h3 className="font-bold text-slate-100 border-b border-[#233142] pb-2 text-xs flex items-center space-x-2">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <span>SAMPLING & CONVERSION</span>
          </h3>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>SAMPLING RATE (HZ)</span>
                <span className="text-cyan-400 font-bold">{config.samplingRate} Hz</span>
              </div>
              <div className="flex space-x-2">
                {[10, 25, 50, 100].map((rate) => (
                  <button
                    key={rate}
                    onClick={() => onUpdateConfig({ samplingRate: rate })}
                    className={`flex-1 py-1 rounded border text-[11px] font-bold ${
                      config.samplingRate === rate
                        ? 'bg-cyan-950/60 border-cyan-500 text-cyan-300'
                        : 'border-[#2d3d4f] text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {rate} Hz
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>INTEGRATION TIME</span>
                <span className="text-cyan-400 font-bold">{config.integrationTime} ms</span>
              </div>
              <input
                type="range"
                min="2"
                max="50"
                step="1"
                value={config.integrationTime}
                onChange={(e) => onUpdateConfig({ integrationTime: parseInt(e.target.value) })}
                className="w-full accent-cyan-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>ADC QUANTISATION</span>
                <span className="text-cyan-400 font-bold">{config.adcResolution}-Bit (0-16383)</span>
              </div>
              <select
                value={config.adcResolution}
                onChange={(e) => onUpdateConfig({ adcResolution: parseInt(e.target.value) })}
                className="w-full bg-[#16202c] border border-[#2d3d4f] text-slate-200 rounded p-1.5 focus:outline-none"
              >
                <option value={12}>12-Bit ADC (0 - 4095 counts)</option>
                <option value={14}>14-Bit Radiometric ADC (0 - 16383 counts)</option>
                <option value={16}>16-Bit Scientific ADC (0 - 65535 counts)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Panel 2: Sensor Noise & NETD */}
        <div className="bg-[#121a24] border border-[#233142] p-4 rounded-lg space-y-4">
          <h3 className="font-bold text-slate-100 border-b border-[#233142] pb-2 text-xs flex items-center space-x-2">
            <ShieldCheck className="w-4 h-4 text-orange-400" />
            <span>NOISE & NETD (mK)</span>
          </h3>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>NETD SENSITIVITY</span>
                <span className="text-orange-400 font-bold">{config.netd} mK ({ (config.netd / 1000).toFixed(3) }°C)</span>
              </div>
              <input
                type="range"
                min="20"
                max="200"
                step="5"
                value={config.netd}
                onChange={(e) => onUpdateConfig({ netd: parseInt(e.target.value) })}
                className="w-full accent-orange-500 cursor-pointer"
              />
              <span className="text-[10px] text-slate-400">Lower NETD yields sharper thermal sensitivity</span>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>SNR (SIGNAL-TO-NOISE)</span>
                <span className="text-orange-400 font-bold">{config.snr} dB</span>
              </div>
              <input
                type="range"
                min="30"
                max="80"
                step="2"
                value={config.snr}
                onChange={(e) => onUpdateConfig({ snr: parseInt(e.target.value) })}
                className="w-full accent-orange-500 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Panel 3: Environmental Radiometry */}
        <div className="bg-[#121a24] border border-[#233142] p-4 rounded-lg space-y-4">
          <h3 className="font-bold text-slate-100 border-b border-[#233142] pb-2 text-xs flex items-center space-x-2">
            <Info className="w-4 h-4 text-emerald-400" />
            <span>RADIOMETRIC ENVIRONMENT</span>
          </h3>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>AMBIENT AIR TEMPERATURE</span>
                <span className="text-emerald-400 font-bold">{config.ambientTemp.toFixed(1)} °C</span>
              </div>
              <input
                type="range"
                min="-10"
                max="60"
                step="0.5"
                value={config.ambientTemp}
                onChange={(e) => onUpdateConfig({ ambientTemp: parseFloat(e.target.value) })}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>SURFACE EMISSIVITY (ε)</span>
                <span className="text-emerald-400 font-bold">{config.emissivity.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.50"
                max="1.00"
                step="0.01"
                value={config.emissivity}
                onChange={(e) => onUpdateConfig({ emissivity: parseFloat(e.target.value) })}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>PIXEL PITCH / DISTANCE</span>
                <span className="text-emerald-400 font-bold">{config.surfaceDistance.toFixed(2)} m</span>
              </div>
              <input
                type="range"
                min="0.2"
                max="5.0"
                step="0.1"
                value={config.surfaceDistance}
                onChange={(e) => onUpdateConfig({ surfaceDistance: parseFloat(e.target.value) })}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
