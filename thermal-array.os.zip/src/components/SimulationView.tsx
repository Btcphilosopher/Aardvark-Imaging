/**
 * THERMAL ARRAY.OS - Industrial Use-Case Simulator & Physics Benchmark Suite
 */

import React from 'react';
import { ScenarioType } from '../types';
import { FlaskConical, Zap, Activity, ShieldAlert, Cpu, Building2, Flame } from 'lucide-react';

interface SimulationViewProps {
  currentScenario: ScenarioType;
  onSelectScenario: (scenario: ScenarioType) => void;
  batteryRunawayInfo: { id: number; baseline: number; current: number; rise: number; rate: number };
}

export const SimulationView: React.FC<SimulationViewProps> = ({
  currentScenario,
  onSelectScenario,
  batteryRunawayInfo
}) => {
  const scenarios: {
    id: ScenarioType;
    title: string;
    category: string;
    icon: React.ReactNode;
    desc: string;
    params: { label: string; value: string }[];
  }[] = [
    {
      id: 'motor_bearing',
      title: 'INDUSTRIAL INDUCTION MOTOR (64×64)',
      category: 'Machinery & Rotational Equipment',
      icon: <Cpu className="w-5 h-5 text-orange-400" />,
      desc: 'Simulates a 3-phase induction motor with ambient = 22°C, cylindrical housing = 38°C, stator fins, and localized shaft bearing fault reaching 72.4°C.',
      params: [
        { label: 'Ambient Temp', value: '22.0 °C' },
        { label: 'Housing Baseline', value: '38.0 °C' },
        { label: 'Bearing Hotspot', value: '72.4 °C' },
        { label: 'Conduction Radius', value: '8.5 mm' }
      ]
    },
    {
      id: 'battery_pack',
      title: 'LITHIUM BATTERY PACK (8 × 12 CELLS)',
      category: 'Energy Storage & EV Diagnostics',
      icon: <Zap className="w-5 h-5 text-amber-400" />,
      desc: 'Simulates an 8×12 cylindrical battery pack matrix (96 cells). Cell 47 undergoes early runaway with +0.82°C/s rise rate, detectable prior to max alarm.',
      params: [
        { label: 'Nominal Cell Temp', value: '31.2 °C' },
        { label: 'Runaway Cell', value: `Cell #${batteryRunawayInfo.id}` },
        { label: 'Current Runaway', value: `${batteryRunawayInfo.current.toFixed(1)} °C` },
        { label: 'Rise Rate', value: `+${batteryRunawayInfo.rate.toFixed(2)} °C/s` }
      ]
    },
    {
      id: 'electrical_panel',
      title: '3-PHASE ELECTRICAL SWITCHBOARD',
      category: 'Electrical Distribution & Substations',
      icon: <Flame className="w-5 h-5 text-red-400" />,
      desc: 'Simulates L1, L2, L3 loaded busbars at 41.8°C baseline with a loose cable lug connector overheating to 72.4°C (+30.6°C rise, 14.2s persistence).',
      params: [
        { label: 'Busbar Baseline', value: '41.8 °C' },
        { label: 'Overheating Lug', value: '72.4 °C' },
        { label: 'Rise Delta', value: '+30.6 °C' },
        { label: 'Persistence', value: '14.2 s' }
      ]
    },
    {
      id: 'building_facade',
      title: 'BUILDING FACADE THERMAL AUDIT',
      category: 'Civil Infrastructure & Energy Auditing',
      icon: <Building2 className="w-5 h-5 text-cyan-400" />,
      desc: 'Simulates exterior wall (14.2°C), roof (11.8°C), double-glazed windows (18.5°C), and major thermal envelope insulation bridge leakage (27.0°C).',
      params: [
        { label: 'Exterior Wall', value: '14.2 °C' },
        { label: 'Roof Surface', value: '11.8 °C' },
        { label: 'Windows', value: '18.5 °C' },
        { label: 'Insulation Leak', value: '27.0 °C' }
      ]
    },
    {
      id: 'industrial_pipe',
      title: 'HIGH-PRESSURE STEAM PIPELINE',
      category: 'Process Engineering & Refineries',
      icon: <Activity className="w-5 h-5 text-emerald-400" />,
      desc: 'Simulates a 95°C steam pipeline with axial fluid temperature decay and localized radial insulation degradation fault.',
      params: [
        { label: 'Steam Fluid Inlet', value: '95.0 °C' },
        { label: 'Pipe Insulation', value: '28.0 °C' },
        { label: 'Degraded Patch', value: '102.0 °C' },
        { label: 'Gradient dT/dx', value: '-0.35 °C/cm' }
      ]
    }
  ];

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6 font-mono text-xs text-slate-200">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#1f2937] pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <FlaskConical className="w-5 h-5 text-orange-400" />
            <h1 className="text-base font-bold text-slate-100">DETERMINISTIC THERMAL SCENE SIMULATOR</h1>
          </div>
          <p className="text-slate-400 text-xs mt-1">
            Standardized industrial ground-truth benchmarks for algorithm validation, sensor noise modeling, and early defect detection.
          </p>
        </div>

        <div className="bg-[#121a24] border border-[#233142] px-3 py-1.5 rounded text-[11px]">
          <span className="text-slate-400">ACTIVE SCENARIO: </span>
          <span className="text-orange-400 font-bold uppercase">{currentScenario.replace('_', ' ')}</span>
        </div>
      </div>

      {/* Battery Runaway Banner if battery pack is selected */}
      {currentScenario === 'battery_pack' && (
        <div className="bg-amber-950/40 border border-amber-500/50 p-4 rounded-lg flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <ShieldAlert className="w-6 h-6 text-amber-400" />
            <div>
              <span className="font-bold text-sm text-amber-300 block">
                THERMAL TREND ALERT: CELL #{batteryRunawayInfo.id}
              </span>
              <span className="text-xs text-amber-200/80">
                Baseline: {batteryRunawayInfo.baseline} °C | Current: {batteryRunawayInfo.current.toFixed(1)} °C | Rise: +{batteryRunawayInfo.rise.toFixed(1)} °C | Rate: +{batteryRunawayInfo.rate.toFixed(2)} °C/s
              </span>
            </div>
          </div>
          <span className="px-3 py-1 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded font-bold text-xs">
            EARLY WARNING TRIGGERED
          </span>
        </div>
      )}

      {/* Scenarios Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {scenarios.map((sc) => {
          const isSelected = currentScenario === sc.id;
          return (
            <div
              key={sc.id}
              onClick={() => onSelectScenario(sc.id)}
              className={`p-4 rounded-lg border cursor-pointer transition-all space-y-3 ${
                isSelected
                  ? 'bg-orange-950/30 border-orange-500 ring-1 ring-orange-500 shadow-lg'
                  : 'bg-[#121a24] border-[#233142] hover:border-slate-500 hover:bg-[#16202c]'
              }`}
            >
              <div className="flex justify-between items-start">
                <div className="flex items-center space-x-2.5">
                  <div className="p-2 bg-[#1a2432] rounded border border-[#2d3d4f]">
                    {sc.icon}
                  </div>
                  <div>
                    <h3 className={`font-bold text-sm ${isSelected ? 'text-orange-400' : 'text-slate-100'}`}>
                      {sc.title}
                    </h3>
                    <span className="text-[10px] text-slate-400">{sc.category}</span>
                  </div>
                </div>
                {isSelected && (
                  <span className="bg-orange-600 text-white font-bold text-[9px] px-2 py-0.5 rounded">
                    ACTIVE
                  </span>
                )}
              </div>

              <p className="text-slate-300 text-xs leading-relaxed">{sc.desc}</p>

              <div className="grid grid-cols-2 gap-2 bg-[#0b0f14] p-2.5 rounded border border-[#1b2533] text-[11px]">
                {sc.params.map((p, idx) => (
                  <div key={idx} className="flex justify-between">
                    <span className="text-slate-400">{p.label}:</span>
                    <span className="text-cyan-300 font-bold">{p.value}</span>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
