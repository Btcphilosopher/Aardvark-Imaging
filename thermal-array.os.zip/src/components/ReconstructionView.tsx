/**
 * THERMAL ARRAY.OS - Super-Resolution & Thermal Reconstruction Module
 */

import React from 'react';
import { PipelineConfig, InterpolationMethod, ThermalFrame } from '../types';
import { Maximize2, AlertTriangle, Layers, Info } from 'lucide-react';

interface ReconstructionViewProps {
  pipeline: PipelineConfig;
  frame: ThermalFrame | null;
  onUpdatePipeline: (updates: Partial<PipelineConfig>) => void;
}

export const ReconstructionView: React.FC<ReconstructionViewProps> = ({
  pipeline,
  frame,
  onUpdatePipeline
}) => {
  const methods: { id: InterpolationMethod; name: string; formula: string; desc: string }[] = [
    {
      id: 'bicubic',
      name: 'Bicubic Spline (Catmull-Rom)',
      formula: '16-point weighted cubic polynomial',
      desc: 'Standard continuous gradient reconstruction for smooth thermal fields'
    },
    {
      id: 'bilinear',
      name: 'Bilinear Interpolation',
      formula: '4-point linear plane projection',
      desc: 'Fast continuous mathematical reconstruction'
    },
    {
      id: 'lanczos',
      name: 'Lanczos-2 Sinc Kernel',
      formula: 'L(x) = sinc(x)·sinc(x/2)',
      desc: 'High-frequency preservation without ringing artifacts'
    },
    {
      id: 'spline',
      name: 'Thin-Plate Spline',
      formula: 'Surface minimum curvature bending',
      desc: 'Physics-inspired continuous surface reconstruction'
    },
    {
      id: 'nearest',
      name: 'Nearest Neighbor (Zero-Order Hold)',
      formula: 'T(x,y) = T(floor(x), floor(y))',
      desc: 'Preserves discrete physical sensor pixel boundaries exactly'
    }
  ];

  const srcW = frame?.width || 32;
  const srcH = frame?.height || 32;
  const scale = pipeline.reconstructionScale;
  const targetW = srcW * scale;
  const targetH = srcH * scale;

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6 font-mono text-xs text-slate-200">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#1f2937] pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <Maximize2 className="w-5 h-5 text-purple-400" />
            <h1 className="text-base font-bold text-slate-100">THERMAL FIELD RECONSTRUCTION (SUPER-RESOLUTION)</h1>
          </div>
          <p className="text-slate-400 text-xs mt-1">
            Mathematical upsampling and continuous surface reconstruction from discrete thermal sensor array elements.
          </p>
        </div>

        <div className="bg-purple-950/60 border border-purple-500/50 px-3 py-1.5 rounded text-[11px] text-purple-300 flex items-center space-x-1.5">
          <Info className="w-4 h-4 text-purple-400" />
          <span>STATUS: RECONSTRUCTION LAYER (INTERPOLATED)</span>
        </div>
      </div>

      {/* Mandatory Engineering Principle Warning */}
      <div className="bg-amber-950/40 border border-amber-500/50 p-3 rounded-lg flex items-start space-x-3 text-amber-200">
        <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <div className="text-xs space-y-1">
          <span className="font-bold block text-amber-300">ENGINEERING PROVENANCE MANDATE:</span>
          <p className="leading-relaxed text-[11px] text-amber-200/90">
            Reconstructed matrices are generated via spatial interpolation algorithms. The resulting higher resolution
            field represents a continuous mathematical estimate and must <strong>never</strong> be presented or archived
            as physically measured detector truth.
          </p>
        </div>
      </div>

      {/* Configuration Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Upsampling Geometry */}
        <div className="bg-[#121a24] border border-[#233142] p-4 rounded-lg space-y-4">
          <h3 className="font-bold text-slate-100 text-xs border-b border-[#233142] pb-2 flex items-center space-x-2">
            <Layers className="w-4 h-4 text-purple-400" />
            <span>UPSAMPLING FACTOR & GEOMETRY</span>
          </h3>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-[#16202c] p-3 rounded border border-[#2d3d4f]">
                <span className="text-slate-400 text-[10px] block">SOURCE DETECTOR ARRAY</span>
                <span className="text-lg font-bold text-cyan-400">{srcW} × {srcH}</span>
                <span className="text-slate-500 text-[10px] block mt-0.5">{srcW * srcH} Physical Pixels</span>
              </div>

              <div className="bg-[#16202c] p-3 rounded border border-purple-500/40">
                <span className="text-purple-300 text-[10px] block">RECONSTRUCTED FIELD</span>
                <span className="text-lg font-bold text-purple-400">{targetW} × {targetH}</span>
                <span className="text-purple-300/70 text-[10px] block mt-0.5">{targetW * targetH} Interpolated Nodes</span>
              </div>
            </div>

            <div>
              <label className="text-slate-300 font-bold block mb-2">UPSAMPLE FACTOR:</label>
              <div className="flex space-x-2">
                {[1, 2, 4].map((s) => (
                  <button
                    key={s}
                    onClick={() => onUpdatePipeline({ reconstructionScale: s as any })}
                    className={`flex-1 py-1.5 rounded font-bold border transition-colors ${
                      scale === s
                        ? 'bg-purple-950/80 border-purple-500 text-purple-300'
                        : 'bg-[#16202c] border-[#2d3d4f] text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {s === 1 ? '1× (Native)' : `${s}× (Super-Res)`}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Interpolation Method Selector */}
        <div className="bg-[#121a24] border border-[#233142] p-4 rounded-lg space-y-4">
          <h3 className="font-bold text-slate-100 text-xs border-b border-[#233142] pb-2">
            RECONSTRUCTION MATHEMATICAL KERNEL
          </h3>

          <div className="space-y-2">
            {methods.map((m) => (
              <label
                key={m.id}
                className={`flex items-start space-x-2 p-2.5 rounded border cursor-pointer transition-all ${
                  pipeline.reconstructionMethod === m.id
                    ? 'bg-purple-950/40 border-purple-500 text-white'
                    : 'bg-[#16202c] border-[#2d3d4f] text-slate-400 hover:text-slate-200'
                }`}
              >
                <input
                  type="radio"
                  name="reconstruction_method"
                  value={m.id}
                  checked={pipeline.reconstructionMethod === m.id}
                  onChange={() => onUpdatePipeline({ reconstructionMethod: m.id })}
                  className="mt-0.5 accent-purple-500"
                />
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-xs">{m.name}</span>
                    <span className="text-[10px] text-purple-400 font-mono">[{m.formula}]</span>
                  </div>
                  <span className="text-[10px] text-slate-400 block mt-0.5">{m.desc}</span>
                </div>
              </label>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
