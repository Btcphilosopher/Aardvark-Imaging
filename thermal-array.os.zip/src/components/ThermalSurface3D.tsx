/**
 * THERMAL ARRAY.OS - 3D Thermal Surface Renderer
 * Isometric/Perspective Wireframe & Colored Mesh Analytical Surface
 */

import React, { useRef, useEffect, useState } from 'react';
import { PaletteName } from '../types';
import { ThermalPalettes } from '../engine/palettes';
import { RotateCw, Maximize2 } from 'lucide-react';

interface ThermalSurface3DProps {
  matrix: Float32Array;
  width: number;
  height: number;
  palette: PaletteName;
}

export const ThermalSurface3D: React.FC<ThermalSurface3DProps> = ({
  matrix,
  width,
  height,
  palette
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [rotationX, setRotationX] = useState<number>(55); // degrees
  const [rotationZ, setRotationZ] = useState<number>(45); // degrees
  const [heightScale, setHeightScale] = useState<number>(2.2);
  const [wireframeOnly, setWireframeOnly] = useState<boolean>(false);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [lastMouse, setLastMouse] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  useEffect(() => {
    if (!canvasRef.current || !matrix) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const cw = (canvas.width = 620);
    const ch = (canvas.height = 560);
    ctx.clearRect(0, 0, cw, ch);

    // Min & Max for height and colour mapping
    let minT = Infinity;
    let maxT = -Infinity;
    for (let i = 0; i < matrix.length; i++) {
      const v = matrix[i];
      if (v < minT) minT = v;
      if (v > maxT) maxT = v;
    }
    const tRange = Math.max(0.1, maxT - minT);

    // Subsample large arrays for crisp 3D real-time performance (e.g. max 48x48 mesh)
    const step = Math.max(1, Math.floor(Math.max(width, height) / 40));
    const meshW = Math.floor(width / step);
    const meshH = Math.floor(height / step);

    const radX = (rotationX * Math.PI) / 180;
    const radZ = (rotationZ * Math.PI) / 180;

    const cosZ = Math.cos(radZ);
    const sinZ = Math.sin(radZ);
    const cosX = Math.cos(radX);
    const sinX = Math.sin(radX);

    const centerX = cw / 2;
    const centerY = ch / 2 + 30;
    const scale = 240 / Math.max(meshW, meshH);

    // Project 3D point (x, y, z) -> 2D screen (sx, sy)
    const project = (gx: number, gy: number, temp: number) => {
      // Centered coords [-1, 1]
      const nx = (gx - meshW / 2) * scale;
      const ny = (gy - meshH / 2) * scale;
      const nz = (((temp - minT) / tRange) * 70 - 35) * heightScale;

      // Rotate around Z axis
      const rx = nx * cosZ - ny * sinZ;
      const ry = nx * sinZ + ny * cosZ;

      // Rotate around X axis (elevation tilt)
      const px = rx;
      const py = ry * cosX - nz * sinX;
      const depth = ry * sinX + nz * cosX;

      return {
        sx: centerX + px,
        sy: centerY + py,
        depth,
        temp
      };
    };

    // Build grid cells & sort by depth for painter's algorithm
    const quads: {
      p0: { sx: number; sy: number; temp: number };
      p1: { sx: number; sy: number; temp: number };
      p2: { sx: number; sy: number; temp: number };
      p3: { sx: number; sy: number; temp: number };
      avgDepth: number;
      avgTemp: number;
    }[] = [];

    for (let gy = 0; gy < meshH - 1; gy++) {
      for (let gx = 0; gx < meshW - 1; gx++) {
        const srcX = gx * step;
        const srcY = gy * step;

        const t0 = matrix[srcY * width + srcX];
        const t1 = matrix[srcY * width + Math.min(width - 1, (gx + 1) * step)];
        const t2 = matrix[Math.min(height - 1, (gy + 1) * step) * width + Math.min(width - 1, (gx + 1) * step)];
        const t3 = matrix[Math.min(height - 1, (gy + 1) * step) * width + srcX];

        const p0 = project(gx, gy, t0);
        const p1 = project(gx + 1, gy, t1);
        const p2 = project(gx + 1, gy + 1, t2);
        const p3 = project(gx, gy + 1, t3);

        const avgDepth = (p0.depth + p1.depth + p2.depth + p3.depth) / 4;
        const avgTemp = (t0 + t1 + t2 + t3) / 4;

        quads.push({ p0, p1, p2, p3, avgDepth, avgTemp });
      }
    }

    // Sort back to front
    quads.sort((a, b) => a.avgDepth - b.avgDepth);

    // Draw quads
    for (const q of quads) {
      const norm = Math.max(0, Math.min(1, (q.avgTemp - minT) / tRange));
      const color = ThermalPalettes.getColor(norm, palette);

      ctx.beginPath();
      ctx.moveTo(q.p0.sx, q.p0.sy);
      ctx.lineTo(q.p1.sx, q.p1.sy);
      ctx.lineTo(q.p2.sx, q.p2.sy);
      ctx.lineTo(q.p3.sx, q.p3.sy);
      ctx.closePath();

      if (!wireframeOnly) {
        ctx.fillStyle = `rgb(${color.r}, ${color.g}, ${color.b})`;
        ctx.fill();
      }

      ctx.strokeStyle = wireframeOnly
        ? `rgb(${color.r}, ${color.g}, ${color.b})`
        : 'rgba(0, 0, 0, 0.25)';
      ctx.lineWidth = 0.6;
      ctx.stroke();
    }
  }, [matrix, width, height, palette, rotationX, rotationZ, heightScale, wireframeOnly]);

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDragging(true);
    setLastMouse({ x: e.clientX, y: e.clientY });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDragging) return;
    const dx = e.clientX - lastMouse.x;
    const dy = e.clientY - lastMouse.y;
    setRotationZ((prev) => (prev + dx * 0.7) % 360);
    setRotationX((prev) => Math.max(15, Math.min(85, prev + dy * 0.5)));
    setLastMouse({ x: e.clientX, y: e.clientY });
  };

  const handleMouseUp = () => setIsDragging(false);

  return (
    <div className="flex flex-col items-center justify-center relative w-full h-full">
      {/* 3D Controls Bar */}
      <div className="absolute top-2 left-2 bg-[#121a24]/90 border border-[#233142] p-2 rounded flex items-center space-x-3 text-xs font-mono z-10 backdrop-blur">
        <span className="text-cyan-400 font-bold">3D SURFACE (X, Y, TEMP)</span>
        <div className="flex items-center space-x-1 text-slate-300">
          <span>ELEVATION:</span>
          <input
            type="range"
            min="0.5"
            max="4.0"
            step="0.1"
            value={heightScale}
            onChange={(e) => setHeightScale(parseFloat(e.target.value))}
            className="w-16 accent-orange-500 cursor-pointer"
          />
        </div>
        <button
          onClick={() => setWireframeOnly(!wireframeOnly)}
          className={`px-2 py-0.5 rounded text-[11px] border ${
            wireframeOnly ? 'bg-orange-600 border-orange-500 text-white' : 'border-[#2d3d4f] text-slate-400'
          }`}
        >
          {wireframeOnly ? 'WIREFRAME' : 'SURFACE MESH'}
        </button>
        <div className="text-[10px] text-slate-400">Drag mouse to rotate 3D view</div>
      </div>

      <canvas
        ref={canvasRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        className="cursor-grab active:cursor-grabbing max-w-full max-h-full rounded"
      />
    </div>
  );
};
