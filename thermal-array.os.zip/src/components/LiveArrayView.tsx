/**
 * THERMAL ARRAY.OS - Main Live Thermal Array Canvas View
 * High-performance scientific rendering with palettes, crosshair, isotherms, and ROI overlay
 */

import React, { useRef, useEffect, useState, useCallback } from 'react';
import {
  ThermalFrame,
  FrameStatistics,
  DisplayMode,
  PaletteName,
  ROI,
  Hotspot,
  PixelInspection
} from '../types';
import { ThermalPalettes } from '../engine/palettes';
import { Crosshair, Eye, Grid, Maximize, ZoomIn, ZoomOut, Box, Square, Circle } from 'lucide-react';
import { ThermalSurface3D } from './ThermalSurface3D';

interface LiveArrayViewProps {
  frame: ThermalFrame | null;
  stats: FrameStatistics;
  displayMode: DisplayMode;
  palette: PaletteName;
  onPaletteChange: (palette: PaletteName) => void;
  onSelectPixel: (inspection: PixelInspection) => void;
  hotspots: Hotspot[];
  rois: ROI[];
  onAddRoi: (roi: ROI) => void;
  onRemoveRoi: (id: string) => void;
}

export const LiveArrayView: React.FC<LiveArrayViewProps> = ({
  frame,
  stats,
  displayMode,
  palette,
  onPaletteChange,
  onSelectPixel,
  hotspots,
  rois,
  onAddRoi,
  onRemoveRoi
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // View state
  const [hoveredPixel, setHoveredPixel] = useState<{ x: number; y: number } | null>(null);
  const [showGrid, setShowGrid] = useState<boolean>(false);
  const [showHotspots, setShowHotspots] = useState<boolean>(true);
  const [showIsotherms, setShowIsotherms] = useState<boolean>(false);
  const [isothermThresholds, setIsothermThresholds] = useState<number[]>([40, 50, 60]);
  const [view3D, setView3D] = useState<boolean>(false);
  const [zoom, setZoom] = useState<number>(1.0);
  const [roiDrawingMode, setRoiDrawingMode] = useState<'none' | 'rectangle' | 'circle'>('none');
  const [dragStart, setDragStart] = useState<{ x: number; y: number } | null>(null);
  const [currentDrag, setCurrentDrag] = useState<{ x: number; y: number } | null>(null);

  // Select matrix based on display mode
  const currentMatrix = frame
    ? displayMode === 'RAW'
      ? frame.rawValues
      : displayMode === 'CALIBRATED'
      ? frame.calibratedValues
      : displayMode === 'RECONSTRUCTED' && frame.reconstructedValues
      ? frame.reconstructedValues
      : frame.filteredValues
    : null;

  const currentWidth = (displayMode === 'RECONSTRUCTED' && frame?.reconstructedWidth) ? frame.reconstructedWidth : (frame?.width || 64);
  const currentHeight = (displayMode === 'RECONSTRUCTED' && frame?.reconstructedHeight) ? frame.reconstructedHeight : (frame?.height || 64);

  // Render thermal matrix onto canvas
  useEffect(() => {
    if (!canvasRef.current || !currentMatrix || !frame) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = currentWidth;
    canvas.height = currentHeight;

    const imgData = ctx.createImageData(currentWidth, currentHeight);
    const data = imgData.data;

    const lut = ThermalPalettes.generateLUT(palette);
    const minVal = stats.min;
    const maxVal = Math.max(minVal + 0.1, stats.max);
    const range = maxVal - minVal;

    for (let i = 0; i < currentMatrix.length; i++) {
      const val = currentMatrix[i];
      let norm = (val - minVal) / range;
      norm = Math.max(0, Math.min(1, norm));

      const lutIdx = Math.floor(norm * 255) * 4;
      const dIdx = i * 4;

      // In RAW mode show bad pixels distinctly if uncalibrated
      if (displayMode === 'RAW' && frame.qualityMask && frame.qualityMask[i] === 2) {
        data[dIdx] = 255;
        data[dIdx + 1] = 0;
        data[dIdx + 2] = 255; // Magenta for bad pixel in raw
        data[dIdx + 3] = 255;
      } else {
        data[dIdx] = lut[lutIdx];
        data[dIdx + 1] = lut[lutIdx + 1];
        data[dIdx + 2] = lut[lutIdx + 2];
        data[dIdx + 3] = 255;
      }
    }

    ctx.putImageData(imgData, 0, 0);

    // Isotherm contours overlay
    if (showIsotherms && !view3D) {
      ctx.lineWidth = 1;
      for (const iso of isothermThresholds) {
        ctx.strokeStyle = iso >= 60 ? '#ef4444' : iso >= 50 ? '#f97316' : '#eab308';
        // Simple marching squares / threshold highlight
        for (let y = 0; y < currentHeight - 1; y++) {
          for (let x = 0; x < currentWidth - 1; x++) {
            const v0 = currentMatrix[y * currentWidth + x];
            const v1 = currentMatrix[y * currentWidth + (x + 1)];
            const v2 = currentMatrix[(y + 1) * currentWidth + x];
            if ((v0 >= iso && (v1 < iso || v2 < iso)) || (v0 < iso && (v1 >= iso || v2 >= iso))) {
              ctx.fillStyle = ctx.strokeStyle;
              ctx.fillRect(x, y, 1, 1);
            }
          }
        }
      }
    }
  }, [currentMatrix, currentWidth, currentHeight, stats, palette, displayMode, showIsotherms, isothermThresholds, frame, view3D]);

  // Coordinate mapping from mouse event
  const getMatrixCoords = useCallback(
    (e: React.MouseEvent<HTMLDivElement>): { x: number; y: number } | null => {
      if (!containerRef.current || !frame) return null;
      const rect = containerRef.current.getBoundingClientRect();
      const clickX = e.clientX - rect.left;
      const clickY = e.clientY - rect.top;

      const normX = clickX / rect.width;
      const normY = clickY / rect.height;

      const x = Math.floor(normX * frame.width);
      const y = Math.floor(normY * frame.height);

      if (x >= 0 && x < frame.width && y >= 0 && y < frame.height) {
        return { x, y };
      }
      return null;
    },
    [frame]
  );

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const coords = getMatrixCoords(e);
    setHoveredPixel(coords);
    if (dragStart) {
      setCurrentDrag(coords);
    }
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (roiDrawingMode !== 'none') {
      const coords = getMatrixCoords(e);
      if (coords) {
        setDragStart(coords);
        setCurrentDrag(coords);
      }
    }
  };

  const handleMouseUp = () => {
    if (dragStart && currentDrag && roiDrawingMode !== 'none') {
      const newRoi: ROI = {
        id: `ROI-${String(rois.length + 1).padStart(3, '0')}`,
        label: `Region ${rois.length + 1}`,
        type: roiDrawingMode,
        points: [
          { x: Math.min(dragStart.x, currentDrag.x), y: Math.min(dragStart.y, currentDrag.y) },
          { x: Math.max(dragStart.x, currentDrag.x), y: Math.max(dragStart.y, currentDrag.y) }
        ],
        color: rois.length % 3 === 0 ? '#38bdf8' : rois.length % 3 === 1 ? '#a855f7' : '#22c55e'
      };
      onAddRoi(newRoi);
    }
    setDragStart(null);
    setCurrentDrag(null);
    setRoiDrawingMode('none');
  };

  const handleClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (roiDrawingMode !== 'none' || !frame) return;
    const coords = getMatrixCoords(e);
    if (!coords) return;

    const idx = coords.y * frame.width + coords.x;
    const raw = frame.rawValues[idx];
    const calibrated = frame.calibratedValues[idx];
    const filtered = frame.filteredValues[idx];
    const qCode = frame.qualityMask[idx];
    const quality: 'GOOD' | 'WARNING' | 'BAD' = qCode === 2 ? 'BAD' : qCode === 1 ? 'WARNING' : 'GOOD';
    const badCode = frame.badPixelTypes ? frame.badPixelTypes[idx] : 0;
    const badType = badCode === 1 ? 'DEAD' : badCode === 3 ? 'HOT' : badCode === 4 ? 'NOISY' : 'NONE';

    // Mock recent time series
    const history = Array.from({ length: 30 }, (_, i) => ({
      timestamp: Date.now() - (30 - i) * 100,
      temp: calibrated + (Math.sin(i * 0.5) * 0.2),
      raw: raw + (Math.sin(i * 0.5) * 16)
    }));

    onSelectPixel({
      x: coords.x,
      y: coords.y,
      raw,
      calibrated: Number(calibrated.toFixed(2)),
      filtered: Number(filtered.toFixed(2)),
      quality,
      badType,
      gain: 1.024,
      offset: -2.15,
      noise: Number((stats.estimatedNoise || 0.12).toFixed(3)),
      residual: 0.042,
      history
    });
  };

  // Hover pixel details
  const hoveredData = hoveredPixel && frame ? {
    x: hoveredPixel.x,
    y: hoveredPixel.y,
    raw: frame.rawValues[hoveredPixel.y * frame.width + hoveredPixel.x],
    calibrated: frame.calibratedValues[hoveredPixel.y * frame.width + hoveredPixel.x],
    filtered: frame.filteredValues[hoveredPixel.y * frame.width + hoveredPixel.x],
    quality: frame.qualityMask[hoveredPixel.y * frame.width + hoveredPixel.x] === 2 ? 'BAD' : frame.qualityMask[hoveredPixel.y * frame.width + hoveredPixel.x] === 1 ? 'WARNING' : 'GOOD'
  } : null;

  return (
    <div className="flex flex-col h-full bg-[#0b0f14] text-slate-200">
      {/* Top Toolbar */}
      <div className="flex items-center justify-between px-4 py-2 bg-[#0e141c] border-b border-[#1b2533] text-xs">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-1.5 font-mono text-[11px]">
            <span className="text-slate-400">PALETTE:</span>
            {(['Iron', 'Inferno', 'Viridis', 'Plasma', 'Grayscale', 'Blue-Red'] as PaletteName[]).map((p) => (
              <button
                key={p}
                onClick={() => onPaletteChange(p)}
                className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors ${
                  palette === p
                    ? 'bg-slate-700 text-orange-400 font-bold border border-orange-500/40'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                {p}
              </button>
            ))}
          </div>

          <div className="h-3 w-px bg-slate-700" />

          {/* Isotherm toggle */}
          <button
            onClick={() => setShowIsotherms(!showIsotherms)}
            className={`flex items-center space-x-1 px-2 py-0.5 rounded text-[11px] font-mono border ${
              showIsotherms
                ? 'bg-orange-950/60 border-orange-600 text-orange-300'
                : 'border-[#2d3d4f] text-slate-400 hover:text-slate-200'
            }`}
          >
            <Eye className="w-3 h-3" />
            <span>ISOTHERMS (40/50/60°C)</span>
          </button>
        </div>

        <div className="flex items-center space-x-2">
          {/* ROI Drawing Controls */}
          <div className="flex items-center space-x-1 bg-[#141d26] border border-[#2d3d4f] rounded p-0.5">
            <button
              onClick={() => setRoiDrawingMode(roiDrawingMode === 'rectangle' ? 'none' : 'rectangle')}
              title="Draw Rectangle ROI"
              className={`p-1 rounded ${roiDrawingMode === 'rectangle' ? 'bg-orange-600 text-white' : 'text-slate-400 hover:text-slate-200'}`}
            >
              <Square className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setRoiDrawingMode(roiDrawingMode === 'circle' ? 'none' : 'circle')}
              title="Draw Circle ROI"
              className={`p-1 rounded ${roiDrawingMode === 'circle' ? 'bg-orange-600 text-white' : 'text-slate-400 hover:text-slate-200'}`}
            >
              <Circle className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Grid Toggle */}
          <button
            onClick={() => setShowGrid(!showGrid)}
            title="Toggle Sensor Grid"
            className={`p-1 rounded border ${showGrid ? 'bg-slate-700 border-slate-500 text-white' : 'border-[#2d3d4f] text-slate-400'}`}
          >
            <Grid className="w-3.5 h-3.5" />
          </button>

          {/* 3D Surface View Toggle */}
          <button
            onClick={() => setView3D(!view3D)}
            className={`flex items-center space-x-1 px-2 py-0.5 rounded text-[11px] font-mono border ${
              view3D
                ? 'bg-cyan-950/60 border-cyan-500 text-cyan-300'
                : 'border-[#2d3d4f] text-slate-400 hover:text-slate-200'
            }`}
          >
            <Box className="w-3.5 h-3.5" />
            <span>{view3D ? '2D ARRAY' : '3D SURFACE'}</span>
          </button>

          {/* Zoom controls */}
          <div className="flex items-center space-x-0.5 bg-[#141d26] border border-[#2d3d4f] rounded p-0.5">
            <button
              onClick={() => setZoom(Math.max(0.5, zoom - 0.25))}
              className="p-1 text-slate-400 hover:text-slate-200"
            >
              <ZoomOut className="w-3 h-3" />
            </button>
            <span className="text-[10px] font-mono px-1 text-slate-300">{(zoom * 100).toFixed(0)}%</span>
            <button
              onClick={() => setZoom(Math.min(3.0, zoom + 0.25))}
              className="p-1 text-slate-400 hover:text-slate-200"
            >
              <ZoomIn className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>

      {/* Main View Area */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Central Canvas Viewport */}
        <div className="flex-1 flex items-center justify-center p-4 bg-[#070b0f] overflow-auto relative">
          {view3D && frame ? (
            <ThermalSurface3D matrix={currentMatrix!} width={currentWidth} height={currentHeight} palette={palette} />
          ) : (
            <div
              ref={containerRef}
              onMouseMove={handleMouseMove}
              onMouseDown={handleMouseDown}
              onMouseUp={handleMouseUp}
              onClick={handleClick}
              onMouseLeave={() => setHoveredPixel(null)}
              style={{
                width: `${Math.min(580, 580 * zoom)}px`,
                height: `${Math.min(580, 580 * zoom)}px`,
                cursor: roiDrawingMode !== 'none' ? 'crosshair' : 'pointer'
              }}
              className="relative aspect-square border-2 border-[#1e293b] shadow-2xl bg-black rounded overflow-hidden select-none"
            >
              {/* Thermal Canvas */}
              <canvas
                ref={canvasRef}
                style={{ imageRendering: displayMode === 'RECONSTRUCTED' ? 'auto' : 'pixelated' }}
                className="w-full h-full block"
              />

              {/* Sensor Pixel Grid Overlay */}
              {showGrid && frame && (
                <div
                  className="absolute inset-0 pointer-events-none opacity-25"
                  style={{
                    backgroundImage: `linear-gradient(to right, rgba(255,255,255,0.4) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.4) 1px, transparent 1px)`,
                    backgroundSize: `${100 / frame.width}% ${100 / frame.height}%`
                  }}
                />
              )}

              {/* Hotspot Bounding Boxes */}
              {showHotspots && frame && (
                <div className="absolute inset-0 pointer-events-none">
                  {hotspots.map((hs) => {
                    const leftPct = (hs.boundingBox.minX / frame.width) * 100;
                    const topPct = (hs.boundingBox.minY / frame.height) * 100;
                    const widthPct = ((hs.boundingBox.maxX - hs.boundingBox.minX + 1) / frame.width) * 100;
                    const heightPct = ((hs.boundingBox.maxY - hs.boundingBox.minY + 1) / frame.height) * 100;

                    return (
                      <div
                        key={hs.id}
                        style={{
                          left: `${leftPct}%`,
                          top: `${topPct}%`,
                          width: `${widthPct}%`,
                          height: `${heightPct}%`
                        }}
                        className="absolute border border-red-500 border-dashed bg-red-500/10 rounded-sm"
                      >
                        <div className="absolute -top-4 left-0 bg-red-600 text-white font-mono text-[9px] px-1 rounded whitespace-nowrap shadow">
                          {hs.id}: {hs.maxTemp}°C
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* ROI Overlays */}
              {frame && (
                <div className="absolute inset-0 pointer-events-none">
                  {rois.map((roi) => {
                    const p1 = roi.points[0];
                    const p2 = roi.points[1] || p1;
                    const minX = Math.min(p1.x, p2.x);
                    const maxX = Math.max(p1.x, p2.x);
                    const minY = Math.min(p1.y, p2.y);
                    const maxY = Math.max(p1.y, p2.y);

                    const leftPct = (minX / frame.width) * 100;
                    const topPct = (minY / frame.height) * 100;
                    const widthPct = ((maxX - minX + 1) / frame.width) * 100;
                    const heightPct = ((maxY - minY + 1) / frame.height) * 100;

                    return (
                      <div
                        key={roi.id}
                        style={{
                          left: `${leftPct}%`,
                          top: `${topPct}%`,
                          width: `${widthPct}%`,
                          height: `${heightPct}%`,
                          borderColor: roi.color,
                          borderRadius: roi.type === 'circle' ? '9999px' : '2px'
                        }}
                        className="absolute border-2 bg-sky-500/10"
                      >
                        <span
                          style={{ backgroundColor: roi.color }}
                          className="absolute -top-4 left-0 text-black font-mono font-bold text-[8px] px-1 rounded"
                        >
                          {roi.id}
                        </span>
                      </div>
                    );
                  })}

                  {/* Active Drag ROI Preview */}
                  {dragStart && currentDrag && (
                    <div
                      style={{
                        left: `${(Math.min(dragStart.x, currentDrag.x) / frame.width) * 100}%`,
                        top: `${(Math.min(dragStart.y, currentDrag.y) / frame.height) * 100}%`,
                        width: `${((Math.abs(currentDrag.x - dragStart.x) + 1) / frame.width) * 100}%`,
                        height: `${((Math.abs(currentDrag.y - dragStart.y) + 1) / frame.height) * 100}%`,
                        borderRadius: roiDrawingMode === 'circle' ? '9999px' : '2px'
                      }}
                      className="absolute border-2 border-orange-400 border-dashed bg-orange-400/20"
                    />
                  )}
                </div>
              )}

              {/* Hover Crosshair */}
              {hoveredPixel && frame && (
                <div
                  style={{
                    left: `${(hoveredPixel.x / frame.width) * 100}%`,
                    top: `${(hoveredPixel.y / frame.height) * 100}%`,
                    width: `${100 / frame.width}%`,
                    height: `${100 / frame.height}%`
                  }}
                  className="absolute border border-cyan-400 pointer-events-none shadow-[0_0_6px_rgba(34,211,238,0.8)]"
                />
              )}
            </div>
          )}

          {/* Reconstruction Banner if active */}
          {displayMode === 'RECONSTRUCTED' && (
            <div className="absolute top-6 left-6 bg-purple-950/80 border border-purple-500 text-purple-200 px-3 py-1.5 rounded text-xs font-mono backdrop-blur">
              <span className="font-bold text-purple-300">RECONSTRUCTION MODE</span> (BICUBIC SUPER-RESOLUTION)
              <div className="text-[10px] text-purple-300/80">Interpolated field — Not raw physical sensor elements</div>
            </div>
          )}
        </div>

        {/* Right Side Calibration Scale & Inspector Pane */}
        <div className="w-72 border-l border-[#1b2533] bg-[#0d131a] flex flex-col justify-between p-3 space-y-3 overflow-y-auto">
          {/* Temperature Colour Legend */}
          <div className="bg-[#121a24] border border-[#233142] p-2.5 rounded">
            <div className="flex items-center justify-between text-[11px] font-mono text-slate-300 mb-1.5">
              <span>THERMAL SCALE</span>
              <span className="text-orange-400 font-bold">{stats.max}°C</span>
            </div>

            {/* Gradient Bar with Ticks */}
            <div className="relative h-44 flex">
              <div
                className="w-5 h-full rounded border border-[#334155]"
                style={{
                  background:
                    palette === 'Iron'
                      ? 'linear-gradient(to top, #000 0%, #280a50 20%, #a0145a 40%, #e65a14 60%, #ffc814 80%, #fff 100%)'
                      : palette === 'Inferno'
                      ? 'linear-gradient(to top, #000004 0%, #57106e 25%, #bb3754 50%, #f98e09 75%, #fcffa4 100%)'
                      : palette === 'Viridis'
                      ? 'linear-gradient(to top, #440154 0%, #3b528b 25%, #21918c 50%, #5ec962 75%, #fde725 100%)'
                      : palette === 'Plasma'
                      ? 'linear-gradient(to top, #0d0887 0%, #7e03a8 25%, #cc4778 50%, #f89540 75%, #f0f921 100%)'
                      : palette === 'Grayscale'
                      ? 'linear-gradient(to top, #000 0%, #888 50%, #fff 100%)'
                      : 'linear-gradient(to top, #1e3cdc 0%, #50b4f0 25%, #f0f0f0 50%, #f08c32 75%, #dc1e1e 100%)'
                }}
              />

              {/* Numerical Scale Ticks */}
              <div className="flex-1 flex flex-col justify-between pl-3 font-mono text-[10px] text-slate-400">
                <span className="text-red-400 font-bold">{stats.max.toFixed(1)}°C — HIGH</span>
                <span>{((stats.max + stats.mean) / 2).toFixed(1)}°C</span>
                <span className="text-emerald-400 font-medium">{stats.mean.toFixed(1)}°C — MEAN</span>
                <span>{((stats.min + stats.mean) / 2).toFixed(1)}°C</span>
                <span className="text-cyan-400 font-bold">{stats.min.toFixed(1)}°C — LOW</span>
              </div>
            </div>
          </div>

          {/* Interactive Hover Crosshair Panel */}
          <div className="bg-[#121a24] border border-[#233142] p-2.5 rounded font-mono text-xs space-y-1.5">
            <div className="flex items-center justify-between border-b border-[#233142] pb-1">
              <span className="text-slate-400 font-bold flex items-center space-x-1">
                <Crosshair className="w-3 h-3 text-cyan-400" />
                <span>CROSSHAIR</span>
              </span>
              <span className="text-[10px] text-slate-400">Click to Inspect</span>
            </div>

            {hoveredData ? (
              <div className="space-y-1 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-400">PIXEL:</span>
                  <span className="text-cyan-300 font-bold">X: {hoveredData.x} | Y: {hoveredData.y}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">RAW ADC:</span>
                  <span className="text-slate-200">{hoveredData.raw.toFixed(0)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">CALIBRATED:</span>
                  <span className="text-orange-400 font-bold">{hoveredData.calibrated.toFixed(2)} °C</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">FILTERED:</span>
                  <span className="text-emerald-400">{hoveredData.filtered.toFixed(2)} °C</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">QUALITY:</span>
                  <span
                    className={`font-bold ${
                      hoveredData.quality === 'GOOD'
                        ? 'text-emerald-400'
                        : hoveredData.quality === 'WARNING'
                        ? 'text-amber-400'
                        : 'text-red-500'
                    }`}
                  >
                    {hoveredData.quality}
                  </span>
                </div>
              </div>
            ) : (
              <div className="text-slate-400 text-[11px] py-2 text-center italic">
                Hover over sensor matrix to inspect individual pixel transduction.
              </div>
            )}
          </div>

          {/* Active Hotspots Summary */}
          <div className="bg-[#121a24] border border-[#233142] p-2.5 rounded font-mono text-xs space-y-1">
            <div className="flex items-center justify-between border-b border-[#233142] pb-1">
              <span className="text-slate-300 font-bold">DETECTED HOTSPOTS</span>
              <span className="text-orange-400 font-bold">{hotspots.length}</span>
            </div>
            {hotspots.length > 0 ? (
              <div className="space-y-1.5 max-h-32 overflow-y-auto pr-1">
                {hotspots.map((hs) => (
                  <div key={hs.id} className="bg-[#182330] p-1.5 rounded border border-red-500/30 text-[11px]">
                    <div className="flex justify-between text-red-400 font-bold">
                      <span>{hs.id}</span>
                      <span>{hs.maxTemp}°C</span>
                    </div>
                    <div className="flex justify-between text-slate-400 text-[10px]">
                      <span>Center: ({hs.centroid.x}, {hs.centroid.y})</span>
                      <span>Rise: +{hs.tempRise}°C</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-slate-400 text-[11px] py-1">No thermal alarm clusters active.</div>
            )}
          </div>
        </div>
      </div>

      {/* Bottom Telemetry Bar */}
      <div className="border-t border-[#1b2533] bg-[#090d12] px-4 py-2 flex items-center justify-between font-mono text-xs">
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <span className="text-slate-400">TEMP MIN:</span>
            <span className="text-cyan-400 font-bold">{stats.min.toFixed(1)} °C</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-slate-400">MAX:</span>
            <span className="text-red-400 font-bold">{stats.max.toFixed(1)} °C</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-slate-400">MEAN:</span>
            <span className="text-emerald-400 font-bold">{stats.mean.toFixed(1)} °C</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-slate-400">EST. NOISE (NETD):</span>
            <span className="text-orange-400 font-bold">{stats.estimatedNoise.toFixed(3)} °C</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-slate-400">BAD PIXELS:</span>
            <span className={stats.badPixelCount > 0 ? 'text-amber-400 font-bold' : 'text-slate-300'}>
              {stats.badPixelCount} / {currentWidth * currentHeight}
            </span>
          </div>
        </div>

        <div className="text-[11px] text-slate-400">
          PROVENANCE: <span className="text-slate-300">{frame?.provenance.join(' → ') || 'RAW'}</span>
        </div>
      </div>
    </div>
  );
};
