/**
 * THERMAL ARRAY.OS - Signal Processing & Spatial / Temporal Filter Workbench
 */

import React from 'react';
import {
  PipelineConfig,
  TemporalFilterType,
  SpatialFilterType
} from '../types';
import { Sliders, Activity, ShieldCheck, Layers } from 'lucide-react';

interface FiltersViewProps {
  pipeline: PipelineConfig;
  onUpdatePipeline: (updates: Partial<PipelineConfig>) => void;
}

export const FiltersView: React.FC<FiltersViewProps> = ({ pipeline, onUpdatePipeline }) => {
  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6 font-mono text-xs text-slate-200">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#1f2937] pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <Sliders className="w-5 h-5 text-cyan-400" />
            <h1 className="text-base font-bold text-slate-100">TEMPORAL & SPATIAL SIGNAL PROCESSING</h1>
          </div>
          <p className="text-slate-400 text-xs mt-1">
            Remove microbolometer sensor noise without blurring critical thermal hotspots or softening physical gradient edges.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Panel 1: Bad Pixel Interpolation */}
        <div className="bg-[#121a24] border border-[#233142] p-4 rounded-lg space-y-4">
          <div className="flex items-center justify-between border-b border-[#233142] pb-2">
            <h3 className="font-bold text-slate-100 text-xs flex items-center space-x-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>BAD PIXEL REPLACEMENT</span>
            </h3>
            <label className="flex items-center space-x-1 cursor-pointer">
              <input
                type="checkbox"
                checked={pipeline.enableBadPixelCorrection}
                onChange={(e) => onUpdatePipeline({ enableBadPixelCorrection: e.target.checked })}
                className="accent-emerald-500"
              />
              <span className="text-[10px] text-emerald-400 font-bold">ENABLE</span>
            </label>
          </div>

          <div className="space-y-2">
            <label className="text-slate-400 text-[11px] block">INTERPOLATION KERNEL:</label>
            {[
              { id: 'local_median', label: 'Local 3×3 Median (Recommended)', desc: 'Robust against impulse noise & cluster defects' },
              { id: 'local_weighted_mean', label: 'Distance Weighted Inverse Mean', desc: 'Smooth spatial gradient interpolation' },
              { id: 'bilinear', label: 'Bilinear 4-Neighbor Interpolation', desc: 'Standard 2D bilinear gradient estimate' },
              { id: 'nearest', label: 'Nearest Valid Neighbor', desc: 'Fastest single-neighbor replacement' }
            ].map((m) => (
              <label
                key={m.id}
                className={`flex items-start space-x-2 p-2 rounded border cursor-pointer ${
                  pipeline.badPixelMethod === m.id
                    ? 'bg-emerald-950/40 border-emerald-500 text-white'
                    : 'bg-[#16202c] border-[#2d3d4f] text-slate-400 hover:text-slate-200'
                }`}
              >
                <input
                  type="radio"
                  name="bad_pixel_method"
                  value={m.id}
                  checked={pipeline.badPixelMethod === m.id}
                  onChange={() => onUpdatePipeline({ badPixelMethod: m.id as any })}
                  className="mt-0.5 accent-emerald-500"
                />
                <div>
                  <span className="font-bold block text-xs">{m.label}</span>
                  <span className="text-[10px] text-slate-400">{m.desc}</span>
                </div>
              </label>
            ))}
          </div>
        </div>

        {/* Panel 2: Temporal Filtering */}
        <div className="bg-[#121a24] border border-[#233142] p-4 rounded-lg space-y-4">
          <div className="flex items-center justify-between border-b border-[#233142] pb-2">
            <h3 className="font-bold text-slate-100 text-xs flex items-center space-x-2">
              <Activity className="w-4 h-4 text-cyan-400" />
              <span>TEMPORAL FILTERING</span>
            </h3>
            <select
              value={pipeline.temporalFilter}
              onChange={(e) => onUpdatePipeline({ temporalFilter: e.target.value as TemporalFilterType })}
              className="bg-[#16202c] border border-[#2d3d4f] text-cyan-300 font-mono text-[11px] rounded px-2 py-0.5"
            >
              <option value="none">NONE (BYPASS)</option>
              <option value="ema">EXPONENTIAL MOVING AVG (EMA)</option>
              <option value="kalman">1D KALMAN FILTER</option>
              <option value="moving_average">ROLLING MEAN (N-FRAMES)</option>
            </select>
          </div>

          <div className="space-y-4">
            {pipeline.temporalFilter === 'ema' && (
              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>SMOOTHING FACTOR (ALPHA):</span>
                  <span className="text-cyan-400 font-bold">{pipeline.temporalAlpha.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min="0.05"
                  max="0.95"
                  step="0.05"
                  value={pipeline.temporalAlpha}
                  onChange={(e) => onUpdatePipeline({ temporalAlpha: parseFloat(e.target.value) })}
                  className="w-full accent-cyan-500 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>High Smoothing (0.1)</span>
                  <span>Fast Response (0.9)</span>
                </div>
              </div>
            )}

            {pipeline.temporalFilter === 'kalman' && (
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>PROCESS NOISE (Q):</span>
                    <span className="text-cyan-400 font-bold">{pipeline.temporalProcessNoise.toFixed(3)}</span>
                  </div>
                  <input
                    type="range"
                    min="0.005"
                    max="0.2"
                    step="0.005"
                    value={pipeline.temporalProcessNoise}
                    onChange={(e) => onUpdatePipeline({ temporalProcessNoise: parseFloat(e.target.value) })}
                    className="w-full accent-cyan-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>MEASUREMENT NOISE (R):</span>
                    <span className="text-cyan-400 font-bold">{pipeline.temporalMeasNoise.toFixed(2)}</span>
                  </div>
                  <input
                    type="range"
                    min="0.05"
                    max="1.0"
                    step="0.05"
                    value={pipeline.temporalMeasNoise}
                    onChange={(e) => onUpdatePipeline({ temporalMeasNoise: parseFloat(e.target.value) })}
                    className="w-full accent-cyan-500 cursor-pointer"
                  />
                </div>
              </div>
            )}

            {pipeline.temporalFilter === 'moving_average' && (
              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>ROLLING WINDOW (FRAMES):</span>
                  <span className="text-cyan-400 font-bold">{pipeline.temporalWindow}</span>
                </div>
                <input
                  type="range"
                  min="2"
                  max="10"
                  step="1"
                  value={pipeline.temporalWindow}
                  onChange={(e) => onUpdatePipeline({ temporalWindow: parseInt(e.target.value) })}
                  className="w-full accent-cyan-500 cursor-pointer"
                />
              </div>
            )}

            <p className="text-[10px] text-slate-400">
              Temporal filtering significantly reduces high-frequency NETD noise across stationary thermal fields.
            </p>
          </div>
        </div>

        {/* Panel 3: Spatial Filtering */}
        <div className="bg-[#121a24] border border-[#233142] p-4 rounded-lg space-y-4">
          <div className="flex items-center justify-between border-b border-[#233142] pb-2">
            <h3 className="font-bold text-slate-100 text-xs flex items-center space-x-2">
              <Layers className="w-4 h-4 text-orange-400" />
              <span>SPATIAL 2D FILTERING</span>
            </h3>
            <select
              value={pipeline.spatialFilter}
              onChange={(e) => onUpdatePipeline({ spatialFilter: e.target.value as SpatialFilterType })}
              className="bg-[#16202c] border border-[#2d3d4f] text-orange-300 font-mono text-[11px] rounded px-2 py-0.5"
            >
              <option value="none">NONE (BYPASS)</option>
              <option value="gaussian">GAUSSIAN BLUR (3×3)</option>
              <option value="median">MEDIAN FILTER (3×3)</option>
              <option value="bilateral">BILATERAL (EDGE-PRESERVING)</option>
              <option value="laplacian">LAPLACIAN SHARPENING</option>
            </select>
          </div>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>SPATIAL SIGMA (σ_s):</span>
                <span className="text-orange-400 font-bold">{pipeline.spatialSigma.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.3"
                max="2.0"
                step="0.1"
                value={pipeline.spatialSigma}
                onChange={(e) => onUpdatePipeline({ spatialSigma: parseFloat(e.target.value) })}
                className="w-full accent-orange-500 cursor-pointer"
              />
            </div>

            {pipeline.spatialFilter === 'bilateral' && (
              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>COLOR/THERMAL SIGMA (σ_r):</span>
                  <span className="text-orange-400 font-bold">{pipeline.spatialSigmaColor.toFixed(1)} °C</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="8.0"
                  step="0.5"
                  value={pipeline.spatialSigmaColor}
                  onChange={(e) => onUpdatePipeline({ spatialSigmaColor: parseFloat(e.target.value) })}
                  className="w-full accent-orange-500 cursor-pointer"
                />
                <span className="text-[10px] text-slate-400">
                  Maintains steep gradient boundaries while suppressing sensor grain.
                </span>
              </div>
            )}

            <div className="bg-[#16202c] p-2 rounded border border-[#2d3d4f] text-[10px] text-slate-400">
              Note: Spatial smoothing is calibrated to prevent eroding genuine industrial hotspots.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
