/**
 * THERMAL ARRAY.OS - Industrial Audit Report & Export Generator
 */

import React, { useState } from 'react';
import {
  ThermalFrame,
  SensorConfig,
  PipelineConfig,
  CalibrationModelData,
  FrameStatistics,
  Hotspot,
  AnomalyResult
} from '../types';
import { REngine } from '../engine/rEngine';
import { FileText, Download, Printer, Copy, CheckCircle, ShieldCheck } from 'lucide-react';

interface ReportsViewProps {
  frame: ThermalFrame | null;
  stats: FrameStatistics;
  config: SensorConfig;
  pipeline: PipelineConfig;
  calModel: CalibrationModelData;
  hotspots: Hotspot[];
  anomalyResult: AnomalyResult | null;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  frame,
  stats,
  config,
  pipeline,
  calModel,
  hotspots,
  anomalyResult
}) => {
  const [copied, setCopied] = useState<boolean>(false);

  const reportDate = new Date().toISOString();
  const rScript = REngine.generateRProcessingPipeline(config, pipeline);

  const exportJSON = () => {
    const reportData = {
      platform: 'THERMAL ARRAY.OS (R-Centric Engine)',
      timestamp: reportDate,
      sensor: {
        geometry: `${config.width}x${config.height}`,
        samplingRateHz: config.samplingRate,
        integrationTimeMs: config.integrationTime,
        emissivity: config.emissivity,
        ambientTempC: config.ambientTemp,
        netdMk: config.netd
      },
      calibration: {
        method: calModel.method,
        rmse: calModel.rmse,
        mae: calModel.mae,
        r2: calModel.r2
      },
      thermalTelemetry: {
        minC: stats.min,
        maxC: stats.max,
        meanC: stats.mean,
        estimatedNoiseC: stats.estimatedNoise,
        badPixels: stats.badPixelCount
      },
      hotspots,
      anomalyResult,
      reproducibleRScript: rScript
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `thermal-audit-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportCSV = () => {
    if (!frame) return;
    let csv = `x,y,raw_adc,calibrated_c,filtered_c,quality_code\n`;
    for (let y = 0; y < frame.height; y++) {
      for (let x = 0; x < frame.width; x++) {
        const idx = y * frame.width + x;
        csv += `${x},${y},${frame.rawValues[idx]},${frame.calibratedValues[idx].toFixed(2)},${frame.filteredValues[idx].toFixed(2)},${frame.qualityMask[idx]}\n`;
      }
    }
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `thermal-matrix-${config.width}x${config.height}-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleCopyReport = () => {
    const text = document.getElementById('report-printable-area')?.innerText || '';
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6 font-mono text-xs text-slate-200">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#1f2937] pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <FileText className="w-5 h-5 text-orange-400" />
            <h1 className="text-base font-bold text-slate-100">AUDIT REPORT & DATA EXPORT</h1>
          </div>
          <p className="text-slate-400 text-xs mt-1">
            Generate formal industrial thermal inspection reports with embedded provenance and reproducible R code.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={exportCSV}
            className="px-3 py-1.5 bg-[#16202c] hover:bg-[#202d3e] border border-[#2d3d4f] text-slate-200 rounded flex items-center space-x-1 font-bold"
          >
            <Download className="w-3.5 h-3.5" />
            <span>EXPORT CSV</span>
          </button>
          <button
            onClick={exportJSON}
            className="px-3 py-1.5 bg-[#16202c] hover:bg-[#202d3e] border border-[#2d3d4f] text-slate-200 rounded flex items-center space-x-1 font-bold"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>EXPORT JSON</span>
          </button>
          <button
            onClick={handleCopyReport}
            className="px-3 py-1.5 bg-orange-600 hover:bg-orange-500 text-white rounded flex items-center space-x-1 font-bold"
          >
            {copied ? <CheckCircle className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'COPIED' : 'COPY REPORT'}</span>
          </button>
        </div>
      </div>

      {/* Printable Report Document Card */}
      <div id="report-printable-area" className="bg-[#0f172a] border border-[#334155] rounded-lg p-6 space-y-6 shadow-2xl">
        {/* Document Header */}
        <div className="border-b border-[#334155] pb-4 flex justify-between items-start">
          <div>
            <div className="text-base font-bold text-slate-100 flex items-center space-x-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <span>THERMAL ARRAY.OS — RADIOMETRIC AUDIT CERTIFICATE</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              Inspection ID: TA-OS-{Date.now().toString(36).toUpperCase()} | Timestamp: {reportDate}
            </div>
          </div>
          <div className="text-right text-[11px]">
            <span className="text-emerald-400 font-bold block">STATUS: AUDIT VERIFIED</span>
            <span className="text-slate-400">Computational Engine: R 4.3.2</span>
          </div>
        </div>

        {/* Sensor & Environmental Telemetry */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="bg-[#141e2e] p-2.5 rounded border border-[#233144]">
            <span className="text-slate-400 text-[10px] block">ARRAY GEOMETRY</span>
            <span className="text-sm font-bold text-slate-200">{config.width} × {config.height} ({config.width * config.height} px)</span>
          </div>
          <div className="bg-[#141e2e] p-2.5 rounded border border-[#233144]">
            <span className="text-slate-400 text-[10px] block">SURFACE EMISSIVITY (ε)</span>
            <span className="text-sm font-bold text-emerald-400">{config.emissivity.toFixed(2)}</span>
          </div>
          <div className="bg-[#141e2e] p-2.5 rounded border border-[#233144]">
            <span className="text-slate-400 text-[10px] block">AMBIENT AIR TEMP</span>
            <span className="text-sm font-bold text-cyan-400">{config.ambientTemp.toFixed(1)} °C</span>
          </div>
          <div className="bg-[#141e2e] p-2.5 rounded border border-[#233144]">
            <span className="text-slate-400 text-[10px] block">CALIBRATION RMSE</span>
            <span className="text-sm font-bold text-orange-400">{calModel.rmse} °C (R² = {calModel.r2})</span>
          </div>
        </div>

        {/* Global Summary Statistics */}
        <div className="bg-[#141e2e] p-4 rounded border border-[#233144] space-y-2">
          <h3 className="font-bold text-slate-200 text-xs border-b border-[#233144] pb-1.5">
            THERMAL FIELD STATISTICS
          </h3>
          <div className="grid grid-cols-5 gap-3 pt-1 text-center">
            <div>
              <span className="text-slate-400 text-[10px] block">MIN TEMP</span>
              <span className="text-base font-bold text-cyan-400">{stats.min.toFixed(2)} °C</span>
            </div>
            <div>
              <span className="text-slate-400 text-[10px] block">MAX TEMP</span>
              <span className="text-base font-bold text-red-400">{stats.max.toFixed(2)} °C</span>
            </div>
            <div>
              <span className="text-slate-400 text-[10px] block">MEAN FIELD</span>
              <span className="text-base font-bold text-emerald-400">{stats.mean.toFixed(2)} °C</span>
            </div>
            <div>
              <span className="text-slate-400 text-[10px] block">EST. NOISE (NETD)</span>
              <span className="text-base font-bold text-orange-400">{stats.estimatedNoise.toFixed(3)} °C</span>
            </div>
            <div>
              <span className="text-slate-400 text-[10px] block">DEFECTIVE PIXELS</span>
              <span className="text-base font-bold text-slate-200">{stats.badPixelCount}</span>
            </div>
          </div>
        </div>

        {/* Detected Hotspots Breakdown Table */}
        <div className="space-y-2">
          <h3 className="font-bold text-slate-200 text-xs">IDENTIFIED THERMAL HOTSPOTS & DEFECTS</h3>
          {hotspots.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-[#141e2e] text-slate-400 border-b border-[#233144]">
                    <th className="p-2">CLUSTER ID</th>
                    <th className="p-2">CENTROID (X, Y)</th>
                    <th className="p-2">MAX TEMP</th>
                    <th className="p-2">TEMP RISE (ΔT)</th>
                    <th className="p-2">PIXEL AREA</th>
                    <th className="p-2">CONFIDENCE</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#233144]">
                  {hotspots.map((hs) => (
                    <tr key={hs.id} className="text-slate-300">
                      <td className="p-2 font-bold text-red-400">{hs.id}</td>
                      <td className="p-2">({hs.centroid.x}, {hs.centroid.y})</td>
                      <td className="p-2 font-bold text-red-400">{hs.maxTemp} °C</td>
                      <td className="p-2 text-amber-400">+{hs.tempRise} °C</td>
                      <td className="p-2">{hs.area} px</td>
                      <td className="p-2 text-emerald-400">{(hs.confidence * 100).toFixed(0)}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="p-3 bg-[#141e2e] rounded text-slate-400 italic">
              No localized overheating clusters detected within nominal operating limits.
            </div>
          )}
        </div>

        {/* Embedded Reproducible R Code */}
        <div className="space-y-2">
          <h3 className="font-bold text-slate-200 text-xs">EMBEDDED REPRODUCIBLE R SCRIPT</h3>
          <div className="bg-[#0b0f14] border border-[#1e293b] p-3 rounded text-[11px] text-slate-400 max-h-40 overflow-y-auto">
            <pre>{rScript}</pre>
          </div>
        </div>
      </div>
    </div>
  );
};
