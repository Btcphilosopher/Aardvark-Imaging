/**
 * THERMAL ARRAY.OS - Time-Series Engine & Thermal Video Sequence Replay
 */

import React, { useState } from 'react';
import { ROI } from '../types';
import { Play, Pause, SkipBack, SkipForward, RotateCcw, Clock, TrendingUp, BarChart2 } from 'lucide-react';

interface TimeSeriesViewProps {
  recordedFrameCount: number;
  currentPlaybackIndex: number;
  isPlaying: boolean;
  onTogglePlayback: () => void;
  onSeek: (index: number) => void;
  playbackSpeed: number;
  onSpeedChange: (speed: number) => void;
  rois: ROI[];
}

export const TimeSeriesView: React.FC<TimeSeriesViewProps> = ({
  recordedFrameCount,
  currentPlaybackIndex,
  isPlaying,
  onTogglePlayback,
  onSeek,
  playbackSpeed,
  onSpeedChange,
  rois
}) => {
  const speeds = [1, 2, 5, 10];

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6 font-mono text-xs text-slate-200">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#1f2937] pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <Clock className="w-5 h-5 text-orange-400" />
            <h1 className="text-base font-bold text-slate-100">TIME-SERIES RECORDER & THERMAL VIDEO REPLAY</h1>
          </div>
          <p className="text-slate-400 text-xs mt-1">
            Replay high-speed thermal matrix sequences, inspect temporal temperature rise rates (°C/s), and examine ROI thermal inertia.
          </p>
        </div>

        <div className="bg-[#121a24] border border-[#233142] px-3 py-1.5 rounded text-[11px]">
          <span className="text-slate-400">RECORDED BUFFER: </span>
          <span className="text-orange-400 font-bold">{recordedFrameCount} Frames</span>
        </div>
      </div>

      {/* Video Replay Control Transport */}
      <div className="bg-[#121a24] border border-[#233142] p-4 rounded-lg space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => onSeek(Math.max(0, currentPlaybackIndex - 1))}
              className="p-2 bg-[#16202c] border border-[#2d3d4f] hover:bg-[#1f2b3a] rounded text-slate-300"
            >
              <SkipBack className="w-4 h-4" />
            </button>
            <button
              onClick={onTogglePlayback}
              className="px-4 py-2 bg-orange-600 hover:bg-orange-500 text-white rounded font-bold flex items-center space-x-1.5"
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              <span>{isPlaying ? 'PAUSE' : 'PLAY'}</span>
            </button>
            <button
              onClick={() => onSeek(Math.min(recordedFrameCount - 1, currentPlaybackIndex + 1))}
              className="p-2 bg-[#16202c] border border-[#2d3d4f] hover:bg-[#1f2b3a] rounded text-slate-300"
            >
              <SkipForward className="w-4 h-4" />
            </button>
          </div>

          {/* Frame Counter */}
          <div className="font-mono text-sm">
            <span className="text-slate-400">FRAME: </span>
            <span className="text-orange-400 font-bold">
              {String(currentPlaybackIndex + 1).padStart(4, '0')}
            </span>
            <span className="text-slate-500"> / {String(recordedFrameCount).padStart(4, '0')}</span>
          </div>

          {/* Speed Multipliers */}
          <div className="flex items-center space-x-1 bg-[#16202c] p-1 rounded border border-[#2d3d4f]">
            {speeds.map((s) => (
              <button
                key={s}
                onClick={() => onSpeedChange(s)}
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                  playbackSpeed === s
                    ? 'bg-orange-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {s}×
              </button>
            ))}
          </div>
        </div>

        {/* Scrubber Timeline */}
        <div className="space-y-1">
          <input
            type="range"
            min="0"
            max={Math.max(1, recordedFrameCount - 1)}
            value={currentPlaybackIndex}
            onChange={(e) => onSeek(parseInt(e.target.value))}
            className="w-full accent-orange-500 cursor-pointer h-2 bg-[#1e293b] rounded"
          />
          <div className="flex justify-between text-[10px] text-slate-400">
            <span>00:00.00 (t0)</span>
            <span>+ {((currentPlaybackIndex / 25)).toFixed(2)} s</span>
            <span>+ {((recordedFrameCount / 25)).toFixed(2)} s</span>
          </div>
        </div>
      </div>

      {/* ROI Thermal Signatures & Waveforms */}
      <div className="bg-[#121a24] border border-[#233142] p-4 rounded-lg space-y-4">
        <div className="flex items-center justify-between border-b border-[#233142] pb-2">
          <h3 className="font-bold text-slate-100 text-xs flex items-center space-x-2">
            <TrendingUp className="w-4 h-4 text-cyan-400" />
            <span>REGION OF INTEREST (ROI) THERMAL SIGNATURES</span>
          </h3>
          <span className="text-[10px] text-slate-400">Time-dependent Mean & Peak</span>
        </div>

        {rois.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {rois.map((roi) => (
              <div key={roi.id} className="bg-[#16202c] p-3 rounded border border-[#2d3d4f] space-y-2">
                <div className="flex justify-between items-center" style={{ color: roi.color }}>
                  <span className="font-bold text-sm">{roi.id}: {roi.label}</span>
                  <span className="text-[11px] font-mono px-1.5 py-0.5 rounded bg-black/40">
                    Rise: +0.45 °C/s
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-[10px] text-slate-400 pt-1">
                  <div>Peak: <span className="text-red-400 font-bold">54.2 °C</span></div>
                  <div>Mean: <span className="text-emerald-400 font-bold">41.8 °C</span></div>
                  <div>Std Dev: <span className="text-cyan-400 font-bold">1.24 °C</span></div>
                </div>

                {/* Synthetic Sparkline representation */}
                <div className="h-14 bg-[#0b0f14] rounded p-1 flex items-end space-x-1 border border-[#1f2937]">
                  {Array.from({ length: 24 }).map((_, idx) => {
                    const h = 20 + Math.sin(idx * 0.4) * 15 + idx * 1.5;
                    return (
                      <div
                        key={idx}
                        style={{ height: `${Math.min(100, h)}%`, backgroundColor: roi.color }}
                        className="flex-1 rounded-t opacity-80"
                      />
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-6 text-slate-400 italic">
            Draw Regions of Interest (ROI) on the Live Array View to track regional thermal signatures over time.
          </div>
        )}
      </div>
    </div>
  );
};
