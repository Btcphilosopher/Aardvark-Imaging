/**
 * THERMAL ARRAY.OS - Pixel Inspector Modal / Drawer
 * Detailed per-pixel calibration, gain, offset, noise, quality status and real-time time-series plot
 */

import React from 'react';
import { PixelInspection } from '../types';
import { X, Activity, Sliders, ShieldCheck } from 'lucide-react';

interface PixelInspectorProps {
  inspection: PixelInspection | null;
  onClose: () => void;
}

export const PixelInspector: React.FC<PixelInspectorProps> = ({ inspection, onClose }) => {
  if (!inspection) return null;

  // Render SVG Sparkline / Time-Series of temperature over time
  const history = inspection.history || [];
  const temps = history.map((h) => h.temp);
  const minT = temps.length > 0 ? Math.min(...temps) - 0.5 : 20;
  const maxT = temps.length > 0 ? Math.max(...temps) + 0.5 : 80;
  const rangeT = Math.max(0.2, maxT - minT);

  const width = 380;
  const height = 120;
  const padding = 20;

  const points = history
    .map((h, i) => {
      const x = padding + (i / (history.length - 1 || 1)) * (width - 2 * padding);
      const y = height - padding - ((h.temp - minT) / rangeT) * (height - 2 * padding);
      return `${x},${y}`;
    })
    .join(' ');

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-[#0f172a] border border-[#334155] rounded-lg shadow-2xl w-full max-w-lg overflow-hidden font-mono text-xs">
        {/* Header */}
        <div className="bg-[#1e293b] px-4 py-3 border-b border-[#334155] flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Activity className="w-4 h-4 text-orange-400" />
            <span className="font-bold text-slate-100 text-sm">
              PIXEL INSPECTOR — [{inspection.x}, {inspection.y}]
            </span>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded hover:bg-[#334155]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body Metrics Grid */}
        <div className="p-4 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-[#141e2e] p-2.5 rounded border border-[#233144]">
              <span className="text-slate-400 text-[10px] block">CALIBRATED TEMPERATURE</span>
              <span className="text-xl font-bold text-orange-400">{inspection.calibrated.toFixed(2)} °C</span>
              <span className="text-slate-500 text-[10px] block mt-0.5">Raw ADC: {inspection.raw}</span>
            </div>

            <div className="bg-[#141e2e] p-2.5 rounded border border-[#233144]">
              <span className="text-slate-400 text-[10px] block">QUALITY STATUS</span>
              <span
                className={`text-xl font-bold ${
                  inspection.quality === 'GOOD'
                    ? 'text-emerald-400'
                    : inspection.quality === 'WARNING'
                    ? 'text-amber-400'
                    : 'text-red-500'
                }`}
              >
                {inspection.quality}
              </span>
              <span className="text-slate-400 text-[10px] block mt-0.5">Defect Type: {inspection.badType}</span>
            </div>

            <div className="bg-[#141e2e] p-2.5 rounded border border-[#233144]">
              <span className="text-slate-400 text-[10px] block">ESTIMATED NOISE (NETD)</span>
              <span className="text-base font-bold text-cyan-400">{inspection.noise.toFixed(3)} °C</span>
              <span className="text-slate-500 text-[10px] block mt-0.5">Residual: ±{inspection.residual.toFixed(3)} °C</span>
            </div>

            <div className="bg-[#141e2e] p-2.5 rounded border border-[#233144]">
              <span className="text-slate-400 text-[10px] block">CALIBRATION GAIN / OFFSET</span>
              <span className="text-base font-bold text-slate-200">
                g: {inspection.gain.toFixed(3)} | o: {inspection.offset.toFixed(2)}
              </span>
              <span className="text-slate-500 text-[10px] block mt-0.5">Model: 2-Point Linear</span>
            </div>
          </div>

          {/* Time Series Waveform */}
          <div className="bg-[#141e2e] p-3 rounded border border-[#233144]">
            <div className="flex items-center justify-between mb-2">
              <span className="text-slate-300 font-bold text-[11px]">TEMPORAL RESPONSE (LAST 30 FRAMES)</span>
              <span className="text-slate-400 text-[10px]">
                Range: {minT.toFixed(1)}°C - {maxT.toFixed(1)}°C
              </span>
            </div>

            <div className="bg-[#0b0f14] p-2 rounded border border-[#1b2533] flex justify-center">
              <svg width={width} height={height} className="overflow-visible">
                {/* Grid lines */}
                <line x1={padding} y1={height / 2} x2={width - padding} y2={height / 2} stroke="#1e293b" strokeDasharray="3 3" />
                <line x1={padding} y1={height - padding} x2={width - padding} y2={height - padding} stroke="#334155" />
                <line x1={padding} y1={padding} x2={padding} y2={height - padding} stroke="#334155" />

                {/* Polyline */}
                {history.length > 1 && (
                  <polyline
                    fill="none"
                    stroke="#f97316"
                    strokeWidth="2"
                    points={points}
                  />
                )}

                {/* Points */}
                {history.map((h, i) => {
                  const x = padding + (i / (history.length - 1 || 1)) * (width - 2 * padding);
                  const y = height - padding - ((h.temp - minT) / rangeT) * (height - 2 * padding);
                  return <circle key={i} cx={x} cy={y} r="2" fill="#38bdf8" />;
                })}
              </svg>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-[#1e293b] px-4 py-2 border-t border-[#334155] flex justify-end">
          <button
            onClick={onClose}
            className="px-3 py-1 bg-slate-700 hover:bg-slate-600 text-white rounded text-xs transition-colors"
          >
            CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};
