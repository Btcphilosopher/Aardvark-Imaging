/**
 * THERMAL ARRAY.OS - Calibration & Non-Uniformity Correction (NUC) Workbench
 */

import React, { useState } from 'react';
import { CalibrationModelData, CalibrationMethod, ThermalFrame } from '../types';
import { Sliders, CheckCircle2, Play, BarChart2, Layers } from 'lucide-react';

interface CalibrationViewProps {
  calModel: CalibrationModelData;
  frame: ThermalFrame | null;
  onRunCalibration: (method: CalibrationMethod) => void;
  onToggleNuc: (enable: boolean) => void;
  nucEnabled: boolean;
}

export const CalibrationView: React.FC<CalibrationViewProps> = ({
  calModel,
  frame,
  onRunCalibration,
  onToggleNuc,
  nucEnabled
}) => {
  const [selectedMethod, setSelectedMethod] = useState<CalibrationMethod>(calModel.method);
  const [activeMap, setActiveMap] = useState<'gain' | 'offset' | 'residual'>('residual');

  // Residual histogram computation
  const residuals = calModel.residuals || new Float32Array(0);
  const bins = 10;
  const histData: number[] = new Array(bins).fill(0);
  const maxRes = Math.max(0.1, calModel.maxError);

  for (let i = 0; i < residuals.length; i++) {
    const binIdx = Math.min(bins - 1, Math.floor((residuals[i] / maxRes) * bins));
    histData[binIdx]++;
  }
  const maxHistCount = Math.max(1, ...histData);

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6 font-mono text-xs text-slate-200">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#1f2937] pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <Sliders className="w-5 h-5 text-orange-400" />
            <h1 className="text-base font-bold text-slate-100">CALIBRATION & NON-UNIFORMITY ENGINE</h1>
          </div>
          <p className="text-slate-400 text-xs mt-1">
            Fit mathematical conversion models across reference blackbodies, estimate per-pixel gain/offset, and compute NUC residual maps.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => onToggleNuc(!nucEnabled)}
            className={`px-3 py-1.5 rounded font-bold border transition-colors ${
              nucEnabled
                ? 'bg-emerald-950/70 border-emerald-500 text-emerald-300'
                : 'bg-[#121a24] border-[#233142] text-slate-400 hover:text-slate-200'
            }`}
          >
            NUC: {nucEnabled ? 'ACTIVE (FIXED-PATTERN REMOVED)' : 'BYPASSED'}
          </button>
        </div>
      </div>

      {/* Calibration Reference Sources & Fit trigger */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-[#121a24] border border-[#233142] p-3 rounded">
          <span className="text-slate-400 text-[10px] block mb-1">REFERENCE 1 (COLD BLACKBODY)</span>
          <span className="text-base font-bold text-cyan-400">20.00 °C</span>
          <span className="text-[10px] text-slate-500 block mt-1">ADC Count: ~4,200</span>
        </div>

        <div className="bg-[#121a24] border border-[#233142] p-3 rounded">
          <span className="text-slate-400 text-[10px] block mb-1">REFERENCE 2 (MID BLACKBODY)</span>
          <span className="text-base font-bold text-orange-400">50.00 °C</span>
          <span className="text-[10px] text-slate-500 block mt-1">ADC Count: ~6,600</span>
        </div>

        <div className="bg-[#121a24] border border-[#233142] p-3 rounded">
          <span className="text-slate-400 text-[10px] block mb-1">REFERENCE 3 (HOT BLACKBODY)</span>
          <span className="text-base font-bold text-red-400">100.00 °C</span>
          <span className="text-[10px] text-slate-500 block mt-1">ADC Count: ~10,600</span>
        </div>

        <div className="bg-[#182330] border border-orange-500/50 p-3 rounded flex flex-col justify-between">
          <div className="flex justify-between items-center">
            <span className="text-orange-400 font-bold text-[11px]">CALIBRATION FIT</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <button
            onClick={() => onRunCalibration(selectedMethod)}
            className="w-full mt-2 py-1.5 bg-orange-600 hover:bg-orange-500 text-white rounded font-bold text-xs flex items-center justify-center space-x-1 transition-colors"
          >
            <Play className="w-3.5 h-3.5" />
            <span>RECALIBRATE SENSOR</span>
          </button>
        </div>
      </div>

      {/* Model Selection & Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Model Selector */}
        <div className="bg-[#121a24] border border-[#233142] p-4 rounded-lg space-y-3">
          <h3 className="font-bold text-slate-100 text-xs border-b border-[#233142] pb-2">
            CALIBRATION MATHEMATICAL MODEL
          </h3>

          <div className="space-y-2">
            {[
              { id: 'two_point', name: 'Two-Point Linear (T = aX + b)', desc: 'Standard industrial 2-point radiometric conversion' },
              { id: 'multi_point_poly', name: 'Polynomial Curve (T = a0 + a1X + a2X²)', desc: 'Higher-order non-linear thermal detector response' },
              { id: 'robust_regression', name: 'Robust Huber Regression', desc: 'Outlier-resistant M-estimator calibration' },
              { id: 'lookup_table', name: 'Calibrated LUT (Look-Up Table)', desc: 'Direct indexed radiometric interpolation table' }
            ].map((m) => (
              <label
                key={m.id}
                className={`flex items-start space-x-2 p-2 rounded border cursor-pointer transition-all ${
                  selectedMethod === m.id
                    ? 'bg-orange-950/40 border-orange-500'
                    : 'bg-[#16202c] border-[#2d3d4f] hover:border-slate-500'
                }`}
              >
                <input
                  type="radio"
                  name="cal_model"
                  value={m.id}
                  checked={selectedMethod === m.id}
                  onChange={() => setSelectedMethod(m.id as CalibrationMethod)}
                  className="mt-0.5 accent-orange-500"
                />
                <div>
                  <span className="font-bold text-slate-200 block text-xs">{m.name}</span>
                  <span className="text-slate-400 text-[10px]">{m.desc}</span>
                </div>
              </label>
            ))}
          </div>
        </div>

        {/* Model Goodness-of-Fit Metrics */}
        <div className="bg-[#121a24] border border-[#233142] p-4 rounded-lg space-y-3">
          <h3 className="font-bold text-slate-100 text-xs border-b border-[#233142] pb-2">
            CALIBRATION FIT QUALITY METRICS
          </h3>

          <div className="grid grid-cols-2 gap-3">
            <div className="bg-[#16202c] p-2.5 rounded border border-[#2d3d4f]">
              <span className="text-slate-400 text-[10px] block">RMSE (ERROR)</span>
              <span className="text-lg font-bold text-cyan-400">{calModel.rmse} °C</span>
            </div>

            <div className="bg-[#16202c] p-2.5 rounded border border-[#2d3d4f]">
              <span className="text-slate-400 text-[10px] block">MAE (ABS ERROR)</span>
              <span className="text-lg font-bold text-cyan-400">{calModel.mae} °C</span>
            </div>

            <div className="bg-[#16202c] p-2.5 rounded border border-[#2d3d4f]">
              <span className="text-slate-400 text-[10px] block">R² COEFFICIENT</span>
              <span className="text-lg font-bold text-emerald-400">{calModel.r2}</span>
            </div>

            <div className="bg-[#16202c] p-2.5 rounded border border-[#2d3d4f]">
              <span className="text-slate-400 text-[10px] block">MAX RESIDUAL</span>
              <span className="text-lg font-bold text-amber-400">{calModel.maxError} °C</span>
            </div>
          </div>

          <div className="bg-[#16202c] p-2 rounded border border-[#2d3d4f] text-[11px] flex justify-between">
            <span className="text-slate-400">SYSTEMATIC BIAS:</span>
            <span className="text-slate-200 font-bold">{calModel.bias.toFixed(4)} °C</span>
          </div>
        </div>

        {/* Residual Histogram */}
        <div className="bg-[#121a24] border border-[#233142] p-4 rounded-lg space-y-3 flex flex-col justify-between">
          <div className="flex items-center justify-between border-b border-[#233142] pb-2">
            <h3 className="font-bold text-slate-100 text-xs flex items-center space-x-1.5">
              <BarChart2 className="w-4 h-4 text-orange-400" />
              <span>RESIDUAL DISTRIBUTION</span>
            </h3>
            <span className="text-[10px] text-slate-400">0 to {maxRes.toFixed(2)}°C</span>
          </div>

          <div className="h-32 flex items-end space-x-1.5 bg-[#0b0f14] p-2 rounded border border-[#1e293b]">
            {histData.map((count, i) => {
              const heightPct = (count / maxHistCount) * 100;
              return (
                <div key={i} className="flex-1 flex flex-col items-center group relative">
                  <div
                    style={{ height: `${Math.max(4, heightPct)}%` }}
                    className="w-full bg-orange-500 hover:bg-orange-400 rounded-t transition-all"
                  />
                  <div className="opacity-0 group-hover:opacity-100 absolute -top-6 bg-black text-white text-[9px] px-1 rounded pointer-events-none">
                    {count}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="text-[10px] text-slate-400 text-center">
            Narrow Gaussian residual distribution confirms high focal-plane uniformity.
          </div>
        </div>
      </div>
    </div>
  );
};
