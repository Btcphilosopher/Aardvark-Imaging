/**
 * THERMAL ARRAY.OS - Main Navigation & Telemetry Header
 */

import React from 'react';
import {
  Activity,
  Cpu,
  Layers,
  Sliders,
  Maximize2,
  TrendingUp,
  AlertTriangle,
  Clock,
  FlaskConical,
  Database,
  ShieldCheck,
  Terminal,
  Play,
  Pause,
  RotateCcw,
  FileText
} from 'lucide-react';
import { DisplayMode, ScenarioType, ActiveTab, FrameStatistics, SensorConfig } from '../types';

interface NavbarProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  displayMode: DisplayMode;
  onSelectDisplayMode: (mode: DisplayMode) => void;
  isStreaming: boolean;
  onToggleStream: () => void;
  onReset?: () => void;
  stats: FrameStatistics;
  config: SensorConfig;
  scenario: ScenarioType;
  onSelectScenario: (scenario: ScenarioType) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  onSelectTab,
  displayMode,
  onSelectDisplayMode,
  isStreaming,
  onToggleStream,
  onReset,
  stats,
  config,
  scenario,
  onSelectScenario
}) => {
  const tabs: { id: ActiveTab; label: string; icon: React.ReactNode }[] = [
    { id: 'live_array', label: 'LIVE ARRAY', icon: <Layers className="w-3.5 h-3.5" /> },
    { id: 'sensor_config', label: 'SENSOR CONFIG', icon: <Cpu className="w-3.5 h-3.5" /> },
    { id: 'calibration', label: 'CALIBRATION & NUC', icon: <Sliders className="w-3.5 h-3.5" /> },
    { id: 'filters', label: 'FILTERS & DSP', icon: <Sliders className="w-3.5 h-3.5" /> },
    { id: 'reconstruction', label: 'RECONSTRUCTION', icon: <Maximize2 className="w-3.5 h-3.5" /> },
    { id: 'thermal_analysis', label: 'THERMAL GRADIENTS', icon: <TrendingUp className="w-3.5 h-3.5" /> },
    { id: 'detection', label: 'DETECTION & ALARMS', icon: <AlertTriangle className="w-3.5 h-3.5" /> },
    { id: 'time_series', label: 'TIME SERIES REPLAY', icon: <Clock className="w-3.5 h-3.5" /> },
    { id: 'simulation', label: 'SIMULATION BENCHMARKS', icon: <FlaskConical className="w-3.5 h-3.5" /> },
    { id: 'r_architecture', label: 'R ENGINE & PACKAGES', icon: <Terminal className="w-3.5 h-3.5" /> },
    { id: 'reports', label: 'AUDIT REPORTS', icon: <FileText className="w-3.5 h-3.5" /> }
  ];

  return (
    <header className="border-b border-[#1f2937] bg-[#0d131a] select-none sticky top-0 z-40">
      {/* Top Telemetry Strip */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-[#19222e] text-xs">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2">
            <div className="w-2.5 h-2.5 rounded-sm bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.6)]" />
            <span className="font-bold tracking-wider text-slate-100 text-sm">THERMAL ARRAY.OS</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#1e293b] text-orange-400 font-mono border border-[#334155]">
              R-ENGINE v4.4 (C/WASM)
            </span>
          </div>

          <div className="h-3 w-px bg-slate-700" />

          {/* Quick Scenario Selector */}
          <div className="flex items-center space-x-1.5">
            <span className="text-slate-400 text-[11px]">SCENE:</span>
            <select
              value={scenario}
              onChange={(e) => onSelectScenario(e.target.value as ScenarioType)}
              className="bg-[#141d26] border border-[#2d3d4f] text-orange-300 font-mono text-[11px] rounded px-2 py-0.5 focus:outline-none focus:border-orange-500"
            >
              <option value="motor_bearing">INDUSTRIAL MOTOR (BEARING 72°C)</option>
              <option value="battery_pack">BATTERY PACK (8×12 RUNAWAY)</option>
              <option value="electrical_panel">ELECTRICAL PANEL (OVERHEATING LUG)</option>
              <option value="building_facade">BUILDING FACADE (ENVELOPE LEAK)</option>
              <option value="industrial_pipe">STEAM PIPELINE (DEGRADATION)</option>
              <option value="uniform_blackbody">UNIFORM BLACKBODY (35°C REF)</option>
            </select>
          </div>
        </div>

        {/* Global Controls & Stream Telemetry */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 bg-[#141d26] border border-[#2d3d4f] rounded px-2 py-0.5 text-[11px] font-mono">
            <span className="text-slate-400">ARRAY:</span>
            <span className="text-emerald-400 font-medium">{config.width} × {config.height}</span>
            <span className="text-slate-500">|</span>
            <span className="text-slate-400">RATE:</span>
            <span className="text-cyan-400 font-medium">{config.samplingRate} Hz</span>
            <span className="text-slate-500">|</span>
            <span className="text-slate-400">MEAN:</span>
            <span className="text-slate-200 font-bold">{stats.mean.toFixed(1)} °C</span>
          </div>

          {/* Display Mode Selector */}
          <div className="flex items-center bg-[#141d26] p-0.5 rounded border border-[#2d3d4f]">
            {(['RAW', 'CALIBRATED', 'FILTERED', 'RECONSTRUCTED'] as DisplayMode[]).map((mode) => (
              <button
                key={mode}
                onClick={() => onSelectDisplayMode(mode)}
                className={`px-2 py-0.5 text-[10px] font-mono font-medium rounded transition-colors ${
                  displayMode === mode
                    ? 'bg-orange-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#1f2b38]'
                }`}
              >
                {mode}
              </button>
            ))}
          </div>

          {/* Stream Control Buttons */}
          <div className="flex items-center space-x-1.5">
            <button
              onClick={onToggleStream}
              className={`flex items-center space-x-1 px-2.5 py-1 text-xs font-mono font-medium rounded transition-colors ${
                isStreaming
                  ? 'bg-amber-600/80 hover:bg-amber-600 text-white'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white'
              }`}
            >
              {isStreaming ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
              <span>{isStreaming ? 'FREEZE' : 'ACQUIRE'}</span>
            </button>

            {onReset && (
              <button
                onClick={onReset}
                title="Reset Stream Simulation"
                className="p-1 text-slate-400 hover:text-slate-200 hover:bg-[#1e293b] rounded transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Main Tab Navigation */}
      <nav className="flex items-center overflow-x-auto scrollbar-none px-2 bg-[#090d12]">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              className={`flex items-center space-x-1.5 px-3 py-2 text-[11px] font-mono font-medium whitespace-nowrap border-b-2 transition-all ${
                isActive
                  ? 'border-orange-500 text-orange-400 bg-[#121922]'
                  : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-[#0e141c]'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>
    </header>
  );
};
