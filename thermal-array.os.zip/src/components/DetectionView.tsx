/**
 * THERMAL ARRAY.OS - Hotspot & Statistical Anomaly Detection Engine
 */

import React, { useState } from 'react';
import { Hotspot, AnomalyResult, AnomalyMethod, ThermalFrame } from '../types';
import { ThermalEngine } from '../engine/thermalEngine';
import { AlertTriangle, ShieldAlert, Sliders, Activity, CheckCircle2 } from 'lucide-react';

interface DetectionViewProps {
  frame: ThermalFrame | null;
  hotspots: Hotspot[];
  anomalyResult: AnomalyResult | null;
  onUpdateAnomalyMethod: (method: AnomalyMethod, threshold: number) => void;
}

export const DetectionView: React.FC<DetectionViewProps> = ({
  frame,
  hotspots,
  anomalyResult,
  onUpdateAnomalyMethod
}) => {
  const [selectedMethod, setSelectedMethod] = useState<AnomalyMethod>('robust_z_score');
  const [thresholdSigma, setThresholdSigma] = useState<number>(3.0);
  const [absHotspotThreshold, setAbsHotspotThreshold] = useState<number>(45.0);

  const methods: { id: AnomalyMethod; label: string; desc: string }[] = [
    { id: 'robust_z_score', label: 'Robust Z-Score (Median Absolute Deviation)', desc: 'Resistant to heavy background sensor noise and outliers' },
    { id: 'z_score', label: 'Standard Parametric Z-Score ((x - μ) / σ)', desc: 'Fast Gaussian deviation thresholding' },
    { id: 'cusum', label: 'CUSUM (Cumulative Sum Control Chart)', desc: 'Detects persistent small mean shifts & gradual thermal drift' },
    { id: 'ewma', label: 'EWMA (Exponential Weighted Moving Average)', desc: 'Temporal historical baseline trend analysis' },
    { id: 'pca_error', label: 'PCA / Spatial Reconstruction Error', desc: 'Isolates abnormal spatial thermal patterns from dominant modes' }
  ];

  const handleMethodChange = (m: AnomalyMethod) => {
    setSelectedMethod(m);
    onUpdateAnomalyMethod(m, thresholdSigma);
  };

  const handleThresholdChange = (t: number) => {
    setThresholdSigma(t);
    onUpdateAnomalyMethod(selectedMethod, t);
  };

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6 font-mono text-xs text-slate-200">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#1f2937] pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <AlertTriangle className="w-5 h-5 text-red-500" />
            <h1 className="text-base font-bold text-slate-100">HOTSPOT & STATISTICAL ANOMALY DETECTION</h1>
          </div>
          <p className="text-slate-400 text-xs mt-1">
            Connected component clustering and statistical control charts for automated industrial anomaly identification.
          </p>
        </div>

        <div className="flex items-center space-x-2 bg-[#121a24] border border-[#233142] px-3 py-1.5 rounded">
          <span className="text-slate-400">ACTIVE DETECTIONS:</span>
          <span className="text-red-400 font-bold">{hotspots.length} HOTSPOTS</span>
          <span className="text-slate-500">|</span>
          <span className="text-amber-400 font-bold">{anomalyResult?.anomalyCount || 0} OUTLIERS</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Hotspot Clustering Module */}
        <div className="bg-[#121a24] border border-[#233142] p-4 rounded-lg space-y-4">
          <div className="flex items-center justify-between border-b border-[#233142] pb-2">
            <h3 className="font-bold text-slate-100 text-xs flex items-center space-x-2">
              <ShieldAlert className="w-4 h-4 text-red-400" />
              <span>HOTSPOT DETECTOR CONFIGURATION</span>
            </h3>
            <span className="text-[10px] text-slate-400">8-Connected Clustering</span>
          </div>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>ABSOLUTE TEMP THRESHOLD:</span>
                <span className="text-red-400 font-bold">{absHotspotThreshold.toFixed(1)} °C</span>
              </div>
              <input
                type="range"
                min="25"
                max="100"
                step="1"
                value={absHotspotThreshold}
                onChange={(e) => setAbsHotspotThreshold(parseFloat(e.target.value))}
                className="w-full accent-red-500 cursor-pointer"
              />
            </div>

            {/* List of Detected Hotspots */}
            <div className="space-y-2">
              <span className="text-slate-400 text-[11px] block">DETECTED THERMAL HOTSPOTS:</span>
              {hotspots.length > 0 ? (
                <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
                  {hotspots.map((hs) => (
                    <div key={hs.id} className="bg-[#182330] p-2.5 rounded border border-red-500/40 space-y-1">
                      <div className="flex justify-between items-center text-red-400 font-bold">
                        <span>{hs.id} — Centroid ({hs.centroid.x}, {hs.centroid.y})</span>
                        <span className="text-sm">{hs.maxTemp} °C</span>
                      </div>
                      <div className="grid grid-cols-3 gap-2 text-[10px] text-slate-400 pt-1">
                        <div>Area: <span className="text-slate-200">{hs.area} px</span></div>
                        <div>Rise: <span className="text-amber-400">+{hs.tempRise} °C</span></div>
                        <div>Confidence: <span className="text-emerald-400">{(hs.confidence * 100).toFixed(0)}%</span></div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="bg-[#16202c] p-3 rounded text-slate-400 text-center italic">
                  No thermal clusters currently exceed detection threshold.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Statistical Anomaly Detection Module */}
        <div className="bg-[#121a24] border border-[#233142] p-4 rounded-lg space-y-4">
          <div className="flex items-center justify-between border-b border-[#233142] pb-2">
            <h3 className="font-bold text-slate-100 text-xs flex items-center space-x-2">
              <Activity className="w-4 h-4 text-amber-400" />
              <span>STATISTICAL ANOMALY METHOD</span>
            </h3>
            <span className="text-amber-400 font-bold">{thresholdSigma.toFixed(1)} σ</span>
          </div>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>STATISTICAL SENSITIVITY THRESHOLD (σ):</span>
                <span className="text-amber-400 font-bold">{thresholdSigma.toFixed(1)} σ</span>
              </div>
              <input
                type="range"
                min="1.5"
                max="6.0"
                step="0.1"
                value={thresholdSigma}
                onChange={(e) => handleThresholdChange(parseFloat(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>

            <div className="space-y-1.5">
              {methods.map((m) => (
                <label
                  key={m.id}
                  className={`flex items-start space-x-2 p-2 rounded border cursor-pointer transition-all ${
                    selectedMethod === m.id
                      ? 'bg-amber-950/40 border-amber-500 text-white'
                      : 'bg-[#16202c] border-[#2d3d4f] text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <input
                    type="radio"
                    name="anomaly_method"
                    value={m.id}
                    checked={selectedMethod === m.id}
                    onChange={() => handleMethodChange(m.id)}
                    className="mt-0.5 accent-amber-500"
                  />
                  <div>
                    <span className="font-bold text-xs block">{m.label}</span>
                    <span className="text-[10px] text-slate-400">{m.desc}</span>
                  </div>
                </label>
              ))}
            </div>

            {anomalyResult && (
              <div className="bg-[#16202c] p-2.5 rounded border border-[#2d3d4f] text-[11px] text-slate-300">
                <span className="text-slate-400 block mb-0.5">ALGORITHM OUTCOME:</span>
                {anomalyResult.description}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
