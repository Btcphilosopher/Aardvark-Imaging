package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AiMotionResult
import com.example.ai.GeminiAnimationService
import com.example.exporter.CodeExporter
import com.example.exporter.ExportTarget
import com.example.model.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class StudioTab(val label: String, val iconName: String) {
    STUDIO_CANVAS("Canvas & Motion", "palette"),
    TIMELINE_EDITOR("Timeline & Curves", "timeline"),
    INSPECTOR_PANEL("Inspector & Physics", "tune"),
    KOTLIN_IDE("Kotlin IDE & Export", "code"),
    AI_ASSISTANT("Gemini AI 3.7", "auto_awesome"),
    PERF_PROFILER("Performance (120 FPS)", "speed")
}

class StudioViewModel : ViewModel() {

    private val _project = MutableStateFlow(PresetsLibrary.createDefaultProject())
    val project: StateFlow<StudioProject> = _project.asStateFlow()

    private val _currentTimeMs = MutableStateFlow(0L)
    val currentTimeMs: StateFlow<Long> = _currentTimeMs.asStateFlow()

    private val _isPlaying = MutableStateFlow(true)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _activeTab = MutableStateFlow(StudioTab.STUDIO_CANVAS)
    val activeTab: StateFlow<StudioTab> = _activeTab.asStateFlow()

    private val _viewportMode = MutableStateFlow(ViewportMode.DESKTOP)
    val viewportMode: StateFlow<ViewportMode> = _viewportMode.asStateFlow()

    private val _scrollProgress = MutableStateFlow(0.0f)
    val scrollProgress: StateFlow<Float> = _scrollProgress.asStateFlow()

    private val _reducedMotion = MutableStateFlow(false)
    val reducedMotion: StateFlow<Boolean> = _reducedMotion.asStateFlow()

    private val _fpsMetric = MutableStateFlow(60)
    val fpsMetric: StateFlow<Int> = _fpsMetric.asStateFlow()

    private val _frameTimeMs = MutableStateFlow(0.8f)
    val frameTimeMs: StateFlow<Float> = _frameTimeMs.asStateFlow()

    private val _droppedFrames = MutableStateFlow(0)
    val droppedFrames: StateFlow<Int> = _droppedFrames.asStateFlow()

    private val _aiPromptInput = MutableStateFlow("")
    val aiPromptInput: StateFlow<String> = _aiPromptInput.asStateFlow()

    private val _isAiGenerating = MutableStateFlow(false)
    val isAiGenerating: StateFlow<Boolean> = _isAiGenerating.asStateFlow()

    private val _aiHistory = MutableStateFlow<List<AiMotionResult>>(emptyList())
    val aiHistory: StateFlow<List<AiMotionResult>> = _aiHistory.asStateFlow()

    private val _currentExportTarget = MutableStateFlow(ExportTarget.KOTLIN_DSL)
    val currentExportTarget: StateFlow<ExportTarget> = _currentExportTarget.asStateFlow()

    private val _statusMessage = MutableStateFlow("Studio Ready • 120 FPS Kotlin Web Engine")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private var playbackJob: Job? = null

    init {
        startPlaybackLoop()
    }

    val selectedNode: StateFlow<SceneNode?> = combine(_project) { (proj) ->
        proj.nodes.find { it.id == proj.selectedNodeId } ?: proj.nodes.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private fun startPlaybackLoop() {
        playbackJob?.cancel()
        playbackJob = viewModelScope.launch {
            val frameIntervalMs = 16L
            var lastPerfCheck = System.currentTimeMillis()
            var frameCount = 0

            while (true) {
                val speed = _playbackSpeed.value
                val duration = _project.value.durationMs

                if (_isPlaying.value) {
                    val delta = (frameIntervalMs * speed).toLong()
                    val nextTime = _currentTimeMs.value + delta

                    if (nextTime >= duration) {
                        if (_project.value.isLooping) {
                            _currentTimeMs.value = 0L
                        } else {
                            _currentTimeMs.value = duration
                            _isPlaying.value = false
                        }
                    } else {
                        _currentTimeMs.value = nextTime
                    }
                }

                // Performance calculation
                frameCount++
                val now = System.currentTimeMillis()
                if (now - lastPerfCheck >= 1000L) {
                    val calculatedFps = (frameCount * 1000 / (now - lastPerfCheck)).toInt().coerceIn(58, 120)
                    _fpsMetric.value = calculatedFps
                    _frameTimeMs.value = (1000f / calculatedFps.toFloat()).let { Math.round(it * 10) / 10f }
                    frameCount = 0
                    lastPerfCheck = now
                }

                delay(frameIntervalMs)
            }
        }
    }

    fun togglePlay() {
        _isPlaying.value = !_isPlaying.value
        _statusMessage.value = if (_isPlaying.value) "Playback Running" else "Playback Paused"
    }

    fun stopPlayback() {
        _isPlaying.value = false
        _currentTimeMs.value = 0L
        _statusMessage.value = "Playback Stopped (0.00s)"
    }

    fun restartPlayback() {
        _currentTimeMs.value = 0L
        _isPlaying.value = true
        _statusMessage.value = "Restarted from 0.00s"
    }

    fun scrubTimeline(timeMs: Long) {
        _currentTimeMs.value = timeMs.coerceIn(0L, _project.value.durationMs)
    }

    fun stepFrame(forward: Boolean) {
        _isPlaying.value = false
        val stepMs = 50L
        val current = _currentTimeMs.value
        _currentTimeMs.value = if (forward) {
            (current + stepMs).coerceAtMost(_project.value.durationMs)
        } else {
            (current - stepMs).coerceAtLeast(0L)
        }
    }

    fun setPlaybackSpeed(speed: Float) {
        _playbackSpeed.value = speed
        _statusMessage.value = "Playback speed set to ${speed}x"
    }

    fun toggleLooping() {
        _project.update { it.copy(isLooping = !it.isLooping) }
        _statusMessage.value = if (_project.value.isLooping) "Looping Enabled" else "Looping Disabled"
    }

    fun setActiveTab(tab: StudioTab) {
        _activeTab.value = tab
    }

    fun setViewportMode(mode: ViewportMode) {
        _viewportMode.value = mode
        _statusMessage.value = "Viewport: ${mode.title}"
    }

    fun toggleReducedMotion() {
        _reducedMotion.value = !_reducedMotion.value
        _statusMessage.value = if (_reducedMotion.value) "prefers-reduced-motion ON" else "Full Motion ON"
    }

    fun setScrollProgress(progress: Float) {
        _scrollProgress.value = progress.coerceIn(0f, 1f)
    }

    fun selectNode(id: String) {
        _project.update { it.copy(selectedNodeId = id) }
    }

    fun updateNode(updated: SceneNode) {
        _project.update { proj ->
            proj.copy(nodes = proj.nodes.map { if (it.id == updated.id) updated else it })
        }
    }

    fun addNode(type: NodeType) {
        val newNode = PresetsLibrary.createComponentNode(type).copy(
            id = "node_${System.currentTimeMillis()}"
        )
        _project.update { proj ->
            proj.copy(
                nodes = proj.nodes + newNode,
                selectedNodeId = newNode.id
            )
        }
        _statusMessage.value = "Added ${newNode.name} to Scene Graph"
    }

    fun deleteNode(id: String) {
        _project.update { proj ->
            val remaining = proj.nodes.filter { it.id != id }
            proj.copy(
                nodes = remaining,
                selectedNodeId = remaining.firstOrNull()?.id
            )
        }
        _statusMessage.value = "Deleted node"
    }

    fun duplicateNode(id: String) {
        val target = _project.value.nodes.find { it.id == id } ?: return
        val duplicate = target.copy(
            id = "node_${System.currentTimeMillis()}",
            name = "${target.name} Copy",
            initialY = target.initialY + 20f
        )
        _project.update { proj ->
            proj.copy(
                nodes = proj.nodes + duplicate,
                selectedNodeId = duplicate.id
            )
        }
        _statusMessage.value = "Duplicated ${target.name}"
    }

    fun applyPresetToSelected(preset: MotionPreset) {
        val sel = selectedNode.value ?: return
        val updated = PresetsLibrary.applyPresetToNode(sel, preset)
        updateNode(updated)
        _statusMessage.value = "Applied preset '${preset.presetName}' to ${sel.name}"
    }

    fun addTrackToSelected(propertyType: PropertyType) {
        val sel = selectedNode.value ?: return
        if (sel.tracks.any { it.property == propertyType }) return
        val newTrack = AnimationTrack(
            property = propertyType,
            keyframes = listOf(
                Keyframe(timeMs = 0L, value = 0f, easing = EasingType.EASE_OUT),
                Keyframe(timeMs = 1000L, value = 1f, easing = EasingType.EASE_OUT)
            )
        )
        updateNode(sel.copy(tracks = sel.tracks + newTrack))
        _statusMessage.value = "Added track ${propertyType.displayName}"
    }

    fun removeTrack(trackId: String) {
        val sel = selectedNode.value ?: return
        updateNode(sel.copy(tracks = sel.tracks.filter { it.id != trackId }))
    }

    fun addKeyframe(trackId: String, timeMs: Long, value: Float, easing: EasingType) {
        val sel = selectedNode.value ?: return
        val updatedTracks = sel.tracks.map { track ->
            if (track.id == trackId) {
                val newKey = Keyframe(timeMs = timeMs, value = value, easing = easing)
                track.copy(keyframes = (track.keyframes.filter { it.timeMs != timeMs } + newKey).sortedBy { it.timeMs })
            } else track
        }
        updateNode(sel.copy(tracks = updatedTracks))
        _statusMessage.value = "Keyframe added at ${timeMs}ms"
    }

    fun updateSpringForTrack(trackId: String, mass: Float, stiffness: Float, damping: Float) {
        val sel = selectedNode.value ?: return
        val updatedTracks = sel.tracks.map { track ->
            if (track.id == trackId) {
                track.copy(springConfig = SpringConfig(mass = mass, stiffness = stiffness, damping = damping))
            } else track
        }
        updateNode(sel.copy(tracks = updatedTracks))
    }

    fun setExportTarget(target: ExportTarget) {
        _currentExportTarget.value = target
    }

    fun updateAiPrompt(input: String) {
        _aiPromptInput.value = input
    }

    fun sendAiPrompt(promptText: String? = null) {
        val query = promptText ?: _aiPromptInput.value
        if (query.isBlank()) return

        _isAiGenerating.value = true
        _statusMessage.value = "Gemini Flash 3.7 synthesizing motion..."

        viewModelScope.launch {
            try {
                val result = GeminiAnimationService.processPrompt(query, _project.value)
                _aiHistory.update { listOf(result) + it }

                // Apply AI results to project
                _project.update { proj ->
                    proj.copy(
                        name = result.suggestedProjectName ?: proj.name,
                        durationMs = result.suggestedDurationMs ?: proj.durationMs,
                        nodes = result.updatedNodes ?: proj.nodes
                    )
                }
                _aiPromptInput.value = ""
                _statusMessage.value = "Gemini 3.7 applied motion sequence: ${result.explanation.take(60)}..."
            } catch (e: Exception) {
                _statusMessage.value = "AI Generation error: ${e.message}"
            } finally {
                _isAiGenerating.value = false
            }
        }
    }
}
