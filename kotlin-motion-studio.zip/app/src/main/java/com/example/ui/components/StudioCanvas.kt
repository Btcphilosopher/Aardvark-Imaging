package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.ComputedProperties
import com.example.engine.MotionEngine
import com.example.model.*
import com.example.ui.theme.*
import com.example.viewmodel.StudioViewModel

@Composable
fun StudioCanvas(
    viewModel: StudioViewModel,
    project: StudioProject,
    currentTimeMs: Long,
    viewportMode: ViewportMode,
    reducedMotion: Boolean,
    scrollProgress: Float,
    selectedNodeId: String?,
    onOpenInspector: () -> Unit
) {
    var isSimulatingHover by remember { mutableStateOf(false) }
    var interactiveSpringOffset by remember { mutableStateOf(0f) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF1B192A), StudioBackground),
                    radius = 900f
                )
            )
    ) {
        // Grid lines background (Subtle frosted white dots/lines)
        Canvas(modifier = Modifier.fillMaxSize()) {
            val gridStep = 32.dp.toPx()
            for (x in 0..(size.width / gridStep).toInt()) {
                drawLine(
                    color = Color(0x08FFFFFF),
                    start = Offset(x * gridStep, 0f),
                    end = Offset(x * gridStep, size.height),
                    strokeWidth = 1f
                )
            }
            for (y in 0..(size.height / gridStep).toInt()) {
                drawLine(
                    color = Color(0x08FFFFFF),
                    start = Offset(0f, y * gridStep),
                    end = Offset(size.width, y * gridStep),
                    strokeWidth = 1f
                )
            }
        }

        // Center Viewport Stage
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Viewport Info Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .width(viewportMode.widthDp.dp)
                    .padding(bottom = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AspectRatio,
                        contentDescription = null,
                        tint = TextSecondary,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${viewportMode.title} Stage",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        fontWeight = FontWeight.Medium
                    )
                }

                Surface(
                    color = GlassFillSubtle,
                    shape = CircleShape,
                    border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorderSubtle)
                ) {
                    Text(
                        text = "${(currentTimeMs / 1000f).let { Math.round(it * 100) / 100f }}s / ${(project.durationMs / 1000f)}s",
                        fontSize = 11.sp,
                        color = IndigoLight,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }

            // Interactive Stage Container (Frosted Glass Canvas)
            Box(
                modifier = Modifier
                    .width(viewportMode.widthDp.dp)
                    .height(viewportMode.heightDp.dp)
                    .shadow(24.dp, RoundedCornerShape(24.dp))
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF1E1E24), Color(0xFF121216))
                        )
                    )
                    .border(1.dp, GlassBorderHighlight, RoundedCornerShape(24.dp))
                    .testTag("stage_canvas_container"),
                contentAlignment = Alignment.Center
            ) {
                // Subtle device speaker / dynamic indicator dot
                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 8.dp)
                        .size(width = 36.dp, height = 4.dp)
                        .clip(CircleShape)
                        .background(Color(0x33FFFFFF))
                )

                // Render all nodes in current project
                project.nodes.forEach { node ->
                    if (!node.isVisible) return@forEach

                    val computed = MotionEngine.computeProperties(
                        node = node,
                        timeMs = currentTimeMs,
                        reducedMotion = reducedMotion,
                        scrollProgress = scrollProgress
                    )

                    val isSelected = node.id == selectedNodeId

                    RenderCanvasNode(
                        node = node,
                        computed = computed,
                        isSelected = isSelected,
                        isHovered = isSimulatingHover,
                        extraSpringY = if (node.type == NodeType.BUTTON) interactiveSpringOffset else 0f,
                        onClick = {
                            viewModel.selectNode(node.id)
                        },
                        onDoubleTap = {
                            viewModel.selectNode(node.id)
                            onOpenInspector()
                        }
                    )
                }

                // Floating Frosted Mini-Inspector overlay in top right corner
                Surface(
                    color = StudioSurfaceGlass,
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorderSubtle),
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(IndigoLight)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "FPS: 60",
                            fontSize = 9.sp,
                            color = TextSecondary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Interactive Controls Overlay (Frosted Glass Scroll Scrubber & Spring test)
            Surface(
                color = StudioSurfaceGlass,
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorderSubtle),
                modifier = Modifier
                    .width(viewportMode.widthDp.dp)
                    .padding(top = 4.dp)
            ) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                    // Scroll animation simulator
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.SwapVert,
                                contentDescription = null,
                                tint = IndigoLight,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Scroll Progression (${(scrollProgress * 100).toInt()}%)",
                                fontSize = 11.sp,
                                color = TextPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        // Spring press test button
                        FilledTonalButton(
                            onClick = {
                                interactiveSpringOffset = -14f
                            },
                            shape = CircleShape,
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = GlassFillActive,
                                contentColor = IndigoLight
                            ),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                            modifier = Modifier.height(26.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.TouchApp,
                                contentDescription = null,
                                modifier = Modifier.size(10.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text("Test Spring", fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Slider(
                        value = scrollProgress,
                        onValueChange = { viewModel.setScrollProgress(it) },
                        colors = SliderDefaults.colors(
                            thumbColor = IndigoPrimary,
                            activeTrackColor = IndigoLight,
                            inactiveTrackColor = StudioSurfaceElevated
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(24.dp)
                            .testTag("scroll_simulator_slider")
                    )
                }
            }
        }
    }
}

@Composable
private fun RenderCanvasNode(
    node: SceneNode,
    computed: ComputedProperties,
    isSelected: Boolean,
    isHovered: Boolean,
    extraSpringY: Float,
    onClick: () -> Unit,
    onDoubleTap: () -> Unit
) {
    val hoverScale = if (isHovered && node.type == NodeType.CARD) 1.05f else 1.0f

    Box(
        modifier = Modifier
            .offset(x = computed.x.dp, y = (computed.y + extraSpringY).dp)
            .graphicsLayer {
                scaleX = computed.scale * hoverScale
                scaleY = computed.scale * hoverScale
                rotationZ = computed.rotation
                rotationY = computed.rotationY
                alpha = computed.opacity
                shadowElevation = computed.shadowElevation
            }
            .size(width = computed.width.dp, height = computed.height.dp)
            .clip(RoundedCornerShape(computed.cornerRadius.dp))
            .background(
                Brush.linearGradient(
                    listOf(
                        Color(node.backgroundColor),
                        Color(node.gradientEndColor)
                    )
                )
            )
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) CyanBright else Color(0x3338BDF8),
                shape = RoundedCornerShape(computed.cornerRadius.dp)
            )
            .pointerInput(node.id) {
                detectTapGestures(
                    onTap = { onClick() },
                    onDoubleTap = { onDoubleTap() }
                )
            }
            .padding(8.dp)
            .testTag("node_${node.name.lowercase()}"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                if (node.icon.isNotEmpty()) {
                    Icon(
                        imageVector = when (node.icon) {
                            "rocket_launch" -> Icons.Default.RocketLaunch
                            "flash_on" -> Icons.Default.FlashOn
                            "insights" -> Icons.Default.Insights
                            "touch_app" -> Icons.Default.TouchApp
                            "auto_awesome" -> Icons.Default.AutoAwesome
                            "hub" -> Icons.Default.Hub
                            else -> Icons.Default.Widgets
                        },
                        contentDescription = null,
                        tint = Color(node.accentColor),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                }

                Text(
                    text = node.text,
                    color = Color(node.textColor),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
            }

            if (node.subtitle.isNotEmpty()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = node.subtitle,
                    color = Color(node.textColor).copy(alpha = 0.7f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Normal,
                    maxLines = 1
                )
            }
        }

        // Selection pill indicator
        if (isSelected) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(2.dp)
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(CyanBright)
            )
        }
    }
}
