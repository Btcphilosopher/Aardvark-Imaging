package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ViewportMode
import com.example.ui.theme.*
import com.example.viewmodel.StudioViewModel

@Composable
fun StudioTopBar(
    viewModel: StudioViewModel,
    projectName: String,
    viewportMode: ViewportMode,
    reducedMotion: Boolean,
    statusMessage: String,
    onOpenAiSheet: () -> Unit,
    onOpenExportSheet: () -> Unit
) {
    Surface(
        color = StudioSurfaceGlass,
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
            // Top Row: App branding + Project title + AI trigger + Export
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Branding
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(IndigoPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "KS",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "KOTLIN MOTION STUDIO",
                            color = TextPrimary.copy(alpha = 0.95f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp
                        )
                        Text(
                            text = "Project: $projectName",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Normal,
                            maxLines = 1
                        )
                    }
                }

                // Actions: AI button & Export CTA
                Row(verticalAlignment = Alignment.CenterVertically) {
                    FilledTonalButton(
                        onClick = onOpenAiSheet,
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = GlassFillSubtle,
                            contentColor = IndigoLight
                        ),
                        shape = CircleShape,
                        border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorderSubtle),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(32.dp)
                            .testTag("ai_assistant_top_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "AI Assistant",
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Gemini 3.7", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    Button(
                        onClick = onOpenExportSheet,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = IndigoPrimary,
                            contentColor = Color.White
                        ),
                        shape = CircleShape,
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(32.dp)
                            .testTag("export_top_btn")
                    ) {
                        Text("Export", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Secondary Row: Viewport modes + Reduced motion pill + Status indicator
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
            ) {
                // Viewport segmented controls (Frosted Glass Pill)
                Row(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(GlassFillSubtle)
                        .border(1.dp, GlassBorderSubtle, CircleShape)
                        .padding(2.dp)
                ) {
                    ViewportMode.values().forEach { mode ->
                        val isSelected = mode == viewportMode
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(if (isSelected) IndigoPrimary else Color.Transparent)
                                .clickable { viewModel.setViewportMode(mode) }
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                                .testTag("viewport_${mode.name.lowercase()}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = when (mode) {
                                        ViewportMode.DESKTOP -> Icons.Default.DesktopWindows
                                        ViewportMode.TABLET -> Icons.Default.Tablet
                                        ViewportMode.MOBILE -> Icons.Default.PhoneAndroid
                                    },
                                    contentDescription = mode.title,
                                    tint = if (isSelected) Color.White else TextSecondary,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = mode.name,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) Color.White else TextSecondary
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Reduced motion toggle pill
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(if (reducedMotion) NeonAmber.copy(alpha = 0.15f) else GlassFillSubtle)
                        .border(1.dp, if (reducedMotion) NeonAmber.copy(alpha = 0.3f) else GlassBorderSubtle, CircleShape)
                        .clickable { viewModel.toggleReducedMotion() }
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                        .testTag("reduced_motion_toggle"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (reducedMotion) NeonAmber else TextTertiary)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = if (reducedMotion) "Reduced Motion: ON" else "Full Motion",
                            fontSize = 10.sp,
                            color = if (reducedMotion) NeonAmber else TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Engine status badge
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(IndigoPrimary.copy(alpha = 0.12f))
                        .border(1.dp, IndigoPrimary.copy(alpha = 0.25f), CircleShape)
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(IndigoLight)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = statusMessage.take(36),
                            fontSize = 10.sp,
                            color = IndigoLight,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}
