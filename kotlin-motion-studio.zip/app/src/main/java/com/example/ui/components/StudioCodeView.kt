package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.exporter.CodeExporter
import com.example.exporter.ExportTarget
import com.example.model.StudioProject
import com.example.ui.theme.*
import com.example.viewmodel.StudioViewModel

@Composable
fun StudioCodeView(
    viewModel: StudioViewModel,
    project: StudioProject,
    currentTarget: ExportTarget
) {
    val context = LocalContext.current
    val generatedCode = remember(project, currentTarget) {
        CodeExporter.generateCode(project, currentTarget)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioBackground)
            .padding(12.dp)
    ) {
        // Export Target Selector Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(bottom = 10.dp)
        ) {
            ExportTarget.values().forEach { target ->
                val isSelected = target == currentTarget
                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.setExportTarget(target) },
                    shape = CircleShape,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) IndigoPrimary else GlassBorderSubtle
                    ),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = IndigoPrimary,
                        selectedLabelColor = Color.White,
                        containerColor = StudioSurfaceVariantGlass,
                        labelColor = TextSecondary
                    ),
                    label = {
                        Text(
                            text = target.displayName,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = when (target) {
                                ExportTarget.KOTLIN_DSL, ExportTarget.KOTLIN_WASM -> Icons.Default.Code
                                ExportTarget.CSS_KEYFRAMES -> Icons.Default.Style
                                ExportTarget.WEB_ANIMATIONS_JS -> Icons.Default.Javascript
                                ExportTarget.HTML_STANDALONE -> Icons.Default.Language
                                ExportTarget.JSON_SCHEMA -> Icons.Default.DataArray
                            },
                            contentDescription = null,
                            tint = if (isSelected) Color.White else IndigoLight,
                            modifier = Modifier.size(14.dp)
                        )
                    },
                    modifier = Modifier.padding(end = 6.dp).testTag("export_chip_${target.name.lowercase()}")
                )
            }
        }

        // Action Toolbar: Copy, Export, Target details
        Surface(
            color = StudioSurfaceGlass,
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorderSubtle),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = null,
                        tint = IndigoLight,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${currentTarget.displayName} (${currentTarget.extension})",
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row {
                    FilledTonalButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("MotionStudioCode", generatedCode)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "Code copied to clipboard!", Toast.LENGTH_SHORT).show()
                        },
                        shape = CircleShape,
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = StudioSurfaceElevated,
                            contentColor = TextPrimary
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(30.dp).testTag("copy_code_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy",
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Copy", fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    Button(
                        onClick = {
                            Toast.makeText(context, "Exported ${project.name} package successfully!", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = IndigoPrimary,
                            contentColor = Color.White
                        ),
                        shape = CircleShape,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(30.dp).testTag("download_package_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = "Download",
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Export", fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Code Editor View
        Surface(
            color = Color(0xFF0C0C10),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorderSubtle),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            val lines = remember(generatedCode) { generatedCode.lines() }

            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .horizontalScroll(rememberScrollState())
                    .padding(10.dp)
            ) {
                // Line numbers
                Column(
                    modifier = Modifier
                        .padding(end = 12.dp)
                        .width(28.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    lines.forEachIndexed { idx, _ ->
                        Text(
                            text = "${idx + 1}",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = TextTertiary
                        )
                    }
                }

                // Code content
                Column {
                    lines.forEach { line ->
                        val lineColor = when {
                            line.trimStart().startsWith("//") || line.trimStart().startsWith("/*") || line.trimStart().startsWith("*") -> TextTertiary
                            line.contains("fun ") || line.contains("class ") || line.contains("@Composable") -> IndigoLight
                            line.contains("val ") || line.contains("var ") || line.contains("const ") -> CyanNeon
                            line.contains("animate") || line.contains("@keyframes") -> NeonAmber
                            line.contains("Color(") || line.contains("dp") || line.contains("ms") -> NeonEmerald
                            else -> TextPrimary
                        }

                        Text(
                            text = line,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = lineColor
                        )
                    }
                }
            }
        }
    }
}
