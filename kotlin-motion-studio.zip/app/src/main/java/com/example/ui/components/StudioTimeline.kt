package com.example.ui.components

import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*
import com.example.viewmodel.StudioViewModel

@Composable
fun StudioTimeline(
    viewModel: StudioViewModel,
    project: StudioProject,
    currentTimeMs: Long,
    isPlaying: Boolean,
    playbackSpeed: Float,
    selectedNode: SceneNode?,
    onOpenInspector: () -> Unit
) {
    var showAddKeyframeDialog by remember { mutableStateOf<AnimationTrack?>(null) }
    var newKeyframeValue by remember { mutableStateOf("1.0") }
    var selectedEasing by remember { mutableStateOf(EasingType.EASE_OUT) }

    Surface(
        color = StudioSurfaceGlass,
        border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorderSubtle),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            // Timeline Transport & Playback Toolbar
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Playback Controls
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { viewModel.restartPlayback() },
                        modifier = Modifier.size(32.dp).testTag("timeline_restart_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Replay,
                            contentDescription = "Restart",
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = { viewModel.stepFrame(forward = false) },
                        modifier = Modifier.size(32.dp).testTag("timeline_step_back_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipPrevious,
                            contentDescription = "Step Back",
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    FilledIconButton(
                        onClick = { viewModel.togglePlay() },
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = if (isPlaying) NeonAmber else IndigoPrimary,
                            contentColor = Color.White
                        ),
                        modifier = Modifier.size(36.dp).testTag("timeline_play_pause_btn")
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    IconButton(
                        onClick = { viewModel.stepFrame(forward = true) },
                        modifier = Modifier.size(32.dp).testTag("timeline_step_fwd_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipNext,
                            contentDescription = "Step Forward",
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = { viewModel.stopPlayback() },
                        modifier = Modifier.size(32.dp).testTag("timeline_stop_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = "Stop",
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = { viewModel.toggleLooping() },
                        modifier = Modifier.size(32.dp).testTag("timeline_loop_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Repeat,
                            contentDescription = "Loop",
                            tint = if (project.isLooping) IndigoLight else TextTertiary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // Speed Selector & Timecode Readout
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Speed pills (Frosted glass badges)
                    listOf(0.5f, 1.0f, 2.0f).forEach { speed ->
                        val isSpeed = playbackSpeed == speed
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSpeed) IndigoPrimary else GlassFillSubtle)
                                .border(1.dp, if (isSpeed) IndigoLight else GlassBorderSubtle, RoundedCornerShape(6.dp))
                                .clickable { viewModel.setPlaybackSpeed(speed) }
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "${speed}x",
                                fontSize = 10.sp,
                                fontWeight = if (isSpeed) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSpeed) Color.White else TextSecondary
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Timecode pill
                    Surface(
                        color = GlassFillSubtle,
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorderSubtle)
                    ) {
                        Text(
                            text = String.format("%.2fs", currentTimeMs / 1000f),
                            color = IndigoLight,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Time Ruler & Scrubbing Bar
            val totalDurationMs = project.durationMs
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(28.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF141418))
                    .border(1.dp, GlassBorderSubtle, RoundedCornerShape(8.dp))
                    .pointerInput(totalDurationMs) {
                        detectTapGestures { offset ->
                            val progress = (offset.x / size.width).coerceIn(0f, 1f)
                            viewModel.scrubTimeline((progress * totalDurationMs).toLong())
                        }
                    }
                    .testTag("timeline_ruler")
            ) {
                // Ruler ticks
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val steps = 8
                    for (i in 0..steps) {
                        val frac = i / steps.toFloat()
                        val x = frac * size.width
                        drawLine(
                            color = Color(0x18FFFFFF),
                            start = Offset(x, 0f),
                            end = Offset(x, size.height),
                            strokeWidth = 1f
                        )
                    }
                }

                // Ruler time text labels
                Row(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("0.0s", fontSize = 9.sp, color = TextTertiary)
                    Text("${totalDurationMs / 2000f}s", fontSize = 9.sp, color = TextTertiary)
                    Text("${totalDurationMs / 1000f}s", fontSize = 9.sp, color = TextTertiary)
                }

                // Playhead indicator
                val playheadFraction = (currentTimeMs.toFloat() / totalDurationMs.toFloat()).coerceIn(0f, 1f)
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .offset(x = (playheadFraction * 320).dp) // approximate visual offset
                        .width(2.dp)
                        .background(IndigoPrimary)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .align(Alignment.TopCenter)
                            .clip(CircleShape)
                            .background(IndigoLight)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Active Track Listing & Keyframe Lanes
            if (selectedNode != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Tracks: ${selectedNode.name}",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        fontWeight = FontWeight.SemiBold
                    )

                    FilledTonalButton(
                        onClick = onOpenInspector,
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = GlassFillActive,
                            contentColor = IndigoLight
                        ),
                        shape = CircleShape,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        modifier = Modifier.height(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = null,
                            modifier = Modifier.size(10.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Edit Properties", fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Scrollable Tracks Container
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 140.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    if (selectedNode.tracks.isEmpty()) {
                        Text(
                            text = "No animation tracks added yet. Tap 'Edit Properties' to add keyframes.",
                            fontSize = 10.sp,
                            color = TextTertiary,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    } else {
                        selectedNode.tracks.forEach { track ->
                            TrackRowItem(
                                track = track,
                                durationMs = totalDurationMs,
                                currentTimeMs = currentTimeMs,
                                onAddKeyframe = {
                                    showAddKeyframeDialog = track
                                },
                                onRemoveTrack = {
                                    viewModel.removeTrack(track.id)
                                }
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                        }
                    }
                }
            }
        }
    }

    // Add Keyframe Dialog
    if (showAddKeyframeDialog != null) {
        val track = showAddKeyframeDialog!!
        AlertDialog(
            containerColor = StudioSurfaceVariant,
            onDismissRequest = { showAddKeyframeDialog = null },
            title = {
                Text(
                    text = "Add Keyframe: ${track.property.displayName}",
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column {
                    Text(
                        text = "Time: ${currentTimeMs}ms (${String.format("%.2fs", currentTimeMs / 1000f)})",
                        color = IndigoLight,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newKeyframeValue,
                        onValueChange = { newKeyframeValue = it },
                        label = { Text("Target Value") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = IndigoPrimary,
                            unfocusedBorderColor = GlassBorderSubtle,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Easing Curve:", fontSize = 11.sp, color = TextSecondary)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(vertical = 4.dp)
                    ) {
                        EasingType.values().take(6).forEach { easing ->
                            val isSel = selectedEasing == easing
                            FilterChip(
                                selected = isSel,
                                onClick = { selectedEasing = easing },
                                label = { Text(easing.label, fontSize = 10.sp) },
                                modifier = Modifier.padding(end = 4.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val v = newKeyframeValue.toFloatOrNull() ?: 1.0f
                        viewModel.addKeyframe(
                            trackId = track.id,
                            timeMs = currentTimeMs,
                            value = v,
                            easing = selectedEasing
                        )
                        showAddKeyframeDialog = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = IndigoPrimary,
                        contentColor = Color.White
                    )
                ) {
                    Text("Add Keyframe")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddKeyframeDialog = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun TrackRowItem(
    track: AnimationTrack,
    durationMs: Long,
    currentTimeMs: Long,
    onAddKeyframe: () -> Unit,
    onRemoveTrack: () -> Unit
) {
    Surface(
        color = StudioSurfaceVariantGlass,
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorderSubtle),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
        ) {
            // Track Property Label
            Column(modifier = Modifier.width(100.dp)) {
                Text(
                    text = track.property.displayName,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    maxLines = 1
                )
                Text(
                    text = "${track.keyframes.size} keys",
                    fontSize = 9.sp,
                    color = TextTertiary
                )
            }

            // Keyframe Lane
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(20.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF101014))
                    .border(1.dp, GlassBorderSubtle, RoundedCornerShape(4.dp))
                    .padding(horizontal = 4.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                // Draw keyframe diamonds
                track.keyframes.forEach { key ->
                    val frac = (key.timeMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
                    Box(
                        modifier = Modifier
                            .offset(x = (frac * 140).dp) // visual placement
                            .size(10.dp)
                            .rotate(45f)
                            .background(
                                when (key.easing) {
                                    EasingType.SPRING -> IndigoLight
                                    EasingType.BOUNCE -> NeonEmerald
                                    else -> NeonAmber
                                }
                            )
                    )
                }
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Action: Add Keyframe at Current Time
            IconButton(
                onClick = onAddKeyframe,
                modifier = Modifier.size(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.AddCircleOutline,
                    contentDescription = "Add Keyframe",
                    tint = IndigoLight,
                    modifier = Modifier.size(16.dp)
                )
            }

            // Action: Remove Track
            IconButton(
                onClick = onRemoveTrack,
                modifier = Modifier.size(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Remove Track",
                    tint = TextTertiary,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}
