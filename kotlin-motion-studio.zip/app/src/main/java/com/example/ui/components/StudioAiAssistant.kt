package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.AiMotionResult
import com.example.ui.theme.*
import com.example.viewmodel.StudioViewModel

@Composable
fun StudioAiAssistant(
    viewModel: StudioViewModel,
    promptInput: String,
    isLoading: Boolean,
    history: List<AiMotionResult>,
    onClose: () -> Unit
) {
    val presetPrompts = listOf(
        "Make this hero section feel like a luxury aerospace website.",
        "Make the logo slowly emerge from darkness.",
        "Make the cards float slightly when the mouse moves.",
        "Make this button feel physical with realistic spring bounce.",
        "Create a futuristic data-dashboard entrance.",
        "Make this animation 30% faster.",
        "Reduce motion on mobile devices."
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioBackground)
            .padding(14.dp)
    ) {
        // AI Header
        Surface(
            color = StudioSurfaceGlass,
            shape = RoundedCornerShape(14.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorderAccent),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(IndigoPrimary, CyanNeon)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Gemini Flash 3.7",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "AI Motion Design & Physics Copilot",
                            color = IndigoLight,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Quick Prompt Suggestion Chips
        Text(
            text = "Suggested Motion Prompts:",
            fontSize = 11.sp,
            color = TextSecondary
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(bottom = 8.dp)
        ) {
            presetPrompts.forEach { chipPrompt ->
                SuggestionChip(
                    onClick = {
                        viewModel.updateAiPrompt(chipPrompt)
                        viewModel.sendAiPrompt(chipPrompt)
                    },
                    shape = CircleShape,
                    border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorderSubtle),
                    colors = SuggestionChipDefaults.suggestionChipColors(
                        containerColor = GlassFillSubtle,
                        labelColor = TextPrimary
                    ),
                    label = {
                        Text(chipPrompt, fontSize = 10.sp, maxLines = 1)
                    },
                    modifier = Modifier.padding(end = 6.dp)
                )
            }
        }

        // Prompt Input Field & Submit
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            OutlinedTextField(
                value = promptInput,
                onValueChange = { viewModel.updateAiPrompt(it) },
                placeholder = { Text("Describe motion, physics, or style...", fontSize = 12.sp, color = TextTertiary) },
                singleLine = false,
                maxLines = 2,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = IndigoPrimary,
                    unfocusedBorderColor = GlassBorderSubtle,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedContainerColor = StudioSurfaceVariantGlass,
                    unfocusedContainerColor = StudioSurfaceVariantGlass
                ),
                modifier = Modifier
                    .weight(1f)
                    .testTag("ai_prompt_input")
            )

            Spacer(modifier = Modifier.width(8.dp))

            Button(
                onClick = { viewModel.sendAiPrompt() },
                enabled = promptInput.isNotBlank() && !isLoading,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = IndigoPrimary,
                    contentColor = Color.White
                ),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                modifier = Modifier
                    .height(54.dp)
                    .testTag("ai_send_btn")
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                } else {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Send",
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // AI Generation Output Stream
        Text(
            text = "Synthesized Motion Outputs:",
            fontSize = 11.sp,
            color = TextSecondary
        )
        Spacer(modifier = Modifier.height(6.dp))

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (history.isEmpty()) {
                Surface(
                    color = StudioSurfaceGlass,
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = IndigoLight,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No AI transformations applied yet.",
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Type any natural language prompt above to generate keyframes, spring physics, and Kotlin animation DSL.",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else {
                history.forEach { result ->
                    AiResultCard(result)
                }
            }
        }
    }
}

@Composable
private fun AiResultCard(result: AiMotionResult) {
    Surface(
        color = StudioSurfaceGlass,
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, IndigoPrimary.copy(alpha = 0.35f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(androidx.compose.foundation.shape.CircleShape)
                            .background(NeonEmerald)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = result.suggestedProjectName ?: "Motion Update",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                if (result.suggestedDurationMs != null) {
                    Text(
                        text = "${result.suggestedDurationMs}ms",
                        fontSize = 10.sp,
                        color = IndigoLight,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Explanation
            Text(
                text = result.explanation,
                fontSize = 11.sp,
                color = TextSecondary,
                lineHeight = 15.sp
            )

            // GPU Tip
            if (result.performanceTip != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    color = StudioSurfaceVariantGlass,
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = null,
                            tint = NeonEmerald,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = result.performanceTip,
                            fontSize = 10.sp,
                            color = NeonEmerald
                        )
                    }
                }
            }

            // Code snippet preview
            if (result.kotlinCodeSnippet != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    color = Color(0xFF0C0C10),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = result.kotlinCodeSnippet,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = IndigoLight,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        }
    }
}
