package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.ViewportMode
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.StudioTab
import com.example.viewmodel.StudioViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainStudioScreen(
    viewModel: StudioViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
) {
    val project by viewModel.project.collectAsStateWithLifecycle()
    val currentTimeMs by viewModel.currentTimeMs.collectAsStateWithLifecycle()
    val isPlaying by viewModel.isPlaying.collectAsStateWithLifecycle()
    val playbackSpeed by viewModel.playbackSpeed.collectAsStateWithLifecycle()
    val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()
    val viewportMode by viewModel.viewportMode.collectAsStateWithLifecycle()
    val scrollProgress by viewModel.scrollProgress.collectAsStateWithLifecycle()
    val reducedMotion by viewModel.reducedMotion.collectAsStateWithLifecycle()
    val fpsMetric by viewModel.fpsMetric.collectAsStateWithLifecycle()
    val frameTimeMs by viewModel.frameTimeMs.collectAsStateWithLifecycle()
    val selectedNode by viewModel.selectedNode.collectAsStateWithLifecycle()
    val promptInput by viewModel.aiPromptInput.collectAsStateWithLifecycle()
    val isAiGenerating by viewModel.isAiGenerating.collectAsStateWithLifecycle()
    val aiHistory by viewModel.aiHistory.collectAsStateWithLifecycle()
    val exportTarget by viewModel.currentExportTarget.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()

    var showAiSheet by remember { mutableStateOf(false) }
    var showExportSheet by remember { mutableStateOf(false) }
    var showComponentsSheet by remember { mutableStateOf(false) }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioBackground),
        topBar = {
            StudioTopBar(
                viewModel = viewModel,
                projectName = project.name,
                viewportMode = viewportMode,
                reducedMotion = reducedMotion,
                statusMessage = statusMessage,
                onOpenAiSheet = { showAiSheet = true },
                onOpenExportSheet = { showExportSheet = true }
            )
        },
        bottomBar = {
            StudioBottomNavigationBar(
                activeTab = activeTab,
                onTabSelected = { viewModel.setActiveTab(it) }
            )
        },
        floatingActionButton = {
            if (activeTab == StudioTab.STUDIO_CANVAS) {
                FloatingActionButton(
                    onClick = { showComponentsSheet = true },
                    containerColor = IndigoPrimary,
                    contentColor = Color.White,
                    shape = androidx.compose.foundation.shape.CircleShape,
                    modifier = Modifier.testTag("fab_add_component")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Component"
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(
                    androidx.compose.ui.graphics.Brush.radialGradient(
                        colors = listOf(Color(0xFF1E1A2E), StudioBackground),
                        radius = 1200f
                    )
                )
        ) {
            when (activeTab) {
                StudioTab.STUDIO_CANVAS -> {
                    Column(modifier = Modifier.fillMaxSize()) {
                        Box(modifier = Modifier.weight(1f)) {
                            StudioCanvas(
                                viewModel = viewModel,
                                project = project,
                                currentTimeMs = currentTimeMs,
                                viewportMode = viewportMode,
                                reducedMotion = reducedMotion,
                                scrollProgress = scrollProgress,
                                selectedNodeId = project.selectedNodeId,
                                onOpenInspector = { viewModel.setActiveTab(StudioTab.INSPECTOR_PANEL) }
                            )
                        }

                        // Bottom Timeline strip on Canvas view for unified workflow
                        StudioTimeline(
                            viewModel = viewModel,
                            project = project,
                            currentTimeMs = currentTimeMs,
                            isPlaying = isPlaying,
                            playbackSpeed = playbackSpeed,
                            selectedNode = selectedNode,
                            onOpenInspector = { viewModel.setActiveTab(StudioTab.INSPECTOR_PANEL) }
                        )
                    }
                }

                StudioTab.TIMELINE_EDITOR -> {
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Top canvas mini preview
                        Box(modifier = Modifier.height(200.dp)) {
                            StudioCanvas(
                                viewModel = viewModel,
                                project = project,
                                currentTimeMs = currentTimeMs,
                                viewportMode = ViewportMode.MOBILE,
                                reducedMotion = reducedMotion,
                                scrollProgress = scrollProgress,
                                selectedNodeId = project.selectedNodeId,
                                onOpenInspector = { viewModel.setActiveTab(StudioTab.INSPECTOR_PANEL) }
                            )
                        }

                        Box(modifier = Modifier.weight(1f)) {
                            StudioTimeline(
                                viewModel = viewModel,
                                project = project,
                                currentTimeMs = currentTimeMs,
                                isPlaying = isPlaying,
                                playbackSpeed = playbackSpeed,
                                selectedNode = selectedNode,
                                onOpenInspector = { viewModel.setActiveTab(StudioTab.INSPECTOR_PANEL) }
                            )
                        }
                    }
                }

                StudioTab.INSPECTOR_PANEL -> {
                    StudioInspector(
                        viewModel = viewModel,
                        node = selectedNode,
                        onApplyPreset = { viewModel.applyPresetToSelected(it) }
                    )
                }

                StudioTab.KOTLIN_IDE -> {
                    StudioCodeView(
                        viewModel = viewModel,
                        project = project,
                        currentTarget = exportTarget
                    )
                }

                StudioTab.AI_ASSISTANT -> {
                    StudioAiAssistant(
                        viewModel = viewModel,
                        promptInput = promptInput,
                        isLoading = isAiGenerating,
                        history = aiHistory,
                        onClose = { viewModel.setActiveTab(StudioTab.STUDIO_CANVAS) }
                    )
                }

                StudioTab.PERF_PROFILER -> {
                    StudioPerformanceOverlay(
                        project = project,
                        fps = fpsMetric,
                        frameTimeMs = frameTimeMs,
                        reducedMotion = reducedMotion
                    )
                }
            }
        }
    }

    // Modal AI Sheet
    if (showAiSheet) {
        ModalBottomSheet(
            onDismissRequest = { showAiSheet = false },
            containerColor = StudioSurface,
            scrimColor = Color.Black.copy(alpha = 0.6f)
        ) {
            Box(modifier = Modifier.height(480.dp)) {
                StudioAiAssistant(
                    viewModel = viewModel,
                    promptInput = promptInput,
                    isLoading = isAiGenerating,
                    history = aiHistory,
                    onClose = { showAiSheet = false }
                )
            }
        }
    }

    // Modal Export Sheet
    if (showExportSheet) {
        ModalBottomSheet(
            onDismissRequest = { showExportSheet = false },
            containerColor = StudioSurface,
            scrimColor = Color.Black.copy(alpha = 0.6f)
        ) {
            Box(modifier = Modifier.height(520.dp)) {
                StudioCodeView(
                    viewModel = viewModel,
                    project = project,
                    currentTarget = exportTarget
                )
            }
        }
    }

    // Modal Components Sheet
    if (showComponentsSheet) {
        ModalBottomSheet(
            onDismissRequest = { showComponentsSheet = false },
            containerColor = StudioSurface,
            scrimColor = Color.Black.copy(alpha = 0.6f)
        ) {
            Box(modifier = Modifier.height(440.dp)) {
                StudioAssetsPanel(
                    viewModel = viewModel,
                    project = project,
                    onComponentAdded = { showComponentsSheet = false }
                )
            }
        }
    }
}

@Composable
private fun StudioBottomNavigationBar(
    activeTab: StudioTab,
    onTabSelected: (StudioTab) -> Unit
) {
    Surface(
        color = StudioSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle),
        modifier = Modifier.fillMaxWidth()
    ) {
        NavigationBar(
            containerColor = Color.Transparent,
            tonalElevation = 0.dp,
            modifier = Modifier.height(64.dp)
        ) {
            StudioTab.values().forEach { tab ->
                val isSelected = tab == activeTab
                NavigationBarItem(
                    selected = isSelected,
                    onClick = { onTabSelected(tab) },
                    icon = {
                        Icon(
                            imageVector = when (tab) {
                                StudioTab.STUDIO_CANVAS -> Icons.Default.Palette
                                StudioTab.TIMELINE_EDITOR -> Icons.Default.Timeline
                                StudioTab.INSPECTOR_PANEL -> Icons.Default.Tune
                                StudioTab.KOTLIN_IDE -> Icons.Default.Code
                                StudioTab.AI_ASSISTANT -> Icons.Default.AutoAwesome
                                StudioTab.PERF_PROFILER -> Icons.Default.Speed
                            },
                            contentDescription = tab.label,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    label = {
                        Text(
                            text = tab.label.split(" ").first(),
                            fontSize = 10.sp,
                            maxLines = 1
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = IndigoLight,
                        indicatorColor = IndigoPrimary.copy(alpha = 0.35f),
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextTertiary
                    ),
                    modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                )
            }
        }
    }
}
