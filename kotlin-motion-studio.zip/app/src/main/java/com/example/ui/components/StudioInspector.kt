package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*
import com.example.viewmodel.StudioViewModel

@Composable
fun StudioInspector(
    viewModel: StudioViewModel,
    node: SceneNode?,
    onApplyPreset: (MotionPreset) -> Unit
) {
    if (node == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(StudioBackground)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Select a component from the canvas or scene hierarchy to inspect properties.",
                color = TextSecondary,
                fontSize = 13.sp
            )
        }
        return
    }

    var inspectorTab by remember { mutableStateOf(0) } // 0: Transform/Styles, 1: Physics & Springs, 2: Triggers, 3: Presets

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioBackground)
            .padding(12.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Node Header Info & Type Badge
        Surface(
            color = StudioSurfaceGlass,
            shape = RoundedCornerShape(14.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorderSubtle),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.padding(14.dp)
            ) {
                Column {
                    Text(
                        text = node.name,
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Type: ${node.type.title}",
                        color = IndigoLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Row {
                    IconButton(
                        onClick = { viewModel.duplicateNode(node.id) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Duplicate",
                            tint = TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    IconButton(
                        onClick = { viewModel.deleteNode(node.id) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Delete",
                            tint = NeonRose,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Sub-tabs (Frosted Glass Tab Pill)
        TabRow(
            selectedTabIndex = inspectorTab,
            containerColor = StudioSurfaceVariantGlass,
            contentColor = IndigoLight,
            indicator = {},
            divider = {},
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .border(1.dp, GlassBorderSubtle, RoundedCornerShape(10.dp))
                .padding(3.dp)
        ) {
            listOf("Transform", "Springs", "Triggers", "Presets").forEachIndexed { idx, label ->
                val isSelected = inspectorTab == idx
                Tab(
                    selected = isSelected,
                    onClick = { inspectorTab = idx },
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) IndigoPrimary else Color.Transparent)
                        .padding(vertical = 4.dp),
                    text = {
                        Text(
                            text = label,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) Color.White else TextSecondary
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        when (inspectorTab) {
            0 -> TransformAndStyleSection(node, viewModel)
            1 -> PhysicsSpringSection(node, viewModel)
            2 -> InteractionTriggerSection(node, viewModel)
            3 -> PresetsSection(onApplyPreset)
        }
    }
}

@Composable
private fun TransformAndStyleSection(node: SceneNode, viewModel: StudioViewModel) {
    Column {
        InspectorCard("Transform & Geometry") {
            PropertySliderRow(
                label = "Position X",
                value = node.initialX,
                range = -200f..200f,
                onValueChange = { viewModel.updateNode(node.copy(initialX = it)) }
            )
            PropertySliderRow(
                label = "Position Y",
                value = node.initialY,
                range = -200f..200f,
                onValueChange = { viewModel.updateNode(node.copy(initialY = it)) }
            )
            PropertySliderRow(
                label = "Scale",
                value = node.initialScale,
                range = 0.2f..2.5f,
                onValueChange = { viewModel.updateNode(node.copy(initialScale = it)) }
            )
            PropertySliderRow(
                label = "Rotation (Deg)",
                value = node.initialRotation,
                range = -180f..180f,
                onValueChange = { viewModel.updateNode(node.copy(initialRotation = it)) }
            )
            PropertySliderRow(
                label = "Opacity",
                value = node.initialOpacity,
                range = 0f..1f,
                onValueChange = { viewModel.updateNode(node.copy(initialOpacity = it)) }
            )
            PropertySliderRow(
                label = "Corner Radius",
                value = node.initialCornerRadius,
                range = 0f..40f,
                onValueChange = { viewModel.updateNode(node.copy(initialCornerRadius = it)) }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        InspectorCard("Quick Track Inserter") {
            Text(
                text = "Promote property to Timeline Animation Track:",
                fontSize = 11.sp,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
            ) {
                listOf(
                    PropertyType.POSITION_Y,
                    PropertyType.SCALE,
                    PropertyType.ROTATION,
                    PropertyType.ROTATION_Y,
                    PropertyType.OPACITY,
                    PropertyType.BLUR,
                    PropertyType.CORNER_RADIUS,
                    PropertyType.CONTRAST
                ).forEach { prop ->
                    val alreadyAdded = node.tracks.any { it.property == prop }
                    FilledTonalButton(
                        onClick = { viewModel.addTrackToSelected(prop) },
                        enabled = !alreadyAdded,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .height(28.dp)
                    ) {
                        Text(
                            text = if (alreadyAdded) "✓ ${prop.displayName}" else "+ ${prop.displayName}",
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PhysicsSpringSection(node: SceneNode, viewModel: StudioViewModel) {
    val springTrack = node.tracks.find { it.property == PropertyType.SCALE || it.property == PropertyType.POSITION_Y || it.property == PropertyType.SPRING_BOUNCE }
        ?: node.tracks.firstOrNull()

    var mass by remember(springTrack) { mutableStateOf(springTrack?.springConfig?.mass ?: 1.0f) }
    var stiffness by remember(springTrack) { mutableStateOf(springTrack?.springConfig?.stiffness ?: 140.0f) }
    var damping by remember(springTrack) { mutableStateOf(springTrack?.springConfig?.damping ?: 12.0f) }

    val dampingRatio = damping / (2f * kotlin.math.sqrt(stiffness * mass))

    Column {
        InspectorCard("Spring Physics Engine") {
            Text(
                text = "Simulates second-order differential mass-spring-damper dynamics.",
                fontSize = 11.sp,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Damping status badge
            Surface(
                color = if (dampingRatio < 1f) IndigoPrimary.copy(alpha = 0.15f) else NeonAmber.copy(alpha = 0.15f),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (dampingRatio < 1f) IndigoPrimary.copy(alpha = 0.3f) else NeonAmber.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.padding(8.dp)
                ) {
                    Text(
                        text = if (dampingRatio < 1f) "Underdamped (Bouncy Oscillation)" else "Overdamped (Smooth Decay)",
                        color = if (dampingRatio < 1f) IndigoLight else NeonAmber,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "ζ = ${String.format("%.2f", dampingRatio)}",
                        color = TextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            PropertySliderRow(
                label = "Mass (kg)",
                value = mass,
                range = 0.2f..5.0f,
                onValueChange = {
                    mass = it
                    springTrack?.let { t -> viewModel.updateSpringForTrack(t.id, mass, stiffness, damping) }
                }
            )

            PropertySliderRow(
                label = "Stiffness (N/m)",
                value = stiffness,
                range = 20f..500f,
                onValueChange = {
                    stiffness = it
                    springTrack?.let { t -> viewModel.updateSpringForTrack(t.id, mass, stiffness, damping) }
                }
            )

            PropertySliderRow(
                label = "Damping (Ns/m)",
                value = damping,
                range = 1f..40f,
                onValueChange = {
                    damping = it
                    springTrack?.let { t -> viewModel.updateSpringForTrack(t.id, mass, stiffness, damping) }
                }
            )
        }
    }
}

@Composable
private fun InteractionTriggerSection(node: SceneNode, viewModel: StudioViewModel) {
    Column {
        InspectorCard("Interactive Trigger") {
            Text(
                text = "Define when this motion sequence activates:",
                fontSize = 11.sp,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(8.dp))

            InteractionTrigger.values().forEach { trigger ->
                val isSelected = node.trigger == trigger
                Surface(
                    color = if (isSelected) IndigoPrimary.copy(alpha = 0.15f) else StudioSurfaceVariantGlass,
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) IndigoPrimary else GlassBorderSubtle
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = trigger.label,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) IndigoLight else TextPrimary
                        )

                        RadioButton(
                            selected = isSelected,
                            onClick = { viewModel.updateNode(node.copy(trigger = trigger)) },
                            colors = RadioButtonDefaults.colors(selectedColor = IndigoPrimary)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PresetsSection(onApplyPreset: (MotionPreset) -> Unit) {
    Column {
        InspectorCard("Motion Presets Library") {
            Text(
                text = "Apply production-ready animation presets directly to selected component:",
                fontSize = 11.sp,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(8.dp))

            MotionPreset.values().forEach { preset ->
                Surface(
                    color = StudioSurfaceVariantGlass,
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorderSubtle),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.padding(10.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = preset.presetName,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = preset.description,
                                fontSize = 10.sp,
                                color = TextSecondary,
                                maxLines = 1
                            )
                        }

                        Button(
                            onClick = { onApplyPreset(preset) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = IndigoPrimary,
                                contentColor = Color.White
                            ),
                            shape = CircleShape,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("Apply", fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InspectorCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        color = StudioSurfaceGlass,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorderSubtle),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = title,
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
private fun PropertySliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = label, fontSize = 11.sp, color = TextSecondary)
            Text(
                text = String.format("%.2f", value),
                fontSize = 11.sp,
                color = IndigoLight,
                fontWeight = FontWeight.SemiBold
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = IndigoPrimary,
                activeTrackColor = IndigoLight,
                inactiveTrackColor = StudioSurfaceElevated
            ),
            modifier = Modifier.height(22.dp)
        )
    }
}
