package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*
import com.example.viewmodel.StudioViewModel

@Composable
fun StudioAssetsPanel(
    viewModel: StudioViewModel,
    project: StudioProject,
    onComponentAdded: () -> Unit
) {
    var assetTab by remember { mutableStateOf(0) } // 0: Web Components, 1: Scene Graph Tree

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioBackground)
            .padding(14.dp)
    ) {
        // Tab switcher (Frosted Glass Pill)
        TabRow(
            selectedTabIndex = assetTab,
            containerColor = StudioSurfaceVariantGlass,
            contentColor = IndigoLight,
            indicator = {},
            divider = {},
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .border(1.dp, GlassBorderSubtle, RoundedCornerShape(10.dp))
                .padding(3.dp)
        ) {
            listOf("Web Components", "Scene Graph (${project.nodes.size})").forEachIndexed { idx, label ->
                val isSelected = assetTab == idx
                Tab(
                    selected = isSelected,
                    onClick = { assetTab = idx },
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) IndigoPrimary else Color.Transparent)
                        .padding(vertical = 4.dp),
                    text = {
                        Text(
                            text = label,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) Color.White else TextSecondary
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (assetTab == 0) {
            // Components grid
            Text(
                text = "Add animated web components to your canvas:",
                fontSize = 11.sp,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(8.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(NodeType.values().toList()) { nodeType ->
                    ComponentCardItem(
                        type = nodeType,
                        onAdd = {
                            viewModel.addNode(nodeType)
                            onComponentAdded()
                        }
                    )
                }
            }
        } else {
            // Scene Graph Tree Hierarchy
            Text(
                text = "Hierarchical Scene Graph (Order & Layers):",
                fontSize = 11.sp,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(8.dp))

            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                project.nodes.forEachIndexed { index, node ->
                    val isSelected = node.id == project.selectedNodeId
                    Surface(
                        color = if (isSelected) IndigoPrimary.copy(alpha = 0.15f) else StudioSurfaceGlass,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) IndigoPrimary else GlassBorderSubtle
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.selectNode(node.id) }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "#${index + 1}",
                                    fontSize = 10.sp,
                                    color = TextTertiary,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = node.name,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) IndigoLight else TextPrimary
                                    )
                                    Text(
                                        text = "${node.type.title} • ${node.tracks.size} tracks",
                                        fontSize = 10.sp,
                                        color = TextSecondary
                                    )
                                }
                            }

                            Row {
                                IconButton(
                                    onClick = {
                                        viewModel.updateNode(node.copy(isVisible = !node.isVisible))
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = if (node.isVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = "Toggle Visibility",
                                        tint = if (node.isVisible) IndigoLight else TextTertiary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                IconButton(
                                    onClick = { viewModel.deleteNode(node.id) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DeleteOutline,
                                        contentDescription = "Delete",
                                        tint = NeonRose,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ComponentCardItem(type: NodeType, onAdd: () -> Unit) {
    Surface(
        color = StudioSurfaceGlass,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorderSubtle),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onAdd() }
            .testTag("asset_card_${type.name.lowercase()}")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        when (type) {
                            NodeType.BUTTON -> IndigoPrimary.copy(alpha = 0.2f)
                            NodeType.HERO -> CyanNeon.copy(alpha = 0.2f)
                            NodeType.CHART -> NeonEmerald.copy(alpha = 0.2f)
                            NodeType.NAVBAR -> NeonAmber.copy(alpha = 0.2f)
                            else -> StudioSurfaceVariant
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when (type) {
                        NodeType.BUTTON -> Icons.Default.TouchApp
                        NodeType.HERO -> Icons.Default.RocketLaunch
                        NodeType.NAVBAR -> Icons.Default.Menu
                        NodeType.CARD -> Icons.Default.ViewAgenda
                        NodeType.MODAL -> Icons.Default.CropPortrait
                        NodeType.CHART -> Icons.Default.BarChart
                        NodeType.COUNTER -> Icons.Default.Speed
                        NodeType.LOGO -> Icons.Default.AutoAwesome
                        else -> Icons.Default.Widgets
                    },
                    contentDescription = null,
                    tint = when (type) {
                        NodeType.BUTTON -> IndigoLight
                        NodeType.HERO -> CyanNeon
                        NodeType.CHART -> NeonEmerald
                        NodeType.NAVBAR -> NeonAmber
                        else -> IndigoLight
                    },
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = type.title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                maxLines = 1
            )
            Text(
                text = "Animated Component",
                fontSize = 9.sp,
                color = TextSecondary
            )
        }
    }
}
