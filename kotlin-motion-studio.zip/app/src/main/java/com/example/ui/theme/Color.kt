package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Frosted Glass Theme Palette (Deep Obsidian + Frosted Glass Layers)
val StudioBackground = Color(0xFF0F0F12)
val StudioSurface = Color(0xFF1A1A1E)
val StudioSurfaceGlass = Color(0xD91A1A1E) // 85% alpha frosted glass
val StudioSurfaceVariant = Color(0xFF252529)
val StudioSurfaceVariantGlass = Color(0xE6252529) // 90% alpha frosted card
val StudioSurfaceElevated = Color(0xFF2E2E34)

// Glass Borders & Shimmer Accents
val GlassBorderSubtle = Color(0x1FFFFFFF) // white/12
val GlassBorderHighlight = Color(0x33FFFFFF) // white/20
val GlassBorderAccent = Color(0x666366F1) // indigo/40
val GlassFillSubtle = Color(0x0DFFFFFF) // white/5
val GlassFillActive = Color(0x1F6366F1) // indigo/12

// Frosted Indigo Primary & Vibrant Accents
val IndigoPrimary = Color(0xFF6366F1)
val IndigoPrimaryDark = Color(0xFF4F46E5)
val IndigoLight = Color(0xFF818CF8)
val CyanNeon = Color(0xFF38BDF8)
val CyanBright = Color(0xFF06B6D4)
val ElectricViolet = Color(0xFF6366F1)
val ElectricVioletLight = Color(0xFF818CF8)
val NeonEmerald = Color(0xFF34D399)
val NeonAmber = Color(0xFFFBBF24)
val NeonRose = Color(0xFFFB7185)

// Typography & Neutrals
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)
val BorderSubtle = Color(0x1FFFFFFF)
val BorderAccent = Color(0x4D6366F1)

