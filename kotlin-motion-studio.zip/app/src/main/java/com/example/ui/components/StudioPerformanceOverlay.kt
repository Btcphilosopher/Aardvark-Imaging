package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.StudioProject
import com.example.ui.theme.*

@Composable
fun StudioPerformanceOverlay(
    project: StudioProject,
    fps: Int,
    frameTimeMs: Float,
    reducedMotion: Boolean
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioBackground)
            .padding(14.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Main FPS & Latency Metrics
        Surface(
            color = StudioSurfaceGlass,
            shape = RoundedCornerShape(14.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorderSubtle),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Real-Time Motion Profiler",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    Surface(
                        color = NeonEmerald.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NeonEmerald.copy(alpha = 0.3f))
                    ) {
                        Text(
                            text = "60 / 120 FPS Target",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeonEmerald,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    MetricBox(
                        title = "FPS Rate",
                        value = "$fps FPS",
                        subtitle = if (fps >= 60) "Fluid • Zero Jitter" else "Sub-60 FPS",
                        color = if (fps >= 58) NeonEmerald else NeonAmber,
                        modifier = Modifier.weight(1f)
                    )

                    MetricBox(
                        title = "Frame Time",
                        value = "${frameTimeMs}ms",
                        subtitle = "Budget: 8.33ms (120Hz)",
                        color = if (frameTimeMs <= 8.33f) IndigoLight else NeonAmber,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Compositor & GPU Pipeline Status
        Surface(
            color = StudioSurfaceGlass,
            shape = RoundedCornerShape(14.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorderSubtle),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Hardware Pipeline & Compositor",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(10.dp))

                ChecklistItem("GPU Transform3D Accelerated", true)
                ChecklistItem("Off-Thread Compositor Active", true)
                ChecklistItem("Zero Layout / Reflow Recalculations", true)
                ChecklistItem("Display List Recomposition Caching", true)
                ChecklistItem("Sub-pixel Anti-aliasing Enabled", true)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Accessibility & WCAG Audit
        Surface(
            color = StudioSurfaceGlass,
            shape = RoundedCornerShape(14.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorderSubtle),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Accessibility & WCAG Motion Audit",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(10.dp))

                ChecklistItem(
                    "prefers-reduced-motion CSS Query",
                    true,
                    if (reducedMotion) "Active (Static fallback)" else "Available"
                )
                ChecklistItem("Zero Vestibular Motion Hazard (< 3 flashes/s)", true)
                ChecklistItem("Screen Reader Semantic Content Descriptions", true)
                ChecklistItem("Keyboard Navigable Timecodes", true)
            }
        }
    }
}

@Composable
private fun MetricBox(
    title: String,
    value: String,
    subtitle: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = StudioSurfaceVariantGlass,
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorderSubtle),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = title, fontSize = 10.sp, color = TextSecondary)
            Spacer(modifier = Modifier.height(3.dp))
            Text(text = value, fontSize = 16.sp, fontWeight = FontWeight.Black, color = color)
            Spacer(modifier = Modifier.height(3.dp))
            Text(text = subtitle, fontSize = 9.sp, color = TextTertiary)
        }
    }
}

@Composable
private fun ChecklistItem(title: String, passed: Boolean, extra: String? = null) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(18.dp)
                    .clip(CircleShape)
                    .background(if (passed) NeonEmerald.copy(alpha = 0.15f) else NeonRose.copy(alpha = 0.15f))
                    .border(1.dp, if (passed) NeonEmerald.copy(alpha = 0.3f) else NeonRose.copy(alpha = 0.3f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (passed) Icons.Default.Check else Icons.Default.Close,
                    contentDescription = null,
                    tint = if (passed) NeonEmerald else NeonRose,
                    modifier = Modifier.size(11.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text(text = title, fontSize = 11.sp, color = TextPrimary)
        }

        if (extra != null) {
            Text(text = extra, fontSize = 10.sp, color = IndigoLight)
        }
    }
}
