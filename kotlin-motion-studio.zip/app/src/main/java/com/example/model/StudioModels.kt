package com.example.model

enum class PropertyType(val displayName: String, val category: String) {
    POSITION_X("Position X", "Transform"),
    POSITION_Y("Position Y", "Transform"),
    POSITION_Z("Position Z (Depth)", "Transform"),
    SCALE("Scale", "Transform"),
    SCALE_X("Scale X", "Transform"),
    SCALE_Y("Scale Y", "Transform"),
    ROTATION("Rotation", "Transform"),
    ROTATION_Y("3D Tilt Y", "Transform"),
    OPACITY("Opacity", "Style"),
    WIDTH("Width", "Layout"),
    HEIGHT("Height", "Layout"),
    CORNER_RADIUS("Corner Radius", "Style"),
    BLUR("Blur", "Filter"),
    BRIGHTNESS("Brightness", "Filter"),
    CONTRAST("Contrast", "Filter"),
    SATURATION("Saturation", "Filter"),
    BACKGROUND_COLOR("Background Color", "Style"),
    TEXT_COLOR("Text Color", "Style"),
    SHADOW_ELEVATION("Shadow Elevation", "Style"),
    SPRING_BOUNCE("Spring Bounce", "Physics")
}

enum class EasingType(val label: String, val formulaDesc: String) {
    LINEAR("Linear", "t"),
    EASE_IN("Ease In", "t * t"),
    EASE_OUT("Ease Out", "1 - (1-t)*(1-t)"),
    EASE_IN_OUT("Ease In-Out", "Cubic smoothstep"),
    CUBIC_BEZIER("Cubic Bezier", "Cubic (0.25, 0.1, 0.25, 1.0)"),
    SPRING("Spring Physics", "Damped harmonic oscillator"),
    ELASTIC("Elastic", "Oscillating exponential decay"),
    BOUNCE("Bounce", "Simulated gravity rebound"),
    CUSTOM("Custom Curve", "Custom user bezier control points")
}

data class Keyframe(
    val id: String = java.util.UUID.randomUUID().toString(),
    val timeMs: Long,
    val value: Float,
    val colorValue: Long? = null,
    val easing: EasingType = EasingType.EASE_OUT,
    val bezierControlP1: Pair<Float, Float> = Pair(0.25f, 0.1f),
    val bezierControlP2: Pair<Float, Float> = Pair(0.25f, 1.0f)
)

data class SpringConfig(
    val mass: Float = 1.0f,
    val stiffness: Float = 100.0f,
    val damping: Float = 10.0f,
    val initialVelocity: Float = 0.0f
) {
    val dampingRatio: Float get() = damping / (2f * kotlin.math.sqrt(stiffness * mass))
    val isOverdamped: Boolean get() = dampingRatio > 1.0f
    val isUnderdamped: Boolean get() = dampingRatio < 1.0f
}

data class AnimationTrack(
    val id: String = java.util.UUID.randomUUID().toString(),
    val property: PropertyType,
    val keyframes: List<Keyframe> = emptyList(),
    val springConfig: SpringConfig = SpringConfig(),
    val isEnabled: Boolean = true,
    val isExpanded: Boolean = false
)

enum class InteractionTrigger(val label: String, val iconName: String) {
    ON_LOAD("On Load", "play_arrow"),
    ON_HOVER("On Hover", "pan_tool"),
    ON_CLICK("On Click", "touch_app"),
    ON_PRESS("On Press", "touch_app"),
    ON_SCROLL("On Scroll", "unfold_more"),
    ON_VIEWPORT_ENTER("On Viewport Enter", "visibility"),
    ON_DRAG("On Drag", "open_with")
}

data class ScrollTriggerConfig(
    val startScrollPct: Float = 0.0f,
    val endScrollPct: Float = 1.0f,
    val parallaxFactor: Float = 0.5f,
    val fadeOnExit: Boolean = true,
    val scaleOnScroll: Boolean = true
)

enum class NodeType(val title: String) {
    HERO("Hero Section"),
    TITLE("Headline Text"),
    SUBTITLE("Subtitle Text"),
    BUTTON("Action Button"),
    CARD("Feature Card"),
    NAVBAR("Navigation Bar"),
    IMAGE("Visual Asset"),
    CHART("Data Visualizer"),
    COUNTER("Animated Counter"),
    BADGE("Pill Badge"),
    MODAL("Dialog Modal"),
    BACKGROUND("Dynamic Background"),
    LOGO("Brand Logo")
}

data class SceneNode(
    val id: String = java.util.UUID.randomUUID().toString(),
    val name: String,
    val type: NodeType,
    val text: String = "",
    val subtitle: String = "",
    val icon: String = "",
    val initialX: Float = 0f,
    val initialY: Float = 0f,
    val initialZ: Float = 0f,
    val initialWidth: Float = 280f,
    val initialHeight: Float = 160f,
    val initialScale: Float = 1.0f,
    val initialRotation: Float = 0.0f,
    val initialRotationY: Float = 0.0f,
    val initialOpacity: Float = 1.0f,
    val initialCornerRadius: Float = 16f,
    val initialBlur: Float = 0f,
    val initialBrightness: Float = 1.0f,
    val initialContrast: Float = 1.0f,
    val initialSaturation: Float = 1.0f,
    val backgroundColor: Long = 0xFF1E293BL,
    val gradientEndColor: Long = 0xFF0F172AL,
    val textColor: Long = 0xFFF8FAFCL,
    val accentColor: Long = 0xFF06B6D4L,
    val shadowElevation: Float = 4f,
    val tracks: List<AnimationTrack> = emptyList(),
    val trigger: InteractionTrigger = InteractionTrigger.ON_LOAD,
    val scrollConfig: ScrollTriggerConfig = ScrollTriggerConfig(),
    val isVisible: Boolean = true,
    val isLocked: Boolean = false,
    val parentId: String? = null,
    val childrenIds: List<String> = emptyList()
)

enum class ViewportMode(val title: String, val widthDp: Int, val heightDp: Int) {
    DESKTOP("Desktop (1440)", 400, 260),
    TABLET("Tablet (768)", 320, 240),
    MOBILE("Mobile (375)", 240, 320)
}

enum class MotionPreset(
    val presetName: String,
    val description: String,
    val category: String
) {
    FADE_IN_UP("Fade & Rise", "Gentle entrance with opacity and upward lift", "Entrance"),
    SPRING_POP("Spring Pop", "Physics-based bouncy scale-in with high damping", "Physics"),
    KINETIC_3D("Kinetic 3D Tilt", "Rotates along Y-axis with perspective depth", "3D"),
    GLASS_BLUR_REVEAL("Glass Blur Reveal", "Smooth transition from 20px blur to crystal clear", "Aesthetic"),
    PARALLAX_FLOAT("Parallax Float", "Continuous elegant hovering motion", "Ambient"),
    MAGNETIC_HOVER("Magnetic Snap", "Snaps toward interaction point with spring stiffness", "Interactive"),
    LIQUID_PULSE("Liquid Pulse", "Organic breathing scale with corner radius morphing", "Organic"),
    GLITCH_SHIFT("Cyber Glitch", "High-frequency micro-displacements with contrast spikes", "FX"),
    CINEMATIC_REVEAL("Cinematic Emerge", "Slow-motion dark-to-light luxury reveal", "Cinematic"),
    BOUNCE_DROP("Gravity Rebound", "Realistic bouncing drop onto ground plane", "Physics"),
    NAVBAR_SLIDE("Navbar Elastic Slide", "Fluid slide-down from top with overshoot", "UI Component"),
    CARD_FLIP("Card 3D Flip", "Full 180-degree interactive card flip", "3D")
}

data class StudioProject(
    val id: String = java.util.UUID.randomUUID().toString(),
    val name: String = "Untitled Animation",
    val durationMs: Long = 3000L,
    val fps: Int = 60,
    val isLooping: Boolean = true,
    val nodes: List<SceneNode> = emptyList(),
    val selectedNodeId: String? = null,
    val viewport: ViewportMode = ViewportMode.DESKTOP,
    val reducedMotionMode: Boolean = false,
    val playbackSpeed: Float = 1.0f
)
