package com.example.model

object PresetsLibrary {

    fun createDefaultProject(): StudioProject {
        val navbar = SceneNode(
            id = "node_navbar",
            name = "AnimatedNavbar",
            type = NodeType.NAVBAR,
            text = "AEROKOTLIN // MOTION STUDIO",
            subtitle = "v3.7 Studio",
            icon = "token",
            initialX = 0f,
            initialY = -90f,
            initialWidth = 360f,
            initialHeight = 44f,
            backgroundColor = 0xCC0F172AL,
            gradientEndColor = 0xCC1E293BL,
            textColor = 0xFF38BDF8L,
            accentColor = 0xFF818CF8L,
            initialCornerRadius = 22f,
            shadowElevation = 8f,
            tracks = listOf(
                AnimationTrack(
                    property = PropertyType.POSITION_Y,
                    keyframes = listOf(
                        Keyframe(timeMs = 0L, value = -140f, easing = EasingType.SPRING),
                        Keyframe(timeMs = 900L, value = -90f, easing = EasingType.SPRING)
                    ),
                    springConfig = SpringConfig(mass = 1.0f, stiffness = 120f, damping = 14f)
                ),
                AnimationTrack(
                    property = PropertyType.OPACITY,
                    keyframes = listOf(
                        Keyframe(timeMs = 0L, value = 0.0f, easing = EasingType.EASE_OUT),
                        Keyframe(timeMs = 600L, value = 1.0f, easing = EasingType.EASE_OUT)
                    )
                )
            )
        )

        val logo = SceneNode(
            id = "node_logo",
            name = "AnimatedLogo",
            type = NodeType.LOGO,
            text = "KOTLIN MOTION",
            subtitle = "Hyper-fast Reactive Web Engine",
            icon = "auto_awesome",
            initialX = 0f,
            initialY = -35f,
            initialWidth = 260f,
            initialHeight = 48f,
            backgroundColor = 0x2238BDF8L,
            gradientEndColor = 0x44818CF8L,
            textColor = 0xFFF1F5F9L,
            accentColor = 0xFF38BDF8L,
            initialCornerRadius = 12f,
            initialScale = 1.0f,
            tracks = listOf(
                AnimationTrack(
                    property = PropertyType.SCALE,
                    keyframes = listOf(
                        Keyframe(timeMs = 200L, value = 0.6f, easing = EasingType.SPRING),
                        Keyframe(timeMs = 1200L, value = 1.0f, easing = EasingType.SPRING)
                    ),
                    springConfig = SpringConfig(mass = 1.0f, stiffness = 150f, damping = 11f)
                ),
                AnimationTrack(
                    property = PropertyType.ROTATION_Y,
                    keyframes = listOf(
                        Keyframe(timeMs = 200L, value = -30f, easing = EasingType.EASE_OUT),
                        Keyframe(timeMs = 1400L, value = 0f, easing = EasingType.EASE_OUT)
                    )
                )
            )
        )

        val hero = SceneNode(
            id = "node_hero",
            name = "AnimatedHeroCard",
            type = NodeType.HERO,
            text = "Next-Gen Web Motion",
            subtitle = "120 FPS Kotlin WebAssembly Engine",
            icon = "rocket_launch",
            initialX = 0f,
            initialY = 30f,
            initialWidth = 320f,
            initialHeight = 72f,
            backgroundColor = 0xFF1E1B4BL,
            gradientEndColor = 0xFF311042L,
            textColor = 0xFFFFFFFFL,
            accentColor = 0xFF06B6D4L,
            initialCornerRadius = 16f,
            shadowElevation = 12f,
            tracks = listOf(
                AnimationTrack(
                    property = PropertyType.POSITION_Y,
                    keyframes = listOf(
                        Keyframe(timeMs = 400L, value = 80f, easing = EasingType.EASE_OUT),
                        Keyframe(timeMs = 1500L, value = 30f, easing = EasingType.SPRING)
                    ),
                    springConfig = SpringConfig(mass = 1.2f, stiffness = 90f, damping = 10f)
                ),
                AnimationTrack(
                    property = PropertyType.OPACITY,
                    keyframes = listOf(
                        Keyframe(timeMs = 400L, value = 0.0f, easing = EasingType.EASE_OUT),
                        Keyframe(timeMs = 1100L, value = 1.0f, easing = EasingType.EASE_OUT)
                    )
                )
            )
        )

        val button = SceneNode(
            id = "node_button",
            name = "SpringButton",
            type = NodeType.BUTTON,
            text = "LAUNCH EXPERIENCE",
            subtitle = "Physics Interaction",
            icon = "flash_on",
            initialX = 0f,
            initialY = 95f,
            initialWidth = 200f,
            initialHeight = 44f,
            backgroundColor = 0xFF06B6D4L,
            gradientEndColor = 0xFF3B82F6L,
            textColor = 0xFF0F172AL,
            accentColor = 0xFFF0FDF4L,
            initialCornerRadius = 22f,
            shadowElevation = 6f,
            trigger = InteractionTrigger.ON_CLICK,
            tracks = listOf(
                AnimationTrack(
                    property = PropertyType.SCALE,
                    keyframes = listOf(
                        Keyframe(timeMs = 700L, value = 0.8f, easing = EasingType.SPRING),
                        Keyframe(timeMs = 1600L, value = 1.0f, easing = EasingType.SPRING),
                        Keyframe(timeMs = 2400L, value = 1.05f, easing = EasingType.EASE_IN_OUT),
                        Keyframe(timeMs = 3000L, value = 1.0f, easing = EasingType.SPRING)
                    ),
                    springConfig = SpringConfig(mass = 0.8f, stiffness = 200f, damping = 12f)
                )
            )
        )

        val chart = SceneNode(
            id = "node_chart",
            name = "AnimatedChart",
            type = NodeType.CHART,
            text = "Telemetry: 120 FPS",
            subtitle = "Zero dropped frames • 0.8ms latency",
            icon = "insights",
            initialX = 0f,
            initialY = 155f,
            initialWidth = 300f,
            initialHeight = 56f,
            backgroundColor = 0xFF090D16L,
            gradientEndColor = 0xFF1E293BL,
            textColor = 0xFF34D399L,
            accentColor = 0xFF10B981L,
            initialCornerRadius = 12f,
            shadowElevation = 4f,
            tracks = listOf(
                AnimationTrack(
                    property = PropertyType.OPACITY,
                    keyframes = listOf(
                        Keyframe(timeMs = 900L, value = 0.0f, easing = EasingType.EASE_OUT),
                        Keyframe(timeMs = 1800L, value = 1.0f, easing = EasingType.EASE_OUT)
                    )
                )
            )
        )

        return StudioProject(
            id = "proj_aerospace",
            name = "Aerospace Web Experience",
            durationMs = 3000L,
            nodes = listOf(navbar, logo, hero, button, chart),
            selectedNodeId = hero.id
        )
    }

    fun applyPresetToNode(node: SceneNode, preset: MotionPreset): SceneNode {
        val newTracks = when (preset) {
            MotionPreset.FADE_IN_UP -> listOf(
                AnimationTrack(
                    property = PropertyType.POSITION_Y,
                    keyframes = listOf(
                        Keyframe(timeMs = 0L, value = node.initialY + 60f, easing = EasingType.EASE_OUT),
                        Keyframe(timeMs = 800L, value = node.initialY, easing = EasingType.EASE_OUT)
                    )
                ),
                AnimationTrack(
                    property = PropertyType.OPACITY,
                    keyframes = listOf(
                        Keyframe(timeMs = 0L, value = 0f, easing = EasingType.EASE_OUT),
                        Keyframe(timeMs = 600L, value = 1f, easing = EasingType.EASE_OUT)
                    )
                )
            )
            MotionPreset.SPRING_POP -> listOf(
                AnimationTrack(
                    property = PropertyType.SCALE,
                    keyframes = listOf(
                        Keyframe(timeMs = 0L, value = 0.2f, easing = EasingType.SPRING),
                        Keyframe(timeMs = 900L, value = 1.0f, easing = EasingType.SPRING)
                    ),
                    springConfig = SpringConfig(mass = 1.0f, stiffness = 160f, damping = 12f)
                ),
                AnimationTrack(
                    property = PropertyType.OPACITY,
                    keyframes = listOf(
                        Keyframe(timeMs = 0L, value = 0f, easing = EasingType.EASE_OUT),
                        Keyframe(timeMs = 300L, value = 1f, easing = EasingType.EASE_OUT)
                    )
                )
            )
            MotionPreset.KINETIC_3D -> listOf(
                AnimationTrack(
                    property = PropertyType.ROTATION_Y,
                    keyframes = listOf(
                        Keyframe(timeMs = 0L, value = -60f, easing = EasingType.EASE_OUT),
                        Keyframe(timeMs = 1200L, value = 0f, easing = EasingType.SPRING)
                    ),
                    springConfig = SpringConfig(mass = 1.2f, stiffness = 110f, damping = 14f)
                ),
                AnimationTrack(
                    property = PropertyType.POSITION_Z,
                    keyframes = listOf(
                        Keyframe(timeMs = 0L, value = -100f, easing = EasingType.EASE_OUT),
                        Keyframe(timeMs = 1200L, value = 0f, easing = EasingType.EASE_OUT)
                    )
                )
            )
            MotionPreset.GLASS_BLUR_REVEAL -> listOf(
                AnimationTrack(
                    property = PropertyType.BLUR,
                    keyframes = listOf(
                        Keyframe(timeMs = 0L, value = 24f, easing = EasingType.EASE_OUT),
                        Keyframe(timeMs = 1000L, value = 0f, easing = EasingType.EASE_OUT)
                    )
                ),
                AnimationTrack(
                    property = PropertyType.OPACITY,
                    keyframes = listOf(
                        Keyframe(timeMs = 0L, value = 0.2f, easing = EasingType.EASE_OUT),
                        Keyframe(timeMs = 800L, value = 1.0f, easing = EasingType.EASE_OUT)
                    )
                )
            )
            MotionPreset.PARALLAX_FLOAT -> listOf(
                AnimationTrack(
                    property = PropertyType.POSITION_Y,
                    keyframes = listOf(
                        Keyframe(timeMs = 0L, value = node.initialY - 12f, easing = EasingType.EASE_IN_OUT),
                        Keyframe(timeMs = 1500L, value = node.initialY + 12f, easing = EasingType.EASE_IN_OUT),
                        Keyframe(timeMs = 3000L, value = node.initialY - 12f, easing = EasingType.EASE_IN_OUT)
                    )
                ),
                AnimationTrack(
                    property = PropertyType.ROTATION,
                    keyframes = listOf(
                        Keyframe(timeMs = 0L, value = -2f, easing = EasingType.EASE_IN_OUT),
                        Keyframe(timeMs = 1500L, value = 2f, easing = EasingType.EASE_IN_OUT),
                        Keyframe(timeMs = 3000L, value = -2f, easing = EasingType.EASE_IN_OUT)
                    )
                )
            )
            MotionPreset.MAGNETIC_HOVER -> listOf(
                AnimationTrack(
                    property = PropertyType.SCALE,
                    keyframes = listOf(
                        Keyframe(timeMs = 0L, value = 1.0f, easing = EasingType.SPRING),
                        Keyframe(timeMs = 400L, value = 1.08f, easing = EasingType.SPRING),
                        Keyframe(timeMs = 1000L, value = 1.0f, easing = EasingType.SPRING)
                    ),
                    springConfig = SpringConfig(mass = 0.6f, stiffness = 220f, damping = 15f)
                ),
                AnimationTrack(
                    property = PropertyType.SHADOW_ELEVATION,
                    keyframes = listOf(
                        Keyframe(timeMs = 0L, value = 4f, easing = EasingType.EASE_OUT),
                        Keyframe(timeMs = 400L, value = 18f, easing = EasingType.EASE_OUT),
                        Keyframe(timeMs = 1000L, value = 4f, easing = EasingType.EASE_OUT)
                    )
                )
            )
            MotionPreset.LIQUID_PULSE -> listOf(
                AnimationTrack(
                    property = PropertyType.CORNER_RADIUS,
                    keyframes = listOf(
                        Keyframe(timeMs = 0L, value = 12f, easing = EasingType.EASE_IN_OUT),
                        Keyframe(timeMs = 1500L, value = 32f, easing = EasingType.EASE_IN_OUT),
                        Keyframe(timeMs = 3000L, value = 12f, easing = EasingType.EASE_IN_OUT)
                    )
                ),
                AnimationTrack(
                    property = PropertyType.SCALE,
                    keyframes = listOf(
                        Keyframe(timeMs = 0L, value = 0.98f, easing = EasingType.EASE_IN_OUT),
                        Keyframe(timeMs = 1500L, value = 1.04f, easing = EasingType.EASE_IN_OUT),
                        Keyframe(timeMs = 3000L, value = 0.98f, easing = EasingType.EASE_IN_OUT)
                    )
                )
            )
            MotionPreset.GLITCH_SHIFT -> listOf(
                AnimationTrack(
                    property = PropertyType.POSITION_X,
                    keyframes = listOf(
                        Keyframe(timeMs = 0L, value = 0f, easing = EasingType.LINEAR),
                        Keyframe(timeMs = 400L, value = -6f, easing = EasingType.LINEAR),
                        Keyframe(timeMs = 450L, value = 8f, easing = EasingType.LINEAR),
                        Keyframe(timeMs = 500L, value = -4f, easing = EasingType.LINEAR),
                        Keyframe(timeMs = 600L, value = 0f, easing = EasingType.LINEAR)
                    )
                ),
                AnimationTrack(
                    property = PropertyType.CONTRAST,
                    keyframes = listOf(
                        Keyframe(timeMs = 0L, value = 1.0f, easing = EasingType.LINEAR),
                        Keyframe(timeMs = 450L, value = 1.8f, easing = EasingType.LINEAR),
                        Keyframe(timeMs = 600L, value = 1.0f, easing = EasingType.LINEAR)
                    )
                )
            )
            MotionPreset.CINEMATIC_REVEAL -> listOf(
                AnimationTrack(
                    property = PropertyType.BRIGHTNESS,
                    keyframes = listOf(
                        Keyframe(timeMs = 0L, value = 0.1f, easing = EasingType.EASE_IN_OUT),
                        Keyframe(timeMs = 2000L, value = 1.0f, easing = EasingType.EASE_IN_OUT)
                    )
                ),
                AnimationTrack(
                    property = PropertyType.POSITION_Y,
                    keyframes = listOf(
                        Keyframe(timeMs = 0L, value = node.initialY + 40f, easing = EasingType.EASE_OUT),
                        Keyframe(timeMs = 2200L, value = node.initialY, easing = EasingType.EASE_OUT)
                    )
                ),
                AnimationTrack(
                    property = PropertyType.SCALE,
                    keyframes = listOf(
                        Keyframe(timeMs = 0L, value = 0.92f, easing = EasingType.EASE_OUT),
                        Keyframe(timeMs = 2200L, value = 1.0f, easing = EasingType.EASE_OUT)
                    )
                )
            )
            MotionPreset.BOUNCE_DROP -> listOf(
                AnimationTrack(
                    property = PropertyType.POSITION_Y,
                    keyframes = listOf(
                        Keyframe(timeMs = 0L, value = node.initialY - 180f, easing = EasingType.BOUNCE),
                        Keyframe(timeMs = 1200L, value = node.initialY, easing = EasingType.BOUNCE)
                    )
                )
            )
            MotionPreset.NAVBAR_SLIDE -> listOf(
                AnimationTrack(
                    property = PropertyType.POSITION_Y,
                    keyframes = listOf(
                        Keyframe(timeMs = 0L, value = -150f, easing = EasingType.SPRING),
                        Keyframe(timeMs = 800L, value = node.initialY, easing = EasingType.SPRING)
                    ),
                    springConfig = SpringConfig(mass = 1.0f, stiffness = 140f, damping = 13f)
                )
            )
            MotionPreset.CARD_FLIP -> listOf(
                AnimationTrack(
                    property = PropertyType.ROTATION_Y,
                    keyframes = listOf(
                        Keyframe(timeMs = 0L, value = 0f, easing = EasingType.EASE_IN_OUT),
                        Keyframe(timeMs = 1200L, value = 180f, easing = EasingType.EASE_IN_OUT)
                    )
                )
            )
        }
        return node.copy(tracks = newTracks)
    }

    fun createComponentNode(type: NodeType): SceneNode {
        return when (type) {
            NodeType.BUTTON -> SceneNode(
                name = "AnimatedButton",
                type = NodeType.BUTTON,
                text = "INTERACTIVE ACTION",
                subtitle = "Spring Touch Response",
                icon = "touch_app",
                initialWidth = 220f,
                initialHeight = 46f,
                backgroundColor = 0xFF8B5CF6L,
                gradientEndColor = 0xFF6366F1L,
                textColor = 0xFFFFFFFFL,
                accentColor = 0xFFC4B5FDL,
                initialCornerRadius = 23f,
                shadowElevation = 6f
            ).let { applyPresetToNode(it, MotionPreset.SPRING_POP) }

            NodeType.CARD -> SceneNode(
                name = "AnimatedCard",
                type = NodeType.CARD,
                text = "Intelligence Layer",
                subtitle = "Reactive state bindings and physics engine",
                icon = "hub",
                initialWidth = 280f,
                initialHeight = 110f,
                backgroundColor = 0xFF1E293BL,
                gradientEndColor = 0xFF0F172AL,
                textColor = 0xFFF8FAFCL,
                accentColor = 0xFF38BDF8L,
                initialCornerRadius = 18f,
                shadowElevation = 10f
            ).let { applyPresetToNode(it, MotionPreset.FADE_IN_UP) }

            NodeType.HERO -> SceneNode(
                name = "AnimatedHero",
                type = NodeType.HERO,
                text = "AeroSpace UI Platform",
                subtitle = "Architecting the future of motion on web",
                icon = "rocket",
                initialWidth = 330f,
                initialHeight = 90f,
                backgroundColor = 0xFF18181BL,
                gradientEndColor = 0xFF27272AL,
                textColor = 0xFFFFFFFFL,
                accentColor = 0xFFF59E0BL,
                initialCornerRadius = 20f,
                shadowElevation = 12f
            ).let { applyPresetToNode(it, MotionPreset.CINEMATIC_REVEAL) }

            NodeType.NAVBAR -> SceneNode(
                name = "AnimatedNavbar",
                type = NodeType.NAVBAR,
                text = "STUDIO // MENU",
                subtitle = "Overview • Features • Code",
                icon = "menu",
                initialWidth = 340f,
                initialHeight = 42f,
                backgroundColor = 0xEE090D16L,
                gradientEndColor = 0xEE1E293BL,
                textColor = 0xFFE2E8F0L,
                accentColor = 0xFF06B6D4L,
                initialCornerRadius = 21f,
                shadowElevation = 6f
            ).let { applyPresetToNode(it, MotionPreset.NAVBAR_SLIDE) }

            NodeType.MODAL -> SceneNode(
                name = "AnimatedModal",
                type = NodeType.MODAL,
                text = "Deploy Web Animation",
                subtitle = "Compile to Kotlin/Wasm with 60 FPS guarantee",
                icon = "cloud_upload",
                initialWidth = 270f,
                initialHeight = 120f,
                backgroundColor = 0xFF0F172AL,
                gradientEndColor = 0xFF1E1B4BL,
                textColor = 0xFFFFFFFFL,
                accentColor = 0xFF10B981L,
                initialCornerRadius = 16f,
                shadowElevation = 16f
            ).let { applyPresetToNode(it, MotionPreset.GLASS_BLUR_REVEAL) }

            NodeType.COUNTER -> SceneNode(
                name = "AnimatedCounter",
                type = NodeType.COUNTER,
                text = "99.98% SPEED",
                subtitle = "Real-time frame delivery rate",
                icon = "speed",
                initialWidth = 230f,
                initialHeight = 60f,
                backgroundColor = 0xFF172554L,
                gradientEndColor = 0xFF1E3A8AL,
                textColor = 0xFF67E8F9L,
                accentColor = 0xFF38BDF8L,
                initialCornerRadius = 14f,
                shadowElevation = 4f
            ).let { applyPresetToNode(it, MotionPreset.PARALLAX_FLOAT) }

            NodeType.CHART -> SceneNode(
                name = "AnimatedChart",
                type = NodeType.CHART,
                text = "Performance Metric",
                subtitle = "Latency: 0.8ms • Zero Jitter",
                icon = "bar_chart",
                initialWidth = 290f,
                initialHeight = 70f,
                backgroundColor = 0xFF0F172AL,
                gradientEndColor = 0xFF022C22L,
                textColor = 0xFF34D399L,
                accentColor = 0xFF10B981L,
                initialCornerRadius = 16f,
                shadowElevation = 6f
            ).let { applyPresetToNode(it, MotionPreset.FADE_IN_UP) }

            NodeType.LOGO -> SceneNode(
                name = "AnimatedLogo",
                type = NodeType.LOGO,
                text = "KOTLIN WASM",
                subtitle = "Pure Motion Studio",
                icon = "auto_awesome",
                initialWidth = 250f,
                initialHeight = 50f,
                backgroundColor = 0xFF311042L,
                gradientEndColor = 0xFF4A044EL,
                textColor = 0xFFF472B6L,
                accentColor = 0xFFEC4899L,
                initialCornerRadius = 12f,
                shadowElevation = 8f
            ).let { applyPresetToNode(it, MotionPreset.KINETIC_3D) }

            else -> SceneNode(
                name = type.title,
                type = type,
                text = type.title,
                subtitle = "Customizable motion element",
                icon = "widgets",
                initialWidth = 240f,
                initialHeight = 70f,
                backgroundColor = 0xFF1E293BL,
                gradientEndColor = 0xFF0F172AL,
                textColor = 0xFFF1F5F9L,
                accentColor = 0xFF06B6D4L,
                initialCornerRadius = 14f
            ).let { applyPresetToNode(it, MotionPreset.SPRING_POP) }
        }
    }
}
