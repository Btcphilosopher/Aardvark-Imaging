package com.example.engine

import com.example.model.*
import kotlin.math.*

data class ComputedProperties(
    val x: Float,
    val y: Float,
    val z: Float,
    val scale: Float,
    val rotation: Float,
    val rotationY: Float,
    val opacity: Float,
    val width: Float,
    val height: Float,
    val cornerRadius: Float,
    val blur: Float,
    val brightness: Float,
    val contrast: Float,
    val saturation: Float,
    val shadowElevation: Float,
    val isHardwareAccelerated: Boolean = true
)

object SpringSimulator {
    /**
     * Solves the second order differential equation for a damped harmonic oscillator:
     * m * x''(t) + c * x'(t) + k * x(t) = 0
     */
    fun evaluateSpring(
        timeSec: Float,
        fromValue: Float,
        toValue: Float,
        config: SpringConfig
    ): Float {
        val m = max(0.01f, config.mass)
        val k = max(0.1f, config.stiffness)
        val c = max(0.0f, config.damping)
        val v0 = config.initialVelocity
        val delta = fromValue - toValue

        if (abs(delta) < 0.0001f && abs(v0) < 0.0001f) return toValue
        if (timeSec <= 0f) return fromValue

        val omega0 = sqrt(k / m)
        val zeta = c / (2f * sqrt(k * m))

        val displacement = when {
            zeta < 1.0f -> {
                // Under-damped (oscillatory)
                val omegaD = omega0 * sqrt(1f - zeta * zeta)
                val decay = exp(-zeta * omega0 * timeSec)
                val a = delta
                val b = (zeta * omega0 * delta + v0) / max(0.0001f, omegaD)
                decay * (a * cos(omegaD * timeSec) + b * sin(omegaD * timeSec))
            }
            zeta > 1.0f -> {
                // Over-damped
                val r1 = -omega0 * (zeta - sqrt(zeta * zeta - 1f))
                val r2 = -omega0 * (zeta + sqrt(zeta * zeta - 1f))
                val c2 = (v0 - r1 * delta) / (r2 - r1)
                val c1 = delta - c2
                c1 * exp(r1 * timeSec) + c2 * exp(r2 * timeSec)
            }
            else -> {
                // Critically damped (zeta == 1.0f)
                val decay = exp(-omega0 * timeSec)
                (delta + (v0 + omega0 * delta) * timeSec) * decay
            }
        }

        return toValue + displacement
    }
}

object EasingEvaluator {
    fun evaluate(
        t: Float,
        easing: EasingType,
        bezierP1: Pair<Float, Float> = Pair(0.25f, 0.1f),
        bezierP2: Pair<Float, Float> = Pair(0.25f, 1.0f)
    ): Float {
        val clampedT = t.coerceIn(0f, 1f)
        return when (easing) {
            EasingType.LINEAR -> clampedT
            EasingType.EASE_IN -> clampedT * clampedT * clampedT
            EasingType.EASE_OUT -> 1f - (1f - clampedT).pow(3)
            EasingType.EASE_IN_OUT -> {
                if (clampedT < 0.5f) 4f * clampedT * clampedT * clampedT
                else 1f - (-2f * clampedT + 2f).pow(3) / 2f
            }
            EasingType.CUBIC_BEZIER, EasingType.CUSTOM -> {
                evaluateCubicBezier(clampedT, bezierP1.first, bezierP1.second, bezierP2.first, bezierP2.second)
            }
            EasingType.SPRING -> {
                SpringSimulator.evaluateSpring(
                    timeSec = clampedT * 1.5f,
                    fromValue = 0f,
                    toValue = 1f,
                    config = SpringConfig(mass = 1.0f, stiffness = 140f, damping = 12f)
                )
            }
            EasingType.ELASTIC -> {
                if (clampedT == 0f) 0f
                else if (clampedT == 1f) 1f
                else {
                    val c4 = (2f * Math.PI.toFloat()) / 3f
                    -(2.0.pow((10f * clampedT - 10f).toDouble()).toFloat()) * sin((clampedT * 10f - 10.75f) * c4)
                }
            }
            EasingType.BOUNCE -> {
                val n1 = 7.5625f
                val d1 = 2.75f
                var x = clampedT
                when {
                    x < 1f / d1 -> n1 * x * x
                    x < 2f / d1 -> {
                        x -= 1.5f / d1
                        n1 * x * x + 0.75f
                    }
                    x < 2.5f / d1 -> {
                        x -= 2.25f / d1
                        n1 * x * x + 0.9375f
                    }
                    else -> {
                        x -= 2.625f / d1
                        n1 * x * x + 0.984375f
                    }
                }
            }
        }
    }

    private fun evaluateCubicBezier(t: Float, x1: Float, y1: Float, x2: Float, y2: Float): Float {
        // Approximate cubic bezier solving
        var currentT = t
        for (i in 0 until 5) {
            val currentX = 3 * (1 - currentT).pow(2) * currentT * x1 + 3 * (1 - currentT) * currentT.pow(2) * x2 + currentT.pow(3)
            val error = currentX - t
            if (abs(error) < 0.001f) break
            currentT = (currentT - error * 0.5f).coerceIn(0f, 1f)
        }
        return 3 * (1 - currentT).pow(2) * currentT * y1 + 3 * (1 - currentT) * currentT.pow(2) * y2 + currentT.pow(3)
    }
}

object MotionEngine {
    fun computeProperties(
        node: SceneNode,
        timeMs: Long,
        reducedMotion: Boolean = false,
        scrollProgress: Float = 0f
    ): ComputedProperties {
        var x = node.initialX
        var y = node.initialY
        var z = node.initialZ
        var scale = node.initialScale
        var rotation = node.initialRotation
        var rotationY = node.initialRotationY
        var opacity = node.initialOpacity
        var width = node.initialWidth
        var height = node.initialHeight
        var cornerRadius = node.initialCornerRadius
        var blur = node.initialBlur
        var brightness = node.initialBrightness
        var contrast = node.initialContrast
        var saturation = node.initialSaturation
        var shadowElevation = node.shadowElevation

        if (reducedMotion) {
            // Respect prefers-reduced-motion accessibility
            return ComputedProperties(
                x = node.initialX,
                y = node.initialY,
                z = node.initialZ,
                scale = 1.0f,
                rotation = 0f,
                rotationY = 0f,
                opacity = 1.0f,
                width = node.initialWidth,
                height = node.initialHeight,
                cornerRadius = node.initialCornerRadius,
                blur = 0f,
                brightness = 1.0f,
                contrast = 1.0f,
                saturation = 1.0f,
                shadowElevation = node.shadowElevation
            )
        }

        // Apply animated tracks
        for (track in node.tracks) {
            if (!track.isEnabled || track.keyframes.isEmpty()) continue

            val value = evaluateTrackValue(track, timeMs)

            when (track.property) {
                PropertyType.POSITION_X -> x = value
                PropertyType.POSITION_Y -> y = value
                PropertyType.POSITION_Z -> z = value
                PropertyType.SCALE -> scale = value
                PropertyType.SCALE_X -> scale = value
                PropertyType.SCALE_Y -> scale = value
                PropertyType.ROTATION -> rotation = value
                PropertyType.ROTATION_Y -> rotationY = value
                PropertyType.OPACITY -> opacity = value.coerceIn(0f, 1f)
                PropertyType.WIDTH -> width = value
                PropertyType.HEIGHT -> height = value
                PropertyType.CORNER_RADIUS -> cornerRadius = value
                PropertyType.BLUR -> blur = value.coerceAtLeast(0f)
                PropertyType.BRIGHTNESS -> brightness = value.coerceAtLeast(0f)
                PropertyType.CONTRAST -> contrast = value.coerceAtLeast(0f)
                PropertyType.SATURATION -> saturation = value.coerceAtLeast(0f)
                PropertyType.SHADOW_ELEVATION -> shadowElevation = value.coerceAtLeast(0f)
                PropertyType.SPRING_BOUNCE -> {
                    y += value
                }
                else -> {}
            }
        }

        // Apply scroll trigger influence if scroll mode is active
        if (node.trigger == InteractionTrigger.ON_SCROLL && scrollProgress > 0f) {
            val scrollDelta = (scrollProgress - node.scrollConfig.startScrollPct) /
                    max(0.01f, (node.scrollConfig.endScrollPct - node.scrollConfig.startScrollPct))
            val clampedScroll = scrollDelta.coerceIn(0f, 1f)
            
            y += (clampedScroll * -120f * node.scrollConfig.parallaxFactor)
            if (node.scrollConfig.fadeOnExit && clampedScroll > 0.6f) {
                val fade = 1f - ((clampedScroll - 0.6f) / 0.4f)
                opacity *= fade.coerceIn(0f, 1f)
            }
            if (node.scrollConfig.scaleOnScroll) {
                scale *= (1f - (clampedScroll * 0.15f))
            }
        }

        val isExpensiveLayout = width != node.initialWidth || height != node.initialHeight || blur > 8f

        return ComputedProperties(
            x = x,
            y = y,
            z = z,
            scale = scale,
            rotation = rotation,
            rotationY = rotationY,
            opacity = opacity,
            width = width,
            height = height,
            cornerRadius = cornerRadius,
            blur = blur,
            brightness = brightness,
            contrast = contrast,
            saturation = saturation,
            shadowElevation = shadowElevation,
            isHardwareAccelerated = !isExpensiveLayout
        )
    }

    private fun evaluateTrackValue(track: AnimationTrack, timeMs: Long): Float {
        val sortedKeys = track.keyframes.sortedBy { it.timeMs }
        if (sortedKeys.isEmpty()) return 0f
        if (sortedKeys.size == 1) return sortedKeys.first().value

        if (timeMs <= sortedKeys.first().timeMs) {
            return sortedKeys.first().value
        }
        if (timeMs >= sortedKeys.last().timeMs) {
            return sortedKeys.last().value
        }

        for (i in 0 until sortedKeys.size - 1) {
            val k1 = sortedKeys[i]
            val k2 = sortedKeys[i + 1]

            if (timeMs in k1.timeMs..k2.timeMs) {
                val span = max(1L, k2.timeMs - k1.timeMs)
                val progress = (timeMs - k1.timeMs).toFloat() / span.toFloat()

                if (k1.easing == EasingType.SPRING) {
                    val timeSec = progress * (span / 1000f) * 2f
                    return SpringSimulator.evaluateSpring(
                        timeSec = timeSec,
                        fromValue = k1.value,
                        toValue = k2.value,
                        config = track.springConfig
                    )
                }

                val easedProgress = EasingEvaluator.evaluate(
                    t = progress,
                    easing = k1.easing,
                    bezierP1 = k1.bezierControlP1,
                    bezierP2 = k1.bezierControlP2
                )
                return k1.value + (k2.value - k1.value) * easedProgress
            }
        }
        return sortedKeys.last().value
    }
}
