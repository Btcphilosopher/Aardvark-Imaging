package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.engine.EasingEvaluator
import com.example.engine.MotionEngine
import com.example.engine.SpringSimulator
import com.example.exporter.CodeExporter
import com.example.exporter.ExportTarget
import com.example.model.EasingType
import com.example.model.PresetsLibrary
import com.example.model.SpringConfig
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Kotlin Motion", appName)
  }

  @Test
  fun `spring simulator converges to target value`() {
    val config = SpringConfig(mass = 1.0f, stiffness = 100f, damping = 10f)
    val startValue = SpringSimulator.evaluateSpring(0.0f, 0f, 100f, config)
    val midValue = SpringSimulator.evaluateSpring(0.5f, 0f, 100f, config)
    val endValue = SpringSimulator.evaluateSpring(3.0f, 0f, 100f, config)

    assertEquals(0f, startValue, 0.01f)
    assertTrue("Spring mid value should be moving towards 100", midValue > 10f)
    assertEquals(100f, endValue, 1.0f)
  }

  @Test
  fun `easing evaluator computes cubic bezier and spring correctly`() {
    val linearVal = EasingEvaluator.evaluate(0.5f, EasingType.LINEAR)
    assertEquals(0.5f, linearVal, 0.01f)

    val easeOutVal = EasingEvaluator.evaluate(0.5f, EasingType.EASE_OUT)
    assertTrue("EaseOut should be front-loaded", easeOutVal > 0.5f)
  }

  @Test
  fun `default project generates valid kotlin and css code`() {
    val project = PresetsLibrary.createDefaultProject()
    assertNotNull(project)
    assertTrue(project.nodes.isNotEmpty())

    val kotlinCode = CodeExporter.generateCode(project, ExportTarget.KOTLIN_DSL)
    assertTrue(kotlinCode.contains("package com.motion.studio.generated"))
    assertTrue(kotlinCode.contains("@Composable"))

    val cssCode = CodeExporter.generateCode(project, ExportTarget.CSS_KEYFRAMES)
    assertTrue(cssCode.contains("@keyframes"))
    assertTrue(cssCode.contains("prefers-reduced-motion"))
  }
}

