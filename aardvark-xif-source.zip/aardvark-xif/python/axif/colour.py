"""
AXIF colour subsystem (SPEC S.14-15).

Scope of this reference implementation, stated honestly: AXIF stores
colour *metadata* precisely (primaries, white point, transfer function,
an optional embedded ICC profile as an opaque byte-exact segment) and
distinguishes metadata-preserving conversion from pixel-transforming
conversion. It does NOT ship a full colour management module (CMM) that
numerically transforms pixels between arbitrary primaries/transfer
functions — that is a legitimate, separable future component (it would
wrap an existing CMM such as LittleCMS rather than reinvent one; see
ROADMAP.md). Round-tripping an embedded ICC profile byte-for-byte through
AXIF is implemented and tested; *applying* that profile is left to the
consumer, exactly as TIFF/PNG/JPEG readers do today.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

# A handful of named presets so callers don't have to hand-type
# chromaticities for the common cases. Values are the standard published
# CIE 1931 xy chromaticities for each space; nothing here is invented.
PRIMARIES_PRESETS = {
    "sRGB": {"r": (0.6400, 0.3300), "g": (0.3000, 0.6000), "b": (0.1500, 0.0600)},
    "DisplayP3": {"r": (0.6800, 0.3200), "g": (0.2650, 0.6900), "b": (0.1500, 0.0600)},
    "Rec2020": {"r": (0.7080, 0.2920), "g": (0.1700, 0.7970), "b": (0.1310, 0.0460)},
    "ACES-AP0": {"r": (0.7347, 0.2653), "g": (0.0000, 1.0000), "b": (0.0001, -0.0770)},
    "ACES-AP1": {"r": (0.7130, 0.2930), "g": (0.1650, 0.8300), "b": (0.1280, 0.0440)},
    "XYZ": {"r": (1.0, 0.0), "g": (0.0, 1.0), "b": (0.0, 0.0)},
}

WHITE_POINTS = {
    "D65": (0.3127, 0.3290),
    "D60": (0.32168, 0.33767),
    "DCI": (0.3140, 0.3510),
}

# Transfer functions we know the *name* of and store faithfully. AXIF
# distinguishes the encoding transfer function from any display transform;
# per SPEC S.13 it never conflates "HDR encoding" with "HDR display".
TRANSFER_FUNCTIONS = {
    "linear",       # scene-linear, no transfer function applied
    "sRGB",         # IEC 61966-2-1
    "gamma22",
    "gamma26",
    "PQ",           # SMPTE ST 2084
    "HLG",          # ARIB STD-B67
    "ACEScc",
    "ACEScct",
}

REFERENCE_KINDS = {"scene-linear", "display-referred"}


@dataclass
class ColourSpace:
    name: str = "sRGB"
    primaries: Optional[dict] = None       # {"r":(x,y), "g":(x,y), "b":(x,y)}
    white_point: Optional[tuple] = None    # (x, y)
    transfer_function: str = "sRGB"
    reference_kind: str = "display-referred"
    icc_profile: Optional[bytes] = field(default=None, repr=False)

    def __post_init__(self):
        if self.primaries is None and self.name in PRIMARIES_PRESETS:
            self.primaries = PRIMARIES_PRESETS[self.name]
        if self.white_point is None:
            self.white_point = WHITE_POINTS["D65"]
        if self.transfer_function not in TRANSFER_FUNCTIONS:
            raise ValueError(
                f"unknown transfer_function {self.transfer_function!r}; "
                f"known: {sorted(TRANSFER_FUNCTIONS)} (extension namespaces "
                f"may register additional ones per SPEC S.66)"
            )
        if self.reference_kind not in REFERENCE_KINDS:
            raise ValueError(f"unknown reference_kind {self.reference_kind!r}")

    def to_manifest(self) -> dict:
        d = {
            "name": self.name,
            "primaries": self.primaries,
            "white_point": self.white_point,
            "transfer_function": self.transfer_function,
            "reference_kind": self.reference_kind,
            "has_icc_profile": self.icc_profile is not None,
        }
        return d

    @classmethod
    def from_manifest(cls, d: dict, icc_profile: Optional[bytes] = None) -> "ColourSpace":
        return cls(
            name=d.get("name", "sRGB"),
            primaries=d.get("primaries"),
            white_point=tuple(d["white_point"]) if d.get("white_point") else None,
            transfer_function=d.get("transfer_function", "sRGB"),
            reference_kind=d.get("reference_kind", "display-referred"),
            icc_profile=icc_profile,
        )


def srgb() -> ColourSpace:
    return ColourSpace("sRGB", transfer_function="sRGB", reference_kind="display-referred")


def display_p3() -> ColourSpace:
    return ColourSpace("DisplayP3", transfer_function="sRGB", reference_kind="display-referred")


def rec2020_pq() -> ColourSpace:
    return ColourSpace("Rec2020", transfer_function="PQ", reference_kind="display-referred")


def scene_linear(primaries_name: str = "ACES-AP1") -> ColourSpace:
    return ColourSpace(primaries_name, transfer_function="linear", reference_kind="scene-linear")
