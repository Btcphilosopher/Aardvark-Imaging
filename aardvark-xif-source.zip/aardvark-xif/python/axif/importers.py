"""
Import adapters (SPEC S.3, S.78): every one of these decodes a real,
independently-maintained codec (via `imagecodecs`, `tifffile`, or Pillow)
into a CanonicalImage. None of them talk to AXIF directly — the writer
never sees a PNG/JPEG/TIFF byte stream, only the CanonicalImage these
functions produce. This is what makes

    SOURCE -> DECODER -> CanonicalImage -> AXIF

a real architectural boundary rather than a naming convention.

Pixel data comes from whichever library round-trips it most faithfully
(imagecodecs for PNG/JPEG/WebP/JPEG2000/JPEG XL/OpenEXR, tifffile for
TIFF, since tifffile correctly preserves arbitrary bit depth and
tiled/multi-page structure that a generic decoder often does not).
Metadata (EXIF tags, ICC profile bytes, XMP packets) is best-effort via
Pillow where the format supports it; unknown/unparsed blocks are kept
byte-exact in Metadata.raw_blocks rather than dropped (SPEC S.28).
"""
from __future__ import annotations

import os
from typing import Optional

import numpy as np

from .colour import ColourSpace, srgb
from .core import CanonicalImage, ChannelDescriptor, gray_channels, rgb_channels, rgba_channels
from .errors import AxifCodecError
from .metadata import Metadata
from .provenance import Provenance


def _channels_for_count(c: int):
    return {1: gray_channels, 3: rgb_channels, 4: rgba_channels}.get(
        c, lambda: [ChannelDescriptor(f"C{i}") for i in range(c)]
    )()


def _ensure_3d(arr: np.ndarray) -> np.ndarray:
    return arr[:, :, None] if arr.ndim == 2 else arr


def _pillow_metadata(path: str) -> Metadata:
    m = Metadata()
    try:
        from PIL import Image
        with Image.open(path) as pil_img:
            try:
                exif = pil_img.getexif()
                if exif:
                    from PIL.ExifTags import TAGS
                    import json as _json
                    for tag_id, value in exif.items():
                        tag = TAGS.get(tag_id, str(tag_id))
                        if isinstance(value, bytes):
                            continue
                        try:
                            _json.dumps(value)
                        except (TypeError, ValueError):
                            value = str(value)
                        m.set("raw.exif", str(tag), value)
            except Exception:
                pass
            icc = pil_img.info.get("icc_profile")
            if icc:
                m.raw_blocks["icc_profile"] = icc
            xmp = pil_img.info.get("xmp")
            if xmp:
                m.raw_blocks["xmp"] = xmp if isinstance(xmp, bytes) else xmp.encode("utf-8")
    except Exception:
        pass
    return m


def _read_bytes(path: str) -> bytes:
    with open(path, "rb") as f:
        return f.read()


def _finish(array: np.ndarray, source_format: str, metadata: Metadata,
            colour_space: Optional[ColourSpace] = None) -> CanonicalImage:
    array = _ensure_3d(np.ascontiguousarray(array))
    prov = Provenance(source_format=source_format)
    from .checksums import sha256_hexdigest
    return CanonicalImage.from_array(
        array, colour_space=colour_space or srgb(), metadata=metadata, provenance=prov,
    )


def import_png(path: str) -> CanonicalImage:
    import imagecodecs
    arr = imagecodecs.png_decode(_read_bytes(path))
    icc = None
    m = _pillow_metadata(path)
    if "icc_profile" in m.raw_blocks:
        icc = m.raw_blocks["icc_profile"]
    cs = ColourSpace(icc_profile=icc) if icc else srgb()
    return _finish(arr, "PNG", m, cs)


def import_jpeg(path: str) -> CanonicalImage:
    import imagecodecs
    arr = imagecodecs.jpeg8_decode(_read_bytes(path))
    m = _pillow_metadata(path)
    icc = m.raw_blocks.get("icc_profile")
    cs = ColourSpace(icc_profile=icc) if icc else srgb()
    return _finish(arr, "JPEG", m, cs)


def import_tiff(path: str) -> CanonicalImage:
    import tifffile
    arr = tifffile.imread(path)
    if arr.ndim == 2:
        arr = arr[:, :, None]
    elif arr.ndim > 3:
        # collapse leading singleton/page dimensions if present
        arr = arr.reshape(arr.shape[-3:]) if arr.shape[0] == 1 else arr[0]
    m = _pillow_metadata(path)
    try:
        with tifffile.TiffFile(path) as tf:
            page = tf.pages[0]
            for tag in page.tags.values():
                try:
                    import json as _json
                    _json.dumps(tag.value)
                    m.set("raw.tiff_tag", tag.name, tag.value)
                except Exception:
                    pass
    except Exception:
        pass
    return _finish(arr, "TIFF", m)


def import_exr(path: str) -> CanonicalImage:
    import imagecodecs
    arr = imagecodecs.exr_decode(_read_bytes(path))
    m = Metadata()
    cs = ColourSpace(transfer_function="linear", reference_kind="scene-linear", name="ACES-AP1")
    return _finish(arr, "OpenEXR", m, cs)


def import_webp(path: str) -> CanonicalImage:
    import imagecodecs
    arr = imagecodecs.webp_decode(_read_bytes(path))
    return _finish(arr, "WebP", Metadata())


def import_jpeg2000(path: str) -> CanonicalImage:
    import imagecodecs
    arr = imagecodecs.jpeg2k_decode(_read_bytes(path))
    return _finish(arr, "JPEG2000", Metadata())


def import_jpegxl(path: str) -> CanonicalImage:
    import imagecodecs
    arr = imagecodecs.jpegxl_decode(_read_bytes(path))
    return _finish(arr, "JPEGXL", Metadata())


def import_bmp(path: str) -> CanonicalImage:
    from PIL import Image
    with Image.open(path) as im:
        arr = np.array(im.convert("RGB"))
    return _finish(arr, "BMP", Metadata())


def import_avif(path: str) -> CanonicalImage:
    import imagecodecs
    arr = imagecodecs.avif_decode(_read_bytes(path))
    return _finish(arr, "AVIF", Metadata())


def import_heif(path: str) -> CanonicalImage:
    import imagecodecs
    arr = imagecodecs.heif_decode(_read_bytes(path))
    return _finish(arr, "HEIF", Metadata())


_EXT_DISPATCH = {
    "png": import_png,
    "jpg": import_jpeg, "jpeg": import_jpeg,
    "tif": import_tiff, "tiff": import_tiff,
    "exr": import_exr,
    "webp": import_webp,
    "jp2": import_jpeg2000, "j2k": import_jpeg2000,
    "jxl": import_jpegxl,
    "bmp": import_bmp,
    "avif": import_avif,
    "heic": import_heif, "heif": import_heif,
}


def import_auto(path: str) -> CanonicalImage:
    ext = os.path.splitext(path)[1].lower().lstrip(".")
    fn = _EXT_DISPATCH.get(ext)
    if fn is None:
        raise AxifCodecError(
            f"no import adapter for extension '.{ext}'. Supported: "
            f"{sorted(set(_EXT_DISPATCH))}"
        )
    return fn(path)


def canonical_from_axif(reader) -> CanonicalImage:
    """AXIF -> CanonicalImage, the read side of the conversion boundary.
    Materialises level 0 in full — for a true 16K master, prefer
    reader.read_region()/read_tile() directly unless a full in-memory
    array is actually required by the target exporter."""
    arr = reader.to_numpy()
    return CanonicalImage(
        width=reader.width, height=reader.height, channels=reader.channels,
        dtype=reader.dtype, array=arr, colour_space=reader.colour_space,
        metadata=reader.metadata, provenance=reader.provenance,
    )
