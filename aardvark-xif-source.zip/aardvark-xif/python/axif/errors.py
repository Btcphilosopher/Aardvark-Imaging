"""
AXIF exception hierarchy.

All errors the reference library can raise derive from AxifError so callers
can catch broadly (`except axif.AxifError`) or narrowly, per spec S.67/S.68:
a decoder must fail *explicitly* rather than silently returning damaged or
truncated image data.
"""


class AxifError(Exception):
    """Base class for all AXIF library errors."""


class AxifFormatError(AxifError):
    """The byte stream is not a well-formed AXIF container (bad magic,
    truncated header, unparsable manifest/index, inconsistent offsets)."""


class AxifVersionError(AxifError):
    """The file declares a FORMAT_MAJOR version this decoder does not
    support, or a mandatory extension this decoder does not implement.
    Per S.9, a decoder MUST reject unsupported mandatory features rather
    than attempt to interpret them."""


class AxifChecksumError(AxifError):
    """A segment's CRC32C (or the file's SHA-256) did not match the value
    recorded in the index/footer. Indicates corruption."""


class AxifCodecError(AxifError):
    """A segment references a codec_id the running process cannot execute
    (missing optional dependency) or the codec raised during encode/decode."""


class AxifSecurityError(AxifError):
    """A declared value (width, height, tile size, uncompressed length,
    metadata size, segment count, offset) exceeds the caller's configured
    ResourceLimits, or an offset/length would read outside the file. Raised
    *before* any large allocation or decompression is attempted, per S.67/68."""


class AxifValidationError(AxifError):
    """Raised by strict validation when a file is structurally parseable
    but violates a conformance rule (see axif.security / axif-validate)."""
