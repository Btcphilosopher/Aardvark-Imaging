"""
AXIF integrity primitives (SPEC S.34).

Two checksum mechanisms are used in the container:

* CRC32C (Castagnoli) — one per data segment, cheap, checked on every
  ordinary tile/region read to catch storage-layer corruption fast.
* SHA-256 — one over the whole file body (everything before the footer),
  checked by `axif-validate` and available for cryptographic content
  addressing / provenance hashing (S.33).

We prefer the compiled `crc32c` package when present (fast, used by real
storage systems) but ship a pure-Python fallback table implementation so the
*core* format never hard-depends on a native extension. Both are verified
against each other and against the standard CRC32C check value in
tests/test_checksums.py.
"""
from __future__ import annotations

import hashlib

try:
    import crc32c as _crc32c_native

    def crc32c(data: bytes) -> int:
        return _crc32c_native.crc32c(data)

    _BACKEND = "native"
except ImportError:  # pragma: no cover - exercised only without the wheel
    _BACKEND = "pure-python"

    _POLY = 0x82F63B78  # reversed Castagnoli polynomial

    def _build_table():
        table = []
        for byte in range(256):
            crc = byte
            for _ in range(8):
                crc = (crc >> 1) ^ _POLY if crc & 1 else crc >> 1
            table.append(crc)
        return table

    _TABLE = _build_table()

    def crc32c(data: bytes) -> int:
        crc = 0xFFFFFFFF
        for b in data:
            crc = (crc >> 8) ^ _TABLE[(crc ^ b) & 0xFF]
        return crc ^ 0xFFFFFFFF


def sha256_digest(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()


def sha256_hexdigest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


class StreamingSHA256:
    """Thin wrapper so writer/reader code doesn't import hashlib directly."""

    def __init__(self):
        self._h = hashlib.sha256()

    def update(self, data: bytes) -> None:
        self._h.update(data)

    def digest(self) -> bytes:
        return self._h.digest()

    def hexdigest(self) -> str:
        return self._h.hexdigest()


__all__ = [
    "crc32c",
    "sha256_digest",
    "sha256_hexdigest",
    "StreamingSHA256",
]
