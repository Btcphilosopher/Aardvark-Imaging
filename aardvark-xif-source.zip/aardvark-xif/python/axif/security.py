"""
AXIF security guards.

Every field that comes from an untrusted file (width, height, tile size,
segment count, an index entry's declared uncompressed_length, an offset)
is checked here *before* it is used to size an allocation or drive a loop.
The design rule (SPEC S.67): treat every AXIF file as hostile input, and
fail with AxifSecurityError rather than let Python (or a native codec)
attempt a multi-gigabyte allocation on our behalf.
"""
from __future__ import annotations

from dataclasses import dataclass

from .errors import AxifSecurityError


@dataclass
class ResourceLimits:
    """Caller-configurable ceilings (SPEC S.68). Defaults are generous
    enough for a real 16K master (15360x8640) plus headroom, but finite."""

    max_width: int = 100_000
    max_height: int = 100_000
    max_pixels: int = 2_000_000_000            # ~2 gigapixels
    max_decoded_segment_bytes: int = 2 * 1024 ** 3   # single-segment decompress ceiling
    max_total_decoded_bytes: int = 8 * 1024 ** 3     # whole-file to_numpy() ceiling
    max_metadata_bytes: int = 64 * 1024 * 1024
    max_tile_dim: int = 8192
    max_segment_count: int = 2_000_000
    max_file_size_bytes: int = 200 * 1024 ** 3
    # decompression-bomb guard: reject a segment if its declared
    # uncompressed_length exceeds compressed length by more than this
    # ratio *and* exceeds max_decoded_segment_bytes on its own. A high
    # ratio alone is not fatal (legitimate flat/synthetic regions compress
    # extremely well); it only matters once combined with genuine size.
    max_expansion_ratio: float = 10_000.0

    @classmethod
    def permissive(cls) -> "ResourceLimits":
        """Loosened limits for internal tooling (benchmark/test fixture
        generation) that deliberately exercises large, valid files."""
        return cls(
            max_width=1_000_000,
            max_height=1_000_000,
            max_pixels=50_000_000_000,
            max_decoded_segment_bytes=16 * 1024 ** 3,
            max_total_decoded_bytes=64 * 1024 ** 3,
            max_file_size_bytes=2 * 1024 ** 4,
        )


DEFAULT_LIMITS = ResourceLimits()


def check_dimensions(width: int, height: int, limits: ResourceLimits) -> None:
    if width <= 0 or height <= 0:
        raise AxifSecurityError(f"non-positive dimensions: {width}x{height}")
    if width > limits.max_width or height > limits.max_height:
        raise AxifSecurityError(
            f"dimensions {width}x{height} exceed configured limits "
            f"({limits.max_width}x{limits.max_height})"
        )
    pixels = width * height
    if pixels > limits.max_pixels:
        raise AxifSecurityError(
            f"{pixels} pixels exceeds max_pixels={limits.max_pixels}"
        )


def check_tile_dims(tile_width: int, tile_height: int, limits: ResourceLimits) -> None:
    if tile_width <= 0 or tile_height <= 0:
        raise AxifSecurityError(f"non-positive tile size: {tile_width}x{tile_height}")
    if tile_width > limits.max_tile_dim or tile_height > limits.max_tile_dim:
        raise AxifSecurityError(
            f"tile size {tile_width}x{tile_height} exceeds max_tile_dim="
            f"{limits.max_tile_dim}"
        )


def check_segment_count(count: int, limits: ResourceLimits) -> None:
    if count > limits.max_segment_count:
        raise AxifSecurityError(
            f"{count} index segments exceeds max_segment_count="
            f"{limits.max_segment_count}"
        )


def check_metadata_size(nbytes: int, limits: ResourceLimits) -> None:
    if nbytes > limits.max_metadata_bytes:
        raise AxifSecurityError(
            f"manifest/metadata block of {nbytes} bytes exceeds "
            f"max_metadata_bytes={limits.max_metadata_bytes}"
        )


def check_bounds(offset: int, length: int, file_size: int) -> None:
    if offset < 0 or length < 0:
        raise AxifSecurityError(f"negative offset/length: {offset}/{length}")
    # Guard the addition itself against wrap-around on platforms where a
    # crafted u64 could overflow a native size_t; Python ints don't
    # overflow, but the *check* is what a C/Rust port must reproduce.
    end = offset + length
    if end < offset:
        raise AxifSecurityError("offset+length integer overflow")
    if end > file_size:
        raise AxifSecurityError(
            f"segment [{offset}, {end}) lies outside the file "
            f"(file size {file_size}) — truncated or malicious file"
        )


def check_segment_expansion(
    compressed_length: int, uncompressed_length: int, limits: ResourceLimits
) -> None:
    if uncompressed_length < 0:
        raise AxifSecurityError("negative uncompressed_length")
    if uncompressed_length > limits.max_decoded_segment_bytes:
        raise AxifSecurityError(
            f"segment declares {uncompressed_length} decoded bytes, "
            f"exceeding max_decoded_segment_bytes="
            f"{limits.max_decoded_segment_bytes}"
        )
    if compressed_length > 0:
        ratio = uncompressed_length / compressed_length
        if (
            ratio > limits.max_expansion_ratio
            and uncompressed_length > limits.max_decoded_segment_bytes // 4
        ):
            raise AxifSecurityError(
                f"suspicious expansion ratio {ratio:.1f}x "
                f"({compressed_length} -> {uncompressed_length} bytes); "
                f"refusing to decompress (possible decompression bomb)"
            )


def check_total_decode_budget(nbytes: int, limits: ResourceLimits) -> None:
    if nbytes > limits.max_total_decoded_bytes:
        raise AxifSecurityError(
            f"decoding {nbytes} bytes would exceed "
            f"max_total_decoded_bytes={limits.max_total_decoded_bytes}; "
            f"use read_region()/read_tile()/read_level() for partial access "
            f"or raise ResourceLimits.max_total_decoded_bytes explicitly"
        )
