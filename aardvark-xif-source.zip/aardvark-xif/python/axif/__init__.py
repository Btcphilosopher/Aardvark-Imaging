"""
AXIF — Aardvark Extended Image Format — Python reference SDK.

    import axif

    image = axif.open("photo.axif")
    print(image.width, image.height)
    region = image.read_region(x=5000, y=3000, width=1024, height=1024, level=0)
    thumb = image.read_thumbnail()

    canonical = axif.import_file("source.tif")
    axif.AxifWriter(canonical, tile_width=512, tile_height=512).write("out.axif")

See ARCHITECTURE.md for the module map and SPECIFICATION.md for the wire
format this package reads and writes.
"""
from .core import (
    CanonicalImage,
    ChannelDescriptor,
    gray_channels,
    rgb_channels,
    rgba_channels,
)
from .colour import ColourSpace, display_p3, rec2020_pq, scene_linear, srgb
from .errors import (
    AxifChecksumError,
    AxifCodecError,
    AxifError,
    AxifFormatError,
    AxifSecurityError,
    AxifValidationError,
    AxifVersionError,
)
from .format import AxifReader, AxifWriter, ValidationReport, WriteReport
from .metadata import Metadata, camera_metadata
from .provenance import AIProvenance, ProcessingStage, Provenance
from .security import DEFAULT_LIMITS, ResourceLimits
from . import codec, diff, benchmark

__version__ = "0.1.0"
FORMAT_VERSION = "1.0.0"


def open(path: str, **kwargs) -> AxifReader:  # noqa: A001 - deliberate stdlib-style shadow, like Pillow's Image.open
    """Open an AXIF file for reading. Returns an AxifReader; use as a
    context manager or call .close() when done."""
    return AxifReader(path, **kwargs)


def import_file(path: str, **kwargs) -> CanonicalImage:
    """Decode a foreign image file (PNG/JPEG/TIFF/OpenEXR/JPEG2000/
    JPEG XL/WebP/BMP/PPM) into a CanonicalImage, dispatching on extension.
    See axif.importers for the per-format adapters."""
    from . import importers
    return importers.import_auto(path, **kwargs)


def convert(source_path: str, target_path: str, **kwargs):
    """SOURCE -> CanonicalImage -> AXIF, or AXIF -> CanonicalImage -> TARGET,
    dispatching on file extensions. See axif.exporters / cli for options."""
    from . import exporters, importers
    src_ext = source_path.rsplit(".", 1)[-1].lower()
    dst_ext = target_path.rsplit(".", 1)[-1].lower()
    if src_ext == "axif":
        reader = AxifReader(source_path)
        canonical = importers.canonical_from_axif(reader)
        return exporters.export_auto(canonical, target_path, **kwargs)
    elif dst_ext == "axif":
        canonical = importers.import_auto(source_path)
        writer = AxifWriter(canonical, **kwargs)
        return writer.write(target_path)
    else:
        canonical = importers.import_auto(source_path)
        return exporters.export_auto(canonical, target_path, **kwargs)


__all__ = [
    "AxifReader", "AxifWriter", "ValidationReport", "WriteReport",
    "CanonicalImage", "ChannelDescriptor", "rgb_channels", "rgba_channels", "gray_channels",
    "ColourSpace", "srgb", "display_p3", "rec2020_pq", "scene_linear",
    "Metadata", "camera_metadata",
    "Provenance", "ProcessingStage", "AIProvenance",
    "ResourceLimits", "DEFAULT_LIMITS",
    "AxifError", "AxifFormatError", "AxifVersionError", "AxifChecksumError",
    "AxifCodecError", "AxifSecurityError", "AxifValidationError",
    "codec", "diff", "benchmark", "open", "import_file", "convert",
    "__version__", "FORMAT_VERSION",
]
