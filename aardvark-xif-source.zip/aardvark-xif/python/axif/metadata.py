"""
AXIF metadata registry (SPEC S.28-32).

Every field is stored as (namespace, name) -> value inside the manifest's
"metadata" object, e.g. "camera.iso": 400, "aardvark.sensor.model": "...".
Namespaces are just dotted strings; the reserved top-level namespaces from
SPEC S.29/S.66 are listed below, but the registry does not refuse unknown
ones — vendor and future namespaces are first-class, per "do not make
third-party metadata impossible".

Unknown metadata blocks encountered while *importing* a foreign file
(arbitrary EXIF tags, raw XMP/IPTC packets) are preserved verbatim under
namespace "raw" rather than dropped, satisfying "preserve unknown metadata
blocks where possible" (S.28) without AXIF having to understand them.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional

RESERVED_NAMESPACES = {
    "core", "camera", "colour", "computational", "scientific",
    "ai", "provenance", "vendor",
    "aardvark.camera", "aardvark.sensor", "aardvark.computational",
    "aardvark.lidar", "aardvark.thermal", "aardvark.hyper",
    "aardvark.metrology",
    "raw",  # opaque passthrough of foreign metadata blocks (exif/xmp/iptc)
}


@dataclass
class Metadata:
    fields: Dict[str, Any] = field(default_factory=dict)
    # opaque, byte-exact blocks preserved from an imported source file
    # (e.g. {"exif": b"...", "xmp": b"..."}), not interpreted by AXIF.
    raw_blocks: Dict[str, bytes] = field(default_factory=dict)

    def set(self, namespace: str, name: str, value: Any) -> None:
        self.fields[f"{namespace}.{name}"] = value

    def get(self, namespace: str, name: str, default=None) -> Any:
        return self.fields.get(f"{namespace}.{name}", default)

    def namespace(self, namespace: str) -> Dict[str, Any]:
        prefix = namespace + "."
        return {
            k[len(prefix):]: v for k, v in self.fields.items() if k.startswith(prefix)
        }

    def to_manifest(self) -> dict:
        return {"fields": dict(self.fields), "raw_block_sizes": {
            k: len(v) for k, v in self.raw_blocks.items()
        }}

    @classmethod
    def from_manifest(cls, d: dict) -> "Metadata":
        m = cls()
        m.fields = dict(d.get("fields", {}))
        return m


# --- Convenience constructors for the common camera fields (SPEC S.30) ----

def camera_metadata(
    *,
    model: Optional[str] = None,
    sensor_model: Optional[str] = None,
    lens: Optional[str] = None,
    focal_length_mm: Optional[float] = None,
    aperture_f: Optional[float] = None,
    shutter_s: Optional[float] = None,
    iso: Optional[int] = None,
    white_balance_k: Optional[float] = None,
    capture_timestamp: Optional[str] = None,
    **extra,
) -> Metadata:
    m = Metadata()
    values = dict(
        model=model, sensor_model=sensor_model, lens=lens,
        focal_length_mm=focal_length_mm, aperture_f=aperture_f,
        shutter_s=shutter_s, iso=iso, white_balance_k=white_balance_k,
        capture_timestamp=capture_timestamp,
    )
    for k, v in values.items():
        if v is not None:
            m.set("camera", k, v)
    for k, v in extra.items():
        m.set("aardvark.camera", k, v)
    return m
