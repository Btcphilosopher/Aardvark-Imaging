"""
AXIF provenance (SPEC S.31-33).

Records *how an image came to look the way it does*: a linear list of
processing stages (RAW -> DENOISE -> DEMOSAIC -> ... -> OUTPUT), each
optionally carrying algorithm/version/parameters/timestamp/software, plus
optional AI-generation provenance and a content-hash chain.

Cryptographic signing (SPEC S.33) is scoped to hashing + a signature/
certificate *reference* field using an established primitive (Ed25519);
this reference implementation records the hash chain and a signature slot
but does not ship a private-key signing workflow — that is a deployment
concern (where does the camera's key live?) out of scope for a file-format
library. Nothing here invents a cryptographic algorithm, per S.33.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


@dataclass
class ProcessingStage:
    stage: str
    algorithm: Optional[str] = None
    version: Optional[str] = None
    parameters: Dict[str, Any] = field(default_factory=dict)
    timestamp: Optional[str] = None
    software: Optional[str] = None
    operator: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "stage": self.stage,
            "algorithm": self.algorithm,
            "version": self.version,
            "parameters": self.parameters,
            "timestamp": self.timestamp,
            "software": self.software,
            "operator": self.operator,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "ProcessingStage":
        return cls(
            stage=d["stage"], algorithm=d.get("algorithm"), version=d.get("version"),
            parameters=d.get("parameters", {}), timestamp=d.get("timestamp"),
            software=d.get("software"), operator=d.get("operator"),
        )


@dataclass
class AIProvenance:
    generator: Optional[str] = None
    model_identifier: Optional[str] = None
    model_version: Optional[str] = None
    prompt_reference: Optional[str] = None   # a reference/hash, not necessarily the raw prompt
    seed: Optional[int] = None
    sampler: Optional[str] = None
    generation_parameters: Dict[str, Any] = field(default_factory=dict)
    post_processing: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return dict(
            generator=self.generator, model_identifier=self.model_identifier,
            model_version=self.model_version, prompt_reference=self.prompt_reference,
            seed=self.seed, sampler=self.sampler,
            generation_parameters=self.generation_parameters,
            post_processing=self.post_processing,
        )

    @classmethod
    def from_dict(cls, d: dict) -> "AIProvenance":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


@dataclass
class Provenance:
    source_format: Optional[str] = None       # e.g. "TIFF", "OpenEXR", "camera-raw"
    source_hash_sha256: Optional[str] = None   # hash of the original imported bytes
    stages: List[ProcessingStage] = field(default_factory=list)
    ai: Optional[AIProvenance] = None
    signature: Optional[Dict[str, str]] = None  # {"algorithm":"Ed25519","signature":"...","certificate_ref":"..."}

    def add_stage(self, stage: str, **kwargs) -> "Provenance":
        kwargs.setdefault("timestamp", datetime.now(timezone.utc).isoformat())
        self.stages.append(ProcessingStage(stage=stage, **kwargs))
        return self

    def to_manifest(self) -> dict:
        return {
            "source_format": self.source_format,
            "source_hash_sha256": self.source_hash_sha256,
            "stages": [s.to_dict() for s in self.stages],
            "ai": self.ai.to_dict() if self.ai else None,
            "signature": self.signature,
        }

    @classmethod
    def from_manifest(cls, d: dict) -> "Provenance":
        return cls(
            source_format=d.get("source_format"),
            source_hash_sha256=d.get("source_hash_sha256"),
            stages=[ProcessingStage.from_dict(s) for s in d.get("stages", [])],
            ai=AIProvenance.from_dict(d["ai"]) if d.get("ai") else None,
            signature=d.get("signature"),
        )
