"""
AXIF image pyramid (SPEC S.18-19).

A PyramidPlan turns (master width, master height, tile size, level_count)
into a list of Level records, each independently addressable and each
covering the whole image at half the resolution of the level before it
(box-filter downsampling), terminating once a level would be smaller than
one tile or `level_count` levels have been produced — whichever comes
first. Level 0 is always the full-resolution master.

Downsampling for levels > 0 happens per-tile from the ALREADY-DOWNSAMPLED
lower-resolution raster, computed level-by-level from level 0 (standard
mip-style construction), so it works uniformly whether level 0 itself came
from an in-memory array or a streaming tile_source — AxifWriter walks
levels from coarse awareness of level 0's total extent, requesting only
the level-0 tiles it needs to build each level-N tile, and never holds
more than a small constant number of level-0 tiles in memory in the
streaming case (see ProceduralTileSource below for a source that can
answer any level directly, which is even cheaper).
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import List

import numpy as np


@dataclass
class Level:
    index: int
    width: int
    height: int
    tile_width: int
    tile_height: int

    @property
    def tiles_x(self) -> int:
        return math.ceil(self.width / self.tile_width)

    @property
    def tiles_y(self) -> int:
        return math.ceil(self.height / self.tile_height)

    @property
    def tile_count(self) -> int:
        return self.tiles_x * self.tiles_y

    def to_dict(self) -> dict:
        return dict(
            level=self.index, width=self.width, height=self.height,
            tile_width=self.tile_width, tile_height=self.tile_height,
            tiles_x=self.tiles_x, tiles_y=self.tiles_y,
        )


@dataclass
class PyramidPlan:
    master_width: int
    master_height: int
    tile_width: int = 512
    tile_height: int = 512
    max_levels: int = 16

    def levels(self) -> List[Level]:
        out = []
        w, h = self.master_width, self.master_height
        i = 0
        while True:
            out.append(Level(i, w, h, self.tile_width, self.tile_height))
            if w <= self.tile_width and h <= self.tile_height:
                break
            if i + 1 >= self.max_levels:
                break
            w = max(1, math.ceil(w / 2))
            h = max(1, math.ceil(h / 2))
            i += 1
        return out


def downsample_box(array: np.ndarray, out_w: int, out_h: int) -> np.ndarray:
    """Area-average (box filter) downsample. Used to build pyramid level
    N+1 from level N. Operates in float32 internally regardless of input
    dtype to avoid integer overflow/banding, then casts back."""
    h, w = array.shape[:2]
    orig_dtype = array.dtype
    src = array.astype(np.float32)
    # Use PIL's high quality box/area resampling via numpy-free path when
    # dimensions are large, falling back to simple striding for tiny tiles.
    from PIL import Image

    if src.ndim == 2:
        src = src[:, :, None]
    channels = src.shape[2]
    out = np.empty((out_h, out_w, channels), dtype=np.float32)
    for c in range(channels):
        im = Image.fromarray(src[:, :, c], mode="F")
        im = im.resize((out_w, out_h), resample=Image.BOX if (w >= out_w and h >= out_h) else Image.BILINEAR)
        out[:, :, c] = np.asarray(im)
    if np.issubdtype(orig_dtype, np.integer):
        info = np.iinfo(orig_dtype)
        out = np.clip(np.round(out), info.min, info.max)
    return out.astype(orig_dtype)


class ProceduralTileSource:
    """A TileSource that renders pixels directly from a deterministic
    generator function of *absolute level-0 pixel coordinates*, so any
    pyramid level can be produced by sampling the generator on a coarser
    grid — the master image is never materialised at all, at any
    resolution. This is what the 16K streaming demonstration fixture
    (test-vectors/generate_fixtures.py) uses to build a true 15360x8640
    AXIF master under a few hundred MB of peak RSS.

    `generator(x, y)` must accept numpy coordinate grids (as produced by
    np.meshgrid) at level-0 scale and return an (H, W, C) uint8/uint16
    array; ProceduralTileSource handles the coordinate scaling for
    level > 0 by sampling every `2**level`-th level-0 coordinate.
    """

    def __init__(self, generator, master_width: int, master_height: int,
                 num_channels: int, dtype=np.uint8):
        self.generator = generator
        self.master_width = master_width
        self.master_height = master_height
        self.num_channels = num_channels
        self.dtype = dtype

    def __call__(self, level: int, tx: int, ty: int, tw: int, th: int) -> np.ndarray:
        scale = 2 ** level
        level_w = max(1, math.ceil(self.master_width / scale))
        level_h = max(1, math.ceil(self.master_height / scale))
        x0 = tx * tw
        y0 = ty * th
        x1 = min(x0 + tw, level_w)
        y1 = min(y0 + th, level_h)
        xs = (np.arange(x0, x1) * scale).astype(np.float64)
        ys = (np.arange(y0, y1) * scale).astype(np.float64)
        gx, gy = np.meshgrid(xs, ys)
        return self.generator(gx, gy).astype(self.dtype)
