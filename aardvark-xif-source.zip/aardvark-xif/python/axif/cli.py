"""
AXIF command-line tools (SPEC S.51-54, S.89).

Each `*_main` function here is both the entry point installed by
pyproject.toml (so `axif-info file.axif` works after `pip install -e .`)
and directly callable from the standalone scripts in cli/ (so the tools
work from a checkout with no install step — see cli/axif-info etc, which
just do `from axif.cli import info_main; sys.exit(info_main())`).
"""
from __future__ import annotations

import argparse
import json
import sys
import time

import numpy as np


def _fmt_bytes(n: int) -> str:
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if abs(n) < 1024.0:
            return f"{n:3.1f}{unit}"
        n /= 1024.0
    return f"{n:.1f}PB"


# --------------------------------------------------------------------- info
def info_main(argv=None) -> int:
    from . import AxifReader

    ap = argparse.ArgumentParser(prog="axif-info", description="Show AXIF file metadata (SPEC S.52)")
    ap.add_argument("file")
    ap.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    args = ap.parse_args(argv)

    r = AxifReader(args.file)
    info = r.info()
    r.close()

    if args.json:
        print(json.dumps(info, indent=2))
        return 0

    print(f"AARDVARK XIF  —  {args.file}")
    print(f"  Format version        : {info['format_version']}")
    print(f"  Profile               : {info['profile']}")
    print(f"  Dimensions            : {info['width']} x {info['height']}")
    print(f"  Channels              : {', '.join(info['channels'])}")
    print(f"  Pixel format          : {info['pixel_format']}")
    print(f"  Colour space          : {info['colour_space']} ({info['transfer_function']})")
    print(f"  Compression           : {info['compression']}")
    print(f"  Tile size             : {info['tile_size']}")
    print(f"  Pyramid levels        : {info['levels']}  {info['level_dims']}")
    print(f"  Segments              : {info['segment_count']}")
    print(f"  Preview / thumbnail   : {info['has_preview']} / {info['has_thumbnail']}")
    print(f"  ICC profile embedded  : {info['has_icc_profile']}")
    print(f"  Metadata fields       : {info['metadata_fields']}")
    print(f"  Provenance stages     : {info['provenance_stages']}")
    print(f"  File size             : {_fmt_bytes(info['file_size_bytes'])} ({info['file_size_bytes']:,} bytes)")
    return 0


# ----------------------------------------------------------------- validate
def validate_main(argv=None) -> int:
    from . import AxifReader

    ap = argparse.ArgumentParser(prog="axif-validate", description="Validate an AXIF file (SPEC S.53)")
    ap.add_argument("file")
    ap.add_argument("--strict", action="store_true", help="verify every segment checksum, not just a sample")
    args = ap.parse_args(argv)

    try:
        r = AxifReader(args.file)
    except Exception as e:
        print(f"INVALID — could not even open the file: {type(e).__name__}: {e}")
        return 1

    report = r.validate(strict=args.strict)
    r.close()
    print(str(report))
    return 0 if report.ok else 1


# ------------------------------------------------------------------ convert
def convert_main(argv=None) -> int:
    from . import AxifWriter, ResourceLimits, codec
    from . import importers, exporters

    ap = argparse.ArgumentParser(prog="axif-convert", description="Convert between AXIF and other formats (SPEC S.51)")
    ap.add_argument("source")
    ap.add_argument("target")
    ap.add_argument("--lossless", action="store_true", help="use a lossless codec (default for AXIF targets)")
    ap.add_argument("--quality", type=float, default=90, help="quality for lossy target codecs (default 90)")
    ap.add_argument("--tile-size", type=int, default=512, help="AXIF tile size in pixels (default 512)")
    ap.add_argument("--level-count", type=int, default=None, help="max pyramid levels (default: auto)")
    ap.add_argument("--codec", default=None, help="AXIF internal codec name, e.g. AXIF-ZLIB-LOSSLESS, JPEGXL-LOSSLESS")
    ap.add_argument("--no-preview", action="store_true")
    ap.add_argument("--no-thumbnail", action="store_true")
    args = ap.parse_args(argv)

    src_ext = args.source.rsplit(".", 1)[-1].lower()
    dst_ext = args.target.rsplit(".", 1)[-1].lower()

    t0 = time.perf_counter()
    if dst_ext == "axif":
        canonical = importers.import_auto(args.source)
        codec_id = codec.CODEC_NAME_TO_ID[args.codec] if args.codec else codec.CODEC_ZLIB_LOSSLESS
        writer = AxifWriter(
            canonical, tile_width=args.tile_size, tile_height=args.tile_size,
            codec_id=codec_id, level_count=args.level_count,
            generate_preview=not args.no_preview, generate_thumbnail=not args.no_thumbnail,
        )
        report = writer.write(args.target)
        dt = time.perf_counter() - t0
        print(f"Wrote {args.target}: {report.tile_count} tiles across {report.level_count} levels, "
              f"{_fmt_bytes(report.file_size)} in {dt:.2f}s")
    elif src_ext == "axif":
        from . import AxifReader
        reader = AxifReader(args.source)
        canonical = importers.canonical_from_axif(reader)
        reader.close()
        exporters.export_auto(canonical, args.target, quality=args.quality,
                               lossless=args.lossless)
        dt = time.perf_counter() - t0
        print(f"Wrote {args.target} in {dt:.2f}s")
    else:
        canonical = importers.import_auto(args.source)
        exporters.export_auto(canonical, args.target, quality=args.quality, lossless=args.lossless)
        dt = time.perf_counter() - t0
        print(f"Wrote {args.target} in {dt:.2f}s")
    return 0


# ------------------------------------------------------------------ extract
def extract_main(argv=None) -> int:
    from . import AxifReader
    from . import exporters

    ap = argparse.ArgumentParser(prog="axif-extract", description="Extract a region/tile/level/preview/thumbnail (SPEC S.89)")
    ap.add_argument("file")
    ap.add_argument("--region", help="x,y,width,height")
    ap.add_argument("--tile", help="level,tx,ty")
    ap.add_argument("--level", type=int, help="extract a full pyramid level")
    ap.add_argument("--preview", action="store_true")
    ap.add_argument("--thumbnail", action="store_true")
    ap.add_argument("--out", required=True, help="output image file (PNG/TIFF/JPEG/...)")
    args = ap.parse_args(argv)

    r = AxifReader(args.file)
    if args.region:
        x, y, w, h = (int(v) for v in args.region.split(","))
        arr = r.read_region(x, y, w, h)
    elif args.tile:
        level, tx, ty = (int(v) for v in args.tile.split(","))
        arr = r.read_tile(level, tx, ty)
    elif args.level is not None:
        arr = r.read_level(args.level)
    elif args.preview:
        arr = r.read_preview()
    elif args.thumbnail:
        arr = r.read_thumbnail()
    else:
        print("specify one of --region/--tile/--level/--preview/--thumbnail", file=sys.stderr)
        return 2

    if arr is None:
        print("requested segment is not present in this file", file=sys.stderr)
        return 1

    canonical = _array_to_canonical(arr, r)
    r.close()
    exporters.export_auto(canonical, args.out)
    print(f"Wrote {args.out}  shape={arr.shape}  dtype={arr.dtype}")
    return 0


def _array_to_canonical(arr: np.ndarray, reader):
    from .core import CanonicalImage
    return CanonicalImage.from_array(arr, channels=reader.channels[: arr.shape[2]],
                                      colour_space=reader.colour_space)


# --------------------------------------------------------------------- diff
def diff_main(argv=None) -> int:
    from . import importers
    from . import diff as diff_mod

    ap = argparse.ArgumentParser(prog="axif-diff", description="Compare two images (SPEC S.80)")
    ap.add_argument("a")
    ap.add_argument("b")
    args = ap.parse_args(argv)

    ca = importers.import_auto(args.a) if not args.a.endswith(".axif") else _axif_to_canonical(args.a)
    cb = importers.import_auto(args.b) if not args.b.endswith(".axif") else _axif_to_canonical(args.b)

    report = diff_mod.compare(ca.array, cb.array)
    print(report)
    return 0


def _axif_to_canonical(path):
    from . import AxifReader
    from . import importers
    r = AxifReader(path)
    c = importers.canonical_from_axif(r)
    r.close()
    return c


# ---------------------------------------------------------------- benchmark
def benchmark_main(argv=None) -> int:
    from . import importers
    from . import benchmark as bench_mod

    ap = argparse.ArgumentParser(prog="axif-benchmark", description="Benchmark AXIF against other codecs (SPEC S.27, S.84)")
    ap.add_argument("file", help="a source image (any supported format) to benchmark")
    ap.add_argument("--roi", help="also benchmark ROI vs full decode once converted to AXIF, format x,y,w,h")
    args = ap.parse_args(argv)

    canonical = importers.import_auto(args.file) if not args.file.endswith(".axif") else _axif_to_canonical(args.file)
    results = bench_mod.compare_against_formats(canonical.array)
    print(bench_mod.results_to_markdown(results, title=f"{args.file}  ({canonical.array.shape}, {canonical.array.dtype})"))

    if args.roi:
        import tempfile
        from . import AxifWriter
        x, y, w, h = (int(v) for v in args.roi.split(","))
        with tempfile.NamedTemporaryFile(suffix=".axif", delete=False) as tf:
            AxifWriter(canonical, tile_width=256, tile_height=256).write(tf.name)
            roi_report = bench_mod.benchmark_roi(tf.name, (x, y, w, h))
            print()
            print(f"ROI benchmark ({x},{y},{w},{h}):")
            print(roi_report)
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="axif", description="AARDVARK XIF toolset")
    sub = ap.add_subparsers(dest="command", required=True)
    for name in ["info", "validate", "convert", "extract", "diff", "benchmark"]:
        sub.add_parser(name)
    args, rest = ap.parse_known_args(argv)
    dispatch = {
        "info": info_main, "validate": validate_main, "convert": convert_main,
        "extract": extract_main, "diff": diff_main, "benchmark": benchmark_main,
    }
    return dispatch[args.command](rest)


if __name__ == "__main__":
    sys.exit(main())
