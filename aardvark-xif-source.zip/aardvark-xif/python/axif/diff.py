"""
axif-diff (SPEC S.80): quantitative comparison between two images (numpy
arrays of the same shape). All metrics here are computed directly from
pixel data with numpy/scipy — nothing is estimated or hard-coded.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.ndimage import uniform_filter


@dataclass
class DiffReport:
    mse: float
    max_abs_error: float
    psnr_db: float           # inf if mse == 0 (byte-exact)
    ssim: float
    mean_delta: float
    identical: bool

    def __str__(self) -> str:
        return (
            f"identical={self.identical}  MSE={self.mse:.6f}  "
            f"PSNR={'inf' if self.psnr_db == float('inf') else f'{self.psnr_db:.2f} dB'}  "
            f"SSIM={self.ssim:.4f}  max|Δ|={self.max_abs_error:.4f}"
        )


def _to_float(a: np.ndarray) -> np.ndarray:
    if np.issubdtype(a.dtype, np.integer):
        return a.astype(np.float64)
    return a.astype(np.float64)


def _dynamic_range(a: np.ndarray, b: np.ndarray) -> float:
    if np.issubdtype(a.dtype, np.integer):
        return float(np.iinfo(a.dtype).max)
    # float image: use the observed max of the reference as the range,
    # a common convention for HDR PSNR since there's no fixed ceiling.
    return float(max(np.max(np.abs(a)), 1e-8))


def _ssim_single_channel(a: np.ndarray, b: np.ndarray, data_range: float, win: int = 7) -> float:
    C1 = (0.01 * data_range) ** 2
    C2 = (0.03 * data_range) ** 2
    a = a.astype(np.float64)
    b = b.astype(np.float64)
    mu_a = uniform_filter(a, win)
    mu_b = uniform_filter(b, win)
    mu_a2, mu_b2, mu_ab = mu_a * mu_a, mu_b * mu_b, mu_a * mu_b
    var_a = uniform_filter(a * a, win) - mu_a2
    var_b = uniform_filter(b * b, win) - mu_b2
    cov_ab = uniform_filter(a * b, win) - mu_ab
    num = (2 * mu_ab + C1) * (2 * cov_ab + C2)
    den = (mu_a2 + mu_b2 + C1) * (var_a + var_b + C2)
    ssim_map = num / den
    return float(np.mean(ssim_map))


def compare(reference: np.ndarray, candidate: np.ndarray) -> DiffReport:
    if reference.shape != candidate.shape:
        raise ValueError(f"shape mismatch: {reference.shape} vs {candidate.shape}")
    ref_f = _to_float(reference)
    cand_f = _to_float(candidate)
    diff = ref_f - cand_f
    mse = float(np.mean(diff * diff))
    max_abs = float(np.max(np.abs(diff)))
    identical = mse == 0.0
    data_range = _dynamic_range(reference, candidate)
    psnr = float("inf") if mse == 0 else 10.0 * np.log10((data_range ** 2) / mse)

    channels = reference.shape[2] if reference.ndim == 3 else 1
    ref3 = reference if reference.ndim == 3 else reference[:, :, None]
    cand3 = candidate if candidate.ndim == 3 else candidate[:, :, None]
    ssim_vals = [
        _ssim_single_channel(ref3[:, :, c], cand3[:, :, c], data_range)
        for c in range(channels)
    ]
    ssim = float(np.mean(ssim_vals))

    return DiffReport(
        mse=mse, max_abs_error=max_abs, psnr_db=psnr, ssim=ssim,
        mean_delta=float(np.mean(np.abs(diff))), identical=identical,
    )
