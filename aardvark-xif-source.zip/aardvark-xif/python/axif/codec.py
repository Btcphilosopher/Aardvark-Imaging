"""
AXIF compression architecture (SPEC S.25-26).

A "codec" here compresses one segment (usually one tile) of raw pixel
samples to bytes and back. Two families exist:

* RAW-SAMPLE codecs (RAW, ZLIB, ZSTD) operate on the flat byte buffer of a
  known dtype/shape; the shape and dtype live in the manifest, not in the
  compressed bytes, so decode() needs them passed in.
* SELF-DESCRIBING codecs (PNG, WEBP, JPEG2000, JPEGXL, EXR) wrap a real,
  independently-maintained open codec via the `imagecodecs` bindings. They
  carry their own shape/dtype and AXIF cross-checks it against the
  manifest's declared geometry on decode.

CODEC_RAW and CODEC_ZLIB are the *core* codecs: every conformant AXIF
decoder MUST implement them (they use only the Python standard library).
Everything else is an *optional* codec per the extension mechanism (SPEC
S.66) — a decoder that lacks the optional dependency raises AxifCodecError
for that segment specifically, and per S.105 can still read the manifest,
thumbnail and any segment stored with a codec it does support.

Nothing here is a placeholder: every codec in CODEC_REGISTRY is exercised
round-trip in tests/test_codecs.py, including a byte-exact lossless check
for the lossless entries.
"""
from __future__ import annotations

import zlib
from dataclasses import dataclass
from typing import Callable, Optional

import numpy as np

from .errors import AxifCodecError

CODEC_RAW = 0
CODEC_ZLIB_LOSSLESS = 1
CODEC_ZSTD_LOSSLESS = 2
CODEC_JPEGXL_LOSSLESS = 10
CODEC_JPEGXL_LOSSY = 11
CODEC_JPEG2000_LOSSLESS = 20
CODEC_JPEG2000_LOSSY = 21
CODEC_WEBP_LOSSY = 30
CODEC_PNG_LOSSLESS = 40
CODEC_EXR_LOSSLESS = 50


@dataclass
class CodecSpec:
    codec_id: int
    name: str
    lossless: bool
    core: bool                      # True => stdlib only, always available
    self_describing: bool           # True => decoder doesn't need external shape/dtype
    encode: Callable
    decode: Callable
    module: Optional[str] = None    # optional runtime dependency, for error messages


# --- RAW ---------------------------------------------------------------
def _raw_encode(array: np.ndarray, **_) -> bytes:
    return np.ascontiguousarray(array).tobytes()


def _raw_decode(data: bytes, *, shape, dtype) -> np.ndarray:
    arr = np.frombuffer(data, dtype=dtype)
    return arr.reshape(shape)


# --- ZLIB (core lossless) ----------------------------------------------
def _zlib_encode(array: np.ndarray, *, level: int = 6, **_) -> bytes:
    return zlib.compress(np.ascontiguousarray(array).tobytes(), level)


def _zlib_decode(data: bytes, *, shape, dtype) -> np.ndarray:
    raw = zlib.decompress(data)
    arr = np.frombuffer(raw, dtype=dtype)
    return arr.reshape(shape)


# --- ZSTD (optional, fast lossless) -------------------------------------
def _zstd_encode(array: np.ndarray, *, level: int = 9, **_) -> bytes:
    try:
        import zstandard
    except ImportError as e:
        raise AxifCodecError("codec ZSTD requires the 'zstandard' package") from e
    cctx = zstandard.ZstdCompressor(level=level)
    return cctx.compress(np.ascontiguousarray(array).tobytes())


def _zstd_decode(data: bytes, *, shape, dtype) -> np.ndarray:
    try:
        import zstandard
    except ImportError as e:
        raise AxifCodecError("codec ZSTD requires the 'zstandard' package") from e
    dctx = zstandard.ZstdDecompressor()
    raw = dctx.decompress(data)
    arr = np.frombuffer(raw, dtype=dtype)
    return arr.reshape(shape)


# --- imagecodecs-backed real adapters -----------------------------------
def _require_imagecodecs():
    try:
        import imagecodecs
        return imagecodecs
    except ImportError as e:
        raise AxifCodecError(
            "this codec requires the optional 'imagecodecs' package"
        ) from e


def _jpegxl_lossless_encode(array: np.ndarray, **_) -> bytes:
    ic = _require_imagecodecs()
    return ic.jpegxl_encode(np.ascontiguousarray(array), lossless=True)


def _jpegxl_lossy_encode(array: np.ndarray, *, quality: float = 90, effort: int = 7, **_) -> bytes:
    ic = _require_imagecodecs()
    return ic.jpegxl_encode(np.ascontiguousarray(array), level=quality, effort=effort, lossless=False)


def _jpegxl_decode(data: bytes, *, shape=None, dtype=None) -> np.ndarray:
    ic = _require_imagecodecs()
    return ic.jpegxl_decode(data)


def _jpeg2000_lossless_encode(array: np.ndarray, **_) -> bytes:
    ic = _require_imagecodecs()
    return ic.jpeg2k_encode(np.ascontiguousarray(array), reversible=True)


def _jpeg2000_lossy_encode(array: np.ndarray, *, quality: float = 80, **_) -> bytes:
    ic = _require_imagecodecs()
    return ic.jpeg2k_encode(np.ascontiguousarray(array), level=quality, reversible=False)


def _jpeg2000_decode(data: bytes, *, shape=None, dtype=None) -> np.ndarray:
    ic = _require_imagecodecs()
    return ic.jpeg2k_decode(data)


def _webp_lossy_encode(array: np.ndarray, *, quality: float = 85, **_) -> bytes:
    ic = _require_imagecodecs()
    return ic.webp_encode(np.ascontiguousarray(array), level=quality)


def _webp_decode(data: bytes, *, shape=None, dtype=None) -> np.ndarray:
    ic = _require_imagecodecs()
    return ic.webp_decode(data)


def _png_encode(array: np.ndarray, **_) -> bytes:
    ic = _require_imagecodecs()
    return ic.png_encode(np.ascontiguousarray(array))


def _png_decode(data: bytes, *, shape=None, dtype=None) -> np.ndarray:
    ic = _require_imagecodecs()
    return ic.png_decode(data)


def _exr_encode(array: np.ndarray, **_) -> bytes:
    ic = _require_imagecodecs()
    arr = np.ascontiguousarray(array)
    if arr.dtype not in (np.float16, np.float32):
        arr = arr.astype(np.float32)
    return ic.exr_encode(arr)


def _exr_decode(data: bytes, *, shape=None, dtype=None) -> np.ndarray:
    ic = _require_imagecodecs()
    return ic.exr_decode(data)


CODEC_REGISTRY = {
    CODEC_RAW: CodecSpec(CODEC_RAW, "AXIF-RAW", True, True, False, _raw_encode, _raw_decode),
    CODEC_ZLIB_LOSSLESS: CodecSpec(
        CODEC_ZLIB_LOSSLESS, "AXIF-ZLIB-LOSSLESS", True, True, False, _zlib_encode, _zlib_decode
    ),
    CODEC_ZSTD_LOSSLESS: CodecSpec(
        CODEC_ZSTD_LOSSLESS, "AXIF-ZSTD-LOSSLESS", True, False, False,
        _zstd_encode, _zstd_decode, module="zstandard",
    ),
    CODEC_JPEGXL_LOSSLESS: CodecSpec(
        CODEC_JPEGXL_LOSSLESS, "JPEGXL-LOSSLESS", True, False, True,
        _jpegxl_lossless_encode, _jpegxl_decode, module="imagecodecs",
    ),
    CODEC_JPEGXL_LOSSY: CodecSpec(
        CODEC_JPEGXL_LOSSY, "JPEGXL-LOSSY", False, False, True,
        _jpegxl_lossy_encode, _jpegxl_decode, module="imagecodecs",
    ),
    CODEC_JPEG2000_LOSSLESS: CodecSpec(
        CODEC_JPEG2000_LOSSLESS, "JPEG2000-LOSSLESS", True, False, True,
        _jpeg2000_lossless_encode, _jpeg2000_decode, module="imagecodecs",
    ),
    CODEC_JPEG2000_LOSSY: CodecSpec(
        CODEC_JPEG2000_LOSSY, "JPEG2000-LOSSY", False, False, True,
        _jpeg2000_lossy_encode, _jpeg2000_decode, module="imagecodecs",
    ),
    CODEC_WEBP_LOSSY: CodecSpec(
        CODEC_WEBP_LOSSY, "WEBP-LOSSY", False, False, True,
        _webp_lossy_encode, _webp_decode, module="imagecodecs",
    ),
    CODEC_PNG_LOSSLESS: CodecSpec(
        CODEC_PNG_LOSSLESS, "PNG-LOSSLESS", True, False, True,
        _png_encode, _png_decode, module="imagecodecs",
    ),
    CODEC_EXR_LOSSLESS: CodecSpec(
        CODEC_EXR_LOSSLESS, "EXR-LOSSLESS-FLOAT", True, False, True,
        _exr_encode, _exr_decode, module="imagecodecs",
    ),
}

CODEC_NAME_TO_ID = {spec.name: cid for cid, spec in CODEC_REGISTRY.items()}


def resolve(codec_id: int) -> CodecSpec:
    try:
        return CODEC_REGISTRY[codec_id]
    except KeyError as e:
        raise AxifCodecError(
            f"unknown codec_id={codec_id}. This decoder does not recognise "
            f"this codec at all (not even well enough to skip it safely); "
            f"per SPEC S.66 an unrecognised MANDATORY segment codec must be "
            f"treated as a version-incompatible file."
        ) from e


def encode(codec_id: int, array: np.ndarray, **params) -> bytes:
    spec = resolve(codec_id)
    try:
        return spec.encode(array, **params)
    except AxifCodecError:
        raise
    except Exception as e:  # pragma: no cover - native codec internal errors
        raise AxifCodecError(f"{spec.name} encode failed: {e}") from e


def decode(codec_id: int, data: bytes, *, shape=None, dtype=None) -> np.ndarray:
    spec = resolve(codec_id)
    try:
        return spec.decode(data, shape=shape, dtype=dtype)
    except AxifCodecError:
        raise
    except Exception as e:  # pragma: no cover
        raise AxifCodecError(f"{spec.name} decode failed: {e}") from e


def is_available(codec_id: int) -> bool:
    spec = resolve(codec_id)
    if spec.core:
        return True
    try:
        __import__(spec.module)
        return True
    except ImportError:
        return False
