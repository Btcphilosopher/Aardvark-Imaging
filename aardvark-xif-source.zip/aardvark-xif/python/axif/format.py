"""
AxifWriter / AxifReader — SPEC S.7 (file structure), S.18-22 (pyramid,
tiling, ROI, random access), S.34-35 (integrity, index), S.67-70
(security, determinism).

Writer strategy (kept deliberately simple and auditable): tiles are
encoded and streamed to a scratch file first (bounded memory regardless of
master image size — this is what makes the 16K streaming fixture possible
on a 4 GB-RAM sandbox), so by the time we build the manifest and index we
already know every segment's final length and can compute all header
offsets analytically in one pass — no placeholder-then-seek-back trick,
and the whole-file SHA-256 in the footer is computed as a single forward
streaming pass while copying the scratch file into the final output.

Reader strategy: header + manifest + index are read once at open() (SPEC
S.35 "index can be loaded before pixel data" / S.106 "self-describing
files"); read_tile/read_region/read_level then do random-access seeks into
the already-open file handle, decoding only the segments actually needed.
Every segment read is bounds-checked and CRC32C-verified before decode
(SPEC S.67), and declared dimensions are checked against ResourceLimits
before any buffer is allocated.
"""
from __future__ import annotations

import json
import math
import os
import tempfile
from dataclasses import dataclass, replace
from typing import Dict, List, Optional, Tuple

import numpy as np

from . import codec
from .checksums import StreamingSHA256, crc32c
from .colour import ColourSpace
from .container import (
    FOOTER_SIZE,
    FORMAT_MAJOR,
    FORMAT_MINOR,
    FORMAT_REVISION,
    FLAG_HAS_INDEX,
    FLAG_PROFILE_ARCHIVAL,
    FLAG_PROFILE_CAMERA,
    FLAG_PROFILE_DELIVERY,
    FLAG_PROFILE_DIGITAL_TWIN,
    FLAG_PROFILE_SCIENTIFIC,
    FLAG_STREAMING_SAFE,
    HEADER_SIZE,
    Header,
    IndexEntry,
    SEGMENT_ICC_PROFILE,
    SEGMENT_NAMES,
    SEGMENT_PREVIEW,
    SEGMENT_THUMBNAIL,
    SEGMENT_TILE,
    pack_footer,
    pack_index,
    unpack_footer,
    unpack_index,
)
from .core import PIXEL_FORMATS, CanonicalImage, ChannelDescriptor
from .errors import (
    AxifChecksumError,
    AxifFormatError,
    AxifSecurityError,
    AxifVersionError,
)
from .metadata import Metadata
from .provenance import Provenance
from .pyramid import Level, PyramidPlan, downsample_box
from .security import (
    DEFAULT_LIMITS,
    ResourceLimits,
    check_bounds,
    check_dimensions,
    check_metadata_size,
    check_segment_count,
    check_segment_expansion,
    check_tile_dims,
    check_total_decode_budget,
)

_PROFILE_FLAGS = {
    "master": 0,
    "core": 0,
    "archival": FLAG_PROFILE_ARCHIVAL,
    "delivery": FLAG_PROFILE_DELIVERY,
    "scientific": FLAG_PROFILE_SCIENTIFIC,
    "camera": FLAG_PROFILE_CAMERA,
    "digital_twin": FLAG_PROFILE_DIGITAL_TWIN,
}


def _max_dim_resize(array: np.ndarray, max_dim: int) -> np.ndarray:
    h, w = array.shape[:2]
    if max(h, w) <= max_dim:
        return array
    scale = max_dim / max(h, w)
    return downsample_box(array, max(1, round(w * scale)), max(1, round(h * scale)))


class AxifWriter:
    def __init__(
        self,
        image: CanonicalImage,
        *,
        tile_width: int = 512,
        tile_height: int = 512,
        codec_id: int = codec.CODEC_ZLIB_LOSSLESS,
        codec_params: Optional[dict] = None,
        level_count: Optional[int] = None,
        profile: str = "master",
        generate_preview: bool = True,
        generate_thumbnail: bool = True,
        preview_max_dim: int = 2048,
        thumbnail_max_dim: int = 256,
        limits: ResourceLimits = DEFAULT_LIMITS,
    ):
        check_dimensions(image.width, image.height, limits)
        check_tile_dims(tile_width, tile_height, limits)
        if profile not in _PROFILE_FLAGS:
            raise ValueError(f"unknown profile {profile!r}; known: {sorted(_PROFILE_FLAGS)}")
        self.image = image
        self.tile_width = tile_width
        self.tile_height = tile_height
        self.codec_id = codec_id
        self.codec_params = codec_params or {}
        self.profile = profile
        self.generate_preview = generate_preview
        self.generate_thumbnail = generate_thumbnail
        self.preview_max_dim = preview_max_dim
        self.thumbnail_max_dim = thumbnail_max_dim
        self.limits = limits
        plan = PyramidPlan(image.width, image.height, tile_width, tile_height,
                            max_levels=level_count or 16)
        self.levels: List[Level] = plan.levels()
        total_tiles = sum(l.tile_count for l in self.levels)
        check_segment_count(total_tiles + 3, limits)
        self._level_cache: Dict[int, np.ndarray] = {}
        if image.array is not None:
            self._level_cache[0] = image.array

    # -- tile production -------------------------------------------------
    def _materialized_level(self, index: int) -> np.ndarray:
        if index not in self._level_cache:
            prev = self._materialized_level(index - 1)
            lvl = self.levels[index]
            self._level_cache[index] = downsample_box(prev, lvl.width, lvl.height)
        return self._level_cache[index]

    def _tile_for_level(self, level: Level, tx: int, ty: int) -> np.ndarray:
        if self.image.tile_source is not None:
            return self.image.get_tile(level.index, tx, ty, level.tile_width, level.tile_height)
        arr = self._materialized_level(level.index)
        y0 = ty * level.tile_height
        x0 = tx * level.tile_width
        return arr[y0: y0 + level.tile_height, x0: x0 + level.tile_width, :]

    def _assemble_level_array(self, level: Level) -> np.ndarray:
        out = np.empty((level.height, level.width, self.image.num_channels), dtype=self.image.dtype)
        for ty in range(level.tiles_y):
            for tx in range(level.tiles_x):
                tile = self._tile_for_level(level, tx, ty)
                y0, x0 = ty * level.tile_height, tx * level.tile_width
                out[y0:y0 + tile.shape[0], x0:x0 + tile.shape[1], :] = tile
        return out

    def _pick_preview_level(self, max_dim: int) -> Level:
        for lvl in self.levels:
            if max(lvl.width, lvl.height) <= max_dim:
                return lvl
        return self.levels[-1]

    def _encode_array(self, arr: np.ndarray, codec_id: int, params: dict) -> Tuple[bytes, int]:
        encoded = codec.encode(codec_id, arr, **params)
        return encoded, arr.nbytes

    def _flags(self) -> int:
        return FLAG_HAS_INDEX | FLAG_STREAMING_SAFE | _PROFILE_FLAGS[self.profile]

    def write(self, path: str) -> "WriteReport":
        scratch_dir = os.path.dirname(os.path.abspath(path)) or "."
        fd, tmp_path = tempfile.mkstemp(dir=scratch_dir, suffix=".axif.scratch")
        os.close(fd)
        index_entries: List[IndexEntry] = []
        cursor = 0
        try:
            with open(tmp_path, "wb") as tmp:
                def emit(segment_type, level, tx, ty, chgroup, cid, payload, raw_len):
                    nonlocal cursor
                    tmp.write(payload)
                    index_entries.append(IndexEntry(
                        segment_type=segment_type, level=level, tile_x=tx, tile_y=ty,
                        channel_group=chgroup, codec_id=cid, offset=cursor,
                        length=len(payload), uncompressed_length=raw_len,
                        crc32c=crc32c(payload),
                    ))
                    cursor += len(payload)

                for level in self.levels:
                    for ty in range(level.tiles_y):
                        for tx in range(level.tiles_x):
                            tile = self._tile_for_level(level, tx, ty)
                            encoded, raw_len = self._encode_array(tile, self.codec_id, self.codec_params)
                            emit(SEGMENT_TILE, level.index, tx, ty, 0, self.codec_id, encoded, raw_len)

                preview_meta = thumbnail_meta = None
                if self.generate_preview or self.generate_thumbnail:
                    preview_level = self._pick_preview_level(self.preview_max_dim)
                    preview_array = self._assemble_level_array(preview_level)
                    aux_codec = (codec.CODEC_PNG_LOSSLESS
                                 if codec.is_available(codec.CODEC_PNG_LOSSLESS)
                                 and self.image.dtype == np.uint8
                                 and self.image.num_channels <= 4
                                 else self.codec_id)
                    if self.generate_preview:
                        enc, raw_len = self._encode_array(preview_array, aux_codec, {})
                        emit(SEGMENT_PREVIEW, 0, 0, 0, 0, aux_codec, enc, raw_len)
                        preview_meta = {"width": int(preview_array.shape[1]),
                                         "height": int(preview_array.shape[0]),
                                         "codec_id": aux_codec}
                    if self.generate_thumbnail:
                        thumb_array = _max_dim_resize(preview_array, self.thumbnail_max_dim)
                        enc2, raw_len2 = self._encode_array(thumb_array, aux_codec, {})
                        emit(SEGMENT_THUMBNAIL, 0, 0, 0, 0, aux_codec, enc2, raw_len2)
                        thumbnail_meta = {"width": int(thumb_array.shape[1]),
                                           "height": int(thumb_array.shape[0]),
                                           "codec_id": aux_codec}

                icc_present = False
                if self.image.colour_space.icc_profile:
                    icc_bytes = self.image.colour_space.icc_profile
                    emit(SEGMENT_ICC_PROFILE, 0, 0, 0, 0, codec.CODEC_RAW, icc_bytes, len(icc_bytes))
                    icc_present = True

            manifest = {
                "axif_manifest_version": 1,
                "format": {"major": FORMAT_MAJOR, "minor": FORMAT_MINOR, "revision": FORMAT_REVISION},
                "profile": self.profile,
                "image": {
                    "width": self.image.width,
                    "height": self.image.height,
                    "pixel_format": self.image.pixel_format,
                    "channels": [c.to_dict() for c in self.image.channels],
                    "tile_width": self.tile_width,
                    "tile_height": self.tile_height,
                    "levels": [l.to_dict() for l in self.levels],
                },
                "colour": self.image.colour_space.to_manifest(),
                "compression": {"codec_id": self.codec_id, "codec_name": codec.resolve(self.codec_id).name},
                "metadata": self.image.metadata.to_manifest(),
                "provenance": self.image.provenance.to_manifest(),
                "preview": preview_meta,
                "thumbnail": thumbnail_meta,
                "has_icc_profile": icc_present,
                "extensions": [],
            }
            manifest_bytes = json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode("utf-8")
            check_metadata_size(len(manifest_bytes), self.limits)
            check_segment_count(len(index_entries), self.limits)

            manifest_offset = HEADER_SIZE
            manifest_length = len(manifest_bytes)
            index_offset = manifest_offset + manifest_length
            index_length = len(index_entries) * 64
            data_offset = index_offset + index_length
            data_length = cursor
            footer_offset = data_offset + data_length
            file_length = footer_offset + FOOTER_SIZE

            rebased = [replace(e, offset=e.offset + data_offset) for e in index_entries]
            index_bytes = pack_index(rebased)
            assert len(index_bytes) == index_length

            header = Header(
                manifest_offset=manifest_offset, manifest_length=manifest_length,
                index_offset=index_offset, index_length=index_length,
                footer_offset=footer_offset, footer_length=FOOTER_SIZE,
                file_length=file_length, flags=self._flags(),
            )
            header_bytes = header.pack()

            sha = StreamingSHA256()
            with open(path, "wb") as out:
                out.write(header_bytes); sha.update(header_bytes)
                out.write(manifest_bytes); sha.update(manifest_bytes)
                out.write(index_bytes); sha.update(index_bytes)
                with open(tmp_path, "rb") as tmp:
                    while True:
                        chunk = tmp.read(4 * 1024 * 1024)
                        if not chunk:
                            break
                        out.write(chunk)
                        sha.update(chunk)
                out.write(pack_footer(sha.digest()))
        finally:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)

        return WriteReport(
            path=path, file_size=file_length, tile_count=len(
                [e for e in index_entries if e.segment_type == SEGMENT_TILE]
            ),
            level_count=len(self.levels), has_preview=bool(preview_meta),
            has_thumbnail=bool(thumbnail_meta),
        )


@dataclass
class WriteReport:
    path: str
    file_size: int
    tile_count: int
    level_count: int
    has_preview: bool
    has_thumbnail: bool


@dataclass
class ValidationReport:
    ok: bool
    issues: List[str]
    segments_checked: int
    segments_total: int

    def __str__(self) -> str:
        status = "VALID" if self.ok else "INVALID"
        lines = [f"{status} ({self.segments_checked}/{self.segments_total} segments checked)"]
        lines += [f"  - {issue}" for issue in self.issues]
        return "\n".join(lines)


class AxifReader:
    def __init__(self, path: str, *, limits: ResourceLimits = DEFAULT_LIMITS,
                 verify_checksums: bool = True):
        self.path = path
        self.limits = limits
        self.verify_checksums = verify_checksums
        self._file_size = os.path.getsize(path)
        if self._file_size > limits.max_file_size_bytes:
            raise AxifSecurityError(
                f"file size {self._file_size} exceeds max_file_size_bytes="
                f"{limits.max_file_size_bytes}"
            )
        if self._file_size < HEADER_SIZE + FOOTER_SIZE:
            raise AxifFormatError("file too small to contain a header and footer")

        self._fh = open(path, "rb")
        self._fh.seek(0)
        header_bytes = self._fh.read(HEADER_SIZE)
        self.header = Header.unpack(header_bytes)
        if self.header.format_major != FORMAT_MAJOR:
            raise AxifVersionError(
                f"file is AXIF format major version {self.header.format_major}, "
                f"this reader implements major version {FORMAT_MAJOR}"
            )

        check_bounds(self.header.manifest_offset, self.header.manifest_length, self._file_size)
        check_metadata_size(self.header.manifest_length, limits)
        self._fh.seek(self.header.manifest_offset)
        manifest_bytes = self._fh.read(self.header.manifest_length)
        try:
            self.manifest = json.loads(manifest_bytes)
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            raise AxifFormatError(f"manifest is not valid UTF-8 JSON: {e}") from e
        if not isinstance(self.manifest, dict) or "image" not in self.manifest:
            raise AxifFormatError("manifest is valid JSON but missing the required 'image' object")

        check_bounds(self.header.index_offset, self.header.index_length, self._file_size)
        self._fh.seek(self.header.index_offset)
        index_bytes = self._fh.read(self.header.index_length)
        entries = unpack_index(index_bytes)
        check_segment_count(len(entries), limits)

        self._entries: Dict[tuple, IndexEntry] = {}
        for e in entries:
            check_bounds(e.offset, e.length, self._file_size)
            self._entries[(e.segment_type, e.level, e.tile_x, e.tile_y, e.channel_group)] = e

        img = self.manifest["image"]
        self.width = img["width"]
        self.height = img["height"]
        self.pixel_format = img["pixel_format"]
        if self.pixel_format not in PIXEL_FORMATS:
            raise AxifFormatError(f"unknown pixel_format {self.pixel_format!r}")
        self.dtype = PIXEL_FORMATS[self.pixel_format]
        check_dimensions(self.width, self.height, limits)
        self.channels = [ChannelDescriptor.from_dict(c) for c in img["channels"]]
        self.tile_width = img["tile_width"]
        self.tile_height = img["tile_height"]
        self._levels = [
            Level(index=d["level"], width=d["width"], height=d["height"],
                  tile_width=d["tile_width"], tile_height=d["tile_height"])
            for d in img["levels"]
        ]

        self.stats = {"tiles_decoded": 0, "bytes_read": 0, "segments_checksum_ok": 0}

        icc = None
        icc_key = (SEGMENT_ICC_PROFILE, 0, 0, 0, 0)
        if icc_key in self._entries:
            icc = self._read_segment_bytes(self._entries[icc_key])
        self.colour_space = ColourSpace.from_manifest(self.manifest.get("colour", {}), icc_profile=icc)
        self.metadata = Metadata.from_manifest(self.manifest.get("metadata", {}))
        self.provenance = Provenance.from_manifest(self.manifest.get("provenance", {}))

    # -- lifecycle --------------------------------------------------------
    def close(self):
        self._fh.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    # -- low-level segment access -----------------------------------------
    def _read_segment_bytes(self, entry: IndexEntry) -> bytes:
        check_bounds(entry.offset, entry.length, self._file_size)
        check_segment_expansion(entry.length, entry.uncompressed_length, self.limits)
        self._fh.seek(entry.offset)
        data = self._fh.read(entry.length)
        if len(data) != entry.length:
            raise AxifFormatError(
                f"truncated segment at offset {entry.offset}: expected "
                f"{entry.length} bytes, file yielded {len(data)}"
            )
        self.stats["bytes_read"] += len(data)
        if self.verify_checksums:
            actual = crc32c(data)
            if actual != entry.crc32c:
                raise AxifChecksumError(
                    f"segment {SEGMENT_NAMES.get(entry.segment_type)} "
                    f"level={entry.level} tile=({entry.tile_x},{entry.tile_y}) "
                    f"CRC32C mismatch: index says {entry.crc32c:#010x}, "
                    f"actual bytes hash to {actual:#010x} — corrupted segment"
                )
            self.stats["segments_checksum_ok"] += 1
        return data

    def level_info(self, level: int = 0) -> Level:
        return self._levels[level]

    @property
    def num_levels(self) -> int:
        return len(self._levels)

    def _tile_shape(self, level: Level, tx: int, ty: int) -> Tuple[int, int]:
        tw = min(level.tile_width, level.width - tx * level.tile_width)
        th = min(level.tile_height, level.height - ty * level.tile_height)
        if tw <= 0 or th <= 0:
            raise AxifFormatError(f"tile ({tx},{ty}) at level {level.index} is out of range")
        return th, tw

    # -- public random-access API (SPEC S.18-22) ---------------------------
    def read_tile(self, level: int, tx: int, ty: int) -> np.ndarray:
        lvl = self._levels[level]
        key = (SEGMENT_TILE, level, tx, ty, 0)
        entry = self._entries.get(key)
        if entry is None:
            raise AxifFormatError(f"no tile segment for level={level} tile=({tx},{ty})")
        data = self._read_segment_bytes(entry)
        th, tw = self._tile_shape(lvl, tx, ty)
        shape = (th, tw, len(self.channels))
        arr = codec.decode(entry.codec_id, data, shape=shape, dtype=self.dtype)
        if arr.ndim == 2:
            # some self-describing codecs (e.g. PNG) drop the trailing
            # axis for single-channel images; restore it so every tile
            # this reader returns is uniformly (H, W, C).
            arr = arr[:, :, None]
        if tuple(arr.shape[:2]) != (th, tw):
            raise AxifFormatError(
                f"decoded tile shape {arr.shape[:2]} does not match manifest "
                f"geometry {(th, tw)} for level={level} tile=({tx},{ty})"
            )
        self.stats["tiles_decoded"] += 1
        return arr

    def read_level(self, level: int = 0) -> np.ndarray:
        lvl = self._levels[level]
        nbytes = lvl.width * lvl.height * len(self.channels) * np.dtype(self.dtype).itemsize
        check_total_decode_budget(nbytes, self.limits)
        out = np.empty((lvl.height, lvl.width, len(self.channels)), dtype=self.dtype)
        for ty in range(lvl.tiles_y):
            for tx in range(lvl.tiles_x):
                tile = self.read_tile(level, tx, ty)
                y0, x0 = ty * lvl.tile_height, tx * lvl.tile_width
                out[y0:y0 + tile.shape[0], x0:x0 + tile.shape[1], :] = tile
        return out

    def to_numpy(self) -> np.ndarray:
        return self.read_level(0)

    def read_region(self, x: int, y: int, width: int, height: int, level: int = 0) -> np.ndarray:
        """SPEC S.21 — decode only the tiles that intersect the requested
        region. Returns an array of shape (height_clamped, width_clamped, C)."""
        lvl = self._levels[level]
        x0, y0 = max(0, x), max(0, y)
        x1, y1 = min(lvl.width, x + width), min(lvl.height, y + height)
        if x1 <= x0 or y1 <= y0:
            return np.zeros((0, 0, len(self.channels)), dtype=self.dtype)
        tx0, ty0 = x0 // lvl.tile_width, y0 // lvl.tile_height
        tx1, ty1 = (x1 - 1) // lvl.tile_width, (y1 - 1) // lvl.tile_height
        out = np.empty((y1 - y0, x1 - x0, len(self.channels)), dtype=self.dtype)
        for ty in range(ty0, ty1 + 1):
            for tx in range(tx0, tx1 + 1):
                tile = self.read_tile(level, tx, ty)
                ty_px, tx_px = ty * lvl.tile_height, tx * lvl.tile_width
                iy0, ix0 = max(y0, ty_px), max(x0, tx_px)
                iy1 = min(y1, ty_px + tile.shape[0])
                ix1 = min(x1, tx_px + tile.shape[1])
                out[iy0 - y0:iy1 - y0, ix0 - x0:ix1 - x0, :] = tile[
                    iy0 - ty_px:iy1 - ty_px, ix0 - tx_px:ix1 - tx_px, :
                ]
        return out

    def read_preview(self) -> Optional[np.ndarray]:
        return self._read_aux(SEGMENT_PREVIEW, "preview")

    def read_thumbnail(self) -> Optional[np.ndarray]:
        return self._read_aux(SEGMENT_THUMBNAIL, "thumbnail")

    def _read_aux(self, segment_type: int, manifest_key: str) -> Optional[np.ndarray]:
        meta = self.manifest.get(manifest_key)
        key = (segment_type, 0, 0, 0, 0)
        if meta is None or key not in self._entries:
            return None
        entry = self._entries[key]
        data = self._read_segment_bytes(entry)
        shape = (meta["height"], meta["width"], len(self.channels))
        arr = codec.decode(entry.codec_id, data, shape=shape, dtype=self.dtype)
        if arr.ndim == 2:
            arr = arr[:, :, None]
        return arr

    # -- introspection / validation ----------------------------------------
    def info(self) -> dict:
        return {
            "format_version": f"{self.header.format_major}.{self.header.format_minor}.{self.header.format_revision}",
            "profile": self.manifest.get("profile"),
            "width": self.width, "height": self.height,
            "channels": [c.name for c in self.channels],
            "pixel_format": self.pixel_format,
            "colour_space": self.colour_space.name,
            "transfer_function": self.colour_space.transfer_function,
            "compression": self.manifest.get("compression", {}).get("codec_name"),
            "tile_size": f"{self.tile_width}x{self.tile_height}",
            "levels": len(self._levels),
            "level_dims": [(l.width, l.height) for l in self._levels],
            "file_size_bytes": self._file_size,
            "has_preview": self.manifest.get("preview") is not None,
            "has_thumbnail": self.manifest.get("thumbnail") is not None,
            "has_icc_profile": self.manifest.get("has_icc_profile", False),
            "metadata_fields": len(self.manifest.get("metadata", {}).get("fields", {})),
            "provenance_stages": len(self.manifest.get("provenance", {}).get("stages", [])),
            "segment_count": len(self._entries),
        }

    def validate(self, strict: bool = False) -> ValidationReport:
        issues: List[str] = []
        self._fh.seek(self.header.footer_offset)
        footer_bytes = self._fh.read(self.header.footer_length)
        try:
            expected_sha = unpack_footer(footer_bytes)
        except AxifFormatError as e:
            issues.append(str(e))
            expected_sha = None

        if expected_sha is not None:
            sha = StreamingSHA256()
            self._fh.seek(0)
            remaining = self.header.footer_offset
            while remaining > 0:
                chunk = self._fh.read(min(4 * 1024 * 1024, remaining))
                if not chunk:
                    issues.append("file truncated before footer_offset")
                    break
                sha.update(chunk)
                remaining -= len(chunk)
            if remaining == 0 and sha.digest() != expected_sha:
                issues.append("whole-file SHA-256 mismatch — file is corrupted or was modified after writing")

        for i, lvl in enumerate(self._levels):
            if i == 0:
                continue
            prev = self._levels[i - 1]
            if lvl.width > prev.width or lvl.height > prev.height:
                issues.append(f"level {i} ({lvl.width}x{lvl.height}) is not <= level {i - 1} ({prev.width}x{prev.height})")

        for lvl in self._levels:
            for ty in range(lvl.tiles_y):
                for tx in range(lvl.tiles_x):
                    if (SEGMENT_TILE, lvl.index, tx, ty, 0) not in self._entries:
                        issues.append(f"missing tile segment: level={lvl.index} tile=({tx},{ty})")

        entries = list(self._entries.values())
        sample = entries if strict else entries[: min(len(entries), 64)]
        checked = 0
        for e in sample:
            try:
                self._read_segment_bytes(e)
                checked += 1
            except Exception as ex:
                issues.append(
                    f"segment {SEGMENT_NAMES.get(e.segment_type, e.segment_type)} "
                    f"level={e.level} tile=({e.tile_x},{e.tile_y}): {ex}"
                )

        return ValidationReport(ok=len(issues) == 0, issues=issues,
                                 segments_checked=checked, segments_total=len(entries))
