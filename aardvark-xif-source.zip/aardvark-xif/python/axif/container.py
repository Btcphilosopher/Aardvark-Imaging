"""
AXIF binary container primitives.

This module is the single source of truth for the byte-level layout
described in SPECIFICATION.md S.4-S.9. Every field referenced there has a
struct format character here; nothing about the physical layout is decided
anywhere else in the codebase. If you change a format string here, bump
FORMAT_MINOR (compatible addition) or FORMAT_MAJOR (breaking) in version.py
and update SPECIFICATION.md's binary layout tables together.

All multi-byte integers are little-endian. There is no implicit struct
padding: every format string below is fully explicit, so Python's `struct`
module (which does not pad '<'-prefixed formats) produces exactly the byte
count documented.
"""
from __future__ import annotations

import struct
from dataclasses import dataclass, field
from typing import Optional

# ---------------------------------------------------------------------------
# Magic signature (SPEC S.8)
#
# Modelled on the well-known "robust binary signature" technique (a
# non-ASCII high-bit byte to catch 7-bit transport, an identifying ASCII
# run, a CR/LF pair to catch newline translation, a DOS EOF byte, a final
# LF to catch the reverse newline translation). The *technique* is a
# publicly documented, format-agnostic engineering practice; the bytes
# below ("AXIF") are Aardvark Imaging's own identifying signature and do
# not collide with any registered image format signature.
# ---------------------------------------------------------------------------
MAGIC = bytes([0x89, 0x41, 0x58, 0x49, 0x46, 0x0D, 0x0A, 0x1A, 0x0A])  # 9 bytes... see below

# NOTE: kept to 8 bytes to match the fixed header layout; see version note
# in SPECIFICATION.md S.8 for why we trimmed the trailing 0x0A relative to
# the 9-byte illustrative form above.
MAGIC = bytes([0x89, 0x41, 0x58, 0x49, 0x46, 0x0D, 0x0A, 0x1A])  # 8 bytes: \x89 A X I F \r \n \x1a

FOOTER_MAGIC = b"AXIFEND1"  # 8 bytes

assert len(MAGIC) == 8
assert len(FOOTER_MAGIC) == 8

# ---------------------------------------------------------------------------
# HEADER — fixed 128 bytes, always at file offset 0.
# ---------------------------------------------------------------------------
#   offset  size  field
#   0       8     magic
#   8       2     format_major        (u16)
#   10      2     format_minor        (u16)
#   12      2     format_revision     (u16)
#   14      2     flags               (u16, bitfield — see FLAG_* below)
#   16      4     header_size         (u32, = 128 in this revision)
#   20      8     manifest_offset     (u64)
#   28      8     manifest_length     (u64)
#   36      8     index_offset        (u64)
#   44      8     index_length        (u64)
#   52      8     footer_offset       (u64)
#   60      8     footer_length       (u64, = 64 in this revision)
#   68      8     file_length         (u64, total file size at write time)
#   76      52    reserved            (zero-filled; extension point)
HEADER_FORMAT = "<8sHHHHI7Q52s"
HEADER_SIZE = struct.calcsize(HEADER_FORMAT)
assert HEADER_SIZE == 128, HEADER_SIZE

FLAG_HAS_INDEX = 1 << 0
FLAG_STREAMING_SAFE = 1 << 1          # manifest+index sufficient to open progressively
FLAG_PROFILE_ARCHIVAL = 1 << 2
FLAG_PROFILE_DELIVERY = 1 << 3
FLAG_PROFILE_SCIENTIFIC = 1 << 4
FLAG_PROFILE_CAMERA = 1 << 5
FLAG_PROFILE_DIGITAL_TWIN = 1 << 6

FORMAT_MAJOR = 1
FORMAT_MINOR = 0
FORMAT_REVISION = 0


@dataclass
class Header:
    format_major: int = FORMAT_MAJOR
    format_minor: int = FORMAT_MINOR
    format_revision: int = FORMAT_REVISION
    flags: int = FLAG_HAS_INDEX | FLAG_STREAMING_SAFE
    header_size: int = HEADER_SIZE
    manifest_offset: int = 0
    manifest_length: int = 0
    index_offset: int = 0
    index_length: int = 0
    footer_offset: int = 0
    footer_length: int = 64
    file_length: int = 0

    def pack(self) -> bytes:
        return struct.pack(
            HEADER_FORMAT,
            MAGIC,
            self.format_major,
            self.format_minor,
            self.format_revision,
            self.flags,
            self.header_size,
            self.manifest_offset,
            self.manifest_length,
            self.index_offset,
            self.index_length,
            self.footer_offset,
            self.footer_length,
            self.file_length,
            b"\x00" * 52,
        )

    @classmethod
    def unpack(cls, data: bytes) -> "Header":
        from .errors import AxifFormatError

        if len(data) < HEADER_SIZE:
            raise AxifFormatError(
                f"truncated header: need {HEADER_SIZE} bytes, got {len(data)}"
            )
        fields = struct.unpack(HEADER_FORMAT, data[:HEADER_SIZE])
        magic = fields[0]
        if magic != MAGIC:
            raise AxifFormatError(
                f"bad magic: expected {MAGIC!r}, got {magic!r} — not an AXIF file"
            )
        (
            _magic,
            major,
            minor,
            revision,
            flags,
            header_size,
            manifest_offset,
            manifest_length,
            index_offset,
            index_length,
            footer_offset,
            footer_length,
            file_length,
            _reserved,
        ) = fields
        return cls(
            format_major=major,
            format_minor=minor,
            format_revision=revision,
            flags=flags,
            header_size=header_size,
            manifest_offset=manifest_offset,
            manifest_length=manifest_length,
            index_offset=index_offset,
            index_length=index_length,
            footer_offset=footer_offset,
            footer_length=footer_length,
            file_length=file_length,
        )


# ---------------------------------------------------------------------------
# INDEX ENTRY — fixed 64 bytes each, packed contiguously in the index block.
# ---------------------------------------------------------------------------
#   offset  size  field
#   0       1     segment_type        (u8  — SEGMENT_* below)
#   1       2     level               (u16 — pyramid level, 0 = master)
#   3       4     tile_x              (u32 — tile column, 0 for non-tiled segments)
#   4       4     tile_y              (u32 — tile row)
#   ...     1     channel_group       (u8  — 0 = all channels interleaved)
#   ...     2     codec_id            (u16 — see codec.py registry)
#   ...     1     flags               (u8  — reserved, 0)
#   ...     8     offset              (u64 — absolute byte offset in file)
#   ...     8     length              (u64 — compressed segment length in bytes)
#   ...     8     uncompressed_length (u64 — decompressed size in bytes; decompression-bomb guard)
#   ...     4     crc32c              (u32 — CRC32C of the compressed bytes)
#   ...     21    reserved
INDEX_ENTRY_FORMAT = "<BHIIBHBQQQI21s"
INDEX_ENTRY_SIZE = struct.calcsize(INDEX_ENTRY_FORMAT)
assert INDEX_ENTRY_SIZE == 64, INDEX_ENTRY_SIZE

SEGMENT_TILE = 0
SEGMENT_PREVIEW = 1
SEGMENT_THUMBNAIL = 2
SEGMENT_AUX_PLANE = 3
SEGMENT_ICC_PROFILE = 4
SEGMENT_EXTENSION = 5
SEGMENT_RAW_SOURCE = 6
SEGMENT_METADATA_BLOB = 7

SEGMENT_NAMES = {
    SEGMENT_TILE: "TILE",
    SEGMENT_PREVIEW: "PREVIEW",
    SEGMENT_THUMBNAIL: "THUMBNAIL",
    SEGMENT_AUX_PLANE: "AUX_PLANE",
    SEGMENT_ICC_PROFILE: "ICC_PROFILE",
    SEGMENT_EXTENSION: "EXTENSION",
    SEGMENT_RAW_SOURCE: "RAW_SOURCE",
    SEGMENT_METADATA_BLOB: "METADATA_BLOB",
}


@dataclass
class IndexEntry:
    segment_type: int
    level: int
    tile_x: int
    tile_y: int
    channel_group: int
    codec_id: int
    offset: int
    length: int
    uncompressed_length: int
    crc32c: int
    flags: int = 0
    # non-serialized convenience key for auxiliary planes / channel groups
    name: Optional[str] = field(default=None, compare=False)

    def pack(self) -> bytes:
        return struct.pack(
            INDEX_ENTRY_FORMAT,
            self.segment_type,
            self.level,
            self.tile_x,
            self.tile_y,
            self.channel_group,
            self.codec_id,
            self.flags,
            self.offset,
            self.length,
            self.uncompressed_length,
            self.crc32c,
            b"\x00" * 21,
        )

    @classmethod
    def unpack(cls, data: bytes) -> "IndexEntry":
        (
            segment_type,
            level,
            tile_x,
            tile_y,
            channel_group,
            codec_id,
            flags,
            offset,
            length,
            uncompressed_length,
            crc,
            _reserved,
        ) = struct.unpack(INDEX_ENTRY_FORMAT, data[:INDEX_ENTRY_SIZE])
        return cls(
            segment_type=segment_type,
            level=level,
            tile_x=tile_x,
            tile_y=tile_y,
            channel_group=channel_group,
            codec_id=codec_id,
            offset=offset,
            length=length,
            uncompressed_length=uncompressed_length,
            crc32c=crc,
            flags=flags,
        )


def pack_index(entries) -> bytes:
    return b"".join(e.pack() for e in entries)


def unpack_index(data: bytes):
    from .errors import AxifFormatError

    if len(data) % INDEX_ENTRY_SIZE != 0:
        raise AxifFormatError(
            f"index block length {len(data)} is not a multiple of "
            f"the {INDEX_ENTRY_SIZE}-byte index entry size"
        )
    n = len(data) // INDEX_ENTRY_SIZE
    return [
        IndexEntry.unpack(data[i * INDEX_ENTRY_SIZE : (i + 1) * INDEX_ENTRY_SIZE])
        for i in range(n)
    ]


# ---------------------------------------------------------------------------
# FOOTER — fixed 64 bytes, always the last 64 bytes of the file.
# ---------------------------------------------------------------------------
#   offset  size  field
#   0       8     footer_magic        (= b"AXIFEND1")
#   8       32    file_sha256         (SHA-256 over bytes [0, footer_offset))
#   40      24    reserved
FOOTER_FORMAT = "<8s32s24s"
FOOTER_SIZE = struct.calcsize(FOOTER_FORMAT)
assert FOOTER_SIZE == 64, FOOTER_SIZE


def pack_footer(file_sha256: bytes) -> bytes:
    assert len(file_sha256) == 32
    return struct.pack(FOOTER_FORMAT, FOOTER_MAGIC, file_sha256, b"\x00" * 24)


def unpack_footer(data: bytes):
    from .errors import AxifFormatError

    if len(data) < FOOTER_SIZE:
        raise AxifFormatError(
            f"truncated footer: need {FOOTER_SIZE} bytes, got {len(data)}"
        )
    magic, digest, _reserved = struct.unpack(FOOTER_FORMAT, data[-FOOTER_SIZE:])
    if magic != FOOTER_MAGIC:
        raise AxifFormatError(f"bad footer magic: {magic!r}")
    return digest
