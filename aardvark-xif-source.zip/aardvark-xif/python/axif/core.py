"""
CanonicalImage (SPEC S.78) — the heart of the interoperability architecture.

Every import adapter (PNG/JPEG/TIFF/OpenEXR/JPEG2000/JPEGXL/WebP/...)
converts its source into a CanonicalImage. Every export adapter converts a
CanonicalImage into its target. AxifWriter/AxifReader consume and produce
CanonicalImage. Nothing in the codebase converts directly between two
foreign formats — the conversion architecture is always

    SOURCE -> DECODER -> CanonicalImage -> AXIF
    AXIF -> CanonicalImage -> TARGET ENCODER -> TARGET FORMAT

per SPEC S.3, never an uncontrolled "format A -> format B" shortcut.

CanonicalImage carries pixels in one of two ways:
  * `array`      — a materialised (H, W, C) numpy array (or (levels-worth
                    of) tiles already resident in memory). Used for images
                    that comfortably fit in RAM (everything a normal
                    PNG/JPEG/TIFF import produces).
  * `tile_source` — a callable(level, tile_x, tile_y, tile_w, tile_h) ->
                    np.ndarray, used for master images that must never be
                    fully materialised (SPEC S.5: "do not design AXIF
                    around the assumption the entire decoded image should
                    always exist in RAM"). AxifWriter calls this once per
                    tile per level and never holds more than a few tiles
                    at once. See axif.pyramid.ProceduralTileSource for a
                    concrete example used by the 16K streaming test
                    fixture.

Exactly one of `array` / `tile_source` is set.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, List, Optional

import numpy as np

from .colour import ColourSpace, srgb
from .metadata import Metadata
from .provenance import Provenance

# --- pixel formats (SPEC S.11) ------------------------------------------
PIXEL_FORMATS = {
    "UINT8": np.dtype("uint8"),
    "UINT16": np.dtype("uint16"),
    "UINT32": np.dtype("uint32"),
    "FLOAT16": np.dtype("float16"),
    "FLOAT32": np.dtype("float32"),
}
DTYPE_TO_PIXEL_FORMAT = {v: k for k, v in PIXEL_FORMATS.items()}


@dataclass
class ChannelDescriptor:
    """SPEC S.12 — a channel is not assumed to be R/G/B/A."""
    name: str
    semantic: str = ""            # e.g. "red", "depth", "thermal_temperature"
    unit: Optional[str] = None    # e.g. "meters", "kelvin", "nanometers"
    colour_association: Optional[str] = None  # "RGB" | "CMYK" | None (aux plane)
    range: Optional[tuple] = None

    def to_dict(self) -> dict:
        return dict(
            name=self.name, semantic=self.semantic, unit=self.unit,
            colour_association=self.colour_association, range=self.range,
        )

    @classmethod
    def from_dict(cls, d: dict) -> "ChannelDescriptor":
        return cls(
            name=d["name"], semantic=d.get("semantic", ""), unit=d.get("unit"),
            colour_association=d.get("colour_association"),
            range=tuple(d["range"]) if d.get("range") else None,
        )


def rgb_channels() -> List[ChannelDescriptor]:
    return [
        ChannelDescriptor("R", "red", colour_association="RGB"),
        ChannelDescriptor("G", "green", colour_association="RGB"),
        ChannelDescriptor("B", "blue", colour_association="RGB"),
    ]


def rgba_channels() -> List[ChannelDescriptor]:
    return rgb_channels() + [ChannelDescriptor("A", "alpha", colour_association="RGB")]


def gray_channels() -> List[ChannelDescriptor]:
    return [ChannelDescriptor("Y", "luminance", colour_association="GRAY")]


TileSourceFn = Callable[[int, int, int, int, int], np.ndarray]
# signature: (level, tile_x, tile_y, tile_w, tile_h) -> ndarray[tile_h, tile_w, C]


@dataclass
class CanonicalImage:
    width: int
    height: int
    channels: List[ChannelDescriptor]
    dtype: np.dtype
    array: Optional[np.ndarray] = None
    tile_source: Optional[TileSourceFn] = None
    colour_space: ColourSpace = field(default_factory=srgb)
    metadata: Metadata = field(default_factory=Metadata)
    provenance: Provenance = field(default_factory=Provenance)

    def __post_init__(self):
        if (self.array is None) == (self.tile_source is None):
            raise ValueError(
                "CanonicalImage requires exactly one of `array` or `tile_source`"
            )
        if self.array is not None:
            if self.array.ndim != 3:
                raise ValueError("array must be (H, W, C)")
            h, w, c = self.array.shape
            if (h, w) != (self.height, self.width):
                raise ValueError(
                    f"array shape {(h, w)} does not match declared "
                    f"{(self.height, self.width)}"
                )
            if c != len(self.channels):
                raise ValueError(
                    f"array has {c} channels but {len(self.channels)} "
                    f"ChannelDescriptors were given"
                )
            if self.array.dtype != self.dtype:
                raise ValueError(
                    f"array dtype {self.array.dtype} != declared dtype {self.dtype}"
                )

    @property
    def num_channels(self) -> int:
        return len(self.channels)

    @property
    def pixel_format(self) -> str:
        return DTYPE_TO_PIXEL_FORMAT[np.dtype(self.dtype)]

    def get_tile(self, level: int, tx: int, ty: int, tw: int, th: int) -> np.ndarray:
        """Fetch one tile at (level, tx, ty) sized up to tw x th (edge tiles
        may be smaller). This is the single choke point AxifWriter uses,
        whether backed by an in-memory array or a true streaming source."""
        if self.tile_source is not None:
            return self.tile_source(level, tx, ty, tw, th)
        # in-memory master (level 0 only reachable this way; pyramid.py
        # handles downsampling for level > 0 via PyramidPlan)
        assert self.array is not None
        y0 = ty * th
        x0 = tx * tw
        y1 = min(y0 + th, self.height)
        x1 = min(x0 + tw, self.width)
        return self.array[y0:y1, x0:x1, :]

    @classmethod
    def from_array(
        cls,
        array: np.ndarray,
        *,
        channels: Optional[List[ChannelDescriptor]] = None,
        colour_space: Optional[ColourSpace] = None,
        metadata: Optional[Metadata] = None,
        provenance: Optional[Provenance] = None,
    ) -> "CanonicalImage":
        if array.ndim == 2:
            array = array[:, :, None]
        h, w, c = array.shape
        if channels is None:
            channels = {1: gray_channels, 3: rgb_channels, 4: rgba_channels}.get(c)
            if channels is None:
                channels = [ChannelDescriptor(f"C{i}") for i in range(c)]
            else:
                channels = channels()
        return cls(
            width=w, height=h, channels=channels, dtype=array.dtype,
            array=np.ascontiguousarray(array),
            colour_space=colour_space or srgb(),
            metadata=metadata or Metadata(),
            provenance=provenance or Provenance(),
        )
