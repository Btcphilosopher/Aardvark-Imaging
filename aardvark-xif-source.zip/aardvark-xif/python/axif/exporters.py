"""
Export adapters (SPEC S.3, S.75). The mirror image of importers.py: every
function here takes a CanonicalImage and calls a real target codec. The
export pipeline is explicit about every transform it applies — SPEC S.75
("AXIF -> colour transform -> resize -> tone map -> alpha handling ->
compression -> target format", S.132 "no destructive silent operations") —
so exporters never silently drop an alpha channel, reduce bit depth, or
tone-map HDR to fit an 8-bit target; where a target format cannot
represent the source faithfully, the function raises AxifCodecError
naming exactly what would have to change, rather than downgrading quietly.
"""
from __future__ import annotations

import inspect
import os

import numpy as np

from .core import CanonicalImage
from .errors import AxifCodecError


def _require_dtype(image: CanonicalImage, allowed, target_name: str):
    if image.dtype not in allowed:
        raise AxifCodecError(
            f"{target_name} export requires dtype in {[str(d) for d in allowed]}, "
            f"image is {image.dtype}. Explicitly convert/quantise first — "
            f"AXIF does not silently reduce bit depth on export (SPEC S.132)."
        )


def export_png(image: CanonicalImage, path: str) -> str:
    import imagecodecs
    _require_dtype(image, (np.dtype("uint8"), np.dtype("uint16")), "PNG")
    arr = image.array
    if arr is None:
        raise AxifCodecError("export requires a materialised array; call reader.to_numpy() first")
    if arr.shape[2] == 1:
        arr = arr[:, :, 0]
    data = imagecodecs.png_encode(arr)
    with open(path, "wb") as f:
        f.write(data)
    return path


def export_jpeg(image: CanonicalImage, path: str, quality: int = 92) -> str:
    import imagecodecs
    _require_dtype(image, (np.dtype("uint8"),), "JPEG")
    arr = image.array
    if arr.shape[2] == 4:
        raise AxifCodecError(
            "JPEG has no alpha channel; export would silently discard it. "
            "Drop the alpha channel explicitly (e.g. image.array[..., :3]) "
            "before calling export_jpeg."
        )
    if arr.shape[2] == 1:
        arr = arr[:, :, 0]
    data = imagecodecs.jpeg8_encode(arr, level=quality)
    with open(path, "wb") as f:
        f.write(data)
    return path


def export_tiff(image: CanonicalImage, path: str) -> str:
    import tifffile
    arr = image.array
    tifffile.imwrite(path, arr, photometric="rgb" if arr.shape[2] >= 3 else "minisblack")
    return path


def export_exr(image: CanonicalImage, path: str) -> str:
    import imagecodecs
    arr = image.array
    if arr.dtype not in (np.dtype("float16"), np.dtype("float32")):
        raise AxifCodecError(
            f"OpenEXR export expects float16/float32 scene data, got {arr.dtype}. "
            f"Convert explicitly (this is a numeric reinterpretation, not a "
            f"lossless re-encode, so AXIF will not do it implicitly)."
        )
    data = imagecodecs.exr_encode(arr)
    with open(path, "wb") as f:
        f.write(data)
    return path


def export_webp(image: CanonicalImage, path: str, quality: int = 90) -> str:
    import imagecodecs
    _require_dtype(image, (np.dtype("uint8"),), "WebP")
    data = imagecodecs.webp_encode(image.array, level=quality)
    with open(path, "wb") as f:
        f.write(data)
    return path


def export_jpeg2000(image: CanonicalImage, path: str, *, lossless: bool = True, quality: float = 80) -> str:
    import imagecodecs
    data = imagecodecs.jpeg2k_encode(image.array, reversible=lossless,
                                      level=None if lossless else quality)
    with open(path, "wb") as f:
        f.write(data)
    return path


def export_jpegxl(image: CanonicalImage, path: str, *, lossless: bool = True, quality: float = 90) -> str:
    import imagecodecs
    data = imagecodecs.jpegxl_encode(image.array, lossless=lossless,
                                      level=None if lossless else quality)
    with open(path, "wb") as f:
        f.write(data)
    return path


_EXT_DISPATCH = {
    "png": export_png,
    "jpg": export_jpeg, "jpeg": export_jpeg,
    "tif": export_tiff, "tiff": export_tiff,
    "exr": export_exr,
    "webp": export_webp,
    "jp2": export_jpeg2000, "j2k": export_jpeg2000,
    "jxl": export_jpegxl,
}


def export_auto(image: CanonicalImage, path: str, **kwargs) -> str:
    ext = os.path.splitext(path)[1].lower().lstrip(".")
    fn = _EXT_DISPATCH.get(ext)
    if fn is None:
        raise AxifCodecError(
            f"no export adapter for extension '.{ext}'. Supported: "
            f"{sorted(set(_EXT_DISPATCH))}"
        )
    accepted = set(inspect.signature(fn).parameters)
    filtered = {k: v for k, v in kwargs.items() if k in accepted}
    return fn(image, path, **filtered)
