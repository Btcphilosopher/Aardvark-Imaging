# Third-Party Notices

This repository's own code is Apache-2.0 (see `LICENSE`). It depends on
the following third-party packages, none of which are vendored or
modified — they're used as ordinary dependencies. Always verify current
license terms against each project's own repository before redistributing
anything built on top of this code; the summary below reflects the
versions pinned in `pyproject.toml` at the time this repository was built
and is not a substitute for your own license review.

| Package | Used for | License |
|---|---|---|
| [NumPy](https://numpy.org/) | array/pixel-buffer core throughout | BSD-3-Clause |
| [Pillow](https://python-pillow.org/) | EXIF/ICC/XMP metadata extraction, a few format helpers | HPND (historical PIL license; permissive, MIT-style) |
| [tifffile](https://github.com/cgohlke/tifffile) | TIFF import/export | BSD-3-Clause |
| [imagecodecs](https://github.com/cgohlke/imagecodecs) | JPEG, PNG, WebP, JPEG 2000, JPEG XL, OpenEXR, AVIF, HEIF codec bindings | BSD-3-Clause |
| [zstandard](https://github.com/indygreg/python-zstandard) (optional) | `AXIF-ZSTD-LOSSLESS` codec | BSD-3-Clause |
| [crc32c](https://github.com/ICRAR/crc32c) (optional) | fast native CRC32C | **LGPL-2.1-or-later** |
| [SciPy](https://scipy.org/) | SSIM windowed filtering in `axif.diff` | BSD-3-Clause |
| [pytest](https://pytest.org/) (dev only) | test suite | MIT |

## A note on `crc32c`

Every other dependency above is permissively licensed (BSD/MIT/HPND) and
imposes no meaningful obligation on downstream use. `crc32c` is the one
exception — it's LGPL-2.1-or-later, which carries different obligations
(e.g. around static linking and redistribution) than the rest of this
dependency tree. This is exactly why `axif/checksums.py` ships a
pure-Python CRC32C implementation and only imports the native `crc32c`
package as an optional accelerator: **`AXIF-RAW` and
`AXIF-ZLIB-LOSSLESS`, the two mandatory core codecs every conformant
decoder must implement (SPECIFICATION.md §8), never require the LGPL
dependency at all.** If the LGPL terms are a problem for a given
deployment, uninstalling `crc32c` doesn't remove any required
functionality — checksums are still computed, just via the pure-Python
fallback (`tests/test_checksums.py::test_pure_python_fallback_matches_reference_vectors`
verifies it against the standard CRC-32C check value independently of
whether the native package is present).

## No patent claims made

Per SPEC S.125, this repository makes no "patent-free" claim about any
codec it wraps. JPEG 2000 and JPEG XL both have documented patent
licensing histories worth your own review if that matters for your use
case — this project neither asserts nor waives anything about them; it
only calls the codecs through the libraries above, unmodified.
