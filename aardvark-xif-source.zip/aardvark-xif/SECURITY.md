# Security

AXIF treats every file it opens as **hostile input** (SPEC S.67), whether
it arrived from a camera, a colleague, or the internet. This document
states the threat model, the specific guards in `python/axif/security.py`,
and how to verify them.

## Threat model

An attacker controls the entire byte content of a `.axif` file (or a file
claiming to be one) that a victim opens with `axif.open()`. The attacker's
goals, and this library's response to each:

| Goal | Guard |
|---|---|
| Crash the process / DoS via huge allocation | `width`/`height`/pixel-count/tile-size/segment-count/metadata-size ceilings, checked **before** allocation (`ResourceLimits`, all in `security.py`) |
| Decompression bomb (tiny compressed bytes claiming a huge decoded size) | `check_segment_expansion()` rejects a segment whose declared `uncompressed_length` exceeds the configured ceiling, or whose expansion ratio is implausible for its size, **before** the codec's decompressor runs |
| Out-of-bounds read via a crafted offset/length | `check_bounds()` verifies `offset + length <= file_size` for every header field and every index entry, with explicit overflow-safe arithmetic, before any `seek`/`read` |
| Silently-corrupted pixel data | Every segment's CRC32C is verified before its bytes are handed to a codec; a mismatch raises `AxifChecksumError` rather than returning wrong pixels |
| Undetected tampering with a validated file | `axif-validate` / `AxifReader.validate()` recomputes the whole-file SHA-256 and compares it to the footer |
| Confuse the decoder about format version | `format_major` is checked immediately after the header is parsed, before the manifest is even read; a mismatch is `AxifVersionError` |
| Malformed/non-UTF-8 manifest, missing required keys | Caught explicitly (`json.JSONDecodeError` **and** `UnicodeDecodeError` — a real bug found in testing, see CHANGELOG.md) and turned into `AxifFormatError` |
| Unknown pixel format / codec ID | Explicit allow-list lookups (`PIXEL_FORMATS`, `CODEC_REGISTRY`); anything else is `AxifFormatError`/`AxifCodecError`, never a silent guess |

## What "fails safely" means here, concretely

Every corrupt/malformed fixture in `test-vectors/corrupt/` and every
scenario in `tests/test_security.py` ends in exactly one of:

1. A specific, typed `AxifError` subclass, with a message naming what was
   wrong — never an unhandled `struct.error`, `MemoryError`,
   `UnicodeDecodeError`, or similar "leaked" Python exception, and never a
   silent wrong answer.
2. A `ValidationReport` from `.validate()` with `ok=False` and specific
   `issues` — for cases where opening the file (reading its manifest) is
   itself still possible, but its content is wrong.

Concretely tested, not just claimed (see `tests/test_security.py`):
corrupted magic bytes, a corrupted manifest (non-UTF-8 bytes injected),
a corrupted tile (CRC32C mismatch caught before decode), a file truncated
after the header, a file truncated mid-data-region (index entries point
past EOF), a crafted manifest declaring 999,999,999 × 999,999,999
dimensions, negative dimensions, an unknown `pixel_format` string, and a
crafted index entry claiming a 50 GB decompressed tile from a 100-byte
compressed payload (the decompression-bomb shape).

## Default limits (`ResourceLimits`, `security.py`)

```
max_width / max_height        100,000 px
max_pixels                    2,000,000,000  (~2 gigapixels)
max_decoded_segment_bytes     2 GiB   (per-segment decompress ceiling)
max_total_decoded_bytes       8 GiB   (whole-file to_numpy() ceiling)
max_metadata_bytes            64 MiB
max_tile_dim                  8,192 px
max_segment_count             2,000,000
max_file_size_bytes           200 GiB
max_expansion_ratio           10,000×  (combined with the segment-bytes ceiling above)
```

These are generous enough for a real 16K master with headroom, and are
every one of them a constructor argument — pass a stricter
`ResourceLimits` to `axif.open(path, limits=...)` for a context that needs
tighter bounds (e.g. a server accepting untrusted uploads), or
`ResourceLimits.permissive()` for internal tooling that deliberately
builds very large, valid files (used by the 16K fixture generator).

## Fuzzing (SPEC S.83) — current status, stated honestly

This repository does not include a `cargo-fuzz` harness (no Rust core
exists yet — see ROADMAP.md). What it does include:

- `tests/test_security.py` and `tests/test_conformance.py` exercise
  structured "hostile shapes" (bad magic, bad manifest bytes, truncation,
  oversized declared dimensions, the decompression-bomb shape) rather
  than only well-formed files.
- Every corrupt fixture is asserted to raise a clean `AxifError` — never
  hang, never crash the interpreter, never return silently-wrong pixels.

A genuine coverage-guided fuzzer (e.g. Python's `atheris`, or a
`cargo-fuzz` harness once a Rust core exists) is on the roadmap and would
be strictly additive to, not a replacement for, the structured tests
above — see ROADMAP.md.

## Reporting

This is a reference implementation produced for a single engineering
exercise, not a monitored public project — there is no dedicated security
contact. Treat findings the way you would for any vendored code you've
adopted into your own project: review before trusting with untrusted
input, and patch forward under your own process.
