# Roadmap

This follows the phased implementation order the format brief itself
specifies (its §136): container and interoperability first, native codec
research only after benchmarking, hardware/product integration last. What
below is marked **done** was built and tested in this repository, in this
session; everything else is future work, stated as such rather than
shipped as a non-functional placeholder.

## Done

- Phases 1–8 (specification, `CanonicalImage`, binary container,
  header/manifest/index, tile engine, metadata, colour system, PNG/JPEG
  import-export) — SPECIFICATION.md, ARCHITECTURE.md, `python/axif/`.
- Phase 9 (TIFF) — `tifffile`-backed, 16-bit verified byte-exact.
- Phase 10 (OpenEXR) — `imagecodecs`-backed, float16/float32 verified
  byte-exact lossless.
- Phase 11 (JPEG XL) — lossless and lossy, including 16-bit and float32
  lossless, byte-exact verified.
- Phase 12 (JPEG 2000) — lossless (reversible transform) and lossy,
  byte-exact verified for lossless.
- Phase 13 (progressive pyramids) — done, streaming-safe (manifest+index
  before pixel data).
- Phase 14 (ROI decoding) — done, measured 40x speedup / 95.7% fewer
  bytes on the real 16K fixture (`docs/BENCHMARKS.md`).
- Phase 15 ("16K viewer") — a real deep-zoom *prototype* (`viewer/`), not
  the full desktop application; see "Not done" below.
- Phase 16 (Python bindings) — this *is* the reference implementation,
  not a binding on top of something else.
- Phase 18 (AI tensor integration) — numpy arrays out of every read path;
  no separate tensor layer was built (see below).
- Phase 20 (performance benchmarking) — `docs/BENCHMARKS.md`, measured on
  this session's sandbox.
- Phase 21 (security hardening) — `SECURITY.md`, `security.py`, exercised
  against real corrupt fixtures.
- Phase 22 (fuzzing) — partial: structured hostile-input tests, not a
  coverage-guided fuzzer (see SECURITY.md).
- Phase 23 (conformance suite) — `test-vectors/conformance/` +
  `tests/test_conformance.py`.

## Not done, and specifically why

**Phase 17 — C ABI.** Needs a Rust or C core to export; see Phase 24/25
below. The wire format (SPECIFICATION.md) was deliberately kept
C-ABI-friendly (flat structs, explicit little-endian offsets, no
pointers, no compiler-dependent padding) so that building the ABI is a
mechanical translation of `container.py`'s struct definitions, not a
redesign.

**Phase 19 — camera/LiDAR/thermal/hyperspectral hardware integration.**
This requires an actual Aardvark camera/sensor pipeline to integrate
with, which doesn't exist to integrate against in this exercise. What
*is* built and ready for that integration: the `ChannelDescriptor` model
already supports arbitrary named channels with units (SPEC S.12, S.62)
— a depth-in-metres or temperature-in-kelvin channel is not a special
case, just a `ChannelDescriptor(unit="meters", ...)` — and
`AxifWriter`'s `tile_source` callable is exactly the seam a real sensor
driver would plug into (see ARCHITECTURE.md's streaming section).

**Phase 24 — Rust core.** No Rust toolchain was available in the sandbox
this was built in (`cargo` not found; installing a full toolchain plus
building `pyo3`/codec bindings from source was judged out of scope for
this session's time budget versus finishing the Python reference
implementation properly). This is the single largest deferred item.
When a toolchain is available, `python/axif/container.py` and
`format.py` are the two files to port first — they contain the entire
wire-format contract; `codec.py`'s adapter *interfaces* would map onto
Rust crates for the same underlying C libraries (`jpeg-xl`, `openjpeg`,
etc.) that `imagecodecs` already wraps in Python.

**GPU backends (Vulkan/Metal/CUDA/WebGPU).** No GPU was available in the
build environment. The tile/segment layout (independently-compressed,
fixed-shape buffers) doesn't need redesigning for GPU upload — there's
just no code that does it yet.

**A coverage-guided fuzzer (`cargo-fuzz` or `atheris`).** See
SECURITY.md — structured hostile-input tests exist and pass; genuine
fuzzing wasn't set up this session.

**The full desktop viewer** (histogram/waveform/RGB-parade/false-colour/
pixel-inspector/layers/before-after compare, SPEC S.46-50). `viewer/`
ships a real, working deep-zoom pan/zoom prototype built from genuinely
decoded tiles of the real 16K file — a meaningful fraction of the
"16K images are navigable, not monolithic" demonstration, not the
full professional imaging application.

**Multi-image containers / auxiliary planes as separate segments** (SPEC
S.37-39, S.62): the segment types (`AUX_PLANE`, `RAW_SOURCE`) are
reserved in the binary format (SPECIFICATION.md §6) but the encoder
doesn't emit them yet — today, additional channels (depth, thermal,
multispectral bands) are represented as extra interleaved channels in
one image via `ChannelDescriptor`, which covers the *data model* (SPEC
S.12, S.38-39) but not yet "a stereo pair as two related images in one
file" or "the original camera-RAW bytes archived alongside the processed
master."

**Digital-twin / measurement-metadata integration** (SPEC S.63, S.130-131)
and **content-authenticity signing** (SPEC S.33): the `Provenance` model
has the right shape (a signature/certificate-reference slot exists) but
no actual Ed25519 signing workflow or digital-twin object-graph linkage
is implemented — both are integration work against systems that don't
exist in this exercise.

## The native codec (AXC) decision

SPEC S.26/S.137 are explicit: build the interoperable container first,
benchmark honestly, and only build a native codec if the benchmarks show
an established one can't be beaten on a *stated objective*. That
benchmarking happened (`docs/BENCHMARKS.md`) and the honest reading of it
is: **no case for AXC yet.**

Specifically — on the four real content bands measured, JPEG XL lossless
wins three of four outright (up to 1892x on the architecture band), and
loses to plain zlib on the fourth (the adversarial high-frequency
grating, 1.82x vs. 2.87x) — a genuine codec-*selection* problem, not a
compression-*ratio* problem a new transform would obviously fix. Nothing
in this benchmark run suggests a bespoke Aardvark transform would beat
JPEG XL/JPEG 2000 on their strong cases, and the one case where they
underperform (adversarial high-frequency content) is already handled
correctly by AXIF's *existing* pluggable-codec architecture — pick zstd/
zlib for that tile instead, which the format already supports today. If a
concrete future need appears that these codecs genuinely can't serve
(e.g. a real-time hardware encode constraint on Aardvark camera silicon,
which is a *latency-under-a-fixed-power-budget* objective these
general-purpose libraries weren't optimised for), that would be a
legitimate, narrow reason to revisit — evaluated then, against a stated
objective, exactly as SPEC S.137 says, not spent speculatively now.
