# AARDVARK XIF — Format Specification

**AARDVARK Extended Image Format (AXIF)**, revision 1.0.0
File extension: `.axif` &nbsp;·&nbsp; Status: reference implementation, this repository

AXIF is an independent Aardvark Imaging container format. It is not an
ISO, JPEG, Adobe, Apple, NVIDIA, or OpenEXR format, is not affiliated with
any of those organizations, and makes no claim to be the first format to
support any individual feature listed below — JPEG XL, JPEG 2000, and
OpenEXR already cover most of this ground individually. AXIF's reason to
exist is architectural: one container that holds a master image, its
pyramid, its tiles, its previews, and its full provenance/metadata as one
self-describing, randomly-accessible, streaming-friendly object, with a
pluggable compression layer instead of one fixed codec.

---

## 1. Scope

This document specifies the AXIF binary container: byte layout, the
manifest schema, the tile index, checksums, and the rules a conformant
decoder must follow. It does not specify the pixel encoding of any
individual *codec* AXIF can carry (RAW, zlib, JPEG XL, JPEG 2000, WebP,
PNG, OpenEXR) — those are specified by their own upstream standards; AXIF
only specifies which codec was used and where its bytes live.

## 2. Terminology

- **Master image** — the full-resolution pixel data (pyramid level 0).
- **Level** — one entry in the image pyramid; level 0 is the master,
  each subsequent level is a ~2× box-downsampled version of the one
  before it, down to a level no larger than one tile.
- **Tile** — a rectangular block of one level, `tile_width` × `tile_height`
  samples (the last row/column of tiles in a level may be smaller —
  "edge tiles" — when the level's dimensions aren't an exact multiple of
  the tile size).
- **Segment** — any one length-prefixed, checksummed, independently
  compressed blob in the file: a tile, the preview, the thumbnail, an
  embedded ICC profile, or a future extension payload.
- **Manifest** — the single UTF-8 JSON document describing the image's
  geometry, channels, colour, compression, metadata and provenance.
- **Index** — the flat table of fixed-size records that locates every
  segment in the file by byte offset and length.

## 3. Conformance profiles

A manifest declares a `profile`: `master`, `archival`, `delivery`,
`scientific`, `camera`, `digital_twin`, or the unmarked default `core`.
Profiles are a *labelling and defaults* convention layered on top of one
wire format — every AXIF decoder that implements this specification can
open every profile; a profile only signals what the *encoder* optimised
for (see ARCHITECTURE.md §Profiles). A corresponding bit is set in the
header `flags` field (§5) purely so a reader can filter files by profile
without parsing the manifest.

## 4. Byte order, integers, strings

- All multi-byte integers are **little-endian**.
- `uN` below means an unsigned N-bit integer.
- All fixed-size struct fields are packed with **no implicit padding**
  (equivalent to Python's `struct` module with a `<` byte-order prefix, or
  `#[repr(C, packed)]` with explicit field order in Rust/C — a conformant
  implementation must not rely on natural alignment).
- The manifest and any UTF-8 text fields are exactly UTF-8, no BOM.

## 5. File layout

```
┌──────────────────────────────┐  offset 0
│ HEADER            (128 bytes, fixed)
├──────────────────────────────┤  header.manifest_offset
│ MANIFEST           (UTF-8 JSON, header.manifest_length bytes)
├──────────────────────────────┤  header.index_offset
│ INDEX              (header.index_length bytes = 64 × segment_count)
├──────────────────────────────┤  data_offset (first entry.offset)
│ DATA SEGMENTS       (tiles, preview, thumbnail, ICC profile, ...)
├──────────────────────────────┤  header.footer_offset
│ FOOTER             (64 bytes, fixed)
└──────────────────────────────┘  header.file_length
```

The four regions do not have to be physically contiguous or in this exact
order — every region is located by an explicit offset/length pair in the
header — but the reference encoder always writes them in this order so
that a client reading the file over HTTP with a small number of range
requests (header, then manifest+index in one request) can begin
progressive display before the data region has downloaded (SPEC S.43,
S.106; header flag `STREAMING_SAFE`, §5.2).

### 5.1 HEADER (128 bytes, always at offset 0)

| Offset | Size | Field             | Type | Notes |
|-------:|-----:|-------------------|------|-------|
| 0      | 8    | `magic`           | bytes | `89 41 58 49 46 0D 0A 1A` |
| 8      | 2    | `format_major`    | u16 | incompatible structural changes bump this |
| 10     | 2    | `format_minor`    | u16 | backwards-compatible additions |
| 12     | 2    | `format_revision` | u16 | clarifications / bugfixes, no wire change |
| 14     | 2    | `flags`           | u16 | bitfield, §5.2 |
| 16     | 4    | `header_size`     | u32 | = 128 in this revision |
| 20     | 8    | `manifest_offset` | u64 | |
| 28     | 8    | `manifest_length` | u64 | |
| 36     | 8    | `index_offset`    | u64 | |
| 44     | 8    | `index_length`    | u64 | = 64 × segment_count |
| 52     | 8    | `footer_offset`   | u64 | |
| 60     | 8    | `footer_length`   | u64 | = 64 in this revision |
| 68     | 8    | `file_length`     | u64 | total file size at write time |
| 76     | 52   | `reserved`        | bytes | zero-filled; extension point for future header fields without breaking offset 0 |

**Magic rationale**: `0x89` is a non-ASCII, high-bit-set byte (catches
7-bit-clean transports mangling the file), `AXIF` is the human-readable
identifier, `0x0D 0x0A` is a CRLF pair (catches LF↔CRLF newline
translation), `0x1A` is the DOS EOF byte (catches truncation by tools that
stop at Ctrl-Z). This is the same general signature-hardening technique
used by several well-known binary formats; AXIF's own 8 bytes do not
collide with any registered image format signature.

#### 5.2 `flags` bitfield

| Bit | Name | Meaning |
|----:|------|---------|
| 0 | `HAS_INDEX` | always 1 in this revision (reserved for a future index-less streaming mode) |
| 1 | `STREAMING_SAFE` | manifest + index are sufficient to open the file progressively (thumbnail/preview/metadata) without reading the data region |
| 2 | `PROFILE_ARCHIVAL` | manifest `profile == "archival"` |
| 3 | `PROFILE_DELIVERY` | manifest `profile == "delivery"` |
| 4 | `PROFILE_SCIENTIFIC` | manifest `profile == "scientific"` |
| 5 | `PROFILE_CAMERA` | manifest `profile == "camera"` |
| 6 | `PROFILE_DIGITAL_TWIN` | manifest `profile == "digital_twin"` |
| 7–15 | reserved | must be 0 in this revision; a decoder must ignore unknown set bits here (optional-extension semantics, §11) |

### 5.3 MANIFEST

UTF-8 JSON. Top-level keys:

```jsonc
{
  "axif_manifest_version": 1,
  "format": {"major": 1, "minor": 0, "revision": 0},
  "profile": "master",
  "image": {
    "width": 15360, "height": 8640,
    "pixel_format": "UINT8",               // see §7
    "channels": [ {"name":"R", "semantic":"red", "unit":null,
                   "colour_association":"RGB", "range":null}, ... ],
    "tile_width": 512, "tile_height": 512,
    "levels": [ {"level":0,"width":15360,"height":8640,
                 "tile_width":512,"tile_height":512}, ... ]
  },
  "colour": {"name":"sRGB","primaries":{...},"white_point":[0.3127,0.3290],
             "transfer_function":"sRGB","reference_kind":"display-referred",
             "has_icc_profile": false},
  "compression": {"codec_id": 1, "codec_name": "AXIF-ZLIB-LOSSLESS"},
  "metadata": {"fields": {"camera.model": "Aardvark C1", ...}},
  "provenance": {"source_format": "TIFF", "source_hash_sha256": null,
                 "stages": [ {"stage":"demosaic","algorithm":"AHD", ...} ],
                 "ai": null, "signature": null},
  "preview":   {"width":2048,"height":1152,"codec_id":40} ,  // or null
  "thumbnail": {"width":256,"height":144,"codec_id":40},      // or null
  "has_icc_profile": false,
  "extensions": []
}
```

`image.levels[i].width/height` give every pyramid level's exact
dimensions; `tiles_x`/`tiles_y` for a level are *derived*, not stored:
`ceil(level.width / level.tile_width)`, likewise for height. A decoder
must compute them this way rather than trusting a stored value, so a
truncated/incomplete level can still be detected by cross-checking against
the index (§9).

### 5.4 INDEX

A flat array of fixed 64-byte records immediately concatenated (no
separators), one per segment:

| Offset | Size | Field | Type |
|-------:|-----:|-------|------|
| 0 | 1 | `segment_type` | u8 — §6 |
| 1 | 2 | `level` | u16 |
| 3 | 4 | `tile_x` | u32 |
| 7 | 4 | `tile_y` | u32 |
| 11 | 1 | `channel_group` | u8 — 0 means "all channels interleaved" |
| 12 | 2 | `codec_id` | u16 — §8 |
| 14 | 1 | `flags` | u8 — reserved, 0 |
| 15 | 8 | `offset` | u64 — absolute byte offset in the file |
| 23 | 8 | `length` | u64 — compressed segment length, bytes |
| 31 | 8 | `uncompressed_length` | u64 — decompressed size, bytes |
| 39 | 4 | `crc32c` | u32 — CRC-32C (Castagnoli) of the *compressed* bytes |
| 43 | 21 | `reserved` | zero-filled |

For `TILE` segments, `level`/`tile_x`/`tile_y` locate the tile; for
`PREVIEW`/`THUMBNAIL`/`ICC_PROFILE` segments all three are 0 and there is
at most one such segment per file (a decoder finds it by segment type
alone). `(segment_type, level, tile_x, tile_y, channel_group)` together
are a unique key — a conformant encoder never writes two entries with the
same key.

### 5.5 DATA SEGMENTS

The raw compressed bytes for each index entry, exactly `length` bytes
starting at `offset`. Nothing else lives in this region; segments may
appear in any order and need not be contiguous (though the reference
encoder writes them contiguously and in level/tile-scan order).

### 5.6 FOOTER (64 bytes, always the last 64 bytes of the file)

| Offset | Size | Field | Notes |
|-------:|-----:|-------|-------|
| 0 | 8 | `footer_magic` | ASCII `AXIFEND1` |
| 8 | 32 | `file_sha256` | SHA-256 over every byte from offset 0 up to (not including) `footer_offset` |
| 40 | 24 | `reserved` | zero-filled |

## 6. Segment types

| Value | Name | Meaning |
|------:|------|---------|
| 0 | `TILE` | one tile of one pyramid level |
| 1 | `PREVIEW` | a single mid-resolution image (SPEC S.42) |
| 2 | `THUMBNAIL` | a single small image |
| 3 | `AUX_PLANE` | reserved for a future auxiliary-channel-as-separate-segment layout (current encoder interleaves aux channels into the tile itself; see ROADMAP.md) |
| 4 | `ICC_PROFILE` | opaque, byte-exact embedded ICC profile |
| 5 | `EXTENSION` | namespaced extension payload, §11 |
| 6 | `RAW_SOURCE` | reserved for embedding the original camera-RAW/source bytes alongside the processed master |
| 7 | `METADATA_BLOB` | reserved for a large opaque metadata block that doesn't belong in the JSON manifest (e.g. a raw XMP packet) |

Types 3, 6, 7 are defined (so their numeric value is reserved and won't be
reused for something else) but not yet emitted by the reference encoder;
see ROADMAP.md.

## 7. Pixel formats

`image.pixel_format` is one of: `UINT8`, `UINT16`, `UINT32`, `FLOAT16`,
`FLOAT32`. A decoder that encounters any other string must raise a
version/format error rather than guess — this is a mandatory field, not
an extension.

## 8. Codec registry

| `codec_id` | Name | Lossless | Core¹ | Notes |
|---:|---|:---:|:---:|---|
| 0 | `AXIF-RAW` | yes | yes | uncompressed samples |
| 1 | `AXIF-ZLIB-LOSSLESS` | yes | yes | DEFLATE (RFC 1951) over raw samples |
| 2 | `AXIF-ZSTD-LOSSLESS` | yes | no | Zstandard |
| 10 | `JPEGXL-LOSSLESS` | yes | no | ISO/IEC 18181 |
| 11 | `JPEGXL-LOSSY` | no | no | ISO/IEC 18181 |
| 20 | `JPEG2000-LOSSLESS` | yes | no | ISO/IEC 15444 (reversible transform) |
| 21 | `JPEG2000-LOSSY` | no | no | ISO/IEC 15444 (irreversible transform) |
| 30 | `WEBP-LOSSY` | no | no | |
| 40 | `PNG-LOSSLESS` | yes | no | used for preview/thumbnail |
| 50 | `EXR-LOSSLESS-FLOAT` | yes | no | OpenEXR container, float16/float32 |

¹ **Core** codecs use only facilities every conformant decoder must
implement (in the reference library: the Python standard library's
`zlib`). Non-core codecs are genuinely optional per SPEC S.66's extension
mechanism: a decoder that lacks JPEG XL support, say, can still open the
file, read the manifest, decode any tile stored with a codec it *does*
support, and must raise a codec-specific error only for the segments it
can't handle — never abort the whole file. `codec_id` values 60–255 and
1000+ are reserved for future/vendor codecs; an unrecognised `codec_id` on
a segment the decoder actually needs to read is an error, but does not
invalidate the rest of the file.

New codec IDs are requested by opening an issue with a name, a
reference implementation, and lossless/lossy classification; IDs are
never reused once shipped.

## 9. Integrity (SPEC S.34)

Two independent mechanisms, checked at different times:

1. **Per-segment CRC32C**, checked (by default) every time that segment
   is actually read. Cheap enough to run unconditionally; catches storage
   bit-rot and truncation on the specific bytes a caller asked for.
2. **Whole-file SHA-256** in the footer, checked by `axif-validate` (or
   `AxifReader.validate()`), covering every byte written by the encoder.
   Confirms nothing was appended, truncated, or modified anywhere in the
   file, independent of which segments a particular read touched.

A decoder must never return pixel data for a segment whose CRC32C does
not match the index before raising — i.e. verify-then-decode, not
decode-then-verify, so a corrupt compressed stream can't be fed to a
native codec that might handle malformed input less safely than AXIF's
own bounds checks (§10).

## 10. Security requirements (SPEC S.67-68)

A conformant decoder must, in this order, before doing anything sized by
an untrusted value:

1. Reject `format_major` values it does not implement.
2. Reject `width`/`height`/tile dimensions/segment counts/metadata length
   against caller-configurable ceilings *before* allocating a buffer of
   that size.
3. Reject any segment whose `offset + length` (or `manifest_offset +
   manifest_length`, etc.) would read past the end of the file.
4. Reject any segment whose declared `uncompressed_length` exceeds the
   caller's decoded-size ceiling, and treat a compressed→uncompressed
   expansion ratio far beyond what the codec could legitimately produce as
   suspicious (decompression-bomb guard) — *before* invoking the codec's
   decompressor.
5. Only then decompress, and verify CRC32C (§9) before returning bytes to
   the caller.

See SECURITY.md for the reference implementation's specific limits and
the fixtures in `test-vectors/corrupt/` that exercise each rule.

## 11. Extensions (SPEC S.66)

`manifest.extensions` is an array of `{"namespace": "...", "id": "...",
"mandatory": bool, "data": ...}` objects. A decoder must skip any
extension entry with `"mandatory": false` that it doesn't recognise. An
entry with `"mandatory": true` that the decoder doesn't recognise makes
the file's mandatory feature set unsupported by that decoder — the
correct response is a version/compatibility error for the whole file (the
same as an unknown `format_major`), not a best-effort partial read.
Reserved top-level namespaces: `core`, `colour`, `camera`, `computational`,
`scientific`, `ai`, `provenance`, `vendor`. Namespaced metadata *fields*
(inside `manifest.metadata.fields`, e.g. `"aardvark.lidar.range_m"`) are
always optional/skippable regardless of namespace — only `extensions[]`
entries can be marked mandatory.

## 12. Backwards/forwards compatibility (SPEC S.104-105)

- Within one `format_major`, a decoder that implements this specification
  can read every mandatory field of every file, present and future minor
  revisions, because `format_minor` only ever *adds* optional manifest
  keys and optional codec IDs — it never repurposes an existing key or
  changes the meaning of an existing struct field.
- An **old** decoder (implementing an earlier `format_minor`) can still
  open a **new** file's header, read its manifest as JSON (ignoring keys
  it doesn't recognise — this is why the manifest is JSON and not a fixed
  struct), read its thumbnail/preview if they use a codec it supports,
  and read metadata — even if the new file's *master* uses a codec the
  old decoder has never heard of. This is what `STREAMING_SAFE` (§5.2)
  and the segment-scoped (not file-scoped) codec error handling (§8) are
  for.
- A `format_major` bump is reserved for a change that breaks this
  guarantee (e.g. a different header layout) and is expected to be rare.

## 13. Worked example: locating one tile

To read pyramid level 2, tile (3, 1):

1. Read bytes `[0, 128)`, parse the header, check `magic` and
   `format_major`.
2. Read `[header.manifest_offset, +header.manifest_length)`, parse as
   JSON.
3. Read `[header.index_offset, +header.index_length)`; for each 64-byte
   record, if `segment_type == TILE and level == 2 and tile_x == 3 and
   tile_y == 1`, that's the entry.
4. Bounds-check `entry.offset + entry.length <= file_length` (§10).
5. Read `[entry.offset, +entry.length)`, verify `crc32c(bytes) ==
   entry.crc32c`.
6. Compute this tile's true pixel shape from `manifest.image.levels[2]`
   and the tile grid (accounting for a possible edge tile).
7. Decode with `codec_id = entry.codec_id` (§8) to get the pixel array.

This is exactly what `AxifReader.read_tile(2, 3, 1)` does in
`python/axif/format.py`, and what `read_region()` does in a loop over the
tiles a requested rectangle intersects.

## 14. What this specification does not yet cover

Marked honestly rather than glossed over — see ROADMAP.md for the
reasoning and plan:

- A byte-level specification for the `AUX_PLANE`/`RAW_SOURCE`/
  `METADATA_BLOB` segment payloads (types reserved, not yet emitted).
- A native "AXC" (Aardvark Extended Codec) — SPEC S.26/S.137 are explicit
  that this should only be built after benchmarking shows an established
  codec (JPEG XL, JPEG 2000) can't be beaten on a stated objective; see
  `docs/BENCHMARKS.md` for the current numbers and ROADMAP.md for the
  decision this implies.
- A C ABI / Rust core (no Rust toolchain was available in the environment
  this repository was built in; the wire format above was designed to be
  straightforward to port — flat structs, explicit offsets, no pointers
  — precisely so that porting is mechanical rather than a redesign).
