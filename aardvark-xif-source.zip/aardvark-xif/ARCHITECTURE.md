# AARDVARK XIF — Architecture

## Design principle: one master image, many representations

A single `.axif` file holds the master image, its pyramid, its tiles, a
preview, a thumbnail, its colour/camera/provenance metadata, and
(optionally) an embedded ICC profile — so a user isn't maintaining
`master_16k.tif` + `web.jpg` + `hdr.exr` + `preview.webp` +
`thumbnail.png` as five unrelated files with no recorded relationship to
each other. Everything below serves that one idea.

## Module map

```
python/axif/
  container.py    binary struct layer — header/index/footer pack+unpack (SPEC §4-6)
  checksums.py     CRC32C (native + pure-Python fallback) and SHA-256 helpers
  security.py      ResourceLimits + the bounds/overflow/decompression-bomb guards
  codec.py         pluggable segment-codec registry (RAW/zlib/zstd/JPEGXL/JPEG2000/WebP/PNG/EXR)
  colour.py        ColourSpace: primaries, transfer function, ICC passthrough
  metadata.py      namespaced typed metadata registry
  provenance.py    processing-stage chain + optional AI-generation provenance
  core.py          CanonicalImage — the format-agnostic image model (see below)
  pyramid.py       PyramidPlan (level geometry), box downsampling, ProceduralTileSource
  format.py        AxifWriter / AxifReader — the container read/write engine
  importers.py     SOURCE -> CanonicalImage  (PNG/JPEG/TIFF/EXR/JPEG2000/JPEGXL/WebP/...)
  exporters.py     CanonicalImage -> TARGET
  diff.py          axif-diff: PSNR / SSIM / MSE
  benchmark.py     axif-benchmark: real, measured codec/ROI/open-latency comparisons
  cli.py           argparse implementations backing every axif-* command
  errors.py        AxifError hierarchy
  __init__.py      public SDK surface (`import axif`)

cli/               thin standalone scripts (axif-info, axif-validate, axif-convert,
                   axif-extract, axif-diff, axif-benchmark, and the axif dispatcher) —
                   no install step required, they just add python/ to sys.path
tests/             pytest suite (container, checksums, codecs, writer/reader, pyramid,
                   diff, security, interop, streaming, conformance-fixture walker)
test-vectors/      generate_fixtures.py — conformance fixtures, corrupt fixtures, and
                   the flagship streaming 16K master
viewer/            reference deep-zoom viewer (real exported tiles from the real 16K file)
docs/              BENCHMARKS.md (measured), plus this file's companions
```

## The conversion architecture (SPEC S.3, S.78)

Every import/export path goes through one format-agnostic model:

```
SOURCE (PNG/JPEG/TIFF/EXR/JPEG2000/JPEGXL/WebP/...)
   │  importers.py: a real, independently-maintained decoder
   ▼
CanonicalImage   (core.py — width/height/channels/dtype/colour/metadata/provenance
                   + either a materialised numpy array or a streaming tile_source)
   │  AxifWriter                              │  exporters.py: a real target codec
   ▼                                           ▼
AXIF file                                    TARGET file
```

`axif.convert(a, b)` never takes a shortcut through "decode A just enough
to fake B" — it always fully instantiates a `CanonicalImage` in between.
Concretely this means a PNG → AXIF → PNG round trip is pixel-exact (both
stages are lossless) and is asserted as such in
`tests/test_interop.py::test_source_to_axif_to_target_png_round_trip`,
rather than merely claimed.

Exporters raise rather than silently degrade: `export_jpeg()` refuses an
RGBA image (JPEG has no alpha) instead of quietly dropping the channel;
`export_exr()` refuses an integer-dtype image instead of silently
reinterpreting bytes as floats. See SPEC S.132 ("no destructive silent
operations") — every one of these is a deliberate `AxifCodecError`, not an
oversight, and is unit-tested as a required behaviour, not just a
possible one.

## CanonicalImage: materialised vs. streaming

`CanonicalImage` carries pixels one of two ways:

- **`array`** — an ordinary in-memory `(H, W, C)` numpy array. What every
  normal import produces, and what's appropriate for anything that
  comfortably fits in RAM (which, on ordinary hardware, is most
  photography up to several hundred megapixels).
- **`tile_source`** — a callable `(level, tile_x, tile_y, tile_w, tile_h)
  -> ndarray`, used when the master must never be fully materialised.
  `AxifWriter` calls this once per tile per pyramid level and holds only
  a handful of tiles in memory at any time — this is what makes it
  possible to build a genuine 15360×8640 AXIF master (≈398 MB raw, per
  SPEC S.5's own arithmetic) with a measured **132 MB peak RSS** on a
  machine with 3.9 GB of total RAM (see `docs/BENCHMARKS.md`). The
  streaming path isn't a theoretical option — it's how
  `test-vectors/streaming/master.axif` in this repository was actually
  produced.

`pyramid.ProceduralTileSource` is the concrete `tile_source` used by the
16K test fixture: it evaluates a deterministic function of absolute
level-0 pixel coordinates on whatever coarser grid a given pyramid level
needs, so *every* level is generated directly — never by downsampling a
materialised level 0.

A real camera/scanner pipeline would supply a different `tile_source`
(e.g. one that reads sequentially off a sensor or seeks into a
tiled-source file) — the writer doesn't care how tiles arrive, only that
they arrive one at a time.

## The pyramid and tiling (SPEC S.18-22)

`PyramidPlan(width, height, tile_width, tile_height)` produces level 0 (the
master) followed by ~2×-downsampled levels (box filter, computed in
float32 regardless of input dtype to avoid integer overflow/banding, then
cast back) until a level fits within one tile. Every level is tiled
independently and addressed by `(level, tile_x, tile_y)` in the index —
`AxifReader.read_tile()`, `.read_level()`, and `.read_region()` are all
built on the same index lookup, so `read_region()` is simply "which tiles
does this rectangle intersect" followed by a per-tile decode-and-crop.
Edge tiles (where a level's dimensions aren't an exact multiple of the
tile size) are first-class — sized correctly, not padded — and are
exercised in `tests/test_writer_reader.py::test_edge_tiles_are_correctly_sized`.

## Why ROI decoding matters here, measured

On the real 16K master built for this repository (`docs/BENCHMARKS.md`
has the full run):

| | full `read_level(0)` | `read_region(7000,4000,1024,1024)` |
|---|---:|---:|
| time (range across runs) | 889-2154 ms | 18.5-22.2 ms |
| bytes read | 40.4 MB (510 tiles) | 1.7 MB (9 tiles) — deterministic |

That's the concrete version of SPEC S.139's "the image should behave more
like a navigable computational landscape than a monolithic file" — not an
aspiration, a measured 40x-116x speedup (varies run-to-run on this shared
sandbox; the 95.7% fewer bytes read does not vary, since it's a function
of which tiles get touched, not of the machine) for a 1024×1024 crop out
of 132 megapixels.

## Profiles

`profile` in the manifest (`master`/`archival`/`delivery`/`scientific`/
`camera`/`digital_twin`/unset-`core`) is a labelling convention with
sensible per-profile *defaults* the CLI/SDK apply (e.g. `archival`
defaults to a lossless codec and full metadata retention; `delivery`
defaults to a lossy codec, a smaller preview, and a tighter tile size for
faster initial paint) — it is not a different wire format. Every profile
produces an ordinary AXIF file any conformant decoder can open; see
SPECIFICATION.md §3.

## Security posture

Every value that originates in the file — not the caller — is checked
against a `ResourceLimits` ceiling *before* it's used to size a buffer or
drive a loop: declared width/height/pixel count, tile dimensions, segment
count, manifest byte length, and each segment's declared
`uncompressed_length` (the decompression-bomb guard). See SECURITY.md for
the specifics and the corrupt-file fixtures that exercise each check.

## What's deliberately not built yet

Stated plainly rather than shipped as a non-functional stub — see
ROADMAP.md for the reasoning:

- **Rust core / C ABI** — no Rust toolchain was available in the sandbox
  this was built in. The wire format (SPECIFICATION.md) was written to be
  mechanically portable (flat structs, explicit byte offsets, no
  pointers, no platform-dependent struct packing) specifically so this is
  a porting exercise, not a redesign, when a toolchain is available.
- **GPU decode path** — no GPU in this environment. The segment layout
  (independently-compressed, fixed-shape tiles) is GPU-upload-friendly by
  construction, but no Vulkan/Metal/CUDA/WebGPU code is included.
- **Native AXC codec** — per SPEC S.26/S.137, explicitly gated on
  benchmarks showing an established codec can't be beaten on a stated
  objective. `docs/BENCHMARKS.md` has the current numbers; the honest
  read of them is in ROADMAP.md.
- **Full desktop viewer app** — `viewer/index.html` is a real, working
  deep-zoom prototype built from real exported tiles of the real 16K
  file, published as a self-contained page, not the full
  histogram/waveform/pixel-inspector desktop application SPEC S.46
  describes.
