# Interoperability Matrix

Per SPEC S.122: "test actual behaviour... do not claim support merely
because an adapter exists." Every ✅/⚠️/❌ below corresponds to an
assertion that actually runs in `tests/test_interop.py` or
`tests/test_codecs.py` — not a claim about the underlying library's
general capabilities.

| Format | Import | Export | Lossless round-trip via AXIF | Notes |
|---|:---:|:---:|:---:|---|
| PNG | ✅ | ✅ | ✅ tested byte-exact | 8/16-bit |
| JPEG | ✅ | ✅ | — (JPEG itself is lossy) | export refuses RGBA (no alpha in JPEG) rather than dropping it silently |
| TIFF | ✅ | ✅ | ✅ tested byte-exact | 8/16-bit verified; tag metadata best-effort extracted |
| OpenEXR | ✅ | ✅ | ✅ tested byte-exact | float16/float32; export refuses integer dtypes rather than reinterpreting |
| JPEG 2000 | ✅ | ✅ | ✅ tested byte-exact (reversible transform) | lossy mode also available |
| JPEG XL | ✅ | ✅ | ✅ tested byte-exact, incl. 16-bit and float32 | lossy mode also available |
| WebP | ✅ | ✅ | — (lossy only in this build) | |
| AVIF | ✅ import only | — | not exercised in tests | `imagecodecs.avif_decode` wired up; no export path or test coverage yet |
| HEIF/HEIC | ✅ import only | — | not exercised in tests | `imagecodecs.heif_decode` wired up; no export path or test coverage yet |
| BMP | ✅ import only | — | not exercised in tests | via Pillow |
| GIF | ❌ | ❌ | — | not implemented |
| PPM/PGM/PAM | ❌ | ❌ | — | not implemented |
| RAW camera formats (DNG/CR2/CR3/NEF/ARW/...) | ❌ | — | — | no adapter; see ROADMAP.md — `RawAdapter -> CanonicalImage` is the intended seam, unimplemented |

## HDR / wide gamut / alpha / multi-channel — tested independently of format

These are properties of `CanonicalImage`, not any one file format, so
they're tested at that level rather than per-format:

| Property | Tested? | Where |
|---|:---:|---|
| HDR (float32 scene-linear) | ✅ | `test_codecs.py::test_exr_lossless_float32`, `test_interop.py::test_exr_import_preserves_float` |
| Wide gamut / named colour spaces (sRGB, Display P3, Rec.2020+PQ, ACES) | ✅ manifest round-trip | `test_writer_reader.py::test_colour_space_roundtrips` |
| Embedded ICC profile (byte-exact passthrough) | ✅ | `test_writer_reader.py::test_icc_profile_roundtrips_byte_exact` |
| Alpha (RGBA) | ✅ | `test_writer_reader.py` (RGBA fixture), JPEG export explicitly rejects it |
| Multi-channel (non-RGB, e.g. 5-band) | ✅ | `test_writer_reader.py`, `test-vectors/conformance/multichannel_5.axif` |
| Progressive (thumbnail/preview before master) | ✅ measured | `docs/BENCHMARKS.md` §1 (1.5 ms open, 6.3 ms thumbnail, 21 ms preview) |
| ROI / tiled random access | ✅ measured | `docs/BENCHMARKS.md` §1 (40x speedup, 9 tiles vs. 510) |

## What "not exercised in tests" means

AVIF/HEIF import, and BMP import, call real `imagecodecs`/Pillow
functions and are not fabricated — but no automated test asserts a
round-trip for them in this repository, so they're marked accordingly
rather than given the same ✅ as the formats with explicit assertions.
Treat them as "should work, unverified here" until a test is added.
