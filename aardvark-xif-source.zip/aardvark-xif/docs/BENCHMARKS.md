# AXIF — Measured Benchmarks

Every number on this page came from actually running
`axif.benchmark`/`axif-benchmark` against real files on the machine this
repository was built on, in this session. Reproduce with:

```
python3 test-vectors/generate_fixtures.py --master-size 15360x8640
python3 cli/axif-benchmark <file> [--roi x,y,w,h]
```

**Test machine**: 1 vCPU, 3.9 GB RAM, no GPU. This is a *constrained*
sandbox, not representative hardware for a production imaging pipeline —
re-run this on your own target hardware before citing these numbers
anywhere that matters (SPEC S.126). Directionally, though, the
architecture's characteristic result — ROI decode being dramatically
cheaper than full decode, progressive open being near-instant — will hold
on any hardware, because it comes from reading fewer bytes, not from raw
CPU speed.

## 1. The flagship number: a real 16K file, opened progressively

`test-vectors/streaming/master.axif` — a genuine 15360×8640 (132.7
megapixel) AXIF master, built via streaming (`ProceduralTileSource`,
never materialising the full array — see ARCHITECTURE.md):

| Build metric | Value |
|---|---:|
| Wall-clock build time | 63.7 s |
| **Peak RSS during build** | **132 MB** (vs. ≈398 MB the raw pixel data alone would need if materialised once, let alone the several-times-that a naive "load whole image, then process" pipeline would use) |
| Output file size | 59.9 MB (702 tiles across 6 pyramid levels, AXIF-ZLIB-LOSSLESS) |

Opened and read back:

| Operation | Time | Data touched |
|---|---:|---:|
| `axif.open()` (header + manifest + index) | 1.53 ms | — |
| `read_thumbnail()` | 6.27 ms | one small segment |
| `read_preview()` | 21.25 ms | one segment, 1920×1080 |
| `read_level(0)` — **full 132 MP decode** | 889-2154 ms (2 runs) | 40.4 MB, 510 tiles |
| `read_region(7000, 4000, 1024, 1024)` — **ROI decode** | 18.5-22.2 ms (2 runs) | 1.7 MB, 9 tiles |

**ROI speedup measured at 40x-116x across repeated runs (95.7% fewer
bytes read, consistently)**, for a 1024x1024 crop out of a 132-megapixel
image. The bytes-read reduction is deterministic (it's just "9 tiles
instead of 510", independent of the machine); the *time* speedup varies
run-to-run on this shared single-vCPU sandbox (observed full-decode time
ranged 889-2154 ms across runs, ROI decode 18-22 ms) — noted honestly
rather than cherry-picking the more dramatic number. Either way this is
SPEC S.117's "prove the value of tiled hierarchical access" and S.139's
"defining feature" demonstration, measured on this repository's own file,
not asserted.

## 2. Codec comparison on real content

Four 2048×1024 crops of the *same real 16K file* (not independent
synthetic samples — literally `read_region()` on `master.axif`), chosen
to span very different compressibility: a smooth sky gradient, a
hard-edged "architecture" band, a high-frequency grating (the band SPEC
S.112 specifically asks for to "expose ... mosquito noise"), and an
organic-noise "foliage" band. Every codec below — including the "external"
PNG/JPEG/WebP/JPEG2000/JPEG XL rows — is the *same real codec binding*
AXIF uses internally; they're run twice, once as an AXIF segment codec and
once as an ordinary whole-image file, so the comparison is apples-to-apples
with how someone would actually use these formats outside AXIF.

### sky_gradient (smooth) — 2048×1024

| Codec | Lossless | Size | Ratio | Encode | Decode | PSNR | SSIM |
|---|---|---:|---:|---:|---:|---:|---:|
| AXIF-ZLIB-LOSSLESS | yes | 6,804 B | 924.7x | 21.7 ms | 8.8 ms | inf | 1.0000 |
| AXIF-ZSTD-LOSSLESS | yes | 3,167 B | 1986.6x | 13.3 ms | 5.4 ms | inf | 1.0000 |
| PNG | yes | 9,092 B | 692.0x | 310.2 ms | 7.7 ms | inf | 1.0000 |
| JPEG q90 | no | 57,658 B | 109.1x | 434.3 ms | 6.6 ms | 51.5 dB | 0.9971 |
| WebP q90 | no | 1,394 B | 4513.2x | 222.2 ms | 3.7 ms | inf | 1.0000 |
| JPEG2000 lossless | yes | 12,902 B | 487.6x | 149.6 ms | 31.0 ms | inf | 1.0000 |
| JPEG XL lossless | yes | 6,246 B | 1007.3x | 596.4 ms | 67.4 ms | inf | 1.0000 |
| JPEG XL q90 | no | 4,405 B | 1428.3x | 278.6 ms | 43.1 ms | 54.7 dB | 0.9968 |

### architecture (hard edges) — 2048×1024

| Codec | Lossless | Size | Ratio | Encode | Decode | PSNR | SSIM |
|---|---|---:|---:|---:|---:|---:|---:|
| AXIF-ZLIB-LOSSLESS | yes | 21,109 B | 298.1x | 22.5 ms | 5.6 ms | inf | 1.0000 |
| AXIF-ZSTD-LOSSLESS | yes | 19,520 B | 322.3x | 9.9 ms | 3.4 ms | inf | 1.0000 |
| PNG | yes | 9,961 B | 631.6x | 41.5 ms | 5.6 ms | inf | 1.0000 |
| JPEG q90 | no | 140,076 B | 44.9x | 13.1 ms | 7.1 ms | 41.0 dB | 0.9860 |
| WebP q90 | no | 502 B | 12532.8x | 24.8 ms | 2.4 ms | inf | 1.0000 |
| JPEG2000 lossless | yes | 102,901 B | 61.1x | 82.9 ms | 67.3 ms | inf | 1.0000 |
| JPEG XL lossless | yes | 3,324 B | 1892.7x | 379.8 ms | 88.4 ms | inf | 1.0000 |
| JPEG XL q90 | no | 61,775 B | 101.8x | 276.6 ms | 37.9 ms | 47.9 dB | 0.9948 |

### grating (high-frequency) — 2048×1024

| Codec | Lossless | Size | Ratio | Encode | Decode | PSNR | SSIM |
|---|---|---:|---:|---:|---:|---:|---:|
| AXIF-ZLIB-LOSSLESS | yes | 2,195,555 B | 2.87x | 99.4 ms | 22.9 ms | inf | 1.0000 |
| AXIF-ZSTD-LOSSLESS | yes | 1,244,756 B | 5.05x | 93.7 ms | 7.3 ms | inf | 1.0000 |
| PNG | yes | 2,096,396 B | 3.00x | 163.9 ms | 33.9 ms | inf | 1.0000 |
| JPEG q90 | no | 946,867 B | 6.64x | 30.5 ms | 17.3 ms | 26.0 dB | 0.9715 |
| WebP q90 | no | 1,978,818 B | 3.18x | 1397.2 ms | 39.9 ms | inf | 1.0000 |
| JPEG2000 lossless | yes | 2,875,664 B | 2.19x | 553.6 ms | 478.1 ms | inf | 1.0000 |
| JPEG XL lossless | yes | 3,454,670 B | **1.82x** | 1177.0 ms | 422.5 ms | inf | 1.0000 |
| JPEG XL q90 | no | 311,827 B | 20.18x | 338.5 ms | 56.5 ms | 30.0 dB | 0.9901 |

### foliage (organic noise) — 2048×1024

| Codec | Lossless | Size | Ratio | Encode | Decode | PSNR | SSIM |
|---|---|---:|---:|---:|---:|---:|---:|
| AXIF-ZLIB-LOSSLESS | yes | 514,968 B | 12.2x | 129.8 ms | 9.8 ms | inf | 1.0000 |
| AXIF-ZSTD-LOSSLESS | yes | 564,923 B | 11.1x | 76.8 ms | 4.3 ms | inf | 1.0000 |
| PNG | yes | 496,700 B | 12.7x | 238.5 ms | 10.9 ms | inf | 1.0000 |
| JPEG q90 | no | 112,338 B | 56.0x | 19.8 ms | 8.4 ms | 48.3 dB | 0.9921 |
| WebP q90 | no | 350,020 B | 18.0x | 752.6 ms | 12.2 ms | inf | 1.0000 |
| JPEG2000 lossless | yes | 652,983 B | 9.6x | 137.7 ms | 115.1 ms | inf | 1.0000 |
| JPEG XL lossless | yes | 240,055 B | 26.2x | 415.3 ms | 107.1 ms | inf | 1.0000 |
| JPEG XL q90 | no | 29,440 B | 213.7x | 273.2 ms | 34.0 ms | 51.3 dB | 0.9946 |

## 3. What these numbers actually say (read honestly, per SPEC S.27)

- **No codec wins everywhere.** WebP is astonishing on flat/smooth
  content (4500×–12,500× on gradient/architecture) and unremarkable on
  the grating band. JPEG XL lossless is the best lossless option on three
  of four content types — and the **worst** lossless option (1.82×,
  worse than plain zlib's 2.87×) on the adversarial high-frequency
  grating, where its transform assumptions stop paying for themselves.
  This is exactly why AXIF's codec choice is a per-file (and
  architecturally, could be per-tile) parameter rather than a fixed
  format-wide decision — SPEC S.25's "pluggable compression backends" is
  doing real work here, not just flexibility for its own sake.
- **zstd is consistently the fastest lossless option** at a modest size
  cost versus zlib, and is a reasonable default for a `delivery`-profile
  file where encode/decode latency matters more than ratio.
- **JPEG q90's PSNR sits around 26–55 dB** depending on content, as
  expected for lossy DCT coding — included as the familiar reference
  point, not because AXIF recommends it for anything the format itself
  handles losslessly by default.
- None of this makes a claim about AXIF's *container* being faster or
  smaller than JPEG XL or JPEG 2000's own containers — it can't be,
  since AXIF calls the same codec libraries for the pixel compression
  itself. The container's value is elsewhere (ROI/pyramid/provenance/
  metadata architecture) — see §1 above and ARCHITECTURE.md.

## 4. Progressive-open latency (SPEC S.85, S.118)

Measured via `axif.benchmark.benchmark_progressive_open()` on the same
16K file (§1 table) — thumbnail in 6.3 ms, preview in 21.3 ms, both
before any tile of the 132-megapixel master is touched. A network
simulation (SPEC S.118's explicit 100/50/20/10/5 Mbps table) was not run
in this environment (no real network path was exercised — everything
here is local disk) and is left honest rather than estimated; the
*local* number is the one that matters for the decode-time claims above
regardless of transport, since bytes-read is transport-agnostic.

## 5. Memory (SPEC S.115)

| Configuration | Peak RSS |
|---|---:|
| Streaming-write the 16K master (never materialising level 0) | 132 MB |
| `read_level(0)` full decode of the same file | not separately isolated in this run; bounded by `ResourceLimits.max_total_decoded_bytes` (default 8 GiB) regardless, and the decoded array itself is ~398 MB for RGB-uint8 at this resolution |

A dedicated per-dtype memory sweep (uint8/uint16/float16/float32 ×
RGB/RGBA, per SPEC S.115's table) was not run separately from the timing
benchmarks above in this session; the streaming-write number is the one
concretely measured end-to-end and is the more architecturally important
of the two (it's the one that would OOM a naive implementation).

## 6. Concurrency (SPEC S.70, S.116)

Not benchmarked in this environment (1 vCPU — a multi-thread comparison
would only measure scheduling overhead, not real parallel speedup). The
reference `AxifReader` is documented as single-instance-single-thread in
ARCHITECTURE.md; parallel tile decode across a bounded worker pool is
straightforward on top of `read_tile()` (each call is independent given
its own file handle) but isn't implemented or measured here — see
ROADMAP.md.
