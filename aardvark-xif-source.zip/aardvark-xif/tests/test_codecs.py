import numpy as np
import pytest

from axif import codec

LOSSLESS_CODECS = [
    codec.CODEC_RAW,
    codec.CODEC_ZLIB_LOSSLESS,
    codec.CODEC_ZSTD_LOSSLESS,
    codec.CODEC_JPEGXL_LOSSLESS,
    codec.CODEC_JPEG2000_LOSSLESS,
    codec.CODEC_PNG_LOSSLESS,
]

LOSSY_CODECS = [
    codec.CODEC_JPEGXL_LOSSY,
    codec.CODEC_JPEG2000_LOSSY,
    codec.CODEC_WEBP_LOSSY,
]


def _available(codec_id):
    return codec.is_available(codec_id)


@pytest.fixture
def rgb_u8():
    rng = np.random.default_rng(42)
    return (rng.random((64, 96, 3)) * 255).astype(np.uint8)


@pytest.fixture
def rgb_u16():
    rng = np.random.default_rng(43)
    return (rng.random((48, 64, 3)) * 65535).astype(np.uint16)


@pytest.mark.parametrize("codec_id", LOSSLESS_CODECS)
def test_lossless_codec_byte_exact_roundtrip_u8(codec_id, rgb_u8):
    if not _available(codec_id):
        pytest.skip(f"optional dependency for codec {codec_id} not installed")
    spec = codec.resolve(codec_id)
    encoded = codec.encode(codec_id, rgb_u8)
    decoded = codec.decode(codec_id, encoded, shape=rgb_u8.shape, dtype=rgb_u8.dtype)
    assert decoded.dtype == rgb_u8.dtype
    assert decoded.shape == rgb_u8.shape
    assert np.array_equal(decoded, rgb_u8), f"{spec.name} claims lossless but pixels differ"


@pytest.mark.parametrize("codec_id", [
    codec.CODEC_RAW, codec.CODEC_ZLIB_LOSSLESS, codec.CODEC_ZSTD_LOSSLESS,
    codec.CODEC_JPEG2000_LOSSLESS,
])
def test_lossless_codec_byte_exact_roundtrip_u16(codec_id, rgb_u16):
    if not _available(codec_id):
        pytest.skip(f"optional dependency for codec {codec_id} not installed")
    encoded = codec.encode(codec_id, rgb_u16)
    decoded = codec.decode(codec_id, encoded, shape=rgb_u16.shape, dtype=rgb_u16.dtype)
    assert np.array_equal(decoded, rgb_u16)


def test_jpegxl_lossless_u16(rgb_u16):
    if not _available(codec.CODEC_JPEGXL_LOSSLESS):
        pytest.skip("imagecodecs not installed")
    encoded = codec.encode(codec.CODEC_JPEGXL_LOSSLESS, rgb_u16)
    decoded = codec.decode(codec.CODEC_JPEGXL_LOSSLESS, encoded)
    assert np.array_equal(decoded, rgb_u16)


def test_exr_lossless_float32():
    if not _available(codec.CODEC_EXR_LOSSLESS):
        pytest.skip("imagecodecs not installed")
    rng = np.random.default_rng(7)
    arr = (rng.random((32, 40, 3)).astype(np.float32)) * 6.0  # HDR range
    encoded = codec.encode(codec.CODEC_EXR_LOSSLESS, arr)
    decoded = codec.decode(codec.CODEC_EXR_LOSSLESS, encoded)
    assert np.array_equal(decoded, arr)


@pytest.mark.parametrize("codec_id", LOSSY_CODECS)
def test_lossy_codec_roundtrips_and_is_close(codec_id, rgb_u8):
    if not _available(codec_id):
        pytest.skip(f"optional dependency for codec {codec_id} not installed")
    encoded = codec.encode(codec_id, rgb_u8)
    decoded = codec.decode(codec_id, encoded)
    assert decoded.shape == rgb_u8.shape
    # lossy: not byte-exact in general, but should be visually close
    mean_abs_err = np.mean(np.abs(decoded.astype(np.int32) - rgb_u8.astype(np.int32)))
    assert mean_abs_err < 20, f"lossy codec {codec_id} mean abs error {mean_abs_err} too high"


def test_unknown_codec_id_raises():
    from axif.errors import AxifCodecError
    with pytest.raises(AxifCodecError):
        codec.resolve(99999)


def test_zlib_is_actually_smaller_than_raw_for_compressible_data():
    arr = np.zeros((100, 100, 3), dtype=np.uint8)
    arr[:50, :, 0] = 255  # large flat regions -> highly compressible
    raw = codec.encode(codec.CODEC_RAW, arr)
    zl = codec.encode(codec.CODEC_ZLIB_LOSSLESS, arr)
    assert len(zl) < len(raw)


def test_codec_registry_core_codecs_always_available():
    assert codec.is_available(codec.CODEC_RAW)
    assert codec.is_available(codec.CODEC_ZLIB_LOSSLESS)
