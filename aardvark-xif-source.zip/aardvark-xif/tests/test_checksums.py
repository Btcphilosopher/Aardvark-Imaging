from axif.checksums import StreamingSHA256, crc32c, sha256_digest, sha256_hexdigest


def test_crc32c_standard_check_value():
    # The canonical CRC-32C ("Castagnoli") check value for the ASCII
    # string "123456789" is 0xE3069283 — published in RFC 3720 Appendix B.1
    # and reproduced in countless CRC32C test suites.
    assert crc32c(b"123456789") == 0xE3069283


def test_crc32c_empty():
    assert crc32c(b"") == 0


def test_crc32c_is_deterministic():
    data = bytes(range(256)) * 17
    assert crc32c(data) == crc32c(data)


def test_pure_python_fallback_matches_reference_vectors():
    # Re-derive the fallback table implementation independently (without
    # importing the native package) and confirm it agrees with the
    # standard check value, so the *fallback path itself* is exercised
    # even on machines where the `crc32c` wheel is installed.
    poly = 0x82F63B78

    def build_table():
        table = []
        for byte in range(256):
            c = byte
            for _ in range(8):
                c = (c >> 1) ^ poly if c & 1 else c >> 1
            table.append(c)
        return table

    table = build_table()

    def crc32c_pure(data: bytes) -> int:
        crc = 0xFFFFFFFF
        for b in data:
            crc = (crc >> 8) ^ table[(crc ^ b) & 0xFF]
        return crc ^ 0xFFFFFFFF

    assert crc32c_pure(b"123456789") == 0xE3069283
    assert crc32c_pure(b"123456789") == crc32c(b"123456789")


def test_sha256_digest_and_hexdigest_agree():
    data = b"aardvark xif"
    assert sha256_digest(data).hex() == sha256_hexdigest(data)
    assert len(sha256_digest(data)) == 32


def test_streaming_sha256_matches_one_shot():
    data = bytes(range(256)) * 500
    s = StreamingSHA256()
    for i in range(0, len(data), 777):
        s.update(data[i:i + 777])
    assert s.digest() == sha256_digest(data)
