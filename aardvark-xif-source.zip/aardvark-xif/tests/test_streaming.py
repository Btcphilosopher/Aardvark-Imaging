import numpy as np
import pytest

import axif
from axif.core import CanonicalImage, rgb_channels
from axif.pyramid import ProceduralTileSource


def _checkerboard_generator(x, y):
    # simple deterministic pattern so we can predict exact pixel values
    r = ((x // 8).astype(np.int64) % 2) * 255
    g = ((y // 8).astype(np.int64) % 2) * 255
    b = (((x + y) // 16).astype(np.int64) % 2) * 255
    return np.stack([r, g, b], axis=-1).astype(np.uint8)


def test_streaming_write_never_needs_full_array(tmp_path):
    width, height = 6000, 4000  # large enough to matter, small enough to run fast in CI
    src = ProceduralTileSource(_checkerboard_generator, width, height, 3)
    img = CanonicalImage(
        width=width, height=height, channels=rgb_channels(), dtype=np.uint8,
        tile_source=src,
    )
    out = tmp_path / "streamed.axif"
    report = axif.AxifWriter(img, tile_width=512, tile_height=512,
                              generate_preview=True, generate_thumbnail=True).write(str(out))
    assert report.tile_count > 0

    r = axif.open(str(out))
    assert (r.width, r.height) == (width, height)

    # spot-check several regions against the generator directly
    for (x, y, w, h) in [(0, 0, 32, 32), (3000, 2000, 40, 40), (5980, 3980, 20, 20)]:
        region = r.read_region(x, y, w, h)
        xs = np.arange(x, x + region.shape[1])
        ys = np.arange(y, y + region.shape[0])
        gx, gy = np.meshgrid(xs, ys)
        expected = _checkerboard_generator(gx.astype(np.float64), gy.astype(np.float64))
        assert np.array_equal(region, expected), f"mismatch at {(x,y,w,h)}"

    thumb = r.read_thumbnail()
    assert thumb is not None
    r.close()


def test_canonical_image_requires_exactly_one_of_array_or_tile_source():
    with pytest.raises(ValueError):
        CanonicalImage(width=10, height=10, channels=rgb_channels(), dtype=np.uint8)
    with pytest.raises(ValueError):
        CanonicalImage(
            width=10, height=10, channels=rgb_channels(), dtype=np.uint8,
            array=np.zeros((10, 10, 3), dtype=np.uint8),
            tile_source=lambda *a: None,
        )
