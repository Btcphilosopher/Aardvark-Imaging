import numpy as np
import pytest

from axif.diff import compare


def test_identical_images_are_identical():
    arr = (np.random.default_rng(0).random((64, 64, 3)) * 255).astype(np.uint8)
    report = compare(arr, arr.copy())
    assert report.identical
    assert report.mse == 0.0
    assert report.psnr_db == float("inf")
    assert report.ssim == pytest.approx(1.0, abs=1e-6)


def test_noisy_image_has_finite_psnr_and_lower_ssim():
    rng = np.random.default_rng(1)
    arr = (rng.random((64, 64, 3)) * 255).astype(np.uint8)
    noisy = np.clip(arr.astype(np.int32) + rng.integers(-30, 30, arr.shape), 0, 255).astype(np.uint8)
    report = compare(arr, noisy)
    assert not report.identical
    assert 0 < report.psnr_db < 100
    assert 0.0 <= report.ssim < 1.0


def test_shape_mismatch_raises():
    a = np.zeros((10, 10, 3), dtype=np.uint8)
    b = np.zeros((10, 11, 3), dtype=np.uint8)
    with pytest.raises(ValueError):
        compare(a, b)


def test_more_different_images_have_worse_psnr():
    rng = np.random.default_rng(2)
    arr = (rng.random((48, 48, 3)) * 255).astype(np.uint8)
    small_noise = np.clip(arr.astype(np.int32) + rng.integers(-5, 5, arr.shape), 0, 255).astype(np.uint8)
    big_noise = np.clip(arr.astype(np.int32) + rng.integers(-60, 60, arr.shape), 0, 255).astype(np.uint8)
    r_small = compare(arr, small_noise)
    r_big = compare(arr, big_noise)
    assert r_small.psnr_db > r_big.psnr_db
    assert r_small.ssim > r_big.ssim


def test_float_hdr_images_compare_correctly():
    rng = np.random.default_rng(3)
    arr = (rng.random((32, 32, 3)).astype(np.float32)) * 4.0
    report = compare(arr, arr.copy())
    assert report.identical
    slightly_off = arr + 0.01
    report2 = compare(arr, slightly_off)
    assert not report2.identical
    assert report2.psnr_db > 20
