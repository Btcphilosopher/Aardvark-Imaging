import numpy as np
import pytest

import axif
from axif import exporters, importers


def _write_png(path, arr):
    import imagecodecs
    with open(path, "wb") as f:
        f.write(imagecodecs.png_encode(arr))


def _write_tiff(path, arr):
    import tifffile
    tifffile.imwrite(str(path), arr)


def _write_exr(path, arr):
    import imagecodecs
    with open(path, "wb") as f:
        f.write(imagecodecs.exr_encode(arr))


@pytest.fixture
def rgb_u8():
    rng = np.random.default_rng(100)
    return (rng.random((80, 96, 3)) * 255).astype(np.uint8)


@pytest.fixture
def rgb_u16():
    rng = np.random.default_rng(101)
    return (rng.random((60, 70, 3)) * 65535).astype(np.uint16)


def test_png_import_is_lossless(tmp_path, rgb_u8):
    p = tmp_path / "in.png"
    _write_png(p, rgb_u8)
    canonical = importers.import_png(str(p))
    assert np.array_equal(canonical.array, rgb_u8)


def test_tiff_import_preserves_16bit(tmp_path, rgb_u16):
    p = tmp_path / "in.tif"
    _write_tiff(p, rgb_u16)
    canonical = importers.import_tiff(str(p))
    assert canonical.dtype == np.uint16
    assert np.array_equal(canonical.array, rgb_u16)


def test_exr_import_preserves_float(tmp_path):
    rng = np.random.default_rng(102)
    arr = (rng.random((20, 24, 3)).astype(np.float32)) * 5.0
    p = tmp_path / "in.exr"
    _write_exr(p, arr)
    canonical = importers.import_exr(str(p))
    assert canonical.dtype == np.float32
    assert np.array_equal(canonical.array, arr)
    assert canonical.colour_space.reference_kind == "scene-linear"


def test_source_to_axif_to_target_png_round_trip(tmp_path, rgb_u8):
    src = tmp_path / "in.png"
    _write_png(src, rgb_u8)
    axif_path = tmp_path / "mid.axif"
    axif.convert(str(src), str(axif_path))
    out_path = tmp_path / "out.png"
    axif.convert(str(axif_path), str(out_path))
    roundtripped = importers.import_png(str(out_path)).array
    assert np.array_equal(roundtripped, rgb_u8), "PNG -> AXIF -> PNG must be pixel-exact (both lossless)"


def test_source_to_axif_to_target_tiff_round_trip(tmp_path, rgb_u16):
    src = tmp_path / "in.tif"
    _write_tiff(src, rgb_u16)
    axif_path = tmp_path / "mid.axif"
    axif.convert(str(src), str(axif_path))
    out_path = tmp_path / "out.tif"
    axif.convert(str(axif_path), str(out_path))
    roundtripped = importers.import_tiff(str(out_path)).array
    assert np.array_equal(roundtripped, rgb_u16)


def test_source_to_axif_to_target_exr_round_trip(tmp_path):
    rng = np.random.default_rng(103)
    arr = (rng.random((16, 20, 3)).astype(np.float32)) * 3.0
    src = tmp_path / "in.exr"
    _write_exr(src, arr)
    axif_path = tmp_path / "mid.axif"
    axif.convert(str(src), str(axif_path), codec_id=axif.codec.CODEC_EXR_LOSSLESS)
    out_path = tmp_path / "out.exr"
    axif.convert(str(axif_path), str(out_path))
    roundtripped = importers.import_exr(str(out_path)).array
    assert np.array_equal(roundtripped, arr)


def test_jpeg_export_rejects_alpha_rather_than_silently_dropping_it(tmp_path):
    arr = (np.random.default_rng(1).random((10, 10, 4)) * 255).astype(np.uint8)
    canonical = axif.CanonicalImage.from_array(arr)
    with pytest.raises(axif.AxifCodecError):
        exporters.export_jpeg(canonical, str(tmp_path / "out.jpg"))


def test_exr_export_rejects_integer_dtype_rather_than_silently_casting(tmp_path):
    arr = (np.random.default_rng(2).random((10, 10, 3)) * 255).astype(np.uint8)
    canonical = axif.CanonicalImage.from_array(arr)
    with pytest.raises(axif.AxifCodecError):
        exporters.export_exr(canonical, str(tmp_path / "out.exr"))


def test_import_auto_dispatches_on_extension(tmp_path, rgb_u8):
    p = tmp_path / "in.png"
    _write_png(p, rgb_u8)
    canonical = importers.import_auto(str(p))
    assert np.array_equal(canonical.array, rgb_u8)


def test_import_unknown_extension_raises(tmp_path):
    p = tmp_path / "in.xyz"
    p.write_bytes(b"not an image")
    with pytest.raises(axif.AxifCodecError):
        importers.import_auto(str(p))


def test_jpeg_lossy_roundtrip_is_close_not_exact(tmp_path, rgb_u8):
    src = tmp_path / "in.jpg"
    import imagecodecs
    with open(src, "wb") as f:
        f.write(imagecodecs.jpeg8_encode(rgb_u8, level=85))
    canonical = importers.import_jpeg(str(src))
    axif_path = tmp_path / "mid.axif"
    axif.AxifWriter(canonical, codec_id=axif.codec.CODEC_ZLIB_LOSSLESS).write(str(axif_path))
    r = axif.open(str(axif_path))
    back = r.to_numpy()
    # AXIF stores whatever pixels it was given losslessly, even though the
    # *source* JPEG was already lossy — the AXIF stage itself introduces
    # zero further error.
    assert np.array_equal(back, canonical.array)
    r.close()
