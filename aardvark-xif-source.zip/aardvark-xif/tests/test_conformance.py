import glob
import os

import numpy as np
import pytest

import axif

CONFORMANCE_DIR = os.path.join(os.path.dirname(__file__), "..", "test-vectors", "conformance")
CORRUPT_DIR = os.path.join(os.path.dirname(__file__), "..", "test-vectors", "corrupt")


def _fixture_files():
    return sorted(glob.glob(os.path.join(CONFORMANCE_DIR, "*.axif")))


@pytest.mark.skipif(not _fixture_files(), reason="run test-vectors/generate_fixtures.py first")
@pytest.mark.parametrize("path", _fixture_files())
def test_conformance_fixture_opens_and_validates(path):
    r = axif.open(path)
    report = r.validate(strict=True)
    assert report.ok, f"{path}: {report.issues}"
    r.close()


@pytest.mark.skipif(not _fixture_files(), reason="run test-vectors/generate_fixtures.py first")
@pytest.mark.parametrize("path", _fixture_files())
def test_conformance_fixture_decodes_without_raising(path):
    r = axif.open(path)
    arr = r.to_numpy()
    assert arr.shape == (r.height, r.width, len(r.channels))
    thumb = r.read_thumbnail()
    if thumb is not None:
        assert thumb.ndim == 3
    r.close()


def _corrupt_files():
    return sorted(glob.glob(os.path.join(CORRUPT_DIR, "*.axif")))


@pytest.mark.skipif(not _corrupt_files(), reason="run test-vectors/generate_fixtures.py first")
@pytest.mark.parametrize("path", _corrupt_files())
def test_corrupt_fixture_never_crashes_the_process(path):
    """SPEC S.83/S.119: malformed input must fail *safely* (a clean
    AxifError) — never an unhandled exception type, never a hang."""
    try:
        r = axif.open(path)
        report = r.validate(strict=True)
        # either validate() reports problems, or (for a corruption that
        # happens to land in bytes that don't affect structural fields)
        # the file may still validate structurally sound; both are fine.
        # What matters is that we got here without an unhandled crash.
        r.close()
    except axif.AxifError:
        pass  # a clean, typed rejection is a pass
