import struct

import pytest

from axif.container import (
    FOOTER_SIZE,
    HEADER_SIZE,
    INDEX_ENTRY_SIZE,
    MAGIC,
    Header,
    IndexEntry,
    pack_footer,
    unpack_footer,
    unpack_index,
    pack_index,
)
from axif.errors import AxifFormatError


def test_header_size_is_128_bytes():
    assert HEADER_SIZE == 128


def test_index_entry_size_is_64_bytes():
    assert INDEX_ENTRY_SIZE == 64


def test_footer_size_is_64_bytes():
    assert FOOTER_SIZE == 64


def test_magic_is_8_bytes_and_starts_with_high_bit_byte():
    assert len(MAGIC) == 8
    assert MAGIC[0] == 0x89
    assert MAGIC[1:5] == b"AXIF"


def test_header_pack_unpack_roundtrip():
    h = Header(
        format_major=1, format_minor=2, format_revision=3, flags=0xABCD,
        manifest_offset=128, manifest_length=1000,
        index_offset=1128, index_length=6400,
        footer_offset=99999, footer_length=64, file_length=100063,
    )
    packed = h.pack()
    assert len(packed) == HEADER_SIZE
    h2 = Header.unpack(packed)
    assert h2 == h


def test_header_rejects_bad_magic():
    bad = b"\x00" * HEADER_SIZE
    with pytest.raises(AxifFormatError):
        Header.unpack(bad)


def test_header_rejects_truncated_bytes():
    with pytest.raises(AxifFormatError):
        Header.unpack(b"\x89AXIF\r\n\x1a")


def test_index_entry_pack_unpack_roundtrip():
    e = IndexEntry(
        segment_type=0, level=3, tile_x=17, tile_y=9, channel_group=0,
        codec_id=1, offset=123456789, length=4096, uncompressed_length=65536,
        crc32c=0xDEADBEEF,
    )
    packed = e.pack()
    assert len(packed) == INDEX_ENTRY_SIZE
    e2 = IndexEntry.unpack(packed)
    assert e2.segment_type == e.segment_type
    assert e2.level == e.level
    assert e2.tile_x == e.tile_x
    assert e2.tile_y == e.tile_y
    assert e2.codec_id == e.codec_id
    assert e2.offset == e.offset
    assert e2.length == e.length
    assert e2.uncompressed_length == e.uncompressed_length
    assert e2.crc32c == e.crc32c


def test_index_block_roundtrip_multiple_entries():
    entries = [
        IndexEntry(0, i, i % 4, i // 4, 0, 1, i * 1000, 900, 4096, i)
        for i in range(37)
    ]
    blob = pack_index(entries)
    assert len(blob) == 37 * INDEX_ENTRY_SIZE
    back = unpack_index(blob)
    assert len(back) == 37
    for a, b in zip(entries, back):
        assert a.offset == b.offset and a.tile_x == b.tile_x and a.tile_y == b.tile_y


def test_index_block_rejects_misaligned_length():
    with pytest.raises(AxifFormatError):
        unpack_index(b"\x00" * (INDEX_ENTRY_SIZE + 3))


def test_footer_pack_unpack_roundtrip():
    digest = bytes(range(32))
    footer = pack_footer(digest)
    assert len(footer) == FOOTER_SIZE
    back = unpack_footer(footer)
    assert back == digest


def test_footer_rejects_bad_magic():
    with pytest.raises(AxifFormatError):
        unpack_footer(b"NOTAXIF!" + b"\x00" * 56)
