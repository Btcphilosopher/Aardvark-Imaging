import numpy as np
import pytest

import axif
from axif import codec
from axif.core import ChannelDescriptor, gray_channels, rgb_channels, rgba_channels


def make_image(w, h, c, dtype, seed=0):
    rng = np.random.default_rng(seed)
    if np.issubdtype(dtype, np.integer):
        info = np.iinfo(dtype)
        arr = rng.integers(0, min(info.max, 65535) + 1, size=(h, w, c)).astype(dtype)
    else:
        arr = (rng.random((h, w, c)).astype(np.float32) * 2.0)
        arr = arr.astype(dtype)
    return arr


@pytest.mark.parametrize("w,h,c,dtype", [
    (300, 257, 3, np.uint8),     # odd, non-multiple of common tile sizes
    (128, 128, 1, np.uint8),     # grayscale, exact multiple
    (200, 150, 4, np.uint8),     # RGBA
    (177, 233, 3, np.uint16),    # 16-bit, prime-ish dims
    (64, 64, 3, np.float32),     # HDR float
    (1, 1, 3, np.uint8),         # degenerate 1x1
    (5, 517, 3, np.uint8),       # very thin image
])
def test_lossless_roundtrip_various_shapes(tmp_path, w, h, c, dtype):
    arr = make_image(w, h, c, dtype, seed=hash((w, h, c, str(dtype))) % (2**31))
    channels = {1: gray_channels, 3: rgb_channels, 4: rgba_channels}.get(c, lambda: [ChannelDescriptor(f"C{i}") for i in range(c)])()
    img = axif.CanonicalImage.from_array(arr, channels=channels)
    out = tmp_path / "test.axif"
    axif.AxifWriter(img, tile_width=64, tile_height=48, codec_id=codec.CODEC_ZLIB_LOSSLESS).write(str(out))
    with axif.open(str(out)) as r:
        assert r.width == w and r.height == h
        back = r.to_numpy()
        assert back.dtype == arr.dtype
        assert np.array_equal(back, arr)
        vr = r.validate(strict=True)
        assert vr.ok, vr.issues


def test_edge_tiles_are_correctly_sized(tmp_path):
    # 100x100 image with 64x64 tiles -> level0 has 2x2 tiles, the right
    # column and bottom row are partial (36px) tiles. Exercise the exact
    # boundary.
    arr = make_image(100, 100, 3, np.uint8, seed=1)
    img = axif.CanonicalImage.from_array(arr)
    out = tmp_path / "edge.axif"
    axif.AxifWriter(img, tile_width=64, tile_height=64).write(str(out))
    r = axif.open(str(out))
    lvl = r.level_info(0)
    assert lvl.tiles_x == 2 and lvl.tiles_y == 2
    corner_tile = r.read_tile(0, 1, 1)
    assert corner_tile.shape == (36, 36, 3)
    assert np.array_equal(corner_tile, arr[64:100, 64:100, :])
    r.close()


def test_multiple_pyramid_levels_generated(tmp_path):
    arr = make_image(1000, 800, 3, np.uint8, seed=2)
    img = axif.CanonicalImage.from_array(arr)
    out = tmp_path / "pyr.axif"
    axif.AxifWriter(img, tile_width=256, tile_height=256).write(str(out))
    r = axif.open(str(out))
    assert r.num_levels >= 3
    for i in range(1, r.num_levels):
        prev, cur = r.level_info(i - 1), r.level_info(i)
        assert cur.width <= prev.width and cur.height <= prev.height
    # level dims should roughly halve
    l0, l1 = r.level_info(0), r.level_info(1)
    assert abs(l0.width / 2 - l1.width) <= 1
    r.close()


def test_roi_read_matches_full_image_crop(tmp_path):
    arr = make_image(600, 500, 3, np.uint8, seed=3)
    img = axif.CanonicalImage.from_array(arr)
    out = tmp_path / "roi.axif"
    axif.AxifWriter(img, tile_width=128, tile_height=128).write(str(out))
    r = axif.open(str(out))
    for (x, y, w, h) in [(0, 0, 50, 50), (130, 5, 200, 300), (590, 490, 50, 50), (0, 0, 600, 500)]:
        region = r.read_region(x, y, w, h)
        x1, y1 = min(600, x + w), min(500, y + h)
        expected = arr[y:y1, x:x1, :]
        assert region.shape == expected.shape
        assert np.array_equal(region, expected), f"mismatch at region {(x,y,w,h)}"
    r.close()


def test_roi_decodes_fewer_bytes_than_full_image(tmp_path):
    arr = make_image(2048, 2048, 3, np.uint8, seed=4)
    img = axif.CanonicalImage.from_array(arr)
    out = tmp_path / "big.axif"
    axif.AxifWriter(img, tile_width=256, tile_height=256, generate_preview=False, generate_thumbnail=False).write(str(out))

    r_full = axif.open(str(out))
    r_full.read_level(0)
    full_bytes = r_full.stats["bytes_read"]
    r_full.close()

    r_roi = axif.open(str(out))
    r_roi.read_region(1000, 1000, 100, 100)
    roi_bytes = r_roi.stats["bytes_read"]
    r_roi.close()

    assert roi_bytes < full_bytes / 10, "ROI read should touch a small fraction of the file"


def test_preview_and_thumbnail_present_and_smaller(tmp_path):
    arr = make_image(3000, 2000, 3, np.uint8, seed=5)
    img = axif.CanonicalImage.from_array(arr)
    out = tmp_path / "prev.axif"
    axif.AxifWriter(img, tile_width=512, tile_height=512, preview_max_dim=800, thumbnail_max_dim=128).write(str(out))
    r = axif.open(str(out))
    prev = r.read_preview()
    thumb = r.read_thumbnail()
    assert prev is not None and thumb is not None
    assert max(prev.shape[:2]) <= 800
    assert max(thumb.shape[:2]) <= 128
    assert thumb.shape[0] < prev.shape[0]
    r.close()


def test_colour_space_roundtrips(tmp_path):
    arr = make_image(64, 64, 3, np.uint16, seed=6)
    img = axif.CanonicalImage.from_array(arr, colour_space=axif.rec2020_pq())
    out = tmp_path / "cs.axif"
    axif.AxifWriter(img, tile_width=32, tile_height=32).write(str(out))
    r = axif.open(str(out))
    assert r.colour_space.name == "Rec2020"
    assert r.colour_space.transfer_function == "PQ"
    r.close()


def test_icc_profile_roundtrips_byte_exact(tmp_path):
    arr = make_image(40, 40, 3, np.uint8, seed=7)
    fake_icc = bytes(range(256)) * 4  # not a real ICC profile, just opaque bytes to round-trip
    cs = axif.ColourSpace(icc_profile=fake_icc)
    img = axif.CanonicalImage.from_array(arr, colour_space=cs)
    out = tmp_path / "icc.axif"
    axif.AxifWriter(img, tile_width=16, tile_height=16).write(str(out))
    r = axif.open(str(out))
    assert r.colour_space.icc_profile == fake_icc
    r.close()


def test_metadata_and_provenance_roundtrip(tmp_path):
    arr = make_image(32, 32, 3, np.uint8, seed=8)
    meta = axif.camera_metadata(model="Aardvark C1", iso=400, aperture_f=2.8, sensor_scan_mode="global-shutter")
    prov = axif.Provenance(source_format="RAW")
    prov.add_stage("demosaic", algorithm="AHD", software="aardvark-isp")
    prov.add_stage("tone_map", algorithm="reinhard")
    img = axif.CanonicalImage.from_array(arr, metadata=meta, provenance=prov)
    out = tmp_path / "meta.axif"
    axif.AxifWriter(img, tile_width=16, tile_height=16).write(str(out))
    r = axif.open(str(out))
    assert r.metadata.get("camera", "model") == "Aardvark C1"
    assert r.metadata.get("camera", "iso") == 400
    assert len(r.provenance.stages) == 2
    assert r.provenance.stages[0].algorithm == "AHD"
    r.close()


def test_different_codecs_all_produce_readable_files(tmp_path):
    arr = make_image(96, 80, 3, np.uint8, seed=9)
    for cid in [codec.CODEC_RAW, codec.CODEC_ZLIB_LOSSLESS, codec.CODEC_ZSTD_LOSSLESS,
                codec.CODEC_JPEGXL_LOSSLESS, codec.CODEC_JPEG2000_LOSSLESS]:
        if not codec.is_available(cid):
            continue
        img = axif.CanonicalImage.from_array(arr)
        out = tmp_path / f"codec_{cid}.axif"
        axif.AxifWriter(img, tile_width=32, tile_height=32, codec_id=cid).write(str(out))
        r = axif.open(str(out))
        back = r.to_numpy()
        assert np.array_equal(back, arr), f"codec {cid} did not round-trip losslessly"
        r.close()


def test_write_report_fields(tmp_path):
    arr = make_image(200, 200, 3, np.uint8, seed=10)
    img = axif.CanonicalImage.from_array(arr)
    out = tmp_path / "report.axif"
    report = axif.AxifWriter(img, tile_width=64, tile_height=64).write(str(out))
    assert report.tile_count > 0
    assert report.level_count >= 1
    assert report.file_size == out.stat().st_size


def test_wrong_major_version_rejected(tmp_path):
    arr = make_image(20, 20, 3, np.uint8, seed=11)
    img = axif.CanonicalImage.from_array(arr)
    out = tmp_path / "ver.axif"
    axif.AxifWriter(img, tile_width=16, tile_height=16).write(str(out))
    data = bytearray(open(out, "rb").read())
    # format_major is a u16 at byte offset 8 (little-endian)
    data[8] = 99
    data[9] = 0
    bad = tmp_path / "ver_bad.axif"
    bad.write_bytes(bytes(data))
    with pytest.raises(axif.AxifVersionError):
        axif.open(str(bad))
