import hashlib
import json
import struct

import numpy as np
import pytest

import axif
from axif.container import Header, HEADER_SIZE, pack_footer
from axif.errors import (
    AxifChecksumError,
    AxifFormatError,
    AxifSecurityError,
    AxifVersionError,
)
from axif.security import ResourceLimits


def _write_sample(path, w=200, h=180, tile=64, seed=0):
    rng = np.random.default_rng(seed)
    arr = (rng.random((h, w, 3)) * 255).astype(np.uint8)
    img = axif.CanonicalImage.from_array(arr)
    axif.AxifWriter(img, tile_width=tile, tile_height=tile).write(str(path))
    return arr


def _flip_byte(path, offset, dst):
    data = bytearray(open(path, "rb").read())
    data[offset] ^= 0xFF
    dst.write_bytes(bytes(data))


def test_bad_magic_rejected(tmp_path):
    f = tmp_path / "bad_magic.axif"
    f.write_bytes(b"\x00\x00NOPE\x00\x00" + b"\x00" * 200)
    with pytest.raises(AxifFormatError):
        axif.open(str(f))


def test_empty_file_rejected(tmp_path):
    f = tmp_path / "empty.axif"
    f.write_bytes(b"")
    with pytest.raises(AxifFormatError):
        axif.open(str(f))


def test_truncated_after_header_rejected(tmp_path):
    good = tmp_path / "good.axif"
    _write_sample(good)
    data = open(good, "rb").read()
    truncated = tmp_path / "trunc.axif"
    truncated.write_bytes(data[:HEADER_SIZE + 10])
    with pytest.raises(AxifFormatError):
        axif.open(str(truncated))


def test_truncated_mid_data_detected_by_bounds_check(tmp_path):
    good = tmp_path / "good.axif"
    _write_sample(good, w=600, h=600, tile=64)
    data = open(good, "rb").read()
    half = tmp_path / "half.axif"
    half.write_bytes(data[: len(data) // 2])
    with pytest.raises(AxifSecurityError):
        axif.open(str(half))


def test_corrupted_manifest_bytes_raise_format_error(tmp_path):
    good = tmp_path / "good.axif"
    _write_sample(good)
    corrupt = tmp_path / "corrupt_manifest.axif"
    # byte 150 lands inside the small manifest JSON block for this fixture
    _flip_byte(good, 150, corrupt)
    with pytest.raises(AxifFormatError):
        axif.open(str(corrupt))


def test_corrupted_tile_detected_via_checksum(tmp_path):
    good = tmp_path / "good.axif"
    arr = _write_sample(good, w=300, h=300, tile=64)
    r = axif.open(str(good))
    entry = r._entries[(0, 0, 0, 0, 0)]  # first level-0 tile
    r.close()
    corrupt = tmp_path / "corrupt_tile.axif"
    _flip_byte(good, entry.offset + entry.length // 2, corrupt)
    r2 = axif.open(str(corrupt))
    with pytest.raises(AxifChecksumError):
        r2.to_numpy()
    r2.close()


def test_validate_reports_whole_file_hash_mismatch(tmp_path):
    good = tmp_path / "good.axif"
    arr = _write_sample(good, w=300, h=300, tile=64)
    r = axif.open(str(good))
    entry = r._entries[(0, 0, 0, 0, 0)]
    r.close()
    corrupt = tmp_path / "corrupt.axif"
    _flip_byte(good, entry.offset + 1, corrupt)
    r2 = axif.open(str(corrupt))
    report = r2.validate(strict=True)
    assert not report.ok
    assert any("SHA-256" in issue for issue in report.issues)
    r2.close()


def _build_manifest_only_file(tmp_path, manifest_dict, name="crafted.axif"):
    mbytes = json.dumps(manifest_dict).encode("utf-8")
    hdr = Header(manifest_offset=HEADER_SIZE, manifest_length=len(mbytes),
                 index_offset=HEADER_SIZE + len(mbytes), index_length=0,
                 footer_offset=HEADER_SIZE + len(mbytes), footer_length=64,
                 file_length=HEADER_SIZE + len(mbytes) + 64)
    body = hdr.pack() + mbytes
    footer = pack_footer(hashlib.sha256(body).digest())
    path = tmp_path / name
    path.write_bytes(body + footer)
    return path


def _minimal_manifest(width, height, tile=512):
    return {
        "axif_manifest_version": 1,
        "format": {"major": 1, "minor": 0, "revision": 0},
        "profile": "master",
        "image": {
            "width": width, "height": height, "pixel_format": "UINT8",
            "channels": [{"name": "R", "semantic": "red", "unit": None,
                          "colour_association": "RGB", "range": None}],
            "tile_width": tile, "tile_height": tile,
            "levels": [{"level": 0, "width": width, "height": height,
                        "tile_width": tile, "tile_height": tile}],
        },
        "colour": {"name": "sRGB", "primaries": None, "white_point": [0.3127, 0.329],
                   "transfer_function": "sRGB", "reference_kind": "display-referred",
                   "has_icc_profile": False},
        "compression": {"codec_id": 1, "codec_name": "AXIF-ZLIB-LOSSLESS"},
        "metadata": {"fields": {}}, "provenance": {"stages": []},
        "preview": None, "thumbnail": None, "has_icc_profile": False, "extensions": [],
    }


def test_oversized_declared_dimensions_rejected(tmp_path):
    manifest = _minimal_manifest(999_999_999, 999_999_999)
    path = _build_manifest_only_file(tmp_path, manifest)
    with pytest.raises(AxifSecurityError):
        axif.open(str(path))


def test_negative_dimensions_rejected(tmp_path):
    manifest = _minimal_manifest(-5, 100)
    path = _build_manifest_only_file(tmp_path, manifest)
    with pytest.raises(AxifSecurityError):
        axif.open(str(path))


def test_unknown_pixel_format_rejected(tmp_path):
    manifest = _minimal_manifest(10, 10)
    manifest["image"]["pixel_format"] = "UINT9000"
    path = _build_manifest_only_file(tmp_path, manifest)
    with pytest.raises(AxifFormatError):
        axif.open(str(path))


def test_custom_resource_limits_are_enforced(tmp_path):
    good = tmp_path / "good.axif"
    _write_sample(good, w=500, h=500, tile=64)
    strict_limits = ResourceLimits(max_width=100, max_height=100)
    with pytest.raises(AxifSecurityError):
        axif.open(str(good), limits=strict_limits)


def test_max_total_decoded_bytes_blocks_full_decode_but_allows_roi(tmp_path):
    good = tmp_path / "good.axif"
    arr = _write_sample(good, w=2000, h=2000, tile=256)
    tiny_budget = ResourceLimits(max_total_decoded_bytes=1024)  # 1 KB — smaller than the full image
    r = axif.open(str(good), limits=tiny_budget)
    with pytest.raises(AxifSecurityError):
        r.to_numpy()
    # ROI of a genuinely small region should still succeed under the same limits
    region = r.read_region(0, 0, 8, 8)
    assert region.shape == (8, 8, 3)
    r.close()


def test_declared_uncompressed_length_wildly_exceeding_actual_is_rejected(tmp_path):
    # Craft an index entry claiming a 50 GB decompressed tile from a tiny
    # compressed payload — a classic decompression-bomb shape.
    import zlib
    from axif.container import IndexEntry, pack_index, SEGMENT_TILE

    small_payload = zlib.compress(b"\x00" * 100)
    manifest = _minimal_manifest(512, 512)
    mbytes = json.dumps(manifest).encode("utf-8")
    entry = IndexEntry(SEGMENT_TILE, 0, 0, 0, 0, 1, 0, len(small_payload),
                        50 * 1024 ** 3, 0)  # 50 GB declared, crc filled below
    from axif.checksums import crc32c
    entry.crc32c = crc32c(small_payload)
    index_bytes = pack_index([entry])

    hdr = Header(manifest_offset=HEADER_SIZE, manifest_length=len(mbytes),
                 index_offset=HEADER_SIZE + len(mbytes), index_length=len(index_bytes),
                 footer_offset=HEADER_SIZE + len(mbytes) + len(index_bytes) + len(small_payload),
                 footer_length=64,
                 file_length=HEADER_SIZE + len(mbytes) + len(index_bytes) + len(small_payload) + 64)
    body = hdr.pack() + mbytes + index_bytes + small_payload
    footer = pack_footer(hashlib.sha256(body).digest())
    path = tmp_path / "bomb.axif"
    path.write_bytes(body + footer)

    r = axif.open(str(path))
    with pytest.raises(AxifSecurityError):
        r.read_tile(0, 0, 0)
    r.close()
