import math

from axif.pyramid import PyramidPlan, downsample_box, ProceduralTileSource
import numpy as np


def test_pyramid_level0_matches_master():
    plan = PyramidPlan(1920, 1080, 512, 512)
    levels = plan.levels()
    assert levels[0].width == 1920 and levels[0].height == 1080


def test_pyramid_terminates_when_smaller_than_tile():
    plan = PyramidPlan(1920, 1080, 512, 512)
    levels = plan.levels()
    last = levels[-1]
    assert last.width <= 512 and last.height <= 512
    # the level before the last must have been bigger than a tile in at
    # least one dimension (otherwise it should have been the last one)
    if len(levels) > 1:
        prev = levels[-2]
        assert prev.width > 512 or prev.height > 512


def test_pyramid_roughly_halves_each_level():
    plan = PyramidPlan(4000, 3000, 256, 256)
    levels = plan.levels()
    for i in range(1, len(levels)):
        prev, cur = levels[i - 1], levels[i]
        assert abs(cur.width - math.ceil(prev.width / 2)) <= 1
        assert abs(cur.height - math.ceil(prev.height / 2)) <= 1


def test_pyramid_tile_count_matches_ceil_division():
    plan = PyramidPlan(1000, 700, 300, 300)
    lvl = plan.levels()[0]
    assert lvl.tiles_x == math.ceil(1000 / 300) == 4
    assel = math.ceil(700 / 300)
    assert lvl.tiles_y == assel == 3


def test_pyramid_respects_max_levels():
    plan = PyramidPlan(1_000_000, 1_000_000, 64, 64, max_levels=5)
    levels = plan.levels()
    assert len(levels) == 5


def test_downsample_box_preserves_flat_colour():
    arr = np.full((64, 64, 3), 200, dtype=np.uint8)
    down = downsample_box(arr, 32, 32)
    assert down.shape == (32, 32, 3)
    assert np.all(down == 200)


def test_downsample_box_preserves_dtype():
    arr = (np.random.default_rng(0).random((40, 40, 3)) * 65535).astype(np.uint16)
    down = downsample_box(arr, 20, 20)
    assert down.dtype == np.uint16


def test_procedural_tile_source_consistent_across_levels():
    def gen(x, y):
        # deterministic pattern: encode coordinates into RGB
        r = (x % 256).astype(np.uint8)
        g = (y % 256).astype(np.uint8)
        b = ((x + y) % 256).astype(np.uint8)
        return np.stack([r, g, b], axis=-1)

    src = ProceduralTileSource(gen, master_width=4096, master_height=4096, num_channels=3)
    # level 0, tile (0,0), 8x8
    tile0 = src(0, 0, 0, 8, 8)
    assert tile0.shape == (8, 8, 3)
    assert tile0[0, 0, 0] == 0 and tile0[0, 0, 1] == 0
    # level 1 (half-res): pixel (0,0) at level 1 corresponds to level-0
    # coordinate (0,0) too (scale=2, so level-1 x=0 -> level-0 x=0)
    tile1 = src(1, 0, 0, 8, 8)
    assert tile1[0, 1, 0] == 2  # level-1 x=1 -> level-0 x=2
