# Changelog

## 0.1.0 — initial reference implementation

Built end-to-end in one session: specification, binary container,
codec architecture, security hardening, importers/exporters, CLI,
118-test suite, a real 15360x8640 streaming test fixture, measured
benchmarks, and a deep-zoom viewer prototype.

### Real bugs found and fixed via testing during this build

Recorded here deliberately, per this project's own stated priority order
(SPEC S.133: fidelity, then correctness, then performance) — these were
caught by tests actually failing, not by inspection, and are fixed in the
code you're reading, not worked around:

- **`AxifReader.stats` initialised after first use.** The ICC-profile
  read inside `__init__` happened before `self.stats` was assigned,
  so any file with an embedded ICC profile raised `AttributeError` on
  open. Found by `test_icc_profile_roundtrips_byte_exact`. Fixed by
  moving the stats-dict initialisation earlier in `__init__`.
- **Manifest parser didn't catch `UnicodeDecodeError`.** A corrupted
  manifest byte range that happened to be invalid UTF-8 (rather than
  merely invalid JSON) raised a raw `UnicodeDecodeError` instead of the
  intended `AxifFormatError`, breaking the "always fail with a typed
  AxifError" guarantee (SECURITY.md). Found via a targeted corruption
  test. Fixed by catching `(json.JSONDecodeError, UnicodeDecodeError)`
  together.
- **PNG preview/thumbnail codec selected for >4-channel images.** The
  writer's aux-segment codec heuristic picked `PNG-LOSSLESS` for any
  8-bit image without checking channel count; PNG (and the underlying
  `imagecodecs` binding) doesn't support 5+ channels, so a 5-band
  multichannel/multispectral fixture crashed during preview generation.
  Found while generating `test-vectors/conformance/multichannel_5.axif`.
  Fixed by gating the PNG choice on `num_channels <= 4` and falling back
  to the tile codec otherwise.
- **Self-describing codecs silently dropped the channel axis for
  grayscale images.** `imagecodecs.png_decode` (and other self-describing
  codecs) return a 2D `(H, W)` array for single-channel images rather
  than `(H, W, 1)`. `read_tile()`'s shape check happened to pass anyway
  (comparing only the first two dimensions), but `read_preview()`/
  `read_thumbnail()` returned the bare 2D array to callers, breaking the
  documented "every array this reader returns is `(H, W, C)`" contract.
  Found by the conformance-fixture test walking `gray_u8.axif`. Fixed by
  normalising to 3D immediately after every self-describing-codec decode.
- **Deep-zoom viewer: wrong world-space scale factor for hotspot tiles.**
  While reviewing `viewer/index_template.html` (no browser was available
  to visually test the published artifact directly, so this was caught
  by manually re-deriving the coordinate math), the level-0/level-1 tile
  placement function conflated "pyramid level" with "power-of-two
  exponent" and was called with off-by-one arguments, which would have
  rendered hotspot tiles at 2x/4x the correct scale and in the wrong
  position relative to the coarse background. Fixed by renaming the
  parameter to the actual pyramid level and correcting both call sites;
  re-derived the expected world-space alignment by hand
  (`tx * tile_width * 2^level`) to confirm the fix before re-publishing.
- **`pickCoarseLevel()` in the viewer effectively never selected the
  coarsest embedded pyramid levels.** The original threshold (`nativeScale
  >= scale * 0.6`, checked in finest-to-coarsest order) picked the
  finest embedded level almost regardless of zoom, because the fudge
  factor made the finest level's condition true too easily. This wasn't
  a crash, just a missed demonstration of adaptive level-of-detail
  selection. Fixed by switching to a proper coarsest-first mipmap
  selection rule and retuning the hotspot-detail zoom threshold.

None of the above were caught by writing the code carefully the first
time — they were caught by writing fixtures and tests that actually
exercise the paths (an ICC profile, a 5-channel image, a grayscale image,
a corrupted-but-not-quite-arbitrarily corrupted manifest) and then reading
the failures, which is the whole point of SPEC S.81-83's conformance
suite and this repository's own test-first approach.
