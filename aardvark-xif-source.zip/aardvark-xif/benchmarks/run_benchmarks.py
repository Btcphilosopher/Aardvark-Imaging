#!/usr/bin/env python3
"""
Reproduces the measurements in docs/BENCHMARKS.md. Requires the 16K
streaming fixture to exist first:

    python3 test-vectors/generate_fixtures.py --skip-conformance --skip-corrupt \
        --master-size 15360x8640

Then:

    python3 benchmarks/run_benchmarks.py
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "python"))

import axif
from axif import benchmark as bm

MASTER = os.path.join(os.path.dirname(__file__), "..", "test-vectors", "streaming", "master.axif")


def section_progressive_and_roi():
    print("## Progressive open + ROI (docs/BENCHMARKS.md §1, §4)\n")
    lat = bm.benchmark_progressive_open(MASTER)
    print(lat)
    roi = bm.benchmark_roi(MASTER, (7000, 4000, 1024, 1024))
    print()
    print("ROI benchmark (1024x1024 region from the 16K master):")
    print(roi)
    print()


def section_codec_comparison():
    print("## Codec comparison on real content (docs/BENCHMARKS.md §2)\n")
    r = axif.open(MASTER)
    crops = {
        "sky_gradient (smooth)": (2000, 200, 2048, 1024),
        "architecture (hard edges)": (2000, 1600, 2048, 1024),
        "grating (high-freq)": (2000, 3200, 2048, 1024),
        "foliage (organic noise)": (2000, 6200, 2048, 1024),
    }
    for name, (x, y, w, h) in crops.items():
        arr = r.read_region(x, y, w, h)
        results = bm.compare_against_formats(arr)
        print(bm.results_to_markdown(results, title=f"{name} — {w}x{h} crop of the real 16K master"))
        print()
    r.close()


if __name__ == "__main__":
    if not os.path.exists(MASTER):
        print(f"Missing {MASTER} — run test-vectors/generate_fixtures.py first.", file=sys.stderr)
        sys.exit(1)
    section_progressive_and_roi()
    section_codec_comparison()
