#!/usr/bin/env python3
"""
Generate the AXIF test-vector set (SPEC S.81 conformance suite, S.112-113
test images). Two kinds of output:

1. Small, fast "conformance" fixtures (test-vectors/conformance/): one
   AXIF file per SPEC-relevant combination (8-bit/16-bit/float, RGB/RGBA/
   grayscale/multichannel, with/without metadata, multiple tiles/levels),
   used by tests/test_conformance.py to assert every one opens, validates,
   and round-trips.

2. The flagship streaming demonstration image (test-vectors/streaming/
   master_16k.axif): a genuine 15360x8640 (16K) AXIF master, built via
   ProceduralTileSource so the *source* pixel data is never materialised
   as a single array — only one tile at a time ever exists in memory.
   The synthetic scene (SPEC S.112) is laid out in horizontal bands
   deliberately chosen to stress different compression failure modes:
   sky gradient (banding), a building silhouette band (hard edges /
   ringing), a high-frequency grating band (mosquito noise / aliasing),
   a smooth colour-transition band (banding), an organic foliage-like
   noise band, and a small-text typography strip (blur / legibility).

Run with --sizes to control which conformance fixtures are built and
--master-size WxH to control the flagship image size (default the true
16K 15360x8640; pass e.g. 4096x2160 for a fast smoke run).
"""
from __future__ import annotations

import argparse
import os
import shutil
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "python"))

import axif
from axif import codec
from axif.core import CanonicalImage, ChannelDescriptor
from axif.pyramid import ProceduralTileSource

HERE = os.path.dirname(os.path.abspath(__file__))


# --------------------------------------------------------------------------
# 1. Conformance fixtures
# --------------------------------------------------------------------------
def _rng_array(shape, dtype, seed):
    rng = np.random.default_rng(seed)
    if np.issubdtype(dtype, np.integer):
        info = np.iinfo(dtype)
        hi = min(info.max, 65535)
        return rng.integers(0, hi + 1, size=shape).astype(dtype)
    arr = rng.random(shape).astype(np.float32) * 3.0
    return arr.astype(dtype)


CONFORMANCE_SPECS = [
    # (name, width, height, channel-descs, dtype, tile, codec_id, extra)
    ("rgb_u8_basic", 512, 384, "rgb", np.uint8, 128, codec.CODEC_ZLIB_LOSSLESS, {}),
    ("rgb_u16_wide_tile", 640, 480, "rgb", np.uint16, 256, codec.CODEC_ZLIB_LOSSLESS, {}),
    ("rgba_u8_alpha", 400, 400, "rgba", np.uint8, 128, codec.CODEC_ZLIB_LOSSLESS, {}),
    ("gray_u8", 300, 300, "gray", np.uint8, 100, codec.CODEC_ZLIB_LOSSLESS, {}),
    ("float32_hdr", 256, 256, "rgb", np.float32, 64, codec.CODEC_EXR_LOSSLESS, {}),
    ("multichannel_5", 128, 128, 5, np.uint8, 64, codec.CODEC_ZLIB_LOSSLESS, {}),
    ("large_multi_tile", 2049, 1537, "rgb", np.uint8, 256, codec.CODEC_ZLIB_LOSSLESS, {}),
    ("odd_dims_1px_tiles", 37, 29, "rgb", np.uint8, 8, codec.CODEC_ZLIB_LOSSLESS, {}),
    ("jpegxl_lossless_u8", 300, 200, "rgb", np.uint8, 128, codec.CODEC_JPEGXL_LOSSLESS, {}),
    ("jpeg2000_lossless_u16", 300, 200, "rgb", np.uint16, 128, codec.CODEC_JPEG2000_LOSSLESS, {}),
]


def _channels_for(spec_channels, count_hint):
    if spec_channels == "rgb":
        from axif.core import rgb_channels
        return rgb_channels()
    if spec_channels == "rgba":
        from axif.core import rgba_channels
        return rgba_channels()
    if spec_channels == "gray":
        from axif.core import gray_channels
        return gray_channels()
    n = spec_channels if isinstance(spec_channels, int) else count_hint
    return [ChannelDescriptor(f"BAND{i}", semantic=f"spectral_band_{i}") for i in range(n)]


def build_conformance_fixtures(out_dir: str):
    os.makedirs(out_dir, exist_ok=True)
    manifest_lines = ["# AXIF conformance fixtures\n", "| name | dims | dtype | channels | codec | file |\n", "|---|---|---|---|---|---|\n"]
    for name, w, h, chspec, dtype, tile, cid, extra in CONFORMANCE_SPECS:
        channels = _channels_for(chspec, chspec if isinstance(chspec, int) else 3)
        arr = _rng_array((h, w, len(channels)), dtype, seed=abs(hash(name)) % (2 ** 31))
        meta = axif.camera_metadata(model="Aardvark Conformance Rig", iso=100) if "u8" in name else axif.Metadata()
        prov = axif.Provenance(source_format="synthetic")
        prov.add_stage("synthesize", algorithm="numpy.random.default_rng")
        img = CanonicalImage.from_array(arr, channels=channels, metadata=meta, provenance=prov)
        path = os.path.join(out_dir, f"{name}.axif")
        if not codec.is_available(cid):
            print(f"  skip {name}: codec unavailable in this environment")
            continue
        report = axif.AxifWriter(img, tile_width=tile, tile_height=tile, codec_id=cid).write(path)
        r = axif.open(path)
        back = r.to_numpy()
        ok = np.array_equal(back, arr) if codec.resolve(cid).lossless else True
        vr = r.validate(strict=True)
        r.close()
        assert vr.ok, f"{name}: validation failed: {vr.issues}"
        assert ok, f"{name}: lossless round-trip failed"
        manifest_lines.append(f"| {name} | {w}x{h} | {dtype.__name__} | {len(channels)} | {codec.resolve(cid).name} | {name}.axif |\n")
        print(f"  ok   {name:24s} {w}x{h} {dtype.__name__:8s} {codec.resolve(cid).name:20s} "
              f"{report.tile_count} tiles, {report.level_count} levels, {report.file_size:,} bytes")
    with open(os.path.join(out_dir, "MANIFEST.md"), "w") as f:
        f.writelines(manifest_lines)


# --------------------------------------------------------------------------
# 2. Malformed / hostile fixtures (SPEC S.119) — for axif-validate demos
# --------------------------------------------------------------------------
def build_corrupt_fixtures(out_dir: str, good_axif_path: str):
    os.makedirs(out_dir, exist_ok=True)

    def flip(name, offset):
        data = bytearray(open(good_axif_path, "rb").read())
        data[offset] ^= 0xFF
        with open(os.path.join(out_dir, name), "wb") as f:
            f.write(bytes(data))

    size = os.path.getsize(good_axif_path)
    flip("corrupt_header.axif", 2)
    flip("corrupt_manifest.axif", 140)
    flip("corrupt_tile_data.axif", size - 200)
    data = open(good_axif_path, "rb").read()
    with open(os.path.join(out_dir, "truncated_50pct.axif"), "wb") as f:
        f.write(data[: len(data) // 2])
    with open(os.path.join(out_dir, "truncated_header_only.axif"), "wb") as f:
        f.write(data[:64])
    print(f"  wrote 5 malformed fixtures to {out_dir}")


# --------------------------------------------------------------------------
# 3. Flagship streaming 16K master (SPEC S.112, S.139)
# --------------------------------------------------------------------------
def _render_text_banner(width: int, height: int) -> np.ndarray:
    from PIL import Image, ImageDraw, ImageFont
    banner = Image.new("RGB", (width, height), (18, 18, 22))
    draw = ImageDraw.Draw(banner)
    sizes = [10, 14, 18, 24, 32, 48, 64]
    y = 10
    text = "AARDVARK EXTENDED IMAGE FORMAT - 0123456789 - the quick brown fox jumps over the lazy dog"
    for size in sizes:
        try:
            font = ImageFont.load_default(size=size)
        except TypeError:
            font = ImageFont.load_default()
        draw.text((10, y), text, fill=(235, 235, 240), font=font)
        y += int(size * 1.6)
        if y > height - size:
            break
    return np.array(banner)


def _make_16k_generator(width: int, height: int):
    text_banner = _render_text_banner(min(width, 6000), 900)
    tb_h, tb_w = text_banner.shape[:2]

    band_bounds = [round(height * f) for f in (0, 1 / 6, 2 / 6, 3 / 6, 4 / 6, 5 / 6, 1.0)]

    def generator(gx: np.ndarray, gy: np.ndarray) -> np.ndarray:
        out = np.zeros(gx.shape + (3,), dtype=np.float64)
        y0 = gy

        # Band 0: sky gradient (smooth vertical transition -> banding stress)
        m0 = (y0 >= band_bounds[0]) & (y0 < band_bounds[1])
        t = (y0 - band_bounds[0]) / max(1, (band_bounds[1] - band_bounds[0]))
        out[..., 0] = np.where(m0, 25 + 140 * t, out[..., 0])
        out[..., 1] = np.where(m0, 60 + 130 * t, out[..., 1])
        out[..., 2] = np.where(m0, 120 + 110 * t, out[..., 2])

        # Band 1: "architecture" — building silhouettes via modulo rectangles (hard edges)
        m1 = (y0 >= band_bounds[1]) & (y0 < band_bounds[2])
        bld_w = 180.0
        bld_id = np.floor(gx / bld_w)
        bld_h_frac = 0.3 + 0.6 * (np.mod(bld_id * 928371.0, 97) / 97.0)
        local_top = band_bounds[1] + (band_bounds[2] - band_bounds[1]) * (1 - bld_h_frac)
        is_building = y0 >= local_top
        window_pattern = (np.mod(gx, bld_w) > 12) & (np.mod(gx, bld_w) < bld_w - 12) & \
                          (np.mod(y0, 40) > 8) & (np.mod(y0, 40) < 32)
        bcolor = np.where(is_building & window_pattern, 210.0, 35.0)
        out[..., 0] = np.where(m1, bcolor, out[..., 0])
        out[..., 1] = np.where(m1, bcolor * 0.95, out[..., 1])
        out[..., 2] = np.where(m1, np.where(is_building, bcolor * 0.7, 55.0), out[..., 2])

        # Band 2: high-frequency grating (mosquito noise / aliasing stress)
        m2 = (y0 >= band_bounds[2]) & (y0 < band_bounds[3])
        freq = 0.15 + 0.35 * ((gx / max(1, width)) % 1.0) * 8
        grating = 127 + 127 * np.sin(gx * 0.4 + freq) * np.cos(y0 * 0.5)
        out[..., 0] = np.where(m2, grating, out[..., 0])
        out[..., 1] = np.where(m2, np.roll(grating, 1, axis=0) if grating.ndim > 1 else grating, out[..., 1])
        out[..., 2] = np.where(m2, 255 - grating, out[..., 2])

        # Band 3: smooth wide colour-transition band (banding stress)
        m3 = (y0 >= band_bounds[3]) & (y0 < band_bounds[4])
        tx = gx / max(1, width)
        out[..., 0] = np.where(m3, 255 * tx, out[..., 0])
        out[..., 1] = np.where(m3, 255 * (1 - tx), out[..., 1])
        out[..., 2] = np.where(m3, 128 + 100 * np.sin(tx * 3.14159), out[..., 2])

        # Band 4: organic "foliage"-like noise (sum of sines, deterministic pseudo-Perlin)
        m4 = (y0 >= band_bounds[4]) & (y0 < band_bounds[5])
        n = (np.sin(gx * 0.021 + 1.7) + np.sin(gy * 0.017 + 0.3) +
             np.sin((gx + gy) * 0.009 + 2.1) + np.sin(gx * 0.11) * 0.3)
        n = (n - n.min()) / (n.max() - n.min() + 1e-9) if n.size else n
        out[..., 0] = np.where(m4, 40 + 60 * n, out[..., 0])
        out[..., 1] = np.where(m4, 90 + 120 * n, out[..., 1])
        out[..., 2] = np.where(m4, 30 + 40 * n, out[..., 2])

        # Band 5: typography strip, sampled from the pre-rendered text banner
        m5 = (y0 >= band_bounds[5]) & (y0 < band_bounds[6])
        by = np.clip((y0 - band_bounds[5]).astype(np.int64), 0, tb_h - 1)
        bx = np.clip((gx.astype(np.int64)) % tb_w, 0, tb_w - 1)
        text_rgb = text_banner[by, bx, :].astype(np.float64)
        out[..., 0] = np.where(m5, text_rgb[..., 0], out[..., 0])
        out[..., 1] = np.where(m5, text_rgb[..., 1], out[..., 1])
        out[..., 2] = np.where(m5, text_rgb[..., 2], out[..., 2])

        return np.clip(out, 0, 255)

    return generator


def build_16k_master(out_path: str, width: int, height: int, tile: int = 512, codec_id: int = codec.CODEC_ZLIB_LOSSLESS):
    generator = _make_16k_generator(width, height)
    src = ProceduralTileSource(generator, width, height, 3, dtype=np.uint8)
    from axif.core import rgb_channels
    img = CanonicalImage(width=width, height=height, channels=rgb_channels(),
                          dtype=np.uint8, tile_source=src)
    meta = axif.camera_metadata(
        model="Aardvark Studio Synthetic Rig", sensor_model="SYN-16K-1",
        capture_timestamp="2026-09-17T00:00:00Z",
    )
    prov = axif.Provenance(source_format="synthetic-procedural")
    prov.add_stage("procedural_generation", algorithm="axif.test-vectors.generate_fixtures:_make_16k_generator",
                    parameters={"width": width, "height": height})
    img.metadata = meta
    img.provenance = prov
    writer = axif.AxifWriter(
        img, tile_width=tile, tile_height=tile, codec_id=codec_id,
        profile="master", preview_max_dim=2048, thumbnail_max_dim=256,
        limits=axif.ResourceLimits.permissive(),
    )
    report = writer.write(out_path)
    return report


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-conformance", action="store_true")
    ap.add_argument("--skip-corrupt", action="store_true")
    ap.add_argument("--skip-master", action="store_true")
    ap.add_argument("--master-size", default="15360x8640", help="WxH for the flagship streaming image")
    ap.add_argument("--master-tile", type=int, default=512)
    ap.add_argument("--master-codec", default="AXIF-ZLIB-LOSSLESS")
    args = ap.parse_args()

    conformance_dir = os.path.join(HERE, "conformance")
    corrupt_dir = os.path.join(HERE, "corrupt")
    streaming_dir = os.path.join(HERE, "streaming")

    if not args.skip_conformance:
        print("Building conformance fixtures...")
        build_conformance_fixtures(conformance_dir)

    if not args.skip_corrupt:
        print("Building malformed/corrupt fixtures...")
        good = os.path.join(conformance_dir, "rgb_u8_basic.axif")
        if os.path.exists(good):
            build_corrupt_fixtures(corrupt_dir, good)
        else:
            print("  skip: rgb_u8_basic.axif not present (run without --skip-conformance first)")

    if not args.skip_master:
        os.makedirs(streaming_dir, exist_ok=True)
        w, h = (int(v) for v in args.master_size.lower().split("x"))
        cid = codec.CODEC_NAME_TO_ID[args.master_codec]
        print(f"Building flagship streaming master {w}x{h} (codec={args.master_codec})...")
        import time
        t0 = time.perf_counter()
        report = build_16k_master(os.path.join(streaming_dir, "master.axif"), w, h,
                                   tile=args.master_tile, codec_id=cid)
        dt = time.perf_counter() - t0
        print(f"  wrote master.axif: {report.tile_count} tiles, {report.level_count} levels, "
              f"{report.file_size:,} bytes in {dt:.1f}s")


if __name__ == "__main__":
    main()
