# AARDVARK XIF

**AARDVARK Extended Image Format (AXIF)** — a professional image container
built around one idea: *one master image, many representations.* A single
`.axif` file holds the full-resolution master, its multi-resolution
pyramid, tiles, a preview, a thumbnail, colour and camera metadata, and
provenance — instead of five unrelated files (`master.tif`, `web.jpg`,
`hdr.exr`, `preview.webp`, `thumb.png`) with no recorded relationship.

AXIF is an independent Aardvark Imaging format. It is not an ISO, JPEG,
Adobe, Apple, NVIDIA, or OpenEXR format, and makes no claim to be first to
support any individual feature — see ARCHITECTURE.md for what it actually
adds on top of the excellent formats (JPEG XL, JPEG 2000, OpenEXR) it
happily wraps as pluggable codecs.

**This is a real, tested reference implementation** — not a mockup. 118
tests pass. A genuine 15360×8640 (16K, 132.7 megapixel) AXIF file was
built with a measured 132 MB peak memory footprint and is included in
`test-vectors/streaming/`. See ROADMAP.md for exactly what's built versus
deliberately deferred (Rust core, C ABI, GPU backends — no toolchain/GPU
was available in the build sandbox).

## Quickstart

```bash
pip install -e ".[codecs,diff]"          # or just add python/ to PYTHONPATH

# convert anything to AXIF, and back
python3 cli/axif-convert photo.tif photo.axif --tile-size 512
python3 cli/axif-info photo.axif
python3 cli/axif-validate photo.axif --strict
python3 cli/axif-extract photo.axif --region 5000,3000,1024,1024 --out crop.png
python3 cli/axif-convert photo.axif photo.jxl
```

```python
import axif

image = axif.open("photo.axif")
print(image.width, image.height, image.pixel_format)
region = image.read_region(x=5000, y=3000, width=1024, height=1024, level=0)
thumb = image.read_thumbnail()

canonical = axif.import_file("source.tif")
axif.AxifWriter(canonical, tile_width=512, tile_height=512).write("out.axif")
```

## What's here

| | |
|---|---|
| `SPECIFICATION.md` | The wire format, precise enough to implement an independent decoder |
| `ARCHITECTURE.md` | Module map, design principles, the conversion architecture |
| `SECURITY.md` | Threat model, resource limits, what "fails safely" means here |
| `ROADMAP.md` | What's done, what's deferred and *why*, the AXC native-codec decision |
| `CHANGELOG.md` | Real bugs found via testing, and how they were fixed |
| `python/axif/` | The reference library — container, codecs, colour, metadata, provenance, importers/exporters, CLI |
| `cli/` | Standalone `axif-info` / `axif-validate` / `axif-convert` / `axif-extract` / `axif-diff` / `axif-benchmark` |
| `tests/` | 118 pytest tests — container structs, checksums, every codec, full read/write round trips, security/corruption handling, interoperability, streaming |
| `test-vectors/` | `generate_fixtures.py` — conformance fixtures, corrupt fixtures, and the real 16K streaming master |
| `viewer/` | A real deep-zoom pan/zoom prototype built from genuinely decoded tiles of the real 16K file |
| `docs/BENCHMARKS.md` | Measured codec/ROI/memory numbers — not estimates |

## Running the tests

```bash
cd tests && python3 -m pytest -q          # 118 passed
python3 test-vectors/generate_fixtures.py  # regenerate all fixtures, incl. the 16K master
```

## License

Apache-2.0 for this repository's own code. See `THIRD_PARTY_NOTICES.md`
for the licenses of the libraries it depends on (numpy, Pillow, tifffile,
imagecodecs, zstandard, crc32c, scipy).
