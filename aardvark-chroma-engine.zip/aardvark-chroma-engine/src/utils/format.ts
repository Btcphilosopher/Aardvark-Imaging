import type { ColourRecord } from '../core/colour/colour-model'
import { cssColorFunction } from '../core/colour/colour-model'

export const fmt = (n: number, d = 2): string => {
  if (!Number.isFinite(n)) return '—'
  const v = Math.abs(n) < 0.5 * Math.pow(10, -d) ? 0 : n
  return v.toFixed(d)
}

export const pct = (n: number, d = 1) => `${fmt(n, d)}%`

type Fmtable = Pick<ColourRecord, 'hex' | 'alpha' | 'srgb' | 'hsl' | 'lab' | 'lch' | 'oklab' | 'oklch' | 'linearRgb'>

const a = (rec: Fmtable) => (rec.alpha < 1 ? ` / ${fmt(rec.alpha, 3)}` : '')

export const cssRgb = (r: Fmtable) => `rgb(${Math.round(Math.min(1, Math.max(0, r.srgb.r)) * 255)} ${Math.round(Math.min(1, Math.max(0, r.srgb.g)) * 255)} ${Math.round(Math.min(1, Math.max(0, r.srgb.b)) * 255)}${a(r)})`
export const cssHsl = (r: Fmtable) => `hsl(${fmt(r.hsl.h, 1)} ${fmt(r.hsl.s * 100, 1)}% ${fmt(r.hsl.l * 100, 1)}%${a(r)})`
export const cssLab = (r: Fmtable) => `lab(${fmt(r.lab.l, 2)} ${fmt(r.lab.a, 2)} ${fmt(r.lab.b, 2)}${a(r)})`
export const cssLch = (r: Fmtable) => `lch(${fmt(r.lch.l, 2)} ${fmt(r.lch.c, 2)} ${fmt(r.lch.h, 1)}${a(r)})`
export const cssOklab = (r: Fmtable) => `oklab(${fmt(r.oklab.l, 4)} ${fmt(r.oklab.a, 4)} ${fmt(r.oklab.b, 4)}${a(r)})`
export const cssOklch = (r: Fmtable) => `oklch(${fmt(r.oklch.l, 4)} ${fmt(r.oklch.c, 4)} ${fmt(r.oklch.h, 1)}${a(r)})`
export const cssP3 = (r: Fmtable) => cssColorFunction(r, 'display-p3')
export const cssRec2020 = (r: Fmtable) => cssColorFunction(r, 'rec2020')

export function isoNow(): string { return new Date().toISOString() }
export function shortDate(iso: string): string { return iso.replace('T', ' ').slice(0, 16) + 'Z' }

export function slug(s: string): string {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'untitled'
}

export function safeNumber(input: string, fallback: number, min = -Infinity, max = Infinity): number {
  const v = parseFloat(input)
  if (!Number.isFinite(v)) return fallback
  return Math.min(max, Math.max(min, v))
}

export function downloadText(filename: string, text: string, mime = 'text/plain'): void {
  const blob = new Blob([text], { type: `${mime};charset=utf-8` })
  downloadBlob(filename, blob)
}

export function downloadBlob(filename: string, blob: Blob): void {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url; a.download = filename
  document.body.appendChild(a); a.click(); a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 2000)
}

export async function copyText(text: string): Promise<boolean> {
  try { await navigator.clipboard.writeText(text); return true } catch {
    try {
      const ta = document.createElement('textarea'); ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0'
      document.body.appendChild(ta); ta.select(); const ok = document.execCommand('copy'); ta.remove(); return ok
    } catch { return false }
  }
}
