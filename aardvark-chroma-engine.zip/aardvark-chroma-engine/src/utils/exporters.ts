import type { ColourRecord } from '../core/colour/colour-model'
import { validateRecords, type ValidationIssue } from '../core/colour/colour-validation'
import type { Project } from '../types/project'
import { APP_VERSION } from '../data/demo-projects'
import { slug, fmt, cssOklch, cssP3, isoNow } from './format'
import { rgbToCmykNaive } from '../core/colour/conversions'
import { validateLut, toCube, type Lut3D } from '../core/lut/lut'

export type ExportFormat = 'json' | 'csv' | 'css' | 'scss' | 'ts' | 'svg' | 'ase' | 'cube' | 'md' | 'html' | 'png'

export const EXPORT_FORMATS: { id: ExportFormat; label: string; ext: string; mime: string; note: string }[] = [
  { id: 'json', label: 'JSON', ext: 'json', mime: 'application/json', note: 'Full colour records with every representation and metadata.' },
  { id: 'csv', label: 'CSV', ext: 'csv', mime: 'text/csv', note: 'Flat table: hex, sRGB, linear, Lab, OKLCh, gamut flags.' },
  { id: 'css', label: 'CSS variables', ext: 'css', mime: 'text/css', note: 'Custom properties (hex) with OKLCh companions and a Display P3 fallback block.' },
  { id: 'scss', label: 'SCSS', ext: 'scss', mime: 'text/x-scss', note: 'Variables and a colour map.' },
  { id: 'ts', label: 'TypeScript', ext: 'ts', mime: 'text/typescript', note: 'A typed, const-asserted colour table.' },
  { id: 'svg', label: 'SVG colour sheet', ext: 'svg', mime: 'image/svg+xml', note: 'Technical specimen sheet with values.' },
  { id: 'ase', label: 'ASE-compatible (conceptual)', ext: 'ase.json', mime: 'application/json', note: 'JSON mirroring the Adobe Swatch Exchange block structure. NOT a binary .ase file.' },
  { id: 'cube', label: '.cube LUT', ext: 'cube', mime: 'text/plain', note: 'Text 3D LUT from the active LUT Lab state.' },
  { id: 'md', label: 'Markdown report', ext: 'md', mime: 'text/markdown', note: 'Project summary, colour tables and validation results.' },
  { id: 'html', label: 'HTML specimen sheet', ext: 'html', mime: 'text/html', note: 'Standalone warm-white specimen page.' },
  { id: 'png', label: 'PNG palette sheet', ext: 'png', mime: 'image/png', note: 'Raster swatch sheet rendered from the current selection.' },
]

export interface ExportContext {
  project: Project
  colours: ColourRecord[]
  setName: string
  assetName: string
  lut?: Lut3D | null
  timestamp?: string
}

export function exportMeta(ctx: ExportContext) {
  const p = ctx.project
  return {
    application: `CHROMA ENGINE ${APP_VERSION} — Aardvark Imaging`,
    project: `${p.name} (${p.code})`,
    set: ctx.setName,
    asset: ctx.assetName,
    colourSpace: 'sRGB primaries, D65; hex values are clipped 8-bit sRGB',
    workingSpace: p.workingSpace,
    sourceProfile: p.sourceProfile,
    destinationProfile: p.destinationProfile,
    outputIntent: p.outputIntent,
    created: ctx.timestamp ?? isoNow(),
    operatorNotes: p.production.operatorNotes || p.notes || '',
  }
}

const headerComment = (ctx: ExportContext, line = '*') => {
  const m = exportMeta(ctx)
  const rows = [`${m.application}`, `Project: ${m.project}`, `Set: ${m.set} · Asset: ${m.asset}`, `Colour space: ${m.colourSpace}`, `Source profile: ${m.sourceProfile} → Destination: ${m.destinationProfile} (output intent: ${m.outputIntent})`, `Created: ${m.created}`, ...(m.operatorNotes ? [`Notes: ${m.operatorNotes.replace(/\s+/g, ' ')}`] : [])]
  return line === '*' ? `/*\n${rows.map((r) => ` * ${r}`).join('\n')}\n */` : rows.map((r) => `${line} ${r}`).join('\n')
}

const varName = (c: ColourRecord, i: number, used: Set<string>) => {
  let base = slug(c.name && c.name !== c.hex.toUpperCase() ? c.name : `colour-${i + 1}`)
  if (/^[0-9]/.test(base)) base = `c-${base}`
  let n = base, k = 2
  while (used.has(n)) n = `${base}-${k++}`
  used.add(n)
  return n
}

const camel = (s: string) => s.replace(/-([a-z0-9])/g, (_, c: string) => c.toUpperCase())
const esc = (s: string) => s.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c] as string))

export function toJson(ctx: ExportContext): string {
  return JSON.stringify({ meta: exportMeta(ctx), colours: ctx.colours }, null, 2)
}

export function toCsv(ctx: ExportContext): string {
  const head = ['name', 'hex', 'alpha', 'r', 'g', 'b', 'linear_r', 'linear_g', 'linear_b', 'L*', 'a*', 'b*', 'C*', 'h*', 'oklab_L', 'oklch_C', 'oklch_h', 'luminance', 'in_srgb', 'in_displayP3', 'in_rec2020', 'notes']
  const q = (s: string) => `"${s.replace(/"/g, '""')}"`
  const rows = ctx.colours.map((c) => [q(c.name), c.hex, fmt(c.alpha, 3), fmt(c.srgb.r * 255, 2), fmt(c.srgb.g * 255, 2), fmt(c.srgb.b * 255, 2), fmt(c.linearRgb.r, 6), fmt(c.linearRgb.g, 6), fmt(c.linearRgb.b, 6),
    fmt(c.lab.l, 3), fmt(c.lab.a, 3), fmt(c.lab.b, 3), fmt(c.lch.c, 3), fmt(c.lch.h, 2), fmt(c.oklab.l, 5), fmt(c.oklch.c, 5), fmt(c.oklch.h, 2), fmt(c.luminance, 6), String(c.gamutStatus.srgb), String(c.gamutStatus.displayP3), String(c.gamutStatus.rec2020), q(c.metadata.notes ?? '')].join(','))
  return `${headerComment(ctx, '#')}\n${head.join(',')}\n${rows.join('\n')}\n`
}

export function toCss(ctx: ExportContext): string {
  const used = new Set<string>()
  const names = ctx.colours.map((c, i) => varName(c, i, used))
  const hex = ctx.colours.map((c, i) => `  --${names[i]}: ${c.hex};`).join('\n')
  const ok = ctx.colours.map((c, i) => `  --${names[i]}-oklch: ${cssOklch(c)};`).join('\n')
  const p3 = ctx.colours.filter((c) => !c.gamutStatus.srgb && c.gamutStatus.displayP3).map((c) => `    --${names[ctx.colours.indexOf(c)]}: ${cssP3(c)};`).join('\n')
  return `${headerComment(ctx)}\n:root {\n${hex}\n\n${ok}\n}\n${p3 ? `\n/* Colours outside sRGB but inside Display P3 (hex above is clipped) */\n@media (color-gamut: p3) {\n  :root {\n${p3}\n  }\n}\n` : ''}`
}

export function toScss(ctx: ExportContext): string {
  const used = new Set<string>()
  const names = ctx.colours.map((c, i) => varName(c, i, used))
  const vars = ctx.colours.map((c, i) => `$${names[i]}: ${c.hex};`).join('\n')
  const map = ctx.colours.map((_c, i) => `  '${names[i]}': $${names[i]}`).join(',\n')
  return `${headerComment(ctx, '//')}\n${vars}\n\n$colours: (\n${map}\n);\n`
}

export function toTs(ctx: ExportContext): string {
  const used = new Set<string>()
  const entries = ctx.colours.map((c, i) => {
    const k = camel(varName(c, i, used))
    return `  ${/^[a-zA-Z_$]/.test(k) ? k : `'${k}'`}: { hex: '${c.hex}', alpha: ${fmt(c.alpha, 3)}, oklch: [${fmt(c.oklch.l, 4)}, ${fmt(c.oklch.c, 4)}, ${fmt(c.oklch.h, 1)}], inSrgb: ${c.gamutStatus.srgb} },`
  }).join('\n')
  return `${headerComment(ctx)}\nexport const colours = {\n${entries}\n} as const\n\nexport type ColourName = keyof typeof colours\n`
}

export function toSvg(ctx: ExportContext): string {
  const cols = Math.min(6, Math.max(1, ctx.colours.length))
  const cw = 168, ch = 178, pad = 24, top = 92
  const rows = Math.ceil(ctx.colours.length / cols)
  const W = pad * 2 + cols * cw, H = top + rows * ch + 38
  const m = exportMeta(ctx)
  const cells = ctx.colours.map((c, i) => {
    const x = pad + (i % cols) * cw, y = top + Math.floor(i / cols) * ch
    const flag = !c.gamutStatus.srgb ? ' ▲ outside sRGB' : ''
    return `<g transform="translate(${x},${y})">
  <rect width="${cw - 12}" height="86" fill="${c.hex}" fill-opacity="${fmt(c.alpha, 3)}" stroke="#16191c" stroke-width="1"/>
  <line x1="0" y1="86" x2="${cw - 12}" y2="86" stroke="#e8630a" stroke-width="2"/>
  <text x="0" y="104" font-family="Arial Narrow, Arial, sans-serif" font-size="11" font-weight="700" letter-spacing="1.2" fill="#16191c">${esc(c.name.toUpperCase())}</text>
  <text x="0" y="119" font-family="monospace" font-size="10" fill="#16191c">${c.hex.toUpperCase()}${esc(flag)}</text>
  <text x="0" y="132" font-family="monospace" font-size="9" fill="#4d5157">RGB ${Math.round(Math.min(1, Math.max(0, c.srgb.r)) * 255)} ${Math.round(Math.min(1, Math.max(0, c.srgb.g)) * 255)} ${Math.round(Math.min(1, Math.max(0, c.srgb.b)) * 255)}</text>
  <text x="0" y="144" font-family="monospace" font-size="9" fill="#4d5157">OKLCH ${fmt(c.oklch.l, 3)} ${fmt(c.oklch.c, 3)} ${fmt(c.oklch.h, 0)}</text>
  <text x="0" y="156" font-family="monospace" font-size="9" fill="#4d5157">LAB ${fmt(c.lab.l, 1)} ${fmt(c.lab.a, 1)} ${fmt(c.lab.b, 1)}</text>
</g>`
  }).join('\n')
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
<title>${esc(ctx.setName)} — colour sheet</title>
<desc>${esc(m.application)} · ${esc(m.project)} · ${esc(m.created)} · ${esc(m.colourSpace)}</desc>
<rect width="${W}" height="${H}" fill="#f2eee6"/>
<rect x="0" y="0" width="${W}" height="8" fill="#e8630a"/>
<text x="${pad}" y="40" font-family="Arial Narrow, Arial, sans-serif" font-size="20" font-weight="700" letter-spacing="3" fill="#16191c">${esc(ctx.setName.toUpperCase())}</text>
<text x="${pad}" y="58" font-family="Arial Narrow, Arial, sans-serif" font-size="11" letter-spacing="1.5" fill="#4d5157">${esc(m.project.toUpperCase())}</text>
<text x="${pad}" y="74" font-family="monospace" font-size="9" fill="#4d5157">${esc(m.colourSpace)} · ${esc(m.created)} · ${esc(m.application)}</text>
${cells}
<line x1="${pad}" y1="${H - 26}" x2="${W - pad}" y2="${H - 26}" stroke="#16191c" stroke-width="0.5"/>
<text x="${pad}" y="${H - 12}" font-family="Arial Narrow, Arial, sans-serif" font-size="9" letter-spacing="1.2" fill="#4d5157">AARDVARK IMAGING — COLOUR IS MEASUREMENT. IMAGING IS ENGINEERING. SCREEN VALUES; NOT A CERTIFIED PROOF.</text>
</svg>
`
}

/** Conceptual ASE structure. The real format is binary big-endian; this mirrors its block model only. */
export function toAse(ctx: ExportContext): string {
  const blocks = [
    { blockType: '0xC001 (group start)', name: ctx.setName },
    ...ctx.colours.map((c) => ({
      blockType: '0x0001 (colour entry)', name: c.name, colourModel: 'RGB ', values: [+c.srgb.r.toFixed(6), +c.srgb.g.toFixed(6), +c.srgb.b.toFixed(6)].map((v) => Math.min(1, Math.max(0, v))), colourType: 'Global',
      cmykApproximation: (() => { const k = rgbToCmykNaive(c.srgb); return { model: 'CMYK', values: [k.c, k.m, k.y, k.k].map((v) => +v.toFixed(4)), note: 'naive approximation; not colour-managed' } })(),
    })),
    { blockType: '0xC002 (group end)' },
  ]
  return JSON.stringify({ format: 'ASE-conceptual', notice: 'Mirrors Adobe Swatch Exchange block structure for inspection. This is not a binary .ase file and will not open in Adobe applications.', meta: exportMeta(ctx), version: '1.0', blocks }, null, 2)
}

export function toMarkdown(ctx: ExportContext): string {
  const m = exportMeta(ctx)
  const issues = validateRecords(ctx.colours)
  const rows = ctx.colours.map((c) => `| ${c.name} | \`${c.hex}\` | ${fmt(c.lab.l, 1)} / ${fmt(c.lab.a, 1)} / ${fmt(c.lab.b, 1)} | ${fmt(c.oklch.l, 3)} / ${fmt(c.oklch.c, 3)} / ${fmt(c.oklch.h, 0)} | ${c.gamutStatus.srgb ? 'sRGB' : c.gamutStatus.displayP3 ? 'P3 only' : c.gamutStatus.rec2020 ? 'Rec.2020 only' : 'outside'} |`).join('\n')
  return `# ${ctx.setName}

- **Project:** ${m.project}
- **Asset:** ${m.asset}
- **Application:** ${m.application}
- **Created:** ${m.created}
- **Colour space:** ${m.colourSpace}
- **Source profile:** ${m.sourceProfile}
- **Destination profile:** ${m.destinationProfile}
- **Output intent:** ${m.outputIntent}
- **Operator notes:** ${m.operatorNotes || '—'}

| Name | Hex | CIELAB (D65) | OKLCh | Gamut |
|---|---|---|---|---|
${rows}

## Validation

${issues.length ? issues.map((i) => `- ${i.severity.toUpperCase()}: ${i.message}`).join('\n') : '- No issues found.'}

> Screen values are display-referred sRGB and any CMYK figures are approximations. This document is not a certified proof.
`
}

export function toHtml(ctx: ExportContext): string {
  const m = exportMeta(ctx)
  const cards = ctx.colours.map((c) => `<figure><div class="sw" style="background:${c.hex};opacity:${fmt(c.alpha, 3)}"></div><figcaption><b>${esc(c.name)}</b><span>${c.hex.toUpperCase()}${c.gamutStatus.srgb ? '' : ' ▲'}</span><span>OKLCH ${fmt(c.oklch.l, 3)} ${fmt(c.oklch.c, 3)} ${fmt(c.oklch.h, 0)}</span><span>LAB ${fmt(c.lab.l, 1)} ${fmt(c.lab.a, 1)} ${fmt(c.lab.b, 1)}</span></figcaption></figure>`).join('\n')
  return `<!doctype html><html lang="en-GB"><head><meta charset="utf-8"><title>${esc(ctx.setName)} — specimen</title>
<style>body{margin:0;background:#f2eee6;color:#16191c;font:14px/1.45 "IBM Plex Sans","Segoe UI",Arial,sans-serif}header{border-top:8px solid #e8630a;padding:24px 32px 12px}
h1{font:700 22px "Barlow Semi Condensed","Arial Narrow",Arial,sans-serif;letter-spacing:.14em;text-transform:uppercase;margin:0}p{margin:4px 0;color:#3a3d42;font-size:12px}
main{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:18px;padding:12px 32px 32px}figure{margin:0}.sw{height:96px;border:1px solid #16191c;border-bottom:3px solid #e8630a}
figcaption{display:flex;flex-direction:column;font:11px monospace;padding-top:6px}figcaption b{font:700 12px "Arial Narrow",Arial,sans-serif;letter-spacing:.1em;text-transform:uppercase}footer{padding:12px 32px 24px;font-size:11px;color:#4d5157}@media print{body{background:#fff}}</style></head>
<body><header><h1>${esc(ctx.setName)}</h1><p>${esc(m.project)} · ${esc(m.asset)}</p><p>${esc(m.application)} · ${esc(m.created)} · ${esc(m.colourSpace)}</p><p>Source ${esc(m.sourceProfile)} → ${esc(m.destinationProfile)} · intent ${esc(m.outputIntent)}</p></header>
<main>${cards}</main><footer>Screen values, display-referred sRGB. ▲ = outside sRGB (hex clipped). Not a certified proof. ${esc(m.operatorNotes)}</footer></body></html>
`
}

export function toCubeExport(ctx: ExportContext): string {
  if (!ctx.lut) return '# No LUT available'
  const m = exportMeta(ctx)
  return toCube(ctx.lut, { title: `${ctx.project.code} ${ctx.setName}`, comments: [m.application, `Project: ${m.project}`, `Created: ${m.created}`, 'Domain: encoded sRGB in, encoded sRGB out (display-referred look LUT)', `Notes: ${m.operatorNotes}`] })
}

export function buildExport(fmtId: ExportFormat, ctx: ExportContext): string {
  switch (fmtId) {
    case 'json': return toJson(ctx)
    case 'csv': return toCsv(ctx)
    case 'css': return toCss(ctx)
    case 'scss': return toScss(ctx)
    case 'ts': return toTs(ctx)
    case 'svg': return toSvg(ctx)
    case 'ase': return toAse(ctx)
    case 'cube': return toCubeExport(ctx)
    case 'md': return toMarkdown(ctx)
    case 'html': return toHtml(ctx)
    case 'png': return ''
  }
}

// ───────────── validation ─────────────

export interface ExportIssue { severity: 'error' | 'warning' | 'info'; message: string }

export function validateExport(format: ExportFormat, ctx: ExportContext): ExportIssue[] {
  const out: ExportIssue[] = []
  if (format === 'cube') {
    if (!ctx.lut) out.push({ severity: 'error', message: 'No LUT is loaded; open LUT Lab and choose a look first.' })
    else {
      const v = validateLut(ctx.lut)
      for (const i of v.issues) out.push({ severity: i.severity, message: `LUT: ${i.message}` })
    }
  } else {
    if (ctx.colours.length === 0) out.push({ severity: 'error', message: 'The selected set contains no colours.' })
    const recIssues: ValidationIssue[] = validateRecords(ctx.colours)
    for (const i of recIssues) out.push({ severity: i.severity, message: i.message })
    const unnamed = ctx.colours.filter((c) => !c.name.trim() || c.name === c.hex.toUpperCase()).length
    if (unnamed) out.push({ severity: 'warning', message: `${unnamed} colour${unnamed > 1 ? 's are' : ' is'} unnamed; generated identifiers (colour-N) will be used.` })
    if (ctx.colours.some((c) => c.alpha < 1) && (format === 'scss' || format === 'ase' || format === 'csv'))
      out.push({ severity: 'info', message: 'Some colours carry alpha. Alpha is exported as a separate field/8-digit value where the format supports it.' })
  }
  if (ctx.project.outputIntent.trim().toLowerCase() === 'unspecified') out.push({ severity: 'warning', message: 'Output intent is unspecified. Set it in Print & Production or System Settings before release.' })
  if (ctx.project.destinationProfile.trim().toLowerCase() === 'unspecified') out.push({ severity: 'info', message: 'Destination profile is unspecified.' })
  if (format === 'ase') out.push({ severity: 'warning', message: 'ASE export is conceptual JSON, not a binary .ase file. CMYK values are naive approximations.' })
  if (format === 'png') out.push({ severity: 'info', message: 'PNG is 8-bit sRGB without an embedded ICC profile; out-of-gamut colours are clipped.' })
  if (format === 'html' || format === 'svg' || format === 'png') out.push({ severity: 'info', message: 'Specimen output is display-referred; it approximates but does not guarantee printed colour.' })
  if (format === 'cube') out.push({ severity: 'info', message: 'Look LUT operates on encoded sRGB (display-referred). It is not a scene-referred or shaper-based production LUT.' })
  return out
}

export async function renderPngSheet(ctx: ExportContext): Promise<Blob | null> {
  const cols = Math.min(6, Math.max(1, ctx.colours.length))
  const cw = 168, ch = 150, pad = 24, top = 80
  const rows = Math.ceil(ctx.colours.length / cols)
  const c = document.createElement('canvas')
  c.width = pad * 2 + cols * cw; c.height = top + rows * ch + 34
  const g = c.getContext('2d')
  if (!g) return null
  g.fillStyle = '#f2eee6'; g.fillRect(0, 0, c.width, c.height)
  g.fillStyle = '#e8630a'; g.fillRect(0, 0, c.width, 8)
  g.fillStyle = '#16191c'; g.font = '700 20px "Arial Narrow", Arial, sans-serif'; g.fillText(ctx.setName.toUpperCase(), pad, 40)
  g.fillStyle = '#4d5157'; g.font = '10px monospace'; g.fillText(`${exportMeta(ctx).project} · ${exportMeta(ctx).created}`, pad, 58)
  ctx.colours.forEach((col, i) => {
    const x = pad + (i % cols) * cw, y = top + Math.floor(i / cols) * ch
    g.globalAlpha = col.alpha; g.fillStyle = col.hex; g.fillRect(x, y, cw - 12, 80); g.globalAlpha = 1
    g.strokeStyle = '#16191c'; g.strokeRect(x + 0.5, y + 0.5, cw - 13, 80)
    g.fillStyle = '#e8630a'; g.fillRect(x, y + 80, cw - 12, 2)
    g.fillStyle = '#16191c'; g.font = '700 11px "Arial Narrow", Arial, sans-serif'; g.fillText(col.name.toUpperCase().slice(0, 22), x, y + 98)
    g.font = '10px monospace'; g.fillText(col.hex.toUpperCase() + (col.gamutStatus.srgb ? '' : ' ▲'), x, y + 112)
    g.fillStyle = '#4d5157'; g.font = '9px monospace'; g.fillText(`OKLCH ${fmt(col.oklch.l, 3)} ${fmt(col.oklch.c, 3)} ${fmt(col.oklch.h, 0)}`, x, y + 125)
  })
  return new Promise((resolve) => c.toBlob((b) => resolve(b), 'image/png'))
}
