import type { AssetMeta } from '../types/project'
import { decodeDataUrl, MAX_IMPORT_SIDE } from '../hooks/useAssetImage'
import { newId } from '../core/colour/colour-model'
import { isoNow } from './format'

export const MAX_FILE_BYTES = 40 * 1024 * 1024

function readAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader()
    r.onload = () => resolve(String(r.result))
    r.onerror = () => reject(new Error(`Could not read ${file.name}`))
    r.readAsDataURL(file)
  })
}

export interface ImportResult { asset?: AssetMeta; error?: string; note?: string }

/** Import a local image. Everything stays on this machine; large images are bounded to MAX_IMPORT_SIDE for processing. */
export async function importImageFile(file: File): Promise<ImportResult> {
  if (!file.type.startsWith('image/')) return { error: `${file.name}: not an image file (${file.type || 'unknown type'})` }
  if (file.size > MAX_FILE_BYTES) return { error: `${file.name}: ${(file.size / 1048576).toFixed(1)} MB exceeds the ${MAX_FILE_BYTES / 1048576} MB limit` }
  try {
    let url = await readAsDataUrl(file)
    const d = await decodeDataUrl(url)
    let note: string | undefined
    if (d.scaled) {
      const c = document.createElement('canvas'); c.width = d.img.width; c.height = d.img.height
      const cctx = c.getContext('2d')
      if (!cctx) throw new Error('Canvas 2D context is unavailable in this environment')
      cctx.putImageData(new ImageData(new Uint8ClampedArray(d.img.data), d.img.width, d.img.height), 0, 0)
      url = c.toDataURL('image/png')
      note = `${file.name} was ${d.originalW}×${d.originalH}; stored at ${d.img.width}×${d.img.height} (processing is bounded to ${MAX_IMPORT_SIDE} px on the long side).`
    }
    const asset: AssetMeta = {
      id: newId('ast'), name: file.name.replace(/\.[^.]+$/, ''), kind: 'image', role: 'Imported', width: d.img.width, height: d.img.height,
      colourSpace: 'sRGB assumed (embedded ICC profiles are not read)', sourceProfile: 'Unknown — treated as sRGB', dataUrl: url,
      notes: `Imported from ${file.name} (${(file.size / 1024).toFixed(0)} KB).`, createdAt: isoNow(),
    }
    return { asset, note }
  } catch (e) {
    return { error: `${file.name}: ${e instanceof Error ? e.message : 'import failed'}` }
  }
}
