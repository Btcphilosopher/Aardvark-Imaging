import type { ColourRecord } from '../core/colour/colour-model'
import type { Project } from '../types/project'
import { deltaE2000Linear } from '../core/colour/contrast'

export interface Nearest { colour: ColourRecord; from: string; deltaE: number }

/** Nearest colour (CIEDE2000) among the project's palettes and saved samples. */
export function nearestInProject(rec: Pick<ColourRecord, 'linearRgb'>, project: Project): Nearest | null {
  let best: Nearest | null = null
  const consider = (c: ColourRecord, from: string) => {
    const d = deltaE2000Linear(rec.linearRgb, c.linearRgb)
    if (!best || d < best.deltaE) best = { colour: c, from, deltaE: d }
  }
  for (const p of project.palettes) for (const pc of p.colours) consider(pc.colour, `Palette · ${p.name}`)
  for (const s of project.samples) consider(s.record, 'Sample')
  return best
}
