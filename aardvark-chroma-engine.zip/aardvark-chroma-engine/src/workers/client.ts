import type { Task, TaskResult } from '../core/image/tasks'
import { runTask } from '../core/image/tasks'
import { useWorkerStatus } from '../state/worker-status'

/**
 * Worker client. Colour-heavy work (generation, rendering, analysis, scopes) runs in a Web Worker.
 * If a Worker cannot be created (very old browser, unusual embed, test runner) the identical task
 * layer runs on the main thread instead and the status panel reports "main-thread fallback".
 */

interface Pending { resolve: (r: TaskResult) => void; reject: (e: Error) => void; label: string }

let worker: Worker | null = null
let failed = false
let nextId = 1
const pending = new Map<number, Pending>()

function ensureWorker(): Worker | null {
  if (worker || failed) return worker
  try {
    worker = new Worker(new URL('./image.worker.ts', import.meta.url), { type: 'module' })
    worker.onmessage = (e: MessageEvent<{ id: number; ok: boolean; result?: TaskResult; error?: string; ms: number }>) => {
      const { id, ok, result, error, ms } = e.data
      const p = pending.get(id)
      if (!p) return
      pending.delete(id)
      useWorkerStatus.getState().finish(ms, !ok ? (error ?? 'error') : null)
      if (ok && result) p.resolve(result)
      else p.reject(new Error(error ?? 'Worker task failed'))
    }
    worker.onerror = (e) => {
      failed = true
      worker = null
      useWorkerStatus.getState().setMode('fallback', e.message)
      for (const [id, p] of pending) { p.reject(new Error('Worker crashed: ' + e.message)); pending.delete(id) }
    }
    useWorkerStatus.getState().setMode('worker')
  } catch (err) {
    failed = true
    useWorkerStatus.getState().setMode('fallback', err instanceof Error ? err.message : String(err))
  }
  return worker
}

export function runInWorker<T extends TaskResult>(task: Task, label: string = task.op): Promise<T> {
  const st = useWorkerStatus.getState()
  st.start(label)
  const w = ensureWorker()
  if (!w) {
    return new Promise<T>((resolve, reject) => {
      // yield to the event loop so the UI can paint the "busy" state before the synchronous fallback runs
      setTimeout(() => {
        const t0 = performance.now()
        try { const r = runTask(task) as T; useWorkerStatus.getState().finish(performance.now() - t0, null); resolve(r) }
        catch (e) { useWorkerStatus.getState().finish(performance.now() - t0, e instanceof Error ? e.message : String(e)); reject(e as Error) }
      }, 0)
    })
  }
  const id = nextId++
  return new Promise<T>((resolve, reject) => {
    pending.set(id, { resolve: resolve as (r: TaskResult) => void, reject, label })
    w.postMessage({ id, task })
  })
}
