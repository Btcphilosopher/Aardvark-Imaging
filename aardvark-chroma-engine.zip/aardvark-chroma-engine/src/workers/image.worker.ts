/// <reference lib="webworker" />
import { runTask, type Task } from '../core/image/tasks'

interface Req { id: number; task: Task }

self.onmessage = (e: MessageEvent<Req>) => {
  const { id, task } = e.data
  const t0 = performance.now()
  try {
    const result = runTask(task)
    const transfer: Transferable[] = []
    if ('image' in result) transfer.push(result.image.data.buffer)
    ;(self as unknown as Worker).postMessage({ id, ok: true, result, ms: performance.now() - t0 }, transfer)
  } catch (err) {
    ;(self as unknown as Worker).postMessage({ id, ok: false, error: err instanceof Error ? err.message : String(err), ms: performance.now() - t0 })
  }
}
