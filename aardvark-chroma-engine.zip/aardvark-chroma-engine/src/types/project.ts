import type { ColourRecord } from '../core/colour/colour-model'
import type { Palette } from '../core/colour/harmony'
import type { GradeParams } from '../core/grading/grade'
import type { GeneratorId } from '../core/image/procedural'
import type { RenderingIntent } from '../core/print/print'
import type { LutBlend } from '../core/lut/lut'

export type AssetVariant = 'working' | 'source' | 'graded' | 'print' | 'display'

export interface AssetMeta {
  id: string
  name: string
  kind: 'image' | 'report' | 'sheet'
  role: string
  width: number
  height: number
  colourSpace: string
  sourceProfile: string
  /** deterministic generator for synthetic assets */
  generator?: { id: GeneratorId; variant: AssetVariant }
  /** imported images are kept as data URLs inside the project so nothing is lost on reload */
  dataUrl?: string
  /** markdown body for report/sheet assets */
  body?: string
  notes: string
  createdAt: string
}

export interface SavedSample {
  id: string
  record: ColourRecord
  note: string
  assetId?: string
  point?: { x: number; y: number }
  /** 'reference' = value from a library; 'pixel' = read from an image; 'picker' = created in the picker */
  origin: 'reference' | 'pixel' | 'picker' | 'region'
}

export interface Annotation { id: string; assetId: string; x: number; y: number; text: string }

export interface PixelMeasurement {
  id: string
  assetId: string
  a: { x: number; y: number }
  b: { x: number; y: number }
  note: string
  at: string
}

export interface GradeSnapshot { id: string; name: string; grade: GradeParams; createdAt: string }

export interface ConversionEntry {
  id: string
  at: string
  input: string
  from: string
  to: string
  output: string
  reference: 'display-referred' | 'scene-referred' | 'working-space' | 'output-referred' | 'approximate-cmyk-preview'
  note: string
}

export interface LogEntry { at: string; label: string }

export interface BrandColour { id: string; group: 'Primary' | 'Secondary' | 'Accent' | 'Neutral' | 'Signal'; name: string; hex: string; usage: string }

export interface BrandSystem { name: string; tagline: string; colours: BrandColour[] }

export interface ProductionJob {
  profileId: string
  intent: RenderingIntent
  blackPointCompensation: boolean
  widthMm: number
  heightMm: number
  dpi: number
  bleedMm: number
  trimMm: number
  operatorNotes: string
}

export interface LutState { presetId: string; strength: number; blend: LutBlend; version: number; history: { version: number; presetId: string; strength: number; at: string }[] }

export interface Project {
  id: string
  code: string
  name: string
  description: string
  createdAt: string
  updatedAt: string
  archived: boolean
  notes: string
  operator: string
  workingSpace: string
  sourceProfile: string
  outputIntent: string
  destinationProfile: string
  assets: AssetMeta[]
  activeAssetId: string
  samples: SavedSample[]
  palettes: Palette[]
  currentGrade: GradeParams
  gradeSnapshots: GradeSnapshot[]
  gradeAB: { a: GradeParams | null; b: GradeParams | null }
  lut: LutState
  conversionHistory: ConversionEntry[]
  measurements: PixelMeasurement[]
  annotations: Annotation[]
  brand: BrandSystem
  production: ProductionJob
  adjustmentLog: LogEntry[]
  displayId: string
}

export interface ProjectSummary { id: string; code: string; name: string; updatedAt: string; archived: boolean; assetCount: number; sampleCount: number; paletteCount: number }

export const summarise = (p: Project): ProjectSummary => ({
  id: p.id, code: p.code, name: p.name, updatedAt: p.updatedAt, archived: p.archived, assetCount: p.assets.length, sampleCount: p.samples.length, paletteCount: p.palettes.length,
})
