import { useMemo } from 'react'
import { useApp } from '../state/store'
import { useLab } from '../state/lab'
import { defaultRender, type RenderParams } from '../core/image/image-processing'
import { buildLut, LUT_PRESETS } from '../core/lut/lut'

const lutCache = new Map<string, ReturnType<typeof buildLut>>()
export function lutFor(presetId: string, size = 17) {
  const key = `${presetId}:${size}`
  let l = lutCache.get(key)
  if (!l) {
    const p = LUT_PRESETS.find((x) => x.id === presetId) ?? LUT_PRESETS[0]
    l = buildLut(p.fn, size, p.name)
    lutCache.set(key, l)
  }
  return l
}

/** Render parameters for the Image Lab derived from project state and lab view settings. */
export function useLabRenderParams(): { params: RenderParams; depsKey: string } {
  const project = useApp((s) => s.project)
  const lab = useLab()
  return useMemo(() => {
    const params: RenderParams = {
      ...defaultRender(),
      grade: lab.applyGrade ? project.currentGrade : null,
      lut: lab.applyLut ? { lut: lutFor(project.lut.presetId), strength: project.lut.strength, blend: project.lut.blend } : null,
      view: lab.view, exposureStops: lab.exposure, saturationPreview: lab.saturation,
      proof: lab.proofOn ? { profileId: project.production.profileId, intent: project.production.intent, bpc: project.production.blackPointCompensation } : null,
    }
    const depsKey = JSON.stringify({ ...params, lut: params.lut ? `${project.lut.presetId}|${project.lut.strength}|${project.lut.blend}` : null })
    return { params, depsKey }
  }, [project.currentGrade, project.lut.presetId, project.lut.strength, project.lut.blend, project.production, lab.applyGrade, lab.applyLut, lab.view, lab.exposure, lab.saturation, lab.proofOn])
}
