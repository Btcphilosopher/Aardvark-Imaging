import { useEffect, useRef, useState } from 'react'
import type { ImageBuf } from '../core/image/image-model'
import type { AssetMeta } from '../types/project'
import { runInWorker } from '../workers/client'
import type { TaskResult } from '../core/image/tasks'
import { variantRenderParams } from '../core/image/variants'
import type { RenderParams, RenderStats } from '../core/image/image-processing'

export const MAX_IMPORT_SIDE = 2400

const images = new Map<string, ImageBuf>()
const inflight = new Map<string, Promise<ImageBuf>>()

export function assetKey(a: AssetMeta): string {
  if (a.generator) return a.generator.variant === 'working' ? `base:${a.generator.id}:${a.width}x${a.height}` : `var:${a.generator.id}:${a.generator.variant}:${a.width}x${a.height}`
  return `imp:${a.id}:${(a.dataUrl ?? '').length}`
}

export async function decodeDataUrl(url: string, maxSide = MAX_IMPORT_SIDE): Promise<{ img: ImageBuf; scaled: boolean; originalW: number; originalH: number }> {
  const el = new Image()
  el.decoding = 'async'
  await new Promise<void>((resolve, reject) => { el.onload = () => resolve(); el.onerror = () => reject(new Error('The file could not be decoded as an image')); el.src = url })
  const ow = el.naturalWidth, oh = el.naturalHeight
  if (!ow || !oh) throw new Error('Image has no dimensions')
  const k = Math.min(1, maxSide / Math.max(ow, oh))
  const w = Math.max(1, Math.round(ow * k)), h = Math.max(1, Math.round(oh * k))
  const c = document.createElement('canvas'); c.width = w; c.height = h
  const ctx = c.getContext('2d', { willReadFrequently: true })
  if (!ctx) throw new Error('Canvas 2D is unavailable')
  ctx.drawImage(el, 0, 0, w, h)
  const d = ctx.getImageData(0, 0, w, h)
  return { img: { width: w, height: h, data: d.data }, scaled: k < 1, originalW: ow, originalH: oh }
}

export function getCachedImage(a: AssetMeta): ImageBuf | undefined { return images.get(assetKey(a)) }

/** Load (generate / decode / derive) the pixels of an asset and register them in the worker cache. */
export function loadAssetImage(a: AssetMeta): Promise<ImageBuf> {
  const key = assetKey(a)
  const hit = images.get(key)
  if (hit) return Promise.resolve(hit)
  const running = inflight.get(key)
  if (running) return running
  const p = (async () => {
    let img: ImageBuf
    if (a.generator) {
      const baseKey = `base:${a.generator.id}:${a.width}x${a.height}`
      let base = images.get(baseKey)
      if (!base) {
        const r = await runInWorker<Extract<TaskResult, { op: 'generate' }>>({ op: 'generate', key: baseKey, generator: a.generator.id, width: a.width, height: a.height }, `generate ${a.generator.id}`)
        base = r.image
        images.set(baseKey, base)
      }
      const params = variantRenderParams(a.generator.variant)
      if (!params) img = base
      else {
        const r = await runInWorker<Extract<TaskResult, { op: 'render' }>>({ op: 'render', key: baseKey, params }, `variant ${a.generator.variant}`)
        img = r.image
        await runInWorker({ op: 'put', key, img }, 'register')
      }
    } else if (a.dataUrl) {
      const d = await decodeDataUrl(a.dataUrl)
      img = d.img
      await runInWorker({ op: 'put', key, img }, 'register import')
    } else throw new Error('Asset has no image data')
    images.set(key, img)
    return img
  })().finally(() => inflight.delete(key))
  inflight.set(key, p)
  return p
}

export function useAssetImage(asset: AssetMeta | undefined): { image: ImageBuf | null; key: string | null; status: 'idle' | 'loading' | 'ready' | 'error'; error: string | null } {
  const [state, setState] = useState<{ image: ImageBuf | null; key: string | null; status: 'idle' | 'loading' | 'ready' | 'error'; error: string | null }>({ image: null, key: null, status: 'idle', error: null })
  useEffect(() => {
    if (!asset || asset.kind !== 'image') { setState({ image: null, key: null, status: 'idle', error: null }); return }
    let alive = true
    const key = assetKey(asset)
    const cached = images.get(key)
    if (cached) { setState({ image: cached, key, status: 'ready', error: null }); return }
    setState((s) => ({ ...s, status: 'loading', error: null }))
    loadAssetImage(asset).then((img) => { if (alive) setState({ image: img, key, status: 'ready', error: null }) })
      .catch((e: Error) => { if (alive) setState({ image: null, key, status: 'error', error: e.message }) })
    return () => { alive = false }
  }, [asset])
  return state
}

/** Latest-wins live render of an asset through the pipeline in the worker. */
export function useRendered(key: string | null, params: RenderParams, depsKey: string, enabled = true): { image: ImageBuf | null; stats: RenderStats | null; busy: boolean; error: string | null } {
  const [out, setOut] = useState<{ image: ImageBuf | null; stats: RenderStats | null; error: string | null }>({ image: null, stats: null, error: null })
  const [busy, setBusy] = useState(false)
  const seq = useRef(0)
  const paramsRef = useRef(params)
  paramsRef.current = params
  useEffect(() => {
    if (!key || !enabled) return
    const id = ++seq.current
    setBusy(true)
    const h = window.setTimeout(() => {
      runInWorker<Extract<TaskResult, { op: 'render' }>>({ op: 'render', key, params: paramsRef.current }, 'render')
        .then((r) => { if (id === seq.current) { setOut({ image: r.image, stats: r.stats, error: null }); setBusy(false) } })
        .catch((e: Error) => { if (id === seq.current) { setOut((o) => ({ ...o, error: e.message })); setBusy(false) } })
    }, 16)
    return () => window.clearTimeout(h)
  }, [key, depsKey, enabled])
  return { ...out, busy }
}
