import { useMemo, useState } from 'react'
import { useApp } from '../state/store'
import { ToolbarPortal, InspectorPortal } from '../components/shell/Slots'
import { Panel, Select, Slider, Check2, Notice, Kv, Badge, Swatch, NumInput } from '../components/common/ui'
import { PRODUCTION_PROFILES, INTENTS, proofColour, printSizeMm, effectiveDpi, requiredPixels, dpiRating, toMm, fromMm, type LengthUnit } from '../core/print/print'
import { usePickerRecord } from '../state/store'
import { linearToSrgb, rgbToHex } from '../core/colour/conversions'
import { fmt, downloadText, isoNow } from '../utils/format'

export default function PrintPage() {
  const { project, mutate } = useApp()
  const rec = usePickerRecord()
  const prod = project.production
  const profile = PRODUCTION_PROFILES.find((p) => p.id === prod.profileId) ?? PRODUCTION_PROFILES[0]
  const proof = useMemo(() => proofColour(rec.linearRgb, { profile, intent: prod.intent, blackPointCompensation: prod.blackPointCompensation }), [rec, profile, prod.intent, prod.blackPointCompensation])
  const [unit, setUnit] = useState<LengthUnit>('mm')
  const asset = project.assets.find((a) => a.id === project.activeAssetId)

  const size = printSizeMm({ widthPx: asset?.width ?? 3000, heightPx: asset?.height ?? 2000, dpi: prod.dpi })
  const dpiAt = effectiveDpi(asset?.width ?? 3000, prod.widthMm)
  const req = requiredPixels(prod.widthMm, prod.heightMm, prod.dpi)
  const set = (patch: Partial<typeof prod>) => mutate('Adjust production settings', (p) => ({ ...p, production: { ...p.production, ...patch } }))

  const exportSheet = () => {
    const lines = [
      `# Production sheet`, ``, `- Source colour space: ${project.workingSpace}`, `- Working colour space: ${project.workingSpace}`,
      `- Output intent: ${INTENTS.find((i) => i.id === prod.intent)?.label}`, `- Rendering intent: ${INTENTS.find((i) => i.id === prod.intent)?.label}`,
      `- Destination profile: ${profile.name} (synthetic approximation — not a certified ICC profile)`,
      `- Gamut warning: ${proof.outOfGamut ? 'colour is outside the approximate destination gamut' : 'within approximate destination gamut'}`,
      `- Approximate ink coverage: ${fmt(proof.tac, 1)}% ${proof.tacExceeded ? '(reduced to the ink limit)' : ''}`,
      `- Image dimensions: ${asset ? `${asset.width} × ${asset.height} px` : 'n/a'}`, `- Resolution: ${prod.dpi} dpi`,
      `- Sheet size: ${fmt(prod.widthMm, 1)} × ${fmt(prod.heightMm, 1)} mm, bleed ${prod.bleedMm} mm, trim ${prod.trimMm} mm`,
      `- Timestamp: ${isoNow()}`, `- Operator notes: ${prod.operatorNotes || '—'}`, ``, `> Approximation only. Not a certified proof.`,
    ]
    downloadText('production-sheet.md', lines.join('\n'), 'text/markdown')
  }

  return (
    <div className="page">
      <ToolbarPortal>
        <Select ariaLabel="Production profile" value={prod.profileId} onChange={(id) => set({ profileId: id })} options={PRODUCTION_PROFILES.map((p) => ({ id: p.id, label: p.name }))} />
        <Select ariaLabel="Rendering intent" value={prod.intent} onChange={(id) => set({ intent: id })} options={INTENTS.map((i) => ({ id: i.id, label: i.label }))} />
        <Check2 checked={prod.blackPointCompensation} onChange={(v) => set({ blackPointCompensation: v })}>Black-point compensation</Check2>
      </ToolbarPortal>
      <InspectorPortal>
        <div className="col" style={{ padding: 10 }}>
          <Panel title="Profile"><div className="small">{profile.note}</div><Kv rows={[['Ink limit', `${profile.inkLimit}%`], ['Dot gain (mid)', `${profile.dotGain}%`], ['Gamut scale', profile.gamutScale.toFixed(2)]]} /></Panel>
          <Notice kind="approx" title="Approximation">Synthetic profile parameters, not certified ICC/FOGRA/SWOP data.</Notice>
        </div>
      </InspectorPortal>
      <div className="split wide">
        <div className="col">
          <Panel title="Proof preview" actions={<Badge kind={proof.outOfGamut ? 'warn' : 'ok'}>{proof.outOfGamut ? 'outside gamut' : 'in gamut'}</Badge>}>
            <div className="row">
              <div className="col" style={{ alignItems: 'center' }}><Swatch hex={rgbToHex(rec.srgb)} size={64} /><span className="small faint">Screen</span></div>
              <div className="col" style={{ alignItems: 'center' }}><Swatch hex={rgbToHex(linearToSrgb(proof.preview))} size={64} /><span className="small faint">Proof</span></div>
            </div>
            <Kv rows={[['CMYK ≈', `${fmt(proof.cmyk.c * 100, 0)} ${fmt(proof.cmyk.m * 100, 0)} ${fmt(proof.cmyk.y * 100, 0)} ${fmt(proof.cmyk.k * 100, 0)}`], ['Total ink coverage', <Badge key="t" kind={proof.tacExceeded ? 'warn' : 'ok'}>{fmt(proof.tac, 1)}%{proof.tacExceeded ? ' (limited)' : ''}</Badge>], ['Appearance shift (OKLab ΔE×100)', fmt(proof.shift, 2)]]} />
            <div className="small faint">Use the Colour Picker to change the colour being proofed.</div>
          </Panel>
          <Panel title="Rendering intents compared">
            <div className="row wrap">
              {INTENTS.map((i) => { const r = proofColour(rec.linearRgb, { profile, intent: i.id, blackPointCompensation: prod.blackPointCompensation }); return (
                <div key={i.id} className="col" style={{ alignItems: 'center', width: 110, gap: 3 }}><Swatch hex={rgbToHex(linearToSrgb(r.preview))} w={100} h={54} title={i.note} /><span className="small">{i.label}</span></div>
              ) })}
            </div>
          </Panel>
        </div>
        <div className="col">
          <Panel title="Size & resolution">
            <div className="field"><span className="label">Units</span><Select ariaLabel="Units" value={unit} onChange={setUnit} options={[{ id: 'mm', label: 'mm' }, { id: 'cm', label: 'cm' }, { id: 'in', label: 'in' }]} /></div>
            <div className="row"><div className="field grow"><span className="label">Sheet width</span><NumInput value={fromMm(prod.widthMm, unit)} onChange={(v) => set({ widthMm: toMm(v, unit) })} decimals={1} unit={unit} /></div>
              <div className="field grow"><span className="label">Sheet height</span><NumInput value={fromMm(prod.heightMm, unit)} onChange={(v) => set({ heightMm: toMm(v, unit) })} decimals={1} unit={unit} /></div></div>
            <Slider label="DPI" value={prod.dpi} min={72} max={600} step={1} decimals={0} defaultValue={300} onChange={(v) => set({ dpi: v })} />
            <Kv rows={[
              ['Image size', asset ? `${asset.width} × ${asset.height} px` : '—'],
              ['Printed at DPI', `${fmt(size.w, 1)} × ${fmt(size.h, 1)} mm`],
              ['Effective DPI at sheet size', <Badge key="d" kind={dpiRating(dpiAt).ok ? 'ok' : 'warn'}>{fmt(dpiAt, 0)} ppi — {dpiRating(dpiAt).label}</Badge>],
              ['Pixels needed for sheet @ DPI', `${req.w} × ${req.h} px`],
            ]} />
            <div className="row"><div className="field grow"><span className="label">Bleed</span><NumInput value={prod.bleedMm} onChange={(v) => set({ bleedMm: v })} decimals={1} unit="mm" min={0} /></div>
              <div className="field grow"><span className="label">Trim</span><NumInput value={prod.trimMm} onChange={(v) => set({ trimMm: v })} decimals={1} unit="mm" min={0} /></div></div>
          </Panel>
          <Panel title="Production sheet">
            <textarea className="textarea" rows={3} placeholder="Operator notes…" value={prod.operatorNotes} onChange={(e) => set({ operatorNotes: e.target.value })} />
            <button className="btn primary" onClick={exportSheet}>Export production sheet</button>
          </Panel>
        </div>
      </div>
    </div>
  )
}
