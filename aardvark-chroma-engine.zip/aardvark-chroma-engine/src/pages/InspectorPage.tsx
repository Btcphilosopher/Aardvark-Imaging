import { useMemo } from 'react'
import { useApp } from '../state/store'
import { useInspect, useLab } from '../state/lab'
import { ToolbarPortal, InspectorPortal } from '../components/shell/Slots'
import { Panel, Swatch, Btn, Notice } from '../components/common/ui'
import { ImageViewer } from '../components/image-viewer/ImageViewer'
import { PixelReadout, Loupe } from '../components/inspectors/PixelReadout'
import { ToolStrip } from '../components/toolbars/ToolStrip'
import { useLabRenderParams } from '../hooks/useRenderParams'
import { makeRecord } from '../core/colour/colour-model'
import { deltaE2000Linear } from '../core/colour/contrast'
import { fmt, downloadText } from '../utils/format'

export default function InspectorPage() {
  const project = useApp((s) => s.project)
  const saveSample = useApp((s) => s.saveSample)
  const { points, removePoint, clearPoints, regions, clearRegions, history } = useInspect()
  const lab = useLab()
  const { params, depsKey } = useLabRenderParams()
  const images = project.assets.filter((a) => a.kind === 'image')
  const asset = images.find((a) => a.id === project.activeAssetId) ?? images[0]

  const distances = useMemo(() => {
    const out: { a: number; b: number; px: number; de: number }[] = []
    for (let i = 0; i < points.length; i++) for (let j = i + 1; j < points.length; j++) {
      const A = points[i].sample, B = points[j].sample
      out.push({ a: i, b: j, px: Math.hypot(A.x - B.x, A.y - B.y), de: deltaE2000Linear(A.record.linearRgb, B.record.linearRgb) })
    }
    return out
  }, [points])

  const exportPoints = () => {
    const rows = points.map((p, i) => ({ label: `P${i + 1}`, x: p.sample.x, y: p.sample.y, hex: p.sample.record.hex, oklch: p.sample.record.oklch }))
    downloadText('pixel-points.json', JSON.stringify(rows, null, 2), 'application/json')
  }

  if (!asset) return <div className="page"><Notice kind="warn">No image asset available.</Notice></div>

  return (
    <div className="page fill" style={{ display: 'grid', gridTemplateColumns: 'auto minmax(0,1fr)', height: '100%' }}>
      <ToolbarPortal><span className="small muted">Sample tool active — click to add a point, drag for a region average.</span></ToolbarPortal>
      <ToolStrip />
      <ImageViewer asset={asset} params={params} depsKey={depsKey} compare={{ mode: 'off', wipe: 0.5 }} pixelGrid={lab.pixelGrid} histogramOverlay={false} sampleSource={lab.sampleSource} />
      <InspectorPortal>
        <div className="col" style={{ padding: 10 }}>
          <Panel title="Live readout"><PixelReadout /><Loupe /></Panel>
          <Panel title={`Points · ${points.length}`} actions={points.length > 0 && <Btn size="sm" kind="ghost" onClick={clearPoints}>Clear</Btn>}>
            {points.length === 0 ? <span className="small muted">Click the image with the Sample tool to add points.</span> : points.map((p, i) => (
              <div key={p.id} className="row small" style={{ justifyContent: 'space-between' }}>
                <span className="row"><Swatch hex={p.sample.record.hex} size={16} />P{i + 1} · {p.sample.x},{p.sample.y} · {p.sample.record.hex.toUpperCase()}</span>
                <span className="row" style={{ gap: 4 }}>
                  <Btn size="sm" kind="ghost" onClick={() => saveSample(makeRecord({ linear: p.sample.record.linearRgb, name: `Point P${i + 1}` }), `Pixel inspector point at ${p.sample.x},${p.sample.y}`, { assetId: asset.id, point: { x: p.sample.x, y: p.sample.y }, origin: 'pixel' })}>Save</Btn>
                  <Btn size="sm" kind="ghost" onClick={() => removePoint(p.id)}>✕</Btn>
                </span>
              </div>
            ))}
            {points.length > 0 && <Btn size="sm" onClick={exportPoints}>Export points JSON</Btn>}
          </Panel>
          {distances.length > 0 && (
            <Panel title="Distances">
              {distances.map((d, i) => <div key={i} className="small row" style={{ justifyContent: 'space-between' }}><span>P{d.a + 1} ↔ P{d.b + 1}</span><span className="mono">{fmt(d.px, 1)} px · ΔE00 {fmt(d.de, 2)}</span></div>)}
            </Panel>
          )}
          <Panel title={`Region averages · ${regions.length}`} actions={regions.length > 0 && <Btn size="sm" kind="ghost" onClick={clearRegions}>Clear</Btn>}>
            {regions.length === 0 ? <span className="small muted">Drag with the Sample tool to average a region.</span> : regions.map((r) => (
              <div key={r.id} className="row small" style={{ justifyContent: 'space-between' }}>
                <span className="row"><Swatch hex={r.hex} size={16} />{r.rect.w}×{r.rect.h} @ {r.rect.x},{r.rect.y}</span>
                <Btn size="sm" kind="ghost" onClick={() => saveSample(makeRecord({ linear: r.meanLinear, name: `Region ${r.rect.w}×${r.rect.h}` }), 'Region average (linear-light mean)', { assetId: asset.id, origin: 'region' })}>Save</Btn>
              </div>
            ))}
          </Panel>
          <Panel title="Recent samples" bodyClass="col">
            <div className="row wrap">{history.slice(0, 16).map((h) => <Swatch key={h.id} hex={h.sample.record.hex} size={18} title={`${h.sample.x},${h.sample.y} · ${h.sample.record.hex}`} />)}</div>
          </Panel>
        </div>
      </InspectorPortal>
    </div>
  )
}
