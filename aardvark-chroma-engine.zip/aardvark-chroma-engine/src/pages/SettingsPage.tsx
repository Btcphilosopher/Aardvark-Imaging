import { useApp } from '../state/store'
import { Panel, Select, Notice, Kv, Btn } from '../components/common/ui'
import { SystemDashboard } from '../components/inspectors/SystemDashboard'
import { DISPLAY_PROFILES } from '../core/calibration/calibration'
import { PRODUCTION_PROFILES, INTENTS } from '../core/print/print'
import { downloadText } from '../utils/format'

const SHORTCUTS: [string, string][] = [
  ['Ctrl/Cmd K', 'Command palette'], ['Ctrl/Cmd S', 'Save now'], ['Ctrl/Cmd Z / Shift Z', 'Undo / redo'], ['Alt + 1–9, 0', 'Go to page'],
  ['\\', 'Toggle inspector'], ['V / H / Z / S / C / M / A / B', 'Select / Pan / Zoom / Sample / Crop / Measure / Annotate / Compare'],
  ['F', 'Fit to screen'], ['1 / 2 / 4', 'Zoom 100 / 200 / 400 %'], ['Scroll', 'Zoom at cursor'], ['Drag', 'Pan (Select or Pan tool)'],
]

export default function SettingsPage() {
  const { project, mutate, toast } = useApp()

  const set = (patch: Partial<typeof project>) => mutate('Change project settings', (p) => ({ ...p, ...patch }))

  return (
    <div className="page">
      <div className="split">
        <div className="col">
          <Panel title="Project settings">
            <div className="field"><span className="label">Name</span><input className="input" value={project.name} onChange={(e) => set({ name: e.target.value })} /></div>
            <div className="field"><span className="label">Code</span><input className="input mono" value={project.code} onChange={(e) => set({ code: e.target.value })} /></div>
            <div className="field"><span className="label">Operator</span><input className="input" value={project.operator} onChange={(e) => set({ operator: e.target.value })} /></div>
            <div className="field"><span className="label">Working space</span><input className="input" value={project.workingSpace} onChange={(e) => set({ workingSpace: e.target.value })} /></div>
            <div className="field"><span className="label">Source profile</span><input className="input" value={project.sourceProfile} onChange={(e) => set({ sourceProfile: e.target.value })} /></div>
            <div className="field"><span className="label">Destination profile</span><input className="input" value={project.destinationProfile} onChange={(e) => set({ destinationProfile: e.target.value })} /></div>
            <div className="field"><span className="label">Output intent</span><input className="input" value={project.outputIntent} onChange={(e) => set({ outputIntent: e.target.value })} /></div>
            <div className="field"><span className="label">Target display</span><Select ariaLabel="Target display" value={project.displayId} onChange={(id) => set({ displayId: id })} options={DISPLAY_PROFILES.map((d) => ({ id: d.id, label: d.name }))} /></div>
            <div className="field"><span className="label">Notes</span><textarea className="textarea" rows={4} value={project.notes} onChange={(e) => set({ notes: e.target.value })} /></div>
          </Panel>
          <Panel title="Production defaults">
            <Kv rows={[['Profile', PRODUCTION_PROFILES.find((p) => p.id === project.production.profileId)?.name ?? '—'], ['Intent', INTENTS.find((i) => i.id === project.production.intent)?.label ?? '—']]} />
            <span className="small faint">Change these in Print & Production.</span>
          </Panel>
        </div>
        <div className="col">
          <Panel title="Technical dashboard"><SystemDashboard /></Panel>
          <Panel title="Keyboard shortcuts">
            <table className="tbl"><tbody>{SHORTCUTS.map(([k, v]) => <tr key={k}><td className="mono" style={{ width: 170 }}><kbd>{k}</kbd></td><td className="small">{v}</td></tr>)}</tbody></table>
          </Panel>
          <Panel title="Autosave">
            <Notice kind="info">Changes are saved to this browser's IndexedDB automatically, about 700 ms after you stop editing, and immediately when you switch or close projects.</Notice>
            <Btn size="sm" onClick={() => downloadText('project-adjustment-log.json', JSON.stringify(project.adjustmentLog, null, 2), 'application/json')}>Export adjustment log</Btn>
          </Panel>
          <Panel title="Diagnostics">
            <Btn size="sm" onClick={() => { toast('info', 'CHROMA ENGINE — colour is measurement. Imaging is engineering.') }}>Test notification</Btn>
          </Panel>
        </div>
      </div>
    </div>
  )
}
