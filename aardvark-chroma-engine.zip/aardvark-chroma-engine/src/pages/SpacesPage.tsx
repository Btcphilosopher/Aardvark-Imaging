import { useMemo, useState } from 'react'
import { usePickerRecord } from '../state/store'
import { Panel, Kv, Badge, Notice, Seg } from '../components/common/ui'
import { RGB_SPACES, type RgbSpaceId } from '../core/colour/conversions'
import { maxChromaOklch } from '../core/colour/gamut'
import { oklabToOklch, linearToOklab, oklabToLinear, oklchToOklab, linearToSrgb } from '../core/colour/conversions'
import { fmt } from '../utils/format'

const SPECTRAL_LOCUS: [number, number][] = [
  [0.1741, 0.0050], [0.1740, 0.0050], [0.1638, 0.0050], [0.1440, 0.0297], [0.1355, 0.0776], [0.1241, 0.1730], [0.1096, 0.3202], [0.0913, 0.4959],
  [0.0687, 0.6685], [0.0454, 0.7967], [0.0235, 0.8630], [0.0082, 0.8752], [0.0039, 0.8339], [0.0139, 0.7502], [0.0389, 0.6519], [0.0743, 0.5586],
  [0.1142, 0.4692], [0.1547, 0.3900], [0.1929, 0.3232], [0.2296, 0.2702], [0.2658, 0.2270], [0.3016, 0.1911], [0.3373, 0.1600], [0.3731, 0.1327],
  [0.4087, 0.1091], [0.4441, 0.0886], [0.4788, 0.0705], [0.5125, 0.0549], [0.5448, 0.0418], [0.5752, 0.0312], [0.6029, 0.0228], [0.6270, 0.0165],
  [0.6482, 0.0117], [0.6658, 0.0082], [0.6801, 0.0058], [0.6915, 0.0041], [0.7006, 0.0029], [0.7079, 0.0020], [0.7140, 0.0013], [0.7190, 0.0009],
  [0.7230, 0.0006], [0.7260, 0.0004], [0.7283, 0.0003], [0.7300, 0.0002], [0.1741, 0.0050],
]

function ChromaticityDiagram({ highlight }: { highlight?: { x: number; y: number } }) {
  const size = 320
  const P = (x: number, y: number) => [24 + x * (size - 48), size - 24 - y * (size - 48)]
  const path = SPECTRAL_LOCUS.map(([x, y], i) => `${i ? 'L' : 'M'}${P(x, y).join(',')}`).join(' ') + 'Z'
  const tri = (ids: [number, number][]) => ids.map(([x, y], i) => `${i ? 'L' : 'M'}${P(x, y).join(',')}`).join(' ') + 'Z'
  const spaces: { id: RgbSpaceId; colour: string; pts: [number, number][] }[] = [
    { id: 'srgb', colour: '#ef5a4e', pts: [[0.64, 0.33], [0.3, 0.6], [0.15, 0.06]] },
    { id: 'displayP3', colour: '#e0a11a', pts: [[0.68, 0.32], [0.265, 0.69], [0.15, 0.06]] },
    { id: 'rec2020', colour: '#4fb39b', pts: [[0.708, 0.292], [0.17, 0.797], [0.131, 0.046]] },
  ]
  const d65 = P(0.3127, 0.329)
  return (
    <svg viewBox={`0 0 ${size} ${size}`} width="100%" style={{ maxWidth: 380, background: '#111315', border: '1px solid var(--line)' }} role="img" aria-label="CIE 1931 xy chromaticity diagram">
      <path d={path} fill="#1c1f22" stroke="#3a4046" />
      {spaces.map((s) => <path key={s.id} d={tri(s.pts)} fill="none" stroke={s.colour} strokeWidth={1.6} />)}
      <circle cx={d65[0]} cy={d65[1]} r={3} fill="#e9ecee" /><text x={d65[0] + 6} y={d65[1] + 3} fontSize="9" fill="#e9ecee">D65</text>
      {highlight && (() => { const [hx, hy] = P(highlight.x, highlight.y); return <circle cx={hx} cy={hy} r={5} fill="none" stroke="#ff7d24" strokeWidth={2} /> })()}
      <text x={8} y={14} fontSize="9" fill="#8a939b">y</text><text x={size - 16} y={size - 8} fontSize="9" fill="#8a939b">x</text>
    </svg>
  )
}

export default function SpacesPage() {
  const rec = usePickerRecord()
  const [space, setSpace] = useState<RgbSpaceId>('srgb')
  const xy = useMemo(() => { const s = rec.xyz.x + rec.xyz.y + rec.xyz.z; return s > 1e-9 ? { x: rec.xyz.x / s, y: rec.xyz.y / s } : { x: 0.3127, y: 0.329 } }, [rec])
  const ok = oklabToOklch(linearToOklab(rec.linearRgb))
  const maxC = maxChromaOklch(ok.l, ok.h, space)
  return (
    <div className="page">
      <div className="split">
        <div className="col">
          <Panel title="CIE 1931 chromaticity" actions={<Seg options={[{ id: 'srgb', label: 'sRGB' }, { id: 'displayP3', label: 'P3' }, { id: 'rec2020', label: 'Rec.2020' }]} value={space} onChange={setSpace} />}>
            <ChromaticityDiagram highlight={xy} />
            <div className="legend"><span><i style={{ background: '#ef5a4e' }} />sRGB</span><span><i style={{ background: '#e0a11a' }} />Display P3</span><span><i style={{ background: '#4fb39b' }} />Rec.2020</span><span><i style={{ background: '#ff7d24', borderRadius: '50%' }} />current colour</span></div>
          </Panel>
          <Panel title="OKLCh gamut slice at current lightness/hue">
            <GamutSlice l={ok.l} h={ok.h} space={space} current={ok.c} />
            <div className="small faint">Maximum chroma at L={fmt(ok.l, 3)}, h={fmt(ok.h, 1)}° in {RGB_SPACES[space].label}: <b className="mono">{fmt(maxC, 4)}</b></div>
          </Panel>
        </div>
        <div className="col">
          <Panel title="Space reference">
            <table className="tbl">
              <thead><tr><th>Space</th><th>Primaries (x,y)</th><th>White</th><th>Transfer</th></tr></thead>
              <tbody>
                <tr><td>sRGB</td><td className="mono small">R .64/.33 G .30/.60 B .15/.06</td><td>D65</td><td>sRGB piecewise (γ≈2.4)</td></tr>
                <tr><td>Display P3</td><td className="mono small">R .68/.32 G .265/.69 B .15/.06</td><td>D65</td><td>sRGB piecewise</td></tr>
                <tr><td>Rec.2020</td><td className="mono small">R .708/.292 G .17/.797 B .131/.046</td><td>D65</td><td>BT.2020 piecewise</td></tr>
              </tbody>
            </table>
          </Panel>
          <Panel title="Current colour">
            <Kv rows={[
              ['xy', `${fmt(xy.x, 4)}, ${fmt(xy.y, 4)}`],
              ['In sRGB', <Badge key="1" kind={rec.gamutStatus.srgb ? 'ok' : 'bad'}>{String(rec.gamutStatus.srgb)}</Badge>],
              ['In P3', <Badge key="2" kind={rec.gamutStatus.displayP3 ? 'ok' : 'bad'}>{String(rec.gamutStatus.displayP3)}</Badge>],
              ['In Rec.2020', <Badge key="3" kind={rec.gamutStatus.rec2020 ? 'ok' : 'bad'}>{String(rec.gamutStatus.rec2020)}</Badge>],
            ]} />
          </Panel>
          <Notice kind="approx" title="Scope">Screen rendering is not colour-managed by the browser beyond its own display profile handling; this diagram shows defined primaries, not a measured display gamut.</Notice>
        </div>
      </div>
    </div>
  )
}

function GamutSlice({ l, h, space, current }: { l: number; h: number; space: RgbSpaceId; current: number }) {
  const n = 48
  const pts = Array.from({ length: n }, (_, i) => { const c = (i / (n - 1)) * 0.4; return { c, ok: linearToSrgb(oklabToLinear(oklchToOklab({ l, c, h }))) } })
  const w = 320, hh = 28
  return (
    <div>
      <svg viewBox={`0 0 ${w} ${hh}`} width="100%" height={hh} style={{ display: 'block' }}>
        {pts.map((p, i) => { const inb = p.ok.r >= -1e-4 && p.ok.r <= 1.0001 && p.ok.g >= -1e-4 && p.ok.g <= 1.0001 && p.ok.b >= -1e-4 && p.ok.b <= 1.0001; const e = { r: Math.min(1, Math.max(0, p.ok.r)), g: Math.min(1, Math.max(0, p.ok.g)), b: Math.min(1, Math.max(0, p.ok.b)) }; return <rect key={i} x={(i / n) * w} y={0} width={w / n + 0.5} height={hh} fill={`rgb(${Math.round(e.r * 255)},${Math.round(e.g * 255)},${Math.round(e.b * 255)})`} opacity={inb ? 1 : 0.25} /> })}
        <line x1={(current / 0.4) * w} x2={(current / 0.4) * w} y1={0} y2={hh} stroke="#fff" strokeWidth={2} />
      </svg>
      <div className="small faint">Chroma 0 → 0.4 at constant L and h in {RGB_SPACES[space].label}. Faded = outside gamut.</div>
    </div>
  )
}
