import { useMemo, useState } from 'react'
import { useApp } from '../state/store'
import { Panel, Seg, Slider, Swatch, Notice, Kv, Select, Btn } from '../components/common/ui'
import { MIX_SPACES, mixColours, mixSteps, stepUniformity, type MixSpace, type HueMode } from '../core/colour/interpolation'
import { alphaOver, blendColours, additiveLight, pigmentMix, BLEND_MODES, type BlendMode } from '../core/colour/compositing'
import { hexRecord, makeRecord } from '../core/colour/colour-model'
import { rgbToHex, linearToSrgb } from '../core/colour/conversions'
import { fmt } from '../utils/format'
import { HexInput } from '../components/common/ui'

const HUE_MODES: { id: HueMode; label: string }[] = [{ id: 'shorter', label: 'Shorter' }, { id: 'longer', label: 'Longer' }, { id: 'increasing', label: 'Increasing' }, { id: 'decreasing', label: 'Decreasing' }]

export default function MixingPage() {
  const toast = useApp((s) => s.toast)
  const [a, setA] = useState(() => hexRecord('#e8630a', 'Colour A'))
  const [b, setB] = useState(() => hexRecord('#33475b', 'Colour B'))
  const [aAlpha, setAAlpha] = useState(1), [bAlpha, setBAlpha] = useState(1)
  const [space, setSpace] = useState<MixSpace>('oklch')
  const [hueMode, setHueMode] = useState<HueMode>('shorter')
  const [steps, setSteps] = useState(9)
  const [t, setT] = useState(0.5)
  const [blend, setBlend] = useState<BlendMode>('multiply')

  const ramp = useMemo(() => mixSteps({ linear: a.linearRgb, alpha: aAlpha }, { linear: b.linearRgb, alpha: bAlpha }, steps, { space, hueMode }), [a, b, aAlpha, bAlpha, steps, space, hueMode])
  const uni = useMemo(() => stepUniformity(ramp), [ramp])
  const mid = useMemo(() => mixColours({ linear: a.linearRgb, alpha: aAlpha }, { linear: b.linearRgb, alpha: bAlpha }, t, { space, hueMode }), [a, b, aAlpha, bAlpha, t, space, hueMode])
  const midRec = makeRecord({ linear: mid.linear, alpha: mid.alpha })

  const acrossSpaces = useMemo(() => MIX_SPACES.map((s) => ({ ...s, hex: rgbToHex(linearToSrgb(mixColours({ linear: a.linearRgb, alpha: 1 }, { linear: b.linearRgb, alpha: 1 }, 0.5, { space: s.id }).linear)) })), [a, b])

  const over = alphaOver({ linear: a.linearRgb, alpha: aAlpha }, { linear: b.linearRgb, alpha: bAlpha })
  const blended = blendColours(b.linearRgb, a.linearRgb, blend)
  const add = additiveLight(a.linearRgb, b.linearRgb)
  const pig = pigmentMix(a.linearRgb, b.linearRgb, 0.5)

  return (
    <div className="page">
      <div className="split wide">
        <div className="col">
          <Panel title="Source colours">
            <div className="grid cols-2">
              <div className="col">
                <div className="row"><Swatch hex={a.hex} size={40} /><HexInput hex={a.hex} onChange={(l) => setA(makeRecord({ linear: l, name: 'Colour A' }))} label="Colour A" /></div>
                <Slider label="Alpha A" value={aAlpha} min={0} max={1} step={0.01} onChange={setAAlpha} defaultValue={1} />
              </div>
              <div className="col">
                <div className="row"><Swatch hex={b.hex} size={40} /><HexInput hex={b.hex} onChange={(l) => setB(makeRecord({ linear: l, name: 'Colour B' }))} label="Colour B" /></div>
                <Slider label="Alpha B" value={bAlpha} min={0} max={1} step={0.01} onChange={setBAlpha} defaultValue={1} />
              </div>
            </div>
          </Panel>
          <Panel title="Digital interpolation" actions={<Seg options={MIX_SPACES.map((s) => ({ id: s.id, label: s.id.toUpperCase() }))} value={space} onChange={setSpace} />}>
            <Notice kind="info">Digital interpolation: a mathematical blend of colour coordinates. Not light mixing, not pigment mixing.</Notice>
            {MIX_SPACES.find((s) => s.id === space)?.polar && <Seg label="Hue route" options={HUE_MODES} value={hueMode} onChange={setHueMode} />}
            <div className="row"><Slider label="Steps" value={steps} min={3} max={16} step={1} decimals={0} onChange={(v) => setSteps(Math.round(v))} defaultValue={9} /></div>
            <div className="strip">{ramp.map((c, i) => { const rec = makeRecord({ linear: c.linear, alpha: c.alpha }); return <Swatch key={i} css={rgbToHex(linearToSrgb(c.linear))} alpha={c.alpha} title={rec.hex} /> })}</div>
            <div className="row"><Slider label="t" value={t} min={0} max={1} step={0.005} onChange={setT} defaultValue={0.5} /></div>
            <div className="row"><Swatch hex={midRec.hex} alpha={midRec.alpha} size={36} /><span className="mono small">{midRec.hex.toUpperCase()} · α {fmt(midRec.alpha, 2)}</span></div>
            <Kv rows={[['Mean step ΔE_OK×100', fmt(uni.mean, 2)], ['Step deviation', fmt(uni.deviation, 3)], ['Endpoint ΔE_OK×100', fmt(uni.endpoint, 2)], ['Min lightness on ramp', fmt(uni.minLightness, 3)]]} />
            {uni.minLightness < Math.min(a.oklab.l, b.oklab.l) - 0.03 && space === 'srgb' && <Notice kind="warn" title="Dark band">sRGB/linear interpolation between saturated hues can dip below both endpoints' lightness — the classic muddy-purple artefact. Try OKLCh.</Notice>}
          </Panel>
          <Panel title="Compare across spaces">
            <div className="row wrap">{acrossSpaces.map((s) => <div key={s.id} className="col" style={{ alignItems: 'center', gap: 3 }}><Swatch hex={s.hex} size={40} title={`${s.label}: ${s.hex}`} /><span className="small faint">{s.id}</span></div>)}</div>
            <div className="small faint">Midpoint (t=0.5) of the same two colours, one swatch per mixing model.</div>
          </Panel>
        </div>
        <div className="col">
          <Panel title="Alpha compositing (Porter–Duff over)">
            <Notice kind="info">A over B: layered translucent media (UI layers, glass, overlays).</Notice>
            <div className="row"><Swatch hex={rgbToHex(linearToSrgb(over.linear))} size={40} /><Kv rows={[['Result', rgbToHex(linearToSrgb(over.linear)).toUpperCase()], ['Result α', fmt(over.alpha, 3)]]} /></div>
          </Panel>
          <Panel title="Blend modes" actions={<Select ariaLabel="Blend mode" value={blend} onChange={setBlend} options={BLEND_MODES.map((m) => ({ id: m, label: m }))} />}>
            <Notice kind="info">Photoshop/W3C-style formulas, evaluated on encoded sRGB. A over B is not the same operation.</Notice>
            <div className="row"><Swatch hex={rgbToHex(linearToSrgb(blended))} size={40} /><span className="mono small">{rgbToHex(linearToSrgb(blended)).toUpperCase()}</span></div>
          </Panel>
          <Panel title="Additive light">
            <Notice kind="info">Sum of emitters (stage lights, displays). Values can exceed display white.</Notice>
            <div className="row"><Swatch hex={rgbToHex(linearToSrgb({ r: Math.min(1, add.linear.r), g: Math.min(1, add.linear.g), b: Math.min(1, add.linear.b) }))} size={40} />
              <Kv rows={[['Peak', fmt(add.peak, 3)], ['Overexposed', add.overexposed ? <span style={{ color: 'var(--red)' }}>yes — would clip</span> : 'no']]} />
            </div>
          </Panel>
          <Panel title="Pigment-style approximation">
            <Notice kind="approx" title="Approximation">Weighted geometric mean of linear reflectance. Not a spectral or Kubelka–Munk model — useful for an intuitive "paint-like" mix only.</Notice>
            <div className="row"><Swatch hex={rgbToHex(linearToSrgb(pig))} size={40} /><span className="mono small">{rgbToHex(linearToSrgb(pig)).toUpperCase()}</span></div>
          </Panel>
          <Btn onClick={() => toast('ok', `Mixed ${midRec.hex.toUpperCase()} saved is available from Save sample in the picker`)} kind="ghost" size="sm">Tip: dial in a mix, then copy its hex above</Btn>
        </div>
      </div>
    </div>
  )
}
