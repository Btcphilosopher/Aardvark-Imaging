import { useMemo, useRef, useState } from 'react'
import { Download, Upload } from 'lucide-react'
import { useApp } from '../state/store'
import { ToolbarPortal, InspectorPortal } from '../components/shell/Slots'
import { Panel, Select, Slider, Seg, Notice, Kv, Badge, Btn, Check2 } from '../components/common/ui'
import { ImageViewer } from '../components/image-viewer/ImageViewer'
import { CurveChart } from '../components/charts/charts'
import { LUT_PRESETS, LUT_BLENDS, validateLut, neutralCurves, toCube, parseCube, type LutBlend } from '../core/lut/lut'
import { lutFor } from '../hooks/useRenderParams'
import { defaultRender } from '../core/image/image-processing'
import { useAssetImage } from '../hooks/useAssetImage'
import { downloadText, slug, isoNow } from '../utils/format'

export default function LutPage() {
  const { project, mutate, toast } = useApp()
  const images = project.assets.filter((a) => a.kind === 'image')
  const asset = images.find((a) => a.id === project.activeAssetId) ?? images[0]
  useAssetImage(asset)
  const [size, setSize] = useState(17)
  const [showBefore, setShowBefore] = useState(true)
  const fileRef = useRef<HTMLInputElement>(null)
  const lutState = project.lut
  const preset = LUT_PRESETS.find((p) => p.id === lutState.presetId) ?? LUT_PRESETS[0]
  const lut = useMemo(() => lutFor(lutState.presetId, size), [lutState.presetId, size])
  const validation = useMemo(() => validateLut(lut), [lut])
  const curves = useMemo(() => neutralCurves(lut), [lut])

  const setPreset = (id: string) => mutate(`Apply LUT “${LUT_PRESETS.find((p) => p.id === id)?.name}”`, (p) => ({ ...p, lut: { ...p.lut, presetId: id, version: p.lut.version + 1, history: [...p.lut.history, { version: p.lut.version + 1, presetId: id, strength: p.lut.strength, at: isoNow() }].slice(-20) } }))
  const setStrength = (v: number) => mutate('Adjust LUT strength', (p) => ({ ...p, lut: { ...p.lut, strength: v } }), { coalesce: 'lut-strength' })
  const setBlend = (b: LutBlend) => mutate('Change LUT blend mode', (p) => ({ ...p, lut: { ...p.lut, blend: b } }))

  const renderParams = useMemo(() => ({ ...defaultRender(), lut: { lut, strength: lutState.strength, blend: lutState.blend } }), [lut, lutState.strength, lutState.blend])
  const beforeParams = useMemo(() => ({ ...defaultRender() }), [])

  const exportCube = () => downloadText(`${slug(preset.name)}-${size}.cube`, toCube(lut, { title: preset.name, comments: [`CHROMA ENGINE — ${preset.description}`, `Project: ${project.name}`] }), 'text/plain')

  const importCube = async (file: File) => {
    const text = await file.text()
    const r = parseCube(text)
    if ('error' in r) { toast('error', `Import failed: ${r.error}`); return }
    toast('ok', `Parsed “${r.title}” (${r.size}³). Note: imported LUTs preview via validation only in this build; apply a built-in look to render.`)
  }

  if (!asset) return <div className="page"><Notice kind="warn">No image asset available.</Notice></div>

  return (
    <div className="page fill" style={{ display: 'grid', gridTemplateColumns: 'minmax(0,1fr) 360px', height: '100%' }}>
      <ToolbarPortal>
        <Select ariaLabel="LUT preset" value={lutState.presetId} onChange={setPreset} options={LUT_PRESETS.map((p) => ({ id: p.id, label: p.name }))} />
        <span className="sep" />
        <Check2 checked={showBefore} onChange={setShowBefore}>Show before/after split</Check2>
        <span className="sep" />
        <Btn size="sm" onClick={exportCube}><Download size={13} /> Export .cube</Btn>
        <Btn size="sm" kind="ghost" onClick={() => fileRef.current?.click()}><Upload size={13} /> Import .cube</Btn>
        <input ref={fileRef} type="file" accept=".cube,text/plain" hidden onChange={(e) => { const f = e.target.files?.[0]; if (f) void importCube(f); e.target.value = '' }} />
      </ToolbarPortal>
      <div style={{ height: '100%', minHeight: 0 }}>
        <ImageViewer asset={asset} params={renderParams} depsKey={JSON.stringify(renderParams) + size} compare={showBefore ? { mode: 'wipe', beforeParams, wipe: 0.5 } : { mode: 'off', wipe: 0.5 }} pixelGrid={false} histogramOverlay={false} sampleSource="displayed" minHeight={300} onWipe={() => {}} />
      </div>
      <InspectorPortal>
        <div className="col" style={{ padding: 10 }}>
          <Panel title="Look"><div className="small faint">{preset.description}</div></Panel>
          <Panel title="Application">
            <Slider label="Strength" value={lutState.strength} min={0} max={1} step={0.01} defaultValue={1} onChange={setStrength} />
            <Select ariaLabel="Blend mode" value={lutState.blend} onChange={setBlend} options={LUT_BLENDS.map((b) => ({ id: b.id, label: b.label }))} />
            <div className="field"><span className="label">Lattice size</span><Seg options={[{ id: '9', label: '9³' }, { id: '17', label: '17³' }, { id: '33', label: '33³' }]} value={String(size) as '9' | '17' | '33'} onChange={(v) => setSize(parseInt(v, 10))} /></div>
          </Panel>
          <Panel title="1D neutral response"><CurveChart series={[{ name: 'R', x: curves.x, y: curves.r, colour: '#ef5a4e' }, { name: 'G', x: curves.x, y: curves.g, colour: '#4fb39b' }, { name: 'B', x: curves.x, y: curves.b, colour: '#7c9cc0' }, { name: 'Identity', x: [0, 1], y: [0, 1], colour: '#5a6167', dash: '3 3' }]} title="Neutral-axis response" /></Panel>
          <Panel title="Validation">
            <Kv rows={[['Lattice', `${lut.size}³ (${lut.size ** 3} points)`], ['Out of range', <Badge key="o" kind={validation.outOfRange > 0 ? 'warn' : 'ok'}>{validation.outOfRange}</Badge>], ['Monotonic neutral', <Badge key="m" kind={validation.neutralMonotonic ? 'ok' : 'warn'}>{String(validation.neutralMonotonic)}</Badge>], ['Max Δ from identity', validation.maxIdentityDelta.toFixed(3)]]} />
            {validation.issues.map((i, k) => <Notice key={k} kind={i.severity === 'error' ? 'warn' : i.severity === 'warning' ? 'approx' : 'info'}>{i.message}</Notice>)}
          </Panel>
          <Panel title="Version history">
            {lutState.history.slice().reverse().slice(0, 8).map((h) => <div key={h.version} className="small faint row" style={{ justifyContent: 'space-between' }}><span>v{h.version} · {LUT_PRESETS.find((p) => p.id === h.presetId)?.name}</span><span>{h.at.slice(0, 10)}</span></div>)}
          </Panel>
        </div>
      </InspectorPortal>
    </div>
  )
}
