import { useMemo, useState } from 'react'
import { Download } from 'lucide-react'
import { useApp } from '../state/store'
import { ToolbarPortal, InspectorPortal } from '../components/shell/Slots'
import { Panel, Select, Kv, Badge, Notice, PixelCanvas, Btn } from '../components/common/ui'
import { DISPLAY_PROFILES, syntheticMeasurements, uniformityMap, PATTERNS, generatePattern, calibrationReportMarkdown, type PatternId } from '../core/calibration/calibration'
import { downloadText, slug, isoNow } from '../utils/format'

export default function CalibrationPage() {
  const { project, mutate } = useApp()
  const [pattern, setPattern] = useState<PatternId>('grayscale-ramp')
  const d = DISPLAY_PROFILES.find((x) => x.id === project.displayId) ?? DISPLAY_PROFILES[0]
  const ms = useMemo(() => syntheticMeasurements(d.id), [d.id])
  const map = useMemo(() => uniformityMap(d.id), [d.id])
  const img = useMemo(() => generatePattern(pattern), [pattern])
  const p = PATTERNS.find((x) => x.id === pattern)!

  const exportReport = () => downloadText(`${slug(d.id)}-calibration-report.md`, calibrationReportMarkdown(d, ms, { operator: project.operator, timestamp: isoNow() }), 'text/markdown')

  return (
    <div className="page">
      <ToolbarPortal>
        <Select ariaLabel="Display" value={d.id} onChange={(id) => mutate('Change target display', (pr) => ({ ...pr, displayId: id }))} options={DISPLAY_PROFILES.map((x) => ({ id: x.id, label: x.name }))} />
        <span className="sep" />
        <Select ariaLabel="Test pattern" value={pattern} onChange={setPattern} options={PATTERNS.map((x) => ({ id: x.id, label: x.name }))} />
        <Btn size="sm" onClick={exportReport}><Download size={13} /> Report</Btn>
      </ToolbarPortal>
      <InspectorPortal>
        <div className="col" style={{ padding: 10 }}>
          <Panel title={d.name}>
            <Kv rows={[['Panel', d.panel], ['Profile', d.profileName], ['Colour space', d.colourSpace], ['Target white', `${d.targetWhiteK} K`], ['Target gamma', String(d.targetGamma)], ['Target luminance', `${d.targetLuminance} cd/m²`], ['Black estimate', `${d.blackLevel} cd/m²`], ['Contrast', `${Math.round(d.targetLuminance / d.blackLevel)}:1`], ['Status', <Badge key="s" kind={d.status === 'calibrated' ? 'ok' : d.status === 'drifting' ? 'warn' : 'bad'}>{d.status}</Badge>], ['Last calibrated', d.lastCalibrated]]} />
          </Panel>
          <Panel title="Gamut coverage (synthetic)"><Kv rows={[['sRGB', `${d.coverage.srgb}%`], ['Display P3', `${d.coverage.displayP3}%`], ['Rec.2020', `${d.coverage.rec2020}%`]]} /></Panel>
          <Notice kind="approx" title="Scope">This is a calibration-planning and visual-test environment, not a replacement for hardware measurement equipment. All measurement data is synthetic.</Notice>
        </div>
      </InspectorPortal>
      <div className="split wide">
        <div className="col">
          <Panel title={p.name}>
            <PixelCanvas image={img} width="100%" />
            <div className="small faint">{p.purpose}</div>
          </Panel>
          <Panel title="Uniformity map (synthetic, ratio to centre)">
            <table className="tbl"><tbody>
              {map.map((row, y) => <tr key={y}>{row.map((v, x) => <td key={x} className="mono" style={{ textAlign: 'center', background: v < 0.9 ? 'rgba(209,40,28,0.25)' : v < 0.96 ? 'rgba(224,161,26,0.2)' : undefined }}>{v.toFixed(2)}</td>)}</tr>)}
            </tbody></table>
          </Panel>
        </div>
        <div className="col">
          <Panel title="Measurement history (synthetic)">
            <table className="tbl">
              <thead><tr><th>Date</th><th className="r">CCT</th><th className="r">γ</th><th className="r">cd/m²</th><th className="r">Avg ΔE</th></tr></thead>
              <tbody>{ms.map((m) => <tr key={m.id}><td>{m.at.slice(0, 10)}</td><td className="r">{m.cct}</td><td className="r">{m.gamma}</td><td className="r">{m.luminance}</td><td className="r"><Badge kind={m.avgDeltaE > 2 ? 'warn' : 'ok'}>{m.avgDeltaE}</Badge></td></tr>)}</tbody>
            </table>
          </Panel>
          <Panel title="All test patterns">
            <div className="row wrap">{PATTERNS.map((x) => <Btn key={x.id} size="sm" kind={x.id === pattern ? 'primary' : 'ghost'} onClick={() => setPattern(x.id)}>{x.name}</Btn>)}</div>
          </Panel>
        </div>
      </div>
    </div>
  )
}
