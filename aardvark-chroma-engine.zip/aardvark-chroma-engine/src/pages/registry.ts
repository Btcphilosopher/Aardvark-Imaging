import { lazy, type ComponentType, type LazyExoticComponent } from 'react'
import { FolderOpen, Image, Pipette, Orbit, Blend, Aperture, Palette, SlidersHorizontal, Grid3x3, Layers, Lightbulb, Monitor, Printer, BarChart3, Crosshair, ArrowLeftRight, BookOpen, Download, Library, Settings, type LucideIcon } from 'lucide-react'
import type { PageId } from '../state/store'

export interface PageDef {
  id: PageId
  index: number
  title: string
  subtitle: string
  group: string
  icon: LucideIcon
  component: LazyExoticComponent<ComponentType>
  /** shortcut digit for Alt+digit (1–9, 0 = 10) where present */
  keywords: string
}

const P = (id: PageId, index: number, title: string, subtitle: string, group: string, icon: LucideIcon, component: LazyExoticComponent<ComponentType>, keywords = ''): PageDef => ({ id, index, title, subtitle, group, icon, component, keywords })

export const PAGES: PageDef[] = [
  P('projects', 1, 'Projects', 'Local project library and session control', 'Project', FolderOpen, lazy(() => import('./ProjectsPage')), 'open create rename duplicate archive import'),
  P('image-lab', 2, 'Image Lab', 'Inspection, comparison and proofing of the active asset', 'Image', Image, lazy(() => import('./ImageLabPage')), 'viewer zoom compare histogram'),
  P('picker', 3, 'Colour Picker', 'Multi-space colour instrument', 'Colour', Pipette, lazy(() => import('./PickerPage')), 'colour color hsl oklch lab eyedropper'),
  P('spaces', 4, 'Colour Spaces', 'Gamuts, chromaticity and space reference', 'Colour', Orbit, lazy(() => import('./SpacesPage')), 'gamut xy chromaticity p3 rec2020'),
  P('mixing', 5, 'Mixing Engine', 'Interpolation, compositing, light and pigment models', 'Colour', Blend, lazy(() => import('./MixingPage')), 'interpolate gradient blend multiply screen'),
  P('harmonies', 6, 'Harmonies', 'Rule-based palette generation', 'Colour', Aperture, lazy(() => import('./HarmoniesPage')), 'complementary analogous triadic palette'),
  P('palettes', 7, 'Palette Studio', 'Library, editing, locking and comparison', 'Colour', Palette, lazy(() => import('./PalettesPage')), 'palette library lock reorder'),
  P('grading', 8, 'Grading Desk', 'Primary correction with scopes (simulated pipeline)', 'Grade', SlidersHorizontal, lazy(() => import('./GradingPage')), 'lift gamma gain wheels waveform vectorscope'),
  P('lut', 9, 'LUT Lab', 'Look LUT construction, validation and .cube export', 'Grade', Grid3x3, lazy(() => import('./LutPage')), 'cube 3d lut look'),
  P('materials', 10, 'Materials', 'Material library and lighting-dependent appearance', 'Material & light', Layers, lazy(() => import('./MaterialsPage')), 'metal stone glass concrete'),
  P('lighting', 11, 'Lighting Lab', 'Kelvin, tint and adaptation experiments', 'Material & light', Lightbulb, lazy(() => import('./LightingPage')), 'kelvin light tungsten daylight'),
  P('calibration', 12, 'Display Calibration', 'Calibration planning and visual test patterns', 'Output', Monitor, lazy(() => import('./CalibrationPage')), 'display gamma white point patterns'),
  P('print', 13, 'Print & Production', 'Approximate CMYK proofing and production sheets', 'Output', Printer, lazy(() => import('./PrintPage')), 'cmyk ink coverage dpi bleed'),
  P('analysis', 14, 'Image Analysis', 'Statistics, clusters and regional sampling', 'Measure', BarChart3, lazy(() => import('./AnalysisPage')), 'histogram dominant regions entropy'),
  P('inspector', 15, 'Pixel Inspector', 'Per-pixel readout, loupe and multi-point sampling', 'Measure', Crosshair, lazy(() => import('./InspectorPage')), 'pixel loupe sample distance'),
  P('conversion', 16, 'Colour Conversion', 'Explicit conversions with a recorded history', 'Measure', ArrowLeftRight, lazy(() => import('./ConversionPage')), 'convert xyz lab cmyk batch'),
  P('brand', 17, 'Brand Systems', 'Brand colour standards, themes and tokens', 'System', BookOpen, lazy(() => import('./BrandPage')), 'tokens theme guidelines'),
  P('export', 18, 'Export Centre', 'Validated exports with metadata', 'System', Download, lazy(() => import('./ExportPage')), 'json css svg cube csv'),
  P('assets', 19, 'Asset Library', 'Assets, reports and reference sheets', 'System', Library, lazy(() => import('./AssetsPage')), 'import drag drop image'),
  P('settings', 20, 'System Settings', 'Project settings, operational dashboard and shortcuts', 'System', Settings, lazy(() => import('./SettingsPage')), 'dashboard shortcuts autosave'),
]

export const PAGE_BY_ID: Record<PageId, PageDef> = Object.fromEntries(PAGES.map((p) => [p.id, p])) as Record<PageId, PageDef>
