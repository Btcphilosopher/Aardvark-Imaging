import { useMemo, useState } from 'react'
import { useApp } from '../state/store'
import { ToolbarPortal, InspectorPortal } from '../components/shell/Slots'
import { Panel, Select, Notice, Btn, Kv, Badge } from '../components/common/ui'
import { EXPORT_FORMATS, buildExport, validateExport, renderPngSheet, type ExportFormat, type ExportContext } from '../utils/exporters'
import { downloadText, downloadBlob, slug } from '../utils/format'
import { lutFor } from '../hooks/useRenderParams'

type SetId = 'all-samples' | 'all-palettes' | `palette:${string}`

export default function ExportPage() {
  const project = useApp((s) => s.project)
  const toast = useApp((s) => s.toast)
  const [format, setFormat] = useState<ExportFormat>('json')
  const [setId, setSetId] = useState<SetId>('all-palettes')

  const colours = useMemo(() => {
    if (setId === 'all-samples') return project.samples.map((s) => s.record)
    if (setId === 'all-palettes') return project.palettes.flatMap((p) => p.colours.map((c) => c.colour))
    const pid = setId.split(':')[1]
    return project.palettes.find((p) => p.id === pid)?.colours.map((c) => c.colour) ?? []
  }, [setId, project])

  const setLabel = setId === 'all-samples' ? 'All saved samples' : setId === 'all-palettes' ? 'All palettes' : project.palettes.find((p) => p.id === setId.split(':')[1])?.name ?? 'Set'
  const asset = project.assets.find((a) => a.id === project.activeAssetId)
  const ctx: ExportContext = useMemo(() => ({ project, colours, setName: setLabel, assetName: asset?.name ?? '—', lut: format === 'cube' ? lutFor(project.lut.presetId) : null }), [project, colours, setLabel, asset, format])
  const issues = useMemo(() => validateExport(format, ctx), [format, ctx])
  const fmtDef = EXPORT_FORMATS.find((f) => f.id === format)!
  const hasErrors = issues.some((i) => i.severity === 'error')

  const doExport = async () => {
    if (hasErrors) { toast('error', 'Fix the errors below before exporting.'); return }
    const filename = `${slug(project.code)}-${slug(setLabel)}.${fmtDef.ext}`
    if (format === 'png') {
      const blob = await renderPngSheet(ctx)
      if (blob) downloadBlob(filename, blob); else toast('error', 'Could not render PNG sheet')
    } else {
      downloadText(filename, buildExport(format, ctx), fmtDef.mime)
    }
    toast('ok', `Exported ${filename}`)
  }

  return (
    <div className="page">
      <ToolbarPortal>
        <Select ariaLabel="Set" value={setId} onChange={setSetId} options={[{ id: 'all-palettes', label: 'All palettes' }, { id: 'all-samples', label: 'All saved samples' }, ...project.palettes.map((p) => ({ id: `palette:${p.id}` as SetId, label: p.name }))]} />
        <Select ariaLabel="Format" value={format} onChange={setFormat} options={EXPORT_FORMATS.map((f) => ({ id: f.id, label: f.label }))} />
        <Btn size="sm" kind="primary" onClick={() => void doExport()} disabled={hasErrors}>Export {fmtDef.ext}</Btn>
      </ToolbarPortal>
      <InspectorPortal>
        <div className="col" style={{ padding: 10 }}>
          <Panel title="Format"><div className="small">{fmtDef.note}</div></Panel>
          <Panel title="Metadata included"><Kv rows={[['Project', `${project.name} (${project.code})`], ['Set', setLabel], ['Colours', String(colours.length)], ['Colour space', 'sRGB primaries, D65'], ['Source profile', project.sourceProfile], ['Destination', project.destinationProfile], ['Output intent', project.outputIntent]]} /></Panel>
        </div>
      </InspectorPortal>
      <Panel title="Pre-export validation" actions={<Badge kind={hasErrors ? 'bad' : issues.length ? 'warn' : 'ok'}>{issues.length ? `${issues.length} notice${issues.length > 1 ? 's' : ''}` : 'clean'}</Badge>}>
        {issues.length === 0 ? <span className="small muted">No issues found.</span> : issues.map((i, k) => <Notice key={k} kind={i.severity === 'error' ? 'warn' : i.severity === 'warning' ? 'approx' : 'info'}>{i.message}</Notice>)}
      </Panel>
      <Panel title="Preview">
        {format === 'png' ? <span className="small muted">PNG preview renders on export.</span> : (
          <pre className="mono small" style={{ maxHeight: 420, overflow: 'auto', background: 'var(--k-900)', padding: 10, border: '1px solid var(--line)' }}>{buildExport(format, ctx).slice(0, 6000)}{buildExport(format, ctx).length > 6000 ? '\n…truncated preview…' : ''}</pre>
        )}
      </Panel>
    </div>
  )
}
