import { useState } from 'react'
import { Lock, Unlock, RefreshCw, Copy, Trash2, GripVertical } from 'lucide-react'
import { useApp } from '../state/store'
import { Panel, Swatch, Btn, Select, Kv, Badge, Empty, GamutBadge } from '../components/common/ui'
import { ToolbarPortal, InspectorPortal } from '../components/shell/Slots'
import { PALETTE_KINDS, regeneratePalette, contrastData, themeVariants, type Palette, type PaletteColour } from '../core/colour/harmony'
import { fmt } from '../utils/format'
import { newId } from '../core/colour/colour-model'

export default function PalettesPage() {
  const { project, mutate, toast, setCompareWith } = useApp()
  const [activeId, setActiveId] = useState<string | null>(project.palettes[0]?.id ?? null)
  const [compareId, setCompareId] = useState<string | null>(null)
  const pal = project.palettes.find((p) => p.id === activeId) ?? project.palettes[0]

  const updatePalette = (id: string, fn: (p: Palette) => Palette, label = 'Update palette') => mutate(label, (p) => ({ ...p, palettes: p.palettes.map((x) => (x.id === id ? fn(x) : x)) }))

  const regen = (id: string) => updatePalette(id, (p) => regeneratePalette(p), `Regenerate unlocked colours in ${pal?.name}`)
  const toggleLock = (id: string, cid: string) => updatePalette(id, (p) => ({ ...p, colours: p.colours.map((c) => (c.colour.id === cid ? { ...c, locked: !c.locked } : c)) }), 'Toggle lock')
  const duplicate = (id: string) => { const src = project.palettes.find((p) => p.id === id); if (!src) return; const copy: Palette = { ...structuredClone(src), id: newId('pal'), name: `${src.name} (copy)` }; mutate(`Duplicate ${src.name}`, (p) => ({ ...p, palettes: [...p.palettes, copy] })); setActiveId(copy.id) }
  const remove = (id: string) => { mutate('Delete palette', (p) => ({ ...p, palettes: p.palettes.filter((x) => x.id !== id) })); if (activeId === id) setActiveId(project.palettes[0]?.id ?? null) }
  const renameColour = (id: string, cid: string, name: string) => updatePalette(id, (p) => ({ ...p, colours: p.colours.map((c) => (c.colour.id === cid ? { ...c, colour: { ...c.colour, name } } : c)) }), 'Rename colour', )

  const move = (id: string, from: number, to: number) => updatePalette(id, (p) => { const arr = [...p.colours]; const [item] = arr.splice(from, 1); arr.splice(to, 0, item); return { ...p, colours: arr } }, 'Reorder palette')

  if (!pal) return <div className="page"><Empty title="No palettes yet">Generate one in Harmonies, or create one below.</Empty></div>
  const compare = project.palettes.find((p) => p.id === compareId)

  return (
    <div className="page">
      <ToolbarPortal>
        <Select ariaLabel="Active palette" value={pal.id} onChange={setActiveId} options={project.palettes.map((p) => ({ id: p.id, label: p.name }))} />
        <Btn size="sm" onClick={() => regen(pal.id)} title="Regenerate unlocked colours"><RefreshCw size={13} /> Regenerate unlocked</Btn>
        <Btn size="sm" onClick={() => duplicate(pal.id)}><Copy size={13} /> Duplicate</Btn>
        <Btn size="sm" kind="danger" onClick={() => { if (confirm(`Delete palette “${pal.name}”?`)) remove(pal.id) }}><Trash2 size={13} /></Btn>
        <span className="sep" />
        <Select ariaLabel="Compare with" value={compareId ?? ''} onChange={(v) => setCompareId(v || null)} options={[{ id: '', label: 'Compare with…' }, ...project.palettes.filter((p) => p.id !== pal.id).map((p) => ({ id: p.id, label: p.name }))]} />
      </ToolbarPortal>
      <InspectorPortal>
        <div className="col" style={{ padding: 10 }}>
          <Panel title="Palette"><Kv rows={[['Kind', PALETTE_KINDS.find((k) => k.id === pal.kind)?.label ?? pal.kind], ['Colours', String(pal.colours.length)], ['Base', pal.params.baseHex.toUpperCase()]]} /></Panel>
          <Panel title="Notes"><textarea className="textarea" rows={4} value={pal.notes} placeholder="Notes about this palette…" onChange={(e) => updatePalette(pal.id, (p) => ({ ...p, notes: e.target.value }), 'Edit palette notes')} /></Panel>
          <Panel title="All palettes">
            {project.palettes.map((p) => <div key={p.id} className="row small" style={{ justifyContent: 'space-between', cursor: 'pointer', padding: '3px 0' }} onClick={() => setActiveId(p.id)}><span style={{ fontWeight: p.id === pal.id ? 600 : 400 }}>{p.name}</span><span className="faint">{p.colours.length}</span></div>)}
          </Panel>
        </div>
      </InspectorPortal>
      <div className="grid" style={{ gridTemplateColumns: compare ? '1fr 1fr' : '1fr' }}>
        <PaletteGrid pal={pal} onToggleLock={(cid) => toggleLock(pal.id, cid)} onRename={(cid, n) => renameColour(pal.id, cid, n)} onCompare={setCompareWith} onMove={(from, to) => move(pal.id, from, to)} onToast={toast} />
        {compare && <PaletteGrid pal={compare} readOnly onToggleLock={() => {}} onRename={() => {}} onCompare={setCompareWith} onMove={() => {}} onToast={toast} />}
      </div>
    </div>
  )
}

function PaletteGrid({ pal, onToggleLock, onRename, onCompare, onMove, readOnly, onToast }: { pal: Palette; onToggleLock: (cid: string) => void; onRename: (cid: string, n: string) => void; onCompare: (c: PaletteColour['colour']) => void; onMove: (from: number, to: number) => void; readOnly?: boolean; onToast: (k: 'ok' | 'info', t: string) => void }) {
  const [dragIdx, setDragIdx] = useState<number | null>(null)
  return (
    <Panel title={pal.name}>
      <div className="col">
        {pal.colours.map((c, i) => {
          const cd = contrastData(c.colour)
          return (
            <div key={c.colour.id} className="row" style={{ gap: 8, padding: '4px 0', borderBottom: '1px solid var(--line-soft)' }}
              draggable={!readOnly} onDragStart={() => setDragIdx(i)} onDragOver={(e) => e.preventDefault()} onDrop={() => { if (dragIdx !== null && dragIdx !== i) onMove(dragIdx, i); setDragIdx(null) }}>
              {!readOnly && <GripVertical size={13} className="faint" style={{ cursor: 'grab' }} />}
              <Swatch hex={c.colour.hex} size={36} onClick={() => onCompare(c.colour)} title="Click to set as compare colour" />
              <div className="grow" style={{ minWidth: 0 }}>
                {readOnly ? <div className="small" style={{ fontWeight: 600 }}>{c.colour.name}</div> : (
                  <input className="input" style={{ height: 22, padding: '0 4px' }} value={c.colour.name} onChange={(e) => onRename(c.colour.id, e.target.value)} aria-label="Colour name" />
                )}
                <div className="small faint">{c.role} · {c.colour.hex.toUpperCase()} · {c.usage}</div>
              </div>
              <GamutBadge status={c.colour.gamutStatus} />
              <Badge kind={cd.best === 'white' ? 'ok' : 'warn'} title={`${fmt(cd.onWhite, 2)}:1 on white / ${fmt(cd.onBlack, 2)}:1 on black`}>{cd.best === 'white' ? `${fmt(cd.onWhite, 1)}:1 white` : `${fmt(cd.onBlack, 1)}:1 black`}</Badge>
              {!readOnly && <Btn icon size="sm" kind="ghost" title={c.locked ? 'Unlock' : 'Lock'} onClick={() => onToggleLock(c.colour.id)}>{c.locked ? <Lock size={13} /> : <Unlock size={13} />}</Btn>}
              {!readOnly && <Btn size="sm" kind="ghost" title="Copy theme variants" onClick={() => { const v = themeVariants(c.colour); onToast('info', `Light: ${v.light.hex} · Dark: ${v.dark.hex}`) }}>Themes</Btn>}
            </div>
          )
        })}
      </div>
    </Panel>
  )
}
