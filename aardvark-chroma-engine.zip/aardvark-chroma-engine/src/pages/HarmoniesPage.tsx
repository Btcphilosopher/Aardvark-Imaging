import { useMemo, useState } from 'react'
import { useApp } from '../state/store'
import { Panel, Select, Swatch, Slider, Btn, Notice } from '../components/common/ui'
import { HexInput } from '../components/common/ui'
import { PALETTE_KINDS, defaultPaletteParams, generatePaletteColours, type PaletteKind, createPalette } from '../core/colour/harmony'
import { hexRecord } from '../core/colour/colour-model'
import { fmt } from '../utils/format'

export default function HarmoniesPage() {
  const { mutate, toast } = useApp()
  const [kind, setKind] = useState<PaletteKind>('complementary')
  const [params, setParams] = useState(() => defaultPaletteParams('#e8630a'))
  const colours = useMemo(() => generatePaletteColours(kind, params, undefined, 'harmony-preview'), [kind, params])
  const def = PALETTE_KINDS.find((k) => k.id === kind)!

  const addToProject = () => {
    const pal = createPalette(kind, params)
    mutate(`Add palette “${pal.name}”`, (p) => ({ ...p, palettes: [...p.palettes, pal] }))
    toast('ok', `Added palette “${pal.name}” to Palette Studio`)
  }

  return (
    <div className="page">
      <div className="split wide">
        <div className="col">
          <Panel title="Preview">
            <div className="row wrap" style={{ gap: 10 }}>
              {colours.map((c) => (
                <div key={c.colour.id} className="col" style={{ alignItems: 'center', gap: 4, width: 92 }}>
                  <Swatch hex={c.colour.hex} size={72} w={88} h={72} title={`${c.colour.name} ${c.colour.hex}`} />
                  <div className="small" style={{ textAlign: 'center' }}>{c.colour.name}</div>
                  <div className="faint small mono">{c.colour.hex.toUpperCase()}</div>
                  <div className="faint small" style={{ textAlign: 'center' }}>{c.role}</div>
                </div>
              ))}
            </div>
            <div className="row" style={{ justifyContent: 'flex-end' }}><Btn kind="primary" onClick={addToProject}>Add to Palette Studio</Btn></div>
          </Panel>
          <Panel title="Usage notes">
            {colours.slice(0, 6).map((c) => <div key={c.colour.id} className="small row"><Swatch hex={c.colour.hex} size={16} /><b>{c.role}</b> — {c.usage}</div>)}
          </Panel>
        </div>
        <div className="col">
          <Panel title="Kind">
            <Select ariaLabel="Palette kind" value={kind} onChange={setKind} options={PALETTE_KINDS.map((k) => ({ id: k.id, label: k.label }))} />
            <div className="small faint">{def.description}</div>
          </Panel>
          <Panel title="Parameters">
            <div className="field"><span className="label">Base colour</span><div className="row"><Swatch hex={hexRecord(params.baseHex, '').hex} size={28} /><HexInput hex={params.baseHex} onChange={(_l, _a, hex) => setParams((p) => ({ ...p, baseHex: hex }))} label="Base colour" /></div></div>
            <Slider label="Hue rotation" value={params.hueRotation} min={-180} max={180} step={1} decimals={0} defaultValue={0} onChange={(v) => setParams((p) => ({ ...p, hueRotation: v }))} format={(v) => `${fmt(v, 0)}°`} />
            <Slider label="Chroma" value={params.chroma} min={0} max={2} step={0.01} defaultValue={1} onChange={(v) => setParams((p) => ({ ...p, chroma: v }))} />
            <Slider label="Lightness" value={params.lightness} min={0.1} max={0.95} step={0.01} defaultValue={0.66} onChange={(v) => setParams((p) => ({ ...p, lightness: v }))} disabled={kind === 'material'} />
            <Slider label="Steps" value={params.steps} min={3} max={12} step={1} decimals={0} defaultValue={5} onChange={(v) => setParams((p) => ({ ...p, steps: Math.round(v) }))} />
            <Slider label="Neutralisation" value={params.neutralisation} min={0} max={1} step={0.01} defaultValue={0} onChange={(v) => setParams((p) => ({ ...p, neutralisation: v }))} />
            <Slider label="Contrast" value={params.contrast} min={0} max={1} step={0.01} defaultValue={0.5} onChange={(v) => setParams((p) => ({ ...p, contrast: v }))} />
            <Slider label="Warmth" value={params.warmth} min={-1} max={1} step={0.01} defaultValue={0} onChange={(v) => setParams((p) => ({ ...p, warmth: v }))} />
            <Slider label="Saturation ceiling" value={params.saturationCeiling} min={0.03} max={0.4} step={0.005} defaultValue={0.32} onChange={(v) => setParams((p) => ({ ...p, saturationCeiling: v }))} />
            <Select ariaLabel="Gamut restriction" value={params.gamut} onChange={(v) => setParams((p) => ({ ...p, gamut: v }))} options={[{ id: 'srgb', label: 'sRGB' }, { id: 'displayP3', label: 'Display P3' }, { id: 'rec2020', label: 'Rec.2020' }]} />
          </Panel>
          <Notice kind="info">Colours are computed in OKLCh from your parameters and mapped to the chosen gamut boundary — nothing here is randomly generated.</Notice>
        </div>
      </div>
    </div>
  )
}
