import { useMemo, useState } from 'react'
import { ToolbarPortal, InspectorPortal } from '../components/shell/Slots'
import { Panel, Swatch, Select, Kv, Notice, Btn, Badge } from '../components/common/ui'
import { MATERIALS, type MaterialCategory } from '../core/materials/materials'
import { hexRecord, makeRecord } from '../core/colour/colour-model'
import { lightSurface } from '../core/lighting/lighting'
import { useApp as useAppStore } from '../state/store'
import { SpaceTable } from '../components/colour-controls/SpaceTable'

const CATS: MaterialCategory[] = ['Metals', 'Stone', 'Concrete', 'Glass', 'Ceramics', 'Timber', 'Painted surfaces', 'Plastics', 'Textiles', 'Asphalt', 'Soil', 'Water', 'Industrial coatings']
const TEMPS: [number, string][] = [[2700, '2700K warm'], [4000, '4000K neutral'], [5600, '5600K daylight'], [6500, '6500K cool']]

export default function MaterialsPage() {
  const [cat, setCat] = useState<MaterialCategory | 'All'>('All')
  const [selId, setSelId] = useState(MATERIALS[0].id)
  const saveSample = useAppStore((s) => s.saveSample)
  const list = cat === 'All' ? MATERIALS : MATERIALS.filter((m) => m.category === cat)
  const sel = MATERIALS.find((m) => m.id === selId) ?? MATERIALS[0]
  const rec = useMemo(() => hexRecord(sel.baseHex, sel.name), [sel])

  const underLight = (k: number) => {
    const albedo = rec.linearRgb
    const lit = lightSurface(albedo, k, 0, 0.35, 0)
    return makeRecord({ linear: { r: Math.min(1, lit.r), g: Math.min(1, lit.g), b: Math.min(1, lit.b) }, name: `${sel.name} @ ${k}K` })
  }

  return (
    <div className="page">
      <ToolbarPortal>
        <Select ariaLabel="Category" value={cat} onChange={(v) => setCat(v as MaterialCategory | 'All')} options={[{ id: 'All', label: 'All categories' }, ...CATS.map((c) => ({ id: c, label: c }))]} />
      </ToolbarPortal>
      <InspectorPortal>
        <div className="col" style={{ padding: 10 }}>
          <Panel title={sel.name}>
            <Swatch hex={sel.baseHex} w={'100%' as unknown as number} h={72} />
            <Kv rows={[['Category', sel.category], ['Roughness', sel.roughness.toFixed(2)], ['Metallic', sel.metallic.toFixed(2)], ['Reflectance ≈', sel.reflectance.toFixed(2)]]} />
            <div className="small">{sel.description}</div>
            <Notice kind="info" title="Lighting">{sel.lightingNotes}</Notice>
            <Notice kind="approx" title="Production">{sel.productionNotes}</Notice>
            <Btn size="sm" onClick={() => saveSample(rec, `Material reference: ${sel.name}`, { origin: 'reference' })}>Save as sample</Btn>
          </Panel>
          <Panel title="Values"><SpaceTable rec={rec} dense /></Panel>
        </div>
      </InspectorPortal>
      <div className="grid cols-3" style={{ gridTemplateColumns: 'repeat(auto-fill,minmax(150px,1fr))' }}>
        {list.map((m) => (
          <button key={m.id} onClick={() => setSelId(m.id)} className="panel" style={{ textAlign: 'left', cursor: 'pointer', padding: 0, border: m.id === selId ? '1px solid var(--or)' : undefined }}>
            <Swatch hex={m.baseHex} w={'100%' as unknown as number} h={72} />
            <div style={{ padding: 8 }}>
              <div className="small" style={{ fontWeight: 600 }}>{m.name}</div>
              <div className="faint small">{m.category}{!m.onBoard && <Badge kind="warn" title="Not on the procedural board">off-board</Badge>}</div>
            </div>
          </button>
        ))}
      </div>
      <Panel title={`${sel.name} under different light`}>
        <div className="row wrap">
          {TEMPS.map(([k, label]) => { const r = underLight(k); return (
            <div key={k} className="col" style={{ alignItems: 'center', gap: 4, width: 120 }}>
              <Swatch hex={r.hex} w={110} h={80} title={r.hex} />
              <div className="small faint">{label}</div>
              <div className="mono small">{r.hex.toUpperCase()}</div>
            </div>
          ) })}
        </div>
        <Notice kind="approx" title="Approximation">Lambertian albedo × Planckian-locus illuminant colour with partial chromatic adaptation. Not a physically based renderer.</Notice>
      </Panel>
    </div>
  )
}
