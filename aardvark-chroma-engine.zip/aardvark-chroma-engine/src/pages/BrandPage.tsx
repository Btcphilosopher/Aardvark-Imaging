import { useState } from 'react'
import { useApp } from '../state/store'
import { ToolbarPortal, InspectorPortal } from '../components/shell/Slots'
import { Panel, Swatch, Select, Btn, CopyBtn, Notice } from '../components/common/ui'
import { hexRecord } from '../core/colour/colour-model'
import { contrastData, themeVariants } from '../core/colour/harmony'
import { downloadText, fmt } from '../utils/format'
import type { BrandColour } from '../types/project'

const GROUPS: BrandColour['group'][] = ['Primary', 'Secondary', 'Accent', 'Neutral', 'Signal']
type ThemeId = 'light' | 'dark' | 'print' | 'presentation'

export default function BrandPage() {
  const { project, mutate } = useApp()
  const [theme, setTheme] = useState<ThemeId>('light')
  const brand = project.brand

  const setTagline = (v: string) => mutate('Edit brand tagline', (p) => ({ ...p, brand: { ...p.brand, tagline: v } }))
  const setColourHex = (id: string, hex: string) => mutate('Edit brand colour', (p) => ({ ...p, brand: { ...p.brand, colours: p.brand.colours.map((c) => (c.id === id ? { ...c, hex } : c)) } }))

  const tokens = () => {
    const css = brand.colours.map((c) => `  --${c.name.toLowerCase().replace(/\s+/g, '-')}: ${c.hex};`).join('\n')
    return `:root {\n${css}\n}\n`
  }
  const tokensJson = () => JSON.stringify({ name: brand.name, tagline: brand.tagline, colours: brand.colours }, null, 2)

  return (
    <div className="page">
      <ToolbarPortal>
        <Select ariaLabel="Theme" value={theme} onChange={setTheme} options={[{ id: 'light', label: 'Light theme' }, { id: 'dark', label: 'Dark theme' }, { id: 'print', label: 'Print theme' }, { id: 'presentation', label: 'Presentation theme' }]} />
        <Btn size="sm" onClick={() => downloadText('aardvark-tokens.css', tokens(), 'text/css')}>Export CSS tokens</Btn>
        <Btn size="sm" onClick={() => downloadText('aardvark-tokens.json', tokensJson(), 'application/json')}>Export JSON tokens</Btn>
      </ToolbarPortal>
      <InspectorPortal>
        <div className="col" style={{ padding: 10 }}>
          <Panel title="Identity">
            <div className="field"><span className="label">Name</span><span className="mono">{brand.name}</span></div>
            <div className="field"><span className="label">Tagline</span><input className="input" value={brand.tagline} onChange={(e) => setTagline(e.target.value)} /></div>
          </Panel>
          <Notice kind="info">Colours generate an accessible UI palette too — see Palette Studio's “Documentation UI” palette in the primary project.</Notice>
        </div>
      </InspectorPortal>
      <Panel title="Aardvark Imaging — internal visual standards" paper>
        <div style={{ borderTop: '8px solid var(--or)', margin: '-10px -10px 10px', padding: '18px 20px 4px' }}>
          <h1 style={{ fontFamily: 'var(--font-label)', fontWeight: 700, fontSize: 22, letterSpacing: '0.12em', textTransform: 'uppercase' }}>{brand.name}</h1>
          <div className="small" style={{ color: '#4d5157' }}>{brand.tagline}</div>
        </div>
        {GROUPS.map((g) => (
          <div key={g} style={{ marginBottom: 14 }}>
            <div className="label" style={{ marginBottom: 6 }}>{g}</div>
            <div className="row wrap">
              {brand.colours.filter((c) => c.group === g).map((c) => {
                const rec = hexRecord(c.hex, c.name)
                const cd = contrastData(rec)
                return (
                  <div key={c.id} style={{ width: 172, border: '1px solid #cfc8b9' }}>
                    <Swatch hex={c.hex} w={170} h={80} />
                    <div style={{ padding: 8 }}>
                      <div className="small" style={{ fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{c.name}</div>
                      <input className="input mono small" style={{ height: 20, padding: '0 4px', marginTop: 3 }} value={c.hex.toUpperCase()} onChange={(e) => setColourHex(c.id, e.target.value)} />
                      <div className="small" style={{ color: '#4d5157', marginTop: 4 }}>{c.usage}</div>
                      <div className="small mono" style={{ marginTop: 3 }}>{fmt(cd.onWhite, 1)}:1 white · {fmt(cd.onBlack, 1)}:1 black</div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        ))}
        <div className="row" style={{ justifyContent: 'flex-end' }}>
          <CopyBtn text={tokens} label="Copy CSS tokens" />
        </div>
      </Panel>
      {theme !== 'light' && (
        <Panel title={`${theme} theme preview`}>
          <div className="row wrap">
            {brand.colours.filter((c) => c.group === 'Primary' || c.group === 'Accent').map((c) => {
              const v = themeVariants(hexRecord(c.hex, c.name))
              const swatch = theme === 'dark' ? v.dark : theme === 'print' ? hexRecord(c.hex, c.name) : v.light
              return <div key={c.id} className="col" style={{ alignItems: 'center', gap: 3 }}><Swatch hex={swatch.hex} size={44} /><span className="small faint">{c.name}</span></div>
            })}
          </div>
        </Panel>
      )}
    </div>
  )
}
