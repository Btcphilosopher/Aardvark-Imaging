import { useMemo, useState } from 'react'
import { useApp, usePickerRecord } from '../state/store'
import { ToolbarPortal, InspectorPortal } from '../components/shell/Slots'
import { Panel, Select, Swatch, Notice, Btn, CopyBtn, Kv } from '../components/common/ui'
import { cssRgb, cssHsl, cssLab, cssLch, cssOklab, cssOklch, cssP3, cssRec2020, shortDate, isoNow } from '../utils/format'
import { newId } from '../core/colour/colour-model'
import type { ConversionEntry } from '../types/project'

type ConvId = 'sRGB' | 'HSL' | 'CIELAB' | 'CIELCh' | 'OKLab' | 'OKLCh' | 'Display P3' | 'Rec.2020'
const TARGETS: ConvId[] = ['sRGB', 'HSL', 'CIELAB', 'CIELCh', 'OKLab', 'OKLCh', 'Display P3', 'Rec.2020']
const REFS: { id: ConversionEntry['reference']; label: string }[] = [
  { id: 'display-referred', label: 'Display-referred' }, { id: 'scene-referred', label: 'Scene-referred' }, { id: 'working-space', label: 'Working-space' },
  { id: 'output-referred', label: 'Output-referred' }, { id: 'approximate-cmyk-preview', label: 'Approximate CMYK preview' },
]

export default function ConversionPage() {
  const { project, mutate, toast } = useApp()
  const rec = usePickerRecord()
  const [to, setTo] = useState<ConvId>('OKLCh')
  const [reference, setReference] = useState<ConversionEntry['reference']>('display-referred')

  const output = useMemo(() => {
    switch (to) {
      case 'sRGB': return cssRgb(rec); case 'HSL': return cssHsl(rec); case 'CIELAB': return cssLab(rec); case 'CIELCh': return cssLch(rec)
      case 'OKLab': return cssOklab(rec); case 'OKLCh': return cssOklch(rec); case 'Display P3': return cssP3(rec); case 'Rec.2020': return cssRec2020(rec)
    }
  }, [rec, to])

  const record = () => {
    const entry: ConversionEntry = { id: newId('cv'), at: isoNow(), input: rec.hex, from: 'sRGB (encoded)', to, output, reference, note: rec.name }
    mutate('Record conversion', (p) => ({ ...p, conversionHistory: [entry, ...p.conversionHistory].slice(0, 300) }))
    toast('ok', 'Conversion recorded in history')
  }

  return (
    <div className="page">
      <ToolbarPortal>
        <Select ariaLabel="Target space" value={to} onChange={setTo} options={TARGETS.map((t) => ({ id: t, label: t }))} />
        <Select ariaLabel="Reference" value={reference} onChange={setReference} options={REFS.map((r) => ({ id: r.id, label: r.label }))} />
        <Btn size="sm" kind="primary" onClick={record}>Record conversion</Btn>
      </ToolbarPortal>
      <InspectorPortal>
        <div className="col" style={{ padding: 10 }}>
          <Notice kind="info" title="Reference categories">Distinguish <b>display-referred</b> (what you see), <b>scene-referred</b> (light captured by a sensor), <b>working-space</b> (internal editing space), <b>output-referred</b> (final deliverable), and <b>approximate CMYK preview</b> (not colour-managed).</Notice>
          <Panel title="History"><Kv rows={[['Entries', String(project.conversionHistory.length)]]} /></Panel>
        </div>
      </InspectorPortal>
      <div className="split">
        <Panel title="Convert">
          <div className="row"><Swatch hex={rec.hex} size={44} /><div><div className="mono">{rec.hex.toUpperCase()}</div><div className="small faint">from the colour picker</div></div></div>
          <div className="row"><code className="mono grow small">{output}</code><CopyBtn text={output} /></div>
        </Panel>
        <Panel title={`Conversion history · ${project.conversionHistory.length}`}>
          <table className="tbl">
            <thead><tr><th>When</th><th>Input</th><th>→</th><th>Output</th><th>Reference</th></tr></thead>
            <tbody>
              {project.conversionHistory.slice(0, 60).map((c) => (
                <tr key={c.id}><td className="small faint">{shortDate(c.at)}</td><td><span className="row" style={{ gap: 4 }}><Swatch hex={c.input.startsWith('#') ? c.input : '#888'} size={14} />{c.input}</span></td><td className="small">{c.to}</td><td className="mono small">{c.output}</td><td className="small faint">{c.reference}</td></tr>
              ))}
            </tbody>
          </table>
        </Panel>
      </div>
    </div>
  )
}
