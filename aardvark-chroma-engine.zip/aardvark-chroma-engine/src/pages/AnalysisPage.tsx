import { useEffect, useState } from 'react'
import { useApp } from '../state/store'
import { useInspect } from '../state/lab'
import { ToolbarPortal, InspectorPortal } from '../components/shell/Slots'
import { Panel, Select, Seg, Kv, Swatch, Notice, Btn } from '../components/common/ui'
import { HistogramChart, BarChart } from '../components/charts/charts'
import { useAssetImage } from '../hooks/useAssetImage'
import { runInWorker } from '../workers/client'
import type { TaskResult } from '../core/image/tasks'
import type { AnalysisResult } from '../core/image/analysis'
import { fmt } from '../utils/format'
import { makeRecord } from '../core/colour/colour-model'

export default function AnalysisPage() {
  const { project, saveSample } = useApp()
  const roi = useInspect((s) => s.roi)
  const setRoi = useInspect((s) => s.setRoi)
  const images = project.assets.filter((a) => a.kind === 'image')
  const asset = images.find((a) => a.id === project.activeAssetId) ?? images[0]
  const src = useAssetImage(asset)
  const [grid, setGrid] = useState<'3' | '5' | 'custom'>('3')
  const [result, setResult] = useState<AnalysisResult | null>(null)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    if (!src.key) return
    setBusy(true)
    const cols = grid === '5' ? 5 : 3, rows = grid === '5' ? 5 : 3
    runInWorker<Extract<TaskResult, { op: 'analyse' }>>({ op: 'analyse', key: src.key, opts: { cols, rows, roi: roi ?? null } }, 'analyse')
      .then((r) => setResult(r.result)).finally(() => setBusy(false))
  }, [src.key, grid, roi])

  if (!asset) return <div className="page"><Notice kind="warn">No image asset available.</Notice></div>

  return (
    <div className="page">
      <ToolbarPortal>
        <Select ariaLabel="Active asset" value={asset.id} onChange={() => {}} options={images.map((a) => ({ id: a.id, label: a.name }))} title="Change active asset from Image Lab" />
        <Seg label="Regions" options={[{ id: '3', label: '3×3' }, { id: '5', label: '5×5' }]} value={grid === 'custom' ? '3' : grid} onChange={setGrid} />
        {roi && <Btn size="sm" kind="ghost" onClick={() => setRoi(null)}>Clear region of interest</Btn>}
        {busy && <span className="small muted">Analysing…</span>}
      </ToolbarPortal>
      <InspectorPortal>
        <div className="col" style={{ padding: 10 }}>
          <Panel title="Summary">
            {result && (
              <Kv rows={[
                ['Analysed at', `${result.width} × ${result.height} px`], ['Average', <span key="a" className="row"><Swatch hex={result.averageHex} size={16} />{result.averageHex.toUpperCase()}</span>],
                ['Contrast (RMS)', fmt(result.contrastRms, 3)], ['Contrast (p95−p05)', fmt(result.contrastPercentile, 3)],
                ['Shadow clip', `${fmt(result.shadowClipPct, 2)}%`], ['Highlight clip', `${fmt(result.highlightClipPct, 2)}%`],
                ['Edge density', `${fmt(result.edgeDensityPct, 2)}%`], ['Entropy', `${fmt(result.entropyBits, 2)} bits`],
                ['Dynamic range', `${fmt(result.dynamicRangeStops, 2)} stops`], ['CCT estimate', result.cctEstimate ? `${Math.round(result.cctEstimate)} K` : '—'],
                ['Time', `${result.ms} ms`],
              ]} />
            )}
            {result?.cctEstimate && <div className="small faint">{result.cctNote}</div>}
          </Panel>
          {roi && <Notice kind="info">Analysing region of interest {roi.w}×{roi.h} px. Set with the Crop tool in Image Lab.</Notice>}
        </div>
      </InspectorPortal>
      <div className="split wide">
        <div className="col">
          <Panel title="Histogram"><HistogramChart hist={result?.histograms ?? null} mode="rgb" /></Panel>
          <Panel title="Dominant colours (OKLab k-means)">
            <div className="row wrap">{result?.dominant.map((d, i) => (
              <div key={i} className="col" style={{ alignItems: 'center', gap: 3 }}>
                <Swatch hex={d.hex} size={44} title={`${d.hex} · ${fmt(d.fraction * 100, 1)}%`} onClick={() => saveSample(makeRecord({ linear: d.linear, name: `Dominant colour ${i + 1}`, source: 'analysis:dominant' }), `${fmt(d.fraction * 100, 1)}% of pixels (OKLab k-means)`)} />
                <span className="small faint">{fmt(d.fraction * 100, 0)}%</span>
              </div>
            ))}</div>
          </Panel>
          <Panel title="Saturation distribution"><BarChart values={result?.saturationDistribution ?? []} colour="#4fb39b" format={(v) => `${fmt(v * 100, 1)}%`} /><div className="small faint">10 bins, HSV saturation 0 → 1</div></Panel>
          <Panel title="Brightness zones (L* deciles)"><BarChart values={result?.brightnessZones ?? []} colour="#e0a11a" format={(v) => `${fmt(v * 100, 1)}%`} /></Panel>
        </div>
        <div className="col">
          <Panel title="Region grid">
            <table className="tbl">
              <thead><tr><th>Row/Col</th><th>Mean</th><th className="r">L*</th><th className="r">C*</th><th>Hue</th><th className="r">Adj. ΔE00</th></tr></thead>
              <tbody>
                {result?.regions.map((r, i) => (
                  <tr key={i}><td>{r.row},{r.col}</td><td><span className="row" style={{ gap: 4 }}><Swatch hex={r.meanHex} size={14} />{r.meanHex.toUpperCase()}</span></td>
                    <td className="r">{fmt(r.luminance * 100, 1)}</td><td className="r">{fmt(r.chroma, 1)}</td><td>{r.dominantHue !== null ? `${Math.round(r.dominantHue)}°` : 'neutral'}</td><td className="r">{fmt(r.contrastAdjacent, 2)}</td></tr>
                ))}
              </tbody>
            </table>
          </Panel>
        </div>
      </div>
    </div>
  )
}
