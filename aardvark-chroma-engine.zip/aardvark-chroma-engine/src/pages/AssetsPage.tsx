import { useRef, useState } from 'react'
import { Upload, Trash2 } from 'lucide-react'
import { useApp } from '../state/store'
import { ToolbarPortal } from '../components/shell/Slots'
import { Panel, Btn, Notice, Kv } from '../components/common/ui'
import { PixelCanvas } from '../components/common/ui'
import { useAssetImage } from '../hooks/useAssetImage'
import { importImageFile } from '../utils/importImage'
import type { AssetMeta } from '../types/project'
import { VARIANT_DESCRIPTION } from '../core/image/variants'

function AssetThumb({ asset }: { asset: AssetMeta }) {
  const { image } = useAssetImage(asset.kind === 'image' ? asset : undefined)
  if (asset.kind !== 'image') return <div style={{ height: 100, display: 'grid', placeItems: 'center', background: 'var(--k-900)' }} className="faint small">Document</div>
  return image ? <PixelCanvas image={image} width="100%" height={100} style={{ objectFit: 'cover' }} /> : <div style={{ height: 100 }} className="skeleton" />
}

export default function AssetsPage() {
  const { project, mutate, toast, setPage } = useApp()
  const [dropping, setDropping] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)
  const [openDoc, setOpenDoc] = useState<string | null>(null)

  const importFiles = async (files: FileList | File[]) => {
    for (const f of Array.from(files)) {
      const r = await importImageFile(f)
      if (r.error) { toast('error', r.error); continue }
      if (r.asset) { const a = r.asset; mutate(`Import ${a.name}`, (p) => ({ ...p, assets: [...p.assets, a] })); toast('ok', `Imported ${a.name}`); if (r.note) toast('warn', r.note) }
    }
  }
  const remove = (id: string) => {
    if (project.assets.length <= 1) { toast('warn', 'Cannot remove the only asset'); return }
    mutate('Remove asset', (p) => ({ ...p, assets: p.assets.filter((a) => a.id !== id), activeAssetId: p.activeAssetId === id ? p.assets.find((a) => a.id !== id)!.id : p.activeAssetId }))
  }
  const doc = project.assets.find((a) => a.id === openDoc)

  return (
    <div className={`page ${dropping ? 'dragging' : ''}`} onDragOver={(e) => { e.preventDefault(); setDropping(true) }} onDragLeave={() => setDropping(false)}
      onDrop={(e) => { e.preventDefault(); setDropping(false); void importFiles(e.dataTransfer.files) }}>
      <ToolbarPortal>
        <Btn size="sm" onClick={() => fileRef.current?.click()}><Upload size={13} /> Import images</Btn>
        <input ref={fileRef} type="file" accept="image/*" multiple hidden onChange={(e) => { if (e.target.files) void importFiles(e.target.files); e.target.value = '' }} />
      </ToolbarPortal>
      {doc && (doc.kind === 'report' || doc.kind === 'sheet') ? (
        <Panel title={doc.name} actions={<Btn size="sm" kind="ghost" onClick={() => setOpenDoc(null)}>Back to library</Btn>}>
          <div className="doc" style={{ maxWidth: 760 }} dangerouslySetInnerHTML={{ __html: mdToHtml(doc.body ?? '') }} />
        </Panel>
      ) : (
        <>
          <Notice kind="info">Drop image files anywhere on this page to import them. Imports stay local to your browser's storage.</Notice>
          <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fill,minmax(220px,1fr))' }}>
            {project.assets.map((a) => (
              <Panel key={a.id} title={a.name} actions={<Btn icon size="sm" kind="ghost" title="Remove asset" onClick={() => remove(a.id)}><Trash2 size={13} /></Btn>}>
                <div style={{ cursor: a.kind === 'image' ? 'pointer' : 'default' }} onClick={() => { if (a.kind === 'image') mutate('Set active asset', (p) => ({ ...p, activeAssetId: a.id }), { silent: true }); if (a.kind !== 'image') setOpenDoc(a.id) }}>
                  <AssetThumb asset={a} />
                </div>
                <Kv rows={[['Role', a.role], ['Kind', a.kind], a.kind === 'image' ? ['Size', `${a.width} × ${a.height} px`] : ['—', ''], ['Colour space', a.colourSpace]]} />
                {a.notes && <div className="small faint">{a.notes}</div>}
                {a.generator && VARIANT_DESCRIPTION[a.generator.variant] && <div className="small faint">{VARIANT_DESCRIPTION[a.generator.variant]}</div>}
                {a.kind === 'image' && <Btn size="sm" onClick={() => { mutate('Set active asset', (p) => ({ ...p, activeAssetId: a.id }), { silent: true }); setPage('image-lab') }}>Open in Image Lab</Btn>}
                {a.kind !== 'image' && <Btn size="sm" onClick={() => setOpenDoc(a.id)}>Open document</Btn>}
              </Panel>
            ))}
          </div>
        </>
      )}
    </div>
  )
}

function mdToHtml(md: string): string {
  const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  const lines = md.split('\n')
  let html = '', inTable = false, inList = false
  for (const raw of lines) {
    const line = raw
    if (/^\|/.test(line)) {
      if (!inTable) { html += '<table><tbody>'; inTable = true }
      if (/^\|[\s-:|]+\|$/.test(line)) continue
      const cells = line.split('|').slice(1, -1).map((c) => c.trim())
      html += '<tr>' + cells.map((c) => `<td>${esc(c)}</td>`).join('') + '</tr>'
      continue
    }
    if (inTable) { html += '</tbody></table>'; inTable = false }
    if (/^-\s/.test(line)) { if (!inList) { html += '<ul>'; inList = true } html += `<li>${esc(line.slice(2))}</li>`; continue }
    if (inList) { html += '</ul>'; inList = false }
    if (/^# /.test(line)) html += `<h1>${esc(line.slice(2))}</h1>`
    else if (/^## /.test(line)) html += `<h2>${esc(line.slice(3))}</h2>`
    else if (/^> /.test(line)) html += `<blockquote>${esc(line.slice(2))}</blockquote>`
    else if (line.trim() === '') html += ''
    else html += `<p>${esc(line).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>')}</p>`
  }
  if (inTable) html += '</tbody></table>'
  if (inList) html += '</ul>'
  return html
}
