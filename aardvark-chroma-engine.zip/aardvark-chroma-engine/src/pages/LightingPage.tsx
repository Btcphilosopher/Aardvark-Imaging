import { useMemo, useState } from 'react'
import { useApp } from '../state/store'
import { ToolbarPortal, InspectorPortal } from '../components/shell/Slots'
import { Panel, Slider, Select, Notice, Kv, PixelCanvas } from '../components/common/ui'
import { LIGHT_PRESETS, defaultLighting, shadeSphere, type LightingSetup } from '../core/lighting/lighting'
import { MATERIALS } from '../core/materials/materials'
import { hexRecord } from '../core/colour/colour-model'

export default function LightingPage() {
  const toast = useApp((s) => s.toast)
  const [L, setL] = useState<LightingSetup>(defaultLighting())
  const [matId, setMatId] = useState(MATERIALS[2].id)
  const mat = MATERIALS.find((m) => m.id === matId) ?? MATERIALS[0]
  const albedo = useMemo(() => hexRecord(mat.baseHex, mat.name).linearRgb, [mat])
  const img = useMemo(() => shadeSphere(360, { albedo, roughness: mat.roughness, metallic: mat.metallic, reflectance: mat.reflectance }, L), [albedo, mat, L])
  const set = (patch: Partial<LightingSetup>) => setL((s) => ({ ...s, ...patch }))

  return (
    <div className="page">
      <ToolbarPortal>
        <Select ariaLabel="Preset" value="" onChange={(id) => { const p = LIGHT_PRESETS.find((x) => x.id === id); if (p) { setL((s) => ({ ...s, ...p.setup })); toast('info', p.note) } }} options={[{ id: '', label: 'Preset…' }, ...LIGHT_PRESETS.map((p) => ({ id: p.id, label: p.name }))]} />
        <Select ariaLabel="Material" value={matId} onChange={setMatId} options={MATERIALS.map((m) => ({ id: m.id, label: m.name }))} />
      </ToolbarPortal>
      <InspectorPortal>
        <div className="col" style={{ padding: 10 }}>
          <Panel title="Light">
            <Slider label="Colour temp" value={L.kelvin} min={1667} max={12000} step={10} decimals={0} defaultValue={5600} onChange={(v) => set({ kelvin: v })} format={(v) => `${Math.round(v)} K`} />
            <Slider label="Tint" value={L.tint} min={-1} max={1} step={0.01} defaultValue={0} onChange={(v) => set({ tint: v })} />
            <Slider label="Intensity" value={L.intensity} min={0} max={2} step={0.01} defaultValue={1} onChange={(v) => set({ intensity: v })} />
            <Slider label="Key azimuth" value={L.keyAzimuth} min={0} max={360} step={1} decimals={0} defaultValue={135} onChange={(v) => set({ keyAzimuth: v })} format={(v) => `${Math.round(v)}°`} />
            <Slider label="Key elevation" value={L.keyElevation} min={0} max={90} step={1} decimals={0} defaultValue={45} onChange={(v) => set({ keyElevation: v })} format={(v) => `${Math.round(v)}°`} />
            <Slider label="Fill" value={L.fill} min={0} max={1} step={0.01} defaultValue={0.25} onChange={(v) => set({ fill: v })} />
            <Slider label="Ambient" value={L.ambient} min={0} max={1} step={0.01} defaultValue={0.12} onChange={(v) => set({ ambient: v })} />
            <Slider label="Adaptation" value={L.adaptation} min={0} max={1} step={0.01} defaultValue={0} onChange={(v) => set({ adaptation: v })} title="0 = full colour cast shown; 1 = fully colour-adapted (cast removed)" />
            <Slider label="Shadow depth" value={L.shadowDepth} min={0} max={1} step={0.01} defaultValue={0.6} onChange={(v) => set({ shadowDepth: v })} />
            <Slider label="Specular" value={L.specular} min={0} max={2} step={0.01} defaultValue={1} onChange={(v) => set({ specular: v })} />
            <Slider label="Exposure" value={L.exposure} min={-3} max={3} step={0.02} defaultValue={0} onChange={(v) => set({ exposure: v })} />
            <Slider label="Contrast" value={L.contrast} min={-1} max={1} step={0.01} defaultValue={0} onChange={(v) => set({ contrast: v })} />
          </Panel>
          <Panel title="Material">
            <Kv rows={[['Roughness', mat.roughness.toFixed(2)], ['Metallic', mat.metallic.toFixed(2)], ['Reflectance', mat.reflectance.toFixed(2)]]} />
          </Panel>
        </div>
      </InspectorPortal>
      <div className="split">
        <Panel title="Lit sphere study" bodyClass="col" >
          <PixelCanvas image={img} width={Math.min(480, img.width)} label="Lit sphere" />
          <Notice kind="approx" title="Approximation">Lambert + Blinn–Phong shading with a Planckian-locus illuminant. Not a physically based renderer.</Notice>
        </Panel>
        <Panel title="Comparison grid">
          <div className="row wrap">
            {LIGHT_PRESETS.map((p) => {
              const setup = { ...defaultLighting(), ...p.setup }
              const thumb = shadeSphere(96, { albedo, roughness: mat.roughness, metallic: mat.metallic, reflectance: mat.reflectance }, setup)
              return <div key={p.id} className="col" style={{ alignItems: 'center', gap: 3, width: 100 }}><PixelCanvas image={thumb} width={92} /><span className="small faint" style={{ textAlign: 'center' }}>{p.name}</span></div>
            })}
          </div>
        </Panel>
      </div>
    </div>
  )
}
