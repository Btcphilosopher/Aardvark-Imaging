import { useMemo, useState, useCallback } from 'react'
import { ZoomIn, ZoomOut, Maximize2, Upload } from 'lucide-react'
import { useApp } from '../state/store'
import { useLab, useInspect } from '../state/lab'
import { useViewerBus } from '../state/ui-slots'
import { ToolbarPortal, InspectorPortal } from '../components/shell/Slots'
import { ToolStrip } from '../components/toolbars/ToolStrip'
import { ImageViewer } from '../components/image-viewer/ImageViewer'
import { PixelReadout, Loupe } from '../components/inspectors/PixelReadout'
import { HistogramChart } from '../components/charts/charts'
import { Btn, Panel, Select, Slider, Check2, Notice, Empty, Kv, Badge, Seg } from '../components/common/ui'
import { useLabRenderParams } from '../hooks/useRenderParams'
import { computeHistograms } from '../core/image/histograms'
import { VIEW_MODES, defaultRender, type RenderStats } from '../core/image/image-processing'
import { importImageFile } from '../utils/importImage'
import { PRODUCTION_PROFILES } from '../core/print/print'
import { fmt } from '../utils/format'
import { deltaE2000Linear } from '../core/colour/contrast'
import { samplePixel } from '../core/image/sampling'

export default function ImageLabPage() {
  const project = useApp((s) => s.project)
  const mutate = useApp((s) => s.mutate)
  const toast = useApp((s) => s.toast)
  const lab = useLab()
  const inspect = useInspect()
  const bus = useViewerBus.getState()
  const { params, depsKey } = useLabRenderParams()
  const [stats, setStats] = useState<RenderStats | null>(null)
  const [dropping, setDropping] = useState(false)
  const images = project.assets.filter((a) => a.kind === 'image')
  const asset = images.find((a) => a.id === project.activeAssetId) ?? images[0]
  const beforeAsset = lab.beforeAssetId === 'self' ? undefined : images.find((a) => a.id === lab.beforeAssetId)
  const displayHist = useMemo(() => (inspect.displayImage ? computeHistograms(inspect.displayImage) : null), [inspect.displayImage])
  const onStats = useCallback((s: RenderStats | null) => setStats(s), [])

  const importFiles = async (files: FileList | File[]) => {
    for (const f of Array.from(files)) {
      const r = await importImageFile(f)
      if (r.error) { toast('error', r.error); continue }
      if (r.asset) { const a = r.asset; mutate(`Import ${a.name}`, (p) => ({ ...p, assets: [...p.assets, a], activeAssetId: a.id })); toast('ok', `Imported ${a.name} (${a.width}×${a.height})`); if (r.note) toast('warn', r.note) }
    }
  }

  if (!asset) return <div className="page"><Empty title="No image assets">This project has no images. Import one from the Asset Library or drop a file here.</Empty></div>

  const compareBefore = lab.compare !== 'off'
    ? { mode: lab.compare, beforeAsset, beforeParams: beforeAsset ? { ...defaultRender() } : { ...defaultRender(), grade: null, lut: null, proof: null }, wipe: lab.wipe }
    : { mode: 'off' as const, wipe: lab.wipe }

  return (
    <div className={`page fill ${dropping ? 'dragging' : ''}`} style={{ display: 'grid', gridTemplateColumns: 'auto minmax(0,1fr)', height: '100%' }}
      onDragOver={(e) => { e.preventDefault(); setDropping(true) }} onDragLeave={() => setDropping(false)}
      onDrop={(e) => { e.preventDefault(); setDropping(false); void importFiles(e.dataTransfer.files) }}>
      <ToolbarPortal>
        <Select ariaLabel="Active asset" value={asset.id} onChange={(id) => mutate('Change active asset', (p) => ({ ...p, activeAssetId: id }), { silent: true })} options={images.map((a) => ({ id: a.id, label: `${a.role} · ${a.name}` }))} />
        <Btn icon size="sm" title="Zoom out" onClick={() => bus.send('zoomOut')}><ZoomOut size={14} /></Btn>
        <Btn size="sm" onClick={() => bus.send('fit')} title="Fit to screen (F)"><Maximize2 size={13} /> Fit</Btn>
        <Btn size="sm" onClick={() => bus.send('zoom100')} title="100 % (1)">100%</Btn>
        <Btn size="sm" onClick={() => bus.send('zoom200')} title="200 % (2)">200%</Btn>
        <Btn size="sm" onClick={() => bus.send('zoom400')} title="400 % (4)">400%</Btn>
        <Btn icon size="sm" title="Zoom in" onClick={() => bus.send('zoomIn')}><ZoomIn size={14} /></Btn>
        <Check2 checked={lab.pixelGrid} onChange={(v) => lab.set({ pixelGrid: v })} title="Draw the pixel grid at ≥800 % zoom">Pixel grid</Check2>
        <label className="btn sm" title="Import local images"><Upload size={13} /> Import<input type="file" accept="image/*" multiple hidden onChange={(e) => { if (e.target.files) void importFiles(e.target.files); e.target.value = '' }} /></label>
      </ToolbarPortal>
      <ToolStrip />
      <ImageViewer asset={asset} params={params} depsKey={depsKey} compare={compareBefore} pixelGrid={lab.pixelGrid} histogramOverlay={lab.histogramOverlay} sampleSource={lab.sampleSource} onWipe={(v) => lab.set({ wipe: v })} onStats={onStats} />
      <InspectorPortal>
        <div className="col" style={{ padding: 10 }}>
          <Panel title="Pixel">
            <PixelReadout />
            <Loupe />
            <Seg label="Sample from" options={[{ id: 'source', label: 'Source pixels', title: 'Read the asset pixels before preview processing' }, { id: 'displayed', label: 'Displayed', title: 'Read the processed image as displayed' }]} value={lab.sampleSource} onChange={(v) => lab.set({ sampleSource: v })} />
          </Panel>
          <Panel title="View">
            <Select ariaLabel="View mode" value={lab.view} onChange={(v) => lab.set({ view: v })} options={VIEW_MODES.map((m) => ({ id: m.id, label: m.label }))} title="View mode" />
            <div className="small faint">{VIEW_MODES.find((m) => m.id === lab.view)?.note}</div>
            <Slider label="Exposure" value={lab.exposure} min={-4} max={4} step={0.05} decimals={2} defaultValue={0} onChange={(v) => lab.set({ exposure: v })} title="View-only exposure preview in stops. Not applied to the grade." format={(v) => `${v >= 0 ? '+' : ''}${fmt(v, 2)} EV`} />
            <Slider label="Saturation" value={lab.saturation} min={0} max={2} step={0.01} defaultValue={1} onChange={(v) => lab.set({ saturation: v })} title="View-only saturation preview about linear luma." />
            <Check2 checked={lab.applyGrade} onChange={(v) => lab.set({ applyGrade: v })} title="Apply the Grading Desk correction to the view">Apply grade</Check2>
            <Check2 checked={lab.applyLut} onChange={(v) => lab.set({ applyLut: v })} title="Apply the LUT Lab look to the view">Apply LUT ({project.lut.presetId})</Check2>
            <Check2 checked={lab.proofOn} onChange={(v) => lab.set({ proofOn: v })} title="Approximate print proof">Proof view ({PRODUCTION_PROFILES.find((p) => p.id === project.production.profileId)?.name})</Check2>
            {lab.proofOn && <Notice kind="approx" title="Approximation">Proof view uses synthetic profile parameters, not a certified ICC proof.</Notice>}
          </Panel>
          <Panel title="Compare">
            <Seg label="Compare mode" options={[{ id: 'off', label: 'Off' }, { id: 'split', label: 'Split' }, { id: 'wipe', label: 'Wipe' }, { id: 'difference', label: 'Diff' }]} value={lab.compare} onChange={(v) => lab.set({ compare: v })} />
            {lab.compare !== 'off' && (
              <>
                <Select ariaLabel="Before image" value={lab.beforeAssetId} onChange={(v) => lab.set({ beforeAssetId: v })} options={[{ id: 'self', label: 'Before = this asset, unprocessed' }, ...images.filter((a) => a.id !== asset.id).map((a) => ({ id: a.id, label: `Before = ${a.name}` }))]} />
                {(lab.compare === 'wipe' || lab.compare === 'split') && <Slider label="Divider" value={lab.wipe} min={0} max={1} step={0.005} defaultValue={0.5} onChange={(v) => lab.set({ wipe: v })} format={(v) => `${Math.round(v * 100)}%`} />}
                {lab.compare === 'difference' && <div className="small faint">Absolute per-channel difference, amplified ×6. Black = identical.</div>}
              </>
            )}
          </Panel>
          <Panel title="Histogram">
            <HistogramChart hist={displayHist} mode="rgb" />
            {stats && (
              <Kv rows={[
                ['Highlights', <Badge key="h" kind={stats.highlightClipPct > 1 ? 'warn' : 'ok'}>{fmt(stats.highlightClipPct, 2)}% ≥253</Badge>],
                ['Shadows', <Badge key="s" kind={stats.shadowClipPct > 1 ? 'warn' : 'ok'}>{fmt(stats.shadowClipPct, 2)}% ≤2</Badge>],
                ['Gamut flag', <Badge key="g" kind={stats.gamutFlaggedPct > 0.5 ? 'warn' : 'ok'}>{fmt(stats.gamutFlaggedPct, 2)}% outside</Badge>],
                ['Render', `${stats.ms} ms`],
              ]} />
            )}
            <div className="legend"><span><i style={{ background: '#ef5a4e' }} />clip ≥253</span><span><i style={{ background: '#7c9cc0' }} />clip ≤2</span></div>
          </Panel>
          <Panel title={`Annotations & measurements · ${project.annotations.filter((a) => a.assetId === asset.id).length + project.measurements.filter((m) => m.assetId === asset.id).length}`}>
            {project.measurements.filter((m) => m.assetId === asset.id).map((m) => {
              const im = inspect.sourceImage
              const a = im ? samplePixel(im, m.a.x, m.a.y) : null, b = im ? samplePixel(im, m.b.x, m.b.y) : null
              const de = a && b ? deltaE2000Linear(a.record.linearRgb, b.record.linearRgb) : null
              return (
                <div key={m.id} className="row small" style={{ gap: 6 }}>
                  <span className="grow">{fmt(Math.hypot(m.b.x - m.a.x, m.b.y - m.a.y), 1)} px{de !== null ? ` · ΔE00 ${fmt(de, 2)}` : ''}<span className="faint"> {m.note && !m.note.startsWith('ΔE') ? `· ${m.note}` : ''}</span></span>
                  <Btn size="sm" kind="ghost" title="Delete measurement" onClick={() => mutate('Delete measurement', (p) => ({ ...p, measurements: p.measurements.filter((x) => x.id !== m.id) }))}>✕</Btn>
                </div>
              )
            })}
            {project.annotations.filter((a) => a.assetId === asset.id).map((a) => (
              <div key={a.id} className="row small" style={{ gap: 6 }}>
                <span className="grow">▲ {a.text}</span>
                <Btn size="sm" kind="ghost" title="Delete annotation" onClick={() => mutate('Delete annotation', (p) => ({ ...p, annotations: p.annotations.filter((x) => x.id !== a.id) }))}>✕</Btn>
              </div>
            ))}
            {project.annotations.filter((a) => a.assetId === asset.id).length + project.measurements.filter((m) => m.assetId === asset.id).length === 0 && <span className="small muted">Use the Measure and Annotate tools (M, A).</span>}
          </Panel>
        </div>
      </InspectorPortal>
    </div>
  )
}
