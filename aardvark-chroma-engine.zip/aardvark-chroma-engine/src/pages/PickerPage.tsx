import { useRef } from 'react'
import { Save } from 'lucide-react'
import { useApp, usePickerRecord } from '../state/store'
import { PICKER_SPACES, PICKER_CHANNELS, toDisplayScale, fromDisplayScale, makeRecord } from '../core/colour/colour-model'
import { srgbToLinear, hslToRgb, clamp01 } from '../core/colour/conversions'
import { ToolbarPortal } from '../components/shell/Slots'
import { Panel, Seg, NumInput, Swatch, HexInput, Btn, CopyBtn, GamutBadge, Notice, ColourChip } from '../components/common/ui'
import { SpaceTable } from '../components/colour-controls/SpaceTable'
import { mapToGamutOklch } from '../core/colour/gamut'
import { tonalScale, materialVariations } from '../core/colour/harmony'
import { cssRgb, cssHsl, cssOklch, cssLab, fmt } from '../utils/format'
import { deltaE2000Linear } from '../core/colour/contrast'

function hueRing(cx: number, cy: number, r: number, thickness: number) {
  const stops = Array.from({ length: 13 }, (_, i) => `hsl(${i * 30} 100% 50%)`).join(',')
  return { background: `conic-gradient(${stops})`, borderRadius: '50%', width: r * 2, height: r * 2 }
  void cx; void cy; void thickness
}

function SLField({ h, s, l, onChange }: { h: number; s: number; l: number; onChange: (s: number, l: number) => void }) {
  const ref = useRef<HTMLDivElement>(null)
  const drag = (e: React.PointerEvent) => {
    const r = ref.current!.getBoundingClientRect()
    const x = clamp01((e.clientX - r.left) / r.width), y = clamp01((e.clientY - r.top) / r.height)
    onChange(x, 1 - y)
  }
  return (
    <div ref={ref} className="pfield" role="slider" tabIndex={0} aria-label="Saturation and lightness" aria-valuetext={`S ${Math.round(s * 100)}% L ${Math.round(l * 100)}%`}
      style={{ width: '100%', aspectRatio: '1.6', background: `linear-gradient(to top, #000, transparent 50%, #fff), linear-gradient(to right, #808080, hsl(${h} 100% 50%))` }}
      onPointerDown={(e) => { (e.target as HTMLElement).setPointerCapture(e.pointerId); drag(e) }} onPointerMove={(e) => { if (e.buttons) drag(e) }}>
      <span className="knob" style={{ left: `${s * 100}%`, top: `${(1 - l) * 100}%`, background: `hsl(${h} ${s * 100}% ${l * 100}%)` }} />
    </div>
  )
}

export default function PickerPage() {
  const { picker, setPickerSpace, setPickerValues, setPickerLinear, setPickerAlpha, commitPickerHistory, pickerHistory, saveSample, compareWith, setCompareWith } = useApp()
  const rec = usePickerRecord()
  const chans = PICKER_CHANNELS[picker.space]

  const setChannel = (i: number, display: number) => {
    const v = [...picker.values] as typeof picker.values
    v[i] = fromDisplayScale(picker.space, i, display)
    setPickerValues(v)
  }
  const commit = () => commitPickerHistory()

  const outOfSrgb = !rec.gamutStatus.srgb
  return (
    <div className="page">
      <ToolbarPortal>
        <Seg options={PICKER_SPACES.map((s) => ({ id: s, label: s.toUpperCase() }))} value={picker.space} onChange={setPickerSpace} label="Picker space" />
        <span className="sep" />
        <Btn size="sm" onClick={() => saveSample(makeRecord({ linear: picker.linear, alpha: picker.alpha, name: undefined, source: 'picker' }))}><Save size={13} /> Save sample</Btn>
        <CopyBtn text={rec.hex.toUpperCase()} label="Copy hex" />
        <CopyBtn text={JSON.stringify(rec, null, 2)} label="Copy JSON" />
      </ToolbarPortal>
      <div className="split wide">
        <div className="col">
          <Panel title="Colour field">
            <div className="row" style={{ alignItems: 'flex-start', gap: 16 }}>
              <div style={{ flex: 1, minWidth: 220 }}>
                <SLField h={rec.hsl.h} s={rec.hsl.s} l={rec.hsl.l} onChange={(s, l) => { setPickerLinear(srgbToLinear({ ...require_hsl(rec.hsl.h, s, l) })) }} />
                <div className="row" style={{ marginTop: 8 }}>
                  <div style={{ flex: 1, height: 16, borderRadius: 8, position: 'relative' }}>
                    <div style={hueRing(0, 0, 0, 0)} />
                  </div>
                </div>
                <HueBar h={rec.hsl.h} onChange={(h) => setPickerLinear(srgbToLinear(require_hsl(h, rec.hsl.s || 0.6, rec.hsl.l)))} onCommit={commit} />
                <div className="row" style={{ marginTop: 8, alignItems: 'center', gap: 10 }}>
                  <Swatch hex={rec.hex} alpha={picker.alpha} size={44} />
                  <div className="grow"><HexInput hex={rec.hex} onChange={(l, a) => { setPickerLinear(l, a, true) }} label="Hex or CSS colour" /></div>
                </div>
                <div className="field" style={{ marginTop: 8 }}>
                  <span className="label">Alpha</span>
                  <input type="range" min={0} max={1} step={0.001} value={picker.alpha} onChange={(e) => setPickerAlpha(parseFloat(e.target.value))} onPointerUp={commit} aria-label="Alpha" />
                </div>
              </div>
              <div style={{ flex: 1, minWidth: 220 }}>
                <div className="grid" style={{ gridTemplateColumns: '1fr', gap: 6 }}>
                  {chans.map((c, i) => (
                    <div key={c.key} className="row">
                      <span className="label" style={{ width: 20 }}>{c.label}</span>
                      <input type="range" className="grow" min={toDisplayScale(picker.space, i, c.min === -160 ? -0.5 : picker.space === 'lab' || picker.space === 'lch' ? c.min : c.min)}
                        max={toDisplayScale(picker.space, i, c.max)} step={c.step} value={toDisplayScale(picker.space, i, picker.values[i])}
                        onChange={(e) => setChannel(i, parseFloat(e.target.value))} onPointerUp={commit} aria-label={c.label} />
                      <div style={{ width: 74 }}><NumInput value={toDisplayScale(picker.space, i, picker.values[i])} onChange={(v) => { setChannel(i, v); commit() }} decimals={c.decimals} min={toDisplayScale(picker.space, i, c.min)} max={toDisplayScale(picker.space, i, c.max)} unit={c.unit} ariaLabel={c.label} /></div>
                    </div>
                  ))}
                </div>
                {outOfSrgb && (
                  <Notice kind="warn" title="Out of gamut"><GamutBadge status={rec.gamutStatus} /> <Btn size="sm" onClick={() => setPickerLinear(mapToGamutOklch(picker.linear, 'srgb'), undefined, true)}>Map to sRGB (OKLCh chroma reduction)</Btn></Notice>
                )}
              </div>
            </div>
          </Panel>
          <Panel title="Copy formats">
            <div className="grid cols-2">
              {[['CSS rgb()', cssRgb(rec)], ['CSS hsl()', cssHsl(rec)], ['CSS oklch()', cssOklch(rec)], ['CSS lab()', cssLab(rec)]].map(([label, val]) => (
                <div key={label} className="row"><code className="mono grow small" style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{val}</code><CopyBtn text={val} label="Copy" /></div>
              ))}
            </div>
          </Panel>
          <Panel title="Tonal scale" actions={<CopyBtn text={() => tonalScale(rec.linearRgb).map((c) => c.hex).join(', ')} label="Copy hexes" />}>
            <div className="strip">{tonalScale(rec.linearRgb).map((c) => <div key={c.id} style={{ background: c.hex }} title={`${c.name} ${c.hex}`} />)}</div>
          </Panel>
          <Panel title="Material variations" actions={<span className="small faint">Deterministic OKLCh transforms</span>}>
            <div className="row wrap">{materialVariations(rec.linearRgb).map((c) => <div key={c.id} className="col" style={{ alignItems: 'center', gap: 3 }}><Swatch hex={c.hex} size={40} title={`${c.name} ${c.hex}`} /><span className="small faint">{c.name}</span></div>)}</div>
          </Panel>
        </div>
        <div className="col">
          <Panel title="Values"><SpaceTable rec={rec} /></Panel>
          <Panel title="Compare" actions={compareWith && <Btn size="sm" kind="ghost" onClick={() => setCompareWith(null)}>Clear</Btn>}>
            {compareWith ? (
              <div className="col">
                <div className="row"><Swatch hex={rec.hex} alpha={picker.alpha} size={36} /><Swatch hex={compareWith.hex} alpha={compareWith.alpha} size={36} /></div>
                <div className="small">ΔE2000 {fmt(deltaE2000Linear(rec.linearRgb, compareWith.linearRgb), 2)}</div>
              </div>
            ) : <span className="small muted">Save a sample, or select a palette colour, then compare here.</span>}
            <div className="row"><Btn size="sm" onClick={() => setCompareWith(rec)}>Set current as compare A</Btn></div>
          </Panel>
          <Panel title={`Colour history · ${pickerHistory.length}`}>
            {pickerHistory.length === 0 ? <span className="small muted">Colours you commit appear here.</span> : (
              <div className="row wrap">{pickerHistory.map((c, i) => <ColourChip key={i} rec={c} onClick={() => setPickerLinear(c.linearRgb, c.alpha, true)} />)}</div>
            )}
          </Panel>
        </div>
      </div>
    </div>
  )
}

function require_hsl(h: number, s: number, l: number) {
  return hslToRgb({ h, s, l })
}

function HueBar({ h, onChange, onCommit }: { h: number; onChange: (h: number) => void; onCommit: () => void }) {
  const ref = useRef<HTMLDivElement>(null)
  const drag = (e: React.PointerEvent) => { const r = ref.current!.getBoundingClientRect(); onChange(clamp01((e.clientX - r.left) / r.width) * 360) }
  return (
    <div ref={ref} role="slider" aria-label="Hue" aria-valuenow={Math.round(h)} tabIndex={0} style={{ height: 16, marginTop: 8, background: 'linear-gradient(to right, red, yellow, lime, cyan, blue, magenta, red)', position: 'relative', cursor: 'pointer' }}
      onPointerDown={(e) => { (e.target as HTMLElement).setPointerCapture(e.pointerId); drag(e) }} onPointerMove={(e) => { if (e.buttons) drag(e) }} onPointerUp={onCommit}
      onKeyDown={(e) => { if (e.key === 'ArrowLeft') { onChange((h - 1 + 360) % 360); onCommit() } if (e.key === 'ArrowRight') { onChange((h + 1) % 360); onCommit() } }}>
      <span style={{ position: 'absolute', left: `${(h / 360) * 100}%`, top: -2, width: 4, height: 20, background: '#fff', border: '1px solid #000', marginLeft: -2 }} />
    </div>
  )
}
