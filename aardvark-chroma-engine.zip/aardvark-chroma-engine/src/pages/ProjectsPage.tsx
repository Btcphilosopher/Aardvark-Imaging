import { useRef, useState } from 'react'
import { Plus, Copy, Archive, ArchiveRestore, Trash2, Upload, Download, RefreshCw } from 'lucide-react'
import { useApp } from '../state/store'
import { ToolbarPortal, InspectorPortal } from '../components/shell/Slots'
import { Btn, Panel, Notice, Kv, Badge, Empty } from '../components/common/ui'
import { shortDate, downloadText, slug } from '../utils/format'

export default function ProjectsPage() {
  const { summaries, project, createProject, duplicateProject, renameProject, archiveProject, deleteProject, importProject, restoreDemos, openProject, toast } = useApp()
  const [name, setName] = useState('')
  const [showArchived, setShowArchived] = useState(false)
  const [renaming, setRenaming] = useState<{ id: string; text: string } | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  const list = summaries.filter((s) => showArchived || !s.archived)

  const onImport = async (file: File) => {
    const text = await file.text()
    const r = await importProject(text)
    toast(r.ok ? 'ok' : 'error', r.message)
  }

  return (
    <div className="page">
      <ToolbarPortal>
        <input className="input" style={{ width: 220 }} placeholder="New project name…" value={name} onChange={(e) => setName(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && name.trim()) { void createProject(name); setName('') } }} />
        <Btn size="sm" kind="primary" onClick={() => { if (name.trim()) { void createProject(name); setName('') } }}><Plus size={13} /> Create</Btn>
        <span className="sep" />
        <Btn size="sm" onClick={() => fileRef.current?.click()}><Upload size={13} /> Import JSON</Btn>
        <input ref={fileRef} type="file" accept="application/json,.json" hidden onChange={(e) => { const f = e.target.files?.[0]; if (f) void onImport(f); e.target.value = '' }} />
        <Btn size="sm" kind="ghost" onClick={() => void restoreDemos()} title="Re-add the six built-in demonstration projects"><RefreshCw size={13} /> Restore demos</Btn>
      </ToolbarPortal>
      <InspectorPortal>
        <div className="col" style={{ padding: 10 }}>
          <Panel title="Library">
            <Kv rows={[['Projects', String(summaries.length)], ['Archived', String(summaries.filter((s) => s.archived).length)], ['Active', project.code]]} />
            <label className="check"><input type="checkbox" checked={showArchived} onChange={(e) => setShowArchived(e.target.checked)} /> Show archived</label>
          </Panel>
          <Notice kind="info">Projects are stored locally in this browser's IndexedDB. Export JSON to back up or move a project.</Notice>
        </div>
      </InspectorPortal>
      {list.length === 0 ? <Empty title="No projects">Create one, or restore the demo projects.</Empty> : (
        <div className="grid cols-3">
          {list.map((s) => (
            <Panel key={s.id} title={renaming?.id === s.id ? (
              <input className="input mono" autoFocus value={renaming.text} onChange={(e) => setRenaming({ id: s.id, text: e.target.value })}
                onKeyDown={(e) => { if (e.key === 'Enter') { void renameProject(s.id, renaming.text); setRenaming(null) } if (e.key === 'Escape') setRenaming(null) }}
                onBlur={() => { void renameProject(s.id, renaming.text); setRenaming(null) }} />
            ) : <span onDoubleClick={() => setRenaming({ id: s.id, text: s.name })}>{s.name}</span>}
              actions={s.id === project.id ? <Badge kind="or">Active</Badge> : undefined}>
              <div className="small mono faint">{s.code}</div>
              <Kv rows={[['Updated', shortDate(s.updatedAt)], ['Assets', String(s.assetCount)], ['Samples', String(s.sampleCount)], ['Palettes', String(s.paletteCount)]]} />
              <div className="row wrap">
                <Btn size="sm" kind="primary" onClick={() => void openProject(s.id)}>Open</Btn>
                <Btn size="sm" onClick={() => setRenaming({ id: s.id, text: s.name })}>Rename</Btn>
                <Btn size="sm" onClick={() => void duplicateProject(s.id)}><Copy size={12} /> Duplicate</Btn>
                <Btn size="sm" onClick={() => void archiveProject(s.id, !s.archived)}>{s.archived ? <><ArchiveRestore size={12} /> Restore</> : <><Archive size={12} /> Archive</>}</Btn>
                <Btn size="sm" onClick={async () => { const full = s.id === project.id ? project : await (await import('../state/persistence')).getProject(s.id); if (full) downloadText(`${slug(full.code)}.chroma-project.json`, JSON.stringify({ format: 'chroma-engine-project', version: 1, project: full }, null, 2), 'application/json') }}><Download size={12} /> Export</Btn>
                <Btn size="sm" kind="danger" onClick={() => { if (confirm(`Delete “${s.name}”? This cannot be undone.`)) void deleteProject(s.id) }}><Trash2 size={12} /></Btn>
              </div>
            </Panel>
          ))}
        </div>
      )}
    </div>
  )
}
