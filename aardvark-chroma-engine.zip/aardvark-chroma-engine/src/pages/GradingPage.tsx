import { useMemo, useState } from 'react'
import { RefreshCw, Camera } from 'lucide-react'
import { useApp } from '../state/store'
import { useLab } from '../state/lab'
import { ToolbarPortal } from '../components/shell/Slots'
import { Panel, Slider, Btn, Select, Notice, Seg, Check2 } from '../components/common/ui'
import { ColourWheel } from '../components/colour-controls/ColourWheel'
import { ImageViewer } from '../components/image-viewer/ImageViewer'
import { HistogramChart, WaveformChart, VectorscopeChart } from '../components/charts/charts'
import { defaultGrade, GRADE_PRESETS, GRADE_PIPELINE_ORDER, type GradeParams, type Wheel } from '../core/grading/grade'
import { defaultRender } from '../core/image/image-processing'
import { useAssetImage } from '../hooks/useAssetImage'
import { runInWorker } from '../workers/client'
import type { ScopesResult } from '../core/image/tasks'
import { useEffect } from 'react'
import { newId } from '../core/colour/colour-model'
import { fmt, isoNow } from '../utils/format'

function useScopes(key: string | null, depsKey: string) {
  const [scopes, setScopes] = useState<ScopesResult | null>(null)
  useEffect(() => {
    if (!key) return
    let alive = true
    const h = window.setTimeout(() => { runInWorker<Extract<import('../core/image/tasks').TaskResult, { op: 'scopes' }>>({ op: 'scopes', key, channel: 'luma' }, 'scopes').then((r) => { if (alive) setScopes(r.result) }).catch(() => {}) }, 90)
    return () => { alive = false; window.clearTimeout(h) }
  }, [key, depsKey])
  return scopes
}

export default function GradingPage() {
  const { project, mutate, toast } = useApp()
  const lab = useLab()
  const [scopeChan, setScopeChan] = useState<'luma' | 'r' | 'g' | 'b'>('luma')
  const images = project.assets.filter((a) => a.kind === 'image')
  const asset = images.find((a) => a.id === project.activeAssetId) ?? images[0]
  const src = useAssetImage(asset)
  const g = project.currentGrade
  const setGrade = (patch: Partial<GradeParams>, coalesce?: string) => mutate('Adjust grade', (p) => ({ ...p, currentGrade: { ...p.currentGrade, ...patch } }), { coalesce: coalesce ? `grade:${coalesce}` : undefined })
  const setWheel = (key: 'offset' | 'lift' | 'gamma' | 'gain', w: Wheel) => setGrade({ [key]: w } as Partial<GradeParams>, `wheel:${key}`)

  const renderParams = useMemo(() => ({ ...defaultRender(), grade: g }), [g])
  const depsKey = JSON.stringify(g)
  const scopes = useScopes(src.key, depsKey + ':' + scopeChan)

  const [abSide, setAbSide] = useState<'a' | 'b'>('b')
  const abParams = useMemo(() => ({ ...defaultRender(), grade: abSide === 'a' ? project.gradeAB.a : project.gradeAB.b }), [abSide, project.gradeAB])

  if (!asset) return <div className="page"><Notice kind="warn">No image asset available.</Notice></div>

  return (
    <div className="page fill" style={{ display: 'grid', gridTemplateRows: 'minmax(0,1fr) 220px', height: '100%' }}>
      <ToolbarPortal>
        <Select ariaLabel="Grade preset" value="" onChange={(id) => { const preset = GRADE_PRESETS.find((x) => x.id === id); if (preset) { mutate(`Apply preset “${preset.name}”`, (p) => ({ ...p, currentGrade: preset.grade() })); toast('ok', `Applied “${preset.name}”`) } }} options={[{ id: '', label: 'Apply preset…' }, ...GRADE_PRESETS.map((p) => ({ id: p.id, label: p.name }))]} />
        <Btn size="sm" kind="ghost" onClick={() => mutate('Reset grade', (p) => ({ ...p, currentGrade: defaultGrade() }))}><RefreshCw size={13} /> Reset</Btn>
        <span className="sep" />
        <Btn size="sm" onClick={() => { const name = prompt('Snapshot name', `Snapshot ${project.gradeSnapshots.length + 1}`); if (name) mutate('Save grade snapshot', (p) => ({ ...p, gradeSnapshots: [...p.gradeSnapshots, { id: newId('gs'), name, grade: p.currentGrade, createdAt: isoNow() }] })) }}><Camera size={13} /> Snapshot</Btn>
        <Btn size="sm" onClick={() => mutate('Set A/B grade B', (p) => ({ ...p, gradeAB: { ...p.gradeAB, b: p.currentGrade } }))}>Set as B</Btn>
        <Btn size="sm" onClick={() => mutate('Set A/B grade A', (p) => ({ ...p, gradeAB: { ...p.gradeAB, a: p.currentGrade } }))}>Set as A</Btn>
        <Check2 checked={lab.applyGrade} onChange={(v) => lab.set({ applyGrade: v })}>Before/after in Image Lab uses this grade</Check2>
      </ToolbarPortal>
      <div className="split wide" style={{ height: '100%', overflow: 'hidden', padding: 10 }}>
        <div className="col" style={{ minHeight: 0, height: '100%' }}>
          <div className="row" style={{ height: '100%', minHeight: 0 }}>
            <div className="grow" style={{ minHeight: 0, height: '100%' }}>
              <ImageViewer asset={asset} params={renderParams} depsKey={depsKey} compare={{ mode: 'off', wipe: 0.5 }} pixelGrid={false} histogramOverlay={false} sampleSource="displayed" minHeight={280} />
            </div>
          </div>
        </div>
        <div className="col" style={{ overflowY: 'auto', maxHeight: '100%' }}>
          <Panel title="Primary" bodyClass="col">
            <Slider label="Exposure" value={g.exposure} min={-4} max={4} step={0.02} onChange={(v) => setGrade({ exposure: v }, 'exposure')} defaultValue={0} format={(v) => `${v >= 0 ? '+' : ''}${fmt(v, 2)} EV`} />
            <Slider label="Contrast" value={g.contrast} min={-1} max={1} step={0.01} onChange={(v) => setGrade({ contrast: v }, 'contrast')} defaultValue={0} />
            <Slider label="Pivot" value={g.pivot} min={0.05} max={0.5} step={0.005} onChange={(v) => setGrade({ pivot: v }, 'pivot')} defaultValue={0.18} />
            <Slider label="Temperature" value={g.temperature} min={-100} max={100} step={1} decimals={0} onChange={(v) => setGrade({ temperature: v }, 'temp')} defaultValue={0} />
            <Slider label="Tint" value={g.tint} min={-100} max={100} step={1} decimals={0} onChange={(v) => setGrade({ tint: v }, 'tint')} defaultValue={0} />
            <Slider label="Saturation" value={g.saturation} min={-1} max={1} step={0.01} onChange={(v) => setGrade({ saturation: v }, 'sat')} defaultValue={0} />
            <Slider label="Vibrance" value={g.vibrance} min={-1} max={1} step={0.01} onChange={(v) => setGrade({ vibrance: v }, 'vib')} defaultValue={0} />
            <Slider label="Hue shift" value={g.hueShift} min={-180} max={180} step={1} decimals={0} onChange={(v) => setGrade({ hueShift: v }, 'hue')} defaultValue={0} format={(v) => `${fmt(v, 0)}°`} />
          </Panel>
          <Panel title="Tone regions" bodyClass="col">
            <Slider label="Shadows" value={g.shadows} min={-1} max={1} step={0.01} onChange={(v) => setGrade({ shadows: v }, 'sh')} defaultValue={0} />
            <Slider label="Midtone detail" value={g.midtoneDetail} min={-1} max={1} step={0.01} onChange={(v) => setGrade({ midtoneDetail: v }, 'mid')} defaultValue={0} />
            <Slider label="Highlights" value={g.highlights} min={-1} max={1} step={0.01} onChange={(v) => setGrade({ highlights: v }, 'hi')} defaultValue={0} />
            <Slider label="Whites" value={g.whites} min={-1} max={1} step={0.01} onChange={(v) => setGrade({ whites: v }, 'wh')} defaultValue={0} />
            <Slider label="Blacks" value={g.blacks} min={-1} max={1} step={0.01} onChange={(v) => setGrade({ blacks: v }, 'bl')} defaultValue={0} />
          </Panel>
          <Panel title="Channels" bodyClass="col">
            <Slider label="Red gain" value={g.channelR} min={-1} max={1} step={0.01} onChange={(v) => setGrade({ channelR: v }, 'cr')} defaultValue={0} />
            <Slider label="Green gain" value={g.channelG} min={-1} max={1} step={0.01} onChange={(v) => setGrade({ channelG: v }, 'cg')} defaultValue={0} />
            <Slider label="Blue gain" value={g.channelB} min={-1} max={1} step={0.01} onChange={(v) => setGrade({ channelB: v }, 'cb')} defaultValue={0} />
          </Panel>
          <Panel title="Colour wheels">
            <div className="row wrap" style={{ justifyContent: 'space-around' }}>
              <ColourWheel label="Offset" value={g.offset} onChange={(w) => setWheel('offset', w)} />
              <ColourWheel label="Lift" value={g.lift} onChange={(w) => setWheel('lift', w)} />
              <ColourWheel label="Gamma" value={g.gamma} onChange={(w) => setWheel('gamma', w)} />
              <ColourWheel label="Gain" value={g.gain} onChange={(w) => setWheel('gain', w)} />
            </div>
          </Panel>
          <Panel title="Pipeline order (fixed)"><ol className="small faint" style={{ margin: 0, paddingLeft: 18 }}>{GRADE_PIPELINE_ORDER.map((s, i) => <li key={i}>{s}</li>)}</ol></Panel>
          <Panel title="Snapshots">
            {project.gradeSnapshots.length === 0 ? <span className="small muted">No snapshots yet.</span> : project.gradeSnapshots.map((s) => (
              <div key={s.id} className="row small" style={{ justifyContent: 'space-between' }}>
                <span>{s.name}</span>
                <span className="row" style={{ gap: 4 }}>
                  <Btn size="sm" onClick={() => mutate(`Load snapshot “${s.name}”`, (p) => ({ ...p, currentGrade: s.grade }))}>Load</Btn>
                  <Btn size="sm" kind="ghost" onClick={() => mutate('Delete snapshot', (p) => ({ ...p, gradeSnapshots: p.gradeSnapshots.filter((x) => x.id !== s.id) }))}>✕</Btn>
                </span>
              </div>
            ))}
          </Panel>
          <Panel title="A/B compare" actions={<Seg options={[{ id: 'a', label: 'A' }, { id: 'b', label: 'B' }]} value={abSide} onChange={setAbSide} />}>
            <div style={{ height: 140 }}><ImageViewer asset={asset} params={abParams} depsKey={JSON.stringify(abParams)} compare={{ mode: 'off', wipe: 0.5 }} pixelGrid={false} histogramOverlay={false} sampleSource="displayed" minHeight={140} /></div>
            <div className="small faint">A and B are independent saved grades — set them from the toolbar. Toggle to compare fully graded looks.</div>
          </Panel>
        </div>
      </div>
      <div className="row" style={{ padding: '0 10px 10px', gap: 10, overflowX: 'auto' }}>
        <Panel title="Waveform (luma)" className="grow" bodyClass="col" style={{ minWidth: 280 }}><WaveformChart wf={scopes?.waveform ?? null} /></Panel>
        <Panel title="Vectorscope" bodyClass="col"><VectorscopeChart vs={scopes?.vectorscope ?? null} size={168} /></Panel>
        <Panel title="RGB parade" className="grow" bodyClass="col" style={{ minWidth: 280 }}>
          <Seg options={[{ id: 'luma', label: 'Y' }, { id: 'r', label: 'R' }, { id: 'g', label: 'G' }, { id: 'b', label: 'B' }]} value={scopeChan} onChange={setScopeChan} />
          <HistogramChart hist={scopes?.hist ?? null} mode="rgb" height={112} />
        </Panel>
      </div>
    </div>
  )
}
