import { type RGB, xyzToLinear, type XYZ, clamp01 } from '../colour/conversions'
import { type ImageBuf, createImage, encode8 } from '../image/image-model'
import { smoothstep } from '../image/noise'

/**
 * Lighting approximations. The illuminant colour comes from the Kim et al. (2002) Planckian-locus fit (1667–25000 K).
 * Surface appearance is Lambert + Blinn–Phong with a metallic/dielectric specular tint. This is an APPROXIMATION for
 * colour studies — not a spectral or physically based renderer.
 */

export function kelvinToXy(kelvin: number): { x: number; y: number } {
  const T = Math.min(25000, Math.max(1667, kelvin))
  const T2 = T * T, T3 = T2 * T
  const x = T <= 4000
    ? -0.2661239e9 / T3 - 0.2343589e6 / T2 + 0.8776956e3 / T + 0.17991
    : -3.0258469e9 / T3 + 2.1070379e6 / T2 + 0.2226347e3 / T + 0.24039
  let y: number
  if (T <= 2222) y = -1.1063814 * x ** 3 - 1.3481102 * x ** 2 + 2.18555832 * x - 0.20219683
  else if (T <= 4000) y = -0.9549476 * x ** 3 - 1.37418593 * x ** 2 + 2.09137015 * x - 0.16748867
  else y = 3.081758 * x ** 3 - 5.8733867 * x ** 2 + 3.75112997 * x - 0.37001483
  return { x, y }
}

/** Illuminant colour as linear sRGB, normalised to unit luminance (Y = 1). `tint` −1..1 is a green(−)/magenta(+) shift. */
export function kelvinToLinearRgb(kelvin: number, tint = 0): RGB {
  const { x, y } = kelvinToXy(kelvin)
  const xyz: XYZ = { x: x / y, y: 1, z: (1 - x - y) / y }
  const c = xyzToLinear(xyz, 'srgb')
  const g = 1 - 0.25 * tint
  const rgb = { r: Math.max(0, c.r), g: Math.max(0, c.g * g), b: Math.max(0, c.b) }
  const Y = 0.2126 * rgb.r + 0.7152 * rgb.g + 0.0722 * rgb.b
  return { r: rgb.r / Y, g: rgb.g / Y, b: rgb.b / Y }
}

/** Relative to D65 (6504 K): the colour cast a surface would show in a viewer who has NOT adapted. */
export function illuminantCast(kelvin: number, tint = 0): RGB {
  const l = kelvinToLinearRgb(kelvin, tint), ref = kelvinToLinearRgb(6504, 0)
  return { r: l.r / ref.r, g: l.g / ref.g, b: l.b / ref.b }
}

/** Von-Kries-style partial adaptation in linear RGB (0 = none, 1 = complete). Coarse — no cone-space transform. */
export function adaptedCast(kelvin: number, tint: number, adaptation: number): RGB {
  const c = illuminantCast(kelvin, tint)
  const k = 1 - clamp01(adaptation)
  return { r: Math.pow(c.r, k), g: Math.pow(c.g, k), b: Math.pow(c.b, k) }
}

export function lightSurface(albedo: RGB, kelvin: number, tint = 0, adaptation = 0, exposure = 0): RGB {
  const c = adaptedCast(kelvin, tint, adaptation), e = Math.pow(2, exposure)
  return { r: albedo.r * c.r * e, g: albedo.g * c.g * e, b: albedo.b * c.b * e }
}

export interface LightingSetup {
  kelvin: number
  tint: number
  intensity: number
  keyAzimuth: number   // degrees, 0 = from the right, 90 = from the top... measured in the image plane
  keyElevation: number // degrees above the view plane, 0..90
  fill: number         // 0..1 fill from the opposite side
  ambient: number      // 0..1
  adaptation: number   // 0..1
  exposure: number     // stops
  contrast: number     // −1..1
  shadowDepth: number  // 0..1
  specular: number     // 0..2 multiplier
  background: RGB      // linear
}

export const defaultLighting = (): LightingSetup => ({
  kelvin: 5600, tint: 0, intensity: 1, keyAzimuth: 135, keyElevation: 45, fill: 0.25, ambient: 0.12, adaptation: 0,
  exposure: 0, contrast: 0, shadowDepth: 0.6, specular: 1, background: { r: 0.02, g: 0.022, b: 0.025 },
})

export interface LightPreset { id: string; name: string; note: string; setup: Partial<LightingSetup> }

export const LIGHT_PRESETS: LightPreset[] = [
  { id: 'studio-daylight', name: 'Studio daylight', note: '5600 K key, moderate fill', setup: { kelvin: 5600, tint: 0, intensity: 1, fill: 0.3, ambient: 0.12, keyElevation: 50 } },
  { id: 'overcast', name: 'Overcast sky', note: '6500 K, very soft, high ambient', setup: { kelvin: 6500, tint: 0.02, intensity: 0.75, fill: 0.7, ambient: 0.4, keyElevation: 80, shadowDepth: 0.15, specular: 0.4 } },
  { id: 'warehouse', name: 'Industrial warehouse', note: '4000 K with a green-leaning discharge tint', setup: { kelvin: 4000, tint: -0.35, intensity: 0.85, fill: 0.15, ambient: 0.1, keyElevation: 75, shadowDepth: 0.75 } },
  { id: 'warm-interior', name: 'Warm architectural interior', note: '2700 K, low-angle, low fill', setup: { kelvin: 2700, tint: 0.05, intensity: 0.9, fill: 0.15, ambient: 0.15, keyElevation: 30 } },
  { id: 'museum', name: 'Museum lighting', note: '3000 K, narrow, high contrast', setup: { kelvin: 3000, tint: 0, intensity: 1.15, fill: 0.08, ambient: 0.05, keyElevation: 55, shadowDepth: 0.9, specular: 1.3 } },
  { id: 'tungsten', name: 'Film-set tungsten', note: '3200 K hard key', setup: { kelvin: 3200, tint: 0, intensity: 1.2, fill: 0.12, ambient: 0.08, keyElevation: 40, shadowDepth: 0.85 } },
  { id: 'blue-hour', name: 'Blue-hour exterior', note: '9000 K, dim, high ambient', setup: { kelvin: 9000, tint: 0.05, intensity: 0.35, fill: 0.5, ambient: 0.35, keyElevation: 20, shadowDepth: 0.3, exposure: 0.4 } },
  { id: 'laboratory', name: 'Laboratory lighting', note: '5000 K neutral, shadow-free', setup: { kelvin: 5000, tint: 0, intensity: 1, fill: 0.55, ambient: 0.3, keyElevation: 85, shadowDepth: 0.2, specular: 0.6 } },
]

export interface SurfaceParams { albedo: RGB; roughness: number; metallic: number; reflectance: number }

const dot = (a: [number, number, number], b: [number, number, number]) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2]

/** Render a lit sphere on a background. Deterministic; size×size RGBA. */
export function shadeSphere(size: number, s: SurfaceParams, L: LightingSetup): ImageBuf {
  const img = createImage(size, size)
  const cast = adaptedCast(L.kelvin, L.tint, L.adaptation)
  const az = (L.keyAzimuth * Math.PI) / 180, el = (L.keyElevation * Math.PI) / 180
  const key: [number, number, number] = [Math.cos(az) * Math.cos(el), -Math.sin(az) * Math.cos(el), Math.sin(el)]
  const fillDir: [number, number, number] = [-key[0], -key[1] * 0.4, 0.55]
  const fl = Math.hypot(...fillDir); fillDir[0] /= fl; fillDir[1] /= fl; fillDir[2] /= fl
  const view: [number, number, number] = [0, 0, 1]
  const shin = 2 / Math.max(0.02, s.roughness * s.roughness) - 1.5
  const specBase = 0.04 * (1 - s.metallic) + s.metallic
  const specTint: RGB = { r: 0.04 + (s.albedo.r - 0.04) * s.metallic, g: 0.04 + (s.albedo.g - 0.04) * s.metallic, b: 0.04 + (s.albedo.b - 0.04) * s.metallic }
  const expMul = Math.pow(2, L.exposure)
  const contrastK = 1 + L.contrast * 0.8
  const rad = size * 0.38, cx = size / 2, cy = size * 0.47
  const bg = { r: L.background.r * cast.r, g: L.background.g * cast.g, b: L.background.b * cast.b }
  const diffuseK = (1 - s.metallic)
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const px = x + 0.5 - cx, py = y + 0.5 - cy
      const d = Math.hypot(px, py)
      let r = bg.r, g = bg.g, b = bg.b
      // contact shadow on the ground plane
      const sx = (px - key[0] * -rad * 0.5) / (rad * 1.05), sy = (py - rad * 0.95) / (rad * 0.25)
      const sh = Math.exp(-(sx * sx + sy * sy) * 1.4) * L.shadowDepth * (py > rad * 0.4 ? 1 : 0)
      r *= 1 - sh * 0.9; g *= 1 - sh * 0.9; b *= 1 - sh * 0.9
      if (d < rad + 0.7) {
        const cov = clamp01(rad + 0.5 - d)
        const nx = px / rad, ny = py / rad
        const nz = Math.sqrt(Math.max(0, 1 - nx * nx - ny * ny))
        const n: [number, number, number] = [nx, -ny, nz]
        const nl = Math.max(0, dot(n, key)), fl2 = Math.max(0, dot(n, fillDir))
        const shade = smoothstep(-0.08, 0.12, dot(n, key))
        const h1: [number, number, number] = [key[0] + view[0], key[1] + view[1], key[2] + view[2]]
        const hl = Math.hypot(...h1); h1[0] /= hl; h1[1] /= hl; h1[2] /= hl
        const spec = Math.pow(Math.max(0, dot(n, h1)), shin) * (shin + 8) / 24 * shade * L.specular * (0.4 + 0.6 * s.reflectance)
        const amb = L.ambient * (0.65 + 0.35 * n[1])
        const light = L.intensity * nl * shade + L.fill * fl2 * 0.6 + amb
        const fres = Math.pow(1 - Math.max(0, n[2]), 4) * 0.25 * (1 - s.roughness) * L.specular
        const sr = light * s.albedo.r * diffuseK + (specTint.r * spec * L.intensity) + specBase * fres * (amb + 0.3)
        const sg = light * s.albedo.g * diffuseK + (specTint.g * spec * L.intensity) + specBase * fres * (amb + 0.3)
        const sb = light * s.albedo.b * diffuseK + (specTint.b * spec * L.intensity) + specBase * fres * (amb + 0.3)
        r = r * (1 - cov) + sr * cast.r * cov
        g = g * (1 - cov) + sg * cast.g * cov
        b = b * (1 - cov) + sb * cast.b * cov
      }
      const pivot = 0.18
      const c = (v: number) => {
        v *= expMul
        if (contrastK !== 1 && v > 0) v = pivot * Math.pow(v / pivot, contrastK)
        return v
      }
      const i = (y * size + x) * 4
      img.data[i] = encode8(c(r)); img.data[i + 1] = encode8(c(g)); img.data[i + 2] = encode8(c(b)); img.data[i + 3] = 255
    }
  }
  return img
}
