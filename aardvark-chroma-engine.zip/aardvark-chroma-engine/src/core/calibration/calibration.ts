import { type ImageBuf, createImage } from '../image/image-model'
import { mulberry32 } from '../image/noise'
import { srgbToLinear, linearToSrgb, parseHex, type RGB } from '../colour/conversions'
import { oklchToOklab, oklabToLinear } from '../colour/conversions'
import { kelvinToXy } from '../lighting/lighting'

/**
 * Display calibration PLANNING environment. All display profiles and measurements in this file are SYNTHETIC and
 * deterministic. Nothing here is read from hardware; a browser cannot measure a display. Use a colorimeter or
 * spectroradiometer for real calibration.
 */

export interface DisplayProfile {
  id: string
  name: string
  panel: string
  profileName: string
  colourSpace: string
  targetWhiteK: number
  targetGamma: number
  targetLuminance: number // cd/m²
  blackLevel: number      // cd/m² (estimate)
  coverage: { srgb: number; displayP3: number; rec2020: number } // % of gamut volume, synthetic
  status: 'calibrated' | 'drifting' | 'uncalibrated'
  lastCalibrated: string
}

export const DISPLAY_PROFILES: DisplayProfile[] = [
  { id: 'dsp-ref', name: 'Grading reference display', panel: '27″ IPS, 10-bit, hardware LUT', profileName: 'AAI-REF-D65-G24-100', colourSpace: 'Rec.709 / BT.1886', targetWhiteK: 6504, targetGamma: 2.4, targetLuminance: 100, blackLevel: 0.028, coverage: { srgb: 100, displayP3: 97.4, rec2020: 71.2 }, status: 'calibrated', lastCalibrated: '2026-08-28T08:40:00Z' },
  { id: 'dsp-p3', name: 'Studio Display P3', panel: '32″ mini-LED, 10-bit', profileName: 'AAI-P3-D65-G22-160', colourSpace: 'Display P3', targetWhiteK: 6504, targetGamma: 2.2, targetLuminance: 160, blackLevel: 0.045, coverage: { srgb: 100, displayP3: 99.1, rec2020: 76.8 }, status: 'drifting', lastCalibrated: '2026-06-02T10:15:00Z' },
  { id: 'dsp-office', name: 'Office desktop panel', panel: '24″ IPS, 8-bit', profileName: 'sRGB IEC61966-2.1 (factory)', colourSpace: 'sRGB', targetWhiteK: 6500, targetGamma: 2.2, targetLuminance: 200, blackLevel: 0.21, coverage: { srgb: 96.5, displayP3: 70.2, rec2020: 51.4 }, status: 'uncalibrated', lastCalibrated: '—' },
]

export interface Measurement {
  id: string
  at: string
  displayId: string
  whiteX: number
  whiteY: number
  cct: number
  gamma: number
  luminance: number
  black: number
  contrastRatio: number
  avgDeltaE: number
  maxDeltaE: number
  note: string
}

export function syntheticMeasurements(displayId: string, count = 8): Measurement[] {
  const d = DISPLAY_PROFILES.find((p) => p.id === displayId) ?? DISPLAY_PROFILES[0]
  const rnd = mulberry32(displayId.length * 7919 + d.targetLuminance)
  const ref = kelvinToXy(d.targetWhiteK)
  const out: Measurement[] = []
  const driftPerStep = d.status === 'calibrated' ? 0.15 : d.status === 'drifting' ? 0.7 : 1.4
  for (let i = 0; i < count; i++) {
    const age = i
    const date = new Date(Date.UTC(2026, 2 + i, 3 + i * 2, 9, 30))
    const cct = d.targetWhiteK + (rnd() - 0.5) * 120 * driftPerStep * (1 + age * 0.4)
    const lum = d.targetLuminance * (1 - 0.012 * age * driftPerStep + (rnd() - 0.5) * 0.02)
    const black = d.blackLevel * (1 + (rnd() - 0.5) * 0.15)
    const avg = 0.6 + driftPerStep * (0.5 + age * 0.22) + rnd() * 0.25
    out.push({
      id: `${displayId}-m${i + 1}`, at: date.toISOString(), displayId,
      whiteX: ref.x + (rnd() - 0.5) * 0.004 * driftPerStep, whiteY: ref.y + (rnd() - 0.5) * 0.004 * driftPerStep,
      cct: Math.round(cct), gamma: +(d.targetGamma + (rnd() - 0.5) * 0.06 * driftPerStep).toFixed(3),
      luminance: +lum.toFixed(1), black: +black.toFixed(3), contrastRatio: Math.round(lum / black),
      avgDeltaE: +avg.toFixed(2), maxDeltaE: +(avg * (2.3 + rnd())).toFixed(2), note: i === 0 ? 'Baseline after profiling (synthetic)' : 'Verification (synthetic)',
    })
  }
  return out
}

/** 5×5 luminance uniformity map (ratio to centre). Radial fall-off plus a gentle gradient plus seeded noise. */
export function uniformityMap(displayId: string, n = 5): number[][] {
  const d = DISPLAY_PROFILES.find((p) => p.id === displayId) ?? DISPLAY_PROFILES[0]
  const rnd = mulberry32(displayId.length * 104729 + 3)
  const severity = d.status === 'calibrated' ? 0.035 : d.status === 'drifting' ? 0.07 : 0.12
  const rows: number[][] = []
  for (let y = 0; y < n; y++) {
    const row: number[] = []
    for (let x = 0; x < n; x++) {
      const dx = x / (n - 1) - 0.5, dy = y / (n - 1) - 0.5
      const v = 1 - severity * (dx * dx + dy * dy) * 4 - severity * 0.5 * dx + (rnd() - 0.5) * severity * 0.4
      row.push(+v.toFixed(3))
    }
    rows.push(row)
  }
  return rows
}

// ───────────── test patterns ─────────────

export type PatternId =
  | 'grayscale-ramp' | 'rgb-ramps' | 'colour-patches' | 'saturation-sweep' | 'contrast-chart' | 'near-black'
  | 'near-white' | 'skin-tones' | 'fine-lines' | 'banding' | 'gradient-smoothness'

export const PATTERNS: { id: PatternId; name: string; purpose: string }[] = [
  { id: 'grayscale-ramp', name: 'Grayscale ramp', purpose: '21 steps from 0 to 255. Every step should be distinguishable and neutral.' },
  { id: 'rgb-ramps', name: 'RGB ramps', purpose: 'Independent red, green, blue and white ramps — reveals channel imbalance and colour casts in the low end.' },
  { id: 'colour-patches', name: 'Colour patches', purpose: '24 patches using commonly cited sRGB approximations of a classic chart. Not a measured reference.' },
  { id: 'saturation-sweep', name: 'Saturation sweep', purpose: 'Hue rows at 6 chroma levels in OKLCh (gamut-mapped). Reveals gamut compression and clipping.' },
  { id: 'contrast-chart', name: 'Contrast chart', purpose: 'Step wedge on black and white surrounds plus a checkerboard for simultaneous-contrast and flare checks.' },
  { id: 'near-black', name: 'Near-black detail', purpose: 'Code values 0–20. On a well-set brightness control steps 3+ are visible.' },
  { id: 'near-white', name: 'Near-white detail', purpose: 'Code values 235–255. Steps merging at the top indicate highlight clipping.' },
  { id: 'skin-tones', name: 'Skin-tone approximation', purpose: 'Synthetic skin-hue chart: lightness rows × chroma columns at OKLCh hue ≈ 55°. Not a measured skin reference.' },
  { id: 'fine-lines', name: 'Fine-line resolution', purpose: 'Line pairs of 1, 2, 3, 4, 6 and 8 px, horizontal and vertical — tests scaling, sharpening and subpixel layout.' },
  { id: 'banding', name: 'Banding test', purpose: '8-bit vs 6-bit quantised gradients. Visible steps in the first indicate display/GPU pipeline depth limits.' },
  { id: 'gradient-smoothness', name: 'Gradient smoothness', purpose: 'Smooth full-range gradients in grey, red, green and blue without dithering (top) and with ordered dither (bottom).' },
]

const CLASSIC_24 = ['#735244', '#c29682', '#627a9d', '#576c43', '#8580b1', '#67bdaa', '#d67e2c', '#505ba6', '#c15a63', '#5e3c6c', '#9dbc40', '#e0a32e', '#383d96', '#469449', '#af363c', '#e7c71f', '#bb5695', '#0885a1', '#f3f3f2', '#c8c8c8', '#a0a0a0', '#7a7a79', '#555555', '#343434']

function fillRect(img: ImageBuf, x: number, y: number, w: number, h: number, r: number, g: number, b: number) {
  for (let yy = Math.max(0, y); yy < Math.min(img.height, y + h); yy++) for (let xx = Math.max(0, x); xx < Math.min(img.width, x + w); xx++) {
    const i = (yy * img.width + xx) * 4
    img.data[i] = r; img.data[i + 1] = g; img.data[i + 2] = b; img.data[i + 3] = 255
  }
}

const BAYER4 = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5]

export function generatePattern(id: PatternId, width = 960, height = 540): ImageBuf {
  const img = createImage(width, height, [0, 0, 0, 255])
  switch (id) {
    case 'grayscale-ramp': {
      const n = 21, w = Math.floor(width / n)
      for (let i = 0; i < n; i++) { const v = Math.round((i / (n - 1)) * 255); fillRect(img, i * w + Math.floor((width - w * n) / 2), 0, w, height, v, v, v) }
      break
    }
    case 'rgb-ramps': {
      const bands = 4, bh = Math.floor(height / bands), n = 32, w = Math.floor(width / n)
      for (let b = 0; b < bands; b++) for (let i = 0; i < n; i++) {
        const v = Math.round((i / (n - 1)) * 255)
        fillRect(img, i * w, b * bh, w, bh, b === 0 || b === 3 ? v : 0, b === 1 || b === 3 ? v : 0, b === 2 || b === 3 ? v : 0)
      }
      break
    }
    case 'colour-patches': {
      const cols = 6, rows = 4, pw = Math.floor(width / cols), ph = Math.floor(height / rows), gap = 8
      for (let i = 0; i < 24; i++) {
        const p = parseHex(CLASSIC_24[i])!
        fillRect(img, (i % cols) * pw + gap, Math.floor(i / cols) * ph + gap, pw - gap * 2, ph - gap * 2, Math.round(p.rgb.r * 255), Math.round(p.rgb.g * 255), Math.round(p.rgb.b * 255))
      }
      break
    }
    case 'saturation-sweep': {
      const hues = 36, levels = 6, w = Math.floor(width / hues), h = Math.floor(height / levels)
      for (let l = 0; l < levels; l++) for (let hI = 0; hI < hues; hI++) {
        const c = (l / (levels - 1)) * 0.3
        let lin = oklabToLinear(oklchToOklab({ l: 0.68, c, h: (hI / hues) * 360 }))
        lin = { r: Math.min(1, Math.max(0, lin.r)), g: Math.min(1, Math.max(0, lin.g)), b: Math.min(1, Math.max(0, lin.b)) }
        const e = linearToSrgb(lin)
        fillRect(img, hI * w, l * h, w, h, Math.round(e.r * 255), Math.round(e.g * 255), Math.round(e.b * 255))
      }
      break
    }
    case 'contrast-chart': {
      const half = Math.floor(width / 2)
      fillRect(img, 0, 0, half, height, 0, 0, 0)
      fillRect(img, half, 0, width - half, height, 255, 255, 255)
      const n = 10, w = Math.floor((half - 40) / n)
      for (let i = 0; i < n; i++) {
        const v = Math.round((i / (n - 1)) * 255)
        fillRect(img, 20 + i * w, 40, w - 4, 140, v, v, v)
        fillRect(img, half + 20 + i * w, 40, w - 4, 140, v, v, v)
      }
      const cs = 24
      for (let y = 0; y < 8; y++) for (let x = 0; x < 16; x++) { const v = (x + y) % 2 ? 255 : 0; fillRect(img, 40 + x * cs, 230 + y * cs, cs, cs, v, v, v) }
      fillRect(img, half + 120, 260, 200, 140, 0, 0, 0)
      break
    }
    case 'near-black': {
      const n = 21, w = Math.floor(width / n)
      for (let i = 0; i < n; i++) fillRect(img, i * w + Math.floor((width - w * n) / 2), 0, w, height, i, i, i)
      break
    }
    case 'near-white': {
      const n = 21, w = Math.floor(width / n)
      for (let i = 0; i < n; i++) { const v = 235 + i; fillRect(img, i * w + Math.floor((width - w * n) / 2), 0, w, height, v, v, v) }
      break
    }
    case 'skin-tones': {
      const rows = 6, cols = 8, w = Math.floor(width / cols), h = Math.floor(height / rows)
      for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) {
        const lin = oklabToLinear(oklchToOklab({ l: 0.36 + (y / (rows - 1)) * 0.5, c: 0.03 + (x / (cols - 1)) * 0.075, h: 55 }))
        const e = linearToSrgb({ r: Math.min(1, Math.max(0, lin.r)), g: Math.min(1, Math.max(0, lin.g)), b: Math.min(1, Math.max(0, lin.b)) })
        fillRect(img, x * w, y * h, w, h, Math.round(e.r * 255), Math.round(e.g * 255), Math.round(e.b * 255))
      }
      break
    }
    case 'fine-lines': {
      const widths = [1, 2, 3, 4, 6, 8], cell = Math.floor(width / widths.length)
      widths.forEach((lw, k) => {
        for (let x = 0; x < cell - 20; x++) if (Math.floor(x / lw) % 2 === 0) fillRect(img, k * cell + 10 + x, 20, 1, Math.floor(height / 2) - 30, 255, 255, 255)
        for (let y = 0; y < Math.floor(height / 2) - 30; y++) if (Math.floor(y / lw) % 2 === 0) fillRect(img, k * cell + 10, Math.floor(height / 2) + 10 + y, cell - 20, 1, 255, 255, 255)
      })
      break
    }
    case 'banding': {
      const h = Math.floor(height / 2)
      for (let x = 0; x < width; x++) {
        const t = x / (width - 1)
        const v8 = Math.round(t * 255), v6 = Math.round(Math.round(t * 63) * (255 / 63))
        fillRect(img, x, 0, 1, h, v8, v8, v8)
        fillRect(img, x, h, 1, height - h, v6, v6, v6)
      }
      break
    }
    case 'gradient-smoothness': {
      const chans: [number, number, number][] = [[1, 1, 1], [1, 0, 0], [0, 1, 0], [0, 0, 1]]
      const bh = Math.floor(height / (chans.length * 2))
      chans.forEach((c, k) => {
        for (let x = 0; x < width; x++) {
          const t = x / (width - 1)
          fillRect(img, x, k * 2 * bh, 1, bh, Math.round(t * 255 * c[0]), Math.round(t * 255 * c[1]), Math.round(t * 255 * c[2]))
          for (let y = 0; y < bh; y++) {
            const th = BAYER4[(y % 4) * 4 + (x % 4)] / 16
            const f = (ch: number) => (ch ? Math.min(255, Math.floor(t * 255 + th)) : 0)
            fillRect(img, x, (k * 2 + 1) * bh + y, 1, 1, f(c[0]), f(c[1]), f(c[2]))
          }
        }
      })
      break
    }
  }
  return img
}

export function calibrationReportMarkdown(d: DisplayProfile, ms: Measurement[], opts: { operator: string; timestamp: string }): string {
  const last = ms[ms.length - 1]
  return [
    `# Display calibration planning report`,
    ``,
    `> Synthetic data. This report is produced by a calibration-planning environment and is **not** a measurement certificate.`,
    ``,
    `- Display: ${d.name} (${d.panel})`,
    `- Profile: ${d.profileName} — ${d.colourSpace}`,
    `- Target: ${d.targetWhiteK} K, gamma ${d.targetGamma}, ${d.targetLuminance} cd/m²`,
    `- Black-level estimate: ${d.blackLevel} cd/m² (contrast ≈ ${Math.round(d.targetLuminance / d.blackLevel)}:1)`,
    `- Coverage (synthetic): sRGB ${d.coverage.srgb}% · Display P3 ${d.coverage.displayP3}% · Rec.2020 ${d.coverage.rec2020}%`,
    `- Status: ${d.status}`,
    `- Last calibrated: ${d.lastCalibrated}`,
    ``,
    `## Measurement history`,
    ``,
    `| Date | CCT (K) | Gamma | Luminance | Black | Avg ΔE | Max ΔE |`,
    `|---|---|---|---|---|---|---|`,
    ...ms.map((m) => `| ${m.at.slice(0, 10)} | ${m.cct} | ${m.gamma} | ${m.luminance} | ${m.black} | ${m.avgDeltaE} | ${m.maxDeltaE} |`),
    ``,
    last ? `Latest average ΔE: ${last.avgDeltaE}. ${last.avgDeltaE > 2 ? 'Recalibration recommended.' : 'Within tolerance.'}` : '',
    ``,
    `Operator: ${opts.operator}`,
    `Generated: ${opts.timestamp}`,
    ``,
  ].join('\n')
}

export type { RGB }
export { srgbToLinear }
