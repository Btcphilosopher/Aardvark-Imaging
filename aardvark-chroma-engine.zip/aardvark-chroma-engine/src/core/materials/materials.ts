import type { RGB } from '../colour/conversions'
import { srgbToLinear, parseHex } from '../colour/conversions'

export type MaterialCategory =
  | 'Metals' | 'Stone' | 'Concrete' | 'Glass' | 'Ceramics' | 'Timber' | 'Painted surfaces'
  | 'Plastics' | 'Textiles' | 'Asphalt' | 'Soil' | 'Water' | 'Industrial coatings'

export interface MaterialRecord {
  id: string
  name: string
  category: MaterialCategory
  baseHex: string
  /** 0 = mirror, 1 = fully diffuse (microfacet-style approximation, not measured BRDF data) */
  roughness: number
  metallic: number
  /** Approximate normal-incidence reflectance of the surface as a whole (0..1) */
  reflectance: number
  transmission: number
  description: string
  lightingNotes: string
  productionNotes: string
  swatches: string[]
  /** true when the material appears in the procedural material board */
  onBoard: boolean
}

export const MATERIALS: MaterialRecord[] = [
  { id: 'mat-alu', name: 'Brushed aluminium', category: 'Metals', baseHex: '#aeb3b8', roughness: 0.38, metallic: 1, reflectance: 0.88, transmission: 0,
    description: 'Satin-finished anodised sheet with unidirectional brush lines. Highlights stretch perpendicular to the grain.',
    lightingNotes: 'Reads almost entirely as reflected environment. Use a large soft source; hard sources give thin specular streaks. Neutral to slightly cool under daylight.',
    productionNotes: 'Keep highlights below 240 in the working image to preserve brush texture. Avoid saturating the reflected environment.',
    swatches: ['#d3d6d9', '#aeb3b8', '#82878c', '#5a5e62'], onBoard: true },
  { id: 'mat-cu', name: 'Oxidised copper', category: 'Metals', baseHex: '#6b8f7b', roughness: 0.6, metallic: 0.55, reflectance: 0.45, transmission: 0,
    description: 'Copper sheet with patchy verdigris patina over a warm metallic substrate.',
    lightingNotes: 'Substrate warms strongly under 2700K; patina shifts toward blue-green under cool light. Colour contrast between patina and copper is highest at 5600K.',
    productionNotes: 'Verdigris sits close to the sRGB green boundary in saturated patches — check gamut before CMYK conversion.',
    swatches: ['#b0653a', '#8a6a4a', '#6b8f7b', '#4f8f7a'], onBoard: true },
  { id: 'mat-orange', name: 'Powder-coated industrial orange', category: 'Industrial coatings', baseHex: '#e8630a', roughness: 0.55, metallic: 0, reflectance: 0.22, transmission: 0,
    description: 'Semi-gloss polyester powder coat with fine orange-peel texture. The Aardvark Imaging primary accent.',
    lightingNotes: 'Highly saturated; red channel clips first under warm light. Under 2700K the coating approaches red-orange.',
    productionNotes: 'Orange lies outside many CMYK gamuts at this chroma. Specify a spot colour for brand-critical reproduction.',
    swatches: ['#f28a3c', '#e8630a', '#b94a05', '#7a3003'], onBoard: true },
  { id: 'mat-steel', name: 'Graphite-painted steel', category: 'Painted surfaces', baseHex: '#3a3f44', roughness: 0.5, metallic: 0.25, reflectance: 0.10, transmission: 0,
    description: 'Dark satin enamel on rolled steel plate with a vertical panel seam.',
    lightingNotes: 'Low albedo means exposure dominates. Edge highlights along seams carry most of the perceived form.',
    productionNotes: 'Shadow detail lives below code value 60. Check for clipping in the blacks before grading.',
    swatches: ['#5b6167', '#3a3f44', '#25292d', '#15181a'], onBoard: true },
  { id: 'mat-sand', name: 'Warm sandstone', category: 'Stone', baseHex: '#c8ad86', roughness: 0.92, metallic: 0, reflectance: 0.35, transmission: 0,
    description: 'Bedded sedimentary stone with horizontal banding and fine grain.',
    lightingNotes: 'Strongly diffuse; colour temperature of the source dominates its appearance. Beautiful under 2700K, dull under cool light.',
    productionNotes: 'Low chroma but hue-critical — small hue shifts read as “wrong stone”. Compare in OKLCh.',
    swatches: ['#dcc7a4', '#c8ad86', '#a98d68', '#836a4b'], onBoard: true },
  { id: 'mat-glass', name: 'Frosted glass', category: 'Glass', baseHex: '#c9d6d8', roughness: 0.7, metallic: 0, reflectance: 0.08, transmission: 0.55, 
    description: 'Acid-etched float glass with a translucent, diffusing surface.',
    lightingNotes: 'Appearance is dominated by what is behind it. Backlighting raises the whole surface; front light shows the etched texture.',
    productionNotes: 'Represent transmission with alpha where the deliverable is layered; otherwise composite against a defined background.',
    swatches: ['#e2ecee', '#c9d6d8', '#9fb2b6', '#6e8388'], onBoard: true },
  { id: 'mat-poly', name: 'Black polymer', category: 'Plastics', baseHex: '#1a1b1d', roughness: 0.45, metallic: 0, reflectance: 0.04, transmission: 0,
    description: 'Glass-filled nylon moulding with a light texture. Low albedo, broad soft specular.',
    lightingNotes: 'Almost all visible information is specular. Add a fill or gradient reflector or the surface disappears.',
    productionNotes: 'Lift blacks by no more than 2–3 code values; crushed blacks read as holes, lifted blacks read as grey plastic.',
    swatches: ['#3a3c40', '#26282b', '#1a1b1d', '#0c0d0e'], onBoard: true },
  { id: 'mat-ceramic', name: 'White ceramic', category: 'Ceramics', baseHex: '#ecebe6', roughness: 0.08, metallic: 0, reflectance: 0.8, transmission: 0,
    description: 'Glazed tile with faint grout lines and a sharp glossy highlight.',
    lightingNotes: 'High albedo: expose to keep the body below clipping and let the specular reach white.',
    productionNotes: 'Watch for highlight clipping in the printed proof; paper white will be the limit.',
    swatches: ['#fbfaf6', '#ecebe6', '#d5d3cb', '#b6b3a8'], onBoard: true },
  { id: 'mat-timber', name: 'Dark timber', category: 'Timber', baseHex: '#4a3020', roughness: 0.65, metallic: 0, reflectance: 0.10, transmission: 0,
    description: 'Oiled hardwood with pronounced long grain.',
    lightingNotes: 'Warm light deepens the reds; cool light desaturates toward olive-brown.',
    productionNotes: 'Keep hue stable in shadows during grading — timber drifts green when blacks are lifted with a cool tint.',
    swatches: ['#7a5236', '#4a3020', '#33201a', '#1f130f'], onBoard: true },
  { id: 'mat-asphalt', name: 'Wet asphalt', category: 'Asphalt', baseHex: '#26282b', roughness: 0.2, metallic: 0, reflectance: 0.06, transmission: 0,
    description: 'Dark aggregate surface with standing water that mirrors the environment.',
    lightingNotes: 'Wet areas act as mirrors — the reflected light sources are the image. Dry areas are almost black.',
    productionNotes: 'Reflected highlights are the largest luminance range in the frame. Protect them in the display-preview.',
    swatches: ['#4a4d52', '#26282b', '#17181a', '#0a0a0b'], onBoard: true },
  { id: 'mat-safety', name: 'Industrial safety paint', category: 'Industrial coatings', baseHex: '#f0b400', roughness: 0.5, metallic: 0, reflectance: 0.5, transmission: 0,
    description: 'Safety-yellow floor coating with black hazard striping and edge wear.',
    lightingNotes: 'Yellow sits near the top of the sRGB luminance range for its hue and clips in the blue channel under warm light.',
    productionNotes: 'Regulated colour: verify with a spectrophotometer for safety-critical applications; screen values are not evidence of compliance.',
    swatches: ['#ffd23a', '#f0b400', '#b58500', '#141414'], onBoard: true },
  { id: 'mat-concrete', name: 'Blue-grey architectural concrete', category: 'Concrete', baseHex: '#808b94', roughness: 0.85, metallic: 0, reflectance: 0.3, transmission: 0,
    description: 'Board-formed cast concrete with tie-holes and surface pitting.',
    lightingNotes: 'Cool tint is subtle and easily lost under warm light. Raking light reveals form-work texture.',
    productionNotes: 'Neutral-ish material: use it as a grey reference only with a measured white balance.',
    swatches: ['#a6b0b8', '#808b94', '#5f6a72', '#3f484f'], onBoard: true },
  { id: 'mat-felt', name: 'Grey wool felt', category: 'Textiles', baseHex: '#8b8a86', roughness: 1, metallic: 0, reflectance: 0.25, transmission: 0,
    description: 'Dense wool acoustic felt. Almost perfectly diffuse with fibre-scale noise.',
    lightingNotes: 'Minimal specular. Useful as a diffuse mid-grey reference under mixed light.',
    productionNotes: 'Neutral reference only; wool fluoresces under UV-rich sources.',
    swatches: ['#a6a5a1', '#8b8a86', '#6a6966', '#494845'], onBoard: false },
  { id: 'mat-loam', name: 'Dark loam', category: 'Soil', baseHex: '#3b2c22', roughness: 1, metallic: 0, reflectance: 0.08, transmission: 0,
    description: 'Moist organic topsoil with coarse aggregate.',
    lightingNotes: 'Very low albedo; shadow-region colour separation matters more than highlights.',
    productionNotes: 'Grade brown-vs-green separation in the shadows; do not lift blacks uniformly.',
    swatches: ['#5a4536', '#3b2c22', '#291d16', '#160f0b'], onBoard: false },
  { id: 'mat-water', name: 'Shallow water', category: 'Water', baseHex: '#4f7f86', roughness: 0.05, metallic: 0, reflectance: 0.02, transmission: 0.8, 
    description: 'Clear shallow water over a pale substrate; colour comes from depth and sky reflection.',
    lightingNotes: 'Fresnel reflection increases sharply at grazing angles; the surface reads as sky colour at distance and substrate colour underfoot.',
    productionNotes: 'Keep water hue in a narrow OKLCh band across shots to avoid continuity breaks.',
    swatches: ['#8fb9be', '#4f7f86', '#2f5259', '#173035'], onBoard: false },
]

export const materialLinear = (m: Pick<MaterialRecord, 'baseHex'>): RGB => {
  const p = parseHex(m.baseHex)
  return srgbToLinear(p ? p.rgb : { r: 0.5, g: 0.5, b: 0.5 })
}

export const MATERIAL_BY_ID: Record<string, MaterialRecord> = Object.fromEntries(MATERIALS.map((m) => [m.id, m]))
