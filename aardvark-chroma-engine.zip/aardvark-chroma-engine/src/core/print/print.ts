import {
  type RGB, type CMYK, srgbToLinear, linearToSrgb, rgbToCmykNaive, cmykToRgbNaive, clamp01, linearToOklab, oklabToOklch, oklchToOklab, oklabToLinear,
} from '../colour/conversions'
import { maxChromaOklch, inGamut } from '../colour/gamut'

/**
 * Print-preview model. Everything here is an APPROXIMATION that stands in for a real ICC-based conversion.
 * The profiles are synthetic parameter sets, NOT certified profiles (no FOGRA/SWOP/GRACoL data is included),
 * and the output must never be represented as a validated proof.
 */

export type RenderingIntent = 'perceptual' | 'relative' | 'absolute' | 'saturation'
export const INTENTS: { id: RenderingIntent; label: string; note: string }[] = [
  { id: 'perceptual', label: 'Perceptual', note: 'Compresses all chroma to make room for out-of-gamut colours.' },
  { id: 'relative', label: 'Relative colorimetric', note: 'Preserves in-gamut colours; clips chroma at the gamut boundary. Paper white maps to white.' },
  { id: 'absolute', label: 'Absolute colorimetric', note: 'As relative, but the paper-white tint is reproduced (proof simulation).' },
  { id: 'saturation', label: 'Saturation', note: 'Keeps vividness; slightly boosts chroma up to the gamut limit.' },
]

export interface ProductionProfile {
  id: string
  name: string
  inkLimit: number       // total area coverage, %
  dotGain: number        // mid-tone dot gain, % (at 50 %)
  paperWhite: RGB        // linear RGB of paper
  blackL: number         // OKLab L of the darkest reproducible colour
  gamutScale: number     // fraction of sRGB max chroma reproducible (0..1.1)
  maxK: number
  category: 'print' | 'display'
  note: string
}

const pw = (hex: string) => {
  const v = parseInt(hex.slice(1), 16)
  return srgbToLinear({ r: ((v >> 16) & 255) / 255, g: ((v >> 8) & 255) / 255, b: (v & 255) / 255 })
}

export const PRODUCTION_PROFILES: ProductionProfile[] = [
  { id: 'matte-coated', name: 'Matte coated paper', inkLimit: 320, dotGain: 17, paperWhite: pw('#f4f2ec'), blackL: 0.2, gamutScale: 0.82, maxK: 100, category: 'print', note: 'Synthetic parameters for a typical matte-coated stock.' },
  { id: 'gloss-coated', name: 'Gloss coated paper', inkLimit: 330, dotGain: 14, paperWhite: pw('#f6f5f1'), blackL: 0.14, gamutScale: 0.9, maxK: 100, category: 'print', note: 'Highest gamut and density of the paper set.' },
  { id: 'uncoated', name: 'Uncoated paper', inkLimit: 280, dotGain: 22, paperWhite: pw('#efeadc'), blackL: 0.3, gamutScale: 0.66, maxK: 95, category: 'print', note: 'Warm paper white, strong dot gain, compressed gamut.' },
  { id: 'newspaper', name: 'Newspaper', inkLimit: 240, dotGain: 28, paperWhite: pw('#d9d5c6'), blackL: 0.36, gamutScale: 0.5, maxK: 90, category: 'print', note: 'Low ink limit and dark, yellowed paper.' },
  { id: 'fine-art', name: 'Fine-art paper', inkLimit: 300, dotGain: 15, paperWhite: pw('#f3efe3'), blackL: 0.24, gamutScale: 0.78, maxK: 100, category: 'print', note: 'Textured cotton-rag stock with a warm white.' },
  { id: 'label-stock', name: 'Industrial label stock', inkLimit: 260, dotGain: 20, paperWhite: pw('#f2f2f0'), blackL: 0.22, gamutScale: 0.72, maxK: 100, category: 'print', note: 'Semi-gloss label face stock; thermal-transfer-like limits.' },
  { id: 'synthetic-film', name: 'Synthetic film', inkLimit: 220, dotGain: 12, paperWhite: pw('#f8f8f8'), blackL: 0.3, gamutScale: 0.7, maxK: 100, category: 'print', note: 'Non-absorbent film; low ink limit, sharp dots.' },
  { id: 'display-output', name: 'Digital display output', inkLimit: 400, dotGain: 0, paperWhite: { r: 1, g: 1, b: 1 }, blackL: 0.0, gamutScale: 1.05, maxK: 100, category: 'display', note: 'No ink model: screen delivery. No CMYK reduction is applied.' },
]

export const PROFILE_BY_ID: Record<string, ProductionProfile> = Object.fromEntries(PRODUCTION_PROFILES.map((p) => [p.id, p]))

export interface ProofOptions { profile: ProductionProfile; intent: RenderingIntent; blackPointCompensation: boolean }

export interface ProofResult {
  cmyk: CMYK
  /** Approximate appearance of the printed result, linear sRGB primaries */
  preview: RGB
  /** Total area coverage after ink limiting, % */
  tac: number
  tacExceeded: boolean
  outOfGamut: boolean
  /** OKLab ΔE ×100 between input and preview */
  shift: number
}

const dotGainCurve = (t: number, gain: number) => clamp01(t + (gain / 100) * 4 * t * (1 - t))

export function proofColour(linear: RGB, opt: ProofOptions): ProofResult {
  const { profile: P, intent, blackPointCompensation } = opt
  const ok = oklabToOklch(linearToOklab(linear))
  const wasOOG = !inGamut(linear, 'srgb') || ok.c > maxChromaOklch(ok.l, ok.h) * P.gamutScale + 1e-4
  let L = ok.l, C = ok.c
  const limit = maxChromaOklch(clamp01(L), ok.h) * P.gamutScale
  switch (intent) {
    case 'perceptual': C = C * Math.min(1, P.gamutScale); break
    case 'relative': case 'absolute': C = Math.min(C, limit); break
    case 'saturation': C = Math.min(C * 1.06, limit * 1.02); break
  }
  if (P.blackL > 0) L = blackPointCompensation ? P.blackL + L * (1 - P.blackL) : Math.max(L, P.blackL)
  const mapped = oklabToLinear(oklchToOklab({ l: clamp01(L), c: C, h: ok.h }))
  const enc = linearToSrgb({ r: clamp01(mapped.r), g: clamp01(mapped.g), b: clamp01(mapped.b) })
  if (P.category === 'display') {
    const preview = srgbToLinear(enc)
    return { cmyk: { c: 0, m: 0, y: 0, k: 0 }, preview, tac: 0, tacExceeded: false, outOfGamut: wasOOG, shift: shiftOf(linear, preview) }
  }
  let cmyk = rgbToCmykNaive(enc)
  cmyk.k = Math.min(cmyk.k, P.maxK / 100)
  let tac = (cmyk.c + cmyk.m + cmyk.y + cmyk.k) * 100
  let exceeded = false
  if (tac > P.inkLimit) {
    exceeded = true
    const over = tac - P.inkLimit
    const cmySum = (cmyk.c + cmyk.m + cmyk.y) * 100
    const k = cmySum > 0 ? Math.max(0, (cmySum - over) / cmySum) : 1
    cmyk = { c: cmyk.c * k, m: cmyk.m * k, y: cmyk.y * k, k: cmyk.k }
    tac = P.inkLimit
  }
  const printed: CMYK = { c: dotGainCurve(cmyk.c, P.dotGain), m: dotGainCurve(cmyk.m, P.dotGain), y: dotGainCurve(cmyk.y, P.dotGain), k: dotGainCurve(cmyk.k, P.dotGain) }
  const ink = srgbToLinear(cmykToRgbNaive(printed))
  const paper = intent === 'absolute' ? P.paperWhite : { r: 1, g: 1, b: 1 }
  const preview = { r: ink.r * paper.r, g: ink.g * paper.g, b: ink.b * paper.b }
  // paper white always limits the highlights, even for relative intents (partial simulation)
  const pl = { r: 1 - (1 - P.paperWhite.r) * 0.35, g: 1 - (1 - P.paperWhite.g) * 0.35, b: 1 - (1 - P.paperWhite.b) * 0.35 }
  const out = intent === 'absolute' ? preview : { r: preview.r * pl.r, g: preview.g * pl.g, b: preview.b * pl.b }
  return { cmyk, preview: out, tac, tacExceeded: exceeded, outOfGamut: wasOOG, shift: shiftOf(linear, out) }
}

function shiftOf(a: RGB, b: RGB): number {
  const x = linearToOklab(a), y = linearToOklab(b)
  return Math.hypot(x.l - y.l, x.a - y.a, x.b - y.b) * 100
}

// ───────────── size / resolution calculators ─────────────

export type LengthUnit = 'mm' | 'cm' | 'in'
const MM: Record<LengthUnit, number> = { mm: 1, cm: 10, in: 25.4 }
export const toMm = (v: number, u: LengthUnit) => v * MM[u]
export const fromMm = (v: number, u: LengthUnit) => v / MM[u]

export interface PrintSizeInput { widthPx: number; heightPx: number; dpi: number }

export function printSizeMm(i: PrintSizeInput): { w: number; h: number } {
  return { w: (i.widthPx / i.dpi) * 25.4, h: (i.heightPx / i.dpi) * 25.4 }
}
export function effectiveDpi(widthPx: number, widthMm: number): number { return widthMm > 0 ? (widthPx / widthMm) * 25.4 : 0 }
export function requiredPixels(widthMm: number, heightMm: number, dpi: number): { w: number; h: number } {
  return { w: Math.ceil((widthMm / 25.4) * dpi), h: Math.ceil((heightMm / 25.4) * dpi) }
}

export function dpiRating(dpi: number): { label: string; ok: boolean } {
  if (dpi >= 300) return { label: 'Excellent (≥300 ppi)', ok: true }
  if (dpi >= 200) return { label: 'Good (200–299 ppi)', ok: true }
  if (dpi >= 150) return { label: 'Acceptable for large-format (150–199 ppi)', ok: true }
  return { label: 'Low (<150 ppi) — expect visible pixelation', ok: false }
}
