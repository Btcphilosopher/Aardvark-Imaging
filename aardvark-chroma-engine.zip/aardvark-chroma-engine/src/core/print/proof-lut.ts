import { srgbToLinear, linearToSrgb } from '../colour/conversions'
import { buildLut, type Lut3D } from '../lut/lut'
import { proofColour, type ProofOptions } from './print'

export interface ProofLut { lut: Lut3D; oog: Uint8Array; tac: Uint8Array }

const cache = new Map<string, ProofLut>()

/** Pre-computes the approximate proof transform on a 21³ lattice of encoded sRGB so per-pixel proofing stays cheap. */
export function buildProofLut(opt: ProofOptions, size = 21): ProofLut {
  const key = `${opt.profile.id}|${opt.intent}|${opt.blackPointCompensation}|${size}`
  const hit = cache.get(key)
  if (hit) return hit
  const n = size * size * size
  const oog = new Uint8Array(n), tac = new Uint8Array(n)
  let idx = 0
  const lut = buildLut((r, g, b) => {
    const res = proofColour(srgbToLinear({ r, g, b }), opt)
    oog[idx] = res.outOfGamut ? 1 : 0
    tac[idx] = res.tacExceeded ? 1 : 0
    idx++
    const e = linearToSrgb(res.preview)
    return [e.r, e.g, e.b]
  }, size, `Proof ${opt.profile.name}`)
  const out = { lut, oog, tac }
  cache.set(key, out)
  return out
}

export function nearestNode(size: number, r: number, g: number, b: number): number {
  const n = size - 1
  const ri = Math.round(Math.min(1, Math.max(0, r)) * n), gi = Math.round(Math.min(1, Math.max(0, g)) * n), bi = Math.round(Math.min(1, Math.max(0, b)) * n)
  return (bi * size + gi) * size + ri
}
