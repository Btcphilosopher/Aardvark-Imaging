import { smoothstep } from '../image/noise'

/**
 * SIMULATED grading pipeline. Operates on display-referred 8-bit sRGB source pixels, evaluated in linear light.
 * It is a browser-scale approximation of a primary-correction stage — it is NOT ACES, OCIO or a camera-native
 * scene-referred pipeline. Order of operations is fixed and documented in GRADE_PIPELINE_ORDER.
 */

export interface Wheel { r: number; g: number; b: number; m: number }

export interface GradeParams {
  exposure: number      // stops, −4..4
  temperature: number   // −100..100 (warm +)
  tint: number          // −100..100 (magenta +)
  offset: Wheel
  lift: Wheel
  gamma: Wheel
  gain: Wheel
  contrast: number      // −1..1
  pivot: number         // linear-light pivot, 0.05..0.5 (0.18 = scene mid grey)
  saturation: number    // −1..1
  vibrance: number      // −1..1
  hueShift: number      // degrees, −180..180
  highlights: number    // −1..1
  shadows: number       // −1..1
  whites: number        // −1..1
  blacks: number        // −1..1
  midtoneDetail: number // −1..1 (global midtone contrast — there is no local filter)
  channelR: number      // −1..1 per-channel gain
  channelG: number
  channelB: number
}

export const GRADE_PIPELINE_ORDER = [
  'Exposure (×2^stops, linear light)',
  'Temperature / tint (RGB multipliers — not a Bradford adaptation)',
  'Offset',
  'Gain → Lift → Gamma (per-channel, wheel colour + master)',
  'Contrast about pivot (power function)',
  'Tone regions: shadows, highlights, whites, blacks, midtone detail (luminance-weighted)',
  'Vibrance, saturation (about linear luma)',
  'Hue shift (rotation about the neutral axis in linear RGB — not perceptually uniform)',
  'Per-channel gain',
  'Clip to display range and encode to sRGB',
]

const zeroWheel = (): Wheel => ({ r: 0, g: 0, b: 0, m: 0 })

export function defaultGrade(): GradeParams {
  return {
    exposure: 0, temperature: 0, tint: 0,
    offset: zeroWheel(), lift: zeroWheel(), gamma: zeroWheel(), gain: zeroWheel(),
    contrast: 0, pivot: 0.18, saturation: 0, vibrance: 0, hueShift: 0,
    highlights: 0, shadows: 0, whites: 0, blacks: 0, midtoneDetail: 0,
    channelR: 0, channelG: 0, channelB: 0,
  }
}

export function isIdentityGrade(g: GradeParams): boolean {
  return JSON.stringify(g) === JSON.stringify(defaultGrade())
}

export interface CompiledGrade {
  identity: boolean
  expMul: number
  wb: [number, number, number]
  off: [number, number, number]
  lift: [number, number, number]
  gain: [number, number, number]
  gexp: [number, number, number]
  contrastExp: number
  pivot: number
  shadows: number; highlights: number; whites: number; blacks: number; mid: number
  sat: number; vib: number
  hue: [number, number, number, number, number, number, number, number, number] | null
  ch: [number, number, number]
}

const LR = 0.2126, LG = 0.7152, LB = 0.0722

export function compileGrade(g: GradeParams): CompiledGrade {
  const t = g.temperature / 100, ti = g.tint / 100
  const wheel = (w: Wheel, k: number): [number, number, number] => [(w.m + w.r) * k, (w.m + w.g) * k, (w.m + w.b) * k]
  const gm = wheel(g.gamma, 1)
  let hue: CompiledGrade['hue'] = null
  if (Math.abs(g.hueShift) > 1e-6) {
    const a = (g.hueShift * Math.PI) / 180
    const c = Math.cos(a), s = Math.sin(a), k = 1 / 3, q = Math.sqrt(1 / 3)
    hue = [
      c + (1 - c) * k, k * (1 - c) - q * s, k * (1 - c) + q * s,
      k * (1 - c) + q * s, c + (1 - c) * k, k * (1 - c) - q * s,
      k * (1 - c) - q * s, k * (1 - c) + q * s, c + (1 - c) * k,
    ]
  }
  const gain = wheel(g.gain, 0.5)
  return {
    identity: isIdentityGrade(g),
    expMul: Math.pow(2, g.exposure),
    wb: [1 + 0.3 * t + 0.0 * ti, 1 - 0.2 * ti, 1 - 0.3 * t + 0.1 * ti],
    off: wheel(g.offset, 0.1),
    lift: wheel(g.lift, 0.2),
    gain: [1 + gain[0], 1 + gain[1], 1 + gain[2]],
    gexp: [Math.pow(2, -gm[0]), Math.pow(2, -gm[1]), Math.pow(2, -gm[2])],
    contrastExp: 1 + g.contrast * 0.8,
    pivot: Math.max(0.01, g.pivot),
    shadows: g.shadows, highlights: g.highlights, whites: g.whites, blacks: g.blacks, mid: g.midtoneDetail,
    sat: 1 + g.saturation, vib: g.vibrance,
    hue,
    ch: [1 + g.channelR * 0.5, 1 + g.channelG * 0.5, 1 + g.channelB * 0.5],
  }
}

/** Apply a compiled grade to one linear-light pixel (in place on `o`). */
export function gradePixel(c: CompiledGrade, r: number, g: number, b: number, o: [number, number, number]): void {
  r *= c.expMul * c.wb[0]; g *= c.expMul * c.wb[1]; b *= c.expMul * c.wb[2]
  r += c.off[0]; g += c.off[1]; b += c.off[2]
  r = r * c.gain[0] + c.lift[0] * (1 - Math.min(1, Math.max(0, r)))
  g = g * c.gain[1] + c.lift[1] * (1 - Math.min(1, Math.max(0, g)))
  b = b * c.gain[2] + c.lift[2] * (1 - Math.min(1, Math.max(0, b)))
  if (r > 0 && c.gexp[0] !== 1) r = Math.pow(r, c.gexp[0])
  if (g > 0 && c.gexp[1] !== 1) g = Math.pow(g, c.gexp[1])
  if (b > 0 && c.gexp[2] !== 1) b = Math.pow(b, c.gexp[2])
  if (c.contrastExp !== 1) {
    const p = c.pivot
    if (r > 0) r = p * Math.pow(r / p, c.contrastExp)
    if (g > 0) g = p * Math.pow(g / p, c.contrastExp)
    if (b > 0) b = p * Math.pow(b / p, c.contrastExp)
  }
  if (c.shadows !== 0 || c.highlights !== 0 || c.whites !== 0 || c.blacks !== 0 || c.mid !== 0) {
    const y = Math.max(0, LR * r + LG * g + LB * b)
    let k = 1
    if (c.shadows !== 0) k *= Math.pow(2, c.shadows * 1.2 * (1 - smoothstep(0.0, 0.3, y)))
    if (c.highlights !== 0) k *= Math.pow(2, c.highlights * smoothstep(0.3, 1.0, y))
    if (c.whites !== 0) k *= Math.pow(2, c.whites * 0.8 * smoothstep(0.7, 1.3, y))
    if (c.mid !== 0) k *= 1 + c.mid * 0.6 * (y - 0.18) * Math.exp(-Math.pow((y - 0.18) / 0.25, 2)) * 4
    r *= k; g *= k; b *= k
    if (c.blacks !== 0) {
      const wb = 0.06 * c.blacks * (1 - smoothstep(0.0, 0.08, y))
      r += wb; g += wb; b += wb
    }
  }
  if (c.sat !== 1 || c.vib !== 0) {
    const y = LR * r + LG * g + LB * b
    let s = c.sat
    if (c.vib !== 0) {
      const mx = Math.max(r, g, b), mn = Math.min(r, g, b)
      const sm = mx > 1e-6 ? (mx - mn) / mx : 0
      s *= 1 + c.vib * (1 - sm) * (1 - sm)
    }
    r = y + (r - y) * s; g = y + (g - y) * s; b = y + (b - y) * s
  }
  if (c.hue) {
    const m = c.hue
    const nr = m[0] * r + m[1] * g + m[2] * b
    const ng = m[3] * r + m[4] * g + m[5] * b
    const nb = m[6] * r + m[7] * g + m[8] * b
    r = nr; g = ng; b = nb
  }
  o[0] = Math.max(0, r * c.ch[0]); o[1] = Math.max(0, g * c.ch[1]); o[2] = Math.max(0, b * c.ch[2])
}

export interface GradePreset { id: string; name: string; note: string; grade: () => GradeParams }

const withGrade = (patch: Partial<GradeParams>): GradeParams => ({ ...defaultGrade(), ...patch })

export const GRADE_PRESETS: GradePreset[] = [
  { id: 'neutral', name: 'Neutral (identity)', note: 'No correction.', grade: defaultGrade },
  { id: 'industrial-cinema', name: 'Industrial cinema', note: 'Cooler shadows, warm highlights, controlled contrast; protects the orange accent.',
    grade: () => withGrade({
      exposure: 0.1, contrast: 0.28, saturation: 0.06, vibrance: 0.15, shadows: 0.12, highlights: -0.1, blacks: -0.2,
      lift: { r: -0.08, g: 0, b: 0.12, m: 0 }, gain: { r: 0.1, g: 0.02, b: -0.08, m: 0 }, midtoneDetail: 0.25,
    }) },
  { id: 'daylight-neutral', name: 'Daylight neutral', note: 'Slight cool correction for warm-biased sources.',
    grade: () => withGrade({ temperature: -14, tint: 3, contrast: 0.08, exposure: 0.05 }) },
  { id: 'warm-interior', name: 'Warm interior', note: 'Tungsten-leaning warmth with lifted shadow separation.',
    grade: () => withGrade({ temperature: 28, tint: -4, contrast: 0.12, shadows: 0.18, gain: { r: 0.08, g: 0, b: -0.06, m: 0 } }) },
  { id: 'flat-log', name: 'Flat source', note: 'Low-contrast, low-saturation transform used to build the Source asset.',
    grade: () => withGrade({ contrast: -0.32, saturation: -0.22, blacks: 0.6, exposure: -0.15 }) },
]
