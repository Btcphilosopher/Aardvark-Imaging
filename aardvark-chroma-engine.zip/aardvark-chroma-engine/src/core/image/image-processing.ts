import { type ImageBuf, createImage, DECODE_LUT, encodeF, encode8, luma8 } from './image-model'
import { type GradeParams, compileGrade, gradePixel } from '../grading/grade'
import { type Lut3D, type LutBlend, type RGBTuple, sampleLut, blendLut } from '../lut/lut'
import { buildProofLut, nearestNode } from '../print/proof-lut'
import { PROFILE_BY_ID, type RenderingIntent } from '../print/print'

export type ViewMode = 'normal' | 'grayscale' | 'invert' | 'false-colour' | 'clipping' | 'gamut' | 'r' | 'g' | 'b' | 'alpha' | 'luma'

export const VIEW_MODES: { id: ViewMode; label: string; note: string }[] = [
  { id: 'normal', label: 'Normal', note: 'Image as processed' },
  { id: 'grayscale', label: 'Grayscale', note: 'Luminance-preserving grayscale' },
  { id: 'invert', label: 'Invert', note: 'Inverted encoded values' },
  { id: 'false-colour', label: 'False colour', note: 'Exposure bands by encoded luma' },
  { id: 'clipping', label: 'Clipping', note: 'Hatched red = highlights ≥253, hatched blue = shadows ≤2' },
  { id: 'gamut', label: 'Gamut warning', note: 'Hatched magenta = outside display/proof gamut' },
  { id: 'r', label: 'Red channel', note: 'Channel isolation' },
  { id: 'g', label: 'Green channel', note: 'Channel isolation' },
  { id: 'b', label: 'Blue channel', note: 'Channel isolation' },
  { id: 'alpha', label: 'Alpha', note: 'Alpha channel as grayscale' },
  { id: 'luma', label: 'Luma', note: 'Rec.709 luma of encoded values' },
]

export interface RenderParams {
  grade: GradeParams | null
  lut: { lut: Lut3D; strength: number; blend: LutBlend } | null
  view: ViewMode
  /** view-only exposure preview, stops (not baked into the grade) */
  exposureStops: number
  /** view-only saturation preview multiplier (1 = neutral) */
  saturationPreview: number
  proof: { profileId: string; intent: RenderingIntent; bpc: boolean } | null
}

export const defaultRender = (): RenderParams => ({ grade: null, lut: null, view: 'normal', exposureStops: 0, saturationPreview: 1, proof: null })
export const defaultRenderParams = defaultRender

export interface RenderStats {
  highlightClipPct: number
  shadowClipPct: number
  gamutFlaggedPct: number
  /** share of pixels outside the selected production profile's approximate gamut (0 when no proof is active) */
  proofOutOfGamutPct: number
  tacFlaggedPct: number
  ms: number
}

const FALSE_BANDS: { hi: number; rgb: [number, number, number] }[] = [
  { hi: 2, rgb: [96, 40, 140] }, { hi: 10, rgb: [30, 80, 180] }, { hi: 24, rgb: [26, 154, 168] },
  { hi: 43, rgb: [-1, -1, -1] }, { hi: 49, rgb: [70, 176, 80] }, { hi: 58, rgb: [-1, -1, -1] },
  { hi: 70, rgb: [232, 160, 180] }, { hi: 96, rgb: [-1, -1, -1] }, { hi: 99, rgb: [238, 210, 40] }, { hi: 101, rgb: [220, 30, 30] },
]

function falseColour(y8: number): [number, number, number] {
  const pct = (y8 / 255) * 100
  for (const b of FALSE_BANDS) if (pct < b.hi) return b.rgb[0] < 0 ? [y8 * 0.85, y8 * 0.85, y8 * 0.85] : b.rgb
  return [220, 30, 30]
}

/** Render one frame: grade → LUT → proof → view mode. Pure function of (src, params). */
export function renderImage(src: ImageBuf, p: RenderParams): { image: ImageBuf; stats: RenderStats } {
  const t0 = Date.now()
  const { width: w, height: h } = src
  const out = createImage(w, h)
  const compiled = p.grade ? compileGrade(p.grade) : null
  const useGrade = compiled && !compiled.identity
  const proof = p.proof && PROFILE_BY_ID[p.proof.profileId] ? buildProofLut({ profile: PROFILE_BY_ID[p.proof.profileId], intent: p.proof.intent, blackPointCompensation: p.proof.bpc }) : null
  const expMul = Math.pow(2, p.exposureStops)
  const satP = p.saturationPreview
  const needsPost = expMul !== 1 || satP !== 1
  const lin: [number, number, number] = [0, 0, 0]
  const tmp: RGBTuple = [0, 0, 0], tmp2: RGBTuple = [0, 0, 0], orig: RGBTuple = [0, 0, 0]
  let hi = 0, sh = 0, gam = 0, tacF = 0, proofOog = 0
  const n = w * h
  const view = p.view
  for (let px = 0; px < n; px++) {
    const i = px * 4
    let lr = DECODE_LUT[src.data[i]], lg = DECODE_LUT[src.data[i + 1]], lb = DECODE_LUT[src.data[i + 2]]
    let gamutFlag = false
    if (useGrade) {
      gradePixel(compiled, lr, lg, lb, lin)
      lr = lin[0]; lg = lin[1]; lb = lin[2]
      if (lr > 1.0005 || lg > 1.0005 || lb > 1.0005) gamutFlag = true
    }
    if (needsPost) {
      lr *= expMul; lg *= expMul; lb *= expMul
      if (satP !== 1) { const y = 0.2126 * lr + 0.7152 * lg + 0.0722 * lb; lr = y + (lr - y) * satP; lg = y + (lg - y) * satP; lb = y + (lb - y) * satP }
    }
    let er = encodeF(lr), eg = encodeF(lg), eb = encodeF(lb)
    if (p.lut) {
      orig[0] = er; orig[1] = eg; orig[2] = eb
      sampleLut(p.lut.lut, er, eg, eb, tmp)
      blendLut(orig, tmp, p.lut.strength, p.lut.blend, tmp2)
      if (tmp2[0] < -0.001 || tmp2[0] > 1.001 || tmp2[1] < -0.001 || tmp2[1] > 1.001 || tmp2[2] < -0.001 || tmp2[2] > 1.001) gamutFlag = true
      er = tmp2[0]; eg = tmp2[1]; eb = tmp2[2]
    }
    if (proof) {
      const node = nearestNode(proof.lut.size, er, eg, eb)
      if (proof.oog[node]) { gamutFlag = true; gam++; proofOog++ }
      if (proof.tac[node]) tacF++
      sampleLut(proof.lut, er, eg, eb, tmp)
      er = tmp[0]; eg = tmp[1]; eb = tmp[2]
    } else if (gamutFlag) gam++
    let R = Math.round(Math.min(1, Math.max(0, er)) * 255), G = Math.round(Math.min(1, Math.max(0, eg)) * 255), B = Math.round(Math.min(1, Math.max(0, eb)) * 255)
    const A = src.data[i + 3]
    const highClip = R >= 253 || G >= 253 || B >= 253
    const lowClip = R <= 2 && G <= 2 && B <= 2
    if (highClip) hi++
    if (lowClip) sh++
    const hatch = (((px % w) + Math.floor(px / w)) & 7) < 4
    switch (view) {
      case 'grayscale': { const y = encode8(0.2126 * DECODE_LUT[R] + 0.7152 * DECODE_LUT[G] + 0.0722 * DECODE_LUT[B]); R = G = B = y; break }
      case 'invert': R = 255 - R; G = 255 - G; B = 255 - B; break
      case 'false-colour': { const c = falseColour(luma8(R, G, B)); R = c[0]; G = c[1]; B = c[2]; break }
      case 'clipping':
        if (highClip) { if (hatch) { R = 235; G = 32; B = 32 } else { R = 120; G = 10; B = 10 } }
        else if (lowClip) { if (hatch) { R = 40; G = 110; B = 255 } else { R = 8; G = 30; B = 90 } }
        else { R = R * 0.7; G = G * 0.7; B = B * 0.7 }
        break
      case 'gamut':
        if (gamutFlag) { if (hatch) { R = 255; G = 0; B = 200 } else { R = 90; G = 0; B = 70 } }
        else { const y = luma8(R, G, B) * 0.55; R = G = B = y }
        break
      case 'r': G = B = R; break
      case 'g': R = B = G; break
      case 'b': R = G = B; break
      case 'alpha': R = G = B = A; break
      case 'luma': { const y = Math.round(luma8(R, G, B)); R = G = B = y; break }
    }
    out.data[i] = R; out.data[i + 1] = G; out.data[i + 2] = B; out.data[i + 3] = view === 'alpha' ? 255 : A
  }
  return { image: out, stats: { highlightClipPct: (hi / n) * 100, shadowClipPct: (sh / n) * 100, gamutFlaggedPct: (gam / n) * 100, proofOutOfGamutPct: (proofOog / n) * 100, tacFlaggedPct: (tacF / n) * 100, ms: Date.now() - t0 } }
}

/** |a − b| per channel, amplified. Images must be the same size. */
export function differenceImage(a: ImageBuf, b: ImageBuf, gain = 4): ImageBuf {
  const w = Math.min(a.width, b.width), h = Math.min(a.height, b.height)
  const out = createImage(w, h)
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const ia = (y * a.width + x) * 4, ib = (y * b.width + x) * 4, o = (y * w + x) * 4
    out.data[o] = Math.min(255, Math.abs(a.data[ia] - b.data[ib]) * gain)
    out.data[o + 1] = Math.min(255, Math.abs(a.data[ia + 1] - b.data[ib + 1]) * gain)
    out.data[o + 2] = Math.min(255, Math.abs(a.data[ia + 2] - b.data[ib + 2]) * gain)
    out.data[o + 3] = 255
  }
  return out
}
