import { type ImageBuf, type Rect, luma8 } from './image-model'

export interface Histograms {
  r: Uint32Array
  g: Uint32Array
  b: Uint32Array
  /** Rec.709 luma of encoded values (display-referred), 256 bins */
  luma: Uint32Array
  count: number
}

export function computeHistograms(img: ImageBuf, rect?: Rect): Histograms {
  const r = new Uint32Array(256), g = new Uint32Array(256), b = new Uint32Array(256), l = new Uint32Array(256)
  const x0 = rect?.x ?? 0, y0 = rect?.y ?? 0, x1 = rect ? rect.x + rect.w : img.width, y1 = rect ? rect.y + rect.h : img.height
  let count = 0
  for (let y = y0; y < y1; y++) {
    let i = (y * img.width + x0) * 4
    for (let x = x0; x < x1; x++, i += 4) {
      const R = img.data[i], G = img.data[i + 1], B = img.data[i + 2]
      r[R]++; g[G]++; b[B]++; l[Math.round(luma8(R, G, B))]++
      count++
    }
  }
  return { r, g, b, luma: l, count }
}

export function percentileBin(hist: Uint32Array, p: number): number {
  let total = 0
  for (let i = 0; i < hist.length; i++) total += hist[i]
  const target = total * p
  let acc = 0
  for (let i = 0; i < hist.length; i++) { acc += hist[i]; if (acc >= target) return i }
  return hist.length - 1
}

export function histogramMean(hist: Uint32Array): number {
  let s = 0, n = 0
  for (let i = 0; i < hist.length; i++) { s += i * hist[i]; n += hist[i] }
  return n ? s / n : 0
}

export function entropyBits(hist: Uint32Array): number {
  let n = 0
  for (let i = 0; i < hist.length; i++) n += hist[i]
  if (!n) return 0
  let e = 0
  for (let i = 0; i < hist.length; i++) if (hist[i]) { const p = hist[i] / n; e -= p * Math.log2(p) }
  return e
}

export type ScopeChannel = 'luma' | 'r' | 'g' | 'b'

export interface Waveform { cols: number; rows: number; data: Uint32Array; max: number }

/** Waveform: for each image column bucket, a histogram of the chosen channel. */
export function computeWaveform(img: ImageBuf, cols = 320, channel: ScopeChannel = 'luma'): Waveform {
  const data = new Uint32Array(cols * 256)
  const step = Math.max(1, Math.floor(img.height / 320))
  for (let y = 0; y < img.height; y += step) {
    for (let x = 0; x < img.width; x++) {
      const i = (y * img.width + x) * 4
      const v = channel === 'r' ? img.data[i] : channel === 'g' ? img.data[i + 1] : channel === 'b' ? img.data[i + 2] : Math.round(luma8(img.data[i], img.data[i + 1], img.data[i + 2]))
      data[Math.min(cols - 1, Math.floor((x / img.width) * cols)) * 256 + v]++
    }
  }
  let max = 0
  for (let i = 0; i < data.length; i++) if (data[i] > max) max = data[i]
  return { cols, rows: 256, data, max }
}

export interface Vectorscope { size: number; data: Uint32Array; max: number }

/** Vectorscope-style plot in Rec.709 Cb/Cr of the encoded image. Axes are chroma, not hue-angle-calibrated graticule targets. */
export function computeVectorscope(img: ImageBuf, size = 160): Vectorscope {
  const data = new Uint32Array(size * size)
  const step = Math.max(1, Math.floor(Math.sqrt((img.width * img.height) / 90000)))
  for (let y = 0; y < img.height; y += step) {
    for (let x = 0; x < img.width; x += step) {
      const i = (y * img.width + x) * 4
      const R = img.data[i] / 255, G = img.data[i + 1] / 255, B = img.data[i + 2] / 255
      const Y = 0.2126 * R + 0.7152 * G + 0.0722 * B
      const cb = (B - Y) / 1.8556, cr = (R - Y) / 1.5748
      const px = Math.min(size - 1, Math.max(0, Math.floor((cb + 0.5) * size)))
      const py = Math.min(size - 1, Math.max(0, Math.floor((0.5 - cr) * size)))
      data[py * size + px]++
    }
  }
  let max = 0
  for (let i = 0; i < data.length; i++) if (data[i] > max) max = data[i]
  return { size, data, max }
}
