import { type ImageBuf, createImage, encode8 } from './image-model'
import { fbm, hash2, smoothstep, mix } from './noise'
import { MATERIALS, materialLinear } from '../materials/materials'
import { srgbToLinear, parseHex, type RGB } from '../colour/conversions'

/**
 * Deterministic procedural imagery. Every pixel is a pure function of (x, y, seed): identical output on every run.
 * These are SYNTHETIC textures for testing colour tools — they are not photographs or physically based renders.
 */

type Out = [number, number, number]
const lin = (hex: string): RGB => srgbToLinear((parseHex(hex) ?? { rgb: { r: 0.5, g: 0.5, b: 0.5 } }).rgb)

const LINEAR: Record<string, RGB> = Object.fromEntries(MATERIALS.map((m) => [m.id, materialLinear(m)]))
const CU_METAL = lin('#b0653a')
const VERDIGRIS = lin('#4f8f7a')

function set(o: Out, r: number, g: number, b: number) { o[0] = r; o[1] = g; o[2] = b }
function scale(o: Out, c: RGB, k: number) { o[0] = c.r * k; o[1] = c.g * k; o[2] = c.b * k }

/** u, v ∈ [0,1] inside the panel; px, py are panel pixel coordinates; w,h panel size in pixels. */
function shadeMaterial(id: string, u: number, v: number, px: number, py: number, w: number, h: number, seed: number, o: Out): void {
  const B = LINEAR[id]
  const aspect = w / h
  switch (id) {
    case 'mat-alu': {
      const streak = fbm(u * 3, v * 260, seed, 3)
      const fine = hash2(px, py, seed) * 0.04
      const sheen = Math.exp(-Math.pow((u - 0.35 - 0.25 * v) / 0.16, 2)) * 0.32
      const k = 0.78 + 0.34 * streak + fine
      set(o, B.r * k + sheen, B.g * k + sheen, B.b * k + sheen * 1.02)
      break
    }
    case 'mat-cu': {
      const m = smoothstep(0.42, 0.62, fbm(u * 5 * aspect, v * 5, seed, 5) + 0.25 * (fbm(u * 22, v * 22, seed + 9, 3) - 0.5))
      const grain = 0.82 + 0.3 * fbm(u * 60, v * 60, seed + 3, 3)
      const r = mix(CU_METAL.r, VERDIGRIS.r, m), g = mix(CU_METAL.g, VERDIGRIS.g, m), b = mix(CU_METAL.b, VERDIGRIS.b, m)
      set(o, r * grain, g * grain, b * grain)
      break
    }
    case 'mat-orange': {
      const peel = 0.93 + 0.1 * fbm(u * 90, v * 90, seed, 2)
      const spec = Math.exp(-(Math.pow(u - 0.3, 2) + Math.pow(v - 0.25, 2)) / 0.03) * 0.28
      set(o, B.r * peel + spec, B.g * peel + spec * 0.9, B.b * peel + spec * 0.85)
      break
    }
    case 'mat-steel': {
      const grain = 0.88 + 0.16 * fbm(u * 70, v * 70, seed, 3)
      const seam = Math.abs(u - 0.5) * w
      let k = grain * (0.9 + 0.18 * (1 - v))
      let add = 0
      if (seam < 1.2) k *= 0.35
      else if (seam < 2.4) add = 0.06
      scale(o, B, k); o[0] += add; o[1] += add; o[2] += add
      break
    }
    case 'mat-sand': {
      const warp = fbm(u * 2, v * 3, seed + 7, 3) * 0.9
      const band = fbm(u * 3, v * 16 + warp * 3, seed, 4)
      const k = 0.68 + 0.5 * band
      const speck = hash2(px, py, seed + 5) > 0.985 ? 0.55 : 1
      const warm = 1 + 0.06 * (band - 0.5)
      set(o, B.r * k * speck * warm, B.g * k * speck, B.b * k * speck / warm)
      break
    }
    case 'mat-glass': {
      const blob = fbm(u * 3.5, v * 3.5, seed, 4)
      const frost = 0.96 + 0.06 * hash2(px, py, seed)
      const glow = 0.85 + 0.35 * (1 - v)
      const k = (0.62 + 0.55 * blob) * frost * glow
      set(o, B.r * k, B.g * k * 1.01, B.b * k * 1.02)
      break
    }
    case 'mat-poly': {
      const tex = 0.75 + 0.5 * fbm(u * 110, v * 110, seed, 2)
      const band = smoothstep(0.0, 0.5, 0.5 - Math.abs(u * 0.9 + v * 0.55 - 0.72)) * 0.11
      scale(o, B, tex); o[0] += band; o[1] += band; o[2] += band * 1.05
      break
    }
    case 'mat-ceramic': {
      const gx = Math.abs((u * 2) % 1 - 0.5), gy = Math.abs((v * 2) % 1 - 0.5)
      const grout = (0.5 - Math.min(gx, gy)) * Math.min(w, h) / 2 < 1.6 ? 0.62 : 1
      const spec = Math.exp(-(Math.pow(u - 0.3, 2) * 4 + Math.pow(v - 0.22, 2) * 3) / 0.05) * 0.5
      const glaze = 0.97 + 0.03 * fbm(u * 8, v * 8, seed, 2)
      scale(o, B, glaze * grout); o[0] += spec * grout; o[1] += spec * grout; o[2] += spec * grout
      break
    }
    case 'mat-timber': {
      const warp = fbm(u * 1.2, v * 3, seed, 3) * 4
      const ring = 0.5 + 0.5 * Math.sin((v * 22 + warp) * Math.PI)
      const fibre = fbm(u * 6, v * 180, seed + 2, 3)
      const k = 0.62 + 0.42 * ring * ring + 0.35 * (fibre - 0.5)
      set(o, B.r * k * 1.25, B.g * k, B.b * k * 0.8)
      break
    }
    case 'mat-asphalt': {
      const agg = 0.7 + 0.7 * hash2(px, py, seed) * hash2(px >> 1, py >> 1, seed + 1)
      const puddleField = fbm(u * 2.4 * aspect, v * 2.6, seed + 4, 4)
      const wet = smoothstep(0.52, 0.6, puddleField)
      const sky = 0.05 + 0.1 * (1 - v)
      const glow = Math.exp(-Math.pow((u - 0.72) / 0.2, 2)) * 0.5
      const rr = B.r * agg, gg = B.g * agg, bb = B.b * agg
      set(o, mix(rr, sky * 0.8 + glow * 0.55, wet), mix(gg, sky * 0.9 + glow * 0.22, wet), mix(bb, sky * 1.15 + glow * 0.05, wet))
      break
    }
    case 'mat-safety': {
      const d = (px + py) / 34
      const stripe = d - Math.floor(d) < 0.5
      const wear = fbm(u * 14, v * 14, seed, 4)
      const chip = wear > 0.66
      if (stripe) {
        const k = chip ? 0.5 : 0.09
        set(o, k * 0.7, k * 0.7, k * 0.7)
      } else {
        const k = (chip ? 0.5 : 1) * (0.94 + 0.08 * hash2(px, py, seed))
        set(o, B.r * k, B.g * k, B.b * k)
      }
      break
    }
    case 'mat-concrete': {
      const base = 0.78 + 0.32 * fbm(u * 9, v * 9, seed, 5)
      const board = Math.abs((v * 4) % 1 - 0.5) > 0.492 ? 0.7 : 1
      const pit = hash2(px >> 1, py >> 1, seed + 8) > 0.988 ? 0.5 : 1
      let tie = 1
      for (const cx of [0.28, 0.72]) {
        const dx = (u - cx) * w, dy = (v - 0.5) * h
        const r = Math.hypot(dx, dy)
        if (r < 8) tie = 0.25
        else if (r < 10) tie = 1.18
      }
      const k = base * board * pit * tie
      set(o, B.r * k, B.g * k, B.b * k)
      break
    }
    default:
      set(o, B.r, B.g, B.b)
  }
}

const BOARD_ROWS: { weight: number; cells: { id: string; w: number }[] }[] = [
  { weight: 0.32, cells: [{ id: 'mat-alu', w: 3.0 }, { id: 'mat-cu', w: 2.2 }, { id: 'mat-orange', w: 2.0 }, { id: 'mat-steel', w: 2.3 }] },
  { weight: 0.36, cells: [{ id: 'mat-sand', w: 2.7 }, { id: 'mat-glass', w: 1.9 }, { id: 'mat-poly', w: 1.9 }, { id: 'mat-ceramic', w: 3.1 }] },
  { weight: 0.32, cells: [{ id: 'mat-timber', w: 2.5 }, { id: 'mat-asphalt', w: 2.5 }, { id: 'mat-safety', w: 2.0 }, { id: 'mat-concrete', w: 2.6 }] },
]

export interface BoardLayoutCell { id: string; x: number; y: number; w: number; h: number }

export function boardLayout(width: number, height: number): { cells: BoardLayoutCell[]; strip: { x: number; y: number; w: number; h: number } } {
  const stripH = Math.round(height * 0.075)
  const boardH = height - stripH
  const gap = 6
  const cells: BoardLayoutCell[] = []
  const totalWeight = BOARD_ROWS.reduce((s, r) => s + r.weight, 0)
  let y = gap
  const usableH = boardH - gap * (BOARD_ROWS.length + 1)
  BOARD_ROWS.forEach((row, ri) => {
    const rh = Math.round((usableH * row.weight) / totalWeight)
    const totalW = row.cells.reduce((s, c) => s + c.w, 0)
    const usableW = width - gap * (row.cells.length + 1)
    let x = gap
    row.cells.forEach((c, ci) => {
      const cw = ci === row.cells.length - 1 ? width - gap - x : Math.round((usableW * c.w) / totalW)
      const ch = ri === BOARD_ROWS.length - 1 ? boardH - gap - y : rh
      cells.push({ id: c.id, x, y, w: cw, h: ch })
      x += cw + gap
    })
    y += rh + gap
  })
  return { cells, strip: { x: 0, y: boardH, w: width, h: stripH } }
}

const STRIP_CHIPS = ['#e8630a', '#f0b400', '#3f8f7b', '#33475b', '#c8ad86', '#d1281c']

/** The Aardvark Imaging material board: 12 procedural surfaces lit by a warm key from the upper left, plus a neutral ramp and colour chips. */
export function generateMaterialBoard(width = 960, height = 640, seed = 20140): ImageBuf {
  const img = createImage(width, height)
  const { cells, strip } = boardLayout(width, height)
  const o: Out = [0, 0, 0]
  const bg: Out = [0.012, 0.013, 0.014]
  // background
  for (let i = 0; i < img.data.length; i += 4) {
    img.data[i] = encode8(bg[0]); img.data[i + 1] = encode8(bg[1]); img.data[i + 2] = encode8(bg[2]); img.data[i + 3] = 255
  }
  for (const cell of cells) {
    const sd = seed + cell.id.length * 31 + cell.id.charCodeAt(4) * 7
    for (let y = 0; y < cell.h; y++) {
      for (let x = 0; x < cell.w; x++) {
        const u = (x + 0.5) / cell.w, v = (y + 0.5) / cell.h
        shadeMaterial(cell.id, u, v, x, y, cell.w, cell.h, sd, o)
        // global light: warm key upper-left, gentle falloff, vignette
        const gx = (cell.x + x) / width, gy = (cell.y + y) / height
        const key = 1.08 - 0.42 * gx - 0.16 * gy
        const vig = 1 - 0.28 * Math.pow(Math.hypot(gx - 0.42, gy - 0.4) * 1.25, 2)
        const kk = key * vig
        // bevel: 1px highlight top/left, shadow bottom/right
        let edge = 1
        if (x === 0 || y === 0) edge = 1.16
        else if (x === cell.w - 1 || y === cell.h - 1) edge = 0.8
        const r = o[0] * kk * 1.03 * edge, g = o[1] * kk * edge, b = o[2] * kk * 0.94 * edge
        const idx = ((cell.y + y) * width + cell.x + x) * 4
        img.data[idx] = encode8(r); img.data[idx + 1] = encode8(g); img.data[idx + 2] = encode8(b)
      }
    }
  }
  drawStrip(img, strip)
  return img
}

function drawStrip(img: ImageBuf, s: { x: number; y: number; w: number; h: number }) {
  const rampW = Math.round(s.w * 0.6)
  const steps = 16
  const chipCount = STRIP_CHIPS.length
  for (let y = s.y; y < s.y + s.h; y++) {
    for (let x = 0; x < s.w; x++) {
      let r: number, g: number, b: number
      if (x < rampW) {
        const step = Math.min(steps - 1, Math.floor((x / rampW) * steps))
        const v = Math.round((step / (steps - 1)) * 255)
        r = g = b = v
      } else {
        const ci = Math.min(chipCount - 1, Math.floor(((x - rampW) / (s.w - rampW)) * chipCount))
        const p = parseHex(STRIP_CHIPS[ci])!
        r = Math.round(p.rgb.r * 255); g = Math.round(p.rgb.g * 255); b = Math.round(p.rgb.b * 255)
      }
      const i = (y * img.width + x) * 4
      img.data[i] = r; img.data[i + 1] = g; img.data[i + 2] = b; img.data[i + 3] = 255
    }
  }
}

/** Architectural exterior: sky gradient, concrete facade, glazing grid and warm interior spill. Used by the Architectural Film Grade project. */
export function generateArchitecturalScene(width = 960, height = 640, seed = 7731): ImageBuf {
  const img = createImage(width, height)
  const concrete = LINEAR['mat-concrete'], glass = lin('#1d2a33'), warm = lin('#e8a24a')
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const u = x / width, v = y / height
      let r: number, g: number, b: number
      const horizon = 0.72
      if (v < 0.16 + 0.1 * (1 - u)) {
        const t = v / 0.26
        r = mix(0.1, 0.55, t) * 0.8; g = mix(0.22, 0.6, t) * 0.9; b = mix(0.5, 0.75, t)
        const cloud = smoothstep(0.55, 0.75, fbm(u * 4, v * 9, seed, 5))
        r = mix(r, 0.8, cloud * 0.7); g = mix(g, 0.82, cloud * 0.7); b = mix(b, 0.86, cloud * 0.7)
      } else if (v < horizon) {
        const k = 0.75 + 0.5 * fbm(u * 8, v * 8, seed + 2, 5)
        const board = Math.abs((v * 22) % 1 - 0.5) > 0.485 ? 0.75 : 1
        r = concrete.r * k * board; g = concrete.g * k * board; b = concrete.b * k * board
        const col = Math.floor(u * 8), row = Math.floor((v - 0.2) * 9)
        const lx = u * 8 - col, ly = (v - 0.2) * 9 - row
        if (v > 0.24 && v < 0.68 && lx > 0.18 && lx < 0.82 && ly > 0.12 && ly < 0.88) {
          const lit = hash2(col, row, seed) > 0.55
          const refl = 0.15 * (1 - ly)
          if (lit) { const w2 = 0.5 + 0.9 * hash2(col + 3, row + 9, seed); r = warm.r * w2; g = warm.g * w2 * 0.95; b = warm.b * w2 * 0.7 }
          else { r = glass.r + refl * 0.3; g = glass.g + refl * 0.4; b = glass.b + refl * 0.6 }
        }
      } else {
        const wet = 0.5 + 0.5 * fbm(u * 5, v * 20, seed + 4, 3)
        const refl = Math.max(0, 1 - (v - horizon) * 5) * 0.4
        r = 0.02 + refl * 0.5 * wet; g = 0.022 + refl * 0.38 * wet; b = 0.026 + refl * 0.3 * wet
      }
      const vig = 1 - 0.25 * Math.pow(Math.hypot(u - 0.5, v - 0.5) * 1.3, 2)
      const i = (y * width + x) * 4
      img.data[i] = encode8(r * vig); img.data[i + 1] = encode8(g * vig); img.data[i + 2] = encode8(b * vig); img.data[i + 3] = 255
    }
  }
  return img
}

/** Landscape-style scene for the Photographic Colour Archive: sky, ridges, water with a warm horizon. */
export function generatePhotoScene(width = 960, height = 640, seed = 4417): ImageBuf {
  const img = createImage(width, height)
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const u = x / width, v = y / height
      let r: number, g: number, b: number
      const ridge = 0.5 + 0.12 * fbm(u * 3, 0.3, seed, 5) + 0.05 * fbm(u * 14, 0.7, seed + 1, 3)
      const glow = Math.exp(-Math.pow((u - 0.68) / 0.22, 2) - Math.pow((v - 0.48) / 0.16, 2))
      if (v < ridge) {
        const t = v / ridge
        r = mix(0.06, 0.62, t * t) + glow * 0.5; g = mix(0.12, 0.34, t * t) + glow * 0.22; b = mix(0.32, 0.28, t) + glow * 0.05
        const cloud = smoothstep(0.5, 0.75, fbm(u * 5, v * 12, seed + 3, 5))
        r += cloud * 0.12; g += cloud * 0.07
      } else if (v < 0.68) {
        const d = (v - ridge) / (0.68 - ridge)
        const tex = 0.6 + 0.6 * fbm(u * 24, v * 40, seed + 5, 4)
        r = mix(0.035, 0.02, d) * tex; g = mix(0.04, 0.03, d) * tex; b = mix(0.05, 0.035, d) * tex
      } else {
        const d = (v - 0.68) / 0.32
        const ripple = 0.85 + 0.3 * fbm(u * 6, v * 90, seed + 6, 3)
        const g2 = Math.exp(-Math.pow((u - 0.68) / (0.05 + d * 0.18), 2)) * (1 - d * 0.6)
        r = (0.03 + g2 * 0.7) * ripple; g = (0.05 + g2 * 0.28) * ripple; b = (0.09 + g2 * 0.06) * ripple
      }
      const i = (y * width + x) * 4
      img.data[i] = encode8(r); img.data[i + 1] = encode8(g); img.data[i + 2] = encode8(b); img.data[i + 3] = 255
    }
  }
  return img
}

export type GeneratorId = 'material-board' | 'architectural-scene' | 'photo-scene'

export function generateBase(id: GeneratorId, width: number, height: number): ImageBuf {
  switch (id) {
    case 'material-board': return generateMaterialBoard(width, height)
    case 'architectural-scene': return generateArchitecturalScene(width, height)
    case 'photo-scene': return generatePhotoScene(width, height)
  }
}
