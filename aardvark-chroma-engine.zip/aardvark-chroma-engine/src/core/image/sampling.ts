import { type ImageBuf, type Rect, DECODE_LUT, clampRect, encode8 } from './image-model'
import { makeRecord, type ColourRecord } from '../colour/colour-model'
import { type RGB, rgbToHex, linearToSrgb, linearToOklab, oklabToOklch } from '../colour/conversions'
import { deltaE2000Linear } from '../colour/contrast'

export interface PixelSample {
  x: number
  y: number
  alpha: number
  record: ColourRecord
}

/** Sample exactly one pixel of the given image buffer. Returns null outside the image. */
export function samplePixel(img: ImageBuf, x: number, y: number, name?: string): PixelSample | null {
  if (x < 0 || y < 0 || x >= img.width || y >= img.height) return null
  const i = (y * img.width + x) * 4
  const rec = makeRecord({
    linear: { r: DECODE_LUT[img.data[i]], g: DECODE_LUT[img.data[i + 1]], b: DECODE_LUT[img.data[i + 2]] },
    alpha: img.data[i + 3] / 255,
    name: name ?? `px ${x},${y}`,
    source: `pixel(${x},${y})`,
  })
  return { x, y, alpha: img.data[i + 3] / 255, record: rec }
}

export interface RegionStat {
  rect: Rect
  row: number
  col: number
  meanLinear: RGB
  meanHex: string
  medianHex: string
  medianLinear: RGB
  luminance: number
  chroma: number
  /** degrees, or null if the region is effectively neutral */
  dominantHue: number | null
  /** mean CIEDE2000 between this region's mean and its 4-neighbours' means */
  contrastAdjacent: number
  pixelCount: number
}

function median8(hist: Uint32Array, n: number): number {
  let acc = 0
  for (let i = 0; i < 256; i++) { acc += hist[i]; if (acc >= n / 2) return i }
  return 255
}

/** Mean (linear light), median (per-channel, encoded) and hue statistics for a rectangular region. */
export function regionStat(img: ImageBuf, rectIn: Rect, row = 0, col = 0): RegionStat {
  const rect = clampRect(rectIn, img)
  let r = 0, g = 0, b = 0, n = 0
  const hr = new Uint32Array(256), hg = new Uint32Array(256), hb = new Uint32Array(256)
  const hue = new Float64Array(36)
  for (let y = rect.y; y < rect.y + rect.h; y++) {
    let i = (y * img.width + rect.x) * 4
    for (let x = 0; x < rect.w; x++, i += 4) {
      const R = img.data[i], G = img.data[i + 1], B = img.data[i + 2]
      r += DECODE_LUT[R]; g += DECODE_LUT[G]; b += DECODE_LUT[B]; n++
      hr[R]++; hg[G]++; hb[B]++
    }
  }
  const mean: RGB = { r: r / n, g: g / n, b: b / n }
  // hue histogram on a bounded sample
  const stride = Math.max(1, Math.floor(Math.sqrt((rect.w * rect.h) / 4000)))
  let chromaSum = 0, cn = 0
  for (let y = rect.y; y < rect.y + rect.h; y += stride) for (let x = rect.x; x < rect.x + rect.w; x += stride) {
    const i = (y * img.width + x) * 4
    const ok = oklabToOklch(linearToOklab({ r: DECODE_LUT[img.data[i]], g: DECODE_LUT[img.data[i + 1]], b: DECODE_LUT[img.data[i + 2]] }))
    hue[Math.min(35, Math.floor(ok.h / 10))] += ok.c
    chromaSum += ok.c; cn++
  }
  let best = 0
  for (let i = 1; i < 36; i++) if (hue[i] > hue[best]) best = i
  const meanChromaOk = chromaSum / Math.max(1, cn)
  const rec = makeRecord({ linear: mean })
  const med: RGB = { r: DECODE_LUT[median8(hr, n)], g: DECODE_LUT[median8(hg, n)], b: DECODE_LUT[median8(hb, n)] }
  return {
    rect, row, col, meanLinear: mean, meanHex: rec.hex,
    medianHex: rgbToHex(linearToSrgb(med)), medianLinear: med,
    luminance: rec.luminance, chroma: rec.chroma,
    dominantHue: meanChromaOk < 0.012 ? null : best * 10 + 5,
    contrastAdjacent: 0, pixelCount: n,
  }
}

/** Divide the image into rows×cols regions and compute per-region statistics with adjacent-region contrast. */
export function regionGrid(img: ImageBuf, cols: number, rows: number): RegionStat[] {
  const out: RegionStat[] = []
  for (let ry = 0; ry < rows; ry++) for (let cx = 0; cx < cols; cx++) {
    const x0 = Math.floor((cx * img.width) / cols), x1 = Math.floor(((cx + 1) * img.width) / cols)
    const y0 = Math.floor((ry * img.height) / rows), y1 = Math.floor(((ry + 1) * img.height) / rows)
    out.push(regionStat(img, { x: x0, y: y0, w: x1 - x0, h: y1 - y0 }, ry, cx))
  }
  for (const s of out) {
    const nb: RegionStat[] = []
    for (const [dr, dc] of [[-1, 0], [1, 0], [0, -1], [0, 1]]) {
      const rr = s.row + dr, cc = s.col + dc
      if (rr >= 0 && rr < rows && cc >= 0 && cc < cols) nb.push(out[rr * cols + cc])
    }
    s.contrastAdjacent = nb.length ? nb.reduce((a, o) => a + deltaE2000Linear(s.meanLinear, o.meanLinear), 0) / nb.length : 0
  }
  return out
}

export const to8Rgb = (c: RGB) => ({ r: encode8(c.r), g: encode8(c.g), b: encode8(c.b) })
