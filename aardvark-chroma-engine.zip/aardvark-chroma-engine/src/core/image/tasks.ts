import type { ImageBuf } from './image-model'
import { generateBase, type GeneratorId } from './procedural'
import { renderImage, type RenderParams, type RenderStats } from './image-processing'
import { analyseImage, type AnalysisOptions, type AnalysisResult } from './analysis'
import { computeHistograms, computeWaveform, computeVectorscope, type Histograms, type Waveform, type Vectorscope, type ScopeChannel } from './histograms'

/**
 * Pure task runner. It is executed inside the Web Worker in the browser, and directly on the main thread as a
 * fallback (and in unit tests). Keeping one implementation guarantees both paths give identical results.
 */

export type Task =
  | { op: 'put'; key: string; img: ImageBuf }
  | { op: 'generate'; key: string; generator: GeneratorId; width: number; height: number }
  | { op: 'render'; key: string; params: RenderParams }
  | { op: 'analyse'; key: string; opts: AnalysisOptions }
  | { op: 'scopes'; key: string; channel: ScopeChannel }
  | { op: 'evict'; key: string }

export interface ScopesResult { hist: Histograms; waveform: Waveform; vectorscope: Vectorscope }

export type TaskResult =
  | { op: 'put' | 'evict'; ok: true }
  | { op: 'generate'; image: ImageBuf }
  | { op: 'render'; image: ImageBuf; stats: RenderStats }
  | { op: 'analyse'; result: AnalysisResult }
  | { op: 'scopes'; result: ScopesResult }

const cache = new Map<string, ImageBuf>()
const MAX_CACHE = 24

function remember(key: string, img: ImageBuf) {
  cache.set(key, img)
  while (cache.size > MAX_CACHE) { const first = cache.keys().next().value; if (first === undefined) break; cache.delete(first) }
}

export function runTask(t: Task): TaskResult {
  switch (t.op) {
    case 'put': remember(t.key, t.img); return { op: 'put', ok: true }
    case 'evict': cache.delete(t.key); return { op: 'evict', ok: true }
    case 'generate': {
      const img = generateBase(t.generator, t.width, t.height)
      remember(t.key, img)
      return { op: 'generate', image: img }
    }
    case 'render': {
      const src = cache.get(t.key)
      if (!src) throw new Error(`Source "${t.key}" is not loaded in the processing cache`)
      const { image, stats } = renderImage(src, t.params)
      return { op: 'render', image, stats }
    }
    case 'analyse': {
      const src = cache.get(t.key)
      if (!src) throw new Error(`Source "${t.key}" is not loaded in the processing cache`)
      return { op: 'analyse', result: analyseImage(src, t.opts) }
    }
    case 'scopes': {
      const src = cache.get(t.key)
      if (!src) throw new Error(`Source "${t.key}" is not loaded in the processing cache`)
      return { op: 'scopes', result: { hist: computeHistograms(src), waveform: computeWaveform(src, 320, t.channel), vectorscope: computeVectorscope(src, 160) } }
    }
  }
}
