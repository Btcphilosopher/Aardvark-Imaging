import { srgbToLinearChannel, linearToSrgbChannel, type RGB } from '../colour/conversions'

/** 8-bit, sRGB-encoded, straight-alpha RGBA raster. This is the *display-referred* working form used by every image operation. */
export interface ImageBuf {
  width: number
  height: number
  data: Uint8ClampedArray
}

export function createImage(width: number, height: number, fill?: [number, number, number, number]): ImageBuf {
  const data = new Uint8ClampedArray(width * height * 4)
  if (fill) for (let i = 0; i < data.length; i += 4) { data[i] = fill[0]; data[i + 1] = fill[1]; data[i + 2] = fill[2]; data[i + 3] = fill[3] }
  return { width, height, data }
}

export const cloneImage = (img: ImageBuf): ImageBuf => ({ width: img.width, height: img.height, data: new Uint8ClampedArray(img.data) })

export interface Pixel8 { r: number; g: number; b: number; a: number }

export function getPixel(img: ImageBuf, x: number, y: number): Pixel8 | null {
  if (x < 0 || y < 0 || x >= img.width || y >= img.height) return null
  const i = (y * img.width + x) * 4
  return { r: img.data[i], g: img.data[i + 1], b: img.data[i + 2], a: img.data[i + 3] }
}

/** 256-entry sRGB decode table (encoded 8-bit → linear light). */
export const DECODE_LUT: Float64Array = (() => {
  const t = new Float64Array(256)
  for (let i = 0; i < 256; i++) t[i] = srgbToLinearChannel(i / 255)
  return t
})()

const ENC_N = 16384
/** Encode table: linear light 0..1 → 8-bit sRGB. */
export const ENCODE_LUT: Uint8Array = (() => {
  const t = new Uint8Array(ENC_N + 1)
  for (let i = 0; i <= ENC_N; i++) t[i] = Math.round(linearToSrgbChannel(i / ENC_N) * 255)
  return t
})()

/** Continuous (float) encode table: linear light → encoded sRGB 0..1. */
export const ENCODE_F: Float32Array = (() => {
  const t = new Float32Array(ENC_N + 1)
  for (let i = 0; i <= ENC_N; i++) t[i] = linearToSrgbChannel(i / ENC_N)
  return t
})()

export function encodeF(linear: number): number {
  if (!(linear > 0)) return 0
  if (linear >= 1) return 1
  return ENCODE_F[(linear * ENC_N + 0.5) | 0]
}

export function encode8(linear: number): number {
  if (!(linear > 0)) return 0
  if (linear >= 1) return 255
  return ENCODE_LUT[(linear * ENC_N + 0.5) | 0]
}

export const pixelLinear = (img: ImageBuf, i: number): RGB => ({ r: DECODE_LUT[img.data[i]], g: DECODE_LUT[img.data[i + 1]], b: DECODE_LUT[img.data[i + 2]] })

/** Rec.709 luma of encoded values (video-style luma, 0..255). Used for histograms/waveforms; NOT relative luminance. */
export const luma8 = (r: number, g: number, b: number): number => 0.2126 * r + 0.7152 * g + 0.0722 * b

export interface Rect { x: number; y: number; w: number; h: number }

export function clampRect(r: Rect, img: { width: number; height: number }): Rect {
  const x = Math.max(0, Math.min(img.width - 1, Math.round(r.x)))
  const y = Math.max(0, Math.min(img.height - 1, Math.round(r.y)))
  return { x, y, w: Math.max(1, Math.min(img.width - x, Math.round(r.w))), h: Math.max(1, Math.min(img.height - y, Math.round(r.h))) }
}

/** Bounded downscale (box filter) so analysis stays cheap on very large imports. */
export function downscaleToMax(img: ImageBuf, maxPixels: number): ImageBuf {
  const n = img.width * img.height
  if (n <= maxPixels) return img
  const f = Math.sqrt(n / maxPixels)
  const w = Math.max(1, Math.floor(img.width / f)), h = Math.max(1, Math.floor(img.height / f))
  const out = createImage(w, h)
  for (let y = 0; y < h; y++) {
    const y0 = Math.floor(y * f), y1 = Math.min(img.height, Math.max(y0 + 1, Math.floor((y + 1) * f)))
    for (let x = 0; x < w; x++) {
      const x0 = Math.floor(x * f), x1 = Math.min(img.width, Math.max(x0 + 1, Math.floor((x + 1) * f)))
      let r = 0, g = 0, b = 0, a = 0, c = 0
      for (let yy = y0; yy < y1; yy++) for (let xx = x0; xx < x1; xx++) {
        const i = (yy * img.width + xx) * 4
        r += DECODE_LUT[img.data[i]]; g += DECODE_LUT[img.data[i + 1]]; b += DECODE_LUT[img.data[i + 2]]; a += img.data[i + 3]; c++
      }
      const o = (y * w + x) * 4
      out.data[o] = encode8(r / c); out.data[o + 1] = encode8(g / c); out.data[o + 2] = encode8(b / c); out.data[o + 3] = Math.round(a / c)
    }
  }
  return out
}
