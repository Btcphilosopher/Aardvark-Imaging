import { type ImageBuf, type Rect, DECODE_LUT, downscaleToMax, luma8 } from './image-model'
import { computeHistograms, entropyBits, percentileBin, type Histograms } from './histograms'
import { regionGrid, regionStat, type RegionStat } from './sampling'
import { type RGB, linearToOklab, oklabToLinear, linearToSrgb, rgbToHex, linearToXyz, xyzToLab, rgbToHsv, clamp01 } from '../colour/conversions'
import { relativeLuminance } from '../colour/conversions'

export interface DominantColour { hex: string; linear: RGB; fraction: number }

export interface AnalysisResult {
  width: number
  height: number
  histograms: Histograms
  averageLinear: RGB
  averageHex: string
  dominant: DominantColour[]
  saturationDistribution: number[]     // 10 bins of HSV saturation, fractions
  contrastRms: number                  // RMS contrast of luma (0..1)
  contrastPercentile: number           // (p95−p05)/(p95+p05) of luma
  shadowClipPct: number
  highlightClipPct: number
  edgeDensityPct: number
  brightnessZones: number[]            // 11 zones, fractions
  cctEstimate: number | null
  cctNote: string
  entropyBits: number
  dynamicRangeStops: number
  regions: RegionStat[]
  regionGrid: { cols: number; rows: number }
  ms: number
}

/** Deterministic k-means in OKLab (farthest-point initialisation, fixed iteration count). */
export function kmeansOklab(img: ImageBuf, k = 6, maxSamples = 14000): DominantColour[] {
  const stride = Math.max(1, Math.floor((img.width * img.height) / maxSamples))
  const pts: number[] = []
  for (let p = 0; p < img.width * img.height; p += stride) {
    const i = p * 4
    const o = linearToOklab({ r: DECODE_LUT[img.data[i]], g: DECODE_LUT[img.data[i + 1]], b: DECODE_LUT[img.data[i + 2]] })
    pts.push(o.l, o.a, o.b)
  }
  const n = pts.length / 3
  if (n === 0) return []
  k = Math.min(k, n)
  const centers: number[] = []
  let mean = [0, 0, 0]
  for (let i = 0; i < n; i++) { mean[0] += pts[i * 3]; mean[1] += pts[i * 3 + 1]; mean[2] += pts[i * 3 + 2] }
  mean = mean.map((v) => v / n)
  let first = 0, bd = Infinity
  for (let i = 0; i < n; i++) { const d = (pts[i * 3] - mean[0]) ** 2 + (pts[i * 3 + 1] - mean[1]) ** 2 + (pts[i * 3 + 2] - mean[2]) ** 2; if (d < bd) { bd = d; first = i } }
  centers.push(pts[first * 3], pts[first * 3 + 1], pts[first * 3 + 2])
  const minD = new Float64Array(n).fill(Infinity)
  while (centers.length / 3 < k) {
    const c = centers.length / 3 - 1
    let far = 0, fd = -1
    for (let i = 0; i < n; i++) {
      const d = (pts[i * 3] - centers[c * 3]) ** 2 + (pts[i * 3 + 1] - centers[c * 3 + 1]) ** 2 + (pts[i * 3 + 2] - centers[c * 3 + 2]) ** 2
      if (d < minD[i]) minD[i] = d
      if (minD[i] > fd) { fd = minD[i]; far = i }
    }
    centers.push(pts[far * 3], pts[far * 3 + 1], pts[far * 3 + 2])
  }
  const assign = new Int32Array(n)
  for (let iter = 0; iter < 14; iter++) {
    const sum = new Float64Array(k * 3), cnt = new Uint32Array(k)
    for (let i = 0; i < n; i++) {
      let best = 0, bdist = Infinity
      for (let c = 0; c < k; c++) {
        const d = (pts[i * 3] - centers[c * 3]) ** 2 + (pts[i * 3 + 1] - centers[c * 3 + 1]) ** 2 + (pts[i * 3 + 2] - centers[c * 3 + 2]) ** 2
        if (d < bdist) { bdist = d; best = c }
      }
      assign[i] = best; cnt[best]++
      sum[best * 3] += pts[i * 3]; sum[best * 3 + 1] += pts[i * 3 + 1]; sum[best * 3 + 2] += pts[i * 3 + 2]
    }
    for (let c = 0; c < k; c++) if (cnt[c]) { centers[c * 3] = sum[c * 3] / cnt[c]; centers[c * 3 + 1] = sum[c * 3 + 1] / cnt[c]; centers[c * 3 + 2] = sum[c * 3 + 2] / cnt[c] }
  }
  const counts = new Uint32Array(k)
  for (let i = 0; i < n; i++) counts[assign[i]]++
  const out: DominantColour[] = []
  for (let c = 0; c < k; c++) {
    if (!counts[c]) continue
    const lin = oklabToLinear({ l: centers[c * 3], a: centers[c * 3 + 1], b: centers[c * 3 + 2] })
    const clipped = { r: clamp01(lin.r), g: clamp01(lin.g), b: clamp01(lin.b) }
    out.push({ hex: rgbToHex(linearToSrgb(clipped)), linear: clipped, fraction: counts[c] / n })
  }
  return out.sort((a, b) => b.fraction - a.fraction)
}

/** McCamy's approximation from CIE xy. Valid roughly 2000–12500 K near the Planckian locus. */
export function mccamyCct(x: number, y: number): number {
  const n = (x - 0.332) / (0.1858 - y)
  return 449 * n ** 3 + 3525 * n ** 2 + 6823.3 * n + 5520.33
}

export interface AnalysisOptions { cols?: number; rows?: number; customRegions?: Rect[]; clusters?: number; maxPixels?: number; roi?: Rect | null }

function cropImage(img: ImageBuf, r: Rect): ImageBuf {
  const x0 = Math.max(0, Math.min(img.width - 1, Math.round(r.x))), y0 = Math.max(0, Math.min(img.height - 1, Math.round(r.y)))
  const w = Math.max(1, Math.min(img.width - x0, Math.round(r.w))), h = Math.max(1, Math.min(img.height - y0, Math.round(r.h)))
  const out = new Uint8ClampedArray(w * h * 4)
  for (let y = 0; y < h; y++) out.set(img.data.subarray(((y0 + y) * img.width + x0) * 4, ((y0 + y) * img.width + x0 + w) * 4), y * w * 4)
  return { width: w, height: h, data: out }
}

export function analyseImage(imgIn: ImageBuf, opts: AnalysisOptions = {}): AnalysisResult {
  const t0 = Date.now()
  const base = opts.roi ? cropImage(imgIn, opts.roi) : imgIn
  const img = downscaleToMax(base, opts.maxPixels ?? 400_000)
  const hist = computeHistograms(img)
  let r = 0, g = 0, b = 0
  const satBins = new Array(10).fill(0)
  const zones = new Array(11).fill(0)
  let sumL = 0, sumL2 = 0, shadow = 0, high = 0
  const n = img.width * img.height
  for (let i = 0; i < n * 4; i += 4) {
    const R = img.data[i], G = img.data[i + 1], B = img.data[i + 2]
    const lr = DECODE_LUT[R], lg = DECODE_LUT[G], lb = DECODE_LUT[B]
    r += lr; g += lg; b += lb
    const hsv = rgbToHsv({ r: R / 255, g: G / 255, b: B / 255 })
    satBins[Math.min(9, Math.floor(hsv.s * 10))]++
    const y = luma8(R, G, B) / 255
    sumL += y; sumL2 += y * y
    if (R <= 2 && G <= 2 && B <= 2) shadow++
    if (R >= 253 || G >= 253 || B >= 253) high++
    const Y = relativeLuminance({ r: lr, g: lg, b: lb })
    const Lstar = Y > 216 / 24389 ? 116 * Math.cbrt(Y) - 16 : (24389 / 27) * Y
    zones[Math.max(0, Math.min(10, Math.round(Lstar / 10)))]++
  }
  const avg: RGB = { r: r / n, g: g / n, b: b / n }
  const meanL = sumL / n
  const rms = Math.sqrt(Math.max(0, sumL2 / n - meanL * meanL))
  const p05 = percentileBin(hist.luma, 0.05) / 255, p95 = percentileBin(hist.luma, 0.95) / 255
  // edge density: Sobel on a bounded luma plane
  const stride = Math.max(1, Math.floor(Math.sqrt(n / 90000)))
  const w = Math.floor(img.width / stride), h = Math.floor(img.height / stride)
  const lum = new Float32Array(w * h)
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const i = (y * stride * img.width + x * stride) * 4; lum[y * w + x] = luma8(img.data[i], img.data[i + 1], img.data[i + 2]) }
  let edges = 0, total = 0
  for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) {
    const i = y * w + x
    const gx = -lum[i - w - 1] - 2 * lum[i - 1] - lum[i + w - 1] + lum[i - w + 1] + 2 * lum[i + 1] + lum[i + w + 1]
    const gy = -lum[i - w - 1] - 2 * lum[i - w] - lum[i - w + 1] + lum[i + w - 1] + 2 * lum[i + w] + lum[i + w + 1]
    if (Math.hypot(gx, gy) > 96) edges++
    total++
  }
  const xyz = linearToXyz(avg)
  const sum = xyz.x + xyz.y + xyz.z
  const cct = sum > 1e-6 ? mccamyCct(xyz.x / sum, xyz.y / sum) : null
  const lowBin = percentileBin(hist.luma, 0.005), highBin = percentileBin(hist.luma, 0.995)
  const yLow = Math.max(DECODE_LUT[lowBin], 1 / 4096), yHigh = Math.max(DECODE_LUT[highBin], yLow * 1.0001)
  const cols = opts.cols ?? 3, rows = opts.rows ?? 3
  const regions = opts.customRegions?.length
    ? opts.customRegions.map((rc, i) => regionStat(img, rc, 0, i))
    : regionGrid(img, cols, rows)
  return {
    width: img.width, height: img.height, histograms: hist,
    averageLinear: avg, averageHex: rgbToHex(linearToSrgb(avg)),
    dominant: kmeansOklab(img, opts.clusters ?? 6),
    saturationDistribution: satBins.map((v) => v / n),
    contrastRms: rms, contrastPercentile: p95 + p05 > 0 ? (p95 - p05) / (p95 + p05) : 0,
    shadowClipPct: (shadow / n) * 100, highlightClipPct: (high / n) * 100,
    edgeDensityPct: total ? (edges / total) * 100 : 0,
    brightnessZones: zones.map((v) => v / n),
    cctEstimate: cct !== null && cct > 1500 && cct < 25000 ? cct : null,
    cctNote: 'Grey-world estimate from the mean image chromaticity (McCamy). Unreliable for images dominated by one colour.',
    entropyBits: entropyBits(hist.luma),
    dynamicRangeStops: Math.log2(yHigh / yLow),
    regions, regionGrid: { cols, rows }, ms: Date.now() - t0,
  }
}

export { xyzToLab }
