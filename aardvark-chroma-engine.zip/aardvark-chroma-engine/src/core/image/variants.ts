import type { AssetVariant } from '../../types/project'
import { GRADE_PRESETS, defaultGrade, type GradeParams } from '../grading/grade'
import { defaultRender, type RenderParams } from './image-processing'

/** How each synthetic asset variant is derived from the deterministic base image. */
export function variantGrade(v: AssetVariant): GradeParams | null {
  switch (v) {
    case 'source': return GRADE_PRESETS.find((g) => g.id === 'flat-log')!.grade()
    case 'graded': return GRADE_PRESETS.find((g) => g.id === 'industrial-cinema')!.grade()
    case 'display': return { ...defaultGrade(), contrast: -0.04, blacks: 0.35, saturation: -0.04, exposure: -0.05 }
    default: return null
  }
}

export function variantRenderParams(v: AssetVariant): RenderParams | null {
  if (v === 'working') return null
  const p = defaultRender()
  if (v === 'print') return { ...p, proof: { profileId: 'matte-coated', intent: 'relative', bpc: true } }
  return { ...p, grade: variantGrade(v) }
}

export const VARIANT_DESCRIPTION: Record<AssetVariant, string> = {
  working: 'Deterministic base image (display-referred sRGB).',
  source: 'Synthetic flat encode: contrast −0.32, saturation −0.22, raised blacks. Stands in for camera-log-style material; not a real camera transform.',
  graded: 'Industrial cinema primary grade from the simulated grading pipeline.',
  print: 'Approximate matte-coated CMYK proof preview. Not a certified proof.',
  display: 'Approximate display response: black lift and slightly reduced saturation.',
}
