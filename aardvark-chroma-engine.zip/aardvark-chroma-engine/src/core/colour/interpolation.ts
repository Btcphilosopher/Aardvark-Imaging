import {
  type RGB, type Lab, srgbToLinear, linearToSrgb, linearToXyz, xyzToLinear, xyzToLab, labToXyz, labToLch, lchToLab,
  linearToOklab, oklabToLinear, oklabToOklch, oklchToOklab, normHue, ACHROMATIC_EPS_LAB, ACHROMATIC_EPS_OK,
} from './conversions'
import { deltaEOk } from './contrast'

export type MixSpace = 'srgb' | 'linear' | 'lab' | 'lch' | 'oklab' | 'oklch'
export type HueMode = 'shorter' | 'longer' | 'increasing' | 'decreasing'

export const MIX_SPACES: { id: MixSpace; label: string; polar: boolean }[] = [
  { id: 'srgb', label: 'sRGB (gamma-encoded)', polar: false },
  { id: 'linear', label: 'Linear RGB', polar: false },
  { id: 'lab', label: 'CIELAB', polar: false },
  { id: 'lch', label: 'CIELCh', polar: true },
  { id: 'oklab', label: 'OKLab', polar: false },
  { id: 'oklch', label: 'OKLCh', polar: true },
]

type Coord = [number, number, number]

/** Coordinates of a linear colour in the mixing space. For polar spaces the third element is hue (°). */
function toCoord(linear: RGB, space: MixSpace): Coord {
  switch (space) {
    case 'srgb': { const s = linearToSrgb(linear); return [s.r, s.g, s.b] }
    case 'linear': return [linear.r, linear.g, linear.b]
    case 'lab': { const l = xyzToLab(linearToXyz(linear)); return [l.l, l.a, l.b] }
    case 'lch': { const l = labToLch(xyzToLab(linearToXyz(linear))); return [l.l, l.c, l.h] }
    case 'oklab': { const l = linearToOklab(linear); return [l.l, l.a, l.b] }
    case 'oklch': { const l = oklabToOklch(linearToOklab(linear)); return [l.l, l.c, l.h] }
  }
}

function fromCoord(c: Coord, space: MixSpace): RGB {
  switch (space) {
    case 'srgb': return srgbToLinear({ r: c[0], g: c[1], b: c[2] })
    case 'linear': return { r: c[0], g: c[1], b: c[2] }
    case 'lab': return xyzToLinear(labToXyz({ l: c[0], a: c[1], b: c[2] } as Lab))
    case 'lch': return xyzToLinear(labToXyz(lchToLab({ l: c[0], c: c[1], h: c[2] })))
    case 'oklab': return oklabToLinear({ l: c[0], a: c[1], b: c[2] })
    case 'oklch': return oklabToLinear(oklchToOklab({ l: c[0], c: c[1], h: c[2] }))
  }
}

/** CSS Color 4 hue fix-up. Returns adjusted [h1, h2] such that a straight lerp gives the requested route. */
export function fixupHues(h1: number, h2: number, mode: HueMode): [number, number] {
  h1 = normHue(h1); h2 = normHue(h2)
  const d = h2 - h1
  switch (mode) {
    case 'shorter':
      if (d > 180) h1 += 360
      else if (d < -180) h2 += 360
      break
    case 'longer':
      if (d > 0 && d < 180) h1 += 360
      else if (d > -180 && d <= 0) h2 += 360
      break
    case 'increasing':
      if (d < 0) h2 += 360
      break
    case 'decreasing':
      if (d > 0) h1 += 360
      break
  }
  return [h1, h2]
}

export interface MixOptions { space: MixSpace; hueMode?: HueMode }
export interface AlphaColour { linear: RGB; alpha: number }

/**
 * Interpolate two colours at parameter t (0 → a, 1 → b) in the chosen space.
 * Alpha is interpolated linearly and colour coordinates are premultiplied (CSS Color 4 behaviour).
 * Achromatic endpoints have "powerless" hue and take the hue of the other endpoint.
 */
export function mixColours(a: AlphaColour, b: AlphaColour, t: number, opts: MixOptions): AlphaColour {
  const { space, hueMode = 'shorter' } = opts
  const polar = space === 'lch' || space === 'oklch'
  const ca = toCoord(a.linear, space)
  const cb = toCoord(b.linear, space)
  if (polar) {
    const eps = space === 'lch' ? ACHROMATIC_EPS_LAB : ACHROMATIC_EPS_OK
    const aPowerless = ca[1] < eps, bPowerless = cb[1] < eps
    if (aPowerless && !bPowerless) ca[2] = cb[2]
    else if (bPowerless && !aPowerless) cb[2] = ca[2]
    else if (aPowerless && bPowerless) { ca[2] = 0; cb[2] = 0 }
  }
  const alpha = a.alpha + (b.alpha - a.alpha) * t
  const out: Coord = [0, 0, 0]
  const pa = a.alpha, pb = b.alpha
  for (let i = 0; i < 3; i++) {
    if (polar && i === 2) continue
    const va = ca[i] * pa, vb = cb[i] * pb
    const v = va + (vb - va) * t
    out[i] = alpha > 1e-9 ? v / alpha : ca[i] + (cb[i] - ca[i]) * t
  }
  if (polar) {
    const [h1, h2] = fixupHues(ca[2], cb[2], hueMode)
    out[2] = normHue(h1 + (h2 - h1) * t)
  }
  return { linear: fromCoord(out, space), alpha }
}

export function mixSteps(a: AlphaColour, b: AlphaColour, steps: number, opts: MixOptions): AlphaColour[] {
  const n = Math.max(2, Math.floor(steps))
  return Array.from({ length: n }, (_, i) => mixColours(a, b, i / (n - 1), opts))
}

export interface StepUniformity {
  /** ΔE_OK between consecutive steps ×100 */
  steps: number[]
  mean: number
  /** Standard deviation of consecutive-step distances — 0 means perceptually even steps. */
  deviation: number
  /** Endpoint-to-endpoint ΔE_OK ×100 */
  endpoint: number
  /** Minimum OKLab lightness along the ramp — a dip signals the well-known dark-band artefact of RGB mixing. */
  minLightness: number
}

export function stepUniformity(ramp: AlphaColour[]): StepUniformity {
  const d: number[] = []
  for (let i = 1; i < ramp.length; i++) d.push(deltaEOk(ramp[i - 1].linear, ramp[i].linear) * 100)
  const mean = d.reduce((s, v) => s + v, 0) / Math.max(1, d.length)
  const variance = d.reduce((s, v) => s + (v - mean) * (v - mean), 0) / Math.max(1, d.length)
  return {
    steps: d,
    mean,
    deviation: Math.sqrt(variance),
    endpoint: deltaEOk(ramp[0].linear, ramp[ramp.length - 1].linear) * 100,
    minLightness: Math.min(...ramp.map((c) => linearToOklab(c.linear).l)),
  }
}
