import { type RGB, srgbToLinear, linearToSrgb, clamp01 } from './conversions'

/**
 * Compositing and colour-combination operations.
 * These are four DIFFERENT physical/mathematical models and the UI labels them separately:
 *  1. Alpha compositing  — Porter–Duff "over" for layered opaque/translucent media
 *  2. Blend modes        — Photoshop/W3C compositing formulas, evaluated on encoded sRGB by convention
 *  3. Additive light     — linear-light sum of emitters (stage lights, displays)
 *  4. Pigment approx.    — weighted geometric mean of linear reflectance (not spectral, not Kubelka–Munk)
 */

export type BlendMode = 'normal' | 'multiply' | 'screen' | 'overlay' | 'soft-light' | 'difference'
export const BLEND_MODES: BlendMode[] = ['normal', 'multiply', 'screen', 'overlay', 'soft-light', 'difference']

export interface AlphaRgb { linear: RGB; alpha: number }

/** Porter–Duff source-over for straight-alpha colours. `space` decides whether it is evaluated on linear light or encoded values. */
export function alphaOver(src: AlphaRgb, dst: AlphaRgb, space: 'linear' | 'srgb' = 'linear'): AlphaRgb {
  const ao = src.alpha + dst.alpha * (1 - src.alpha)
  if (ao <= 1e-9) return { linear: { r: 0, g: 0, b: 0 }, alpha: 0 }
  const enc = (c: RGB) => (space === 'linear' ? c : linearToSrgb(c))
  const s = enc(src.linear), d = enc(dst.linear)
  const f = (cs: number, cd: number) => (cs * src.alpha + cd * dst.alpha * (1 - src.alpha)) / ao
  const out = { r: f(s.r, d.r), g: f(s.g, d.g), b: f(s.b, d.b) }
  return { linear: space === 'linear' ? out : srgbToLinear(out), alpha: ao }
}

function blendChannel(mode: BlendMode, cb: number, cs: number): number {
  switch (mode) {
    case 'normal': return cs
    case 'multiply': return cb * cs
    case 'screen': return cb + cs - cb * cs
    case 'overlay': return hardLight(cs, cb)
    case 'soft-light': {
      if (cs <= 0.5) return cb - (1 - 2 * cs) * cb * (1 - cb)
      const d = cb <= 0.25 ? ((16 * cb - 12) * cb + 4) * cb : Math.sqrt(cb)
      return cb + (2 * cs - 1) * (d - cb)
    }
    case 'difference': return Math.abs(cb - cs)
    default: return cs
  }
}

// hard-light isn't exposed in the UI list, but overlay is defined as hard-light with layers swapped.
function hardLight(cb: number, cs: number): number {
  return cs <= 0.5 ? cb * 2 * cs : cb + (2 * cs - 1) - cb * (2 * cs - 1)
}

/** Blend a source layer onto a backdrop. Both are linear RGB; evaluation space is encoded sRGB unless `space: 'linear'`. */
export function blendColours(backdrop: RGB, source: RGB, mode: BlendMode, space: 'srgb' | 'linear' = 'srgb'): RGB {
  const b = space === 'srgb' ? linearToSrgb(backdrop) : backdrop
  const s = space === 'srgb' ? linearToSrgb(source) : source
  const f = (cb: number, cs: number) => {
    cb = clamp01(cb); cs = clamp01(cs)
    return blendChannel(mode, cb, cs)
  }
  const out = { r: f(b.r, s.r), g: f(b.g, s.g), b: f(b.b, s.b) }
  return space === 'srgb' ? srgbToLinear(out) : out
}

export interface AdditiveResult { linear: RGB; overexposed: boolean; peak: number }

/** Sum of light emitters in linear space; `peak` > 1 means the sum exceeds display white and would clip. */
export function additiveLight(a: RGB, b: RGB, wa = 1, wb = 1): AdditiveResult {
  const l = { r: a.r * wa + b.r * wb, g: a.g * wa + b.g * wb, b: a.b * wa + b.b * wb }
  const peak = Math.max(l.r, l.g, l.b)
  return { linear: l, overexposed: peak > 1 + 1e-9, peak }
}

/** Pigment-style approximation: weighted geometric mean of linear reflectance. Not a spectral model. */
export function pigmentMix(a: RGB, b: RGB, t: number): RGB {
  const eps = 1e-4
  const g = (x: number, y: number) => Math.exp((1 - t) * Math.log(Math.max(x, eps)) + t * Math.log(Math.max(y, eps)))
  return { r: g(a.r, b.r), g: g(a.g, b.g), b: g(a.b, b.b) }
}
