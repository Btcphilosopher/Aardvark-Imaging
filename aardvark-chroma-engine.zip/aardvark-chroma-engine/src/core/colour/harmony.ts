import {
  type RGB, linearToOklab, oklabToOklch, oklchToOklab, oklabToLinear, normHue, clamp, clamp01, type RgbSpaceId,
} from './conversions'
import { makeRecord, hexRecord, type ColourRecord, DEMO_TIMESTAMP } from './colour-model'
import { maxChromaOklch } from './gamut'
import { ensureContrast, wcagContrast, wcagLevel, type WcagLevel } from './contrast'
import { MATERIALS, materialLinear } from '../materials/materials'
import { PROFILE_BY_ID } from '../print/print'

export type PaletteKind =
  | 'complementary' | 'analogous' | 'triadic' | 'split-complementary' | 'tetradic' | 'monochromatic' | 'near-neutral'
  | 'high-contrast' | 'industrial' | 'material' | 'architectural' | 'cinematic' | 'print-safe' | 'accessible-ui'

export const PALETTE_KINDS: { id: PaletteKind; label: string; description: string }[] = [
  { id: 'complementary', label: 'Complementary', description: 'Base hue and its opposite (180°), extended by lightness tiers.' },
  { id: 'analogous', label: 'Analogous', description: 'Neighbouring hues at 30° spacing centred on the base.' },
  { id: 'triadic', label: 'Triadic', description: 'Three hues at 120° intervals.' },
  { id: 'split-complementary', label: 'Split-complementary', description: 'Base plus the two hues flanking its complement (±30°).' },
  { id: 'tetradic', label: 'Tetradic', description: 'Four hues at 90° intervals.' },
  { id: 'monochromatic', label: 'Monochromatic', description: 'Single hue, lightness ramp with gently varying chroma.' },
  { id: 'near-neutral', label: 'Near-neutral', description: 'Very low chroma greys that keep a trace of the base hue.' },
  { id: 'high-contrast', label: 'High-contrast', description: 'Alternating near-black and near-white anchors with saturated accents.' },
  { id: 'industrial', label: 'Low-chroma industrial', description: 'Muted steels, sands and a single restrained accent.' },
  { id: 'material', label: 'Material palette', description: 'Sampled from the Aardvark material library, ordered by lightness.' },
  { id: 'architectural', label: 'Architectural', description: 'Concrete, stone, timber and glass tones biased by the base hue.' },
  { id: 'cinematic', label: 'Cinematic', description: 'Teal/orange split with tinted shadows and highlights.' },
  { id: 'print-safe', label: 'Print-safe approximation', description: 'Gamut-limited to the matte-coated synthetic profile (approximation, not a proof).' },
  { id: 'accessible-ui', label: 'Accessible UI', description: 'Role-based UI palette with WCAG contrast targets enforced.' },
]

export interface PaletteParams {
  baseHex: string
  hueRotation: number     // degrees
  chroma: number          // multiplier 0..2
  lightness: number       // OKLab L of the base, 0.1..0.95
  steps: number           // 3..12
  neutralisation: number  // 0..1
  contrast: number        // 0..1 spread of lightness tiers
  warmth: number          // −1..1
  saturationCeiling: number // max OKLCh chroma 0.03..0.4
  gamut: RgbSpaceId
}

export const defaultPaletteParams = (baseHex = '#e8630a'): PaletteParams => ({
  baseHex, hueRotation: 0, chroma: 1, lightness: 0.66, steps: 5, neutralisation: 0, contrast: 0.5, warmth: 0, saturationCeiling: 0.32, gamut: 'srgb',
})

export interface PaletteColour {
  colour: ColourRecord
  role: string
  locked: boolean
  usage: string
}

export interface Palette {
  id: string
  name: string
  kind: PaletteKind
  params: PaletteParams
  colours: PaletteColour[]
  notes: string
  createdAt: string
}

const HUE_NAMES: [number, string][] = [
  [20, 'Rose'], [40, 'Red'], [65, 'Orange'], [90, 'Amber'], [110, 'Yellow'], [130, 'Lime'], [160, 'Green'], [190, 'Teal'], [215, 'Cyan'],
  [250, 'Azure'], [275, 'Blue'], [305, 'Violet'], [335, 'Magenta'], [360, 'Rose'],
]

export function colourName(rec: Pick<ColourRecord, 'oklch'>): string {
  const { l, c, h } = rec.oklch
  if (c < 0.022) {
    if (l < 0.18) return 'Near-black'
    if (l < 0.36) return 'Graphite'
    if (l < 0.6) return 'Mid grey'
    if (l < 0.82) return 'Aluminium'
    return 'Warm white'
  }
  const hue = HUE_NAMES.find(([lim]) => normHue(h) < lim)?.[1] ?? 'Red'
  const tone = l < 0.3 ? 'Deep ' : l < 0.48 ? 'Dark ' : l < 0.72 ? '' : l < 0.86 ? 'Light ' : 'Pale '
  const chroma = c < 0.05 ? 'Muted ' : ''
  return `${tone}${chroma}${hue}`.replace(/ +/g, ' ').replace(/^ /, '').replace(/^Muted /, 'Muted ')
}

interface Seed { l: number; c: number; h: number; role: string }

function tierL(base: number, tier: number, contrast: number): number {
  if (tier === 0) return base
  const step = 0.06 + contrast * 0.16
  const dir = tier % 2 === 1 ? 1 : -1
  return clamp(base + dir * Math.ceil(tier / 2) * step, 0.08, 0.96)
}

function hueSeeds(offsets: number[], base: { l: number; c: number; h: number }, n: number, contrast: number, roleFor: (i: number) => string): Seed[] {
  const out: Seed[] = []
  for (let i = 0; i < Math.max(n, offsets.length); i++) {
    const tier = Math.floor(i / offsets.length)
    out.push({ l: tierL(base.l, tier, contrast), c: base.c * (tier ? 0.85 : 1), h: base.h + offsets[i % offsets.length], role: roleFor(i) })
  }
  return out
}

function seedsFor(kind: PaletteKind, p: PaletteParams, base: { l: number; c: number; h: number }): Seed[] {
  const n = p.steps
  const roles = (names: string[]) => (i: number) => names[i] ?? `Tone ${i + 1}`
  switch (kind) {
    case 'complementary': return hueSeeds([0, 180], base, n, p.contrast, roles(['Primary', 'Complement', 'Primary light', 'Complement dark', 'Primary dark', 'Complement light']))
    case 'analogous': {
      const offs = Array.from({ length: n }, (_, i) => (i - (n - 1) / 2) * 30)
      return offs.map((o, i) => ({ l: base.l + (i - (n - 1) / 2) * 0.02 * p.contrast * 4, c: base.c, h: base.h + o, role: i === Math.floor((n - 1) / 2) ? 'Primary' : `Neighbour ${i + 1}` }))
    }
    case 'triadic': return hueSeeds([0, 120, 240], base, n, p.contrast, roles(['Primary', 'Secondary', 'Tertiary']))
    case 'split-complementary': return hueSeeds([0, 150, 210], base, n, p.contrast, roles(['Primary', 'Split A', 'Split B']))
    case 'tetradic': return hueSeeds([0, 90, 180, 270], base, n, p.contrast, roles(['Primary', 'Secondary', 'Tertiary', 'Quaternary']))
    case 'monochromatic': return Array.from({ length: n }, (_, i) => {
      const t = n === 1 ? 0.5 : i / (n - 1)
      return { l: clamp(0.94 - t * (0.5 + p.contrast * 0.36), 0.08, 0.97), c: base.c * (0.35 + 0.65 * Math.sin(Math.PI * (0.15 + 0.7 * t))), h: base.h, role: i === 0 ? 'Lightest' : i === n - 1 ? 'Darkest' : `Step ${i + 1}` }
    })
    case 'near-neutral': return Array.from({ length: n }, (_, i) => {
      const t = n === 1 ? 0.5 : i / (n - 1)
      return { l: 0.95 - t * (0.62 + p.contrast * 0.28), c: 0.006 + 0.014 * (1 - Math.abs(t - 0.5) * 1.6), h: base.h, role: i === 0 ? 'Paper' : i === n - 1 ? 'Ink' : `Neutral ${i + 1}` }
    })
    case 'high-contrast': return Array.from({ length: n }, (_, i) => {
      if (i % 3 === 0) return { l: 0.12, c: 0.012, h: base.h, role: 'Anchor dark' }
      if (i % 3 === 1) return { l: 0.97, c: 0.008, h: base.h, role: 'Anchor light' }
      return { l: 0.7 - 0.05 * Math.floor(i / 3), c: base.c, h: base.h + 150 * Math.floor(i / 3 + 0.5 * 0), role: `Accent ${Math.floor(i / 3) + 1}` }
    })
    case 'industrial': {
      const cap = Math.min(0.055, base.c)
      const list: Seed[] = [
        { l: 0.24, c: cap * 0.35, h: 245, role: 'Graphite' }, { l: 0.52, c: cap * 0.5, h: 240, role: 'Steel' }, { l: 0.8, c: cap * 0.4, h: 235, role: 'Aluminium' },
        { l: 0.72, c: cap, h: 80, role: 'Sandstone' }, { l: 0.62, c: Math.min(0.17, base.c), h: base.h, role: 'Accent' }, { l: 0.4, c: cap * 0.9, h: 60, role: 'Timber' },
        { l: 0.93, c: cap * 0.25, h: 85, role: 'Warm white' }, { l: 0.13, c: cap * 0.2, h: 250, role: 'Near-black' },
      ]
      return Array.from({ length: n }, (_, i) => list[i % list.length])
    }
    case 'architectural': return Array.from({ length: n }, (_, i) => {
      const anchors = [{ l: 0.68, h: 250 }, { l: 0.78, h: 80 }, { l: 0.36, h: 55 }, { l: 0.88, h: 200 }, { l: 0.5, h: 240 }, { l: 0.94, h: 85 }]
      const a = anchors[i % anchors.length]
      return { l: a.l, c: 0.018 + base.c * 0.16, h: a.h * 0.75 + base.h * 0.25, role: ['Concrete', 'Stone', 'Timber', 'Glass', 'Steel frame', 'Render'][i % 6] }
    })
    case 'cinematic': {
      const list: Seed[] = [
        { l: 0.18, c: 0.05, h: 215, role: 'Shadow (teal)' }, { l: 0.42, c: 0.075, h: 205, role: 'Low-mid teal' }, { l: 0.62, c: 0.03, h: 75, role: 'Mid neutral' },
        { l: 0.74, c: 0.13, h: 55, role: 'Key (orange)' }, { l: 0.9, c: 0.05, h: 80, role: 'Highlight (amber)' }, { l: 0.3, c: 0.04, h: 240, role: 'Cool fill' },
      ]
      return Array.from({ length: n }, (_, i) => list[i % list.length])
    }
    case 'print-safe': return hueSeeds([0, 30, 180, 210], base, n, p.contrast, roles(['Primary', 'Neighbour', 'Complement', 'Cool complement']))
    case 'material': {
      const sorted = MATERIALS.map((m) => ({ m, ok: oklabToOklch(linearToOklab(materialLinear(m))) })).sort((a, b) => b.ok.l - a.ok.l)
      const pick = Array.from({ length: n }, (_, i) => sorted[Math.min(sorted.length - 1, Math.round((i / Math.max(1, n - 1)) * (sorted.length - 1)))])
      return pick.map(({ m, ok }) => ({ l: ok.l, c: ok.c, h: ok.h, role: m.name }))
    }
    case 'accessible-ui': return []
  }
}

/** Compose a palette colour from OKLCh values after the shared parameter stage (rotation, warmth, chroma, neutralisation, ceiling, gamut). */
function finishSeed(s: Seed, p: PaletteParams, kind: PaletteKind, absoluteHue: boolean): RGB {
  let h = s.h + (absoluteHue ? 0 : 0)
  h += p.hueRotation
  // warmth rotates hue toward orange (55°) for positive, toward blue (255°) for negative, proportional to distance (max 25°)
  const target = p.warmth >= 0 ? 55 : 255
  const diff = ((target - h + 540) % 360) - 180
  h += clamp(diff, -25, 25) * Math.abs(p.warmth)
  let c = s.c * p.chroma * (1 - p.neutralisation)
  if (kind !== 'print-safe') c = Math.min(c, p.saturationCeiling)
  else c = Math.min(c, p.saturationCeiling)
  let l = clamp(s.l, 0.03, 0.99)
  if (kind === 'print-safe') {
    const prof = PROFILE_BY_ID['matte-coated']
    c = Math.min(c, maxChromaOklch(l, h, 'srgb') * prof.gamutScale * 0.92)
    l = Math.max(l, prof.blackL)
  } else {
    c = Math.min(c, maxChromaOklch(l, h, p.gamut))
  }
  const lin = oklabToLinear(oklchToOklab({ l, c: Math.max(0, c), h: normHue(h) }))
  return { r: clamp01(lin.r), g: clamp01(lin.g), b: clamp01(lin.b) }
}

export function usageNote(role: string, l: number): string {
  const r = role.toLowerCase()
  if (r.includes('primary') || r.includes('key') || r.includes('accent')) return 'Brand or interactive emphasis; keep below ~10 % of surface area.'
  if (r.includes('paper') || r.includes('white') || r.includes('light') && l > 0.85) return 'Large background or documentation surface.'
  if (r.includes('ink') || r.includes('near-black') || r.includes('dark') && l < 0.3) return 'Body text and workspace backgrounds.'
  if (r.includes('graphite') || r.includes('steel') || r.includes('frame')) return 'Structural surfaces, borders and controls.'
  return l > 0.6 ? 'Secondary surface or highlight.' : 'Secondary surface or supporting text.'
}

let paletteCounter = 0
export const newPaletteId = () => `pal_${Date.now().toString(36)}${(paletteCounter++).toString(36)}`

function toPaletteColours(seeds: Seed[], p: PaletteParams, kind: PaletteKind, seedId: string, existing?: PaletteColour[]): PaletteColour[] {
  return seeds.map((s, i) => {
    const old = existing?.[i]
    if (old?.locked) return old
    const linear = finishSeed(s, p, kind, false)
    const rec = makeRecord({ id: `${seedId}_${i}`, linear, source: `palette:${kind}`, createdAt: DEMO_TIMESTAMP, tags: [kind] })
    rec.name = old?.colour.name && old.colour.name !== old.colour.hex.toUpperCase() && old.colour.metadata.source.startsWith('manual') ? old.colour.name : colourName(rec)
    return { colour: rec, role: s.role, locked: false, usage: usageNote(s.role, rec.oklch.l) }
  })
}

const UI_BG_LIGHT: RGB = { r: 0.88, g: 0.86, b: 0.8 }

function accessiblePalette(p: PaletteParams, existing?: PaletteColour[], seedId = 'ui'): PaletteColour[] {
  const base = oklabToOklch(linearToOklab(hexRecord(p.baseHex, 'base').linearRgb))
  const H = base.h + p.hueRotation
  const mk = (l: number, c: number, h: number): RGB => {
    const cc = Math.min(c * p.chroma * (1 - p.neutralisation), p.saturationCeiling, maxChromaOklch(l, h, p.gamut))
    const lin = oklabToLinear(oklchToOklab({ l, c: cc, h }))
    return { r: clamp01(lin.r), g: clamp01(lin.g), b: clamp01(lin.b) }
  }
  const bg = mk(0.965, 0.006, H)
  const surface = mk(0.93, 0.008, H)
  const border = mk(0.78, 0.01, H)
  const text = ensureContrast(mk(0.25, 0.02, H), bg, 12)
  const muted = ensureContrast(mk(0.5, 0.02, H), bg, 4.6)
  const primary = ensureContrast(mk(base.l, base.c, H), bg, 4.5)
  const onPrimary = ensureContrast({ r: 1, g: 1, b: 1 }, primary, 4.5)
  const danger = ensureContrast(mk(0.55, 0.19, 28), bg, 4.5)
  const success = ensureContrast(mk(0.55, 0.14, 150), bg, 4.5)
  const warning = ensureContrast(mk(0.55, 0.12, 75), bg, 3.2)
  const list: [string, RGB, string][] = [
    ['Background', bg, 'Page background'], ['Surface', surface, 'Cards, panels'], ['Border', border, 'Dividers; 3:1 needed only for essential UI boundaries'],
    ['Text', text, 'Body text — ≥12:1 on background'], ['Text muted', muted, 'Secondary text — ≥4.5:1'], ['Primary', primary, 'Interactive emphasis; ≥4.5:1 as text'],
    ['On primary', onPrimary, 'Text on primary fills — ≥4.5:1'], ['Danger', danger, 'Errors, destructive actions'], ['Success', success, 'Success states'], ['Warning', warning, 'Warnings; pair with icon or text, not colour alone'],
  ]
  return list.slice(0, Math.max(6, Math.min(list.length, p.steps + 3))).map(([role, lin, usage], i) => {
    const old = existing?.[i]
    if (old?.locked) return old
    const rec = makeRecord({ id: `${seedId}_${i}`, linear: lin, source: 'palette:accessible-ui', createdAt: DEMO_TIMESTAMP, tags: ['accessible-ui'], name: role })
    return { colour: rec, role, locked: false, usage }
  })
}

export function generatePaletteColours(kind: PaletteKind, p: PaletteParams, existing?: PaletteColour[], seedId = 'pc'): PaletteColour[] {
  if (kind === 'accessible-ui') return accessiblePalette(p, existing, seedId)
  const baseRec = hexRecord(p.baseHex, 'base')
  const ok = oklabToOklch(linearToOklab(baseRec.linearRgb))
  const base = { l: kind === 'material' ? ok.l : p.lightness * 0.6 + ok.l * 0.4 * (Math.abs(p.lightness - 0.66) < 1e-9 ? 1 : 0) + (Math.abs(p.lightness - 0.66) < 1e-9 ? 0 : 0.4 * p.lightness), c: ok.c, h: ok.h }
  const seeds = seedsFor(kind, p, base)
  return toPaletteColours(seeds, p, kind, seedId, existing)
}

export function createPalette(kind: PaletteKind, params: PaletteParams, name?: string): Palette {
  const id = newPaletteId()
  return {
    id, name: name ?? `${PALETTE_KINDS.find((k) => k.id === kind)?.label ?? kind} — ${params.baseHex.toUpperCase()}`,
    kind, params, colours: generatePaletteColours(kind, params, undefined, id), notes: '', createdAt: new Date().toISOString(),
  }
}

/** Regenerate every unlocked colour with new parameters; locked colours keep their exact record. */
export function regeneratePalette(pal: Palette, params: PaletteParams = pal.params, kind: PaletteKind = pal.kind): Palette {
  return { ...pal, kind, params, colours: generatePaletteColours(kind, params, pal.colours, pal.id) }
}

// ───────────── per-colour contrast / variants ─────────────

const WHITE: RGB = { r: 1, g: 1, b: 1 }
const NEAR_BLACK: RGB = { r: 0.006, g: 0.007, b: 0.008 }
const WARM_WHITE: RGB = { r: 0.89, g: 0.86, b: 0.79 }
const GRAPHITE: RGB = { r: 0.013, g: 0.016, b: 0.018 }

export interface ContrastData { onWhite: number; onBlack: number; levelOnWhite: WcagLevel; levelOnBlack: WcagLevel; best: 'white' | 'black' }

export function contrastData(rec: Pick<ColourRecord, 'linearRgb'>): ContrastData {
  const a = wcagContrast(rec.linearRgb, WHITE), b = wcagContrast(rec.linearRgb, NEAR_BLACK)
  return { onWhite: a, onBlack: b, levelOnWhite: wcagLevel(a), levelOnBlack: wcagLevel(b), best: a >= b ? 'white' : 'black' }
}

export function themeVariants(rec: Pick<ColourRecord, 'linearRgb' | 'name'>): { light: ColourRecord; dark: ColourRecord } {
  const l = ensureContrast(rec.linearRgb, WARM_WHITE, 4.5)
  const d = ensureContrast(rec.linearRgb, GRAPHITE, 4.5)
  return {
    light: makeRecord({ linear: l, name: `${rec.name} · light theme`, source: 'variant:light', createdAt: DEMO_TIMESTAMP }),
    dark: makeRecord({ linear: d, name: `${rec.name} · dark theme`, source: 'variant:dark', createdAt: DEMO_TIMESTAMP }),
  }
}

export { UI_BG_LIGHT }

// ───────────── tonal scale, material variations ─────────────

export function tonalScale(base: RGB, steps = 11, space: RgbSpaceId = 'srgb'): ColourRecord[] {
  const ok = oklabToOklch(linearToOklab(base))
  const labels = [50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 950]
  return Array.from({ length: steps }, (_, i) => {
    const t = steps === 1 ? 0.5 : i / (steps - 1)
    const l = 0.97 - t * 0.83
    const chromaShape = Math.sin(Math.PI * (0.12 + 0.76 * t))
    const c = Math.min(ok.c * (0.25 + 0.95 * chromaShape), maxChromaOklch(l, ok.h, space))
    const lin = oklabToLinear(oklchToOklab({ l, c, h: ok.h }))
    const rec = makeRecord({ linear: { r: clamp01(lin.r), g: clamp01(lin.g), b: clamp01(lin.b) }, source: 'tonal-scale', createdAt: DEMO_TIMESTAMP })
    rec.name = steps === labels.length ? String(labels[i]) : `Step ${i + 1}`
    return rec
  })
}

export function materialVariations(base: RGB): ColourRecord[] {
  const ok = oklabToOklch(linearToOklab(base))
  const defs: [string, number, number, number][] = [
    ['Brushed', 0.02, 0.6, 0], ['Oxidised', -0.05, 0.75, 95], ['Gloss', 0.03, 1.12, 0], ['Weathered', -0.07, 0.45, 15],
    ['Wet', -0.14, 1.15, 0], ['Sun-bleached', 0.1, 0.5, -10],
  ]
  return defs.map(([name, dl, cm, dh]) => {
    const l = clamp(ok.l + dl, 0.05, 0.97), h = ok.h + (dh === 95 ? (ok.h > 200 ? 0 : 95 * 0.5) : dh)
    const c = Math.min(ok.c * cm, maxChromaOklch(l, h))
    const lin = oklabToLinear(oklchToOklab({ l, c, h }))
    const rec = makeRecord({ linear: { r: clamp01(lin.r), g: clamp01(lin.g), b: clamp01(lin.b) }, name, source: 'material-variation', createdAt: DEMO_TIMESTAMP })
    return rec
  })
}
