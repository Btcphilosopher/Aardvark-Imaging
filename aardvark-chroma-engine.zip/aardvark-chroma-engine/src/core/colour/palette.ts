import {
  type RGB, type RgbSpaceId, linearToOklab, oklabToOklch, oklchToOklab, oklabToLinear, normHue, clamp, clamp01,
} from './conversions'
import { maxChromaOklch, inGamut } from './gamut'
import { deltaEOk, ensureContrast, wcagContrast } from './contrast'
import { MATERIALS, materialLinear } from '../materials/materials'

export type HarmonyKind =
  | 'complementary' | 'analogous' | 'triadic' | 'split-complementary' | 'tetradic' | 'monochromatic' | 'near-neutral'
  | 'high-contrast' | 'low-chroma-industrial' | 'material' | 'architectural' | 'cinematic' | 'print-safe' | 'accessible-ui'

export const HARMONIES: { id: HarmonyKind; label: string; note: string }[] = [
  { id: 'complementary', label: 'Complementary', note: 'Base and the hue 180° opposite in OKLCh, with tonal steps.' },
  { id: 'analogous', label: 'Analogous', note: 'Neighbouring hues within ±30°.' },
  { id: 'triadic', label: 'Triadic', note: 'Three hues 120° apart.' },
  { id: 'split-complementary', label: 'Split-complementary', note: 'Base plus the hues 150° and 210° away.' },
  { id: 'tetradic', label: 'Tetradic', note: 'Rectangle scheme: 0°, 60°, 180°, 240°.' },
  { id: 'monochromatic', label: 'Monochromatic', note: 'One hue, lightness ramp with a chroma envelope.' },
  { id: 'near-neutral', label: 'Near-neutral', note: 'Very low chroma, alternating warm and cool tints.' },
  { id: 'high-contrast', label: 'High-contrast', note: 'Alternating very dark and very light values.' },
  { id: 'low-chroma-industrial', label: 'Low-chroma industrial', note: 'Chroma capped near 0.05 around the base hue.' },
  { id: 'material', label: 'Material palette', note: 'Nearest entries from the material library to the base colour.' },
  { id: 'architectural', label: 'Architectural palette', note: 'Concrete, stone and timber neutrals with the base as the single accent.' },
  { id: 'cinematic', label: 'Cinematic palette', note: 'Warm/cool split-tone with dark cool shadows and warm highlights.' },
  { id: 'print-safe', label: 'Print-safe approximation', note: 'Chroma limited to a conservative fraction of the sRGB boundary. Approximate, not a profile conversion.' },
  { id: 'accessible-ui', label: 'Accessible UI', note: 'Ramp with WCAG-checked text roles on light and dark surfaces.' },
]

export interface PaletteControls {
  kind: HarmonyKind
  base: RGB                // linear sRGB
  steps: number            // 3..12
  hueRotation: number      // degrees
  chromaScale: number      // 0..2
  lightnessShift: number   // −0.3..0.3
  neutralisation: number   // 0..1
  contrast: number         // −0.5..1
  warmth: number           // −1..1
  saturationCeiling: number // OKLCh C ceiling 0.02..0.4
  gamut: RgbSpaceId | 'print'
}

export const defaultControls = (base: RGB): PaletteControls => ({
  kind: 'complementary', base, steps: 6, hueRotation: 0, chromaScale: 1, lightnessShift: 0, neutralisation: 0, contrast: 0, warmth: 0, saturationCeiling: 0.4, gamut: 'srgb',
})

export interface PaletteEntry { linear: RGB; role: string; name: string; usage: string }

interface Lch { l: number; c: number; h: number }
const toLch = (c: RGB): Lch => oklabToOklch(linearToOklab(c))
const fromLch = (c: Lch): RGB => oklabToLinear(oklchToOklab(c))

function tonalRamp(n: number, lo: number, hi: number): number[] {
  return Array.from({ length: n }, (_, i) => (n === 1 ? (lo + hi) / 2 : lo + ((hi - lo) * i) / (n - 1)))
}

const ROLE_NAMES = ['Primary', 'Secondary', 'Tertiary', 'Quaternary']

function anchorsFor(kind: HarmonyKind, b: Lch): { dh: number; role: string }[] {
  switch (kind) {
    case 'complementary': return [{ dh: 0, role: 'Primary' }, { dh: 180, role: 'Complement' }]
    case 'analogous': return [{ dh: -30, role: 'Analogue A' }, { dh: 0, role: 'Primary' }, { dh: 30, role: 'Analogue B' }]
    case 'triadic': return [{ dh: 0, role: 'Primary' }, { dh: 120, role: 'Triad B' }, { dh: 240, role: 'Triad C' }]
    case 'split-complementary': return [{ dh: 0, role: 'Primary' }, { dh: 150, role: 'Split A' }, { dh: 210, role: 'Split B' }]
    case 'tetradic': return [{ dh: 0, role: 'Primary' }, { dh: 60, role: 'Rect B' }, { dh: 180, role: 'Rect C' }, { dh: 240, role: 'Rect D' }]
    default: return [{ dh: 0, role: ROLE_NAMES[0] }].concat(b.c < 0 ? [] : [])
  }
}

/** Generate a palette. Deterministic. Everything is built in OKLCh, then the controls are applied uniformly. */
export function generatePalette(ctl: PaletteControls): PaletteEntry[] {
  const b = toLch(ctl.base)
  const n = Math.max(3, Math.min(12, Math.round(ctl.steps)))
  let raw: { lch: Lch; role: string; usage: string }[] = []
  const anchorKinds: HarmonyKind[] = ['complementary', 'analogous', 'triadic', 'split-complementary', 'tetradic']
  if (anchorKinds.includes(ctl.kind)) {
    const anchors = anchorsFor(ctl.kind, b)
    anchors.forEach((a, i) => raw.push({ lch: { l: b.l, c: b.c, h: b.h + a.dh }, role: a.role, usage: i === 0 ? 'Brand-defining accent; use sparingly.' : 'Supporting hue; keep to secondary elements.' }))
    const extra = n - raw.length
    const ramp = tonalRamp(Math.max(0, extra), 0.22, 0.92)
    for (let i = 0; i < extra; i++) {
      const a = anchors[i % anchors.length]
      const l = ramp[i]
      raw.push({ lch: { l, c: b.c * (0.35 + 0.5 * (1 - Math.abs(l - 0.6))), h: b.h + a.dh }, role: `${a.role} ${l > b.l ? 'tint' : 'shade'}`, usage: l > b.l ? 'Backgrounds and fills.' : 'Text, borders and depth.' })
    }
  } else if (ctl.kind === 'monochromatic') {
    tonalRamp(n, 0.2, 0.94).forEach((l, i) => raw.push({ lch: { l, c: b.c * Math.sin(Math.PI * (0.15 + 0.7 * (i / Math.max(1, n - 1)))) * 1.05, h: b.h }, role: `Step ${i + 1}`, usage: i < n / 3 ? 'Deep tones: text, outlines.' : i < (2 * n) / 3 ? 'Mid tones: primary fills.' : 'Light tones: backgrounds.' }))
  } else if (ctl.kind === 'near-neutral') {
    tonalRamp(n, 0.16, 0.95).forEach((l, i) => raw.push({ lch: { l, c: 0.006 + 0.012 * (i % 2), h: i % 2 ? 70 : 250 }, role: `Neutral ${i + 1}`, usage: 'Surfaces, dividers and text; tinted alternately warm and cool.' }))
  } else if (ctl.kind === 'high-contrast') {
    for (let i = 0; i < n; i++) raw.push({ lch: { l: i % 2 === 0 ? 0.16 + 0.05 * (i / n) : 0.94 - 0.03 * (i / n), c: b.c * (i % 2 === 0 ? 0.8 : 0.45), h: b.h + (i * 360) / n }, role: i % 2 === 0 ? `Ink ${Math.floor(i / 2) + 1}` : `Paper ${Math.floor(i / 2) + 1}`, usage: i % 2 === 0 ? 'Text and marks.' : 'Grounds.' })
  } else if (ctl.kind === 'low-chroma-industrial') {
    tonalRamp(n, 0.22, 0.88).forEach((l, i) => raw.push({ lch: { l, c: Math.min(0.05, b.c * 0.3) * (0.4 + 0.6 * ((i % 3) / 2)), h: b.h + ((i % 3) - 1) * 28 }, role: `Industrial ${i + 1}`, usage: 'Machinery, enclosures and equipment surfaces.' }))
  } else if (ctl.kind === 'material') {
    const scored = MATERIALS.flatMap((m) => [{ m, hex: m.baseHex, lin: materialLinear(m) }]).map((x) => ({ ...x, d: deltaEOk(x.lin, ctl.base) })).sort((a, z) => a.d - z.d)
    scored.slice(0, n).forEach((s) => raw.push({ lch: toLch(s.lin), role: s.m.category, usage: `${s.m.name} — ${s.m.description.split('.')[0]}.` }))
  } else if (ctl.kind === 'architectural') {
    const fixed: { name: string; l: number; c: number; h: number; use: string }[] = [
      { name: 'Board-formed concrete', l: 0.62, c: 0.022, h: 240, use: 'Primary mass.' },
      { name: 'Warm limestone', l: 0.82, c: 0.04, h: 80, use: 'Cladding, plinths.' },
      { name: 'Dark timber', l: 0.34, c: 0.05, h: 55, use: 'Joinery, doors.' },
      { name: 'Anodised aluminium', l: 0.72, c: 0.01, h: 250, use: 'Frames, flashings.' },
      { name: 'Graphite steel', l: 0.3, c: 0.012, h: 250, use: 'Structural steel.' },
      { name: 'Frosted glazing', l: 0.9, c: 0.014, h: 200, use: 'Glazing tint.' },
    ]
    raw.push({ lch: b, role: 'Accent', usage: 'Single accent element per elevation.' })
    fixed.slice(0, n - 1).forEach((f) => raw.push({ lch: { l: f.l, c: f.c, h: f.h }, role: f.name, usage: f.use }))
  } else if (ctl.kind === 'cinematic') {
    const warm = 55, cool = 215
    tonalRamp(n, 0.16, 0.95).forEach((l, i) => { const t = i / Math.max(1, n - 1); raw.push({ lch: { l, c: Math.min(0.14, b.c) * (0.5 + 0.7 * Math.abs(t - 0.5) * 2 * 0.6 + 0.3), h: t < 0.5 ? cool + (warm - cool) * 0 : warm }, role: t < 0.34 ? 'Shadow' : t < 0.67 ? 'Midtone' : 'Highlight', usage: t < 0.34 ? 'Cool teal shadows.' : t < 0.67 ? 'Neutral separation.' : 'Warm highlights.' }) })
    raw[Math.floor(n / 2)] = { lch: b, role: 'Key colour', usage: 'The colour the grade is built around.' }
  } else if (ctl.kind === 'print-safe') {
    tonalRamp(n, 0.25, 0.9).forEach((l, i) => raw.push({ lch: { l, c: Math.min(b.c, maxChromaOklch(l, b.h) * 0.62), h: b.h + (i % 2 ? 24 : -12) }, role: `Print ${i + 1}`, usage: 'Chroma held to 62% of the sRGB boundary to avoid CMYK clipping (approximation).' }))
  } else {
    // accessible-ui
    const white: RGB = { r: 1, g: 1, b: 1 }, dark: RGB = { r: 0.012, g: 0.013, b: 0.015 }
    const primary = ensureContrast(fromLch(b), white, 4.5)
    const pl = toLch(primary)
    raw = [
      { lch: { l: 0.985, c: 0.004, h: b.h }, role: 'Surface (light)', usage: 'Page background, light theme.' },
      { lch: { l: 0.93, c: 0.01, h: b.h }, role: 'Surface raised', usage: 'Cards and panels.' },
      { lch: { l: 0.82, c: 0.014, h: b.h }, role: 'Border', usage: 'Dividers; 1.6:1 on white — decorative only.' },
      { lch: pl, role: 'Primary', usage: 'Interactive elements; ≥4.5:1 on white.' },
      { lch: toLch(ensureContrast(fromLch({ l: 0.4, c: b.c * 0.2, h: b.h }), white, 7)), role: 'Text', usage: 'Body text; ≥7:1 on white.' },
      { lch: toLch(dark), role: 'Surface (dark)', usage: 'Page background, dark theme.' },
      { lch: toLch(ensureContrast(fromLch({ l: 0.75, c: b.c, h: b.h }), dark, 4.5)), role: 'Primary (dark)', usage: 'Interactive elements on dark; ≥4.5:1.' },
      { lch: toLch(ensureContrast(fromLch({ l: 0.85, c: 0.01, h: b.h }), dark, 7)), role: 'Text (dark)', usage: 'Body text on dark; ≥7:1.' },
    ].slice(0, Math.max(n, 4)) as typeof raw
  }
  if (raw.length > n && ctl.kind !== 'accessible-ui') raw = raw.slice(0, n)
  return raw.map((r, i) => finalise(r.lch, ctl, r.role, r.usage, i))
}

function finalise(l: Lch, ctl: PaletteControls, role: string, usage: string, i: number): PaletteEntry {
  let { l: L, c: C, h: H } = l
  H = normHue(H + ctl.hueRotation)
  if (ctl.warmth !== 0) {
    // rotate hue toward warm (55°) or cool (250°) along the shorter arc
    const target = ctl.warmth > 0 ? 55 : 250
    const d = ((target - H + 540) % 360) - 180
    H = normHue(H + d * Math.abs(ctl.warmth) * 0.35)
  }
  C = C * ctl.chromaScale * (1 - ctl.neutralisation)
  C = Math.min(C, ctl.saturationCeiling)
  L = clamp(L + ctl.lightnessShift, 0.02, 0.99)
  if (ctl.contrast !== 0) L = clamp(0.6 + (L - 0.6) * (1 + ctl.contrast), 0.02, 0.99)
  if (ctl.gamut === 'print') C = Math.min(C, maxChromaOklch(L, H, 'srgb') * 0.7)
  else C = Math.min(C, maxChromaOklch(L, H, ctl.gamut))
  let lin = fromLch({ l: L, c: C, h: H })
  if (ctl.gamut === 'srgb' || ctl.gamut === 'print') lin = { r: clamp01(lin.r), g: clamp01(lin.g), b: clamp01(lin.b) }
  const name = `${role}`
  void i
  return { linear: lin, role, name, usage }
}

export interface VariantPair { light: RGB; dark: RGB }

/** Light/dark theme variants of a palette colour: lift or deepen in OKLCh while keeping hue and (bounded) chroma. */
export function themeVariants(c: RGB): VariantPair {
  const o = toLch(c)
  const mk = (l: number) => {
    const cc = Math.min(o.c, maxChromaOklch(l, o.h))
    const lin = fromLch({ l, c: cc, h: o.h })
    return { r: clamp01(lin.r), g: clamp01(lin.g), b: clamp01(lin.b) }
  }
  return { light: mk(clamp(o.l + 0.14, 0.05, 0.97)), dark: mk(clamp(o.l - 0.16, 0.05, 0.97)) }
}

export interface ContrastInfo { onWhite: number; onBlack: number; bestText: 'white' | 'black'; ratio: number }

export function contrastInfo(c: RGB): ContrastInfo {
  const w = wcagContrast(c, { r: 1, g: 1, b: 1 }), k = wcagContrast(c, { r: 0, g: 0, b: 0 })
  return { onWhite: w, onBlack: k, bestText: w >= k ? 'white' : 'black', ratio: Math.max(w, k) }
}

/** Tonal scale (e.g. 50..950) at constant OKLCh hue with gamut-bounded chroma. */
export function tonalScale(base: RGB, steps = 11): RGB[] {
  const o = toLch(base)
  return tonalRamp(steps, 0.97, 0.16).map((l) => {
    const c = Math.min(o.c * (0.55 + 0.6 * Math.sin(Math.PI * (1 - (l - 0.16) / 0.81))), maxChromaOklch(l, o.h))
    const lin = fromLch({ l, c: Math.max(0, c), h: o.h })
    return { r: clamp01(lin.r), g: clamp01(lin.g), b: clamp01(lin.b) }
  })
}

export const isRenderable = (c: RGB) => inGamut(c, 'srgb')
