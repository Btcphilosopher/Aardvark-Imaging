import {
  type RGB, type HSL, type HSV, type HWB, type XYZ, type Lab, type LCh, type ColourSpaces,
  spacesFromLinear, srgbToLinear, linearToSrgb, hslToRgb, hsvToRgb, hwbToRgb, labToXyz, xyzToLinear, lchToLab,
  oklabToLinear, oklchToOklab, parseHex, rgbToHex, decodeRgb, convertLinear, clamp,
} from './conversions'
import { type GamutStatus, gamutStatus } from './gamut'

/** Canonical colour record. All numeric fields are derived by `makeRecord` from ONE stored linear-light triplet. */
export type ColourRecord = {
  id: string
  name: string
  /** Clipped 8-bit sRGB hex. When `gamutStatus.srgb` is false this is a clipped representation of the true colour. */
  hex: string
  alpha: number
  /** Encoded sRGB, 0..1. May fall outside 0..1 when the colour is outside the sRGB gamut. */
  srgb: { r: number; g: number; b: number }
  linearRgb: { r: number; g: number; b: number }
  hsl: { h: number; s: number; l: number }
  hsv: { h: number; s: number; v: number }
  hwb: { h: number; w: number; b: number }
  xyz: { x: number; y: number; z: number }
  lab: { l: number; a: number; b: number }
  lch: { l: number; c: number; h: number }
  oklab: { l: number; a: number; b: number }
  oklch: { l: number; c: number; h: number }
  luminance: number
  chroma: number
  hue: number
  gamutStatus: { srgb: boolean; displayP3: boolean; rec2020: boolean }
  metadata: {
    source: string
    createdAt: string
    tags: string[]
    notes?: string
  }
}

export const DEMO_TIMESTAMP = '2026-09-01T09:00:00.000Z'

let idCounter = 0
export function newId(prefix = 'c'): string {
  idCounter += 1
  const rnd = typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID().slice(0, 8) : Math.random().toString(36).slice(2, 10)
  return `${prefix}_${rnd}${idCounter.toString(36)}`
}

export interface RecordInit {
  id?: string
  name?: string
  linear: RGB
  alpha?: number
  source?: string
  tags?: string[]
  notes?: string
  createdAt?: string
}

/** Build a canonical record from linear-light sRGB-primaries RGB (the internal canonical form). */
export function makeRecord(init: RecordInit): ColourRecord {
  const s: ColourSpaces = spacesFromLinear(init.linear)
  const gs: GamutStatus = gamutStatus(init.linear)
  const alpha = clamp(init.alpha ?? 1, 0, 1)
  const hex = rgbToHex(s.srgb, 1)
  return {
    id: init.id ?? newId(),
    name: init.name ?? hex.toUpperCase(),
    hex,
    alpha,
    srgb: s.srgb,
    linearRgb: s.linearRgb,
    hsl: s.hsl,
    hsv: s.hsv,
    hwb: s.hwb,
    xyz: s.xyz,
    lab: s.lab,
    lch: s.lch,
    oklab: s.oklab,
    oklch: s.oklch,
    luminance: s.luminance,
    chroma: s.lch.c,
    hue: s.lch.h,
    gamutStatus: gs,
    metadata: {
      source: init.source ?? 'manual',
      createdAt: init.createdAt ?? new Date().toISOString(),
      tags: init.tags ?? [],
      ...(init.notes ? { notes: init.notes } : {}),
    },
  }
}

export function recordFromHex(hex: string, opts: Omit<RecordInit, 'linear'> = {}): ColourRecord | null {
  const p = parseHex(hex)
  if (!p) return null
  return makeRecord({ ...opts, linear: srgbToLinear(p.rgb), alpha: opts.alpha ?? p.alpha, name: opts.name })
}

/** Like recordFromHex but never fails — falls back to a neutral mid grey. Use only for trusted literals. */
export function hexRecord(hex: string, name: string, tags: string[] = [], id?: string, source = 'demo'): ColourRecord {
  return recordFromHex(hex, { name, tags, id, source, createdAt: DEMO_TIMESTAMP }) ?? makeRecord({ name, linear: { r: 0.18, g: 0.18, b: 0.18 }, id })
}

export const recordLinear = (r: { linearRgb: RGB }): RGB => r.linearRgb

// ───────────── picker-space handling ─────────────

export type PickerSpace = 'rgb' | 'hsl' | 'hsv' | 'hwb' | 'lab' | 'lch' | 'oklab' | 'oklch'
export const PICKER_SPACES: PickerSpace[] = ['hsl', 'hsv', 'oklch', 'lab', 'rgb', 'lch']

export type Triplet = [number, number, number]

/** Linear-light sRGB from channel values in the named picker space. Units: rgb 0..1, h° s/l/v/w/b 0..1, Lab L 0..100, OK L 0..1. */
export function linearFromPicker(space: PickerSpace, v: Triplet): RGB {
  switch (space) {
    case 'rgb': return srgbToLinear({ r: v[0], g: v[1], b: v[2] })
    case 'hsl': return srgbToLinear(hslToRgb({ h: v[0], s: v[1], l: v[2] } as HSL))
    case 'hsv': return srgbToLinear(hsvToRgb({ h: v[0], s: v[1], v: v[2] } as HSV))
    case 'hwb': return srgbToLinear(hwbToRgb({ h: v[0], w: v[1], b: v[2] } as HWB))
    case 'lab': return xyzToLinear(labToXyz({ l: v[0], a: v[1], b: v[2] } as Lab))
    case 'lch': return xyzToLinear(labToXyz(lchToLab({ l: v[0], c: v[1], h: v[2] } as LCh)))
    case 'oklab': return oklabToLinear({ l: v[0], a: v[1], b: v[2] })
    case 'oklch': return oklabToLinear(oklchToOklab({ l: v[0], c: v[1], h: v[2] }))
  }
}

export function pickerValues(rec: Pick<ColourRecord, 'srgb' | 'hsl' | 'hsv' | 'hwb' | 'lab' | 'lch' | 'oklab' | 'oklch'>, space: PickerSpace): Triplet {
  switch (space) {
    case 'rgb': return [rec.srgb.r, rec.srgb.g, rec.srgb.b]
    case 'hsl': return [rec.hsl.h, rec.hsl.s, rec.hsl.l]
    case 'hsv': return [rec.hsv.h, rec.hsv.s, rec.hsv.v]
    case 'hwb': return [rec.hwb.h, rec.hwb.w, rec.hwb.b]
    case 'lab': return [rec.lab.l, rec.lab.a, rec.lab.b]
    case 'lch': return [rec.lch.l, rec.lch.c, rec.lch.h]
    case 'oklab': return [rec.oklab.l, rec.oklab.a, rec.oklab.b]
    case 'oklch': return [rec.oklch.l, rec.oklch.c, rec.oklch.h]
  }
}

export interface ChannelSpec { key: string; label: string; min: number; max: number; step: number; unit: string; decimals: number }

export const PICKER_CHANNELS: Record<PickerSpace, ChannelSpec[]> = {
  rgb: [
    { key: 'r', label: 'R', min: 0, max: 255, step: 1, unit: '', decimals: 0 },
    { key: 'g', label: 'G', min: 0, max: 255, step: 1, unit: '', decimals: 0 },
    { key: 'b', label: 'B', min: 0, max: 255, step: 1, unit: '', decimals: 0 },
  ],
  hsl: [
    { key: 'h', label: 'H', min: 0, max: 360, step: 1, unit: '°', decimals: 1 },
    { key: 's', label: 'S', min: 0, max: 100, step: 1, unit: '%', decimals: 1 },
    { key: 'l', label: 'L', min: 0, max: 100, step: 1, unit: '%', decimals: 1 },
  ],
  hsv: [
    { key: 'h', label: 'H', min: 0, max: 360, step: 1, unit: '°', decimals: 1 },
    { key: 's', label: 'S', min: 0, max: 100, step: 1, unit: '%', decimals: 1 },
    { key: 'v', label: 'V', min: 0, max: 100, step: 1, unit: '%', decimals: 1 },
  ],
  hwb: [
    { key: 'h', label: 'H', min: 0, max: 360, step: 1, unit: '°', decimals: 1 },
    { key: 'w', label: 'W', min: 0, max: 100, step: 1, unit: '%', decimals: 1 },
    { key: 'b', label: 'B', min: 0, max: 100, step: 1, unit: '%', decimals: 1 },
  ],
  lab: [
    { key: 'l', label: 'L*', min: 0, max: 100, step: 0.5, unit: '', decimals: 2 },
    { key: 'a', label: 'a*', min: -160, max: 160, step: 0.5, unit: '', decimals: 2 },
    { key: 'b', label: 'b*', min: -160, max: 160, step: 0.5, unit: '', decimals: 2 },
  ],
  lch: [
    { key: 'l', label: 'L*', min: 0, max: 100, step: 0.5, unit: '', decimals: 2 },
    { key: 'c', label: 'C*', min: 0, max: 230, step: 0.5, unit: '', decimals: 2 },
    { key: 'h', label: 'h', min: 0, max: 360, step: 1, unit: '°', decimals: 1 },
  ],
  oklab: [
    { key: 'l', label: 'L', min: 0, max: 1, step: 0.005, unit: '', decimals: 4 },
    { key: 'a', label: 'a', min: -0.5, max: 0.5, step: 0.002, unit: '', decimals: 4 },
    { key: 'b', label: 'b', min: -0.5, max: 0.5, step: 0.002, unit: '', decimals: 4 },
  ],
  oklch: [
    { key: 'l', label: 'L', min: 0, max: 1, step: 0.005, unit: '', decimals: 4 },
    { key: 'c', label: 'C', min: 0, max: 0.4, step: 0.002, unit: '', decimals: 4 },
    { key: 'h', label: 'h', min: 0, max: 360, step: 1, unit: '°', decimals: 1 },
  ],
}

/** UI display scale: picker-space values are stored 0..1 for rgb/hsl-type fields, shown 0..255 / 0..100. */
export function toDisplayScale(space: PickerSpace, i: number, v: number): number {
  if (space === 'rgb') return v * 255
  if ((space === 'hsl' || space === 'hsv' || space === 'hwb') && i > 0) return v * 100
  return v
}
export function fromDisplayScale(space: PickerSpace, i: number, v: number): number {
  if (space === 'rgb') return v / 255
  if ((space === 'hsl' || space === 'hsv' || space === 'hwb') && i > 0) return v / 100
  return v
}

// ───────────── string parsing ─────────────

export function parseColourString(input: string): { linear: RGB; alpha: number } | null {
  const s = input.trim().toLowerCase()
  const hex = parseHex(s)
  if (hex && /^#?[0-9a-f]{3,8}$/.test(s)) return { linear: srgbToLinear(hex.rgb), alpha: hex.alpha }
  const nums = (body: string) => body.split(/[\s,/]+/).filter(Boolean).map((t) => (t.endsWith('%') ? parseFloat(t) / 100 : parseFloat(t.replace('deg', ''))))
  const fn = /^([a-z]+)\((.*)\)$/.exec(s)
  if (!fn) return null
  const n = nums(fn[2])
  if (n.length < 3 || n.some((x) => Number.isNaN(x))) return null
  const alpha = n.length > 3 ? clamp(n[3], 0, 1) : 1
  switch (fn[1]) {
    case 'rgb': case 'rgba': {
      const scale = fn[2].includes('%') ? 1 : 1 / 255
      return { linear: srgbToLinear({ r: n[0] * scale, g: n[1] * scale, b: n[2] * scale }), alpha }
    }
    case 'hsl': case 'hsla': return { linear: linearFromPicker('hsl', [n[0], n[1] > 1 ? n[1] / 100 : n[1], n[2] > 1 ? n[2] / 100 : n[2]]), alpha }
    case 'oklch': return { linear: linearFromPicker('oklch', [n[0] > 1 ? n[0] / 100 : n[0], n[1], n[2]]), alpha }
    case 'oklab': return { linear: linearFromPicker('oklab', [n[0], n[1], n[2]]), alpha }
    case 'lab': return { linear: linearFromPicker('lab', [n[0], n[1], n[2]]), alpha }
    default: return null
  }
}

// ───────────── encodings for non-sRGB working spaces ─────────────

/** Encoded values of a linear-sRGB colour in Display P3 or Rec.2020 as a CSS `color()` string. */
export function cssColorFunction(rec: Pick<ColourRecord, 'linearRgb'>, space: 'srgb' | 'display-p3' | 'rec2020'): string {
  const id = space === 'srgb' ? 'srgb' : space === 'display-p3' ? 'displayP3' : 'rec2020'
  const enc = spacesFromLinear(rec.linearRgb)
  const v = id === 'srgb' ? enc.srgb : id === 'displayP3' ? enc.displayP3 : enc.rec2020
  const f = (x: number) => (Math.round(x * 10000) / 10000).toString()
  return `color(${space} ${f(v.r)} ${f(v.g)} ${f(v.b)})`
}

export { decodeRgb, convertLinear, linearToSrgb }
export type { RGB, XYZ }
