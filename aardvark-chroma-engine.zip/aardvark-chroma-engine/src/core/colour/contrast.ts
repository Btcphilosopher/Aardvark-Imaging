import { type RGB, type Lab, linearToXyz, xyzToLab, linearToOklab, relativeLuminance, clamp01, oklabToLinear, oklabToOklch, oklchToOklab } from './conversions'

/** WCAG 2.x contrast ratio between two linear-light colours (luminance clamped to 0..1). */
export function wcagContrast(a: RGB, b: RGB): number {
  const la = clamp01(relativeLuminance(a)), lb = clamp01(relativeLuminance(b))
  const hi = Math.max(la, lb), lo = Math.min(la, lb)
  return (hi + 0.05) / (lo + 0.05)
}

export type WcagLevel = 'AAA' | 'AA' | 'AA Large' | 'Fail'

export function wcagLevel(ratio: number): WcagLevel {
  if (ratio >= 7) return 'AAA'
  if (ratio >= 4.5) return 'AA'
  if (ratio >= 3) return 'AA Large'
  return 'Fail'
}

export function deltaE76(a: Lab, b: Lab): number {
  return Math.hypot(a.l - b.l, a.a - b.a, a.b - b.b)
}

const rad = (d: number) => (d * Math.PI) / 180
const deg = (r: number) => (r * 180) / Math.PI

/** CIEDE2000 (Sharma, Wu, Dalal 2005), kL = kC = kH = 1. */
export function deltaE2000(x: Lab, y: Lab): number {
  const C1 = Math.hypot(x.a, x.b), C2 = Math.hypot(y.a, y.b)
  const Cbar = (C1 + C2) / 2
  const G = 0.5 * (1 - Math.sqrt(Math.pow(Cbar, 7) / (Math.pow(Cbar, 7) + Math.pow(25, 7))))
  const a1 = (1 + G) * x.a, a2 = (1 + G) * y.a
  const c1 = Math.hypot(a1, x.b), c2 = Math.hypot(a2, y.b)
  const hp = (b: number, a: number) => (b === 0 && a === 0 ? 0 : (deg(Math.atan2(b, a)) + 360) % 360)
  const h1 = hp(x.b, a1), h2 = hp(y.b, a2)
  const dL = y.l - x.l
  const dC = c2 - c1
  let dh: number
  if (c1 * c2 === 0) dh = 0
  else if (Math.abs(h2 - h1) <= 180) dh = h2 - h1
  else if (h2 - h1 > 180) dh = h2 - h1 - 360
  else dh = h2 - h1 + 360
  const dH = 2 * Math.sqrt(c1 * c2) * Math.sin(rad(dh / 2))
  const Lbar = (x.l + y.l) / 2
  const cbar = (c1 + c2) / 2
  let hbar: number
  if (c1 * c2 === 0) hbar = h1 + h2
  else if (Math.abs(h1 - h2) <= 180) hbar = (h1 + h2) / 2
  else if (h1 + h2 < 360) hbar = (h1 + h2 + 360) / 2
  else hbar = (h1 + h2 - 360) / 2
  const T = 1 - 0.17 * Math.cos(rad(hbar - 30)) + 0.24 * Math.cos(rad(2 * hbar)) + 0.32 * Math.cos(rad(3 * hbar + 6)) - 0.2 * Math.cos(rad(4 * hbar - 63))
  const dTheta = 30 * Math.exp(-Math.pow((hbar - 275) / 25, 2))
  const Rc = 2 * Math.sqrt(Math.pow(cbar, 7) / (Math.pow(cbar, 7) + Math.pow(25, 7)))
  const Sl = 1 + (0.015 * Math.pow(Lbar - 50, 2)) / Math.sqrt(20 + Math.pow(Lbar - 50, 2))
  const Sc = 1 + 0.045 * cbar
  const Sh = 1 + 0.015 * cbar * T
  const Rt = -Math.sin(rad(2 * dTheta)) * Rc
  return Math.sqrt(Math.pow(dL / Sl, 2) + Math.pow(dC / Sc, 2) + Math.pow(dH / Sh, 2) + Rt * (dC / Sc) * (dH / Sh))
}

/** Euclidean distance in OKLab (scale ×100 for a JND-like number; ≈1 is roughly just-noticeable). */
export function deltaEOk(a: RGB, b: RGB): number {
  const x = linearToOklab(a), y = linearToOklab(b)
  return Math.hypot(x.l - y.l, x.a - y.a, x.b - y.b)
}

export function deltaE2000Linear(a: RGB, b: RGB): number {
  return deltaE2000(xyzToLab(linearToXyz(a)), xyzToLab(linearToXyz(b)))
}

/**
 * Adjust OKLCh lightness (constant hue and chroma) until `fg` meets `target` contrast on `bg`.
 * Searches toward whichever end of the lightness axis gives contrast. Returns the best achievable colour.
 */
export function ensureContrast(fg: RGB, bg: RGB, target: number): RGB {
  if (wcagContrast(fg, bg) >= target) return fg
  const ok = oklabToOklch(linearToOklab(fg))
  const bgLighter = relativeLuminance(bg) > 0.18
  const dir = bgLighter ? -1 : 1
  let lo = ok.l, hi = dir < 0 ? 0 : 1
  let best = fg
  for (let i = 0; i < 28; i++) {
    const mid = (lo + hi) / 2
    const cand = oklabToLinear(oklchToOklab({ l: mid, c: ok.c, h: ok.h }))
    const clipped = { r: clamp01(cand.r), g: clamp01(cand.g), b: clamp01(cand.b) }
    if (wcagContrast(clipped, bg) >= target) { best = clipped; hi = mid }
    else lo = mid
  }
  return best
}

export function bestTextOn(bg: RGB): 'light' | 'dark' {
  const white = { r: 1, g: 1, b: 1 }, black = { r: 0, g: 0, b: 0 }
  return wcagContrast(white, bg) >= wcagContrast(black, bg) ? 'light' : 'dark'
}
export type { Lab }
