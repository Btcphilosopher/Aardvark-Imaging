/**
 * CHROMA ENGINE — authoritative colour conversion layer.
 *
 * Every colour value shown anywhere in the application is derived from the functions in this file.
 * Nothing else may re-implement a transfer function, matrix or colour-space formula.
 *
 * Conventions
 *  - RGB triplets are floating point, nominal range 0..1, and are NOT clamped unless a function says so.
 *    Out-of-range values are legitimate and mean "outside the gamut of that space".
 *  - "linear" = linear-light RGB relative to the sRGB / Rec.709 primaries and D65 white.
 *  - CIELAB / CIELCh use the D65 reference white derived from the sRGB white chromaticity (no D50 adaptation).
 *  - Hue angles are degrees in [0, 360). For achromatic colours hue is "powerless" and reported as 0.
 */

export interface RGB { r: number; g: number; b: number }
export interface XYZ { x: number; y: number; z: number }
export interface HSL { h: number; s: number; l: number }
export interface HSV { h: number; s: number; v: number }
export interface HWB { h: number; w: number; b: number }
export interface Lab { l: number; a: number; b: number }
export interface LCh { l: number; c: number; h: number }

export type Mat3 = readonly [number, number, number, number, number, number, number, number, number]

// ───────────────────────── matrix helpers ─────────────────────────

export function mulMat3(m: Mat3, v: RGB): RGB {
  return {
    r: m[0] * v.r + m[1] * v.g + m[2] * v.b,
    g: m[3] * v.r + m[4] * v.g + m[5] * v.b,
    b: m[6] * v.r + m[7] * v.g + m[8] * v.b,
  }
}

export function invertMat3(m: Mat3): Mat3 {
  const [a, b, c, d, e, f, g, h, i] = m
  const A = e * i - f * h
  const B = -(d * i - f * g)
  const C = d * h - e * g
  const det = a * A + b * B + c * C
  if (Math.abs(det) < 1e-15) throw new Error('Singular matrix')
  const inv = 1 / det
  return [
    A * inv, -(b * i - c * h) * inv, (b * f - c * e) * inv,
    B * inv, (a * i - c * g) * inv, -(a * f - c * d) * inv,
    C * inv, -(a * h - b * g) * inv, (a * e - b * d) * inv,
  ]
}

export function chromaticityToXYZ(x: number, y: number): XYZ {
  return { x: x / y, y: 1, z: (1 - x - y) / y }
}

/** Derive the linear-RGB→XYZ matrix from primaries and white point (Lindbloom method). */
export function rgbToXyzMatrix(
  r: [number, number], g: [number, number], b: [number, number], white: [number, number],
): Mat3 {
  const R = chromaticityToXYZ(...r)
  const G = chromaticityToXYZ(...g)
  const B = chromaticityToXYZ(...b)
  const W = chromaticityToXYZ(...white)
  const P: Mat3 = [R.x, G.x, B.x, R.y, G.y, B.y, R.z, G.z, B.z]
  const S = mulMat3(invertMat3(P), { r: W.x, g: W.y, b: W.z })
  return [
    R.x * S.r, G.x * S.g, B.x * S.b,
    R.y * S.r, G.y * S.g, B.y * S.b,
    R.z * S.r, G.z * S.g, B.z * S.b,
  ]
}

// ───────────────────────── colour spaces ─────────────────────────

export const D65_XY: [number, number] = [0.3127, 0.329]
export const D65_WHITE: XYZ = chromaticityToXYZ(...D65_XY)

export const SRGB_TO_XYZ: Mat3 = rgbToXyzMatrix([0.64, 0.33], [0.3, 0.6], [0.15, 0.06], D65_XY)
export const XYZ_TO_SRGB: Mat3 = invertMat3(SRGB_TO_XYZ)
export const P3_TO_XYZ: Mat3 = rgbToXyzMatrix([0.68, 0.32], [0.265, 0.69], [0.15, 0.06], D65_XY)
export const XYZ_TO_P3: Mat3 = invertMat3(P3_TO_XYZ)
export const REC2020_TO_XYZ: Mat3 = rgbToXyzMatrix([0.708, 0.292], [0.17, 0.797], [0.131, 0.046], D65_XY)
export const XYZ_TO_REC2020: Mat3 = invertMat3(REC2020_TO_XYZ)

export type RgbSpaceId = 'srgb' | 'displayP3' | 'rec2020'

export const RGB_SPACES: Record<RgbSpaceId, { label: string; toXyz: Mat3; fromXyz: Mat3 }> = {
  srgb: { label: 'sRGB (IEC 61966-2-1)', toXyz: SRGB_TO_XYZ, fromXyz: XYZ_TO_SRGB },
  displayP3: { label: 'Display P3', toXyz: P3_TO_XYZ, fromXyz: XYZ_TO_P3 },
  rec2020: { label: 'Rec.2020', toXyz: REC2020_TO_XYZ, fromXyz: XYZ_TO_REC2020 },
}

// ───────────────────────── transfer functions ─────────────────────────

/** sRGB electro-optical transfer: encoded → linear. Odd-symmetric so out-of-range values survive round trips. */
export function srgbToLinearChannel(v: number): number {
  const a = Math.abs(v)
  const l = a <= 0.04045 ? a / 12.92 : Math.pow((a + 0.055) / 1.055, 2.4)
  return v < 0 ? -l : l
}

export function linearToSrgbChannel(v: number): number {
  const a = Math.abs(v)
  const e = a <= 0.0031308 ? a * 12.92 : 1.055 * Math.pow(a, 1 / 2.4) - 0.055
  return v < 0 ? -e : e
}

const BT2020_ALPHA = 1.09929682680944
const BT2020_BETA = 0.018053968510807

export function rec2020ToLinearChannel(v: number): number {
  const a = Math.abs(v)
  const l = a < BT2020_BETA * 4.5 ? a / 4.5 : Math.pow((a + BT2020_ALPHA - 1) / BT2020_ALPHA, 1 / 0.45)
  return v < 0 ? -l : l
}

export function linearToRec2020Channel(v: number): number {
  const a = Math.abs(v)
  const e = a < BT2020_BETA ? 4.5 * a : BT2020_ALPHA * Math.pow(a, 0.45) - (BT2020_ALPHA - 1)
  return v < 0 ? -e : e
}

const mapRgb = (c: RGB, f: (v: number) => number): RGB => ({ r: f(c.r), g: f(c.g), b: f(c.b) })

export const srgbToLinear = (c: RGB): RGB => mapRgb(c, srgbToLinearChannel)
export const linearToSrgb = (c: RGB): RGB => mapRgb(c, linearToSrgbChannel)

/** Decode encoded RGB of any supported space to linear-light RGB *of that same space*. */
export function decodeRgb(space: RgbSpaceId, c: RGB): RGB {
  return mapRgb(c, space === 'rec2020' ? rec2020ToLinearChannel : srgbToLinearChannel)
}
/** Encode linear-light RGB of a space to its display-referred (encoded) values. */
export function encodeRgb(space: RgbSpaceId, c: RGB): RGB {
  return mapRgb(c, space === 'rec2020' ? linearToRec2020Channel : linearToSrgbChannel)
}

// ───────────────────────── XYZ ─────────────────────────

export function linearToXyz(c: RGB, space: RgbSpaceId = 'srgb'): XYZ {
  const v = mulMat3(RGB_SPACES[space].toXyz, c)
  return { x: v.r, y: v.g, z: v.b }
}

export function xyzToLinear(xyz: XYZ, space: RgbSpaceId = 'srgb'): RGB {
  return mulMat3(RGB_SPACES[space].fromXyz, { r: xyz.x, g: xyz.y, b: xyz.z })
}

/** Convert linear-light RGB between two RGB spaces (no gamut mapping — out-of-range values are preserved). */
export function convertLinear(c: RGB, from: RgbSpaceId, to: RgbSpaceId): RGB {
  if (from === to) return { ...c }
  return xyzToLinear(linearToXyz(c, from), to)
}

/** Relative luminance Y from linear sRGB-primaries RGB. */
export function relativeLuminance(linear: RGB): number {
  const m = SRGB_TO_XYZ
  return m[3] * linear.r + m[4] * linear.g + m[5] * linear.b
}

// ───────────────────────── CIELAB / CIELCh ─────────────────────────

const LAB_EPS = 216 / 24389
const LAB_KAPPA = 24389 / 27

export function xyzToLab(xyz: XYZ, white: XYZ = D65_WHITE): Lab {
  const f = (t: number) => (t > LAB_EPS ? Math.cbrt(t) : (LAB_KAPPA * t + 16) / 116)
  const fx = f(xyz.x / white.x)
  const fy = f(xyz.y / white.y)
  const fz = f(xyz.z / white.z)
  return { l: 116 * fy - 16, a: 500 * (fx - fy), b: 200 * (fy - fz) }
}

export function labToXyz(lab: Lab, white: XYZ = D65_WHITE): XYZ {
  const fy = (lab.l + 16) / 116
  const fx = fy + lab.a / 500
  const fz = fy - lab.b / 200
  const finv = (t: number) => {
    const t3 = t * t * t
    return t3 > LAB_EPS ? t3 : (116 * t - 16) / LAB_KAPPA
  }
  const yr = lab.l > LAB_KAPPA * LAB_EPS ? Math.pow((lab.l + 16) / 116, 3) : lab.l / LAB_KAPPA
  return { x: finv(fx) * white.x, y: yr * white.y, z: finv(fz) * white.z }
}

export const ACHROMATIC_EPS_LAB = 1e-3
export const ACHROMATIC_EPS_OK = 2e-5

export const normHue = (h: number) => ((h % 360) + 360) % 360

export function labToLch(lab: Lab): LCh {
  const c = Math.hypot(lab.a, lab.b)
  return { l: lab.l, c, h: c < ACHROMATIC_EPS_LAB ? 0 : normHue((Math.atan2(lab.b, lab.a) * 180) / Math.PI) }
}

export function lchToLab(lch: LCh): Lab {
  const h = (lch.h * Math.PI) / 180
  return { l: lch.l, a: lch.c * Math.cos(h), b: lch.c * Math.sin(h) }
}

// ───────────────────────── OKLab / OKLCh (Ottosson 2020) ─────────────────────────

export function linearToOklab(c: RGB): Lab {
  const l = Math.cbrt(0.4122214708 * c.r + 0.5363325363 * c.g + 0.0514459929 * c.b)
  const m = Math.cbrt(0.2119034982 * c.r + 0.6806995451 * c.g + 0.1073969566 * c.b)
  const s = Math.cbrt(0.0883024619 * c.r + 0.2817188376 * c.g + 0.6299787005 * c.b)
  return {
    l: 0.2104542553 * l + 0.793617785 * m - 0.0040720468 * s,
    a: 1.9779984951 * l - 2.428592205 * m + 0.4505937099 * s,
    b: 0.0259040371 * l + 0.7827717662 * m - 0.808675766 * s,
  }
}

export function oklabToLinear(lab: Lab): RGB {
  const l = Math.pow(lab.l + 0.3963377774 * lab.a + 0.2158037573 * lab.b, 3)
  const m = Math.pow(lab.l - 0.1055613458 * lab.a - 0.0638541728 * lab.b, 3)
  const s = Math.pow(lab.l - 0.0894841775 * lab.a - 1.291485548 * lab.b, 3)
  return {
    r: 4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
    g: -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
    b: -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s,
  }
}

export function oklabToOklch(lab: Lab): LCh {
  const c = Math.hypot(lab.a, lab.b)
  return { l: lab.l, c, h: c < ACHROMATIC_EPS_OK ? 0 : normHue((Math.atan2(lab.b, lab.a) * 180) / Math.PI) }
}

export const oklchToOklab = lchToLab

// ───────────────────────── HSL / HSV / HWB (on encoded sRGB) ─────────────────────────

function hueFromRgb(r: number, g: number, b: number, max: number, d: number): number {
  let h: number
  if (max === r) h = ((g - b) / d) % 6
  else if (max === g) h = (b - r) / d + 2
  else h = (r - g) / d + 4
  return normHue(h * 60)
}

function sector(h: number, c: number, x: number): [number, number, number] {
  if (h < 1) return [c, x, 0]
  if (h < 2) return [x, c, 0]
  if (h < 3) return [0, c, x]
  if (h < 4) return [0, x, c]
  if (h < 5) return [x, 0, c]
  return [c, 0, x]
}

export function rgbToHsl(c: RGB): HSL {
  const { r, g, b } = c
  const max = Math.max(r, g, b), min = Math.min(r, g, b)
  const l = (max + min) / 2
  const d = max - min
  if (d < 1e-9) return { h: 0, s: 0, l }
  const s = d / (1 - Math.abs(2 * l - 1))
  return { h: hueFromRgb(r, g, b, max, d), s, l }
}

export function hslToRgb(c: HSL): RGB {
  const h = normHue(c.h) / 60
  const ch = (1 - Math.abs(2 * c.l - 1)) * c.s
  const x = ch * (1 - Math.abs((h % 2) - 1))
  const m = c.l - ch / 2
  const [r, g, b] = sector(h, ch, x)
  return { r: r + m, g: g + m, b: b + m }
}

export function rgbToHsv(c: RGB): HSV {
  const max = Math.max(c.r, c.g, c.b), min = Math.min(c.r, c.g, c.b)
  const d = max - min
  if (d < 1e-9) return { h: 0, s: 0, v: max }
  return { h: hueFromRgb(c.r, c.g, c.b, max, d), s: d / max, v: max }
}

export function hsvToRgb(c: HSV): RGB {
  const h = normHue(c.h) / 60
  const ch = c.v * c.s
  const x = ch * (1 - Math.abs((h % 2) - 1))
  const m = c.v - ch
  const [r, g, b] = sector(h, ch, x)
  return { r: r + m, g: g + m, b: b + m }
}

export function rgbToHwb(c: RGB): HWB {
  const hsv = rgbToHsv(c)
  return { h: hsv.h, w: (1 - hsv.s) * hsv.v, b: 1 - hsv.v }
}

export function hwbToRgb(c: HWB): RGB {
  const w = c.w, b = c.b
  if (w + b >= 1) {
    const g = w / (w + b)
    return { r: g, g, b: g }
  }
  const rgb = hsvToRgb({ h: c.h, s: 1, v: 1 })
  const k = 1 - w - b
  return { r: rgb.r * k + w, g: rgb.g * k + w, b: rgb.b * k + w }
}

// ───────────────────────── 8-bit and hex ─────────────────────────

export const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v)
export const clamp = (v: number, lo: number, hi: number) => (v < lo ? lo : v > hi ? hi : v)

export const to8 = (v: number) => Math.round(clamp01(v) * 255)

export function rgbToHex(c: RGB, alpha = 1): string {
  const h = (v: number) => to8(v).toString(16).padStart(2, '0')
  const base = `#${h(c.r)}${h(c.g)}${h(c.b)}`
  return alpha < 1 ? base + h(alpha) : base
}

export interface ParsedHex { rgb: RGB; alpha: number }

/** Parse #rgb, #rgba, #rrggbb, #rrggbbaa (leading # optional). Returns null on anything else. */
export function parseHex(input: string): ParsedHex | null {
  const s = input.trim().replace(/^#/, '')
  if (!/^[0-9a-fA-F]+$/.test(s)) return null
  let full: string
  if (s.length === 3 || s.length === 4) full = s.split('').map((ch) => ch + ch).join('')
  else if (s.length === 6 || s.length === 8) full = s
  else return null
  const n = (i: number) => parseInt(full.slice(i, i + 2), 16) / 255
  return { rgb: { r: n(0), g: n(2), b: n(4) }, alpha: full.length === 8 ? n(6) : 1 }
}

// ───────────────────────── grayscale & CMYK preview ─────────────────────────

/** Luminance-preserving grayscale, returned as an encoded-sRGB value. */
export function toGrayscaleEncoded(linear: RGB): number {
  return linearToSrgbChannel(clamp01(relativeLuminance(linear)))
}

export interface CMYK { c: number; m: number; y: number; k: number }

/**
 * NAIVE device-independent RGB→CMYK. This is a *preview approximation only* and is not a
 * colour-managed conversion; it knows nothing about inks, paper or profiles.
 */
export function rgbToCmykNaive(encoded: RGB): CMYK {
  const r = clamp01(encoded.r), g = clamp01(encoded.g), b = clamp01(encoded.b)
  const k = 1 - Math.max(r, g, b)
  if (k >= 1 - 1e-9) return { c: 0, m: 0, y: 0, k: 1 }
  return { c: (1 - r - k) / (1 - k), m: (1 - g - k) / (1 - k), y: (1 - b - k) / (1 - k), k }
}

export function cmykToRgbNaive(c: CMYK): RGB {
  return { r: (1 - c.c) * (1 - c.k), g: (1 - c.m) * (1 - c.k), b: (1 - c.y) * (1 - c.k) }
}

// ───────────────────────── composed bundle ─────────────────────────

export interface ColourSpaces {
  srgb: RGB
  linearRgb: RGB
  hsl: HSL
  hsv: HSV
  hwb: HWB
  xyz: XYZ
  lab: Lab
  lch: LCh
  oklab: Lab
  oklch: LCh
  luminance: number
  displayP3: RGB
  rec2020: RGB
}

/** The single entry point: linear-light sRGB-primaries RGB → every representation. */
export function spacesFromLinear(linear: RGB): ColourSpaces {
  const srgb = linearToSrgb(linear)
  const xyz = linearToXyz(linear)
  const lab = xyzToLab(xyz)
  const oklab = linearToOklab(linear)
  return {
    srgb,
    linearRgb: linear,
    hsl: rgbToHsl(srgb),
    hsv: rgbToHsv(srgb),
    hwb: rgbToHwb(srgb),
    xyz,
    lab,
    lch: labToLch(lab),
    oklab,
    oklch: oklabToOklch(oklab),
    luminance: relativeLuminance(linear),
    displayP3: encodeRgb('displayP3', convertLinear(linear, 'srgb', 'displayP3')),
    rec2020: encodeRgb('rec2020', convertLinear(linear, 'srgb', 'rec2020')),
  }
}
