import type { ColourRecord } from './colour-model'
import { parseHex } from './conversions'

export type Severity = 'error' | 'warning' | 'info'
export interface ValidationIssue {
  severity: Severity
  code: 'missing-name' | 'invalid-value' | 'out-of-gamut-srgb' | 'out-of-gamut-p3' | 'hex-mismatch' | 'alpha-range' | 'duplicate-id'
  message: string
  colourId?: string
}

const finite = (v: number) => Number.isFinite(v)

export function validateRecord(rec: ColourRecord): ValidationIssue[] {
  const issues: ValidationIssue[] = []
  const at = { colourId: rec.id }
  if (!rec.name || !rec.name.trim()) issues.push({ severity: 'warning', code: 'missing-name', message: `Colour ${rec.hex} has no name`, ...at })
  const nums = [rec.srgb.r, rec.srgb.g, rec.srgb.b, rec.linearRgb.r, rec.linearRgb.g, rec.linearRgb.b, rec.lab.l, rec.lab.a, rec.lab.b, rec.oklab.l, rec.oklab.a, rec.oklab.b, rec.alpha]
  if (!nums.every(finite)) issues.push({ severity: 'error', code: 'invalid-value', message: `${rec.name || rec.id}: contains a non-finite channel value`, ...at })
  if (!parseHex(rec.hex)) issues.push({ severity: 'error', code: 'invalid-value', message: `${rec.name || rec.id}: invalid hex "${rec.hex}"`, ...at })
  if (rec.alpha < 0 || rec.alpha > 1) issues.push({ severity: 'error', code: 'alpha-range', message: `${rec.name || rec.id}: alpha ${rec.alpha} outside 0–1`, ...at })
  if (!rec.gamutStatus.srgb) {
    issues.push({
      severity: rec.gamutStatus.displayP3 ? 'info' : 'warning',
      code: rec.gamutStatus.displayP3 ? 'out-of-gamut-srgb' : 'out-of-gamut-p3',
      message: `${rec.name || rec.id}: outside sRGB gamut${rec.gamutStatus.displayP3 ? ' (inside Display P3)' : rec.gamutStatus.rec2020 ? ' (inside Rec.2020 only)' : ' (outside Rec.2020)'}; hex export is clipped`,
      ...at,
    })
  }
  return issues
}

export function validateRecords(recs: ColourRecord[]): ValidationIssue[] {
  const out: ValidationIssue[] = []
  const seen = new Set<string>()
  for (const r of recs) {
    if (seen.has(r.id)) out.push({ severity: 'error', code: 'duplicate-id', message: `Duplicate colour id ${r.id}`, colourId: r.id })
    seen.add(r.id)
    out.push(...validateRecord(r))
  }
  return out
}
