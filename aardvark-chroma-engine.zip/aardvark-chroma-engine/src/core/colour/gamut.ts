import {
  type RGB, type RgbSpaceId, convertLinear, oklabToLinear, linearToOklab, oklchToOklab, oklabToOklch, clamp01,
} from './conversions'

/** Tolerance that absorbs floating-point noise at the gamut boundary. */
export const GAMUT_EPS = 1e-4

export interface GamutStatus { srgb: boolean; displayP3: boolean; rec2020: boolean }

/** Is a linear-light sRGB-primaries colour inside the given RGB space's gamut? */
export function inGamut(linearSrgb: RGB, space: RgbSpaceId): boolean {
  const c = convertLinear(linearSrgb, 'srgb', space)
  const lo = -GAMUT_EPS, hi = 1 + GAMUT_EPS
  return c.r >= lo && c.r <= hi && c.g >= lo && c.g <= hi && c.b >= lo && c.b <= hi
}

export function gamutStatus(linearSrgb: RGB): GamutStatus {
  return {
    srgb: inGamut(linearSrgb, 'srgb'),
    displayP3: inGamut(linearSrgb, 'displayP3'),
    rec2020: inGamut(linearSrgb, 'rec2020'),
  }
}

export const clipLinear = (c: RGB): RGB => ({ r: clamp01(c.r), g: clamp01(c.g), b: clamp01(c.b) })

/** How far outside the target gamut a colour is: max channel excursion (0 when inside). */
export function gamutExcursion(linearSrgb: RGB, space: RgbSpaceId = 'srgb'): number {
  const c = convertLinear(linearSrgb, 'srgb', space)
  const ex = (v: number) => (v < 0 ? -v : v > 1 ? v - 1 : 0)
  return Math.max(ex(c.r), ex(c.g), ex(c.b))
}

/**
 * Gamut-map by reducing OKLCh chroma at constant lightness and hue until the colour is inside `space`.
 * Deterministic 24-step bisection. Preserves hue and lightness far better than per-channel clipping.
 */
export function mapToGamutOklch(linearSrgb: RGB, space: RgbSpaceId = 'srgb'): RGB {
  if (inGamut(linearSrgb, space)) return linearSrgb
  const ok = oklabToOklch(linearToOklab(linearSrgb))
  if (ok.l <= 0) return { r: 0, g: 0, b: 0 }
  if (ok.l >= 1) return { r: 1, g: 1, b: 1 }
  let lo = 0, hi = ok.c
  for (let i = 0; i < 24; i++) {
    const mid = (lo + hi) / 2
    const cand = oklabToLinear(oklchToOklab({ l: ok.l, c: mid, h: ok.h }))
    if (inGamut(cand, space)) lo = mid
    else hi = mid
  }
  const out = oklabToLinear(oklchToOklab({ l: ok.l, c: lo, h: ok.h }))
  const back = convertLinear(out, 'srgb', 'srgb')
  return space === 'srgb' ? clipLinear(back) : back
}

/** Maximum in-gamut OKLCh chroma for given lightness and hue (used by palette gamut restriction). */
export function maxChromaOklch(l: number, h: number, space: RgbSpaceId = 'srgb'): number {
  let lo = 0, hi = 0.5
  for (let i = 0; i < 24; i++) {
    const mid = (lo + hi) / 2
    if (inGamut(oklabToLinear(oklchToOklab({ l, c: mid, h })), space)) lo = mid
    else hi = mid
  }
  return lo
}
