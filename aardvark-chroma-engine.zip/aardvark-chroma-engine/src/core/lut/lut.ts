import { clamp01 } from '../colour/conversions'

/**
 * Simplified LUT model. A 3D LUT here maps encoded sRGB (0..1) → encoded sRGB, sampled on a size³ lattice with
 * red varying fastest (the .cube convention). Application uses trilinear interpolation. It is a coherent model of a
 * display-referred look LUT — not a scene-referred, shaper-based or tetrahedral production implementation.
 */

export interface Lut3D {
  title: string
  size: number
  data: Float32Array   // size³ × 3, red fastest
}

export type RGBTuple = [number, number, number]
export type LutFn = (r: number, g: number, b: number) => RGBTuple

const luma = (r: number, g: number, b: number) => 0.2126 * r + 0.7152 * g + 0.0722 * b
const sCurve = (x: number, k: number) => {
  const t = clamp01(x)
  const a = 1 / (1 + Math.exp(-k * (t - 0.5)))
  const lo = 1 / (1 + Math.exp(k * 0.5)), hi = 1 / (1 + Math.exp(-k * 0.5))
  return (a - lo) / (hi - lo)
}
const sat = (r: number, g: number, b: number, s: number): RGBTuple => { const y = luma(r, g, b); return [y + (r - y) * s, y + (g - y) * s, y + (b - y) * s] }

export interface LutPreset { id: string; name: string; description: string; fn: LutFn }

export const LUT_PRESETS: LutPreset[] = [
  { id: 'identity', name: 'Identity', description: 'Output equals input. Used as the reference for validation.', fn: (r, g, b) => [r, g, b] },
  { id: 'contrast', name: 'Contrast', description: 'Sigmoid per-channel contrast (k = 5.2).', fn: (r, g, b) => [sCurve(r, 5.2), sCurve(g, 5.2), sCurve(b, 5.2)] },
  { id: 'warm-cool', name: 'Warm–cool split', description: 'Cool shadows, warm highlights: blue lifted in the lows, red lifted in the highs.',
    fn: (r, g, b) => { const y = luma(r, g, b); return [r + 0.06 * y - 0.01, g + 0.01 * y, b + 0.05 * (1 - y) - 0.05 * y] } },
  { id: 'desaturate', name: 'Desaturation', description: 'Global saturation ×0.45 about Rec.709 luma.', fn: (r, g, b) => sat(r, g, b, 0.45) },
  { id: 'filmic', name: 'Filmic-look approximation', description: 'Toe + shoulder S-curve, mild desaturation of extremes, teal shadows / amber highlights. An approximation, not a film-stock emulation.',
    fn: (r, g, b) => {
      const c = [sCurve(r, 4.4), sCurve(g, 4.4), sCurve(b, 4.4)] as RGBTuple
      const y = luma(c[0], c[1], c[2])
      const s = sat(c[0], c[1], c[2], 0.9 - 0.25 * Math.pow(2 * y - 1, 2))
      return [s[0] + 0.035 * y - 0.01, s[1] + 0.006, s[2] + 0.03 * (1 - y) - 0.03 * y]
    } },
  { id: 'industrial-orange', name: 'Industrial orange', description: 'Pushes warm mids toward orange, deepens graphite shadows, holds neutral highlights.',
    fn: (r, g, b) => { const y = luma(r, g, b); const m = 4 * y * (1 - y); const c = sat(sCurve(r, 3.6), sCurve(g, 3.6), sCurve(b, 3.6), 1.1); return [c[0] + 0.07 * m, c[1] + 0.012 * m, c[2] - 0.06 * m] } },
  { id: 'cool-architectural', name: 'Cool architectural', description: 'Blue-grey bias, restrained saturation, clean lifted blacks.',
    fn: (r, g, b) => { const c = sat(r, g, b, 0.82); return [c[0] * 0.97 + 0.008, c[1] * 1.0 + 0.012, c[2] * 1.04 + 0.022] } },
  { id: 'monochrome', name: 'Monochrome', description: 'Luma-only output with a gentle contrast curve.', fn: (r, g, b) => { const y = sCurve(luma(r, g, b), 3.2); return [y, y, y] } },
]

export function buildLut(fn: LutFn, size = 17, title = 'CHROMA ENGINE LUT'): Lut3D {
  const data = new Float32Array(size * size * size * 3)
  let i = 0
  for (let b = 0; b < size; b++) for (let g = 0; g < size; g++) for (let r = 0; r < size; r++) {
    const o = fn(r / (size - 1), g / (size - 1), b / (size - 1))
    data[i++] = o[0]; data[i++] = o[1]; data[i++] = o[2]
  }
  return { title, size, data }
}

/** Trilinear lookup; inputs are clamped to 0..1, output is not clamped (out-of-range values are reported by validateLut). */
export function sampleLut(lut: Lut3D, r: number, g: number, b: number, out: RGBTuple): void {
  const n = lut.size - 1
  const x = clamp01(r) * n, y = clamp01(g) * n, z = clamp01(b) * n
  const x0 = Math.min(n - 1, Math.floor(x)), y0 = Math.min(n - 1, Math.floor(y)), z0 = Math.min(n - 1, Math.floor(z))
  const fx = x - x0, fy = y - y0, fz = z - z0
  const s = lut.size, d = lut.data
  const idx = (xx: number, yy: number, zz: number) => ((zz * s + yy) * s + xx) * 3
  for (let c = 0; c < 3; c++) {
    const c000 = d[idx(x0, y0, z0) + c], c100 = d[idx(x0 + 1, y0, z0) + c]
    const c010 = d[idx(x0, y0 + 1, z0) + c], c110 = d[idx(x0 + 1, y0 + 1, z0) + c]
    const c001 = d[idx(x0, y0, z0 + 1) + c], c101 = d[idx(x0 + 1, y0, z0 + 1) + c]
    const c011 = d[idx(x0, y0 + 1, z0 + 1) + c], c111 = d[idx(x0 + 1, y0 + 1, z0 + 1) + c]
    const c00 = c000 + (c100 - c000) * fx, c10 = c010 + (c110 - c010) * fx
    const c01 = c001 + (c101 - c001) * fx, c11 = c011 + (c111 - c011) * fx
    const c0 = c00 + (c10 - c00) * fy, c1 = c01 + (c11 - c01) * fy
    out[c] = c0 + (c1 - c0) * fz
  }
}

export type LutBlend = 'normal' | 'luminosity' | 'colour'
export const LUT_BLENDS: { id: LutBlend; label: string }[] = [
  { id: 'normal', label: 'Normal (mix)' },
  { id: 'luminosity', label: 'Luminosity only' },
  { id: 'colour', label: 'Colour only' },
]

/** Blend original and LUT output (all encoded). */
export function blendLut(orig: RGBTuple, lutd: RGBTuple, strength: number, mode: LutBlend, out: RGBTuple): void {
  let t: RGBTuple = lutd
  if (mode === 'luminosity') {
    const k = luma(orig[0], orig[1], orig[2]), l = luma(lutd[0], lutd[1], lutd[2])
    const d = l - k
    t = [orig[0] + d, orig[1] + d, orig[2] + d]
  } else if (mode === 'colour') {
    const k = luma(orig[0], orig[1], orig[2]), l = luma(lutd[0], lutd[1], lutd[2])
    const d = k - l
    t = [lutd[0] + d, lutd[1] + d, lutd[2] + d]
  }
  out[0] = orig[0] + (t[0] - orig[0]) * strength
  out[1] = orig[1] + (t[1] - orig[1]) * strength
  out[2] = orig[2] + (t[2] - orig[2]) * strength
}

// ───────────── .cube text ─────────────

export function toCube(lut: Lut3D, meta: { title?: string; comments?: string[] } = {}): string {
  const lines: string[] = []
  lines.push(`TITLE "${(meta.title ?? lut.title).replace(/"/g, "'")}"`)
  for (const c of meta.comments ?? []) lines.push(`# ${c.replace(/\n/g, ' ')}`)
  lines.push(`LUT_3D_SIZE ${lut.size}`)
  lines.push('DOMAIN_MIN 0.0 0.0 0.0')
  lines.push('DOMAIN_MAX 1.0 1.0 1.0')
  for (let i = 0; i < lut.data.length; i += 3) {
    lines.push(`${lut.data[i].toFixed(6)} ${lut.data[i + 1].toFixed(6)} ${lut.data[i + 2].toFixed(6)}`)
  }
  return lines.join('\n') + '\n'
}

export function parseCube(text: string): Lut3D | { error: string } {
  let size = 0, title = 'Imported LUT'
  const vals: number[] = []
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim()
    if (!line || line.startsWith('#')) continue
    if (line.startsWith('TITLE')) { title = line.replace(/^TITLE\s*/, '').replace(/^"|"$/g, ''); continue }
    if (line.startsWith('LUT_3D_SIZE')) { size = parseInt(line.split(/\s+/)[1], 10); continue }
    if (line.startsWith('LUT_1D_SIZE')) return { error: '1D .cube files are not supported by this importer.' }
    if (line.startsWith('DOMAIN_')) continue
    const p = line.split(/\s+/).map(Number)
    if (p.length === 3 && p.every(Number.isFinite)) vals.push(...p)
    else return { error: `Unparseable line: "${line.slice(0, 40)}"` }
  }
  if (!Number.isInteger(size) || size < 2 || size > 65) return { error: 'Missing or invalid LUT_3D_SIZE.' }
  if (vals.length !== size * size * size * 3) return { error: `Expected ${size ** 3} entries, found ${vals.length / 3}.` }
  return { title, size, data: Float32Array.from(vals) }
}

// ───────────── validation ─────────────

export interface LutValidation {
  valid: boolean
  issues: { severity: 'error' | 'warning' | 'info'; message: string }[]
  outOfRange: number
  neutralMonotonic: boolean
  maxIdentityDelta: number
  meanIdentityDelta: number
}

export function validateLut(lut: Lut3D): LutValidation {
  const issues: LutValidation['issues'] = []
  const n = lut.size
  let outOfRange = 0, maxD = 0, sumD = 0
  const total = n * n * n
  if (lut.data.length !== total * 3) issues.push({ severity: 'error', message: `Data length ${lut.data.length} does not match size ${n}³×3.` })
  let i = 0
  for (let b = 0; b < n; b++) for (let g = 0; g < n; g++) for (let r = 0; r < n; r++) {
    const o = [lut.data[i], lut.data[i + 1], lut.data[i + 2]]
    if (o.some((v) => !Number.isFinite(v))) issues.push({ severity: 'error', message: `Non-finite value at (${r},${g},${b}).` })
    if (o.some((v) => v < -1e-6 || v > 1 + 1e-6)) outOfRange++
    const d = Math.max(Math.abs(o[0] - r / (n - 1)), Math.abs(o[1] - g / (n - 1)), Math.abs(o[2] - b / (n - 1)))
    maxD = Math.max(maxD, d); sumD += d
    i += 3
  }
  let mono = true
  let prev = -Infinity
  for (let k = 0; k < n; k++) {
    const idx = ((k * n + k) * n + k) * 3
    const y = luma(lut.data[idx], lut.data[idx + 1], lut.data[idx + 2])
    if (y < prev - 1e-6) mono = false
    prev = y
  }
  if (outOfRange > 0) issues.push({ severity: 'warning', message: `${outOfRange} of ${total} lattice points produce values outside 0–1 and will clip.` })
  if (!mono) issues.push({ severity: 'warning', message: 'Neutral axis is not monotonic: tonal inversions along the grey ramp.' })
  if (maxD < 1e-6) issues.push({ severity: 'info', message: 'LUT is an identity transform.' })
  if (n < 17) issues.push({ severity: 'info', message: `Lattice size ${n} is coarse; 17 or 33 is typical.` })
  return {
    valid: !issues.some((x) => x.severity === 'error'), issues, outOfRange, neutralMonotonic: mono,
    maxIdentityDelta: maxD, meanIdentityDelta: sumD / total,
  }
}

/** Sample a LUT's response along the neutral axis (for the 1D curve display) and per-channel ramps. */
export function neutralCurves(lut: Lut3D, samples = 64): { x: number[]; r: number[]; g: number[]; b: number[] } {
  const x: number[] = [], r: number[] = [], g: number[] = [], b: number[] = []
  const o: RGBTuple = [0, 0, 0]
  for (let i = 0; i < samples; i++) {
    const t = i / (samples - 1)
    sampleLut(lut, t, t, t, o)
    x.push(t); r.push(o[0]); g.push(o[1]); b.push(o[2])
  }
  return { x, r, g, b }
}
