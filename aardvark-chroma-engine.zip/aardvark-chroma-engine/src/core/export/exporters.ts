import type { ColourRecord } from '../colour/colour-model'
import { cssColorFunction } from '../colour/colour-model'
import { validateRecords, type ValidationIssue } from '../colour/colour-validation'
import { wcagContrast } from '../colour/contrast'

export const APP_NAME = 'CHROMA ENGINE'
export const APP_VENDOR = 'Aardvark Imaging'
export const APP_VERSION = '0.1.0'

export interface ExportMeta {
  projectName: string
  projectCode: string
  assetName: string
  workingSpace: string
  sourceProfile: string
  destinationProfile: string
  operatorNotes: string
  timestamp: string
}

export interface NamedColour { group: string; record: ColourRecord }

const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'unnamed'
const camel = (s: string) => slug(s).replace(/-([a-z0-9])/g, (_, c: string) => c.toUpperCase())
const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')

function uniqueNames(cs: NamedColour[], fn: (s: string) => string): string[] {
  const seen = new Map<string, number>()
  return cs.map((c) => {
    const base = fn(c.record.name || c.record.hex)
    const n = (seen.get(base) ?? 0) + 1
    seen.set(base, n)
    return n === 1 ? base : `${base}-${n}`
  })
}

export function headerComment(meta: ExportMeta, lines: string[] = []): string[] {
  return [
    `${APP_NAME} ${APP_VERSION} — ${APP_VENDOR}`,
    `Project: ${meta.projectName} (${meta.projectCode})`,
    `Asset: ${meta.assetName}`,
    `Working space: ${meta.workingSpace}; source profile: ${meta.sourceProfile}; destination profile: ${meta.destinationProfile}`,
    `Created: ${meta.timestamp}`,
    ...(meta.operatorNotes ? [`Operator notes: ${meta.operatorNotes.replace(/\n/g, ' ')}`] : []),
    ...lines,
  ]
}

export function toCssVariables(cs: NamedColour[], meta: ExportMeta): string {
  const names = uniqueNames(cs, slug)
  const body = cs.map((c, i) => `  --aai-${names[i]}: ${c.record.hex};${c.record.gamutStatus.srgb ? '' : ` /* out of sRGB gamut: clipped; true value ${cssColorFunction(c.record, 'display-p3')} */`}`)
  return `/*\n${headerComment(meta).map((l) => ` * ${l}`).join('\n')}\n */\n:root {\n${body.join('\n')}\n}\n`
}

export function toScss(cs: NamedColour[], meta: ExportMeta): string {
  const names = uniqueNames(cs, slug)
  return `${headerComment(meta).map((l) => `// ${l}`).join('\n')}\n${cs.map((c, i) => `$aai-${names[i]}: ${c.record.hex};`).join('\n')}\n`
}

export function toTypeScript(cs: NamedColour[], meta: ExportMeta): string {
  const names = uniqueNames(cs, camel)
  const rows = cs.map((c, i) => `  ${JSON.stringify(names[i])}: ${JSON.stringify(c.record.hex)},`)
  return `${headerComment(meta).map((l) => `// ${l}`).join('\n')}\nexport const colours = {\n${rows.join('\n')}\n} as const\n\nexport type ColourName = keyof typeof colours\n`
}

export function toDesignTokensJson(cs: NamedColour[], meta: ExportMeta): string {
  const tree: Record<string, Record<string, unknown>> = {}
  const names = uniqueNames(cs, slug)
  cs.forEach((c, i) => {
    const g = slug(c.group)
    tree[g] ??= {}
    tree[g][names[i]] = { $value: c.record.hex, $type: 'color', $description: c.record.metadata.notes ?? '', $extensions: { 'com.aardvark-imaging.chroma-engine': { oklch: c.record.oklch, gamut: c.record.gamutStatus } } }
  })
  return JSON.stringify({ $description: headerComment(meta).join(' | '), ...tree }, null, 2) + '\n'
}

export function toColourJson(cs: NamedColour[], meta: ExportMeta): string {
  return JSON.stringify({ application: `${APP_NAME} ${APP_VERSION}`, vendor: APP_VENDOR, meta, colours: cs.map((c) => ({ group: c.group, ...c.record })) }, null, 2) + '\n'
}

export function toCsv(cs: NamedColour[], meta: ExportMeta): string {
  const head = ['group', 'name', 'hex', 'alpha', 'srgb_r', 'srgb_g', 'srgb_b', 'oklch_l', 'oklch_c', 'oklch_h', 'lab_l', 'lab_a', 'lab_b', 'luminance', 'in_srgb', 'in_p3', 'in_rec2020']
  const f = (v: number, d = 4) => (Math.round(v * 10 ** d) / 10 ** d).toString()
  const q = (s: string) => `"${s.replace(/"/g, '""')}"`
  const rows = cs.map((c) => [q(c.group), q(c.record.name), c.record.hex, f(c.record.alpha), f(c.record.srgb.r), f(c.record.srgb.g), f(c.record.srgb.b), f(c.record.oklch.l), f(c.record.oklch.c), f(c.record.oklch.h, 2), f(c.record.lab.l, 2), f(c.record.lab.a, 2), f(c.record.lab.b, 2), f(c.record.luminance), c.record.gamutStatus.srgb, c.record.gamutStatus.displayP3, c.record.gamutStatus.rec2020].join(','))
  return `${headerComment(meta).map((l) => `# ${l}`).join('\n')}\n${head.join(',')}\n${rows.join('\n')}\n`
}

/** CONCEPTUAL ASE-style block structure as JSON. It is NOT a binary Adobe Swatch Exchange file. */
export function toAseConceptual(cs: NamedColour[], meta: ExportMeta): string {
  const groups = [...new Set(cs.map((c) => c.group))]
  return JSON.stringify({
    format: 'ASE-conceptual (JSON representation; not binary .ase)',
    application: `${APP_NAME} ${APP_VERSION}`, meta,
    blocks: groups.flatMap((g) => [
      { type: 'groupStart', name: g },
      ...cs.filter((c) => c.group === g).map((c) => ({ type: 'colour', name: c.record.name, model: 'RGB', values: [c.record.srgb.r, c.record.srgb.g, c.record.srgb.b].map((v) => Math.min(1, Math.max(0, v))), colourType: 'global' })),
      { type: 'groupEnd' },
    ]),
  }, null, 2) + '\n'
}

export function toSvgSheet(cs: NamedColour[], meta: ExportMeta): string {
  const cols = Math.min(6, Math.max(1, cs.length)), cw = 168, ch = 132, pad = 24, headH = 96
  const rows = Math.ceil(cs.length / cols)
  const W = pad * 2 + cols * cw, H = headH + rows * ch + pad
  const cells = cs.map((c, i) => {
    const x = pad + (i % cols) * cw, y = headH + Math.floor(i / cols) * ch
    const dark = wcagContrast(c.record.linearRgb, { r: 1, g: 1, b: 1 }) > wcagContrast(c.record.linearRgb, { r: 0, g: 0, b: 0 })
    const ink = dark ? '#ffffff' : '#111111'
    const oklch = `OKLCH ${c.record.oklch.l.toFixed(3)} ${c.record.oklch.c.toFixed(3)} ${c.record.oklch.h.toFixed(0)}`
    return `<g><rect x="${x}" y="${y}" width="${cw - 8}" height="${ch - 8}" fill="${c.record.hex}"/>` +
      `<text x="${x + 8}" y="${y + 20}" font-family="Arial, sans-serif" font-size="11" font-weight="700" fill="${ink}">${esc(c.record.name.toUpperCase())}</text>` +
      `<text x="${x + 8}" y="${y + ch - 46}" font-family="Arial, sans-serif" font-size="10" fill="${ink}">${c.record.hex.toUpperCase()}${c.record.gamutStatus.srgb ? '' : ' (CLIPPED)'}</text>` +
      `<text x="${x + 8}" y="${y + ch - 32}" font-family="Arial, sans-serif" font-size="9" fill="${ink}">${oklch}</text>` +
      `<text x="${x + 8}" y="${y + ch - 18}" font-family="Arial, sans-serif" font-size="9" fill="${ink}">${esc(c.group)}</text></g>`
  })
  return `<?xml version="1.0" encoding="UTF-8"?>\n<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">\n` +
    `<!-- ${esc(headerComment(meta).join(' | ')).replace(/--/g, '- -')} -->\n<rect width="${W}" height="${H}" fill="#f2eee6"/>\n` +
    `<rect x="${pad}" y="${pad}" width="6" height="40" fill="#e8630a"/>\n` +
    `<text x="${pad + 16}" y="${pad + 16}" font-family="Arial, sans-serif" font-size="16" font-weight="700" fill="#16191c">${esc(meta.projectName.toUpperCase())}</text>\n` +
    `<text x="${pad + 16}" y="${pad + 34}" font-family="Arial, sans-serif" font-size="10" fill="#4a5058">${esc(APP_VENDOR)} · ${esc(meta.projectCode)} · ${esc(meta.workingSpace)} · ${esc(meta.timestamp.slice(0, 10))}</text>\n` +
    `${cells.join('\n')}\n</svg>\n`
}

export function toHtmlSpecimen(cs: NamedColour[], meta: ExportMeta): string {
  const rows = cs.map((c) => {
    const ci = wcagContrast(c.record.linearRgb, { r: 1, g: 1, b: 1 })
    return `<tr><td><span style="display:inline-block;width:56px;height:24px;background:${c.record.hex};border:1px solid #16191c"></span></td><td>${esc(c.record.name)}</td><td>${esc(c.group)}</td><td class="n">${c.record.hex.toUpperCase()}</td><td class="n">${c.record.oklch.l.toFixed(3)} ${c.record.oklch.c.toFixed(3)} ${c.record.oklch.h.toFixed(1)}</td><td class="n">${c.record.lab.l.toFixed(1)} ${c.record.lab.a.toFixed(1)} ${c.record.lab.b.toFixed(1)}</td><td class="n">${ci.toFixed(2)}:1</td><td>${c.record.gamutStatus.srgb ? 'sRGB' : c.record.gamutStatus.displayP3 ? 'P3 only' : c.record.gamutStatus.rec2020 ? '2020 only' : 'outside'}</td></tr>`
  }).join('\n')
  return `<!doctype html><html lang="en-GB"><head><meta charset="utf-8"><title>${esc(meta.projectName)} — Colour specimen</title><style>body{font:14px/1.5 Arial,sans-serif;background:#f2eee6;color:#16191c;margin:32px}h1{font-size:20px;margin:0;border-left:6px solid #e8630a;padding-left:12px}.m{color:#4a5058;font-size:12px;margin:6px 0 20px 18px}table{border-collapse:collapse;width:100%;background:#fbf9f4}th,td{border-bottom:1px solid #c9c4b8;padding:6px 8px;text-align:left}th{font-size:11px;text-transform:uppercase;letter-spacing:.06em;background:#e6e1d5}.n{font-variant-numeric:tabular-nums}</style></head><body><h1>${esc(meta.projectName)}</h1><div class="m">${esc(APP_VENDOR)} · ${esc(APP_NAME)} ${APP_VERSION} · ${esc(meta.projectCode)} · ${esc(meta.timestamp)}<br>Working space ${esc(meta.workingSpace)} · source ${esc(meta.sourceProfile)} · destination ${esc(meta.destinationProfile)}${meta.operatorNotes ? `<br>Operator notes: ${esc(meta.operatorNotes)}` : ''}</div><table><thead><tr><th></th><th>Name</th><th>Group</th><th>Hex</th><th>OKLCh</th><th>CIELAB</th><th>Contrast on white</th><th>Gamut</th></tr></thead><tbody>${rows}</tbody></table><p class="m">Colour values are display-referred sRGB unless stated. CMYK and print values in this application are approximations, not certified profile conversions.</p></body></html>\n`
}

export function toMarkdownReport(cs: NamedColour[], meta: ExportMeta, extra: { title: string; sections?: { heading: string; body: string }[] } = { title: 'Colour report' }): string {
  const rows = cs.map((c) => `| ${c.record.name} | ${c.group} | \`${c.record.hex}\` | ${c.record.oklch.l.toFixed(3)} / ${c.record.oklch.c.toFixed(3)} / ${c.record.oklch.h.toFixed(1)} | ${c.record.gamutStatus.srgb ? 'in' : 'OUT'} |`)
  return [
    `# ${extra.title}`, '', ...headerComment(meta).map((l) => `- ${l}`), '',
    ...(extra.sections ?? []).flatMap((s) => [`## ${s.heading}`, '', s.body, '']),
    '## Colours', '', '| Name | Group | Hex | OKLCh (L / C / h) | sRGB gamut |', '| --- | --- | --- | --- | --- |', ...rows, '',
    '> Values are display-referred and computed by a single deterministic conversion layer. This browser environment is not a calibrated colour-management system.', '',
  ].join('\n')
}

// ───────────── validation ─────────────

export interface ExportCheck { severity: 'error' | 'warning' | 'info'; message: string }

export interface ExportValidationInput {
  colours: NamedColour[]
  formatId: string
  outputIntentSet: boolean
  usesApproximateConversions: boolean
}

export function validateExport(input: ExportValidationInput): ExportCheck[] {
  const out: ExportCheck[] = []
  if (input.colours.length === 0 && input.formatId !== 'cube') out.push({ severity: 'error', message: 'Nothing selected to export.' })
  const issues: ValidationIssue[] = validateRecords(input.colours.map((c) => c.record))
  for (const i of issues) out.push({ severity: i.severity, message: i.message })
  if (!input.outputIntentSet) out.push({ severity: 'warning', message: 'Output intent is unspecified for this project; specify a production profile before print delivery.' })
  if (input.usesApproximateConversions) out.push({ severity: 'info', message: 'This export includes values derived from approximate conversions (CMYK preview, proof model).' })
  if (input.formatId === 'ase') out.push({ severity: 'warning', message: 'ASE export is a conceptual JSON structure, not a binary Adobe Swatch Exchange file (unsupported feature).' })
  if (input.formatId === 'png') out.push({ severity: 'info', message: 'PNG palette sheet is rendered in sRGB without an embedded ICC profile.' })
  const dup = new Set<string>(), names = new Set<string>()
  for (const c of input.colours) { if (names.has(c.record.name)) dup.add(c.record.name); names.add(c.record.name) }
  if (dup.size) out.push({ severity: 'info', message: `Duplicate names will be suffixed on export: ${[...dup].slice(0, 4).join(', ')}` })
  return out
}
