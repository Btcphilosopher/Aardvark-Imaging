import { hexRecord, DEMO_TIMESTAMP, makeRecord } from '../core/colour/colour-model'
import { MATERIALS } from '../core/materials/materials'
import { boardLayout } from '../core/image/procedural'
import { defaultGrade, GRADE_PRESETS } from '../core/grading/grade'
import { createPalette, defaultPaletteParams, type Palette } from '../core/colour/harmony'
import { srgbToLinear } from '../core/colour/conversions'
import type { Project, AssetMeta, BrandSystem, SavedSample, ConversionEntry, AssetVariant } from '../types/project'
import type { GeneratorId } from '../core/image/procedural'
import { cssOklch, cssLab, cssHsl } from '../utils/format'

export const APP_VERSION = '0.1.0'

export const AARDVARK_BRAND: BrandSystem = {
  name: 'Aardvark Imaging',
  tagline: 'Colour is measurement. Imaging is engineering.',
  colours: [
    { id: 'b-orange', group: 'Primary', name: 'Industrial orange', hex: '#e8630a', usage: 'Active tools, selected states, calibration markers, principal actions. Never as a large field.' },
    { id: 'b-graphite', group: 'Primary', name: 'Graphite', hex: '#23272b', usage: 'Workspace panels and primary text on light documents.' },
    { id: 'b-warm-white', group: 'Primary', name: 'Warm white', hex: '#f2eee6', usage: 'Documentation surfaces, reports and printed specimens.' },
    { id: 'b-aluminium', group: 'Neutral', name: 'Aluminium grey', hex: '#9aa3ab', usage: 'Technical controls, secondary labels and measurement lines.' },
    { id: 'b-near-black', group: 'Neutral', name: 'Near-black', hex: '#111315', usage: 'Image viewing surround. Neutral, never pure black.' },
    { id: 'b-blue-grey', group: 'Secondary', name: 'Deep blue-grey', hex: '#33475b', usage: 'Data series, secondary emphasis, architectural work.' },
    { id: 'b-sandstone', group: 'Secondary', name: 'Sandstone', hex: '#c8ad86', usage: 'Warm neutral for documentation backgrounds and material work.' },
    { id: 'b-copper', group: 'Accent', name: 'Oxidised copper', hex: '#3f8f7b', usage: 'Passed validations, in-gamut status, second data series.' },
    { id: 'b-red', group: 'Signal', name: 'Signal red', hex: '#d1281c', usage: 'Errors, clipping and out-of-gamut warnings (always with a symbol or text).' },
    { id: 'b-amber', group: 'Signal', name: 'Technical amber', hex: '#d99a00', usage: 'Cautions and approximation notices.' },
  ],
}

function asset(id: string, name: string, role: string, gen: GeneratorId, variant: AssetVariant, notes: string, sourceProfile = 'sRGB IEC 61966-2-1 (synthetic)'): AssetMeta {
  return {
    id, name, kind: 'image', role, width: 960, height: 640, colourSpace: variant === 'print' ? 'Approximate CMYK preview (matte coated, synthetic)' : 'sRGB, display-referred, 8-bit',
    sourceProfile, generator: { id: gen, variant }, notes, createdAt: DEMO_TIMESTAMP,
  }
}

function conversionEntries(): ConversionEntry[] {
  const list: [string, string][] = [['#e8630a', 'Industrial orange'], ['#aeb3b8', 'Brushed aluminium'], ['#c8ad86', 'Sandstone'], ['#3f8f7b', 'Oxidised copper']]
  const out: ConversionEntry[] = []
  list.forEach(([hex, name], i) => {
    const r = hexRecord(hex, name)
    out.push({ id: `cv_${i}a`, at: `2026-09-0${i + 1}T10:${10 + i}:00.000Z`, input: hex, from: 'sRGB (encoded)', to: 'OKLCh', output: cssOklch(r), reference: 'display-referred', note: name })
    out.push({ id: `cv_${i}b`, at: `2026-09-0${i + 1}T10:${20 + i}:00.000Z`, input: hex, from: 'sRGB (encoded)', to: 'CIELAB (D65)', output: cssLab(r), reference: 'display-referred', note: name })
  })
  out.push({ id: 'cv_hsl', at: '2026-09-05T09:00:00.000Z', input: '#e8630a', from: 'sRGB (encoded)', to: 'HSL', output: cssHsl(hexRecord('#e8630a', '')), reference: 'display-referred', note: 'Orange as HSL for CSS tokens' })
  return out
}

function materialSamples(): SavedSample[] {
  const { cells } = boardLayout(960, 640)
  return MATERIALS.filter((m) => m.onBoard).map((m): SavedSample => {
    const c = cells.find((cell) => cell.id === m.id)!
    return {
      id: `smp_${m.id}`, origin: 'reference', assetId: 'ast-working', point: { x: Math.round(c.x + c.w / 2), y: Math.round(c.y + c.h / 2) },
      note: `${m.category} — library reference value, not a pixel measurement`,
      record: hexRecord(m.baseHex, m.name, [m.category.toLowerCase()], `${m.id}-ref`, 'material library'),
    }
  }).slice(0, 8).concat([{
    id: 'smp_chip_orange', origin: 'reference', assetId: 'ast-working', point: { x: 900, y: 610 }, note: 'Colour chip on the calibration strip (deterministic)',
    record: hexRecord('#e8630a', 'Strip chip · orange', ['strip'], 'chip-orange', 'calibration strip'),
  }])
}

function palettesFor(): Palette[] {
  const p1 = createPalette('material', { ...defaultPaletteParams('#aeb3b8'), steps: 8 }, 'Optical materials — lightness order')
  const p2 = createPalette('cinematic', { ...defaultPaletteParams('#e8630a'), steps: 6 }, 'Industrial cinema split')
  const p3 = createPalette('industrial', { ...defaultPaletteParams('#e8630a'), steps: 8 }, 'Low-chroma industrial')
  const p4 = createPalette('accessible-ui', { ...defaultPaletteParams('#e8630a'), steps: 7 }, 'Documentation UI (accessible)')
  ;[p1, p2, p3, p4].forEach((p, i) => { p.createdAt = DEMO_TIMESTAMP; p.id = `pal_demo_${i + 1}`; p.colours.forEach((c, k) => { c.colour.id = `pal_demo_${i + 1}_${k}` }) })
  p1.notes = 'Sampled from the material library. Order is descending OKLab lightness.'
  p2.notes = 'Teal shadows and orange key for the graded version.'
  return [p1, p2, p3, p4]
}

const TECH_REPORT = `# Technical report — AAI-OPT-2026-014

**Optical Materials / Industrial Cinema Study**

## Scope
A colour-managed imaging study of twelve synthetic industrial materials rendered as a deterministic procedural board.
All assets are generated locally; no measured reflectance data or photographs are included.

## Pipeline summary
| Stage | Asset | Notes |
|---|---|---|
| Source | Board — source (flat) | Synthetic low-contrast encode standing in for a camera-log-style capture |
| Working | Board — working | Display-referred sRGB, 8-bit |
| Graded | Board — graded | Industrial cinema primary grade (simulated pipeline) |
| Print preview | Board — print preview | Approximate matte-coated proof — **not** a certified profile |
| Display preview | Board — display preview | Approximate display response simulation |

## Findings
- Powder-coated orange is the most gamut-critical material; it exceeds the approximate matte-coated gamut at full saturation.
- Wet asphalt reflections dominate the luminance range of the frame; protect them in the display preview.
- Graphite steel and black polymer hold their detail below code value 60. Do not lift blacks uniformly.

## Limitations
The browser is not a calibrated colour-management environment. CMYK values are approximations.
`

function materialSheet(): string {
  const rows = MATERIALS.map((m) => `| ${m.name} | ${m.category} | ${m.baseHex} | ${m.roughness.toFixed(2)} | ${m.metallic.toFixed(2)} | ${m.reflectance.toFixed(2)} |`).join('\n')
  return `# Material reference sheet\n\n| Material | Category | Base | Roughness | Metallic | Reflectance |\n|---|---|---|---|---|---|\n${rows}\n\nValues are approximations for colour studies.\n`
}

export function blankProject(id: string, code: string, name: string, description: string, gen: GeneratorId = 'material-board'): Project {
  return {
    id, code, name, description, createdAt: DEMO_TIMESTAMP, updatedAt: DEMO_TIMESTAMP, archived: false, notes: '', operator: 'Operator',
    workingSpace: 'sRGB (display-referred)', sourceProfile: 'sRGB IEC 61966-2-1 (synthetic)', outputIntent: 'Unspecified', destinationProfile: 'Unspecified',
    assets: [asset('ast-working', 'Working image', 'Working', gen, 'working', 'Deterministic procedural image.')], activeAssetId: 'ast-working',
    samples: [], palettes: [], currentGrade: defaultGrade(), gradeSnapshots: [], gradeAB: { a: null, b: null },
    lut: { presetId: 'identity', strength: 1, blend: 'normal', version: 1, history: [{ version: 1, presetId: 'identity', strength: 1, at: DEMO_TIMESTAMP }] },
    conversionHistory: [], measurements: [], annotations: [], brand: structuredClone(AARDVARK_BRAND),
    production: { profileId: 'matte-coated', intent: 'relative', blackPointCompensation: true, widthMm: 297, heightMm: 210, dpi: 300, bleedMm: 3, trimMm: 5, operatorNotes: '' },
    adjustmentLog: [], displayId: 'dsp-ref',
  }
}

export function primaryDemoProject(): Project {
  const p = blankProject('prj-aai-opt-2026-014', 'AAI-OPT-2026-014', 'Aardvark Imaging Optical Materials / Industrial Cinema Study',
    'A colour-managed imaging study examining industrial materials, architectural surfaces, reflective metals, painted steel, sandstone, glass, polymers and low-light environments across multiple image-production pipelines.')
  p.assets = [
    asset('ast-source', 'Board — source (flat)', 'Source', 'material-board', 'source', 'Synthetic low-contrast encode standing in for camera-log-style source material.', 'Synthetic flat encode (not a camera profile)'),
    asset('ast-working', 'Board — working', 'Working', 'material-board', 'working', 'Display-referred working image (procedural).'),
    asset('ast-graded', 'Board — graded', 'Graded', 'material-board', 'graded', 'Industrial cinema primary grade applied to the working image (simulated pipeline).'),
    asset('ast-print', 'Board — print preview', 'Print preview', 'material-board', 'print', 'Approximate matte-coated proof preview. Not a certified proof.'),
    asset('ast-display', 'Board — display preview', 'Display preview', 'material-board', 'display', 'Approximate display response simulation (black lift, reduced saturation).'),
    { id: 'ast-report', name: 'Technical report', kind: 'report', role: 'Report', width: 0, height: 0, colourSpace: '—', sourceProfile: '—', body: TECH_REPORT, notes: 'Project technical report.', createdAt: DEMO_TIMESTAMP },
    { id: 'ast-matsheet', name: 'Material reference sheet', kind: 'sheet', role: 'Reference sheet', width: 0, height: 0, colourSpace: '—', sourceProfile: '—', body: materialSheet(), notes: 'Generated from the material library.', createdAt: DEMO_TIMESTAMP },
  ]
  p.activeAssetId = 'ast-working'
  p.samples = materialSamples()
  p.palettes = palettesFor()
  p.currentGrade = GRADE_PRESETS.find((g) => g.id === 'industrial-cinema')!.grade()
  p.gradeSnapshots = [
    { id: 'gs_1', name: 'Industrial cinema (baseline)', grade: GRADE_PRESETS[1].grade(), createdAt: DEMO_TIMESTAMP },
    { id: 'gs_2', name: 'Daylight neutral', grade: GRADE_PRESETS[2].grade(), createdAt: DEMO_TIMESTAMP },
  ]
  p.gradeAB = { a: GRADE_PRESETS[2].grade(), b: GRADE_PRESETS[1].grade() }
  p.conversionHistory = conversionEntries()
  p.measurements = [
    { id: 'ms_1', assetId: 'ast-working', a: { x: 405, y: 95 }, b: { x: 560, y: 95 }, note: 'Orange coating vs aluminium — mid-panel', at: DEMO_TIMESTAMP },
    { id: 'ms_2', assetId: 'ast-working', a: { x: 130, y: 420 }, b: { x: 330, y: 420 }, note: 'Sandstone vs frosted glass', at: DEMO_TIMESTAMP },
    { id: 'ms_3', assetId: 'ast-working', a: { x: 300, y: 560 }, b: { x: 760, y: 560 }, note: 'Wet asphalt vs concrete', at: DEMO_TIMESTAMP },
  ]
  p.annotations = [{ id: 'an_1', assetId: 'ast-working', x: 500, y: 100, text: 'Orange peel texture — check clipping in red channel' }]
  p.outputIntent = 'Matte coated paper (synthetic approximation)'
  p.destinationProfile = 'Matte coated paper — approximate'
  p.production = { ...p.production, operatorNotes: 'Preview only. Confirm spot colour for the powder-coat orange before release.' }
  p.notes = 'Primary demonstration project. All values are synthetic and deterministic.'
  return p
}

function other(id: string, code: string, name: string, desc: string, gen: GeneratorId, extra: (p: Project) => void): Project {
  const p = blankProject(id, code, name, desc, gen)
  extra(p)
  return p
}

export function allDemoProjects(): Project[] {
  const primary = primaryDemoProject()
  const arch = other('prj-arch-film', 'AAI-ARC-2026-007', 'Architectural Film Grade', 'Cool concrete, warm interior spill and reflective ground plane, graded for a cinema deliverable.', 'architectural-scene', (p) => {
    p.assets = [asset('ast-working', 'Facade — working', 'Working', 'architectural-scene', 'working', 'Procedural architectural exterior.'), asset('ast-graded', 'Facade — graded', 'Graded', 'architectural-scene', 'graded', 'Cinema grade.')]
    p.currentGrade = GRADE_PRESETS[1].grade()
    p.palettes = [createPalette('architectural', { ...defaultPaletteParams('#33475b'), steps: 6 }, 'Facade tones')]
    p.samples = [{ id: 'smp_glaz', origin: 'reference', record: hexRecord('#1d2a33', 'Glazing', ['glass']), note: 'Unlit glazing reference', assetId: 'ast-working', point: { x: 320, y: 300 } }]
  })
  const brand = other('prj-brand', 'AAI-BRD-2026-001', 'Aardvark Imaging Brand System', 'Internal visual standards manual: tokens, themes and specimen sheets.', 'material-board', (p) => {
    p.palettes = [createPalette('accessible-ui', { ...defaultPaletteParams('#e8630a'), steps: 7 }, 'Brand UI roles')]
    p.samples = AARDVARK_BRAND.colours.map((c) => ({ id: `smp_${c.id}`, origin: 'reference' as const, record: hexRecord(c.hex, c.name, [c.group.toLowerCase()], `${c.id}-ref`, 'brand'), note: c.usage }))
  })
  const print = other('prj-print-proof', 'AAI-PRT-2026-011', 'Print Production Proof', 'Approximate CMYK proofing study across the synthetic paper set.', 'material-board', (p) => {
    p.production = { ...p.production, profileId: 'gloss-coated', intent: 'perceptual', operatorNotes: 'Proof preview only.' }
    p.outputIntent = 'Gloss coated (synthetic approximation)'
    p.assets = [asset('ast-working', 'Board — working', 'Working', 'material-board', 'working', ''), asset('ast-print', 'Board — print preview', 'Print preview', 'material-board', 'print', 'Approximate proof.')]
  })
  const disp = other('prj-display', 'AAI-DSP-2026-003', 'Display Calibration Research', 'Planning environment for display targets and verification history (synthetic measurements).', 'material-board', (p) => {
    p.displayId = 'dsp-p3'
    p.notes = 'Synthetic measurement history. Use hardware measurement for real calibration.'
  })
  const archive = other('prj-photo-archive', 'AAI-PHO-2026-020', 'Photographic Colour Archive', 'Reference scene for tonal and colour-temperature studies.', 'photo-scene', (p) => {
    p.assets = [asset('ast-working', 'Dusk scene — working', 'Working', 'photo-scene', 'working', 'Procedural dusk landscape.'), asset('ast-source', 'Dusk scene — source (flat)', 'Source', 'photo-scene', 'source', '')]
    p.samples = [{ id: 'smp_horizon', origin: 'reference', record: makeRecord({ name: 'Horizon glow', linear: srgbToLinear({ r: 0.92, g: 0.55, b: 0.32 }), createdAt: DEMO_TIMESTAMP, source: 'reference' }), note: 'Approximate horizon glow reference', assetId: 'ast-working', point: { x: 650, y: 300 } }]
  })
  return [primary, arch, brand, print, disp, archive]
}

