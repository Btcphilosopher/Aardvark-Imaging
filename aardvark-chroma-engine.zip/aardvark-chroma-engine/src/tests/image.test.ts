import { describe, it, expect } from 'vitest'
import { generateMaterialBoard, boardLayout } from '../core/image/procedural'
import { renderImage, defaultRender, differenceImage } from '../core/image/image-processing'
import { analyseImage, mccamyCct, kmeansOklab } from '../core/image/analysis'
import { computeHistograms, computeWaveform, entropyBits } from '../core/image/histograms'
import { regionGrid, samplePixel } from '../core/image/sampling'
import { createImage, downscaleToMax, DECODE_LUT, encode8 } from '../core/image/image-model'
import { defaultGrade, GRADE_PRESETS, compileGrade, gradePixel } from '../core/grading/grade'
import { buildLut, LUT_PRESETS, sampleLut, toCube, parseCube, validateLut, blendLut } from '../core/lut/lut'
import { runTask } from '../core/image/tasks'
import { kelvinToLinearRgb, shadeSphere, defaultLighting, illuminantCast } from '../core/lighting/lighting'
import { proofColour, PROFILE_BY_ID, requiredPixels, effectiveDpi, printSizeMm } from '../core/print/print'
import { generatePattern, PATTERNS, syntheticMeasurements } from '../core/calibration/calibration'
import { srgbToLinear } from '../core/colour/conversions'

const same = (a: Uint8ClampedArray, b: Uint8ClampedArray) => a.length === b.length && a.every((v, i) => v === b[i])
const W = 240, H = 160
const board = generateMaterialBoard(W, H)

describe('procedural imagery', () => {
  it('is deterministic', () => {
    const a = generateMaterialBoard(W, H), b = generateMaterialBoard(W, H)
    expect(same(a.data, b.data)).toBe(true)
  })
  it('tiles the board without overlap and fills the width', () => {
    const { cells } = boardLayout(960, 640)
    expect(cells).toHaveLength(12)
    for (const c of cells) { expect(c.x).toBeGreaterThanOrEqual(0); expect(c.x + c.w).toBeLessThanOrEqual(960); expect(c.y + c.h).toBeLessThanOrEqual(640) }
    for (let i = 0; i < cells.length; i++) for (let j = i + 1; j < cells.length; j++) {
      const a = cells[i], b = cells[j]
      expect(a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h).toBe(false)
    }
  })
  it('contains real tonal range and is fully opaque', () => {
    const h = computeHistograms(board)
    expect(h.count).toBe(W * H)
    expect(board.data.every((v, i) => i % 4 !== 3 || v === 255)).toBe(true)
    expect(entropyBits(h.luma)).toBeGreaterThan(4)
  })
})

describe('render pipeline', () => {
  it('identity render reproduces the source', () => {
    const { image } = renderImage(board, defaultRender())
    let maxd = 0
    for (let i = 0; i < board.data.length; i++) maxd = Math.max(maxd, Math.abs(image.data[i] - board.data[i]))
    expect(maxd).toBeLessThanOrEqual(1)
  })
  it('identity grade is bit-close to no grade; positive exposure brightens', () => {
    const a = renderImage(board, { ...defaultRender(), grade: defaultGrade() }).image
    expect(Math.abs(a.data[1000] - board.data[1000])).toBeLessThanOrEqual(1)
    const g = { ...defaultGrade(), exposure: 1 }
    const b = renderImage(board, { ...defaultRender(), grade: g }).image
    expect(computeHistograms(b).luma.reduce((s, v, i) => s + v * i, 0)).toBeGreaterThan(computeHistograms(board).luma.reduce((s, v, i) => s + v * i, 0))
  })
  it('exposure +1 stop doubles linear light for mid values', () => {
    const c = compileGrade({ ...defaultGrade(), exposure: 1 })
    const o: [number, number, number] = [0, 0, 0]
    gradePixel(c, 0.1, 0.2, 0.05, o)
    expect(o[0]).toBeCloseTo(0.2, 9); expect(o[1]).toBeCloseTo(0.4, 9)
  })
  it('saturation −1 yields neutral pixels; hue shift of 360° is identity', () => {
    const o: [number, number, number] = [0, 0, 0]
    gradePixel(compileGrade({ ...defaultGrade(), saturation: -1 }), 0.6, 0.2, 0.1, o)
    expect(o[0]).toBeCloseTo(o[1], 9); expect(o[1]).toBeCloseTo(o[2], 9)
    gradePixel(compileGrade({ ...defaultGrade(), hueShift: 360 }), 0.6, 0.2, 0.1, o)
    expect(o[0]).toBeCloseTo(0.6, 6); expect(o[1]).toBeCloseTo(0.2, 6)
  })
  it('hue rotation preserves luminance', () => {
    const o: [number, number, number] = [0, 0, 0]
    gradePixel(compileGrade({ ...defaultGrade(), hueShift: 90 }), 0.6, 0.2, 0.1, o)
    const y0 = 0.2126 * 0.6 + 0.7152 * 0.2 + 0.0722 * 0.1
    // rotation about the neutral axis preserves the mean, not Rec.709 luma; check mean
    expect((o[0] + o[1] + o[2]) / 3).toBeCloseTo((0.6 + 0.2 + 0.1) / 3, 9)
    expect(y0).toBeGreaterThan(0)
  })
  it('channel isolation and invert views behave', () => {
    const r = renderImage(board, { ...defaultRender(), view: 'r' }).image
    expect(r.data[0]).toBe(r.data[1]); expect(r.data[1]).toBe(r.data[2])
    const inv = renderImage(board, { ...defaultRender(), view: 'invert' }).image
    expect(inv.data[0]).toBe(255 - board.data[0])
  })
  it('clipping stats count exactly what is clipped', () => {
    const img = createImage(4, 1)
    const px = [[255, 255, 255], [0, 0, 0], [128, 128, 128], [254, 10, 10]]
    px.forEach((p, i) => { img.data.set([p[0], p[1], p[2], 255], i * 4) })
    const { stats } = renderImage(img, defaultRender())
    expect(stats.highlightClipPct).toBeCloseTo(50, 5)
    expect(stats.shadowClipPct).toBeCloseTo(25, 5)
  })
  it('difference of identical images is black; grade-induced difference is not', () => {
    expect(differenceImage(board, board).data.every((v, i) => i % 4 === 3 || v === 0)).toBe(true)
    const g = renderImage(board, { ...defaultRender(), grade: GRADE_PRESETS[1].grade() }).image
    expect(differenceImage(board, g).data.some((v, i) => i % 4 !== 3 && v > 0)).toBe(true)
  })
  it('proof view changes pixels and reports gamut for saturated orange on newspaper', () => {
    const img = createImage(1, 1, [232, 99, 10, 255])
    const { image, stats } = renderImage(img, { ...defaultRender(), proof: { profileId: 'newspaper', intent: 'relative', bpc: true } })
    expect(image.data[0]).not.toBe(232)
    expect(stats.proofOutOfGamutPct).toBe(100)
  })
})

describe('analysis', () => {
  const res = analyseImage(board, { cols: 3, rows: 3 })
  it('reports coherent global statistics', () => {
    expect(res.histograms.count).toBe(W * H)
    expect(res.regions).toHaveLength(9)
    expect(res.dominant.length).toBeGreaterThan(2)
    expect(res.dominant.reduce((s, d) => s + d.fraction, 0)).toBeCloseTo(1, 6)
    expect(res.brightnessZones.reduce((s, v) => s + v, 0)).toBeCloseTo(1, 6)
    expect(res.saturationDistribution.reduce((s, v) => s + v, 0)).toBeCloseTo(1, 6)
    expect(res.dynamicRangeStops).toBeGreaterThan(3)
    expect(res.entropyBits).toBeLessThanOrEqual(8)
  })
  it('flat grey image: zero contrast, zero edges, neutral, 0 entropy', () => {
    const g = createImage(64, 64, [128, 128, 128, 255])
    const a = analyseImage(g)
    expect(a.contrastRms).toBeCloseTo(0, 9); expect(a.edgeDensityPct).toBe(0); expect(a.entropyBits).toBe(0)
    expect(a.regions.every((r) => r.dominantHue === null)).toBe(true)
    expect(a.cctEstimate).toBeGreaterThan(5500); expect(a.cctEstimate).toBeLessThan(7500)
  })
  it('regions: average of a two-tone image is in linear light, not gamma space', () => {
    const img = createImage(2, 1); img.data.set([0, 0, 0, 255, 255, 255, 255, 255])
    const r = regionGrid(img, 1, 1)[0]
    expect(r.meanLinear.r).toBeCloseTo(0.5, 9)
    expect(r.meanHex).toBe('#bcbcbc')
    expect(r.medianLinear.r).toBeDefined()
  })
  it('kmeans recovers distinct blocks', () => {
    const img = createImage(40, 10)
    for (let x = 0; x < 40; x++) for (let y = 0; y < 10; y++) img.data.set(x < 20 ? [230, 90, 10, 255] : [30, 60, 120, 255], (y * 40 + x) * 4)
    const d = kmeansOklab(img, 2)
    expect(d).toHaveLength(2); expect(d[0].fraction).toBeCloseTo(0.5, 2)
    expect(new Set(d.map((x) => x.hex))).toEqual(new Set(['#e65a0a', '#1e3c78']))
  })
  it('McCamy CCT for D65 xy ≈ 6500 K', () => { expect(Math.abs(mccamyCct(0.3127, 0.329) - 6505)).toBeLessThan(40) })
  it('downscale is bounded and preserves mean colour', () => {
    const d = downscaleToMax(board, 1000)
    expect(d.width * d.height).toBeLessThanOrEqual(1000)
  })
  it('waveform bins sum to sampled pixel count and pixel sampling reads exact pixels', () => {
    const wf = computeWaveform(board, 60)
    expect(wf.data.reduce((s, v) => s + v, 0)).toBeGreaterThan(0)
    const s = samplePixel(board, 10, 10)!
    expect(s.record.srgb.r).toBeCloseTo(board.data[(10 * W + 10) * 4] / 255, 9)
    expect(samplePixel(board, -1, 0)).toBeNull(); expect(samplePixel(board, W, 0)).toBeNull()
  })
})

describe('worker task layer', () => {
  it('put/render/analyse round trip through the cache', () => {
    runTask({ op: 'put', key: 't', img: board })
    const r = runTask({ op: 'render', key: 't', params: { ...defaultRender(), grade: { ...defaultGrade(), exposure: 0.5 } } })
    expect(r.op === 'render' && r.image.width).toBe(W)
    const a = runTask({ op: 'analyse', key: 't', opts: { cols: 5, rows: 5 } })
    expect(a.op === 'analyse' && a.result.regions.length).toBe(25)
    expect(() => runTask({ op: 'render', key: 'missing', params: defaultRender() })).toThrow()
  })
})

describe('LUT', () => {
  it('identity LUT is an identity and validates', () => {
    const lut = buildLut(LUT_PRESETS[0].fn, 9)
    const v = validateLut(lut)
    expect(v.maxIdentityDelta).toBeLessThan(1e-6); expect(v.valid).toBe(true)
    const o: [number, number, number] = [0, 0, 0]
    sampleLut(lut, 0.3, 0.6, 0.9, o)
    expect(o[0]).toBeCloseTo(0.3, 6); expect(o[1]).toBeCloseTo(0.6, 6); expect(o[2]).toBeCloseTo(0.9, 6)
  })
  it('.cube export round-trips exactly at 6 decimals and has the required header', () => {
    const lut = buildLut(LUT_PRESETS[4].fn, 5)
    const text = toCube(lut, { comments: ['test'] })
    expect(text).toContain('LUT_3D_SIZE 5')
    const parsed = parseCube(text)
    expect('error' in parsed).toBe(false)
    if (!('error' in parsed)) for (let i = 0; i < lut.data.length; i++) expect(Math.abs(parsed.data[i] - lut.data[i])).toBeLessThan(1e-6)
    expect('error' in parseCube('LUT_3D_SIZE 3\n0 0 0')).toBe(true)
  })
  it('all presets keep a monotonic neutral axis except none — and out-of-range points are counted', () => {
    for (const p of LUT_PRESETS) expect(validateLut(buildLut(p.fn, 9)).neutralMonotonic).toBe(true)
    const bad = buildLut((r, g, b) => [r * 1.4, g, b], 5)
    expect(validateLut(bad).outOfRange).toBeGreaterThan(0)
  })
  it('strength 0 leaves the colour unchanged; strength 1 equals the LUT; luminosity blend keeps colour', () => {
    const o: [number, number, number] = [0, 0, 0]
    blendLut([0.2, 0.4, 0.6], [0.5, 0.5, 0.5], 0, 'normal', o); expect(o).toEqual([0.2, 0.4, 0.6])
    blendLut([0.2, 0.4, 0.6], [0.5, 0.5, 0.5], 1, 'normal', o); expect(o).toEqual([0.5, 0.5, 0.5])
  })
})

describe('lighting', () => {
  it('kelvin: 2700K is warm, 6500K ≈ neutral, 9000K is cool; unit luminance', () => {
    const w = kelvinToLinearRgb(2700), n = kelvinToLinearRgb(6504), c = kelvinToLinearRgb(9000)
    expect(w.r).toBeGreaterThan(w.b * 2); expect(c.b).toBeGreaterThan(c.r)
    expect(Math.abs(n.r - n.b)).toBeLessThan(0.08)
    expect(0.2126 * w.r + 0.7152 * w.g + 0.0722 * w.b).toBeCloseTo(1, 9)
    const cast = illuminantCast(6504); expect(cast.r).toBeCloseTo(1, 9)
  })
  it('sphere render is deterministic, has a lit side brighter than the shadow side', () => {
    const L = { ...defaultLighting(), keyAzimuth: 180 }
    const img = shadeSphere(64, { albedo: srgbToLinear({ r: 0.7, g: 0.5, b: 0.3 }), roughness: 0.5, metallic: 0, reflectance: 0.2 }, L)
    const left = img.data[(32 * 64 + 20) * 4], right = img.data[(32 * 64 + 44) * 4]
    expect(left).toBeGreaterThan(right)
  })
})

describe('print', () => {
  it('display profile applies no ink; newspaper has lower TAC limit than gloss', () => {
    const o = srgbToLinear({ r: 0.05, g: 0.05, b: 0.05 })
    const paper = proofColour(o, { profile: PROFILE_BY_ID['newspaper'], intent: 'relative', blackPointCompensation: true })
    expect(paper.tac).toBeLessThanOrEqual(PROFILE_BY_ID['newspaper'].inkLimit)
    const disp = proofColour(o, { profile: PROFILE_BY_ID['display-output'], intent: 'relative', blackPointCompensation: true })
    expect(disp.tac).toBe(0)
  })
  it('BPC lifts black to the profile black; without BPC shadows clip', () => {
    const k = srgbToLinear({ r: 0, g: 0, b: 0 })
    const a = proofColour(k, { profile: PROFILE_BY_ID['uncoated'], intent: 'relative', blackPointCompensation: true })
    expect(a.shift).toBeGreaterThan(5)
  })
  it('size calculators are consistent', () => {
    expect(printSizeMm({ widthPx: 3000, heightPx: 2000, dpi: 300 }).w).toBeCloseTo(254, 6)
    expect(requiredPixels(254, 254, 300).w).toBe(3000)
    expect(effectiveDpi(3000, 254)).toBeCloseTo(300, 6)
  })
})

describe('calibration', () => {
  it('every test pattern renders opaque, non-empty and deterministic', () => {
    for (const p of PATTERNS) {
      const a = generatePattern(p.id, 320, 180), b = generatePattern(p.id, 320, 180)
      expect(same(a.data, b.data)).toBe(true)
      expect(new Set(Array.from(a.data).filter((_, i) => i % 4 === 0)).size).toBeGreaterThan(1)
    }
  })
  it('grayscale ramp is monotonic; near-black has all 21 code values 0..20', () => {
    const r = generatePattern('grayscale-ramp', 210, 10)
    let prev = -1
    for (let x = 0; x < 210; x++) { const v = r.data[x * 4]; expect(v).toBeGreaterThanOrEqual(prev); prev = v }
    const nb = generatePattern('near-black', 210, 10)
    expect(new Set(Array.from({ length: 210 }, (_, x) => nb.data[x * 4])).size).toBe(21)
  })
  it('synthetic measurements are deterministic', () => {
    expect(syntheticMeasurements('disp-grade')).toEqual(syntheticMeasurements('disp-grade'))
    expect(DECODE_LUT[encode8(0.5)]).toBeGreaterThan(0.49)
  })
})
