import { describe, it, expect } from 'vitest'
import {
  srgbToLinear, linearToSrgb, spacesFromLinear, linearToXyz, xyzToLab, linearToOklab, oklabToLinear, labToXyz, xyzToLinear,
  rgbToHsl, hslToRgb, rgbToHsv, hsvToRgb, rgbToHwb, hwbToRgb, parseHex, rgbToHex, D65_WHITE, SRGB_TO_XYZ, convertLinear,
  rgbToCmykNaive, cmykToRgbNaive, linearToRec2020Channel, rec2020ToLinearChannel, labToLch, lchToLab, oklabToOklch, oklchToOklab,
  type RGB,
} from '../core/colour/conversions'
import { makeRecord, recordFromHex, linearFromPicker, pickerValues, parseColourString, PICKER_SPACES } from '../core/colour/colour-model'
import { inGamut, gamutStatus, mapToGamutOklch, maxChromaOklch } from '../core/colour/gamut'
import { mixColours, mixSteps, stepUniformity, fixupHues } from '../core/colour/interpolation'
import { deltaE2000, wcagContrast, wcagLevel, ensureContrast } from '../core/colour/contrast'
import { alphaOver, blendColours, additiveLight, pigmentMix } from '../core/colour/compositing'
import { validateRecord } from '../core/colour/colour-validation'

const near = (a: number, b: number, tol = 1e-6) => expect(Math.abs(a - b)).toBeLessThanOrEqual(tol)
const nearRgb = (a: RGB, b: RGB, tol = 1e-6) => { near(a.r, b.r, tol); near(a.g, b.g, tol); near(a.b, b.b, tol) }
const rgb = (r: number, g: number, b: number): RGB => ({ r, g, b })

describe('transfer functions and matrices', () => {
  it('sRGB round-trips across the full range including out-of-range values', () => {
    for (const v of [-0.3, -0.01, 0, 0.002, 0.04, 0.5, 0.9, 1, 1.4]) {
      near(linearToSrgb(srgbToLinear(rgb(v, v, v))).r, v, 1e-12)
    }
  })
  it('known sRGB → linear values', () => {
    near(srgbToLinear(rgb(0.5, 0.5, 0.5)).r, 0.21404114048223255, 1e-12)
    near(srgbToLinear(rgb(1, 1, 1)).g, 1, 1e-12)
  })
  it('derived sRGB matrix matches the standard (IEC 61966-2-1) to 4 decimals', () => {
    const std = [0.4124, 0.3576, 0.1805, 0.2126, 0.7152, 0.0722, 0.0193, 0.1192, 0.9505]
    SRGB_TO_XYZ.forEach((v, i) => near(v, std[i], 6e-4))
  })
  it('linear white maps to the D65 white point exactly', () => {
    const w = linearToXyz(rgb(1, 1, 1))
    near(w.x, D65_WHITE.x, 1e-9); near(w.y, 1, 1e-9); near(w.z, D65_WHITE.z, 1e-9)
  })
  it('Rec.2020 transfer round-trips', () => {
    for (const v of [0, 0.001, 0.02, 0.4, 1]) near(rec2020ToLinearChannel(linearToRec2020Channel(v)), v, 1e-12)
  })
  it('P3 ↔ sRGB conversion round-trips and P3 green is outside sRGB', () => {
    const g = convertLinear(rgb(0, 1, 0), 'displayP3', 'srgb')
    expect(g.g).toBeGreaterThan(1)
    expect(g.r).toBeLessThan(0)
    nearRgb(convertLinear(g, 'srgb', 'displayP3'), rgb(0, 1, 0), 1e-9)
  })
})

describe('CIELAB / OKLab reference values', () => {
  it('white → L*=100, a*=b*=0', () => {
    const lab = xyzToLab(linearToXyz(rgb(1, 1, 1)))
    near(lab.l, 100, 1e-9); near(lab.a, 0, 1e-9); near(lab.b, 0, 1e-9)
  })
  it('sRGB red in D65 CIELAB ≈ (53.24, 80.09, 67.20)', () => {
    const lab = xyzToLab(linearToXyz(rgb(1, 0, 0)))
    near(lab.l, 53.2408, 0.02); near(lab.a, 80.0925, 0.05); near(lab.b, 67.2032, 0.05)
  })
  it('sRGB red in OKLab ≈ (0.62796, 0.22486, 0.12585)', () => {
    const ok = linearToOklab(rgb(1, 0, 0))
    near(ok.l, 0.62796, 2e-4); near(ok.a, 0.22486, 2e-4); near(ok.b, 0.12585, 2e-4)
  })
  it('OKLab white is (1, 0, 0) and black is (0, 0, 0)', () => {
    const w = linearToOklab(rgb(1, 1, 1)); near(w.l, 1, 1e-4); near(w.a, 0, 1e-4); near(w.b, 0, 1e-4)
    const k = linearToOklab(rgb(0, 0, 0)); near(k.l, 0, 1e-9)
  })
  it('Lab and OKLab round-trip deterministically', () => {
    for (const c of [rgb(0.2, 0.5, 0.8), rgb(0.9, 0.1, 0.05), rgb(0.01, 0.01, 0.02), rgb(1.2, -0.1, 0.4)]) {
      nearRgb(xyzToLinear(labToXyz(xyzToLab(linearToXyz(c)))), c, 1e-9)
      nearRgb(oklabToLinear(linearToOklab(c)), c, 1e-6)
      nearRgb(xyzToLinear(labToXyz(lchToLab(labToLch(xyzToLab(linearToXyz(c)))))), c, 1e-9)
      nearRgb(oklabToLinear(oklchToOklab(oklabToOklch(linearToOklab(c)))), c, 1e-6)
    }
  })
  it('achromatic colours have chroma 0 and powerless hue reported as 0', () => {
    const s = spacesFromLinear(srgbToLinear(rgb(0.5, 0.5, 0.5)))
    expect(s.lch.c).toBeLessThan(1e-3)
    expect(s.lch.h).toBe(0)
    expect(s.hsl.s).toBe(0)
  })
})

describe('HSL / HSV / HWB', () => {
  const samples = [rgb(1, 0, 0), rgb(0.2, 0.6, 0.9), rgb(0.9, 0.85, 0.1), rgb(0.5, 0.5, 0.5), rgb(0, 0, 0), rgb(1, 1, 1), rgb(0.1, 0.9, 0.5)]
  it('round-trip', () => {
    for (const c of samples) {
      nearRgb(hslToRgb(rgbToHsl(c)), c, 1e-9)
      nearRgb(hsvToRgb(rgbToHsv(c)), c, 1e-9)
      nearRgb(hwbToRgb(rgbToHwb(c)), c, 1e-9)
    }
  })
  it('known values', () => {
    const h = rgbToHsl(rgb(0, 1, 0)); near(h.h, 120); near(h.s, 1); near(h.l, 0.5)
    const v = rgbToHsv(rgb(0, 0, 1)); near(v.h, 240); near(v.v, 1)
    const w = rgbToHwb(rgb(1, 0.5, 0.5)); near(w.w, 0.5); near(w.b, 0)
  })
})

describe('hex and CMYK', () => {
  it('parses and formats hex', () => {
    expect(parseHex('#f80')?.rgb.g).toBeCloseTo(0x88 / 255, 9)
    expect(parseHex('e8630a')?.rgb.r).toBeCloseTo(0xe8 / 255, 9)
    expect(parseHex('#e8630a80')?.alpha).toBeCloseTo(0x80 / 255, 9)
    expect(rgbToHex(rgb(0.9098, 0.3882, 0.0392))).toBe('#e8630a')
  })
  it('rejects invalid hex without throwing', () => {
    for (const bad of ['', '#', '#12', '#12345', 'zzzzzz', '#gg0000', '#1234567']) expect(parseHex(bad)).toBeNull()
  })
  it('naive CMYK round-trips for in-range colours', () => {
    const c = rgb(0.8, 0.3, 0.1)
    nearRgb(cmykToRgbNaive(rgbToCmykNaive(c)), c, 1e-9)
    expect(rgbToCmykNaive(rgb(0, 0, 0)).k).toBe(1)
  })
})

describe('colour record', () => {
  it('every representation derives from one linear triplet and stays mutually consistent', () => {
    const rec = recordFromHex('#e8630a', { name: 'Industrial orange' })!
    expect(rec.hex).toBe('#e8630a')
    nearRgb(srgbToLinear(rec.srgb), rec.linearRgb, 1e-12)
    nearRgb(hslToRgb(rec.hsl), rec.srgb, 1e-9)
    near(rec.chroma, rec.lch.c, 1e-12)
    expect(rec.gamutStatus).toEqual({ srgb: true, displayP3: true, rec2020: true })
    expect(validateRecord(rec)).toHaveLength(0)
  })
  it('returns null for invalid hex', () => { expect(recordFromHex('nope')).toBeNull() })
  it('out-of-sRGB colours are flagged, not silently clipped', () => {
    const rec = makeRecord({ name: 'p3 green', linear: convertLinear(rgb(0, 1, 0), 'displayP3', 'srgb') })
    expect(rec.gamutStatus.srgb).toBe(false)
    expect(rec.gamutStatus.displayP3).toBe(true)
    expect(rec.srgb.g).toBeGreaterThan(1)
    expect(validateRecord(rec).some((i) => i.code === 'out-of-gamut-srgb')).toBe(true)
  })
  it('picker spaces round-trip through the canonical record', () => {
    const rec = recordFromHex('#3a7fb5')!
    for (const sp of PICKER_SPACES) {
      const v = pickerValues(rec, sp)
      nearRgb(linearFromPicker(sp, v), rec.linearRgb, 1e-6)
    }
  })
  it('parses CSS strings', () => {
    nearRgb(parseColourString('rgb(255, 0, 0)')!.linear, rgb(1, 0, 0), 1e-9)
    nearRgb(parseColourString('hsl(120 100% 50%)')!.linear, rgb(0, 1, 0), 1e-9)
    const ok = parseColourString('oklch(0.628 0.2577 29.23)')!
    expect(ok.linear.r).toBeGreaterThan(0.95)
    expect(parseColourString('banana')).toBeNull()
    expect(parseColourString('rgb(1,2)')).toBeNull()
  })
})

describe('gamut', () => {
  it('classifies P3 and Rec.2020 primaries', () => {
    const p3g = convertLinear(rgb(0, 1, 0), 'displayP3', 'srgb')
    expect(gamutStatus(p3g)).toEqual({ srgb: false, displayP3: true, rec2020: true })
    const r2 = convertLinear(rgb(0, 1, 0), 'rec2020', 'srgb')
    expect(gamutStatus(r2)).toEqual({ srgb: false, displayP3: false, rec2020: true })
    expect(inGamut(rgb(0.2, 0.3, 0.4), 'srgb')).toBe(true)
  })
  it('OKLCh gamut mapping lands inside sRGB and preserves hue and lightness', () => {
    const wild = oklabToLinear(oklchToOklab({ l: 0.7, c: 0.35, h: 140 }))
    expect(inGamut(wild, 'srgb')).toBe(false)
    const mapped = mapToGamutOklch(wild, 'srgb')
    expect(inGamut(mapped, 'srgb')).toBe(true)
    const a = oklabToOklch(linearToOklab(wild)), b = oklabToOklch(linearToOklab(mapped))
    near(a.h, b.h, 0.5); near(a.l, b.l, 0.01)
  })
  it('maxChroma is bounded and shrinks toward black and white', () => {
    const mid = maxChromaOklch(0.6, 30)
    expect(mid).toBeGreaterThan(0.1)
    expect(maxChromaOklch(0.98, 30)).toBeLessThan(mid)
    expect(maxChromaOklch(0.05, 30)).toBeLessThan(mid)
  })
})

describe('interpolation', () => {
  const red = { linear: srgbToLinear(rgb(1, 0, 0)), alpha: 1 }
  const blue = { linear: srgbToLinear(rgb(0, 0, 1)), alpha: 1 }
  it('endpoints are exact in every space', () => {
    for (const space of ['srgb', 'linear', 'lab', 'lch', 'oklab', 'oklch'] as const) {
      nearRgb(mixColours(red, blue, 0, { space }).linear, red.linear, 1e-7)
      nearRgb(mixColours(red, blue, 1, { space }).linear, blue.linear, 1e-7)
    }
  })
  it('midpoints differ between spaces (sRGB mid is the familiar dark purple, linear is brighter)', () => {
    const s = mixColours(red, blue, 0.5, { space: 'srgb' }).linear
    nearRgb(s, srgbToLinear(rgb(0.5, 0, 0.5)), 1e-9)
    const l = mixColours(red, blue, 0.5, { space: 'linear' }).linear
    nearRgb(l, rgb(0.5, 0, 0.5), 1e-9)
    expect(l.r).toBeGreaterThan(s.r)
  })
  it('hue routes: shorter vs longer differ by the opposite arc', () => {
    expect(fixupHues(10, 350, 'shorter')).toEqual([370, 350])
    expect(fixupHues(10, 350, 'longer')).toEqual([10, 350])
    expect(fixupHues(350, 10, 'increasing')).toEqual([350, 370])
    expect(fixupHues(10, 350, 'decreasing')).toEqual([370, 350])
    expect(fixupHues(350, 10, 'decreasing')).toEqual([350, 10])
    const a = mixColours(red, blue, 0.5, { space: 'oklch', hueMode: 'shorter' })
    const b = mixColours(red, blue, 0.5, { space: 'oklch', hueMode: 'longer' })
    const ha = oklabToOklch(linearToOklab(a.linear)).h, hb = oklabToOklch(linearToOklab(b.linear)).h
    expect(Math.abs(ha - hb)).toBeGreaterThan(90)
  })
  it('achromatic endpoint takes the hue of the other (no hue swing through grey)', () => {
    const white = { linear: rgb(1, 1, 1), alpha: 1 }
    const mid = mixColours(red, white, 0.5, { space: 'oklch' }).linear
    const h0 = oklabToOklch(linearToOklab(red.linear)).h
    near(oklabToOklch(linearToOklab(mid)).h, h0, 1)
  })
  it('alpha is interpolated and colour is premultiplied', () => {
    const clear = { linear: rgb(0, 0, 1), alpha: 0 }
    const m = mixColours(red, clear, 0.5, { space: 'linear' })
    near(m.alpha, 0.5)
    nearRgb(m.linear, red.linear, 1e-9)
  })
  it('OKLab produces more even steps than sRGB for red→cyan', () => {
    const cyan = { linear: srgbToLinear(rgb(0, 1, 1)), alpha: 1 }
    const a = stepUniformity(mixSteps(red, cyan, 9, { space: 'oklab' }))
    const b = stepUniformity(mixSteps(red, cyan, 9, { space: 'srgb' }))
    expect(a.steps).toHaveLength(8)
    expect(a.deviation).toBeLessThan(b.deviation + 1e-9)
  })
})

describe('delta E and contrast', () => {
  it('CIEDE2000 matches Sharma reference pairs', () => {
    near(deltaE2000({ l: 50, a: 2.6772, b: -79.7751 }, { l: 50, a: 0, b: -82.7485 }), 2.0425, 1e-4)
    near(deltaE2000({ l: 50, a: 2.5, b: 0 }, { l: 50, a: 0, b: -2.5 }), 4.3065, 1e-4)
    near(deltaE2000({ l: 50, a: -1, b: 2 }, { l: 50, a: 0, b: 0 }), 2.3669, 1e-4)
    near(deltaE2000({ l: 50, a: 2.5, b: 0 }, { l: 50, a: 2.5, b: 0 }), 0, 1e-12)
  })
  it('WCAG contrast: black on white is 21:1; identical colours 1:1', () => {
    near(wcagContrast(rgb(0, 0, 0), rgb(1, 1, 1)), 21, 1e-9)
    near(wcagContrast(rgb(0.3, 0.3, 0.3), rgb(0.3, 0.3, 0.3)), 1, 1e-12)
    expect(wcagLevel(4.5)).toBe('AA'); expect(wcagLevel(2.9)).toBe('Fail'); expect(wcagLevel(7)).toBe('AAA')
  })
  it('ensureContrast reaches the target when achievable', () => {
    const bg = srgbToLinear(rgb(0.95, 0.93, 0.9))
    const fg = ensureContrast(srgbToLinear(rgb(0.9, 0.5, 0.2)), bg, 4.5)
    expect(wcagContrast(fg, bg)).toBeGreaterThanOrEqual(4.5)
  })
})

describe('compositing', () => {
  it('alpha over: opaque source wins, transparent source is invisible', () => {
    const bg = { linear: rgb(0.2, 0.2, 0.2), alpha: 1 }
    nearRgb(alphaOver({ linear: rgb(1, 0, 0), alpha: 1 }, bg).linear, rgb(1, 0, 0))
    nearRgb(alphaOver({ linear: rgb(1, 0, 0), alpha: 0 }, bg).linear, bg.linear)
    near(alphaOver({ linear: rgb(1, 0, 0), alpha: 0.5 }, { linear: rgb(0, 0, 1), alpha: 0.5 }).alpha, 0.75)
  })
  it('blend modes: multiply with white is identity, screen with black is identity, difference with self is black', () => {
    const c = srgbToLinear(rgb(0.6, 0.4, 0.2))
    nearRgb(blendColours(c, rgb(1, 1, 1), 'multiply'), c, 1e-9)
    nearRgb(blendColours(c, rgb(0, 0, 0), 'screen'), c, 1e-9)
    nearRgb(blendColours(c, c, 'difference'), rgb(0, 0, 0), 1e-9)
    nearRgb(blendColours(c, rgb(0.5, 0.5, 0.5), 'soft-light', 'linear'), blendColours(c, rgb(0.5, 0.5, 0.5), 'soft-light', 'linear'))
  })
  it('overlay = hard-light with layers swapped (mid grey source with mid grey backdrop stays mid)', () => {
    const m = { r: 0.5, g: 0.5, b: 0.5 }
    nearRgb(blendColours(m, m, 'overlay', 'linear'), m, 1e-9)
    const dark = blendColours({ r: 0.2, g: 0.2, b: 0.2 }, { r: 0.5, g: 0.5, b: 0.5 }, 'overlay', 'linear')
    near(dark.r, 0.2, 1e-9)
  })
  it('additive light flags overexposure; pigment mixing of equal colours is identity', () => {
    expect(additiveLight(rgb(0.8, 0.2, 0), rgb(0.5, 0.5, 0)).overexposed).toBe(true)
    expect(additiveLight(rgb(0.1, 0.1, 0.1), rgb(0.2, 0.2, 0.2)).overexposed).toBe(false)
    const c = rgb(0.3, 0.5, 0.1)
    nearRgb(pigmentMix(c, c, 0.37), c, 1e-9)
    const yb = pigmentMix(srgbToLinear(rgb(1, 0.9, 0)), srgbToLinear(rgb(0, 0.2, 1)), 0.5)
    expect(yb.g).toBeGreaterThan(yb.r)
  })
})
