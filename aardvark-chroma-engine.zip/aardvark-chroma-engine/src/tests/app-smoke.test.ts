// @vitest-environment jsdom
import 'fake-indexeddb/auto'
import { describe, it, expect, beforeAll, afterEach } from 'vitest'
import { cleanup, render, screen, waitFor, within } from '@testing-library/react'
import { createElement } from 'react'

// jsdom has no ResizeObserver / matchMedia / clipboard — stub the minimum the shell needs.
beforeAll(() => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  ;(globalThis as any).ResizeObserver = class { observe() {} unobserve() {} disconnect() {} }
  Object.defineProperty(window, 'matchMedia', { writable: true, value: (q: string) => ({ matches: false, media: q, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {}, dispatchEvent: () => false }) })
  Object.defineProperty(navigator, 'clipboard', { value: { writeText: async () => {} }, configurable: true })
  // jsdom implements <canvas> as an element but not the 2D rendering API. Real browsers always provide it;
  // stub a permissive fake context here purely so this environment can exercise the full render tree.
  const fakeCtx = new Proxy({}, {
    get(_t, prop) {
      if (prop === 'measureText') return () => ({ width: 0 })
      if (prop === 'createImageData') return (w: number, h: number) => new ImageData(Math.max(1, w), Math.max(1, h))
      if (prop === 'getImageData') return (_x: number, _y: number, w: number, h: number) => new ImageData(Math.max(1, w), Math.max(1, h))
      if (prop === 'canvas') return undefined
      return () => fakeCtx
    },
  }) as unknown as CanvasRenderingContext2D
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  ;(HTMLCanvasElement.prototype as any).getContext = () => fakeCtx
  // jsdom has no ImageData constructor.
  if (typeof (globalThis as { ImageData?: unknown }).ImageData === 'undefined') {
    class FakeImageData { data: Uint8ClampedArray; width: number; height: number
      constructor(a: Uint8ClampedArray | number, b: number, c?: number) {
        if (a instanceof Uint8ClampedArray) { this.data = a; this.width = b; this.height = c ?? 1 }
        else { this.width = a; this.height = b; this.data = new Uint8ClampedArray(a * b * 4) }
      }
    }
    ;(globalThis as unknown as { ImageData: unknown }).ImageData = FakeImageData
  }
})
afterEach(() => cleanup())

describe('App shell smoke test (jsdom, fake IndexedDB, no Worker/Canvas)', () => {
  it('boots, seeds demo projects, and renders the primary demo project', async () => {
    const { default: App } = await import('../App')
    render(createElement(App))
    await waitFor(() => expect(screen.getByText(/Chroma Engine/i)).toBeTruthy(), { timeout: 8000 })
    await waitFor(() => expect(screen.getAllByText(/AAI-OPT-2026-014/i).length).toBeGreaterThan(0), { timeout: 8000 })
    expect(screen.getByRole('tab', { name: /AAI-OPT-2026-014/i })).toBeTruthy()
  }, 15000)

  it('navigates across every page in the rail without throwing', async () => {
    const { default: App } = await import('../App')
    render(createElement(App))
    await waitFor(() => expect(screen.getByText(/Chroma Engine/i)).toBeTruthy(), { timeout: 8000 })
    const nav = screen.getByRole('navigation', { name: /primary/i })
    const buttons = within(nav).getAllByRole('button')
    expect(buttons.length).toBeGreaterThanOrEqual(20)
    for (const btn of buttons) {
      btn.click()
      await waitFor(() => expect(document.getElementById('main')).toBeTruthy())
    }
  }, 20000)

  it('the colour picker page renders a hex value derived from real conversions', async () => {
    const { default: App } = await import('../App')
    render(createElement(App))
    await waitFor(() => expect(screen.getByText(/Chroma Engine/i)).toBeTruthy(), { timeout: 8000 })
    const nav = screen.getByRole('navigation', { name: /primary/i })
    const pickerBtn = within(nav).getByRole('button', { name: /Colour Picker/i })
    pickerBtn.click()
    await waitFor(() => expect(screen.getAllByText(/#E8630A/i).length).toBeGreaterThan(0))
  })
})
