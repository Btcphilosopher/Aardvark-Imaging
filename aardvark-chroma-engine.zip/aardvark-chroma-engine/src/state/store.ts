import { create } from 'zustand'
import { makeRecord, linearFromPicker, pickerValues, newId, type ColourRecord, type PickerSpace, type Triplet } from '../core/colour/colour-model'
import { srgbToLinear, type RGB } from '../core/colour/conversions'
import type { Project, ProjectSummary, SavedSample } from '../types/project'
import { summarise } from '../types/project'
import { allDemoProjects, blankProject } from '../data/demo-projects'
import * as db from './persistence'
import { isoNow } from '../utils/format'

export type PageId =
  | 'projects' | 'image-lab' | 'picker' | 'spaces' | 'mixing' | 'harmonies' | 'palettes' | 'grading' | 'lut' | 'materials' | 'lighting'
  | 'calibration' | 'print' | 'analysis' | 'inspector' | 'conversion' | 'brand' | 'export' | 'assets' | 'settings'

export type ToolId = 'select' | 'pan' | 'zoom' | 'sample' | 'crop' | 'measure' | 'annotate' | 'compare' | 'histogram' | 'channel' | 'proof'

export interface Toast { id: number; kind: 'info' | 'ok' | 'warn' | 'error'; text: string }
interface HistoryEntry { label: string; project: Project }

export type SaveStatus = 'saved' | 'saving' | 'dirty' | 'error' | 'unavailable'

interface AppState {
  ready: boolean
  summaries: ProjectSummary[]
  project: Project
  openTabs: string[]
  page: PageId
  tool: ToolId
  inspectorOpen: boolean
  commandOpen: boolean
  view: { zoom: number; cursor: { x: number; y: number } | null; readout: string | null }
  save: { status: SaveStatus; at: string | null; message: string | null }
  undoStack: HistoryEntry[]
  redoStack: HistoryEntry[]
  picker: { space: PickerSpace; values: Triplet; linear: RGB; alpha: number }
  pickerHistory: ColourRecord[]
  compareWith: ColourRecord | null
  toasts: Toast[]
  // lifecycle
  init: () => Promise<void>
  // navigation
  setPage: (p: PageId) => void
  setTool: (t: ToolId) => void
  toggleInspector: () => void
  setCommandOpen: (o: boolean) => void
  setView: (v: Partial<AppState['view']>) => void
  toast: (kind: Toast['kind'], text: string) => void
  dismissToast: (id: number) => void
  // project mutation
  mutate: (label: string, fn: (p: Project) => Project, opts?: { coalesce?: string; silent?: boolean }) => void
  undo: () => void
  redo: () => void
  // picker
  setPickerSpace: (s: PickerSpace) => void
  setPickerValues: (v: Triplet) => void
  setPickerLinear: (l: RGB, alpha?: number, remember?: boolean) => void
  setPickerAlpha: (a: number) => void
  commitPickerHistory: () => void
  setCompareWith: (c: ColourRecord | null) => void
  saveSample: (rec: ColourRecord, note?: string, extra?: Partial<SavedSample>) => void
  // projects
  openProject: (id: string) => Promise<void>
  closeTab: (id: string) => Promise<void>
  createProject: (name: string) => Promise<void>
  duplicateProject: (id: string) => Promise<void>
  renameProject: (id: string, name: string) => Promise<void>
  archiveProject: (id: string, archived: boolean) => Promise<void>
  deleteProject: (id: string) => Promise<void>
  importProject: (text: string) => Promise<{ ok: boolean; message: string }>
  restoreDemos: () => Promise<void>
  flushSave: () => Promise<void>
}

const HISTORY_MAX = 80
let saveTimer: number | null = null
let lastCoalesce: { key: string; at: number } | null = null
let toastId = 1

const DEFAULT_PICKER_LINEAR: RGB = srgbToLinear({ r: 0xe8 / 255, g: 0x63 / 255, b: 0x0a / 255 })

function initialPicker(space: PickerSpace = 'oklch') {
  const rec = makeRecord({ linear: DEFAULT_PICKER_LINEAR })
  return { space, values: pickerValues(rec, space), linear: DEFAULT_PICKER_LINEAR, alpha: 1 }
}

const fallbackProject = () => blankProject('prj-loading', 'AAI-000', 'Loading…', '')

export const useApp = create<AppState>((set, get) => {
  const scheduleSave = () => {
    set((s) => ({ save: { ...s.save, status: s.save.status === 'unavailable' ? 'unavailable' : 'dirty' } }))
    if (saveTimer) window.clearTimeout(saveTimer)
    saveTimer = window.setTimeout(() => { void get().flushSave() }, 700)
  }

  const refreshSummaries = async (): Promise<ProjectSummary[]> => {
    const all = await db.getAllProjects()
    const s = all.map(summarise).sort((a, b) => a.code.localeCompare(b.code))
    set({ summaries: s })
    return s
  }

  const pushMeta = async () => {
    try { await db.setMeta('session', { active: get().project.id, tabs: get().openTabs }) } catch { /* persistence unavailable — surfaced via save status */ }
  }

  const loadProject = async (id: string): Promise<Project | null> => {
    try { return (await db.getProject(id)) ?? null } catch { return null }
  }

  return {
    ready: false,
    summaries: [],
    project: fallbackProject(),
    openTabs: [],
    page: 'image-lab',
    tool: 'select',
    inspectorOpen: true,
    commandOpen: false,
    view: { zoom: 1, cursor: null, readout: null },
    save: { status: 'saved', at: null, message: null },
    undoStack: [],
    redoStack: [],
    picker: initialPicker(),
    pickerHistory: [],
    compareWith: null,
    toasts: [],

    init: async () => {
      try {
        let all = await db.getAllProjects()
        if (all.length === 0) {
          for (const p of allDemoProjects()) await db.putProject(p)
          all = await db.getAllProjects()
        }
        const session = await db.getMeta<{ active: string; tabs: string[] }>('session')
        const activeId = session && all.some((p) => p.id === session.active) ? session.active : (all.find((p) => p.id === 'prj-aai-opt-2026-014') ?? all[0]).id
        const tabs = (session?.tabs ?? [activeId]).filter((t) => all.some((p) => p.id === t))
        if (!tabs.includes(activeId)) tabs.unshift(activeId)
        const project = all.find((p) => p.id === activeId)!
        set({ project, openTabs: tabs, ready: true, save: { status: 'saved', at: project.updatedAt, message: null } })
        await refreshSummaries()
      } catch (e) {
        // Persistence unavailable (private mode, blocked storage): run from memory and say so.
        const demos = allDemoProjects()
        set({
          project: demos[0], openTabs: [demos[0].id], ready: true, summaries: demos.map(summarise),
          save: { status: 'unavailable', at: null, message: e instanceof Error ? e.message : 'IndexedDB unavailable' },
        })
      }
    },

    setPage: (page) => set({ page }),
    setTool: (tool) => set({ tool }),
    toggleInspector: () => set((s) => ({ inspectorOpen: !s.inspectorOpen })),
    setCommandOpen: (commandOpen) => set({ commandOpen }),
    setView: (v) => set((s) => ({ view: { ...s.view, ...v } })),
    toast: (kind, text) => { const id = toastId++; set((s) => ({ toasts: [...s.toasts.slice(-3), { id, kind, text }] })); window.setTimeout(() => get().dismissToast(id), kind === 'error' ? 7000 : 3500) },
    dismissToast: (id) => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })),

    mutate: (label, fn, opts) => {
      const prev = get().project
      const next: Project = { ...fn(prev), updatedAt: isoNow() }
      const now = Date.now()
      const coalesced = !!opts?.coalesce && lastCoalesce?.key === opts.coalesce && now - lastCoalesce.at < 1200
      lastCoalesce = opts?.coalesce ? { key: opts.coalesce, at: now } : null
      set((s) => ({
        project: coalesced || opts?.silent
          ? next
          : { ...next, adjustmentLog: [...next.adjustmentLog, { at: next.updatedAt, label }].slice(-200) },
        undoStack: coalesced ? s.undoStack : [...s.undoStack, { label, project: prev }].slice(-HISTORY_MAX),
        redoStack: [],
      }))
      scheduleSave()
    },

    undo: () => {
      const { undoStack, project } = get()
      const top = undoStack[undoStack.length - 1]
      if (!top) return
      lastCoalesce = null
      set((s) => ({ project: top.project, undoStack: s.undoStack.slice(0, -1), redoStack: [...s.redoStack, { label: top.label, project }] }))
      scheduleSave()
      get().toast('info', `Undid: ${top.label}`)
    },
    redo: () => {
      const { redoStack, project } = get()
      const top = redoStack[redoStack.length - 1]
      if (!top) return
      lastCoalesce = null
      set((s) => ({ project: top.project, redoStack: s.redoStack.slice(0, -1), undoStack: [...s.undoStack, { label: top.label, project }] }))
      scheduleSave()
      get().toast('info', `Redid: ${top.label}`)
    },

    setPickerSpace: (space) => set((s) => {
      const rec = makeRecord({ linear: s.picker.linear })
      return { picker: { ...s.picker, space, values: pickerValues(rec, space) } }
    }),
    setPickerValues: (values) => set((s) => {
      if (values.some((v) => !Number.isFinite(v))) return s
      return { picker: { ...s.picker, values, linear: linearFromPicker(s.picker.space, values) } }
    }),
    setPickerLinear: (linear, alpha, remember = false) => {
      set((s) => {
        const rec = makeRecord({ linear })
        return { picker: { ...s.picker, linear, alpha: alpha ?? s.picker.alpha, values: pickerValues(rec, s.picker.space) } }
      })
      if (remember) get().commitPickerHistory()
    },
    setPickerAlpha: (alpha) => set((s) => ({ picker: { ...s.picker, alpha: Math.min(1, Math.max(0, alpha)) } })),
    commitPickerHistory: () => set((s) => {
      const rec = makeRecord({ linear: s.picker.linear, alpha: s.picker.alpha, name: undefined, source: 'picker' })
      if (s.pickerHistory[0]?.hex === rec.hex && s.pickerHistory[0].alpha === rec.alpha) return s
      return { pickerHistory: [rec, ...s.pickerHistory].slice(0, 24) }
    }),
    setCompareWith: (compareWith) => set({ compareWith }),

    saveSample: (rec, note = '', extra = {}) => {
      const sample: SavedSample = { id: newId('smp'), record: { ...rec, id: newId('c') }, note, origin: 'picker', ...extra }
      get().mutate(`Save sample ${rec.name}`, (p) => ({ ...p, samples: [...p.samples, sample] }))
      get().toast('ok', `Saved sample “${rec.name}”`)
    },

    flushSave: async () => {
      if (saveTimer) { window.clearTimeout(saveTimer); saveTimer = null }
      if (get().save.status === 'unavailable') return
      set((s) => ({ save: { ...s.save, status: 'saving' } }))
      try {
        const p = get().project
        await db.putProject(p)
        await pushMeta()
        set((s) => ({ save: { status: s.project === p ? 'saved' : 'dirty', at: p.updatedAt, message: null } }))
        await refreshSummaries()
      } catch (e) {
        set({ save: { status: 'error', at: get().save.at, message: e instanceof Error ? e.message : 'Save failed' } })
      }
    },

    openProject: async (id) => {
      if (get().project.id === id) { set({ page: 'image-lab' }); return }
      await get().flushSave()
      const p = await loadProject(id)
      if (!p) { get().toast('error', 'Project could not be loaded'); return }
      lastCoalesce = null
      set((s) => ({ project: p, openTabs: s.openTabs.includes(id) ? s.openTabs : [...s.openTabs, id], undoStack: [], redoStack: [], save: { status: 'saved', at: p.updatedAt, message: null } }))
      await pushMeta()
    },
    closeTab: async (id) => {
      const { openTabs, project } = get()
      if (openTabs.length <= 1) return
      const rest = openTabs.filter((t) => t !== id)
      set({ openTabs: rest })
      if (project.id === id) await get().openProject(rest[rest.length - 1])
      else await pushMeta()
    },
    createProject: async (name) => {
      const clean = name.trim() || 'Untitled project'
      const n = get().summaries.length + 1
      const p = blankProject(newId('prj'), `AAI-NEW-2026-${String(n).padStart(3, '0')}`, clean, 'New project.')
      p.createdAt = isoNow(); p.updatedAt = p.createdAt
      await get().flushSave()
      await db.putProject(p).catch(() => undefined)
      await refreshSummaries()
      lastCoalesce = null
      set((s) => ({ project: p, openTabs: [...s.openTabs, p.id], undoStack: [], redoStack: [], save: { status: 'saved', at: p.updatedAt, message: null } }))
      await pushMeta()
      get().toast('ok', `Created “${clean}”`)
    },
    duplicateProject: async (id) => {
      await get().flushSave()
      const src = await loadProject(id)
      if (!src) return
      const copy: Project = { ...structuredClone(src), id: newId('prj'), name: `${src.name} (copy)`, code: `${src.code}-C`, createdAt: isoNow(), updatedAt: isoNow(), archived: false }
      await db.putProject(copy).catch(() => undefined)
      await refreshSummaries()
      get().toast('ok', `Duplicated as “${copy.name}”`)
    },
    renameProject: async (id, name) => {
      const clean = name.trim()
      if (!clean) { get().toast('warn', 'Project name cannot be empty'); return }
      if (get().project.id === id) { get().mutate('Rename project', (p) => ({ ...p, name: clean })); await get().flushSave(); return }
      const p = await loadProject(id)
      if (!p) return
      await db.putProject({ ...p, name: clean, updatedAt: isoNow() })
      await refreshSummaries()
    },
    archiveProject: async (id, archived) => {
      if (get().project.id === id) { get().mutate(archived ? 'Archive project' : 'Restore project', (p) => ({ ...p, archived })); await get().flushSave(); return }
      const p = await loadProject(id)
      if (!p) return
      await db.putProject({ ...p, archived, updatedAt: isoNow() })
      await refreshSummaries()
    },
    deleteProject: async (id) => {
      const all = get().summaries
      if (all.length <= 1) { get().toast('warn', 'Cannot delete the only project'); return }
      await db.deleteProject(id).catch(() => undefined)
      const rest = all.filter((s) => s.id !== id)
      set({ summaries: rest, openTabs: get().openTabs.filter((t) => t !== id) })
      if (get().project.id === id) await get().openProject(rest[0].id)
      get().toast('ok', 'Project deleted')
    },
    importProject: async (text) => {
      let raw: unknown
      try { raw = JSON.parse(text) } catch { return { ok: false, message: 'Not valid JSON — nothing was imported.' } }
      const obj = raw as Partial<Project> & { project?: Partial<Project> }
      const cand = (obj.project ?? obj) as Partial<Project>
      if (!cand || typeof cand !== 'object' || !cand.name || !Array.isArray(cand.assets) || !Array.isArray(cand.samples) || !Array.isArray(cand.palettes) || !cand.currentGrade)
        return { ok: false, message: 'File is not a CHROMA ENGINE project (missing name, assets, samples, palettes or grade). Nothing was imported.' }
      const base = blankProject(newId('prj'), cand.code ?? 'AAI-IMP', cand.name, cand.description ?? '')
      const p: Project = { ...base, ...(cand as Project), id: newId('prj'), updatedAt: isoNow(), archived: false }
      if (!p.assets.some((a) => a.id === p.activeAssetId)) p.activeAssetId = p.assets.find((a) => a.kind === 'image')?.id ?? p.assets[0]?.id ?? ''
      await get().flushSave()
      await db.putProject(p).catch(() => undefined)
      await refreshSummaries()
      return { ok: true, message: `Imported “${p.name}” as a new project.` }
    },
    restoreDemos: async () => {
      for (const p of allDemoProjects()) await db.putProject({ ...p, id: (await db.getProject(p.id)) ? `${p.id}-restored-${Date.now().toString(36)}` : p.id }).catch(() => undefined)
      await refreshSummaries()
      get().toast('ok', 'Demo projects restored (existing projects were not overwritten)')
    },
  }
})

export const usePickerRecord = (): ColourRecord => {
  const { linear, alpha } = useApp((s) => s.picker)
  return makeRecord({ linear, alpha, name: 'Picker colour', id: 'picker' })
}
