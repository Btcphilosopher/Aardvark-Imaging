import { create } from 'zustand'

interface WorkerStatus {
  mode: 'starting' | 'worker' | 'fallback'
  queue: number
  active: string | null
  lastMs: number
  completed: number
  lastError: string | null
  setMode: (m: 'worker' | 'fallback', err?: string) => void
  start: (label: string) => void
  finish: (ms: number, err: string | null) => void
}

export const useWorkerStatus = create<WorkerStatus>((set) => ({
  mode: 'starting', queue: 0, active: null, lastMs: 0, completed: 0, lastError: null,
  setMode: (mode, err) => set({ mode, lastError: err ?? null }),
  start: (label) => set((s) => ({ queue: s.queue + 1, active: label })),
  finish: (ms, err) => set((s) => ({ queue: Math.max(0, s.queue - 1), active: s.queue <= 1 ? null : s.active, lastMs: ms, completed: s.completed + 1, lastError: err ?? s.lastError })),
}))
