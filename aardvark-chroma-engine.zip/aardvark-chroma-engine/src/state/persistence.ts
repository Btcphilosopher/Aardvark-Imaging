import type { Project } from '../types/project'

const DB_NAME = 'aardvark-chroma-engine'
const DB_VERSION = 1

let dbPromise: Promise<IDBDatabase> | null = null

export function openDb(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise
  dbPromise = new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') { reject(new Error('IndexedDB is not available in this environment')); return }
    const req = indexedDB.open(DB_NAME, DB_VERSION)
    req.onupgradeneeded = () => {
      const db = req.result
      if (!db.objectStoreNames.contains('projects')) db.createObjectStore('projects', { keyPath: 'id' })
      if (!db.objectStoreNames.contains('meta')) db.createObjectStore('meta')
    }
    req.onsuccess = () => resolve(req.result)
    req.onerror = () => { dbPromise = null; reject(req.error ?? new Error('Failed to open IndexedDB')) }
  })
  return dbPromise
}

/** Test hook: drop the cached connection so a fresh fake database can be opened. */
export function resetDbConnection(): void { dbPromise = null }

function wrap<T>(req: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => { req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error) })
}

export async function getAllProjects(): Promise<Project[]> {
  const db = await openDb()
  return wrap(db.transaction('projects', 'readonly').objectStore('projects').getAll() as IDBRequest<Project[]>)
}

export async function getProject(id: string): Promise<Project | undefined> {
  const db = await openDb()
  return wrap(db.transaction('projects', 'readonly').objectStore('projects').get(id) as IDBRequest<Project | undefined>)
}

export async function putProject(p: Project): Promise<void> {
  const db = await openDb()
  await wrap(db.transaction('projects', 'readwrite').objectStore('projects').put(p))
}

export async function deleteProject(id: string): Promise<void> {
  const db = await openDb()
  await wrap(db.transaction('projects', 'readwrite').objectStore('projects').delete(id))
}

export async function getMeta<T>(key: string): Promise<T | undefined> {
  const db = await openDb()
  return wrap(db.transaction('meta', 'readonly').objectStore('meta').get(key) as IDBRequest<T | undefined>)
}

export async function setMeta(key: string, value: unknown): Promise<void> {
  const db = await openDb()
  await wrap(db.transaction('meta', 'readwrite').objectStore('meta').put(value, key))
}

export async function clearAll(): Promise<void> {
  const db = await openDb()
  await wrap(db.transaction('projects', 'readwrite').objectStore('projects').clear())
  await wrap(db.transaction('meta', 'readwrite').objectStore('meta').clear())
}
