import { create } from 'zustand'

/** Tracks whether the current page has claimed the right-hand inspector so the default inspector can step aside. */
export const useInspectorClaims = create<{ claims: number; claim: () => void; release: () => void }>((set) => ({
  claims: 0,
  claim: () => set((s) => ({ claims: s.claims + 1 })),
  release: () => set((s) => ({ claims: Math.max(0, s.claims - 1) })),
}))

export interface ViewerCommand { type: 'fit' | 'zoom100' | 'zoom200' | 'zoom400' | 'zoomIn' | 'zoomOut'; n: number }
export const useViewerBus = create<{ cmd: ViewerCommand | null; send: (t: ViewerCommand['type']) => void }>((set, get) => ({
  cmd: null,
  send: (type) => set({ cmd: { type, n: (get().cmd?.n ?? 0) + 1 } }),
}))
