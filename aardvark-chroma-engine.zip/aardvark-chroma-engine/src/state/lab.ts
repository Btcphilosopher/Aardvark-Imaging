import { create } from 'zustand'
import type { ViewMode } from '../core/image/image-processing'
import type { Rect } from '../core/image/image-model'
import type { ImageBuf } from '../core/image/image-model'
import type { PixelSample } from '../core/image/sampling'

export type CompareMode = 'off' | 'split' | 'wipe' | 'difference'

interface LabState {
  view: ViewMode
  compare: CompareMode
  beforeAssetId: string | 'self'
  wipe: number
  pixelGrid: boolean
  histogramOverlay: boolean
  applyGrade: boolean
  applyLut: boolean
  proofOn: boolean
  exposure: number
  saturation: number
  sampleSource: 'source' | 'displayed'
  set: (p: Partial<Omit<LabState, 'set' | 'cycleChannel' | 'cycleCompare'>>) => void
  cycleChannel: () => void
  cycleCompare: () => void
}

const CHANNELS: ViewMode[] = ['normal', 'r', 'g', 'b', 'alpha', 'luma']
const COMPARES: CompareMode[] = ['off', 'split', 'wipe', 'difference']

export const useLab = create<LabState>((set, get) => ({
  view: 'normal', compare: 'off', beforeAssetId: 'self', wipe: 0.5, pixelGrid: true, histogramOverlay: false, applyGrade: true, applyLut: false, proofOn: false,
  exposure: 0, saturation: 1, sampleSource: 'source',
  set: (p) => set(p),
  cycleChannel: () => { const i = CHANNELS.indexOf(get().view); set({ view: CHANNELS[(i + 1) % CHANNELS.length] }) },
  cycleCompare: () => { const i = COMPARES.indexOf(get().compare); set({ compare: COMPARES[(i + 1) % COMPARES.length] }) },
}))

export interface HistoryPoint { id: number; sample: PixelSample; label: string }
export interface RegionSample { id: number; rect: Rect; hex: string; name: string; meanLinear: { r: number; g: number; b: number } }

interface InspectState {
  hover: { x: number; y: number } | null
  hoverSample: PixelSample | null
  sourceImage: ImageBuf | null
  displayImage: ImageBuf | null
  history: HistoryPoint[]
  points: HistoryPoint[]
  regions: RegionSample[]
  roi: Rect | null
  pendingMeasure: { x: number; y: number } | null
  selection: { kind: 'annotation' | 'sample' | 'measurement'; id: string } | null
  setHover: (h: { x: number; y: number } | null, s: PixelSample | null) => void
  setImages: (src: ImageBuf | null, disp: ImageBuf | null) => void
  pushHistory: (s: PixelSample) => void
  addPoint: (s: PixelSample) => void
  removePoint: (id: number) => void
  clearPoints: () => void
  addRegion: (r: Omit<RegionSample, 'id'>) => void
  clearRegions: () => void
  setRoi: (r: Rect | null) => void
  setPendingMeasure: (p: { x: number; y: number } | null) => void
  select: (s: InspectState['selection']) => void
}

let hid = 1
export const useInspect = create<InspectState>((set) => ({
  hover: null, hoverSample: null, sourceImage: null, displayImage: null, history: [], points: [], regions: [], roi: null, pendingMeasure: null, selection: null,
  setHover: (hover, hoverSample) => set({ hover, hoverSample }),
  setImages: (sourceImage, displayImage) => set({ sourceImage, displayImage }),
  pushHistory: (sample) => set((s) => ({ history: [{ id: hid++, sample, label: `#${hid - 1}` }, ...s.history].slice(0, 40) })),
  addPoint: (sample) => set((s) => ({ points: [...s.points, { id: hid++, sample, label: `P${s.points.length + 1}` }].slice(-12) })),
  removePoint: (id) => set((s) => ({ points: s.points.filter((p) => p.id !== id) })),
  clearPoints: () => set({ points: [] }),
  addRegion: (r) => set((s) => ({ regions: [...s.regions, { ...r, id: hid++ }].slice(-12) })),
  clearRegions: () => set({ regions: [] }),
  setRoi: (roi) => set({ roi }),
  setPendingMeasure: (pendingMeasure) => set({ pendingMeasure }),
  select: (selection) => set({ selection }),
}))
