import { useEffect } from 'react'
import { Shell } from './components/shell/Shell'
import { useApp } from './state/store'
import { Loading } from './components/common/ui'

export default function App() {
  const ready = useApp((s) => s.ready)
  const init = useApp((s) => s.init)
  useEffect(() => { void init() }, [init])
  useEffect(() => {
    const flush = () => { void useApp.getState().flushSave() }
    window.addEventListener('beforeunload', flush)
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flush() })
    return () => window.removeEventListener('beforeunload', flush)
  }, [])
  if (!ready) return <div style={{ padding: 40 }}><Loading label="Opening CHROMA ENGINE" /></div>
  return <Shell />
}
