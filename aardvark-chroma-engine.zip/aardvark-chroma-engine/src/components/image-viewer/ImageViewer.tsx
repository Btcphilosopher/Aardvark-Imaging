import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type { AssetMeta } from '../../types/project'
import type { ImageBuf } from '../../core/image/image-model'
import { differenceImage, type RenderParams, defaultRender } from '../../core/image/image-processing'
import { computeHistograms } from '../../core/image/histograms'
import { regionStat, samplePixel } from '../../core/image/sampling'
import { deltaE2000Linear } from '../../core/colour/contrast'
import { useAssetImage, useRendered } from '../../hooks/useAssetImage'
import { useApp } from '../../state/store'
import { useInspect } from '../../state/lab'
import { useViewerBus } from '../../state/ui-slots'
import { newId, makeRecord } from '../../core/colour/colour-model'
import { Loading, ErrorState } from '../common/ui'
import { isoNow, fmt } from '../../utils/format'

export interface CompareSpec { mode: 'off' | 'split' | 'wipe' | 'difference'; beforeAsset?: AssetMeta; beforeParams?: RenderParams; beforeKey?: string; wipe: number }

interface Props {
  asset: AssetMeta
  params: RenderParams
  depsKey: string
  compare: CompareSpec
  pixelGrid: boolean
  histogramOverlay: boolean
  sampleSource: 'source' | 'displayed'
  onWipe?: (v: number) => void
  onStats?: (s: ReturnType<typeof useRendered>['stats']) => void
  minHeight?: number
}

const isIdentity = (p: RenderParams) => !p.grade && !p.lut && !p.proof && p.view === 'normal' && p.exposureStops === 0 && p.saturationPreview === 1

function toCanvas(img: ImageBuf): HTMLCanvasElement {
  const c = document.createElement('canvas')
  c.width = img.width; c.height = img.height
  const ctx = c.getContext('2d')
  if (!ctx) throw new Error('Canvas 2D context is unavailable in this environment')
  ctx.putImageData(new ImageData(new Uint8ClampedArray(img.data), img.width, img.height), 0, 0)
  return c
}

export function ImageViewer({ asset, params, depsKey, compare, pixelGrid, histogramOverlay, sampleSource, onWipe, onStats, minHeight = 420 }: Props) {
  const tool = useApp((s) => s.tool)
  const setView = useApp((s) => s.setView)
  const mutate = useApp((s) => s.mutate)
  const toast = useApp((s) => s.toast)
  const project = useApp((s) => s.project)
  const inspect = useInspect()
  const busCmd = useViewerBus((s) => s.cmd)

  const wrapRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [size, setSize] = useState({ w: 800, h: 520 })
  const [xf, setXf] = useState({ zoom: 1, ox: 0, oy: 0 })
  const xfRef = useRef(xf); xfRef.current = xf
  const drag = useRef<{ kind: 'pan' | 'wipe' | 'region' | 'crop'; sx: number; sy: number; ox: number; oy: number; ix: number; iy: number; moved: boolean } | null>(null)
  const [dragRect, setDragRect] = useState<{ x: number; y: number; w: number; h: number; kind: 'region' | 'crop' } | null>(null)
  const [hoverLocal, setHoverLocal] = useState<{ x: number; y: number } | null>(null)
  const [annotating, setAnnotating] = useState<{ x: number; y: number } | null>(null)
  const [noteText, setNoteText] = useState('')
  const fittedFor = useRef<string | null>(null)

  const src = useAssetImage(asset)
  const needsRender = !isIdentity(params)
  const after = useRendered(src.key, params, depsKey, needsRender)
  const afterImage = needsRender ? after.image : src.image

  const beforeAsset = compare.beforeAsset ?? asset
  const beforeSrc = useAssetImage(compare.mode !== 'off' && compare.beforeAsset && compare.beforeAsset.id !== asset.id ? beforeAsset : undefined)
  const beforeParams = compare.beforeParams ?? defaultRender()
  const beforeNeeds = !isIdentity(beforeParams)
  const beforeKey = compare.beforeAsset && compare.beforeAsset.id !== asset.id ? beforeSrc.key : src.key
  const beforeRendered = useRendered(beforeKey, beforeParams, JSON.stringify({ ...beforeParams, lut: !!beforeParams.lut }) + beforeKey, compare.mode !== 'off' && beforeNeeds)
  const beforeBase = compare.beforeAsset && compare.beforeAsset.id !== asset.id ? beforeSrc.image : src.image
  const beforeImage = compare.mode === 'off' ? null : beforeNeeds ? beforeRendered.image : beforeBase

  useEffect(() => { onStats?.(after.stats) }, [after.stats, onStats])

  const afterCanvas = useMemo(() => (afterImage ? toCanvas(afterImage) : null), [afterImage])
  const beforeCanvas = useMemo(() => (beforeImage ? toCanvas(beforeImage) : null), [beforeImage])
  const diffCanvas = useMemo(() => (compare.mode === 'difference' && afterImage && beforeImage ? toCanvas(differenceImage(beforeImage, afterImage, 6)) : null), [compare.mode, afterImage, beforeImage])
  const overlayHist = useMemo(() => (histogramOverlay && afterImage ? computeHistograms(afterImage) : null), [histogramOverlay, afterImage])

  // publish images to the inspect store for readouts
  useEffect(() => { if (src.image) inspect.setImages(src.image, afterImage ?? src.image) }, [src.image, afterImage]) // eslint-disable-line react-hooks/exhaustive-deps

  const img = src.image
  const fit = useCallback(() => {
    if (!img) return
    const z = Math.min((size.w - 24) / img.width, (size.h - 24) / img.height)
    const zoom = Math.max(0.02, Math.min(z, 32))
    setXf({ zoom, ox: (size.w - img.width * zoom) / 2, oy: (size.h - img.height * zoom) / 2 })
  }, [img, size.w, size.h])

  useEffect(() => {
    if (!img) return
    const id = `${asset.id}:${img.width}x${img.height}`
    if (fittedFor.current !== id) { fittedFor.current = id; fit() }
  }, [img, asset.id, fit])

  useEffect(() => { setView({ zoom: xf.zoom }) }, [xf.zoom, setView])

  const zoomAt = useCallback((factor: number, cx: number, cy: number, absolute?: number) => {
    setXf((t) => {
      const nz = Math.max(0.02, Math.min(64, absolute ?? t.zoom * factor))
      const ix = (cx - t.ox) / t.zoom, iy = (cy - t.oy) / t.zoom
      return { zoom: nz, ox: cx - ix * nz, oy: cy - iy * nz }
    })
  }, [])

  useEffect(() => {
    if (!busCmd) return
    const cx = size.w / 2, cy = size.h / 2
    switch (busCmd.type) {
      case 'fit': fit(); break
      case 'zoom100': zoomAt(1, cx, cy, 1); break
      case 'zoom200': zoomAt(1, cx, cy, 2); break
      case 'zoom400': zoomAt(1, cx, cy, 4); break
      case 'zoomIn': zoomAt(1.25, cx, cy); break
      case 'zoomOut': zoomAt(0.8, cx, cy); break
    }
  }, [busCmd?.n]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    const el = wrapRef.current
    if (!el) return
    const ro = new ResizeObserver(() => setSize({ w: Math.max(200, el.clientWidth), h: Math.max(200, el.clientHeight) }))
    ro.observe(el)
    setSize({ w: Math.max(200, el.clientWidth), h: Math.max(200, el.clientHeight) })
    return () => ro.disconnect()
  }, [])

  // ───────── drawing ─────────
  const measurements = project.measurements.filter((m) => m.assetId === asset.id)
  const annotations = project.annotations.filter((a) => a.assetId === asset.id)
  const samples = project.samples.filter((s) => s.assetId === asset.id && s.point)

  useEffect(() => {
    const c = canvasRef.current
    if (!c) return
    const dpr = Math.min(2, window.devicePixelRatio || 1)
    c.width = Math.round(size.w * dpr); c.height = Math.round(size.h * dpr)
    c.style.width = `${size.w}px`; c.style.height = `${size.h}px`
    const g = c.getContext('2d')
    if (!g) return
    g.setTransform(dpr, 0, 0, dpr, 0, 0)
    g.fillStyle = '#0b0c0d'; g.fillRect(0, 0, size.w, size.h)
    // engineering grid backdrop
    g.strokeStyle = '#15181a'; g.lineWidth = 1
    for (let x = xf.ox % 32; x < size.w; x += 32) { g.beginPath(); g.moveTo(x + 0.5, 0); g.lineTo(x + 0.5, size.h); g.stroke() }
    for (let y = xf.oy % 32; y < size.h; y += 32) { g.beginPath(); g.moveTo(0, y + 0.5); g.lineTo(size.w, y + 0.5); g.stroke() }
    if (!img || !afterCanvas) return
    const { zoom, ox, oy } = xf
    const w = img.width * zoom, h = img.height * zoom
    g.imageSmoothingEnabled = zoom < 1
    g.imageSmoothingQuality = 'high'
    if (compare.mode === 'difference' && diffCanvas) g.drawImage(diffCanvas, ox, oy, w, h)
    else if ((compare.mode === 'split' || compare.mode === 'wipe') && beforeCanvas) {
      const sx = ox + w * compare.wipe
      g.save(); g.beginPath(); g.rect(0, 0, sx, size.h); g.clip(); g.drawImage(beforeCanvas, ox, oy, w, h); g.restore()
      g.save(); g.beginPath(); g.rect(sx, 0, size.w - sx, size.h); g.clip(); g.drawImage(afterCanvas, ox, oy, w, h); g.restore()
      g.strokeStyle = '#e8630a'; g.lineWidth = 2; g.beginPath(); g.moveTo(sx, Math.max(0, oy)); g.lineTo(sx, Math.min(size.h, oy + h)); g.stroke()
      g.fillStyle = '#e8630a'; g.fillRect(sx - 6, size.h / 2 - 14, 12, 28)
      g.fillStyle = 'rgba(11,12,13,0.85)'; g.font = '11px "IBM Plex Sans", sans-serif'
      g.fillRect(Math.max(ox, 0) + 6, Math.max(oy, 0) + 6, 52, 18); g.fillRect(Math.min(size.w, ox + w) - 58, Math.max(oy, 0) + 6, 52, 18)
      g.fillStyle = '#e9ecee'; g.fillText('BEFORE', Math.max(ox, 0) + 12, Math.max(oy, 0) + 19); g.fillText('AFTER', Math.min(size.w, ox + w) - 52, Math.max(oy, 0) + 19)
    } else g.drawImage(afterCanvas, ox, oy, w, h)
    g.strokeStyle = '#3a4046'; g.lineWidth = 1; g.strokeRect(ox - 0.5, oy - 0.5, w + 1, h + 1)

    // pixel grid
    if (pixelGrid && zoom >= 8) {
      g.strokeStyle = 'rgba(255,255,255,0.16)'; g.lineWidth = 1
      const x0 = Math.max(0, Math.floor(-ox / zoom)), x1 = Math.min(img.width, Math.ceil((size.w - ox) / zoom))
      const y0 = Math.max(0, Math.floor(-oy / zoom)), y1 = Math.min(img.height, Math.ceil((size.h - oy) / zoom))
      g.beginPath()
      for (let x = x0; x <= x1; x++) { const px = Math.round(ox + x * zoom) + 0.5; g.moveTo(px, oy + y0 * zoom); g.lineTo(px, oy + y1 * zoom) }
      for (let y = y0; y <= y1; y++) { const py = Math.round(oy + y * zoom) + 0.5; g.moveTo(ox + x0 * zoom, py); g.lineTo(ox + x1 * zoom, py) }
      g.stroke()
    }

    const P = (x: number, y: number): [number, number] => [ox + x * zoom, oy + y * zoom]
    // saved samples
    for (const s of samples) {
      const [px, py] = P(s.point!.x + 0.5, s.point!.y + 0.5)
      g.strokeStyle = '#000'; g.lineWidth = 3; g.strokeRect(px - 5, py - 5, 10, 10)
      g.strokeStyle = s.record.hex; g.lineWidth = 1.5; g.strokeRect(px - 5, py - 5, 10, 10)
      if (inspect.selection?.kind === 'sample' && inspect.selection.id === s.id) { g.strokeStyle = '#ff7d24'; g.lineWidth = 2; g.strokeRect(px - 9, py - 9, 18, 18) }
    }
    // measurements
    for (const m of measurements) {
      const [ax, ay] = P(m.a.x + 0.5, m.a.y + 0.5), [bx, by] = P(m.b.x + 0.5, m.b.y + 0.5)
      g.strokeStyle = '#000'; g.lineWidth = 3; g.beginPath(); g.moveTo(ax, ay); g.lineTo(bx, by); g.stroke()
      g.strokeStyle = '#e0a11a'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(ax, ay); g.lineTo(bx, by); g.stroke()
      g.fillStyle = '#e0a11a'; for (const [x, y] of [[ax, ay], [bx, by]]) g.fillRect(x - 3, y - 3, 6, 6)
      const d = Math.hypot(m.b.x - m.a.x, m.b.y - m.a.y)
      const label = `${fmt(d, 1)} px`
      g.font = '11px "IBM Plex Sans", sans-serif'
      const tw = g.measureText(label).width
      g.fillStyle = 'rgba(11,12,13,0.9)'; g.fillRect((ax + bx) / 2 - tw / 2 - 4, (ay + by) / 2 - 18, tw + 8, 16)
      g.fillStyle = '#e0a11a'; g.fillText(label, (ax + bx) / 2 - tw / 2, (ay + by) / 2 - 6)
    }
    if (inspect.pendingMeasure) {
      const [ax, ay] = P(inspect.pendingMeasure.x + 0.5, inspect.pendingMeasure.y + 0.5)
      g.fillStyle = '#e0a11a'; g.fillRect(ax - 4, ay - 4, 8, 8)
      if (hoverLocal) { const [bx, by] = P(hoverLocal.x + 0.5, hoverLocal.y + 0.5); g.setLineDash([4, 3]); g.strokeStyle = '#e0a11a'; g.beginPath(); g.moveTo(ax, ay); g.lineTo(bx, by); g.stroke(); g.setLineDash([]) }
    }
    // annotations
    for (const a of annotations) {
      const [px, py] = P(a.x + 0.5, a.y + 0.5)
      g.fillStyle = '#e8630a'; g.beginPath(); g.moveTo(px, py); g.lineTo(px + 9, py - 12); g.lineTo(px - 9, py - 12); g.closePath(); g.fill()
      g.font = '11px "IBM Plex Sans", sans-serif'; const tw = g.measureText(a.text).width
      g.fillStyle = 'rgba(11,12,13,0.92)'; g.fillRect(px + 10, py - 26, tw + 10, 18); g.strokeStyle = '#e8630a'; g.lineWidth = 1; g.strokeRect(px + 10.5, py - 25.5, tw + 9, 17)
      g.fillStyle = '#e9ecee'; g.fillText(a.text, px + 15, py - 13)
    }
    // ROI
    const roi = inspect.roi
    if (roi) {
      const [rx, ry] = P(roi.x, roi.y)
      g.save(); g.fillStyle = 'rgba(0,0,0,0.45)'; g.beginPath(); g.rect(ox, oy, w, h); g.rect(rx, ry, roi.w * zoom, roi.h * zoom); g.fill('evenodd'); g.restore()
      g.strokeStyle = '#e8630a'; g.lineWidth = 1.5; g.setLineDash([6, 3]); g.strokeRect(rx + 0.5, ry + 0.5, roi.w * zoom, roi.h * zoom); g.setLineDash([])
    }
    if (dragRect) {
      const [rx, ry] = P(dragRect.x, dragRect.y)
      g.strokeStyle = dragRect.kind === 'crop' ? '#e8630a' : '#4fb39b'; g.lineWidth = 1.5; g.setLineDash([4, 3]); g.strokeRect(rx + 0.5, ry + 0.5, dragRect.w * zoom, dragRect.h * zoom); g.setLineDash([])
    }
    // crosshair
    if (hoverLocal && (tool === 'sample' || tool === 'measure' || tool === 'crop' || tool === 'annotate')) {
      const [cx, cy] = P(hoverLocal.x + 0.5, hoverLocal.y + 0.5)
      g.strokeStyle = 'rgba(255,255,255,0.85)'; g.lineWidth = 1
      g.beginPath(); g.moveTo(cx - 12, cy + 0.5); g.lineTo(cx - 3, cy + 0.5); g.moveTo(cx + 3, cy + 0.5); g.lineTo(cx + 12, cy + 0.5); g.moveTo(cx + 0.5, cy - 12); g.lineTo(cx + 0.5, cy - 3); g.moveTo(cx + 0.5, cy + 3); g.lineTo(cx + 0.5, cy + 12); g.stroke()
      g.strokeStyle = 'rgba(0,0,0,0.9)'; g.strokeRect(cx - Math.max(3, zoom / 2) - 0.5, cy - Math.max(3, zoom / 2) - 0.5, Math.max(6, zoom) + 1, Math.max(6, zoom) + 1)
    }
    // histogram overlay
    if (overlayHist) {
      const hw = 256, hh = 80, hx = size.w - hw - 12, hy = size.h - hh - 12
      g.fillStyle = 'rgba(11,12,13,0.82)'; g.fillRect(hx - 4, hy - 4, hw + 8, hh + 8); g.strokeStyle = '#3a4046'; g.strokeRect(hx - 3.5, hy - 3.5, hw + 7, hh + 7)
      let max = 1
      for (let i = 1; i < 255; i++) max = Math.max(max, overlayHist.r[i], overlayHist.g[i], overlayHist.b[i])
      g.globalCompositeOperation = 'lighter'
      const ser: [Uint32Array, string][] = [[overlayHist.r, 'rgba(239,90,78,0.8)'], [overlayHist.g, 'rgba(79,179,155,0.8)'], [overlayHist.b, 'rgba(124,156,192,0.8)']]
      for (const [a, col] of ser) { g.fillStyle = col; for (let i = 0; i < 256; i++) { const bh = Math.min(hh, (a[i] / max) * hh); g.fillRect(hx + i, hy + hh - bh, 1, bh) } }
      g.globalCompositeOperation = 'source-over'
    }
  }, [size, xf, img, afterCanvas, beforeCanvas, diffCanvas, compare.mode, compare.wipe, pixelGrid, samples, measurements, annotations, inspect.roi, inspect.pendingMeasure, inspect.selection, dragRect, hoverLocal, tool, overlayHist])

  // ───────── pointer interaction ─────────
  const toImage = (e: { clientX: number; clientY: number }) => {
    const r = canvasRef.current!.getBoundingClientRect()
    const cx = e.clientX - r.left, cy = e.clientY - r.top
    const t = xfRef.current
    return { cx, cy, x: Math.floor((cx - t.ox) / t.zoom), y: Math.floor((cy - t.oy) / t.zoom), fx: (cx - t.ox) / t.zoom, fy: (cy - t.oy) / t.zoom }
  }
  const sampleImage = (): ImageBuf | null => (sampleSource === 'displayed' && afterImage ? afterImage : img)

  const readout = (x: number, y: number) => {
    const im = sampleImage()
    if (!im) return
    const s = samplePixel(im, x, y)
    inspect.setHover(s ? { x, y } : null, s)
    setView({ cursor: s ? { x, y } : null, readout: s ? `${s.record.hex.toUpperCase()}  RGB ${Math.round(s.record.srgb.r * 255)} ${Math.round(s.record.srgb.g * 255)} ${Math.round(s.record.srgb.b * 255)}  L* ${fmt(s.record.lab.l, 1)}` : null })
  }

  const onPointerDown = (e: React.PointerEvent) => {
    if (!img) return
    const p = toImage(e)
    canvasRef.current!.setPointerCapture(e.pointerId)
    const inImg = p.x >= 0 && p.y >= 0 && p.x < img.width && p.y < img.height
    const wipeActive = (compare.mode === 'wipe' || compare.mode === 'split')
    if (wipeActive && Math.abs(p.cx - (xf.ox + img.width * xf.zoom * compare.wipe)) < 10) { drag.current = { kind: 'wipe', sx: p.cx, sy: p.cy, ox: 0, oy: 0, ix: p.x, iy: p.y, moved: false }; return }
    const panning = e.button === 1 || e.button === 2 || tool === 'pan' || tool === 'select' || (tool === 'zoom' && e.shiftKey)
    if (panning) { drag.current = { kind: 'pan', sx: p.cx, sy: p.cy, ox: xf.ox, oy: xf.oy, ix: p.x, iy: p.y, moved: false }; return }
    if (tool === 'zoom') { zoomAt(e.altKey ? 0.8 : 1.25, p.cx, p.cy); return }
    if (!inImg) return
    if (tool === 'sample') { drag.current = { kind: 'region', sx: p.cx, sy: p.cy, ox: 0, oy: 0, ix: p.x, iy: p.y, moved: false }; return }
    if (tool === 'crop') { drag.current = { kind: 'crop', sx: p.cx, sy: p.cy, ox: 0, oy: 0, ix: p.x, iy: p.y, moved: false }; return }
    if (tool === 'measure') {
      const pm = inspect.pendingMeasure
      if (!pm) inspect.setPendingMeasure({ x: p.x, y: p.y })
      else {
        inspect.setPendingMeasure(null)
        if (pm.x === p.x && pm.y === p.y) return
        const im = sampleImage()
        const a = im ? samplePixel(im, pm.x, pm.y) : null, b = im ? samplePixel(im, p.x, p.y) : null
        const de = a && b ? deltaE2000Linear(a.record.linearRgb, b.record.linearRgb) : null
        mutate('Add measurement', (pr) => ({ ...pr, measurements: [...pr.measurements, { id: newId('ms'), assetId: asset.id, a: pm, b: { x: p.x, y: p.y }, note: de !== null ? `ΔE00 ${fmt(de, 2)}` : '', at: isoNow() }] }))
        toast('ok', `Measured ${fmt(Math.hypot(p.x - pm.x, p.y - pm.y), 1)} px${de !== null ? ` · ΔE00 ${fmt(de, 2)}` : ''}`)
      }
      return
    }
    if (tool === 'annotate') { setAnnotating({ x: p.x, y: p.y }); setNoteText(''); return }
  }

  const onPointerMove = (e: React.PointerEvent) => {
    if (!img) return
    const p = toImage(e)
    const d = drag.current
    if (d) {
      if (Math.hypot(p.cx - d.sx, p.cy - d.sy) > 3) d.moved = true
      if (d.kind === 'pan') setXf((t) => ({ ...t, ox: d.ox + (p.cx - d.sx), oy: d.oy + (p.cy - d.sy) }))
      else if (d.kind === 'wipe') onWipe?.(Math.min(1, Math.max(0, (p.cx - xf.ox) / (img.width * xf.zoom))))
      else if (d.kind === 'region' || d.kind === 'crop') {
        const x0 = Math.max(0, Math.min(d.ix, p.x)), y0 = Math.max(0, Math.min(d.iy, p.y))
        const x1 = Math.min(img.width - 1, Math.max(d.ix, p.x)), y1 = Math.min(img.height - 1, Math.max(d.iy, p.y))
        if (d.moved) setDragRect({ x: x0, y: y0, w: x1 - x0 + 1, h: y1 - y0 + 1, kind: d.kind })
      }
    }
    if (p.x >= 0 && p.y >= 0 && p.x < img.width && p.y < img.height) { setHoverLocal({ x: p.x, y: p.y }); readout(p.x, p.y) }
    else { setHoverLocal(null); inspect.setHover(null, null); setView({ cursor: null, readout: null }) }
  }

  const onPointerUp = (e: React.PointerEvent) => {
    const d = drag.current
    drag.current = null
    try { canvasRef.current?.releasePointerCapture(e.pointerId) } catch { /* not captured */ }
    if (!d || !img) return
    const p = toImage(e)
    if (d.kind === 'region' || d.kind === 'crop') {
      const dr = dragRect
      setDragRect(null)
      if (d.kind === 'crop') {
        if (dr && dr.w > 2 && dr.h > 2) { inspect.setRoi({ x: dr.x, y: dr.y, w: dr.w, h: dr.h }); toast('info', `Region of interest ${dr.w}×${dr.h} px set (used by Image Analysis)`) }
        else inspect.setRoi(null)
        return
      }
      const im = sampleImage()
      if (!im) return
      if (dr && d.moved && dr.w > 1 && dr.h > 1) {
        const rs = regionStat(im, dr)
        inspect.addRegion({ rect: dr, hex: rs.meanHex, name: `Region ${dr.w}×${dr.h}`, meanLinear: rs.meanLinear })
        toast('ok', `Region mean ${rs.meanHex.toUpperCase()} (${dr.w * dr.h} px, linear-light average)`)
      } else {
        const s = samplePixel(im, p.x, p.y)
        if (s) { inspect.pushHistory(s); inspect.addPoint(s) }
      }
    }
  }

  const onWheel = useCallback((e: WheelEvent) => {
    e.preventDefault()
    const r = canvasRef.current!.getBoundingClientRect()
    zoomAt(e.deltaY < 0 ? 1.15 : 1 / 1.15, e.clientX - r.left, e.clientY - r.top)
  }, [zoomAt])
  useEffect(() => {
    const c = canvasRef.current
    if (!c) return
    c.addEventListener('wheel', onWheel, { passive: false })
    return () => c.removeEventListener('wheel', onWheel)
  }, [onWheel])

  const commitAnnotation = () => {
    if (annotating && noteText.trim()) mutate('Add annotation', (pr) => ({ ...pr, annotations: [...pr.annotations, { id: newId('an'), assetId: asset.id, x: annotating.x, y: annotating.y, text: noteText.trim().slice(0, 120) }] }))
    setAnnotating(null); setNoteText('')
  }

  const saveHoverAsSample = () => {
    const s = inspect.hoverSample
    if (!s) return
    const rec = makeRecord({ linear: s.record.linearRgb, alpha: s.alpha, name: `Pixel ${s.x},${s.y}`, source: `pixel(${s.x},${s.y}) of ${asset.name}` })
    useApp.getState().saveSample(rec, `Sampled from ${asset.name}`, { assetId: asset.id, point: { x: s.x, y: s.y }, origin: 'pixel' })
  }

  const cursor = tool === 'pan' || tool === 'select' ? (drag.current ? 'grabbing' : 'grab') : tool === 'zoom' ? 'zoom-in' : 'crosshair'

  return (
    <div className="viewer" ref={wrapRef} style={{ minHeight, height: '100%', width: '100%' }}>
      <canvas ref={canvasRef} style={{ cursor, touchAction: 'none' }} onPointerDown={onPointerDown} onPointerMove={onPointerMove} onPointerUp={onPointerUp}
        onPointerLeave={() => { if (!drag.current) { setHoverLocal(null); inspect.setHover(null, null); setView({ cursor: null, readout: null }) } }}
        onContextMenu={(e) => e.preventDefault()} tabIndex={0} role="img" aria-label={`${asset.name} viewer. Scroll to zoom, drag to pan.`}
        onKeyDown={(e) => {
          const step = e.shiftKey ? 40 : 10
          if (e.key === 'ArrowLeft') setXf((t) => ({ ...t, ox: t.ox + step })); else if (e.key === 'ArrowRight') setXf((t) => ({ ...t, ox: t.ox - step }))
          else if (e.key === 'ArrowUp') setXf((t) => ({ ...t, oy: t.oy + step })); else if (e.key === 'ArrowDown') setXf((t) => ({ ...t, oy: t.oy - step }))
          else if (e.key === '+' || e.key === '=') zoomAt(1.25, size.w / 2, size.h / 2); else if (e.key === '-') zoomAt(0.8, size.w / 2, size.h / 2)
          else if (e.key === 'Enter' && tool === 'sample') saveHoverAsSample()
        }} />
      <div className="overlay">
        {src.status === 'loading' && <span className="chip">Generating {asset.name}…</span>}
        {after.busy && needsRender && <span className="chip" style={{ color: 'var(--or-hi)' }}>● processing</span>}
        {hoverLocal && inspect.hoverSample && <span className="chip">{hoverLocal.x}, {hoverLocal.y} · {inspect.hoverSample.record.hex.toUpperCase()}</span>}
        {tool === 'sample' && <span className="chip">Sample: click a pixel, drag for a region average · Enter saves hover</span>}
        {tool === 'measure' && <span className="chip">Measure: {inspect.pendingMeasure ? 'click the second point' : 'click the first point'}</span>}
        {tool === 'crop' && <span className="chip">Crop: drag a region of interest · click to clear</span>}
        {tool === 'annotate' && <span className="chip">Annotate: click to place a note</span>}
      </div>
      {annotating && img && (
        <div style={{ position: 'absolute', left: Math.min(size.w - 240, xf.ox + annotating.x * xf.zoom + 12), top: Math.min(size.h - 40, xf.oy + annotating.y * xf.zoom - 14), zIndex: 5 }} className="row">
          <input autoFocus className="input" style={{ width: 220 }} value={noteText} placeholder="Annotation text" aria-label="Annotation text" onChange={(e) => setNoteText(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') commitAnnotation(); if (e.key === 'Escape') setAnnotating(null) }} onBlur={commitAnnotation} />
        </div>
      )}
      {src.status === 'loading' && !img && <div style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center' }}><Loading label={`Generating ${asset.name}`} /></div>}
      {src.status === 'error' && <div style={{ position: 'absolute', left: 16, top: 16, right: 16 }}><ErrorState message={src.error ?? 'Failed to load image'} /></div>}
      {after.error && <div style={{ position: 'absolute', left: 16, bottom: 16, right: 16 }}><ErrorState message={after.error} /></div>}
    </div>
  )
}
