import { useEffect, useId, useRef, useState, type ReactNode, type CSSProperties } from 'react'
import { AlertTriangle, Info, Check, X as XIcon } from 'lucide-react'
import { parseColourString, type ColourRecord } from '../../core/colour/colour-model'
import { copyText, fmt } from '../../utils/format'
import { useApp } from '../../state/store'

export function Panel({ title, actions, children, paper, className = '', bodyClass = '', noBody, id, style }: { title?: ReactNode; actions?: ReactNode; children: ReactNode; paper?: boolean; className?: string; bodyClass?: string; noBody?: boolean; id?: string; style?: CSSProperties }) {
  return (
    <section className={`panel ${paper ? 'paper' : ''} ${className}`} id={id} style={style}>
      {title !== undefined && (
        <header className="panel-head">
          <h3>{title}</h3>
          {actions && <div className="actions">{actions}</div>}
        </header>
      )}
      {noBody ? children : <div className={`panel-body ${bodyClass}`}>{children}</div>}
    </section>
  )
}

export function Notice({ kind = 'info', title, children }: { kind?: 'approx' | 'warn' | 'ok' | 'info'; title?: string; children: ReactNode }) {
  const Icon = kind === 'warn' ? AlertTriangle : kind === 'ok' ? Check : Info
  return (
    <div className={`notice ${kind}`} role={kind === 'warn' ? 'alert' : 'note'}>
      <Icon size={14} aria-hidden style={{ flex: 'none', marginTop: 2 }} />
      <div>{title && <b>{title} </b>}{children}</div>
    </div>
  )
}

export function Badge({ kind, children, title }: { kind?: 'ok' | 'warn' | 'bad' | 'or'; children: ReactNode; title?: string }) {
  const sym = kind === 'ok' ? '✓ ' : kind === 'warn' ? '△ ' : kind === 'bad' ? '✕ ' : ''
  return <span className={`badge ${kind ?? ''}`} title={title}>{sym}{children}</span>
}

export function Field({ label, children, hint, title }: { label: ReactNode; children: ReactNode; hint?: ReactNode; title?: string }) {
  return <label className="field" title={title}><span className="label">{label}{hint && <span className="faint" style={{ textTransform: 'none', letterSpacing: 0 }}>{hint}</span>}</span>{children}</label>
}

export function Btn({ children, onClick, kind, icon, title, disabled, pressed, size, type = 'button', className = '' }: {
  children?: ReactNode; onClick?: () => void; kind?: 'primary' | 'ghost' | 'danger'; icon?: boolean; title?: string; disabled?: boolean; pressed?: boolean; size?: 'sm'; type?: 'button' | 'submit'; className?: string
}) {
  return (
    <button type={type} className={`btn ${kind ?? ''} ${icon ? 'icon' : ''} ${size ?? ''} ${className}`} onClick={onClick} title={title} aria-label={icon ? title : undefined} disabled={disabled} aria-pressed={pressed}>
      {children}
    </button>
  )
}

/** Validated numeric input. Commits on blur/Enter; invalid text is rejected with visible state and reverts. Arrow keys step. */
export function NumInput({ value, onChange, min = -Infinity, max = Infinity, step = 1, decimals = 2, unit, title, id, ariaLabel }: {
  value: number; onChange: (v: number) => void; min?: number; max?: number; step?: number; decimals?: number; unit?: string; title?: string; id?: string; ariaLabel?: string
}) {
  const [text, setText] = useState<string | null>(null)
  const [invalid, setInvalid] = useState(false)
  const shown = text ?? (Number.isFinite(value) ? fmt(value, decimals) : '')
  const commit = () => {
    if (text === null) return
    const v = parseFloat(text.replace(',', '.'))
    if (!Number.isFinite(v) || text.trim() === '') { setInvalid(true); window.setTimeout(() => setInvalid(false), 1200); setText(null); return }
    onChange(Math.min(max, Math.max(min, v)))
    setText(null); setInvalid(false)
  }
  return (
    <div className="numwrap">
      <input id={id} className="input" inputMode="decimal" value={shown} title={title} aria-label={ariaLabel} aria-invalid={invalid}
        style={unit ? { paddingRight: 22 } : undefined}
        onChange={(e) => setText(e.target.value)} onFocus={(e) => e.target.select()} onBlur={commit}
        onKeyDown={(e) => {
          if (e.key === 'Enter') { commit(); (e.target as HTMLInputElement).blur() }
          else if (e.key === 'Escape') { setText(null); (e.target as HTMLInputElement).blur() }
          else if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
            e.preventDefault()
            const m = e.shiftKey ? 10 : e.altKey ? 0.1 : 1
            const base = text !== null ? parseFloat(text) : value
            const next = Math.min(max, Math.max(min, (Number.isFinite(base) ? base : value) + (e.key === 'ArrowUp' ? 1 : -1) * step * m))
            onChange(next); setText(null)
          }
        }} />
      {unit && <span className="unit">{unit}</span>}
    </div>
  )
}

export function Slider({ label, value, onChange, min, max, step = 0.01, decimals = 2, defaultValue, title, format, disabled }: {
  label: string; value: number; onChange: (v: number) => void; min: number; max: number; step?: number; decimals?: number; defaultValue?: number; title?: string; format?: (v: number) => string; disabled?: boolean
}) {
  const id = useId()
  const [editing, setEditing] = useState<string | null>(null)
  const commit = () => {
    if (editing === null) return
    const v = parseFloat(editing)
    if (Number.isFinite(v)) onChange(Math.min(max, Math.max(min, v)))
    setEditing(null)
  }
  return (
    <div className="slider" title={title}>
      <label className="label" htmlFor={id} onDoubleClick={() => defaultValue !== undefined && onChange(defaultValue)}>{label}</label>
      <input id={id} type="range" min={min} max={max} step={step} value={Number.isFinite(value) ? value : 0} disabled={disabled}
        aria-valuetext={format ? format(value) : fmt(value, decimals)}
        onChange={(e) => onChange(parseFloat(e.target.value))} onDoubleClick={() => defaultValue !== undefined && onChange(defaultValue)} />
      {editing === null
        ? <span className="val" tabIndex={0} role="button" aria-label={`Edit ${label} value`} onClick={() => setEditing(fmt(value, decimals))} onKeyDown={(e) => { if (e.key === 'Enter') setEditing(fmt(value, decimals)) }}>{format ? format(value) : fmt(value, decimals)}</span>
        : <input className="input" style={{ height: 22, padding: '0 4px', textAlign: 'right' }} autoFocus value={editing} onChange={(e) => setEditing(e.target.value)} onBlur={commit}
            onKeyDown={(e) => { if (e.key === 'Enter') commit(); if (e.key === 'Escape') setEditing(null) }} aria-label={`${label} value`} />}
    </div>
  )
}

export function Seg<T extends string>({ options, value, onChange, label }: { options: { id: T; label: string; title?: string }[]; value: T; onChange: (v: T) => void; label?: string }) {
  return (
    <div className="seg" role="group" aria-label={label}>
      {options.map((o) => <button key={o.id} type="button" aria-pressed={value === o.id} title={o.title} onClick={() => onChange(o.id)}>{o.label}</button>)}
    </div>
  )
}

export function Select<T extends string>({ value, onChange, options, ariaLabel, title }: { value: T; onChange: (v: T) => void; options: { id: T; label: string }[]; ariaLabel?: string; title?: string }) {
  return (
    <select className="select" value={value} aria-label={ariaLabel} title={title} onChange={(e) => onChange(e.target.value as T)}>
      {options.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}
    </select>
  )
}

export function Check2({ checked, onChange, children, title }: { checked: boolean; onChange: (v: boolean) => void; children: ReactNode; title?: string }) {
  return <label className="check" title={title}><input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />{children}</label>
}

export function Swatch({ hex, alpha = 1, size = 24, w, h, title, onClick, style, css, selected }: { hex?: string; alpha?: number; size?: number; w?: number; h?: number; title?: string; onClick?: () => void; style?: CSSProperties; css?: string; selected?: boolean }) {
  const bg = css ?? hex
  const inner = <i style={{ background: bg, opacity: alpha }} />
  const st: CSSProperties = { width: w ?? size, height: h ?? size, ...style, ...(selected ? { outline: '2px solid var(--or-hi)', outlineOffset: 1 } : {}) }
  if (onClick) return <button type="button" className={`swatch ${alpha < 1 ? 'checker' : ''}`} style={{ ...st, padding: 0, cursor: 'pointer' }} title={title} aria-label={title ?? hex} onClick={onClick}>{inner}</button>
  return <span className={`swatch ${alpha < 1 ? 'checker' : ''}`} style={st} title={title}>{inner}</span>
}

export function ColourChip({ rec, size = 24, onClick, selected }: { rec: Pick<ColourRecord, 'hex' | 'alpha' | 'name'>; size?: number; onClick?: () => void; selected?: boolean }) {
  return <Swatch hex={rec.hex} alpha={rec.alpha} size={size} title={`${rec.name} ${rec.hex}`} onClick={onClick} selected={selected} />
}

export function CopyBtn({ text, label = 'Copy', kind }: { text: string | (() => string); label?: string; kind?: 'primary' | 'ghost' }) {
  const toast = useApp((s) => s.toast)
  return <Btn size="sm" kind={kind} onClick={async () => { const t = typeof text === 'function' ? text() : text; toast((await copyText(t)) ? 'ok' : 'error', (await Promise.resolve(t)) ? `${label}: copied` : 'Copy failed') }}>{label}</Btn>
}

export function Kv({ rows }: { rows: [ReactNode, ReactNode][] }) {
  return <dl className="kv">{rows.map(([k, v], i) => <div key={i} style={{ display: 'contents' }}><dt>{k}</dt><dd>{v}</dd></div>)}</dl>
}

export function Empty({ title, children, action }: { title: string; children?: ReactNode; action?: ReactNode }) {
  return <div className="empty"><b className="label">{title}</b>{children && <div className="small">{children}</div>}{action}</div>
}

export function Loading({ label = 'Loading' }: { label?: string }) {
  return <div className="col" role="status" aria-live="polite" style={{ padding: 16 }}><span className="label">{label}…</span><div className="skeleton" style={{ height: 8, width: '70%' }} /><div className="skeleton" style={{ height: 8, width: '45%' }} /></div>
}

export function ErrorState({ message, retry }: { message: string; retry?: () => void }) {
  return <div className="notice warn" role="alert"><XIcon size={14} aria-hidden style={{ flex: 'none', marginTop: 2 }} /><div><b>Error </b>{message}{retry && <> <Btn size="sm" onClick={retry}>Retry</Btn></>}</div></div>
}

/** Draw an RGBA buffer into a canvas at its native resolution (CSS scales it). */
export function PixelCanvas({ image, width, height, style, smooth = false, className = '', label }: { image: { width: number; height: number; data: Uint8ClampedArray } | null; width?: number | string; height?: number | string; style?: CSSProperties; smooth?: boolean; className?: string; label?: string }) {
  const ref = useRef<HTMLCanvasElement>(null)
  useEffect(() => {
    const c = ref.current
    if (!c || !image) return
    c.width = image.width; c.height = image.height
    const ctx = c.getContext('2d')
    if (!ctx) return
    ctx.imageSmoothingEnabled = smooth
    ctx.putImageData(new ImageData(new Uint8ClampedArray(image.data.buffer as ArrayBuffer, image.data.byteOffset, image.data.byteLength), image.width, image.height), 0, 0)
  }, [image, smooth])
  return <canvas ref={ref} className={className} role="img" aria-label={label ?? 'Image'} style={{ width: width ?? '100%', height: height ?? 'auto', imageRendering: smooth ? 'auto' : 'pixelated', ...style }} />
}

export function useDebounced<T>(value: T, ms = 200): T {
  const [v, setV] = useState(value)
  useEffect(() => { const h = window.setTimeout(() => setV(value), ms); return () => window.clearTimeout(h) }, [value, ms])
  return v
}

export function GamutBadge({ status }: { status: { srgb: boolean; displayP3: boolean; rec2020: boolean } }) {
  if (status.srgb) return <Badge kind="ok" title="Inside sRGB">sRGB ✓ in gamut</Badge>
  if (status.displayP3) return <Badge kind="warn" title="Outside sRGB, inside Display P3">Outside sRGB · in P3</Badge>
  if (status.rec2020) return <Badge kind="warn" title="Outside Display P3, inside Rec.2020">Outside P3 · in Rec.2020</Badge>
  return <Badge kind="bad" title="Outside Rec.2020">Outside Rec.2020</Badge>
}

/** Colour text input that accepts hex or CSS colour strings; invalid text is flagged and reverted. */
export function HexInput({ hex, onChange, label, alphaHex }: { hex: string; onChange: (linear: import('../../core/colour/conversions').RGB, alpha: number, hex: string) => void; label?: string; alphaHex?: boolean }) {
  const [text, setText] = useState<string | null>(null)
  const [invalid, setInvalid] = useState(false)
  const commit = () => {
    if (text === null) return
    const p = parseColourString(text)
    if (!p) { setInvalid(true); window.setTimeout(() => setInvalid(false), 1400); setText(null); return }
    onChange(p.linear, p.alpha, text); setText(null); setInvalid(false)
  }
  return (
    <input className="input mono" value={text ?? (alphaHex ? hex : hex.slice(0, 7)).toUpperCase()} aria-label={label ?? 'Colour value'} aria-invalid={invalid} title="Hex (#rgb, #rrggbb, #rrggbbaa) or a CSS colour: rgb(), hsl(), oklch(), lab()"
      onChange={(e) => setText(e.target.value)} onFocus={(e) => e.target.select()} onBlur={commit}
      onKeyDown={(e) => { if (e.key === 'Enter') { commit(); (e.target as HTMLInputElement).blur() } else if (e.key === 'Escape') { setText(null); (e.target as HTMLInputElement).blur() } }} />
  )
}
