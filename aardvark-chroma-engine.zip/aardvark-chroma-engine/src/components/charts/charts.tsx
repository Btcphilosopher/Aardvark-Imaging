import { useEffect, useRef } from 'react'
import type { Histograms, Waveform, Vectorscope } from '../../core/image/histograms'

type HistMode = 'rgb' | 'luma' | 'r' | 'g' | 'b'

export function HistogramChart({ hist, mode = 'rgb', height = 90, log = false, showClip = true }: { hist: Histograms | null; mode?: HistMode; height?: number; log?: boolean; showClip?: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null)
  useEffect(() => {
    const c = ref.current
    if (!c || !hist) return
    const w = 256
    c.width = w; c.height = height
    const ctx = c.getContext('2d')
    if (!ctx) return
    ctx.fillStyle = '#111315'; ctx.fillRect(0, 0, w, height)
    ctx.strokeStyle = '#292e33'; ctx.lineWidth = 1
    for (let i = 1; i < 4; i++) { ctx.beginPath(); ctx.moveTo(i * 64 + 0.5, 0); ctx.lineTo(i * 64 + 0.5, height); ctx.stroke() }
    const series: [Uint32Array, string][] = mode === 'rgb' ? [[hist.r, 'rgba(239,90,78,0.75)'], [hist.g, 'rgba(79,179,155,0.75)'], [hist.b, 'rgba(124,156,192,0.75)']]
      : mode === 'luma' ? [[hist.luma, 'rgba(223,227,230,0.85)']] : mode === 'r' ? [[hist.r, 'rgba(239,90,78,0.85)']] : mode === 'g' ? [[hist.g, 'rgba(79,179,155,0.85)']] : [[hist.b, 'rgba(124,156,192,0.85)']]
    const f = (v: number) => (log ? Math.log1p(v) : v)
    let max = 1
    for (const [arr] of series) for (let i = 1; i < 255; i++) max = Math.max(max, f(arr[i]))
    ctx.globalCompositeOperation = 'lighter'
    for (const [arr, col] of series) {
      ctx.fillStyle = col
      for (let i = 0; i < 256; i++) { const h = Math.min(height, (f(arr[i]) / max) * (height - 2)); ctx.fillRect(i, height - h, 1, h) }
    }
    ctx.globalCompositeOperation = 'source-over'
    if (showClip) {
      const tot = hist.count || 1
      const lo = (hist.r[0] + hist.g[0] + hist.b[0]) / 3 / tot, hi = (hist.r[255] + hist.g[255] + hist.b[255]) / 3 / tot
      if (lo > 0.001) { ctx.fillStyle = '#7c9cc0'; ctx.fillRect(0, 0, 3, 6) }
      if (hi > 0.001) { ctx.fillStyle = '#ef5a4e'; ctx.fillRect(w - 3, 0, 3, 6) }
    }
  }, [hist, mode, height, log, showClip])
  return <canvas ref={ref} role="img" aria-label={`${mode} histogram`} style={{ width: '100%', height, display: 'block', border: '1px solid var(--line)' }} />
}

export function WaveformChart({ wf, height = 140, colour = 'rgba(223,227,230,1)' }: { wf: Waveform | null; height?: number; colour?: string }) {
  const ref = useRef<HTMLCanvasElement>(null)
  useEffect(() => {
    const c = ref.current
    if (!c || !wf) return
    c.width = wf.cols; c.height = 256
    const ctx = c.getContext('2d')
    if (!ctx) return
    ctx.fillStyle = '#0b0c0d'; ctx.fillRect(0, 0, wf.cols, 256)
    const img = ctx.createImageData(wf.cols, 256)
    const m = /rgba?\((\d+),(\d+),(\d+)/.exec(colour.replace(/\s/g, ''))
    const [cr, cg, cb] = m ? [+m[1], +m[2], +m[3]] : [223, 227, 230]
    const norm = Math.log1p(wf.max)
    for (let x = 0; x < wf.cols; x++) for (let v = 0; v < 256; v++) {
      const n = wf.data[x * 256 + v]
      if (!n) continue
      const a = Math.min(1, 0.18 + (Math.log1p(n) / norm) * 0.95)
      const o = ((255 - v) * wf.cols + x) * 4
      img.data[o] = cr; img.data[o + 1] = cg; img.data[o + 2] = cb; img.data[o + 3] = Math.round(a * 255)
    }
    ctx.putImageData(img, 0, 0)
    ctx.strokeStyle = 'rgba(232,99,10,0.5)'; ctx.lineWidth = 1
    for (const v of [0, 64, 128, 192, 255]) { const y = 255 - v + 0.5; ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(wf.cols, y); ctx.stroke() }
  }, [wf, colour])
  return <canvas ref={ref} role="img" aria-label="Waveform" style={{ width: '100%', height, display: 'block', border: '1px solid var(--line)', imageRendering: 'pixelated' }} />
}

export function VectorscopeChart({ vs, size = 200 }: { vs: Vectorscope | null; size?: number }) {
  const ref = useRef<HTMLCanvasElement>(null)
  useEffect(() => {
    const c = ref.current
    if (!c || !vs) return
    c.width = vs.size; c.height = vs.size
    const ctx = c.getContext('2d')
    if (!ctx) return
    ctx.fillStyle = '#0b0c0d'; ctx.fillRect(0, 0, vs.size, vs.size)
    const img = ctx.createImageData(vs.size, vs.size)
    const norm = Math.log1p(vs.max)
    for (let i = 0; i < vs.data.length; i++) {
      const n = vs.data[i]
      if (!n) continue
      const a = Math.min(1, 0.25 + (Math.log1p(n) / norm) * 0.9)
      img.data[i * 4] = 240; img.data[i * 4 + 1] = 200; img.data[i * 4 + 2] = 160; img.data[i * 4 + 3] = Math.round(a * 255)
    }
    ctx.putImageData(img, 0, 0)
    ctx.strokeStyle = 'rgba(154,163,171,0.55)'; ctx.lineWidth = 1
    const r = vs.size / 2
    ctx.beginPath(); ctx.arc(r, r, r * 0.9, 0, Math.PI * 2); ctx.moveTo(r, 0); ctx.lineTo(r, vs.size); ctx.moveTo(0, r); ctx.lineTo(vs.size, r); ctx.stroke()
    // Rec.709 primaries/secondaries at 100 % saturation (Cb/Cr of the encoded colours)
    const marks: [string, number, number, string][] = [['R', 1, 0, '#ef5a4e'], ['Yl', 1, 1, '#e0a11a'], ['G', 0, 1, '#4fb39b'], ['Cy', 0, 1, '#4fb39b'], ['B', 0, 0, '#7c9cc0'], ['Mg', 1, 0, '#c879b0']]
    void marks
    const pts: [string, [number, number, number]][] = [['R', [1, 0, 0]], ['Yl', [1, 1, 0]], ['G', [0, 1, 0]], ['Cy', [0, 1, 1]], ['B', [0, 0, 1]], ['Mg', [1, 0, 1]]]
    ctx.font = '9px sans-serif'; ctx.fillStyle = '#e0a11a'
    for (const [name, [R, G, B]] of pts) {
      const Y = 0.2126 * R + 0.7152 * G + 0.0722 * B
      const cb = (B - Y) / 1.8556, cr = (R - Y) / 1.5748
      const x = (cb + 0.5) * vs.size, y = (0.5 - cr) * vs.size
      ctx.strokeRect(x - 3, y - 3, 6, 6); ctx.fillText(name, x + 5, y - 4)
    }
  }, [vs])
  return <canvas ref={ref} role="img" aria-label="Vectorscope" style={{ width: size, height: size, display: 'block', border: '1px solid var(--line)' }} />
}

/** Simple SVG line chart for LUT/1D curves. Values 0..1. */
export function CurveChart({ series, size = 200, title }: { series: { name: string; x: number[]; y: number[]; colour: string; dash?: string }[]; size?: number; title?: string }) {
  const pad = 18
  const s = size - pad * 2
  const path = (x: number[], y: number[]) => x.map((xv, i) => `${i ? 'L' : 'M'}${(pad + xv * s).toFixed(1)},${(pad + (1 - Math.min(1.1, Math.max(-0.1, y[i]))) * s).toFixed(1)}`).join(' ')
  return (
    <svg viewBox={`0 0 ${size} ${size}`} width={size} height={size} role="img" aria-label={title ?? 'Curve'} style={{ background: '#111315', border: '1px solid var(--line)', display: 'block', maxWidth: '100%' }}>
      {[0, 0.25, 0.5, 0.75, 1].map((t) => <g key={t}><line x1={pad + t * s} x2={pad + t * s} y1={pad} y2={pad + s} stroke="#292e33" /><line y1={pad + t * s} y2={pad + t * s} x1={pad} x2={pad + s} stroke="#292e33" /></g>)}
      <rect x={pad} y={pad} width={s} height={s} fill="none" stroke="#3a4046" />
      {series.map((sr) => <path key={sr.name} d={path(sr.x, sr.y)} fill="none" stroke={sr.colour} strokeWidth={1.6} strokeDasharray={sr.dash} />)}
      <text x={pad} y={size - 4} fontSize="9" fill="#8a939b">input →</text>
    </svg>
  )
}

export function BarChart({ values, labels, height = 80, colour = '#e8630a', format }: { values: number[]; labels?: string[]; height?: number; colour?: string; format?: (v: number) => string }) {
  const max = Math.max(...values, 1e-9)
  return (
    <div role="img" aria-label="Bar chart" style={{ display: 'flex', alignItems: 'flex-end', gap: 2, height, borderBottom: '1px solid var(--line)' }}>
      {values.map((v, i) => (
        <div key={i} title={`${labels?.[i] ?? i}: ${format ? format(v) : v.toFixed(3)}`} style={{ flex: 1, height: `${(v / max) * 100}%`, minHeight: v > 0 ? 1 : 0, background: colour }} />
      ))}
    </div>
  )
}
