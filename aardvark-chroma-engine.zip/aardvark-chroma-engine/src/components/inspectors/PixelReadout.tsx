import { useEffect, useRef } from 'react'
import { useApp } from '../../state/store'
import { useInspect, useLab } from '../../state/lab'
import { nearestInProject } from '../../utils/nearest'
import { fmt } from '../../utils/format'
import { GamutBadge, Swatch } from '../common/ui'

export function PixelReadout() {
  const s = useInspect((x) => x.hoverSample)
  const project = useApp((x) => x.project)
  if (!s) return <div className="small muted" style={{ padding: 4 }}>Hover over the image to read pixel values. Values come from the actual pixel data of the {useLab.getState().sampleSource === 'source' ? 'source asset' : 'displayed (processed) image'}.</div>
  const r = s.record
  const n = nearestInProject(r, project)
  const c8 = (v: number) => Math.round(Math.min(1, Math.max(0, v)) * 255)
  return (
    <div className="col" style={{ gap: 6 }}>
      <div className="row">
        <Swatch hex={r.hex} alpha={s.alpha} size={40} />
        <div className="mono" style={{ fontSize: 15 }}>{r.hex.toUpperCase()}<div className="small faint">x {s.x}  y {s.y}  α {fmt(s.alpha, 3)}</div></div>
      </div>
      <table className="tbl" style={{ fontSize: 11.5 }}>
        <tbody>
          <tr><td className="faint">RGB</td><td className="mono">{c8(r.srgb.r)} {c8(r.srgb.g)} {c8(r.srgb.b)}</td></tr>
          <tr><td className="faint">Linear</td><td className="mono">{fmt(r.linearRgb.r, 4)} {fmt(r.linearRgb.g, 4)} {fmt(r.linearRgb.b, 4)}</td></tr>
          <tr><td className="faint">HSL</td><td className="mono">{fmt(r.hsl.h, 0)}° {fmt(r.hsl.s * 100, 0)}% {fmt(r.hsl.l * 100, 0)}%</td></tr>
          <tr><td className="faint">Lab</td><td className="mono">{fmt(r.lab.l, 1)} {fmt(r.lab.a, 1)} {fmt(r.lab.b, 1)}</td></tr>
          <tr><td className="faint">OKLab</td><td className="mono">{fmt(r.oklab.l, 3)} {fmt(r.oklab.a, 3)} {fmt(r.oklab.b, 3)}</td></tr>
          <tr><td className="faint">Luminance</td><td className="mono">{fmt(r.luminance, 4)}</td></tr>
          <tr><td className="faint">Nearest</td><td>{n ? <span className="row"><Swatch hex={n.colour.hex} size={14} /> <span className="small">{n.colour.name} · ΔE00 {fmt(n.deltaE, 1)}</span></span> : '—'}</td></tr>
          <tr><td className="faint">Gamut</td><td><GamutBadge status={r.gamutStatus} /></td></tr>
        </tbody>
      </table>
    </div>
  )
}

/** Magnified pixel neighbourhood with grid and crosshair, drawn from real pixels. */
export function Loupe({ radius = 7, cell = 16 }: { radius?: number; cell?: number }) {
  const ref = useRef<HTMLCanvasElement>(null)
  const hover = useInspect((s) => s.hover)
  const src = useInspect((s) => s.sourceImage)
  const disp = useInspect((s) => s.displayImage)
  const source = useLab((s) => s.sampleSource)
  const img = source === 'displayed' ? disp : src
  const n = radius * 2 + 1
  useEffect(() => {
    const c = ref.current
    if (!c) return
    c.width = n * cell; c.height = n * cell
    const g = c.getContext('2d')
    if (!g) return
    g.fillStyle = '#0b0c0d'; g.fillRect(0, 0, c.width, c.height)
    if (!img || !hover) return
    for (let dy = -radius; dy <= radius; dy++) for (let dx = -radius; dx <= radius; dx++) {
      const x = hover.x + dx, y = hover.y + dy
      if (x < 0 || y < 0 || x >= img.width || y >= img.height) continue
      const i = (y * img.width + x) * 4
      g.fillStyle = `rgb(${img.data[i]},${img.data[i + 1]},${img.data[i + 2]})`
      g.fillRect((dx + radius) * cell, (dy + radius) * cell, cell, cell)
    }
    g.strokeStyle = 'rgba(0,0,0,0.35)'; g.lineWidth = 1
    for (let i = 0; i <= n; i++) { g.beginPath(); g.moveTo(i * cell + 0.5, 0); g.lineTo(i * cell + 0.5, n * cell); g.moveTo(0, i * cell + 0.5); g.lineTo(n * cell, i * cell + 0.5); g.stroke() }
    g.strokeStyle = '#000'; g.lineWidth = 3; g.strokeRect(radius * cell + 1, radius * cell + 1, cell - 2, cell - 2)
    g.strokeStyle = '#ff7d24'; g.lineWidth = 1.5; g.strokeRect(radius * cell + 1, radius * cell + 1, cell - 2, cell - 2)
  }, [img, hover, n, cell, radius])
  return <canvas ref={ref} role="img" aria-label="Pixel loupe" style={{ width: n * cell, height: n * cell, maxWidth: '100%', imageRendering: 'pixelated', border: '1px solid var(--line)', display: 'block' }} />
}
