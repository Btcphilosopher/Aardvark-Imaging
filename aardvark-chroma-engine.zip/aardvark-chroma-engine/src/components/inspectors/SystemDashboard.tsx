import { useMemo } from 'react'
import { useApp } from '../../state/store'
import { useWorkerStatus } from '../../state/worker-status'
import { Kv, Badge } from '../common/ui'
import { validateRecords } from '../../core/colour/colour-validation'
import { shortDate } from '../../utils/format'

export function useProjectValidation() {
  const project = useApp((s) => s.project)
  return useMemo(() => {
    const colours = [...project.samples.map((s) => s.record), ...project.palettes.flatMap((p) => p.colours.map((c) => c.colour))]
    const issues: { severity: 'error' | 'warning' | 'info'; message: string }[] = validateRecords(colours).filter((i) => i.severity !== 'info')
    if (project.outputIntent.trim().toLowerCase() === 'unspecified') issues.push({ severity: 'warning', message: 'Output intent is unspecified' })
    return issues
  }, [project])
}

/** Operational overview: every value is live state, not decoration. */
export function SystemDashboard() {
  const project = useApp((s) => s.project)
  const view = useApp((s) => s.view)
  const tool = useApp((s) => s.tool)
  const save = useApp((s) => s.save)
  const w = useWorkerStatus()
  const issues = useProjectValidation()
  const asset = project.assets.find((a) => a.id === project.activeAssetId)
  const errors = issues.filter((i) => i.severity === 'error').length
  return (
    <div className="col">
      <Kv rows={[
        ['Project', <span key="p">{project.code} · {project.name}</span>],
        ['Active asset', asset ? asset.name : '—'],
        ['Image size', asset && asset.kind === 'image' ? `${asset.width} × ${asset.height} px` : '—'],
        ['Working space', project.workingSpace],
        ['Output intent', project.outputIntent],
        ['Zoom', `${Math.round(view.zoom * 100)} %`],
        ['Tool', tool],
        ['Saved samples', String(project.samples.length)],
        ['Palettes', String(project.palettes.length)],
        ['Assets', String(project.assets.length)],
        ['Last autosave', save.at ? shortDate(save.at) : '—'],
        ['Autosave state', <Badge key="s" kind={save.status === 'saved' ? 'ok' : save.status === 'error' || save.status === 'unavailable' ? 'bad' : 'warn'}>{save.status}</Badge>],
        ['Worker', <span key="w">{w.mode === 'worker' ? 'Web Worker' : w.mode === 'fallback' ? 'Main-thread fallback' : 'Starting'}</span>],
        ['Queue', `${w.queue}${w.active ? ` · ${w.active}` : ''}`],
        ['Last task', `${Math.round(w.lastMs)} ms (${w.completed} completed)`],
        ['Warnings', <Badge key="v" kind={errors ? 'bad' : issues.length ? 'warn' : 'ok'}>{issues.length ? `${issues.length} (${errors} errors)` : 'none'}</Badge>],
      ]} />
      {save.message && <div className="small" style={{ color: 'var(--red)' }}>{save.message}</div>}
      {issues.length > 0 && (
        <ul className="small muted" style={{ margin: 0, paddingLeft: 16 }}>
          {issues.slice(0, 6).map((i, k) => <li key={k}>{i.severity === 'error' ? '✕' : '△'} {i.message}</li>)}
          {issues.length > 6 && <li>…and {issues.length - 6} more</li>}
        </ul>
      )}
    </div>
  )
}
