import { MousePointer2, Hand, ZoomIn, Pipette, Crop, Ruler, MessageSquare, SplitSquareHorizontal, BarChart3, Layers, Printer } from 'lucide-react'
import { useApp, type ToolId } from '../../state/store'
import { useLab } from '../../state/lab'
import { Btn } from '../common/ui'

const POINTER: { id: ToolId; icon: typeof Hand; label: string; key: string }[] = [
  { id: 'select', icon: MousePointer2, label: 'Select / drag to pan', key: 'V' },
  { id: 'pan', icon: Hand, label: 'Pan', key: 'H' },
  { id: 'zoom', icon: ZoomIn, label: 'Zoom (click in, Alt-click out)', key: 'Z' },
  { id: 'sample', icon: Pipette, label: 'Sample pixel / region', key: 'S' },
  { id: 'crop', icon: Crop, label: 'Crop: region of interest for analysis', key: 'C' },
  { id: 'measure', icon: Ruler, label: 'Measure distance and ΔE', key: 'M' },
  { id: 'annotate', icon: MessageSquare, label: 'Annotate', key: 'A' },
]

export function ToolStrip() {
  const tool = useApp((s) => s.tool)
  const setTool = useApp((s) => s.setTool)
  const lab = useLab()
  return (
    <div className="toolstrip" role="toolbar" aria-label="Image tools" aria-orientation="vertical">
      {POINTER.map((t) => (
        <Btn key={t.id} icon kind="ghost" pressed={tool === t.id} title={`${t.label} (${t.key})`} onClick={() => setTool(t.id)}><t.icon size={16} /></Btn>
      ))}
      <div style={{ height: 1, background: 'var(--line)', margin: '4px 2px' }} />
      <Btn icon kind="ghost" pressed={lab.compare !== 'off'} title={`Compare: ${lab.compare} (B cycles off → split → wipe → difference)`} onClick={lab.cycleCompare}><SplitSquareHorizontal size={16} /></Btn>
      <Btn icon kind="ghost" pressed={lab.histogramOverlay} title="Histogram overlay" onClick={() => lab.set({ histogramOverlay: !lab.histogramOverlay })}><BarChart3 size={16} /></Btn>
      <Btn icon kind="ghost" pressed={['r', 'g', 'b', 'alpha', 'luma'].includes(lab.view)} title={`Channel view: ${lab.view} (click to cycle R, G, B, alpha, luma)`} onClick={lab.cycleChannel}><Layers size={16} /></Btn>
      <Btn icon kind="ghost" pressed={lab.proofOn} title="Proof view: approximate print proof from the project's production profile" onClick={() => lab.set({ proofOn: !lab.proofOn })}><Printer size={16} /></Btn>
    </div>
  )
}
