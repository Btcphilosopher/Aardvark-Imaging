import { useEffect, useLayoutEffect, useState, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import { useInspectorClaims } from '../../state/ui-slots'

function useSlot(id: string): HTMLElement | null {
  const [el, setEl] = useState<HTMLElement | null>(null)
  useLayoutEffect(() => { setEl(document.getElementById(id)) }, [id])
  return el
}

/** Render children into the contextual top toolbar. */
export function ToolbarPortal({ children }: { children: ReactNode }) {
  const el = useSlot('toolbar-slot')
  return el ? createPortal(children, el) : null
}

/** Render children into the right-hand inspector; the default inspector hides while a page claims it. */
export function InspectorPortal({ children }: { children: ReactNode }) {
  const el = useSlot('inspector-slot')
  const { claim, release } = useInspectorClaims.getState()
  useEffect(() => { claim(); return () => release() }, [claim, release])
  return el ? createPortal(children, el) : null
}
