import { useEffect, useMemo, useRef, useState } from 'react'
import { useApp, type ToolId } from '../../state/store'
import { PAGES } from '../../pages/registry'
import { useViewerBus } from '../../state/ui-slots'
import { copyText, downloadText, slug } from '../../utils/format'
import { cssOklch } from '../../utils/format'
import { makeRecord } from '../../core/colour/colour-model'

export interface Command { id: string; group: string; label: string; keys?: string; run: () => void; keywords?: string }

export function useCommands(): Command[] {
  const app = useApp()
  const bus = useViewerBus.getState()
  return useMemo<Command[]>(() => {
    const nav: Command[] = PAGES.map((p) => ({ id: `go-${p.id}`, group: 'Go to', label: `${String(p.index).padStart(2, '0')} ${p.title}`, keys: p.index <= 9 ? `Alt+${p.index}` : p.index === 10 ? 'Alt+0' : undefined, run: () => app.setPage(p.id), keywords: p.keywords + ' ' + p.subtitle }))
    const tools: [ToolId, string, string][] = [['select', 'Select', 'V'], ['pan', 'Pan', 'H'], ['zoom', 'Zoom', 'Z'], ['sample', 'Sample (eyedropper)', 'S'], ['crop', 'Crop / region', 'C'], ['measure', 'Measure', 'M'], ['annotate', 'Annotate', 'A'], ['compare', 'Compare', 'B']]
    const toolCmds: Command[] = tools.map(([id, label, k]) => ({ id: `tool-${id}`, group: 'Tool', label: `Tool: ${label}`, keys: k, run: () => { app.setTool(id); if (app.page !== 'inspector') app.setPage('image-lab') } }))
    const viewer: Command[] = [
      { id: 'fit', group: 'View', label: 'Fit to screen', keys: 'F', run: () => bus.send('fit') },
      { id: 'z100', group: 'View', label: 'Zoom 100 %', keys: '1', run: () => bus.send('zoom100') },
      { id: 'z200', group: 'View', label: 'Zoom 200 %', keys: '2', run: () => bus.send('zoom200') },
      { id: 'z400', group: 'View', label: 'Zoom 400 %', keys: '4', run: () => bus.send('zoom400') },
    ]
    const edit: Command[] = [
      { id: 'undo', group: 'Edit', label: 'Undo', keys: 'Ctrl+Z', run: () => app.undo() },
      { id: 'redo', group: 'Edit', label: 'Redo', keys: 'Ctrl+Shift+Z', run: () => app.redo() },
      { id: 'save', group: 'Project', label: 'Save now', keys: 'Ctrl+S', run: () => { void app.flushSave().then(() => app.toast('ok', 'Project saved')) } },
      { id: 'inspector', group: 'View', label: 'Toggle inspector', keys: '\\', run: () => app.toggleInspector() },
      { id: 'new', group: 'Project', label: 'New project', run: () => { void app.createProject(`Project ${app.summaries.length + 1}`).then(() => app.setPage('projects')) } },
      { id: 'export-json', group: 'Project', label: 'Export project JSON', run: () => downloadText(`${slug(app.project.code)}.chroma-project.json`, JSON.stringify({ format: 'chroma-engine-project', version: 1, project: app.project }, null, 2), 'application/json') },
      { id: 'copy-css', group: 'Picker', label: 'Copy picker colour as CSS', run: () => { const r = makeRecord({ linear: app.picker.linear, alpha: app.picker.alpha }); void copyText(`${r.hex}; /* ${cssOklch(r)} */`).then(() => app.toast('ok', 'Copied CSS')) } },
      { id: 'save-sample', group: 'Picker', label: 'Save picker colour as sample', run: () => app.saveSample(makeRecord({ linear: app.picker.linear, alpha: app.picker.alpha, name: undefined, source: 'picker' }), 'From command palette') },
    ]
    return [...nav, ...tools.length ? toolCmds : [], ...viewer, ...edit]
  }, [app, bus])
}

export function CommandPalette() {
  const open = useApp((s) => s.commandOpen)
  const setOpen = useApp((s) => s.setCommandOpen)
  const commands = useCommands()
  const [q, setQ] = useState('')
  const [sel, setSel] = useState(0)
  const inputRef = useRef<HTMLInputElement>(null)
  const listRef = useRef<HTMLUListElement>(null)

  const results = useMemo(() => {
    const terms = q.toLowerCase().split(/\s+/).filter(Boolean)
    if (!terms.length) return commands
    return commands.filter((c) => { const hay = `${c.group} ${c.label} ${c.keywords ?? ''}`.toLowerCase(); return terms.every((t) => hay.includes(t)) })
  }, [q, commands])

  useEffect(() => { if (open) { setQ(''); setSel(0); window.setTimeout(() => inputRef.current?.focus(), 0) } }, [open])
  useEffect(() => { setSel(0) }, [q])
  useEffect(() => { listRef.current?.querySelector('[aria-selected="true"]')?.scrollIntoView({ block: 'nearest' }) }, [sel])

  if (!open) return null
  const run = (c: Command | undefined) => { if (!c) return; setOpen(false); c.run() }
  return (
    <div className="scrim" onMouseDown={(e) => { if (e.target === e.currentTarget) setOpen(false) }}>
      <div className="cmd" role="dialog" aria-modal="true" aria-label="Command palette">
        <input ref={inputRef} value={q} onChange={(e) => setQ(e.target.value)} placeholder="Type a command or page…" aria-label="Command search" role="combobox" aria-expanded="true" aria-controls="cmd-list"
          onKeyDown={(e) => {
            if (e.key === 'ArrowDown') { e.preventDefault(); setSel((s) => Math.min(results.length - 1, s + 1)) }
            else if (e.key === 'ArrowUp') { e.preventDefault(); setSel((s) => Math.max(0, s - 1)) }
            else if (e.key === 'Enter') { e.preventDefault(); run(results[sel]) }
            else if (e.key === 'Escape') { e.preventDefault(); setOpen(false) }
          }} />
        <ul id="cmd-list" ref={listRef} role="listbox">
          {results.length === 0 && <li style={{ cursor: 'default', color: 'var(--t3)' }}>No matching commands</li>}
          {results.map((c, i) => (
            <li key={c.id} role="option" aria-selected={i === sel} onMouseMove={() => setSel(i)} onClick={() => run(c)}>
              <span className="grp">{c.group}</span><span>{c.label}</span>{c.keys && <kbd>{c.keys}</kbd>}
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
