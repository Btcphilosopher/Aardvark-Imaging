import { Suspense, useEffect } from 'react'
import { X, Undo2, Redo2, Command as CommandIcon, PanelRight, Save } from 'lucide-react'
import { useApp } from '../../state/store'
import { PAGES, PAGE_BY_ID } from '../../pages/registry'
import { useInspectorClaims } from '../../state/ui-slots'
import { useWorkerStatus } from '../../state/worker-status'
import { CommandPalette, useCommands } from './CommandPalette'
import { Btn, Loading, Panel, Badge, Kv } from '../common/ui'
import { SystemDashboard } from '../inspectors/SystemDashboard'
import { ColourChip } from '../common/ui'
import { shortDate } from '../../utils/format'
import { useState } from 'react'
import { useShallow } from 'zustand/react/shallow'

const isTyping = (t: EventTarget | null) => {
  const el = t as HTMLElement | null
  return !!el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT' || el.isContentEditable)
}

function Rail() {
  const page = useApp((s) => s.page)
  const setPage = useApp((s) => s.setPage)
  const groups: string[] = []
  PAGES.forEach((p) => { if (!groups.includes(p.group)) groups.push(p.group) })
  return (
    <nav className="rail" aria-label="Primary">
      {groups.map((g) => (
        <div key={g}>
          <div className="rail-group">{g}</div>
          {PAGES.filter((p) => p.group === g).map((p) => (
            <button key={p.id} className="rail-item" aria-current={page === p.id ? 'page' : undefined} onClick={() => setPage(p.id)} title={`${p.title} — ${p.subtitle}`}>
              <span className="idx">{String(p.index).padStart(2, '0')}</span><p.icon size={15} aria-hidden /><span>{p.title}</span>
            </button>
          ))}
        </div>
      ))}
    </nav>
  )
}

function ProjectTabs() {
  const { openTabs, project, summaries, openProject, closeTab } = useApp()
  return (
    <div className="tabs" role="tablist" aria-label="Open projects">
      {openTabs.map((id) => {
        const s = id === project.id ? { code: project.code, name: project.name } : summaries.find((x) => x.id === id)
        if (!s) return null
        return (
          <div key={id} style={{ display: 'flex' }}>
            <button role="tab" className="tab" aria-selected={id === project.id} onClick={() => void openProject(id)} title={`${s.code} — ${s.name}`}>
              <span className="code">{s.code}</span><span className="title">{s.name}</span>
            </button>
            {openTabs.length > 1 && <button className="tab x" aria-label={`Close ${s.name}`} onClick={() => void closeTab(id)} style={{ padding: '0 8px' }}><X size={12} /></button>}
          </div>
        )
      })}
    </div>
  )
}

function Toolbar() {
  const page = useApp((s) => s.page)
  const def = PAGE_BY_ID[page]
  const { undoStack, redoStack, undo, redo, save, setCommandOpen, toggleInspector, inspectorOpen, flushSave } = useApp()
  return (
    <header className="toolbar">
      <div className="title">{def.title}<small>{def.subtitle}</small></div>
      <span className="sep" />
      <div id="toolbar-slot" className="row grow" style={{ minWidth: 0, overflowX: 'auto' }} />
      <span className="sep" />
      <Btn icon size="sm" kind="ghost" title={undoStack.length ? `Undo: ${undoStack[undoStack.length - 1].label} (Ctrl+Z)` : 'Nothing to undo'} disabled={!undoStack.length} onClick={undo}><Undo2 size={15} /></Btn>
      <Btn icon size="sm" kind="ghost" title={redoStack.length ? `Redo: ${redoStack[redoStack.length - 1].label} (Ctrl+Shift+Z)` : 'Nothing to redo'} disabled={!redoStack.length} onClick={redo}><Redo2 size={15} /></Btn>
      <Btn size="sm" kind="ghost" title="Save now (Ctrl+S)" onClick={() => void flushSave()}><Save size={14} /><span className="small muted">{save.status === 'saved' ? 'Saved' : save.status === 'saving' ? 'Saving…' : save.status === 'dirty' ? 'Unsaved' : save.status === 'unavailable' ? 'Not persisted' : 'Save failed'}</span></Btn>
      <Btn size="sm" title="Command palette (Ctrl+K)" onClick={() => setCommandOpen(true)}><CommandIcon size={13} /> Commands <kbd>Ctrl K</kbd></Btn>
      <Btn icon size="sm" kind="ghost" title="Toggle inspector (\)" pressed={inspectorOpen} onClick={toggleInspector}><PanelRight size={15} /></Btn>
    </header>
  )
}

function DefaultInspector() {
  const project = useApp((s) => s.project)
  const setPage = useApp((s) => s.setPage)
  return (
    <div className="col" style={{ padding: 10 }}>
      <Panel title="Project">
        <Kv rows={[['Code', project.code], ['Updated', shortDate(project.updatedAt)], ['Intent', project.outputIntent], ['Working', project.workingSpace]]} />
      </Panel>
      <Panel title={`Saved samples · ${project.samples.length}`} actions={<Btn size="sm" kind="ghost" onClick={() => setPage('picker')}>Picker</Btn>}>
        {project.samples.length === 0 ? <span className="small muted">No samples yet. Use the picker, or the Sample tool in Image Lab.</span> : (
          <div className="row wrap" style={{ gap: 4 }}>{project.samples.slice(0, 32).map((s) => <ColourChip key={s.id} rec={s.record} size={22} />)}</div>
        )}
      </Panel>
      <Panel title="System"><SystemDashboard /></Panel>
    </div>
  )
}

function StatusBar() {
  const { project, view, tool, save, samplesCount } = useApp(useShallow((s) => ({ project: s.project, view: s.view, tool: s.tool, save: s.save, samplesCount: s.project.samples.length })))
  const w = useWorkerStatus()
  const [dash, setDash] = useState(false)
  const asset = project.assets.find((a) => a.id === project.activeAssetId)
  return (
    <footer className="status" role="contentinfo">
      <span className="cell"><b>{project.code}</b></span>
      <span className="cell">{asset && asset.kind === 'image' ? <><b>{asset.width}×{asset.height}</b> px</> : 'no image'}</span>
      <span className="cell">Working <b>{project.workingSpace.split(' ')[0]}</b></span>
      <span className="cell">Intent <b>{project.outputIntent.length > 22 ? project.outputIntent.slice(0, 22) + '…' : project.outputIntent}</b></span>
      <span className="cell">Zoom <b>{Math.round(view.zoom * 100)}%</b></span>
      <span className="cell">Tool <b>{tool}</b></span>
      <span className="cell grow" style={{ minWidth: 0, overflow: 'hidden' }}>{view.cursor ? <><b>{view.cursor.x}, {view.cursor.y}</b>&nbsp;{view.readout}</> : <span className="faint">Move over an image to measure</span>}</span>
      <span className="cell">Samples <b>{samplesCount}</b></span>
      <span className="cell" title={w.mode === 'fallback' ? 'Web Worker unavailable — running on main thread' : 'Web Worker'}>
        {w.queue > 0 ? <span style={{ color: 'var(--or-hi)' }}>● {w.active ?? 'busy'}</span> : <span>○ idle</span>} · <b>{Math.round(w.lastMs)} ms</b>
      </span>
      <span className="cell" title={save.message ?? ''}>
        <span style={{ color: save.status === 'saved' ? 'var(--teal)' : save.status === 'error' || save.status === 'unavailable' ? 'var(--red)' : 'var(--amber)' }}>{save.status === 'saved' ? '✓' : save.status === 'saving' ? '…' : '△'}</span> {save.status === 'saved' ? `Autosaved ${save.at ? shortDate(save.at).slice(11, 16) : ''}` : save.status}
      </span>
      <button className="cell" onClick={() => setDash((d) => !d)} title="Technical dashboard" aria-expanded={dash}>SYS</button>
      {dash && (
        <div style={{ position: 'fixed', right: 12, bottom: 34, width: 340, zIndex: 50 }}>
          <Panel title="Technical dashboard" actions={<Btn size="sm" kind="ghost" onClick={() => setDash(false)}>Close</Btn>}><SystemDashboard /></Panel>
        </div>
      )}
    </footer>
  )
}

function Toasts() {
  const toasts = useApp((s) => s.toasts)
  return <div className="toasts" aria-live="polite">{toasts.map((t) => <div key={t.id} className={`toast ${t.kind}`}>{t.text}</div>)}</div>
}

export function Shell() {
  const page = useApp((s) => s.page)
  const inspectorOpen = useApp((s) => s.inspectorOpen)
  const claims = useInspectorClaims((s) => s.claims)
  const app = useApp()
  const commands = useCommands()
  const def = PAGE_BY_ID[page]
  const Page = def.component

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const mod = e.ctrlKey || e.metaKey
      if (mod && e.key.toLowerCase() === 'k') { e.preventDefault(); app.setCommandOpen(!app.commandOpen); return }
      if (mod && e.key.toLowerCase() === 's') { e.preventDefault(); void app.flushSave().then(() => app.toast('ok', 'Project saved')); return }
      if (isTyping(e.target) || app.commandOpen) return
      if (mod && e.key.toLowerCase() === 'z') { e.preventDefault(); if (e.shiftKey) app.redo(); else app.undo(); return }
      if (mod && e.key.toLowerCase() === 'y') { e.preventDefault(); app.redo(); return }
      if (e.altKey && /^[0-9]$/.test(e.key)) { const n = e.key === '0' ? 10 : parseInt(e.key, 10); const p = PAGES.find((x) => x.index === n); if (p) { e.preventDefault(); app.setPage(p.id) }; return }
      if (mod || e.altKey) return
      if (e.key === '\\') { app.toggleInspector(); return }
      const map: Record<string, string> = { v: 'tool-select', h: 'tool-pan', z: 'tool-zoom', s: 'tool-sample', c: 'tool-crop', m: 'tool-measure', a: 'tool-annotate', b: 'tool-compare', f: 'fit', '1': 'z100', '2': 'z200', '4': 'z400' }
      const id = map[e.key.toLowerCase()]
      if (id && (app.page === 'image-lab' || app.page === 'inspector' || app.page === 'grading')) commands.find((c) => c.id === id)?.run()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [app, commands])

  return (
    <div className="app" style={{ gridTemplateColumns: `208px minmax(0,1fr) ${inspectorOpen ? 'auto' : '0px'}` }}>
      <div className="brand">
        <svg className="mark" viewBox="0 0 32 32" aria-hidden><rect width="32" height="32" fill="#16191c" /><path d="M5 26 L16 5 L27 26 Z" fill="none" stroke="#e8630a" strokeWidth="2.6" /><rect x="11" y="19" width="10" height="2.4" fill="#f2eee6" /></svg>
        <div><div className="name">Chroma Engine</div><div className="sub">Aardvark Imaging</div></div>
      </div>
      <ProjectTabs />
      <Rail />
      <Toolbar />
      <main className="main" id="main" tabIndex={-1}>
        <Suspense fallback={<Loading label={`Loading ${def.title}`} />}><Page key={page} /></Suspense>
      </main>
      <aside className="inspector" style={{ display: inspectorOpen ? 'block' : 'none' }} aria-label="Inspector">
        <div id="inspector-slot" />
        {claims === 0 && <DefaultInspector />}
      </aside>
      <StatusBar />
      <CommandPalette />
      <Toasts />
    </div>
  )
}

export { Badge }
