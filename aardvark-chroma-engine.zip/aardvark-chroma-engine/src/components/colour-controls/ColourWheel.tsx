import { useEffect, useRef } from 'react'
import type { Wheel } from '../../core/grading/grade'

const SQ = Math.sqrt(3)

/** Wheel maps (angle, radius) to a zero-sum RGB offset: (r,g,b) = ρ·(cosθ, cos(θ−120°), cos(θ−240°)). */
export function vecToWheel(x: number, y: number): { r: number; g: number; b: number } {
  const th = Math.atan2(y, x)
  const rho = Math.min(1, Math.hypot(x, y))
  return { r: rho * Math.cos(th), g: rho * Math.cos(th - (2 * Math.PI) / 3), b: rho * Math.cos(th - (4 * Math.PI) / 3) }
}
export function wheelToVec(w: { r: number; g: number; b: number }): { x: number; y: number } {
  return { x: (w.r - (w.g + w.b) / 2) / 1.5, y: (w.g - w.b) / SQ }
}

export function ColourWheel({ value, onChange, label, size = 104 }: { value: Wheel; onChange: (w: Wheel) => void; label: string; size?: number }) {
  const ref = useRef<HTMLCanvasElement>(null)
  useEffect(() => {
    const c = ref.current
    if (!c) return
    const n = size * 2
    c.width = n; c.height = n
    const g = c.getContext('2d')
    if (!g) return
    const img = g.createImageData(n, n)
    const r0 = n / 2 - 2
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
      const dx = (x - n / 2 + 0.5) / r0, dy = -(y - n / 2 + 0.5) / r0
      const rho = Math.hypot(dx, dy)
      const o = (y * n + x) * 4
      if (rho > 1) { img.data[o + 3] = 0; continue }
      const th = Math.atan2(dy, dx)
      const v = [Math.cos(th), Math.cos(th - (2 * Math.PI) / 3), Math.cos(th - (4 * Math.PI) / 3)]
      const s = 0.85
      for (let k = 0; k < 3; k++) img.data[o + k] = Math.round(255 * Math.min(1, Math.max(0, 0.22 + 0.5 * v[k] * Math.min(1, rho * 1.1) * s + 0.1 * (1 - rho))))
      img.data[o + 3] = 255
    }
    g.putImageData(img, 0, 0)
  }, [size])
  const { x, y } = wheelToVec(value)
  const set = (e: React.PointerEvent) => {
    const r = ref.current!.getBoundingClientRect()
    const vx = ((e.clientX - r.left) / r.width - 0.5) * 2 * (r.width / (r.width - 2)), vy = -((e.clientY - r.top) / r.height - 0.5) * 2 * (r.height / (r.height - 2))
    onChange({ ...value, ...vecToWheel(vx, vy) })
  }
  return (
    <div className="col" style={{ alignItems: 'center', gap: 4 }}>
      <span className="label">{label}</span>
      <div style={{ position: 'relative', width: size, height: size, touchAction: 'none' }}>
        <canvas ref={ref} style={{ width: size, height: size, borderRadius: '50%', border: '1px solid var(--line)', cursor: 'crosshair', display: 'block' }} role="slider" tabIndex={0} aria-label={`${label} colour wheel`} aria-valuetext={`R ${value.r.toFixed(2)} G ${value.g.toFixed(2)} B ${value.b.toFixed(2)}`}
          onPointerDown={(e) => { (e.target as HTMLElement).setPointerCapture(e.pointerId); set(e) }} onPointerMove={(e) => { if (e.buttons) set(e) }} onDoubleClick={() => onChange({ ...value, r: 0, g: 0, b: 0 })}
          onKeyDown={(e) => { const d = 0.05; const v = wheelToVec(value); const nv = e.key === 'ArrowLeft' ? { x: v.x - d, y: v.y } : e.key === 'ArrowRight' ? { x: v.x + d, y: v.y } : e.key === 'ArrowUp' ? { x: v.x, y: v.y + d } : e.key === 'ArrowDown' ? { x: v.x, y: v.y - d } : null; if (nv) { e.preventDefault(); onChange({ ...value, ...vecToWheel(nv.x, nv.y) }) } }} />
        <span style={{ position: 'absolute', left: `${50 + x * 48}%`, top: `${50 - y * 48}%`, width: 10, height: 10, margin: '-5px 0 0 -5px', border: '2px solid #fff', boxShadow: '0 0 0 1px #000', borderRadius: '50%', pointerEvents: 'none' }} />
      </div>
      <input type="range" min={-1} max={1} step={0.01} value={value.m} aria-label={`${label} master`} onChange={(e) => onChange({ ...value, m: parseFloat(e.target.value) })} onDoubleClick={() => onChange({ ...value, m: 0 })} style={{ width: size }} title="Master (double-click to reset)" />
    </div>
  )
}
