import type { ColourRecord } from '../../core/colour/colour-model'
import { encodeRgb, rgbToCmykNaive, toGrayscaleEncoded, convertLinear } from '../../core/colour/conversions'
import { fmt } from '../../utils/format'

/** Every representation of a colour, all read from the canonical record (no independent maths here except display scaling). */
export function SpaceTable({ rec, dense }: { rec: ColourRecord; dense?: boolean }) {
  const c8 = (v: number) => Math.round(Math.min(1, Math.max(0, v)) * 255)
  const p3 = encodeRgb('displayP3', convertLinear(rec.linearRgb, 'srgb', 'displayP3'))
  const r2 = encodeRgb('rec2020', convertLinear(rec.linearRgb, 'srgb', 'rec2020'))
  const cmyk = rgbToCmykNaive(rec.srgb)
  const gray = Math.round(toGrayscaleEncoded(rec.linearRgb) * 255)
  const rows: [string, string, string?][] = [
    ['Hex', `${rec.hex.toUpperCase()}${rec.alpha < 1 ? '' : ''}`, 'Clipped 8-bit sRGB'],
    ['sRGB', `${c8(rec.srgb.r)}  ${c8(rec.srgb.g)}  ${c8(rec.srgb.b)}`, 'Display-referred, encoded'],
    ['sRGB (0–1)', `${fmt(rec.srgb.r, 4)}  ${fmt(rec.srgb.g, 4)}  ${fmt(rec.srgb.b, 4)}`, 'Values outside 0–1 are outside the sRGB gamut'],
    ['Linear RGB', `${fmt(rec.linearRgb.r, 5)}  ${fmt(rec.linearRgb.g, 5)}  ${fmt(rec.linearRgb.b, 5)}`, 'Linear light, sRGB primaries'],
    ['Display P3', `${fmt(p3.r, 4)}  ${fmt(p3.g, 4)}  ${fmt(p3.b, 4)}`, 'Encoded with the sRGB curve'],
    ['Rec.2020', `${fmt(r2.r, 4)}  ${fmt(r2.g, 4)}  ${fmt(r2.b, 4)}`, 'Encoded with the BT.2020 curve'],
    ['HSL', `${fmt(rec.hsl.h, 1)}°  ${fmt(rec.hsl.s * 100, 1)}%  ${fmt(rec.hsl.l * 100, 1)}%`],
    ['HSV', `${fmt(rec.hsv.h, 1)}°  ${fmt(rec.hsv.s * 100, 1)}%  ${fmt(rec.hsv.v * 100, 1)}%`],
    ['HWB', `${fmt(rec.hwb.h, 1)}°  ${fmt(rec.hwb.w * 100, 1)}%  ${fmt(rec.hwb.b * 100, 1)}%`],
    ['XYZ (D65)', `${fmt(rec.xyz.x, 5)}  ${fmt(rec.xyz.y, 5)}  ${fmt(rec.xyz.z, 5)}`, 'Y = 1 is the reference white'],
    ['CIELAB', `${fmt(rec.lab.l, 2)}  ${fmt(rec.lab.a, 2)}  ${fmt(rec.lab.b, 2)}`, 'D65 reference white'],
    ['CIELCh', `${fmt(rec.lch.l, 2)}  ${fmt(rec.lch.c, 2)}  ${fmt(rec.lch.h, 1)}°`],
    ['OKLab', `${fmt(rec.oklab.l, 4)}  ${fmt(rec.oklab.a, 4)}  ${fmt(rec.oklab.b, 4)}`],
    ['OKLCh', `${fmt(rec.oklch.l, 4)}  ${fmt(rec.oklch.c, 4)}  ${fmt(rec.oklch.h, 1)}°`],
    ['Luminance Y', fmt(rec.luminance, 5), 'Relative luminance'],
    ['Grayscale', `${gray}`, 'Luminance-preserving, encoded'],
    ['CMYK ≈', `${fmt(cmyk.c * 100, 0)} ${fmt(cmyk.m * 100, 0)} ${fmt(cmyk.y * 100, 0)} ${fmt(cmyk.k * 100, 0)}`, 'NAIVE approximation — not colour-managed'],
    ['Alpha', fmt(rec.alpha, 3)],
  ]
  return (
    <table className="tbl" style={dense ? { fontSize: 11.5 } : undefined}>
      <tbody>
        {rows.map(([k, v, note]) => (
          <tr key={k}><td className="faint" style={{ width: 92, whiteSpace: 'nowrap' }}>{k}</td><td className="mono">{v}</td>{!dense && <td className="faint small">{note}</td>}</tr>
        ))}
      </tbody>
    </table>
  )
}
