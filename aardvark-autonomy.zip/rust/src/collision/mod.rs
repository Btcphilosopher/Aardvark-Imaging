//! Continuous OBB Collision Checking Kernel in Rust (Separating Axis Theorem)

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct OrientedBox {
    pub center: [f64; 2],
    pub extents: [f64; 2], // half-width, half-length
    pub angle_rad: f64,
}

impl OrientedBox {
    pub fn new(center: [f64; 2], extents: [f64; 2], angle_rad: f64) -> Self {
        Self { center, extents, angle_rad }
    }

    pub fn get_axes(&self) -> [[f64; 2]; 2] {
        let (c, s) = (self.angle_rad.cos(), self.angle_rad.sin());
        [[c, s], [-s, c]]
    }

    pub fn project_onto_axis(&self, axis: [f64; 2]) -> (f64, f64) {
        let center_proj = self.center[0] * axis[0] + self.center[1] * axis[1];
        let axes = self.get_axes();
        let r = self.extents[0] * (axes[0][0]*axis[0] + axes[0][1]*axis[1]).abs()
              + self.extents[1] * (axes[1][0]*axis[0] + axes[1][1]*axis[1]).abs();
        (center_proj - r, center_proj + r)
    }
}

pub fn check_obb_intersection(box_a: &OrientedBox, box_b: &OrientedBox) -> bool {
    let axes_a = box_a.get_axes();
    let axes_b = box_b.get_axes();
    let test_axes = [axes_a[0], axes_a[1], axes_b[0], axes_b[1]];

    for axis in test_axes {
        let (min_a, max_a) = box_a.project_onto_axis(axis);
        let (min_b, max_b) = box_b.project_onto_axis(axis);
        if max_a < min_b || max_b < min_a {
            return false; // Separating axis found
        }
    }
    true
}
