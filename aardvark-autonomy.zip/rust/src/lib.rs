//! Aardvark Autonomy Core - Rust High-Performance Spatial & Geometry Engine
//! High-throughput point cloud voxelization, KD-Tree spatial indexing, OBB collision checking

pub mod geometry;
pub mod spatial;
pub mod collision;
pub mod trajectory;
pub mod pointcloud;

pub use geometry::*;
pub use spatial::*;
pub use collision::*;
pub use trajectory::*;
pub use pointcloud::*;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_quaternion_so3_orthogonality() {
        let q = Quaternion::from_euler(0.1, -0.2, 1.57);
        let r = q.to_rotation_matrix();
        let det = r.determinant();
        assert!((det - 1.0).abs() < 1e-6, "SO(3) Determinant must be 1.0");
    }

    #[test]
    fn test_obb_collision_detection() {
        let b1 = OrientedBox::new([0.0, 0.0], [1.0, 1.0], 0.0);
        let b2 = OrientedBox::new([0.5, 0.5], [1.0, 1.0], 0.0);
        let b3 = OrientedBox::new([5.0, 5.0], [1.0, 1.0], 0.0);

        assert!(check_obb_intersection(&b1, &b2), "Overlapping boxes must intersect");
        assert!(!check_obb_intersection(&b1, &b3), "Distant boxes must not intersect");
    }

    #[test]
    fn test_kd_tree_nearest_neighbor() {
        let pts = vec![
            [0.0, 0.0],
            [1.0, 1.0],
            [5.0, 5.0],
            [10.0, 10.0],
        ];
        let tree = SpatialKDTree::build(pts);
        let (nearest, dist) = tree.nearest([1.1, 0.9]);
        assert_eq!(nearest, [1.0, 1.0]);
        assert!(dist < 0.2);
    }
}
