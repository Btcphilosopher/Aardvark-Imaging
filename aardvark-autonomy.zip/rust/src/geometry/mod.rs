//! Geometry & SE(3) Transform Operations in Rust

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct Point3D {
    pub x: f64,
    pub y: f64,
    pub z: f64,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct Quaternion {
    pub x: f64,
    pub y: f64,
    pub z: f64,
    pub w: f64,
}

impl Quaternion {
    pub fn identity() -> Self {
        Self { x: 0.0, y: 0.0, z: 0.0, w: 1.0 }
    }

    pub fn from_euler(roll: f64, pitch: f64, yaw: f64) -> Self {
        let cy = (yaw * 0.5).cos();
        let sy = (yaw * 0.5).sin();
        let cp = (pitch * 0.5).cos();
        let sp = (pitch * 0.5).sin();
        let cr = (roll * 0.5).cos();
        let sr = (roll * 0.5).sin();

        Self {
            w: cr * cp * cy + sr * sp * sy,
            x: sr * cp * cy - cr * sp * sy,
            y: cr * sp * cy + sr * cp * sy,
            z: cr * cp * sy - sr * sp * cy,
        }
    }

    pub fn to_rotation_matrix(&self) -> Matrix3x3 {
        let norm = (self.x*self.x + self.y*self.y + self.z*self.z + self.w*self.w).sqrt();
        let (qx, qy, qz, qw) = (self.x/norm, self.y/norm, self.z/norm, self.w/norm);

        Matrix3x3 {
            data: [
                [1.0 - 2.0*(qy*qy + qz*qz), 2.0*(qx*qy - qz*qw), 2.0*(qx*qz + qy*qw)],
                [2.0*(qx*qy + qz*qw), 1.0 - 2.0*(qx*qx + qz*qz), 2.0*(qy*qz - qx*qw)],
                [2.0*(qx*qz - qy*qw), 2.0*(qy*qz + qx*qw), 1.0 - 2.0*(qx*qx + qy*qy)],
            ]
        }
    }
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct Matrix3x3 {
    pub data: [[f64; 3]; 3],
}

impl Matrix3x3 {
    pub fn determinant(&self) -> f64 {
        let d = &self.data;
        d[0][0] * (d[1][1]*d[2][2] - d[1][2]*d[2][1])
      - d[0][1] * (d[1][0]*d[2][2] - d[1][2]*d[2][0])
      + d[0][2] * (d[1][0]*d[2][1] - d[1][1]*d[2][0])
    }
}
