//! Trajectory Evaluation & Smoothing Primitives in Rust

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TrajectoryPointRust {
    pub t: f64,
    pub x: f64,
    pub y: f64,
    pub yaw: f64,
    pub v: f64,
    pub w: f64,
}

pub fn evaluate_trajectory_cost_rust(
    points: &[TrajectoryPointRust],
    target_x: f64,
    target_y: f64,
    w_goal: f64,
    w_smooth: f64,
) -> f64 {
    if points.is_empty() {
        return f64::MAX;
    }

    let last = &points[points.len() - 1];
    let goal_dist = ((last.x - target_x).powi(2) + (last.y - target_y).powi(2)).sqrt();

    let mut angular_jerk = 0.0;
    for i in 1..points.len() {
        angular_jerk += (points[i].w - points[i-1].w).abs();
    }

    w_goal * goal_dist + w_smooth * angular_jerk
}
