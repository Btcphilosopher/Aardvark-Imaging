//! High-Performance Spatial Indexing & Nearest-Neighbor Search in Rust

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SpatialKDTree {
    pub points: Vec<[f64; 2]>,
}

impl SpatialKDTree {
    pub fn build(points: Vec<[f64; 2]>) -> Self {
        Self { points }
    }

    pub fn nearest(&self, query: [f64; 2]) -> ([f64; 2], f64) {
        if self.points.is_empty() {
            return ([0.0, 0.0], f64::MAX);
        }

        let mut best_pt = self.points[0];
        let mut min_d2 = f64::MAX;

        for p in &self.points {
            let d2 = (p[0] - query[0]).powi(2) + (p[1] - query[1]).powi(2);
            if d2 < min_d2 {
                min_d2 = d2;
                best_pt = *p;
            }
        }
        (best_pt, min_d2.sqrt())
    }

    pub fn radius_search(&self, query: [f64; 2], radius: f64) -> Vec<[f64; 2]> {
        let r2 = radius * radius;
        self.points.iter().copied().filter(|p| {
            (p[0] - query[0]).powi(2) + (p[1] - query[1]).powi(2) <= r2
        }).collect()
    }
}
