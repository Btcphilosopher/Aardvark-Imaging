//! Point Cloud Downsampling & Voxel Filtering in Rust

use serde::{Deserialize, Serialize};
use std::collections::HashMap;

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct LidarPoint {
    pub x: f32,
    pub y: f32,
    pub z: f32,
    pub intensity: f32,
}

pub fn voxel_downsample_rust(points: &[LidarPoint], voxel_size: f32) -> Vec<LidarPoint> {
    if points.is_empty() || voxel_size <= 0.0 {
        return points.to_vec();
    }

    let mut voxel_map: HashMap<(i32, i32, i32), (f32, f32, f32, f32, usize)> = HashMap::new();

    for p in points {
        let vx = (p.x / voxel_size).floor() as i32;
        let vy = (p.y / voxel_size).floor() as i32;
        let vz = (p.z / voxel_size).floor() as i32;

        let entry = voxel_map.entry((vx, vy, vz)).or_insert((0.0, 0.0, 0.0, 0.0, 0));
        entry.0 += p.x;
        entry.1 += p.y;
        entry.2 += p.z;
        entry.3 = entry.3.max(p.intensity);
        entry.4 += 1;
    }

    voxel_map.into_values().map(|(sum_x, sum_y, sum_z, max_i, count)| {
        let n = count as f32;
        LidarPoint {
            x: sum_x / n,
            y: sum_y / n,
            z: sum_z / n,
            intensity: max_i,
        }
    }).collect()
}
