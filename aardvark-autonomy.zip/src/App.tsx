/**
 * Aardvark Autonomy - Main Interactive Autonomy Operator Console
 */

import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { MapVisualizer3D } from './components/MapVisualizer3D';
import { PerceptionView } from './components/PerceptionView';
import { LocalisationView } from './components/LocalisationView';
import { PlanningView } from './components/PlanningView';
import { SafetyView } from './components/SafetyView';
import { BehaviorMissionView } from './components/BehaviorMissionView';
import { TelemetryBenchmarksView } from './components/TelemetryBenchmarksView';
import { ArchitectureDocsView } from './components/ArchitectureDocsView';
import { AutonomySimulation } from './simulation/autonomySimulation';
import { TelemetrySnapshot } from './types/autonomy';
import {
  Map,
  Camera,
  Compass,
  Route,
  Shield,
  GitFork,
  Cpu,
  BookOpen
} from 'lucide-react';

type TabKey =
  | 'map'
  | 'perception'
  | 'localisation'
  | 'planning'
  | 'safety'
  | 'behavior'
  | 'benchmarks'
  | 'architecture';

export default function App() {
  const [selectedScenario, setSelectedScenario] = useState<string>('SCENARIO_03_STATIC_OBSTACLES');
  const [activeTab, setActiveTab] = useState<TabKey>('map');
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [speed, setSpeed] = useState<number>(1);

  // Simulation instance
  const simRef = useRef<AutonomySimulation | null>(null);
  if (!simRef.current) {
    simRef.current = new AutonomySimulation(selectedScenario);
  }

  const [telemetry, setTelemetry] = useState<TelemetrySnapshot>(simRef.current.getSnapshot());

  // Fault Injections State
  const [faultGPS, setFaultGPS] = useState<boolean>(simRef.current.faultGPS);
  const [faultLidar, setFaultLidar] = useState<boolean>(simRef.current.faultLidar);
  const [faultCamera, setFaultCamera] = useState<boolean>(simRef.current.faultCamera);
  const [faultSlip, setFaultSlip] = useState<boolean>(simRef.current.faultSlip);

  // Main Simulation Loop
  useEffect(() => {
    let animId: number;
    let lastTime = performance.now();

    const loop = (currentTime: number) => {
      const elapsed = currentTime - lastTime;
      const targetInterval = 50 / speed; // 50ms base step = 20Hz

      if (isPlaying && elapsed >= targetInterval && simRef.current) {
        lastTime = currentTime;
        const snapshot = simRef.current.step();
        setTelemetry({ ...snapshot });
      }

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [isPlaying, speed]);

  // Handlers
  const handleTogglePlay = () => {
    setIsPlaying((p) => !p);
  };

  const handleStep = () => {
    if (simRef.current) {
      const snapshot = simRef.current.step();
      setTelemetry({ ...snapshot });
    }
  };

  const handleReset = () => {
    if (simRef.current) {
      simRef.current.reset();
      setTelemetry({ ...simRef.current.getSnapshot() });
    }
  };

  const handleSelectScenario = (scenarioId: string) => {
    setSelectedScenario(scenarioId);
    if (simRef.current) {
      simRef.current.setScenario(scenarioId);
      setFaultGPS(simRef.current.faultGPS);
      setFaultLidar(simRef.current.faultLidar);
      setFaultCamera(simRef.current.faultCamera);
      setFaultSlip(simRef.current.faultSlip);
      setTelemetry({ ...simRef.current.getSnapshot() });
    }
  };

  const handleToggleEstop = () => {
    if (simRef.current) {
      if (simRef.current.getSnapshot().safety.estopLatched) {
        simRef.current.resetEstop();
      } else {
        simRef.current.triggerEstop('Operator UI Triggered E-Stop');
      }
      setTelemetry({ ...simRef.current.getSnapshot() });
    }
  };

  const handleSetGoal = (x: number, y: number) => {
    if (simRef.current) {
      simRef.current.setGoal(x, y);
      setTelemetry({ ...simRef.current.getSnapshot() });
    }
  };

  const handleToggleFault = (fault: 'GPS' | 'LIDAR' | 'CAMERA' | 'SLIP') => {
    if (!simRef.current) return;
    if (fault === 'GPS') {
      simRef.current.faultGPS = !faultGPS;
      setFaultGPS(!faultGPS);
    } else if (fault === 'LIDAR') {
      simRef.current.faultLidar = !faultLidar;
      setFaultLidar(!faultLidar);
    } else if (fault === 'CAMERA') {
      simRef.current.faultCamera = !faultCamera;
      setFaultCamera(!faultCamera);
    } else if (fault === 'SLIP') {
      simRef.current.faultSlip = !faultSlip;
      setFaultSlip(!faultSlip);
    }
    setTelemetry({ ...simRef.current.getSnapshot() });
  };

  const tabs: { key: TabKey; label: string; icon: React.FC<{ className?: string }> }[] = [
    { key: 'map', label: '3D LiDAR & Map', icon: Map },
    { key: 'perception', label: 'Perception & MOT', icon: Camera },
    { key: 'localisation', label: 'Localisation & EKF', icon: Compass },
    { key: 'planning', label: 'Planning & DWA', icon: Route },
    { key: 'safety', label: 'Safety & Faults', icon: Shield },
    { key: 'behavior', label: 'Behavior & Mission', icon: GitFork },
    { key: 'benchmarks', label: 'Rust Benchmarks', icon: Cpu },
    { key: 'architecture', label: 'Architecture & ROS 2', icon: BookOpen }
  ];

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-950 text-slate-100 overflow-hidden font-sans">
      {/* Top Header & Simulation Controls */}
      <Header
        telemetry={telemetry}
        isPlaying={isPlaying}
        onTogglePlay={handleTogglePlay}
        onStep={handleStep}
        onReset={handleReset}
        onToggleEstop={handleToggleEstop}
        selectedScenario={selectedScenario}
        onSelectScenario={handleSelectScenario}
        speed={speed}
        onChangeSpeed={setSpeed}
      />

      {/* Main Workspace Navigation Bar */}
      <nav className="bg-slate-900 border-b border-slate-800 px-4 flex items-center space-x-1 overflow-x-auto select-none">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.key;
          return (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex items-center space-x-1.5 py-2 px-3 text-xs font-medium border-b-2 transition whitespace-nowrap ${
                isActive
                  ? 'border-amber-400 text-amber-400 bg-slate-800/60 font-semibold'
                  : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Main View Area */}
      <main className="flex-1 p-3 overflow-hidden">
        {activeTab === 'map' && (
          <MapVisualizer3D
            telemetry={telemetry}
            onSetGoal={handleSetGoal}
            worldEntities={simRef.current ? (simRef.current as any).entities : []}
          />
        )}
        {activeTab === 'perception' && (
          <PerceptionView
            telemetry={telemetry}
            worldEntities={simRef.current ? (simRef.current as any).entities : []}
          />
        )}
        {activeTab === 'localisation' && <LocalisationView telemetry={telemetry} />}
        {activeTab === 'planning' && <PlanningView telemetry={telemetry} />}
        {activeTab === 'safety' && (
          <SafetyView
            telemetry={telemetry}
            faultGPS={faultGPS}
            faultLidar={faultLidar}
            faultCamera={faultCamera}
            faultSlip={faultSlip}
            onToggleFault={handleToggleFault}
            onToggleEstop={handleToggleEstop}
          />
        )}
        {activeTab === 'behavior' && (
          <BehaviorMissionView
            telemetry={telemetry}
            onSetGoal={handleSetGoal}
            onResetMission={handleReset}
          />
        )}
        {activeTab === 'benchmarks' && <TelemetryBenchmarksView telemetry={telemetry} />}
        {activeTab === 'architecture' && <ArchitectureDocsView />}
      </main>
    </div>
  );
}
