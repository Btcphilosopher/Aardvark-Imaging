/**
 * Aardvark Autonomy - Frontend Canonical Types
 */

export type AutonomyState =
  | 'BOOT'
  | 'SELF_TEST'
  | 'CALIBRATING'
  | 'READY'
  | 'LOCALISING'
  | 'AUTONOMOUS'
  | 'DEGRADED'
  | 'RECOVERY'
  | 'EMERGENCY_STOP'
  | 'FAULT'
  | 'SHUTDOWN';

export type QualityState = 'UNKNOWN' | 'INITIALISING' | 'GOOD' | 'DEGRADED' | 'LOST';

export type MissionStatus =
  | 'CREATED'
  | 'VALIDATING'
  | 'READY'
  | 'RUNNING'
  | 'PAUSED'
  | 'BLOCKED'
  | 'FAILED'
  | 'COMPLETED'
  | 'CANCELLED';

export interface Pose2D {
  x: number;
  y: number;
  yaw: number;
}

export interface Velocity2D {
  vx: number;
  wz: number;
}

export interface WorldEntity {
  id: string;
  entityType: 'wall' | 'pillar' | 'pallet' | 'pedestrian' | 'vehicle' | 'crate' | 'robot';
  coordinates: [number, number][];
  isStatic: boolean;
  vx?: number;
  vy?: number;
  yMin?: number;
  yMax?: number;
  confidence?: number;
}

export interface LidarPoint2D {
  x: number;
  y: number;
  z: number;
  intensity: number;
  isObstacle: boolean;
}

export interface TrackedObject {
  id: string;
  className: string;
  confidence: number;
  state: 'TENTATIVE' | 'CONFIRMED' | 'LOST';
  x: number;
  y: number;
  vx: number;
  vy: number;
  length: number;
  width: number;
  hits: number;
  age: number;
}

export interface Waypoint {
  id: string;
  x: number;
  y: number;
  yaw: number;
  speed: number;
}

export interface TrajectoryPoint {
  t: number;
  x: number;
  y: number;
  yaw: number;
  v: number;
  w: number;
  curvature: number;
}

export interface CandidateTrajectory {
  v: number;
  w: number;
  score: number;
  goalScore: number;
  obstacleScore: number;
  smoothScore: number;
  progressScore: number;
  points: TrajectoryPoint[];
}

export interface RejectedTrajectory {
  v: number;
  w: number;
  reason: string;
}

export interface SafetyState {
  approved: boolean;
  state: string;
  reason: string | null;
  minObstacleDist: number;
  ttc: number;
  estopLatched: boolean;
}

export interface ScenarioDef {
  id: string;
  name: string;
  description: string;
  robotStart: Pose2D;
  goal: Pose2D;
  entities: WorldEntity[];
  faults?: string[];
}

export interface EkfState {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  wz: number;
  roll: number;
  pitch: number;
  yaw: number;
  bax: number;
  bay: number;
  baz: number;
  bgx: number;
  bgy: number;
  bgz: number;
  covMatrix: number[][];
}

export interface BehaviorNodeState {
  name: string;
  status: 'SUCCESS' | 'FAILURE' | 'RUNNING' | 'IDLE';
  children?: BehaviorNodeState[];
}

export interface TelemetrySnapshot {
  simTime: number;
  autonomyState: AutonomyState;
  missionStatus: MissionStatus;
  progressPercent: number;
  robotPose: Pose2D;
  groundTruthPose: Pose2D;
  velocity: Velocity2D;
  locQuality: QualityState;
  safety: SafetyState;
  points: LidarPoint2D[];
  tracks: TrackedObject[];
  globalPath: Waypoint[];
  activeTrajectory: TrajectoryPoint[] | null;
  rankedCandidates: CandidateTrajectory[];
  rejectedCandidates: RejectedTrajectory[];
  activeGoal: Pose2D | null;
  ekf: EkfState;
  behaviorTree: BehaviorNodeState;
  auditLogs: { id: string; time: string; severity: 'INFO' | 'WARN' | 'ERROR' | 'CRITICAL'; event: string; details: string }[];
  benchmarks: {
    sensorIngestRate: number;
    lidarProcessingFps: number;
    planningLatencyMs: number;
    controlFreqHz: number;
    ekfFreqHz: number;
    rustSpeedupFactor: number;
  };
}
