import React from 'react';
import { TelemetrySnapshot } from '../types/autonomy';
import { Cpu, Activity, Zap, Layers, BarChart3, Clock } from 'lucide-react';

interface TelemetryBenchmarksViewProps {
  telemetry: TelemetrySnapshot;
}

export const TelemetryBenchmarksView: React.FC<TelemetryBenchmarksViewProps> = ({ telemetry }) => {
  const bench = telemetry.benchmarks;

  return (
    <div id="telemetry-benchmarks-view" className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-full overflow-y-auto p-1">
      {/* Real-Time Processing Metrics */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
          <div className="flex items-center space-x-2">
            <Cpu className="w-4 h-4 text-sky-400" />
            <h3 className="text-sm font-semibold text-white">System Processing Throughput & Latencies</h3>
          </div>
          <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-2 py-0.5 rounded">
            REAL-TIME DETERMINISTIC
          </span>
        </div>

        {/* 4 Metric Tiles */}
        <div className="grid grid-cols-2 gap-3 text-xs font-mono mb-4">
          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-500 text-[10px] block">SENSOR INGESTION RATE</span>
            <span className="text-base font-bold text-sky-400">
              {bench.sensorIngestRate.toLocaleString()} meas/s
            </span>
            <span className="text-slate-500 text-[10px] block mt-0.5">LiDAR + IMU + GPS + Odom</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-500 text-[10px] block">LIDAR PIPELINE RATE</span>
            <span className="text-base font-bold text-emerald-400">
              {bench.lidarProcessingFps} FPS
            </span>
            <span className="text-slate-500 text-[10px] block mt-0.5">Voxel + Ground + Cluster</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-500 text-[10px] block">GLOBAL A* LATENCY</span>
            <span className="text-base font-bold text-amber-400">
              {bench.planningLatencyMs} ms
            </span>
            <span className="text-slate-500 text-[10px] block mt-0.5">Target &lt; 20.0ms</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-500 text-[10px] block">CONTROL LOOP FREQ</span>
            <span className="text-base font-bold text-indigo-400">
              {bench.controlFreqHz} Hz
            </span>
            <span className="text-slate-500 text-[10px] block mt-0.5">Pure Pursuit + Anti-Windup</span>
          </div>
        </div>

        {/* Frequency & Jitter Breakdown */}
        <div className="space-y-2 text-xs font-mono bg-slate-950/80 p-3 rounded border border-slate-800">
          <div className="text-slate-400 font-semibold mb-1 text-[11px]">LOOP JITTER & SCHEDULING</div>
          <div className="flex justify-between text-slate-300">
            <span>EKF ESTIMATOR FREQUENCY:</span>
            <span className="text-emerald-400 font-bold">{bench.ekfFreqHz} Hz (Fixed dt=0.02s)</span>
          </div>
          <div className="flex justify-between text-slate-300">
            <span>WORST-CASE TIMESTEP JITTER:</span>
            <span className="text-sky-400 font-bold">&lt; 0.42 ms</span>
          </div>
          <div className="flex justify-between text-slate-300">
            <span>AUDIT LOGGING OVERHEAD:</span>
            <span className="text-slate-400 font-bold">&lt; 0.05 ms / event</span>
          </div>
        </div>
      </div>

      {/* Rust High-Performance Acceleration Benchmarks */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
          <div className="flex items-center space-x-2">
            <Zap className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-semibold text-white">Rust FFI Kernel Acceleration Benchmarks</h3>
          </div>
          <span className="text-[11px] font-mono text-amber-400 bg-amber-950/60 border border-amber-800 px-2 py-0.5 rounded">
            AVG SPEEDUP: {bench.rustSpeedupFactor}x
          </span>
        </div>

        {/* Benchmark Table */}
        <div className="flex-1 overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[10px]">
                <th className="pb-2">KERNEL OPERATION</th>
                <th className="pb-2">PYTHON TIME</th>
                <th className="pb-2">RUST KERNEL</th>
                <th className="pb-2">SPEEDUP</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              <tr>
                <td className="py-2.5 text-slate-300 font-semibold">Point Cloud Voxelization (10k pts)</td>
                <td className="py-2.5 text-slate-400">14.8 ms</td>
                <td className="py-2.5 text-emerald-400 font-bold">0.42 ms</td>
                <td className="py-2.5 text-amber-400 font-bold">35.2x</td>
              </tr>
              <tr>
                <td className="py-2.5 text-slate-300 font-semibold">KD-Tree Radius Search (1k queries)</td>
                <td className="py-2.5 text-slate-400">8.6 ms</td>
                <td className="py-2.5 text-emerald-400 font-bold">0.31 ms</td>
                <td className="py-2.5 text-amber-400 font-bold">27.7x</td>
              </tr>
              <tr>
                <td className="py-2.5 text-slate-300 font-semibold">OBB Continuous SAT Collision Check</td>
                <td className="py-2.5 text-slate-400">5.2 ms</td>
                <td className="py-2.5 text-emerald-400 font-bold">0.24 ms</td>
                <td className="py-2.5 text-amber-400 font-bold">21.6x</td>
              </tr>
              <tr>
                <td className="py-2.5 text-slate-300 font-semibold">Dynamic Window Rollout Evaluator</td>
                <td className="py-2.5 text-slate-400">12.1 ms</td>
                <td className="py-2.5 text-emerald-400 font-bold">0.85 ms</td>
                <td className="py-2.5 text-amber-400 font-bold">14.2x</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="mt-3 text-[11px] text-slate-400 font-mono">
          ✓ Rust FFI integration via PyO3 & C-ABI zero-copy shared buffers.
        </div>
      </div>
    </div>
  );
};
