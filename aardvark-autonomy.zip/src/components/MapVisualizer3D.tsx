import React, { useRef, useEffect, useState } from 'react';
import { TelemetrySnapshot, WorldEntity } from '../types/autonomy';
import { Layers, Target, Eye, ZoomIn, ZoomOut, RotateCcw, Navigation } from 'lucide-react';

interface MapVisualizer3DProps {
  telemetry: TelemetrySnapshot;
  onSetGoal: (x: number, y: number) => void;
  worldEntities: WorldEntity[];
}

export const MapVisualizer3D: React.FC<MapVisualizer3DProps> = ({
  telemetry,
  onSetGoal,
  worldEntities
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Viewport transforms (center offset in world meters, scale in pixels per meter)
  const [zoom, setZoom] = useState<number>(28); // pixels per meter
  const [panX, setPanX] = useState<number>(0);
  const [panY, setPanY] = useState<number>(0);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [followRobot, setFollowRobot] = useState<boolean>(true);

  // Layer Toggles
  const [showLidar, setShowLidar] = useState<boolean>(true);
  const [showCostmap, setShowCostmap] = useState<boolean>(true);
  const [showGlobalPath, setShowGlobalPath] = useState<boolean>(true);
  const [showCandidates, setShowCandidates] = useState<boolean>(true);
  const [showTracks, setShowTracks] = useState<boolean>(true);
  const [showGeofence, setShowGeofence] = useState<boolean>(true);
  const [is3DView, setIs3DView] = useState<boolean>(false);

  // Follow robot auto-center
  useEffect(() => {
    if (followRobot) {
      setPanX(-telemetry.robotPose.x);
      setPanY(-telemetry.robotPose.y);
    }
  }, [telemetry.robotPose.x, telemetry.robotPose.y, followRobot]);

  // Main Canvas Render Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Handle high DPI
    const width = canvas.clientWidth;
    const height = canvas.clientHeight;
    canvas.width = width * window.devicePixelRatio;
    canvas.height = height * window.devicePixelRatio;
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio);

    // Clear background
    ctx.fillStyle = '#090d16';
    ctx.fillRect(0, 0, width, height);

    // Convert World Coordinates (meters) to Canvas Coordinates (pixels)
    const worldToCanvas = (wx: number, wy: number) => {
      const cx = width / 2 + (wx + panX) * zoom;
      const cy = height / 2 - (wy + panY) * zoom; // Invert Y for standard Cartesian
      return { x: cx, y: cy };
    };

    // Convert Canvas to World
    const canvasToWorld = (cx: number, cy: number) => {
      const wx = (cx - width / 2) / zoom - panX;
      const wy = -(cy - height / 2) / zoom - panY;
      return { x: wx, y: wy };
    };

    // 1. Draw Grid Lines (1m and 5m intervals)
    ctx.lineWidth = 1;
    const minW = canvasToWorld(0, height);
    const maxW = canvasToWorld(width, 0);

    const startX = Math.floor(minW.x) - 1;
    const endX = Math.ceil(maxW.x) + 1;
    const startY = Math.floor(minW.y) - 1;
    const endY = Math.ceil(maxW.y) + 1;

    for (let gx = startX; gx <= endX; gx++) {
      const pt1 = worldToCanvas(gx, startY);
      const pt2 = worldToCanvas(gx, endY);
      ctx.strokeStyle = gx % 5 === 0 ? 'rgba(51, 65, 85, 0.45)' : 'rgba(30, 41, 59, 0.3)';
      ctx.beginPath();
      ctx.moveTo(pt1.x, pt1.y);
      ctx.lineTo(pt2.x, pt2.y);
      ctx.stroke();

      if (gx % 5 === 0 && zoom > 18) {
        ctx.fillStyle = '#475569';
        ctx.font = '9px monospace';
        ctx.fillText(`${gx}m`, pt1.x + 2, height - 8);
      }
    }

    for (let gy = startY; gy <= endY; gy++) {
      const pt1 = worldToCanvas(startX, gy);
      const pt2 = worldToCanvas(endX, gy);
      ctx.strokeStyle = gy % 5 === 0 ? 'rgba(51, 65, 85, 0.45)' : 'rgba(30, 41, 59, 0.3)';
      ctx.beginPath();
      ctx.moveTo(pt1.x, pt1.y);
      ctx.lineTo(pt2.x, pt2.y);
      ctx.stroke();

      if (gy % 5 === 0 && zoom > 18) {
        ctx.fillStyle = '#475569';
        ctx.font = '9px monospace';
        ctx.fillText(`${gy}m`, 8, pt1.y - 2);
      }
    }

    // Origin Axes
    const origin = worldToCanvas(0, 0);
    ctx.strokeStyle = 'rgba(239, 68, 68, 0.6)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(origin.x, origin.y);
    ctx.lineTo(origin.x + 30, origin.y);
    ctx.stroke(); // X (Red)

    ctx.strokeStyle = 'rgba(34, 197, 94, 0.6)';
    ctx.beginPath();
    ctx.moveTo(origin.x, origin.y);
    ctx.lineTo(origin.x, origin.y - 30);
    ctx.stroke(); // Y (Green)

    // 2. Draw Geofence Perimeter
    if (showGeofence) {
      const gf1 = worldToCanvas(-19, 19);
      const gf2 = worldToCanvas(19, 19);
      const gf3 = worldToCanvas(19, -19);
      const gf4 = worldToCanvas(-19, -19);

      ctx.strokeStyle = 'rgba(244, 63, 94, 0.5)';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([6, 6]);
      ctx.beginPath();
      ctx.moveTo(gf1.x, gf1.y);
      ctx.lineTo(gf2.x, gf2.y);
      ctx.lineTo(gf3.x, gf3.y);
      ctx.lineTo(gf4.x, gf4.y);
      ctx.closePath();
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // 3. Draw Static & Dynamic World Entities
    worldEntities.forEach((ent) => {
      if (ent.coordinates.length < 2) return;
      const pts = ent.coordinates.map((c) => worldToCanvas(c[0], c[1]));

      // Costmap Inflation Halo around obstacles
      if (showCostmap && ent.isStatic) {
        ctx.fillStyle = 'rgba(234, 179, 8, 0.06)';
        ctx.beginPath();
        const center = ent.coordinates.reduce((a, b) => [a[0] + b[0], a[1] + b[1]], [0, 0]);
        center[0] /= ent.coordinates.length;
        center[1] /= ent.coordinates.length;
        const cCanvas = worldToCanvas(center[0], center[1]);
        ctx.arc(cCanvas.x, cCanvas.y, zoom * 1.5, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.beginPath();
      ctx.moveTo(pts[0].x, pts[0].y);
      for (let i = 1; i < pts.length; i++) {
        ctx.lineTo(pts[i].x, pts[i].y);
      }
      ctx.closePath();

      if (ent.entityType === 'wall') {
        ctx.fillStyle = '#334155';
        ctx.strokeStyle = '#64748b';
      } else if (ent.entityType === 'pillar') {
        ctx.fillStyle = '#475569';
        ctx.strokeStyle = '#94a3b8';
      } else if (ent.entityType === 'pallet' || ent.entityType === 'crate') {
        ctx.fillStyle = '#78350f';
        ctx.strokeStyle = '#d97706';
      } else if (ent.entityType === 'pedestrian') {
        ctx.fillStyle = '#065f46';
        ctx.strokeStyle = '#10b981';
      } else {
        ctx.fillStyle = '#1e3a8a';
        ctx.strokeStyle = '#3b82f6';
      }

      ctx.lineWidth = 1.5;
      ctx.fill();
      ctx.stroke();

      // Draw Entity Label & Velocity Vector
      const cx = pts.reduce((a, b) => a + b.x, 0) / pts.length;
      const cy = pts.reduce((a, b) => a + b.y, 0) / pts.length;
      ctx.fillStyle = '#cbd5e1';
      ctx.font = '10px monospace';
      ctx.fillText(ent.id, cx - 14, cy - 8);

      if (!ent.isStatic && (ent.vx || ent.vy)) {
        const vx = ent.vx || 0;
        const vy = ent.vy || 0;
        const arrowEnd = worldToCanvas(
          (ent.coordinates[0][0] + ent.coordinates[1][0]) / 2 + vx * 1.2,
          (ent.coordinates[0][1] + ent.coordinates[1][1]) / 2 + vy * 1.2
        );
        ctx.strokeStyle = '#10b981';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(arrowEnd.x, arrowEnd.y);
        ctx.stroke();
      }
    });

    // 4. Draw LiDAR Return Points & Raycasts
    if (showLidar && telemetry.points.length > 0) {
      const rPos = worldToCanvas(telemetry.robotPose.x, telemetry.robotPose.y);

      // Draw Subtle Rays
      ctx.strokeStyle = 'rgba(6, 182, 212, 0.06)';
      ctx.lineWidth = 0.5;
      for (let i = 0; i < telemetry.points.length; i += 2) {
        const pt = worldToCanvas(telemetry.points[i].x, telemetry.points[i].y);
        ctx.beginPath();
        ctx.moveTo(rPos.x, rPos.y);
        ctx.lineTo(pt.x, pt.y);
        ctx.stroke();
      }

      // Draw Point Cloud
      telemetry.points.forEach((p) => {
        const pt = worldToCanvas(p.x, p.y);
        ctx.fillStyle = p.isObstacle ? '#f43f5e' : '#06b6d4';
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, 1.8, 0, Math.PI * 2);
        ctx.fill();
      });
    }

    // 5. Draw Global A* Path Waypoints
    if (showGlobalPath && telemetry.globalPath && telemetry.globalPath.length > 0) {
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 2;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      telemetry.globalPath.forEach((wp, idx) => {
        const pt = worldToCanvas(wp.x, wp.y);
        if (idx === 0) ctx.moveTo(pt.x, pt.y);
        else ctx.lineTo(pt.x, pt.y);
      });
      ctx.stroke();
      ctx.setLineDash([]);

      // Waypoint Dots
      telemetry.globalPath.forEach((wp) => {
        const pt = worldToCanvas(wp.x, wp.y);
        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, 3, 0, Math.PI * 2);
        ctx.fill();
      });
    }

    // 6. Draw Local Trajectory Rollout Candidates (Explainability)
    if (showCandidates) {
      // Rejected Candidates (dim red)
      telemetry.rejectedCandidates.forEach((c) => {
        const heading = telemetry.robotPose.yaw;
        const endX = telemetry.robotPose.x + c.v * 1.5 * Math.cos(heading + c.w * 0.8);
        const endY = telemetry.robotPose.y + c.v * 1.5 * Math.sin(heading + c.w * 0.8);
        const p1 = worldToCanvas(telemetry.robotPose.x, telemetry.robotPose.y);
        const p2 = worldToCanvas(endX, endY);
        ctx.strokeStyle = 'rgba(239, 68, 68, 0.25)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(p1.x, p1.y);
        ctx.lineTo(p2.x, p2.y);
        ctx.stroke();
      });

      // Ranked Feasible Candidates (green/blue arc)
      telemetry.rankedCandidates.forEach((c, idx) => {
        if (!c.points || c.points.length === 0) return;
        ctx.strokeStyle = idx === 0 ? 'rgba(56, 189, 248, 0.9)' : 'rgba(148, 163, 184, 0.25)';
        ctx.lineWidth = idx === 0 ? 3 : 1;
        ctx.beginPath();
        c.points.forEach((pt, pIdx) => {
          const cp = worldToCanvas(pt.x, pt.y);
          if (pIdx === 0) ctx.moveTo(cp.x, cp.y);
          else ctx.lineTo(cp.x, cp.y);
        });
        ctx.stroke();
      });
    }

    // 7. Draw Active Goal Waypoint
    if (telemetry.activeGoal) {
      const gPt = worldToCanvas(telemetry.activeGoal.x, telemetry.activeGoal.y);
      ctx.strokeStyle = '#10b981';
      ctx.fillStyle = 'rgba(16, 185, 129, 0.2)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(gPt.x, gPt.y, 8, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Pulsing Target Crosshair
      ctx.beginPath();
      ctx.moveTo(gPt.x - 12, gPt.y);
      ctx.lineTo(gPt.x + 12, gPt.y);
      ctx.moveTo(gPt.x, gPt.y - 12);
      ctx.lineTo(gPt.x, gPt.y + 12);
      ctx.stroke();

      ctx.fillStyle = '#10b981';
      ctx.font = '10px monospace font-bold';
      ctx.fillText('GOAL', gPt.x + 10, gPt.y - 10);
    }

    // 8. Draw Ground-Truth Robot vs EKF Estimated Robot
    // Ground-Truth Ghost (White dashed)
    const gt = worldToCanvas(telemetry.groundTruthPose.x, telemetry.groundTruthPose.y);
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
    ctx.lineWidth = 1;
    ctx.setLineDash([2, 2]);
    ctx.beginPath();
    ctx.arc(gt.x, gt.y, zoom * 0.35, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);

    // Estimated Robot Footprint (AMR Chassis + Wheels + Heading Arrow)
    const rPt = worldToCanvas(telemetry.robotPose.x, telemetry.robotPose.y);
    ctx.save();
    ctx.translate(rPt.x, rPt.y);
    ctx.rotate(-telemetry.robotPose.yaw); // Inverted Y rotation

    const robotL = zoom * 0.7; // length
    const robotW = zoom * 0.5; // width

    // Uncertainty Covariance Ellipse
    ctx.fillStyle = 'rgba(56, 189, 248, 0.15)';
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.5)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.ellipse(0, 0, zoom * 0.45, zoom * 0.45, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Chassis Body
    ctx.fillStyle = telemetry.safety.estopLatched ? '#e11d48' : '#0284c7';
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect(-robotL / 2, -robotW / 2, robotL, robotW, 4);
    ctx.fill();
    ctx.stroke();

    // Wheels (Differential Drive Left/Right)
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(-robotL * 0.3, -robotW / 2 - 3, robotL * 0.6, 3);
    ctx.fillRect(-robotL * 0.3, robotW / 2, robotL * 0.6, 3);

    // LiDAR Turret
    ctx.fillStyle = '#38bdf8';
    ctx.beginPath();
    ctx.arc(0, 0, 4, 0, Math.PI * 2);
    ctx.fill();

    // Heading Direction Arrow
    ctx.strokeStyle = '#f8fafc';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(robotL * 0.7, 0);
    ctx.lineTo(robotL * 0.5, -4);
    ctx.moveTo(robotL * 0.7, 0);
    ctx.lineTo(robotL * 0.5, 4);
    ctx.stroke();

    ctx.restore();
  }, [
    telemetry,
    zoom,
    panX,
    panY,
    showLidar,
    showCostmap,
    showGlobalPath,
    showCandidates,
    showTracks,
    showGeofence,
    worldEntities
  ]);

  // Mouse Handlers for Drag-to-Pan and Click-to-Set-Goal
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (e.button === 0) {
      setIsDragging(true);
      setDragStart({ x: e.clientX, y: e.clientY });
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (isDragging) {
      setFollowRobot(false);
      const dx = (e.clientX - dragStart.x) / zoom;
      const dy = -(e.clientY - dragStart.y) / zoom;
      setPanX((prev) => prev + dx);
      setPanY((prev) => prev + dy);
      setDragStart({ x: e.clientX, y: e.clientY });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const factor = e.deltaY < 0 ? 1.15 : 0.85;
    setZoom((prev) => Math.max(8, Math.min(80, prev * factor)));
  };

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (isDragging) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    const wx = (clickX - canvas.clientWidth / 2) / zoom - panX;
    const wy = -(clickY - canvas.clientHeight / 2) / zoom - panY;

    // Set new navigation goal
    onSetGoal(wx, wy);
  };

  return (
    <div id="map-visualizer-container" className="relative w-full h-full bg-slate-950 rounded-lg overflow-hidden border border-slate-800 shadow-inner flex flex-col">
      {/* Canvas Viewport */}
      <canvas
        ref={canvasRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onWheel={handleWheel}
        onClick={handleCanvasClick}
        className="w-full h-full cursor-crosshair block"
      />

      {/* Overlay: Top Controls Bar */}
      <div className="absolute top-3 left-3 bg-slate-900/90 backdrop-blur border border-slate-800 rounded-lg px-3 py-1.5 flex items-center space-x-2 text-xs text-slate-300 shadow-lg">
        <span className="font-semibold text-amber-400">MAP / 3D WORLD</span>
        <span className="text-slate-600">|</span>
        <button
          onClick={() => setFollowRobot(!followRobot)}
          className={`flex items-center gap-1 px-2 py-0.5 rounded font-mono text-[11px] ${
            followRobot ? 'bg-sky-600 text-white' : 'bg-slate-800 text-slate-400'
          }`}
        >
          <Navigation className="w-3 h-3" />
          <span>FOLLOW</span>
        </button>
        <span className="text-slate-500 font-mono text-[11px]">
          X:{telemetry.robotPose.x.toFixed(2)}m Y:{telemetry.robotPose.y.toFixed(2)}m θ:{(telemetry.robotPose.yaw * (180 / Math.PI)).toFixed(0)}°
        </span>
      </div>

      {/* Overlay: Layer Visibility Toggles */}
      <div className="absolute top-3 right-3 bg-slate-900/90 backdrop-blur border border-slate-800 rounded-lg p-2 flex flex-wrap gap-1.5 text-xs text-slate-300 shadow-lg max-w-md justify-end">
        <button
          onClick={() => setShowLidar(!showLidar)}
          className={`px-2 py-0.5 rounded text-[11px] font-mono ${
            showLidar ? 'bg-cyan-600 text-white' : 'bg-slate-800 text-slate-400'
          }`}
        >
          LiDAR ({telemetry.points.length})
        </button>
        <button
          onClick={() => setShowCostmap(!showCostmap)}
          className={`px-2 py-0.5 rounded text-[11px] font-mono ${
            showCostmap ? 'bg-amber-600 text-white' : 'bg-slate-800 text-slate-400'
          }`}
        >
          Costmap
        </button>
        <button
          onClick={() => setShowGlobalPath(!showGlobalPath)}
          className={`px-2 py-0.5 rounded text-[11px] font-mono ${
            showGlobalPath ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-400'
          }`}
        >
          A* Path
        </button>
        <button
          onClick={() => setShowCandidates(!showCandidates)}
          className={`px-2 py-0.5 rounded text-[11px] font-mono ${
            showCandidates ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400'
          }`}
        >
          Rollouts ({telemetry.rankedCandidates.length})
        </button>
        <button
          onClick={() => setShowGeofence(!showGeofence)}
          className={`px-2 py-0.5 rounded text-[11px] font-mono ${
            showGeofence ? 'bg-rose-600 text-white' : 'bg-slate-800 text-slate-400'
          }`}
        >
          Geofence
        </button>
      </div>

      {/* Overlay: Bottom Zoom & Reset */}
      <div className="absolute bottom-3 right-3 flex items-center space-x-1.5 bg-slate-900/90 backdrop-blur border border-slate-800 rounded-lg p-1 shadow-lg">
        <button
          onClick={() => setZoom((z) => Math.min(80, z * 1.2))}
          className="p-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded"
          title="Zoom In"
        >
          <ZoomIn className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={() => setZoom((z) => Math.max(8, z * 0.8))}
          className="p-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded"
          title="Zoom Out"
        >
          <ZoomOut className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={() => {
            setZoom(28);
            setPanX(-telemetry.robotPose.x);
            setPanY(-telemetry.robotPose.y);
            setFollowRobot(true);
          }}
          className="p-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded"
          title="Center on Robot"
        >
          <RotateCcw className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Bottom Hint */}
      <div className="absolute bottom-3 left-3 text-[11px] text-slate-400 bg-slate-950/80 px-2.5 py-1 rounded border border-slate-800 pointer-events-none">
        💡 Click on map to dispatch navigation goal • Drag to pan • Scroll to zoom
      </div>
    </div>
  );
};
