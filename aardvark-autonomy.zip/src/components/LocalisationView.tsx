import React from 'react';
import { TelemetrySnapshot } from '../types/autonomy';
import { Compass, Activity, Grid, CheckCircle2, AlertCircle } from 'lucide-react';

interface LocalisationViewProps {
  telemetry: TelemetrySnapshot;
}

export const LocalisationView: React.FC<LocalisationViewProps> = ({ telemetry }) => {
  const ekf = telemetry.ekf;
  const gt = telemetry.groundTruthPose;

  const errorX = Math.abs(ekf.x - gt.x);
  const errorY = Math.abs(ekf.y - gt.y);
  const errorYaw = Math.abs((ekf.yaw - gt.yaw) * (180 / Math.PI));

  return (
    <div id="localisation-view" className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-full overflow-y-auto p-1">
      {/* 15-State EKF Vector */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
          <div className="flex items-center space-x-2">
            <Compass className="w-4 h-4 text-sky-400" />
            <h3 className="text-sm font-semibold text-white">15-State Extended Kalman Filter (EKF)</h3>
          </div>
          <span className="text-[11px] font-mono text-sky-400 bg-sky-950/60 border border-sky-800 px-2 py-0.5 rounded">
            JOSEPH-FORM COVARIANCE
          </span>
        </div>

        {/* State Groups Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs font-mono">
          {/* Position */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <div className="text-slate-500 text-[10px] mb-1">POSITION [X, Y, Z]</div>
            <div className="text-slate-200">X: <span className="text-sky-400 font-bold">{ekf.x.toFixed(3)}</span>m</div>
            <div className="text-slate-200">Y: <span className="text-sky-400 font-bold">{ekf.y.toFixed(3)}</span>m</div>
            <div className="text-slate-200">Z: <span className="text-slate-400">{ekf.z.toFixed(3)}</span>m</div>
          </div>

          {/* Velocity */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <div className="text-slate-500 text-[10px] mb-1">VELOCITY [Vx, Vy, Vz]</div>
            <div className="text-slate-200">Vx: <span className="text-emerald-400 font-bold">{ekf.vx.toFixed(3)}</span>m/s</div>
            <div className="text-slate-200">Vy: <span className="text-slate-400">{ekf.vy.toFixed(3)}</span>m/s</div>
            <div className="text-slate-200">Vz: <span className="text-slate-400">{ekf.vz.toFixed(3)}</span>m/s</div>
          </div>

          {/* Orientation */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <div className="text-slate-500 text-[10px] mb-1">ATTITUDE [R, P, Y]</div>
            <div className="text-slate-200">Roll: <span className="text-slate-400">{ekf.roll.toFixed(3)}</span>rad</div>
            <div className="text-slate-200">Pitch: <span className="text-slate-400">{ekf.pitch.toFixed(3)}</span>rad</div>
            <div className="text-slate-200">Yaw: <span className="text-amber-400 font-bold">{(ekf.yaw * (180 / Math.PI)).toFixed(1)}</span>°</div>
          </div>

          {/* Accel Bias */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <div className="text-slate-500 text-[10px] mb-1">ACCEL BIAS [b_ax, b_ay, b_az]</div>
            <div className="text-slate-300">b_ax: {ekf.bax.toFixed(4)}</div>
            <div className="text-slate-300">b_ay: {ekf.bay.toFixed(4)}</div>
            <div className="text-slate-300">b_az: {ekf.baz.toFixed(4)}</div>
          </div>

          {/* Gyro Bias */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <div className="text-slate-500 text-[10px] mb-1">GYRO BIAS [b_gx, b_gy, b_gz]</div>
            <div className="text-slate-300">b_gx: {ekf.bgx.toFixed(4)}</div>
            <div className="text-slate-300">b_gy: {ekf.bgy.toFixed(4)}</div>
            <div className="text-slate-300">b_gz: {ekf.bgz.toFixed(4)}</div>
          </div>

          {/* Localisation Error */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <div className="text-slate-500 text-[10px] mb-1">ESTIMATION ERROR</div>
            <div className="text-slate-200">ΔPos: <span className="text-emerald-400 font-bold">{Math.hypot(errorX, errorY).toFixed(3)}</span>m</div>
            <div className="text-slate-200">ΔYaw: <span className="text-emerald-400 font-bold">{errorYaw.toFixed(2)}</span>°</div>
            <div className="text-slate-400 text-[10px] mt-1">STATUS: {telemetry.locQuality}</div>
          </div>
        </div>

        {/* State Comparison Table */}
        <div className="mt-4 pt-3 border-t border-slate-800">
          <h4 className="text-xs font-semibold text-slate-300 mb-2">Ground-Truth vs Fused Estimate Comparison</h4>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-500 text-[10px]">
                  <th className="pb-1.5">METRIC</th>
                  <th className="pb-1.5">GROUND TRUTH</th>
                  <th className="pb-1.5">EKF FUSED</th>
                  <th className="pb-1.5">ERROR</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                <tr>
                  <td className="py-1.5 text-slate-400">Position X</td>
                  <td className="py-1.5">{gt.x.toFixed(3)}m</td>
                  <td className="py-1.5 text-sky-400">{ekf.x.toFixed(3)}m</td>
                  <td className="py-1.5 text-emerald-400">{errorX.toFixed(3)}m</td>
                </tr>
                <tr>
                  <td className="py-1.5 text-slate-400">Position Y</td>
                  <td className="py-1.5">{gt.y.toFixed(3)}m</td>
                  <td className="py-1.5 text-sky-400">{ekf.y.toFixed(3)}m</td>
                  <td className="py-1.5 text-emerald-400">{errorY.toFixed(3)}m</td>
                </tr>
                <tr>
                  <td className="py-1.5 text-slate-400">Heading Yaw</td>
                  <td className="py-1.5">{(gt.yaw * (180 / Math.PI)).toFixed(2)}°</td>
                  <td className="py-1.5 text-amber-400">{(ekf.yaw * (180 / Math.PI)).toFixed(2)}°</td>
                  <td className="py-1.5 text-emerald-400">{errorYaw.toFixed(2)}°</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* 15x15 Covariance Heatmap Visualizer */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
          <div className="flex items-center space-x-2">
            <Grid className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-semibold text-white">15×15 State Covariance Matrix $P$</h3>
          </div>
          <span className="text-[11px] font-mono text-amber-400 bg-amber-950/60 border border-amber-800 px-2 py-0.5 rounded">
            TRACE = 0.084
          </span>
        </div>

        {/* Heatmap Grid */}
        <div className="flex-1 flex flex-col items-center justify-center p-2 bg-slate-950 rounded border border-slate-800">
          <div className="grid grid-cols-15 gap-0.5 w-full max-w-[320px] aspect-square">
            {ekf.covMatrix.map((row, r) =>
              row.map((val, c) => {
                const isDiag = r === c;
                const intensity = isDiag ? Math.min(1.0, val * 15) : Math.min(0.8, Math.abs(val) * 30);
                return (
                  <div
                    key={`${r}-${c}`}
                    className="rounded-[1px] transition-colors"
                    style={{
                      backgroundColor: isDiag
                        ? `rgba(56, 189, 248, ${Math.max(0.2, intensity)})`
                        : `rgba(245, 158, 11, ${intensity})`
                    }}
                    title={`P[${r},${c}] = ${val.toFixed(5)}`}
                  />
                );
              })
            )}
          </div>
          <div className="flex items-center justify-between w-full max-w-[320px] mt-2 text-[10px] font-mono text-slate-500">
            <span>[0] POS_X</span>
            <span className="text-sky-400 font-bold">DIAGONAL (VARIANCE)</span>
            <span>[14] BIAS_GZ</span>
          </div>
        </div>

        <div className="mt-3 text-[11px] text-slate-400 font-mono">
          ✓ Positive Semi-Definiteness enforced via Joseph Form: $P = (I - KH)P(I - KH)^T + KRK^T$
        </div>
      </div>
    </div>
  );
};
