import React from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  AlertOctagon,
  ShieldCheck,
  ShieldAlert,
  Compass,
  Cpu,
  CheckCircle2,
  AlertTriangle,
  Flame
} from 'lucide-react';
import { TelemetrySnapshot } from '../types/autonomy';
import { SCENARIOS } from '../simulation/scenarios';

interface HeaderProps {
  telemetry: TelemetrySnapshot;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onStep: () => void;
  onReset: () => void;
  onToggleEstop: () => void;
  selectedScenario: string;
  onSelectScenario: (id: string) => void;
  speed: number;
  onChangeSpeed: (s: number) => void;
}

export const Header: React.FC<HeaderProps> = ({
  telemetry,
  isPlaying,
  onTogglePlay,
  onStep,
  onReset,
  onToggleEstop,
  selectedScenario,
  onSelectScenario,
  speed,
  onChangeSpeed
}) => {
  const isEstop = telemetry.safety.estopLatched;

  return (
    <header id="app-header" className="bg-slate-900 border-b border-slate-800 text-slate-100 px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 shadow-md select-none">
      {/* Brand & Identity */}
      <div className="flex items-center space-x-3">
        <div className="bg-amber-500/20 border border-amber-500/40 p-1.5 rounded-lg flex items-center justify-center">
          <Flame className="w-5 h-5 text-amber-400" />
        </div>
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-base font-bold tracking-tight text-white flex items-center gap-1.5">
              AARDVARK <span className="text-amber-400 font-semibold">AUTONOMY</span>
            </h1>
            <span className="text-[10px] font-mono uppercase bg-slate-800 border border-slate-700 text-slate-300 px-1.5 py-0.5 rounded">
              v0.1.0-PROD
            </span>
          </div>
          <p className="text-xs text-slate-400">Multi-Modal Perception, Mapping, Planning & Control</p>
        </div>
      </div>

      {/* Scenario Selector & Sim Controls */}
      <div className="flex items-center space-x-2 bg-slate-950/70 border border-slate-800 p-1 rounded-lg">
        <select
          id="scenario-select"
          value={selectedScenario}
          onChange={(e) => onSelectScenario(e.target.value)}
          className="bg-slate-900 text-xs text-slate-200 border border-slate-700 rounded px-2.5 py-1.5 focus:outline-none focus:border-amber-400 font-mono"
        >
          {Object.values(SCENARIOS).map((sc) => (
            <option key={sc.id} value={sc.id}>
              {sc.name}
            </option>
          ))}
        </select>

        {/* Play/Pause */}
        <button
          id="btn-play-pause"
          onClick={onTogglePlay}
          className={`flex items-center gap-1 px-3 py-1.5 rounded text-xs font-semibold transition ${
            isPlaying
              ? 'bg-amber-600 hover:bg-amber-500 text-white'
              : 'bg-emerald-600 hover:bg-emerald-500 text-white'
          }`}
        >
          {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
          <span>{isPlaying ? 'PAUSE' : 'RUN'}</span>
        </button>

        {/* Step */}
        <button
          id="btn-sim-step"
          onClick={onStep}
          disabled={isPlaying}
          className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 rounded text-xs font-mono"
          title="Single Step (50ms)"
        >
          STEP
        </button>

        {/* Reset */}
        <button
          id="btn-sim-reset"
          onClick={onReset}
          className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded"
          title="Reset Simulation"
        >
          <RotateCcw className="w-3.5 h-3.5" />
        </button>

        {/* Speed Multiplier */}
        <div className="flex items-center space-x-1 pl-1 border-l border-slate-800">
          {[1, 2, 5].map((s) => (
            <button
              key={s}
              onClick={() => onChangeSpeed(s)}
              className={`px-1.5 py-0.5 text-[11px] font-mono rounded ${
                speed === s ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {s}x
            </button>
          ))}
        </div>
      </div>

      {/* Live Status Indicators */}
      <div className="flex items-center space-x-3 text-xs">
        {/* Autonomy State */}
        <div className="flex items-center space-x-1.5 bg-slate-950/80 border border-slate-800 px-2.5 py-1 rounded">
          <span className="text-slate-400 text-[11px]">STATE:</span>
          <span
            className={`font-mono font-semibold ${
              isEstop
                ? 'text-rose-400 animate-pulse'
                : telemetry.autonomyState === 'AUTONOMOUS'
                ? 'text-emerald-400'
                : 'text-amber-400'
            }`}
          >
            {telemetry.autonomyState}
          </span>
        </div>

        {/* Localisation Quality */}
        <div className="flex items-center space-x-1.5 bg-slate-950/80 border border-slate-800 px-2.5 py-1 rounded">
          <Compass className="w-3.5 h-3.5 text-sky-400" />
          <span className="text-slate-400 text-[11px]">EKF:</span>
          <span
            className={`font-mono font-semibold ${
              telemetry.locQuality === 'GOOD'
                ? 'text-emerald-400'
                : telemetry.locQuality === 'DEGRADED'
                ? 'text-amber-400'
                : 'text-rose-400'
            }`}
          >
            {telemetry.locQuality}
          </span>
        </div>

        {/* Safety Supervisor */}
        <div className="flex items-center space-x-1.5 bg-slate-950/80 border border-slate-800 px-2.5 py-1 rounded">
          {telemetry.safety.approved ? (
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          ) : (
            <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
          )}
          <span className="text-slate-400 text-[11px]">SAFETY:</span>
          <span
            className={`font-mono font-semibold ${
              telemetry.safety.approved ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {telemetry.safety.state}
          </span>
        </div>

        {/* Sim Time & Progress */}
        <div className="flex items-center space-x-2 bg-slate-950/80 border border-slate-800 px-2.5 py-1 rounded">
          <span className="text-slate-400 font-mono text-[11px]">T={telemetry.simTime.toFixed(1)}s</span>
          <div className="w-16 bg-slate-800 h-2 rounded-full overflow-hidden">
            <div
              className={`h-full ${telemetry.missionStatus === 'COMPLETED' ? 'bg-emerald-500' : 'bg-amber-500'}`}
              style={{ width: `${telemetry.progressPercent}%` }}
            />
          </div>
          <span className="font-mono text-[11px] text-slate-300">{telemetry.progressPercent.toFixed(0)}%</span>
        </div>

        {/* EMERGENCY STOP BUTTON */}
        <button
          id="btn-emergency-stop"
          onClick={onToggleEstop}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition shadow-lg ${
            isEstop
              ? 'bg-rose-700 hover:bg-rose-600 text-white animate-bounce'
              : 'bg-rose-600 hover:bg-rose-500 text-white'
          }`}
        >
          <AlertOctagon className="w-4 h-4" />
          <span>{isEstop ? 'RESET E-STOP' : 'E-STOP'}</span>
        </button>
      </div>
    </header>
  );
};
