import React from 'react';
import { BookOpen, Layers, Terminal, Database, Code, CheckCircle } from 'lucide-react';

export const ArchitectureDocsView: React.FC = () => {
  return (
    <div id="architecture-docs-view" className="h-full overflow-y-auto p-4 space-y-6 text-slate-200">
      {/* Overview Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <div className="flex items-center space-x-2 text-amber-400 mb-2">
          <BookOpen className="w-5 h-5" />
          <h2 className="text-base font-bold text-white tracking-wide">AARDVARK AUTONOMY ARCHITECTURE SPECIFICATION</h2>
        </div>
        <p className="text-xs text-slate-300 leading-relaxed">
          Aardvark Autonomy is a simulation-first autonomous robotics perception, mapping, planning, and control platform built on deterministic multi-rate pipelines.
        </p>
        <div className="mt-4 p-3 bg-slate-950 border border-slate-800 rounded font-mono text-xs text-amber-300">
          SENSORS → PERCEPTION → LOCALISATION → WORLD MODEL → MAPPING → PREDICTION → PLANNING → BEHAVIOUR → CONTROL → ROBOT STATE
        </div>
      </div>

      {/* 2-Column Grid: ROS 2 Topics & Canonical Schemas */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* ROS 2 Interface Mappings */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono text-xs">
          <div className="flex items-center space-x-2 text-sky-400 mb-3 font-bold">
            <Terminal className="w-4 h-4" />
            <h3 className="text-white">ROS 2 DDS Topic Mappings</h3>
          </div>
          <div className="space-y-2 text-[11px]">
            <div className="p-2 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-400 block font-semibold">/sensors/lidar/points</span>
              <span className="text-sky-300 font-mono">sensor_msgs/msg/PointCloud2</span>
            </div>
            <div className="p-2 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-400 block font-semibold">/localisation/odometry</span>
              <span className="text-sky-300 font-mono">nav_msgs/msg/Odometry</span>
            </div>
            <div className="p-2 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-400 block font-semibold">/planning/global_plan</span>
              <span className="text-sky-300 font-mono">nav_msgs/msg/Path</span>
            </div>
            <div className="p-2 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-400 block font-semibold">/control/cmd_vel</span>
              <span className="text-sky-300 font-mono">geometry_msgs/msg/TwistStamped</span>
            </div>
            <div className="p-2 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-400 block font-semibold">/safety/supervisor_state</span>
              <span className="text-rose-400 font-mono">aardvark_msgs/msg/SafetyDecision</span>
            </div>
          </div>
        </div>

        {/* Core Mathematical Invariants */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono text-xs">
          <div className="flex items-center space-x-2 text-emerald-400 mb-3 font-bold">
            <Code className="w-4 h-4" />
            <h3 className="text-white">Core Mathematical Invariants</h3>
          </div>
          <div className="space-y-2 text-[11px]">
            <div className="p-2 bg-slate-950 rounded border border-slate-800">
              <span className="text-emerald-400 font-bold block">1. Joseph-Form EKF Covariance:</span>
              <span className="text-slate-300">P = (I - KH)P(I - KH)ᵀ + KRKᵀ</span>
            </div>
            <div className="p-2 bg-slate-950 rounded border border-slate-800">
              <span className="text-emerald-400 font-bold block">2. Log-Odds Bayesian Mapping:</span>
              <span className="text-slate-300">L(m|z₁:ₜ) = L(m|z₁:ₜ₋₁) + log(P/(1-P))</span>
            </div>
            <div className="p-2 bg-slate-950 rounded border border-slate-800">
              <span className="text-emerald-400 font-bold block">3. Pure Pursuit Arc Steering:</span>
              <span className="text-slate-300">κ = 2·sin(α) / L, where L = clamp(Lₘᵢₙ, Lₘₐₓ, k·v)</span>
            </div>
            <div className="p-2 bg-slate-950 rounded border border-slate-800">
              <span className="text-emerald-400 font-bold block">4. Multi-Objective Scoring:</span>
              <span className="text-slate-300">J = w_goal·J_goal + w_obs·J_obs + w_smooth·J_smooth</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
