import React, { useState } from 'react';
import { TelemetrySnapshot } from '../types/autonomy';
import { GitFork, Flag, Target, Play, Pause, RotateCcw, CheckCircle2, ChevronDown, ChevronRight } from 'lucide-react';

interface BehaviorMissionViewProps {
  telemetry: TelemetrySnapshot;
  onSetGoal: (x: number, y: number) => void;
  onResetMission: () => void;
}

export const BehaviorMissionView: React.FC<BehaviorMissionViewProps> = ({
  telemetry,
  onSetGoal,
  onResetMission
}) => {
  const [customX, setCustomX] = useState<string>('5.0');
  const [customY, setCustomY] = useState<string>('5.0');

  const handleDispatchCustomGoal = (e: React.FormEvent) => {
    e.preventDefault();
    const gx = parseFloat(customX);
    const gy = parseFloat(customY);
    if (!isNaN(gx) && !isNaN(gy)) {
      onSetGoal(gx, gy);
    }
  };

  return (
    <div id="behavior-mission-view" className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-full overflow-y-auto p-1">
      {/* Behaviour Tree Execution State */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
          <div className="flex items-center space-x-2">
            <GitFork className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-semibold text-white">Hierarchical Behaviour Tree</h3>
          </div>
          <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-2 py-0.5 rounded">
            STATUS: RUNNING
          </span>
        </div>

        {/* Interactive Tree View */}
        <div className="flex-1 space-y-2 font-mono text-xs">
          {/* Root Selector */}
          <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
            <div className="flex items-center space-x-2 text-sky-400 font-bold">
              <span>? Selector: RootExecutive</span>
              <span className="text-emerald-400 text-[10px] bg-emerald-950 px-1.5 py-0.2 rounded">
                RUNNING
              </span>
            </div>

            {/* Child Branch 1: Obstacle Avoidance */}
            <div className="ml-5 mt-2 border-l border-slate-800 pl-3 space-y-1.5">
              <div className="flex items-center justify-between text-slate-300">
                <span>→ Sequence: DynamicObstacleAvoidance</span>
                <span className={`text-[10px] px-1.5 rounded ${telemetry.tracks.length > 0 ? 'bg-amber-950 text-amber-400' : 'bg-slate-900 text-slate-500'}`}>
                  {telemetry.tracks.length > 0 ? 'RUNNING' : 'IDLE'}
                </span>
              </div>
              <div className="ml-4 text-[11px] text-slate-400 space-y-1">
                <div className="flex items-center justify-between">
                  <span>• CheckObstacleAhead (d &lt; 1.2m)</span>
                  <span className={telemetry.tracks.length > 0 ? 'text-emerald-400' : 'text-slate-500'}>
                    {telemetry.tracks.length > 0 ? 'TRUE' : 'FALSE'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span>• TriggerLocalDWAReplanAction</span>
                  <span className={telemetry.tracks.length > 0 ? 'text-amber-400' : 'text-slate-500'}>
                    {telemetry.tracks.length > 0 ? 'ACTIVE' : 'IDLE'}
                  </span>
                </div>
              </div>
            </div>

            {/* Child Branch 2: Standard Navigation */}
            <div className="ml-5 mt-2 border-l border-slate-800 pl-3 space-y-1.5">
              <div className="flex items-center justify-between text-slate-300">
                <span>→ Sequence: StandardNavigation</span>
                <span className="text-emerald-400 text-[10px] bg-emerald-950 px-1.5 rounded">
                  RUNNING
                </span>
              </div>
              <div className="ml-4 text-[11px] text-slate-400 space-y-1">
                <div className="flex items-center justify-between">
                  <span>• CheckLocalisationQuality (EKF)</span>
                  <span className="text-emerald-400">GOOD</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>• PurePursuitArcFollower</span>
                  <span className="text-emerald-400">RUNNING</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-3 text-[11px] text-slate-400 font-mono">
          ✓ Behavior Tree ticked at 20Hz synchronously in main simulation cycle.
        </div>
      </div>

      {/* Mission Lifecycle & Goal Dispatcher */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
          <div className="flex items-center space-x-2">
            <Flag className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-semibold text-white">Mission Lifecycle & Target Dispatch</h3>
          </div>
          <span className="text-[11px] font-mono text-amber-400 bg-amber-950/60 border border-amber-800 px-2 py-0.5 rounded">
            {telemetry.missionStatus}
          </span>
        </div>

        {/* Current Mission Meta */}
        <div className="bg-slate-950 p-3 rounded border border-slate-800 text-xs font-mono mb-4 space-y-2">
          <div className="flex justify-between text-slate-300">
            <span>MISSION ID:</span>
            <span className="text-amber-400 font-bold">msn_0001</span>
          </div>
          <div className="flex justify-between text-slate-300">
            <span>ROBOT ASSIGNED:</span>
            <span className="text-sky-400">robot-alpha-01</span>
          </div>
          <div className="flex justify-between text-slate-300">
            <span>TARGET POSITION:</span>
            <span className="text-emerald-400 font-bold">
              ({telemetry.activeGoal?.x.toFixed(2)}, {telemetry.activeGoal?.y.toFixed(2)})m
            </span>
          </div>
          <div className="flex justify-between text-slate-300">
            <span>GOAL TOLERANCE:</span>
            <span className="text-slate-400">0.35m</span>
          </div>

          {/* Progress Bar */}
          <div className="pt-2">
            <div className="flex justify-between text-[10px] text-slate-400 mb-1">
              <span>WAYPOINT PROGRESS</span>
              <span>{telemetry.progressPercent.toFixed(1)}%</span>
            </div>
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div
                className={`h-full ${telemetry.missionStatus === 'COMPLETED' ? 'bg-emerald-500' : 'bg-amber-500'}`}
                style={{ width: `${telemetry.progressPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Dispatch Custom Goal Form */}
        <form onSubmit={handleDispatchCustomGoal} className="bg-slate-950/80 p-3 rounded border border-slate-800">
          <h4 className="text-xs font-semibold text-slate-200 mb-2">Dispatch New Waypoint Target</h4>
          <div className="grid grid-cols-2 gap-2 text-xs font-mono mb-3">
            <div>
              <label className="text-slate-400 text-[10px] block mb-1">TARGET X (meters)</label>
              <input
                type="number"
                step="0.5"
                value={customX}
                onChange={(e) => setCustomX(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-amber-400"
              />
            </div>
            <div>
              <label className="text-slate-400 text-[10px] block mb-1">TARGET Y (meters)</label>
              <input
                type="number"
                step="0.5"
                value={customY}
                onChange={(e) => setCustomY(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <button
              type="submit"
              className="flex-1 bg-amber-600 hover:bg-amber-500 text-white font-semibold py-1.5 px-3 rounded text-xs transition"
            >
              DISPATCH TARGET
            </button>
            <button
              type="button"
              onClick={onResetMission}
              className="bg-slate-800 hover:bg-slate-700 text-slate-300 py-1.5 px-3 rounded text-xs"
            >
              RESET
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
