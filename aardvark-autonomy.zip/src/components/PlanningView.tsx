import React from 'react';
import { TelemetrySnapshot } from '../types/autonomy';
import { Route, Zap, CheckCircle, XCircle, ChevronRight, HelpCircle } from 'lucide-react';

interface PlanningViewProps {
  telemetry: TelemetrySnapshot;
}

export const PlanningView: React.FC<PlanningViewProps> = ({ telemetry }) => {
  return (
    <div id="planning-view" className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-full overflow-y-auto p-1">
      {/* Global A* Path Waypoints */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
          <div className="flex items-center space-x-2">
            <Route className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-semibold text-white">Global A* Path Plan</h3>
          </div>
          <span className="text-[11px] font-mono text-amber-400 bg-amber-950/60 border border-amber-800 px-2 py-0.5 rounded">
            {telemetry.globalPath?.length || 0} WAYPOINTS • LATENCY: 8.4ms
          </span>
        </div>

        {/* Waypoints Sequence List */}
        <div className="flex-1 overflow-y-auto max-h-[360px] space-y-2 pr-1">
          {telemetry.globalPath?.map((wp, idx) => (
            <div
              key={wp.id}
              className="flex items-center justify-between p-2.5 bg-slate-950/70 border border-slate-800/80 rounded text-xs font-mono"
            >
              <div className="flex items-center space-x-2">
                <span className="w-5 h-5 flex items-center justify-center bg-amber-500/20 text-amber-400 font-bold rounded-full text-[10px]">
                  {idx + 1}
                </span>
                <div>
                  <span className="text-slate-200 font-semibold">{wp.id}</span>
                  <span className="text-slate-400 text-[11px] ml-2">
                    ({wp.x.toFixed(2)}, {wp.y.toFixed(2)})m
                  </span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-emerald-400">{wp.speed.toFixed(1)} m/s</span>
                <span className="text-slate-500 text-[10px] block">θ: {(wp.yaw * (180 / Math.PI)).toFixed(0)}°</span>
              </div>
            </div>
          ))}

          {(!telemetry.globalPath || telemetry.globalPath.length === 0) && (
            <div className="p-8 text-center text-xs text-slate-500 font-mono">
              No active global plan. Click anywhere on the map to dispatch a goal.
            </div>
          )}
        </div>

        {/* Global Cost Summary */}
        <div className="mt-3 pt-3 border-t border-slate-800 flex items-center justify-between text-xs font-mono text-slate-400">
          <span>PLANNER: 8-Connected A* with Turn Cost</span>
          <span className="text-amber-400">HEURISTIC: Euclidean</span>
        </div>
      </div>

      {/* Explainable Trajectory Rollout Evaluation */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
          <div className="flex items-center space-x-2">
            <Zap className="w-4 h-4 text-sky-400" />
            <h3 className="text-sm font-semibold text-white">Explainable Trajectory Rollout Ranking</h3>
          </div>
          <span className="text-[11px] font-mono text-sky-400 bg-sky-950/60 border border-sky-800 px-2 py-0.5 rounded">
            DYNAMIC WINDOW (DWA)
          </span>
        </div>

        {/* Candidate Ranking Table */}
        <div className="flex-1 overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[10px]">
                <th className="pb-2">RANK</th>
                <th className="pb-2">V (m/s)</th>
                <th className="pb-2">ω (rad/s)</th>
                <th className="pb-2">TOTAL SCORE</th>
                <th className="pb-2">STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {telemetry.rankedCandidates.slice(0, 5).map((c, i) => (
                <tr key={i} className={i === 0 ? 'bg-sky-500/10 font-semibold' : 'hover:bg-slate-800/40'}>
                  <td className="py-2">
                    {i === 0 ? (
                      <span className="text-emerald-400 font-bold">#1 [SELECTED]</span>
                    ) : (
                      <span className="text-slate-500">#{i + 1}</span>
                    )}
                  </td>
                  <td className="py-2 text-slate-200">{c.v.toFixed(2)}</td>
                  <td className="py-2 text-slate-200">{c.w.toFixed(2)}</td>
                  <td className="py-2 text-sky-400 font-bold">{c.score.toFixed(2)}</td>
                  <td className="py-2">
                    <span className="text-emerald-400 text-[10px] flex items-center gap-1">
                      <CheckCircle className="w-3 h-3" /> FEASIBLE
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Rejected Candidates with Explicit Reasons (Explainability) */}
          <div className="mt-4 pt-3 border-t border-slate-800">
            <h4 className="text-xs font-semibold text-rose-400 mb-2 flex items-center gap-1">
              <XCircle className="w-3.5 h-3.5" /> Rejected Candidate Trajectories & Explanations
            </h4>
            <div className="space-y-1.5 max-h-36 overflow-y-auto">
              {telemetry.rejectedCandidates.map((r, i) => (
                <div key={i} className="p-2 bg-rose-950/20 border border-rose-900/40 rounded text-[11px] font-mono flex items-start justify-between">
                  <span className="text-slate-300 font-semibold">
                    (v={r.v.toFixed(1)}, ω={r.w.toFixed(1)})
                  </span>
                  <span className="text-rose-400 text-right">{r.reason}</span>
                </div>
              ))}
              {telemetry.rejectedCandidates.length === 0 && (
                <div className="text-slate-500 text-xs font-mono py-2">
                  All candidate rollouts evaluated as safe.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
