import React from 'react';
import { TelemetrySnapshot } from '../types/autonomy';
import { ShieldCheck, ShieldAlert, AlertOctagon, Bug, Radio, Shield, List, Lock } from 'lucide-react';

interface SafetyViewProps {
  telemetry: TelemetrySnapshot;
  faultGPS: boolean;
  faultLidar: boolean;
  faultCamera: boolean;
  faultSlip: boolean;
  onToggleFault: (fault: 'GPS' | 'LIDAR' | 'CAMERA' | 'SLIP') => void;
  onToggleEstop: () => void;
}

export const SafetyView: React.FC<SafetyViewProps> = ({
  telemetry,
  faultGPS,
  faultLidar,
  faultCamera,
  faultSlip,
  onToggleFault,
  onToggleEstop
}) => {
  const safety = telemetry.safety;

  return (
    <div id="safety-view" className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-full overflow-y-auto p-1">
      {/* Safety Supervisor Real-Time State */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
          <div className="flex items-center space-x-2">
            <Shield className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-semibold text-white">Independent Safety Supervisor</h3>
          </div>
          <span
            className={`text-[11px] font-mono font-bold px-2 py-0.5 rounded border ${
              safety.approved
                ? 'text-emerald-400 bg-emerald-950/60 border-emerald-800'
                : 'text-rose-400 bg-rose-950/60 border-rose-800 animate-pulse'
            }`}
          >
            {safety.state}
          </span>
        </div>

        {/* Dynamic Metric Tiles */}
        <div className="grid grid-cols-2 gap-3 text-xs font-mono mb-4">
          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-500 text-[10px] block">MIN OBSTACLE DIST</span>
            <span
              className={`text-base font-bold ${
                safety.minObstacleDist < 0.6 ? 'text-rose-400' : 'text-emerald-400'
              }`}
            >
              {safety.minObstacleDist.toFixed(2)}m
            </span>
            <span className="text-slate-500 text-[10px] block mt-0.5">Threshold: 0.35m</span>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-slate-500 text-[10px] block">TIME-TO-COLLISION (TTC)</span>
            <span
              className={`text-base font-bold ${
                safety.ttc < 1.0 ? 'text-rose-400' : 'text-emerald-400'
              }`}
            >
              {safety.ttc.toFixed(2)}s
            </span>
            <span className="text-slate-500 text-[10px] block mt-0.5">Critical TTC: 0.60s</span>
          </div>
        </div>

        {/* Dynamic Constraint Bounds */}
        <div className="space-y-2 text-xs font-mono bg-slate-950/80 p-3 rounded border border-slate-800">
          <div className="text-slate-400 font-semibold mb-1 text-[11px]">DETERMINISTIC SAFETY LIMITS</div>
          <div className="flex justify-between text-slate-300">
            <span>MAX LINEAR SPEED:</span>
            <span className="text-sky-400 font-bold">1.50 m/s</span>
          </div>
          <div className="flex justify-between text-slate-300">
            <span>MAX ACCELERATION:</span>
            <span className="text-sky-400 font-bold">1.20 m/s²</span>
          </div>
          <div className="flex justify-between text-slate-300">
            <span>MAX PATH CURVATURE κ:</span>
            <span className="text-sky-400 font-bold">3.50 m⁻¹</span>
          </div>
          <div className="flex justify-between text-slate-300">
            <span>GEOFENCE PERIMETER:</span>
            <span className="text-sky-400 font-bold">[-19m, +19m]</span>
          </div>
        </div>

        {/* Fault Injection Control Box */}
        <div className="mt-4 pt-3 border-t border-slate-800">
          <div className="flex items-center space-x-2 mb-2">
            <Bug className="w-3.5 h-3.5 text-amber-400" />
            <h4 className="text-xs font-semibold text-slate-200">Fault Injection Testing Workbench</h4>
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs font-mono">
            <button
              onClick={() => onToggleFault('GPS')}
              className={`p-2 rounded border text-left flex items-center justify-between ${
                faultGPS ? 'bg-rose-950/60 border-rose-700 text-rose-300' : 'bg-slate-950 border-slate-800 text-slate-400'
              }`}
            >
              <span>GPS OUTAGE</span>
              <span className="font-bold">{faultGPS ? 'ACTIVE' : 'OFF'}</span>
            </button>

            <button
              onClick={() => onToggleFault('LIDAR')}
              className={`p-2 rounded border text-left flex items-center justify-between ${
                faultLidar ? 'bg-rose-950/60 border-rose-700 text-rose-300' : 'bg-slate-950 border-slate-800 text-slate-400'
              }`}
            >
              <span>LIDAR DROPOUT</span>
              <span className="font-bold">{faultLidar ? 'ACTIVE' : 'OFF'}</span>
            </button>

            <button
              onClick={() => onToggleFault('CAMERA')}
              className={`p-2 rounded border text-left flex items-center justify-between ${
                faultCamera ? 'bg-rose-950/60 border-rose-700 text-rose-300' : 'bg-slate-950 border-slate-800 text-slate-400'
              }`}
            >
              <span>CAMERA FAULT</span>
              <span className="font-bold">{faultCamera ? 'ACTIVE' : 'OFF'}</span>
            </button>

            <button
              onClick={() => onToggleFault('SLIP')}
              className={`p-2 rounded border text-left flex items-center justify-between ${
                faultSlip ? 'bg-rose-950/60 border-rose-700 text-rose-300' : 'bg-slate-950 border-slate-800 text-slate-400'
              }`}
            >
              <span>WHEEL SLIP 35%</span>
              <span className="font-bold">{faultSlip ? 'ACTIVE' : 'OFF'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Safety Audit Log Stream */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
          <div className="flex items-center space-x-2">
            <List className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-semibold text-white">Immutable Audit Event Stream</h3>
          </div>
          <span className="text-[11px] font-mono text-slate-400">
            {telemetry.auditLogs.length} EVENTS RECORDED
          </span>
        </div>

        {/* Audit Log Stream */}
        <div className="flex-1 overflow-y-auto space-y-2 max-h-[400px] pr-1 font-mono text-xs">
          {telemetry.auditLogs.map((log) => (
            <div
              key={log.id}
              className={`p-2 rounded border ${
                log.severity === 'CRITICAL'
                  ? 'bg-rose-950/30 border-rose-800 text-rose-200'
                  : log.severity === 'WARN'
                  ? 'bg-amber-950/30 border-amber-800 text-amber-200'
                  : 'bg-slate-950/70 border-slate-800 text-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-[11px] text-amber-400">{log.event}</span>
                <span className="text-slate-500 text-[10px]">{log.time}</span>
              </div>
              <p className="text-[11px] text-slate-400">{log.details}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
