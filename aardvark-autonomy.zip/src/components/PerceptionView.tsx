import React from 'react';
import { TelemetrySnapshot, WorldEntity } from '../types/autonomy';
import { Camera, Radio, Eye, Scan, Target, CheckCircle, Clock } from 'lucide-react';

interface PerceptionViewProps {
  telemetry: TelemetrySnapshot;
  worldEntities: WorldEntity[];
}

export const PerceptionView: React.FC<PerceptionViewProps> = ({ telemetry, worldEntities }) => {
  return (
    <div id="perception-view" className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-full overflow-y-auto p-1">
      {/* Synthetic RGB-D Camera View */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
          <div className="flex items-center space-x-2">
            <Camera className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-semibold text-white">Forward Synthetic RGB-D Camera</h3>
          </div>
          <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-2 py-0.5 rounded">
            30 FPS • 1280x720 • FOV 85°
          </span>
        </div>

        {/* Camera Simulated Viewport */}
        <div className="relative flex-1 min-h-[240px] bg-slate-950 rounded border border-slate-800 overflow-hidden flex items-center justify-center">
          {/* Simulated Horizon & Floor Grid */}
          <div className="absolute inset-0 bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 opacity-80" />

          {/* Depth Grid Lines */}
          <div className="absolute inset-x-0 bottom-0 h-32 border-t border-slate-800 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:2rem_1rem] opacity-30" />

          {/* Bounding Box Overlays for Visible Objects in FOV */}
          <div className="absolute inset-0 p-4 flex items-center justify-center space-x-8">
            {telemetry.tracks.map((trk, i) => {
              const relX = trk.x - telemetry.robotPose.x;
              const relY = trk.y - telemetry.robotPose.y;
              const dist = Math.hypot(relX, relY);

              return (
                <div
                  key={trk.id}
                  className="border-2 border-emerald-400 bg-emerald-500/10 rounded px-3 py-2 flex flex-col justify-between shadow-lg animate-pulse"
                  style={{ width: `${Math.max(80, 160 - dist * 15)}px`, height: `${Math.max(70, 140 - dist * 15)}px` }}
                >
                  <div className="flex items-center justify-between text-[10px] font-mono text-emerald-300 font-bold bg-slate-900/90 px-1 py-0.5 rounded">
                    <span>{trk.className.toUpperCase()}</span>
                    <span>{(trk.confidence * 100).toFixed(0)}%</span>
                  </div>
                  <div className="text-[9px] font-mono text-slate-300 bg-slate-900/80 px-1 rounded">
                    d={dist.toFixed(2)}m • v={Math.hypot(trk.vx, trk.vy).toFixed(2)}m/s
                  </div>
                </div>
              );
            })}

            {telemetry.tracks.length === 0 && (
              <div className="text-center text-xs text-slate-500 font-mono">
                [ NO DYNAMIC OBJECTS IN DIRECT CAMERA FRUSTUM ]
              </div>
            )}
          </div>

          {/* Crosshair & OSD */}
          <div className="absolute top-2 left-2 text-[10px] font-mono text-slate-400 bg-slate-900/80 px-2 py-1 rounded">
            RGB-D SENSOR: CAMERA_LINK_01 • OPTICAL_AXIS_Z
          </div>
        </div>

        {/* Perception Statistics */}
        <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t border-slate-800 text-xs font-mono">
          <div className="bg-slate-950 p-2 rounded border border-slate-800">
            <span className="text-slate-500 text-[10px] block">VOXEL RES</span>
            <span className="text-slate-200 font-bold">0.05m</span>
          </div>
          <div className="bg-slate-950 p-2 rounded border border-slate-800">
            <span className="text-slate-500 text-[10px] block">OUTLIER REJ</span>
            <span className="text-emerald-400 font-bold">99.2%</span>
          </div>
          <div className="bg-slate-950 p-2 rounded border border-slate-800">
            <span className="text-slate-500 text-[10px] block">GROUND RATIO</span>
            <span className="text-cyan-400 font-bold">42.8%</span>
          </div>
        </div>
      </div>

      {/* Multi-Object Tracking (MOT) Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
          <div className="flex items-center space-x-2">
            <Scan className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-semibold text-white">Multi-Object Tracking (MOT) State</h3>
          </div>
          <span className="text-[11px] font-mono text-cyan-400 bg-cyan-950/60 border border-cyan-800 px-2 py-0.5 rounded">
            {telemetry.tracks.length} ACTIVE TRACKS
          </span>
        </div>

        {/* Tracks Table */}
        <div className="flex-1 overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                <th className="pb-2 font-medium">TRACK ID</th>
                <th className="pb-2 font-medium">CLASS</th>
                <th className="pb-2 font-medium">STATE</th>
                <th className="pb-2 font-medium">POS (X, Y)</th>
                <th className="pb-2 font-medium">VEL (Vx, Vy)</th>
                <th className="pb-2 font-medium">HITS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {telemetry.tracks.map((t) => (
                <tr key={t.id} className="hover:bg-slate-800/40">
                  <td className="py-2.5 font-bold text-cyan-400">{t.id}</td>
                  <td className="py-2.5 text-slate-300 capitalize">{t.className}</td>
                  <td className="py-2.5">
                    <span className="bg-emerald-950/60 text-emerald-400 border border-emerald-800 px-1.5 py-0.5 rounded text-[10px]">
                      {t.state}
                    </span>
                  </td>
                  <td className="py-2.5 text-slate-300">
                    ({t.x.toFixed(2)}, {t.y.toFixed(2)})m
                  </td>
                  <td className="py-2.5 text-slate-400">
                    ({t.vx.toFixed(2)}, {t.vy.toFixed(2)})m/s
                  </td>
                  <td className="py-2.5 text-slate-400">{t.hits}</td>
                </tr>
              ))}
              {telemetry.tracks.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500">
                    No active moving tracks in perceptual field.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Association Matrix Info */}
        <div className="mt-3 pt-3 border-t border-slate-800 text-[11px] text-slate-400">
          <div className="flex items-center justify-between font-mono">
            <span>ASSOCIATION KERNEL: Hungarian / Mahalanobis</span>
            <span>GATING THRESHOLD: 1.20m</span>
          </div>
        </div>
      </div>
    </div>
  );
};
