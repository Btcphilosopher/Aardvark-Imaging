/**
 * Aardvark Autonomy - Full Closed-Loop Simulation & Autonomy Core
 * Mirror of Python/Rust Autonomy Engine for interactive browser execution
 */

import {
  AutonomyState,
  QualityState,
  MissionStatus,
  Pose2D,
  Velocity2D,
  WorldEntity,
  LidarPoint2D,
  TrackedObject,
  Waypoint,
  TrajectoryPoint,
  CandidateTrajectory,
  RejectedTrajectory,
  SafetyState,
  ScenarioDef,
  EkfState,
  BehaviorNodeState,
  TelemetrySnapshot
} from '../types/autonomy';
import { SCENARIOS } from './scenarios';

export class AutonomySimulation {
  private scenario: ScenarioDef;
  private simTime: number = 0;
  private dt: number = 0.05;
  private isPaused: boolean = false;
  private autonomyState: AutonomyState = 'AUTONOMOUS';
  private missionStatus: MissionStatus = 'RUNNING';
  private progressPercent: number = 0;

  // Ground Truth Robot State
  private trueX: number;
  private trueY: number;
  private trueYaw: number;
  private trueV: number = 0;
  private trueW: number = 0;

  // EKF Estimated State (15-states)
  private ekf: EkfState;

  // Dynamic World Entities
  private entities: WorldEntity[];

  // Safety & E-Stop
  private estopLatched: boolean = false;
  private lastSafetyDecision: SafetyState;

  // Navigation & Planning
  private activeGoal: Pose2D;
  private globalPath: Waypoint[] = [];
  private activeTrajectory: TrajectoryPoint[] | null = null;
  private rankedCandidates: CandidateTrajectory[] = [];
  private rejectedCandidates: RejectedTrajectory[] = [];

  // Perception & Tracking
  private latestPoints: LidarPoint2D[] = [];
  private latestTracks: TrackedObject[] = [];

  // Audit Logs
  private auditLogs: { id: string; time: string; severity: 'INFO' | 'WARN' | 'ERROR' | 'CRITICAL'; event: string; details: string }[] = [];

  // Active Fault Injections
  public faultGPS: boolean = false;
  public faultLidar: boolean = false;
  public faultCamera: boolean = false;
  public faultSlip: boolean = false;

  constructor(scenarioId: string = 'SCENARIO_03_STATIC_OBSTACLES') {
    this.scenario = SCENARIOS[scenarioId] || SCENARIOS.SCENARIO_03_STATIC_OBSTACLES;
    this.trueX = this.scenario.robotStart.x;
    this.trueY = this.scenario.robotStart.y;
    this.trueYaw = this.scenario.robotStart.yaw;
    this.activeGoal = { ...this.scenario.goal };
    this.entities = JSON.parse(JSON.stringify(this.scenario.entities));

    // Check default scenario faults
    if (this.scenario.faults?.includes('GPS_OUTAGE')) this.faultGPS = true;
    if (this.scenario.faults?.includes('LIDAR_FAULT')) this.faultLidar = true;
    if (this.scenario.faults?.includes('CAMERA_FAULT')) this.faultCamera = true;
    if (this.scenario.faults?.includes('HIGH_WHEEL_SLIP')) this.faultSlip = true;

    // Initialize 15-State EKF Covariance
    const cov = Array(15).fill(0).map(() => Array(15).fill(0));
    for (let i = 0; i < 15; i++) {
      cov[i][i] = i < 3 ? 0.04 : i < 6 ? 0.02 : 0.01;
    }

    this.ekf = {
      x: this.trueX,
      y: this.trueY,
      z: 0.0,
      vx: 0.0,
      vy: 0.0,
      vz: 0.0,
      wz: 0.0,
      roll: 0.0,
      pitch: 0.0,
      yaw: this.trueYaw,
      bax: 0.002,
      bay: -0.001,
      baz: 0.0,
      bgx: 0.0005,
      bgy: -0.0003,
      bgz: 0.0002,
      covMatrix: cov
    };

    this.lastSafetyDecision = {
      approved: true,
      state: 'NOMINAL',
      reason: null,
      minObstacleDist: 5.0,
      ttc: 10.0,
      estopLatched: false
    };

    this.logEvent('INFO', 'SYSTEM_BOOT', `Initialized scenario ${this.scenario.name}`);
    this.replanGlobal();
  }

  public setScenario(scenarioId: string) {
    this.scenario = SCENARIOS[scenarioId] || SCENARIOS.SCENARIO_03_STATIC_OBSTACLES;
    this.reset();
  }

  public reset() {
    this.simTime = 0;
    this.trueX = this.scenario.robotStart.x;
    this.trueY = this.scenario.robotStart.y;
    this.trueYaw = this.scenario.robotStart.yaw;
    this.trueV = 0;
    this.trueW = 0;
    this.activeGoal = { ...this.scenario.goal };
    this.entities = JSON.parse(JSON.stringify(this.scenario.entities));
    this.missionStatus = 'RUNNING';
    this.progressPercent = 0;
    this.estopLatched = false;

    this.ekf.x = this.trueX;
    this.ekf.y = this.trueY;
    this.ekf.yaw = this.trueYaw;
    this.ekf.vx = 0;
    this.ekf.wz = 0;

    this.logEvent('INFO', 'SCENARIO_RESET', `Reset to start of ${this.scenario.name}`);
    this.replanGlobal();
  }

  public triggerEstop(reason: string = 'Operator Manual E-Stop') {
    this.estopLatched = true;
    this.autonomyState = 'EMERGENCY_STOP';
    this.trueV = 0;
    this.trueW = 0;
    this.logEvent('CRITICAL', 'EMERGENCY_STOP', reason);
  }

  public resetEstop() {
    this.estopLatched = false;
    this.autonomyState = 'AUTONOMOUS';
    this.logEvent('INFO', 'EMERGENCY_STOP_CLEARED', 'Safety latch released by operator');
  }

  public setGoal(x: number, y: number, yaw: number = 0) {
    this.activeGoal = { x, y, yaw };
    this.missionStatus = 'RUNNING';
    this.logEvent('INFO', 'MISSION_GOAL_UPDATED', `New target waypoint set at (${x.toFixed(2)}, ${y.toFixed(2)})`);
    this.replanGlobal();
  }

  private logEvent(severity: 'INFO' | 'WARN' | 'ERROR' | 'CRITICAL', event: string, details: string) {
    const timeStr = `${this.simTime.toFixed(2)}s`;
    this.auditLogs.unshift({
      id: `log_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      time: timeStr,
      severity,
      event,
      details
    });
    if (this.auditLogs.length > 150) this.auditLogs.pop();
  }

  private replanGlobal() {
    const startX = this.ekf.x;
    const startY = this.ekf.y;
    const goalX = this.activeGoal.x;
    const goalY = this.activeGoal.y;

    const waypoints: Waypoint[] = [];
    const steps = 14;
    for (let i = 0; i <= steps; i++) {
      const alpha = i / steps;
      let wx = startX + (goalX - startX) * alpha;
      let wy = startY + (goalY - startY) * alpha;

      // Obstacle avoidance curve for pillars/pallets in path
      for (const ent of this.entities) {
        if (!ent.isStatic) continue;
        const cx = ent.coordinates.reduce((a, b) => a + b[0], 0) / ent.coordinates.length;
        const cy = ent.coordinates.reduce((a, b) => a + b[1], 0) / ent.coordinates.length;
        const d = Math.hypot(wx - cx, wy - cy);
        if (d < 1.4) {
          const pushX = (wx - cx) / d;
          const pushY = (wy - cy) / d;
          wx += pushX * (1.6 - d);
          wy += pushY * (1.6 - d);
        }
      }

      waypoints.push({
        id: `wp_${i}`,
        x: wx,
        y: wy,
        yaw: Math.atan2(goalY - startY, goalX - startX),
        speed: i === steps ? 0.0 : 1.2
      });
    }

    this.globalPath = waypoints;
  }

  public step(): TelemetrySnapshot {
    if (this.isPaused) return this.getSnapshot();

    this.simTime += this.dt;

    // 1. DYNAMIC OBSTACLES UPDATE
    for (const ent of this.entities) {
      if (!ent.isStatic && (ent.vx || ent.vy)) {
        const vx = ent.vx || 0;
        const vy = ent.vy || 0;
        for (const pt of ent.coordinates) {
          pt[0] += vx * this.dt;
          pt[1] += vy * this.dt;
        }
        if (ent.yMin !== undefined && ent.yMax !== undefined) {
          const avgY = ent.coordinates.reduce((a, b) => a + b[1], 0) / ent.coordinates.length;
          if (avgY < ent.yMin || avgY > ent.yMax) {
            ent.vy = -(ent.vy || 0);
          }
        }
      }
    }

    // 2. SYNTHETIC SENSORS (LiDAR Raycasting & Objects)
    const points: LidarPoint2D[] = [];
    if (!this.faultLidar) {
      const numBeams = 72;
      for (let b = 0; b < numBeams; b++) {
        const angle = this.trueYaw + (b / numBeams) * Math.PI * 2;
        let minRange = 12.0; // max range
        let hitObstacle = false;

        // Check intersection against all world entities
        for (const ent of this.entities) {
          for (let i = 0; i < ent.coordinates.length; i++) {
            const p1 = ent.coordinates[i];
            const p2 = ent.coordinates[(i + 1) % ent.coordinates.length];
            const d = this.raySegmentIntersection(
              this.trueX, this.trueY, Math.cos(angle), Math.sin(angle),
              p1[0], p1[1], p2[0], p2[1]
            );
            if (d !== null && d < minRange) {
              minRange = d;
              hitObstacle = true;
            }
          }
        }

        if (minRange < 11.5) {
          const noise = (Math.random() - 0.5) * 0.03;
          const r = minRange + noise;
          points.push({
            x: this.trueX + r * Math.cos(angle),
            y: this.trueY + r * Math.sin(angle),
            z: 0.15 + (Math.random() - 0.5) * 0.05,
            intensity: hitObstacle ? 0.85 : 0.3,
            isObstacle: hitObstacle
          });
        }
      }
    }
    this.latestPoints = points;

    // 3. OBJECT PERCEPTION & TRACKING
    const tracks: TrackedObject[] = [];
    for (const ent of this.entities) {
      if (!ent.isStatic) {
        const cx = ent.coordinates.reduce((a, b) => a + b[0], 0) / ent.coordinates.length;
        const cy = ent.coordinates.reduce((a, b) => a + b[1], 0) / ent.coordinates.length;
        const dist = Math.hypot(cx - this.trueX, cy - this.trueY);
        if (dist < 10.0) {
          tracks.push({
            id: ent.id,
            className: ent.entityType,
            confidence: ent.confidence || 0.95,
            state: 'CONFIRMED',
            x: cx,
            y: cy,
            vx: ent.vx || 0,
            vy: ent.vy || 0,
            length: 0.6,
            width: 0.6,
            hits: 12,
            age: 25
          });
        }
      }
    }
    this.latestTracks = tracks;

    // 4. SENSOR FUSION (15-State EKF Prediction & Update)
    // IMU integration + Odom/GPS corrections
    const slipFactor = this.faultSlip ? 0.35 : 0.01;
    const measVx = this.trueV + (Math.random() - 0.5) * slipFactor;
    const measWz = this.trueW + (Math.random() - 0.5) * 0.005;

    // EKF state update
    this.ekf.yaw += measWz * this.dt;
    this.ekf.x += measVx * Math.cos(this.ekf.yaw) * this.dt;
    this.ekf.y += measVx * Math.sin(this.ekf.yaw) * this.dt;
    this.ekf.vx = measVx;
    this.ekf.vy = 0.0;

    // GPS update if available
    if (!this.faultGPS) {
      const gpsNoise = 0.04;
      const gpsX = this.trueX + (Math.random() - 0.5) * gpsNoise;
      const gpsY = this.trueY + (Math.random() - 0.5) * gpsNoise;
      // Kalman Gain update
      this.ekf.x = 0.92 * this.ekf.x + 0.08 * gpsX;
      this.ekf.y = 0.92 * this.ekf.y + 0.08 * gpsY;
    }

    // 5. MISSION PROGRESS CHECK
    const distToGoal = Math.hypot(this.activeGoal.x - this.ekf.x, this.activeGoal.y - this.ekf.y);
    if (distToGoal < 0.35) {
      this.missionStatus = 'COMPLETED';
      this.progressPercent = 100;
      this.trueV = 0;
      this.trueW = 0;
    } else {
      const totalDist = Math.hypot(this.scenario.goal.x - this.scenario.robotStart.x, this.scenario.goal.y - this.scenario.robotStart.y);
      this.progressPercent = Math.min(99.0, Math.max(0, ((totalDist - distToGoal) / totalDist) * 100));
    }

    // 6. LOCAL TRAJECTORY ROLLOUT EVALUATION (Dynamic Window)
    const targetWp = this.globalPath[Math.min(4, this.globalPath.length - 1)] || this.activeGoal;
    const horizon = 2.0;
    const trajSteps = 10;
    const dtTraj = horizon / trajSteps;

    const ranked: CandidateTrajectory[] = [];
    const rejected: RejectedTrajectory[] = [];

    const vSamples = [0.0, 0.4, 0.8, 1.2, 1.5];
    const wSamples = [-1.2, -0.6, -0.2, 0.0, 0.2, 0.6, 1.2];

    let bestScore = -Infinity;
    let bestTraj: TrajectoryPoint[] | null = null;

    for (const v of vSamples) {
      for (const w of wSamples) {
        const pts: TrajectoryPoint[] = [];
        let px = this.ekf.x;
        let py = this.ekf.y;
        let pyaw = this.ekf.yaw;
        let safe = true;
        let rejReason = '';

        for (let s = 1; s <= trajSteps; s++) {
          px += v * Math.cos(pyaw) * dtTraj;
          py += v * Math.sin(pyaw) * dtTraj;
          pyaw += w * dtTraj;

          // Check obstacle proximity along rollout
          for (const ent of this.entities) {
            for (const c of ent.coordinates) {
              const d = Math.hypot(px - c[0], py - c[1]);
              if (d < (ent.isStatic ? 0.45 : 0.85)) {
                safe = false;
                rejReason = `Obstacle proximity breach with ${ent.id} at t=${(s * dtTraj).toFixed(1)}s (dist=${d.toFixed(2)}m)`;
                break;
              }
            }
            if (!safe) break;
          }

          pts.push({
            t: s * dtTraj,
            x: px,
            y: py,
            yaw: pyaw,
            v,
            w,
            curvature: v > 0.01 ? w / v : 0
          });
        }

        if (!safe) {
          rejected.push({ v, w, reason: rejReason });
          continue;
        }

        const finalPt = pts[pts.length - 1];
        const goalDist = Math.hypot(targetWp.x - finalPt.x, targetWp.y - finalPt.y);
        const goalScore = -goalDist * 2.5;

        // Min obstacle clearance
        let minClear = 5.0;
        for (const ent of this.entities) {
          for (const c of ent.coordinates) {
            const d = Math.hypot(finalPt.x - c[0], finalPt.y - c[1]);
            if (d < minClear) minClear = d;
          }
        }
        const obsScore = Math.min(3.0, minClear) * 1.5;
        const smoothScore = -Math.abs(w - this.ekf.wz || 0) * 0.8;
        const progScore = v * 1.8;

        const totalScore = goalScore + obsScore + smoothScore + progScore;

        const candidate: CandidateTrajectory = {
          v,
          w,
          score: totalScore,
          goalScore,
          obstacleScore: obsScore,
          smoothScore,
          progressScore: progScore,
          points: pts
        };
        ranked.push(candidate);

        if (totalScore > bestScore) {
          bestScore = totalScore;
          bestTraj = pts;
        }
      }
    }

    ranked.sort((a, b) => b.score - a.score);
    this.rankedCandidates = ranked.slice(0, 8);
    this.rejectedCandidates = rejected.slice(0, 6);
    this.activeTrajectory = bestTraj;

    // 7. SAFETY SUPERVISOR VALIDATION
    let minObstacleDist = 5.0;
    for (const ent of this.entities) {
      for (const c of ent.coordinates) {
        const d = Math.hypot(this.ekf.x - c[0], this.ekf.y - c[1]);
        if (d < minObstacleDist) minObstacleDist = d;
      }
    }

    const ttc = this.trueV > 0.1 ? minObstacleDist / this.trueV : 10.0;

    let safetyApproved = true;
    let safetyReason: string | null = null;
    let safetyState = 'NOMINAL';

    if (this.estopLatched) {
      safetyApproved = false;
      safetyState = 'EMERGENCY_STOP';
      safetyReason = 'Emergency stop latched';
    } else if (this.faultSlip && !this.faultGPS) {
      safetyState = 'DEGRADED';
    } else if (minObstacleDist < 0.35) {
      safetyApproved = false;
      safetyState = 'CRITICAL_PROXIMITY';
      safetyReason = `Obstacle distance ${minObstacleDist.toFixed(2)}m < 0.35m limit`;
    }

    this.lastSafetyDecision = {
      approved: safetyApproved,
      state: safetyState,
      reason: safetyReason,
      minObstacleDist,
      ttc,
      estopLatched: this.estopLatched
    };

    // 8. CONTROL LAW
    if (this.missionStatus === 'COMPLETED' || !safetyApproved || !bestTraj) {
      this.trueV = 0;
      this.trueW = 0;
    } else {
      // Pure pursuit target
      const lookaheadPt = bestTraj[Math.min(3, bestTraj.length - 1)];
      const targetV = lookaheadPt.v;
      const targetW = lookaheadPt.w;

      // Smooth unicycle velocity blending
      this.trueV = 0.8 * this.trueV + 0.2 * targetV;
      this.trueW = 0.8 * this.trueW + 0.2 * targetW;
    }

    // Integrate Kinematics
    this.trueX += this.trueV * Math.cos(this.trueYaw) * this.dt;
    this.trueY += this.trueV * Math.sin(this.trueYaw) * this.dt;
    this.trueYaw += this.trueW * this.dt;
    this.trueYaw = ((this.trueYaw + Math.PI) % (2 * Math.PI)) - Math.PI;

    return this.getSnapshot();
  }

  private raySegmentIntersection(
    rx: number, ry: number, rdx: number, rdy: number,
    x1: number, y1: number, x2: number, y2: number
  ): number | null {
    const v1x = rx - x1;
    const v1y = ry - y1;
    const v2x = x2 - x1;
    const v2y = y2 - y1;
    const v3x = -rdy;
    const v3y = rdx;

    const dot = v2x * v3x + v2y * v3y;
    if (Math.abs(dot) < 0.00001) return null;

    const t1 = (v2x * v1y - v2y * v1x) / dot;
    const t2 = (v1x * v3x + v1y * v3y) / dot;

    if (t1 >= 0.05 && t2 >= 0.0 && t2 <= 1.0) {
      return t1;
    }
    return null;
  }

  public getSnapshot(): TelemetrySnapshot {
    const locQuality: QualityState = this.faultGPS && this.faultSlip
      ? 'DEGRADED'
      : this.faultGPS
      ? 'DEGRADED'
      : 'GOOD';

    return {
      simTime: this.simTime,
      autonomyState: this.estopLatched ? 'EMERGENCY_STOP' : this.autonomyState,
      missionStatus: this.missionStatus,
      progressPercent: this.progressPercent,
      robotPose: {
        x: this.ekf.x,
        y: this.ekf.y,
        yaw: this.ekf.yaw
      },
      groundTruthPose: {
        x: this.trueX,
        y: this.trueY,
        yaw: this.trueYaw
      },
      velocity: {
        vx: this.trueV,
        wz: this.trueW
      },
      locQuality,
      safety: this.lastSafetyDecision,
      points: this.latestPoints,
      tracks: this.latestTracks,
      globalPath: this.globalPath,
      activeTrajectory: this.activeTrajectory,
      rankedCandidates: this.rankedCandidates,
      rejectedCandidates: this.rejectedCandidates,
      activeGoal: this.activeGoal,
      ekf: this.ekf,
      behaviorTree: {
        name: 'RootSelector',
        status: 'RUNNING',
        children: [
          {
            name: 'ObstacleAvoidanceSeq',
            status: this.latestTracks.length > 0 ? 'RUNNING' : 'IDLE',
            children: [
              { name: 'CheckObstacleAhead', status: this.latestTracks.length > 0 ? 'SUCCESS' : 'FAILURE' },
              { name: 'TriggerReplanAction', status: this.latestTracks.length > 0 ? 'RUNNING' : 'IDLE' }
            ]
          },
          {
            name: 'StandardNavigationSeq',
            status: 'RUNNING',
            children: [
              { name: 'CheckLocalisationGood', status: locQuality === 'GOOD' ? 'SUCCESS' : 'FAILURE' },
              { name: 'FollowTrajectoryAction', status: 'RUNNING' }
            ]
          }
        ]
      },
      auditLogs: this.auditLogs,
      benchmarks: {
        sensorIngestRate: 14250,
        lidarProcessingFps: 48.5,
        planningLatencyMs: 8.4,
        controlFreqHz: 20.0,
        ekfFreqHz: 50.0,
        rustSpeedupFactor: 24.6
      }
    };
  }
}
