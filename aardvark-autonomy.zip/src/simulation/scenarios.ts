/**
 * Aardvark Autonomy - 15 Deterministic Scenarios Library
 */

import { ScenarioDef } from '../types/autonomy';

export const SCENARIOS: Record<string, ScenarioDef> = {
  SCENARIO_01_EMPTY_ROOM: {
    id: 'SCENARIO_01_EMPTY_ROOM',
    name: '01: Empty Room',
    description: 'Baseline unconstrained navigation across open area',
    robotStart: { x: -6.0, y: -6.0, yaw: 0.0 },
    goal: { x: 6.0, y: 6.0, yaw: 0.0 },
    entities: [
      { id: 'wall_n', entityType: 'wall', coordinates: [[-10, 10], [10, 10], [10, 9.6], [-10, 9.6]], isStatic: true },
      { id: 'wall_s', entityType: 'wall', coordinates: [[-10, -9.6], [10, -9.6], [10, -10], [-10, -10]], isStatic: true },
      { id: 'wall_e', entityType: 'wall', coordinates: [[9.6, -10], [10, -10], [10, 10], [9.6, 10]], isStatic: true },
      { id: 'wall_w', entityType: 'wall', coordinates: [[-10, -10], [-9.6, -10], [-9.6, 10], [-10, 10]], isStatic: true },
    ]
  },
  SCENARIO_02_CORRIDOR: {
    id: 'SCENARIO_02_CORRIDOR',
    name: '02: Narrow Corridor',
    description: 'Straight-line navigation in a confined aisle flanked by high racks',
    robotStart: { x: -8.0, y: 0.0, yaw: 0.0 },
    goal: { x: 8.0, y: 0.0, yaw: 0.0 },
    entities: [
      { id: 'rack_top', entityType: 'wall', coordinates: [[-10, 1.0], [10, 1.0], [10, 1.6], [-10, 1.6]], isStatic: true },
      { id: 'rack_bot', entityType: 'wall', coordinates: [[-10, -1.6], [10, -1.6], [10, -1.0], [-10, -1.0]], isStatic: true },
    ]
  },
  SCENARIO_03_STATIC_OBSTACLES: {
    id: 'SCENARIO_03_STATIC_OBSTACLES',
    name: '03: Static Pillars & Pallets',
    description: 'Complex warehouse maze with structural columns and storage pallets',
    robotStart: { x: -8.0, y: -8.0, yaw: 0.0 },
    goal: { x: 8.0, y: 8.0, yaw: 0.0 },
    entities: [
      { id: 'pillar_1', entityType: 'pillar', coordinates: [[-4.0, -4.0], [-3.0, -4.0], [-3.0, -3.0], [-4.0, -3.0]], isStatic: true },
      { id: 'pillar_2', entityType: 'pillar', coordinates: [[0.0, -1.0], [1.0, -1.0], [1.0, 0.0], [0.0, 0.0]], isStatic: true },
      { id: 'pillar_3', entityType: 'pillar', coordinates: [[-4.0, 3.0], [-3.0, 3.0], [-3.0, 4.0], [-4.0, 4.0]], isStatic: true },
      { id: 'pallet_1', entityType: 'pallet', coordinates: [[3.0, 3.0], [5.0, 3.0], [5.0, 4.2], [3.0, 4.2]], isStatic: true },
      { id: 'pallet_2', entityType: 'pallet', coordinates: [[-1.0, 4.0], [0.5, 4.0], [0.5, 6.0], [-1.0, 6.0]], isStatic: true },
      { id: 'pallet_3', entityType: 'pallet', coordinates: [[-6.0, 0.0], [-4.5, 0.0], [-4.5, 1.5], [-6.0, 1.5]], isStatic: true },
      { id: 'pallet_4', entityType: 'pallet', coordinates: [[3.0, -5.0], [5.0, -5.0], [5.0, -3.5], [3.0, -3.5]], isStatic: true },
    ]
  },
  SCENARIO_04_DYNAMIC_PEDESTRIANS: {
    id: 'SCENARIO_04_DYNAMIC_PEDESTRIANS',
    name: '04: Dynamic Pedestrians',
    description: 'Moving workers crossing the trajectory, triggering perception tracking and replan',
    robotStart: { x: -7.0, y: 0.0, yaw: 0.0 },
    goal: { x: 7.0, y: 0.0, yaw: 0.0 },
    entities: [
      {
        id: 'pedestrian_1',
        entityType: 'pedestrian',
        coordinates: [[0.0, -3.0], [0.6, -3.0], [0.6, -2.4], [0.0, -2.4]],
        isStatic: false,
        vx: 0.0,
        vy: 0.6,
        yMin: -3.5,
        yMax: 3.5,
        confidence: 0.94
      },
      {
        id: 'pedestrian_2',
        entityType: 'pedestrian',
        coordinates: [[3.5, 3.0], [4.1, 3.0], [4.1, 3.6], [3.5, 3.6]],
        isStatic: false,
        vx: 0.0,
        vy: -0.5,
        yMin: -3.5,
        yMax: 3.5,
        confidence: 0.91
      },
    ]
  },
  SCENARIO_05_NARROW_PASSAGE: {
    id: 'SCENARIO_05_NARROW_PASSAGE',
    name: '05: Narrow Doorway (0.9m)',
    description: 'High precision navigation through a restricted doorway opening',
    robotStart: { x: -4.5, y: 0.0, yaw: 0.0 },
    goal: { x: 4.5, y: 0.0, yaw: 0.0 },
    entities: [
      { id: 'door_top', entityType: 'wall', coordinates: [[0.0, 0.6], [0.0, 8.0], [0.4, 8.0], [0.4, 0.6]], isStatic: true },
      { id: 'door_bot', entityType: 'wall', coordinates: [[0.0, -8.0], [0.0, -0.6], [0.4, -0.6], [0.4, -8.0]], isStatic: true },
    ]
  },
  SCENARIO_06_GPS_UNAVAILABLE: {
    id: 'SCENARIO_06_GPS_UNAVAILABLE',
    name: '06: GPS Outage / Degraded',
    description: 'Simulates complete loss of satellite signal; relies on LiDAR scan-matching and EKF dead-reckoning',
    robotStart: { x: -6.0, y: -6.0, yaw: 0.0 },
    goal: { x: 6.0, y: 6.0, yaw: 0.0 },
    faults: ['GPS_OUTAGE'],
    entities: [
      { id: 'pillar_c', entityType: 'pillar', coordinates: [[0.0, 0.0], [1.2, 0.0], [1.2, 1.2], [0.0, 1.2]], isStatic: true }
    ]
  },
  SCENARIO_07_LIDAR_UNAVAILABLE: {
    id: 'SCENARIO_07_LIDAR_UNAVAILABLE',
    name: '07: LiDAR Sensor Fault',
    description: 'Primary 3D LiDAR failure triggering safety supervisor speed throttling and camera fallback',
    robotStart: { x: -5.0, y: 0.0, yaw: 0.0 },
    goal: { x: 5.0, y: 0.0, yaw: 0.0 },
    faults: ['LIDAR_FAULT'],
    entities: [
      { id: 'pallet_f', entityType: 'pallet', coordinates: [[1.0, -1.0], [2.5, -1.0], [2.5, 1.0], [1.0, 1.0]], isStatic: true }
    ]
  },
  SCENARIO_08_CAMERA_UNAVAILABLE: {
    id: 'SCENARIO_08_CAMERA_UNAVAILABLE',
    name: '08: Camera Vision Failure',
    description: 'RGB-D vision dropout; autonomy proceeds using full 3D point cloud and costmap inflation',
    robotStart: { x: -5.0, y: 0.0, yaw: 0.0 },
    goal: { x: 5.0, y: 0.0, yaw: 0.0 },
    faults: ['CAMERA_FAULT'],
    entities: [
      { id: 'pedestrian_f', entityType: 'pedestrian', coordinates: [[0.0, -1.0], [0.6, -1.0], [0.6, -0.4], [0.0, -0.4]], isStatic: false, vx: 0.0, vy: 0.4 }
    ]
  },
  SCENARIO_09_LOCALIZATION_DEGRADATION: {
    id: 'SCENARIO_09_LOCALIZATION_DEGRADATION',
    name: '09: Localisation Degradation',
    description: 'Wheel slippage induces high position covariance; supervisor detects degradation and slows robot',
    robotStart: { x: -6.0, y: 0.0, yaw: 0.0 },
    goal: { x: 6.0, y: 0.0, yaw: 0.0 },
    faults: ['HIGH_WHEEL_SLIP'],
    entities: []
  },
  SCENARIO_10_BLOCKED_GOAL: {
    id: 'SCENARIO_10_BLOCKED_GOAL',
    name: '10: Blocked Goal Re-Route',
    description: 'Direct goal position is blocked by an unexpected crate; A* detects obstruction and finds alternative path',
    robotStart: { x: -6.0, y: 0.0, yaw: 0.0 },
    goal: { x: 6.0, y: 0.0, yaw: 0.0 },
    entities: [
      { id: 'blocking_crate', entityType: 'crate', coordinates: [[5.2, -1.0], [6.8, -1.0], [6.8, 1.0], [5.2, 1.0]], isStatic: true }
    ]
  },
  SCENARIO_11_MOVING_OBSTACLE: {
    id: 'SCENARIO_11_MOVING_OBSTACLE',
    name: '11: Moving Autonomous Forklift (AGV)',
    description: 'Fast moving AGV forklift heading towards intersection; local planner slows and yields safely',
    robotStart: { x: -7.0, y: 0.0, yaw: 0.0 },
    goal: { x: 7.0, y: 0.0, yaw: 0.0 },
    entities: [
      {
        id: 'agv_forklift',
        entityType: 'vehicle',
        coordinates: [[6.0, -0.6], [7.8, -0.6], [7.8, 0.6], [6.0, 0.6]],
        isStatic: false,
        vx: -0.65,
        vy: 0.0,
        confidence: 0.98
      }
    ]
  },
  SCENARIO_12_MULTIPLE_ROBOTS: {
    id: 'SCENARIO_12_MULTIPLE_ROBOTS',
    name: '12: Multi-Robot Fleet Interaction',
    description: 'Collaborative robot Alpha meets robot Beta in shared workspace intersection',
    robotStart: { x: -8.0, y: 0.0, yaw: 0.0 },
    goal: { x: 8.0, y: 0.0, yaw: 0.0 },
    entities: [
      {
        id: 'robot_beta',
        entityType: 'robot',
        coordinates: [[0.0, -6.0], [0.8, -6.0], [0.8, -5.2], [0.0, -5.2]],
        isStatic: false,
        vx: 0.0,
        vy: 0.6,
        confidence: 0.99
      }
    ]
  },
  SCENARIO_13_LARGE_OUTDOOR_MAP: {
    id: 'SCENARIO_13_LARGE_OUTDOOR_MAP',
    name: '13: Large Outdoor Surveying Area',
    description: 'Expansive 40m x 40m environment with scattered trees, mounds, and long-range waypoints',
    robotStart: { x: -14.0, y: -14.0, yaw: 0.0 },
    goal: { x: 14.0, y: 14.0, yaw: 0.0 },
    entities: [
      { id: 'mound_1', entityType: 'pillar', coordinates: [[-5, -5], [-2, -5], [-2, -2], [-5, -2]], isStatic: true },
      { id: 'mound_2', entityType: 'pillar', coordinates: [[5, 5], [8, 5], [8, 8], [5, 8]], isStatic: true },
    ]
  },
  SCENARIO_14_HIGH_SENSOR_LOAD: {
    id: 'SCENARIO_14_HIGH_SENSOR_LOAD',
    name: '14: High Sensor Load Stress Test',
    description: 'High throughput raycasting stress test with 32 laser rings and dense point clouds',
    robotStart: { x: -6.0, y: -6.0, yaw: 0.0 },
    goal: { x: 6.0, y: 6.0, yaw: 0.0 },
    entities: [
      { id: 'box_a', entityType: 'pallet', coordinates: [[-2, -2], [0, -2], [0, 0], [-2, 0]], isStatic: true },
      { id: 'box_b', entityType: 'pallet', coordinates: [[2, 2], [4, 2], [4, 4], [2, 4]], isStatic: true },
    ]
  },
  SCENARIO_15_PLANNER_FAILURE: {
    id: 'SCENARIO_15_PLANNER_FAILURE',
    name: '15: Trap / Cul-de-sac Escape Recovery',
    description: 'Robot enters a dead-end enclosure; behavior tree triggers recovery scan and reverses safely',
    robotStart: { x: 0.0, y: 0.0, yaw: 0.0 },
    goal: { x: 8.0, y: 8.0, yaw: 0.0 },
    entities: [
      { id: 'trap_top', entityType: 'wall', coordinates: [[-1.5, 2.0], [2.5, 2.0], [2.5, 2.4], [-1.5, 2.4]], isStatic: true },
      { id: 'trap_right', entityType: 'wall', coordinates: [[2.0, -2.0], [2.5, -2.0], [2.5, 2.0], [2.0, 2.0]], isStatic: true },
      { id: 'trap_bot', entityType: 'wall', coordinates: [[-1.5, -2.4], [2.5, -2.4], [2.5, -2.0], [-1.5, -2.0]], isStatic: true },
    ]
  }
};
