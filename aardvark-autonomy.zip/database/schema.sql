-- Aardvark Autonomy PostgreSQL Relational Storage Schema
-- Phase 24 & 32: Robots, Sensors, Calibration, Trajectories, Maps, Missions, Audit Logs

CREATE TABLE IF NOT EXISTS robots (
    robot_id VARCHAR(64) PRIMARY KEY,
    model_type VARCHAR(64) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    dimensions_lwh FLOAT[] NOT NULL,
    max_linear_speed FLOAT NOT NULL,
    max_angular_speed FLOAT NOT NULL,
    battery_level FLOAT DEFAULT 100.0,
    status VARCHAR(32) DEFAULT 'READY'
);

CREATE TABLE IF NOT EXISTS sensors (
    sensor_id VARCHAR(64) PRIMARY KEY,
    robot_id VARCHAR(64) REFERENCES robots(robot_id),
    sensor_type VARCHAR(64) NOT NULL,
    frame_id VARCHAR(64) NOT NULL,
    rate_hz FLOAT NOT NULL,
    extrinsics_matrix FLOAT[][] NOT NULL,
    noise_parameters JSONB DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS missions (
    mission_id VARCHAR(64) PRIMARY KEY,
    robot_id VARCHAR(64) REFERENCES robots(robot_id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    priority INT DEFAULT 1,
    status VARCHAR(32) DEFAULT 'CREATED',
    goals JSONB NOT NULL,
    progress_percent FLOAT DEFAULT 0.0
);

CREATE TABLE IF NOT EXISTS trajectories (
    trajectory_id VARCHAR(64) PRIMARY KEY,
    mission_id VARCHAR(64) REFERENCES missions(mission_id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    duration_sec FLOAT NOT NULL,
    is_feasible BOOLEAN DEFAULT TRUE,
    rejection_reason TEXT,
    points JSONB NOT NULL
);

CREATE TABLE IF NOT EXISTS safety_events (
    event_id VARCHAR(64) PRIMARY KEY,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    robot_id VARCHAR(64) REFERENCES robots(robot_id),
    safety_state VARCHAR(32) NOT NULL,
    approved BOOLEAN NOT NULL,
    reason TEXT,
    min_obstacle_dist FLOAT,
    time_to_collision FLOAT
);

CREATE TABLE IF NOT EXISTS audit_logs (
    log_id BIGSERIAL PRIMARY KEY,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    component VARCHAR(64) NOT NULL,
    severity VARCHAR(16) NOT NULL,
    event_type VARCHAR(64) NOT NULL,
    trace_data JSONB DEFAULT '{}'::jsonb
);

-- Optimized Indexes
CREATE INDEX IF NOT EXISTS idx_safety_events_robot_ts ON safety_events(robot_id, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_component ON audit_logs(component, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_missions_status ON missions(status);
