-- Initial Seed Data for Aardvark Autonomy
INSERT INTO robots (robot_id, model_type, dimensions_lwh, max_linear_speed, max_angular_speed, battery_level, status)
VALUES ('robot-alpha-01', 'differential_drive', ARRAY[0.8, 0.6, 0.4], 1.5, 1.57, 98.5, 'READY')
ON CONFLICT (robot_id) DO NOTHING;

INSERT INTO missions (mission_id, robot_id, priority, status, goals, progress_percent)
VALUES (
    'msn_0001',
    'robot-alpha-01',
    1,
    'READY',
    '[{"goal_id": "g1", "goal_type": "waypoint_nav", "target_pose": {"x": 8.0, "y": 8.0, "z": 0.0}, "tolerance_m": 0.35}]'::jsonb,
    0.0
) ON CONFLICT (mission_id) DO NOTHING;
