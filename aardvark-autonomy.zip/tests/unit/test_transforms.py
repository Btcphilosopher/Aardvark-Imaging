"""
Aardvark Autonomy - Unit Tests for Spatial Transforms & SE(3) Invariants
"""

import pytest
import numpy as np
from aardvark_autonomy.core.transforms import (
    euler_to_quaternion,
    quaternion_to_rotation_matrix,
    create_transform_matrix,
    compose_transforms,
    invert_transform,
    transform_point,
)
from aardvark_autonomy.core.types import (
    CoordinateFrame,
    Transform,
    Point,
    Timestamp,
)


def test_quaternion_normalization_and_orthogonality():
    qx, qy, qz, qw = euler_to_quaternion(0.2, -0.3, 1.57)
    norm = np.sqrt(qx*qx + qy*qy + qz*qz + qw*qw)
    assert abs(norm - 1.0) < 1e-6

    R = quaternion_to_rotation_matrix(qx, qy, qz, qw)
    # Check R * R^T == I
    identity = np.dot(R, R.T)
    assert np.allclose(identity, np.eye(3), atol=1e-6)
    # Check determinant == +1
    assert abs(np.linalg.det(R) - 1.0) < 1e-6


def test_transform_inversion():
    t_mat = create_transform_matrix(2.5, -3.0, 1.0, 0.0, 0.0, 0.7071, 0.7071)
    t = Transform(
        source_frame=CoordinateFrame.BASE_LINK,
        target_frame=CoordinateFrame.MAP,
        matrix_4x4=t_mat.tolist(),
        timestamp=Timestamp.now()
    )

    t_inv = invert_transform(t)
    t_composed = compose_transforms(t, t_inv)
    m_comp = np.array(t_composed.matrix_4x4)

    assert np.allclose(m_comp, np.eye(4), atol=1e-5)
