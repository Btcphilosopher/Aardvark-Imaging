"""
Aardvark Autonomy - Safety Supervisor Strict Verification Tests
Phase 50: Proving fail-safe gates for speed, curvature, geofence, and E-Stop
"""

import pytest
from aardvark_autonomy.safety.supervisor import SafetySupervisor
from aardvark_autonomy.core.types import (
    Trajectory,
    TrajectoryPoint,
    Pose,
    Velocity,
    QualityState,
)
from aardvark_autonomy.planning.costmap import MasterCostmap


def test_estop_rejects_all_trajectories():
    supervisor = SafetySupervisor()
    supervisor.trigger_estop("Operator E-Stop")

    traj = Trajectory(
        points=[TrajectoryPoint(timestamp_sec=0.1, x=1.0, y=1.0, yaw=0.0, v_linear=0.5, v_angular=0.0)],
        duration_sec=1.0
    )
    costmap = MasterCostmap()
    pose = Pose(x=0.0, y=0.0, z=0.0)
    vel = Velocity(vx=0.0)

    decision = supervisor.validate_trajectory(
        traj, pose, vel, QualityState.GOOD, costmap, [], last_telemetry_age_sec=0.01
    )
    assert not decision.approved
    assert decision.safety_state == "EMERGENCY_STOP"


def test_speed_limit_violation_rejected():
    supervisor = SafetySupervisor(max_v=1.5)
    # Propose trajectory with 2.5 m/s (illegal)
    traj = Trajectory(
        points=[TrajectoryPoint(timestamp_sec=0.1, x=1.0, y=1.0, yaw=0.0, v_linear=2.5, v_angular=0.0)],
        duration_sec=1.0
    )
    costmap = MasterCostmap()
    pose = Pose(x=0.0, y=0.0, z=0.0)
    vel = Velocity(vx=0.0)

    decision = supervisor.validate_trajectory(
        traj, pose, vel, QualityState.GOOD, costmap, [], last_telemetry_age_sec=0.01
    )
    assert not decision.approved
    assert "exceeds max limit" in decision.reason
