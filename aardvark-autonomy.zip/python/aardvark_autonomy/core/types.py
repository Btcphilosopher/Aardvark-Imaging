"""
Aardvark Autonomy - Canonical Typed Data Models
Phase 2: Canonical Data Model specification
"""

from __future__ import annotations
from enum import Enum
from typing import List, Dict, Optional, Tuple, Any
from pydantic import BaseModel, Field
import time
import numpy as np


class CoordinateFrame(str, Enum):
    WORLD = "world"
    MAP = "map"
    ODOM = "odom"
    BASE_LINK = "base_link"
    LIDAR_LINK = "lidar_link"
    CAMERA_LINK = "camera_link"
    IMU_LINK = "imu_link"
    GPS_LINK = "gps_link"


class QualityState(str, Enum):
    UNKNOWN = "UNKNOWN"
    INITIALISING = "INITIALISING"
    GOOD = "GOOD"
    DEGRADED = "DEGRADED"
    LOST = "LOST"


class AutonomyState(str, Enum):
    BOOT = "BOOT"
    SELF_TEST = "SELF_TEST"
    CALIBRATING = "CALIBRATING"
    READY = "READY"
    LOCALISING = "LOCALISING"
    AUTONOMOUS = "AUTONOMOUS"
    DEGRADED = "DEGRADED"
    RECOVERY = "RECOVERY"
    EMERGENCY_STOP = "EMERGENCY_STOP"
    FAULT = "FAULT"
    SHUTDOWN = "SHUTDOWN"


class MissionStatus(str, Enum):
    CREATED = "CREATED"
    VALIDATING = "VALIDATING"
    READY = "READY"
    RUNNING = "RUNNING"
    PAUSED = "PAUSED"
    BLOCKED = "BLOCKED"
    FAILED = "FAILED"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"


class TrackState(str, Enum):
    TENTATIVE = "TENTATIVE"
    CONFIRMED = "CONFIRMED"
    LOST = "LOST"
    DELETED = "DELETED"


class Timestamp(BaseModel):
    utc_iso: str
    sec: float
    monotonic_sec: float

    @classmethod
    def now(cls) -> Timestamp:
        s = time.time()
        m = time.monotonic()
        return cls(
            utc_iso=time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(s)) + f".{int((s % 1)*1000):03d}Z",
            sec=s,
            monotonic_sec=m,
        )


class Covariance(BaseModel):
    dim: int
    matrix: List[List[float]]
    confidence: float = 1.0

    @classmethod
    def diagonal(cls, std_devs: List[float]) -> Covariance:
        dim = len(std_devs)
        mat = [[0.0] * dim for _ in range(dim)]
        for i, sd in enumerate(std_devs):
            mat[i][i] = float(sd * sd)
        return cls(dim=dim, matrix=mat)


class Pose(BaseModel):
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    qx: float = 0.0
    qy: float = 0.0
    qz: float = 0.0
    qw: float = 1.0
    frame_id: CoordinateFrame = CoordinateFrame.MAP
    covariance: Optional[Covariance] = None

    @property
    def yaw(self) -> float:
        # Standard yaw from quaternion
        siny_cosp = 2.0 * (self.qw * self.qz + self.qx * self.qy)
        cosy_cosp = 1.0 - 2.0 * (self.qy * self.qy + self.qz * self.qz)
        return float(np.arctan2(siny_cosp, cosy_cosp))


class Velocity(BaseModel):
    vx: float = 0.0
    vy: float = 0.0
    vz: float = 0.0
    wx: float = 0.0
    wy: float = 0.0
    wz: float = 0.0
    frame_id: CoordinateFrame = CoordinateFrame.BASE_LINK
    covariance: Optional[Covariance] = None


class Acceleration(BaseModel):
    ax: float = 0.0
    ay: float = 0.0
    az: float = 0.0
    frame_id: CoordinateFrame = CoordinateFrame.BASE_LINK


class Transform(BaseModel):
    source_frame: CoordinateFrame
    target_frame: CoordinateFrame
    matrix_4x4: List[List[float]]
    timestamp: Timestamp


# Sensor Models
class SensorConfiguration(BaseModel):
    sensor_id: str
    sensor_type: str
    frame_id: CoordinateFrame
    rate_hz: float
    extrinsics_to_base: Transform
    intrinsics: Dict[str, Any] = Field(default_factory=dict)
    noise_parameters: Dict[str, float] = Field(default_factory=dict)


class Point(BaseModel):
    x: float
    y: float
    z: float
    intensity: float = 1.0
    ring: int = 0
    confidence: float = 1.0


class PointCloud(BaseModel):
    id: str
    timestamp: Timestamp
    frame_id: CoordinateFrame
    points: List[Point] = Field(default_factory=list)
    quality: float = 1.0


class CameraFrame(BaseModel):
    id: str
    timestamp: Timestamp
    frame_id: CoordinateFrame
    width: int
    height: int
    rgb_data_base64: Optional[str] = None
    depth_data_base64: Optional[str] = None
    confidence: float = 1.0


class ImuMeasurement(BaseModel):
    id: str
    timestamp: Timestamp
    frame_id: CoordinateFrame
    linear_acceleration: Acceleration
    angular_velocity: List[float] # wx, wy, wz
    orientation: Optional[List[float]] = None # qx, qy, qz, qw
    covariance: Optional[Covariance] = None


class GpsMeasurement(BaseModel):
    id: str
    timestamp: Timestamp
    frame_id: CoordinateFrame
    latitude: float
    longitude: float
    altitude: float
    utm_x: float
    utm_y: float
    covariance: Optional[Covariance] = None
    quality_fix: int = 4 # RTK fixed


class OdometryMeasurement(BaseModel):
    id: str
    timestamp: Timestamp
    frame_id: CoordinateFrame
    pose: Pose
    velocity: Velocity
    left_wheel_rad: float = 0.0
    right_wheel_rad: float = 0.0


# Perception & Tracking
class DetectedObject(BaseModel):
    id: str
    class_name: str
    confidence: float
    pose: Pose
    dimensions: List[float] # [length, width, height]
    source_sensor: str
    timestamp: Timestamp


class TrackedObject(BaseModel):
    track_id: str
    class_name: str
    confidence: float
    state: TrackState
    position: List[float] # [x, y, z]
    velocity: List[float] # [vx, vy, vz]
    acceleration: List[float] = Field(default_factory=lambda: [0.0, 0.0, 0.0])
    dimensions: List[float] # [length, width, height]
    covariance: Optional[Covariance] = None
    hits: int = 1
    age_steps: int = 1
    last_updated: Timestamp


class ObjectPrediction(BaseModel):
    track_id: str
    predicted_trajectory: List[Pose]
    prediction_horizon_sec: float
    probability: float


# World & Mapping
class WorldEntity(BaseModel):
    id: str
    entity_type: str # obstacle, wall, vehicle, pedestrian, landmark, restricted_zone
    geometry_type: str # polygon, box, circle
    coordinates: List[List[float]]
    is_static: bool = True
    metadata: Dict[str, Any] = Field(default_factory=dict)


class OccupancyCell(BaseModel):
    x: int
    y: int
    log_odds: float
    probability: float
    state: str # FREE, OCCUPIED, UNKNOWN


class Voxel(BaseModel):
    x: int
    y: int
    z: int
    occupancy_prob: float
    confidence: float
    semantic_class: str
    last_seen_sec: float


class CostCell(BaseModel):
    x: int
    y: int
    cost_value: int # 0=free, 1-252=cost, 253=lethal, 254=unknown


# Planning & Control
class Waypoint(BaseModel):
    id: str
    x: float
    y: float
    yaw: float = 0.0
    target_speed: float = 1.0
    tolerance_radius: float = 0.3


class Path(BaseModel):
    waypoints: List[Waypoint]
    total_cost: float
    total_length: float
    planning_time_ms: float
    planner_id: str
    map_version: int


class TrajectoryPoint(BaseModel):
    timestamp_sec: float
    x: float
    y: float
    z: float = 0.0
    yaw: float
    v_linear: float
    v_angular: float
    a_linear: float = 0.0
    curvature: float = 0.0


class Trajectory(BaseModel):
    points: List[TrajectoryPoint]
    duration_sec: float
    is_feasible: bool = True
    rejection_reason: Optional[str] = None


class ControlCommand(BaseModel):
    timestamp: Timestamp
    linear_velocity: float
    angular_velocity: float
    steering_angle: float = 0.0
    brake: float = 0.0
    e_stop: bool = False


# Safety & Mission
class SafetyDecision(BaseModel):
    approved: bool
    safety_state: str
    reason: Optional[str] = None
    min_obstacle_distance: float
    time_to_collision: float
    timestamp: Timestamp


class MissionGoal(BaseModel):
    goal_id: str
    goal_type: str # waypoint_nav, patrol, return_to_dock, inspection
    target_pose: Pose
    tolerance_m: float = 0.3
    is_reached: bool = False


class Mission(BaseModel):
    mission_id: str
    robot_id: str
    created_at: Timestamp
    priority: int = 1
    status: MissionStatus = MissionStatus.CREATED
    goals: List[MissionGoal] = Field(default_factory=list)
    active_goal_index: int = 0
    progress_percent: float = 0.0


class DiagnosticEvent(BaseModel):
    event_id: str
    timestamp: Timestamp
    component: str
    severity: str # INFO, WARN, ERROR, CRITICAL
    message: str
    trace_data: Dict[str, Any] = Field(default_factory=dict)
