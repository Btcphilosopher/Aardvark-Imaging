"""
Aardvark Autonomy - Spatial Mathematics & Explicit Coordinate Transforms
Phase 3: Coordinate Transformations (SE(3) Algebra, Homogeneous Matrices, Quaternions)
"""

from __future__ import annotations
import numpy as np
from typing import List, Tuple
from aardvark_autonomy.core.types import (
    CoordinateFrame,
    Transform,
    Pose,
    Point,
    PointCloud,
    Timestamp,
)


def euler_to_quaternion(roll: float, pitch: float, yaw: float) -> Tuple[float, float, float, float]:
    """Convert roll, pitch, yaw (rad) to quaternion (qx, qy, qz, qw)."""
    cy = np.cos(yaw * 0.5)
    sy = np.sin(yaw * 0.5)
    cp = np.cos(pitch * 0.5)
    sp = np.sin(pitch * 0.5)
    cr = np.cos(roll * 0.5)
    sr = np.sin(roll * 0.5)

    qw = cr * cp * cy + sr * sp * sy
    qx = sr * cp * cy - cr * sp * sy
    qy = cr * sp * cy + sr * cp * sy
    qz = cr * cp * sy - sr * sp * cy
    return float(qx), float(qy), float(qz), float(qw)


def quaternion_to_rotation_matrix(qx: float, qy: float, qz: float, qw: float) -> np.ndarray:
    """Convert unit quaternion to 3x3 SO(3) rotation matrix with validation."""
    norm = np.sqrt(qx*qx + qy*qy + qz*qz + qw*qw)
    if norm < 1e-8:
        raise ValueError("Degenerate zero quaternion provided")
    qx, qy, qz, qw = qx/norm, qy/norm, qz/norm, qw/norm

    r00 = 1.0 - 2.0 * (qy*qy + qz*qz)
    r01 = 2.0 * (qx*qy - qz*qw)
    r02 = 2.0 * (qx*qz + qy*qw)

    r10 = 2.0 * (qx*qy + qz*qw)
    r11 = 1.0 - 2.0 * (qx*qx + qz*qz)
    r12 = 2.0 * (qy*qz - qx*qw)

    r20 = 2.0 * (qx*qz - qy*qw)
    r21 = 2.0 * (qy*qz + qx*qw)
    r22 = 1.0 - 2.0 * (qx*qx + qy*qy)

    R = np.array([
        [r00, r01, r02],
        [r10, r11, r12],
        [r20, r21, r22]
    ], dtype=np.float64)

    # Validate orthogonality: R * R^T == I, det(R) == 1
    if abs(np.linalg.det(R) - 1.0) > 1e-4:
        raise ValueError("Malformed rotation matrix: determinant must be 1")
    return R


def create_transform_matrix(
    tx: float, ty: float, tz: float,
    qx: float = 0.0, qy: float = 0.0, qz: float = 0.0, qw: float = 1.0
) -> np.ndarray:
    """Construct 4x4 homogeneous transformation matrix T in SE(3)."""
    R = quaternion_to_rotation_matrix(qx, qy, qz, qw)
    T = np.eye(4, dtype=np.float64)
    T[:3, :3] = R
    T[:3, 3] = [tx, ty, tz]
    return T


def compose_transforms(t_a_to_b: Transform, t_b_to_c: Transform) -> Transform:
    """Compose two transforms: T_A_to_C = T_B_to_C * T_A_to_B."""
    if t_a_to_b.target_frame != t_b_to_c.source_frame:
        raise ValueError(
            f"Frame mismatch during composition: {t_a_to_b.target_frame} != {t_b_to_c.source_frame}"
        )
    m1 = np.array(t_a_to_b.matrix_4x4, dtype=np.float64)
    m2 = np.array(t_b_to_c.matrix_4x4, dtype=np.float64)
    m_composed = np.dot(m2, m1)

    return Transform(
        source_frame=t_a_to_b.source_frame,
        target_frame=t_b_to_c.target_frame,
        matrix_4x4=m_composed.tolist(),
        timestamp=Timestamp.now()
    )


def invert_transform(t: Transform) -> Transform:
    """Invert 4x4 SE(3) transform: T^-1 = [R^T, -R^T * t; 0, 1]."""
    mat = np.array(t.matrix_4x4, dtype=np.float64)
    R = mat[:3, :3]
    pos = mat[:3, 3]

    R_inv = R.T
    pos_inv = -np.dot(R_inv, pos)

    inv_mat = np.eye(4, dtype=np.float64)
    inv_mat[:3, :3] = R_inv
    inv_mat[:3, 3] = pos_inv

    return Transform(
        source_frame=t.target_frame,
        target_frame=t.source_frame,
        matrix_4x4=inv_mat.tolist(),
        timestamp=Timestamp.now()
    )


def transform_point(p: Point, transform: Transform) -> Point:
    """Apply 4x4 transform to a 3D Point."""
    T = np.array(transform.matrix_4x4, dtype=np.float64)
    v = np.array([p.x, p.y, p.z, 1.0], dtype=np.float64)
    v_trans = np.dot(T, v)
    return Point(
        x=float(v_trans[0]),
        y=float(v_trans[1]),
        z=float(v_trans[2]),
        intensity=p.intensity,
        ring=p.ring,
        confidence=p.confidence
    )


def transform_cloud(cloud: PointCloud, transform: Transform) -> PointCloud:
    """Vectorized transformation of entire PointCloud."""
    if len(cloud.points) == 0:
        return PointCloud(
            id=f"{cloud.id}_transformed",
            timestamp=Timestamp.now(),
            frame_id=transform.target_frame,
            points=[],
            quality=cloud.quality
        )

    pts = np.array([[p.x, p.y, p.z, 1.0] for p in cloud.points], dtype=np.float64)
    T = np.array(transform.matrix_4x4, dtype=np.float64)
    pts_trans = np.dot(pts, T.T)

    new_points = [
        Point(
            x=float(pts_trans[i, 0]),
            y=float(pts_trans[i, 1]),
            z=float(pts_trans[i, 2]),
            intensity=p.intensity,
            ring=p.ring,
            confidence=p.confidence
        )
        for i, p in enumerate(cloud.points)
    ]

    return PointCloud(
        id=f"{cloud.id}_trans",
        timestamp=Timestamp.now(),
        frame_id=transform.target_frame,
        points=new_points,
        quality=cloud.quality
    )


def transform_pose(pose: Pose, transform: Transform) -> Pose:
    """Transform Pose from pose.frame_id to transform.target_frame."""
    T = np.array(transform.matrix_4x4, dtype=np.float64)
    T_pose = create_transform_matrix(
        pose.x, pose.y, pose.z,
        pose.qx, pose.qy, pose.qz, pose.qw
    )
    T_new = np.dot(T, T_pose)

    R_new = T_new[:3, :3]
    # Convert R_new back to quaternion
    tr = R_new[0, 0] + R_new[1, 1] + R_new[2, 2]
    if tr > 0.0:
        S = np.sqrt(tr + 1.0) * 2.0
        qw = 0.25 * S
        qx = (R_new[2, 1] - R_new[1, 2]) / S
        qy = (R_new[0, 2] - R_new[2, 0]) / S
        qz = (R_new[1, 0] - R_new[0, 1]) / S
    elif (R_new[0, 0] > R_new[1, 1]) and (R_new[0, 0] > R_new[2, 2]):
        S = np.sqrt(1.0 + R_new[0, 0] - R_new[1, 1] - R_new[2, 2]) * 2.0
        qw = (R_new[2, 1] - R_new[1, 2]) / S
        qx = 0.25 * S
        qy = (R_new[0, 1] + R_new[1, 0]) / S
        qz = (R_new[0, 2] + R_new[2, 0]) / S
    elif R_new[1, 1] > R_new[2, 2]:
        S = np.sqrt(1.0 + R_new[1, 1] - R_new[0, 0] - R_new[2, 2]) * 2.0
        qw = (R_new[0, 2] - R_new[2, 0]) / S
        qx = (R_new[0, 1] + R_new[1, 0]) / S
        qy = 0.25 * S
        qz = (R_new[1, 2] + R_new[2, 1]) / S
    else:
        S = np.sqrt(1.0 + R_new[2, 2] - R_new[0, 0] - R_new[1, 1]) * 2.0
        qw = (R_new[1, 0] - R_new[0, 1]) / S
        qx = (R_new[0, 2] + R_new[2, 0]) / S
        qy = (R_new[1, 2] + R_new[2, 1]) / S
        qz = 0.25 * S

    return Pose(
        x=float(T_new[0, 3]),
        y=float(T_new[1, 3]),
        z=float(T_new[2, 3]),
        qx=float(qx),
        qy=float(qy),
        qz=float(qz),
        qw=float(qw),
        frame_id=transform.target_frame,
        covariance=pose.covariance
    )
