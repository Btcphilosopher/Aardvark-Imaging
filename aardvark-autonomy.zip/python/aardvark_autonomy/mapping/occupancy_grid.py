"""
Aardvark Autonomy - 2D Log-Odds Occupancy Grid Map
Phase 14: Bayesian Log-Odds Sensor Model & Bresenham Raytracing
"""

import numpy as np
from typing import List, Tuple, Optional
from aardvark_autonomy.core.types import (
    PointCloud,
    Pose,
    OccupancyCell,
    CoordinateFrame,
    Timestamp,
)


class OccupancyGridMap:
    def __init__(
        self,
        width_m: float = 40.0,
        height_m: float = 40.0,
        resolution_m: float = 0.10,
        origin_x: float = -20.0,
        origin_y: float = -20.0,
        prob_hit: float = 0.70,
        prob_miss: float = 0.35,
        l_min: float = -4.0,
        l_max: float = 4.0
    ):
        self.width_m = width_m
        self.height_m = height_m
        self.resolution = resolution_m
        self.origin_x = origin_x
        self.origin_y = origin_y
        self.cols = int(width_m / resolution_m)
        self.rows = int(height_m / resolution_m)

        # Log odds grid L(m) initialized to 0.0 (p=0.5 unknown)
        self.log_odds = np.zeros((self.rows, self.cols), dtype=np.float32)

        self.l_occ = float(np.log(prob_hit / (1.0 - prob_hit)))
        self.l_free = float(np.log(prob_miss / (1.0 - prob_miss)))
        self.l_min = l_min
        self.l_max = l_max

    def world_to_grid(self, wx: float, wy: float) -> Optional[Tuple[int, int]]:
        gx = int((wx - self.origin_x) / self.resolution)
        gy = int((wy - self.origin_y) / self.resolution)
        if 0 <= gx < self.cols and 0 <= gy < self.rows:
            return gx, gy
        return None

    def grid_to_world(self, gx: int, gy: int) -> Tuple[float, float]:
        wx = self.origin_x + (gx + 0.5) * self.resolution
        wy = self.origin_y + (gy + 0.5) * self.resolution
        return wx, wy

    def update_with_scan(self, robot_pose: Pose, obstacle_cloud: PointCloud) -> None:
        """Ray-trace from sensor origin to detected obstacle points with Bayesian log-odds update."""
        sensor_gx_gy = self.world_to_grid(robot_pose.x, robot_pose.y)
        if not sensor_gx_gy:
            return
        x0, y0 = sensor_gx_gy

        for p in obstacle_cloud.points:
            # Transform point to world frame if in base/lidar frame
            cos_y = np.cos(robot_pose.yaw)
            sin_y = np.sin(robot_pose.yaw)
            wx = robot_pose.x + (cos_y * p.x - sin_y * p.y)
            wy = robot_pose.y + (sin_y * p.x + cos_y * p.y)

            end_gx_gy = self.world_to_grid(wx, wy)
            if not end_gx_gy:
                continue
            x1, y1 = end_gx_gy

            # Bresenham's line algorithm for free cells along ray
            dx = abs(x1 - x0)
            dy = abs(y1 - y0)
            sx = 1 if x0 < x1 else -1
            sy = 1 if y0 < y1 else -1
            err = dx - dy

            curr_x, curr_y = x0, y0
            while (curr_x != x1 or curr_y != y1):
                if 0 <= curr_x < self.cols and 0 <= curr_y < self.rows:
                    self.log_odds[curr_y, curr_x] = max(
                        self.l_min, self.log_odds[curr_y, curr_x] + self.l_free
                    )
                e2 = 2 * err
                if e2 > -dy:
                    err -= dy
                    curr_x += sx
                if e2 < dx:
                    err += dx
                    curr_y += sy

            # Update obstacle endpoint cell as occupied
            if 0 <= x1 < self.cols and 0 <= y1 < self.rows:
                self.log_odds[y1, x1] = min(
                    self.l_max, self.log_odds[y1, x1] + self.l_occ
                )

    def get_probability_grid(self) -> np.ndarray:
        """Convert log odds to probability: p(m) = 1 - 1 / (1 + exp(L))."""
        return 1.0 - 1.0 / (1.0 + np.exp(self.log_odds))

    def get_cost_grid(self) -> np.ndarray:
        """Return 0-254 cost representation."""
        prob = self.get_probability_grid()
        costs = np.zeros_like(prob, dtype=np.uint8)
        costs[prob > 0.65] = 253 # lethal
        costs[(prob <= 0.65) & (prob > 0.45)] = 254 # unknown
        costs[prob <= 0.45] = (prob[prob <= 0.45] * (252.0 / 0.45)).astype(np.uint8)
        return costs
