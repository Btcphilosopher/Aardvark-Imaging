"""
Aardvark Autonomy - Pure Pursuit Path Tracker & Anti-Windup PID Velocity Controller
Phase 18 & 25: Geometric Arc Steering & Saturated Control
"""

import numpy as np
from typing import Tuple, Optional
from aardvark_autonomy.core.types import (
    Pose,
    Velocity,
    Trajectory,
    TrajectoryPoint,
    ControlCommand,
    Timestamp,
)


class VelocityPID:
    def __init__(self, kp: float = 1.2, ki: float = 0.15, kd: float = 0.05, i_clamp: float = 0.5):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.i_clamp = i_clamp
        self.integral = 0.0
        self.prev_error = 0.0

    def compute(self, target_v: float, current_v: float, dt: float) -> float:
        if dt <= 0.0:
            return target_v

        error = target_v - current_v
        self.integral += error * dt
        # Anti-windup clamping
        self.integral = max(-self.i_clamp, min(self.i_clamp, self.integral))

        derivative = (error - self.prev_error) / dt
        self.prev_error = error

        u = self.kp * error + self.ki * self.integral + self.kd * derivative
        return float(target_v + u)


class PurePursuitController:
    def __init__(
        self,
        lookahead_min: float = 0.4,
        lookahead_max: float = 1.5,
        lookahead_ratio: float = 0.8,
        max_speed: float = 1.5,
        max_w: float = 1.6
    ):
        self.l_min = lookahead_min
        self.l_max = lookahead_max
        self.k_lookahead = lookahead_ratio
        self.max_speed = max_speed
        self.max_w = max_w
        self.pid = VelocityPID()

    def compute_command(
        self,
        current_pose: Pose,
        current_vel: Velocity,
        trajectory: Trajectory,
        dt: float = 0.05
    ) -> ControlCommand:
        if not trajectory.points:
            return ControlCommand(
                timestamp=Timestamp.now(),
                linear_velocity=0.0,
                angular_velocity=0.0,
                brake=1.0
            )

        # 1. Compute adaptive lookahead distance L = clamp(l_min, l_max, k * v)
        current_speed = max(0.1, abs(current_vel.vx))
        lookahead = max(self.l_min, min(self.l_max, self.k_lookahead * current_speed))

        # 2. Find target lookahead point on trajectory
        robot_x, robot_y, robot_yaw = current_pose.x, current_pose.y, current_pose.yaw
        target_pt: Optional[TrajectoryPoint] = None

        for pt in trajectory.points:
            dist = np.sqrt((pt.x - robot_x)**2 + (pt.y - robot_y)**2)
            if dist >= lookahead:
                target_pt = pt
                break

        if target_pt is None:
            target_pt = trajectory.points[-1]

        # 3. Compute heading error alpha
        angle_to_target = np.arctan2(target_pt.y - robot_y, target_pt.x - robot_x)
        alpha = (angle_to_target - robot_yaw + np.pi) % (2 * np.pi) - np.pi

        # 4. Pure pursuit curvature: kappa = 2 * sin(alpha) / L
        dist_to_pt = max(0.1, np.sqrt((target_pt.x - robot_x)**2 + (target_pt.y - robot_y)**2))
        curvature = 2.0 * np.sin(alpha) / dist_to_pt

        # 5. Target speed
        v_cmd_raw = min(self.max_speed, target_pt.v_linear)
        # Slow down around sharp turns
        v_cmd_curved = v_cmd_raw / (1.0 + 1.5 * abs(curvature))

        v_controlled = self.pid.compute(v_cmd_curved, current_vel.vx, dt)
        v_controlled = max(0.0, min(self.max_speed, v_controlled))

        w_cmd = v_controlled * curvature
        w_cmd = max(-self.max_w, min(self.max_w, w_cmd))

        return ControlCommand(
            timestamp=Timestamp.now(),
            linear_velocity=float(v_controlled),
            angular_velocity=float(w_cmd),
            steering_angle=float(np.arctan(curvature * 0.55)), # Equivalent Ackermann angle
            brake=0.0,
            e_stop=False
        )
