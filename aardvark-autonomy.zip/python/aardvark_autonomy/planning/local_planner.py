"""
Aardvark Autonomy - Local Trajectory Rollout Evaluator & Explainable Planner
Phase 19: DWA / Trajectory Rollout Candidate Generation with Multi-Objective Scoring
"""

import numpy as np
from typing import List, Tuple, Optional, Dict, Any
from aardvark_autonomy.core.types import (
    Pose,
    Velocity,
    Trajectory,
    TrajectoryPoint,
    Waypoint,
    Path,
)
from aardvark_autonomy.planning.costmap import MasterCostmap


class LocalTrajectoryEvaluator:
    def __init__(
        self,
        prediction_horizon_sec: float = 2.5,
        dt: float = 0.1,
        v_samples: int = 9,
        w_samples: int = 15,
        max_v: float = 1.5,
        max_w: float = 1.6,
        max_a: float = 1.0,
        max_alpha: float = 2.0,
        w_goal: float = 2.5,
        w_obstacle: float = 3.0,
        w_smooth: float = 1.0,
        w_vel: float = 1.2,
        w_progress: float = 2.0
    ):
        self.horizon = prediction_horizon_sec
        self.dt = dt
        self.v_samples = v_samples
        self.w_samples = w_samples
        self.max_v = max_v
        self.max_w = max_w
        self.max_a = max_a
        self.max_alpha = max_alpha
        self.w_goal = w_goal
        self.w_obstacle = w_obstacle
        self.w_smooth = w_smooth
        self.w_vel = w_vel
        self.w_progress = w_progress

    def evaluate(
        self,
        current_pose: Pose,
        current_vel: Velocity,
        target_waypoint: Waypoint,
        costmap: MasterCostmap
    ) -> Tuple[Optional[Trajectory], List[Dict[str, Any]], List[Dict[str, Any]]]:
        """
        Evaluate candidate velocity pairs (v, w) in Dynamic Window.
        Returns: (best_trajectory, ranked_candidates, rejected_candidates)
        """
        # 1. Compute Dynamic Window based on acceleration limits
        min_v = max(0.0, current_vel.vx - self.max_a * self.dt * 2.0)
        max_v = min(self.max_v, current_vel.vx + self.max_a * self.dt * 2.0)
        min_w = max(-self.max_w, current_vel.wz - self.max_alpha * self.dt * 2.0)
        max_w = min(self.max_w, current_vel.wz + self.max_alpha * self.dt * 2.0)

        v_candidates = np.linspace(min_v, max_v, self.v_samples)
        w_candidates = np.linspace(min_w, max_w, self.w_samples)

        steps = int(self.horizon / self.dt)
        ranked_candidates: List[Dict[str, Any]] = []
        rejected_candidates: List[Dict[str, Any]] = []

        best_score = -float('inf')
        best_trajectory: Optional[Trajectory] = None

        target_pos = np.array([target_waypoint.x, target_waypoint.y])

        for v in v_candidates:
            for w in w_candidates:
                # Forward simulate trajectory
                points: List[TrajectoryPoint] = []
                x, y, yaw = current_pose.x, current_pose.y, current_pose.yaw
                t = 0.0
                is_safe = True
                rejection_reason = None
                min_obstacle_dist = float('inf')

                for step in range(steps):
                    # Unicycle kinematic model update
                    x += v * np.cos(yaw) * self.dt
                    y += v * np.sin(yaw) * self.dt
                    yaw += w * self.dt
                    t += self.dt

                    # Curvature kappa = w / v
                    curvature = float(w / v) if v > 1e-3 else 0.0

                    # Check costmap cell
                    cell_cost = costmap.get_cost_at(x, y)
                    if cell_cost >= 253:
                        is_safe = False
                        rejection_reason = f"Lethal collision at step {step} (t={t:.2f}s, cost={cell_cost})"
                        break

                    points.append(TrajectoryPoint(
                        timestamp_sec=t,
                        x=float(x),
                        y=float(y),
                        yaw=float(yaw),
                        v_linear=float(v),
                        v_angular=float(w),
                        a_linear=float((v - current_vel.vx) / max(0.01, t)),
                        curvature=curvature
                    ))

                if not is_safe or len(points) == 0:
                    rejected_candidates.append({
                        "v": float(v),
                        "w": float(w),
                        "reason": rejection_reason or "Unknown collision",
                        "points_count": len(points)
                    })
                    continue

                # Multi-objective scoring
                final_pt = points[-1]
                dist_to_goal = float(np.linalg.norm(np.array([final_pt.x, final_pt.y]) - target_pos))
                goal_score = -dist_to_goal

                # Obstacle clearance score
                avg_cost = np.mean([costmap.get_cost_at(p.x, p.y) for p in points])
                obstacle_score = -(avg_cost / 254.0)

                # Smoothness score (penalize large angular rate change)
                smooth_score = -abs(w - current_vel.wz)

                # Progress score
                heading_to_goal = np.arctan2(target_pos[1] - current_pose.y, target_pos[0] - current_pose.x)
                heading_err = abs((final_pt.yaw - heading_to_goal + np.pi) % (2 * np.pi) - np.pi)
                progress_score = -heading_err

                total_score = (
                    self.w_goal * goal_score +
                    self.w_obstacle * obstacle_score +
                    self.w_smooth * smooth_score +
                    self.w_vel * (v / self.max_v) +
                    self.w_progress * progress_score
                )

                candidate_meta = {
                    "v": float(v),
                    "w": float(w),
                    "score": float(total_score),
                    "goal_score": float(goal_score),
                    "obstacle_score": float(obstacle_score),
                    "smooth_score": float(smooth_score),
                    "progress_score": float(progress_score),
                    "points": points
                }
                ranked_candidates.append(candidate_meta)

                if total_score > best_score:
                    best_score = total_score
                    best_trajectory = Trajectory(
                        points=points,
                        duration_sec=self.horizon,
                        is_feasible=True
                    )

        ranked_candidates.sort(key=lambda c: c["score"], reverse=True)
        return best_trajectory, ranked_candidates[:10], rejected_candidates
