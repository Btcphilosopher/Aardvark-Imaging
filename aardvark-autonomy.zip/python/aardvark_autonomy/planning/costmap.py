"""
Aardvark Autonomy - Layered Costmap Engine
Phase 16: Static, Obstacle, Inflation, Dynamic & Semantic Costmap Layers
"""

import numpy as np
from typing import List, Optional, Tuple, Dict, Any
from aardvark_autonomy.core.types import TrackedObject, WorldEntity, Pose


class CostmapLayer:
    def __init__(self, cols: int, rows: int, resolution: float, origin_x: float, origin_y: float):
        self.cols = cols
        self.rows = rows
        self.resolution = resolution
        self.origin_x = origin_x
        self.origin_y = origin_y
        self.costs = np.zeros((rows, cols), dtype=np.uint8)

    def world_to_grid(self, wx: float, wy: float) -> Optional[Tuple[int, int]]:
        gx = int((wx - self.origin_x) / self.resolution)
        gy = int((wy - self.origin_y) / self.resolution)
        if 0 <= gx < self.cols and 0 <= gy < self.rows:
            return gx, gy
        return None


class StaticCostmap(CostmapLayer):
    def update_from_entities(self, entities: List[WorldEntity]) -> None:
        self.costs.fill(0)
        for entity in entities:
            if not entity.is_static:
                continue
            coords = entity.coordinates
            if len(coords) >= 4:
                # Fill axis-aligned or bounding polygon
                xs = [c[0] for c in coords]
                ys = [c[1] for c in coords]
                g_min = self.world_to_grid(min(xs), min(ys))
                g_max = self.world_to_grid(max(xs), max(ys))
                if g_min and g_max:
                    self.costs[g_min[1]:g_max[1]+1, g_min[0]:g_max[0]+1] = 253 # Lethal wall/obstacle


class DynamicObstacleLayer(CostmapLayer):
    def update_from_tracks(self, tracks: List[TrackedObject]) -> None:
        self.costs.fill(0)
        for track in tracks:
            tx, ty = track.position[0], track.position[1]
            # Dimensions
            radius = max(0.4, max(track.dimensions[0], track.dimensions[1]) / 2.0)
            grid_r = int(np.ceil(radius / self.resolution))
            center = self.world_to_grid(tx, ty)
            if not center:
                continue
            cx, cy = center
            for dy in range(-grid_r, grid_r + 1):
                for dx in range(-grid_r, grid_r + 1):
                    if dx*dx + dy*dy <= grid_r*grid_r:
                        gx, gy = cx + dx, cy + dy
                        if 0 <= gx < self.cols and 0 <= gy < self.rows:
                            self.costs[gy, gx] = 253 # Dynamic obstacle lethal


class InflationLayer(CostmapLayer):
    def __init__(self, cols: int, rows: int, resolution: float, origin_x: float, origin_y: float, inflation_radius: float = 0.8, cost_scale: float = 3.0):
        super().__init__(cols, rows, resolution, origin_x, origin_y)
        self.inflation_radius = inflation_radius
        self.cost_scale = cost_scale

    def compute_inflation(self, lethal_layer: np.ndarray) -> None:
        self.costs.fill(0)
        lethal_y, lethal_x = np.where(lethal_layer == 253)
        if len(lethal_x) == 0:
            return

        r_cells = int(np.ceil(self.inflation_radius / self.resolution))

        # Precompute kernel decay
        kernel = np.zeros((2*r_cells+1, 2*r_cells+1), dtype=np.uint8)
        for dy in range(-r_cells, r_cells + 1):
            for dx in range(-r_cells, r_cells + 1):
                dist = np.sqrt(dx*dx + dy*dy) * self.resolution
                if dist == 0.0:
                    kernel[dy + r_cells, dx + r_cells] = 253
                elif dist <= self.inflation_radius:
                    # Exponential cost decay: 253 * exp(-scale * (dist - robot_radius))
                    cost = int(252 * np.exp(-self.cost_scale * dist / self.inflation_radius))
                    kernel[dy + r_cells, dx + r_cells] = max(1, cost)

        for lx, ly in zip(lethal_x, lethal_y):
            min_y = max(0, ly - r_cells)
            max_y = min(self.rows, ly + r_cells + 1)
            min_x = max(0, lx - r_cells)
            max_x = min(self.cols, lx + r_cells + 1)

            k_min_y = min_y - (ly - r_cells)
            k_max_y = k_min_y + (max_y - min_y)
            k_min_x = min_x - (lx - r_cells)
            k_max_x = k_min_x + (max_x - min_x)

            sub_kernel = kernel[k_min_y:k_max_y, k_min_x:k_max_x]
            self.costs[min_y:max_y, min_x:max_x] = np.maximum(
                self.costs[min_y:max_y, min_x:max_x], sub_kernel
            )


class MasterCostmap:
    def __init__(self, width_m: float = 40.0, height_m: float = 40.0, resolution_m: float = 0.10, origin_x: float = -20.0, origin_y: float = -20.0):
        self.cols = int(width_m / resolution_m)
        self.rows = int(height_m / resolution_m)
        self.resolution = resolution_m
        self.origin_x = origin_x
        self.origin_y = origin_y

        self.static_layer = StaticCostmap(self.cols, self.rows, resolution_m, origin_x, origin_y)
        self.dynamic_layer = DynamicObstacleLayer(self.cols, self.rows, resolution_m, origin_x, origin_y)
        self.inflation_layer = InflationLayer(self.cols, self.rows, resolution_m, origin_x, origin_y)
        self.master_grid = np.zeros((self.rows, self.cols), dtype=np.uint8)

    def update(self, entities: List[WorldEntity], tracks: List[TrackedObject]) -> None:
        self.static_layer.update_from_entities(entities)
        self.dynamic_layer.update_from_tracks(tracks)

        combined_lethal = np.maximum(self.static_layer.costs, self.dynamic_layer.costs)
        self.inflation_layer.compute_inflation(combined_lethal)

        # Merge layers
        self.master_grid = np.maximum(combined_lethal, self.inflation_layer.costs)

    def get_cost_at(self, wx: float, wy: float) -> int:
        gx = int((wx - self.origin_x) / self.resolution)
        gy = int((wy - self.origin_y) / self.resolution)
        if 0 <= gx < self.cols and 0 <= gy < self.rows:
            return int(self.master_grid[gy, gx])
        return 254 # Unknown / out of bounds

    def is_lethal(self, wx: float, wy: float) -> bool:
        return self.get_cost_at(wx, wy) >= 253
