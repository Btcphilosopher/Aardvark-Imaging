"""
Aardvark Autonomy - A* Global Path Planner
Phase 17: 8-Connected Grid Search with Turn Penalties & Costmap Traversal Weighting
"""

import heapq
import time
import numpy as np
from typing import List, Tuple, Optional, Dict
from aardvark_autonomy.core.types import Path, Waypoint, Pose
from aardvark_autonomy.planning.costmap import MasterCostmap


class AStarPlanner:
    def __init__(
        self,
        heuristic_type: str = "euclidean",
        turn_penalty_weight: float = 1.2,
        costmap_weight: float = 0.05,
        unknown_penalty: float = 50.0
    ):
        self.heuristic_type = heuristic_type
        self.turn_penalty_weight = turn_penalty_weight
        self.costmap_weight = costmap_weight
        self.unknown_penalty = unknown_penalty
        self.planner_id = "AStar-8Way-v1.0"

    def _heuristic(self, x1: int, y1: int, x2: int, y2: int) -> float:
        dx = abs(x1 - x2)
        dy = abs(y1 - y2)
        if self.heuristic_type == "euclidean":
            return np.sqrt(dx*dx + dy*dy)
        elif self.heuristic_type == "diagonal":
            return (dx + dy) + (np.sqrt(2.0) - 2.0) * min(dx, dy)
        else: # Manhattan
            return float(dx + dy)

    def plan(self, start_pose: Pose, goal_pose: Pose, costmap: MasterCostmap) -> Optional[Path]:
        t0 = time.perf_counter()

        start_gx = int((start_pose.x - costmap.origin_x) / costmap.resolution)
        start_gy = int((start_pose.y - costmap.origin_y) / costmap.resolution)
        goal_gx = int((goal_pose.x - costmap.origin_x) / costmap.resolution)
        goal_gy = int((goal_pose.y - costmap.origin_y) / costmap.resolution)

        if not (0 <= start_gx < costmap.cols and 0 <= start_gy < costmap.rows):
            return None
        if not (0 <= goal_gx < costmap.cols and 0 <= goal_gy < costmap.rows):
            return None

        # If goal is directly in lethal obstacle, find closest free cell
        if costmap.master_grid[goal_gy, goal_gx] >= 253:
            found = False
            for r in range(1, 10):
                for dy in range(-r, r + 1):
                    for dx in range(-r, r + 1):
                        ngx, ngy = goal_gx + dx, goal_gy + dy
                        if 0 <= ngx < costmap.cols and 0 <= ngy < costmap.rows:
                            if costmap.master_grid[ngy, ngx] < 253:
                                goal_gx, goal_gy = ngx, ngy
                                found = True
                                break
                    if found:
                        break
                if found:
                    break

        # Priority queue item: (f_score, g_score, (gx, gy), prev_direction)
        # 8-connected neighbor offsets and step costs: (dx, dy, base_cost)
        neighbors = [
            (1, 0, 1.0), (-1, 0, 1.0), (0, 1, 1.0), (0, -1, 1.0),
            (1, 1, 1.4142), (-1, 1, 1.4142), (1, -1, 1.4142), (-1, -1, 1.4142)
        ]

        open_set: List[Tuple[float, float, int, int, Optional[Tuple[int, int]]]] = []
        heapq.heappush(open_set, (self._heuristic(start_gx, start_gy, goal_gx, goal_gy), 0.0, start_gx, start_gy, None))

        came_from: Dict[Tuple[int, int], Tuple[int, int]] = {}
        g_scores: Dict[Tuple[int, int], float] = {(start_gx, start_gy): 0.0}

        max_iterations = 15000
        iterations = 0

        while open_set and iterations < max_iterations:
            iterations += 1
            f, g, cx, cy, prev_dir = heapq.heappop(open_set)

            if cx == goal_gx and cy == goal_gy:
                # Reconstruct path
                path_grid = [(cx, cy)]
                curr = (cx, cy)
                while curr in came_from:
                    curr = came_from[curr]
                    path_grid.append(curr)
                path_grid.reverse()

                # Convert grid path to world Waypoints with smoothing
                waypoints: List[Waypoint] = []
                total_length = 0.0

                for i, (gx, gy) in enumerate(path_grid):
                    # Subsample path every 3 cells for smooth waypoints
                    if i > 0 and i < len(path_grid) - 1 and i % 3 != 0:
                        continue
                    wx = costmap.origin_x + (gx + 0.5) * costmap.resolution
                    wy = costmap.origin_y + (gy + 0.5) * costmap.resolution

                    if waypoints:
                        dx = wx - waypoints[-1].x
                        dy = wy - waypoints[-1].y
                        yaw = float(np.arctan2(dy, dx))
                        waypoints[-1].yaw = yaw
                        total_length += np.sqrt(dx*dx + dy*dy)
                    else:
                        yaw = start_pose.yaw

                    waypoints.append(Waypoint(
                        id=f"wp_{i}",
                        x=float(wx),
                        y=float(wy),
                        yaw=yaw,
                        target_speed=1.0,
                        tolerance_radius=0.3
                    ))

                if len(waypoints) > 1:
                    waypoints[-1].yaw = goal_pose.yaw

                planning_time_ms = (time.perf_counter() - t0) * 1000.0

                return Path(
                    waypoints=waypoints,
                    total_cost=float(g),
                    total_length=float(total_length),
                    planning_time_ms=float(planning_time_ms),
                    planner_id=self.planner_id,
                    map_version=1
                )

            for dx, dy, step_cost in neighbors:
                nx, ny = cx + dx, cy + dy
                if not (0 <= nx < costmap.cols and 0 <= ny < costmap.rows):
                    continue

                cell_cost = costmap.master_grid[ny, nx]
                if cell_cost >= 253: # Lethal
                    continue

                traversal_cost = step_cost + (cell_cost * self.costmap_weight)
                if cell_cost == 254: # Unknown penalty
                    traversal_cost += self.unknown_penalty

                # Add turn penalty
                curr_dir = (dx, dy)
                if prev_dir and prev_dir != curr_dir:
                    traversal_cost += self.turn_penalty_weight

                tentative_g = g + traversal_cost
                if (nx, ny) not in g_scores or tentative_g < g_scores[(nx, ny)]:
                    g_scores[(nx, ny)] = tentative_g
                    f_score = tentative_g + self._heuristic(nx, ny, goal_gx, goal_gy)
                    came_from[(nx, ny)] = (cx, cy)
                    heapq.heappush(open_set, (f_score, tentative_g, nx, ny, curr_dir))

        return None
