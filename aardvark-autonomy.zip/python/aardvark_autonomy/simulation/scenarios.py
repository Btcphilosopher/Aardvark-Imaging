"""
Aardvark Autonomy - 15 Deterministic Test Scenarios
Phase 48: Standardized Benchmark & Verification Scenarios
"""

from typing import Dict, Any, List
from aardvark_autonomy.core.types import WorldEntity, Pose, CoordinateFrame


def get_scenario_definition(scenario_id: str) -> Dict[str, Any]:
    scenarios: Dict[str, Dict[str, Any]] = {
        "SCENARIO_01_EMPTY_ROOM": {
            "name": "Empty Room",
            "description": "Baseline navigation in unbounded room without obstacles",
            "robot_start": Pose(x=-5.0, y=-5.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "goal": Pose(x=5.0, y=5.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "entities": [
                WorldEntity(id="wall_north", entity_type="wall", geometry_type="polygon", coordinates=[[-10, 10], [10, 10], [10, 9.8], [-10, 9.8]], is_static=True),
                WorldEntity(id="wall_south", entity_type="wall", geometry_type="polygon", coordinates=[[-10, -9.8], [10, -9.8], [10, -10], [-10, -10]], is_static=True),
                WorldEntity(id="wall_east", entity_type="wall", geometry_type="polygon", coordinates=[[9.8, -10], [10, -10], [10, 10], [9.8, 10]], is_static=True),
                WorldEntity(id="wall_west", entity_type="wall", geometry_type="polygon", coordinates=[[-10, -10], [-9.8, -10], [-9.8, 10], [-10, 10]], is_static=True),
            ]
        },
        "SCENARIO_02_CORRIDOR": {
            "name": "Narrow Corridor",
            "description": "Straight navigation down a 1.2m confined aisle",
            "robot_start": Pose(x=-8.0, y=0.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "goal": Pose(x=8.0, y=0.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "entities": [
                WorldEntity(id="corridor_top", entity_type="wall", geometry_type="polygon", coordinates=[[-10, 0.8], [10, 0.8], [10, 1.2], [-10, 1.2]], is_static=True),
                WorldEntity(id="corridor_bot", entity_type="wall", geometry_type="polygon", coordinates=[[-10, -1.2], [10, -1.2], [10, -0.8], [-10, -0.8]], is_static=True),
            ]
        },
        "SCENARIO_03_STATIC_OBSTACLES": {
            "name": "Static Obstacles (Warehouse Pillars)",
            "description": "Maze of pallets and structural support pillars",
            "robot_start": Pose(x=-8.0, y=-8.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "goal": Pose(x=8.0, y=8.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "entities": [
                WorldEntity(id="pillar_1", entity_type="pillar", geometry_type="box", coordinates=[[-4.0, -4.0], [-3.0, -4.0], [-3.0, -3.0], [-4.0, -3.0]], is_static=True),
                WorldEntity(id="pillar_2", entity_type="pillar", geometry_type="box", coordinates=[[0.0, -1.0], [1.0, -1.0], [1.0, 0.0], [0.0, 0.0]], is_static=True),
                WorldEntity(id="pallet_1", entity_type="pallet", geometry_type="box", coordinates=[[3.0, 3.0], [5.0, 3.0], [5.0, 4.0], [3.0, 4.0]], is_static=True),
                WorldEntity(id="pallet_2", entity_type="pallet", geometry_type="box", coordinates=[[-2.0, 3.0], [-1.0, 3.0], [-1.0, 5.0], [-2.0, 5.0]], is_static=True),
            ]
        },
        "SCENARIO_04_DYNAMIC_PEDESTRIANS": {
            "name": "Dynamic Pedestrians",
            "description": "Warehouse workers crossing the active path orthogonally",
            "robot_start": Pose(x=-7.0, y=0.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "goal": Pose(x=7.0, y=0.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "entities": [
                WorldEntity(id="pedestrian_01", entity_type="pedestrian", geometry_type="box", coordinates=[[0.0, -3.0], [0.6, -3.0], [0.6, -2.4], [0.0, -2.4]], is_static=False, metadata={"vx": 0.0, "vy": 0.6, "y_min": -4.0, "y_max": 4.0}),
                WorldEntity(id="pedestrian_02", entity_type="pedestrian", geometry_type="box", coordinates=[[3.5, 3.0], [4.1, 3.0], [4.1, 3.6], [3.5, 3.6]], is_static=False, metadata={"vx": 0.0, "vy": -0.5, "y_min": -4.0, "y_max": 4.0}),
            ]
        },
        "SCENARIO_05_NARROW_PASSAGE": {
            "name": "Narrow Passage (Doorway)",
            "description": "High precision navigation through a 0.9m doorway",
            "robot_start": Pose(x=-4.0, y=0.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "goal": Pose(x=4.0, y=0.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "entities": [
                WorldEntity(id="wall_door_left", entity_type="wall", geometry_type="polygon", coordinates=[[0.0, 0.55], [0.0, 8.0], [0.4, 8.0], [0.4, 0.55]], is_static=True),
                WorldEntity(id="wall_door_right", entity_type="wall", geometry_type="polygon", coordinates=[[0.0, -8.0], [0.0, -0.55], [0.4, -0.55], [0.4, -8.0]], is_static=True),
            ]
        },
        "SCENARIO_06_GPS_UNAVAILABLE": {
            "name": "GPS Unavailable",
            "description": "Indoor GNSS outage forcing pure LiDAR scan-matching and EKF dead reckoning",
            "robot_start": Pose(x=-6.0, y=-6.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "goal": Pose(x=6.0, y=6.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "fault_injections": ["GPS_OUTAGE"],
            "entities": []
        },
        "SCENARIO_07_LIDAR_UNAVAILABLE": {
            "name": "LiDAR Unavailable",
            "description": "Primary LiDAR hardware timeout triggering degraded camera vision & safe stop",
            "robot_start": Pose(x=-5.0, y=0.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "goal": Pose(x=5.0, y=0.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "fault_injections": ["LIDAR_FAULT"],
            "entities": []
        },
        "SCENARIO_08_CAMERA_UNAVAILABLE": {
            "name": "Camera Vision Unavailable",
            "description": "Camera sensor dropout with LiDAR fallback",
            "robot_start": Pose(x=-5.0, y=0.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "goal": Pose(x=5.0, y=0.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "fault_injections": ["CAMERA_FAULT"],
            "entities": []
        },
        "SCENARIO_09_LOCALIZATION_DEGRADATION": {
            "name": "Localization Degradation",
            "description": "Wheel slip inducing covariance blowup and Safety Supervisor velocity throttling",
            "robot_start": Pose(x=-6.0, y=0.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "goal": Pose(x=6.0, y=0.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "fault_injections": ["HIGH_WHEEL_SLIP"],
            "entities": []
        },
        "SCENARIO_10_BLOCKED_GOAL": {
            "name": "Blocked Goal Re-routing",
            "description": "Direct goal point obstructed by dropped crate, requiring global replan",
            "robot_start": Pose(x=-6.0, y=0.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "goal": Pose(x=6.0, y=0.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "entities": [
                WorldEntity(id="dropped_crate", entity_type="crate", geometry_type="box", coordinates=[[5.6, -0.5], [6.4, -0.5], [6.4, 0.5], [5.6, 0.5]], is_static=True)
            ]
        },
        "SCENARIO_11_MOVING_OBSTACLE": {
            "name": "Moving Autonomous Forklift",
            "description": "Fast-moving AGV forklift yielding right-of-way",
            "robot_start": Pose(x=-7.0, y=0.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "goal": Pose(x=7.0, y=0.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "entities": [
                WorldEntity(id="agv_forklift", entity_type="vehicle", geometry_type="box", coordinates=[[6.0, -0.5], [7.5, -0.5], [7.5, 0.5], [6.0, 0.5]], is_static=False, metadata={"vx": -0.8, "vy": 0.0})
            ]
        },
        "SCENARIO_12_MULTIPLE_ROBOTS": {
            "name": "Multi-Robot Fleet Interaction",
            "description": "Two collaborative robots navigating shared intersection",
            "robot_start": Pose(x=-8.0, y=0.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "goal": Pose(x=8.0, y=0.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "entities": [
                WorldEntity(id="robot_beta", entity_type="robot", geometry_type="box", coordinates=[[0.0, -6.0], [0.8, -6.0], [0.8, -5.2], [0.0, -5.2]], is_static=False, metadata={"vx": 0.0, "vy": 0.7})
            ]
        },
        "SCENARIO_13_LARGE_OUTDOOR_MAP": {
            "name": "Large Outdoor Surveying Map",
            "description": "40m x 40m wide exploration with RTK GPS integration",
            "robot_start": Pose(x=-15.0, y=-15.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "goal": Pose(x=15.0, y=15.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "entities": []
        },
        "SCENARIO_14_HIGH_SENSOR_LOAD": {
            "name": "High Sensor Load Benchmark",
            "description": "32-beam 50Hz LiDAR with maximum point generation rate",
            "robot_start": Pose(x=-5.0, y=-5.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "goal": Pose(x=5.0, y=5.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "entities": []
        },
        "SCENARIO_15_PLANNER_FAILURE_RECOVERY": {
            "name": "Planner Failure Recovery",
            "description": "Complete cul-de-sac entrapment triggering Behavior Tree recovery spin",
            "robot_start": Pose(x=0.0, y=0.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "goal": Pose(x=8.0, y=8.0, z=0.0, frame_id=CoordinateFrame.MAP),
            "entities": [
                WorldEntity(id="box_culdesac_1", entity_type="wall", geometry_type="polygon", coordinates=[[2.0, -2.0], [2.0, 2.0], [2.4, 2.0], [2.4, -2.0]], is_static=True),
                WorldEntity(id="box_culdesac_2", entity_type="wall", geometry_type="polygon", coordinates=[[-2.0, 2.0], [2.0, 2.0], [2.0, 2.4], [-2.0, 2.4]], is_static=True),
                WorldEntity(id="box_culdesac_3", entity_type="wall", geometry_type="polygon", coordinates=[[-2.0, -2.0], [2.0, -2.0], [2.0, -1.6], [-2.0, -1.6]], is_static=True),
            ]
        }
    }
    return scenarios.get(scenario_id, scenarios["SCENARIO_03_STATIC_OBSTACLES"])
