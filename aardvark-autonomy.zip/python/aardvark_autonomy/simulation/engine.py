"""
Aardvark Autonomy - Closed-Loop Autonomy Simulator & Digital Twin Engine
Phase 21, 27, 29 & 30: Deterministic Sensor-to-Action Simulation & Record/Replay Engine
"""

import time
import numpy as np
from typing import Dict, Any, List, Optional
from aardvark_autonomy.core.types import (
    Pose,
    Velocity,
    Acceleration,
    SensorConfiguration,
    CoordinateFrame,
    Transform,
    Timestamp,
    MissionStatus,
    MissionGoal,
    AutonomyState,
    QualityState,
)
from aardvark_autonomy.sensors.synthetic_lidar import SimulatedLidar
from aardvark_autonomy.sensors.synthetic_imu import SimulatedIMU
from aardvark_autonomy.sensors.synthetic_gps import SimulatedGPS
from aardvark_autonomy.sensors.synthetic_odometry import SimulatedWheelEncoder
from aardvark_autonomy.sensors.synthetic_camera import SimulatedCamera
from aardvark_autonomy.perception.lidar_pipeline import LidarPipeline
from aardvark_autonomy.fusion.ekf_engine import FusionEngine
from aardvark_autonomy.tracking.multi_object_tracker import MultiObjectTracker
from aardvark_autonomy.mapping.occupancy_grid import OccupancyGridMap
from aardvark_autonomy.planning.costmap import MasterCostmap
from aardvark_autonomy.planning.astar_planner import AStarPlanner
from aardvark_autonomy.planning.local_planner import LocalTrajectoryEvaluator
from aardvark_autonomy.safety.supervisor import SafetySupervisor
from aardvark_autonomy.control.pure_pursuit import PurePursuitController
from aardvark_autonomy.behavior.engine import BehaviorTreeEngine
from aardvark_autonomy.missions.engine import MissionEngine
from aardvark_autonomy.simulation.scenarios import get_scenario_definition


class AutonomySimulationEngine:
    def __init__(self, scenario_id: str = "SCENARIO_03_STATIC_OBSTACLES", seed: int = 42):
        self.scenario_id = scenario_id
        self.seed = seed
        self.rng = np.random.default_rng(seed)
        self.dt = 0.05
        self.sim_time = 0.0
        self.is_paused = False
        self.autonomy_state = AutonomyState.AUTONOMOUS

        # Load Scenario
        self.scenario = get_scenario_definition(scenario_id)
        self.world_entities = [e.dict() for e in self.scenario["entities"]]

        # Ground-Truth Robot State
        start_pose: Pose = self.scenario["robot_start"]
        self.true_x = start_pose.x
        self.true_y = start_pose.y
        self.true_z = start_pose.z
        self.true_yaw = start_pose.yaw
        self.true_v = 0.0
        self.true_w = 0.0

        # Sensor Configurations
        dummy_transform = Transform(
            source_frame=CoordinateFrame.LIDAR_LINK,
            target_frame=CoordinateFrame.BASE_LINK,
            matrix_4x4=np.eye(4).tolist(),
            timestamp=Timestamp.now()
        )

        lidar_cfg = SensorConfiguration(
            sensor_id="lidar_01",
            sensor_type="lidar_3d",
            frame_id=CoordinateFrame.LIDAR_LINK,
            rate_hz=20.0,
            extrinsics_to_base=dummy_transform,
            intrinsics={"num_lasers": 16, "horizontal_fov_deg": 360.0, "horizontal_resolution_deg": 2.0},
            noise_parameters={"range_noise_sigma_m": 0.015}
        )
        imu_cfg = SensorConfiguration(
            sensor_id="imu_01",
            sensor_type="imu_6dof",
            frame_id=CoordinateFrame.IMU_LINK,
            rate_hz=100.0,
            extrinsics_to_base=dummy_transform
        )
        gps_cfg = SensorConfiguration(
            sensor_id="gps_01",
            sensor_type="gnss_rtk",
            frame_id=CoordinateFrame.GPS_LINK,
            rate_hz=10.0,
            extrinsics_to_base=dummy_transform
        )
        odom_cfg = SensorConfiguration(
            sensor_id="odom_01",
            sensor_type="wheel_encoders",
            frame_id=CoordinateFrame.ODOM,
            rate_hz=50.0,
            extrinsics_to_base=dummy_transform
        )
        cam_cfg = SensorConfiguration(
            sensor_id="cam_01",
            sensor_type="rgbd_camera",
            frame_id=CoordinateFrame.CAMERA_LINK,
            rate_hz=30.0,
            extrinsics_to_base=dummy_transform
        )

        # Instantiate Autonomy Pipelines
        self.lidar = SimulatedLidar(lidar_cfg, seed=seed)
        self.imu = SimulatedIMU(imu_cfg, seed=seed)
        self.gps = SimulatedGPS(gps_cfg, seed=seed)
        self.odom = SimulatedWheelEncoder(odom_cfg, seed=seed)
        self.camera = SimulatedCamera(cam_cfg, seed=seed)

        self.lidar.start()
        self.imu.start()
        self.gps.start()
        self.odom.start()
        self.camera.start()

        self.lidar_pipeline = LidarPipeline()
        self.ekf = FusionEngine()
        self.ekf.reset(start_pose)
        self.tracker = MultiObjectTracker()
        self.occupancy_map = OccupancyGridMap()
        self.costmap = MasterCostmap()
        self.global_planner = AStarPlanner()
        self.local_evaluator = LocalTrajectoryEvaluator()
        self.safety_supervisor = SafetySupervisor()
        self.controller = PurePursuitController()
        self.behavior_tree = BehaviorTreeEngine()
        self.mission_engine = MissionEngine()

        # Initialize Default Mission
        goal_pose: Pose = self.scenario["goal"]
        self.mission = self.mission_engine.create_mission(
            goals=[MissionGoal(goal_id="g1", goal_type="waypoint_nav", target_pose=goal_pose, tolerance_m=0.35)]
        )
        self.mission_engine.start_mission()

        # Cached outputs for telemetry & explainability
        self.latest_scan = None
        self.latest_cloud = None
        self.latest_detections = []
        self.latest_tracks = []
        self.global_path = None
        self.active_trajectory = None
        self.ranked_candidates = []
        self.rejected_candidates = []
        self.last_safety_decision = None
        self.last_command = None
        self.recorded_frames: List[Dict[str, Any]] = []

    def get_ground_truth_pose(self) -> Pose:
        from aardvark_autonomy.core.transforms import euler_to_quaternion
        qx, qy, qz, qw = euler_to_quaternion(0.0, 0.0, self.true_yaw)
        return Pose(
            x=float(self.true_x),
            y=float(self.true_y),
            z=float(self.true_z),
            qx=float(qx),
            qy=float(qy),
            qz=float(qz),
            qw=float(qw),
            frame_id=CoordinateFrame.MAP
        )

    def step(self) -> Dict[str, Any]:
        """Execute one complete deterministic tick of the closed-loop autonomy pipeline."""
        if self.is_paused:
            return self.get_telemetry_snapshot()

        self.sim_time += self.dt

        # 1. Update Dynamic World Entities (e.g. Pedestrians, moving AGVs)
        for entity in self.world_entities:
            meta = entity.get("metadata", {})
            vx = meta.get("vx", 0.0)
            vy = meta.get("vy", 0.0)
            if vx != 0.0 or vy != 0.0:
                for coord in entity["coordinates"]:
                    coord[0] += vx * self.dt
                    coord[1] += vy * self.dt
                # Bounce on bounds if specified
                if "y_min" in meta and "y_max" in meta:
                    y_avg = np.mean([c[1] for c in entity["coordinates"]])
                    if y_avg < meta["y_min"] or y_avg > meta["y_max"]:
                        meta["vy"] = -meta["vy"]

        # 2. SENSOR SIMULATION
        gt_pose = self.get_ground_truth_pose()
        raw_scan = self.lidar.read(self.world_entities, gt_pose)
        self.latest_scan = raw_scan

        class DynamicsObj:
            ax = 0.0
            ay = 0.0
            az = 0.0
            wx = 0.0
            wy = 0.0
            wz = self.true_w
            linear_velocity = self.true_v
            angular_velocity = self.true_w
            dt = self.dt

        dyn = DynamicsObj()
        imu_meas = self.imu.read(dyn, gt_pose)
        gps_meas = self.gps.read(gt_pose)
        odom_meas = self.odom.read(dyn, gt_pose)
        cam_dets = self.camera.detect_visible_objects(self.world_entities, gt_pose)

        # 3. PERCEPTION PIPELINE
        voxel_cloud = self.lidar_pipeline.voxel_downsample(raw_scan)
        filtered_cloud = self.lidar_pipeline.remove_statistical_outliers(voxel_cloud)
        ground_cloud, obstacle_cloud = self.lidar_pipeline.segment_ground_and_obstacles(filtered_cloud)
        lidar_dets = self.lidar_pipeline.cluster_obstacles(obstacle_cloud)
        all_dets = lidar_dets + cam_dets
        self.latest_detections = all_dets
        self.latest_cloud = obstacle_cloud

        # 4. OBJECT TRACKING
        self.latest_tracks = self.tracker.update(all_dets, dt=self.dt)

        # 5. LOCALISATION & SENSOR FUSION (EKF)
        self.ekf.predict(imu_meas, dt=self.dt)
        self.ekf.update_odometry(odom_meas)
        self.ekf.update_gps(gps_meas)
        fused_pose = self.ekf.get_fused_pose()
        fused_vel = self.ekf.get_fused_velocity()

        # 6. MAPPING & MULTI-LAYER COSTMAP
        self.occupancy_map.update_with_scan(fused_pose, obstacle_cloud)
        from aardvark_autonomy.core.types import WorldEntity
        entity_objs = [WorldEntity(**e) for e in self.world_entities]
        self.costmap.update(entity_objs, self.latest_tracks)

        # 7. MISSION ENGINE PROGRESS
        self.mission_engine.update_progress(fused_pose)
        active_goal = self.mission_engine.get_active_goal()

        # 8. BEHAVIOUR TREE TICK
        bt_context = {
            "localisation_quality": self.ekf.quality_state,
            "min_obstacle_dist": min([np.linalg.norm(np.array([t.position[0]-fused_pose.x, t.position[1]-fused_pose.y])) for t in self.latest_tracks] or [5.0]),
            "goal_reached": active_goal is None,
            "has_active_trajectory": self.active_trajectory is not None,
            "needs_replan": False
        }
        self.behavior_tree.tick(bt_context)

        # 9. GLOBAL & LOCAL PLANNING
        if active_goal and (self.global_path is None or bt_context.get("needs_replan", False)):
            self.global_path = self.global_planner.plan(fused_pose, active_goal.target_pose, self.costmap)

        if self.global_path and self.global_path.waypoints:
            # Pick active lookahead waypoint
            target_wp = self.global_path.waypoints[min(3, len(self.global_path.waypoints)-1)]
            best_traj, ranked, rejected = self.local_evaluator.evaluate(
                fused_pose, fused_vel, target_wp, self.costmap
            )
            self.active_trajectory = best_traj
            self.ranked_candidates = ranked
            self.rejected_candidates = rejected

        # 10. SAFETY SUPERVISOR VALIDATION
        safety_dec = self.safety_supervisor.validate_trajectory(
            self.active_trajectory,
            fused_pose,
            fused_vel,
            self.ekf.quality_state,
            self.costmap,
            self.latest_tracks,
            last_telemetry_age_sec=0.01
        )
        self.last_safety_decision = safety_dec

        # 11. CONTROL OR SAFE STOP
        if safety_dec.approved and self.active_trajectory:
            cmd = self.controller.compute_command(fused_pose, fused_vel, self.active_trajectory, dt=self.dt)
            self.last_command = cmd
            # Apply control to simulated unicycle robot kinematics
            self.true_v = cmd.linear_velocity
            self.true_w = cmd.angular_velocity
        else:
            self.true_v = 0.0
            self.true_w = 0.0

        # Integrate Robot Dynamics
        self.true_x += self.true_v * np.cos(self.true_yaw) * self.dt
        self.true_y += self.true_v * np.sin(self.true_yaw) * self.dt
        self.true_yaw += self.true_w * self.dt
        self.true_yaw = (self.true_yaw + np.pi) % (2 * np.pi) - np.pi

        # 12. RECORD FRAME FOR DETERMINISTIC REPLAY
        snapshot = self.get_telemetry_snapshot()
        self.recorded_frames.append(snapshot)
        if len(self.recorded_frames) > 1000:
            self.recorded_frames.pop(0)

        return snapshot

    def get_telemetry_snapshot(self) -> Dict[str, Any]:
        fused_pose = self.ekf.get_fused_pose()
        fused_vel = self.ekf.get_fused_velocity()
        active_goal = self.mission_engine.get_active_goal()

        return {
            "sim_time": round(self.sim_time, 2),
            "autonomy_state": self.autonomy_state.value,
            "mission_status": self.mission.status.value if self.mission else "IDLE",
            "progress_percent": round(self.mission.progress_percent if self.mission else 0.0, 1),
            "robot_pose": {
                "x": round(fused_pose.x, 3),
                "y": round(fused_pose.y, 3),
                "yaw": round(fused_pose.yaw, 3),
            },
            "ground_truth_pose": {
                "x": round(self.true_x, 3),
                "y": round(self.true_y, 3),
                "yaw": round(self.true_yaw, 3),
            },
            "velocity": {
                "vx": round(fused_vel.vx, 3),
                "wz": round(fused_vel.wz, 3),
            },
            "localisation_quality": self.ekf.quality_state.value,
            "safety": {
                "approved": self.last_safety_decision.approved if self.last_safety_decision else True,
                "state": self.last_safety_decision.safety_state if self.last_safety_decision else "NOMINAL",
                "reason": self.last_safety_decision.reason if self.last_safety_decision else None,
                "min_obstacle_dist": round(self.last_safety_decision.min_obstacle_distance if self.last_safety_decision else 5.0, 2),
                "ttc": round(self.last_safety_decision.time_to_collision if self.last_safety_decision else 10.0, 2),
                "estop": self.safety_supervisor.emergency_stop_latched,
            },
            "tracks_count": len(self.latest_tracks),
            "points_count": len(self.latest_cloud.points) if self.latest_cloud else 0,
            "has_path": self.global_path is not None,
            "has_trajectory": self.active_trajectory is not None,
            "goal": {
                "x": round(active_goal.target_pose.x, 2) if active_goal else 0.0,
                "y": round(active_goal.target_pose.y, 2) if active_goal else 0.0,
            } if active_goal else None,
            "ranked_candidates_count": len(self.ranked_candidates),
            "rejected_candidates_count": len(self.rejected_candidates)
        }
