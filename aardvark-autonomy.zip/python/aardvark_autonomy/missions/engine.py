"""
Aardvark Autonomy - Mission Engine
Phase 20 & 22: Mission Lifecycle, Waypoint Sequencing & Goal Dispatcher
"""

from typing import List, Optional, Dict, Any
from aardvark_autonomy.core.types import (
    Mission,
    MissionGoal,
    MissionStatus,
    Pose,
    Timestamp,
)


class MissionEngine:
    def __init__(self, robot_id: str = "robot-alpha-01"):
        self.robot_id = robot_id
        self.current_mission: Optional[Mission] = None
        self.mission_history: List[Mission] = []

    def create_mission(self, goals: List[MissionGoal], priority: int = 1) -> Mission:
        mission = Mission(
            mission_id=f"msn_{len(self.mission_history)+1:04d}",
            robot_id=self.robot_id,
            created_at=Timestamp.now(),
            priority=priority,
            status=MissionStatus.READY,
            goals=goals,
            active_goal_index=0,
            progress_percent=0.0
        )
        self.current_mission = mission
        self.mission_history.append(mission)
        return mission

    def start_mission(self) -> bool:
        if self.current_mission and self.current_mission.status in (MissionStatus.READY, MissionStatus.PAUSED):
            self.current_mission.status = MissionStatus.RUNNING
            return True
        return False

    def pause_mission(self) -> bool:
        if self.current_mission and self.current_mission.status == MissionStatus.RUNNING:
            self.current_mission.status = MissionStatus.PAUSED
            return True
        return False

    def cancel_mission(self) -> bool:
        if self.current_mission:
            self.current_mission.status = MissionStatus.CANCELLED
            return True
        return False

    def update_progress(self, current_pose: Pose) -> None:
        if not self.current_mission or self.current_mission.status != MissionStatus.RUNNING:
            return

        goals = self.current_mission.goals
        if not goals:
            self.current_mission.status = MissionStatus.COMPLETED
            return

        idx = self.current_mission.active_goal_index
        if idx < len(goals):
            curr_goal = goals[idx]
            dist_to_goal = ((current_pose.x - curr_goal.target_pose.x)**2 + (current_pose.y - curr_goal.target_pose.y)**2)**0.5
            if dist_to_goal <= curr_goal.tolerance_m:
                curr_goal.is_reached = True
                self.current_mission.active_goal_index += 1
                if self.current_mission.active_goal_index >= len(goals):
                    self.current_mission.status = MissionStatus.COMPLETED
                    self.current_mission.progress_percent = 100.0
                else:
                    self.current_mission.progress_percent = (self.current_mission.active_goal_index / len(goals)) * 100.0

    def get_active_goal(self) -> Optional[MissionGoal]:
        if self.current_mission and self.current_mission.status == MissionStatus.RUNNING:
            idx = self.current_mission.active_goal_index
            if idx < len(self.current_mission.goals):
                return self.current_mission.goals[idx]
        return None
