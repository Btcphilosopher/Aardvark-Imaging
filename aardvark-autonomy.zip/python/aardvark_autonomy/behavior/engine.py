"""
Aardvark Autonomy - Behaviour Tree Orchestration Engine
Phase 21: Real Class-Based Hierarchical Behaviour Tree Engine
"""

from enum import Enum
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
from aardvark_autonomy.core.types import AutonomyState, MissionStatus, QualityState


class NodeStatus(str, Enum):
    SUCCESS = "SUCCESS"
    FAILURE = "FAILURE"
    RUNNING = "RUNNING"


class BehaviorNode(ABC):
    def __init__(self, name: str):
        self.name = name
        self.last_status = NodeStatus.SUCCESS

    @abstractmethod
    def tick(self, context: Dict[str, Any]) -> NodeStatus:
        pass


class SequenceNode(BehaviorNode):
    def __init__(self, name: str, children: List[BehaviorNode]):
        super().__init__(name)
        self.children = children

    def tick(self, context: Dict[str, Any]) -> NodeStatus:
        for child in self.children:
            status = child.tick(context)
            if status != NodeStatus.SUCCESS:
                self.last_status = status
                return status
        self.last_status = NodeStatus.SUCCESS
        return NodeStatus.SUCCESS


class SelectorNode(BehaviorNode):
    def __init__(self, name: str, children: List[BehaviorNode]):
        super().__init__(name)
        self.children = children

    def tick(self, context: Dict[str, Any]) -> NodeStatus:
        for child in self.children:
            status = child.tick(context)
            if status != NodeStatus.FAILURE:
                self.last_status = status
                return status
        self.last_status = NodeStatus.FAILURE
        return NodeStatus.FAILURE


# Concrete Condition & Action Nodes
class CheckLocalisationGood(BehaviorNode):
    def __init__(self):
        super().__init__("CheckLocalisationGood")

    def tick(self, context: Dict[str, Any]) -> NodeStatus:
        loc_quality = context.get("localisation_quality", QualityState.GOOD)
        if loc_quality == QualityState.GOOD:
            return NodeStatus.SUCCESS
        return NodeStatus.FAILURE


class CheckObstacleAhead(BehaviorNode):
    def __init__(self, threshold_m: float = 1.2):
        super().__init__("CheckObstacleAhead")
        self.threshold = threshold_m

    def tick(self, context: Dict[str, Any]) -> NodeStatus:
        min_obs_dist = context.get("min_obstacle_dist", 5.0)
        if min_obs_dist < self.threshold:
            return NodeStatus.SUCCESS # Obstacle is present!
        return NodeStatus.FAILURE


class TriggerReplanAction(BehaviorNode):
    def __init__(self):
        super().__init__("TriggerReplanAction")

    def tick(self, context: Dict[str, Any]) -> NodeStatus:
        context["needs_replan"] = True
        return NodeStatus.SUCCESS


class NavigatePathAction(BehaviorNode):
    def __init__(self):
        super().__init__("NavigatePathAction")

    def tick(self, context: Dict[str, Any]) -> NodeStatus:
        if context.get("goal_reached", False):
            return NodeStatus.SUCCESS
        if context.get("has_active_trajectory", False):
            return NodeStatus.RUNNING
        return NodeStatus.FAILURE


class BehaviorTreeEngine:
    def __init__(self):
        # Build Standard Warehouse Navigation Tree
        # Root: Selector (Handle E-Stop, Handle Obstacle Replan, Normal Navigate)
        self.root = SelectorNode("RootSelector", [
            SequenceNode("ObstacleAvoidanceSequence", [
                CheckObstacleAhead(threshold_m=1.2),
                TriggerReplanAction()
            ]),
            SequenceNode("StandardNavigationSequence", [
                CheckLocalisationGood(),
                NavigatePathAction()
            ])
        ])

    def tick(self, context: Dict[str, Any]) -> NodeStatus:
        return self.root.tick(context)
