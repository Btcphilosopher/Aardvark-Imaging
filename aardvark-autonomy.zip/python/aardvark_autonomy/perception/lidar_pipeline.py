"""
Aardvark Autonomy - LiDAR Perception Pipeline
Phase 7: Point cloud voxelization, statistical filtering, ground estimation & clustering
"""

import numpy as np
from typing import List, Tuple, Dict, Any
from aardvark_autonomy.core.types import (
    PointCloud,
    Point,
    DetectedObject,
    Pose,
    CoordinateFrame,
    Timestamp,
)
from aardvark_autonomy.core.transforms import transform_cloud


class LidarPipeline:
    def __init__(
        self,
        voxel_size: float = 0.08,
        ground_threshold_m: float = 0.12,
        cluster_tolerance_m: float = 0.45,
        min_cluster_size: int = 4,
        max_cluster_size: int = 500
    ):
        self.voxel_size = voxel_size
        self.ground_threshold_m = ground_threshold_m
        self.cluster_tolerance_m = cluster_tolerance_m
        self.min_cluster_size = min_cluster_size
        self.max_cluster_size = max_cluster_size

    def voxel_downsample(self, cloud: PointCloud) -> PointCloud:
        """Voxel grid downsampling preserving centroid and max intensity."""
        if not cloud.points:
            return cloud

        pts = np.array([[p.x, p.y, p.z] for p in cloud.points])
        intensities = np.array([p.intensity for p in cloud.points])

        voxel_indices = np.floor(pts / self.voxel_size).astype(np.int32)
        unique_voxels, inverse_indices = np.unique(voxel_indices, axis=0, return_inverse=True)

        downsampled_points: List[Point] = []
        for i in range(len(unique_voxels)):
            mask = (inverse_indices == i)
            centroid = np.mean(pts[mask], axis=0)
            max_intensity = float(np.max(intensities[mask]))
            downsampled_points.append(Point(
                x=float(centroid[0]),
                y=float(centroid[1]),
                z=float(centroid[2]),
                intensity=max_intensity,
                confidence=float(np.mean([cloud.points[idx].confidence for idx in np.where(mask)[0]]))
            ))

        return PointCloud(
            id=f"{cloud.id}_voxelized",
            timestamp=cloud.timestamp,
            frame_id=cloud.frame_id,
            points=downsampled_points,
            quality=cloud.quality
        )

    def remove_statistical_outliers(self, cloud: PointCloud, k_neighbors: int = 8, std_ratio: float = 1.5) -> PointCloud:
        """Filter isolated sparse sensor noise points."""
        if len(cloud.points) < k_neighbors:
            return cloud

        pts = np.array([[p.x, p.y, p.z] for p in cloud.points])
        # Simple spatial distance metric
        inliers: List[Point] = []
        for i, p in enumerate(cloud.points):
            diffs = pts - pts[i]
            dists = np.linalg.norm(diffs, axis=1)
            dists.sort()
            mean_dist = np.mean(dists[1:k_neighbors+1])
            if mean_dist < 1.2 * self.voxel_size * 10:
                inliers.append(p)

        return PointCloud(
            id=f"{cloud.id}_filtered",
            timestamp=cloud.timestamp,
            frame_id=cloud.frame_id,
            points=inliers,
            quality=cloud.quality
        )

    def segment_ground_and_obstacles(self, cloud: PointCloud) -> Tuple[PointCloud, PointCloud]:
        """RANSAC plane estimation / height thresholding for ground plane vs obstacle points."""
        ground_pts: List[Point] = []
        obstacle_pts: List[Point] = []

        for p in cloud.points:
            # In base_link or map coordinates, ground is near z <= 0.05
            if p.z < self.ground_threshold_m:
                ground_pts.append(p)
            else:
                obstacle_pts.append(p)

        ground_cloud = PointCloud(
            id=f"{cloud.id}_ground",
            timestamp=cloud.timestamp,
            frame_id=cloud.frame_id,
            points=ground_pts,
            quality=cloud.quality
        )
        obstacle_cloud = PointCloud(
            id=f"{cloud.id}_obstacles",
            timestamp=cloud.timestamp,
            frame_id=cloud.frame_id,
            points=obstacle_pts,
            quality=cloud.quality
        )
        return ground_cloud, obstacle_cloud

    def cluster_obstacles(self, obstacle_cloud: PointCloud) -> List[DetectedObject]:
        """Euclidean distance clustering into 3D bounding boxes."""
        if not obstacle_cloud.points:
            return []

        pts = np.array([[p.x, p.y, p.z] for p in obstacle_cloud.points])
        visited = np.zeros(len(pts), dtype=bool)
        clusters: List[List[int]] = []

        for i in range(len(pts)):
            if visited[i]:
                continue
            visited[i] = True
            current_cluster = [i]
            queue = [i]

            while queue:
                idx = queue.pop(0)
                diffs = pts - pts[idx]
                dists = np.linalg.norm(diffs, axis=1)
                neighbors = np.where((dists < self.cluster_tolerance_m) & (~visited))[0]
                for n in neighbors:
                    visited[n] = True
                    queue.append(n)
                    current_cluster.append(n)

            if self.min_cluster_size <= len(current_cluster) <= self.max_cluster_size:
                clusters.append(current_cluster)

        detected_objects: List[DetectedObject] = []
        for cluster_idx, indices in enumerate(clusters):
            cluster_pts = pts[indices]
            min_bound = np.min(cluster_pts, axis=0)
            max_bound = np.max(cluster_pts, axis=0)
            centroid = (min_bound + max_bound) / 2.0
            dimensions = max_bound - min_bound

            detected_objects.append(DetectedObject(
                id=f"lidar_obj_{cluster_idx}_{obstacle_cloud.id}",
                class_name="dynamic_obstacle" if dimensions[0] < 1.5 and dimensions[1] < 1.5 else "static_structure",
                confidence=float(min(0.95, 0.6 + len(indices) * 0.01)),
                pose=Pose(
                    x=float(centroid[0]),
                    y=float(centroid[1]),
                    z=float(centroid[2]),
                    frame_id=obstacle_cloud.frame_id
                ),
                dimensions=[float(max(0.3, dimensions[0])), float(max(0.3, dimensions[1])), float(max(0.3, dimensions[2]))],
                source_sensor="lidar_primary",
                timestamp=obstacle_cloud.timestamp
            ))

        return detected_objects
