"""
Aardvark Autonomy - Independent Safety Supervisor
Phase 24 & 50: Deterministic Safety Validation & Command Gating
"""

import time
import numpy as np
from typing import Optional, List, Dict, Any
from aardvark_autonomy.core.types import (
    Trajectory,
    Pose,
    Velocity,
    SafetyDecision,
    QualityState,
    Timestamp,
    TrackedObject,
)
from aardvark_autonomy.planning.costmap import MasterCostmap


class SafetySupervisor:
    def __init__(
        self,
        max_v: float = 1.5,
        max_a: float = 1.2,
        max_w: float = 1.6,
        max_curvature: float = 3.5,
        min_obstacle_distance: float = 0.35,
        critical_ttc_sec: float = 0.60,
        geofence_bounds: Optional[Tuple[float, float, float, float]] = (-19.0, 19.0, -19.0, 19.0)
    ):
        self.max_v = max_v
        self.max_a = max_a
        self.max_w = max_w
        self.max_curvature = max_curvature
        self.min_obstacle_dist = min_obstacle_distance
        self.critical_ttc = critical_ttc_sec
        self.geofence = geofence_bounds # (min_x, max_x, min_y, max_y)
        self.emergency_stop_latched = False
        self.rejected_command_count = 0
        self.audit_log: List[Dict[str, Any]] = []

    def trigger_estop(self, reason: str = "Operator E-Stop") -> None:
        self.emergency_stop_latched = True
        self._record_audit("EMERGENCY_STOP_TRIGGERED", {"reason": reason})

    def reset_estop(self) -> None:
        self.emergency_stop_latched = False
        self._record_audit("EMERGENCY_STOP_CLEARED", {})

    def _record_audit(self, event_type: str, details: Dict[str, Any]) -> None:
        self.audit_log.append({
            "timestamp": Timestamp.now().utc_iso,
            "event": event_type,
            "details": details
        })
        if len(self.audit_log) > 200:
            self.audit_log.pop(0)

    def validate_trajectory(
        self,
        proposed_trajectory: Optional[Trajectory],
        current_pose: Pose,
        current_vel: Velocity,
        loc_quality: QualityState,
        costmap: MasterCostmap,
        tracks: List[TrackedObject],
        last_telemetry_age_sec: float
    ) -> SafetyDecision:
        t_now = Timestamp.now()

        # 1. Check E-Stop latch
        if self.emergency_stop_latched:
            self.rejected_command_count += 1
            return SafetyDecision(
                approved=False,
                safety_state="EMERGENCY_STOP",
                reason="Emergency stop is latched",
                min_obstacle_distance=0.0,
                time_to_collision=0.0,
                timestamp=t_now
            )

        # 2. Check telemetry freshness
        if last_telemetry_age_sec > 0.25:
            self.rejected_command_count += 1
            return SafetyDecision(
                approved=False,
                safety_state="FAULT",
                reason=f"Stale telemetry watchdog expired ({last_telemetry_age_sec:.3f}s > 0.25s)",
                min_obstacle_distance=0.0,
                time_to_collision=0.0,
                timestamp=t_now
            )

        # 3. Check Localisation quality
        if loc_quality in (QualityState.LOST, QualityState.UNKNOWN):
            self.rejected_command_count += 1
            return SafetyDecision(
                approved=False,
                safety_state="DEGRADED",
                reason=f"Localisation quality unacceptable: {loc_quality}",
                min_obstacle_distance=0.0,
                time_to_collision=0.0,
                timestamp=t_now
            )

        # 4. Check Trajectory validity
        if not proposed_trajectory or not proposed_trajectory.points:
            self.rejected_command_count += 1
            return SafetyDecision(
                approved=False,
                safety_state="REJECTED",
                reason="Null or empty trajectory proposed",
                min_obstacle_distance=0.0,
                time_to_collision=0.0,
                timestamp=t_now
            )

        # 5. Check kinematic boundaries and geofence along trajectory
        min_dist_found = float('inf')
        ttc_found = float('inf')

        for idx, pt in enumerate(proposed_trajectory.points):
            # Speed limit check
            if abs(pt.v_linear) > self.max_v * 1.05:
                self.rejected_command_count += 1
                return SafetyDecision(
                    approved=False,
                    safety_state="REJECTED",
                    reason=f"Linear velocity {pt.v_linear:.2f} m/s exceeds max limit {self.max_v} m/s",
                    min_obstacle_distance=min_dist_found,
                    time_to_collision=ttc_found,
                    timestamp=t_now
                )

            # Angular rate check
            if abs(pt.v_angular) > self.max_w * 1.05:
                self.rejected_command_count += 1
                return SafetyDecision(
                    approved=False,
                    safety_state="REJECTED",
                    reason=f"Angular velocity {pt.v_angular:.2f} rad/s exceeds max limit {self.max_w} rad/s",
                    min_obstacle_distance=min_dist_found,
                    time_to_collision=ttc_found,
                    timestamp=t_now
                )

            # Curvature check
            if abs(pt.curvature) > self.max_curvature:
                self.rejected_command_count += 1
                return SafetyDecision(
                    approved=False,
                    safety_state="REJECTED",
                    reason=f"Trajectory curvature {pt.curvature:.2f} 1/m exceeds threshold {self.max_curvature}",
                    min_obstacle_distance=min_dist_found,
                    time_to_collision=ttc_found,
                    timestamp=t_now
                )

            # Geofence boundary check
            if self.geofence:
                min_x, max_x, min_y, max_y = self.geofence
                if not (min_x <= pt.x <= max_x and min_y <= pt.y <= max_y):
                    self.rejected_command_count += 1
                    return SafetyDecision(
                        approved=False,
                        safety_state="REJECTED",
                        reason=f"Trajectory point ({pt.x:.2f}, {pt.y:.2f}) breaches geofence bounds",
                        min_obstacle_distance=min_dist_found,
                        time_to_collision=ttc_found,
                        timestamp=t_now
                    )

            # Static & dynamic costmap collision check
            cost = costmap.get_cost_at(pt.x, pt.y)
            if cost >= 253:
                ttc_found = pt.timestamp_sec
                self.rejected_command_count += 1
                return SafetyDecision(
                    approved=False,
                    safety_state="REJECTED",
                    reason=f"Trajectory point {idx} collides with lethal obstacle (TTC={ttc_found:.2f}s)",
                    min_obstacle_distance=0.0,
                    time_to_collision=ttc_found,
                    timestamp=t_now
                )

            # Dynamic track proximity
            for trk in tracks:
                d = float(np.linalg.norm(np.array([pt.x - trk.position[0], pt.y - trk.position[1]])))
                if d < min_dist_found:
                    min_dist_found = d
                if d < self.min_obstacle_dist:
                    ttc_found = pt.timestamp_sec
                    self.rejected_command_count += 1
                    return SafetyDecision(
                        approved=False,
                        safety_state="REJECTED",
                        reason=f"Dynamic obstacle proximity breach (d={d:.2f}m < {self.min_obstacle_dist}m, TTC={ttc_found:.2f}s)",
                        min_obstacle_distance=min_dist_found,
                        time_to_collision=ttc_found,
                        timestamp=t_now
                    )

        return SafetyDecision(
            approved=True,
            safety_state="APPROVED",
            reason=None,
            min_obstacle_distance=float(min_dist_found if min_dist_found != float('inf') else 5.0),
            time_to_collision=float(ttc_found if ttc_found != float('inf') else 10.0),
            timestamp=t_now
        )
