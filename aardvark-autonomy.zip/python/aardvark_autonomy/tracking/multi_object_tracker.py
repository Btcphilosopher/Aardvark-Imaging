"""
Aardvark Autonomy - Multi-Object Tracker (MOT)
Phase 13: Hungarian / Nearest-Neighbor Association & Multi-Hypothesis Kalman Tracking
"""

import numpy as np
from typing import List, Dict, Optional
from aardvark_autonomy.core.types import (
    DetectedObject,
    TrackedObject,
    TrackState,
    Timestamp,
    Covariance,
)


class Track:
    def __init__(self, detection: DetectedObject, track_id: str):
        self.track_id = track_id
        self.class_name = detection.class_name
        self.confidence = detection.confidence
        self.state = TrackState.TENTATIVE
        self.position = np.array([detection.pose.x, detection.pose.y, detection.pose.z], dtype=np.float64)
        self.velocity = np.zeros(3, dtype=np.float64)
        self.dimensions = np.array(detection.dimensions, dtype=np.float64)
        self.hits = 1
        self.age_steps = 1
        self.time_since_update = 0
        self.last_updated = detection.timestamp

    def predict(self, dt: float = 0.05) -> None:
        self.position += self.velocity * dt
        self.age_steps += 1
        self.time_since_update += 1
        if self.time_since_update > 5 and self.state == TrackState.CONFIRMED:
            self.state = TrackState.LOST
        elif self.time_since_update > 15:
            self.state = TrackState.DELETED

    def update(self, detection: DetectedObject, dt: float = 0.05) -> None:
        meas_pos = np.array([detection.pose.x, detection.pose.y, detection.pose.z])
        # Simple Alpha-Beta Filter update
        alpha = 0.6
        beta = 0.4
        res = meas_pos - self.position
        self.position += alpha * res
        if dt > 0:
            self.velocity = (1 - beta) * self.velocity + beta * (res / dt)
        self.dimensions = 0.8 * self.dimensions + 0.2 * np.array(detection.dimensions)
        self.confidence = 0.7 * self.confidence + 0.3 * detection.confidence
        self.hits += 1
        self.time_since_update = 0
        self.last_updated = detection.timestamp
        if self.hits >= 3 and self.state == TrackState.TENTATIVE:
            self.state = TrackState.CONFIRMED

    def to_schema(self) -> TrackedObject:
        return TrackedObject(
            track_id=self.track_id,
            class_name=self.class_name,
            confidence=float(self.confidence),
            state=self.state,
            position=self.position.tolist(),
            velocity=self.velocity.tolist(),
            acceleration=[0.0, 0.0, 0.0],
            dimensions=self.dimensions.tolist(),
            covariance=Covariance.diagonal([0.1, 0.1, 0.1]),
            hits=self.hits,
            age_steps=self.age_steps,
            last_updated=self.last_updated
        )


class MultiObjectTracker:
    def __init__(self, max_distance_threshold: float = 1.2):
        self.tracks: Dict[str, Track] = {}
        self.next_track_id = 1
        self.max_dist_threshold = max_distance_threshold

    def update(self, detections: List[DetectedObject], dt: float = 0.05) -> List[TrackedObject]:
        # 1. Predict existing tracks
        for track in list(self.tracks.values()):
            track.predict(dt)
            if track.state == TrackState.DELETED:
                del self.tracks[track.track_id]

        active_track_ids = list(self.tracks.keys())

        if not active_track_ids:
            for det in detections:
                tid = f"trk_{self.next_track_id:04d}"
                self.next_track_id += 1
                self.tracks[tid] = Track(det, tid)
            return [t.to_schema() for t in self.tracks.values() if t.state != TrackState.DELETED]

        # 2. Compute cost matrix C_ij = alpha*d_pos + delta*d_class
        cost_matrix = np.full((len(active_track_ids), len(detections)), 1e6)
        for i, tid in enumerate(active_track_ids):
            track = self.tracks[tid]
            for j, det in enumerate(detections):
                d_pos = np.linalg.norm(track.position[:2] - np.array([det.pose.x, det.pose.y]))
                d_class = 0.0 if track.class_name == det.class_name else 2.0
                cost = d_pos + d_class
                if d_pos < self.max_dist_threshold:
                    cost_matrix[i, j] = cost

        # 3. Greedy association
        matched_tracks = set()
        matched_dets = set()

        while True:
            min_val = np.min(cost_matrix)
            if min_val >= 1e5:
                break
            i, j = np.unravel_index(np.argmin(cost_matrix), cost_matrix.shape)
            cost_matrix[i, :] = 1e6
            cost_matrix[:, j] = 1e6
            tid = active_track_ids[i]
            self.tracks[tid].update(detections[j], dt)
            matched_tracks.add(i)
            matched_dets.add(j)

        # 4. Initiate new tracks for unmatched detections
        for j, det in enumerate(detections):
            if j not in matched_dets:
                tid = f"trk_{self.next_track_id:04d}"
                self.next_track_id += 1
                self.tracks[tid] = Track(det, tid)

        return [t.to_schema() for t in self.tracks.values() if t.state != TrackState.DELETED]
