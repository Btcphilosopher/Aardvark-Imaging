"""
Aardvark Autonomy - Synthetic Wheel Encoder & Odometry Sensor
Phase 6: Differential Drive Wheel Odometry with slip model
"""

import numpy as np
from typing import Any
from aardvark_autonomy.sensors.base import BaseSensor
from aardvark_autonomy.core.types import (
    SensorConfiguration,
    OdometryMeasurement,
    Pose,
    Velocity,
    CoordinateFrame,
    Timestamp,
    Covariance,
)
from aardvark_autonomy.core.transforms import euler_to_quaternion


class SimulatedWheelEncoder(BaseSensor):
    def __init__(self, config: SensorConfiguration, track_width: float = 0.50, wheel_radius: float = 0.10, seed: int = 42):
        super().__init__(config)
        self.rng = np.random.default_rng(seed)
        self.track_width = track_width
        self.wheel_radius = wheel_radius
        self.slip_coef = float(config.noise_parameters.get("slip_coefficient", 0.02))

        # Accumulated odom dead-reckoning state
        self.odom_x = 0.0
        self.odom_y = 0.0
        self.odom_yaw = 0.0

    def update_dead_reckoning(self, v_linear: float, w_angular: float, dt: float) -> OdometryMeasurement:
        self.last_read_timestamp = Timestamp.now()
        self.total_reads += 1

        # Apply slight slip and noise
        noisy_v = v_linear * (1.0 + self.rng.normal(0, self.slip_coef))
        noisy_w = w_angular * (1.0 + self.rng.normal(0, self.slip_coef * 1.5))

        # RK2 Runge-Kutta / Midpoint Integration
        mid_yaw = self.odom_yaw + 0.5 * noisy_w * dt
        self.odom_x += noisy_v * np.cos(mid_yaw) * dt
        self.odom_y += noisy_v * np.sin(mid_yaw) * dt
        self.odom_yaw += noisy_w * dt

        qx, qy, qz, qw = euler_to_quaternion(0.0, 0.0, self.odom_yaw)

        # Differential wheel angular velocities (rad/s)
        v_left = noisy_v - (noisy_w * self.track_width / 2.0)
        v_right = noisy_v + (noisy_w * self.track_width / 2.0)
        w_left_rad = v_left / self.wheel_radius
        w_right_rad = v_right / self.wheel_radius

        cov_pose = Covariance.diagonal([0.05, 0.05, 0.05, 0.02, 0.02, 0.02])

        return OdometryMeasurement(
            id=f"odom_{self.total_reads}",
            timestamp=self.last_read_timestamp,
            frame_id=CoordinateFrame.ODOM,
            pose=Pose(
                x=float(self.odom_x),
                y=float(self.odom_y),
                z=0.0,
                qx=float(qx),
                qy=float(qy),
                qz=float(qz),
                qw=float(qw),
                frame_id=CoordinateFrame.ODOM,
                covariance=cov_pose
            ),
            velocity=Velocity(
                vx=float(noisy_v),
                vy=0.0,
                vz=0.0,
                wx=0.0,
                wy=0.0,
                wz=float(noisy_w),
                frame_id=CoordinateFrame.BASE_LINK
            ),
            left_wheel_rad=float(w_left_rad),
            right_wheel_rad=float(w_right_rad)
        )

    def read(self, robot_dynamics: Any, robot_pose: Any) -> OdometryMeasurement:
        v = getattr(robot_dynamics, "linear_velocity", 0.0)
        w = getattr(robot_dynamics, "angular_velocity", 0.0)
        dt = getattr(robot_dynamics, "dt", 0.05)
        return self.update_dead_reckoning(v, w, dt)
