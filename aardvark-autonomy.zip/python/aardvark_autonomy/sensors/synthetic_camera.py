"""
Aardvark Autonomy - Synthetic RGB-D Camera Sensor
Phase 6 & 8: Pinhole camera model with depth buffer projection
"""

import numpy as np
from typing import List, Any
from aardvark_autonomy.sensors.base import BaseSensor
from aardvark_autonomy.core.types import (
    SensorConfiguration,
    CameraFrame,
    Timestamp,
    CoordinateFrame,
    DetectedObject,
    Pose,
    QualityState,
)


class SimulatedCamera(BaseSensor):
    def __init__(self, config: SensorConfiguration, seed: int = 42):
        super().__init__(config)
        self.rng = np.random.default_rng(seed)
        self.width = int(config.intrinsics.get("width", 640))
        self.height = int(config.intrinsics.get("height", 480))
        self.fov_h_deg = float(config.intrinsics.get("fov_h_deg", 86.0))
        self.max_depth = float(config.intrinsics.get("max_depth_m", 10.0))
        self.depth_noise = float(config.noise_parameters.get("depth_noise_sigma_m", 0.02))

        # Intrinsic matrix K
        fx = (self.width / 2.0) / np.tan(np.deg2rad(self.fov_h_deg / 2.0))
        fy = fx
        cx = self.width / 2.0
        cy = self.height / 2.0
        self.K = np.array([
            [fx, 0, cx],
            [0, fy, cy],
            [0, 0, 1]
        ], dtype=np.float64)

    def read(self, world_entities: List[Any], robot_pose: Any) -> CameraFrame:
        self.last_read_timestamp = Timestamp.now()
        self.total_reads += 1

        return CameraFrame(
            id=f"frame_{self.total_reads}",
            timestamp=self.last_read_timestamp,
            frame_id=CoordinateFrame.CAMERA_LINK,
            width=self.width,
            height=self.height,
            rgb_data_base64=None,
            depth_data_base64=None,
            confidence=1.0 if self.health_state == QualityState.GOOD else 0.3
        )

    def detect_visible_objects(self, world_entities: List[Any], robot_pose: Any) -> List[DetectedObject]:
        """Project world entities into camera frustum and return synthetic detected 3D bounding boxes."""
        if self.health_state == QualityState.LOST or not self.is_running:
            return []

        detected: List[DetectedObject] = []
        rx, ry, rz = robot_pose.x, robot_pose.y, robot_pose.z
        yaw = robot_pose.yaw

        for entity in world_entities:
            coords = entity.get("coordinates", [])
            if not coords:
                continue
            cx = float(np.mean([c[0] for c in coords]))
            cy = float(np.mean([c[1] for c in coords]))

            dx = cx - rx
            dy = cy - ry
            dist = np.sqrt(dx*dx + dy*dy)

            if 0.3 < dist < self.max_depth:
                # Relative angle in robot body frame
                angle_to_obj = np.arctan2(dy, dx) - yaw
                angle_to_obj = (angle_to_obj + np.pi) % (2 * np.pi) - np.pi

                if abs(np.rad2deg(angle_to_obj)) < (self.fov_h_deg / 2.0):
                    noisy_dist = dist + self.rng.normal(0, self.depth_noise)
                    confidence = float(max(0.65, min(0.99, 1.0 - (dist / self.max_depth) * 0.4 + self.rng.normal(0, 0.03))))

                    detected.append(DetectedObject(
                        id=f"det_{entity.get('id', 'obj')}_{self.total_reads}",
                        class_name=entity.get("entity_type", "obstacle"),
                        confidence=confidence,
                        pose=Pose(
                            x=cx + self.rng.normal(0, 0.05),
                            y=cy + self.rng.normal(0, 0.05),
                            z=0.4,
                            frame_id=CoordinateFrame.MAP
                        ),
                        dimensions=[0.8, 0.8, 1.2],
                        source_sensor="camera_front",
                        timestamp=Timestamp.now()
                    ))
        return detected
