"""
Aardvark Autonomy - Synthetic LiDAR Generator & Ray-Cast Engine
Phase 6 & 28: Synthetic LiDAR Raycasting with configurable Gaussian noise
"""

import numpy as np
from typing import List, Any
from aardvark_autonomy.sensors.base import BaseSensor
from aardvark_autonomy.core.types import (
    SensorConfiguration,
    CoordinateFrame,
    PointCloud,
    Point,
    Timestamp,
    Transform,
    QualityState,
)


class SimulatedLidar(BaseSensor):
    def __init__(self, config: SensorConfiguration, seed: int = 42):
        super().__init__(config)
        self.rng = np.random.default_rng(seed)
        self.num_lasers = int(config.intrinsics.get("num_lasers", 16))
        self.horizontal_fov_deg = float(config.intrinsics.get("horizontal_fov_deg", 360.0))
        self.horizontal_res_deg = float(config.intrinsics.get("horizontal_resolution_deg", 1.0))
        self.min_range = float(config.intrinsics.get("min_range_m", 0.15))
        self.max_range = float(config.intrinsics.get("max_range_m", 30.0))
        self.noise_sigma = float(config.noise_parameters.get("range_noise_sigma_m", 0.015))

    def read(self, world_entities: List[Any], robot_pose: Any) -> PointCloud:
        """Ray-cast against geometric obstacles in world and return raw PointCloud in LIDAR_LINK frame."""
        self.last_read_timestamp = Timestamp.now()
        self.total_reads += 1

        if self.health_state == QualityState.LOST or not self.is_running:
            return PointCloud(
                id=f"scan_{self.total_reads}",
                timestamp=self.last_read_timestamp,
                frame_id=self.frame_id,
                points=[],
                quality=0.0
            )

        points: List[Point] = []
        angles = np.deg2rad(np.arange(-self.horizontal_fov_deg/2, self.horizontal_fov_deg/2, self.horizontal_res_deg))
        elevation_angles = np.linspace(-0.26, 0.26, self.num_lasers) # -15 to +15 deg

        # Base robot coordinates
        rx, ry, rz = robot_pose.x, robot_pose.y, robot_pose.z
        yaw = robot_pose.yaw

        for ring, el in enumerate(elevation_angles):
            for az in angles:
                # Global ray direction
                global_az = yaw + az
                dir_x = np.cos(el) * np.cos(global_az)
                dir_y = np.cos(el) * np.sin(global_az)
                dir_z = np.sin(el)

                hit_range = self.max_range

                # Check ray intersection with ground plane (z = 0)
                if dir_z < -1e-4:
                    t_ground = (0.0 - (rz + 0.35)) / dir_z
                    if 0.0 < t_ground < hit_range:
                        hit_range = t_ground

                # Check intersection with world bounding boxes / segments
                for entity in world_entities:
                    coords = entity.get("coordinates", [])
                    if len(coords) >= 4: # Polygon / bounding box
                        cx = np.mean([c[0] for c in coords])
                        cy = np.mean([c[1] for c in coords])
                        radius = max(np.linalg.norm(np.array([c[0]-cx, c[1]-cy])) for c in coords)
                        # Ray-sphere intersection approximation
                        to_obj = np.array([cx - rx, cy - ry])
                        proj = to_obj[0]*dir_x + to_obj[1]*dir_y
                        if proj > 0:
                            dist_sq = (to_obj[0]**2 + to_obj[1]**2) - proj**2
                            if dist_sq < radius**2:
                                t_box = proj - np.sqrt(max(0.0, radius**2 - dist_sq))
                                if self.min_range < t_box < hit_range:
                                    hit_range = t_box

                if self.min_range < hit_range < self.max_range:
                    noisy_range = hit_range + self.rng.normal(0.0, self.noise_sigma)
                    # Convert to lidar-local Cartesian frame
                    lx = noisy_range * np.cos(el) * np.cos(az)
                    ly = noisy_range * np.cos(el) * np.sin(az)
                    lz = noisy_range * np.sin(el)
                    intensity = float(max(0.1, min(1.0, 1.0 - (noisy_range / self.max_range) + self.rng.normal(0, 0.05))))

                    points.append(Point(
                        x=float(lx),
                        y=float(ly),
                        z=float(lz),
                        intensity=intensity,
                        ring=ring,
                        confidence=0.98 if self.health_state == QualityState.GOOD else 0.5
                    ))

        return PointCloud(
            id=f"scan_{self.total_reads}",
            timestamp=self.last_read_timestamp,
            frame_id=self.frame_id,
            points=points,
            quality=1.0 if self.health_state == QualityState.GOOD else 0.4
        )
