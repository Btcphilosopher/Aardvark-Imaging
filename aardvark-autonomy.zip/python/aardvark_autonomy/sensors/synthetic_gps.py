"""
Aardvark Autonomy - Synthetic RTK/Standard GNSS GPS Sensor
Phase 6: Global Navigation Satellite System observation model
"""

import numpy as np
from typing import Any
from aardvark_autonomy.sensors.base import BaseSensor
from aardvark_autonomy.core.types import (
    SensorConfiguration,
    GpsMeasurement,
    Timestamp,
    Covariance,
    QualityState,
)


class SimulatedGPS(BaseSensor):
    def __init__(self, config: SensorConfiguration, origin_lat: float = 37.7749, origin_lon: float = -122.4194, seed: int = 42):
        super().__init__(config)
        self.rng = np.random.default_rng(seed)
        self.origin_lat = origin_lat
        self.origin_lon = origin_lon
        self.horizontal_accuracy = float(config.noise_parameters.get("horizontal_accuracy_m", 0.03)) # 3cm RTK

    def read(self, robot_pose: Any, rtk_fixed: bool = True) -> GpsMeasurement:
        self.last_read_timestamp = Timestamp.now()
        self.total_reads += 1

        if self.health_state == QualityState.LOST or not self.is_running:
            return GpsMeasurement(
                id=f"gps_{self.total_reads}",
                timestamp=self.last_read_timestamp,
                frame_id=self.frame_id,
                latitude=self.origin_lat,
                longitude=self.origin_lon,
                altitude=0.0,
                utm_x=0.0,
                utm_y=0.0,
                quality_fix=0
            )

        # UTM local approximation (meters from origin)
        err_x = self.rng.normal(0, self.horizontal_accuracy)
        err_y = self.rng.normal(0, self.horizontal_accuracy)

        utm_x = robot_pose.x + 500000.0 + err_x
        utm_y = robot_pose.y + 4100000.0 + err_y

        # Convert meters to lat/lon offsets
        d_lat = (robot_pose.y + err_y) / 111139.0
        d_lon = (robot_pose.x + err_x) / (111139.0 * np.cos(np.deg2rad(self.origin_lat)))

        lat = self.origin_lat + d_lat
        lon = self.origin_lon + d_lon

        cov = Covariance.diagonal([self.horizontal_accuracy, self.horizontal_accuracy, self.horizontal_accuracy * 2.0])

        return GpsMeasurement(
            id=f"gps_{self.total_reads}",
            timestamp=self.last_read_timestamp,
            frame_id=self.frame_id,
            latitude=float(lat),
            longitude=float(lon),
            altitude=float(robot_pose.z),
            utm_x=float(utm_x),
            utm_y=float(utm_y),
            covariance=cov,
            quality_fix=4 if rtk_fixed else 1
        )
