"""
Aardvark Autonomy - Base Sensor Abstraction
Phase 6: Sensor Interface & Health Monitoring
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
from aardvark_autonomy.core.types import (
    CoordinateFrame,
    Transform,
    Timestamp,
    SensorConfiguration,
    QualityState,
)


class BaseSensor(ABC):
    def __init__(self, config: SensorConfiguration):
        self.config = config
        self.is_running = False
        self.health_state = QualityState.GOOD
        self.last_read_timestamp: Optional[Timestamp] = None
        self.total_reads = 0
        self.dropped_samples = 0

    def start(self) -> bool:
        self.is_running = True
        return True

    def stop(self) -> bool:
        self.is_running = False
        return True

    def configure(self, parameters: Dict[str, Any]) -> bool:
        for k, v in parameters.items():
            self.config.noise_parameters[k] = v
        return True

    def health(self) -> QualityState:
        return self.health_state

    def set_fault(self, fault_state: QualityState) -> None:
        self.health_state = fault_state

    @property
    def frame_id(self) -> CoordinateFrame:
        return self.config.frame_id

    @property
    def calibration(self) -> Transform:
        return self.config.extrinsics_to_base

    @abstractmethod
    def read(self, world_state: Any, robot_pose: Any) -> Any:
        """Acquire latest observation relative to simulated or physical environment."""
        pass
