"""
Aardvark Autonomy - Synthetic 6-DOF IMU Sensor
Phase 6: Inertial Measurement Unit with drift, bias instability & white noise
"""

import numpy as np
from aardvark_autonomy.sensors.base import BaseSensor
from aardvark_autonomy.core.types import (
    SensorConfiguration,
    ImuMeasurement,
    Acceleration,
    Timestamp,
    Covariance,
    QualityState,
)


class SimulatedIMU(BaseSensor):
    def __init__(self, config: SensorConfiguration, seed: int = 42):
        super().__init__(config)
        self.rng = np.random.default_rng(seed)
        self.accel_noise = float(config.noise_parameters.get("accel_noise_density", 0.002))
        self.gyro_noise = float(config.noise_parameters.get("gyro_noise_density", 0.0003))
        self.accel_bias = np.array([0.01, -0.015, 0.02])
        self.gyro_bias = np.array([0.001, -0.002, 0.0005])

    def read(self, robot_dynamics: Any, robot_pose: Any) -> ImuMeasurement:
        self.last_read_timestamp = Timestamp.now()
        self.total_reads += 1

        # True acceleration + gravity (9.81 m/s^2 along z)
        true_ax = getattr(robot_dynamics, "ax", 0.0)
        true_ay = getattr(robot_dynamics, "ay", 0.0)
        true_az = getattr(robot_dynamics, "az", 0.0) + 9.80665

        # True angular rate
        true_wx = getattr(robot_dynamics, "wx", 0.0)
        true_wy = getattr(robot_dynamics, "wy", 0.0)
        true_wz = getattr(robot_dynamics, "wz", 0.0)

        # Apply bias walk and white noise
        self.accel_bias += self.rng.normal(0, 1e-5, 3)
        self.gyro_bias += self.rng.normal(0, 1e-6, 3)

        meas_ax = true_ax + self.accel_bias[0] + self.rng.normal(0, self.accel_noise)
        meas_ay = true_ay + self.accel_bias[1] + self.rng.normal(0, self.accel_noise)
        meas_az = true_az + self.accel_bias[2] + self.rng.normal(0, self.accel_noise)

        meas_wx = true_wx + self.gyro_bias[0] + self.rng.normal(0, self.gyro_noise)
        meas_wy = true_wy + self.gyro_bias[1] + self.rng.normal(0, self.gyro_noise)
        meas_wz = true_wz + self.gyro_bias[2] + self.rng.normal(0, self.gyro_noise)

        cov = Covariance.diagonal([
            self.accel_noise, self.accel_noise, self.accel_noise,
            self.gyro_noise, self.gyro_noise, self.gyro_noise
        ])

        return ImuMeasurement(
            id=f"imu_{self.total_reads}",
            timestamp=self.last_read_timestamp,
            frame_id=self.frame_id,
            linear_acceleration=Acceleration(
                ax=float(meas_ax),
                ay=float(meas_ay),
                az=float(meas_az),
                frame_id=self.frame_id
            ),
            angular_velocity=[float(meas_wx), float(meas_wy), float(meas_wz)],
            covariance=cov
        )
