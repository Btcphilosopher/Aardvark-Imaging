"""
Aardvark Autonomy - Extended Kalman Filter (EKF) Sensor Fusion Engine
Phase 9 & 11: 15-State Error-State / Direct EKF with Joseph-Form Numerical Covariance Safeguards
"""

import numpy as np
from typing import Optional, Tuple, Dict, Any
from aardvark_autonomy.core.types import (
    Pose,
    Velocity,
    Acceleration,
    Covariance,
    CoordinateFrame,
    Timestamp,
    QualityState,
    ImuMeasurement,
    GpsMeasurement,
    OdometryMeasurement,
)
from aardvark_autonomy.core.transforms import euler_to_quaternion


class FusionEngine:
    def __init__(self, state_dim: int = 15):
        self.state_dim = state_dim
        # State vector x: [px, py, pz, vx, vy, vz, roll, pitch, yaw, bax, bay, baz, bgx, bgy, bgz]
        self.x = np.zeros(15, dtype=np.float64)

        # Covariance matrix P
        self.P = np.eye(15, dtype=np.float64) * 0.1
        # Set initial uncertainties
        self.P[0:3, 0:3] *= 0.05   # position
        self.P[3:6, 3:6] *= 0.1    # velocity
        self.P[6:9, 6:9] *= 0.01   # orientation
        self.P[9:12, 9:12] *= 1e-4 # accel bias
        self.P[12:15, 12:15] *= 1e-5 # gyro bias

        # Process noise Q
        self.Q = np.eye(15, dtype=np.float64) * 1e-4
        self.Q[3:6, 3:6] = np.eye(3) * 0.02
        self.Q[6:9, 6:9] = np.eye(3) * 0.005

        self.last_update_sec: Optional[float] = None
        self.quality_state = QualityState.INITIALISING

    def reset(self, initial_pose: Pose) -> None:
        self.x.fill(0.0)
        self.x[0] = initial_pose.x
        self.x[1] = initial_pose.y
        self.x[2] = initial_pose.z
        self.x[8] = initial_pose.yaw
        self.P = np.eye(15, dtype=np.float64) * 0.05
        self.quality_state = QualityState.GOOD

    def predict(self, imu: ImuMeasurement, dt: float) -> None:
        """Propagate state and covariance using IMU accelerometer and gyroscope inputs."""
        if dt <= 0.0 or dt > 1.0:
            dt = 0.05

        # Extract unbiased inputs
        accel_raw = np.array([
            imu.linear_acceleration.ax,
            imu.linear_acceleration.ay,
            imu.linear_acceleration.az - 9.80665
        ]) - self.x[9:12]

        gyro_raw = np.array(imu.angular_velocity) - self.x[12:15]

        yaw = self.x[8]
        cos_y, sin_y = np.cos(yaw), np.sin(yaw)

        # Body to World rotation for 2D/3D planar motion
        R = np.array([
            [cos_y, -sin_y, 0.0],
            [sin_y, cos_y, 0.0],
            [0.0, 0.0, 1.0]
        ])

        accel_world = np.dot(R, accel_raw)

        # State transition f(x, u)
        self.x[0:3] += self.x[3:6] * dt + 0.5 * accel_world * (dt ** 2)
        self.x[3:6] += accel_world * dt
        self.x[8] += gyro_raw[2] * dt
        self.x[8] = (self.x[8] + np.pi) % (2 * np.pi) - np.pi

        # State Jacobian F = df/dx
        F = np.eye(15, dtype=np.float64)
        F[0:3, 3:6] = np.eye(3) * dt
        # Derivative of position and velocity wrt yaw
        d_accel_dyaw = np.array([
            -sin_y * accel_raw[0] - cos_y * accel_raw[1],
            cos_y * accel_raw[0] - sin_y * accel_raw[1],
            0.0
        ])
        F[0:3, 8] = 0.5 * d_accel_dyaw * (dt ** 2)
        F[3:6, 8] = d_accel_dyaw * dt
        F[3:6, 9:12] = -R * dt
        F[8, 14] = -dt

        # Covariance propagation
        self.P = np.dot(np.dot(F, self.P), F.T) + self.Q * dt
        self._enforce_symmetry_and_psd()

    def update_gps(self, gps: GpsMeasurement) -> None:
        """Update position states from GPS UTM measurement."""
        if gps.quality_fix == 0:
            return

        z = np.array([gps.utm_x - 500000.0, gps.utm_y - 4100000.0, gps.altitude])
        H = np.zeros((3, 15), dtype=np.float64)
        H[0, 0] = 1.0
        H[1, 1] = 1.0
        H[2, 2] = 1.0

        R = np.eye(3, dtype=np.float64) * (0.05 ** 2 if gps.quality_fix == 4 else 1.5 ** 2)
        self._apply_measurement_update(z, H, R, h_func=lambda x: x[0:3])

    def update_odometry(self, odom: OdometryMeasurement) -> None:
        """Update velocity and orientation from wheel odometry."""
        z = np.array([odom.velocity.vx, odom.velocity.wz, odom.pose.yaw])
        H = np.zeros((3, 15), dtype=np.float64)
        H[0, 3] = 1.0  # vx
        H[1, 14] = 0.0 # wz
        H[2, 8] = 1.0  # yaw

        R = np.diag([0.02**2, 0.01**2, 0.03**2])

        def h_func(x):
            return np.array([x[3], x[14], x[8]])

        self._apply_measurement_update(z, H, R, h_func=h_func)

    def _apply_measurement_update(self, z: np.ndarray, H: np.ndarray, R: np.ndarray, h_func: Any) -> None:
        """Joseph Form Covariance Measurement Update with Numerical Conditioning Safeguards."""
        y = z - h_func(self.x)
        # Wrap yaw error if present
        if len(y) >= 3:
            y[-1] = (y[-1] + np.pi) % (2 * np.pi) - np.pi

        # Innovation Covariance S = H P H^T + R
        S = np.dot(np.dot(H, self.P), H.T) + R

        # Numerical safeguard: check conditioning
        cond = np.linalg.cond(S)
        if np.isnan(cond) or cond > 1e12:
            return # Skip update to prevent matrix divergence

        # Kalman Gain K = P H^T S^-1
        K = np.dot(np.dot(self.P, H.T), np.linalg.inv(S))

        # State update
        self.x += np.dot(K, y)
        self.x[8] = (self.x[8] + np.pi) % (2 * np.pi) - np.pi

        # Joseph Form Covariance Update: P = (I - KH) P (I - KH)^T + K R K^T
        I = np.eye(15, dtype=np.float64)
        IKH = I - np.dot(K, H)
        self.P = np.dot(np.dot(IKH, self.P), IKH.T) + np.dot(np.dot(K, R), K.T)

        self._enforce_symmetry_and_psd()
        self._update_quality_state()

    def _enforce_symmetry_and_psd(self) -> None:
        """Enforce covariance symmetry and positive semi-definiteness."""
        self.P = 0.5 * (self.P + self.P.T)
        # Floor eigenvalues to prevent negative variance
        w, v = np.linalg.eigh(self.P)
        w = np.clip(w, 1e-8, None)
        self.P = np.dot(np.dot(v, np.diag(w)), v.T)

    def _update_quality_state(self) -> None:
        trace_pos = np.trace(self.P[0:3, 0:3])
        if trace_pos < 0.15:
            self.quality_state = QualityState.GOOD
        elif trace_pos < 0.60:
            self.quality_state = QualityState.DEGRADED
        else:
            self.quality_state = QualityState.LOST

    def get_fused_pose(self) -> Pose:
        qx, qy, qz, qw = euler_to_quaternion(self.x[6], self.x[7], self.x[8])
        cov_6x6 = np.zeros((6, 6))
        cov_6x6[:3, :3] = self.P[:3, :3]
        cov_6x6[3:, 3:] = self.P[6:9, 6:9]

        return Pose(
            x=float(self.x[0]),
            y=float(self.x[1]),
            z=float(self.x[2]),
            qx=float(qx),
            qy=float(qy),
            qz=float(qz),
            qw=float(qw),
            frame_id=CoordinateFrame.MAP,
            covariance=Covariance(dim=6, matrix=cov_6x6.tolist(), confidence=0.98 if self.quality_state == QualityState.GOOD else 0.4)
        )

    def get_fused_velocity(self) -> Velocity:
        return Velocity(
            vx=float(self.x[3]),
            vy=float(self.x[4]),
            vz=float(self.x[5]),
            wx=float(self.x[12]),
            wy=float(self.x[13]),
            wz=float(self.x[14]),
            frame_id=CoordinateFrame.BASE_LINK
        )
