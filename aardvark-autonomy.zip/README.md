# AARDVARK AUTONOMY
## Production-Grade Simulation-First Autonomous Robotics Platform

Aardvark Autonomy is a simulation-first autonomous robotics perception, mapping, planning, safety, and control platform designed with a clean, closed-loop autonomy pipeline:

```
SENSORS → PERCEPTION → LOCALISATION → WORLD MODEL → MAPPING → PREDICTION → PLANNING → BEHAVIOUR → CONTROL → ROBOT STATE
```

---

### Core Architecture & Separation of Concerns

1. **Physical World vs Observation vs Estimate vs Action**:
   - **Raw Observations**: Non-destructive raw sensor frames from LiDAR, RGB-D Camera, IMU, GPS, and Wheel Encoders.
   - **Calibrated & Transformed**: Explicit homogeneous transformation matrices $T \in \text{SE}(3)$, extrinsic/intrinsic calibration, coordinate frame validation (`world`, `map`, `odom`, `base_link`, `lidar_frame`, `camera_frame`).
   - **Perception & Tracking**: LiDAR voxelization, RANSAC ground-plane extraction, statistical outlier removal, Euclidean clustering, synthetic vision bounding boxes, multi-object Kalman tracking with Hungarian association.
   - **Localisation & Fusion**: 15-state Extended Kalman Filter (EKF) fusing IMU, Odometry, GPS, and Scan-Matching with Joseph-form covariance updates and explicit quality monitoring (`UNKNOWN`, `INITIALISING`, `GOOD`, `DEGRADED`, `LOST`).
   - **World Model & Multi-Layer Costmap**: Semantic map entities, Log-odds 2D Occupancy Grid, 3D Voxel spatial hash, Static, Obstacle, Inflation (exponential decay), Dynamic Obstacle, and Semantic layers.
   - **Global & Local Planning**: 8-connected A* search with diagonal heuristics and turn penalties + Local Trajectory Rollout (DWA) evaluator ranking candidate trajectories with explainable rejection reasons.
   - **Safety Supervisor**: Independent fail-safe supervisor evaluating dynamic constraints (speed, acceleration, curvature, obstacle buffer, geofencing, stale sensor timeout, E-stop).
   - **Control**: Pure Pursuit path tracking ($\kappa = 2\sin(\alpha)/L$) + Anti-windup PID velocity control for differential-drive kinematics.
   - **Behaviour Tree & Mission Engine**: State machine with explicit transitions, audit logs, and mission lifecycles (`CREATED`, `RUNNING`, `PAUSED`, `BLOCKED`, `COMPLETED`).

---

### Technology Stack

* **Python (`python/aardvark_autonomy/`)**: Primary autonomy engine, perception, EKF fusion, mapping, A* planning, safety supervisor, pure-pursuit control, FastAPI server, deterministic simulation engine, and test suites.
* **Rust (`rust/`)**: High-performance geometry, KD-Tree spatial indexing, voxel downsampling, OBB continuous collision checking, trajectory evaluation, and FFI bindings.
* **Kotlin (`kotlin/app/`)**: Operator console, Jetpack Compose UI, Coroutines/StateFlow, Ktor client, and WebSocket telemetry consumer.
* **PostgreSQL (`database/`)**: Relational storage for robots, configurations, calibration, maps, trajectories, safety audit logs, and diagnostic events.
* **Web Operator Console (`src/`)**: Interactive mission dashboard with real-time 2D/3D LiDAR visualizer, EKF covariance monitor, explainable trajectory inspector, scenario runner, and replay controls.

---

### Getting Started

```bash
# 1. Install Python package in editable mode
pip install -e python/

# 2. Build Rust acceleration kernels
cd rust && cargo build --release && cargo test

# 3. Start the Web Operator Console & Simulator
npm run dev

# 4. Run tests
pytest tests/
```
