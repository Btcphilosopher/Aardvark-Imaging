import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Aardvark CGI Engine | Python-Native 3D Creation & Render System',
  description: 'Python-Native 3D Modelling, Procedural Geometry, Materials, Lighting, Physics & CGI Rendering System',
  openGraph: {
    title: 'Aardvark CGI Engine | Python-Native 3D Creation & Render System',
    description: 'Python-Native 3D Modelling, Procedural Geometry, Materials, Lighting, Physics & CGI Rendering System',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Aardvark CGI Engine | Python-Native 3D Creation & Render System',
    description: 'Python-Native 3D Modelling, Procedural Geometry, Materials, Lighting, Physics & CGI Rendering System',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
