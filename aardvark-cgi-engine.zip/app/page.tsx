import { AardvarkStudio } from '@/components/aardvark/AardvarkStudio';

export default function HomePage() {
  return (
    <main className="w-full h-screen overflow-hidden bg-[#0a0d14]">
      <AardvarkStudio />
    </main>
  );
}
