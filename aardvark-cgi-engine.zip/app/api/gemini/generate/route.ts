import { GoogleGenAI } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const { prompt, type = 'scene' } = await req.json();

    if (!process.env.GEMINI_API_KEY) {
      return NextResponse.json(
        {
          error: 'GEMINI_API_KEY environment variable is not configured.',
          code: `# Fallback local procedural script\nimport aard\nscene = aard.scene()\nturbine = aard.turbomachine(rpm=3600)\nprint("[Aardvark CGI] Generated default scene.")`,
        },
        { status: 200 }
      );
    }

    const ai = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const systemInstruction = `You are the Aardvark CGI Python Script Generator.
Aardvark is a Python-native 3D DCC, modeling, animation, materials, lighting, physics and CGI rendering system.
Return ONLY executable Python code using the official Aardvark DSL (aard module). Do NOT enclose in markdown code blocks if possible, or keep it cleanly formatted.
Available Aardvark APIs:
- aard.scene(): Initialize scene
- aard.turbomachine(rpm=3600, blades=18, stages=4, casing_transparent=True, thermal_vis=True)
- aard.city(buildings=40, seed=101, neon_density=0.8)
- aard.mesh.cube(size=2), sphere(radius=1.5), torus(radius=2, tube=0.4), helix(radius=1.5), logo(scale=(1,1,1)), cylinder(), plane()
- aard.material(name="...", color="#hex", metallic=0.9, roughness=0.15, transmission=0.0, emission="#hex", emission_intensity=0.0, procedural="brushed_metal"|"carbon_fiber"|"grid")
- aard.light.area(location=(x,y,z), intensity=4.0, color="#hex"), spot(), point(), directional()
- aard.camera(location=(x,y,z), focal_length=50, aperture=2.4, focus_distance=8.0, dof=True)
- aard.particles(count=2000, emitter="ring"|"sphere"|"box", color_start="#hex", color_end="#hex", vortex_strength=4.0, turbulence=2.0)
- aard.cloth(grid_x=16, grid_y=16, spacing=0.25, mass=1.0)
- obj.animate(property="rotation.y", start=0, end=360, duration_frames=240)
Generate an expressive, high-end CGI scene script based on the user's prompt.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    let generatedCode = response.text || '';
    // Strip markdown code fences if present
    generatedCode = generatedCode.replace(/^```python\s*/i, '').replace(/^```\s*/i, '').replace(/```$/i, '').trim();

    return NextResponse.json({
      success: true,
      code: generatedCode,
    });
  } catch (err: any) {
    console.error('Gemini CGI Generator Error:', err);
    return NextResponse.json(
      {
        error: err.message || 'Failed to generate Python CGI scene script',
      },
      { status: 500 }
    );
  }
}
