// AARDVARK 3D GEOMETRY GENERATORS & PARAMETRIC MESH BUILDER

import * as THREE from 'three';
import { ParametricProps, PrimitiveType, AardModifier } from '../core/types';
import { SimplexNoise } from '../core/math';

const noise = new SimplexNoise(42);

export function buildParametricGeometry(
  type: PrimitiveType,
  props: ParametricProps = {},
  modifiers: AardModifier[] = []
): THREE.BufferGeometry {
  let geo: THREE.BufferGeometry;

  switch (type) {
    case 'cube': {
      const w = props.width ?? props.size ?? 2;
      const h = props.height ?? props.size ?? 2;
      const d = props.depth ?? props.size ?? 2;
      const segs = props.segments ?? 4;
      geo = new THREE.BoxGeometry(w, h, d, segs, segs, segs);
      break;
    }

    case 'sphere':
    case 'icosphere': {
      const r = props.radius ?? 1.5;
      const segs = props.segments ?? 48;
      const rings = props.rings ?? 32;
      geo = new THREE.SphereGeometry(r, segs, rings);
      break;
    }

    case 'cylinder': {
      const rt = props.radius ?? 1.0;
      const rb = props.radius2 ?? props.radius ?? 1.0;
      const h = props.height ?? 3.0;
      const segs = props.radialSegments ?? props.segments ?? 32;
      const hsegs = props.heightScale ? Math.floor(props.heightScale) : 8;
      geo = new THREE.CylinderGeometry(rt, rb, h, segs, hsegs);
      break;
    }

    case 'cone': {
      const r = props.radius ?? 1.2;
      const h = props.height ?? 2.5;
      const segs = props.radialSegments ?? 32;
      geo = new THREE.ConeGeometry(r, h, segs);
      break;
    }

    case 'torus': {
      const r = props.radius ?? 1.8;
      const tube = props.tubeRadius ?? 0.45;
      const radSegs = props.radialSegments ?? 24;
      const tubSegs = props.tubularSegments ?? 64;
      geo = new THREE.TorusGeometry(r, tube, radSegs, tubSegs);
      break;
    }

    case 'plane':
    case 'grid': {
      const w = props.width ?? 10;
      const h = props.height ?? 10;
      const segs = props.segments ?? 20;
      geo = new THREE.PlaneGeometry(w, h, segs, segs);
      break;
    }

    case 'capsule': {
      const r = props.radius ?? 0.8;
      const len = props.height ?? 2.0;
      const capSegs = props.segments ?? 12;
      const radSegs = props.radialSegments ?? 24;
      geo = new THREE.CapsuleGeometry(r, len, capSegs, radSegs);
      break;
    }

    case 'pyramid': {
      const r = props.radius ?? 1.5;
      const h = props.height ?? 2.0;
      geo = new THREE.ConeGeometry(r, h, 4);
      break;
    }

    case 'helix': {
      const r = props.radius ?? 1.2;
      const tube = props.tubeRadius ?? 0.2;
      const turns = 4;
      const points: THREE.Vector3[] = [];
      const steps = 120;
      for (let i = 0; i <= steps; i++) {
        const t = (i / steps) * turns * Math.PI * 2;
        const y = ((i / steps) - 0.5) * 4.0;
        const x = Math.cos(t) * r;
        const z = Math.sin(t) * r;
        points.push(new THREE.Vector3(x, y, z));
      }
      const curve = new THREE.CatmullRomCurve3(points);
      geo = new THREE.TubeGeometry(curve, steps, tube, 16, false);
      break;
    }

    case 'terrain': {
      const w = props.width ?? 30;
      const h = props.height ?? 30;
      const segs = props.segments ?? 80;
      const hScale = props.heightScale ?? 3.5;
      const rough = props.roughness ?? 0.08;
      const octaves = props.octaves ?? 4;

      const pGeo = new THREE.PlaneGeometry(w, h, segs, segs);
      pGeo.rotateX(-Math.PI / 2);
      const pos = pGeo.attributes.position;
      for (let i = 0; i < pos.count; i++) {
        const x = pos.getX(i);
        const z = pos.getZ(i);
        const elev = noise.fbm(x * rough, 0.5, z * rough, octaves) * hScale;
        pos.setY(i, elev);
      }
      pGeo.computeVertexNormals();
      geo = pGeo;
      break;
    }

    case 'turbomachine': {
      geo = buildTurbomachineComposite(props);
      break;
    }

    case 'city': {
      geo = buildProceduralCityComposite(props);
      break;
    }

    case 'logo': {
      geo = buildAardvarkLogoComposite(props);
      break;
    }

    default:
      geo = new THREE.BoxGeometry(2, 2, 2, 4, 4, 4);
      break;
  }

  // Apply non-destructive modifier stack
  geo = applyModifierStack(geo, modifiers);

  geo.computeVertexNormals();
  return geo;
}

// Non-destructive modifier stack implementation
export function applyModifierStack(
  baseGeo: THREE.BufferGeometry,
  modifiers: AardModifier[]
): THREE.BufferGeometry {
  let geo = baseGeo.clone();

  for (const mod of modifiers) {
    if (!mod.enabled) continue;

    switch (mod.type) {
      case 'subdivision': {
        const levels = mod.params.levels ?? 1;
        // Simple smoothing / subdiv subdivision
        for (let l = 0; l < Math.min(levels, 2); l++) {
          geo = smoothSubdivide(geo);
        }
        break;
      }

      case 'displace': {
        const str = mod.params.strength ?? 0.25;
        const tex = mod.params.texture ?? 'perlin';
        const pos = geo.attributes.position;
        if (!geo.attributes.normal) {
          geo.computeVertexNormals();
        }
        const norm = geo.attributes.normal;
        for (let i = 0; i < pos.count; i++) {
          const vx = pos.getX(i);
          const vy = pos.getY(i);
          const vz = pos.getZ(i);
          const nx = norm ? norm.getX(i) : 0;
          const ny = norm ? norm.getY(i) : 1;
          const nz = norm ? norm.getZ(i) : 0;

          let d = 0;
          if (tex === 'perlin') {
            d = noise.noise3D(vx * 2, vy * 2, vz * 2);
          } else {
            d = Math.sin(vx * 4) * Math.cos(vz * 4);
          }

          pos.setX(i, vx + nx * d * str);
          pos.setY(i, vy + ny * d * str);
          pos.setZ(i, vz + nz * d * str);
        }
        geo.computeVertexNormals();
        break;
      }

      case 'mirror': {
        const axis = mod.params.axis ?? 'x';
        const cloned = geo.clone();
        const pos = cloned.attributes.position;
        for (let i = 0; i < pos.count; i++) {
          if (axis === 'x') pos.setX(i, -pos.getX(i));
          if (axis === 'y') pos.setY(i, -pos.getY(i));
          if (axis === 'z') pos.setZ(i, -pos.getZ(i));
        }
        // Merge base + mirrored
        geo = mergeGeometries([geo, cloned]);
        break;
      }

      case 'array': {
        const count = mod.params.count ?? 3;
        const off = mod.params.offset ?? { x: 2.2, y: 0, z: 0 };
        const copies: THREE.BufferGeometry[] = [];
        for (let i = 0; i < count; i++) {
          const copy = geo.clone();
          copy.translate(off.x * i, off.y * i, off.z * i);
          copies.push(copy);
        }
        geo = mergeGeometries(copies);
        break;
      }

      case 'bevel':
      case 'solidify':
      case 'smooth':
        geo.computeVertexNormals();
        break;
    }
  }

  return geo;
}

// Procedural Turbomachine Composite Geometry (Shaft, multi-stage rotor blades, stator rings, combustor ring)
function buildTurbomachineComposite(props: ParametricProps): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [];
  const bladesCount = props.blades ?? 16;
  const stages = props.stages ?? 4;

  // 1. Central Rotating Core Shaft
  const shaftGeo = new THREE.CylinderGeometry(0.35, 0.45, 7.5, 32, 1);
  shaftGeo.rotateX(Math.PI / 2);
  parts.push(shaftGeo);

  // 2. Nose Cone Aerodynamic Spinner
  const noseGeo = new THREE.ConeGeometry(0.8, 1.8, 32);
  noseGeo.rotateX(-Math.PI / 2);
  noseGeo.translate(0, 0, 4.2);
  parts.push(noseGeo);

  // 3. Multi-Stage Turbine Bladed Disks
  for (let s = 0; s < stages; s++) {
    const stageZ = (s - (stages - 1) / 2) * 1.6;
    const stageRadius = 2.4 - s * 0.25;

    // Rotor Hub Disk
    const hub = new THREE.CylinderGeometry(stageRadius * 0.45, stageRadius * 0.45, 0.35, 24);
    hub.rotateX(Math.PI / 2);
    hub.translate(0, 0, stageZ);
    parts.push(hub);

    // Aerofoil Blades distributed radially
    for (let b = 0; b < bladesCount; b++) {
      const angle = (b / bladesCount) * Math.PI * 2;
      const bladeLength = stageRadius * 0.75;
      const bladeGeo = new THREE.BoxGeometry(0.08, bladeLength, 0.32);

      // Twist the aerofoil
      const bladeRot = new THREE.Matrix4()
        .makeRotationAxis(new THREE.Vector3(0, 0, 1), angle)
        .multiply(new THREE.Matrix4().makeRotationZ(0.25 + s * 0.05));

      bladeGeo.translate(0, bladeLength / 2 + stageRadius * 0.42, 0);
      bladeGeo.applyMatrix4(bladeRot);
      bladeGeo.translate(0, 0, stageZ);
      parts.push(bladeGeo);
    }

    // Outer Stator Shroud Ring
    const shroud = new THREE.TorusGeometry(stageRadius * 1.15, 0.08, 16, 48);
    shroud.translate(0, 0, stageZ);
    parts.push(shroud);
  }

  // 4. Combustor Fuel Injector Annulus Ring
  const combustorRing = new THREE.TorusGeometry(1.6, 0.18, 16, 32);
  combustorRing.translate(0, 0, -2.8);
  parts.push(combustorRing);

  // 5. Exhaust Nozzle Cone
  const exhaustNozzle = new THREE.CylinderGeometry(1.8, 1.1, 1.4, 32, 1, true);
  exhaustNozzle.rotateX(Math.PI / 2);
  exhaustNozzle.translate(0, 0, -4.2);
  parts.push(exhaustNozzle);

  return mergeGeometries(parts);
}

// Procedural Sci-Fi Cyber City Composite
function buildProceduralCityComposite(props: ParametricProps): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [];
  const count = props.buildingsCount ?? 36;
  const seed = props.citySeed ?? 101;
  const rand = (n: number) => Math.abs(Math.sin(n * 12.9898 + seed * 78.233) * 43758.5453) % 1;

  const gridSize = Math.ceil(Math.sqrt(count));
  const spacing = 3.5;

  for (let i = 0; i < count; i++) {
    const gx = (i % gridSize) - gridSize / 2;
    const gz = Math.floor(i / gridSize) - gridSize / 2;

    const r1 = rand(i * 3 + 1);
    const r2 = rand(i * 5 + 7);
    const r3 = rand(i * 11 + 13);

    const bWidth = 1.4 + r1 * 1.2;
    const bDepth = 1.4 + r2 * 1.2;
    const bHeight = 4.0 + r3 * 12.0;

    // Building tower
    const tower = new THREE.BoxGeometry(bWidth, bHeight, bDepth);
    tower.translate(gx * spacing, bHeight / 2, gz * spacing);
    parts.push(tower);

    // Spire / Antenna on high towers
    if (bHeight > 9.0) {
      const spire = new THREE.CylinderGeometry(0.04, 0.12, 3.5, 8);
      spire.translate(gx * spacing, bHeight + 1.75, gz * spacing);
      parts.push(spire);
    }

    // Setback Tier for skyscrapers
    if (bHeight > 11.0) {
      const tier = new THREE.BoxGeometry(bWidth * 0.65, 3.0, bDepth * 0.65);
      tier.translate(gx * spacing, bHeight + 1.5, gz * spacing);
      parts.push(tier);
    }
  }

  // Street Level Ground Grid
  const ground = new THREE.PlaneGeometry(gridSize * spacing * 1.5, gridSize * spacing * 1.5);
  ground.rotateX(-Math.PI / 2);
  ground.translate(0, 0, 0);
  parts.push(ground);

  return mergeGeometries(parts);
}

// Procedural Aardvark Cinematic Logo Composite
function buildAardvarkLogoComposite(_props: ParametricProps): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [];

  // Outer Hexagonal Crest Frame
  const hexCurve = new THREE.CylinderGeometry(2.4, 2.4, 0.4, 6, 1, true);
  hexCurve.rotateX(Math.PI / 2);
  parts.push(hexCurve);

  // Central Stylized 'A' Monogram
  const leftLeg = new THREE.BoxGeometry(0.4, 3.2, 0.45);
  leftLeg.rotateZ(0.26);
  leftLeg.translate(-0.6, 0.1, 0);
  parts.push(leftLeg);

  const rightLeg = new THREE.BoxGeometry(0.4, 3.2, 0.45);
  rightLeg.rotateZ(-0.26);
  rightLeg.translate(0.6, 0.1, 0);
  parts.push(rightLeg);

  const crossBar = new THREE.BoxGeometry(1.3, 0.35, 0.45);
  crossBar.translate(0, -0.3, 0);
  parts.push(crossBar);

  // Crest Apex Crown Prism
  const apex = new THREE.ConeGeometry(0.5, 0.9, 4);
  apex.translate(0, 1.8, 0);
  parts.push(apex);

  // Orbital Gyroscope Rings
  const orbit1 = new THREE.TorusGeometry(3.0, 0.08, 16, 64);
  orbit1.rotateX(0.4);
  orbit1.rotateY(0.6);
  parts.push(orbit1);

  const orbit2 = new THREE.TorusGeometry(3.4, 0.06, 16, 64);
  orbit2.rotateX(-0.5);
  orbit2.rotateZ(0.3);
  parts.push(orbit2);

  return mergeGeometries(parts);
}

// Utility: Merge multiple BufferGeometries into one single BufferGeometry
function mergeGeometries(geometries: THREE.BufferGeometry[]): THREE.BufferGeometry {
  if (geometries.length === 0) return new THREE.BufferGeometry();
  if (geometries.length === 1) return geometries[0];

  let totalPositions = 0;
  let totalIndices = 0;

  for (const g of geometries) {
    totalPositions += g.attributes.position ? g.attributes.position.count * 3 : 0;
    if (g.index) {
      totalIndices += g.index.count;
    } else if (g.attributes.position) {
      totalIndices += g.attributes.position.count;
    }
  }

  const mergedPos = new Float32Array(totalPositions);
  const mergedNorm = new Float32Array(totalPositions);
  const mergedUv = new Float32Array((totalPositions / 3) * 2);
  const mergedIndices: number[] = [];

  let posOffset = 0;
  let uvOffset = 0;
  let vertexIndexOffset = 0;

  for (const g of geometries) {
    const pos = g.attributes.position;
    if (!g.attributes.normal && pos) {
      g.computeVertexNormals();
    }
    const norm = g.attributes.normal;
    const uv = g.attributes.uv;

    if (!pos) continue;

    for (let i = 0; i < pos.count; i++) {
      mergedPos[posOffset * 3 + i * 3] = pos.getX(i);
      mergedPos[posOffset * 3 + i * 3 + 1] = pos.getY(i);
      mergedPos[posOffset * 3 + i * 3 + 2] = pos.getZ(i);

      if (norm) {
        mergedNorm[posOffset * 3 + i * 3] = norm.getX(i);
        mergedNorm[posOffset * 3 + i * 3 + 1] = norm.getY(i);
        mergedNorm[posOffset * 3 + i * 3 + 2] = norm.getZ(i);
      }

      if (uv) {
        mergedUv[uvOffset * 2 + i * 2] = uv.getX(i);
        mergedUv[uvOffset * 2 + i * 2 + 1] = uv.getY(i);
      }
    }

    if (g.index) {
      for (let i = 0; i < g.index.count; i++) {
        mergedIndices.push(g.index.getX(i) + vertexIndexOffset);
      }
    } else {
      for (let i = 0; i < pos.count; i++) {
        mergedIndices.push(i + vertexIndexOffset);
      }
    }

    vertexIndexOffset += pos.count;
    posOffset += pos.count;
    uvOffset += pos.count;
  }

  const merged = new THREE.BufferGeometry();
  merged.setAttribute('position', new THREE.BufferAttribute(mergedPos, 3));
  merged.setAttribute('normal', new THREE.BufferAttribute(mergedNorm, 3));
  merged.setAttribute('uv', new THREE.BufferAttribute(mergedUv, 2));
  merged.setIndex(mergedIndices);
  merged.computeVertexNormals();

  return merged;
}

// Simple Catmull-Clark / Midpoint vertex smoothing subdivider
function smoothSubdivide(geo: THREE.BufferGeometry): THREE.BufferGeometry {
  const pos = geo.attributes.position;
  if (!pos) return geo;

  const newPos: number[] = [];
  const indices = geo.index;

  if (indices) {
    for (let i = 0; i < indices.count; i += 3) {
      const i0 = indices.getX(i);
      const i1 = indices.getX(i + 1);
      const i2 = indices.getX(i + 2);

      const v0 = new THREE.Vector3(pos.getX(i0), pos.getY(i0), pos.getZ(i0));
      const v1 = new THREE.Vector3(pos.getX(i1), pos.getY(i1), pos.getZ(i1));
      const v2 = new THREE.Vector3(pos.getX(i2), pos.getY(i2), pos.getZ(i2));

      // Midpoints
      const m01 = v0.clone().add(v1).multiplyScalar(0.5);
      const m12 = v1.clone().add(v2).multiplyScalar(0.5);
      const m20 = v2.clone().add(v0).multiplyScalar(0.5);

      // Sub-triangle 1
      addTri(newPos, v0, m01, m20);
      // Sub-triangle 2
      addTri(newPos, v1, m12, m01);
      // Sub-triangle 3
      addTri(newPos, v2, m20, m12);
      // Sub-triangle 4 (center)
      addTri(newPos, m01, m12, m20);
    }
  } else {
    for (let i = 0; i < pos.count; i += 3) {
      const v0 = new THREE.Vector3(pos.getX(i), pos.getY(i), pos.getZ(i));
      const v1 = new THREE.Vector3(pos.getX(i + 1), pos.getY(i + 1), pos.getZ(i + 1));
      const v2 = new THREE.Vector3(pos.getX(i + 2), pos.getY(i + 2), pos.getZ(i + 2));

      const m01 = v0.clone().add(v1).multiplyScalar(0.5);
      const m12 = v1.clone().add(v2).multiplyScalar(0.5);
      const m20 = v2.clone().add(v0).multiplyScalar(0.5);

      addTri(newPos, v0, m01, m20);
      addTri(newPos, v1, m12, m01);
      addTri(newPos, v2, m20, m12);
      addTri(newPos, m01, m12, m20);
    }
  }

  const res = new THREE.BufferGeometry();
  res.setAttribute('position', new THREE.BufferAttribute(new Float32Array(newPos), 3));
  res.computeVertexNormals();
  return res;
}

function addTri(arr: number[], v0: THREE.Vector3, v1: THREE.Vector3, v2: THREE.Vector3) {
  arr.push(v0.x, v0.y, v0.z, v1.x, v1.y, v1.z, v2.x, v2.y, v2.z);
}
