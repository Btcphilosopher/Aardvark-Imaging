// AARDVARK PHYSICS & SIMULATION ENGINE (PARTICLES, CLOTH, RIGID BODIES)

import * as THREE from 'three';
import { AardParticleSystemData, AardClothData, Vector3D } from '../core/types';
import { SimplexNoise } from '../core/math';

const noise = new SimplexNoise(777);

export interface ParticleState {
  positions: Float32Array;
  velocities: Float32Array;
  colors: Float32Array;
  sizes: Float32Array;
  ages: Float32Array;
  lifetimes: Float32Array;
}

export class AardParticleEngine {
  public state: ParticleState;
  public geometry: THREE.BufferGeometry;
  public points: THREE.Points;
  private count: number;

  constructor(public config: AardParticleSystemData) {
    this.count = config.count;
    this.state = {
      positions: new Float32Array(this.count * 3),
      velocities: new Float32Array(this.count * 3),
      colors: new Float32Array(this.count * 3),
      sizes: new Float32Array(this.count),
      ages: new Float32Array(this.count),
      lifetimes: new Float32Array(this.count),
    };

    // Initialize random particle births
    for (let i = 0; i < this.count; i++) {
      this.resetParticle(i, Math.random() * config.lifetime);
    }

    this.geometry = new THREE.BufferGeometry();
    this.geometry.setAttribute('position', new THREE.BufferAttribute(this.state.positions, 3));
    this.geometry.setAttribute('color', new THREE.BufferAttribute(this.state.colors, 3));
    this.geometry.setAttribute('size', new THREE.BufferAttribute(this.state.sizes, 1));

    // Create particle sprite texture
    const spriteCanvas = document.createElement('canvas');
    spriteCanvas.width = 64;
    spriteCanvas.height = 64;
    const ctx = spriteCanvas.getContext('2d');
    if (ctx) {
      const grad = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
      grad.addColorStop(0, 'rgba(255, 255, 255, 1)');
      grad.addColorStop(0.3, 'rgba(255, 200, 100, 0.8)');
      grad.addColorStop(0.8, 'rgba(100, 200, 255, 0.2)');
      grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 64, 64);
    }
    const spriteTex = new THREE.CanvasTexture(spriteCanvas);

    const material = new THREE.PointsMaterial({
      size: 0.15,
      vertexColors: true,
      map: spriteTex,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      sizeAttenuation: true,
    });

    this.points = new THREE.Points(this.geometry, material);
  }

  private resetParticle(i: number, initialAge: number = 0) {
    const idx3 = i * 3;
    const emType = this.config.emitterType;
    const emSize = this.config.emitterSize;

    let px = 0, py = 0, pz = 0;

    if (emType === 'ring') {
      const angle = Math.random() * Math.PI * 2;
      const r = (0.7 + Math.random() * 0.3) * emSize.x;
      px = Math.cos(angle) * r;
      py = (Math.random() - 0.5) * emSize.y;
      pz = Math.sin(angle) * r;
    } else if (emType === 'sphere') {
      const u = Math.random();
      const v = Math.random();
      const theta = u * 2.0 * Math.PI;
      const phi = Math.acos(2.0 * v - 1.0);
      const r = Math.cbrt(Math.random()) * emSize.x;
      px = r * Math.sin(phi) * Math.cos(theta);
      py = r * Math.sin(phi) * Math.sin(theta);
      pz = r * Math.cos(phi);
    } else {
      px = (Math.random() - 0.5) * emSize.x;
      py = (Math.random() - 0.5) * emSize.y;
      pz = (Math.random() - 0.5) * emSize.z;
    }

    this.state.positions[idx3] = px;
    this.state.positions[idx3 + 1] = py;
    this.state.positions[idx3 + 2] = pz;

    const spd = this.config.speed;
    this.state.velocities[idx3] = (Math.random() - 0.5) * spd * this.config.spread;
    this.state.velocities[idx3 + 1] = (Math.random() * 0.5 + 0.5) * spd;
    this.state.velocities[idx3 + 2] = (Math.random() - 0.5) * spd * this.config.spread;

    this.state.ages[i] = initialAge;
    this.state.lifetimes[i] = this.config.lifetime * (0.8 + Math.random() * 0.4);
  }

  public update(dt: number, time: number) {
    const cStart = new THREE.Color(this.config.colorStart);
    const cEnd = new THREE.Color(this.config.colorEnd);
    const vStr = this.config.vortex;
    const turb = this.config.turbulence;

    const pos = this.state.positions;
    const vel = this.state.velocities;
    const col = this.state.colors;
    const sizes = this.state.sizes;

    for (let i = 0; i < this.count; i++) {
      const idx3 = i * 3;
      this.state.ages[i] += dt;

      if (this.state.ages[i] >= this.state.lifetimes[i]) {
        this.resetParticle(i, 0);
      }

      const lifeRatio = this.state.ages[i] / this.state.lifetimes[i];
      const x = pos[idx3];
      const y = pos[idx3 + 1];
      const z = pos[idx3 + 2];

      // Vortex tangential force
      if (vStr > 0) {
        const distXZ = Math.sqrt(x * x + z * z) + 0.1;
        const tangX = -z / distXZ;
        const tangZ = x / distXZ;
        vel[idx3] += tangX * vStr * dt;
        vel[idx3 + 2] += tangZ * vStr * dt;
      }

      // Curl / Simplex noise turbulence
      if (turb > 0) {
        const nx = noise.noise3D(x * 0.5, y * 0.5, time * 0.5) * turb;
        const ny = noise.noise3D(y * 0.5, z * 0.5, time * 0.5) * turb;
        const nz = noise.noise3D(z * 0.5, x * 0.5, time * 0.5) * turb;
        vel[idx3] += nx * dt;
        vel[idx3 + 1] += ny * dt;
        vel[idx3 + 2] += nz * dt;
      }

      // Gravity & Wind
      vel[idx3] += this.config.wind.x * dt;
      vel[idx3 + 1] += (this.config.gravity.y + this.config.wind.y) * dt;
      vel[idx3 + 2] += this.config.wind.z * dt;

      // Integrate position
      pos[idx3] += vel[idx3] * dt;
      pos[idx3 + 1] += vel[idx3 + 1] * dt;
      pos[idx3 + 2] += vel[idx3 + 2] * dt;

      // Color lerp
      const curCol = cStart.clone().lerp(cEnd, lifeRatio);
      col[idx3] = curCol.r;
      col[idx3 + 1] = curCol.g;
      col[idx3 + 2] = curCol.b;

      // Size interpolation
      sizes[i] = THREE.MathUtils.lerp(this.config.sizeStart, this.config.sizeEnd, lifeRatio);
    }

    this.geometry.attributes.position.needsUpdate = true;
    this.geometry.attributes.color.needsUpdate = true;
    this.geometry.attributes.size.needsUpdate = true;
  }
}

// Mass-Spring Cloth Simulator
export class AardClothEngine {
  public geometry: THREE.PlaneGeometry;
  public mesh: THREE.Mesh;
  public positions: Float32Array;
  private prevPositions: Float32Array;
  private pinned: Set<number>;

  constructor(public config: AardClothData) {
    const { gridX, gridY, spacing } = config;
    this.geometry = new THREE.PlaneGeometry(gridX * spacing, gridY * spacing, gridX - 1, gridY - 1);
    this.positions = this.geometry.attributes.position.array as Float32Array;
    this.prevPositions = new Float32Array(this.positions);
    this.pinned = new Set(config.pinnedVertices);

    const mat = new THREE.MeshPhysicalMaterial({
      color: 0x991b1b,
      roughness: 0.35,
      metalness: 0.1,
      sheen: 1.0,
      sheenColor: new THREE.Color(0xfca5a5),
      side: THREE.DoubleSide,
    });

    this.mesh = new THREE.Mesh(this.geometry, mat);
  }

  public update(dt: number, time: number) {
    const pos = this.positions;
    const prev = this.prevPositions;
    const count = pos.length / 3;
    const damping = this.config.damping;
    const windStr = noise.noise3D(time * 2, 0, 0) * 3.5;

    // Verlet Integration
    for (let i = 0; i < count; i++) {
      if (this.pinned.has(i)) continue;

      const idx = i * 3;
      const x = pos[idx];
      const y = pos[idx + 1];
      const z = pos[idx + 2];

      const px = prev[idx];
      const py = prev[idx + 1];
      const pz = prev[idx + 2];

      let vx = (x - px) * damping;
      let vy = (y - py) * damping;
      let vz = (z - pz) * damping;

      // Forces: Gravity + Wind
      vy -= this.config.gravity * dt * dt;
      vz += (this.config.wind.z + windStr) * dt * dt;

      prev[idx] = x;
      prev[idx + 1] = y;
      prev[idx + 2] = z;

      pos[idx] = x + vx;
      pos[idx + 1] = y + vy;
      pos[idx + 2] = z + vz;
    }

    // Constraint Satisfaction (Distance springs)
    const { gridX, gridY, spacing } = this.config;
    for (let iter = 0; iter < 4; iter++) {
      for (let y = 0; y < gridY; y++) {
        for (let x = 0; x < gridX; x++) {
          const i1 = y * gridX + x;

          // Right neighbor
          if (x < gridX - 1) {
            const i2 = y * gridX + (x + 1);
            this.relaxConstraint(i1, i2, spacing);
          }
          // Bottom neighbor
          if (y < gridY - 1) {
            const i2 = (y + 1) * gridX + x;
            this.relaxConstraint(i1, i2, spacing);
          }
        }
      }
    }

    this.geometry.attributes.position.needsUpdate = true;
    this.geometry.computeVertexNormals();
  }

  private relaxConstraint(i1: number, i2: number, restLength: number) {
    const p = this.positions;
    const idx1 = i1 * 3;
    const idx2 = i2 * 3;

    const dx = p[idx2] - p[idx1];
    const dy = p[idx2 + 1] - p[idx1 + 1];
    const dz = p[idx2 + 2] - p[idx1 + 2];

    const dist = Math.sqrt(dx * dx + dy * dy + dz * dz) + 0.00001;
    const diff = (dist - restLength) / dist;

    const p1Pinned = this.pinned.has(i1);
    const p2Pinned = this.pinned.has(i2);

    if (!p1Pinned && !p2Pinned) {
      p[idx1] += dx * 0.5 * diff;
      p[idx1 + 1] += dy * 0.5 * diff;
      p[idx1 + 2] += dz * 0.5 * diff;

      p[idx2] -= dx * 0.5 * diff;
      p[idx2 + 1] -= dy * 0.5 * diff;
      p[idx2 + 2] -= dz * 0.5 * diff;
    } else if (!p1Pinned) {
      p[idx1] += dx * diff;
      p[idx1 + 1] += dy * diff;
      p[idx1 + 2] += dz * diff;
    } else if (!p2Pinned) {
      p[idx2] -= dx * diff;
      p[idx2 + 1] -= dy * diff;
      p[idx2 + 2] -= dz * diff;
    }
  }
}
