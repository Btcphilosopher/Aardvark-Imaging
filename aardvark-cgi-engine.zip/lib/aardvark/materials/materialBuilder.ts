// AARDVARK PBR MATERIAL ENGINE & PROCEDURAL SHADER COMPILER

import * as THREE from 'three';
import { AardMaterialData, ProceduralTextureType } from '../core/types';

// Texture procedural generator cache
const proceduralTextureCache = new Map<string, THREE.CanvasTexture>();

export function createProceduralCanvasTexture(
  type: ProceduralTextureType,
  scale: number = 1.0,
  baseHex: string = '#ffffff'
): THREE.CanvasTexture | null {
  if (type === 'none') return null;

  const cacheKey = `${type}_${scale}_${baseHex}`;
  if (proceduralTextureCache.has(cacheKey)) {
    return proceduralTextureCache.get(cacheKey)!;
  }

  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d');
  if (!ctx) return null;

  const w = canvas.width;
  const h = canvas.height;

  // Render procedural pattern
  switch (type) {
    case 'grid': {
      ctx.fillStyle = '#0f131a';
      ctx.fillRect(0, 0, w, h);
      ctx.strokeStyle = '#2b3548';
      ctx.lineWidth = 2;
      const step = 32 / scale;
      for (let x = 0; x <= w; x += step) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let y = 0; y <= h; y += step) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }
      break;
    }

    case 'brushed_metal': {
      ctx.fillStyle = '#b0b5be';
      ctx.fillRect(0, 0, w, h);
      const imgData = ctx.getImageData(0, 0, w, h);
      const d = imgData.data;
      for (let y = 0; y < h; y++) {
        const rowNoise = (Math.random() - 0.5) * 45;
        for (let x = 0; x < w; x++) {
          const idx = (y * w + x) * 4;
          const grain = (Math.random() - 0.5) * 15 + rowNoise;
          d[idx] = Math.min(255, Math.max(0, 180 + grain));
          d[idx + 1] = Math.min(255, Math.max(0, 185 + grain));
          d[idx + 2] = Math.min(255, Math.max(0, 195 + grain));
          d[idx + 3] = 255;
        }
      }
      ctx.putImageData(imgData, 0, 0);
      break;
    }

    case 'carbon_fiber': {
      ctx.fillStyle = '#111215';
      ctx.fillRect(0, 0, w, h);
      const size = 16 / scale;
      for (let x = 0; x < w; x += size * 2) {
        for (let y = 0; y < h; y += size * 2) {
          ctx.fillStyle = '#22252c';
          ctx.fillRect(x, y, size, size);
          ctx.fillRect(x + size, y + size, size, size);
          ctx.fillStyle = '#181a1f';
          ctx.fillRect(x + size, y, size, size);
          ctx.fillRect(x, y + size, size, size);
        }
      }
      break;
    }

    case 'checker': {
      const tileSize = 32 / scale;
      for (let x = 0; x < w; x += tileSize) {
        for (let y = 0; y < h; y += tileSize) {
          const isEven = (Math.floor(x / tileSize) + Math.floor(y / tileSize)) % 2 === 0;
          ctx.fillStyle = isEven ? '#e2e8f0' : '#1e293b';
          ctx.fillRect(x, y, tileSize, tileSize);
        }
      }
      break;
    }

    case 'marble':
    case 'perlin': {
      ctx.fillStyle = '#1a202c';
      ctx.fillRect(0, 0, w, h);
      const imgData = ctx.getImageData(0, 0, w, h);
      const d = imgData.data;
      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
          const idx = (y * w + x) * 4;
          const nx = (x / w) * 6 * scale;
          const ny = (y / h) * 6 * scale;
          const val = Math.sin(nx + Math.sin(ny * 2.5) * 3.0);
          const bright = Math.floor((val + 1) * 0.5 * 255);
          d[idx] = bright;
          d[idx + 1] = Math.floor(bright * 0.9);
          d[idx + 2] = Math.floor(bright * 0.8);
          d[idx + 3] = 255;
        }
      }
      ctx.putImageData(imgData, 0, 0);
      break;
    }

    default:
      ctx.fillStyle = baseHex;
      ctx.fillRect(0, 0, w, h);
      break;
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(scale, scale);
  proceduralTextureCache.set(cacheKey, texture);
  return texture;
}

export function buildPhysicalMaterial(data: AardMaterialData): THREE.Material {
  const proceduralMap = createProceduralCanvasTexture(
    data.proceduralTexture,
    data.textureScale,
    data.color
  );

  const mat = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(data.color),
    metalness: data.metallic,
    roughness: data.roughness,
    ior: data.ior,
    transmission: data.transmission,
    thickness: data.transmission > 0 ? 1.5 : 0.0,
    specularIntensity: data.specular,
    clearcoat: data.clearcoat,
    clearcoatRoughness: data.clearcoatRoughness,
    sheen: data.sheen,
    sheenColor: data.sheenColor ? new THREE.Color(data.sheenColor) : new THREE.Color(data.color),
    emissive: new THREE.Color(data.emission),
    emissiveIntensity: data.emissionIntensity,
    opacity: data.opacity,
    transparent: data.opacity < 1.0 || data.transmission > 0,
    wireframe: data.wireframe,
    flatShading: data.flatShading,
    map: proceduralMap,
  });

  return mat;
}
