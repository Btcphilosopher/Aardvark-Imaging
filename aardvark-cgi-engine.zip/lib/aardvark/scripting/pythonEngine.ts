// AARDVARK PYTHON 3.13+ CREATIVE CORE RUNTIME & CODE <-> SCENE GENERATOR

import {
  AardDocument,
  AardObject,
  AardMaterialData,
  PrimitiveType,
  Vector3D,
} from '../core/types';
import { generateId, createDefaultDocument } from '../core/document';

export interface PythonExecutionResult {
  success: boolean;
  logs: string[];
  errors: string[];
  updatedDocument?: AardDocument;
}

export const SHOWCASE_PRESETS: Record<
  string,
  { name: string; description: string; code: string }
> = {
  turbomachine: {
    name: '1. Industrial Turbomachine (Digital Twin)',
    description: 'High-precision aerospace turbine: Titanium gold rotor blades, thermal combustor glow, and vortex exhaust',
    code: `# AARDVARK CGI BENCHMARK 1: INDUSTRIAL TURBOMACHINE (AEROSPACE DIGITAL TWIN)
import aard
import numpy as np

# 1. Initialize Scene & Master Settings
scene = aard.scene()
scene.seed = 42
scene.fps = 24

# 2. Procedural Turbomachine Assembly
turbomachine = aard.turbomachine(
    rpm=3600,
    blades=18,
    stages=4,
    casing_transparent=True,
    thermal_vis=True
)
turbomachine.location = (0, 0.5, 0)
turbomachine.material = aard.material("Machined Titanium Gold", metallic=0.96, roughness=0.15)

# 3. Dynamic Studio 3-Point Lighting
key_light = aard.light.area(
    location=(6, 8, 6),
    intensity=4.2,
    color="#fff5e6",
    size=(4, 4),
    cast_shadow=True
)

rim_light = aard.light.spot(
    location=(-7, 6, -6),
    intensity=6.0,
    color="#38bdf8",
    angle=45
)

fill_light = aard.light.point(
    location=(-5, 3, 5),
    intensity=1.5,
    color="#c084fc"
)

# 4. Physical Cinema Camera with Depth of Field
camera = aard.camera(
    location=(0, 3.2, 9.5),
    focal_length=50,
    aperture=2.4,
    focus_distance=9.5,
    dof=True
)
camera.turntable_rig(target=turbomachine, speed=1.0)

# 5. Volumetric Exhaust Particle Vortex
vortex = aard.particles(
    count=2500,
    emitter="ring",
    color_start="#ff7700",
    color_end="#00d4ff",
    vortex_strength=4.5,
    turbulence=1.8
)

# 6. Deterministic 360-Degree Continuous Rotation
turbomachine.animate("rotation.y", start=0, end=360, duration_frames=240)

print("[Aardvark CGI Engine] Compiled Industrial Turbomachine Digital Twin Scene.")
`,
  },

  cinematic_logo: {
    name: '2. Aardvark Cinematic Logo',
    description: 'Liquid gold & chrome monogram emerging from a procedural quantum particle field with volumetric rays',
    code: `# AARDVARK CGI BENCHMARK 2: CINEMATIC LOGO REVEAL
import aard

scene = aard.scene()
scene.seed = 101

# 1. Procedural Aardvark Monogram Emblem
logo = aard.mesh.logo(
    scale=(1.4, 1.4, 1.4)
)
logo.location = (0, 0.5, 0)
logo.material = aard.material("Polished Chrome Mirror", metallic=1.0, roughness=0.04)

# 2. Glowing Hexagonal Crest
crest = aard.mesh.torus(radius=3.2, tube=0.12, radial_segments=6)
crest.location = (0, 0.5, 0)
crest.material = aard.material("Neon Cyan Pulse", emission="#00f0ff", emission_intensity=5.0)

# 3. Quantum Nebula Particle Cloud
particles = aard.particles(
    count=3500,
    emitter="sphere",
    color_start="#00f0ff",
    color_end="#ff007f",
    vortex_strength=6.0,
    turbulence=2.4
)

# 4. Cinematic Sweeping Anamorphic Camera
camera = aard.camera(
    location=(0, 1.8, 8.0),
    focal_length=35,
    aperture=1.4,
    focus_distance=8.0,
    dof=True
)

# 5. Animation Tracks
logo.animate("rotation.y", start=-45, end=315, duration_frames=240)
crest.animate("rotation.z", start=0, end=360, duration_frames=240)

print("[Aardvark CGI Engine] Compiled Cinematic Logo Reveal Scene.")
`,
  },

  cyber_city: {
    name: '3. Procedural Sci-Fi Cyber City',
    description: 'Data-driven parametric metropolis with lighted skyscrapers, spires, and traffic grids',
    code: `# AARDVARK CGI BENCHMARK 3: PROCEDURAL SCI-FI CYBER METROPOLIS
import aard

scene = aard.scene()
scene.seed = 888

# 1. Procedural City Matrix Generator (36 Skyscrapers)
city = aard.city(
    buildings=49,
    seed=888,
    neon_density=0.8
)
city.location = (0, 0, 0)
city.material = aard.material("Dark Carbon Infrastructure", color="#15171e", roughness=0.5, metallic=0.4)

# 2. Atmospheric Mood Lighting
sun = aard.light.directional(
    location=(20, 35, 20),
    intensity=1.2,
    color="#38bdf8"
)

cyber_glow = aard.light.point(
    location=(0, 8, 0),
    intensity=8.0,
    color="#ff0055"
)

# 3. High Altitude Helicopter Flyover Camera
camera = aard.camera(
    location=(18, 16, 22),
    focal_length=24,
    aperture=2.8,
    focus_distance=24.0,
    dof=False
)

camera.animate("location.x", start=22, end=-18, duration_frames=240)
camera.animate("location.z", start=22, end=14, duration_frames=240)

print("[Aardvark CGI Engine] Compiled Procedural Cyber City Scene.")
`,
  },

  cloth_particles: {
    name: '4. Cloth & Particle Physics Symphony',
    description: 'Real-time mass-spring cloth fluttering in turbulent wind accompanied by glowing fluid particles',
    code: `# AARDVARK CGI BENCHMARK 4: CLOTH SIMULATION & TURBULENT PARTICLES
import aard

scene = aard.scene()

# 1. Silken Cloth Banner Simulation
cloth = aard.cloth(
    grid_x=16,
    grid_y=16,
    spacing=0.25,
    mass=0.8,
    damping=0.98,
    gravity=9.8
)
cloth.location = (-1.8, 2.5, 0)

# 2. Floating Crystal Sphere Collider
sphere = aard.mesh.sphere(radius=1.2)
sphere.location = (1.5, 0.5, 0)
sphere.material = aard.material("Optical Crystal Glass", transmission=0.95, roughness=0.02, ior=1.52)

# 3. Wind Vortex Particles
particles = aard.particles(
    count=2000,
    emitter="box",
    speed=2.5,
    color_start="#38bdf8",
    color_end="#ec4899",
    turbulence=3.0
)

# 4. Cinematic Lighting
light = aard.light.spot(location=(5, 7, 5), intensity=5.0, color="#ffffff")

camera = aard.camera(location=(0, 2.0, 7.5), focal_length=50, aperture=1.8, dof=True)

print("[Aardvark CGI Engine] Compiled Cloth & Physics Symphony.")
`,
  },

  product_turntable: {
    name: '5. Luxury Product Visualizer',
    description: 'High-end industrial timepiece turntable with studio reflections, brushed gold & optical glass',
    code: `# AARDVARK CGI BENCHMARK 5: LUXURY PRODUCT TURNTABLE
import aard

scene = aard.scene()

# 1. Luxury Chronograph Bezel & Body
case_outer = aard.mesh.torus(radius=2.0, tube=0.35, tubular_segments=64)
case_outer.material = aard.material("Brushed Gold 18K", color="#e5a93c", metallic=0.95, roughness=0.18)

dial = aard.mesh.cylinder(radius=1.8, height=0.1, segments=64)
dial.location = (0, 0, 0)
dial.material = aard.material("Carbon Fiber Dial", procedural="carbon_fiber", roughness=0.4)

crystal = aard.mesh.cylinder(radius=1.85, height=0.08, segments=64)
crystal.location = (0, 0.15, 0)
crystal.material = aard.material("Sapphire Crystal Glass", transmission=0.96, roughness=0.01, ior=1.77)

# 2. Studio 3-Point Overhead Rig
overhead = aard.light.area(location=(0, 6, 0), intensity=5.0, size=(5, 5), color="#ffffff")
rim = aard.light.spot(location=(-4, 3, -4), intensity=4.0, color="#93c5fd")

camera = aard.camera(location=(0, 2.8, 5.8), focal_length=85, aperture=1.4, focus_distance=5.8, dof=True)
case_outer.animate("rotation.y", start=0, end=360, duration_frames=240)

print("[Aardvark CGI Engine] Compiled Luxury Product Studio.")
`,
  },

  generative_attractor: {
    name: '6. Mathematical Lorenz Attractor & Chaos',
    description: 'Chaos theory mathematical curves visualized with procedural iridescent glowing ribbon geometry',
    code: `# AARDVARK CGI BENCHMARK 6: MATHEMATICAL GENERATIVE CHAOS
import aard
import numpy as np

scene = aard.scene()

# 1. Parametric Helix / Attractor Ribbon
helix = aard.mesh.helix(radius=1.8, tube_radius=0.25)
helix.material = aard.material("Cyber Iridescent", color="#a855f7", emission="#06b6d4", emission_intensity=3.5)

core = aard.mesh.icosphere(radius=1.0, subdivisions=3)
core.material = aard.material("Mirror Chrome", metallic=1.0, roughness=0.02)

# 2. Cosmic Ambient Light
light = aard.light.point(location=(0, 0, 0), intensity=6.0, color="#e879f9")
camera = aard.camera(location=(0, 2.5, 7.5), focal_length=40, aperture=2.0)

helix.animate("rotation.y", start=0, end=360, duration_frames=240)
helix.animate("rotation.x", start=0, end=180, duration_frames=240)

print("[Aardvark CGI Engine] Compiled Mathematical Generative Chaos.")
`,
  },
};

// Python execution simulator for the Aardvark CGI DSL
export function executeAardvarkPythonScript(
  script: string,
  baseDoc: AardDocument
): PythonExecutionResult {
  const logs: string[] = [];
  const errors: string[] = [];
  const doc: AardDocument = JSON.parse(JSON.stringify(baseDoc));

  try {
    logs.push(`>>> Aardvark Python 3.13 Interpreter Initialized.`);

    // Quick regex parser to detect scene configurations
    if (script.includes('aard.scene()')) {
      logs.push(`[aard.scene] Initialized clean Scene Graph context.`);
    }

    // Match turbomachine generator
    if (script.includes('turbomachine(') || script.includes('aard.turbomachine')) {
      const matchRpm = script.match(/rpm\s*=\s*(\d+)/);
      const matchBlades = script.match(/blades\s*=\s*(\d+)/);
      const matchStages = script.match(/stages\s*=\s*(\d+)/);

      const rpm = matchRpm ? parseInt(matchRpm[1], 10) : 3600;
      const blades = matchBlades ? parseInt(matchBlades[1], 10) : 16;
      const stages = matchStages ? parseInt(matchStages[1], 10) : 4;

      // Ensure turbomachine object exists
      let turboObj = Object.values(doc.objects).find(
        (o) => o.primitiveType === 'turbomachine'
      );
      if (!turboObj) {
        const id = generateId('turbo');
        turboObj = {
          id,
          name: 'Aardvark Turbomachine Turbine',
          type: 'turbomachine',
          visible: true,
          locked: false,
          parentId: null,
          childrenIds: [],
          transform: {
            position: { x: 0, y: 0.5, z: 0 },
            rotation: { x: 0, y: 0, z: 0, order: 'XYZ' },
            scale: { x: 1, y: 1, z: 1 },
          },
          primitiveType: 'turbomachine',
          parametricProps: { rpm, blades, stages, casingTransparent: true, thermalVis: true },
          modifiers: [],
          materialId: 'mat_gold',
          animationTracks: [
            {
              id: generateId('track'),
              property: 'transform.rotation.y',
              keyframes: [
                { frame: 0, value: 0 },
                { frame: 240, value: 360 },
              ],
            },
          ],
        };
        doc.objects[id] = turboObj;
      } else {
        turboObj.parametricProps = {
          ...turboObj.parametricProps,
          rpm,
          blades,
          stages,
        };
      }
      logs.push(`[aard.turbomachine] Built Turbomachine: RPM=${rpm}, Blades=${blades}, Stages=${stages}`);
    }

    // Match procedural city
    if (script.includes('aard.city') || script.includes('city(')) {
      const matchB = script.match(/buildings\s*=\s*(\d+)/);
      const matchSeed = script.match(/seed\s*=\s*(\d+)/);
      const buildings = matchB ? parseInt(matchB[1], 10) : 36;
      const seed = matchSeed ? parseInt(matchSeed[1], 10) : 42;

      let cityObj = Object.values(doc.objects).find((o) => o.primitiveType === 'city');
      if (!cityObj) {
        const id = generateId('city');
        cityObj = {
          id,
          name: 'Procedural Cyber City',
          type: 'procedural_city',
          visible: true,
          locked: false,
          parentId: null,
          childrenIds: [],
          transform: {
            position: { x: 0, y: 0, z: 0 },
            rotation: { x: 0, y: 0, z: 0, order: 'XYZ' },
            scale: { x: 1, y: 1, z: 1 },
          },
          primitiveType: 'city',
          parametricProps: { buildingsCount: buildings, citySeed: seed },
          modifiers: [],
          materialId: 'mat_carbon',
          animationTracks: [],
        };
        doc.objects[id] = cityObj;
      } else {
        cityObj.parametricProps = {
          ...cityObj.parametricProps,
          buildingsCount: buildings,
          citySeed: seed,
        };
      }
      logs.push(`[aard.city] Generated Procedural City Matrix with ${buildings} Skyscrapers.`);
    }

    // Match logo
    if (script.includes('mesh.logo') || script.includes('aard.mesh.logo')) {
      let logoObj = Object.values(doc.objects).find((o) => o.primitiveType === 'logo');
      if (!logoObj) {
        const id = generateId('logo');
        logoObj = {
          id,
          name: 'Aardvark Monogram Crest',
          type: 'mesh',
          visible: true,
          locked: false,
          parentId: null,
          childrenIds: [],
          transform: {
            position: { x: 0, y: 0.5, z: 0 },
            rotation: { x: 0, y: 0, z: 0, order: 'XYZ' },
            scale: { x: 1.2, y: 1.2, z: 1.2 },
          },
          primitiveType: 'logo',
          parametricProps: {},
          modifiers: [],
          materialId: 'mat_chrome',
          animationTracks: [
            {
              id: generateId('track'),
              property: 'transform.rotation.y',
              keyframes: [
                { frame: 0, value: 0 },
                { frame: 240, value: 360 },
              ],
            },
          ],
        };
        doc.objects[id] = logoObj;
      }
      logs.push(`[aard.mesh.logo] Created Aardvark Monogram Emblem.`);
    }

    // Match particles
    if (script.includes('aard.particles(') || script.includes('particles(')) {
      const matchCount = script.match(/count\s*=\s*(\d+)/);
      const count = matchCount ? parseInt(matchCount[1], 10) : 2400;

      const pObj = Object.values(doc.objects).find((o) => o.type === 'particle_system');
      if (pObj && pObj.particleData) {
        pObj.particleData.count = count;
      }
      logs.push(`[aard.particles] Configured Particle Vortex with ${count} live simulation particles.`);
    }

    // Parse print statements
    const printMatches = script.match(/print\((["'])(.*?)\1\)/g);
    if (printMatches) {
      for (const p of printMatches) {
        const text = p.replace(/^print\(["']|["']\)$/g, '');
        logs.push(text);
      }
    }

    logs.push(`[Aardvark Scene Graph] Synchronized ${Object.keys(doc.objects).length} 3D objects with WebGL GPU renderer.`);
    doc.pythonScript = script;

    return {
      success: true,
      logs,
      errors: [],
      updatedDocument: doc,
    };
  } catch (err: any) {
    errors.push(err.message || String(err));
    return {
      success: false,
      logs,
      errors,
    };
  }
}

// Scene Graph -> Python Script generator
export function generatePythonScriptFromScene(doc: AardDocument): string {
  let py = `# AARDVARK CGI ENGINE - GENERATED SCENE SCRIPT
import aard

scene = aard.scene()
scene.fps = ${doc.renderSettings.fps}
scene.resolution = (${doc.renderSettings.resolution.width}, ${doc.renderSettings.resolution.height})

# --- MATERIALS ---
`;

  for (const mat of Object.values(doc.materials)) {
    py += `mat_${mat.id} = aard.material(
    name="${mat.name}",
    color="${mat.color}",
    metallic=${mat.metallic},
    roughness=${mat.roughness},
    transmission=${mat.transmission},
    emission="${mat.emission}",
    emission_intensity=${mat.emissionIntensity}
)\n\n`;
  }

  py += `# --- OBJECTS & CAMERAS ---\n`;
  for (const obj of Object.values(doc.objects)) {
    const pos = obj.transform.position;
    const rot = obj.transform.rotation;
    const sc = obj.transform.scale;

    if (obj.type === 'camera' && obj.cameraData) {
      py += `camera = aard.camera(
    location=(${pos.x.toFixed(2)}, ${pos.y.toFixed(2)}, ${pos.z.toFixed(2)}),
    focal_length=${obj.cameraData.focalLength},
    aperture=${obj.cameraData.aperture},
    focus_distance=${obj.cameraData.focusDistance},
    dof=${obj.cameraData.depthOfField ? 'True' : 'False'}
)\n\n`;
    } else if (obj.type === 'light' && obj.lightData) {
      py += `light_${obj.id} = aard.light.${obj.lightData.type}(
    location=(${pos.x.toFixed(2)}, ${pos.y.toFixed(2)}, ${pos.z.toFixed(2)}),
    intensity=${obj.lightData.intensity},
    color="${obj.lightData.color}"
)\n\n`;
    } else if (obj.primitiveType) {
      py += `obj_${obj.id} = aard.mesh.${obj.primitiveType}(
    location=(${pos.x.toFixed(2)}, ${pos.y.toFixed(2)}, ${pos.z.toFixed(2)}),
    rotation=(${rot.x.toFixed(1)}, ${rot.y.toFixed(1)}, ${rot.z.toFixed(1)}),
    scale=(${sc.x.toFixed(2)}, ${sc.y.toFixed(2)}, ${sc.z.toFixed(2)})
)\n`;
      if (obj.materialId) {
        py += `obj_${obj.id}.material = mat_${obj.materialId}\n`;
      }
      py += `\n`;
    }
  }

  py += `print(f"[Aardvark Engine] Synchronized {len(scene.objects)} objects.")\n`;
  return py;
}
