// AARDVARK CGI ENGINE - CORE TYPES & DOCUMENT SCHEMA

export type ID = string;

export interface Vector3D {
  x: number;
  y: number;
  z: number;
}

export interface Vector4D {
  x: number;
  y: number;
  z: number;
  w: number;
}

export interface EulerRot {
  x: number;
  y: number;
  z: number;
  order?: 'XYZ' | 'YXZ' | 'ZXY' | 'ZYX' | 'YZX' | 'XZY';
}

export interface AardTransform {
  position: Vector3D;
  rotation: EulerRot; // In degrees
  quaternion?: Vector4D;
  scale: Vector3D;
}

// Render Quality Levels (Section 91)
export type RenderQualityLevel = 0 | 1 | 2 | 3 | 4 | 5 | 6;
// 0: WIREFRAME
// 1: REALTIME SOLID
// 2: MATERIAL PREVIEW
// 3: HIGH QUALITY PBR
// 4: CGI STUDIO (Bloom, SSAO, SSR)
// 5: PATH TRACE / ACCUMULATION
// 6: FINAL PRODUCTION MASTER

export type ViewportMode =
  | 'wireframe'
  | 'solid'
  | 'material'
  | 'lit'
  | 'rendered'
  | 'pathtrace'
  | 'aov_depth'
  | 'aov_normal'
  | 'aov_albedo'
  | 'aov_roughness'
  | 'aov_emission'
  | 'aov_cryptomatte';

export type WorkspaceMode =
  | 'MODEL'
  | 'SCULPT'
  | 'MATERIAL'
  | 'ANIMATE'
  | 'VFX'
  | 'PHYSICS'
  | 'LIGHTING'
  | 'CAMERA'
  | 'COMPOSITE'
  | 'SEQUENCER'
  | 'SCRIPT'
  | 'AI_GEN';

export type ObjectType =
  | 'mesh'
  | 'curve'
  | 'surface'
  | 'light'
  | 'camera'
  | 'armature'
  | 'particle_system'
  | 'cloth'
  | 'fluid'
  | 'volume'
  | 'turbomachine'
  | 'procedural_city'
  | 'empty'
  | 'group';

export type PrimitiveType =
  | 'cube'
  | 'sphere'
  | 'icosphere'
  | 'cylinder'
  | 'cone'
  | 'torus'
  | 'plane'
  | 'circle'
  | 'capsule'
  | 'pyramid'
  | 'helix'
  | 'grid'
  | 'terrain'
  | 'teapot'
  | 'text3d'
  | 'turbomachine'
  | 'city'
  | 'logo';

export interface ParametricProps {
  radius?: number;
  radius2?: number;
  width?: number;
  height?: number;
  depth?: number;
  size?: number;
  segments?: number;
  rings?: number;
  tubeRadius?: number;
  tubularSegments?: number;
  radialSegments?: number;
  arc?: number;
  subdivisions?: number;
  // Terrain
  roughness?: number;
  heightScale?: number;
  octaves?: number;
  // Text 3D
  text?: string;
  fontSize?: number;
  extrusionDepth?: number;
  bevelEnabled?: boolean;
  bevelThickness?: number;
  bevelSize?: number;
  // Turbomachine
  rpm?: number;
  blades?: number;
  stages?: number;
  casingTransparent?: boolean;
  thermalVis?: boolean;
  // City
  buildingsCount?: number;
  citySeed?: number;
  neonDensity?: number;
  // Curve / Revolve
  curvePath?: Vector3D[];
  latheSegments?: number;
}

export type ModifierType =
  | 'subdivision'
  | 'bevel'
  | 'mirror'
  | 'array'
  | 'solidify'
  | 'displace'
  | 'boolean'
  | 'decimate'
  | 'smooth'
  | 'lattice'
  | 'curve_deform'
  | 'geometry_nodes';

export interface AardModifier {
  id: ID;
  name: string;
  type: ModifierType;
  enabled: boolean;
  params: {
    levels?: number; // subdivision
    renderLevels?: number;
    width?: number; // bevel
    segments?: number;
    axis?: 'x' | 'y' | 'z'; // mirror
    count?: number; // array
    offset?: Vector3D;
    thickness?: number; // solidify
    strength?: number; // displace
    texture?: 'perlin' | 'worley' | 'wave';
    operation?: 'union' | 'difference' | 'intersect'; // boolean
    targetObjectId?: ID;
    ratio?: number; // decimate
    factor?: number; // smooth
  };
}

export type LightType = 'directional' | 'point' | 'spot' | 'area' | 'environment' | 'emissive';

export interface AardLightData {
  type: LightType;
  color: string;
  intensity: number;
  distance?: number;
  decay?: number;
  angle?: number;
  penumbra?: number;
  castShadow: boolean;
  shadowSoftness?: number;
  shadowMapSize?: number;
  areaSize?: { width: number; height: number };
  temperature?: number; // Kelvin
}

export type CameraType = 'perspective' | 'orthographic' | 'panoramic' | 'fisheye';

export interface AardCameraData {
  type: CameraType;
  fov: number; // For perspective
  focalLength: number; // in mm (e.g. 24, 35, 50, 85)
  sensorSize: number; // in mm (e.g. 36 for full frame)
  aperture: number; // F-Stop (e.g. 1.4, 2.8, 5.6)
  focusDistance: number; // in units
  depthOfField: boolean;
  bokehSize?: number;
  near: number;
  far: number;
  iso?: number;
  shutterSpeed?: number;
  rigMode?: 'free' | 'orbit' | 'turntable' | 'dolly' | 'crane' | 'follow' | 'lookat';
  targetObjectId?: ID;
}

export type ProceduralTextureType =
  | 'none'
  | 'perlin'
  | 'simplex'
  | 'worley'
  | 'voronoi'
  | 'marble'
  | 'wood'
  | 'brick'
  | 'brushed_metal'
  | 'carbon_fiber'
  | 'grid'
  | 'checker'
  | 'gradient';

export interface AardMaterialData {
  id: ID;
  name: string;
  color: string;
  metallic: number;
  roughness: number;
  specular: number;
  ior: number;
  transmission: number; // Glass / transparent
  subsurface: number; // SSS
  subsurfaceColor?: string;
  clearcoat: number;
  clearcoatRoughness: number;
  sheen: number;
  sheenColor?: string;
  emission: string;
  emissionIntensity: number;
  opacity: number;
  wireframe: boolean;
  flatShading: boolean;
  proceduralTexture: ProceduralTextureType;
  textureScale: number;
  normalScale: number;
  displacementScale: number;
}

export interface AardParticleSystemData {
  enabled?: boolean;
  count: number;
  rate?: number;
  lifetime: number;
  speed: number;
  spread: number;
  emitterType: 'point' | 'sphere' | 'box' | 'mesh' | 'ring';
  emitterSize: Vector3D;
  colorStart: string;
  colorEnd: string;
  sizeStart: number;
  sizeEnd: number;
  gravity: Vector3D;
  wind: Vector3D;
  turbulence: number;
  vortex: number;
  trails?: boolean;
}

export interface AardClothData {
  enabled?: boolean;
  gridX: number;
  gridY: number;
  spacing: number;
  mass: number;
  damping: number;
  stretchStiffness?: number;
  bendStiffness?: number;
  pinnedVertices: number[];
  wind: Vector3D;
  gravity: number;
}

export interface AardRigidBodyData {
  enabled?: boolean;
  type: 'dynamic' | 'static' | 'kinematic';
  collider: 'box' | 'sphere' | 'capsule' | 'mesh' | 'plane';
  mass: number;
  restitution?: number; // Bounciness
  friction?: number;
  linearDamping?: number;
  angularDamping?: number;
  velocity?: Vector3D;
  angularVelocity?: Vector3D;
}

export interface Keyframe {
  frame: number;
  value: number | Vector3D | EulerRot | string;
  easing?: 'linear' | 'easeIn' | 'easeOut' | 'easeInOut' | 'bezier';
}

export interface AnimationTrack {
  id: ID;
  property: string; // e.g. "transform.position.x", "material.roughness", "light.intensity"
  keyframes: Keyframe[];
}

export interface AardObject {
  id: ID;
  name: string;
  type: ObjectType;
  visible: boolean;
  locked: boolean;
  parentId: ID | null;
  childrenIds: ID[];
  transform: AardTransform;
  primitiveType?: PrimitiveType;
  parametricProps?: ParametricProps;
  modifiers: AardModifier[];
  materialId?: ID;
  lightData?: AardLightData;
  cameraData?: AardCameraData;
  particleData?: AardParticleSystemData;
  clothData?: AardClothData;
  rigidBodyData?: AardRigidBodyData;
  animationTracks: AnimationTrack[];
  customAttributes?: Record<string, any>;
  tags?: string[];
}

export interface AardCollection {
  id: ID;
  name: string;
  visible: boolean;
  color: string;
  objectIds: ID[];
}

export interface PostProcessSettings {
  acesToneMapping: boolean;
  exposure: number;
  contrast: number;
  bloomEnabled: boolean;
  bloomStrength: number;
  bloomRadius: number;
  bloomThreshold: number;
  dofEnabled: boolean;
  dofFocusDistance: number;
  dofAperture: number;
  chromaticAberration: number;
  vignetteStrength: number;
  filmGrain: number;
  ambientOcclusion: boolean;
  ssaoIntensity: number;
  fogEnabled: boolean;
  fogColor: string;
  fogNear: number;
  fogFar: number;
}

export interface RenderSettings {
  engine: 'raster' | 'pathtrace' | 'hybrid';
  qualityLevel: RenderQualityLevel;
  resolution: { width: number; height: number };
  fps: number;
  startFrame: number;
  endFrame: number;
  currentFrame: number;
  samples: number;
  bounces: number;
  denoise: boolean;
  motionBlur: boolean;
  motionBlurSamples: number;
  antialiasing: boolean;
  postProcess: PostProcessSettings;
}

export interface NodeGraphNode {
  id: ID;
  title: string;
  type: string;
  category: 'input' | 'math' | 'geometry' | 'texture' | 'filter' | 'output';
  position: { x: number; y: number };
  inputs: { id: string; name: string; type: string; value?: any }[];
  outputs: { id: string; name: string; type: string; value?: any }[];
  params?: Record<string, any>;
}

export interface NodeGraphConnection {
  id: ID;
  fromNodeId: ID;
  fromOutputId: string;
  toNodeId: ID;
  toInputId: string;
}

export interface NodeGraph {
  id: ID;
  name: string;
  type: 'geometry' | 'shader' | 'vfx' | 'compositor';
  nodes: NodeGraphNode[];
  connections: NodeGraphConnection[];
}

export interface AardDocument {
  version: string;
  id: ID;
  name: string;
  author: string;
  createdAt: string;
  updatedAt: string;
  scenes: {
    id: ID;
    name: string;
    activeCameraId: ID;
    activeCollectionId: ID;
  }[];
  collections: AardCollection[];
  objects: Record<ID, AardObject>;
  materials: Record<ID, AardMaterialData>;
  nodeGraphs: NodeGraph[];
  pythonScript: string;
  renderSettings: RenderSettings;
  audioTrack?: {
    enabled: boolean;
    bpm: number;
    duration: number;
  };
}
