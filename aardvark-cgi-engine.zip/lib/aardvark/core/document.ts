// AARDVARK 3D DOCUMENT FACTORY & SERIALIZATION

import {
  AardDocument,
  AardObject,
  AardMaterialData,
  AardCollection,
  ID,
  RenderSettings,
} from './types';

export function generateId(prefix: string = 'aard'): ID {
  return `${prefix}_${Math.random().toString(36).substr(2, 9)}`;
}

export function createDefaultRenderSettings(): RenderSettings {
  return {
    engine: 'raster',
    qualityLevel: 4, // CGI Studio quality by default
    resolution: { width: 1920, height: 1080 },
    fps: 24,
    startFrame: 0,
    endFrame: 240,
    currentFrame: 0,
    samples: 128,
    bounces: 4,
    denoise: true,
    motionBlur: true,
    motionBlurSamples: 8,
    antialiasing: true,
    postProcess: {
      acesToneMapping: true,
      exposure: 1.15,
      contrast: 1.05,
      bloomEnabled: true,
      bloomStrength: 0.6,
      bloomRadius: 0.5,
      bloomThreshold: 0.85,
      dofEnabled: false,
      dofFocusDistance: 6.0,
      dofAperture: 2.8,
      chromaticAberration: 0.002,
      vignetteStrength: 0.25,
      filmGrain: 0.02,
      ambientOcclusion: true,
      ssaoIntensity: 1.2,
      fogEnabled: true,
      fogColor: '#0a0d14',
      fogNear: 15,
      fogFar: 80,
    },
  };
}

export function createDefaultMaterials(): Record<ID, AardMaterialData> {
  const materials: Record<ID, AardMaterialData> = {
    mat_gold: {
      id: 'mat_gold',
      name: 'Machined Titanium Gold',
      color: '#e6ba53',
      metallic: 0.95,
      roughness: 0.18,
      specular: 1.0,
      ior: 1.45,
      transmission: 0.0,
      subsurface: 0.0,
      clearcoat: 0.4,
      clearcoatRoughness: 0.1,
      sheen: 0.0,
      emission: '#000000',
      emissionIntensity: 0.0,
      opacity: 1.0,
      wireframe: false,
      flatShading: false,
      proceduralTexture: 'brushed_metal',
      textureScale: 4.0,
      normalScale: 0.3,
      displacementScale: 0.0,
    },
    mat_chrome: {
      id: 'mat_chrome',
      name: 'Polished Mirror Chrome',
      color: '#ffffff',
      metallic: 1.0,
      roughness: 0.04,
      specular: 1.0,
      ior: 2.4,
      transmission: 0.0,
      subsurface: 0.0,
      clearcoat: 1.0,
      clearcoatRoughness: 0.02,
      sheen: 0.0,
      emission: '#000000',
      emissionIntensity: 0.0,
      opacity: 1.0,
      wireframe: false,
      flatShading: false,
      proceduralTexture: 'none',
      textureScale: 1.0,
      normalScale: 0.0,
      displacementScale: 0.0,
    },
    mat_glass: {
      id: 'mat_glass',
      name: 'Optical Crystal Glass',
      color: '#d4ebf2',
      metallic: 0.0,
      roughness: 0.02,
      specular: 1.0,
      ior: 1.52,
      transmission: 0.92,
      subsurface: 0.0,
      clearcoat: 1.0,
      clearcoatRoughness: 0.01,
      sheen: 0.0,
      emission: '#000000',
      emissionIntensity: 0.0,
      opacity: 0.3,
      wireframe: false,
      flatShading: false,
      proceduralTexture: 'none',
      textureScale: 1.0,
      normalScale: 0.0,
      displacementScale: 0.0,
    },
    mat_carbon: {
      id: 'mat_carbon',
      name: 'Carbon Fiber Weave',
      color: '#1a1b1e',
      metallic: 0.3,
      roughness: 0.45,
      specular: 0.8,
      ior: 1.4,
      transmission: 0.0,
      subsurface: 0.0,
      clearcoat: 0.8,
      clearcoatRoughness: 0.15,
      sheen: 0.2,
      emission: '#000000',
      emissionIntensity: 0.0,
      opacity: 1.0,
      wireframe: false,
      flatShading: false,
      proceduralTexture: 'carbon_fiber',
      textureScale: 8.0,
      normalScale: 0.6,
      displacementScale: 0.0,
    },
    mat_studio_floor: {
      id: 'mat_studio_floor',
      name: 'Studio Dark Concrete',
      color: '#161922',
      metallic: 0.1,
      roughness: 0.75,
      specular: 0.5,
      ior: 1.5,
      transmission: 0.0,
      subsurface: 0.0,
      clearcoat: 0.1,
      clearcoatRoughness: 0.8,
      sheen: 0.0,
      emission: '#000000',
      emissionIntensity: 0.0,
      opacity: 1.0,
      wireframe: false,
      flatShading: false,
      proceduralTexture: 'grid',
      textureScale: 2.0,
      normalScale: 0.4,
      displacementScale: 0.0,
    },
    mat_neon_cyan: {
      id: 'mat_neon_cyan',
      name: 'Cyber Neon Cyan',
      color: '#00f0ff',
      metallic: 0.0,
      roughness: 0.2,
      specular: 0.5,
      ior: 1.0,
      transmission: 0.0,
      subsurface: 0.0,
      clearcoat: 0.0,
      clearcoatRoughness: 0.0,
      sheen: 0.0,
      emission: '#00f0ff',
      emissionIntensity: 4.5,
      opacity: 1.0,
      wireframe: false,
      flatShading: false,
      proceduralTexture: 'none',
      textureScale: 1.0,
      normalScale: 0.0,
      displacementScale: 0.0,
    },
    mat_hot_thermal: {
      id: 'mat_hot_thermal',
      name: 'Combustor Thermal Glow',
      color: '#ff4800',
      metallic: 0.2,
      roughness: 0.3,
      specular: 0.8,
      ior: 1.4,
      transmission: 0.0,
      subsurface: 0.0,
      clearcoat: 0.0,
      clearcoatRoughness: 0.0,
      sheen: 0.0,
      emission: '#ff5500',
      emissionIntensity: 6.0,
      opacity: 1.0,
      wireframe: false,
      flatShading: false,
      proceduralTexture: 'perlin',
      textureScale: 5.0,
      normalScale: 0.0,
      displacementScale: 0.0,
    },
  };
  return materials;
}

export function createDefaultDocument(): AardDocument {
  const materials = createDefaultMaterials();

  const cameraObj: AardObject = {
    id: 'cam_main',
    name: 'Cinematic Cinema Camera',
    type: 'camera',
    visible: true,
    locked: false,
    parentId: null,
    childrenIds: [],
    transform: {
      position: { x: 0, y: 3.2, z: 9.5 },
      rotation: { x: -14, y: 0, z: 0, order: 'XYZ' },
      scale: { x: 1, y: 1, z: 1 },
    },
    modifiers: [],
    cameraData: {
      type: 'perspective',
      fov: 42,
      focalLength: 50,
      sensorSize: 36,
      aperture: 2.4,
      focusDistance: 9.5,
      depthOfField: true,
      bokehSize: 0.03,
      near: 0.1,
      far: 1000,
      rigMode: 'turntable',
    },
    animationTracks: [],
  };

  const keyLight: AardObject = {
    id: 'light_key',
    name: 'Key Light (Warm Softbox)',
    type: 'light',
    visible: true,
    locked: false,
    parentId: null,
    childrenIds: [],
    transform: {
      position: { x: 6, y: 8, z: 6 },
      rotation: { x: -45, y: 40, z: 0, order: 'XYZ' },
      scale: { x: 1, y: 1, z: 1 },
    },
    modifiers: [],
    lightData: {
      type: 'area',
      color: '#fff5e6',
      intensity: 3.8,
      castShadow: true,
      shadowSoftness: 1.5,
      shadowMapSize: 2048,
      areaSize: { width: 4, height: 4 },
      temperature: 5400,
    },
    animationTracks: [],
  };

  const rimLight: AardObject = {
    id: 'light_rim',
    name: 'Rim Light (Cyan Accent)',
    type: 'light',
    visible: true,
    locked: false,
    parentId: null,
    childrenIds: [],
    transform: {
      position: { x: -7, y: 6, z: -6 },
      rotation: { x: 30, y: -135, z: 0, order: 'XYZ' },
      scale: { x: 1, y: 1, z: 1 },
    },
    modifiers: [],
    lightData: {
      type: 'spot',
      color: '#38bdf8',
      intensity: 5.5,
      angle: 45,
      penumbra: 0.6,
      castShadow: true,
      distance: 30,
      temperature: 8000,
    },
    animationTracks: [],
  };

  const fillLight: AardObject = {
    id: 'light_fill',
    name: 'Fill Light (Violet Ambient)',
    type: 'light',
    visible: true,
    locked: false,
    parentId: null,
    childrenIds: [],
    transform: {
      position: { x: -5, y: 3, z: 5 },
      rotation: { x: -20, y: -30, z: 0, order: 'XYZ' },
      scale: { x: 1, y: 1, z: 1 },
    },
    modifiers: [],
    lightData: {
      type: 'point',
      color: '#c084fc',
      intensity: 1.4,
      castShadow: false,
      distance: 25,
    },
    animationTracks: [],
  };

  const turbomachineHero: AardObject = {
    id: 'obj_turbomachine_hero',
    name: 'Aardvark Turbomachine Turbine',
    type: 'turbomachine',
    visible: true,
    locked: false,
    parentId: null,
    childrenIds: [],
    transform: {
      position: { x: 0, y: 0.5, z: 0 },
      rotation: { x: 0, y: 25, z: 0, order: 'XYZ' },
      scale: { x: 1, y: 1, z: 1 },
    },
    primitiveType: 'turbomachine',
    parametricProps: {
      rpm: 3600,
      blades: 16,
      stages: 4,
      casingTransparent: true,
      thermalVis: true,
    },
    modifiers: [
      {
        id: 'mod_subdiv_1',
        name: 'Catmull-Clark Subdiv',
        type: 'subdivision',
        enabled: true,
        params: { levels: 1, renderLevels: 2 },
      },
    ],
    materialId: 'mat_gold',
    animationTracks: [
      {
        id: 'track_rot_y',
        property: 'transform.rotation.y',
        keyframes: [
          { frame: 0, value: 0 },
          { frame: 240, value: 360 },
        ],
      },
    ],
  };

  const studioFloor: AardObject = {
    id: 'obj_studio_floor',
    name: 'Infinite Studio Floor',
    type: 'mesh',
    visible: true,
    locked: true,
    parentId: null,
    childrenIds: [],
    transform: {
      position: { x: 0, y: -1.5, z: 0 },
      rotation: { x: -90, y: 0, z: 0, order: 'XYZ' },
      scale: { x: 1, y: 1, z: 1 },
    },
    primitiveType: 'plane',
    parametricProps: {
      width: 60,
      height: 60,
      segments: 30,
    },
    modifiers: [],
    materialId: 'mat_studio_floor',
    animationTracks: [],
  };

  const particleVortex: AardObject = {
    id: 'obj_particles_vortex',
    name: 'Exhaust Particle Vortex',
    type: 'particle_system',
    visible: true,
    locked: false,
    parentId: null,
    childrenIds: [],
    transform: {
      position: { x: 0, y: 0.5, z: 0 },
      rotation: { x: 0, y: 0, z: 0, order: 'XYZ' },
      scale: { x: 1, y: 1, z: 1 },
    },
    modifiers: [],
    particleData: {
      enabled: true,
      count: 2400,
      rate: 80,
      lifetime: 3.5,
      speed: 3.0,
      spread: 0.4,
      emitterType: 'ring',
      emitterSize: { x: 1.8, y: 0.2, z: 1.8 },
      colorStart: '#ff7700',
      colorEnd: '#00d4ff',
      sizeStart: 0.12,
      sizeEnd: 0.02,
      gravity: { x: 0, y: 0.5, z: 0 },
      wind: { x: 0, y: 0, z: 2.0 },
      turbulence: 1.8,
      vortex: 4.5,
      trails: true,
    },
    animationTracks: [],
  };

  const objects: Record<ID, AardObject> = {
    [cameraObj.id]: cameraObj,
    [keyLight.id]: keyLight,
    [rimLight.id]: rimLight,
    [fillLight.id]: fillLight,
    [turbomachineHero.id]: turbomachineHero,
    [studioFloor.id]: studioFloor,
    [particleVortex.id]: particleVortex,
  };

  const collections: AardCollection[] = [
    {
      id: 'col_scene',
      name: 'Main Rig & Geometry',
      visible: true,
      color: '#3b82f6',
      objectIds: [turbomachineHero.id, studioFloor.id, particleVortex.id],
    },
    {
      id: 'col_lighting',
      name: 'Studio Lighting & Cameras',
      visible: true,
      color: '#eab308',
      objectIds: [cameraObj.id, keyLight.id, rimLight.id, fillLight.id],
    },
  ];

  const defaultPythonScript = `# AARDVARK CGI ENGINE - PYTHON CREATIVE CORE
# Python 3.13+ Computational CGI Scene Script
import aard
import numpy as np

# Initialize Scene & Master Renderer
scene = aard.scene()
scene.seed = 42
scene.fps = 24

# 1. Turbomachine Stage Configuration
turbomachine = aard.turbomachine(
    rpm=3600,
    blades=16,
    stages=4,
    casing_transparent=True,
    thermal_vis=True
)
turbomachine.location = (0, 0.5, 0)
turbomachine.material = aard.material("Titanium Gold", metallic=0.95, roughness=0.18)

# 2. Studio Lighting Rig
key_light = aard.light.area(
    location=(6, 8, 6),
    intensity=3.8,
    color="#fff5e6",
    size=(4, 4),
    cast_shadow=True
)

rim_light = aard.light.spot(
    location=(-7, 6, -6),
    intensity=5.5,
    color="#38bdf8",
    angle=45
)

# 3. Cinematic Physical Camera
cam = aard.camera(
    location=(0, 3.2, 9.5),
    focal_length=50,
    aperture=2.4,
    focus_distance=9.5,
    dof=True
)
cam.turntable_rig(target=turbomachine, speed=1.0)

# 4. Exhaust Particle Vortex
vortex = aard.particles(
    count=2400,
    emitter="ring",
    color_start="#ff7700",
    color_end="#00d4ff",
    vortex_strength=4.5,
    turbulence=1.8
)

# 5. Deterministic Animation Binding
turbomachine.animate("rotation.y", start=0, end=360, duration_frames=240)

print(f"[Aardvark Engine] Compiled 3D Scene: {len(scene.objects)} objects ready for CGI Master Render.")
`;

  return {
    version: '2.4.0',
    id: 'doc_aardvark_main',
    name: 'Aardvark Industrial Turbomachine CGI',
    author: 'Aardvark CGI System',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    scenes: [
      {
        id: 'scene_01',
        name: 'Master Production Scene',
        activeCameraId: cameraObj.id,
        activeCollectionId: 'col_scene',
      },
    ],
    collections,
    objects,
    materials,
    nodeGraphs: [
      {
        id: 'graph_geom_turbomachine',
        name: 'Turbomachine Generator Graph',
        type: 'geometry',
        nodes: [
          {
            id: 'node_in_rpm',
            title: 'RPM Input',
            type: 'Float',
            category: 'input',
            position: { x: 50, y: 100 },
            inputs: [],
            outputs: [{ id: 'out_val', name: 'Value (3600)', type: 'float', value: 3600 }],
          },
          {
            id: 'node_blades',
            title: 'Blade Distribute',
            type: 'ArrayCircular',
            category: 'geometry',
            position: { x: 300, y: 120 },
            inputs: [{ id: 'in_count', name: 'Count (16)', type: 'int', value: 16 }],
            outputs: [{ id: 'out_geo', name: 'Blades', type: 'geometry' }],
          },
          {
            id: 'node_subdiv',
            title: 'Catmull-Clark Subdiv',
            type: 'Subdivision',
            category: 'geometry',
            position: { x: 550, y: 140 },
            inputs: [{ id: 'in_geo', name: 'Mesh', type: 'geometry' }],
            outputs: [{ id: 'out_geo', name: 'Subdivided', type: 'geometry' }],
          },
          {
            id: 'node_out',
            title: 'Geometry Output',
            type: 'Output',
            category: 'output',
            position: { x: 800, y: 150 },
            inputs: [{ id: 'in_final', name: 'Scene Mesh', type: 'geometry' }],
            outputs: [],
          },
        ],
        connections: [
          {
            id: 'conn_1',
            fromNodeId: 'node_in_rpm',
            fromOutputId: 'out_val',
            toNodeId: 'node_blades',
            toInputId: 'in_count',
          },
          {
            id: 'conn_2',
            fromNodeId: 'node_blades',
            fromOutputId: 'out_geo',
            toNodeId: 'node_subdiv',
            toInputId: 'in_geo',
          },
          {
            id: 'conn_3',
            fromNodeId: 'node_subdiv',
            fromOutputId: 'out_geo',
            toNodeId: 'node_out',
            toInputId: 'in_final',
          },
        ],
      },
    ],
    pythonScript: defaultPythonScript,
    renderSettings: createDefaultRenderSettings(),
  };
}
