'use client';

import React, { useState } from 'react';
import {
  AardDocument,
  RenderSettings,
} from '../../lib/aardvark/core/types';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Code2,
  Sliders,
  Sparkles,
  Layers,
  Terminal,
  RotateCcw,
  Plus,
  Send,
  Loader2,
  CheckCircle2,
  Film,
  Activity,
  Maximize2,
  Minimize2,
} from 'lucide-react';
import {
  executeAardvarkPythonScript,
  generatePythonScriptFromScene,
} from '../../lib/aardvark/scripting/pythonEngine';

interface BottomDockProps {
  doc: AardDocument;
  onUpdateDocument: (doc: AardDocument) => void;
  isPlaying: boolean;
  onTogglePlay: () => void;
  currentFrame: number;
  onSeekFrame: (frame: number) => void;
}

export const BottomDock: React.FC<BottomDockProps> = ({
  doc,
  onUpdateDocument,
  isPlaying,
  onTogglePlay,
  currentFrame,
  onSeekFrame,
}) => {
  const [activeTab, setActiveTab] = useState<'timeline' | 'python' | 'nodes' | 'compositor' | 'ai_gen'>('python');
  const [isExpanded, setIsExpanded] = useState(false);
  const [pythonCode, setPythonCode] = useState(doc.pythonScript);
  const [pythonLogs, setPythonLogs] = useState<string[]>([
    '>>> Aardvark CGI Engine Python 3.13 Runtime ready.',
    '>>> Type commands or run script to control the 3D scene.',
  ]);
  const [aiPrompt, setAiPrompt] = useState('');
  const [isGeneratingAi, setIsGeneratingAi] = useState(false);

  // Sync internal pythonCode when doc changes
  React.useEffect(() => {
    setPythonCode(doc.pythonScript);
  }, [doc.pythonScript]);

  const handleRunPython = () => {
    const result = executeAardvarkPythonScript(pythonCode, doc);
    setPythonLogs(result.logs.concat(result.errors.map((e) => `ERROR: ${e}`)));
    if (result.success && result.updatedDocument) {
      onUpdateDocument(result.updatedDocument);
    }
  };

  const handleSyncSceneToCode = () => {
    const generated = generatePythonScriptFromScene(doc);
    setPythonCode(generated);
    setPythonLogs((prev) => [...prev, '>>> Synchronized Python script from active Scene Graph.']);
  };

  const handleGenerateWithAi = async () => {
    if (!aiPrompt.trim()) return;
    setIsGeneratingAi(true);

    try {
      const res = await fetch('/api/gemini/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: aiPrompt, type: 'scene' }),
      });
      const data = await res.json();
      if (data.code) {
        setPythonCode(data.code);
        const result = executeAardvarkPythonScript(data.code, doc);
        setPythonLogs((prev) => [
          ...prev,
          `>>> Gemini AI generated CGI scene for prompt: "${aiPrompt}"`,
          ...result.logs,
        ]);
        if (result.success && result.updatedDocument) {
          onUpdateDocument(result.updatedDocument);
        }
        setActiveTab('python');
      }
    } catch (err: any) {
      setPythonLogs((prev) => [...prev, `ERROR generating scene: ${err.message}`]);
    } finally {
      setIsGeneratingAi(false);
    }
  };

  const updatePostProcess = (key: keyof RenderSettings['postProcess'], val: any) => {
    const updated: AardDocument = JSON.parse(JSON.stringify(doc));
    (updated.renderSettings.postProcess as any)[key] = val;
    onUpdateDocument(updated);
  };

  return (
    <div
      className={`bg-[#0c0f17] border-t border-white/10 flex flex-col select-none text-slate-300 z-20 transition-all duration-200 ${
        isExpanded ? 'h-96' : 'h-64'
      }`}
    >
      {/* Bottom Tabs Bar */}
      <div className="h-9 border-b border-white/10 bg-[#10131d] flex items-center justify-between px-3">
        <div className="flex items-center gap-1 text-xs">
          <button
            onClick={() => setActiveTab('timeline')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded transition-colors ${
              activeTab === 'timeline' ? 'bg-blue-600 text-white font-medium' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Film className="w-3.5 h-3.5" />
            <span>Timeline & Keyframes</span>
          </button>

          <button
            onClick={() => setActiveTab('python')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded transition-colors ${
              activeTab === 'python' ? 'bg-blue-600 text-white font-medium' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Code2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Python 3.13 IDE</span>
          </button>

          <button
            onClick={() => setActiveTab('nodes')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded transition-colors ${
              activeTab === 'nodes' ? 'bg-blue-600 text-white font-medium' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5 text-purple-400" />
            <span>Geometry Nodes</span>
          </button>

          <button
            onClick={() => setActiveTab('compositor')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded transition-colors ${
              activeTab === 'compositor' ? 'bg-blue-600 text-white font-medium' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sliders className="w-3.5 h-3.5 text-amber-400" />
            <span>Compositor & Post-FX</span>
          </button>

          <button
            onClick={() => setActiveTab('ai_gen')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded transition-colors ${
              activeTab === 'ai_gen' ? 'bg-indigo-600 text-white font-medium' : 'text-indigo-300 hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>AI Scene Prompt</span>
          </button>
        </div>

        {/* Right Dock Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 text-slate-400 hover:text-white rounded hover:bg-white/5"
            title="Toggle Expanded Dock"
          >
            {isExpanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* TAB CONTENTS */}
      <div className="flex-1 overflow-hidden">
        {/* TIMELINE */}
        {activeTab === 'timeline' && (
          <div className="h-full flex flex-col p-3 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => onSeekFrame(0)}
                  className="p-1 rounded bg-white/5 hover:bg-white/10 text-slate-300"
                  title="First Frame"
                >
                  <SkipBack className="w-4 h-4" />
                </button>
                <button
                  onClick={onTogglePlay}
                  className="px-3 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white font-semibold flex items-center gap-1.5"
                >
                  {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  <span>{isPlaying ? 'Pause' : 'Play'}</span>
                </button>
                <span className="font-mono text-xs text-blue-400">
                  Frame <strong className="text-white text-sm">{currentFrame}</strong> / 240 ({(currentFrame / 24).toFixed(2)}s)
                </span>
              </div>
              <span className="text-[11px] text-slate-500 font-mono">24.00 FPS • ACEScg Cinema Standard</span>
            </div>

            {/* Frame Scrubber Bar */}
            <div className="relative pt-2">
              <input
                type="range"
                min="0"
                max="240"
                value={currentFrame}
                onChange={(e) => onSeekFrame(parseInt(e.target.value, 10))}
                className="w-full accent-blue-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono px-1">
                <span>0f (0.0s)</span>
                <span>60f (2.5s)</span>
                <span>120f (5.0s)</span>
                <span>180f (7.5s)</span>
                <span>240f (10.0s)</span>
              </div>
            </div>

            {/* Tracks visualizer */}
            <div className="flex-1 bg-[#141824] rounded-lg border border-white/5 p-2 overflow-y-auto space-y-1 font-mono text-[11px]">
              <div className="flex items-center justify-between px-2 py-1 bg-white/5 rounded text-slate-300">
                <span>turbomachine.rotation.y [0° → 360°]</span>
                <span className="text-emerald-400">Continuous 240f Loop</span>
              </div>
              <div className="flex items-center justify-between px-2 py-1 bg-white/5 rounded text-slate-300">
                <span>cam_main.turntable_rig [Orbit speed 1.0x]</span>
                <span className="text-blue-400">360° Cinematic Sweeper</span>
              </div>
              <div className="flex items-center justify-between px-2 py-1 bg-white/5 rounded text-slate-300">
                <span>particles.vortex [Dynamic Flow Integration]</span>
                <span className="text-pink-400">Physics Verlet Solver</span>
              </div>
            </div>
          </div>
        )}

        {/* PYTHON 3.13 IDE */}
        {activeTab === 'python' && (
          <div className="h-full flex">
            {/* Code Editor */}
            <div className="flex-1 flex flex-col border-r border-white/10">
              <div className="p-2 border-b border-white/10 bg-[#121520] flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 text-slate-300 font-mono">
                  <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                  <span>main_scene.py (Aardvark Python 3.13 DSL)</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleSyncSceneToCode}
                    className="flex items-center gap-1 px-2.5 py-1 rounded bg-white/5 hover:bg-white/10 text-slate-300 text-xs transition-colors"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Scene → Code</span>
                  </button>
                  <button
                    onClick={handleRunPython}
                    className="flex items-center gap-1 px-3 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow-md transition-colors"
                  >
                    <Play className="w-3 h-3 fill-current" />
                    <span>Run Script (Ctrl+Enter)</span>
                  </button>
                </div>
              </div>
              <textarea
                value={pythonCode}
                onChange={(e) => setPythonCode(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                    e.preventDefault();
                    handleRunPython();
                  }
                }}
                spellCheck={false}
                className="flex-1 w-full bg-[#0a0d14] text-emerald-300 font-mono text-xs p-3 outline-none resize-none selection:bg-blue-600/40"
              />
            </div>

            {/* Live Stdout / Stderr Terminal */}
            <div className="w-80 flex flex-col bg-[#090b10]">
              <div className="p-2 border-b border-white/10 bg-[#121520] text-xs font-mono text-slate-400 flex items-center justify-between">
                <span>Aardvark stdout / stderr</span>
                <span className="text-[10px] text-emerald-400">Kernel Active</span>
              </div>
              <div className="flex-1 p-3 font-mono text-[11px] overflow-y-auto space-y-1 text-slate-300">
                {pythonLogs.map((log, idx) => (
                  <div
                    key={idx}
                    className={
                      log.startsWith('ERROR')
                        ? 'text-red-400'
                        : log.startsWith('>>>')
                        ? 'text-blue-400 font-semibold'
                        : 'text-slate-300'
                    }
                  >
                    {log}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* NODE GRAPH */}
        {activeTab === 'nodes' && (
          <div className="h-full flex flex-col p-3">
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="font-semibold text-white flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-purple-400" />
                Geometry Node Graph: Turbomachine Procedural Generator
              </span>
              <span className="text-[11px] text-slate-400 font-mono">4 Active Processing Nodes</span>
            </div>

            <div className="flex-1 bg-[#121622] rounded-xl border border-white/10 relative p-4 flex items-center justify-around overflow-hidden">
              {/* Node 1: RPM Input */}
              <div className="w-44 bg-[#1a2030] border border-blue-500/40 rounded-lg p-2.5 shadow-xl text-xs space-y-2">
                <div className="font-bold text-blue-400 text-[11px] border-b border-white/10 pb-1">Float Input: RPM</div>
                <div className="text-[11px] text-slate-300">Value: 3600.0</div>
                <div className="text-right text-[10px] text-blue-400 font-mono">● Out Float</div>
              </div>

              <div className="w-8 h-[2px] bg-blue-500/50" />

              {/* Node 2: Circular Array */}
              <div className="w-48 bg-[#1a2030] border border-purple-500/40 rounded-lg p-2.5 shadow-xl text-xs space-y-2">
                <div className="font-bold text-purple-400 text-[11px] border-b border-white/10 pb-1">Circular Array (Blades)</div>
                <div className="text-[10px] text-purple-400 font-mono">● In Count: 16</div>
                <div className="text-right text-[10px] text-purple-400 font-mono">● Out Geometry</div>
              </div>

              <div className="w-8 h-[2px] bg-purple-500/50" />

              {/* Node 3: Subdivision */}
              <div className="w-48 bg-[#1a2030] border border-emerald-500/40 rounded-lg p-2.5 shadow-xl text-xs space-y-2">
                <div className="font-bold text-emerald-400 text-[11px] border-b border-white/10 pb-1">Catmull-Clark Subdiv</div>
                <div className="text-[10px] text-emerald-400 font-mono">● In Mesh</div>
                <div className="text-right text-[10px] text-emerald-400 font-mono">● Out Subdivided</div>
              </div>

              <div className="w-8 h-[2px] bg-emerald-500/50" />

              {/* Node 4: Scene Output */}
              <div className="w-44 bg-[#1a2030] border border-amber-500/40 rounded-lg p-2.5 shadow-xl text-xs space-y-2">
                <div className="font-bold text-amber-400 text-[11px] border-b border-white/10 pb-1">Master Output</div>
                <div className="text-[10px] text-amber-400 font-mono">● In Geometry</div>
                <div className="text-[10px] text-emerald-400 font-semibold">Active in Viewport</div>
              </div>
            </div>
          </div>
        )}

        {/* COMPOSITOR & POST-FX */}
        {activeTab === 'compositor' && (
          <div className="h-full p-4 grid grid-cols-4 gap-4 text-xs overflow-y-auto">
            {/* Tone Mapping & Exposure */}
            <div className="bg-[#141824] p-3 rounded-xl border border-white/5 space-y-2.5">
              <span className="font-semibold text-white block">Tone Mapping & Exposure</span>
              <div>
                <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                  <span>Exposure</span>
                  <span className="font-mono text-white">{doc.renderSettings.postProcess.exposure.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="2.5"
                  step="0.05"
                  value={doc.renderSettings.postProcess.exposure}
                  onChange={(e) => updatePostProcess('exposure', parseFloat(e.target.value))}
                  className="w-full accent-blue-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                  <span>Contrast</span>
                  <span className="font-mono text-white">{doc.renderSettings.postProcess.contrast.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min="0.8"
                  max="1.5"
                  step="0.05"
                  value={doc.renderSettings.postProcess.contrast}
                  onChange={(e) => updatePostProcess('contrast', parseFloat(e.target.value))}
                  className="w-full accent-blue-500"
                />
              </div>
            </div>

            {/* Bloom & Glare */}
            <div className="bg-[#141824] p-3 rounded-xl border border-white/5 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-white">Anamorphic Bloom</span>
                <input
                  type="checkbox"
                  checked={doc.renderSettings.postProcess.bloomEnabled}
                  onChange={(e) => updatePostProcess('bloomEnabled', e.target.checked)}
                  className="accent-blue-500"
                />
              </div>
              <div>
                <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                  <span>Strength</span>
                  <span className="font-mono text-white">{doc.renderSettings.postProcess.bloomStrength.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="2"
                  step="0.05"
                  value={doc.renderSettings.postProcess.bloomStrength}
                  onChange={(e) => updatePostProcess('bloomStrength', parseFloat(e.target.value))}
                  className="w-full accent-blue-500"
                />
              </div>
            </div>

            {/* Cinematic Lens FX */}
            <div className="bg-[#141824] p-3 rounded-xl border border-white/5 space-y-2.5">
              <span className="font-semibold text-white block">Lens Imperfections</span>
              <div>
                <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                  <span>Vignette Strength</span>
                  <span className="font-mono text-white">{doc.renderSettings.postProcess.vignetteStrength.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="0.8"
                  step="0.05"
                  value={doc.renderSettings.postProcess.vignetteStrength}
                  onChange={(e) => updatePostProcess('vignetteStrength', parseFloat(e.target.value))}
                  className="w-full accent-blue-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                  <span>Film Grain</span>
                  <span className="font-mono text-white">{doc.renderSettings.postProcess.filmGrain.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="0.1"
                  step="0.01"
                  value={doc.renderSettings.postProcess.filmGrain}
                  onChange={(e) => updatePostProcess('filmGrain', parseFloat(e.target.value))}
                  className="w-full accent-blue-500"
                />
              </div>
            </div>

            {/* Depth Fog */}
            <div className="bg-[#141824] p-3 rounded-xl border border-white/5 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-white">Atmospheric Fog</span>
                <input
                  type="checkbox"
                  checked={doc.renderSettings.postProcess.fogEnabled}
                  onChange={(e) => updatePostProcess('fogEnabled', e.target.checked)}
                  className="accent-blue-500"
                />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400 text-[11px]">Fog Color</span>
                <input
                  type="color"
                  value={doc.renderSettings.postProcess.fogColor}
                  onChange={(e) => updatePostProcess('fogColor', e.target.value)}
                  className="w-8 h-8 rounded border border-white/20 cursor-pointer bg-transparent"
                />
              </div>
            </div>
          </div>
        )}

        {/* AI SCENE GENERATOR */}
        {activeTab === 'ai_gen' && (
          <div className="h-full p-4 flex flex-col justify-center max-w-3xl mx-auto space-y-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-indigo-400" />
              <div>
                <h3 className="font-semibold text-sm text-white">Gemini AI Scene & Shader Generator</h3>
                <p className="text-xs text-slate-400">
                  Describe any 3D CGI scene, procedural turbomachine, lighting setup, or particle system in natural language.
                </p>
              </div>
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                placeholder="e.g. 'Create a supersonic scramjet turbomachine with 24 glowing titanium blades and cyan plasma vortex'"
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleGenerateWithAi();
                }}
                className="flex-1 bg-[#141824] border border-indigo-500/30 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-400"
              />
              <button
                onClick={handleGenerateWithAi}
                disabled={isGeneratingAi}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-semibold text-xs rounded-xl flex items-center gap-2 shadow-lg shadow-indigo-500/20 transition-all"
              >
                {isGeneratingAi ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                <span>Generate Scene</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
