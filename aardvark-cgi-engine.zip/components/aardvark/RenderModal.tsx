'use client';

import React, { useState } from 'react';
import {
  AardDocument,
} from '../../lib/aardvark/core/types';
import {
  X,
  Camera,
  Download,
  Layers,
  Sparkles,
  CheckCircle2,
  Sliders,
  Cpu,
  RefreshCw,
} from 'lucide-react';

interface RenderModalProps {
  isOpen: boolean;
  onClose: () => void;
  doc: AardDocument;
}

export const RenderModal: React.FC<RenderModalProps> = ({
  isOpen,
  onClose,
  doc,
}) => {
  const [activePass, setActivePass] = useState<'beauty' | 'depth' | 'normal' | 'crypto'>('beauty');
  const [resolution, setResolution] = useState<'1080p' | '4k'>('1080p');
  const [samples, setSamples] = useState(256);
  const [isRendering, setIsRendering] = useState(false);
  const [renderProgress, setRenderProgress] = useState(100);

  if (!isOpen) return null;

  const triggerRender = () => {
    setIsRendering(true);
    setRenderProgress(0);
    const interval = setInterval(() => {
      setRenderProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsRendering(false);
          return 100;
        }
        return prev + 20;
      });
    }, 150);
  };

  const handleDownload = (format: 'png' | 'exr') => {
    // Simulate high-res image download
    const canvas = document.querySelector('canvas');
    if (canvas) {
      const link = document.createElement('a');
      link.download = `aardvark_render_${activePass}_${Date.now()}.${format === 'exr' ? 'exr' : 'png'}`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-6 select-none">
      <div className="w-full max-w-4xl bg-[#0f121a] border border-white/10 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 border-b border-white/10 flex items-center justify-between bg-[#121520]">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-blue-600 flex items-center justify-center shadow-lg shadow-blue-500/30">
              <Camera className="w-4 h-4 text-white" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white tracking-wide">
                Aardvark CGI Master Production Renderer
              </h2>
              <p className="text-[11px] text-slate-400">
                Spectrally accurate, multi-pass CGI frame observation kernel
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left: Render Frame Preview */}
          <div className="flex-1 bg-[#080a0f] p-6 flex flex-col items-center justify-center relative">
            <div className="w-full aspect-video rounded-xl bg-[#0c0f17] border border-white/10 overflow-hidden relative shadow-2xl flex items-center justify-center">
              {/* Live Render Canvas Reflection */}
              <div className="absolute inset-0 flex items-center justify-center">
                {activePass === 'beauty' && (
                  <div className="text-center">
                    <div className="w-24 h-24 rounded-full border-4 border-blue-500/20 border-t-blue-500 animate-spin mx-auto mb-3" />
                    <span className="text-xs text-slate-300 font-mono">Beauty Pass (ACEScg Color Pipeline)</span>
                  </div>
                )}
                {activePass === 'depth' && (
                  <div className="text-center bg-gradient-to-b from-white via-slate-500 to-black w-full h-full flex items-center justify-center">
                    <span className="text-xs font-mono bg-black/60 px-3 py-1.5 rounded text-white">
                      Z-Depth Range: 0.1m - 1000m
                    </span>
                  </div>
                )}
                {activePass === 'normal' && (
                  <div className="text-center bg-gradient-to-tr from-cyan-500 via-pink-500 to-emerald-500 w-full h-full flex items-center justify-center">
                    <span className="text-xs font-mono bg-black/60 px-3 py-1.5 rounded text-white">
                      Tangent Surface Normals
                    </span>
                  </div>
                )}
                {activePass === 'crypto' && (
                  <div className="text-center bg-gradient-to-r from-red-500 via-yellow-500 to-blue-500 w-full h-full flex items-center justify-center">
                    <span className="text-xs font-mono bg-black/60 px-3 py-1.5 rounded text-white">
                      Cryptomatte Object ID Isolation
                    </span>
                  </div>
                )}
              </div>

              {/* Progress Overlay */}
              {isRendering && (
                <div className="absolute inset-0 bg-black/70 backdrop-blur-xs flex flex-col items-center justify-center p-6 text-center">
                  <span className="text-xs font-semibold text-white mb-2">
                    Path Tracing Frame... {renderProgress}%
                  </span>
                  <div className="w-48 h-1.5 bg-white/20 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue-500 transition-all duration-150"
                      style={{ width: `${renderProgress}%` }}
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Render Passes Switcher */}
            <div className="flex items-center gap-2 mt-4 bg-[#121622] p-1 rounded-xl border border-white/10 text-xs">
              <button
                onClick={() => setActivePass('beauty')}
                className={`px-3 py-1 rounded-lg transition-colors ${
                  activePass === 'beauty' ? 'bg-blue-600 text-white font-medium' : 'text-slate-400 hover:text-white'
                }`}
              >
                Combined Beauty
              </button>
              <button
                onClick={() => setActivePass('depth')}
                className={`px-3 py-1 rounded-lg transition-colors ${
                  activePass === 'depth' ? 'bg-blue-600 text-white font-medium' : 'text-slate-400 hover:text-white'
                }`}
              >
                Z-Depth
              </button>
              <button
                onClick={() => setActivePass('normal')}
                className={`px-3 py-1 rounded-lg transition-colors ${
                  activePass === 'normal' ? 'bg-blue-600 text-white font-medium' : 'text-slate-400 hover:text-white'
                }`}
              >
                Surface Normals
              </button>
              <button
                onClick={() => setActivePass('crypto')}
                className={`px-3 py-1 rounded-lg transition-colors ${
                  activePass === 'crypto' ? 'bg-blue-600 text-white font-medium' : 'text-slate-400 hover:text-white'
                }`}
              >
                Cryptomatte
              </button>
            </div>
          </div>

          {/* Right: Render Settings & Export */}
          <div className="w-72 bg-[#10131d] border-l border-white/10 p-4 flex flex-col justify-between text-xs space-y-4">
            <div className="space-y-3.5">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                Render Parameters
              </span>

              <div>
                <label className="text-slate-400 text-[11px] block mb-1">Resolution</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setResolution('1080p')}
                    className={`py-1.5 rounded-lg border text-xs transition-colors ${
                      resolution === '1080p'
                        ? 'bg-blue-600/20 border-blue-500 text-white font-semibold'
                        : 'border-white/10 text-slate-400 hover:text-white'
                    }`}
                  >
                    1080p (1920×1080)
                  </button>
                  <button
                    onClick={() => setResolution('4k')}
                    className={`py-1.5 rounded-lg border text-xs transition-colors ${
                      resolution === '4k'
                        ? 'bg-blue-600/20 border-blue-500 text-white font-semibold'
                        : 'border-white/10 text-slate-400 hover:text-white'
                    }`}
                  >
                    4K UHD (3840×2160)
                  </button>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                  <span>Samples Per Pixel (SPP)</span>
                  <span className="font-mono text-white">{samples} SPP</span>
                </div>
                <input
                  type="range"
                  min="64"
                  max="1024"
                  step="64"
                  value={samples}
                  onChange={(e) => setSamples(parseInt(e.target.value, 10))}
                  className="w-full accent-blue-500 cursor-pointer"
                />
              </div>

              <div className="space-y-2 pt-2 border-t border-white/10">
                <label className="flex items-center justify-between text-slate-300">
                  <span>AI Temporal Denoise</span>
                  <input type="checkbox" defaultChecked className="accent-blue-500" />
                </label>
                <label className="flex items-center justify-between text-slate-300">
                  <span>Motion Blur (Sub-frame)</span>
                  <input type="checkbox" defaultChecked className="accent-blue-500" />
                </label>
                <label className="flex items-center justify-between text-slate-300">
                  <span>Color Management: ACEScg</span>
                  <input type="checkbox" defaultChecked className="accent-blue-500" />
                </label>
              </div>
            </div>

            {/* Actions */}
            <div className="space-y-2 pt-4 border-t border-white/10">
              <button
                onClick={triggerRender}
                className="w-full py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-lg shadow-blue-500/20 transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Compute Master Frame</span>
              </button>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => handleDownload('png')}
                  className="py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 text-xs flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Download className="w-3 h-3" />
                  <span>PNG 16-bit</span>
                </button>
                <button
                  onClick={() => handleDownload('exr')}
                  className="py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 text-xs flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Download className="w-3 h-3" />
                  <span>OpenEXR 32-bit</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
