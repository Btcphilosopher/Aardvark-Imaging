'use client';

import React, { useState } from 'react';
import {
  AardDocument,
  AardObject,
  ID,
  PrimitiveType,
  LightType,
} from '../../lib/aardvark/core/types';
import { generateId } from '../../lib/aardvark/core/document';
import {
  Eye,
  EyeOff,
  Lock,
  Unlock,
  Trash2,
  Copy,
  Plus,
  Search,
  Box,
  Sun,
  Camera,
  Flame,
  Sparkles,
  Layers,
  ChevronRight,
  ChevronDown,
  Wind,
  Cpu,
  Building,
} from 'lucide-react';

interface OutlinerProps {
  doc: AardDocument;
  selectedObjectId: ID | null;
  onSelectObject: (id: ID | null) => void;
  onUpdateDocument: (doc: AardDocument) => void;
}

export const Outliner: React.FC<OutlinerProps> = ({
  doc,
  selectedObjectId,
  onSelectObject,
  onUpdateDocument,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddMenu, setShowAddMenu] = useState(false);

  const toggleVisibility = (id: ID, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = { ...doc };
    if (updated.objects[id]) {
      updated.objects[id] = {
        ...updated.objects[id],
        visible: !updated.objects[id].visible,
      };
      onUpdateDocument(updated);
    }
  };

  const toggleLock = (id: ID, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = { ...doc };
    if (updated.objects[id]) {
      updated.objects[id] = {
        ...updated.objects[id],
        locked: !updated.objects[id].locked,
      };
      onUpdateDocument(updated);
    }
  };

  const deleteObject = (id: ID, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = { ...doc };
    delete updated.objects[id];
    // Remove from collections
    updated.collections = updated.collections.map((col) => ({
      ...col,
      objectIds: col.objectIds.filter((objId) => objId !== id),
    }));
    if (selectedObjectId === id) {
      onSelectObject(null);
    }
    onUpdateDocument(updated);
  };

  const duplicateObject = (id: ID, e: React.MouseEvent) => {
    e.stopPropagation();
    const src = doc.objects[id];
    if (!src) return;

    const newId = generateId(src.type);
    const cloned: AardObject = JSON.parse(JSON.stringify(src));
    cloned.id = newId;
    cloned.name = `${src.name} (Copy)`;
    cloned.transform.position.x += 1.5;

    const updated = { ...doc };
    updated.objects[newId] = cloned;
    onUpdateDocument(updated);
    onSelectObject(newId);
  };

  const addObject = (type: 'mesh' | 'light' | 'camera' | 'particle' | 'cloth', subType?: string) => {
    const updated = { ...doc };
    const id = generateId(type);
    let newObj: AardObject;

    if (type === 'light') {
      newObj = {
        id,
        name: `Studio ${subType || 'Point'} Light`,
        type: 'light',
        visible: true,
        locked: false,
        parentId: null,
        childrenIds: [],
        transform: {
          position: { x: 3, y: 5, z: 3 },
          rotation: { x: -30, y: 30, z: 0, order: 'XYZ' },
          scale: { x: 1, y: 1, z: 1 },
        },
        modifiers: [],
        lightData: {
          type: (subType as LightType) || 'point',
          color: '#ffffff',
          intensity: 4.0,
          castShadow: true,
        },
        animationTracks: [],
      };
    } else if (type === 'camera') {
      newObj = {
        id,
        name: 'Secondary Action Camera',
        type: 'camera',
        visible: true,
        locked: false,
        parentId: null,
        childrenIds: [],
        transform: {
          position: { x: 0, y: 2.5, z: 8 },
          rotation: { x: -10, y: 0, z: 0, order: 'XYZ' },
          scale: { x: 1, y: 1, z: 1 },
        },
        modifiers: [],
        cameraData: {
          type: 'perspective',
          fov: 45,
          focalLength: 50,
          sensorSize: 36,
          aperture: 2.8,
          focusDistance: 8.0,
          depthOfField: true,
          near: 0.1,
          far: 1000,
          rigMode: 'free',
        },
        animationTracks: [],
      };
    } else if (type === 'particle') {
      newObj = {
        id,
        name: 'Particle Energy Burst',
        type: 'particle_system',
        visible: true,
        locked: false,
        parentId: null,
        childrenIds: [],
        transform: {
          position: { x: 0, y: 1, z: 0 },
          rotation: { x: 0, y: 0, z: 0, order: 'XYZ' },
          scale: { x: 1, y: 1, z: 1 },
        },
        modifiers: [],
        particleData: {
          enabled: true,
          count: 1800,
          rate: 60,
          lifetime: 2.5,
          speed: 2.8,
          spread: 0.5,
          emitterType: 'sphere',
          emitterSize: { x: 1, y: 1, z: 1 },
          colorStart: '#38bdf8',
          colorEnd: '#ec4899',
          sizeStart: 0.1,
          sizeEnd: 0.02,
          gravity: { x: 0, y: -0.2, z: 0 },
          wind: { x: 0, y: 0, z: 0 },
          turbulence: 2.0,
          vortex: 2.0,
          trails: true,
        },
        animationTracks: [],
      };
    } else if (type === 'cloth') {
      newObj = {
        id,
        name: 'Simulated Silk Banner',
        type: 'cloth',
        visible: true,
        locked: false,
        parentId: null,
        childrenIds: [],
        transform: {
          position: { x: 0, y: 2.5, z: 0 },
          rotation: { x: 0, y: 0, z: 0, order: 'XYZ' },
          scale: { x: 1, y: 1, z: 1 },
        },
        modifiers: [],
        clothData: {
          gridX: 16,
          gridY: 16,
          spacing: 0.2,
          mass: 0.8,
          damping: 0.98,
          gravity: 9.8,
          pinnedVertices: [0, 15],
          wind: { x: 0.5, y: 0, z: 1.5 },
        },
        animationTracks: [],
      };
    } else {
      // Mesh primitive
      const prim = (subType as PrimitiveType) || 'cube';
      newObj = {
        id,
        name: `Parametric ${prim.charAt(0).toUpperCase() + prim.slice(1)}`,
        type: prim === 'turbomachine' ? 'turbomachine' : prim === 'city' ? 'procedural_city' : 'mesh',
        visible: true,
        locked: false,
        parentId: null,
        childrenIds: [],
        transform: {
          position: { x: 0, y: 0.5, z: 0 },
          rotation: { x: 0, y: 0, z: 0, order: 'XYZ' },
          scale: { x: 1, y: 1, z: 1 },
        },
        primitiveType: prim,
        parametricProps:
          prim === 'turbomachine'
            ? { rpm: 3600, blades: 16, stages: 4 }
            : prim === 'city'
            ? { buildingsCount: 36, citySeed: 101 }
            : { size: 2, radius: 1.2 },
        modifiers: [],
        materialId: 'mat_gold',
        animationTracks: [],
      };
    }

    updated.objects[id] = newObj;
    onUpdateDocument(updated);
    onSelectObject(id);
    setShowAddMenu(false);
  };

  const getObjectIcon = (obj: AardObject) => {
    if (obj.type === 'light') return <Sun className="w-3.5 h-3.5 text-amber-400" />;
    if (obj.type === 'camera') return <Camera className="w-3.5 h-3.5 text-cyan-400" />;
    if (obj.type === 'particle_system') return <Sparkles className="w-3.5 h-3.5 text-pink-400" />;
    if (obj.type === 'cloth') return <Wind className="w-3.5 h-3.5 text-purple-400" />;
    if (obj.primitiveType === 'turbomachine') return <Cpu className="w-3.5 h-3.5 text-blue-400" />;
    if (obj.primitiveType === 'city') return <Building className="w-3.5 h-3.5 text-emerald-400" />;
    return <Box className="w-3.5 h-3.5 text-blue-400" />;
  };

  const filteredObjects = Object.values(doc.objects).filter((obj) =>
    obj.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="w-72 bg-[#0f121a] border-r border-white/10 flex flex-col h-full select-none text-slate-300 z-20">
      {/* Header */}
      <div className="p-2.5 border-b border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-white uppercase tracking-wider">
          <Layers className="w-3.5 h-3.5 text-blue-400" />
          <span>Scene Outliner</span>
        </div>

        {/* Add Object Dropdown Button */}
        <div className="relative">
          <button
            onClick={() => setShowAddMenu(!showAddMenu)}
            className="flex items-center gap-1 px-2 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium transition-colors"
          >
            <Plus className="w-3 h-3" />
            <span>Add</span>
          </button>

          {showAddMenu && (
            <div className="absolute right-0 top-full mt-1.5 w-52 bg-[#141824] border border-white/10 rounded-xl shadow-2xl p-1.5 z-50 text-xs">
              <div className="text-[10px] uppercase font-semibold text-slate-400 px-2 py-1">
                Parametric Primitives
              </div>
              <button
                onClick={() => addObject('mesh', 'turbomachine')}
                className="w-full text-left px-2.5 py-1.5 rounded hover:bg-blue-600/20 hover:text-white flex items-center gap-2"
              >
                <Cpu className="w-3.5 h-3.5 text-blue-400" />
                <span>Turbomachine Stage</span>
              </button>
              <button
                onClick={() => addObject('mesh', 'city')}
                className="w-full text-left px-2.5 py-1.5 rounded hover:bg-blue-600/20 hover:text-white flex items-center gap-2"
              >
                <Building className="w-3.5 h-3.5 text-emerald-400" />
                <span>Procedural Cyber City</span>
              </button>
              <button
                onClick={() => addObject('mesh', 'logo')}
                className="w-full text-left px-2.5 py-1.5 rounded hover:bg-blue-600/20 hover:text-white flex items-center gap-2"
              >
                <Box className="w-3.5 h-3.5 text-indigo-400" />
                <span>Aardvark Monogram</span>
              </button>
              <button
                onClick={() => addObject('mesh', 'torus')}
                className="w-full text-left px-2.5 py-1.5 rounded hover:bg-blue-600/20 hover:text-white flex items-center gap-2"
              >
                <Box className="w-3.5 h-3.5 text-blue-400" />
                <span>Torus Ring</span>
              </button>
              <button
                onClick={() => addObject('mesh', 'sphere')}
                className="w-full text-left px-2.5 py-1.5 rounded hover:bg-blue-600/20 hover:text-white flex items-center gap-2"
              >
                <Box className="w-3.5 h-3.5 text-blue-400" />
                <span>UV Sphere</span>
              </button>
              <button
                onClick={() => addObject('mesh', 'helix')}
                className="w-full text-left px-2.5 py-1.5 rounded hover:bg-blue-600/20 hover:text-white flex items-center gap-2"
              >
                <Box className="w-3.5 h-3.5 text-blue-400" />
                <span>Attractor Helix</span>
              </button>

              <div className="w-full h-[1px] bg-white/10 my-1" />

              <div className="text-[10px] uppercase font-semibold text-slate-400 px-2 py-1">
                Lighting & Cameras
              </div>
              <button
                onClick={() => addObject('light', 'area')}
                className="w-full text-left px-2.5 py-1.5 rounded hover:bg-blue-600/20 hover:text-white flex items-center gap-2"
              >
                <Sun className="w-3.5 h-3.5 text-amber-400" />
                <span>Area Softbox Light</span>
              </button>
              <button
                onClick={() => addObject('light', 'spot')}
                className="w-full text-left px-2.5 py-1.5 rounded hover:bg-blue-600/20 hover:text-white flex items-center gap-2"
              >
                <Sun className="w-3.5 h-3.5 text-amber-400" />
                <span>Spotlight</span>
              </button>
              <button
                onClick={() => addObject('camera')}
                className="w-full text-left px-2.5 py-1.5 rounded hover:bg-blue-600/20 hover:text-white flex items-center gap-2"
              >
                <Camera className="w-3.5 h-3.5 text-cyan-400" />
                <span>Cinema Camera</span>
              </button>

              <div className="w-full h-[1px] bg-white/10 my-1" />

              <div className="text-[10px] uppercase font-semibold text-slate-400 px-2 py-1">
                VFX & Physics
              </div>
              <button
                onClick={() => addObject('particle')}
                className="w-full text-left px-2.5 py-1.5 rounded hover:bg-blue-600/20 hover:text-white flex items-center gap-2"
              >
                <Sparkles className="w-3.5 h-3.5 text-pink-400" />
                <span>Particle Vortex</span>
              </button>
              <button
                onClick={() => addObject('cloth')}
                className="w-full text-left px-2.5 py-1.5 rounded hover:bg-blue-600/20 hover:text-white flex items-center gap-2"
              >
                <Wind className="w-3.5 h-3.5 text-purple-400" />
                <span>Cloth Simulation</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Search Bar */}
      <div className="p-2 border-b border-white/5">
        <div className="flex items-center gap-1.5 px-2 py-1 bg-[#151923] border border-white/10 rounded-lg text-xs">
          <Search className="w-3.5 h-3.5 text-slate-500" />
          <input
            type="text"
            placeholder="Search scene graph..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-transparent text-slate-200 placeholder-slate-500 outline-none text-xs"
          />
        </div>
      </div>

      {/* Objects Tree List */}
      <div className="flex-1 overflow-y-auto p-1.5 space-y-0.5 font-sans">
        {filteredObjects.map((obj) => {
          const isSelected = selectedObjectId === obj.id;
          return (
            <div
              key={obj.id}
              onClick={() => onSelectObject(obj.id)}
              className={`group flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs cursor-pointer transition-all ${
                isSelected
                  ? 'bg-blue-600 text-white font-medium shadow-sm'
                  : 'hover:bg-white/5 text-slate-300'
              }`}
            >
              <div className="flex items-center gap-2 overflow-hidden">
                {getObjectIcon(obj)}
                <span className="truncate text-xs">{obj.name}</span>
              </div>

              {/* Action Icons */}
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  onClick={(e) => toggleVisibility(obj.id, e)}
                  className="p-1 hover:text-white text-slate-400 transition-colors"
                  title="Toggle Visibility"
                >
                  {obj.visible ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3 text-slate-600" />}
                </button>
                <button
                  onClick={(e) => toggleLock(obj.id, e)}
                  className="p-1 hover:text-white text-slate-400 transition-colors"
                  title="Toggle Lock"
                >
                  {obj.locked ? <Lock className="w-3 h-3 text-amber-400" /> : <Unlock className="w-3 h-3" />}
                </button>
                <button
                  onClick={(e) => duplicateObject(obj.id, e)}
                  className="p-1 hover:text-white text-slate-400 transition-colors"
                  title="Duplicate Object"
                >
                  <Copy className="w-3 h-3" />
                </button>
                <button
                  onClick={(e) => deleteObject(obj.id, e)}
                  className="p-1 hover:text-red-400 text-slate-400 transition-colors"
                  title="Delete Object"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer Info */}
      <div className="p-2 border-t border-white/10 text-[11px] text-slate-500 flex items-center justify-between font-mono">
        <span>{Object.keys(doc.objects).length} Entities</span>
        <span>{doc.collections.length} Collections</span>
      </div>
    </div>
  );
};
