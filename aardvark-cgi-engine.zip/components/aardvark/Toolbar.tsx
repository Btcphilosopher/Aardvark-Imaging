'use client';

import React from 'react';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  RotateCcw,
  Sparkles,
  Cpu,
  Sliders,
  Layers,
  Wand2,
  Camera,
  FolderOpen,
  Save,
  Code2,
  Box,
  Flame,
  Sun,
  Palette,
  Film,
  Activity,
  ChevronDown,
} from 'lucide-react';
import { RenderQualityLevel } from '../../lib/aardvark/core/types';
import { SHOWCASE_PRESETS } from '../../lib/aardvark/scripting/pythonEngine';

export type StudioTab =
  | 'model'
  | 'sculpt'
  | 'material'
  | 'animate'
  | 'physics'
  | 'lighting'
  | 'compositor'
  | 'script'
  | 'ai_gen';

interface ToolbarProps {
  activeTab: StudioTab;
  onTabChange: (tab: StudioTab) => void;
  isPlaying: boolean;
  onTogglePlay: () => void;
  currentFrame: number;
  maxFrames: number;
  onSeekFrame: (frame: number) => void;
  onResetPlayback: () => void;
  qualityLevel: RenderQualityLevel;
  onQualityLevelChange: (level: RenderQualityLevel) => void;
  transformTool: 'select' | 'translate' | 'rotate' | 'scale';
  onTransformToolChange: (tool: 'select' | 'translate' | 'rotate' | 'scale') => void;
  onOpenRenderModal: () => void;
  onLoadPreset: (presetKey: string) => void;
  onSaveProject: () => void;
  onRunPython: () => void;
}

export const Toolbar: React.FC<ToolbarProps> = ({
  activeTab,
  onTabChange,
  isPlaying,
  onTogglePlay,
  currentFrame,
  maxFrames,
  onSeekFrame,
  onResetPlayback,
  qualityLevel,
  onQualityLevelChange,
  transformTool,
  onTransformToolChange,
  onOpenRenderModal,
  onLoadPreset,
  onSaveProject,
  onRunPython,
}) => {
  return (
    <header className="h-14 bg-[#0d1017] border-b border-white/10 flex items-center justify-between px-3 select-none text-slate-300 z-30">
      {/* Left: Branding & Preset Showcases */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 pr-3 border-r border-white/10">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-400 flex items-center justify-center shadow-lg shadow-blue-500/20">
            <Cpu className="w-4 h-4 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-1.5 leading-none">
              <span className="font-bold text-sm tracking-wider text-white">AARDVARK</span>
              <span className="text-[10px] font-mono px-1 py-0.5 rounded bg-blue-500/20 text-blue-400 font-semibold">
                CGI 3D
              </span>
            </div>
            <span className="text-[10px] text-slate-400 tracking-tight">Python-Native Engine</span>
          </div>
        </div>

        {/* Preset Benchmark Scene Loader */}
        <div className="relative group">
          <button className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-slate-200 transition-colors">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Benchmark Scenes</span>
            <ChevronDown className="w-3 h-3 text-slate-400" />
          </button>
          <div className="absolute left-0 top-full mt-1.5 w-64 bg-[#141824] border border-white/10 rounded-xl shadow-2xl p-1.5 hidden group-hover:block z-50">
            <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 px-2 py-1">
              Engine Benchmarks & Presets
            </div>
            {Object.entries(SHOWCASE_PRESETS).map(([key, preset]) => (
              <button
                key={key}
                onClick={() => onLoadPreset(key)}
                className="w-full text-left px-2.5 py-2 rounded-lg hover:bg-blue-600/20 hover:text-white transition-colors flex flex-col group/item"
              >
                <span className="text-xs font-medium text-slate-200 group-hover/item:text-blue-300">
                  {preset.name}
                </span>
                <span className="text-[10px] text-slate-400 line-clamp-1">{preset.description}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Center: Workspace Studio Tabs */}
      <div className="flex items-center bg-[#131722] p-1 rounded-xl border border-white/10 gap-0.5 text-xs">
        <button
          onClick={() => onTabChange('model')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-lg transition-colors ${
            activeTab === 'model'
              ? 'bg-blue-600 text-white font-medium shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Box className="w-3.5 h-3.5" />
          <span>Model</span>
        </button>

        <button
          onClick={() => onTabChange('sculpt')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-lg transition-colors ${
            activeTab === 'sculpt'
              ? 'bg-blue-600 text-white font-medium shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Wand2 className="w-3.5 h-3.5" />
          <span>Sculpt</span>
        </button>

        <button
          onClick={() => onTabChange('material')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-lg transition-colors ${
            activeTab === 'material'
              ? 'bg-blue-600 text-white font-medium shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Palette className="w-3.5 h-3.5" />
          <span>Material</span>
        </button>

        <button
          onClick={() => onTabChange('animate')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-lg transition-colors ${
            activeTab === 'animate'
              ? 'bg-blue-600 text-white font-medium shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Film className="w-3.5 h-3.5" />
          <span>Animate</span>
        </button>

        <button
          onClick={() => onTabChange('physics')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-lg transition-colors ${
            activeTab === 'physics'
              ? 'bg-blue-600 text-white font-medium shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Flame className="w-3.5 h-3.5" />
          <span>Physics</span>
        </button>

        <button
          onClick={() => onTabChange('lighting')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-lg transition-colors ${
            activeTab === 'lighting'
              ? 'bg-blue-600 text-white font-medium shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Sun className="w-3.5 h-3.5" />
          <span>Lighting</span>
        </button>

        <button
          onClick={() => onTabChange('compositor')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-lg transition-colors ${
            activeTab === 'compositor'
              ? 'bg-blue-600 text-white font-medium shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>Compositor</span>
        </button>

        <button
          onClick={() => onTabChange('script')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-lg transition-colors ${
            activeTab === 'script'
              ? 'bg-blue-600 text-white font-medium shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Code2 className="w-3.5 h-3.5" />
          <span>Python 3.13</span>
        </button>

        <button
          onClick={() => onTabChange('ai_gen')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-lg transition-colors ${
            activeTab === 'ai_gen'
              ? 'bg-indigo-600 text-white font-medium shadow-sm'
              : 'text-indigo-300 hover:text-white hover:bg-white/5'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
          <span>AI Scene Gen</span>
        </button>
      </div>

      {/* Right: Transport & Render Actions */}
      <div className="flex items-center gap-2.5">
        {/* Playback Transport Mini Controls */}
        <div className="flex items-center gap-1 bg-[#131722] px-2 py-1 rounded-lg border border-white/10 text-xs">
          <button
            onClick={onResetPlayback}
            className="p-1 hover:text-white text-slate-400 transition-colors"
            title="Reset to Frame 0"
          >
            <SkipBack className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onTogglePlay}
            className={`p-1 rounded transition-colors ${
              isPlaying ? 'bg-amber-500/20 text-amber-400' : 'hover:text-white text-slate-300'
            }`}
            title={isPlaying ? 'Pause (Space)' : 'Play (Space)'}
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
          </button>
          <span className="font-mono text-[11px] text-blue-400 font-semibold px-1">
            {currentFrame}
            <span className="text-slate-500">/{maxFrames}</span>
          </span>
        </div>

        {/* Run Python Script Shortcut */}
        <button
          onClick={onRunPython}
          className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 text-xs font-medium transition-colors"
          title="Run Python Script (Ctrl + Enter)"
        >
          <Play className="w-3 h-3 fill-current" />
          <span>Run Python</span>
        </button>

        {/* Master CGI Render Button */}
        <button
          onClick={onOpenRenderModal}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-semibold shadow-lg shadow-blue-500/20 transition-all"
        >
          <Camera className="w-3.5 h-3.5" />
          <span>Render Master</span>
        </button>

        {/* Save .aard Project */}
        <button
          onClick={onSaveProject}
          className="p-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white transition-colors"
          title="Export Aardvark Document (.aard / JSON)"
        >
          <Save className="w-3.5 h-3.5" />
        </button>
      </div>
    </header>
  );
};
