'use client';

import React, { useState, useEffect, useCallback } from 'react';
import {
  AardDocument,
  ID,
  ViewportMode,
  RenderQualityLevel,
} from '../../lib/aardvark/core/types';
import { createDefaultDocument } from '../../lib/aardvark/core/document';
import {
  SHOWCASE_PRESETS,
  executeAardvarkPythonScript,
} from '../../lib/aardvark/scripting/pythonEngine';
import { Toolbar, StudioTab } from './Toolbar';
import { Viewport3D } from './Viewport3D';
import { Outliner } from './Outliner';
import { Inspector } from './Inspector';
import { BottomDock } from './BottomDock';
import { RenderModal } from './RenderModal';

export const AardvarkStudio: React.FC = () => {
  const [doc, setDoc] = useState<AardDocument>(() => createDefaultDocument());
  const [selectedObjectId, setSelectedObjectId] = useState<ID | null>('obj_turbomachine_hero');
  const [activeTab, setActiveTab] = useState<StudioTab>('model');
  const [viewportMode, setViewportMode] = useState<ViewportMode>('lit');
  const [qualityLevel, setQualityLevel] = useState<RenderQualityLevel>(4);
  const [transformTool, setTransformTool] = useState<'select' | 'translate' | 'rotate' | 'scale'>('select');

  // Animation playback state
  const [isPlaying, setIsPlaying] = useState(true);
  const [currentFrame, setCurrentFrame] = useState(0);

  // Render modal state
  const [isRenderModalOpen, setIsRenderModalOpen] = useState(false);

  // Playback timer
  useEffect(() => {
    let interval: any = null;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentFrame((prev) => {
          if (prev >= doc.renderSettings.endFrame) {
            return doc.renderSettings.startFrame;
          }
          return prev + 1;
        });
      }, 1000 / doc.renderSettings.fps);
    }
    return () => clearInterval(interval);
  }, [isPlaying, doc.renderSettings.fps, doc.renderSettings.endFrame, doc.renderSettings.startFrame]);

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if typing in text inputs or code editor
      if (
        ['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement).tagName)
      ) {
        return;
      }

      if (e.code === 'Space') {
        e.preventDefault();
        setIsPlaying((p) => !p);
      } else if (e.key === 'q' || e.key === 'Q') {
        setTransformTool('select');
      } else if (e.key === 'w' || e.key === 'W') {
        setTransformTool('translate');
      } else if (e.key === 'e' || e.key === 'E') {
        setTransformTool('rotate');
      } else if (e.key === 'r' || e.key === 'R') {
        setTransformTool('scale');
      } else if (e.key === '1') {
        setViewportMode('wireframe');
      } else if (e.key === '2') {
        setViewportMode('solid');
      } else if (e.key === '3') {
        setViewportMode('material');
      } else if (e.key === '4') {
        setViewportMode('lit');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleLoadPreset = (presetKey: string) => {
    const preset = SHOWCASE_PRESETS[presetKey];
    if (!preset) return;

    const result = executeAardvarkPythonScript(preset.code, doc);
    if (result.success && result.updatedDocument) {
      setDoc(result.updatedDocument);
      // Select the first non-light/camera object
      const heroObj = Object.values(result.updatedDocument.objects).find(
        (o) => o.type !== 'light' && o.type !== 'camera'
      );
      if (heroObj) setSelectedObjectId(heroObj.id);
    }
  };

  const handleSaveProject = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(doc, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${doc.name.toLowerCase().replace(/\s+/g, '_')}.aard`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleRunPython = () => {
    const result = executeAardvarkPythonScript(doc.pythonScript, doc);
    if (result.success && result.updatedDocument) {
      setDoc(result.updatedDocument);
    }
  };

  return (
    <div className="flex flex-col w-screen h-screen bg-[#0a0d14] text-slate-200 overflow-hidden font-sans select-none">
      {/* 1. Master Top Toolbar */}
      <Toolbar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        isPlaying={isPlaying}
        onTogglePlay={() => setIsPlaying((p) => !p)}
        currentFrame={currentFrame}
        maxFrames={doc.renderSettings.endFrame}
        onSeekFrame={setCurrentFrame}
        onResetPlayback={() => setCurrentFrame(0)}
        qualityLevel={qualityLevel}
        onQualityLevelChange={setQualityLevel}
        transformTool={transformTool}
        onTransformToolChange={setTransformTool}
        onOpenRenderModal={() => setIsRenderModalOpen(true)}
        onLoadPreset={handleLoadPreset}
        onSaveProject={handleSaveProject}
        onRunPython={handleRunPython}
      />

      {/* 2. Middle Main Workspace (Outliner + Viewport + Inspector) */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Scene Graph Outliner */}
        <Outliner
          doc={doc}
          selectedObjectId={selectedObjectId}
          onSelectObject={setSelectedObjectId}
          onUpdateDocument={setDoc}
        />

        {/* Center 3D Viewport */}
        <div className="flex-1 relative h-full">
          <Viewport3D
            doc={doc}
            selectedObjectId={selectedObjectId}
            onSelectObject={setSelectedObjectId}
            isPlaying={isPlaying}
            currentFrame={currentFrame}
            viewportMode={viewportMode}
            onViewportModeChange={setViewportMode}
            transformTool={transformTool}
          />
        </div>

        {/* Right Properties Inspector */}
        <Inspector
          doc={doc}
          selectedObjectId={selectedObjectId}
          onUpdateDocument={setDoc}
        />
      </div>

      {/* 3. Bottom Multi-Tab Dock (Timeline, Python 3.13 IDE, Nodes, Compositor, AI) */}
      <BottomDock
        doc={doc}
        onUpdateDocument={setDoc}
        isPlaying={isPlaying}
        onTogglePlay={() => setIsPlaying((p) => !p)}
        currentFrame={currentFrame}
        onSeekFrame={setCurrentFrame}
      />

      {/* 4. Production Master Render Modal */}
      <RenderModal
        isOpen={isRenderModalOpen}
        onClose={() => setIsRenderModalOpen(false)}
        doc={doc}
      />
    </div>
  );
};
