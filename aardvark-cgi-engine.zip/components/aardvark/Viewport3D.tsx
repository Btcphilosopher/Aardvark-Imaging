'use client';

import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import {
  AardDocument,
  AardObject,
  ID,
  ViewportMode,
  RenderQualityLevel,
} from '../../lib/aardvark/core/types';
import { buildParametricGeometry } from '../../lib/aardvark/geometry/primitives';
import { buildPhysicalMaterial } from '../../lib/aardvark/materials/materialBuilder';
import {
  AardParticleEngine,
  AardClothEngine,
} from '../../lib/aardvark/physics/simulationEngine';
import {
  Layers,
  Sparkles,
  Camera,
  Sun,
  Eye,
  Maximize2,
  Minimize2,
  Grid,
  Focus,
  Crosshair,
} from 'lucide-react';

interface Viewport3DProps {
  doc: AardDocument;
  selectedObjectId: ID | null;
  onSelectObject: (id: ID | null) => void;
  onUpdateObjectTransform?: (id: ID, pos: { x: number; y: number; z: number }, rot: { x: number; y: number; z: number }) => void;
  isPlaying: boolean;
  currentFrame: number;
  viewportMode: ViewportMode;
  onViewportModeChange: (mode: ViewportMode) => void;
  transformTool: 'select' | 'translate' | 'rotate' | 'scale';
  isSculptMode?: boolean;
  sculptBrush?: { type: string; radius: number; strength: number };
}

export const Viewport3D: React.FC<Viewport3DProps> = ({
  doc,
  selectedObjectId,
  onSelectObject,
  isPlaying,
  currentFrame,
  viewportMode,
  onViewportModeChange,
  transformTool,
  isSculptMode,
  sculptBrush,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Three.js instances
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const threeObjectsRef = useRef<Map<ID, THREE.Object3D>>(new Map());
  const particleEnginesRef = useRef<Map<ID, AardParticleEngine>>(new Map());
  const clothEnginesRef = useRef<Map<ID, AardClothEngine>>(new Map());

  // Orbit controls state
  const isDraggingRef = useRef(false);
  const dragButtonRef = useRef(0);
  const mousePosRef = useRef({ x: 0, y: 0 });
  const cameraSphericalRef = useRef({ radius: 14, phi: 1.1, theta: 0.4 });
  const cameraTargetRef = useRef(new THREE.Vector3(0, 0.8, 0));

  // Telemetry stats
  const [stats, setStats] = useState({ fps: 60, triangles: 0, vertices: 0, drawCalls: 0 });
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showGrid, setShowGrid] = useState(true);
  const [showOverlays, setShowOverlays] = useState(true);

  // Selection outline helper
  const selectionBoxRef = useRef<THREE.BoxHelper | null>(null);

  // Initialize Three.js WebGL Renderer & Scene
  useEffect(() => {
    if (!canvasRef.current || !containerRef.current) return;

    const width = containerRef.current.clientWidth;
    const height = containerRef.current.clientHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0c0e14);
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 1000);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({
      canvas: canvasRef.current,
      antialias: true,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: true,
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    rendererRef.current = renderer;

    // Grid Floor Helper
    const grid = new THREE.GridHelper(40, 40, 0x3b82f6, 0x1e293b);
    grid.position.y = -1.49;
    grid.name = '__aardvark_grid';
    scene.add(grid);

    // Selection Outline Box Helper
    const dummyMesh = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1));
    const boxHelper = new THREE.BoxHelper(dummyMesh, 0x00f0ff);
    boxHelper.visible = false;
    scene.add(boxHelper);
    selectionBoxRef.current = boxHelper;

    // Resize Observer
    const handleResize = () => {
      if (!containerRef.current || !rendererRef.current || !cameraRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };

    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(containerRef.current);

    return () => {
      resizeObserver.disconnect();
      renderer.dispose();
    };
  }, []);

  // Update Scene Objects when `doc` changes
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    // Clean up existing scene objects (except grid, helpers)
    threeObjectsRef.current.forEach((obj) => scene.remove(obj));
    threeObjectsRef.current.clear();
    particleEnginesRef.current.clear();
    clothEnginesRef.current.clear();

    let totalTris = 0;
    let totalVerts = 0;

    // Build objects
    Object.values(doc.objects).forEach((objData) => {
      if (!objData.visible) return;

      let threeObj: THREE.Object3D | null = null;

      if (objData.type === 'light' && objData.lightData) {
        const l = objData.lightData;
        const color = new THREE.Color(l.color);

        if (l.type === 'directional') {
          const dirLight = new THREE.DirectionalLight(color, l.intensity);
          dirLight.castShadow = l.castShadow;
          dirLight.shadow.mapSize.width = l.shadowMapSize || 2048;
          dirLight.shadow.mapSize.height = l.shadowMapSize || 2048;
          threeObj = dirLight;
        } else if (l.type === 'spot') {
          const spotLight = new THREE.SpotLight(
            color,
            l.intensity * 2,
            l.distance || 50,
            ((l.angle || 45) * Math.PI) / 180,
            l.penumbra || 0.5
          );
          spotLight.castShadow = l.castShadow;
          threeObj = spotLight;
        } else if (l.type === 'area') {
          // Rect / Point simulation
          const pointL = new THREE.PointLight(color, l.intensity * 1.5, l.distance || 30);
          pointL.castShadow = l.castShadow;
          threeObj = pointL;
        } else {
          const pointL = new THREE.PointLight(color, l.intensity, l.distance || 25);
          threeObj = pointL;
        }

        // Add a visual gizmo icon mesh for the light
        const gizmo = new THREE.Mesh(
          new THREE.OctahedronGeometry(0.2, 0),
          new THREE.MeshBasicMaterial({ color: color, wireframe: true })
        );
        threeObj.add(gizmo);
      } else if (objData.type === 'particle_system' && objData.particleData) {
        const pEngine = new AardParticleEngine(objData.particleData);
        particleEnginesRef.current.set(objData.id, pEngine);
        threeObj = pEngine.points;
      } else if (objData.type === 'cloth' && objData.clothData) {
        const clothEngine = new AardClothEngine(objData.clothData);
        clothEnginesRef.current.set(objData.id, clothEngine);
        threeObj = clothEngine.mesh;
      } else if (objData.type === 'camera' && objData.cameraData) {
        // Visual frustum representation in viewport
        const camGizmo = new THREE.CameraHelper(
          new THREE.PerspectiveCamera(objData.cameraData.fov, 16 / 9, 0.5, 6)
        );
        camGizmo.visible = true;
        threeObj = camGizmo;
      } else if (objData.primitiveType) {
        const geo = buildParametricGeometry(
          objData.primitiveType,
          objData.parametricProps,
          objData.modifiers
        );

        if (geo.attributes.position) {
          totalVerts += geo.attributes.position.count;
          totalTris += geo.index ? geo.index.count / 3 : geo.attributes.position.count / 3;
        }

        const matData = objData.materialId ? doc.materials[objData.materialId] : null;
        let mat: THREE.Material;

        if (viewportMode === 'wireframe') {
          mat = new THREE.MeshBasicMaterial({ color: 0x00f0ff, wireframe: true });
        } else if (viewportMode === 'solid') {
          mat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.6, metalness: 0.1 });
        } else if (viewportMode === 'aov_normal') {
          mat = new THREE.MeshNormalMaterial();
        } else if (viewportMode === 'aov_depth') {
          mat = new THREE.MeshDepthMaterial();
        } else if (matData) {
          mat = buildPhysicalMaterial(matData);
        } else {
          mat = new THREE.MeshStandardMaterial({ color: 0xd4af37, metalness: 0.8, roughness: 0.2 });
        }

        const mesh = new THREE.Mesh(geo, mat);
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        threeObj = mesh;
      }

      if (threeObj) {
        threeObj.position.set(
          objData.transform.position.x,
          objData.transform.position.y,
          objData.transform.position.z
        );
        threeObj.rotation.set(
          (objData.transform.rotation.x * Math.PI) / 180,
          (objData.transform.rotation.y * Math.PI) / 180,
          (objData.transform.rotation.z * Math.PI) / 180
        );
        threeObj.scale.set(
          objData.transform.scale.x,
          objData.transform.scale.y,
          objData.transform.scale.z
        );
        threeObj.userData = { id: objData.id, name: objData.name };

        scene.add(threeObj);
        threeObjectsRef.current.set(objData.id, threeObj);
      }
    });

    // Add ambient base fill
    const ambLight = new THREE.AmbientLight(0x222634, 1.2);
    scene.add(ambLight);

    setStats((prev) => ({
      ...prev,
      triangles: Math.round(totalTris),
      vertices: totalVerts,
      drawCalls: threeObjectsRef.current.size + 3,
    }));
  }, [doc, viewportMode]);

  // Update selection outline box
  useEffect(() => {
    if (!selectionBoxRef.current) return;
    if (selectedObjectId && threeObjectsRef.current.has(selectedObjectId)) {
      const targetObj = threeObjectsRef.current.get(selectedObjectId)!;
      selectionBoxRef.current.setFromObject(targetObj);
      selectionBoxRef.current.visible = true;
    } else {
      selectionBoxRef.current.visible = false;
    }
  }, [selectedObjectId, doc]);

  // Orbit controls mouse handling
  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    dragButtonRef.current = e.button;
    mousePosRef.current = { x: e.clientX, y: e.clientY };

    // Raycast object selection on left click
    if (e.button === 0 && cameraRef.current && sceneRef.current && canvasRef.current) {
      const rect = canvasRef.current.getBoundingClientRect();
      const mouseX = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const mouseY = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      const raycaster = new THREE.Raycaster();
      raycaster.setFromCamera(new THREE.Vector2(mouseX, mouseY), cameraRef.current);

      const hitCandidates: THREE.Object3D[] = [];
      threeObjectsRef.current.forEach((obj) => hitCandidates.push(obj));

      const intersects = raycaster.intersectObjects(hitCandidates, true);
      if (intersects.length > 0) {
        let topObj: THREE.Object3D | null = intersects[0].object;
        while (topObj && !topObj.userData?.id && topObj.parent) {
          topObj = topObj.parent;
        }
        if (topObj && topObj.userData?.id) {
          onSelectObject(topObj.userData.id);
        }
      }
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current) return;

    const dx = e.clientX - mousePosRef.current.x;
    const dy = e.clientY - mousePosRef.current.y;
    mousePosRef.current = { x: e.clientX, y: e.clientY };

    if (dragButtonRef.current === 0 || dragButtonRef.current === 1) {
      // Orbit rotation
      cameraSphericalRef.current.theta -= dx * 0.008;
      cameraSphericalRef.current.phi = Math.max(
        0.05,
        Math.min(Math.PI - 0.05, cameraSphericalRef.current.phi - dy * 0.008)
      );
    } else if (dragButtonRef.current === 2) {
      // Pan
      const right = new THREE.Vector3(1, 0, 0).applyQuaternion(cameraRef.current!.quaternion);
      const up = new THREE.Vector3(0, 1, 0).applyQuaternion(cameraRef.current!.quaternion);
      cameraTargetRef.current.addScaledVector(right, -dx * 0.015);
      cameraTargetRef.current.addScaledVector(up, dy * 0.015);
    }
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  const handleWheel = (e: React.WheelEvent) => {
    cameraSphericalRef.current.radius = Math.max(
      2,
      Math.min(100, cameraSphericalRef.current.radius + e.deltaY * 0.015)
    );
  };

  // Main Render Animation Loop
  useEffect(() => {
    let animId: number;
    let lastTime = performance.now();
    let frameCount = 0;
    let lastFpsUpdate = lastTime;

    const renderLoop = (time: number) => {
      animId = requestAnimationFrame(renderLoop);

      const dt = Math.min((time - lastTime) / 1000, 0.05);
      lastTime = time;

      // FPS counter
      frameCount++;
      if (time - lastFpsUpdate >= 500) {
        setStats((prev) => ({
          ...prev,
          fps: Math.round((frameCount * 1000) / (time - lastFpsUpdate)),
        }));
        frameCount = 0;
        lastFpsUpdate = time;
      }

      // Update camera position from spherical coordinates
      if (cameraRef.current) {
        const { radius, phi, theta } = cameraSphericalRef.current;
        const target = cameraTargetRef.current;

        const cx = target.x + radius * Math.sin(phi) * Math.sin(theta);
        const cy = target.y + radius * Math.cos(phi);
        const cz = target.z + radius * Math.sin(phi) * Math.cos(theta);

        cameraRef.current.position.set(cx, cy, cz);
        cameraRef.current.lookAt(target);
      }

      // Update physics simulations (Particles & Cloth)
      particleEnginesRef.current.forEach((pEngine) => {
        pEngine.update(dt, time / 1000);
      });

      clothEnginesRef.current.forEach((cEngine) => {
        cEngine.update(dt, time / 1000);
      });

      // Animate turbomachine or animated objects if playing
      if (isPlaying) {
        const speed = (currentFrame / doc.renderSettings.fps) * Math.PI * 2;
        threeObjectsRef.current.forEach((obj, id) => {
          const docObj = doc.objects[id];
          if (docObj?.primitiveType === 'turbomachine') {
            obj.rotation.y = speed * 1.5;
          } else if (docObj?.animationTracks?.length) {
            obj.rotation.y = speed;
          }
        });
      }

      // Render Three.js Scene
      if (rendererRef.current && sceneRef.current && cameraRef.current) {
        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }
    };

    animId = requestAnimationFrame(renderLoop);
    return () => cancelAnimationFrame(animId);
  }, [isPlaying, currentFrame, doc]);

  return (
    <div
      ref={containerRef}
      className={`relative w-full h-full bg-[#0a0d14] select-none overflow-hidden ${
        isFullscreen ? 'fixed inset-0 z-50' : ''
      }`}
      onContextMenu={(e) => e.preventDefault()}
    >
      <canvas
        ref={canvasRef}
        className="w-full h-full block cursor-crosshair"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onWheel={handleWheel}
      />

      {/* Top Left: Viewport Mode Pills (Wireframe, Solid, Material, Lit, Depth, Normal) */}
      <div className="absolute top-3 left-3 flex items-center gap-1.5 bg-[#121620]/90 backdrop-blur-md border border-white/10 rounded-lg p-1 text-xs text-slate-300 shadow-xl z-20">
        <button
          onClick={() => onViewportModeChange('wireframe')}
          className={`px-2.5 py-1 rounded transition-colors ${
            viewportMode === 'wireframe'
              ? 'bg-blue-600 text-white font-medium shadow-sm'
              : 'hover:bg-white/5 hover:text-white'
          }`}
          title="Level 0: Wireframe Topology"
        >
          Wireframe
        </button>
        <button
          onClick={() => onViewportModeChange('solid')}
          className={`px-2.5 py-1 rounded transition-colors ${
            viewportMode === 'solid'
              ? 'bg-blue-600 text-white font-medium shadow-sm'
              : 'hover:bg-white/5 hover:text-white'
          }`}
          title="Level 1: Solid Shading"
        >
          Solid
        </button>
        <button
          onClick={() => onViewportModeChange('material')}
          className={`px-2.5 py-1 rounded transition-colors ${
            viewportMode === 'material'
              ? 'bg-blue-600 text-white font-medium shadow-sm'
              : 'hover:bg-white/5 hover:text-white'
          }`}
          title="Level 3: PBR Material Preview"
        >
          PBR Material
        </button>
        <button
          onClick={() => onViewportModeChange('lit')}
          className={`px-2.5 py-1 rounded transition-colors ${
            viewportMode === 'lit'
              ? 'bg-blue-600 text-white font-medium shadow-sm'
              : 'hover:bg-white/5 hover:text-white'
          }`}
          title="Level 4: CGI Studio Master"
        >
          CGI Studio
        </button>

        <div className="w-[1px] h-4 bg-white/10 mx-0.5" />

        {/* AOVs Dropdown */}
        <select
          value={viewportMode.startsWith('aov_') ? viewportMode : ''}
          onChange={(e) => {
            if (e.target.value) onViewportModeChange(e.target.value as ViewportMode);
          }}
          className="bg-transparent text-slate-400 hover:text-white text-xs px-1.5 py-1 rounded outline-none cursor-pointer"
        >
          <option value="" disabled className="bg-slate-900 text-slate-400">
            AOVs / Passes
          </option>
          <option value="aov_normal" className="bg-slate-900 text-white">
            AOV: Surface Normals
          </option>
          <option value="aov_depth" className="bg-slate-900 text-white">
            AOV: Z-Depth Pass
          </option>
        </select>
      </div>

      {/* Top Right: Viewport Controls & Telemetry HUD */}
      <div className="absolute top-3 right-3 flex items-center gap-2 z-20">
        <div className="flex items-center gap-3 bg-[#121620]/90 backdrop-blur-md border border-white/10 rounded-lg px-3 py-1.5 text-xs text-slate-400 shadow-xl font-mono">
          <span className="flex items-center gap-1 text-emerald-400 font-semibold">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            {stats.fps} FPS
          </span>
          <span>{stats.triangles.toLocaleString()} Tris</span>
          <span>{stats.vertices.toLocaleString()} Verts</span>
          <span>{stats.drawCalls} Draws</span>
        </div>

        <button
          onClick={() => setShowGrid(!showGrid)}
          className={`p-1.5 rounded-lg border text-xs transition-colors backdrop-blur-md ${
            showGrid
              ? 'bg-blue-600/20 border-blue-500/40 text-blue-400'
              : 'bg-[#121620]/90 border-white/10 text-slate-400 hover:text-white'
          }`}
          title="Toggle Grid (G)"
        >
          <Grid className="w-4 h-4" />
        </button>

        <button
          onClick={() => setIsFullscreen(!isFullscreen)}
          className="p-1.5 bg-[#121620]/90 backdrop-blur-md border border-white/10 rounded-lg text-slate-400 hover:text-white text-xs transition-colors"
          title="Toggle Fullscreen Viewport"
        >
          {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
        </button>
      </div>

      {/* Center Reticle & Safe Frame Guides */}
      {showOverlays && (
        <div className="absolute inset-0 pointer-events-none border border-white/5 m-8 rounded-lg flex items-center justify-center">
          <div className="w-4 h-4 border-t border-l border-white/20 absolute top-0 left-0" />
          <div className="w-4 h-4 border-t border-r border-white/20 absolute top-0 right-0" />
          <div className="w-4 h-4 border-b border-l border-white/20 absolute bottom-0 left-0" />
          <div className="w-4 h-4 border-b border-r border-white/20 absolute bottom-0 right-0" />
        </div>
      )}

      {/* Bottom Left: Active Selected Object Status Pill */}
      {selectedObjectId && doc.objects[selectedObjectId] && (
        <div className="absolute bottom-3 left-3 bg-[#121620]/90 backdrop-blur-md border border-blue-500/30 rounded-lg px-3 py-1.5 text-xs text-slate-200 flex items-center gap-2 shadow-xl z-20">
          <Focus className="w-3.5 h-3.5 text-blue-400" />
          <span>Selected:</span>
          <span className="font-semibold text-white">
            {doc.objects[selectedObjectId].name}
          </span>
          <span className="text-[10px] uppercase tracking-wider px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 font-mono">
            {doc.objects[selectedObjectId].type}
          </span>
        </div>
      )}
    </div>
  );
};
