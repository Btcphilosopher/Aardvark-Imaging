'use client';

import React, { useState } from 'react';
import {
  AardDocument,
  AardObject,
  ID,
  AardMaterialData,
  ProceduralTextureType,
} from '../../lib/aardvark/core/types';
import {
  Sliders,
  Sparkles,
  Sun,
  Camera,
  Layers,
  Box,
  Flame,
  Plus,
  Trash2,
  Cpu,
  Palette,
  Eye,
  Settings2,
  RefreshCw,
} from 'lucide-react';

interface InspectorProps {
  doc: AardDocument;
  selectedObjectId: ID | null;
  onUpdateDocument: (doc: AardDocument) => void;
}

export const Inspector: React.FC<InspectorProps> = ({
  doc,
  selectedObjectId,
  onUpdateDocument,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'transform' | 'geometry' | 'material' | 'modifiers' | 'physics'>('transform');

  if (!selectedObjectId || !doc.objects[selectedObjectId]) {
    return (
      <div className="w-80 bg-[#0f121a] border-l border-white/10 flex flex-col h-full items-center justify-center p-6 text-center text-slate-500 text-xs">
        <Box className="w-8 h-8 mb-2 opacity-30" />
        <span className="font-medium text-slate-400">No Object Selected</span>
        <span className="text-[11px] mt-1">Select an entity in the Viewport or Outliner to inspect its CGI properties.</span>
      </div>
    );
  }

  const obj = doc.objects[selectedObjectId];
  const mat = obj.materialId ? doc.materials[obj.materialId] : null;

  const updateObject = (updater: (draft: AardObject) => void) => {
    const updatedDoc: AardDocument = JSON.parse(JSON.stringify(doc));
    if (updatedDoc.objects[selectedObjectId]) {
      updater(updatedDoc.objects[selectedObjectId]);
      onUpdateDocument(updatedDoc);
    }
  };

  const updateMaterial = (updater: (draft: AardMaterialData) => void) => {
    if (!obj.materialId) return;
    const updatedDoc: AardDocument = JSON.parse(JSON.stringify(doc));
    if (updatedDoc.materials[obj.materialId]) {
      updater(updatedDoc.materials[obj.materialId]);
      onUpdateDocument(updatedDoc);
    }
  };

  return (
    <div className="w-80 bg-[#0f121a] border-l border-white/10 flex flex-col h-full select-none text-slate-300 z-20">
      {/* Object Title Header */}
      <div className="p-3 border-b border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-2 overflow-hidden">
          <Settings2 className="w-4 h-4 text-blue-400 shrink-0" />
          <input
            type="text"
            value={obj.name}
            onChange={(e) =>
              updateObject((d) => {
                d.name = e.target.value;
              })
            }
            className="bg-transparent text-xs font-semibold text-white outline-none hover:bg-white/5 px-1 py-0.5 rounded truncate"
          />
        </div>
        <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 font-semibold">
          {obj.type}
        </span>
      </div>

      {/* Sub Tabs */}
      <div className="flex items-center border-b border-white/10 bg-[#131722] p-1 gap-1 text-[11px]">
        <button
          onClick={() => setActiveSubTab('transform')}
          className={`flex-1 py-1 rounded transition-colors ${
            activeSubTab === 'transform' ? 'bg-blue-600 text-white font-medium' : 'text-slate-400 hover:text-white'
          }`}
        >
          Transform
        </button>

        {obj.primitiveType && (
          <button
            onClick={() => setActiveSubTab('geometry')}
            className={`flex-1 py-1 rounded transition-colors ${
              activeSubTab === 'geometry' ? 'bg-blue-600 text-white font-medium' : 'text-slate-400 hover:text-white'
            }`}
          >
            Geometry
          </button>
        )}

        {obj.materialId && (
          <button
            onClick={() => setActiveSubTab('material')}
            className={`flex-1 py-1 rounded transition-colors ${
              activeSubTab === 'material' ? 'bg-blue-600 text-white font-medium' : 'text-slate-400 hover:text-white'
            }`}
          >
            Material
          </button>
        )}

        {obj.modifiers && (
          <button
            onClick={() => setActiveSubTab('modifiers')}
            className={`flex-1 py-1 rounded transition-colors ${
              activeSubTab === 'modifiers' ? 'bg-blue-600 text-white font-medium' : 'text-slate-400 hover:text-white'
            }`}
          >
            Stack
          </button>
        )}

        {(obj.particleData || obj.clothData) && (
          <button
            onClick={() => setActiveSubTab('physics')}
            className={`flex-1 py-1 rounded transition-colors ${
              activeSubTab === 'physics' ? 'bg-blue-600 text-white font-medium' : 'text-slate-400 hover:text-white'
            }`}
          >
            Physics
          </button>
        )}
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-3 space-y-4 text-xs font-sans">
        {/* TRANSFORM CONTROLS */}
        {activeSubTab === 'transform' && (
          <div className="space-y-3">
            {/* Position */}
            <div>
              <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">
                Position (X, Y, Z)
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['x', 'y', 'z'] as const).map((axis) => (
                  <div key={axis} className="flex items-center bg-[#161a26] border border-white/10 rounded-lg px-2 py-1">
                    <span className="text-[10px] uppercase font-bold text-slate-500 mr-1.5">{axis}</span>
                    <input
                      type="number"
                      step="0.1"
                      value={obj.transform.position[axis]}
                      onChange={(e) =>
                        updateObject((d) => {
                          d.transform.position[axis] = parseFloat(e.target.value) || 0;
                        })
                      }
                      className="w-full bg-transparent text-slate-200 outline-none text-xs font-mono"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Rotation */}
            <div>
              <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">
                Rotation (Degrees)
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['x', 'y', 'z'] as const).map((axis) => (
                  <div key={axis} className="flex items-center bg-[#161a26] border border-white/10 rounded-lg px-2 py-1">
                    <span className="text-[10px] uppercase font-bold text-slate-500 mr-1.5">{axis}</span>
                    <input
                      type="number"
                      step="5"
                      value={obj.transform.rotation[axis]}
                      onChange={(e) =>
                        updateObject((d) => {
                          d.transform.rotation[axis] = parseFloat(e.target.value) || 0;
                        })
                      }
                      className="w-full bg-transparent text-slate-200 outline-none text-xs font-mono"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Scale */}
            <div>
              <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">
                Scale
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['x', 'y', 'z'] as const).map((axis) => (
                  <div key={axis} className="flex items-center bg-[#161a26] border border-white/10 rounded-lg px-2 py-1">
                    <span className="text-[10px] uppercase font-bold text-slate-500 mr-1.5">{axis}</span>
                    <input
                      type="number"
                      step="0.1"
                      value={obj.transform.scale[axis]}
                      onChange={(e) =>
                        updateObject((d) => {
                          d.transform.scale[axis] = parseFloat(e.target.value) || 1;
                        })
                      }
                      className="w-full bg-transparent text-slate-200 outline-none text-xs font-mono"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* LIGHT DATA (If Light) */}
            {obj.type === 'light' && obj.lightData && (
              <div className="pt-3 border-t border-white/10 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-semibold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Sun className="w-3.5 h-3.5" />
                    Light Attributes
                  </span>
                </div>

                <div>
                  <label className="text-slate-400 text-[11px] block mb-1">Light Type</label>
                  <select
                    value={obj.lightData.type}
                    onChange={(e) =>
                      updateObject((d) => {
                        if (d.lightData) d.lightData.type = e.target.value as any;
                      })
                    }
                    className="w-full bg-[#161a26] border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white outline-none"
                  >
                    <option value="area">Area Softbox</option>
                    <option value="spot">Conical Spotlight</option>
                    <option value="point">Omni Point Light</option>
                    <option value="directional">Sun Directional</option>
                  </select>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-400 text-[11px]">Light Color</span>
                  <input
                    type="color"
                    value={obj.lightData.color}
                    onChange={(e) =>
                      updateObject((d) => {
                        if (d.lightData) d.lightData.color = e.target.value;
                      })
                    }
                    className="w-8 h-8 rounded border border-white/20 cursor-pointer bg-transparent"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>Intensity (Lumens / Candela)</span>
                    <span className="font-mono text-white">{obj.lightData.intensity.toFixed(1)}</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="15"
                    step="0.1"
                    value={obj.lightData.intensity}
                    onChange={(e) =>
                      updateObject((d) => {
                        if (d.lightData) d.lightData.intensity = parseFloat(e.target.value);
                      })
                    }
                    className="w-full accent-blue-500 cursor-pointer"
                  />
                </div>
              </div>
            )}

            {/* CAMERA DATA (If Camera) */}
            {obj.type === 'camera' && obj.cameraData && (
              <div className="pt-3 border-t border-white/10 space-y-3">
                <span className="text-[11px] font-semibold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Camera className="w-3.5 h-3.5" />
                  Cinema Optics
                </span>

                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>Focal Length (mm)</span>
                    <span className="font-mono text-white">{obj.cameraData.focalLength} mm</span>
                  </div>
                  <input
                    type="range"
                    min="18"
                    max="135"
                    step="1"
                    value={obj.cameraData.focalLength}
                    onChange={(e) =>
                      updateObject((d) => {
                        if (d.cameraData) {
                          d.cameraData.focalLength = parseInt(e.target.value, 10);
                          d.cameraData.fov = 2 * Math.atan(18 / d.cameraData.focalLength) * (180 / Math.PI);
                        }
                      })
                    }
                    className="w-full accent-blue-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>Aperture (f-stop)</span>
                    <span className="font-mono text-white">f/{obj.cameraData.aperture.toFixed(1)}</span>
                  </div>
                  <input
                    type="range"
                    min="1.2"
                    max="22"
                    step="0.1"
                    value={obj.cameraData.aperture}
                    onChange={(e) =>
                      updateObject((d) => {
                        if (d.cameraData) d.cameraData.aperture = parseFloat(e.target.value);
                      })
                    }
                    className="w-full accent-blue-500 cursor-pointer"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-400 text-[11px]">Depth of Field Bokeh</span>
                  <input
                    type="checkbox"
                    checked={obj.cameraData.depthOfField}
                    onChange={(e) =>
                      updateObject((d) => {
                        if (d.cameraData) d.cameraData.depthOfField = e.target.checked;
                      })
                    }
                    className="accent-blue-500 cursor-pointer"
                  />
                </div>
              </div>
            )}
          </div>
        )}

        {/* GEOMETRY & PARAMETRIC PROPS */}
        {activeSubTab === 'geometry' && obj.primitiveType && (
          <div className="space-y-3">
            <span className="text-[11px] font-semibold text-blue-400 uppercase tracking-wider flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5" />
              Parametric Generator: {obj.primitiveType}
            </span>

            {/* Turbomachine controls */}
            {obj.primitiveType === 'turbomachine' && (
              <>
                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>Turbine RPM</span>
                    <span className="font-mono text-white">{obj.parametricProps?.rpm || 3600} RPM</span>
                  </div>
                  <input
                    type="range"
                    min="500"
                    max="12000"
                    step="100"
                    value={obj.parametricProps?.rpm || 3600}
                    onChange={(e) =>
                      updateObject((d) => {
                        d.parametricProps = { ...d.parametricProps, rpm: parseInt(e.target.value, 10) };
                      })
                    }
                    className="w-full accent-blue-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>Blades Count</span>
                    <span className="font-mono text-white">{obj.parametricProps?.blades || 16} Blades</span>
                  </div>
                  <input
                    type="range"
                    min="6"
                    max="32"
                    step="2"
                    value={obj.parametricProps?.blades || 16}
                    onChange={(e) =>
                      updateObject((d) => {
                        d.parametricProps = { ...d.parametricProps, blades: parseInt(e.target.value, 10) };
                      })
                    }
                    className="w-full accent-blue-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>Compressor Stages</span>
                    <span className="font-mono text-white">{obj.parametricProps?.stages || 4} Stages</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="8"
                    step="1"
                    value={obj.parametricProps?.stages || 4}
                    onChange={(e) =>
                      updateObject((d) => {
                        d.parametricProps = { ...d.parametricProps, stages: parseInt(e.target.value, 10) };
                      })
                    }
                    className="w-full accent-blue-500 cursor-pointer"
                  />
                </div>
              </>
            )}

            {/* City controls */}
            {obj.primitiveType === 'city' && (
              <>
                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>Skyscrapers Density</span>
                    <span className="font-mono text-white">{obj.parametricProps?.buildingsCount || 36}</span>
                  </div>
                  <input
                    type="range"
                    min="9"
                    max="81"
                    step="1"
                    value={obj.parametricProps?.buildingsCount || 36}
                    onChange={(e) =>
                      updateObject((d) => {
                        d.parametricProps = { ...d.parametricProps, buildingsCount: parseInt(e.target.value, 10) };
                      })
                    }
                    className="w-full accent-blue-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>Procedural Seed</span>
                    <span className="font-mono text-white">{obj.parametricProps?.citySeed || 101}</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="999"
                    step="1"
                    value={obj.parametricProps?.citySeed || 101}
                    onChange={(e) =>
                      updateObject((d) => {
                        d.parametricProps = { ...d.parametricProps, citySeed: parseInt(e.target.value, 10) };
                      })
                    }
                    className="w-full accent-blue-500 cursor-pointer"
                  />
                </div>
              </>
            )}
          </div>
        )}

        {/* MATERIAL PBR CONTROLS */}
        {activeSubTab === 'material' && mat && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                <Palette className="w-3.5 h-3.5" />
                {mat.name}
              </span>
            </div>

            {/* Base Color */}
            <div className="flex items-center justify-between">
              <span className="text-slate-400 text-[11px]">Base Albedo Color</span>
              <input
                type="color"
                value={mat.color}
                onChange={(e) =>
                  updateMaterial((m) => {
                    m.color = e.target.value;
                  })
                }
                className="w-8 h-8 rounded border border-white/20 cursor-pointer bg-transparent"
              />
            </div>

            {/* Metallic */}
            <div>
              <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                <span>Metallic F0</span>
                <span className="font-mono text-white">{mat.metallic.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={mat.metallic}
                onChange={(e) =>
                  updateMaterial((m) => {
                    m.metallic = parseFloat(e.target.value);
                  })
                }
                className="w-full accent-blue-500 cursor-pointer"
              />
            </div>

            {/* Roughness */}
            <div>
              <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                <span>Roughness (Microfacet GGX)</span>
                <span className="font-mono text-white">{mat.roughness.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={mat.roughness}
                onChange={(e) =>
                  updateMaterial((m) => {
                    m.roughness = parseFloat(e.target.value);
                  })
                }
                className="w-full accent-blue-500 cursor-pointer"
              />
            </div>

            {/* Transmission / Glass */}
            <div>
              <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                <span>Transmission (Optical Glass)</span>
                <span className="font-mono text-white">{mat.transmission.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={mat.transmission}
                onChange={(e) =>
                  updateMaterial((m) => {
                    m.transmission = parseFloat(e.target.value);
                  })
                }
                className="w-full accent-blue-500 cursor-pointer"
              />
            </div>

            {/* Emission */}
            <div className="flex items-center justify-between">
              <span className="text-slate-400 text-[11px]">Emission Glow</span>
              <input
                type="color"
                value={mat.emission}
                onChange={(e) =>
                  updateMaterial((m) => {
                    m.emission = e.target.value;
                  })
                }
                className="w-8 h-8 rounded border border-white/20 cursor-pointer bg-transparent"
              />
            </div>

            {/* Procedural Pattern */}
            <div>
              <label className="text-slate-400 text-[11px] block mb-1">Procedural Shader Texture</label>
              <select
                value={mat.proceduralTexture}
                onChange={(e) =>
                  updateMaterial((m) => {
                    m.proceduralTexture = e.target.value as ProceduralTextureType;
                  })
                }
                className="w-full bg-[#161a26] border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white outline-none"
              >
                <option value="none">Solid Pure PBR</option>
                <option value="brushed_metal">Machined Brushed Metal</option>
                <option value="carbon_fiber">Carbon Fiber Weave</option>
                <option value="grid">Studio Procedural Grid</option>
                <option value="marble">Organic Marble Noise</option>
                <option value="checker">Checkerboard Matrix</option>
              </select>
            </div>
          </div>
        )}

        {/* MODIFIER STACK */}
        {activeSubTab === 'modifiers' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-semibold text-purple-400 uppercase tracking-wider flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5" />
                Modifier Stack
              </span>
              <button
                onClick={() =>
                  updateObject((d) => {
                    d.modifiers.push({
                      id: `mod_${Date.now()}`,
                      name: 'Catmull-Clark Subdiv',
                      type: 'subdivision',
                      enabled: true,
                      params: { levels: 1 },
                    });
                  })
                }
                className="flex items-center gap-1 px-2 py-0.5 rounded bg-purple-600/30 text-purple-300 hover:bg-purple-600/50 border border-purple-500/40 text-[10px]"
              >
                <Plus className="w-3 h-3" />
                <span>Add Modifier</span>
              </button>
            </div>

            {obj.modifiers.map((mod, idx) => (
              <div key={mod.id} className="bg-[#161a26] border border-white/10 rounded-lg p-2.5 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-white">{mod.name}</span>
                  <div className="flex items-center gap-1">
                    <input
                      type="checkbox"
                      checked={mod.enabled}
                      onChange={(e) =>
                        updateObject((d) => {
                          d.modifiers[idx].enabled = e.target.checked;
                        })
                      }
                      className="accent-purple-500"
                    />
                    <button
                      onClick={() =>
                        updateObject((d) => {
                          d.modifiers.splice(idx, 1);
                        })
                      }
                      className="text-slate-500 hover:text-red-400 p-1"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>

                {mod.type === 'subdivision' && (
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>Subdivision Levels</span>
                    <input
                      type="number"
                      min="1"
                      max="3"
                      value={mod.params.levels || 1}
                      onChange={(e) =>
                        updateObject((d) => {
                          d.modifiers[idx].params.levels = parseInt(e.target.value, 10);
                        })
                      }
                      className="w-16 bg-[#10131d] border border-white/10 rounded px-1.5 py-0.5 text-right font-mono"
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
