// ============================================================================
// AARDVARK XIF - COLOUR SCIENCE & SCOPES ENGINE
// High-precision colorimetric transforms, HDR transfer functions, gamut mapping,
// false-colour exposure analysis, and broadcast scopes (waveform, histogram, parade).
// ============================================================================

import { ColorSpace, TransferFunction } from './canonical-image';

export interface RgbPixel {
  r: number;
  g: number;
  b: number;
  a?: number;
}

export interface ScopeData {
  histogram: {
    r: number[];
    g: number[];
    b: number[];
    lum: number[];
    bins: number;
    maxCount: number;
    isLogScale: boolean;
  };
  waveform: Uint8Array; // 2D intensity grid [256 height x width]
  waveformWidth: number;
  waveformHeight: number;
  rgbParade: {
    r: Uint8Array;
    g: Uint8Array;
    b: Uint8Array;
    width: number;
    height: number;
  };
  stats: {
    minLum: number;
    maxLum: number;
    avgLum: number;
    clippedHighlightsPercent: number;
    crushedShadowsPercent: number;
    peakNitsEstimate: number;
  };
}

export class ColourScienceEngine {
  // Primaries Chromaticity Coordinates (x, y)
  // [Rx, Ry, Gx, Gy, Bx, By, Wx, Wy]
  public static readonly PRIMARIES = {
    sRGB: { r: [0.64, 0.33], g: [0.30, 0.60], b: [0.15, 0.06], w: [0.3127, 0.3290] },
    DisplayP3: { r: [0.68, 0.32], g: [0.265, 0.690], b: [0.15, 0.06], w: [0.3127, 0.3290] },
    Rec2020: { r: [0.708, 0.292], g: [0.170, 0.797], b: [0.131, 0.046], w: [0.3127, 0.3290] },
    ACEScg: { r: [0.713, 0.293], g: [0.165, 0.830], b: [0.128, 0.044], w: [0.32168, 0.33767] },
  };

  /**
   * Linearize an encoded channel value based on transfer function
   */
  public static decodeEOTF(val: number, tf: TransferFunction): number {
    if (val <= 0) return 0;
    switch (tf) {
      case TransferFunction.LINEAR:
        return val;

      case TransferFunction.SRGB:
        return val <= 0.04045 ? val / 12.92 : Math.pow((val + 0.055) / 1.055, 2.4);

      case TransferFunction.GAMMA_2_4:
        return Math.pow(val, 2.4);

      case TransferFunction.PQ_ST2084: {
        // SMPTE ST 2084 PQ to Linear (normalized 0..1 where 1.0 = 10,000 cd/m2)
        const m1 = 2610 / 16384;
        const m2 = (2523 / 4096) * 128;
        const c1 = 3424 / 4096;
        const c2 = (2413 / 4096) * 32;
        const c3 = (2392 / 4096) * 32;

        const Np = Math.pow(Math.max(0, val), 1 / m2);
        const num = Math.max(Np - c1, 0);
        const den = c2 - c3 * Np;
        return Math.pow(num / Math.max(den, 1e-6), 1 / m1);
      }

      case TransferFunction.HLG: {
        // ARIB STD-B67 HLG to Linear
        const a = 0.17883277;
        const b = 0.28466892;
        const c = 0.55991073;
        if (val <= 0.5) {
          return (val * val) / 3.0;
        } else {
          return (Math.exp((val - c) / a) + b) / 12.0;
        }
      }

      case TransferFunction.LOG_C: {
        // ARRI LogC4 approximate
        return (Math.pow(10, (val - 0.385537) / 0.247189) - 0.052272) * 0.95;
      }

      default:
        return val;
    }
  }

  /**
   * Encode a linear value into target transfer function
   */
  public static encodeOETF(linearVal: number, tf: TransferFunction): number {
    if (linearVal <= 0) return 0;
    switch (tf) {
      case TransferFunction.LINEAR:
        return linearVal;

      case TransferFunction.SRGB:
        return linearVal <= 0.0031308
          ? 12.92 * linearVal
          : 1.055 * Math.pow(linearVal, 1.0 / 2.4) - 0.055;

      case TransferFunction.GAMMA_2_4:
        return Math.pow(linearVal, 1.0 / 2.4);

      case TransferFunction.PQ_ST2084: {
        const m1 = 2610 / 16384;
        const m2 = (2523 / 4096) * 128;
        const c1 = 3424 / 4096;
        const c2 = (2413 / 4096) * 32;
        const c3 = (2392 / 4096) * 32;

        const Ym1 = Math.pow(Math.max(0, linearVal), m1);
        const num = c1 + c2 * Ym1;
        const den = 1 + c3 * Ym1;
        return Math.pow(num / den, m2);
      }

      case TransferFunction.HLG: {
        const a = 0.17883277;
        const b = 0.28466892;
        const c = 0.55991073;
        if (linearVal <= 1.0 / 12.0) {
          return Math.sqrt(3.0 * linearVal);
        } else {
          return a * Math.log(12.0 * linearVal - b) + c;
        }
      }

      default:
        return linearVal;
    }
  }

  /**
   * Convert RGB from Source ColorSpace to Display Target (e.g. ACEScg / P3 / Rec2020 -> sRGB)
   */
  public static transformColorSpace(
    rgb: [number, number, number],
    fromSpace: ColorSpace,
    toSpace: ColorSpace,
  ): [number, number, number] {
    if (fromSpace === toSpace) return [...rgb];

    // Simple 3x3 linear matrix transformation approximations
    // Display P3 -> sRGB
    if (fromSpace === ColorSpace.DISPLAY_P3 && toSpace === ColorSpace.SRGB) {
      const [r, g, b] = rgb;
      return [
        1.2249 * r - 0.2247 * g - 0.0002 * b,
        -0.0420 * r + 1.0419 * g + 0.0001 * b,
        -0.0197 * r - 0.0786 * g + 1.0983 * b,
      ];
    }

    // Rec.2020 -> sRGB
    if (fromSpace === ColorSpace.REC2020 && toSpace === ColorSpace.SRGB) {
      const [r, g, b] = rgb;
      return [
        1.6605 * r - 0.5876 * g - 0.0728 * b,
        -0.1246 * r + 1.1329 * g - 0.0083 * b,
        -0.0182 * r - 0.1006 * g + 1.1187 * b,
      ];
    }

    // ACEScg -> sRGB
    if (fromSpace === ColorSpace.ACESCG && toSpace === ColorSpace.SRGB) {
      const [r, g, b] = rgb;
      return [
        1.7049 * r - 0.6217 * g - 0.0832 * b,
        -0.1301 * r + 1.1407 * g - 0.0106 * b,
        -0.0240 * r - 0.1289 * g + 1.1529 * b,
      ];
    }

    // sRGB -> Display P3
    if (fromSpace === ColorSpace.SRGB && toSpace === ColorSpace.DISPLAY_P3) {
      const [r, g, b] = rgb;
      return [
        0.8225 * r + 0.1775 * g + 0.0000 * b,
        0.0332 * r + 0.9668 * g + 0.0000 * b,
        0.0171 * r + 0.0724 * g + 0.9105 * b,
      ];
    }

    return [...rgb];
  }

  /**
   * Apply False Color Exposure overlay to a pixel
   * Uses standard ARRI style False Color Exposure indexing:
   * Purple: Sub-black / crushed (0-2 IRE)
   * Blue: Deep shadows (2-10 IRE)
   * Teal: Dark Skin / low tones (10-30 IRE)
   * Green: 18% Middle Grey (38-42 IRE)
   * Pink: Caucasian Skin tones (52-58 IRE)
   * Yellow: Bright Highlights (75-85 IRE)
   * Red: Clipping / Saturation (99-100 IRE)
   */
  public static getFalseColorPixel(r: number, g: number, b: number): [number, number, number] {
    const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    const ire = Math.max(0, Math.min(100, lum * 100));

    if (ire <= 2) return [0.5, 0.0, 0.5]; // Purple (Clipping black)
    if (ire <= 10) return [0.0, 0.2, 0.8]; // Blue
    if (ire >= 38 && ire <= 44) return [0.0, 0.8, 0.1]; // Green (18% Mid-Grey reference)
    if (ire >= 52 && ire <= 58) return [0.9, 0.5, 0.7]; // Pink (Skin-tone reference)
    if (ire >= 80 && ire <= 90) return [1.0, 0.9, 0.0]; // Yellow (Specular highlight warning)
    if (ire >= 98) return [1.0, 0.0, 0.0]; // Red (Clipping white)

    // Grayscale neutral background
    const gVal = ire / 100 * 0.4 + 0.1;
    return [gVal, gVal, gVal];
  }

  /**
   * Compute comprehensive scopes data from decoded image pixels
   */
  public static computeScopes(
    pixels: Float32Array,
    width: number,
    height: number,
    bins: number = 256,
    isLogScale: boolean = false,
  ): ScopeData {
    const histR = new Array(bins).fill(0);
    const histG = new Array(bins).fill(0);
    const histB = new Array(bins).fill(0);
    const histLum = new Array(bins).fill(0);

    const totalPixels = width * height;
    let minLum = 1.0;
    let maxLum = 0.0;
    let sumLum = 0.0;
    let clippedCount = 0;
    let crushedCount = 0;

    const waveformW = Math.min(256, width);
    const waveformH = 128;
    const wfGrid = new Uint8Array(waveformW * waveformH);

    const paradeR = new Uint8Array(waveformW * waveformH);
    const paradeG = new Uint8Array(waveformW * waveformH);
    const paradeB = new Uint8Array(waveformW * waveformH);

    const stepX = Math.max(1, Math.floor(width / waveformW));
    const stepY = Math.max(1, Math.floor(height / 100));

    for (let y = 0; y < height; y += stepY) {
      for (let x = 0; x < width; x += stepX) {
        const idx = (y * width + x) * 4;
        const r = Math.max(0, Math.min(1.0, pixels[idx]));
        const g = Math.max(0, Math.min(1.0, pixels[idx + 1]));
        const b = Math.max(0, Math.min(1.0, pixels[idx + 2]));
        const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;

        minLum = Math.min(minLum, lum);
        maxLum = Math.max(maxLum, lum);
        sumLum += lum;

        if (lum >= 0.99) clippedCount++;
        if (lum <= 0.01) crushedCount++;

        const binR = Math.min(bins - 1, Math.floor(r * (bins - 1)));
        const binG = Math.min(bins - 1, Math.floor(g * (bins - 1)));
        const binB = Math.min(bins - 1, Math.floor(b * (bins - 1)));
        const binL = Math.min(bins - 1, Math.floor(lum * (bins - 1)));

        histR[binR]++;
        histG[binG]++;
        histB[binB]++;
        histLum[binL]++;

        // Waveform plot
        const wfX = Math.min(waveformW - 1, Math.floor(x / stepX));
        const wfY = Math.min(waveformH - 1, Math.floor((1.0 - lum) * (waveformH - 1)));
        const wfIdx = wfY * waveformW + wfX;
        wfGrid[wfIdx] = Math.min(255, wfGrid[wfIdx] + 15);

        // Parade plot
        const rY = Math.min(waveformH - 1, Math.floor((1.0 - r) * (waveformH - 1)));
        const gY = Math.min(waveformH - 1, Math.floor((1.0 - g) * (waveformH - 1)));
        const bY = Math.min(waveformH - 1, Math.floor((1.0 - b) * (waveformH - 1)));

        paradeR[rY * waveformW + wfX] = Math.min(255, paradeR[rY * waveformW + wfX] + 15);
        paradeG[gY * waveformW + wfX] = Math.min(255, paradeG[gY * waveformW + wfX] + 15);
        paradeB[bY * waveformW + wfX] = Math.min(255, paradeB[bY * waveformW + wfX] + 15);
      }
    }

    let maxHist = 1;
    for (let i = 0; i < bins; i++) {
      maxHist = Math.max(maxHist, histR[i], histG[i], histB[i], histLum[i]);
    }

    const sampledCount = Math.max(1, (width / stepX) * (height / stepY));
    const avgLum = sumLum / sampledCount;

    return {
      histogram: {
        r: histR,
        g: histG,
        b: histB,
        lum: histLum,
        bins,
        maxCount: maxHist,
        isLogScale,
      },
      waveform: wfGrid,
      waveformWidth: waveformW,
      waveformHeight: waveformH,
      rgbParade: {
        r: paradeR,
        g: paradeG,
        b: paradeB,
        width: waveformW,
        height: waveformH,
      },
      stats: {
        minLum,
        maxLum,
        avgLum,
        clippedHighlightsPercent: (clippedCount / sampledCount) * 100,
        crushedShadowsPercent: (crushedCount / sampledCount) * 100,
        peakNitsEstimate: maxLum > 1.0 ? maxLum * 1000 : maxLum * 400,
      },
    };
  }

  /**
   * Delta E 2000 (CIEDE2000) for color accuracy difference computation
   */
  public static calculateDeltaE2000(rgb1: [number, number, number], rgb2: [number, number, number]): number {
    // Fast Euclidean approximation in perceptually weighted Lab space
    const rmean = (rgb1[0] + rgb2[0]) / 2;
    const r = rgb1[0] - rgb2[0];
    const g = rgb1[1] - rgb2[1];
    const b = rgb1[2] - rgb2[2];
    const weightR = 2 + rmean;
    const weightG = 4.0;
    const weightB = 3 - rmean;
    return Math.sqrt(weightR * r * r + weightG * g * g + weightB * b * b) * 100;
  }
}
