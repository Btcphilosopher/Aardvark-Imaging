// ============================================================================
// AARDVARK XIF - CANONICAL IMAGE MODEL
// High-dynamic-range, high-resolution, multi-channel, multi-resolution image model
// ============================================================================

export enum SampleType {
  UINT8 = 'UINT8',
  UINT10 = 'UINT10',
  UINT12 = 'UINT12',
  UINT14 = 'UINT14',
  UINT16 = 'UINT16',
  UINT32 = 'UINT32',
  FLOAT16 = 'FLOAT16',
  FLOAT32 = 'FLOAT32',
}

export enum ColorSpace {
  SRGB = 'sRGB',
  DISPLAY_P3 = 'Display P3',
  REC2020 = 'Rec.2020',
  ACESCG = 'ACEScg',
  ACESCC = 'ACEScc',
  LINEAR_SRGB = 'Linear sRGB',
  CIE_XYZ = 'CIE XYZ D65',
  CUSTOM_ICC = 'Custom ICC',
}

export enum TransferFunction {
  LINEAR = 'Linear (Scene-Referred)',
  SRGB = 'sRGB Gamma (2.2 approx)',
  PQ_ST2084 = 'SMPTE ST 2084 (PQ HDR 10,000 nits)',
  HLG = 'ARIB STD-B67 (HLG HDR)',
  HLG_BT2100 = 'ARIB STD-B67 (HLG HDR)',
  GAMMA_2_4 = 'BT.1886 Gamma 2.4',
  LOG_C = 'ARRI LogC4',
}

export enum ChannelSemantic {
  RED = 'R',
  GREEN = 'G',
  BLUE = 'B',
  ALPHA = 'A',
  LUMINANCE = 'Y',
  DEPTH = 'DEPTH',
  DISPARITY = 'DISPARITY',
  NORMAL_X = 'NORMAL_X',
  NORMAL_Y = 'NORMAL_Y',
  NORMAL_Z = 'NORMAL_Z',
  THERMAL = 'THERMAL',
  NIR = 'NIR',
  RED_EDGE = 'RED_EDGE',
  SPECTRAL_BAND = 'SPECTRAL_BAND',
  MASK = 'MASK',
  OBJECT_ID = 'OBJECT_ID',
}

export interface AxifChannelInfo {
  name: string;
  semantic: ChannelSemantic;
  sampleType: SampleType;
  bitDepth: number;
  rangeMin: number;
  rangeMax: number;
  units?: string;
  wavelengthNm?: number;
}

export enum CompressionCodec {
  RAW = 'RAW (Uncompressed)',
  AXC_LOSSLESS = 'AXC Lossless (Paeth+Entropy)',
  AXC_WAVELET = 'AXC Wavelet DWT (Reversible 5/3)',
  AXC_LOSSY = 'AXC Lossy Perceptual (9/7 CDF + Q)',
  ZSTD_DEFLATE = 'ZSTD/Deflate Container',
  JPEG_XL_COMPAT = 'JPEG XL Adapter',
  OPENEXR_COMPAT = 'OpenEXR Float Adapter',
}

export interface AxifLevelInfo {
  levelIndex: number;
  width: number;
  height: number;
  scaleFactor: number; // 1, 2, 4, 8, 16, 32...
  tilesX: number;
  tilesY: number;
  tileWidth: number;
  tileHeight: number;
  totalTiles: number;
}

export interface AxifTileCoord {
  level: number;
  tileX: number;
  tileY: number;
  channelIndex?: number;
}

export interface AxifTileData {
  coord: AxifTileCoord;
  width: number;
  height: number;
  pixelData: Float32Array | Uint8Array | Uint16Array;
  channels: number;
  byteSize: number;
  codec: CompressionCodec;
  crc32c: number;
}

export interface AxifRegionRequest {
  x: number;
  y: number;
  width: number;
  height: number;
  level: number;
  channels?: string[];
}

export interface AxifDecodedRegion {
  x: number;
  y: number;
  width: number;
  height: number;
  level: number;
  data: Float32Array; // Interleaved Float32 [r, g, b, a] normalized or HDR
  channels: number;
  tilesAccessed: number;
  decodeTimeMs: number;
}

export interface AxifProvenanceEntry {
  stage: string;
  timestamp: string;
  software: string;
  version: string;
  parameters: Record<string, string | number | boolean>;
  operator?: string;
  inputHash?: string;
  outputHash: string;
}

export interface AxifCameraMetadata {
  make: string;
  model: string;
  serialNumber: string;
  lensModel: string;
  focalLengthMm: number;
  apertureFStop: number;
  shutterSpeedSec: number;
  isoEquivalent: number;
  sensorDimensionsMm: [number, number];
  sensorNativeResolution: [number, number];
  readoutMode: string;
  temperatureCelsius: number;
  whiteBalanceKelvin: number;
  calibrationMatrix?: number[][];
}

export interface AxifAiProvenance {
  isAiGenerated: boolean;
  generator?: string;
  modelIdentifier?: string;
  modelVersion?: string;
  promptReference?: string;
  seed?: number;
  sampler?: string;
  cfgScale?: number;
  steps?: number;
}

export interface AxifMetadataContainer {
  title: string;
  author: string;
  copyright: string;
  description: string;
  creationDate: string;
  camera?: AxifCameraMetadata;
  aiProvenance?: AxifAiProvenance;
  provenanceGraph: AxifProvenanceEntry[];
  customAttributes: Record<string, string | number | boolean>;
  iccProfileName?: string;
  contentSignature?: string;
  masterHashSha256?: string;
}

/**
 * Core Canonical Image Model
 */
export class CanonicalImage {
  public id: string;
  public width: number;
  public height: number;
  public channels: AxifChannelInfo[];
  public colorSpace: ColorSpace;
  public transferFunction: TransferFunction;
  public tileWidth: number;
  public tileHeight: number;
  public levels: AxifLevelInfo[];
  public metadata: AxifMetadataContainer;
  public defaultCodec: CompressionCodec;

  // Cached tile memory storage (virtualized or memory-backed)
  private tileCache: Map<string, AxifTileData> = new Map();
  // Generator function for synthetic or dynamic tiles
  private proceduralTileSampler?: (coord: AxifTileCoord, outWidth: number, outHeight: number) => Float32Array;

  constructor(
    width: number,
    height: number,
    channels: AxifChannelInfo[] = [
      { name: 'R', semantic: ChannelSemantic.RED, sampleType: SampleType.FLOAT32, bitDepth: 32, rangeMin: 0, rangeMax: 1 },
      { name: 'G', semantic: ChannelSemantic.GREEN, sampleType: SampleType.FLOAT32, bitDepth: 32, rangeMin: 0, rangeMax: 1 },
      { name: 'B', semantic: ChannelSemantic.BLUE, sampleType: SampleType.FLOAT32, bitDepth: 32, rangeMin: 0, rangeMax: 1 },
      { name: 'A', semantic: ChannelSemantic.ALPHA, sampleType: SampleType.FLOAT32, bitDepth: 32, rangeMin: 0, rangeMax: 1 },
    ],
    colorSpace: ColorSpace = ColorSpace.DISPLAY_P3,
    transferFunction: TransferFunction = TransferFunction.SRGB,
    tileWidth: number = 512,
    tileHeight: number = 512,
    codec: CompressionCodec = CompressionCodec.AXC_LOSSLESS,
  ) {
    this.id = 'axif_' + Math.random().toString(36).substring(2, 9);
    this.width = width;
    this.height = height;
    this.channels = channels;
    this.colorSpace = colorSpace;
    this.transferFunction = transferFunction;
    this.tileWidth = tileWidth;
    this.tileHeight = tileHeight;
    this.defaultCodec = codec;
    this.metadata = {
      title: 'Aardvark Master 16K Render',
      author: 'Aardvark Imaging Pro Systems',
      copyright: '© 2026 Aardvark Imaging. All rights reserved.',
      description: 'Native AXIF high-dynamic-range tiled multi-resolution master container.',
      creationDate: new Date().toISOString(),
      provenanceGraph: [],
      customAttributes: {
        'aardvark.container.version': '1.0.0',
        'aardvark.storage.tiled': true,
        'aardvark.storage.tile_size': `${tileWidth}x${tileHeight}`,
        'aardvark.pipeline.hdr_capable': true,
      },
    };

    this.levels = this.computePyramidLevels();
  }

  public setProceduralSampler(sampler: (coord: AxifTileCoord, outWidth: number, outHeight: number) => Float32Array) {
    this.proceduralTileSampler = sampler;
  }

  private computePyramidLevels(): AxifLevelInfo[] {
    const levels: AxifLevelInfo[] = [];
    let curW = this.width;
    let curH = this.height;
    let scale = 1;
    let levelIdx = 0;

    while (curW > 64 || curH > 64 || levelIdx === 0) {
      const tilesX = Math.ceil(curW / this.tileWidth);
      const tilesY = Math.ceil(curH / this.tileHeight);
      levels.push({
        levelIndex: levelIdx,
        width: curW,
        height: curH,
        scaleFactor: scale,
        tilesX,
        tilesY,
        tileWidth: this.tileWidth,
        tileHeight: this.tileHeight,
        totalTiles: tilesX * tilesY,
      });

      if (curW <= 128 && curH <= 128) break;
      curW = Math.max(1, Math.floor(curW / 2));
      curH = Math.max(1, Math.floor(curH / 2));
      scale *= 2;
      levelIdx++;
      if (levelIdx > 10) break; // Maximum 10 pyramid levels
    }
    return levels;
  }

  private getTileKey(coord: AxifTileCoord): string {
    return `${coord.level}_${coord.tileX}_${coord.tileY}_${coord.channelIndex ?? 'all'}`;
  }

  public setTile(coord: AxifTileCoord, data: AxifTileData): void {
    this.tileCache.set(this.getTileKey(coord), data);
  }

  public getTile(coord: AxifTileCoord): AxifTileData {
    const key = this.getTileKey(coord);
    if (this.tileCache.has(key)) {
      return this.tileCache.get(key)!;
    }

    // If we have a procedural sampler (for 8K/16K synthetic or test master charts)
    if (this.proceduralTileSampler) {
      const levelInfo = this.levels[coord.level] || this.levels[0];
      const startX = coord.tileX * this.tileWidth;
      const startY = coord.tileY * this.tileHeight;
      const tW = Math.min(this.tileWidth, levelInfo.width - startX);
      const tH = Math.min(this.tileHeight, levelInfo.height - startY);

      const pixels = this.proceduralTileSampler(coord, tW, tH);
      const tile: AxifTileData = {
        coord,
        width: tW,
        height: tH,
        pixelData: pixels,
        channels: this.channels.length,
        byteSize: pixels.byteLength,
        codec: this.defaultCodec,
        crc32c: 0x9a8b7c6d ^ (coord.tileX * 31 + coord.tileY * 17 + coord.level * 101),
      };
      this.tileCache.set(key, tile);
      return tile;
    }

    // Default empty black tile
    const tW = this.tileWidth;
    const tH = this.tileHeight;
    const pixels = new Float32Array(tW * tH * this.channels.length);
    const tile: AxifTileData = {
      coord,
      width: tW,
      height: tH,
      pixelData: pixels,
      channels: this.channels.length,
      byteSize: pixels.byteLength,
      codec: CompressionCodec.RAW,
      crc32c: 0,
    };
    return tile;
  }

  /**
   * Reads a sub-region (ROI) at a specific resolution level.
   * Only reads and decompresses the tiles intersecting the requested viewport!
   */
  public readRegion(request: AxifRegionRequest): AxifDecodedRegion {
    const startTime = performance.now();
    const level = Math.min(request.level, this.levels.length - 1);
    const levelInfo = this.levels[level];

    // Constrain region to image bounds
    const rx = Math.max(0, Math.min(request.x, levelInfo.width - 1));
    const ry = Math.max(0, Math.min(request.y, levelInfo.height - 1));
    const rw = Math.min(request.width, levelInfo.width - rx);
    const rh = Math.min(request.height, levelInfo.height - ry);

    const outData = new Float32Array(rw * rh * 4); // RGBA output

    const minTileX = Math.floor(rx / this.tileWidth);
    const maxTileX = Math.floor((rx + rw - 1) / this.tileWidth);
    const minTileY = Math.floor(ry / this.tileHeight);
    const maxTileY = Math.floor((ry + rh - 1) / this.tileHeight);

    let tilesAccessed = 0;

    for (let ty = minTileY; ty <= maxTileY; ty++) {
      for (let tx = minTileX; tx <= maxTileX; tx++) {
        if (tx >= levelInfo.tilesX || ty >= levelInfo.tilesY) continue;

        const tile = this.getTile({ level, tileX: tx, tileY: ty });
        tilesAccessed++;

        const tileStartX = tx * this.tileWidth;
        const tileStartY = ty * this.tileHeight;

        const intersectMinX = Math.max(rx, tileStartX);
        const intersectMaxX = Math.min(rx + rw, tileStartX + tile.width);
        const intersectMinY = Math.max(ry, tileStartY);
        const intersectMaxY = Math.min(ry + rh, tileStartY + tile.height);

        const chCount = this.channels.length;
        const tileFloatData = tile.pixelData as Float32Array;

        for (let py = intersectMinY; py < intersectMaxY; py++) {
          const tileLocalY = py - tileStartY;
          const outLocalY = py - ry;

          for (let px = intersectMinX; px < intersectMaxX; px++) {
            const tileLocalX = px - tileStartX;
            const outLocalX = px - rx;

            const tileIdx = (tileLocalY * tile.width + tileLocalX) * chCount;
            const outIdx = (outLocalY * rw + outLocalX) * 4;

            if (chCount >= 4) {
              outData[outIdx] = tileFloatData[tileIdx];
              outData[outIdx + 1] = tileFloatData[tileIdx + 1];
              outData[outIdx + 2] = tileFloatData[tileIdx + 2];
              outData[outIdx + 3] = tileFloatData[tileIdx + 3];
            } else if (chCount === 3) {
              outData[outIdx] = tileFloatData[tileIdx];
              outData[outIdx + 1] = tileFloatData[tileIdx + 1];
              outData[outIdx + 2] = tileFloatData[tileIdx + 2];
              outData[outIdx + 3] = 1.0;
            } else if (chCount === 1) {
              const v = tileFloatData[tileIdx];
              outData[outIdx] = v;
              outData[outIdx + 1] = v;
              outData[outIdx + 2] = v;
              outData[outIdx + 3] = 1.0;
            }
          }
        }
      }
    }

    const decodeTimeMs = performance.now() - startTime;
    return {
      x: rx,
      y: ry,
      width: rw,
      height: rh,
      level,
      data: outData,
      channels: 4,
      tilesAccessed,
      decodeTimeMs,
    };
  }

  public getLevelCount(): number {
    return this.levels.length;
  }

  public getLevelInfo(level: number): AxifLevelInfo {
    return this.levels[Math.min(level, this.levels.length - 1)];
  }
}
