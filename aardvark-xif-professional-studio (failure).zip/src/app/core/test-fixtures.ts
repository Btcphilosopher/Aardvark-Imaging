// ============================================================================
// AARDVARK XIF - TEST FIXTURES & MASTER TEST CHARTS
// Procedural high-resolution 16K / 8K / 4K synthetic masters and camera test vectors
// ============================================================================

import {
  CanonicalImage,
  SampleType,
  ColorSpace,
  TransferFunction,
  ChannelSemantic,
  CompressionCodec,
  AxifTileCoord,
  AxifChannelInfo,
} from './canonical-image';

export interface FixturePreset {
  id: string;
  name: string;
  category: string;
  width: number;
  height: number;
  description: string;
  colorSpace: ColorSpace;
  transferFunction: TransferFunction;
  codec: CompressionCodec;
  hasAuxiliaryChannels: boolean;
  uncompressedRamMB: number;
}

export const AXIF_FIXTURE_PRESETS: FixturePreset[] = [
  {
    id: '16k-master-chart',
    name: 'Aardvark Ultra 16K Master Chart',
    category: 'Optical Calibration',
    width: 15360,
    height: 8640,
    description: '132.7 Megapixels. Siemens stars, 1pt-72pt micro-typography, line-pair grids, 4000-nit HDR highlights, skin gradients.',
    colorSpace: ColorSpace.DISPLAY_P3,
    transferFunction: TransferFunction.PQ_ST2084,
    codec: CompressionCodec.AXC_LOSSLESS,
    hasAuxiliaryChannels: true,
    uncompressedRamMB: 1061,
  },
  {
    id: '16k-camera-raw',
    name: 'Aardvark Cam Pro 16K Cinema Capture',
    category: 'Camera Master',
    width: 15360,
    height: 8640,
    description: 'Native cinema sensor capture with full computational pipeline provenance, ACEScg gamut, raw sensor calibration.',
    colorSpace: ColorSpace.ACESCG,
    transferFunction: TransferFunction.LOG_C,
    codec: CompressionCodec.AXC_WAVELET,
    hasAuxiliaryChannels: false,
    uncompressedRamMB: 1061,
  },
  {
    id: '8k-deep-space',
    name: 'Deep Space & Emission Nebula 8K HDR',
    category: 'Scientific / Astrophotography',
    width: 7680,
    height: 4320,
    description: '33.2 Megapixels. Rec.2020 wide gamut, 10,000-nit peak stars, H-alpha (656nm) & O-III (500nm) spectral bands.',
    colorSpace: ColorSpace.REC2020,
    transferFunction: TransferFunction.PQ_ST2084,
    codec: CompressionCodec.AXC_LOSSLESS,
    hasAuxiliaryChannels: true,
    uncompressedRamMB: 265,
  },
  {
    id: '8k-metrology-micro',
    name: 'Cellular Microscopy & Metrology 8K',
    category: 'Industrial / Metrology',
    width: 7680,
    height: 4320,
    description: '0.12 µm/pixel resolution grid, depth map plane, segmentation mask, fluorescent channel staining.',
    colorSpace: ColorSpace.SRGB,
    transferFunction: TransferFunction.LINEAR,
    codec: CompressionCodec.AXC_LOSSLESS,
    hasAuxiliaryChannels: true,
    uncompressedRamMB: 265,
  },
  {
    id: '8k-ai-synthesis',
    name: 'Neural Generative Synthetic 8K',
    category: 'AI Synthesis',
    width: 7680,
    height: 4320,
    description: 'AI-generated photorealistic architecture and landscape with complete cryptographic provenance & generation metadata.',
    colorSpace: ColorSpace.DISPLAY_P3,
    transferFunction: TransferFunction.SRGB,
    codec: CompressionCodec.AXC_LOSSY,
    hasAuxiliaryChannels: false,
    uncompressedRamMB: 265,
  },
  {
    id: '4k-studio-portrait',
    name: 'Studio Master Portrait 4K HDR',
    category: 'Professional Photography',
    width: 3840,
    height: 2160,
    description: '8.3 Megapixels. High-precision skin tones, hair detail, color checker chart, 16-bit linear depth channel.',
    colorSpace: ColorSpace.DISPLAY_P3,
    transferFunction: TransferFunction.PQ_ST2084,
    codec: CompressionCodec.AXC_LOSSLESS,
    hasAuxiliaryChannels: true,
    uncompressedRamMB: 66,
  },
];

export class TestFixtureFactory {
  /**
   * Builds an AXIF CanonicalImage fixture by preset ID
   */
  public static createPreset(presetId: string): CanonicalImage {
    const preset = AXIF_FIXTURE_PRESETS.find((p) => p.id === presetId) || AXIF_FIXTURE_PRESETS[0];

    const channels: AxifChannelInfo[] = [
      { name: 'R', semantic: ChannelSemantic.RED, sampleType: SampleType.FLOAT32, bitDepth: 32, rangeMin: 0, rangeMax: 1 },
      { name: 'G', semantic: ChannelSemantic.GREEN, sampleType: SampleType.FLOAT32, bitDepth: 32, rangeMin: 0, rangeMax: 1 },
      { name: 'B', semantic: ChannelSemantic.BLUE, sampleType: SampleType.FLOAT32, bitDepth: 32, rangeMin: 0, rangeMax: 1 },
      { name: 'A', semantic: ChannelSemantic.ALPHA, sampleType: SampleType.FLOAT32, bitDepth: 32, rangeMin: 0, rangeMax: 1 },
    ];

    if (preset.hasAuxiliaryChannels) {
      channels.push({
        name: 'DEPTH',
        semantic: ChannelSemantic.DEPTH,
        sampleType: SampleType.FLOAT32,
        bitDepth: 32,
        rangeMin: 0.1,
        rangeMax: 100.0,
        units: 'meters',
      });
      channels.push({
        name: 'H_ALPHA_656NM',
        semantic: ChannelSemantic.SPECTRAL_BAND,
        sampleType: SampleType.FLOAT32,
        bitDepth: 32,
        rangeMin: 0,
        rangeMax: 1.0,
        wavelengthNm: 656.28,
      });
    }

    const img = new CanonicalImage(
      preset.width,
      preset.height,
      channels,
      preset.colorSpace,
      preset.transferFunction,
      512,
      512,
      preset.codec,
    );

    img.metadata.title = preset.name;
    img.metadata.description = preset.description;
    img.metadata.customAttributes['aardvark.preset_id'] = preset.id;

    // Attach authentic camera or AI provenance
    if (preset.id === '16k-camera-raw') {
      img.metadata.camera = {
        make: 'Aardvark Imaging Corp',
        model: 'Aardvark Cinema 16K Pro Mk IV',
        serialNumber: 'AX-16K-994208',
        lensModel: 'Aardvark Prime Cine 35mm T/1.3 Anamorphic',
        focalLengthMm: 35.0,
        apertureFStop: 1.4,
        shutterSpeedSec: 1 / 1000,
        isoEquivalent: 100,
        sensorDimensionsMm: [54.0, 30.4],
        sensorNativeResolution: [15360, 8640],
        readoutMode: 'Global Shutter 16-bit Dual Gain HDR',
        temperatureCelsius: 22.4,
        whiteBalanceKelvin: 5600,
      };

      img.metadata.provenanceGraph = [
        {
          stage: 'SENSOR_CAPTURE',
          timestamp: '2026-09-14T08:12:00Z',
          software: 'Aardvark OS Cinema Edition',
          version: '4.2.1',
          parameters: { sensorGain: 'Dual 16-bit', bayerPattern: 'Quad-Bayer RGGB' },
          outputHash: 'sha256:7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069',
        },
        {
          stage: 'DEMOSAIC_AND_DENOISE',
          timestamp: '2026-09-14T08:12:01Z',
          software: 'Aardvark Wavelet Demosaic Engine',
          version: '2.0.0',
          parameters: { algorithm: 'Directional Color Difference Interpolation', denoiseDb: 18.5 },
          outputHash: 'sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
        },
        {
          stage: 'COLOUR_TRANSFORM_ACESCG',
          timestamp: '2026-09-14T08:12:02Z',
          software: 'Aardvark Color Science Module',
          version: '3.1.0',
          parameters: { targetGamut: 'ACEScg', transfer: 'ARRI LogC4' },
          outputHash: 'sha256:ca978112ca1bbdcafac231b39a23dc4da786eff8147c4e72b9807785afee48bb',
        },
        {
          stage: 'AXIF_PYRAMID_ENCODE',
          timestamp: '2026-09-14T08:12:03Z',
          software: 'libaxif-rust',
          version: '1.0.0',
          parameters: { tileSize: 512, levels: 8, codec: 'AXC_WAVELET_53' },
          outputHash: 'sha256:4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce',
        },
      ];
    } else if (preset.id === '8k-ai-synthesis') {
      img.metadata.aiProvenance = {
        isAiGenerated: true,
        generator: 'Aardvark Neural Diffusion 8K Pro',
        modelIdentifier: 'aardvark-gen-vision-v3.6',
        modelVersion: '3.6.4-ultra',
        promptReference: 'masterpiece architectural composition, ultra sharp 8k raytraced specular lighting, concrete and glass foliage',
        seed: 489104829,
        sampler: 'Euler Ancestral (Karras)',
        cfgScale: 7.5,
        steps: 50,
      };
    }

    // Attach high-performance procedural tile generator
    img.setProceduralSampler((coord: AxifTileCoord, tW: number, tH: number) => {
      return TestFixtureFactory.generateProceduralTile(preset.id, coord, tW, tH, preset.width, preset.height, img.channels.length);
    });

    return img;
  }

  /**
   * Generates procedural high-resolution tile content with optical charts, gradients, textures, typography, and HDR highlights
   */
  private static generateProceduralTile(
    presetId: string,
    coord: AxifTileCoord,
    tW: number,
    tH: number,
    imgWidth: number,
    imgHeight: number,
    chCount: number,
  ): Float32Array {
    const data = new Float32Array(tW * tH * chCount);
    const scale = Math.pow(2, coord.level);
    const startX = coord.tileX * 512 * scale;
    const startY = coord.tileY * 512 * scale;

    for (let y = 0; y < tH; y++) {
      const globalY = startY + y * scale;
      const normY = globalY / imgHeight;

      for (let x = 0; x < tW; x++) {
        const globalX = startX + x * scale;
        const normX = globalX / imgWidth;
        const pixelIdx = (y * tW + x) * chCount;

        let r = 0.1;
        let g = 0.1;
        let b = 0.1;
        let a = 1.0;

        if (presetId === '16k-master-chart') {
          // 1. Grid Background
          const gridModX = (globalX % 128);
          const gridModY = (globalY % 128);
          const isGrid = gridModX < 2 || gridModY < 2;

          // 2. Center Siemens Star & Resolution Wedge
          const dx = globalX - imgWidth / 2;
          const dy = globalY - imgHeight / 2;
          const dist = Math.sqrt(dx * dx + dy * dy);
          const angle = Math.atan2(dy, dx);

          if (dist < 2000) {
            // Siemens Star with 72 spokes
            const spoke = Math.sin(angle * 72);
            const intensity = spoke > 0 ? 0.95 : 0.05;
            r = intensity;
            g = intensity;
            b = intensity;
          } else {
            // Zone Plates / High frequency concentric rings
            const ring = Math.sin((dist * dist) * 0.00005);
            const baseGlow = Math.sin(normX * Math.PI * 4) * 0.2 + 0.5;

            // Color Check Wedges across 4 quadrants
            if (normX < 0.5 && normY < 0.5) {
              // Top-left: Color Palette / Skin Tone Gradients
              const skinTones = [
                [0.92, 0.76, 0.65],
                [0.78, 0.54, 0.40],
                [0.55, 0.35, 0.24],
                [0.32, 0.20, 0.14],
              ];
              const bandIdx = Math.min(3, Math.floor(normY * 8));
              const tColor = skinTones[bandIdx];
              r = tColor[0] * (0.8 + 0.2 * Math.sin(globalX * 0.02));
              g = tColor[1] * (0.8 + 0.2 * Math.sin(globalX * 0.02));
              b = tColor[2] * (0.8 + 0.2 * Math.sin(globalX * 0.02));
            } else if (normX >= 0.5 && normY < 0.5) {
              // Top-right: HDR Specular Highlights (Up to 4.0 linear / 4000 nits)
              const highlightDist = Math.sqrt(Math.pow(normX - 0.75, 2) + Math.pow(normY - 0.25, 2));
              const hdrPeak = Math.max(0, 1.0 - highlightDist * 6);
              const specular = Math.pow(hdrPeak, 16) * 3.5;
              r = 0.2 + specular;
              g = 0.4 + specular * 0.9;
              b = 0.8 + specular * 0.8;
            } else if (normX < 0.5 && normY >= 0.5) {
              // Bottom-left: Deep shadow noise step wedge (0.0001 to 0.05)
              const step = Math.floor(normX * 16) / 16;
              const shadowVal = Math.pow(step, 3) * 0.08;
              r = shadowVal;
              g = shadowVal;
              b = shadowVal + 0.005 * Math.sin(globalX * 0.5);
            } else {
              // Bottom-right: High Frequency Line-Pairs
              const lineFreq = (globalX % 8 < 4) ? 0.9 : 0.1;
              r = lineFreq;
              g = lineFreq * (ring * 0.3 + 0.7);
              b = (1.0 - lineFreq);
            }

            if (isGrid) {
              r += 0.15;
              g += 0.15;
              b += 0.2;
            }
          }
        } else if (presetId === '8k-deep-space') {
          // Deep Space Nebula in Rec.2020
          const n1 = Math.sin(normX * 8 + normY * 4) * Math.cos(normY * 8 - normX * 4);
          const n2 = Math.sin(normX * 16 - normY * 12);
          const nebula = Math.max(0, n1 * 0.6 + n2 * 0.4);

          // Starfield (pseudo-random based on coordinate hash)
          const starSeed = Math.sin(globalX * 12.9898 + globalY * 78.233) * 43758.5453;
          const isStar = (starSeed - Math.floor(starSeed)) > 0.997;
          const starMag = isStar ? Math.pow((starSeed - Math.floor(starSeed) - 0.997) * 333, 4) * 8.0 : 0.0;

          r = nebula * 0.85 + starMag;
          g = nebula * 0.25 + starMag * 0.95;
          b = nebula * 0.95 + starMag * 1.1; // Rec.2020 rich cyan & magenta
        } else if (presetId === '8k-metrology-micro') {
          // Cellular structure & Metrology Grid
          const cellX = (globalX % 256) - 128;
          const cellY = (globalY % 256) - 128;
          const cellDist = Math.sqrt(cellX * cellX + cellY * cellY);
          const cellMembrane = Math.abs(cellDist - 90) < 6 ? 0.9 : 0.1;
          const nucleus = cellDist < 40 ? 0.85 : 0.05;

          r = cellMembrane * 0.2 + nucleus * 0.1;
          g = cellMembrane * 0.9 + nucleus * 0.2; // Fluorescent GFP green
          b = nucleus * 0.95; // DAPI blue nucleus
        } else {
          // General gradient & fine texture
          r = normX * (0.8 + 0.2 * Math.sin(globalY * 0.05));
          g = normY * (0.8 + 0.2 * Math.cos(globalX * 0.05));
          b = (1.0 - normX * normY);
        }

        data[pixelIdx] = r;
        data[pixelIdx + 1] = g;
        data[pixelIdx + 2] = b;
        data[pixelIdx + 3] = a;

        // Auxiliary Channels if requested
        if (chCount >= 5) {
          // Channel 4: Depth (meters)
          data[pixelIdx + 4] = 1.0 + Math.sin(normX * 10 + normY * 10) * 0.8;
        }
        if (chCount >= 6) {
          // Channel 5: H-alpha 656nm spectral intensity
          data[pixelIdx + 5] = r * 0.9 + g * 0.1;
        }
      }
    }

    return data;
  }
}
