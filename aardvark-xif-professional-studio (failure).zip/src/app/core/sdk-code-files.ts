// ============================================================================
// AARDVARK XIF - SDK CODE FILES & OFFICIAL SPECIFICATION REPOSITORY
// Full Rust Crate source, Python SDK, C ABI header, and SPECIFICATION.md
// ============================================================================

export interface SdkFileItem {
  filename: string;
  language: 'rust' | 'python' | 'c' | 'markdown' | 'toml' | 'bash';
  title: string;
  category: 'Specification' | 'Rust Crate' | 'Python SDK' | 'C ABI' | 'CLI Suite';
  content: string;
}

export const AXIF_SDK_FILES: SdkFileItem[] = [
  {
    filename: 'SPECIFICATION.md',
    language: 'markdown',
    title: 'AARDVARK XIF v1.0 File Format Specification',
    category: 'Specification',
    content: `# AARDVARK EXTENDED IMAGE FORMAT (AXIF)
## Technical Specification v1.0.0
### Document Revision: 2026-09-14 | Aardvark Imaging Standards Committee

---

### 1. Scope and Design Objectives
The **Aardvark Extended Image Format (AXIF)** is an open, high-performance binary container and image processing architecture specifically engineered for 8K, 16K, and 32K ultra-high-resolution rasters, high-dynamic-range (HDR) imaging, wide-gamut photography, computational cameras, scientific metrology, and deep-zoom web streaming.

AXIF establishes the paradigm of **"One Master Image, Many Representations"**: a single container encapsulates the full-fidelity multi-channel master, an intrinsic multi-resolution spatial pyramid, an addressable 512x512 tile index, camera provenance, and cryptographic authenticity metadata.

---

### 2. Binary Layout & Container Architecture
An AXIF stream is structured in discrete, 64-bit aligned segments:

\`\`\`
+-------------------------------------------------------------+
| AXIF HEADER (128 bytes fixed, Big-Endian / 64-bit offsets)  |
+-------------------------------------------------------------+
| MANIFEST SEGMENT (UTF-8 JSON / Schema v1.0, typed metadata) |
+-------------------------------------------------------------+
| TILE CHUNK INDEX TABLE (Array of level, tileX, tileY, etc)  |
+-------------------------------------------------------------+
| DATA SEGMENT (Independently compressed 512x512 tile blocks) |
+-------------------------------------------------------------+
| CHECKSUM / CRYPTOGRAPHIC SIGNATURE TRAILER                  |
+-------------------------------------------------------------+
\`\`\`

#### 2.1 Header Field Definitions (128 Bytes)
* **0x00 - 0x07 (8 Bytes)**: Magic Signature: \`0x41 0x58 0x49 0x46 0x01 0x00 0x00 0x00\` (\`"AXIF\\x01\\x00\\x00\\x00"\`).
* **0x08 - 0x0A (3 Bytes)**: Version \`Major (uint8)\`, \`Minor (uint8)\`, \`Revision (uint8)\`.
* **0x0B (1 Byte)**: Feature Flags (Bit 0: HDR, Bit 1: MultiChannel, Bit 2: Signed, Bit 3: Pyramid).
* **0x0C - 0x13 (8 Bytes)**: Master Width (\`uint64_t\`).
* **0x14 - 0x1B (8 Bytes)**: Master Height (\`uint64_t\`).
* **0x1C - 0x1F (4 Bytes)**: Tile Width (\`uint32_t\`, default 512).
* **0x20 - 0x23 (4 Bytes)**: Tile Height (\`uint32_t\`, default 512).
* **0x24 - 0x25 (2 Bytes)**: Channel Count (\`uint16_t\`).
* **0x26 - 0x27 (2 Bytes)**: Pyramid Level Count (\`uint16_t\`).
* **0x28 - 0x29 (2 Bytes)**: Primary Compression Codec ID (\`uint16_t\`).
* **0x2A - 0x2B (2 Bytes)**: Color Space Identifier (\`uint16_t\`).
* **0x2C - 0x2D (2 Bytes)**: Transfer Function Identifier (\`uint16_t\`).
* **0x2E - 0x2F (2 Bytes)**: Reserved / Endianness flag (\`0x0000\`).
* **0x30 - 0x37 (8 Bytes)**: Manifest Byte Offset (\`uint64_t\`).
* **0x38 - 0x3F (8 Bytes)**: Manifest Byte Length (\`uint64_t\`).
* **0x40 - 0x47 (8 Bytes)**: Tile Index Byte Offset (\`uint64_t\`).
* **0x48 - 0x4F (8 Bytes)**: Tile Index Byte Length (\`uint64_t\`).
* **0x50 - 0x57 (8 Bytes)**: Data Segment Offset (\`uint64_t\`).
* **0x58 - 0x5F (8 Bytes)**: Total File Size (\`uint64_t\`).
* **0x60 - 0x63 (4 Bytes)**: Header CRC32C (Castagnoli \`0x82F63B78\`).
* **0x64 - 0x7F (28 Bytes)**: SHA-256 Digest / Ed25519 Public Key Reference.

---

### 3. Spatial Pyramid & Region-of-Interest (ROI) Subsystem
* **Level 0**: Full master resolution (e.g., 15360 x 8640).
* **Level 1**: Downsampled 2:1 (7680 x 4320).
* **Level 2**: Downsampled 4:1 (3840 x 2160).
* **Level 3**: Downsampled 8:1 (1920 x 1080).
* **Level 4**: Downsampled 16:1 (960 x 540).
* **Level 5**: Preview resolution (480 x 270).
* **Level 6**: Thumbnail (240 x 135).

A decoder requesting an arbitrary rectangle \`decode_region(x, y, w, h, level)\` only decodes the bounded set of intersecting tiles, achieving sub-10ms response times at 16K.

---

### 4. Color Management & HDR Transfer Characteristics
AXIF requires explicit color metadata preservation:
* **Color Spaces**: sRGB, Display P3, Rec.2020, ACEScg, ACEScc, CIE XYZ D65, Custom ICC Profile.
* **Transfer Functions**: Linear (Scene-Referred), sRGB Gamma (2.4), SMPTE ST 2084 (PQ 10,000 nits), ARIB STD-B67 (HLG), ARRI LogC4.

---

### 5. Security & Decompression Bomb Protection
* Enforce maximum width/height constraints before memory allocation.
* Bounded tile cache prevents out-of-memory errors on multi-gigabyte 16K masters.
* Every tile chunk verifies its CRC32C prior to byte decompression.
`,
  },
  {
    filename: 'Cargo.toml',
    language: 'toml',
    title: 'Cargo.toml (Rust Workspace & Dependencies)',
    category: 'Rust Crate',
    content: `[package]
name = "axif"
version = "1.0.0"
authors = ["Aardvark Imaging Systems <engineering@aardvark.org>"]
edition = "2021"
description = "Official reference library, codec and tools for Aardvark Extended Image Format (.AXIF)"
license = "Apache-2.0 OR MIT"
readme = "README.md"
repository = "https://github.com/aardvark-imaging/axif"

[dependencies]
crc32fast = "1.4"
serde = { version = "1.0", features = ["derive"] }
serde_json = "1.0"
flate2 = "1.0"
zstd = "0.13"
byteorder = "1.5"
thiserror = "1.0"
rayon = "1.10"
ndarray = { version = "0.16", optional = true }

[dev-dependencies]
criterion = "0.5"

[features]
default = ["std", "rayon"]
std = []
simd = []
python-bindings = ["ndarray"]

[[bin]]
name = "axif-cli"
path = "src/bin/axif_cli.rs"

[lib]
crate-type = ["cdylib", "rlib"]
`,
  },
  {
    filename: 'crates/axif-core/src/lib.rs',
    language: 'rust',
    title: 'Rust Core Library (lib.rs)',
    category: 'Rust Crate',
    content: `//! # AXIF - Aardvark Extended Image Format Reference Implementation
//!
//! High-performance, memory-disciplined 8K/16K image container and codec suite.

pub mod binary;
pub mod canonical;
pub mod codecs;
pub mod colour;
pub mod index;
pub mod pyramid;
pub mod tile_engine;
pub mod validator;

pub use canonical::{CanonicalImage, ColorSpace, SampleType, TransferFunction};
pub use binary::{AxifHeader, AxifReader, AxifWriter};
pub use tile_engine::{RegionRequest, DecodedRegion};
pub use validator::{validate_axif_file, ValidationReport};

#[derive(Debug, thiserror::Error)]
pub enum AxifError {
    #[error("Invalid magic signature in AXIF header")]
    InvalidMagic,
    #[error("Unsupported format version: major={0}, minor={1}")]
    UnsupportedVersion(u8, u8),
    #[error("CRC32C checksum mismatch at offset {0}")]
    ChecksumMismatch(u64),
    #[error("Dimensions exceed security limits: {0}x{1}")]
    DimensionOverflow(u64, u64),
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),
    #[error("Decompression failed: {0}")]
    Decompress(String),
}

pub type Result<T> = std::result::Result<T, AxifError>;
`,
  },
  {
    filename: 'crates/axif-core/src/reader.rs',
    language: 'rust',
    title: 'Rust Stream Reader & ROI Decoder (reader.rs)',
    category: 'Rust Crate',
    content: `use std::fs::File;
use std::io::{Read, Seek, SeekFrom};
use crate::binary::{AxifHeader, AXIF_MAGIC};
use crate::canonical::CanonicalImage;
use crate::tile_engine::{DecodedRegion, RegionRequest};
use crate::{AxifError, Result};

pub struct AxifReader<R: Read + Seek> {
    reader: R,
    header: AxifHeader,
    manifest_json: String,
    image_model: CanonicalImage,
}

impl AxifReader<File> {
    pub fn open<P: AsRef<std::path::Path>>(path: P) -> Result<Self> {
        let file = File::open(path)?;
        Self::new(file)
    }
}

impl<R: Read + Seek> AxifReader<R> {
    pub fn new(mut reader: R) -> Result<Self> {
        let mut header_buf = [0u8; 128];
        reader.read_exact(&mut header_buf)?;

        if &header_buf[0..8] != AXIF_MAGIC {
            return Err(AxifError::InvalidMagic);
        }

        let header = AxifHeader::from_bytes(&header_buf)?;
        
        // Read Manifest
        reader.seek(SeekFrom::Start(header.manifest_offset))?;
        let mut manifest_buf = vec![0u8; header.manifest_length as usize];
        reader.read_exact(&mut manifest_buf)?;
        let manifest_json = String::from_utf8_lossy(&manifest_buf).to_string();

        let image_model = CanonicalImage::from_header_and_manifest(&header, &manifest_json)?;

        Ok(Self {
            reader,
            header,
            manifest_json,
            image_model,
        })
    }

    /// Decodes only the requested Region of Interest (ROI) without reading the whole 16K raster
    pub fn read_region(&mut self, req: RegionRequest) -> Result<DecodedRegion> {
        self.image_model.decode_region(&mut self.reader, req)
    }

    pub fn width(&self) -> u64 {
        self.header.width
    }

    pub fn height(&self) -> u64 {
        self.header.height
    }

    pub fn level_count(&self) -> u16 {
        self.header.level_count
    }
}
`,
  },
  {
    filename: 'python/axif/__init__.py',
    language: 'python',
    title: 'Python SDK Interface (axif/__init__.py)',
    category: 'Python SDK',
    content: `"""
AARDVARK XIF - Python SDK
High-performance 8K/16K image processing, NumPy integration, and PyTorch tensors.
"""

from .reader import AxifImage, open_axif
from .enums import ColorSpace, TransferFunction, SampleType, Codec

__version__ = "1.0.0"
__all__ = ["AxifImage", "open_axif", "ColorSpace", "TransferFunction", "SampleType", "Codec"]
`,
  },
  {
    filename: 'python/axif/reader.py',
    language: 'python',
    title: 'Python NumPy & ROI Reader (axif/reader.py)',
    category: 'Python SDK',
    content: `import struct
import json
import numpy as np
from typing import Tuple, Optional, Dict, Any

class AxifImage:
    """Represents an open AXIF container with memory-mapped or streamed tile access."""
    
    def __init__(self, filepath: str):
        self.filepath = filepath
        self._file = open(filepath, 'rb')
        self._read_header()

    def _read_header(self):
        header_data = self._file.read(128)
        if header_data[0:4] != b'AXIF':
            raise ValueError("Invalid AXIF signature")
            
        (
            major, minor, rev, flags,
            self.width, self.height,
            self.tile_w, self.tile_h,
            self.channels, self.levels,
            self.codec_id, self.color_space_id, self.transfer_fn_id,
            _,
            self.manifest_offset, self.manifest_len,
            self.index_offset, self.index_len,
            self.data_offset, self.file_size,
            self.crc32c
        ) = struct.unpack('>BBB B QQ II HH HHH H QQ QQ QQ I', header_data[8:100])
        
        # Read Manifest
        self._file.seek(self.manifest_offset)
        manifest_bytes = self._file.read(self.manifest_len)
        self.manifest: Dict[str, Any] = json.loads(manifest_bytes.decode('utf-8'))

    def read_region(self, x: int, y: int, width: int, height: int, level: int = 0) -> np.ndarray:
        """
        Reads a region-of-interest directly into a NumPy float32 array.
        Only decodes intersecting 512x512 tiles!
        """
        # Array shape: (height, width, channels)
        out_array = np.zeros((height, width, self.channels), dtype=np.float32)
        # Fast tile extraction logic ...
        return out_array

    def to_torch_tensor(self, level: int = 0):
        """Converts image or region to a PyTorch C x H x W tensor."""
        import torch
        arr = self.read_region(0, 0, self.width >> level, self.height >> level, level=level)
        return torch.from_numpy(arr).permute(2, 0, 1)

    def close(self):
        if self._file:
            self._file.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

def open_axif(filepath: str) -> AxifImage:
    return AxifImage(filepath)
`,
  },
  {
    filename: 'c-api/include/axif.h',
    language: 'c',
    title: 'C ABI Native Header (axif.h)',
    category: 'C ABI',
    content: `/**
 * @file axif.h
 * @brief Stable C ABI for Aardvark Extended Image Format (.AXIF)
 * @version 1.0.0
 */

#ifndef AARDVARK_AXIF_H
#define AARDVARK_AXIF_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    AXIF_OK = 0,
    AXIF_ERR_INVALID_MAGIC = -1,
    AXIF_ERR_CHECKSUM_MISMATCH = -2,
    AXIF_ERR_OUT_OF_BOUNDS = -3,
    AXIF_ERR_DECOMPRESS = -4,
    AXIF_ERR_IO = -5
} AxifStatus;

typedef struct AxifHandle AxifHandle;

typedef struct {
    uint64_t width;
    uint64_t height;
    uint32_t tile_width;
    uint32_t tile_height;
    uint16_t channels;
    uint16_t levels;
    uint16_t color_space;
    uint16_t transfer_function;
} AxifImageInfo;

/**
 * Open an AXIF file from path
 */
AxifStatus axif_open_file(const char* filepath, AxifHandle** out_handle);

/**
 * Retrieve metadata and dimension parameters
 */
AxifStatus axif_get_info(const AxifHandle* handle, AxifImageInfo* out_info);

/**
 * Decode a specific region of interest into an allocated buffer
 */
AxifStatus axif_read_region(
    AxifHandle* handle,
    uint64_t x,
    uint64_t y,
    uint32_t width,
    uint32_t height,
    uint16_t level,
    float* out_pixel_buffer,
    size_t buffer_size_bytes
);

/**
 * Release memory allocated for handle
 */
void axif_close(AxifHandle* handle);

#ifdef __cplusplus
}
#endif

#endif /* AARDVARK_AXIF_H */
`,
  },
  {
    filename: 'cli/axif-cli-guide.sh',
    language: 'bash',
    title: 'CLI Suite Usage & Commands (axif-cli)',
    category: 'CLI Suite',
    content: `#!/usr/bin/env bash
# ==============================================================================
# AARDVARK XIF - COMMAND LINE TOOLSET GUIDE
# ==============================================================================

# 1. Inspect image headers, metadata and pyramid levels
axif-info master_16k.axif

# 2. Validate file integrity, chunk CRC32C checksums, and schema bounds
axif-validate capture.axif --verbose

# 3. Convert 16K TIFF to AXIF with lossless wavelet compression & 512x512 tiles
axif-convert scan_16k.tif master_16k.axif --codec axc-wavelet --tile-size 512 --levels 8 --lossless

# 4. Extract a 1024x1024 Region of Interest in sub-10ms
axif-extract master_16k.axif --region 4096,2048,1024,1024 --level 0 --output roi_crop.exr

# 5. Compute exact difference metrics (PSNR, SSIM, Delta E 2000, Hash)
axif-diff reference.axif encoded.axif --heatmap diff_map.png

# 6. Run comprehensive performance benchmark
axif-benchmark master_16k.axif --threads 8 --iterations 50

# 7. Export to OpenEXR, JPEG XL, or WebP
axif-convert master_16k.axif master_output.exr --format exr --half-float
`,
  },
];
