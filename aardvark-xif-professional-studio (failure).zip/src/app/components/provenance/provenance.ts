import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AxifStateService } from '../../services/axif-state.service';

@Component({
  selector: 'app-provenance',
  imports: [CommonModule, MatIconModule],
  templateUrl: './provenance.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ProvenanceComponent {
  public state = inject(AxifStateService);
}
