import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AxifStateService, ActiveTab } from '../../services/axif-state.service';

@Component({
  selector: 'app-header',
  imports: [CommonModule, MatIconModule],
  templateUrl: './header.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HeaderComponent {
  public state = inject(AxifStateService);

  public tabs: { id: ActiveTab; label: string; icon: string }[] = [
    { id: 'viewer', label: '16K Viewport', icon: 'zoom_in' },
    { id: 'scopes', label: 'Scopes & HDR', icon: 'equalizer' },
    { id: 'forensics', label: 'Binary Forensics', icon: 'data_object' },
    { id: 'converter', label: 'Interop & Diff', icon: 'compare' },
    { id: 'benchmark', label: 'Benchmark & CLI', icon: 'speed' },
    { id: 'provenance', label: 'Provenance Graph', icon: 'account_tree' },
    { id: 'sdk', label: 'Specification & SDK', icon: 'terminal' },
  ];

  public onPresetChange(event: Event): void {
    const select = event.target as HTMLSelectElement;
    this.state.selectPreset(select.value);
  }
}
