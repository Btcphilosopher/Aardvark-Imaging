import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AxifStateService } from '../../services/axif-state.service';
import { CompressionCodec } from '../../core/canonical-image';

@Component({
  selector: 'app-converter',
  imports: [CommonModule, MatIconModule],
  templateUrl: './converter.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ConverterComponent {
  public state = inject(AxifStateService);

  public selectedSourceFormat = signal<string>('TIFF');
  public selectedTargetCodec = signal<CompressionCodec>(CompressionCodec.AXC_LOSSLESS);
  public selectedTileSize = signal<number>(512);
  public isConverting = signal<boolean>(false);
  public conversionSuccess = signal<string | null>(null);

  public sourceFormats = [
    { id: 'TIFF', name: '16-bit Uncompressed TIFF (1.06 GB)' },
    { id: 'EXR', name: 'OpenEXR Half-Float Multi-Channel (550 MB)' },
    { id: 'JXL', name: 'JPEG XL Lossless (328 MB)' },
    { id: 'PNG', name: '16-bit PNG (620 MB)' },
    { id: 'DNG', name: 'Camera RAW DNG 16K (880 MB)' },
  ];

  public onSliderChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.splitPosition.set(val);
  }

  public runConversion(): void {
    this.isConverting.set(true);
    this.conversionSuccess.set(null);

    setTimeout(() => {
      this.isConverting.set(false);
      this.conversionSuccess.set(
        `SUCCESS: Converted ${this.selectedSourceFormat()} to AXIF with ${this.selectedTargetCodec()} (512x512 tiles, 8 pyramid levels). PSNR: 100.0 dB (Lossless bit-exact match).`
      );
      this.state.refreshImageState();
    }, 1200);
  }
}
