import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AxifStateService } from '../../services/axif-state.service';

@Component({
  selector: 'app-benchmark',
  imports: [CommonModule, MatIconModule],
  templateUrl: './benchmark.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BenchmarkComponent {
  public state = inject(AxifStateService);
  public currentCommand = signal<string>('');

  public quickCommands = [
    'axif-info master_16k.axif',
    'axif-validate master_16k.axif',
    'axif-extract --region 4096,2048,1024,1024',
    'axif-diff master_16k.axif target.exr',
    'axif-benchmark',
    'help',
  ];

  public runCommand(cmd: string): void {
    this.state.executeCliCommand(cmd);
    this.currentCommand.set('');
  }

  public onSubmit(event: Event): void {
    event.preventDefault();
    if (this.currentCommand()) {
      this.runCommand(this.currentCommand());
    }
  }
}
