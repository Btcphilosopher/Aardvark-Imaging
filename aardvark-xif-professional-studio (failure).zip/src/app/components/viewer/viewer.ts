import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  ViewChild,
  inject,
  signal,
  effect,
  AfterViewInit,
  OnDestroy,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AxifStateService } from '../../services/axif-state.service';
import { ColourScienceEngine } from '../../core/colour-science';
import { ColorSpace, TransferFunction } from '../../core/canonical-image';

@Component({
  selector: 'app-viewer',
  imports: [CommonModule, MatIconModule],
  templateUrl: './viewer.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ViewerComponent implements AfterViewInit, OnDestroy {
  public state = inject(AxifStateService);

  @ViewChild('viewportCanvas', { static: false }) canvasRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('containerRef', { static: false }) containerRef!: ElementRef<HTMLDivElement>;

  public isDragging = false;
  public dragStartX = 0;
  public dragStartY = 0;
  public lastPanX = 0;
  public lastPanY = 0;

  public isRoiMode = signal<boolean>(false);
  public isSelectingRoi = false;
  public roiStart = { x: 0, y: 0 };
  public roiCurrent = { x: 0, y: 0 };
  public selectedRoiBox = signal<{ x: number; y: number; w: number; h: number; latencyMs: number } | null>(null);

  public renderStats = signal<{
    fps: number;
    tilesDrawn: number;
    viewportPixels: string;
    levelUsed: number;
    decodeLatencyMs: number;
  }>({
    fps: 60,
    tilesDrawn: 4,
    viewportPixels: '1920x1080',
    levelUsed: 0,
    decodeLatencyMs: 3.2,
  });

  private animationFrameId: number | null = null;
  private resizeObserver: ResizeObserver | null = null;

  constructor() {
    effect(() => {
      // Re-render when image, level, zoom, pan, channel, or false color changes
      const img = this.state.activeImage();
      const zoom = this.state.zoomLevel();
      const panX = this.state.panX();
      const panY = this.state.panY();
      const level = this.state.selectedPyramidLevel();
      const ch = this.state.activeChannelView();
      const fc = this.state.isFalseColorEnabled();
      const cs = this.state.activeDisplayColorSpace();
      this.scheduleRender();
    });
  }

  ngAfterViewInit(): void {
    if (this.containerRef?.nativeElement) {
      this.resizeObserver = new ResizeObserver(() => {
        this.resizeCanvas();
        this.scheduleRender();
      });
      this.resizeObserver.observe(this.containerRef.nativeElement);
    }
    this.fitToScreen();
    this.resizeCanvas();
    this.scheduleRender();
  }

  ngOnDestroy(): void {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
    this.resizeObserver?.disconnect();
  }

  public resizeCanvas(): void {
    const canvas = this.canvasRef?.nativeElement;
    const container = this.containerRef?.nativeElement;
    if (!canvas || !container) return;

    const rect = container.getBoundingClientRect();
    if (rect.width > 0 && rect.height > 0) {
      canvas.width = Math.floor(rect.width);
      canvas.height = Math.floor(rect.height);
    }
  }

  public scheduleRender(): void {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
    this.animationFrameId = requestAnimationFrame(() => {
      this.render();
    });
  }

  public render(): void {
    const canvas = this.canvasRef?.nativeElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    const startTime = performance.now();
    const img = this.state.activeImage();
    const zoom = this.state.zoomLevel();
    const panX = this.state.panX();
    const panY = this.state.panY();
    const selectedLevel = this.state.selectedPyramidLevel();
    const channelView = this.state.activeChannelView();
    const isFalseColor = this.state.isFalseColorEnabled();
    const targetColorSpace = this.state.activeDisplayColorSpace();

    const cW = canvas.width;
    const cH = canvas.height;

    // Clear background
    ctx.fillStyle = '#080808';
    ctx.fillRect(0, 0, cW, cH);

    // Calculate source rect in Level 0 pixels
    const viewWInImage = cW / zoom;
    const viewHInImage = cH / zoom;
    const srcX = Math.floor(img.width / 2 - panX - viewWInImage / 2);
    const srcY = Math.floor(img.height / 2 - panY - viewHInImage / 2);

    // Pick optimal pyramid level based on zoom if level is automatic, or use selectedLevel
    const levelInfo = img.getLevelInfo(selectedLevel);
    const scale = levelInfo.scaleFactor;

    // Request region from canonical image model
    const levelSrcX = Math.floor(srcX / scale);
    const levelSrcY = Math.floor(srcY / scale);
    const levelSrcW = Math.ceil(viewWInImage / scale);
    const levelSrcH = Math.ceil(viewHInImage / scale);

    const decodedRegion = img.readRegion({
      x: Math.max(0, levelSrcX),
      y: Math.max(0, levelSrcY),
      width: Math.min(levelInfo.width, levelSrcW + 2),
      height: Math.min(levelInfo.height, levelSrcH + 2),
      level: selectedLevel,
    });

    if (decodedRegion.width > 0 && decodedRegion.height > 0) {
      // Create ImageData for the decoded viewport
      const imgData = ctx.createImageData(decodedRegion.width, decodedRegion.height);
      const data32 = new Uint32Array(imgData.data.buffer);
      const rawData = decodedRegion.data;
      const totalPixels = decodedRegion.width * decodedRegion.height;

      for (let i = 0; i < totalPixels; i++) {
        const rawIdx = i * 4;
        let r = rawData[rawIdx];
        let g = rawData[rawIdx + 1];
        let b = rawData[rawIdx + 2];
        let a = rawData[rawIdx + 3];

        // Channel isolation
        if (channelView === 'R') {
          g = r;
          b = r;
        } else if (channelView === 'G') {
          r = g;
          b = g;
        } else if (channelView === 'B') {
          r = b;
          g = b;
        } else if (channelView === 'DEPTH') {
          const depthVal = (r + g + b) / 3;
          r = depthVal;
          g = depthVal * 0.8;
          b = 1.0 - depthVal;
        }

        // Color Space Transformation
        if (img.colorSpace !== targetColorSpace) {
          const transformed = ColourScienceEngine.transformColorSpace([r, g, b], img.colorSpace, targetColorSpace);
          r = transformed[0];
          g = transformed[1];
          b = transformed[2];
        }

        // False Color Exposure Mode
        if (isFalseColor) {
          const fc = ColourScienceEngine.getFalseColorPixel(r, g, b);
          r = fc[0];
          g = fc[1];
          b = fc[2];
        }

        const u8R = Math.max(0, Math.min(255, Math.floor(r * 255)));
        const u8G = Math.max(0, Math.min(255, Math.floor(g * 255)));
        const u8B = Math.max(0, Math.min(255, Math.floor(b * 255)));
        const u8A = Math.max(0, Math.min(255, Math.floor(a * 255)));

        // Little-endian ABGR representation
        data32[i] = (u8A << 24) | (u8B << 16) | (u8G << 8) | u8R;
      }

      // Draw decoded region onto temporary offscreen canvas and scale to viewport
      const offscreen = document.createElement('canvas');
      offscreen.width = decodedRegion.width;
      offscreen.height = decodedRegion.height;
      const offCtx = offscreen.getContext('2d');
      if (offCtx) {
        offCtx.putImageData(imgData, 0, 0);

        ctx.imageSmoothingEnabled = zoom < 2.0; // Pixelate when deep zoomed past 200%
        const destX = (decodedRegion.x * scale - srcX) * zoom;
        const destY = (decodedRegion.y * scale - srcY) * zoom;
        const destW = decodedRegion.width * scale * zoom;
        const destH = decodedRegion.height * scale * zoom;

        ctx.drawImage(offscreen, destX, destY, destW, destH);
      }
    }

    // Draw Tile Grid Boundaries
    if (this.state.showTileGrid()) {
      ctx.strokeStyle = 'rgba(6, 182, 212, 0.4)'; // Cyan border
      ctx.lineWidth = 1;
      ctx.fillStyle = 'rgba(6, 182, 212, 0.8)';
      ctx.font = '10px "Fira Code", monospace';

      const tilePxInView = img.tileWidth * scale * zoom;
      const minTx = Math.floor(Math.max(0, srcX) / (img.tileWidth * scale));
      const maxTx = Math.floor(Math.min(img.width, srcX + viewWInImage) / (img.tileWidth * scale));
      const minTy = Math.floor(Math.max(0, srcY) / (img.tileHeight * scale));
      const maxTy = Math.floor(Math.min(img.height, srcY + viewHInImage) / (img.tileHeight * scale));

      for (let ty = minTy; ty <= maxTy; ty++) {
        for (let tx = minTx; tx <= maxTx; tx++) {
          const tScreenX = (tx * img.tileWidth * scale - srcX) * zoom;
          const tScreenY = (ty * img.tileHeight * scale - srcY) * zoom;

          ctx.strokeRect(tScreenX, tScreenY, tilePxInView, tilePxInView);
          ctx.fillText(`L${selectedLevel}:T[${tx},${ty}]`, tScreenX + 6, tScreenY + 14);
        }
      }
    }

    // Draw Selected ROI Box
    const roi = this.selectedRoiBox();
    if (roi) {
      const roiScreenX = (roi.x - srcX) * zoom;
      const roiScreenY = (roi.y - srcY) * zoom;
      const roiScreenW = roi.w * zoom;
      const roiScreenH = roi.h * zoom;

      ctx.strokeStyle = '#10b981'; // Emerald
      ctx.lineWidth = 2;
      ctx.setLineDash([4, 4]);
      ctx.strokeRect(roiScreenX, roiScreenY, roiScreenW, roiScreenH);
      ctx.setLineDash([]);

      ctx.fillStyle = '#10b981';
      ctx.fillRect(roiScreenX, roiScreenY - 20, 160, 20);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 11px sans-serif';
      ctx.fillText(`ROI ${roi.w}x${roi.h} (${roi.latencyMs.toFixed(1)}ms)`, roiScreenX + 4, roiScreenY - 6);
    }

    const elapsed = performance.now() - startTime;
    this.renderStats.set({
      fps: Math.round(1000 / Math.max(16, elapsed)),
      tilesDrawn: decodedRegion.tilesAccessed,
      viewportPixels: `${cW}x${cH}`,
      levelUsed: selectedLevel,
      decodeLatencyMs: Math.round((decodedRegion.decodeTimeMs + elapsed) * 10) / 10,
    });
  }

  // Zoom & Pan Handlers
  public setZoom(zoom: number): void {
    this.state.zoomLevel.set(Math.max(0.05, Math.min(32.0, zoom)));
  }

  public zoomIn(): void {
    this.setZoom(this.state.zoomLevel() * 1.5);
  }

  public zoomOut(): void {
    this.setZoom(this.state.zoomLevel() / 1.5);
  }

  public setActualPixels(): void {
    this.setZoom(1.0);
  }

  public fitToScreen(): void {
    const canvas = this.canvasRef?.nativeElement || { width: 1200, height: 700 };
    const img = this.state.activeImage();
    const scaleX = canvas.width / img.width;
    const scaleY = canvas.height / img.height;
    const fitZoom = Math.min(scaleX, scaleY) * 0.95;
    this.state.panX.set(0);
    this.state.panY.set(0);
    this.setZoom(fitZoom);
  }

  public onMouseDown(event: MouseEvent): void {
    if (this.isRoiMode()) {
      this.isSelectingRoi = true;
      this.roiStart = { x: event.offsetX, y: event.offsetY };
      this.roiCurrent = { x: event.offsetX, y: event.offsetY };
      return;
    }

    this.isDragging = true;
    this.dragStartX = event.clientX;
    this.dragStartY = event.clientY;
    this.lastPanX = this.state.panX();
    this.lastPanY = this.state.panY();
  }

  public onMouseMove(event: MouseEvent): void {
    const canvas = this.canvasRef?.nativeElement;
    if (!canvas) return;

    const img = this.state.activeImage();
    const zoom = this.state.zoomLevel();
    const panX = this.state.panX();
    const panY = this.state.panY();

    const viewWInImage = canvas.width / zoom;
    const viewHInImage = canvas.height / zoom;
    const srcX = Math.floor(img.width / 2 - panX - viewWInImage / 2);
    const srcY = Math.floor(img.height / 2 - panY - viewHInImage / 2);

    const imgPixelX = Math.max(0, Math.min(img.width - 1, Math.floor(srcX + event.offsetX / zoom)));
    const imgPixelY = Math.max(0, Math.min(img.height - 1, Math.floor(srcY + event.offsetY / zoom)));

    // Update Loupe Inspector
    const tileX = Math.floor(imgPixelX / img.tileWidth);
    const tileY = Math.floor(imgPixelY / img.tileHeight);

    // Read single pixel
    const pxRegion = img.readRegion({ x: imgPixelX, y: imgPixelY, width: 1, height: 1, level: 0 });
    const r = pxRegion.data[0] || 0;
    const g = pxRegion.data[1] || 0;
    const b = pxRegion.data[2] || 0;
    const a = pxRegion.data[3] || 1;
    const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;

    this.state.hoveredPixel.set({
      x: imgPixelX,
      y: imgPixelY,
      r: Math.round(r * 1000) / 1000,
      g: Math.round(g * 1000) / 1000,
      b: Math.round(b * 1000) / 1000,
      a: Math.round(a * 100) / 100,
      nits: Math.round(lum * 10000),
      tileCoord: `T[${tileX}, ${tileY}]`,
      depth: 1.25,
      spectral: 0.88,
    });

    if (this.isSelectingRoi) {
      this.roiCurrent = { x: event.offsetX, y: event.offsetY };
      this.scheduleRender();
      return;
    }

    if (this.isDragging) {
      const dx = (event.clientX - this.dragStartX) / zoom;
      const dy = (event.clientY - this.dragStartY) / zoom;
      this.state.panX.set(this.lastPanX + dx);
      this.state.panY.set(this.lastPanY + dy);
    }
  }

  public onMouseUp(event: MouseEvent): void {
    if (this.isSelectingRoi) {
      this.isSelectingRoi = false;
      const canvas = this.canvasRef?.nativeElement;
      if (!canvas) return;

      const zoom = this.state.zoomLevel();
      const panX = this.state.panX();
      const panY = this.state.panY();
      const img = this.state.activeImage();

      const viewWInImage = canvas.width / zoom;
      const viewHInImage = canvas.height / zoom;
      const srcX = Math.floor(img.width / 2 - panX - viewWInImage / 2);
      const srcY = Math.floor(img.height / 2 - panY - viewHInImage / 2);

      const minX = Math.min(this.roiStart.x, this.roiCurrent.x);
      const maxX = Math.max(this.roiStart.x, this.roiCurrent.x);
      const minY = Math.min(this.roiStart.y, this.roiCurrent.y);
      const maxY = Math.max(this.roiStart.y, this.roiCurrent.y);

      const roiW = Math.max(32, Math.floor((maxX - minX) / zoom));
      const roiH = Math.max(32, Math.floor((maxY - minY) / zoom));
      const roiX = Math.floor(srcX + minX / zoom);
      const roiY = Math.floor(srcY + minY / zoom);

      const t0 = performance.now();
      img.readRegion({ x: roiX, y: roiY, width: roiW, height: roiH, level: 0 });
      const lat = performance.now() - t0;

      this.selectedRoiBox.set({
        x: roiX,
        y: roiY,
        w: roiW,
        h: roiH,
        latencyMs: lat,
      });

      this.scheduleRender();
      return;
    }
    this.isDragging = false;
  }

  public onWheel(event: WheelEvent): void {
    event.preventDefault();
    const factor = event.deltaY < 0 ? 1.15 : 0.85;
    this.setZoom(this.state.zoomLevel() * factor);
  }
}
