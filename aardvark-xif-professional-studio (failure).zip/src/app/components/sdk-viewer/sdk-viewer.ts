import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AXIF_SDK_FILES, SdkFileItem } from '../../core/sdk-code-files';

@Component({
  selector: 'app-sdk-viewer',
  imports: [CommonModule, MatIconModule],
  templateUrl: './sdk-viewer.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SdkViewerComponent {
  public files = signal<SdkFileItem[]>(AXIF_SDK_FILES);
  public selectedFile = signal<SdkFileItem>(AXIF_SDK_FILES[0]);
  public copyMessage = signal<string | null>(null);

  public selectFile(file: SdkFileItem): void {
    this.selectedFile.set(file);
    this.copyMessage.set(null);
  }

  public copyCode(): void {
    navigator.clipboard.writeText(this.selectedFile().content).then(() => {
      this.copyMessage.set('Copied to clipboard!');
      setTimeout(() => this.copyMessage.set(null), 2000);
    });
  }

  public downloadFile(): void {
    const file = this.selectedFile();
    const blob = new Blob([file.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = file.filename.split('/').pop() || 'file.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
}
