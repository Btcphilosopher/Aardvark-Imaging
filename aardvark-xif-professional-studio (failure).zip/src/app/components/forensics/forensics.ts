import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AxifStateService } from '../../services/axif-state.service';
import { AxifBinaryChunkInspection } from '../../core/axif-binary';

@Component({
  selector: 'app-forensics',
  imports: [CommonModule, MatIconModule],
  templateUrl: './forensics.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ForensicsComponent {
  public state = inject(AxifStateService);

  public selectedChunk = signal<AxifBinaryChunkInspection | null>(null);
  public isRepairSimulated = signal<boolean>(false);
  public repairStatusMessage = signal<string | null>(null);

  constructor() {
    // Select first chunk by default
    const rep = this.state.validationReport();
    if (rep && rep.chunks.length > 0) {
      this.selectedChunk.set(rep.chunks[0]);
    }
  }

  public selectChunk(chunk: AxifBinaryChunkInspection): void {
    this.selectedChunk.set(chunk);
  }

  public simulateTamperingAndRepair(): void {
    this.isRepairSimulated.set(true);
    this.repairStatusMessage.set('Simulating index truncation & corrupt tile CRC32C...');

    setTimeout(() => {
      this.repairStatusMessage.set('Running axif-repair: scanning stream for AXIF_CHUNK markers...');
    }, 800);

    setTimeout(() => {
      this.repairStatusMessage.set('SUCCESS: Reconstructed tile index table (510 tiles recovered), verified CRC32C, sealed container.');
      this.isRepairSimulated.set(false);
      this.state.refreshImageState();
    }, 2000);
  }
}
