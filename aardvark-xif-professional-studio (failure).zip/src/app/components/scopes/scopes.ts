import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  ViewChild,
  inject,
  AfterViewInit,
  effect,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AxifStateService } from '../../services/axif-state.service';
import { ColorSpace, TransferFunction } from '../../core/canonical-image';
import { ScopeData } from '../../core/colour-science';

@Component({
  selector: 'app-scopes',
  imports: [CommonModule, MatIconModule],
  templateUrl: './scopes.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ScopesComponent implements AfterViewInit {
  public state = inject(AxifStateService);

  @ViewChild('histogramCanvas', { static: false }) histogramCanvasRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('waveformCanvas', { static: false }) waveformCanvasRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('paradeCanvas', { static: false }) paradeCanvasRef!: ElementRef<HTMLCanvasElement>;

  public colorSpaces = [
    { id: ColorSpace.SRGB, name: 'sRGB (Rec.709)', gamutPct: '100% sRGB / 35.9% CIE' },
    { id: ColorSpace.DISPLAY_P3, name: 'Display P3', gamutPct: '125% sRGB / 45.5% CIE' },
    { id: ColorSpace.REC2020, name: 'Rec.2020 UHD', gamutPct: '150% sRGB / 75.8% CIE' },
    { id: ColorSpace.ACESCG, name: 'ACEScg Cinema Gamut', gamutPct: 'Cinema Master / 90.2% CIE' },
  ];

  public transferFunctions = [
    { id: TransferFunction.LINEAR, name: 'Scene-Referred Linear (1.0)' },
    { id: TransferFunction.SRGB, name: 'sRGB Piecewise Gamma (2.4)' },
    { id: TransferFunction.PQ_ST2084, name: 'SMPTE ST 2084 PQ (10,000 Nits HDR)' },
    { id: TransferFunction.HLG_BT2100, name: 'ARIB STD-B67 (Hybrid Log-Gamma)' },
    { id: TransferFunction.LOG_C, name: 'ARRI LogC4 Cinema Profile' },
  ];

  constructor() {
    effect(() => {
      const scopes = this.state.currentScopes();
      const isLog = this.state.isLogHistogram();
      this.drawScopes();
    });
  }

  ngAfterViewInit(): void {
    this.drawScopes();
  }

  public toggleLogHistogram(): void {
    this.state.isLogHistogram.set(!this.state.isLogHistogram());
    this.state.refreshImageState();
  }

  public drawScopes(): void {
    const scopes = this.state.currentScopes();
    if (!scopes) return;

    this.drawHistogram(scopes);
    this.drawWaveform(scopes);
    this.drawParade(scopes);
  }

  private drawHistogram(scopes: ScopeData): void {
    const canvas = this.histogramCanvasRef?.nativeElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.fillStyle = '#0a0a0a';
    ctx.fillRect(0, 0, w, h);

    // Grid lines
    ctx.strokeStyle = '#262626';
    ctx.lineWidth = 1;
    for (let i = 1; i < 4; i++) {
      const x = (w / 4) * i;
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }

    const maxVal = Math.max(...scopes.histogram.r, ...scopes.histogram.g, ...scopes.histogram.b, 1);

    // Draw Red
    ctx.strokeStyle = 'rgba(239, 68, 68, 0.8)';
    ctx.beginPath();
    for (let i = 0; i < scopes.histogram.r.length; i++) {
      const x = (i / scopes.histogram.r.length) * w;
      const y = h - (scopes.histogram.r[i] / maxVal) * (h - 10);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // Draw Green
    ctx.strokeStyle = 'rgba(34, 197, 94, 0.8)';
    ctx.beginPath();
    for (let i = 0; i < scopes.histogram.g.length; i++) {
      const x = (i / scopes.histogram.g.length) * w;
      const y = h - (scopes.histogram.g[i] / maxVal) * (h - 10);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // Draw Blue
    ctx.strokeStyle = 'rgba(59, 130, 246, 0.8)';
    ctx.beginPath();
    for (let i = 0; i < scopes.histogram.b.length; i++) {
      const x = (i / scopes.histogram.b.length) * w;
      const y = h - (scopes.histogram.b[i] / maxVal) * (h - 10);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
  }

  private drawWaveform(scopes: ScopeData): void {
    const canvas = this.waveformCanvasRef?.nativeElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.fillStyle = '#0a0a0a';
    ctx.fillRect(0, 0, w, h);

    // IRE Grids (0%, 25%, 50%, 75%, 100%)
    ctx.strokeStyle = '#262626';
    ctx.font = '9px monospace';
    ctx.fillStyle = '#737373';
    for (let ire = 0; ire <= 100; ire += 25) {
      const y = h - (ire / 100) * (h - 16) - 8;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
      ctx.fillText(`${ire} IRE`, 4, y - 2);
    }

    // Render waveform grid if present
    const wf = scopes.waveform;
    const wfW = scopes.waveformWidth;
    const wfH = scopes.waveformHeight;
    if (wf && wfW > 0 && wfH > 0) {
      const imgData = ctx.createImageData(w, h);
      const data32 = new Uint32Array(imgData.data.buffer);

      for (let y = 0; y < h; y++) {
        const srcY = Math.floor((y / h) * wfH);
        for (let x = 0; x < w; x++) {
          const srcX = Math.floor((x / w) * wfW);
          const intensity = wf[srcY * wfW + srcX];
          if (intensity > 0) {
            const alpha = Math.min(255, intensity * 2);
            // Cyan colored point
            data32[y * w + x] = (alpha << 24) | (248 << 16) | (189 << 8) | 56;
          }
        }
      }
      ctx.putImageData(imgData, 0, 0);
    }
  }

  private drawParade(scopes: ScopeData): void {
    const canvas = this.paradeCanvasRef?.nativeElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.fillStyle = '#0a0a0a';
    ctx.fillRect(0, 0, w, h);

    const sectionW = Math.floor(w / 3);
    const p = scopes.rgbParade;
    if (!p) return;

    // Draw Dividers
    ctx.strokeStyle = '#3f3f46';
    ctx.beginPath();
    ctx.moveTo(sectionW, 0);
    ctx.lineTo(sectionW, h);
    ctx.moveTo(sectionW * 2, 0);
    ctx.lineTo(sectionW * 2, h);
    ctx.stroke();

    const imgData = ctx.createImageData(w, h);
    const data32 = new Uint32Array(imgData.data.buffer);

    for (let y = 0; y < h; y++) {
      const srcY = Math.floor((y / h) * p.height);
      for (let x = 0; x < w; x++) {
        const sec = Math.floor(x / sectionW);
        const relX = x - sec * sectionW;
        const srcX = Math.floor((relX / sectionW) * p.width);
        const srcIdx = srcY * p.width + srcX;

        if (sec === 0) {
          // Red
          const intR = p.r[srcIdx];
          if (intR > 0) {
            data32[y * w + x] = (Math.min(255, intR * 2) << 24) | (68 << 16) | (68 << 8) | 239;
          }
        } else if (sec === 1) {
          // Green
          const intG = p.g[srcIdx];
          if (intG > 0) {
            data32[y * w + x] = (Math.min(255, intG * 2) << 24) | (94 << 16) | (197 << 8) | 34;
          }
        } else if (sec === 2) {
          // Blue
          const intB = p.b[srcIdx];
          if (intB > 0) {
            data32[y * w + x] = (Math.min(255, intB * 2) << 24) | (246 << 16) | (130 << 8) | 59;
          }
        }
      }
    }

    ctx.putImageData(imgData, 0, 0);
  }
}
