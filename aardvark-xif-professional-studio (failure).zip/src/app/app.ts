import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './components/header/header';
import { ViewerComponent } from './components/viewer/viewer';
import { ScopesComponent } from './components/scopes/scopes';
import { ForensicsComponent } from './components/forensics/forensics';
import { ConverterComponent } from './components/converter/converter';
import { BenchmarkComponent } from './components/benchmark/benchmark';
import { ProvenanceComponent } from './components/provenance/provenance';
import { SdkViewerComponent } from './components/sdk-viewer/sdk-viewer';
import { AxifStateService } from './services/axif-state.service';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    CommonModule,
    HeaderComponent,
    ViewerComponent,
    ScopesComponent,
    ForensicsComponent,
    ConverterComponent,
    BenchmarkComponent,
    ProvenanceComponent,
    SdkViewerComponent,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  public state = inject(AxifStateService);
}
