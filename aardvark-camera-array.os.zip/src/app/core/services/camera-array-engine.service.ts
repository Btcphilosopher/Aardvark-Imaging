import { Injectable, computed, signal } from '@angular/core';
import {
  ArrayHealthReport,
  CameraArrayScene,
  CameraId,
  CameraModule,
  OpticalPipelineStage,
  PixelProbeData,
  SynchronizedFrameSet,
  SyncState,
  VirtualApertureConfig,
  FusionWeightsConfig,
} from '../models/camera-array.model';

@Injectable({
  providedIn: 'root',
})
export class CameraArrayEngineService {
  // Available High-Fidelity Test Scenes
  readonly availableScenes: CameraArrayScene[] = [
    {
      id: 'scene.optical_bench',
      name: 'Optical Calibration Bench (ISO 12233 & ChArUco)',
      description: 'Controlled laboratory setup with resolving targets, color chart, and depth steps.',
      imagePath: '/assets/aistudio/optical_lab_test_scene.png',
      focalObjectDistanceM: 0.85,
      sceneDepthRangeM: [0.35, 3.2],
      illuminanceLux: 1200,
      colorTemperatureK: 5500,
    },
    {
      id: 'scene.architectural_depth',
      name: 'Architectural Geometric Depth & Perspective',
      description: 'Multi-plane architectural geometry with structured depth planes and fine lines.',
      imagePath: '/assets/aistudio/architectural_depth_scene.png',
      focalObjectDistanceM: 1.8,
      sceneDepthRangeM: [0.8, 15.0],
      illuminanceLux: 4500,
      colorTemperatureK: 6200,
    },
    {
      id: 'scene.botanical_hdr',
      name: 'Botanical HDR Specular Highlights & Bokeh',
      description: 'Organic textures, fine foliage edges, and high-dynamic-range sunlight bokeh.',
      imagePath: '/assets/aistudio/botanical_hdr_scene.png',
      focalObjectDistanceM: 0.55,
      sceneDepthRangeM: [0.25, 4.5],
      illuminanceLux: 8500,
      colorTemperatureK: 5800,
    },
  ];

  // Active scene selection
  readonly activeScene = signal<CameraArrayScene>(this.availableScenes[0]);

  // Physical Camera Array Topology (4-Camera Smartphone System)
  readonly cameras = signal<CameraModule[]>([
    {
      id: 'camera.main',
      name: 'Camera 0 (Main Wide 1X)',
      role: 'MAIN_WIDE',
      isActive: true,
      lens: {
        focalLengthMm: 6.8,
        focalLength35mmEq: 24.0,
        fNumber: 1.6,
        entrancePupilMm: 4.25,
        fieldOfViewDeg: { horizontal: 73.7, vertical: 53.1, diagonal: 84.1 },
        opticalCenterOffsetPx: [0.0, 0.0],
        elementCount: 7,
      },
      sensor: {
        model: 'Sony IMX989 Type 1.0" Quad-Bayer',
        sensorFormat: '1.0-inch',
        resolutionPx: [8192, 6144],
        pixelPitchMicrons: 1.6,
        bayerPattern: 'QUAD_BAYER_RGGB',
        readNoiseElectrons: 1.2,
        fullWellCapacityElectrons: 48000,
        dynamicRangeDb: 84.5,
        temperatureCelsius: 38.2,
        megapixel: 50.3,
      },
      intrinsics: {
        fx: 4250.0,
        fy: 4250.0,
        cx: 4096.0,
        cy: 3072.0,
        skew: 0.0,
        k1: -0.042,
        k2: 0.015,
        k3: -0.002,
        p1: 0.0001,
        p2: -0.0002,
        rmsReprojectionErrorPx: 0.12,
        calibrationDate: '2026-09-15T08:30:00Z',
      },
      extrinsics: {
        translationMm: [0.0, 0.0, 0.0], // Reference optical origin
        rotationMatrix: [
          [1.0, 0.0, 0.0],
          [0.0, 1.0, 0.0],
          [0.0, 0.0, 1.0],
        ],
        quaternion: [0.0, 0.0, 0.0, 1.0],
        eulerDeg: { pitch: 0.0, yaw: 0.0, roll: 0.0 },
        baselineFromMainMm: 0.0,
      },
      currentExposure: {
        shutterSpeedSec: 1 / 120,
        iso: 100,
        exposureValue: 11.6,
        analogGainDb: 0.0,
        digitalGainDb: 0.0,
      },
      snrDb: 42.1,
    },
    {
      id: 'camera.ultrawide',
      name: 'Camera 1 (Ultra-Wide 0.5X)',
      role: 'ULTRA_WIDE',
      isActive: true,
      lens: {
        focalLengthMm: 2.2,
        focalLength35mmEq: 13.0,
        fNumber: 2.2,
        entrancePupilMm: 1.0,
        fieldOfViewDeg: { horizontal: 114.0, vertical: 92.0, diagonal: 122.0 },
        opticalCenterOffsetPx: [1.2, -0.8],
        elementCount: 6,
      },
      sensor: {
        model: 'Sony IMX858 Type 1/2.51" Dual-PD',
        sensorFormat: '1/2.51-inch',
        resolutionPx: [8192, 6144],
        pixelPitchMicrons: 0.7,
        bayerPattern: 'QUAD_BAYER_RGGB',
        readNoiseElectrons: 1.6,
        fullWellCapacityElectrons: 22000,
        dynamicRangeDb: 78.0,
        temperatureCelsius: 39.5,
        megapixel: 50.3,
      },
      intrinsics: {
        fx: 1375.0,
        fy: 1375.0,
        cx: 4096.0,
        cy: 3072.0,
        skew: 0.0,
        k1: -0.118,
        k2: 0.048,
        k3: -0.009,
        p1: 0.0004,
        p2: 0.0003,
        rmsReprojectionErrorPx: 0.18,
        calibrationDate: '2026-09-15T08:30:00Z',
      },
      extrinsics: {
        translationMm: [-14.5, 10.2, 0.4], // Baseline layout relative to Main
        rotationMatrix: [
          [0.9998, 0.0035, -0.0174],
          [-0.0035, 0.9999, 0.0012],
          [0.0174, -0.0011, 0.9998],
        ],
        quaternion: [0.0006, 0.0087, -0.0018, 0.9999],
        eulerDeg: { pitch: 0.07, yaw: 1.0, roll: -0.2 },
        baselineFromMainMm: 17.73,
      },
      currentExposure: {
        shutterSpeedSec: 1 / 120,
        iso: 160,
        exposureValue: 10.8,
        analogGainDb: 2.1,
        digitalGainDb: 0.0,
      },
      snrDb: 38.6,
    },
    {
      id: 'camera.tele',
      name: 'Camera 2 (Periscope Telephoto 3.2X)',
      role: 'TELEPHOTO',
      isActive: true,
      lens: {
        focalLengthMm: 19.5,
        focalLength35mmEq: 70.0,
        fNumber: 2.0,
        entrancePupilMm: 9.75,
        fieldOfViewDeg: { horizontal: 28.5, vertical: 19.2, diagonal: 34.0 },
        opticalCenterOffsetPx: [-0.6, 1.4],
        elementCount: 6,
      },
      sensor: {
        model: 'Sony IMX858 Type 1/2.51" Periscope',
        sensorFormat: '1/2.51-inch',
        resolutionPx: [8192, 6144],
        pixelPitchMicrons: 0.7,
        bayerPattern: 'QUAD_BAYER_RGGB',
        readNoiseElectrons: 1.5,
        fullWellCapacityElectrons: 22000,
        dynamicRangeDb: 79.2,
        temperatureCelsius: 40.1,
        megapixel: 50.3,
      },
      intrinsics: {
        fx: 12180.0,
        fy: 12180.0,
        cx: 4096.0,
        cy: 3072.0,
        skew: 0.0,
        k1: 0.012,
        k2: -0.004,
        k3: 0.0005,
        p1: -0.0001,
        p2: 0.0002,
        rmsReprojectionErrorPx: 0.09,
        calibrationDate: '2026-09-15T08:30:00Z',
      },
      extrinsics: {
        translationMm: [18.2, 10.0, -0.6],
        rotationMatrix: [
          [0.9997, -0.002, 0.024],
          [0.002, 0.9999, 0.0005],
          [-0.024, -0.0005, 0.9997],
        ],
        quaternion: [-0.0002, -0.012, 0.001, 0.9999],
        eulerDeg: { pitch: -0.03, yaw: -1.38, roll: 0.11 },
        baselineFromMainMm: 20.78,
      },
      currentExposure: {
        shutterSpeedSec: 1 / 160,
        iso: 125,
        exposureValue: 11.4,
        analogGainDb: 1.2,
        digitalGainDb: 0.0,
      },
      snrDb: 40.4,
    },
    {
      id: 'camera.depth',
      name: 'Camera 3 (dToF LiDAR / IR Range)',
      role: 'DEPTH_DTOF',
      isActive: true,
      lens: {
        focalLengthMm: 1.8,
        focalLength35mmEq: 16.0,
        fNumber: 1.4,
        entrancePupilMm: 1.28,
        fieldOfViewDeg: { horizontal: 90.0, vertical: 70.0, diagonal: 102.0 },
        opticalCenterOffsetPx: [0.0, 0.0],
        elementCount: 3,
      },
      sensor: {
        model: 'Direct-ToF SPAD 64-Zone Array',
        sensorFormat: 'Custom SPAD',
        resolutionPx: [640, 480],
        pixelPitchMicrons: 9.6,
        bayerPattern: 'MONO_IR',
        readNoiseElectrons: 0.1,
        fullWellCapacityElectrons: 1000,
        dynamicRangeDb: 90.0,
        temperatureCelsius: 36.8,
        megapixel: 0.3,
      },
      intrinsics: {
        fx: 520.0,
        fy: 520.0,
        cx: 320.0,
        cy: 240.0,
        skew: 0.0,
        k1: -0.01,
        k2: 0.002,
        k3: 0.0,
        p1: 0.0,
        p2: 0.0,
        rmsReprojectionErrorPx: 0.05,
        calibrationDate: '2026-09-15T08:30:00Z',
      },
      extrinsics: {
        translationMm: [2.0, -18.5, 0.1],
        rotationMatrix: [
          [1.0, 0.0, 0.0],
          [0.0, 1.0, 0.0],
          [0.0, 0.0, 1.0],
        ],
        quaternion: [0.0, 0.0, 0.0, 1.0],
        eulerDeg: { pitch: 0.0, yaw: 0.0, roll: 0.0 },
        baselineFromMainMm: 18.61,
      },
      currentExposure: {
        shutterSpeedSec: 1 / 1000,
        iso: 100,
        exposureValue: 14.0,
        analogGainDb: 0.0,
        digitalGainDb: 0.0,
      },
      snrDb: 46.0,
    },
  ]);

  // Selected Camera for deep inspection
  readonly selectedCameraId = signal<CameraId>('camera.main');
  readonly selectedCamera = computed(() => {
    const list = this.cameras();
    return list.find((c) => c.id === this.selectedCameraId()) || list[0];
  });

  // Virtual Computational Aperture Configuration
  readonly apertureConfig = signal<VirtualApertureConfig>({
    virtualFNumber: 1.4,
    focusPlaneDistanceM: 0.85,
    depthOfFieldNearM: 0.76,
    depthOfFieldFarM: 0.96,
    bladeCount: 9, // 9-blade circular aperture
    anamorphicSqueezeFactor: 1.0,
    chromaticAberrationCorrection: 0.95,
    bokehHighlightGain: 1.35,
    antiVignetting: true,
  });

  // Fusion & Super-Resolution Configuration
  readonly fusionConfig = signal<FusionWeightsConfig>({
    sharpnessWeight: 0.35,
    snrWeight: 0.30,
    exposureWeight: 0.20,
    parallaxToleranceWeight: 0.15,
    superResolutionFactor: 2.0,
    polyphaseInterpolation: true,
  });

  // Sync Engine State
  readonly syncMode = signal<SyncState>('CALIBRATED');
  readonly clockDriftPpm = signal<number>(2.4);
  readonly simulatedJitterMs = signal<number>(0.18);
  readonly autoSyncCorrection = signal<boolean>(true);

  // Optical Output View Modes
  readonly outputViewMode = signal<
    'APERTURE_SYNTHESIS' | 'MULTI_CAM_FUSED' | 'MAIN_SENSOR_ONLY' | 'STEREO_DEPTH' | 'FUSION_WEIGHTS' | 'SUPER_RESOLUTION'
  >('APERTURE_SYNTHESIS');

  // Live Pixel Math Probe
  readonly activePixelProbe = signal<PixelProbeData>({
    x: 480,
    y: 320,
    groundTruthDepthM: 0.85,
    stereoDisparityPx: 14.2,
    circleOfConfusionMm: 0.008,
    inFocus: true,
    weights: {
      main: 0.42,
      tele: 0.48,
      ultrawide: 0.10,
    },
    timingOffsetMs: 0.18,
    geometricResidualPx: 0.06,
    colorDeltaE: 1.8,
    snrGainDb: 4.8,
  });

  // IMU Telemetry (Simulated continuous 1000Hz stream)
  readonly imuTelemetry = signal({
    gyroscopeRads: [0.002, -0.005, 0.001],
    accelerometerMps2: [0.12, 9.81, -0.04],
    quaternion: [0.0, 0.0, 0.0, 1.0],
    temperatureCelsius: 37.4,
  });

  // 14-Stage Optical Pipeline
  readonly pipelineStages = signal<OpticalPipelineStage[]>([
    {
      id: '01_capture',
      name: 'Synchronized Capture Initiation',
      description: 'Trigger pulse dispatch across MIPI CSI-2 bus interfaces.',
      hardwareUnit: 'ISP',
      executionTimeMs: 0.4,
      status: 'COMPLETE',
      confidence: 1.0,
    },
    {
      id: '02_discovery',
      name: 'Sensor Graph & Topology',
      description: 'Validates 4-sensor multi-camera graph and hardware capabilities.',
      hardwareUnit: 'CPU',
      executionTimeMs: 0.2,
      status: 'COMPLETE',
      confidence: 1.0,
    },
    {
      id: '03_timestamp_norm',
      name: 'Monotonic Timestamp Normalization',
      description: 'Clock oscillator model & drift calibration (±2.4 PPM).',
      hardwareUnit: 'CPU',
      executionTimeMs: 0.5,
      status: 'COMPLETE',
      confidence: 0.99,
    },
    {
      id: '04_frame_sync',
      name: 'Cross-Correlation Frame Sync',
      description: 'Sub-millisecond frame correlation & temporal jitter compensation.',
      hardwareUnit: 'ISP',
      executionTimeMs: 0.8,
      status: 'COMPLETE',
      confidence: 0.98,
    },
    {
      id: '05_intrinsics',
      name: 'Lens Distortion Unwarping',
      description: 'Brown-Conrady radial/tangential correction (k1, k2, k3, p1, p2).',
      hardwareUnit: 'GPU',
      executionTimeMs: 1.2,
      status: 'COMPLETE',
      confidence: 0.99,
    },
    {
      id: '06_extrinsics',
      name: 'SE(3) Multi-Camera Rigid Pose',
      description: 'Euclidean transformation relative to Camera 0 reference origin.',
      hardwareUnit: 'GPU',
      executionTimeMs: 0.9,
      status: 'COMPLETE',
      confidence: 0.97,
    },
    {
      id: '07_photometric',
      name: 'Photometric & Color Normalization',
      description: 'Vignetting, relative illumination, and Macbeth spectral alignment.',
      hardwareUnit: 'ISP',
      executionTimeMs: 1.5,
      status: 'COMPLETE',
      confidence: 0.96,
    },
    {
      id: '08_imu_fusion',
      name: 'IMU Motion Compensation',
      description: 'High-rate gyroscope trajectory matching & rolling-shutter de-skew.',
      hardwareUnit: 'SENSOR_HUB',
      executionTimeMs: 0.6,
      status: 'COMPLETE',
      confidence: 0.98,
    },
    {
      id: '09_stereo_depth',
      name: 'Multi-Baseline Stereo & LiDAR Fusion',
      description: 'Dense depth map extraction with dToF confidence weighting.',
      hardwareUnit: 'NPU',
      executionTimeMs: 3.4,
      status: 'COMPLETE',
      confidence: 0.94,
    },
    {
      id: '10_parallax_occlusion',
      name: 'Depth-Aware Occlusion & Parallax',
      description: 'Epipolar rectification and occlusion mask generation.',
      hardwareUnit: 'GPU',
      executionTimeMs: 1.8,
      status: 'COMPLETE',
      confidence: 0.93,
    },
    {
      id: '11_multi_fusion',
      name: 'Polyphase Multi-Sensor Fusion',
      description: 'Sharpness, noise, and geometric confidence pixel blending.',
      hardwareUnit: 'GPU',
      executionTimeMs: 2.7,
      status: 'COMPLETE',
      confidence: 0.96,
    },
    {
      id: '12_aperture_synth',
      name: 'Virtual Aperture & Pupil Defocus',
      description: 'Point Spread Function (PSF) synthesis with physical blade simulation.',
      hardwareUnit: 'GPU',
      executionTimeMs: 2.1,
      status: 'COMPLETE',
      confidence: 0.98,
    },
    {
      id: '13_super_res',
      name: 'Subpixel Polyphase Reconstruction',
      description: 'Spatial super-resolution utilizing subpixel phase offsets.',
      hardwareUnit: 'NPU',
      executionTimeMs: 3.1,
      status: 'COMPLETE',
      confidence: 0.95,
    },
    {
      id: '14_render',
      name: 'Linear DNG / Display Linear Output',
      description: 'High-dynamic-range linear color space render with embedded provenance.',
      hardwareUnit: 'GPU',
      executionTimeMs: 1.0,
      status: 'COMPLETE',
      confidence: 1.0,
    },
  ]);

  // Overall Pipeline Latency
  readonly totalPipelineLatencyMs = computed(() => {
    return this.pipelineStages().reduce((acc, stage) => acc + stage.executionTimeMs, 0).toFixed(1);
  });

  // Array Health & System Telemetry
  readonly arrayHealth = signal<ArrayHealthReport>({
    allSensorsOperational: true,
    timingJitterOk: true,
    calibrationThermalDriftDetected: false,
    chassisThermalState: 'OPTIMAL_38C',
    cpuLoadPercent: 18,
    gpuLoadPercent: 54,
    npuLoadPercent: 42,
    memoryRingBufferMb: 128,
    ispThroughputMpixSec: 420,
    droppedFramesLastSecond: 0,
  });

  // Live Synchronized Frame Set
  readonly currentFrameSet = signal<SynchronizedFrameSet>({
    timestampReferenceNs: 1790146400000000000,
    frames: new Map(),
    maxTimingErrorNs: 180000,
    timingErrorMs: 0.18,
    syncState: 'CALIBRATED',
    clockDriftPpm: 2.4,
    temporalOffsetEstimates: new Map([
      ['camera.main', 0.0],
      ['camera.ultrawide', -0.12],
      ['camera.tele', +0.37],
      ['camera.depth', -0.04],
    ]),
    matchPercentage: 99.8,
  });

  // Method to set Scene
  setScene(sceneId: string): void {
    const scene = this.availableScenes.find((s) => s.id === sceneId);
    if (scene) {
      this.activeScene.set(scene);
      this.apertureConfig.update((c) => ({
        ...c,
        focusPlaneDistanceM: scene.focalObjectDistanceM,
      }));
      this.recalculatePixelProbe(this.activePixelProbe().x, this.activePixelProbe().y);
    }
  }

  // Method to toggle camera on/off
  toggleCamera(id: CameraId): void {
    this.cameras.update((list) =>
      list.map((c) => (c.id === id ? { ...c, isActive: !c.isActive } : c))
    );
    this.recalculatePixelProbe(this.activePixelProbe().x, this.activePixelProbe().y);
  }

  // Method to update virtual f-number
  setVirtualFNumber(fNum: number): void {
    this.apertureConfig.update((c) => {
      // Calculate depth of field boundaries based on fNum and focus distance
      const d = c.focusPlaneDistanceM;
      const hyperfocal = (24 * 24) / (fNum * 0.02) / 1000; // Hyperfocal distance in meters approx
      const near = (hyperfocal * d) / (hyperfocal + d);
      const far = (hyperfocal * d) / (hyperfocal - d);

      return {
        ...c,
        virtualFNumber: parseFloat(fNum.toFixed(2)),
        depthOfFieldNearM: parseFloat(near.toFixed(2)),
        depthOfFieldFarM: far > 0 ? parseFloat(far.toFixed(2)) : 99.0,
      };
    });
    this.recalculatePixelProbe(this.activePixelProbe().x, this.activePixelProbe().y);
  }

  // Method to update focus distance
  setFocusDistance(distM: number): void {
    this.apertureConfig.update((c) => ({
      ...c,
      focusPlaneDistanceM: parseFloat(distM.toFixed(2)),
    }));
    this.recalculatePixelProbe(this.activePixelProbe().x, this.activePixelProbe().y);
  }

  // Mathematical Pixel Probe Calculation
  recalculatePixelProbe(x: number, y: number, canvasWidth = 800, canvasHeight = 500): void {
    const normX = Math.max(0, Math.min(1, x / canvasWidth));
    const normY = Math.max(0, Math.min(1, y / canvasHeight));

    const scene = this.activeScene();
    const minZ = scene.sceneDepthRangeM[0];
    const maxZ = scene.sceneDepthRangeM[1];

    // Compute realistic depth based on radial distance from center
    const radialDist = Math.sqrt(Math.pow(normX - 0.5, 2) + Math.pow(normY - 0.5, 2));
    const calculatedDepth = minZ + radialDist * (maxZ - minZ) * 1.4;
    const groundTruthDepth = parseFloat(Math.min(maxZ, Math.max(minZ, calculatedDepth)).toFixed(2));

    const focusPlane = this.apertureConfig().focusPlaneDistanceM;
    const fNum = this.apertureConfig().virtualFNumber;

    // Optical Circle of Confusion (CoC) in mm
    // CoC = (f^2 / N) * |Z - Z_focus| / (Z * (Z_focus - f))
    const focalLengthMm = 24.0;
    const deltaZ = Math.abs(groundTruthDepth - focusPlane);
    const rawCoc = ((focalLengthMm * focalLengthMm) / fNum) * (deltaZ / (groundTruthDepth * (focusPlane * 1000 - focalLengthMm)));
    const circleOfConfusionMm = parseFloat(Math.min(2.5, Math.max(0.005, rawCoc * 100)).toFixed(3));

    const inFocus = deltaZ < 0.15 * (fNum / 1.4);

    // Multi-camera weight distribution based on active sensors and zoom/depth characteristics
    const activeCams = this.cameras().filter((c) => c.isActive);
    let mainW = 0.45;
    let teleW = 0.45;
    let ultraW = 0.10;

    if (!activeCams.some((c) => c.id === 'camera.tele')) {
      mainW = 0.80;
      teleW = 0.0;
      ultraW = 0.20;
    }
    if (!activeCams.some((c) => c.id === 'camera.ultrawide')) {
      mainW = 0.55;
      teleW = 0.45;
      ultraW = 0.0;
    }
    if (!activeCams.some((c) => c.id === 'camera.main')) {
      mainW = 0.0;
      teleW = 0.70;
      ultraW = 0.30;
    }

    // Baseline stereo disparity (Disparity = baseline * f / Z)
    const disparityPx = parseFloat(((20.8 * 4250) / (groundTruthDepth * 1000)).toFixed(1));

    // SNR Gain in dB (multi-sensor coherent fusion: ~3 to 6 dB gain)
    const snrGain = (activeCams.length > 1 ? 3.0 + activeCams.length * 0.8 : 0.0).toFixed(1);

    this.activePixelProbe.set({
      x: Math.round(x),
      y: Math.round(y),
      groundTruthDepthM: groundTruthDepth,
      stereoDisparityPx: disparityPx,
      circleOfConfusionMm: circleOfConfusionMm,
      inFocus: inFocus,
      weights: {
        main: parseFloat(mainW.toFixed(2)),
        tele: parseFloat(teleW.toFixed(2)),
        ultrawide: parseFloat(ultraW.toFixed(2)),
      },
      timingOffsetMs: this.simulatedJitterMs(),
      geometricResidualPx: parseFloat((0.05 + (1 - this.cameras()[0].intrinsics.rmsReprojectionErrorPx) * 0.04).toFixed(2)),
      colorDeltaE: parseFloat((1.2 + (normX * 0.8)).toFixed(1)),
      snrGainDb: parseFloat(snrGain),
    });
  }

  // Export full container manifest
  generateAArrayExport() {
    return {
      schemaVersion: '1.4.0',
      system: 'Aardvark Camera Array.OS',
      projectId: 'aardvark-rig-042',
      timestamp: new Date().toISOString(),
      opticalSetup: {
        activeScene: this.activeScene(),
        cameras: this.cameras(),
        apertureConfig: this.apertureConfig(),
        fusionConfig: this.fusionConfig(),
        syncMode: this.syncMode(),
        activePixelProbe: this.activePixelProbe(),
      },
      provenance: {
        hardwareId: 'AARDVARK_QUAD_OPTICS_V3',
        calibrationMatrixValidated: true,
        cryptographicHash: '0x8F4A39B2841CE510D94689EAC3724B9C',
      },
    };
  }
}
