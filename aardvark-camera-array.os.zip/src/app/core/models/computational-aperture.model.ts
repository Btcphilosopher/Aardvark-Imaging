// Computational Aperture & Fusion Data Models - Aardvark Camera Array.OS

export interface VirtualApertureConfig {
  virtualFNumber: number; // e.g. f/0.95 to f/16.0
  focusPlaneDistanceM: number; // focus distance in meters (0.5 to infinity)
  depthRangeM: [number, number]; // [minZ, maxZ]
  bladeCount: number; // 0 for circular, 5, 7, 9 for polygonal iris
  anamorphicSqueeze: number; // 1.0 = spherical, 1.33 = anamorphic oval
  bokehHighlightGain: number; // 1.0 - 2.5
  vignetteStrength: number; // 0.0 - 1.0
  chromaticAberrationPx: number; // synthetic transverse CA
  nearBlurEnabled: boolean;
  farBlurEnabled: boolean;
  occlusionHandling: 'RIGOROUS_ALPHA_MATTE' | 'GAUSSIAN_APPROX' | 'DEPTH_PEELING';
}

export interface FusionWeightsConfig {
  weightSharpness: number; // 0.0 - 1.0
  weightSnr: number;
  weightBaselineParallax: number;
  weightExposureBalance: number;
  weightMotionPenalty: number;
  superResolutionFactor: 1.0 | 1.5 | 2.0 | 4.0;
  ghostDetectionThreshold: number;
  hdrBracktingEnabled: boolean;
}

export interface PixelProbeData {
  x: number;
  y: number;
  normalizedX: number;
  normalizedY: number;
  groundTruthDepthM: number;
  stereoDisparityPx: number;
  depthConfidence: number; // 0.0 - 1.0
  circleOfConfusionMm: number;
  inFocus: boolean;
  weights: {
    main: number;
    ultrawide: number;
    tele: number;
    depth: number;
  };
  temporalOffsetMs: number;
  geometricResidualPx: number;
  colorDeltaE: number;
  snrGainDb: number;
  rawPixelRgb: [number, number, number];
  fusedPixelRgb: [number, number, number];
  computationalBokehRgb: [number, number, number];
}

export interface ArrayHealthReport {
  overallStatus: 'NOMINAL' | 'DEGRADED' | 'CALIBRATION_REQUIRED' | 'THERMAL_THROTTLE';
  opticalCalibrationQuality: 'EXCELLENT' | 'GOOD' | 'MARGINAL' | 'POOR';
  temporalSyncQuality: 'CALIBRATED' | 'APPROXIMATE' | 'DEGRADED';
  colorMatchQuality: 'MATCHED' | 'SLIGHT_VARIANCE' | 'MISMATCHED';
  geometricResidualRmsPx: number;
  averageTimingErrorMs: number;
  droppedFramesCount: number;
  cpuLoadPercent: number;
  gpuLoadPercent: number;
  npuLoadPercent: number;
  ispThroughputMpixSec: number;
  memoryRingBufferMb: number;
  thermalThrottling: boolean;
  powerConsumptionWatts: number;
  powerMode: 'HIGH_QUALITY' | 'BALANCED' | 'THERMAL_CONSERVE';
}

export interface ExportableAArrayMetadata {
  schemaVersion: string;
  projectId: string;
  creationTimestampIso: string;
  hardwarePlatform: {
    deviceModel: string;
    cameraCount: number;
    syncHardwareAvailable: boolean;
    sensorArrayGeometry: string;
  };
  calibration: {
    calibrationId: string;
    rmsReprojectionError: number;
    epipolarResidualPx: number;
    referenceCamera: string;
  };
  provenance: {
    pipelineVersion: string;
    sourceCameras: string[];
    depthAlgorithm: string;
    fusionAlgorithm: string;
    apertureModel: string;
    timingErrorNs: number;
    processingHardware: string;
  };
}
