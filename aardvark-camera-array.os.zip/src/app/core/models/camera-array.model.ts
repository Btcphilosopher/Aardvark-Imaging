// Camera Array Domain Models - Aardvark Camera Array.OS

export type CameraId = 'camera.main' | 'camera.ultrawide' | 'camera.tele' | 'camera.depth' | string;

export type CameraRole = 'MAIN_WIDE' | 'ULTRA_WIDE' | 'TELEPHOTO' | 'DEPTH_DTOF' | 'WIDE' | 'ULTRAWIDE' | 'DEPTH_AUX';

export type BayerPattern = 'RGGB' | 'BGGR' | 'GRBG' | 'GBRG' | 'MONO' | 'QUAD_BAYER' | 'QUAD_BAYER_RGGB' | 'MONO_IR';

export type ShutterType = 'ROLLING' | 'GLOBAL';

export type SyncState = 
  | 'HARDWARE_SYNCHRONIZED' 
  | 'CALIBRATED' 
  | 'APPROXIMATELY_SYNCHRONIZED' 
  | 'SOFTWARE_ALIGNED' 
  | 'UNSYNCHRONIZED';

export type LensDistortionModel = 'PINHOLE' | 'BROWN_CONRADY' | 'FISHEYE_KANNALA_BRANDT' | 'RATIONAL_POLYNOMIAL';

export interface CameraArrayScene {
  readonly id: string;
  readonly name: string;
  readonly description: string;
  readonly imagePath: string;
  readonly focalObjectDistanceM: number;
  readonly sceneDepthRangeM: [number, number];
  readonly illuminanceLux: number;
  readonly colorTemperatureK: number;
}

export interface SensorSpecs {
  readonly model: string;
  readonly sensorFormat: string;
  readonly resolutionPx: [number, number];
  readonly pixelPitchMicrons: number;
  readonly bayerPattern: BayerPattern;
  readonly readNoiseElectrons: number;
  readonly fullWellCapacityElectrons: number;
  readonly dynamicRangeDb: number;
  temperatureCelsius: number;
  readonly megapixel: number;
}

export interface LensSpecs {
  readonly focalLengthMm: number;
  readonly focalLength35mmEq: number;
  readonly fNumber: number;
  readonly entrancePupilMm: number;
  readonly fieldOfViewDeg: { horizontal: number; vertical: number; diagonal: number } | number;
  readonly opticalCenterOffsetPx: [number, number];
  readonly elementCount: number;
}

export interface IntrinsicCalibration {
  fx: number;
  fy: number;
  cx: number;
  cy: number;
  skew: number;
  k1: number;
  k2: number;
  k3: number;
  p1: number;
  p2: number;
  rmsReprojectionErrorPx: number;
  calibrationDate: string;
}

export interface ExtrinsicPoseSE3 {
  rotationMatrix: [
    [number, number, number],
    [number, number, number],
    [number, number, number]
  ];
  translationMm: [number, number, number];
  quaternion?: [number, number, number, number];
  eulerDeg: { pitch: number; yaw: number; roll: number };
  baselineFromMainMm: number;
}

export interface ExposureMetadata {
  shutterSpeedSec: number;
  iso: number;
  exposureValue: number;
  analogGainDb: number;
  digitalGainDb: number;
}

export interface CameraModule {
  readonly id: CameraId;
  readonly name: string;
  readonly role: CameraRole;
  readonly isActive: boolean;
  readonly lens: LensSpecs;
  readonly sensor: SensorSpecs;
  readonly intrinsics: IntrinsicCalibration;
  readonly extrinsics: ExtrinsicPoseSE3;
  readonly currentExposure: ExposureMetadata;
  readonly snrDb: number;
}

export interface SynchronizedFrameSet {
  timestampReferenceNs: number;
  frames: Map<CameraId, unknown>;
  maxTimingErrorNs: number;
  timingErrorMs: number;
  syncState: SyncState;
  clockDriftPpm: number;
  temporalOffsetEstimates: Map<CameraId, number>;
  matchPercentage: number;
}

export interface OpticalPipelineStage {
  id: string;
  name: string;
  description: string;
  hardwareUnit: 'ISP' | 'GPU' | 'NPU' | 'CPU' | 'SENSOR_HUB';
  executionTimeMs: number;
  status: 'ACTIVE' | 'IDLE' | 'BYPASS' | 'COMPLETE';
  confidence: number;
}

export interface VirtualApertureConfig {
  virtualFNumber: number;
  focusPlaneDistanceM: number;
  depthOfFieldNearM: number;
  depthOfFieldFarM: number;
  bladeCount: number;
  anamorphicSqueezeFactor: number;
  chromaticAberrationCorrection: number;
  bokehHighlightGain: number;
  antiVignetting: boolean;
}

export interface FusionWeightsConfig {
  sharpnessWeight: number;
  snrWeight: number;
  exposureWeight: number;
  parallaxToleranceWeight: number;
  superResolutionFactor: number;
  polyphaseInterpolation: boolean;
}

export interface PixelProbeData {
  x: number;
  y: number;
  groundTruthDepthM: number;
  stereoDisparityPx: number;
  circleOfConfusionMm: number;
  inFocus: boolean;
  weights: {
    main: number;
    tele: number;
    ultrawide: number;
  };
  timingOffsetMs: number;
  geometricResidualPx: number;
  colorDeltaE: number;
  snrGainDb: number;
}

export interface ArrayHealthReport {
  allSensorsOperational: boolean;
  timingJitterOk: boolean;
  calibrationThermalDriftDetected: boolean;
  chassisThermalState: string;
  cpuLoadPercent: number;
  gpuLoadPercent: number;
  npuLoadPercent: number;
  memoryRingBufferMb: number;
  ispThroughputMpixSec: number;
  droppedFramesLastSecond: number;
}
