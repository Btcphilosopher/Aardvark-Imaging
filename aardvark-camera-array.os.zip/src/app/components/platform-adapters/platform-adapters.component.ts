import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CameraArrayEngineService } from '../../core/services/camera-array-engine.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-platform-adapters',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Hardware Platform Abstraction Console -->
      <div class="bg-neutral-900 border border-neutral-800 rounded-xl p-5 shadow-sm">
        <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-neutral-800 pb-4">
          <div>
            <h2 class="text-sm font-semibold text-neutral-100 uppercase tracking-wider flex items-center gap-2">
              <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">memory</mat-icon>
              Platform Adapters & Hardware Abstraction Layer
            </h2>
            <p class="text-xs text-neutral-400 mt-0.5">
              Android Camera2 Logical Multi-Camera & iOS AVFoundation AVCaptureMultiCamSession SDK bindings
            </p>
          </div>

          <!-- Platform Selector -->
          <div class="flex items-center gap-1 bg-neutral-950 p-1 rounded-lg border border-neutral-800">
            <button
              (click)="selectedPlatform.set('ANDROID_CAMERA2')"
              class="px-3 py-1.5 text-xs font-mono rounded transition-colors cursor-pointer"
              [class]="selectedPlatform() === 'ANDROID_CAMERA2' ? 'bg-neutral-800 text-cyan-300 font-bold border border-neutral-700' : 'text-neutral-400 hover:text-neutral-200'"
            >
              Android Camera2 Multi-Cam
            </button>
            <button
              (click)="selectedPlatform.set('IOS_AVFOUNDATION')"
              class="px-3 py-1.5 text-xs font-mono rounded transition-colors cursor-pointer"
              [class]="selectedPlatform() === 'IOS_AVFOUNDATION' ? 'bg-neutral-800 text-cyan-300 font-bold border border-neutral-700' : 'text-neutral-400 hover:text-neutral-200'"
            >
              Apple AVFoundation MultiCam
            </button>
          </div>
        </div>

        <!-- System Execution Unit Load Budget -->
        <div class="grid grid-cols-2 lg:grid-cols-5 gap-3 mt-4 text-xs font-mono">
          <div class="bg-neutral-950 p-3 rounded-lg border border-neutral-800">
            <div class="flex justify-between text-neutral-400 text-[10px] uppercase">
              <span>ISP Direct</span>
              <span class="text-emerald-400">{{ engine.arrayHealth().ispThroughputMpixSec }} Mpix/s</span>
            </div>
            <div class="text-base font-bold text-neutral-200 mt-1">Demosaic & Linear</div>
            <div class="w-full h-1 bg-neutral-800 rounded-full mt-2 overflow-hidden">
              <div class="h-full bg-emerald-400 rounded-full w-[65%]"></div>
            </div>
          </div>

          <div class="bg-neutral-950 p-3 rounded-lg border border-neutral-800">
            <div class="flex justify-between text-neutral-400 text-[10px] uppercase">
              <span>GPU Compute</span>
              <span class="text-cyan-400">{{ engine.arrayHealth().gpuLoadPercent }}%</span>
            </div>
            <div class="text-base font-bold text-neutral-200 mt-1">Warp & Aperture</div>
            <div class="w-full h-1 bg-neutral-800 rounded-full mt-2 overflow-hidden">
              <div class="h-full bg-cyan-400 rounded-full" [style.width.%]="engine.arrayHealth().gpuLoadPercent"></div>
            </div>
          </div>

          <div class="bg-neutral-950 p-3 rounded-lg border border-neutral-800">
            <div class="flex justify-between text-neutral-400 text-[10px] uppercase">
              <span>NPU Engine</span>
              <span class="text-purple-400">{{ engine.arrayHealth().npuLoadPercent }}%</span>
            </div>
            <div class="text-base font-bold text-neutral-200 mt-1">Polyphase Super-Res</div>
            <div class="w-full h-1 bg-neutral-800 rounded-full mt-2 overflow-hidden">
              <div class="h-full bg-purple-400 rounded-full" [style.width.%]="engine.arrayHealth().npuLoadPercent"></div>
            </div>
          </div>

          <div class="bg-neutral-950 p-3 rounded-lg border border-neutral-800">
            <div class="flex justify-between text-neutral-400 text-[10px] uppercase">
              <span>Host CPU</span>
              <span class="text-neutral-300">{{ engine.arrayHealth().cpuLoadPercent }}%</span>
            </div>
            <div class="text-base font-bold text-neutral-200 mt-1">Clock Sync & IMU</div>
            <div class="w-full h-1 bg-neutral-800 rounded-full mt-2 overflow-hidden">
              <div class="h-full bg-neutral-400 rounded-full" [style.width.%]="engine.arrayHealth().cpuLoadPercent"></div>
            </div>
          </div>

          <div class="bg-neutral-950 p-3 rounded-lg border border-neutral-800">
            <div class="flex justify-between text-neutral-400 text-[10px] uppercase">
              <span>Memory Ring</span>
              <span class="text-amber-400">{{ engine.arrayHealth().memoryRingBufferMb }} MB</span>
            </div>
            <div class="text-base font-bold text-neutral-200 mt-1">Zero-Copy DMA</div>
            <div class="w-full h-1 bg-neutral-800 rounded-full mt-2 overflow-hidden">
              <div class="h-full bg-amber-400 rounded-full w-[38%]"></div>
            </div>
          </div>
        </div>
      </div>

      <!-- Platform Native Adapter Architecture Code & Metadata Viewer -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Architecture Structure & Metadata Map -->
        <div class="lg:col-span-6 bg-neutral-950 border border-neutral-800 rounded-xl p-5 shadow-sm space-y-4">
          <div class="border-b border-neutral-800 pb-3 flex items-center justify-between">
            <h3 class="text-xs font-bold text-neutral-100 uppercase tracking-wider font-mono flex items-center gap-2">
              <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">developer_board</mat-icon>
              Hardware Capability Map
            </h3>
            <span class="text-xs font-mono text-emerald-400">VALIDATED</span>
          </div>

          @if (selectedPlatform() === 'ANDROID_CAMERA2') {
            <div class="space-y-3 font-mono text-xs text-neutral-300">
              <div class="p-2.5 bg-neutral-900 rounded border border-neutral-800">
                <div class="text-[10px] text-neutral-400 uppercase">Logical Camera ID</div>
                <div class="text-cyan-400 font-bold mt-0.5">CameraManager.openCamera("0") [Logical Multi-Cam]</div>
              </div>

              <div class="p-2.5 bg-neutral-900 rounded border border-neutral-800">
                <div class="text-[10px] text-neutral-400 uppercase">Physical Camera Stream IDs</div>
                <div class="text-neutral-200 mt-0.5">Physical IDs: 0 (Wide), 1 (UltraWide), 2 (Tele), 3 (Depth)</div>
              </div>

              <div class="p-2.5 bg-neutral-900 rounded border border-neutral-800">
                <div class="text-[10px] text-neutral-400 uppercase">Sync Capability Flag</div>
                <div class="text-emerald-400 font-bold mt-0.5">LOGICAL_MULTI_CAMERA_SENSOR_SYNC_TYPE_CALIBRATED</div>
                <div class="text-[10px] text-neutral-400 mt-0.5">Physical cameras share master clock oscillator</div>
              </div>

              <div class="p-2.5 bg-neutral-900 rounded border border-neutral-800">
                <div class="text-[10px] text-neutral-400 uppercase">Metadata Tags Queried</div>
                <div class="text-neutral-200 mt-0.5">SENSOR_TIMESTAMP, LENS_INTRINSIC_CALIBRATION, LENS_DISTORTION, SENSOR_ROLLING_SHUTTER_SKEW</div>
              </div>
            </div>
          } @else {
            <div class="space-y-3 font-mono text-xs text-neutral-300">
              <div class="p-2.5 bg-neutral-900 rounded border border-neutral-800">
                <div class="text-[10px] text-neutral-400 uppercase">Capture Session Model</div>
                <div class="text-cyan-400 font-bold mt-0.5">AVCaptureMultiCamSession (Simultaneous Multi-Sensor)</div>
              </div>

              <div class="p-2.5 bg-neutral-900 rounded border border-neutral-800">
                <div class="text-[10px] text-neutral-400 uppercase">Synchronizer Component</div>
                <div class="text-emerald-400 font-bold mt-0.5">AVCaptureDataOutputSynchronizer</div>
                <div class="text-[10px] text-neutral-400 mt-0.5">Delivers frame collections time-aligned via CMSampleBuffer</div>
              </div>

              <div class="p-2.5 bg-neutral-900 rounded border border-neutral-800">
                <div class="text-[10px] text-neutral-400 uppercase">Depth & Calibration Buffers</div>
                <div class="text-neutral-200 mt-0.5">AVDepthData (Disparity/Depth) + AVCameraCalibrationData (Intrinsics, Extrinsics, Pixel Size)</div>
              </div>

              <div class="p-2.5 bg-neutral-900 rounded border border-neutral-800">
                <div class="text-[10px] text-neutral-400 uppercase">Zero-Copy Buffer Pool</div>
                <div class="text-neutral-200 mt-0.5">CVPixelBufferPool with Metal texture sharing (CVMetalTextureCache)</div>
              </div>
            </div>
          }
        </div>

        <!-- C++ Adapter Binding Implementation Code Preview -->
        <div class="lg:col-span-6 bg-neutral-950 border border-neutral-800 rounded-xl p-5 shadow-sm space-y-4">
          <div class="border-b border-neutral-800 pb-3 flex items-center justify-between">
            <h3 class="text-xs font-bold text-neutral-100 uppercase tracking-wider font-mono flex items-center gap-2">
              <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">code</mat-icon>
              {{ selectedPlatform() === 'ANDROID_CAMERA2' ? 'AndroidCameraProvider.cpp' : 'AppleCameraProvider.mm' }}
            </h3>
            <span class="text-[10px] font-mono text-neutral-400">C++20 / NATIVE</span>
          </div>

          <pre class="bg-neutral-900 p-4 rounded-lg border border-neutral-800 font-mono text-[11px] text-neutral-300 overflow-x-auto leading-relaxed max-h-[290px] whitespace-pre">{{ activeCode() }}</pre>
        </div>
      </div>
    </div>
  `,
})
export class PlatformAdaptersComponent {
  readonly engine = inject(CameraArrayEngineService);
  selectedPlatform = signal<'ANDROID_CAMERA2' | 'IOS_AVFOUNDATION'>('ANDROID_CAMERA2');

  readonly androidCode = `// Aardvark Camera Array.OS - Android NDK Camera2 Provider
#include "aardvark/capture/AndroidCameraProvider.hpp"

namespace aardvark::capture {

Status AndroidCameraProvider::InitializeLogicalSession(
    const std::string& logicalCameraId,
    const std::vector<std::string>& physicalCameraIds) {
    
    ACameraManager* manager = ACameraManager_create();
    ACameraDevice* device = nullptr;
    
    // Validate calibrated hardware synchronisation
    camera_status_t status = ACameraManager_openCamera(manager, logicalCameraId.c_str(), &deviceCallbacks_, &device);
    if (status != ACAMERA_OK) {
        return Status::Error("Failed to open logical multi-camera");
    }

    for (const auto& physId : physicalCameraIds) {
        PhysicalStreamConfig cfg;
        cfg.physicalId = physId;
        cfg.format = AIMAGE_FORMAT_RAW16;
        cfg.bufferQueueSize = 4; // Zero-copy ring buffer
        RegisterPhysicalStream(device, cfg);
    }

    return Status::Ok();
}

} // namespace aardvark::capture`;

  readonly iosCode = `// Aardvark Camera Array.OS - Apple AVFoundation MultiCam Provider
#import "aardvark/capture/AppleCameraProvider.h"
#import <AVFoundation/AVFoundation.h>

@implementation AppleMultiCamSessionAdapter {
    AVCaptureMultiCamSession *_multiCamSession;
    AVCaptureDataOutputSynchronizer *_outputSynchronizer;
}

- (BOOL)startSynchronizedMultiCamCapture:(NSArray<AVCaptureDevice *> *)devices {
    _multiCamSession = [[AVCaptureMultiCamSession alloc] init];
    
    NSMutableArray<AVCaptureOutput *> *outputs = [NSMutableArray array];
    for (AVCaptureDevice *device in devices) {
        AVCaptureDeviceInput *input = [AVCaptureDeviceInput deviceInputWithDevice:device error:nil];
        if ([_multiCamSession canAddInput:input]) {
            [_multiCamSession addInputWithNoConnections:input];
        }
        
        AVCaptureVideoDataOutput *videoOutput = [[AVCaptureVideoDataOutput alloc] init];
        videoOutput.alwaysDiscardsLateVideoFrames = NO;
        [_multiCamSession addOutputWithNoConnections:videoOutput];
        [outputs addObject:videoOutput];
    }
    
    _outputSynchronizer = [[AVCaptureDataOutputSynchronizer alloc] initWithDataOutputs:outputs];
    [_outputSynchronizer setDelegate:self queue:dispatch_get_main_queue()];
    [_multiCamSession startRunning];
    return YES;
}

@end`;

  activeCode(): string {
    return this.selectedPlatform() === 'ANDROID_CAMERA2' ? this.androidCode : this.iosCode;
  }
}
