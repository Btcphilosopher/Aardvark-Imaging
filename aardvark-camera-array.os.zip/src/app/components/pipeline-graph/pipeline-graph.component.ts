import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CameraArrayEngineService } from '../../core/services/camera-array-engine.service';
import { OpticalPipelineStage } from '../../core/models/camera-array.model';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-pipeline-graph',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="bg-neutral-900 border border-neutral-800 rounded-xl p-5 shadow-sm space-y-4">
      <!-- Section Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-800 pb-3">
        <div>
          <h2 class="text-sm font-semibold text-neutral-100 uppercase tracking-wider flex items-center gap-2 font-mono">
            <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">account_tree</mat-icon>
            14-Stage Optical & Computational Processing Pipeline
          </h2>
          <p class="text-xs text-neutral-400 mt-0.5">
            Capture → Synchronise → Calibrate → Register → Align → Fuse → Reconstruct → Render
          </p>
        </div>

        <div class="text-xs font-mono text-neutral-300">
          Total Latency: <span class="text-cyan-400 font-bold">{{ engine.totalPipelineLatencyMs() }} ms</span> (60 FPS Capable)
        </div>
      </div>

      <!-- Horizontal Pipeline Flow Strip -->
      <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
        @for (stage of engine.pipelineStages(); track stage.id) {
          <button
            type="button"
            [attr.aria-label]="'Inspect ' + stage.name + ' stage'"
            (click)="selectedStage.set(stage)"
            class="p-2.5 rounded-lg border transition-all cursor-pointer flex flex-col justify-between font-mono text-xs group text-left focus:outline-none focus:ring-1 focus:ring-cyan-400"
            [class]="selectedStage()?.id === stage.id ? 'bg-neutral-800 border-cyan-400 shadow-md shadow-cyan-950/40' : 'bg-neutral-950 border-neutral-800 hover:border-neutral-700'"
          >
            <div>
              <div class="flex items-center justify-between mb-1">
                <span class="text-[9px] text-neutral-400 font-bold uppercase">{{ stage.hardwareUnit }}</span>
                <span class="text-[9px] px-1 py-0.2 rounded font-bold" [class]="getUnitBadgeClass(stage.hardwareUnit)">
                  {{ stage.executionTimeMs }}ms
                </span>
              </div>
              <div class="text-[11px] font-semibold text-neutral-200 line-clamp-2 leading-tight">
                {{ stage.name }}
              </div>
            </div>

            <!-- Confidence Bar -->
            <div class="w-full h-1 bg-neutral-900 rounded-full mt-2 overflow-hidden">
              <div class="h-full bg-cyan-400 rounded-full" [style.width.%]="stage.confidence * 100"></div>
            </div>
          </button>
        }
      </div>

      <!-- Stage Deep Inspection Box -->
      @if (selectedStage(); as st) {
        <div class="p-3.5 bg-neutral-950 border border-neutral-800 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-mono">
          <div class="flex items-center gap-3">
            <div class="w-8 h-8 rounded bg-neutral-900 border border-neutral-700 flex items-center justify-center text-cyan-400 font-bold">
              {{ st.id.slice(0, 2).toUpperCase() }}
            </div>
            <div>
              <div class="text-sm font-bold text-neutral-100">{{ st.name }}</div>
              <div class="text-neutral-400 text-[11px] mt-0.5">{{ st.description }}</div>
            </div>
          </div>

          <div class="flex items-center gap-4 text-[11px] shrink-0">
            <div>
              <span class="text-neutral-400 uppercase block">Compute Unit</span>
              <span class="text-cyan-400 font-bold">{{ st.hardwareUnit }}</span>
            </div>
            <div>
              <span class="text-neutral-400 uppercase block">Execution Time</span>
              <span class="text-neutral-200 font-bold">{{ st.executionTimeMs }} ms</span>
            </div>
            <div>
              <span class="text-neutral-400 uppercase block">Algorithmic Confidence</span>
              <span class="text-emerald-400 font-bold">{{ (st.confidence * 100).toFixed(0) }}%</span>
            </div>
          </div>
        </div>
      }
    </div>
  `,
})
export class PipelineGraphComponent {
  readonly engine = inject(CameraArrayEngineService);
  selectedStage = signal<OpticalPipelineStage | null>(this.engine.pipelineStages()[10]); // Default on Computational Aperture

  getUnitBadgeClass(unit: string): string {
    switch (unit) {
      case 'ISP':
        return 'bg-emerald-950 text-emerald-300 border border-emerald-800';
      case 'GPU':
        return 'bg-cyan-950 text-cyan-300 border border-cyan-800';
      case 'NPU':
        return 'bg-purple-950 text-purple-300 border border-purple-800';
      case 'SENSOR_HUB':
        return 'bg-amber-950 text-amber-300 border border-amber-800';
      default:
        return 'bg-neutral-800 text-neutral-300 border border-neutral-700';
    }
  }
}
