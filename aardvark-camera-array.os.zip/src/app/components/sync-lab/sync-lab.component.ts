import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CameraArrayEngineService } from '../../core/services/camera-array-engine.service';
import { SyncState } from '../../core/models/camera-array.model';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-sync-lab',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Sync Engine Overview Console -->
      <div class="bg-neutral-900 border border-neutral-800 rounded-xl p-5 shadow-sm">
        <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-neutral-800 pb-4">
          <div>
            <h2 class="text-sm font-semibold text-neutral-100 uppercase tracking-wider flex items-center gap-2">
              <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">sync</mat-icon>
              Multi-Camera Timestamp Synchronisation & Jitter Engine
            </h2>
            <p class="text-xs text-neutral-400 mt-0.5">
              Sub-millisecond frame correlation · Monotonic clock normalization · IMU gyroscope trajectory constraint
            </p>
          </div>

          <!-- Hardware Sync State Tag -->
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono text-neutral-400">SYNC STATE:</span>
            <div
              class="px-2.5 py-1 rounded text-xs font-mono font-bold flex items-center gap-1.5 border"
              [class]="getSyncBadgeClass()"
            >
              <div class="w-2 h-2 rounded-full" [class]="getSyncDotClass()"></div>
              {{ engine.syncMode() }}
            </div>
          </div>
        </div>

        <!-- Metric Readout Cards -->
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-4 text-xs font-mono">
          <div class="bg-neutral-950 p-3 rounded-lg border border-neutral-800">
            <span class="text-[10px] text-neutral-400 uppercase block">Max Timing Error (Δt)</span>
            <span class="text-xl font-bold text-cyan-400 mt-1 block">
              {{ engine.currentFrameSet().timingErrorMs }} <span class="text-xs font-normal text-neutral-400">ms</span>
            </span>
            <span class="text-[10px] text-neutral-400 font-mono">({{ engine.currentFrameSet().maxTimingErrorNs }} ns)</span>
          </div>

          <div class="bg-neutral-950 p-3 rounded-lg border border-neutral-800">
            <span class="text-[10px] text-neutral-400 uppercase block">Frame Match Success</span>
            <span class="text-xl font-bold text-emerald-400 mt-1 block">
              {{ engine.currentFrameSet().matchPercentage.toFixed(1) }} <span class="text-xs font-normal text-neutral-400">%</span>
            </span>
            <span class="text-[10px] text-neutral-400 font-mono">0 Dropped in Ring Buffer</span>
          </div>

          <div class="bg-neutral-950 p-3 rounded-lg border border-neutral-800">
            <span class="text-[10px] text-neutral-400 uppercase block">Clock Oscillator Drift</span>
            <span class="text-xl font-bold text-neutral-200 mt-1 block">
              ± {{ engine.clockDriftPpm() }} <span class="text-xs font-normal text-neutral-400">PPM</span>
            </span>
            <span class="text-[10px] text-neutral-400 font-mono">PLL Phase Lock Active</span>
          </div>

          <div class="bg-neutral-950 p-3 rounded-lg border border-neutral-800">
            <span class="text-[10px] text-neutral-400 uppercase block">IMU Assisted Temporal Lock</span>
            <span class="text-xl font-bold text-emerald-400 mt-1 block">
              6-DoF Gyro
            </span>
            <span class="text-[10px] text-neutral-400 font-mono">1000 Hz Sampling</span>
          </div>
        </div>
      </div>

      <!-- Real-Time 5-Stream Timeline Ribbon (Vertical Slice #2) -->
      <div class="bg-neutral-950 border border-neutral-800 rounded-xl p-5 shadow-sm space-y-4">
        <div class="flex items-center justify-between border-b border-neutral-800 pb-3">
          <h3 class="text-xs font-bold text-neutral-100 uppercase tracking-wider font-mono flex items-center gap-2">
            <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">timeline</mat-icon>
            Array Timestamp Stream Visualizer
          </h3>
          <span class="text-xs font-mono text-neutral-400">SAMPLE FREQUENCY: 60 FPS (16.66 ms / frame)</span>
        </div>

        <!-- Timeline Stream Rows -->
        <div class="space-y-3 font-mono text-xs">
          <!-- Main Camera (Reference) -->
          <div class="bg-neutral-900/80 p-3 rounded-lg border border-neutral-800 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div class="w-48 shrink-0 flex items-center justify-between">
              <span class="font-bold text-neutral-200">CAMERA 0 (MAIN)</span>
              <span class="text-neutral-400 text-[11px]">REF: 0.000 ms</span>
            </div>
            <!-- Simulated Pulse Bar -->
            <div class="flex-1 h-6 bg-neutral-950 rounded border border-neutral-800 relative overflow-hidden flex items-center px-2">
              <div class="w-full flex justify-between">
                @for (i of [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]; track i) {
                  <div class="w-3 h-4 bg-cyan-500/80 rounded-sm"></div>
                }
              </div>
            </div>
            <div class="text-[11px] text-emerald-400 shrink-0 font-bold">1289345021000 ns</div>
          </div>

          <!-- Ultra-Wide Camera -->
          <div class="bg-neutral-900/80 p-3 rounded-lg border border-neutral-800 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div class="w-48 shrink-0 flex items-center justify-between">
              <span class="font-bold text-neutral-200">CAMERA 1 (ULTRA)</span>
              <span class="text-amber-400 text-[11px]">{{ engine.currentFrameSet().temporalOffsetEstimates.get('camera.ultrawide') }} ms</span>
            </div>
            <div class="flex-1 h-6 bg-neutral-950 rounded border border-neutral-800 relative overflow-hidden flex items-center px-2">
              <div class="w-full flex justify-between ml-1">
                @for (i of [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]; track i) {
                  <div class="w-3 h-4 bg-purple-500/80 rounded-sm"></div>
                }
              </div>
            </div>
            <div class="text-[11px] text-neutral-300 shrink-0">1289345017200 ns</div>
          </div>

          <!-- Telephoto Camera -->
          <div class="bg-neutral-900/80 p-3 rounded-lg border border-neutral-800 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div class="w-48 shrink-0 flex items-center justify-between">
              <span class="font-bold text-neutral-200">CAMERA 2 (TELE)</span>
              <span class="text-amber-400 text-[11px]">{{ engine.currentFrameSet().temporalOffsetEstimates.get('camera.tele') }} ms</span>
            </div>
            <div class="flex-1 h-6 bg-neutral-950 rounded border border-neutral-800 relative overflow-hidden flex items-center px-2">
              <div class="w-full flex justify-between -ml-1">
                @for (i of [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]; track i) {
                  <div class="w-3 h-4 bg-emerald-500/80 rounded-sm"></div>
                }
              </div>
            </div>
            <div class="text-[11px] text-neutral-300 shrink-0">1289345024800 ns</div>
          </div>

          <!-- Depth dToF Sensor -->
          <div class="bg-neutral-900/80 p-3 rounded-lg border border-neutral-800 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div class="w-48 shrink-0 flex items-center justify-between">
              <span class="font-bold text-neutral-200">CAMERA 3 (dToF)</span>
              <span class="text-emerald-400 text-[11px]">{{ engine.currentFrameSet().temporalOffsetEstimates.get('camera.depth') }} ms</span>
            </div>
            <div class="flex-1 h-6 bg-neutral-950 rounded border border-neutral-800 relative overflow-hidden flex items-center px-2">
              <div class="w-full flex justify-between">
                @for (i of [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]; track i) {
                  <div class="w-3 h-4 bg-amber-500/80 rounded-sm"></div>
                }
              </div>
            </div>
            <div class="text-[11px] text-neutral-300 shrink-0">1289345019400 ns</div>
          </div>

          <!-- IMU 6-DoF Gyroscope -->
          <div class="bg-neutral-900/80 p-3 rounded-lg border border-neutral-800 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div class="w-48 shrink-0 flex items-center justify-between">
              <span class="font-bold text-neutral-200">IMU GYROSCOPE</span>
              <span class="text-cyan-400 text-[11px]">1000 Hz Continuous</span>
            </div>
            <div class="flex-1 h-6 bg-neutral-950 rounded border border-neutral-800 relative overflow-hidden flex items-center px-2">
              <div class="w-full h-1 bg-cyan-400/40 rounded-full"></div>
            </div>
            <div class="text-[11px] text-cyan-400 shrink-0 font-mono">
              ω: [{{ engine.imuTelemetry().gyroscopeRads[0].toFixed(3) }}, {{ engine.imuTelemetry().gyroscopeRads[1].toFixed(3) }}]
            </div>
          </div>
        </div>
      </div>

      <!-- Jitter Injection & Recovery Stress Test Controls -->
      <div class="bg-neutral-900 border border-neutral-800 rounded-xl p-5 shadow-sm">
        <div class="border-b border-neutral-800 pb-3 mb-4 flex items-center justify-between">
          <h3 class="text-xs font-bold text-neutral-100 uppercase tracking-wider font-mono flex items-center gap-2">
            <mat-icon class="!w-4 !h-4 !text-base text-amber-400">tune</mat-icon>
            Synchronization Stress-Test & Offset Injection
          </h3>
          <span class="text-xs text-neutral-400 font-mono">Simulate clock drift and hardware bus latency</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <!-- Jitter Injection Slider -->
          <div class="bg-neutral-950 p-4 rounded-lg border border-neutral-800 flex flex-col justify-between">
            <div class="flex items-center justify-between text-xs font-mono mb-2">
              <span class="text-neutral-300">Injected Bus Jitter (Δt)</span>
              <span class="text-amber-400 font-bold">{{ engine.simulatedJitterMs() }} ms</span>
            </div>
            <input
              type="range"
              min="0.0"
              max="3.0"
              step="0.02"
              [value]="engine.simulatedJitterMs()"
              (input)="onJitterChange($event)"
              class="w-full accent-amber-400 cursor-pointer"
            />
            <div class="flex justify-between text-[10px] font-mono text-neutral-400 mt-2">
              <span>0.0 ms (Exact)</span>
              <span>1.0 ms (Moderate)</span>
              <span>3.0 ms (Heavy Stress)</span>
            </div>
          </div>

          <!-- Auto-Sync PLL Toggle & Mode Selector -->
          <div class="bg-neutral-950 p-4 rounded-lg border border-neutral-800 flex flex-col justify-between">
            <div class="flex items-center justify-between text-xs font-mono mb-3">
              <span class="text-neutral-300">Software PLL Auto-Correction</span>
              <button
                (click)="toggleAutoSync()"
                class="px-3 py-1 rounded text-xs font-bold font-mono transition-colors cursor-pointer"
                [class]="engine.autoSyncCorrection() ? 'bg-emerald-950 text-emerald-300 border border-emerald-700' : 'bg-rose-950 text-rose-300 border border-rose-700'"
              >
                {{ engine.autoSyncCorrection() ? 'ACTIVE (Locked)' : 'DISABLED (Drifting)' }}
              </button>
            </div>
            
            <!-- Sync Mode Segmented Switch -->
            <div class="flex items-center gap-1 bg-neutral-900 p-1 rounded border border-neutral-800">
              @for (mode of syncModes; track mode) {
                <button
                  (click)="setSyncMode(mode)"
                  class="flex-1 py-1 text-[10px] font-mono rounded transition-colors cursor-pointer"
                  [class]="engine.syncMode() === mode ? 'bg-neutral-800 text-cyan-300 font-bold border border-neutral-700' : 'text-neutral-400 hover:text-neutral-200'"
                >
                  {{ mode }}
                </button>
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class SyncLabComponent {
  readonly engine = inject(CameraArrayEngineService);

  readonly syncModes: SyncState[] = [
    'HARDWARE_SYNCHRONIZED',
    'CALIBRATED',
    'APPROXIMATELY_SYNCHRONIZED',
    'SOFTWARE_ALIGNED',
  ];

  onJitterChange(event: Event): void {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.engine.simulatedJitterMs.set(val);
  }

  toggleAutoSync(): void {
    this.engine.autoSyncCorrection.update(v => !v);
  }

  setSyncMode(mode: SyncState): void {
    this.engine.syncMode.set(mode);
  }

  getSyncBadgeClass(): string {
    const mode = this.engine.syncMode();
    if (mode === 'HARDWARE_SYNCHRONIZED' || mode === 'CALIBRATED') {
      return 'bg-emerald-950/80 text-emerald-300 border-emerald-700';
    }
    if (mode === 'APPROXIMATELY_SYNCHRONIZED' || mode === 'SOFTWARE_ALIGNED') {
      return 'bg-amber-950/80 text-amber-300 border-amber-700';
    }
    return 'bg-rose-950/80 text-rose-300 border-rose-700';
  }

  getSyncDotClass(): string {
    const mode = this.engine.syncMode();
    if (mode === 'HARDWARE_SYNCHRONIZED' || mode === 'CALIBRATED') {
      return 'bg-emerald-400';
    }
    if (mode === 'APPROXIMATELY_SYNCHRONIZED' || mode === 'SOFTWARE_ALIGNED') {
      return 'bg-amber-400';
    }
    return 'bg-rose-400';
  }
}
