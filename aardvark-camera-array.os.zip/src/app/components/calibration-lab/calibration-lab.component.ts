import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CameraArrayEngineService } from '../../core/services/camera-array-engine.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-calibration-lab',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Calibration Console Header -->
      <div class="bg-neutral-900 border border-neutral-800 rounded-xl p-5 shadow-sm">
        <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-neutral-800 pb-4">
          <div>
            <h2 class="text-sm font-semibold text-neutral-100 uppercase tracking-wider flex items-center gap-2">
              <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">grid_on</mat-icon>
              Optical & Geometric Calibration Laboratory
            </h2>
            <p class="text-xs text-neutral-400 mt-0.5">
              ChArUco / AprilTag target solver · Brown-Conrady unwarping · Multi-camera SE(3) Euclidean pose residuals
            </p>
          </div>

          <!-- Target Pattern Selector -->
          <div class="flex items-center gap-1 bg-neutral-950 p-1 rounded-lg border border-neutral-800">
            @for (target of targetPatterns; track target.id) {
              <button
                (click)="selectedTarget.set(target.id)"
                class="px-3 py-1.5 text-xs font-mono rounded transition-colors cursor-pointer"
                [class]="selectedTarget() === target.id ? 'bg-neutral-800 text-cyan-300 font-bold border border-neutral-700' : 'text-neutral-400 hover:text-neutral-200'"
              >
                {{ target.name }}
              </button>
            }
          </div>
        </div>

        <!-- RMS Reprojection Error Scoreboard -->
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-4 font-mono text-xs">
          @for (cam of engine.cameras(); track cam.id) {
            <div class="bg-neutral-950 p-3 rounded-lg border border-neutral-800">
              <span class="text-[10px] text-neutral-400 uppercase block">{{ cam.name }}</span>
              <span class="text-xl font-bold text-emerald-400 mt-1 block">
                {{ cam.intrinsics.rmsReprojectionErrorPx }} <span class="text-xs font-normal text-neutral-400">px RMS</span>
              </span>
              <div class="w-full h-1.5 bg-neutral-900 rounded-full mt-2 overflow-hidden">
                <div
                  class="h-full bg-emerald-400 rounded-full"
                  [style.width.%]="(1 - cam.intrinsics.rmsReprojectionErrorPx) * 100"
                ></div>
              </div>
              <span class="text-[10px] text-neutral-400 mt-1 block">CAL: {{ cam.intrinsics.calibrationDate.slice(0, 10) }}</span>
            </div>
          }
        </div>
      </div>

      <!-- Calibration Target Simulator & Distortion Unwarp Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Target & Feature Detection Visualizer -->
        <div class="lg:col-span-6 bg-neutral-950 border border-neutral-800 rounded-xl p-5 shadow-sm flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between border-b border-neutral-800 pb-3 mb-4">
              <h3 class="text-xs font-bold text-neutral-100 uppercase tracking-wider font-mono flex items-center gap-2">
                <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">center_focus_strong</mat-icon>
                Simulated Calibration Target & Corners
              </h3>
              <span class="text-xs font-mono text-emerald-400">144 DETECTED CORNERS</span>
            </div>

            <!-- Target Canvas (Checkerboard / AprilTag / ChArUco) -->
            <div class="aspect-4/3 bg-neutral-900 border border-neutral-800 rounded-lg relative overflow-hidden flex items-center justify-center p-4">
              <!-- Geometric Grid Pattern -->
              <div class="w-full h-full grid grid-cols-8 grid-rows-6 gap-1 p-2 bg-neutral-950 border border-neutral-700 rounded shadow-inner">
                @for (cell of gridCells; track cell.id) {
                  <div
                    class="rounded-xs relative flex items-center justify-center"
                    [class]="cell.isDark ? 'bg-neutral-800 border border-neutral-700' : 'bg-neutral-200 border border-neutral-300'"
                  >
                    <!-- Corner Detection Subpixel Crosses -->
                    @if (cell.hasCorner) {
                      <div class="absolute -top-1 -left-1 w-2 h-2 rounded-full bg-cyan-400 ring-2 ring-cyan-500/40 z-10"></div>
                    }
                  </div>
                }
              </div>

              <!-- Optical Axis Centroid Crosshair -->
              <div class="absolute inset-0 pointer-events-none flex items-center justify-center">
                <div class="w-12 h-12 border border-dashed border-cyan-400/60 rounded-full flex items-center justify-center">
                  <div class="w-1 h-1 bg-cyan-400 rounded-full"></div>
                </div>
              </div>
            </div>
          </div>

          <div class="mt-4 flex items-center justify-between text-xs font-mono text-neutral-400">
            <span>Pattern: {{ selectedTarget() }}</span>
            <span class="text-cyan-400">Subpixel Accuracy: ± 0.04 px</span>
          </div>
        </div>

        <!-- Lens Distortion Unwarping Grid Visualizer -->
        <div class="lg:col-span-6 bg-neutral-950 border border-neutral-800 rounded-xl p-5 shadow-sm flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between border-b border-neutral-800 pb-3 mb-4">
              <h3 class="text-xs font-bold text-neutral-100 uppercase tracking-wider font-mono flex items-center gap-2">
                <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">blur_on</mat-icon>
                Radial & Tangential Unwarp Map
              </h3>
              <span class="text-xs font-mono text-cyan-400">BROWN-CONRADY</span>
            </div>

            <!-- Distortion Warp Mesh Grid -->
            <div class="aspect-4/3 bg-neutral-900 border border-neutral-800 rounded-lg relative overflow-hidden flex items-center justify-center p-4">
              <svg class="w-full h-full" viewBox="0 0 320 240">
                <!-- Distorted Mesh Lines (Radial Barrel / Pincushion Distortion Lines) -->
                @for (x of [20, 60, 100, 140, 160, 180, 220, 260, 300]; track x) {
                  <path
                    [attr.d]="getCurvedVLine(x)"
                    fill="none"
                    stroke="#06b6d4"
                    stroke-width="1.2"
                    stroke-opacity="0.6"
                  />
                }
                @for (y of [20, 50, 80, 120, 160, 190, 220]; track y) {
                  <path
                    [attr.d]="getCurvedHLine(y)"
                    fill="none"
                    stroke="#06b6d4"
                    stroke-width="1.2"
                    stroke-opacity="0.6"
                  />
                }
                <!-- Center optical axis -->
                <circle cx="160" cy="120" r="4" fill="#38bdf8" />
              </svg>
            </div>
          </div>

          <div class="mt-4 flex items-center justify-between text-xs font-mono text-neutral-400">
            <span>Polynomial Terms: k1, k2, k3, p1, p2</span>
            <span class="text-emerald-400">Linearized Residual: 0.08 px</span>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class CalibrationLabComponent {
  readonly engine = inject(CameraArrayEngineService);

  readonly targetPatterns = [
    { id: 'CHARUCO', name: 'ChArUco 8x6' },
    { id: 'APRILTAG_GRID', name: 'AprilTag 36h11' },
    { id: 'CHECKERBOARD', name: 'Chessboard 9x7' },
  ];

  selectedTarget = signal('CHARUCO');

  readonly gridCells = Array.from({ length: 48 }, (_, i) => ({
    id: i,
    isDark: (Math.floor(i / 8) + (i % 8)) % 2 === 0,
    hasCorner: (i % 3 === 0),
  }));

  getCurvedVLine(x: number): string {
    const cx = 160;
    const dx = x - cx;
    const curve = dx * 0.08;
    return `M ${x} 10 Q ${x + curve} 120 ${x} 230`;
  }

  getCurvedHLine(y: number): string {
    const cy = 120;
    const dy = y - cy;
    const curve = dy * 0.08;
    return `M 10 ${y} Q 160 ${y + curve} 310 ${y}`;
  }
}
