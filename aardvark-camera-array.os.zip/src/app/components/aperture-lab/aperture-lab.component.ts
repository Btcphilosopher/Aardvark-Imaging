import { ChangeDetectionStrategy, Component, inject, ElementRef, viewChild } from '@angular/core';
import { CameraArrayEngineService } from '../../core/services/camera-array-engine.service';
import { MatIconModule } from '@angular/material/icon';

type ViewModeId = 'APERTURE_SYNTHESIS' | 'MULTI_CAM_FUSED' | 'MAIN_SENSOR_ONLY' | 'STEREO_DEPTH' | 'FUSION_WEIGHTS' | 'SUPER_RESOLUTION';

@Component({
  selector: 'app-aperture-lab',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Top Aperture & Fusion Controls Console -->
      <div class="bg-neutral-900 border border-neutral-800 rounded-xl p-5 shadow-sm">
        <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-neutral-800 pb-4">
          <div>
            <h2 class="text-sm font-semibold text-neutral-100 uppercase tracking-wider flex items-center gap-2">
              <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">camera</mat-icon>
              Aardvark Computational Aperture & Optical Fusion Lab
            </h2>
            <p class="text-xs text-neutral-400 mt-0.5">
              Virtual entrance pupil synthesis · Depth-aware PSF defocus · Subpixel multi-camera reconstruction
            </p>
          </div>

          <!-- View Mode Selector -->
          <div class="flex items-center gap-1 bg-neutral-950 p-1 rounded-lg border border-neutral-800 overflow-x-auto">
            @for (mode of viewModes; track mode.id) {
              <button
                type="button"
                (click)="setViewMode(mode.id)"
                class="px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap cursor-pointer"
                [class]="engine.outputViewMode() === mode.id ? 'bg-neutral-800 text-cyan-400 font-semibold shadow-sm border border-neutral-700' : 'text-neutral-400 hover:text-neutral-200'"
              >
                {{ mode.label }}
              </button>
            }
          </div>
        </div>

        <!-- Fine Optical Parameter Rails -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-4">
          <!-- Focal Plane Distance -->
          <div class="bg-neutral-950 p-3 rounded-lg border border-neutral-800 flex flex-col justify-between">
            <div class="flex items-center justify-between text-xs font-mono mb-2">
              <span class="text-neutral-400 uppercase">Focus Plane Distance</span>
              <span class="text-cyan-400 font-bold">{{ engine.apertureConfig().focusPlaneDistanceM }} m</span>
            </div>
            <input
              type="range"
              min="0.3"
              max="6.0"
              step="0.05"
              [value]="engine.apertureConfig().focusPlaneDistanceM"
              (input)="onFocusSliderChange($event)"
              class="w-full accent-cyan-400 cursor-pointer"
            />
            <div class="flex justify-between text-[10px] font-mono text-neutral-400 mt-1">
              <span>0.3m (Macro)</span>
              <span>1.0m (Portrait)</span>
              <span>3.5m</span>
              <span>∞ (Infinity)</span>
            </div>
          </div>

          <!-- Virtual Aperture F-Number -->
          <div class="bg-neutral-950 p-3 rounded-lg border border-neutral-800 flex flex-col justify-between">
            <div class="flex items-center justify-between text-xs font-mono mb-2">
              <span class="text-neutral-400 uppercase">Virtual Aperture</span>
              <span class="text-cyan-400 font-bold">f/{{ engine.apertureConfig().virtualFNumber }}</span>
            </div>
            <input
              type="range"
              min="0.95"
              max="16.0"
              step="0.05"
              [value]="engine.apertureConfig().virtualFNumber"
              (input)="onApertureSliderChange($event)"
              class="w-full accent-cyan-400 cursor-pointer"
            />
            <div class="flex justify-between text-[10px] font-mono text-neutral-400 mt-1">
              <span>f/0.95 (Ultra Bokeh)</span>
              <span>f/2.8</span>
              <span>f/5.6</span>
              <span>f/16 (Deep Focus)</span>
            </div>
          </div>

          <!-- Bokeh Iris Blade Geometry -->
          <div class="bg-neutral-950 p-3 rounded-lg border border-neutral-800 flex flex-col justify-between">
            <div class="flex items-center justify-between text-xs font-mono mb-2">
              <span class="text-neutral-400 uppercase">Iris Blades & Specular</span>
              <span class="text-neutral-200 font-bold">{{ engine.apertureConfig().bladeCount === 0 ? 'Circular' : engine.apertureConfig().bladeCount + '-Blade' }}</span>
            </div>
            <div class="flex items-center gap-1">
              @for (blades of [0, 5, 7, 9]; track blades) {
                <button
                  type="button"
                  (click)="setBlades(blades)"
                  class="flex-1 py-1 text-xs font-mono rounded border transition-colors cursor-pointer"
                  [class]="engine.apertureConfig().bladeCount === blades ? 'bg-neutral-800 border-cyan-500 text-cyan-300' : 'bg-neutral-900 border-neutral-700 text-neutral-400 hover:text-neutral-200'"
                >
                  {{ blades === 0 ? 'Circ' : blades }}
                </button>
              }
            </div>
            <div class="text-[10px] font-mono text-neutral-400 mt-1">
              Highlight Boost: {{ engine.apertureConfig().bokehHighlightGain }}X
            </div>
          </div>

          <!-- Fusion Super-Resolution Multiplier -->
          <div class="bg-neutral-950 p-3 rounded-lg border border-neutral-800 flex flex-col justify-between">
            <div class="flex items-center justify-between text-xs font-mono mb-2">
              <span class="text-neutral-400 uppercase">Super-Res Factor</span>
              <span class="text-emerald-400 font-bold">{{ engine.fusionConfig().superResolutionFactor }}X Spatial</span>
            </div>
            <div class="flex items-center gap-1">
              @for (factor of [1.0, 1.5, 2.0, 4.0]; track factor) {
                <button
                  type="button"
                  (click)="setSuperRes(factor)"
                  class="flex-1 py-1 text-xs font-mono rounded border transition-colors cursor-pointer"
                  [class]="engine.fusionConfig().superResolutionFactor === factor ? 'bg-emerald-950 border-emerald-500 text-emerald-300' : 'bg-neutral-900 border-neutral-700 text-neutral-400 hover:text-neutral-200'"
                >
                  {{ factor }}X
                </button>
              }
            </div>
            <div class="text-[10px] font-mono text-neutral-400 mt-1">
              Subpixel Polyphase Alignment
            </div>
          </div>
        </div>
      </div>

      <!-- Live Reconstructed Optical Viewport & Interactive Pixel Probe -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Main Optical Viewport Canvas Area -->
        <div class="lg:col-span-8 bg-neutral-950 border border-neutral-800 rounded-xl overflow-hidden flex flex-col shadow-sm">
          <!-- Viewport Header Toolbar -->
          <div class="bg-neutral-900 px-4 py-2.5 border-b border-neutral-800 flex items-center justify-between text-xs font-mono">
            <div class="flex items-center gap-2">
              <span class="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
              <span class="text-neutral-200 font-semibold uppercase">{{ activeModeLabel() }}</span>
            </div>

            <div class="flex items-center gap-3 text-neutral-400">
              <span>LATENCY: <strong class="text-neutral-200">{{ engine.totalPipelineLatencyMs() }} ms</strong></span>
              <span>·</span>
              <span>PROBE: <strong class="text-cyan-400">X: {{ engine.activePixelProbe().x }}, Y: {{ engine.activePixelProbe().y }}</strong></span>
            </div>
          </div>

          <!-- Image Stage with Synthetic Optical Shader Simulation -->
          <div
            #imageStage
            tabindex="0"
            role="region"
            aria-label="Interactive Optical Viewport and Pixel Probe Canvas"
            (mousemove)="onCanvasMouseMove($event)"
            (click)="onCanvasClick($event)"
            (keydown.enter)="onStageKeydown()"
            class="relative w-full aspect-16/10 bg-neutral-900 flex items-center justify-center cursor-crosshair overflow-hidden group select-none focus:outline-none focus:ring-1 focus:ring-cyan-500"
          >
            <!-- Rendered Output Layer (Adapts dynamically to Mode & Optical Controls) -->
            <img
              [src]="engine.activeScene().imagePath"
              alt="Optical test scene"
              referrerpolicy="no-referrer"
              class="w-full h-full object-cover transition-all duration-300"
              [style]="getImageFilterStyle()"
            />

            <!-- Depth Visualization Heatmap Overlay (in Depth mode) -->
            @if (engine.outputViewMode() === 'STEREO_DEPTH') {
              <div class="absolute inset-0 bg-gradient-to-tr from-indigo-900/80 via-purple-800/70 to-amber-500/80 mix-blend-color pointer-events-none"></div>
            }

            <!-- Weight Contribution Heatmap Overlay (in Fusion Weights mode) -->
            @if (engine.outputViewMode() === 'FUSION_WEIGHTS') {
              <div class="absolute inset-0 bg-gradient-radial from-emerald-500/60 via-cyan-500/40 to-purple-600/70 mix-blend-screen pointer-events-none"></div>
            }

            <!-- Crosshair Target Ring -->
            <div
              class="absolute w-12 h-12 -ml-6 -mt-6 border border-cyan-400/80 rounded-full pointer-events-none flex items-center justify-center shadow-lg transition-transform duration-75"
              [style.left.px]="engine.activePixelProbe().x"
              [style.top.px]="engine.activePixelProbe().y"
            >
              <div class="w-1.5 h-1.5 bg-cyan-400 rounded-full"></div>
              <div class="absolute w-16 h-[1px] bg-cyan-400/30"></div>
              <div class="absolute h-16 w-[1px] bg-cyan-400/30"></div>
              
              <!-- Floating Mini Probe Tag -->
              <div class="absolute -top-7 left-7 bg-neutral-900/90 text-neutral-100 font-mono text-[10px] px-2 py-0.5 rounded border border-neutral-700 whitespace-nowrap shadow">
                Z: {{ engine.activePixelProbe().groundTruthDepthM }}m · {{ engine.activePixelProbe().inFocus ? 'IN-FOCUS' : 'DEFOCUS' }}
              </div>
            </div>

            <!-- Optical Grid Lines HUD -->
            <div class="absolute inset-0 pointer-events-none opacity-20 dense-grid"></div>

            <!-- Focus Plane Depth Indicator Tag -->
            <div class="absolute bottom-3 left-3 bg-neutral-900/90 backdrop-blur-sm border border-neutral-700 text-neutral-200 text-xs font-mono px-3 py-1 rounded shadow">
              FOCUS PLANE: {{ engine.apertureConfig().focusPlaneDistanceM }}m · VIRTUAL f/{{ engine.apertureConfig().virtualFNumber }} · {{ engine.apertureConfig().bladeCount === 0 ? 'CIRCULAR' : engine.apertureConfig().bladeCount + '-BLADE' }}
            </div>
          </div>
        </div>

        <!-- Calculation Explorer (Signature Aardvark Multi-Camera Math Probe) -->
        <div class="lg:col-span-4 bg-neutral-950 border border-neutral-800 rounded-xl p-4 flex flex-col justify-between shadow-sm">
          <div>
            <div class="border-b border-neutral-800 pb-2.5 mb-3 flex items-center justify-between">
              <h3 class="text-xs font-bold text-neutral-100 uppercase tracking-wider font-mono flex items-center gap-1.5">
                <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">query_stats</mat-icon>
                Calculation Explorer
              </h3>
              <span class="text-[11px] font-mono text-emerald-400">LIVE PROBE</span>
            </div>

            @let probe = engine.activePixelProbe();

            <!-- Pixel Coordinates & In-Focus State -->
            <div class="grid grid-cols-2 gap-2 mb-3 font-mono text-xs">
              <div class="bg-neutral-900 p-2 rounded border border-neutral-800">
                <span class="text-[10px] text-neutral-400 uppercase block">Sample Point</span>
                <span class="font-bold text-neutral-200">X: {{ probe.x }} · Y: {{ probe.y }}</span>
              </div>
              <div class="bg-neutral-900 p-2 rounded border border-neutral-800">
                <span class="text-[10px] text-neutral-400 uppercase block">Optical State</span>
                <span class="font-bold" [class]="probe.inFocus ? 'text-emerald-400' : 'text-amber-400'">
                  {{ probe.inFocus ? 'SHARP (In-Focus)' : 'BLURRED (Defocus)' }}
                </span>
              </div>
            </div>

            <!-- Multi-Camera Pixel Contribution Breakdown -->
            <div class="bg-neutral-900 p-3 rounded-lg border border-neutral-800 mb-3 font-mono text-xs">
              <div class="text-[11px] font-semibold text-neutral-300 uppercase tracking-wider mb-2 flex items-center justify-between">
                <span>Multi-Camera Contribution</span>
                <span class="text-cyan-400">100% Total</span>
              </div>

              <!-- Camera 0: Main -->
              <div class="space-y-1 mb-2">
                <div class="flex justify-between text-[11px]">
                  <span class="text-neutral-300">Camera 0 (Main 24mm)</span>
                  <span class="text-cyan-400 font-bold">{{ (probe.weights.main * 100).toFixed(0) }}%</span>
                </div>
                <div class="w-full h-1.5 bg-neutral-800 rounded-full overflow-hidden">
                  <div class="h-full bg-cyan-400 rounded-full" [style.width.%]="probe.weights.main * 100"></div>
                </div>
              </div>

              <!-- Camera 2: Telephoto -->
              <div class="space-y-1 mb-2">
                <div class="flex justify-between text-[11px]">
                  <span class="text-neutral-300">Camera 2 (Tele 70mm)</span>
                  <span class="text-emerald-400 font-bold">{{ (probe.weights.tele * 100).toFixed(0) }}%</span>
                </div>
                <div class="w-full h-1.5 bg-neutral-800 rounded-full overflow-hidden">
                  <div class="h-full bg-emerald-400 rounded-full" [style.width.%]="probe.weights.tele * 100"></div>
                </div>
              </div>

              <!-- Camera 1: Ultra-wide -->
              <div class="space-y-1">
                <div class="flex justify-between text-[11px]">
                  <span class="text-neutral-300">Camera 1 (Ultra 13mm)</span>
                  <span class="text-purple-400 font-bold">{{ (probe.weights.ultrawide * 100).toFixed(0) }}%</span>
                </div>
                <div class="w-full h-1.5 bg-neutral-800 rounded-full overflow-hidden">
                  <div class="h-full bg-purple-400 rounded-full" [style.width.%]="probe.weights.ultrawide * 100"></div>
                </div>
              </div>
            </div>

            <!-- Mathematical Residuals & Optical Invariants -->
            <div class="space-y-2 font-mono text-xs">
              <div class="flex items-center justify-between p-2 bg-neutral-900 rounded border border-neutral-800">
                <span class="text-neutral-400">Metric Depth (Z)</span>
                <span class="text-neutral-200 font-bold">{{ probe.groundTruthDepthM }} m (Disp: {{ probe.stereoDisparityPx }}px)</span>
              </div>

              <div class="flex items-center justify-between p-2 bg-neutral-900 rounded border border-neutral-800">
                <span class="text-neutral-400">Circle of Confusion (CoC)</span>
                <span class="text-cyan-400 font-bold">{{ probe.circleOfConfusionMm }} mm</span>
              </div>

              <div class="flex items-center justify-between p-2 bg-neutral-900 rounded border border-neutral-800">
                <span class="text-neutral-400">Geometric Alignment Residual</span>
                <span class="text-emerald-400 font-bold">{{ probe.geometricResidualPx }} px</span>
              </div>

              <div class="flex items-center justify-between p-2 bg-neutral-900 rounded border border-neutral-800">
                <span class="text-neutral-400">Spectral Colour Delta (ΔE)</span>
                <span class="text-neutral-200 font-bold">{{ probe.colorDeltaE }}</span>
              </div>

              <div class="flex items-center justify-between p-2 bg-neutral-900 rounded border border-neutral-800">
                <span class="text-neutral-400">Sensor Fusion SNR Gain</span>
                <span class="text-emerald-400 font-bold">{{ probe.snrGainDb }} dB</span>
              </div>
            </div>
          </div>

          <!-- Bottom Notice -->
          <div class="text-[11px] font-mono text-neutral-400 border-t border-neutral-800 pt-3 mt-3">
            Click or drag across the image stage to probe any optical coordinate in real time.
          </div>
        </div>
      </div>
    </div>
  `,
})
export class ApertureLabComponent {
  readonly engine = inject(CameraArrayEngineService);
  readonly imageStage = viewChild<ElementRef<HTMLDivElement>>('imageStage');

  readonly viewModes: { id: ViewModeId; label: string }[] = [
    { id: 'APERTURE_SYNTHESIS', label: 'Computational Aperture' },
    { id: 'MULTI_CAM_FUSED', label: 'Multi-Cam Fused' },
    { id: 'MAIN_SENSOR_ONLY', label: 'Main Sensor Only' },
    { id: 'STEREO_DEPTH', label: 'Stereo Depth Map' },
    { id: 'FUSION_WEIGHTS', label: 'Contribution Heatmap' },
    { id: 'SUPER_RESOLUTION', label: '2X Super-Resolution' },
  ];

  setViewMode(mode: ViewModeId): void {
    this.engine.outputViewMode.set(mode);
  }

  activeModeLabel(): string {
    const active = this.viewModes.find(m => m.id === this.engine.outputViewMode());
    return active ? active.label : 'Aperture Synthesis';
  }

  onFocusSliderChange(event: Event): void {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.engine.setFocusDistance(val);
  }

  onApertureSliderChange(event: Event): void {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.engine.setVirtualFNumber(val);
  }

  setBlades(count: number): void {
    this.engine.apertureConfig.update(c => ({ ...c, bladeCount: count }));
    this.engine.recalculatePixelProbe(this.engine.activePixelProbe().x, this.engine.activePixelProbe().y);
  }

  setSuperRes(factor: number): void {
    this.engine.fusionConfig.update(c => ({ ...c, superResolutionFactor: factor }));
  }

  onCanvasMouseMove(event: MouseEvent): void {
    const stageEl = this.imageStage()?.nativeElement;
    if (!stageEl) return;
    const rect = stageEl.getBoundingClientRect();
    const x = Math.round(event.clientX - rect.left);
    const y = Math.round(event.clientY - rect.top);
    this.engine.recalculatePixelProbe(x, y, rect.width, rect.height);
  }

  onCanvasClick(event: MouseEvent): void {
    this.onCanvasMouseMove(event);
  }

  onStageKeydown(): void {
    const stageEl = this.imageStage()?.nativeElement;
    if (!stageEl) return;
    const rect = stageEl.getBoundingClientRect();
    this.engine.recalculatePixelProbe(rect.width / 2, rect.height / 2, rect.width, rect.height);
  }

  // Dynamic CSS styling to simulate the physical optical transformation
  getImageFilterStyle(): string {
    const mode = this.engine.outputViewMode();
    const fNum = this.engine.apertureConfig().virtualFNumber;

    if (mode === 'MAIN_SENSOR_ONLY') {
      return 'filter: contrast(1.0) brightness(0.98) saturate(0.95);';
    } else if (mode === 'SUPER_RESOLUTION') {
      return 'filter: contrast(1.12) brightness(1.02) saturate(1.05); transform: scale(1.02);';
    } else if (mode === 'MULTI_CAM_FUSED') {
      return 'filter: contrast(1.08) brightness(1.01) saturate(1.04);';
    } else if (mode === 'APERTURE_SYNTHESIS') {
      // Simulate depth of field blur strength inversely proportional to f-number
      const blurPx = Math.max(0, (2.8 - fNum) * 1.5);
      return `filter: contrast(1.05) brightness(1.02) ${blurPx > 0.3 ? `blur(${blurPx.toFixed(1)}px)` : ''};`;
    }
    return '';
  }
}
