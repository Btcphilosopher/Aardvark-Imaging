import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CameraArrayEngineService } from '../../core/services/camera-array-engine.service';
import { CameraId } from '../../core/models/camera-array.model';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-array-3d-chassis',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="bg-neutral-900 border border-neutral-800 rounded-xl p-5 shadow-sm flex flex-col gap-5">
      <!-- Section Title & Status -->
      <div class="flex items-center justify-between border-b border-neutral-800 pb-3">
        <div>
          <h2 class="text-sm font-semibold text-neutral-100 uppercase tracking-wider flex items-center gap-2">
            <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">lens</mat-icon>
            Rigid Multi-Camera Array Geometry
          </h2>
          <p class="text-xs text-neutral-400 mt-0.5">
            Hardware baseline layout · SE(3) Euclidean pose graph · Optical axis convergence
          </p>
        </div>

        <div class="flex items-center gap-3 text-xs font-mono">
          <span class="text-neutral-400">ACTIVE SENSORS</span>
          <span class="text-cyan-400 font-bold bg-neutral-800 px-2 py-0.5 rounded border border-neutral-700">
            {{ activeCameraCount() }} / {{ engine.cameras().length }}
          </span>
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- 3D Camera Chassis Visualizer (Interactive SVG/Canvas Model) -->
        <div class="lg:col-span-6 bg-neutral-950 border border-neutral-800 rounded-lg p-4 flex flex-col items-center justify-center relative overflow-hidden min-h-[380px]">
          <!-- Grid Background -->
          <div class="absolute inset-0 subtle-grid opacity-30 pointer-events-none"></div>

          <!-- Phone Chassis Silhouette -->
          <div class="w-64 h-84 bg-neutral-900/90 border-2 border-neutral-700 rounded-3xl p-3 shadow-2xl relative flex flex-col items-center">
            <!-- Camera Island Glass Module -->
            <div class="w-full bg-neutral-950/80 border border-neutral-700/80 rounded-2xl p-4 shadow-inner relative flex flex-col items-center justify-center">
              
              <!-- Telephoto 70mm (Top) -->
              <button 
                type="button"
                aria-label="Inspect Telephoto 70mm camera module"
                (click)="selectCamera('camera.tele')"
                class="w-16 h-16 rounded-full border-2 transition-all cursor-pointer flex flex-col items-center justify-center relative group focus:outline-none focus:ring-2 focus:ring-cyan-400"
                [class]="selectedCameraId() === 'camera.tele' ? 'border-cyan-400 bg-cyan-950/40 shadow-lg shadow-cyan-950/50' : 'border-neutral-600 bg-neutral-900 hover:border-neutral-400'"
              >
                <!-- Lens Rim -->
                <div class="w-11 h-11 rounded-full border border-neutral-700 bg-neutral-950 flex items-center justify-center">
                  <div class="w-6 h-6 rounded-full bg-gradient-to-tr from-cyan-900/80 to-blue-900/60 border border-cyan-500/40"></div>
                </div>
                <span class="absolute -top-5 text-[10px] font-mono font-medium text-neutral-300">TELE 70mm</span>
                <!-- Active dot -->
                <div class="absolute top-1 right-1 w-2 h-2 rounded-full" [class]="isCameraActive('camera.tele') ? 'bg-emerald-400' : 'bg-neutral-600'"></div>
              </button>

              <!-- Mid Row: Main Wide (Left) & Ultra-Wide (Right) -->
              <div class="w-full flex items-center justify-between mt-3 px-1">
                <!-- Main Wide 24mm -->
                <button 
                  type="button"
                  aria-label="Inspect Main Wide 24mm camera module"
                  (click)="selectCamera('camera.main')"
                  class="w-18 h-18 rounded-full border-2 transition-all cursor-pointer flex flex-col items-center justify-center relative group focus:outline-none focus:ring-2 focus:ring-cyan-400"
                  [class]="selectedCameraId() === 'camera.main' ? 'border-cyan-400 bg-cyan-950/40 shadow-lg shadow-cyan-950/50' : 'border-neutral-600 bg-neutral-900 hover:border-neutral-400'"
                >
                  <div class="w-13 h-13 rounded-full border border-neutral-700 bg-neutral-950 flex items-center justify-center">
                    <div class="w-8 h-8 rounded-full bg-gradient-to-tr from-emerald-900/80 to-cyan-900/60 border border-emerald-500/40"></div>
                  </div>
                  <span class="absolute -bottom-5 text-[10px] font-mono font-medium text-neutral-300">MAIN 24mm</span>
                  <div class="absolute top-1 right-1 w-2 h-2 rounded-full" [class]="isCameraActive('camera.main') ? 'bg-emerald-400' : 'bg-neutral-600'"></div>
                </button>

                <!-- Ultra-Wide 13mm -->
                <button 
                  type="button"
                  aria-label="Inspect Ultra-Wide 13mm camera module"
                  (click)="selectCamera('camera.ultrawide')"
                  class="w-15 h-15 rounded-full border-2 transition-all cursor-pointer flex flex-col items-center justify-center relative group focus:outline-none focus:ring-2 focus:ring-cyan-400"
                  [class]="selectedCameraId() === 'camera.ultrawide' ? 'border-cyan-400 bg-cyan-950/40 shadow-lg shadow-cyan-950/50' : 'border-neutral-600 bg-neutral-900 hover:border-neutral-400'"
                >
                  <div class="w-10 h-10 rounded-full border border-neutral-700 bg-neutral-950 flex items-center justify-center">
                    <div class="w-6 h-6 rounded-full bg-gradient-to-tr from-amber-900/80 to-purple-900/60 border border-amber-500/40"></div>
                  </div>
                  <span class="absolute -bottom-5 text-[10px] font-mono font-medium text-neutral-300">ULTRA 13mm</span>
                  <div class="absolute top-1 right-1 w-2 h-2 rounded-full" [class]="isCameraActive('camera.ultrawide') ? 'bg-emerald-400' : 'bg-neutral-600'"></div>
                </button>
              </div>

              <!-- Depth dToF LiDAR (Bottom) -->
              <button 
                type="button"
                aria-label="Inspect Depth dToF LiDAR sensor"
                (click)="selectCamera('camera.depth')"
                class="w-10 h-10 rounded-full border transition-all cursor-pointer flex flex-col items-center justify-center mt-7 relative group focus:outline-none focus:ring-2 focus:ring-cyan-400"
                [class]="selectedCameraId() === 'camera.depth' ? 'border-cyan-400 bg-cyan-950/40' : 'border-neutral-700 bg-neutral-900 hover:border-neutral-500'"
              >
                <div class="w-6 h-6 rounded-full bg-neutral-950 border border-neutral-800 flex items-center justify-center">
                  <div class="w-3 h-3 rounded-full bg-purple-600/80"></div>
                </div>
                <span class="absolute -bottom-4 text-[9px] font-mono text-neutral-400">dToF / IR</span>
                <div class="absolute top-0.5 right-0.5 w-1.5 h-1.5 rounded-full" [class]="isCameraActive('camera.depth') ? 'bg-emerald-400' : 'bg-neutral-600'"></div>
              </button>

            </div>

            <!-- Optical Center Reference Crosshair -->
            <div class="mt-4 text-[11px] font-mono text-neutral-400 flex items-center gap-1.5">
              <span>REFERENCE OPTICAL ORIGIN:</span>
              <span class="text-neutral-200">CAMERA 0 (MAIN)</span>
            </div>
          </div>

          <!-- Ray Convergence Hint -->
          <div class="mt-4 text-xs font-mono text-neutral-400 flex items-center gap-2">
            <span class="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
            <span>Triangular Baseline: 20.8mm (Main-Tele) · 17.7mm (Main-Ultra)</span>
          </div>
        </div>

        <!-- Camera Module Deep Telemetry & Matrix Inspector -->
        <div class="lg:col-span-6 flex flex-col justify-between gap-4">
          @let cam = engine.selectedCamera();

          <div class="bg-neutral-950 border border-neutral-800 rounded-lg p-4">
            <!-- Header for Selected Camera -->
            <div class="flex items-center justify-between border-b border-neutral-800 pb-2.5 mb-3">
              <div class="flex items-center gap-2">
                <div class="w-3 h-3 rounded-full" [class]="cam.isActive ? 'bg-emerald-500' : 'bg-neutral-600'"></div>
                <span class="text-sm font-bold text-neutral-100 font-mono">{{ cam.name }}</span>
              </div>
              <button
                type="button"
                (click)="engine.toggleCamera(cam.id)"
                class="text-xs font-mono px-2.5 py-1 rounded transition-colors cursor-pointer"
                [class]="cam.isActive ? 'bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700' : 'bg-emerald-950 text-emerald-300 border border-emerald-800'"
              >
                {{ cam.isActive ? 'Bypass Sensor' : 'Engage Sensor' }}
              </button>
            </div>

            <!-- Sensor & Optical Specs Table -->
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4 text-xs font-mono">
              <div class="bg-neutral-900/70 p-2 rounded border border-neutral-800">
                <div class="text-[10px] text-neutral-400 uppercase">Focal Length</div>
                <div class="text-sm font-semibold text-neutral-200 mt-0.5">{{ cam.lens.focalLength35mmEq }} mm eq.</div>
                <div class="text-[10px] text-neutral-400">({{ cam.lens.focalLengthMm }} mm physical)</div>
              </div>

              <div class="bg-neutral-900/70 p-2 rounded border border-neutral-800">
                <div class="text-[10px] text-neutral-400 uppercase">Aperture</div>
                <div class="text-sm font-semibold text-cyan-400 mt-0.5">f/{{ cam.lens.fNumber }}</div>
                <div class="text-[10px] text-neutral-400">Pupil: {{ cam.lens.entrancePupilMm }} mm</div>
              </div>

              <div class="bg-neutral-900/70 p-2 rounded border border-neutral-800">
                <div class="text-[10px] text-neutral-400 uppercase">Sensor Format</div>
                <div class="text-sm font-semibold text-neutral-200 mt-0.5">{{ cam.sensor.sensorFormat }}</div>
                <div class="text-[10px] text-neutral-400">{{ cam.sensor.megapixel }} MP · {{ cam.sensor.pixelPitchMicrons }} µm</div>
              </div>

              <div class="bg-neutral-900/70 p-2 rounded border border-neutral-800">
                <div class="text-[10px] text-neutral-400 uppercase">Est. SNR / Temp</div>
                <div class="text-sm font-semibold text-emerald-400 mt-0.5">{{ cam.snrDb }} dB</div>
                <div class="text-[10px] text-neutral-400">{{ cam.sensor.temperatureCelsius }} °C</div>
              </div>
            </div>

            <!-- Intrinsic Calibration Matrix (K) & Distortion -->
            <div class="mb-3">
              <div class="text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1 flex items-center justify-between font-mono">
                <span>Intrinsic Camera Matrix (K)</span>
                <span class="text-emerald-400 text-[11px]">RMS: {{ cam.intrinsics.rmsReprojectionErrorPx }} px</span>
              </div>
              <div class="bg-neutral-900 p-2.5 rounded border border-neutral-800 font-mono text-xs text-neutral-300">
                <div class="flex justify-between py-0.5">
                  <span>[ fx: {{ cam.intrinsics.fx.toFixed(1) }}</span>
                  <span>skew: {{ cam.intrinsics.skew.toFixed(3) }}</span>
                  <span>cx: {{ cam.intrinsics.cx.toFixed(1) }} ]</span>
                </div>
                <div class="flex justify-between py-0.5">
                  <span>[  0.00</span>
                  <span>fy: {{ cam.intrinsics.fy.toFixed(1) }}</span>
                  <span>cy: {{ cam.intrinsics.cy.toFixed(1) }} ]</span>
                </div>
                <div class="flex justify-between py-0.5">
                  <span>[  0.00</span>
                  <span>0.00</span>
                  <span>1.00 ]</span>
                </div>
              </div>
            </div>

            <!-- Brown-Conrady Radial Distortion Coefficients -->
            <div class="mb-3">
              <div class="text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1 font-mono">
                Brown-Conrady Distortion (k1, k2, k3, p1, p2)
              </div>
              <div class="grid grid-cols-5 gap-1.5 font-mono text-xs text-neutral-300">
                <div class="bg-neutral-900 p-1.5 rounded border border-neutral-800 text-center">
                  <span class="text-[10px] text-neutral-400 block">k1</span>
                  {{ cam.intrinsics.k1 }}
                </div>
                <div class="bg-neutral-900 p-1.5 rounded border border-neutral-800 text-center">
                  <span class="text-[10px] text-neutral-400 block">k2</span>
                  {{ cam.intrinsics.k2 }}
                </div>
                <div class="bg-neutral-900 p-1.5 rounded border border-neutral-800 text-center">
                  <span class="text-[10px] text-neutral-400 block">k3</span>
                  {{ cam.intrinsics.k3 }}
                </div>
                <div class="bg-neutral-900 p-1.5 rounded border border-neutral-800 text-center">
                  <span class="text-[10px] text-neutral-400 block">p1</span>
                  {{ cam.intrinsics.p1 }}
                </div>
                <div class="bg-neutral-900 p-1.5 rounded border border-neutral-800 text-center">
                  <span class="text-[10px] text-neutral-400 block">p2</span>
                  {{ cam.intrinsics.p2 }}
                </div>
              </div>
            </div>

            <!-- Extrinsic SE(3) Rigid Pose Relative to Main -->
            <div>
              <div class="text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1 flex items-center justify-between font-mono">
                <span>Extrinsic SE(3) Translation [Tx, Ty, Tz] & Rotation</span>
                <span class="text-cyan-400 text-[11px]">Baseline: {{ cam.extrinsics.baselineFromMainMm }} mm</span>
              </div>
              <div class="bg-neutral-900 p-2 rounded border border-neutral-800 font-mono text-xs text-neutral-300 flex items-center justify-between">
                <span>T = [ {{ cam.extrinsics.translationMm[0] }}mm, {{ cam.extrinsics.translationMm[1] }}mm, {{ cam.extrinsics.translationMm[2] }}mm ]</span>
                <span class="text-neutral-400">Pitch {{ cam.extrinsics.eulerDeg.pitch }}° · Yaw {{ cam.extrinsics.eulerDeg.yaw }}°</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class Array3DChassisComponent {
  readonly engine = inject(CameraArrayEngineService);

  selectedCameraId(): CameraId {
    return this.engine.selectedCameraId();
  }

  selectCamera(id: CameraId): void {
    this.engine.selectedCameraId.set(id);
  }

  isCameraActive(id: CameraId): boolean {
    return !!this.engine.cameras().find(c => c.id === id)?.isActive;
  }

  activeCameraCount(): number {
    return this.engine.cameras().filter(c => c.isActive).length;
  }
}
