import { ChangeDetectionStrategy, Component, inject, output, signal } from '@angular/core';
import { CameraArrayEngineService } from '../../core/services/camera-array-engine.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-header',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <header class="w-full bg-neutral-900 border-b border-neutral-800 sticky top-0 z-50">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-4">
        <!-- Zone 1: Single text element wordmark -->
        <div class="flex items-center gap-3 shrink-0">
          <div class="w-7 h-7 bg-neutral-800 border border-neutral-700 rounded-lg flex items-center justify-center text-cyan-400 font-mono text-xs font-bold">
            A
          </div>
          <span class="text-sm font-semibold tracking-wider text-neutral-100 uppercase">
            Aardvark Camera Array.OS
          </span>
        </div>

        <!-- Zone 2: Navigation Links -->
        <nav class="hidden md:flex items-center gap-1 text-xs font-medium">
          @for (tab of navTabs; track tab.id) {
            <button
              (click)="onSelectTab(tab.id)"
              class="px-3 py-1.5 rounded-md transition-colors whitespace-nowrap cursor-pointer"
              [class]="activeTab() === tab.id ? 'bg-neutral-800 text-cyan-400 font-semibold shadow-sm' : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'"
            >
              {{ tab.label }}
            </button>
          }
        </nav>

        <!-- Zone 3: Actions & Scene Selector -->
        <div class="flex items-center gap-2 shrink-0">
          <!-- Scene Selector -->
          <div class="relative">
            <select
              [value]="engine.activeScene().id"
              (change)="onSceneChange($event)"
              class="bg-neutral-800 border border-neutral-700 text-neutral-200 text-xs rounded-md px-2.5 py-1.5 pr-8 focus:outline-none focus:border-cyan-500 font-mono cursor-pointer"
            >
              @for (scene of engine.availableScenes; track scene.id) {
                <option [value]="scene.id">{{ scene.name }}</option>
              }
            </select>
            <mat-icon class="!w-4 !h-4 !text-base absolute right-2 top-1.5 text-neutral-400 pointer-events-none">arrow_drop_down</mat-icon>
          </div>

          <!-- Export .aarray Project Action -->
          <button
            (click)="exportAArrayProject()"
            class="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-900 bg-cyan-400 hover:bg-cyan-300 rounded-md transition-colors whitespace-nowrap shadow-sm cursor-pointer"
          >
            <mat-icon class="!w-4 !h-4 !text-base">download</mat-icon>
            <span>Export .aarray</span>
          </button>
        </div>
      </div>
    </header>
  `,
})
export class HeaderComponent {
  readonly engine = inject(CameraArrayEngineService);
  readonly tabSelected = output<string>();

  readonly navTabs = [
    { id: 'array_studio', label: 'Array Studio' },
    { id: 'aperture_lab', label: 'Aperture Lab' },
    { id: 'sync_lab', label: 'Sync & Jitter Lab' },
    { id: 'calibration_lab', label: 'Calibration & Residuals' },
    { id: 'platform_adapters', label: 'Platform Adapters' },
    { id: 'provenance_sdk', label: 'SDK & Provenance' },
  ];

  activeTab = signal<string>('array_studio');

  onSelectTab(tabId: string): void {
    this.activeTab.set(tabId);
    this.tabSelected.emit(tabId);
  }

  onSceneChange(event: Event): void {
    const select = event.target as HTMLSelectElement;
    this.engine.setScene(select.value);
  }

  exportAArrayProject(): void {
    const metadata = this.engine.generateAArrayExport();
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(metadata, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${metadata.projectId}_camera_array.aarray.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  }
}
