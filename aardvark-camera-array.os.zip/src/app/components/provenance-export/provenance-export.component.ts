import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CameraArrayEngineService } from '../../core/services/camera-array-engine.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-provenance-export',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Top Console Header -->
      <div class="bg-neutral-900 border border-neutral-800 rounded-xl p-5 shadow-sm">
        <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-neutral-800 pb-4">
          <div>
            <h2 class="text-sm font-semibold text-neutral-100 uppercase tracking-wider flex items-center gap-2">
              <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">terminal</mat-icon>
              Python Research API, CLI & .aarray Container Provenance
            </h2>
            <p class="text-xs text-neutral-400 mt-0.5">
              Production SDK bindings · Versioned container format · Command-line research utilities
            </p>
          </div>

          <!-- Section Switcher -->
          <div class="flex items-center gap-1 bg-neutral-950 p-1 rounded-lg border border-neutral-800">
            <button
              (click)="activeTab.set('PYTHON')"
              class="px-3 py-1.5 text-xs font-mono rounded transition-colors cursor-pointer"
              [class]="activeTab() === 'PYTHON' ? 'bg-neutral-800 text-cyan-300 font-bold border border-neutral-700' : 'text-neutral-400 hover:text-neutral-200'"
            >
              Python Research API
            </button>
            <button
              (click)="activeTab.set('CLI')"
              class="px-3 py-1.5 text-xs font-mono rounded transition-colors cursor-pointer"
              [class]="activeTab() === 'CLI' ? 'bg-neutral-800 text-cyan-300 font-bold border border-neutral-700' : 'text-neutral-400 hover:text-neutral-200'"
            >
              CLI Tools
            </button>
            <button
              (click)="activeTab.set('AARRAY')"
              class="px-3 py-1.5 text-xs font-mono rounded transition-colors cursor-pointer"
              [class]="activeTab() === 'AARRAY' ? 'bg-neutral-800 text-cyan-300 font-bold border border-neutral-700' : 'text-neutral-400 hover:text-neutral-200'"
            >
              .aarray Container JSON
            </button>
          </div>
        </div>

        <!-- SDK Overview Banner -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4 font-mono text-xs">
          <div class="bg-neutral-950 p-3 rounded-lg border border-neutral-800">
            <span class="text-[10px] text-neutral-400 uppercase block">SDK Core</span>
            <span class="text-sm font-bold text-neutral-200 mt-1 block">aardvark-camera-array v3.8</span>
            <span class="text-[10px] text-emerald-400">C++20 Engine + PyBind11</span>
          </div>

          <div class="bg-neutral-950 p-3 rounded-lg border border-neutral-800">
            <span class="text-[10px] text-neutral-400 uppercase block">Provenance Hash</span>
            <span class="text-sm font-bold text-cyan-400 mt-1 block font-mono">0x8F4A...B29C</span>
            <span class="text-[10px] text-neutral-400">Immutable Cryptographic Audit</span>
          </div>

          <div class="bg-neutral-950 p-3 rounded-lg border border-neutral-800">
            <span class="text-[10px] text-neutral-400 uppercase block">Format Version</span>
            <span class="text-sm font-bold text-neutral-200 mt-1 block">AARRAY_SCHEMA_V1.4</span>
            <span class="text-[10px] text-neutral-400">DNG + Multi-Sensor JSON</span>
          </div>
        </div>
      </div>

      <!-- Main Code & Inspection Panel -->
      <div class="bg-neutral-950 border border-neutral-800 rounded-xl p-5 shadow-sm">
        @if (activeTab() === 'PYTHON') {
          <div class="space-y-3">
            <div class="flex items-center justify-between border-b border-neutral-800 pb-2">
              <span class="text-xs font-mono text-cyan-400 font-bold">research_pipeline_experiment.py</span>
              <span class="text-[11px] font-mono text-neutral-400">Python 3.11+ / NumPy / PyTorch</span>
            </div>

            <pre class="bg-neutral-900 p-4 rounded-lg border border-neutral-800 font-mono text-xs text-neutral-200 overflow-x-auto leading-relaxed whitespace-pre">{{ pythonCode }}</pre>
          </div>
        } @else if (activeTab() === 'CLI') {
          <div class="space-y-4">
            <div class="flex items-center justify-between border-b border-neutral-800 pb-2">
              <span class="text-xs font-mono text-cyan-400 font-bold">Aardvark Array CLI Utility Manual</span>
              <span class="text-[11px] font-mono text-neutral-400">Terminal Commands</span>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
              <div class="bg-neutral-900 p-3 rounded-lg border border-neutral-800">
                <div class="text-cyan-400 font-bold mb-1">$ aardvark-array inspect phone.aarray</div>
                <p class="text-neutral-400 text-[11px]">Inspects camera calibration, baseline geometry, and sensor hardware parameters.</p>
              </div>

              <div class="bg-neutral-900 p-3 rounded-lg border border-neutral-800">
                <div class="text-cyan-400 font-bold mb-1">$ aardvark-array calibrate dataset/ --charuco</div>
                <p class="text-neutral-400 text-[11px]">Runs ChArUco / AprilTag multi-camera intrinsic & extrinsic SE(3) calibration solver.</p>
              </div>

              <div class="bg-neutral-900 p-3 rounded-lg border border-neutral-800">
                <div class="text-cyan-400 font-bold mb-1">$ aardvark-array sync dataset/ --pll-lock</div>
                <p class="text-neutral-400 text-[11px]">Calculates cross-correlation frame offsets and computes monotonic timestamp normalisation.</p>
              </div>

              <div class="bg-neutral-900 p-3 rounded-lg border border-neutral-800">
                <div class="text-cyan-400 font-bold mb-1">$ aardvark-array depth dataset/ --dtof-fuse</div>
                <p class="text-neutral-400 text-[11px]">Executes multi-baseline stereo disparity matching fused with dToF LiDAR surface maps.</p>
              </div>

              <div class="bg-neutral-900 p-3 rounded-lg border border-neutral-800">
                <div class="text-cyan-400 font-bold mb-1">$ aardvark-array fuse dataset/ --superres 2.0</div>
                <p class="text-neutral-400 text-[11px]">Fuses wide, telephoto, and ultra-wide frames with subpixel resolution reconstruction.</p>
              </div>

              <div class="bg-neutral-900 p-3 rounded-lg border border-neutral-800">
                <div class="text-cyan-400 font-bold mb-1">$ aardvark-array aperture --focus 0.8 --fnum 1.4</div>
                <p class="text-neutral-400 text-[11px]">Renders synthetic computational entrance pupil with physically modeled depth-of-field PSF.</p>
              </div>
            </div>
          </div>
        } @else {
          <div class="space-y-3">
            <div class="flex items-center justify-between border-b border-neutral-800 pb-2">
              <span class="text-xs font-mono text-cyan-400 font-bold">Metadata Container Manifest (.aarray)</span>
              <span class="text-[11px] font-mono text-emerald-400">JSON Schema v1.4</span>
            </div>

            <pre class="bg-neutral-900 p-4 rounded-lg border border-neutral-800 font-mono text-xs text-neutral-300 overflow-x-auto max-h-[340px] whitespace-pre">{{ exportJson() }}</pre>
          </div>
        }
      </div>
    </div>
  `,
})
export class ProvenanceExportComponent {
  readonly engine = inject(CameraArrayEngineService);
  activeTab = signal<'PYTHON' | 'CLI' | 'AARRAY'>('PYTHON');

  readonly pythonCode = `import aardvark_array as aa
import numpy as np

# 1. Load physical smartphone camera array container
array = aa.CameraArray.load("phone_quad_array.aarray")
print(f"Loaded array with {len(array.cameras)} physical modules")

# 2. Capture hardware-synchronized multi-sensor frame set
frames = array.capture(
    exposure_mode="bracketed_hdr",
    enable_imu_fusion=True,
    depth_aux=True
)

# 3. Microsecond timestamp synchronization & clock drift PLL correction
sync_set = aa.synchronize(
    frames,
    clock_model=aa.ClockModel.HARDWARE_CALIBRATED,
    max_jitter_tolerance_ms=0.5
)
print(f"Synchronization locked: timing error = {sync_set.timing_error_ns / 1000:.2f} µs")

# 4. Epipolar geometric registration and stereo disparity estimation
calibration = aa.calibrate(array)
depth_map = aa.estimate_depth(
    sync_set,
    calibration,
    algorithm=aa.DepthAlgorithm.SEMI_GLOBAL_STEREO_DTOF
)

# 5. Multi-sensor polyphase optimal fusion
fused_linear = aa.fuse(
    sync_set,
    calibration,
    depth_map,
    weights_config=aa.FusionWeights(
        sharpness=0.40,
        snr=0.25,
        parallax_tolerance=0.15
    )
)

# 6. Signature Computational Aperture Synthesis
bokeh_reconstructed = aa.computational_aperture(
    fused_linear,
    depth_map=depth_map,
    focus_distance_m=0.8,
    virtual_aperture=1.4,
    blade_count=9,
    bokeh_highlight_gain=1.4
)

# Save linear research buffer with embedded provenance metadata
aa.save("output_aperture_f1.4.dng", bokeh_reconstructed, provenance=True)`;

  exportJson(): string {
    return JSON.stringify(this.engine.generateAArrayExport(), null, 2);
  }
}
