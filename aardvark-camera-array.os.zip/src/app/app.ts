import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CameraArrayEngineService } from './core/services/camera-array-engine.service';
import { HeaderComponent } from './components/header/header.component';
import { Array3DChassisComponent } from './components/array-3d-chassis/array-3d-chassis.component';
import { ApertureLabComponent } from './components/aperture-lab/aperture-lab.component';
import { SyncLabComponent } from './components/sync-lab/sync-lab.component';
import { CalibrationLabComponent } from './components/calibration-lab/calibration-lab.component';
import { PlatformAdaptersComponent } from './components/platform-adapters/platform-adapters.component';
import { ProvenanceExportComponent } from './components/provenance-export/provenance-export.component';
import { PipelineGraphComponent } from './components/pipeline-graph/pipeline-graph.component';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-root',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    HeaderComponent,
    Array3DChassisComponent,
    ApertureLabComponent,
    SyncLabComponent,
    CalibrationLabComponent,
    PlatformAdaptersComponent,
    ProvenanceExportComponent,
    PipelineGraphComponent,
    MatIconModule,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  readonly engine = inject(CameraArrayEngineService);
  activeTab = signal<string>('array_studio');

  onTabSelected(tabId: string): void {
    this.activeTab.set(tabId);
  }
}
