import { ColourRecord, Palette } from '../types/colour';
import { createColourFromHex } from '../core/colour-math';

export const MASTER_COLOUR_LIBRARY: ColourRecord[] = [
  // Industrial & Modernist Precision
  createColourFromHex('#D96B24', 'Hard Industrial Orange', {
    category: 'Industrial',
    tags: ['industrial', 'orange', 'warm', 'machinery', 'aureom'],
    description: 'High-visibility industrial orange with balanced OKLCh chroma. The core signature tone of AUREOM.',
  }),
  createColourFromHex('#121417', 'Graphite Black', {
    category: 'Industrial',
    tags: ['neutral', 'dark', 'graphite', 'surface', 'chassis'],
    description: 'Deep carbon neutral background with 5% cool undertone.',
  }),
  createColourFromHex('#8E959F', 'Aluminium Grey', {
    category: 'Industrial',
    tags: ['neutral', 'metal', 'aluminium', 'mid-tone'],
    description: 'Anodised milled aluminium tone with uniform spectral reflection.',
  }),
  createColourFromHex('#F5F3EE', 'Warm Technical White', {
    category: 'Industrial',
    tags: ['neutral', 'light', 'white', 'background', 'typography'],
    description: 'Calibrated architectural off-white designed for glare-free reading.',
  }),
  createColourFromHex('#C8B9A6', 'Pale Sandstone', {
    category: 'Architectural',
    tags: ['architectural', 'mineral', 'sandstone', 'warm', 'neutral'],
    description: 'Natural quartz-rich sandstone neutral with tactile organic warmth.',
  }),
  createColourFromHex('#4A5568', 'Muted Blue-Grey', {
    category: 'Industrial',
    tags: ['industrial', 'slate', 'blue', 'secondary', 'cold'],
    description: 'Heavy machinery cold grey used in structural framing.',
  }),
  createColourFromHex('#0F2A4A', 'Deep Maritime Blue', {
    category: 'Maritime',
    tags: ['maritime', 'navy', 'deep', 'ocean', 'aerospace'],
    description: 'Sub-sea deep navy with profound light absorption and high contrast against orange.',
  }),
  createColourFromHex('#2C7A7B', 'Oxidised Copper Patina', {
    category: 'Architectural',
    tags: ['copper', 'patina', 'verdigris', 'mineral', 'green'],
    description: 'Naturally aged copper carbonate verdigris with matte mineral feel.',
  }),
  createColourFromHex('#E53E3E', 'Signal Red', {
    category: 'Safety & System',
    tags: ['signal', 'red', 'danger', 'alert', 'iso'],
    description: 'ISO-compliant high-luminance danger and emergency stop signal.',
  }),
  createColourFromHex('#DD6B20', 'Technical Amber', {
    category: 'Safety & System',
    tags: ['amber', 'warning', 'caution', 'industrial'],
    description: 'Advisory warning beacon amber with optimal eye sensitivity.',
  }),

  // Architectural Minerals
  createColourFromHex('#5C5852', 'Cast Concrete Ash', {
    category: 'Architectural',
    tags: ['concrete', 'mineral', 'stone', 'architectural'],
    description: 'Smooth cast concrete with subtle portland cement aggregate tone.',
  }),
  createColourFromHex('#2D3748', 'Milled Dark Slate', {
    category: 'Architectural',
    tags: ['slate', 'stone', 'dark', 'roofing'],
    description: 'Fine-grain metamorphic slate with high density and low sheen.',
  }),
  createColourFromHex('#8B4513', 'Architectural Terracotta', {
    category: 'Architectural',
    tags: ['terracotta', 'clay', 'ceramic', 'facade'],
    description: 'Kiln-fired earthenware facade tile tone.',
  }),
  createColourFromHex('#1A202C', 'Obsidian Basalt', {
    category: 'Architectural',
    tags: ['obsidian', 'basalt', 'volcanic', 'dark'],
    description: 'Vitreous volcanic glass with near-complete light absorption.',
  }),

  // Aerospace & High-Tech
  createColourFromHex('#63B3ED', 'Stratosphere Cyan', {
    category: 'Aerospace',
    tags: ['cyan', 'sky', 'aerospace', 'hud', 'telemetry'],
    description: 'High-altitude sky luminance used for avionics HUD elements.',
  }),
  createColourFromHex('#48BB78', 'Precision Radar Green', {
    category: 'Aerospace',
    tags: ['green', 'radar', 'phosphor', 'telemetry'],
    description: 'P43 phosphor CRT radar emission with peak 544nm wavelength.',
  }),
  createColourFromHex('#9F7AEA', 'Titanium Ion Purple', {
    category: 'Aerospace',
    tags: ['titanium', 'ion', 'anodised', 'exotic'],
    description: 'Thin-film dielectric interference colour on electro-polished titanium.',
  }),

  // Modernist Art & Heritage
  createColourFromHex('#002FA7', 'International Klein Blue', {
    category: 'Modernist',
    tags: ['klein', 'ultramarine', 'modernist', 'synthetic'],
    description: 'Synthetic ultramarine suspended in Rhodopas M matte resin.',
  }),
  createColourFromHex('#F6E05E', 'Bauhaus Signal Yellow', {
    category: 'Modernist',
    tags: ['bauhaus', 'yellow', 'primary', 'modernist'],
    description: 'High-contrast primary yellow from Kandinsky-Itten colour theory.',
  }),
  createColourFromHex('#C53030', 'Constructivist Crimson', {
    category: 'Modernist',
    tags: ['constructivist', 'red', 'poster', 'soviet-modernism'],
    description: 'Deep lithographic ink red with strong opacity.',
  }),
];

export const INITIAL_AUREOM_PALETTE: Palette = {
  id: 'palette-aureom-industrial',
  name: 'AUREOM / Industrial Palette System',
  description:
    'A precision industrial palette system designed for heavy engineering interfaces, modernist hardware chassis, and high-visibility digital workstations.',
  category: 'brand',
  version: '1.4.0',
  author: 'Chroma Engineering Group',
  createdAt: '2026-03-01T08:00:00.000Z',
  updatedAt: '2026-09-19T02:00:00.000Z',
  tags: ['industrial', 'aureom', 'brand', 'design-tokens', 'supermodernist'],
  colours: [
    {
      id: 'pc-1',
      role: 'accent',
      colour: MASTER_COLOUR_LIBRARY[0], // Hard Industrial Orange (#D96B24)
      notes: 'Primary brand focal anchor; interactive CTA and state trigger.',
      locked: true,
    },
    {
      id: 'pc-2',
      role: 'background',
      colour: MASTER_COLOUR_LIBRARY[1], // Graphite Black (#121417)
      notes: 'Primary dark workspace canvas and chassis tone.',
      locked: true,
    },
    {
      id: 'pc-3',
      role: 'surface',
      colour: createColourFromHex('#1C1F24', 'Graphite Elevated Surface'),
      notes: 'Elevated tool cards, floating inspector panels and modals.',
    },
    {
      id: 'pc-4',
      role: 'text-primary',
      colour: MASTER_COLOUR_LIBRARY[3], // Warm Technical White (#F5F3EE)
      notes: 'High-contrast typography for critical readouts and headings.',
      locked: true,
    },
    {
      id: 'pc-5',
      role: 'text-secondary',
      colour: MASTER_COLOUR_LIBRARY[2], // Aluminium Grey (#8E959F)
      notes: 'Secondary labels, coordinate axes, and technical captions.',
    },
    {
      id: 'pc-6',
      role: 'border',
      colour: createColourFromHex('#2A2E37', 'Technical Grid Line'),
      notes: '1px hairline dividing borders and inspection graticules.',
    },
    {
      id: 'pc-7',
      role: 'success',
      colour: createColourFromHex('#38A169', 'Calibrated Emerald'),
      notes: 'Gamut valid, WCAG AAA compliant, system nominal state.',
    },
    {
      id: 'pc-8',
      role: 'warning',
      colour: MASTER_COLOUR_LIBRARY[9], // Technical Amber (#DD6B20)
      notes: 'Gamut boundary proximity and low-contrast warnings.',
    },
    {
      id: 'pc-9',
      role: 'danger',
      colour: MASTER_COLOUR_LIBRARY[8], // Signal Red (#E53E3E)
      notes: 'Out-of-gamut clipping and critical accessibility violations.',
    },
    {
      id: 'pc-10',
      role: 'information',
      colour: MASTER_COLOUR_LIBRARY[6], // Deep Maritime Blue (#0F2A4A)
      notes: 'Telemetry overlays, reference frames, and data anchors.',
    },
  ],
};
