'use client';

import React, { useState } from 'react';
import { useColourStore } from '../../state/colour-store';
import { Printer, AlertTriangle, Layers } from 'lucide-react';

export function PrintProductionView() {
  const { state } = useColourStore();
  const [paperType, setPaperType] = useState<'coated' | 'uncoated' | 'kraft'>('coated');

  const curr = state.currentColour;
  const totalInk = curr.cmyk.c + curr.cmyk.m + curr.cmyk.y + curr.cmyk.k;
  const isHighTac = totalInk > 300;

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono text-xs">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#22262e] pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-[#ff5500] text-black font-bold px-1.5 py-0.5 rounded-xs text-[10px]">
              15
            </span>
            <h1 className="text-lg font-bold tracking-tight text-white uppercase">
              Print & Production Laboratory // CMYK & Substrate Physics
            </h1>
          </div>
          <p className="text-[#8e94a0] text-[11px] mt-0.5">
            Four-color process separation (FOGRA51 / GRACol 2013), total ink coverage (TAC/TIC) limits, and paper substrate simulations.
          </p>
        </div>

        <div className="flex items-center bg-[#171a20] border border-[#262a33] rounded-xs p-1 text-[11px]">
          <span className="text-[#8e94a0] mr-2 pl-1">SUBSTRATE:</span>
          {(['coated', 'uncoated', 'kraft'] as const).map((p) => (
            <button
              key={p}
              onClick={() => setPaperType(p)}
              className={`px-3 py-1 rounded-xs uppercase font-bold cursor-pointer transition-colors ${
                paperType === p ? 'bg-[#ff5500] text-white' : 'text-[#8e94a0] hover:text-white'
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* CMYK Separations (7 Cols) */}
        <div className="lg:col-span-7 bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-4">
          <span className="font-semibold text-white tracking-wider">
            FOUR-COLOUR PROCESS SEPARATION
          </span>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-[#101216] border border-[#22262e] p-3 rounded-xs space-y-1">
              <div className="text-[#00ffff] font-bold">CYAN (C)</div>
              <div className="text-2xl font-bold text-white">{curr.cmyk.c}%</div>
              <div className="w-full bg-[#1c2028] h-1.5 rounded-full overflow-hidden">
                <div className="bg-[#00ffff] h-full" style={{ width: `${curr.cmyk.c}%` }} />
              </div>
            </div>

            <div className="bg-[#101216] border border-[#22262e] p-3 rounded-xs space-y-1">
              <div className="text-[#ff00ff] font-bold">MAGENTA (M)</div>
              <div className="text-2xl font-bold text-white">{curr.cmyk.m}%</div>
              <div className="w-full bg-[#1c2028] h-1.5 rounded-full overflow-hidden">
                <div className="bg-[#ff00ff] h-full" style={{ width: `${curr.cmyk.m}%` }} />
              </div>
            </div>

            <div className="bg-[#101216] border border-[#22262e] p-3 rounded-xs space-y-1">
              <div className="text-[#ffff00] font-bold">YELLOW (Y)</div>
              <div className="text-2xl font-bold text-white">{curr.cmyk.y}%</div>
              <div className="w-full bg-[#1c2028] h-1.5 rounded-full overflow-hidden">
                <div className="bg-[#ffff00] h-full" style={{ width: `${curr.cmyk.y}%` }} />
              </div>
            </div>

            <div className="bg-[#101216] border border-[#22262e] p-3 rounded-xs space-y-1">
              <div className="text-[#a0aec0] font-bold">BLACK (K)</div>
              <div className="text-2xl font-bold text-white">{curr.cmyk.k}%</div>
              <div className="w-full bg-[#1c2028] h-1.5 rounded-full overflow-hidden">
                <div className="bg-[#a0aec0] h-full" style={{ width: `${curr.cmyk.k}%` }} />
              </div>
            </div>
          </div>

          {/* Paper Substrate Simulation Field */}
          <div className="space-y-2 pt-2">
            <span className="text-[#8e94a0]">Substrate Texture & Ink Absorption Simulation</span>
            <div
              className={`h-36 rounded-xs border border-black/20 p-4 flex items-center justify-center shadow-inner ${
                paperType === 'coated'
                  ? 'bg-[#ffffff] text-black'
                  : paperType === 'uncoated'
                  ? 'bg-[#f4efe6] text-black'
                  : 'bg-[#d8c39e] text-black'
              }`}
            >
              <div
                className="w-32 h-20 rounded-xs shadow-md flex items-center justify-center font-bold text-white text-xs border border-black/10"
                style={{
                  backgroundColor: curr.hex,
                  opacity: paperType === 'uncoated' ? 0.88 : paperType === 'kraft' ? 0.78 : 1.0,
                }}
              >
                {curr.hex}
              </div>
            </div>
          </div>
        </div>

        {/* Press Inspection Matrix (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-3">
            <span className="font-semibold text-white tracking-wider">
              PRESS COVERAGE AUDIT
            </span>

            <div className="space-y-2 text-[11px]">
              <div className="flex justify-between p-2 rounded-xs bg-[#101216] border border-[#1e222b]">
                <span className="text-[#8e94a0]">Total Ink Limit (TAC):</span>
                <span className={`font-bold ${isHighTac ? 'text-[#e53e3e]' : 'text-[#38a169]'}`}>
                  {totalInk}% (Max 300%)
                </span>
              </div>
              <div className="flex justify-between p-2 rounded-xs bg-[#101216] border border-[#1e222b]">
                <span className="text-[#8e94a0]">Rich Black Candidate:</span>
                <span className="text-white font-bold">
                  {curr.luminance < 0.1 ? 'YES (C:60 M:40 Y:40 K:100)' : 'NO'}
                </span>
              </div>
              <div className="flex justify-between p-2 rounded-xs bg-[#101216] border border-[#1e222b]">
                <span className="text-[#8e94a0]">Spot Color Equivalent:</span>
                <span className="text-[#ff5500] font-bold">Pantone Solid Coated Approx</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
