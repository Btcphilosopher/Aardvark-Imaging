'use client';

import React, { useState } from 'react';
import { useColourStore } from '../../state/colour-store';
import { Compass, Plus, Copy, Check } from 'lucide-react';
import { generateHarmonies } from '../../core/harmonies';
import { ColourRecord } from '../../types/colour';

export function HarmoniesView() {
  const { state, setCurrentColour, addPaletteColour } = useColourStore();
  const [space, setSpace] = useState<'oklch' | 'lch' | 'hsl'>('oklch');
  const [copiedHex, setCopiedHex] = useState<string | null>(null);

  const harmonies = generateHarmonies(state.currentColour, space);

  const handleCopy = (hex: string) => {
    navigator.clipboard.writeText(hex);
    setCopiedHex(hex);
    setTimeout(() => setCopiedHex(null), 1500);
  };

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono text-xs">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#22262e] pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-[#ff5500] text-black font-bold px-1.5 py-0.5 rounded-xs text-[10px]">
              04
            </span>
            <h1 className="text-lg font-bold tracking-tight text-white uppercase">
              Harmonies // Geometric & Perceptual Systems
            </h1>
          </div>
          <p className="text-[#8e94a0] text-[11px] mt-0.5">
            Polar geometric chord relationships computed in uniform OKLCh, CIELCh, and classic HSL.
          </p>
        </div>

        {/* Space Selector */}
        <div className="flex items-center bg-[#171a20] border border-[#262a33] rounded-xs p-1 text-[11px]">
          <span className="text-[#8e94a0] mr-2 pl-1">COMPUTATION SPACE:</span>
          {(['oklch', 'lch', 'hsl'] as const).map((s) => (
            <button
              key={s}
              onClick={() => setSpace(s)}
              className={`px-2.5 py-1 rounded-xs uppercase font-bold cursor-pointer transition-colors ${
                space === s
                  ? 'bg-[#ff5500] text-white'
                  : 'text-[#8e94a0] hover:text-white'
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Harmonies List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {harmonies.map((h) => (
          <div
            key={h.type}
            className="bg-[#14171d] border border-[#242831] rounded-sm p-4 flex flex-col justify-between space-y-4"
          >
            <div>
              <div className="flex items-center justify-between">
                <span className="font-bold text-white text-sm tracking-wide">
                  {h.title}
                </span>
                <span className="text-[#ff5500] text-[10px] font-bold">
                  {h.angles.map((a) => (a >= 0 ? `+${a}°` : `${a}°`)).join(' / ')}
                </span>
              </div>
              <p className="text-[#8e94a0] text-[11px] mt-1 leading-relaxed">
                {h.description}
              </p>
            </div>

            {/* Swatches Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2">
              {h.colours.map((col, idx) => (
                <div
                  key={idx}
                  className="bg-[#101216] border border-[#22262e] rounded-xs p-2 flex flex-col space-y-2 group"
                >
                  <div
                    className="h-16 rounded-xs border border-white/10 shadow-inner cursor-pointer relative"
                    style={{ backgroundColor: col.hex }}
                    onClick={() => setCurrentColour(col)}
                    title="Click to set as current workstation colour"
                  />

                  <div className="flex items-center justify-between text-[10px]">
                    <span className="font-mono text-white font-semibold">
                      {col.hex}
                    </span>
                    <button
                      onClick={() => handleCopy(col.hex)}
                      className="text-[#646a78] hover:text-white p-0.5 cursor-pointer"
                    >
                      {copiedHex === col.hex ? (
                        <Check className="w-3 h-3 text-[#38a169]" />
                      ) : (
                        <Copy className="w-3 h-3" />
                      )}
                    </button>
                  </div>

                  <button
                    onClick={() => addPaletteColour(col, h.type)}
                    className="w-full bg-[#171a22] hover:bg-[#252b36] border border-[#262a33] text-[#c5c8d0] hover:text-white py-0.5 rounded-xs text-[9px] font-bold flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-2.5 h-2.5" />
                    <span>Save</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
