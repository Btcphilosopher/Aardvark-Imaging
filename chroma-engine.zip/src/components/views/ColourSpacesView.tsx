'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useColourStore } from '../../state/colour-store';
import { Globe, RefreshCw, ZoomIn } from 'lucide-react';
import { oklchToSrgb, srgbToHex, isRgbInSrgbGamut } from '../../core/colour-math';

export function ColourSpacesView() {
  const { state, setCurrentColour, updateCurrentColourFromOklch } = useColourStore();
  const [activeSpace, setActiveSpace] = useState<'oklch' | 'lab' | 'hsl' | 'xy'>('oklch');
  const [fixedSliceLightness, setFixedSliceLightness] = useState(state.currentColour.oklch.l);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const curr = state.currentColour;

  // Render 2D chromaticity / hue-chroma slice onto canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    const imgData = ctx.createImageData(w, h);
    const data = imgData.data;

    // Render OKLCh Hue x Chroma slice at fixed Lightness
    const maxChroma = 0.35;

    for (let py = 0; py < h; py++) {
      for (let px = 0; px < w; px++) {
        const idx = (py * w + px) * 4;

        // Polar mapping: center = zero chroma, radius = maxChroma, angle = hue
        const cx = w / 2;
        const cy = h / 2;
        const dx = px - cx;
        const dy = py - cy;
        const dist = Math.sqrt(dx * dx + dy * dy);
        const radius = (Math.min(w, h) / 2) * 0.92;

        if (dist <= radius) {
          const chroma = (dist / radius) * maxChroma;
          let angleRad = Math.atan2(-dy, dx);
          let hueDeg = (angleRad * 180) / Math.PI;
          if (hueDeg < 0) hueDeg += 360;

          const rgb = oklchToSrgb({ l: fixedSliceLightness, c: chroma, h: hueDeg });
          const inGamut = isRgbInSrgbGamut(rgb);

          if (inGamut) {
            data[idx] = rgb.r;
            data[idx + 1] = rgb.g;
            data[idx + 2] = rgb.b;
            data[idx + 3] = 255;
          } else {
            // Gamut boundary outline
            data[idx] = 25;
            data[idx + 1] = 28;
            data[idx + 2] = 35;
            data[idx + 3] = 255;
          }
        } else {
          // Out of polar circle
          data[idx] = 16;
          data[idx + 1] = 18;
          data[idx + 2] = 22;
          data[idx + 3] = 255;
        }
      }
    }

    ctx.putImageData(imgData, 0, 0);

    // Draw Crosshairs and Current Color Point
    const cx = w / 2;
    const cy = h / 2;
    const radius = (Math.min(w, h) / 2) * 0.92;
    const currDist = (curr.oklch.c / maxChroma) * radius;
    const currAngleRad = (curr.oklch.h * Math.PI) / 180;
    const currX = cx + Math.cos(currAngleRad) * currDist;
    const currY = cy - Math.sin(currAngleRad) * currDist;

    // Outer circle
    ctx.strokeStyle = '#323744';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    ctx.stroke();

    // Axes
    ctx.strokeStyle = 'rgba(255,255,255,0.15)';
    ctx.beginPath();
    ctx.moveTo(cx - radius, cy);
    ctx.lineTo(cx + radius, cy);
    ctx.moveTo(cx, cy - radius);
    ctx.lineTo(cx, cy + radius);
    ctx.stroke();

    // Active color locus point
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#ff5500';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(currX, currY, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  }, [curr, fixedSliceLightness]);

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const px = (e.clientX - rect.left) * (canvas.width / rect.width);
    const py = (e.clientY - rect.top) * (canvas.height / rect.height);

    const cx = canvas.width / 2;
    const cy = canvas.height / 2;
    const dx = px - cx;
    const dy = py - cy;
    const dist = Math.sqrt(dx * dx + dy * dy);
    const radius = (Math.min(canvas.width, canvas.height) / 2) * 0.92;

    if (dist <= radius) {
      const chroma = (dist / radius) * 0.35;
      let angleRad = Math.atan2(-dy, dx);
      let hueDeg = (angleRad * 180) / Math.PI;
      if (hueDeg < 0) hueDeg += 360;

      updateCurrentColourFromOklch(fixedSliceLightness, chroma, hueDeg);
    }
  };

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono text-xs">
      {/* Header */}
      <div className="border-b border-[#22262e] pb-4">
        <div className="flex items-center gap-2">
          <span className="bg-[#ff5500] text-black font-bold px-1.5 py-0.5 rounded-xs text-[10px]">
            02
          </span>
          <h1 className="text-lg font-bold tracking-tight text-white uppercase">
            Colour Spaces & Perceptual Coordinate Projections
          </h1>
        </div>
        <p className="text-[#8e94a0] text-[11px] mt-0.5">
          2D polar chromaticity slices, perceptual locus mapping in OKLCh / Lab / XYZ, and display gamut cross-sections.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Visual 2D Slice Canvas (7 Cols) */}
        <div className="lg:col-span-7 bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-4">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-white tracking-wider">
              OKLCh CHROMATICITY PLANE (L = {(fixedSliceLightness * 100).toFixed(0)}%)
            </span>
            <span className="text-[#8e94a0] text-[10px]">CLICK CANVAS TO SAMPLE</span>
          </div>

          <div className="flex justify-center bg-[#0d0f13] p-4 rounded-xs border border-[#1e222b]">
            <canvas
              ref={canvasRef}
              width={340}
              height={340}
              onClick={handleCanvasClick}
              className="cursor-crosshair rounded-full shadow-2xl"
            />
          </div>

          {/* Lightness Slice Slider */}
          <div className="space-y-1.5 pt-2">
            <div className="flex justify-between text-[11px]">
              <span className="text-[#c5c8d0]">Slice Lightness Plane (L)</span>
              <span className="text-white font-bold">
                {(fixedSliceLightness * 100).toFixed(1)}%
              </span>
            </div>
            <input
              type="range"
              min="0.05"
              max="0.95"
              step="0.01"
              value={fixedSliceLightness}
              onChange={(e) => setFixedSliceLightness(parseFloat(e.target.value))}
              className="w-full accent-[#ff5500] cursor-pointer"
            />
          </div>
        </div>

        {/* Space Geometry Readouts (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-3">
            <span className="font-semibold text-white tracking-wider">
              PERCEPTUAL SPACE COMPARISON
            </span>

            <div className="space-y-2 text-[11px]">
              <div className="p-2.5 rounded-xs bg-[#101216] border border-[#1e222b] space-y-1">
                <div className="flex justify-between text-[#ff5500] font-bold">
                  <span>OKLCh / OKLab (Ottosson 2020)</span>
                  <span>UNIFORM</span>
                </div>
                <p className="text-[#8e94a0] text-[10px] leading-relaxed">
                  Engineered for uniform lightness and hue linearity. Eliminates the Abney effect (blue-to-purple shift). Optimal for UI tonal ramps.
                </p>
              </div>

              <div className="p-2.5 rounded-xs bg-[#101216] border border-[#1e222b] space-y-1">
                <div className="flex justify-between text-[#38a169] font-bold">
                  <span>CIE L*a*b* (1976 D65)</span>
                  <span>INDUSTRY STD</span>
                </div>
                <p className="text-[#8e94a0] text-[10px] leading-relaxed">
                  Global standard for delta-E calculations, textiles, plastics, and delta-E 2000 tolerance auditing.
                </p>
              </div>

              <div className="p-2.5 rounded-xs bg-[#101216] border border-[#1e222b] space-y-1">
                <div className="flex justify-between text-[#3182ce] font-bold">
                  <span>Display-P3 (Apple / DCI)</span>
                  <span>WIDE GAMUT</span>
                </div>
                <p className="text-[#8e94a0] text-[10px] leading-relaxed">
                  ~25% larger color volume than sRGB, with significantly extended green and red loci.
                </p>
              </div>
            </div>
          </div>

          {/* Gamut Volumetric Matrix */}
          <div className="bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-2.5">
            <span className="font-semibold text-white tracking-wider">
              GAMUT ENCLOSURE AUDIT
            </span>
            <div className="grid grid-cols-3 gap-2 text-center text-[10px]">
              <div className="bg-[#101216] p-2 rounded-xs border border-[#1e222b]">
                <div className="text-[#8e94a0]">sRGB (Standard)</div>
                <div
                  className={`font-bold mt-1 ${
                    curr.gamutStatus.inSRGB ? 'text-[#38a169]' : 'text-[#e53e3e]'
                  }`}
                >
                  {curr.gamutStatus.inSRGB ? 'ENCLOSED' : 'CLIPPED'}
                </div>
              </div>

              <div className="bg-[#101216] p-2 rounded-xs border border-[#1e222b]">
                <div className="text-[#8e94a0]">Display-P3</div>
                <div
                  className={`font-bold mt-1 ${
                    curr.gamutStatus.inDisplayP3 ? 'text-[#38a169]' : 'text-[#e53e3e]'
                  }`}
                >
                  {curr.gamutStatus.inDisplayP3 ? 'ENCLOSED' : 'CLIPPED'}
                </div>
              </div>

              <div className="bg-[#101216] p-2 rounded-xs border border-[#1e222b]">
                <div className="text-[#8e94a0]">Rec.2020</div>
                <div
                  className={`font-bold mt-1 ${
                    curr.gamutStatus.inRec2020 ? 'text-[#38a169]' : 'text-[#e53e3e]'
                  }`}
                >
                  {curr.gamutStatus.inRec2020 ? 'ENCLOSED' : 'CLIPPED'}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
