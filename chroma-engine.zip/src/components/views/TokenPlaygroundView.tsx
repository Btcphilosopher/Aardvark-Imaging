'use client';

import React, { useState } from 'react';
import { useColourStore } from '../../state/colour-store';
import {
  LayoutGrid,
  Activity,
  AlertTriangle,
  CheckCircle2,
  Sliders,
  Terminal,
  Sun,
  Moon,
  TrendingUp,
  Shield,
  Layers,
  Search,
} from 'lucide-react';

export function TokenPlaygroundView() {
  const { state, setCurrentColour } = useColourStore();
  const [isLightMode, setIsLightMode] = useState(false);
  const [activeTab, setActiveTab] = useState('telemetry');

  const activePalette =
    state.palettes.find((p) => p.id === state.activePaletteId) || state.palettes[0];

  // Derive semantic tokens
  const getRoleColor = (role: string, fallback: string) => {
    const item = activePalette.colours.find((c) => c.role === role);
    return item ? item.colour.hex : fallback;
  };

  const accentColor = getRoleColor('accent', '#D96B24');
  const bgColor = isLightMode ? '#F5F3EE' : getRoleColor('background', '#121417');
  const surfaceColor = isLightMode ? '#FFFFFF' : getRoleColor('surface', '#1C1F24');
  const textPrimary = isLightMode ? '#121417' : getRoleColor('text-primary', '#F5F3EE');
  const textSecondary = isLightMode ? '#5C5852' : getRoleColor('text-secondary', '#8E959F');
  const borderColor = isLightMode ? '#E2DFD8' : getRoleColor('border', '#2A2E37');
  const successColor = getRoleColor('success', '#38A169');
  const warningColor = getRoleColor('warning', '#DD6B20');
  const dangerColor = getRoleColor('danger', '#E53E3E');
  const infoColor = getRoleColor('information', '#0F2A4A');

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono text-xs">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#22262e] pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-[#ff5500] text-black font-bold px-1.5 py-0.5 rounded-xs text-[10px]">
              11
            </span>
            <h1 className="text-lg font-bold tracking-tight text-white uppercase">
              Brand Systems & Design Token Playground
            </h1>
          </div>
          <p className="text-[#8e94a0] text-[11px] mt-0.5">
            A live interactive industrial workstation interface driven entirely by active design tokens.
          </p>
        </div>

        {/* Theme Toggle */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsLightMode(!isLightMode)}
            className="flex items-center gap-2 bg-[#171a20] hover:bg-[#22262f] text-white border border-[#2a2e38] px-3 py-1.5 rounded-xs cursor-pointer transition-colors"
          >
            {isLightMode ? (
              <>
                <Moon className="w-3.5 h-3.5 text-[#ff5500]" />
                <span>Switch to Dark Chassis</span>
              </>
            ) : (
              <>
                <Sun className="w-3.5 h-3.5 text-[#ff5500]" />
                <span>Switch to Light Architectural</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Embedded Miniature Application Canvas */}
      <div
        className="rounded-sm border shadow-2xl p-6 space-y-6 transition-colors duration-200"
        style={{
          backgroundColor: bgColor,
          color: textPrimary,
          borderColor: borderColor,
        }}
      >
        {/* App Top Bar */}
        <div
          className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b"
          style={{ borderColor: borderColor }}
        >
          <div className="flex items-center gap-3">
            <div
              className="w-5 h-5 rounded-xs shadow-md"
              style={{ backgroundColor: accentColor }}
            />
            <span className="font-bold text-sm tracking-wider">AUREOM TELEMETRY OS</span>
            <span
              className="px-2 py-0.5 rounded-xs text-[10px] font-bold"
              style={{
                backgroundColor: `${accentColor}25`,
                color: accentColor,
                border: `1px solid ${accentColor}50`,
              }}
            >
              CHASSIS v1.4
            </span>
          </div>

          <div className="flex items-center gap-2 text-[11px]">
            <button
              onClick={() => setActiveTab('telemetry')}
              className="px-3 py-1 rounded-xs font-semibold cursor-pointer"
              style={{
                backgroundColor: activeTab === 'telemetry' ? surfaceColor : 'transparent',
                border: `1px solid ${activeTab === 'telemetry' ? borderColor : 'transparent'}`,
              }}
            >
              Telemetry
            </button>
            <button
              onClick={() => setActiveTab('modules')}
              className="px-3 py-1 rounded-xs font-semibold cursor-pointer"
              style={{
                backgroundColor: activeTab === 'modules' ? surfaceColor : 'transparent',
                border: `1px solid ${activeTab === 'modules' ? borderColor : 'transparent'}`,
              }}
            >
              Modules
            </button>
            <button
              onClick={() => setActiveTab('security')}
              className="px-3 py-1 rounded-xs font-semibold cursor-pointer"
              style={{
                backgroundColor: activeTab === 'security' ? surfaceColor : 'transparent',
                border: `1px solid ${activeTab === 'security' ? borderColor : 'transparent'}`,
              }}
            >
              Diagnostics
            </button>
          </div>
        </div>

        {/* KPI Metrics Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div
            className="p-4 rounded-xs border space-y-1 shadow-sm"
            style={{ backgroundColor: surfaceColor, borderColor: borderColor }}
          >
            <div className="text-[10px] uppercase font-bold" style={{ color: textSecondary }}>
              Chamber Pressure
            </div>
            <div className="text-2xl font-bold" style={{ color: textPrimary }}>
              148.2 kPa
            </div>
            <div className="flex items-center gap-1 text-[10px]" style={{ color: successColor }}>
              <TrendingUp className="w-3 h-3" />
              <span>Nominal Range (+0.4%)</span>
            </div>
          </div>

          <div
            className="p-4 rounded-xs border space-y-1 shadow-sm"
            style={{ backgroundColor: surfaceColor, borderColor: borderColor }}
          >
            <div className="text-[10px] uppercase font-bold" style={{ color: textSecondary }}>
              Thermal Flux
            </div>
            <div className="text-2xl font-bold" style={{ color: accentColor }}>
              842.0 °C
            </div>
            <div className="flex items-center gap-1 text-[10px]" style={{ color: warningColor }}>
              <AlertTriangle className="w-3 h-3" />
              <span>Target Boundary</span>
            </div>
          </div>

          <div
            className="p-4 rounded-xs border space-y-1 shadow-sm"
            style={{ backgroundColor: surfaceColor, borderColor: borderColor }}
          >
            <div className="text-[10px] uppercase font-bold" style={{ color: textSecondary }}>
              Turbine Efficiency
            </div>
            <div className="text-2xl font-bold" style={{ color: textPrimary }}>
              99.82%
            </div>
            <div className="flex items-center gap-1 text-[10px]" style={{ color: successColor }}>
              <CheckCircle2 className="w-3 h-3" />
              <span>Calibrated ISO</span>
            </div>
          </div>

          <div
            className="p-4 rounded-xs border space-y-1 shadow-sm"
            style={{ backgroundColor: surfaceColor, borderColor: borderColor }}
          >
            <div className="text-[10px] uppercase font-bold" style={{ color: textSecondary }}>
              Core Resonance
            </div>
            <div className="text-2xl font-bold" style={{ color: textPrimary }}>
              48.0 Hz
            </div>
            <div className="flex items-center gap-1 text-[10px]" style={{ color: textSecondary }}>
              <Activity className="w-3 h-3" />
              <span>Harmonic Lock</span>
            </div>
          </div>
        </div>

        {/* Live Interactive Table */}
        <div
          className="rounded-xs border overflow-hidden"
          style={{ backgroundColor: surfaceColor, borderColor: borderColor }}
        >
          <div
            className="p-3 border-b flex justify-between items-center"
            style={{ borderColor: borderColor }}
          >
            <span className="font-bold text-[11px]">ACTIVE SYSTEM SENSORS</span>
            <span className="text-[10px]" style={{ color: textSecondary }}>
              4 NODES CONNECTED
            </span>
          </div>

          <table className="w-full text-left text-[11px]">
            <thead>
              <tr className="border-b text-[10px] uppercase" style={{ borderColor: borderColor, color: textSecondary }}>
                <th className="p-3">Node</th>
                <th className="p-3">Location</th>
                <th className="p-3">Status</th>
                <th className="p-3">Spectral Delta</th>
                <th className="p-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y" style={{ borderColor: borderColor }}>
              {[
                { id: 'SEN-01', loc: 'Primary Ingot Chamber', status: 'Optimal', delta: '0.02 ΔE', stColor: successColor },
                { id: 'SEN-02', loc: 'Exhaust Heat Exchanger', status: 'Warning', delta: '1.45 ΔE', stColor: warningColor },
                { id: 'SEN-03', loc: 'Sub-sea Hydraulic Feed', status: 'Optimal', delta: '0.04 ΔE', stColor: successColor },
                { id: 'SEN-04', loc: 'Secondary Induction Coil', status: 'Caution', delta: '0.98 ΔE', stColor: warningColor },
              ].map((row) => (
                <tr key={row.id}>
                  <td className="p-3 font-bold" style={{ color: textPrimary }}>{row.id}</td>
                  <td className="p-3" style={{ color: textSecondary }}>{row.loc}</td>
                  <td className="p-3 font-bold" style={{ color: row.stColor }}>{row.status}</td>
                  <td className="p-3 font-mono" style={{ color: textPrimary }}>{row.delta}</td>
                  <td className="p-3 text-right">
                    <button
                      className="px-2.5 py-1 rounded-xs font-bold text-[10px] cursor-pointer"
                      style={{
                        backgroundColor: accentColor,
                        color: isLightMode ? '#FFFFFF' : '#121417',
                      }}
                    >
                      Calibrate
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
