'use client';

import React, { useState, useSyncExternalStore } from 'react';
import { useColourStore } from '../../state/colour-store';
import {
  Sliders,
  Copy,
  Check,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  Plus,
  Pipette,
  Layers,
  Compass,
  Contrast,
  ArrowRight,
} from 'lucide-react';
import { calculateCIEDE2000 } from '../../core/colour-difference';
import { mapOklchToSrgbGamut } from '../../core/colour-math';

export function ColourLabView() {
  const {
    state,
    setCurrentColour,
    setComparisonColour,
    updateCurrentColourFromHex,
    updateCurrentColourFromRgb,
    updateCurrentColourFromOklch,
    updateCurrentColourFromHsl,
    addPaletteColour,
    setActiveNavTab,
  } = useColourStore();

  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [customHexInput, setCustomHexInput] = useState(state.currentColour.hex);
  const [hexError, setHexError] = useState<string | null>(null);
  const hasEyedropper = useSyncExternalStore(
    () => () => {},
    () => typeof window !== 'undefined' && 'EyeDropper' in window,
    () => false
  );

  const curr = state.currentColour;
  const comp = state.comparisonColour;

  const deltaE = calculateCIEDE2000(curr, comp);

  const handleCopy = (key: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 1500);
  };

  const handleHexSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = customHexInput.trim();
    if (!/^#?([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$/.test(clean)) {
      setHexError('Invalid HEX format (e.g. #D96B24)');
      return;
    }
    setHexError(null);
    updateCurrentColourFromHex(clean.startsWith('#') ? clean : `#${clean}`);
  };

  const applyGamutMapping = () => {
    const mappedOklch = mapOklchToSrgbGamut(curr.oklch);
    updateCurrentColourFromOklch(mappedOklch.l, mappedOklch.c, mappedOklch.h);
  };

  const handleEyedropper = async () => {
    if ('EyeDropper' in window) {
      try {
        const eyeDropper = new (window as any).EyeDropper();
        const res = await eyeDropper.open();
        if (res?.sRGBHex) {
          updateCurrentColourFromHex(res.sRGBHex);
          setCustomHexInput(res.sRGBHex);
        }
      } catch (err) {
        console.log('Eyedropper dismissed');
      }
    }
  };

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono text-xs">
      {/* View Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#22262e] pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-[#ff5500] text-black font-bold px-1.5 py-0.5 rounded-xs text-[10px]">
              01
            </span>
            <h1 className="text-lg font-bold tracking-tight text-white uppercase">
              Colour Lab // Primary Spectrometry
            </h1>
          </div>
          <p className="text-[#8e94a0] text-[11px] mt-0.5">
            Perceptual coordinate inspection, gamut boundary verification, and master parameter controls.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {hasEyedropper && (
            <button
              onClick={handleEyedropper}
              className="flex items-center gap-1.5 bg-[#171a20] hover:bg-[#22262f] text-[#c5c8d0] border border-[#2a2e38] px-2.5 py-1.5 rounded-xs cursor-pointer transition-colors"
            >
              <Pipette className="w-3.5 h-3.5 text-[#ff5500]" />
              <span>Eyedropper</span>
            </button>
          )}

          <button
            onClick={() => addPaletteColour(curr, 'accent')}
            className="flex items-center gap-1.5 bg-[#ff5500] hover:bg-[#e04b00] text-white font-semibold px-3 py-1.5 rounded-xs cursor-pointer transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add to System Palette</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Visual Colour Field & Comparison Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Large Interactive Colour Field (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          {/* Main Visual Swatch Banner */}
          <div className="bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-4 relative overflow-hidden">
            <div className="flex items-center justify-between text-[11px] text-[#8e94a0]">
              <span className="font-semibold text-white tracking-wider">
                PRIMARY SAMPLE: {curr.name.toUpperCase()}
              </span>
              <span className="text-[#ff5500]">CANONICAL CANVASES</span>
            </div>

            {/* Split Swatch Field: Current vs Comparison */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Primary Active Colour Field */}
              <div
                className="h-44 sm:h-52 rounded-xs border border-white/10 p-3 flex flex-col justify-between shadow-inner relative transition-colors duration-150"
                style={{ backgroundColor: curr.hex }}
              >
                <div className="flex items-center justify-between">
                  <span
                    className={`px-2 py-0.5 rounded-xs text-[11px] font-bold ${
                      curr.contrastData.contrastOnWhite > 4.5
                        ? 'bg-black/80 text-white'
                        : 'bg-white/90 text-black'
                    }`}
                  >
                    ACTIVE SPECIMEN
                  </span>
                  <span
                    className={`text-[11px] font-mono font-bold ${
                      curr.contrastData.contrastOnWhite > 4.5 ? 'text-black' : 'text-white'
                    }`}
                  >
                    {curr.hex}
                  </span>
                </div>

                <div
                  className={`p-2 rounded-xs backdrop-blur-xs text-[10px] space-y-0.5 ${
                    curr.contrastData.contrastOnWhite > 4.5
                      ? 'bg-black/60 text-white'
                      : 'bg-white/70 text-black'
                  }`}
                >
                  <div className="flex justify-between font-bold">
                    <span>OKLCh:</span>
                    <span>
                      {(curr.oklch.l * 100).toFixed(1)}% / {curr.oklch.c} / {curr.oklch.h}°
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Luminance:</span>
                    <span>{(curr.luminance * 100).toFixed(1)}%</span>
                  </div>
                </div>
              </div>

              {/* Comparison Colour Field */}
              <div
                className="h-44 sm:h-52 rounded-xs border border-white/10 p-3 flex flex-col justify-between shadow-inner relative transition-colors duration-150 cursor-pointer"
                style={{ backgroundColor: comp.hex }}
                onClick={() => setComparisonColour(curr)}
                title="Click to snapshot current colour into comparison target"
              >
                <div className="flex items-center justify-between">
                  <span
                    className={`px-2 py-0.5 rounded-xs text-[11px] font-bold ${
                      comp.contrastData.contrastOnWhite > 4.5
                        ? 'bg-black/80 text-white'
                        : 'bg-white/90 text-black'
                    }`}
                  >
                    COMPARISON TARGET
                  </span>
                  <span
                    className={`text-[11px] font-mono font-bold ${
                      comp.contrastData.contrastOnWhite > 4.5 ? 'text-black' : 'text-white'
                    }`}
                  >
                    {comp.hex}
                  </span>
                </div>

                <div
                  className={`p-2 rounded-xs backdrop-blur-xs text-[10px] space-y-0.5 ${
                    comp.contrastData.contrastOnWhite > 4.5
                      ? 'bg-black/60 text-white'
                      : 'bg-white/70 text-black'
                  }`}
                >
                  <div className="flex justify-between font-bold">
                    <span>ΔE2000 Delta:</span>
                    <span className="text-[#ff5500] font-bold">{deltaE} JND</span>
                  </div>
                  <div className="text-[9px] opacity-80 truncate">
                    Click swatch to swap with current
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Metrics Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-[#22262e] text-[11px]">
              <div className="bg-[#101216] p-2 rounded-xs border border-[#1e222b]">
                <div className="text-[#6e7583]">SPECTRAL PEAK</div>
                <div className="font-bold text-white mt-0.5">
                  ~{curr.metadata.spectralPeakNm || 580} nm
                </div>
              </div>
              <div className="bg-[#101216] p-2 rounded-xs border border-[#1e222b]">
                <div className="text-[#6e7583]">ESTIMATED CCT</div>
                <div className="font-bold text-white mt-0.5">
                  {curr.metadata.temperatureK || 6500} K
                </div>
              </div>
              <div className="bg-[#101216] p-2 rounded-xs border border-[#1e222b]">
                <div className="text-[#6e7583]">WCAG ON BLACK</div>
                <div className="font-bold text-[#ff5500] mt-0.5">
                  {curr.contrastData.contrastOnBlack}:1
                </div>
              </div>
              <div className="bg-[#101216] p-2 rounded-xs border border-[#1e222b]">
                <div className="text-[#6e7583]">GAMUT INTEGRITY</div>
                <div className="flex items-center gap-1 mt-0.5">
                  {curr.gamutStatus.inSRGB ? (
                    <span className="text-[#38a169] font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> sRGB PASS
                    </span>
                  ) : (
                    <span className="text-[#e53e3e] font-bold flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3" /> OUT OF sRGB
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Out-of-Gamut Action Banner if needed */}
            {!curr.gamutStatus.inSRGB && (
              <div className="bg-[#241712] border border-[#e53e3e]/40 p-2.5 rounded-xs flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 text-[#e53e3e]">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>
                    Colour coordinates exceed standard sRGB gamut volume and will clip on standard displays.
                  </span>
                </div>
                <button
                  onClick={applyGamutMapping}
                  className="bg-[#e53e3e] hover:bg-[#c53030] text-white px-2 py-1 rounded-xs font-bold text-[10px] shrink-0 cursor-pointer"
                >
                  MAP TO sRGB GAMUT
                </button>
              </div>
            )}
          </div>

          {/* Synchronized Precision Sliders */}
          <div className="bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-4">
            <div className="flex items-center justify-between border-b border-[#22262e] pb-2">
              <span className="font-semibold text-white tracking-wider">
                SYNCHRONISED SPECTRAL & PERCEPTUAL SLIDERS
              </span>
              <span className="text-[#6e7583] text-[10px]">OKLCh · RGB · HSL</span>
            </div>

            {/* OKLCh Sliders */}
            <div className="space-y-3">
              <div className="text-[#8e94a0] font-bold text-[10px] uppercase text-[#ff5500]">
                OKLCh Perceptual Engine (Uniform Lightness & Chroma)
              </div>

              {/* Lightness (L) */}
              <div className="space-y-1">
                <div className="flex justify-between text-[11px]">
                  <span className="text-[#c5c8d0]">Lightness (L)</span>
                  <span className="text-white font-bold">
                    {(curr.oklch.l * 100).toFixed(1)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.005"
                  value={curr.oklch.l}
                  onChange={(e) =>
                    updateCurrentColourFromOklch(
                      parseFloat(e.target.value),
                      curr.oklch.c,
                      curr.oklch.h
                    )
                  }
                  className="w-full accent-[#ff5500] cursor-pointer"
                />
              </div>

              {/* Chroma (C) */}
              <div className="space-y-1">
                <div className="flex justify-between text-[11px]">
                  <span className="text-[#c5c8d0]">Chroma (C)</span>
                  <span className="text-white font-bold">{curr.oklch.c.toFixed(4)}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="0.38"
                  step="0.002"
                  value={curr.oklch.c}
                  onChange={(e) =>
                    updateCurrentColourFromOklch(
                      curr.oklch.l,
                      parseFloat(e.target.value),
                      curr.oklch.h
                    )
                  }
                  className="w-full accent-[#ff5500] cursor-pointer"
                />
              </div>

              {/* Hue (H) */}
              <div className="space-y-1">
                <div className="flex justify-between text-[11px]">
                  <span className="text-[#c5c8d0]">Hue Angle (H)</span>
                  <span className="text-white font-bold">{curr.oklch.h.toFixed(1)}°</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="360"
                  step="0.5"
                  value={curr.oklch.h}
                  onChange={(e) =>
                    updateCurrentColourFromOklch(
                      curr.oklch.l,
                      curr.oklch.c,
                      parseFloat(e.target.value)
                    )
                  }
                  className="w-full accent-[#ff5500] cursor-pointer"
                />
              </div>
            </div>

            {/* RGB Hardware Channels */}
            <div className="space-y-3 pt-3 border-t border-[#22262e]">
              <div className="text-[#8e94a0] font-bold text-[10px] uppercase">
                sRGB Hardware Phosphor Channels (0..255)
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Red */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-[#e53e3e]">Red (R)</span>
                    <span className="text-white font-bold">{curr.srgb.r}</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="255"
                    value={curr.srgb.r}
                    onChange={(e) =>
                      updateCurrentColourFromRgb(
                        parseInt(e.target.value),
                        curr.srgb.g,
                        curr.srgb.b
                      )
                    }
                    className="w-full accent-[#e53e3e] cursor-pointer"
                  />
                </div>

                {/* Green */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-[#38a169]">Green (G)</span>
                    <span className="text-white font-bold">{curr.srgb.g}</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="255"
                    value={curr.srgb.g}
                    onChange={(e) =>
                      updateCurrentColourFromRgb(
                        curr.srgb.r,
                        parseInt(e.target.value),
                        curr.srgb.b
                      )
                    }
                    className="w-full accent-[#38a169] cursor-pointer"
                  />
                </div>

                {/* Blue */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-[#3182ce]">Blue (B)</span>
                    <span className="text-white font-bold">{curr.srgb.b}</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="255"
                    value={curr.srgb.b}
                    onChange={(e) =>
                      updateCurrentColourFromRgb(
                        curr.srgb.r,
                        curr.srgb.g,
                        parseInt(e.target.value)
                      )
                    }
                    className="w-full accent-[#3182ce] cursor-pointer"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Full Coordinate Inspector Matrix (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Direct HEX Input Box */}
          <div className="bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-3">
            <span className="font-semibold text-white tracking-wider">
              DIRECT VALUE INGESTION
            </span>

            <form onSubmit={handleHexSubmit} className="flex gap-2">
              <input
                type="text"
                value={customHexInput}
                onChange={(e) => setCustomHexInput(e.target.value)}
                placeholder="#D96B24"
                className="flex-1 bg-[#101216] border border-[#262a33] text-white px-3 py-1.5 rounded-xs font-mono focus:border-[#ff5500] focus:outline-none uppercase"
              />
              <button
                type="submit"
                className="bg-[#242933] hover:bg-[#303744] text-white font-bold px-3 py-1.5 rounded-xs cursor-pointer"
              >
                APPLY
              </button>
            </form>
            {hexError && <div className="text-[#e53e3e] text-[10px]">{hexError}</div>}
          </div>

          {/* Coordinate Systems Readout Table */}
          <div className="bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-[#22262e] pb-2">
              <span className="font-semibold text-white tracking-wider">
                CANONICAL COORDINATES
              </span>
              <span className="text-[10px] text-[#6e7583]">CLICK TO COPY</span>
            </div>

            <div className="space-y-1.5">
              {[
                { label: 'HEX', val: curr.hex },
                {
                  label: 'sRGB',
                  val: `rgb(${curr.srgb.r}, ${curr.srgb.g}, ${curr.srgb.b})`,
                },
                {
                  label: 'Linear sRGB',
                  val: `${curr.linearRgb.r.toFixed(3)}, ${curr.linearRgb.g.toFixed(3)}, ${curr.linearRgb.b.toFixed(3)}`,
                },
                {
                  label: 'OKLCh',
                  val: `oklch(${(curr.oklch.l * 100).toFixed(1)}% ${curr.oklch.c} ${curr.oklch.h}deg)`,
                },
                {
                  label: 'OKLab',
                  val: `oklab(${curr.oklab.l} ${curr.oklab.a} ${curr.oklab.b})`,
                },
                {
                  label: 'CIELAB (D65)',
                  val: `lab(${curr.lab.l} ${curr.lab.a} ${curr.lab.b})`,
                },
                {
                  label: 'CIELCh',
                  val: `lch(${curr.lch.l} ${curr.lch.c} ${curr.lch.h}deg)`,
                },
                {
                  label: 'CIE XYZ',
                  val: `xyz(${curr.xyz.x}, ${curr.xyz.y}, ${curr.xyz.z})`,
                },
                {
                  label: 'HSL',
                  val: `hsl(${curr.hsl.h}deg ${curr.hsl.s}% ${curr.hsl.l}%)`,
                },
                {
                  label: 'HSV / HSB',
                  val: `hsv(${curr.hsv.h}deg ${curr.hsv.s}% ${curr.hsv.v}%)`,
                },
                {
                  label: 'HWB',
                  val: `hwb(${curr.hwb.h}deg ${curr.hwb.w}% ${curr.hwb.b}%)`,
                },
                {
                  label: 'CMYK (Approx)',
                  val: `cmyk(${curr.cmyk.c}%, ${curr.cmyk.m}%, ${curr.cmyk.y}%, ${curr.cmyk.k}%)`,
                },
                {
                  label: 'Display-P3',
                  val: `color(display-p3 ${curr.displayP3.r} ${curr.displayP3.g} ${curr.displayP3.b})`,
                },
              ].map((row) => (
                <div
                  key={row.label}
                  onClick={() => handleCopy(row.label, row.val)}
                  className="flex items-center justify-between p-1.5 rounded-xs bg-[#101216] border border-[#1e222b] hover:border-[#ff5500]/40 cursor-pointer transition-colors group"
                >
                  <span className="text-[#8e94a0] font-bold text-[10px]">
                    {row.label}
                  </span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-white font-mono">{row.val}</span>
                    {copiedKey === row.label ? (
                      <Check className="w-3 h-3 text-[#38a169]" />
                    ) : (
                      <Copy className="w-3 h-3 text-[#4b5261] group-hover:text-white" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Nav Shortcuts to downstream modules */}
          <div className="bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-2.5">
            <span className="font-semibold text-white tracking-wider">
              DOWNSTREAM PIPELINE
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setActiveNavTab('TONAL SYSTEM')}
                className="flex items-center justify-between bg-[#101216] hover:bg-[#1a1e27] border border-[#22262e] p-2 rounded-xs text-[#c5c8d0] hover:text-white cursor-pointer"
              >
                <span>Tonal Scale (0..100)</span>
                <ArrowRight className="w-3 h-3 text-[#ff5500]" />
              </button>
              <button
                onClick={() => setActiveNavTab('HARMONIES')}
                className="flex items-center justify-between bg-[#101216] hover:bg-[#1a1e27] border border-[#22262e] p-2 rounded-xs text-[#c5c8d0] hover:text-white cursor-pointer"
              >
                <span>Harmonies</span>
                <ArrowRight className="w-3 h-3 text-[#ff5500]" />
              </button>
              <button
                onClick={() => setActiveNavTab('MATERIALS')}
                className="flex items-center justify-between bg-[#101216] hover:bg-[#1a1e27] border border-[#22262e] p-2 rounded-xs text-[#c5c8d0] hover:text-white cursor-pointer"
              >
                <span>Physical Materials</span>
                <ArrowRight className="w-3 h-3 text-[#ff5500]" />
              </button>
              <button
                onClick={() => setActiveNavTab('CONTRAST')}
                className="flex items-center justify-between bg-[#101216] hover:bg-[#1a1e27] border border-[#22262e] p-2 rounded-xs text-[#c5c8d0] hover:text-white cursor-pointer"
              >
                <span>Contrast Lab</span>
                <ArrowRight className="w-3 h-3 text-[#ff5500]" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
