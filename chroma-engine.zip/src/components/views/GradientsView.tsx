'use client';

import React, { useState } from 'react';
import { useColourStore } from '../../state/colour-store';
import { Maximize2, Copy, Check, Plus, Trash2 } from 'lucide-react';
import { MASTER_COLOUR_LIBRARY } from '../../data/colour-library';
import { ColourRecord } from '../../types/colour';

export function GradientsView() {
  const { state, setCurrentColour } = useColourStore();
  const [stops, setStops] = useState<ColourRecord[]>([
    state.currentColour,
    MASTER_COLOUR_LIBRARY[6], // Deep Maritime Blue
    MASTER_COLOUR_LIBRARY[3], // Warm Technical White
  ]);
  const [gradientType, setGradientType] = useState<'linear' | 'radial' | 'conic'>('linear');
  const [angle, setAngle] = useState(90);
  const [copied, setCopied] = useState(false);

  const cssGradient =
    gradientType === 'linear'
      ? `linear-gradient(${angle}deg in oklch, ${stops.map((s) => s.hex).join(', ')})`
      : gradientType === 'radial'
      ? `radial-gradient(circle in oklch, ${stops.map((s) => s.hex).join(', ')})`
      : `conic-gradient(from ${angle}deg in oklch, ${stops.map((s) => s.hex).join(', ')})`;

  const handleCopy = () => {
    navigator.clipboard.writeText(`background: ${cssGradient};`);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const removeStop = (idx: number) => {
    if (stops.length > 2) {
      setStops(stops.filter((_, i) => i !== idx));
    }
  };

  const addStop = () => {
    if (stops.length < 6) {
      setStops([...stops, MASTER_COLOUR_LIBRARY[stops.length % MASTER_COLOUR_LIBRARY.length]]);
    }
  };

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono text-xs">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#22262e] pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-[#ff5500] text-black font-bold px-1.5 py-0.5 rounded-xs text-[10px]">
              12
            </span>
            <h1 className="text-lg font-bold tracking-tight text-white uppercase">
              Gradients // CSS Color 4 OKLCh Interpolation
            </h1>
          </div>
          <p className="text-[#8e94a0] text-[11px] mt-0.5">
            Multi-stop perceptual gradients in CSS Modern Color 4 OKLCh space.
          </p>
        </div>

        <button
          onClick={handleCopy}
          className="flex items-center gap-1.5 bg-[#ff5500] hover:bg-[#e04b00] text-white font-semibold px-3 py-1.5 rounded-xs cursor-pointer"
        >
          {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
          <span>Copy CSS Gradient</span>
        </button>
      </div>

      {/* Main Gradient Preview */}
      <div className="bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-4">
        <div
          className="h-64 rounded-xs border border-white/10 shadow-2xl transition-all"
          style={{ background: cssGradient }}
        />

        {/* Controls */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          {/* Type Selector */}
          <div className="space-y-1">
            <span className="text-[#8e94a0]">Gradient Geometry</span>
            <div className="flex gap-1 bg-[#101216] border border-[#262a33] p-1 rounded-xs">
              {(['linear', 'radial', 'conic'] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setGradientType(t)}
                  className={`flex-1 py-1 rounded-xs uppercase font-bold cursor-pointer transition-colors ${
                    gradientType === t ? 'bg-[#ff5500] text-white' : 'text-[#8e94a0]'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Angle Slider */}
          {gradientType !== 'radial' && (
            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-[#8e94a0]">Angle Vector</span>
                <span className="text-white font-bold">{angle}°</span>
              </div>
              <input
                type="range"
                min="0"
                max="360"
                value={angle}
                onChange={(e) => setAngle(parseInt(e.target.value))}
                className="w-full accent-[#ff5500] cursor-pointer"
              />
            </div>
          )}

          {/* Add Stop Button */}
          <div className="flex items-end">
            <button
              onClick={addStop}
              disabled={stops.length >= 6}
              className="w-full bg-[#1c2028] hover:bg-[#252b36] border border-[#2a2e38] text-white py-2 rounded-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-40"
            >
              <Plus className="w-3.5 h-3.5 text-[#ff5500]" />
              <span>Add Gradient Color Stop</span>
            </button>
          </div>
        </div>
      </div>

      {/* Stops Sequence Manager */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
        {stops.map((stop, idx) => (
          <div
            key={idx}
            className="bg-[#14171d] border border-[#242831] rounded-sm p-3 flex items-center justify-between gap-3"
          >
            <div className="flex items-center gap-2">
              <div
                className="w-10 h-10 rounded-xs border border-white/20 shrink-0 shadow-inner cursor-pointer"
                style={{ backgroundColor: stop.hex }}
                onClick={() => setCurrentColour(stop)}
                title="Click to set active colour"
              />
              <div className="space-y-0.5">
                <div className="font-bold text-white text-[11px]">STOP {idx + 1}</div>
                <div className="text-[#8e94a0] font-mono text-[10px]">{stop.hex}</div>
              </div>
            </div>

            <button
              onClick={() => removeStop(idx)}
              disabled={stops.length <= 2}
              className="p-1.5 text-[#8e94a0] hover:text-[#e53e3e] cursor-pointer disabled:opacity-20"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
