'use client';

import React, { useState } from 'react';
import { useColourStore } from '../../state/colour-store';
import {
  Download,
  Copy,
  Check,
  FileCode,
  FileText,
  FileSpreadsheet,
  Layers,
} from 'lucide-react';
import {
  exportToCssVariables,
  exportToTailwindConfig,
  exportToTypeScriptTokens,
  exportToW3cJson,
  exportToCsv,
  exportToSvgSwatches,
  generateHtmlSpecimenSheet,
} from '../../core/exports';
import { generateTonalScale } from '../../core/tonal-scales';

export function ExportView() {
  const { state } = useColourStore();
  const [activeFormat, setActiveFormat] = useState<
    'css' | 'tailwind' | 'ts' | 'w3c' | 'csv' | 'svg' | 'html'
  >('css');
  const [copied, setCopied] = useState(false);

  const activePalette =
    state.palettes.find((p) => p.id === state.activePaletteId) || state.palettes[0];
  const tonal = generateTonalScale(state.currentColour, 'oklch');

  let exportContent = '';
  let fileExtension = 'txt';
  let mimeType = 'text/plain';

  switch (activeFormat) {
    case 'css':
      exportContent = exportToCssVariables(activePalette);
      fileExtension = 'css';
      mimeType = 'text/css';
      break;
    case 'tailwind':
      exportContent = exportToTailwindConfig(activePalette);
      fileExtension = 'js';
      mimeType = 'text/javascript';
      break;
    case 'ts':
      exportContent = exportToTypeScriptTokens(activePalette);
      fileExtension = 'ts';
      mimeType = 'text/typescript';
      break;
    case 'w3c':
      exportContent = exportToW3cJson(activePalette);
      fileExtension = 'json';
      mimeType = 'application/json';
      break;
    case 'csv':
      exportContent = exportToCsv(activePalette);
      fileExtension = 'csv';
      mimeType = 'text/csv';
      break;
    case 'svg':
      exportContent = exportToSvgSwatches(activePalette);
      fileExtension = 'svg';
      mimeType = 'image/svg+xml';
      break;
    case 'html':
      exportContent = generateHtmlSpecimenSheet(activePalette, tonal);
      fileExtension = 'html';
      mimeType = 'text/html';
      break;
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(exportContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const handleDownload = () => {
    const blob = new Blob([exportContent], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `chroma-${activePalette.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}.${fileExtension}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono text-xs">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#22262e] pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-[#ff5500] text-black font-bold px-1.5 py-0.5 rounded-xs text-[10px]">
              21
            </span>
            <h1 className="text-lg font-bold tracking-tight text-white uppercase">
              Production Export // Multi-Format System Generator
            </h1>
          </div>
          <p className="text-[#8e94a0] text-[11px] mt-0.5">
            Export standard tokens for CSS Custom Properties, Tailwind CSS, TypeScript, W3C Design Tokens, SVG vector cards, and HTML Specimen Sheets.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 bg-[#171a20] hover:bg-[#22262f] text-white border border-[#2a2e38] px-3 py-1.5 rounded-xs cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-[#38a169]" /> : <Copy className="w-3.5 h-3.5" />}
            <span>Copy to Clipboard</span>
          </button>

          <button
            onClick={handleDownload}
            className="flex items-center gap-1.5 bg-[#ff5500] hover:bg-[#e04b00] text-white font-semibold px-3 py-1.5 rounded-xs cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download File</span>
          </button>
        </div>
      </div>

      {/* Format Switcher */}
      <div className="flex flex-wrap gap-1.5 bg-[#14171d] border border-[#242831] p-1.5 rounded-sm">
        {[
          { id: 'css', label: 'CSS Variables', icon: FileCode },
          { id: 'tailwind', label: 'Tailwind Config', icon: FileCode },
          { id: 'ts', label: 'TypeScript Tokens', icon: FileCode },
          { id: 'w3c', label: 'W3C JSON Tokens', icon: FileCode },
          { id: 'csv', label: 'CSV Data Table', icon: FileSpreadsheet },
          { id: 'svg', label: 'SVG Swatch Cards', icon: Layers },
          { id: 'html', label: 'HTML / Specimen Sheet', icon: FileText },
        ].map((fmt) => (
          <button
            key={fmt.id}
            onClick={() => setActiveFormat(fmt.id as any)}
            className={`px-3 py-1.5 rounded-xs font-bold uppercase text-[10px] cursor-pointer transition-colors flex items-center gap-1.5 ${
              activeFormat === fmt.id
                ? 'bg-[#ff5500] text-white'
                : 'text-[#8e94a0] hover:text-white hover:bg-[#1b1f28]'
            }`}
          >
            <fmt.icon className="w-3 h-3" />
            <span>{fmt.label}</span>
          </button>
        ))}
      </div>

      {/* Code Viewer Panel */}
      <div className="bg-[#101216] border border-[#242831] rounded-sm p-4 overflow-x-auto shadow-inner">
        <pre className="text-white font-mono text-[11px] leading-relaxed select-all">
          {exportContent}
        </pre>
      </div>
    </div>
  );
}
