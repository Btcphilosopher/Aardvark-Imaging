'use client';

import React from 'react';
import { useColourStore } from '../../state/colour-store';
import { BookOpen, Plus, ExternalLink } from 'lucide-react';
import { MASTER_COLOUR_LIBRARY } from '../../data/colour-library';

export function LibraryView() {
  const { setCurrentColour, addPaletteColour } = useColourStore();

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono text-xs">
      {/* Header */}
      <div className="border-b border-[#22262e] pb-4">
        <div className="flex items-center gap-2">
          <span className="bg-[#ff5500] text-black font-bold px-1.5 py-0.5 rounded-xs text-[10px]">
            20
          </span>
          <h1 className="text-lg font-bold tracking-tight text-white uppercase">
            Master Colour Library // Curated Systematic Swatches
          </h1>
        </div>
        <p className="text-[#8e94a0] text-[11px] mt-0.5">
          Curated industrial, architectural, automotive, aerospace, maritime, and modernist colour specifications.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {MASTER_COLOUR_LIBRARY.map((c) => (
          <div
            key={c.id}
            className="bg-[#14171d] border border-[#242831] rounded-sm p-4 flex flex-col justify-between space-y-3 group hover:border-[#ff5500]/50 transition-colors"
          >
            <div>
              <div className="flex justify-between items-start">
                <span className="font-bold text-white text-sm">{c.name}</span>
                <span className="text-[#ff5500] text-[9px] uppercase font-bold">
                  {c.metadata.category}
                </span>
              </div>
              <p className="text-[#8e94a0] text-[10px] mt-1 line-clamp-2">
                {c.metadata.description}
              </p>
            </div>

            <div
              className="h-24 rounded-xs border border-white/10 shadow-inner flex flex-col justify-end p-2 cursor-pointer"
              style={{ backgroundColor: c.hex }}
              onClick={() => setCurrentColour(c)}
              title="Click to load in Colour Lab"
            >
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-xs bg-black/70 text-white w-max font-mono">
                {c.hex}
              </span>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setCurrentColour(c)}
                className="flex-1 bg-[#101216] hover:bg-[#1e232c] border border-[#262a33] text-white py-1 rounded-xs font-semibold text-[10px] cursor-pointer"
              >
                Inspect
              </button>
              <button
                onClick={() => addPaletteColour(c, 'accent')}
                className="p-1 bg-[#ff5500] hover:bg-[#e04b00] text-white rounded-xs cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
