'use client';

import React, { useState } from 'react';
import { useColourStore } from '../../state/colour-store';
import { Search, Plus, Filter } from 'lucide-react';
import { MASTER_COLOUR_LIBRARY } from '../../data/colour-library';

export function ColourSearchView() {
  const { setCurrentColour, addPaletteColour } = useColourStore();
  const [query, setQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = [
    'All',
    'Industrial',
    'Architectural',
    'Aerospace',
    'Maritime',
    'Safety & System',
    'Modernist',
  ];

  const filtered = MASTER_COLOUR_LIBRARY.filter((c) => {
    const matchesCat =
      selectedCategory === 'All' || c.metadata.category === selectedCategory;
    const matchesText =
      c.name.toLowerCase().includes(query.toLowerCase()) ||
      c.hex.toLowerCase().includes(query.toLowerCase()) ||
      c.metadata.tags?.some((t) => t.toLowerCase().includes(query.toLowerCase())) ||
      c.metadata.description?.toLowerCase().includes(query.toLowerCase());
    return matchesCat && matchesText;
  });

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono text-xs">
      {/* Header */}
      <div className="border-b border-[#22262e] pb-4">
        <div className="flex items-center gap-2">
          <span className="bg-[#ff5500] text-black font-bold px-1.5 py-0.5 rounded-xs text-[10px]">
            19
          </span>
          <h1 className="text-lg font-bold tracking-tight text-white uppercase">
            Colour Search & Attribute Query Engine
          </h1>
        </div>
        <p className="text-[#8e94a0] text-[11px] mt-0.5">
          Local deterministic semantic search across physical materials, industrial palettes, and spectral attributes.
        </p>
      </div>

      {/* Search and Category Filters */}
      <div className="bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-3">
        <div className="flex items-center px-3 py-2 bg-[#101216] border border-[#262a33] rounded-xs">
          <Search className="w-4 h-4 text-[#ff5500] mr-2 shrink-0" />
          <input
            type="text"
            placeholder="Search by name, tag (e.g. 'industrial', 'sandstone', 'warm'), hex code, or description..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-transparent text-white focus:outline-none"
          />
        </div>

        {/* Categories Bar */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1 rounded-xs uppercase font-bold text-[10px] cursor-pointer transition-colors ${
                selectedCategory === cat
                  ? 'bg-[#ff5500] text-white'
                  : 'bg-[#101216] text-[#8e94a0] hover:text-white border border-[#22262e]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Results Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {filtered.map((col) => (
          <div
            key={col.id}
            className="bg-[#14171d] border border-[#242831] rounded-sm p-4 flex flex-col justify-between space-y-3"
          >
            <div>
              <div className="flex justify-between items-start">
                <span className="font-bold text-white text-sm">{col.name}</span>
                <span className="text-[#ff5500] text-[9px] font-bold uppercase">
                  {col.metadata.category}
                </span>
              </div>
              <p className="text-[#8e94a0] text-[10px] mt-1 line-clamp-2">
                {col.metadata.description}
              </p>
            </div>

            <div
              className="h-20 rounded-xs border border-white/10 shadow-inner flex flex-col justify-end p-2 cursor-pointer"
              style={{ backgroundColor: col.hex }}
              onClick={() => setCurrentColour(col)}
              title="Click to inspect in Colour Lab"
            >
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-xs bg-black/70 text-white w-max">
                {col.hex}
              </span>
            </div>

            <div className="text-[10px] text-[#8e94a0] space-y-0.5">
              <div>Luminance: {(col.luminance * 100).toFixed(1)}%</div>
              <div>OKLCh: {(col.oklch.l * 100).toFixed(0)}% / {col.oklch.c}</div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setCurrentColour(col)}
                className="flex-1 bg-[#101216] hover:bg-[#1e232c] border border-[#262a33] text-white py-1 rounded-xs font-semibold text-[10px] cursor-pointer"
              >
                Inspect
              </button>
              <button
                onClick={() => addPaletteColour(col, 'accent')}
                className="p-1 bg-[#ff5500] hover:bg-[#e04b00] text-white rounded-xs cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
