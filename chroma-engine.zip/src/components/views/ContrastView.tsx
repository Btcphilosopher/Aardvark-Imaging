'use client';

import React, { useState } from 'react';
import { useColourStore } from '../../state/colour-store';
import {
  Contrast,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  FileText,
  MousePointer,
  Check,
  RotateCcw,
} from 'lucide-react';
import { calculateWcagContrast, estimateApcaContrast } from '../../core/colour-math';
import { MASTER_COLOUR_LIBRARY } from '../../data/colour-library';

export function ContrastView() {
  const { state, setCurrentColour } = useColourStore();

  const [fgColor, setFgColor] = useState(state.currentColour);
  const [bgColor, setBgColor] = useState(MASTER_COLOUR_LIBRARY[1]); // Graphite Black

  const wcagRatio = calculateWcagContrast(fgColor.luminance, bgColor.luminance);
  const apcaScore = estimateApcaContrast(fgColor.luminance, bgColor.luminance);

  const passesAALarge = wcagRatio >= 3.0;
  const passesAANormal = wcagRatio >= 4.5;
  const passesAAALarge = wcagRatio >= 4.5;
  const passesAAANormal = wcagRatio >= 7.0;

  const swapColours = () => {
    const temp = fgColor;
    setFgColor(bgColor);
    setBgColor(temp);
  };

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono text-xs">
      {/* Header */}
      <div className="border-b border-[#22262e] pb-4">
        <div className="flex items-center gap-2">
          <span className="bg-[#ff5500] text-black font-bold px-1.5 py-0.5 rounded-xs text-[10px]">
            07
          </span>
          <h1 className="text-lg font-bold tracking-tight text-white uppercase">
            Contrast Laboratory // WCAG 2.1 & APCA Evaluation
          </h1>
        </div>
        <p className="text-[#8e94a0] text-[11px] mt-0.5">
          Standardized accessibility verification across body copy, interactive buttons, form inputs, focus rings, and graphical charts.
        </p>
      </div>

      {/* Control Configuration Bar */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center bg-[#14171d] border border-[#242831] rounded-sm p-4">
        {/* Foreground Selection */}
        <div className="md:col-span-5 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-white font-bold text-[11px]">FOREGROUND (TEXT / ICON)</span>
            <span className="text-[#8e94a0]">{fgColor.hex}</span>
          </div>
          <div className="flex items-center gap-2">
            <div
              className="w-10 h-10 rounded-xs border border-white/20 shrink-0 shadow-inner"
              style={{ backgroundColor: fgColor.hex }}
            />
            <select
              value={fgColor.id}
              onChange={(e) => {
                const found = MASTER_COLOUR_LIBRARY.find((c) => c.id === e.target.value);
                if (found) setFgColor(found);
              }}
              className="w-full bg-[#101216] border border-[#262a33] text-white p-2 rounded-xs text-[11px] focus:outline-none"
            >
              {MASTER_COLOUR_LIBRARY.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.hex})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Swap Button */}
        <div className="md:col-span-2 flex justify-center">
          <button
            onClick={swapColours}
            title="Swap Foreground and Background"
            className="p-2.5 bg-[#171a22] hover:bg-[#252b36] border border-[#262a33] text-[#ff5500] rounded-xs cursor-pointer transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        {/* Background Selection */}
        <div className="md:col-span-5 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-white font-bold text-[11px]">BACKGROUND CANVAS</span>
            <span className="text-[#8e94a0]">{bgColor.hex}</span>
          </div>
          <div className="flex items-center gap-2">
            <div
              className="w-10 h-10 rounded-xs border border-white/20 shrink-0 shadow-inner"
              style={{ backgroundColor: bgColor.hex }}
            />
            <select
              value={bgColor.id}
              onChange={(e) => {
                const found = MASTER_COLOUR_LIBRARY.find((c) => c.id === e.target.value);
                if (found) setBgColor(found);
              }}
              className="w-full bg-[#101216] border border-[#262a33] text-white p-2 rounded-xs text-[11px] focus:outline-none"
            >
              {MASTER_COLOUR_LIBRARY.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.hex})
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Compliance Scorecards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Ratio Metric */}
        <div className="bg-[#14171d] border border-[#242831] rounded-sm p-3 space-y-1">
          <span className="text-[#8e94a0] text-[10px]">WCAG 2.1 RATIO</span>
          <div className="text-2xl font-bold text-[#ff5500]">{wcagRatio}:1</div>
          <span className="text-[10px] text-[#646a78]">Luminance Contrast</span>
        </div>

        {/* APCA Metric */}
        <div className="bg-[#14171d] border border-[#242831] rounded-sm p-3 space-y-1">
          <span className="text-[#8e94a0] text-[10px]">APCA LIGHTNESS CONTRAST</span>
          <div className="text-2xl font-bold text-white">{apcaScore} Lc</div>
          <span className="text-[10px] text-[#646a78]">Advanced Perceptual Algorithm</span>
        </div>

        {/* AA Compliance */}
        <div className="bg-[#14171d] border border-[#242831] rounded-sm p-3 space-y-1">
          <span className="text-[#8e94a0] text-[10px]">WCAG LEVEL AA</span>
          <div className="flex items-center gap-2 mt-1">
            {passesAANormal ? (
              <span className="text-[#38a169] font-bold flex items-center gap-1 text-sm">
                <CheckCircle2 className="w-4 h-4" /> PASS (Normal & Large)
              </span>
            ) : passesAALarge ? (
              <span className="text-[#dd6b20] font-bold flex items-center gap-1 text-sm">
                <AlertTriangle className="w-4 h-4" /> PASS (Large Only)
              </span>
            ) : (
              <span className="text-[#e53e3e] font-bold flex items-center gap-1 text-sm">
                <XCircle className="w-4 h-4" /> FAIL
              </span>
            )}
          </div>
          <span className="text-[10px] text-[#646a78]">Minimum 4.5:1 / 3.0:1 required</span>
        </div>

        {/* AAA Compliance */}
        <div className="bg-[#14171d] border border-[#242831] rounded-sm p-3 space-y-1">
          <span className="text-[#8e94a0] text-[10px]">WCAG LEVEL AAA</span>
          <div className="flex items-center gap-2 mt-1">
            {passesAAANormal ? (
              <span className="text-[#38a169] font-bold flex items-center gap-1 text-sm">
                <CheckCircle2 className="w-4 h-4" /> PASS (Enhanced)
              </span>
            ) : passesAAALarge ? (
              <span className="text-[#dd6b20] font-bold flex items-center gap-1 text-sm">
                <AlertTriangle className="w-4 h-4" /> PASS (Large Only)
              </span>
            ) : (
              <span className="text-[#e53e3e] font-bold flex items-center gap-1 text-sm">
                <XCircle className="w-4 h-4" /> FAIL
              </span>
            )}
          </div>
          <span className="text-[10px] text-[#646a78]">Minimum 7.0:1 / 4.5:1 required</span>
        </div>
      </div>

      {/* Live Interactive Component Previews with Selected Pair */}
      <div className="bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-4">
        <span className="font-semibold text-white tracking-wider">
          LIVE INTERACTIVE COMPONENT AUDIT PREVIEWS
        </span>

        <div
          className="p-6 rounded-xs border border-white/10 space-y-6 shadow-inner"
          style={{ backgroundColor: bgColor.hex, color: fgColor.hex }}
        >
          {/* Typography Sample */}
          <div className="space-y-2">
            <h2 className="text-xl font-bold tracking-tight">
              AUREOM System Headline (H1 / Display)
            </h2>
            <p className="text-xs leading-relaxed max-w-3xl opacity-90">
              Colour is not an arbitrary aesthetic veneer. It is a systematic optical medium that governs user comprehension, visual hierarchy, material reflectance, and display compliance across all physical and digital interfaces.
            </p>
          </div>

          {/* Interactive UI Controls */}
          <div className="flex flex-wrap items-center gap-4 pt-2">
            {/* Primary Filled Button */}
            <button
              className="px-4 py-2 rounded-xs font-bold shadow-md cursor-pointer transition-transform active:scale-95"
              style={{ backgroundColor: fgColor.hex, color: bgColor.hex }}
            >
              Primary Interactive CTA
            </button>

            {/* Outlined Button */}
            <button
              className="px-4 py-2 rounded-xs font-bold border-2 cursor-pointer transition-transform active:scale-95"
              style={{ borderColor: fgColor.hex, color: fgColor.hex }}
            >
              Secondary Outlined Action
            </button>

            {/* Form Input Field */}
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value="Parameter Input: 104.5 kPa"
                className="px-3 py-2 rounded-xs border focus:outline-none"
                style={{
                  backgroundColor: bgColor.hex,
                  borderColor: fgColor.hex,
                  color: fgColor.hex,
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
