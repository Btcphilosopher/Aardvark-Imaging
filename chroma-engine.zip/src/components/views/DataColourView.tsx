'use client';

import React, { useState } from 'react';
import { useColourStore } from '../../state/colour-store';
import { BarChart3, TrendingUp, PieChart, Activity } from 'lucide-react';

export function DataColourView() {
  const { state, setCurrentColour } = useColourStore();
  const [scaleType, setScaleType] = useState<'sequential' | 'diverging' | 'qualitative'>('sequential');

  // Sequential ramp based on current colour
  const baseHex = state.currentColour.hex;
  const sequentialColors = [
    '#f7e8db',
    '#f0ceb6',
    '#e49e6f',
    state.currentColour.hex,
    '#9e4713',
    '#612908',
  ];

  const divergingColors = [
    '#0f2a4a',
    '#3182ce',
    '#e2e8f0',
    state.currentColour.hex,
    '#c53030',
  ];

  const qualitativeColors = [
    state.currentColour.hex,
    '#3182ce',
    '#38a169',
    '#805ad5',
    '#d69e2e',
    '#e53e3e',
  ];

  const activeScale =
    scaleType === 'sequential'
      ? sequentialColors
      : scaleType === 'diverging'
      ? divergingColors
      : qualitativeColors;

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono text-xs">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#22262e] pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-[#ff5500] text-black font-bold px-1.5 py-0.5 rounded-xs text-[10px]">
              14
            </span>
            <h1 className="text-lg font-bold tracking-tight text-white uppercase">
              Data Visualisation Colour System // Perceptual Scales
            </h1>
          </div>
          <p className="text-[#8e94a0] text-[11px] mt-0.5">
            Sequential, Diverging, and Categorical scales designed for charts, telemetry heatmaps, and ISO risk matrices.
          </p>
        </div>

        {/* Scale Type Switcher */}
        <div className="flex items-center bg-[#171a20] border border-[#262a33] rounded-xs p-1 text-[11px]">
          {(['sequential', 'diverging', 'qualitative'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setScaleType(t)}
              className={`px-3 py-1 rounded-xs uppercase font-bold cursor-pointer transition-colors ${
                scaleType === t ? 'bg-[#ff5500] text-white' : 'text-[#8e94a0] hover:text-white'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Scale Swatch Ribbon */}
      <div className="bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-3">
        <span className="font-semibold text-white tracking-wider">
          ACTIVE DATA PALETTE
        </span>
        <div className="flex h-12 rounded-xs overflow-hidden border border-[#262a33]">
          {activeScale.map((hex, idx) => (
            <div
              key={idx}
              className="flex-1 flex items-end p-2 cursor-pointer hover:opacity-90 transition-opacity"
              style={{ backgroundColor: hex }}
            >
              <span className="text-[10px] font-bold px-1 py-0.2 rounded-xs bg-black/70 text-white">
                {hex}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Simulated Live Visualisations */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Simulated Bar Chart */}
        <div className="bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-4">
          <div className="flex items-center justify-between">
            <span className="font-bold text-white text-[11px]">BAR METRIC DISTRIBUTION</span>
            <span className="text-[#8e94a0] text-[10px]">TELEMETRY NODES</span>
          </div>

          <div className="h-48 flex items-end justify-between gap-3 pt-4 border-b border-[#22262e]">
            {[65, 42, 88, 95, 30, 72].map((val, idx) => (
              <div key={idx} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end">
                <div
                  className="w-full rounded-t-xs transition-all shadow-md"
                  style={{
                    height: `${val}%`,
                    backgroundColor: activeScale[idx % activeScale.length],
                  }}
                />
                <span className="text-[9px] text-[#646a78]">N-{idx + 1}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Simulated Heatmap Matrix */}
        <div className="bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-4">
          <div className="flex items-center justify-between">
            <span className="font-bold text-white text-[11px]">THERMAL RISK MATRIX (4x4)</span>
            <span className="text-[#8e94a0] text-[10px]">CHAMBER SENSORS</span>
          </div>

          <div className="grid grid-cols-4 gap-2">
            {[0, 1, 2, 3, 2, 4, 1, 5, 3, 0, 4, 2, 5, 3, 1, 0].map((step, idx) => (
              <div
                key={idx}
                className="h-10 rounded-xs flex items-center justify-center font-bold text-white shadow-inner"
                style={{ backgroundColor: activeScale[step % activeScale.length] }}
              >
                <span className="bg-black/50 px-1 py-0.2 rounded text-[9px]">
                  {(step * 24.5).toFixed(0)}°
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
