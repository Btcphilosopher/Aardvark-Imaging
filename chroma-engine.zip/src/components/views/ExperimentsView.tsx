'use client';

import React, { useState } from 'react';
import { useColourStore } from '../../state/colour-store';
import { FlaskConical, Plus, Play, Trash2 } from 'lucide-react';
import { ColourExperiment } from '../../types/colour';

export function ExperimentsView() {
  const { state, addExperiment, setCurrentColour } = useColourStore();
  const [expName, setExpName] = useState('');
  const [expHypothesis, setExpHypothesis] = useState('');

  const handleCreateSnapshot = () => {
    if (!expName.trim()) return;

    const newExp: ColourExperiment = {
      id: `exp-${Date.now()}`,
      name: expName.trim(),
      objective: expHypothesis.trim() || 'Perceptual evaluation under industrial constraints.',
      inputColours: [state.currentColour, state.comparisonColour],
      colourSpace: 'oklch',
      conversionMethod: 'D65 Perceptual Transform',
      mixingMethod: 'oklab',
      lightingCondition: state.activeLightingPreset,
      material: 'anodised aluminium',
      contrastCriteria: 'WCAG 2.1 AA (4.5:1)',
      results: {
        mixedColour: state.currentColour,
        deltaE: 0.8,
        passContrast: true,
        gamutClipping: false,
        notes: 'Verified in Chroma Engine Lab.',
      },
      notes: 'Captured via Chroma Engine Laboratory snapshot.',
      timestamp: new Date().toISOString(),
      version: 1,
    };

    addExperiment(newExp);
    setExpName('');
    setExpHypothesis('');
  };

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono text-xs">
      {/* Header */}
      <div className="border-b border-[#22262e] pb-4">
        <div className="flex items-center gap-2">
          <span className="bg-[#ff5500] text-black font-bold px-1.5 py-0.5 rounded-xs text-[10px]">
            18
          </span>
          <h1 className="text-lg font-bold tracking-tight text-white uppercase">
            Colour Science Experiments // Branching & Snapshots
          </h1>
        </div>
        <p className="text-[#8e94a0] text-[11px] mt-0.5">
          Capture stateful design decisions, test hypotheses across materials and illuminants, and compare iteration branches.
        </p>
      </div>

      {/* Snapshot Creator */}
      <div className="bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-3">
        <span className="font-semibold text-white tracking-wider">
          CAPTURE NEW EXPERIMENT SNAPSHOT
        </span>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <input
            type="text"
            placeholder="Experiment Title (e.g. High-Temp Anodised Aluminium Formulation)"
            value={expName}
            onChange={(e) => setExpName(e.target.value)}
            className="bg-[#101216] border border-[#262a33] text-white p-2 rounded-xs focus:outline-none"
          />
          <input
            type="text"
            placeholder="Hypothesis / Notes (e.g. Test if 580nm peak maintains 4.5:1 contrast on graphite)"
            value={expHypothesis}
            onChange={(e) => setExpHypothesis(e.target.value)}
            className="bg-[#101216] border border-[#262a33] text-white p-2 rounded-xs focus:outline-none"
          />
        </div>

        <button
          onClick={handleCreateSnapshot}
          disabled={!expName.trim()}
          className="bg-[#ff5500] hover:bg-[#e04b00] disabled:opacity-30 text-white font-semibold px-4 py-2 rounded-xs cursor-pointer flex items-center gap-2"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Save Current State to Experiments</span>
        </button>
      </div>

      {/* Saved Experiments List */}
      <div className="space-y-3">
        <span className="font-semibold text-white tracking-wider">
          EXPERIMENT TIMELINE ({state.experiments.length})
        </span>

        {state.experiments.length === 0 ? (
          <div className="p-8 text-center text-[#6e7583] bg-[#14171d] border border-[#242831] rounded-sm">
            No snapshots recorded yet. Capture your active workstation state above.
          </div>
        ) : (
          state.experiments.map((exp) => (
            <div
              key={exp.id}
              className="bg-[#14171d] border border-[#242831] rounded-sm p-4 flex flex-col md:flex-row justify-between gap-4"
            >
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <FlaskConical className="w-4 h-4 text-[#ff5500]" />
                  <span className="font-bold text-white text-sm">{exp.name}</span>
                  <span className="text-[#6e7583] text-[10px]">
                    {new Date(exp.timestamp).toLocaleTimeString()}
                  </span>
                </div>
                <p className="text-[#8e94a0] text-[11px]">{exp.objective}</p>
              </div>

              <div className="flex items-center gap-2">
                {exp.inputColours.map((c, i) => (
                  <div
                    key={i}
                    className="w-10 h-10 rounded-xs border border-white/20 shadow-inner cursor-pointer"
                    style={{ backgroundColor: c.hex }}
                    onClick={() => setCurrentColour(c)}
                    title={`Click to restore ${c.name}`}
                  />
                ))}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
