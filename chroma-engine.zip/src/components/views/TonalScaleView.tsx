'use client';

import React, { useState } from 'react';
import { useColourStore } from '../../state/colour-store';
import { Layers, Plus, Copy, Check, Info } from 'lucide-react';
import { generateTonalScale } from '../../core/tonal-scales';

export function TonalScaleView() {
  const { state, setCurrentColour, addPaletteColour } = useColourStore();
  const [space, setSpace] = useState<'oklch' | 'lab' | 'lch' | 'hsl'>('oklch');
  const [copiedTone, setCopiedTone] = useState<number | null>(null);

  const tonalScale = generateTonalScale(state.currentColour, space);

  const handleCopy = (tone: number, hex: string) => {
    navigator.clipboard.writeText(hex);
    setCopiedTone(tone);
    setTimeout(() => setCopiedTone(null), 1500);
  };

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono text-xs">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#22262e] pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-[#ff5500] text-black font-bold px-1.5 py-0.5 rounded-xs text-[10px]">
              06
            </span>
            <h1 className="text-lg font-bold tracking-tight text-white uppercase">
              Tonal System // Perceptual Scale Generator (0..100)
            </h1>
          </div>
          <p className="text-[#8e94a0] text-[11px] mt-0.5">
            Full 12-step systematic tonal ramp (0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 95, 100) with real-time WCAG contrast metrics.
          </p>
        </div>

        {/* Space Selector */}
        <div className="flex items-center bg-[#171a20] border border-[#262a33] rounded-xs p-1 text-[11px]">
          <span className="text-[#8e94a0] mr-2 pl-1">SCALE SPACE:</span>
          {(['oklch', 'lab', 'hsl'] as const).map((s) => (
            <button
              key={s}
              onClick={() => setSpace(s)}
              className={`px-2.5 py-1 rounded-xs uppercase font-bold cursor-pointer transition-colors ${
                space === s
                  ? 'bg-[#ff5500] text-white'
                  : 'text-[#8e94a0] hover:text-white'
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Continuous Band Strip */}
      <div className="bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-3">
        <span className="font-semibold text-white tracking-wider">
          CONTINUOUS SYSTEM TONAL BAND
        </span>
        <div className="flex h-16 rounded-xs overflow-hidden border border-[#262a33]">
          {tonalScale.steps.map((step) => (
            <div
              key={step.tone}
              className="flex-1 flex flex-col justify-between p-1.5 cursor-pointer hover:opacity-90 transition-opacity"
              style={{
                backgroundColor: step.colour.hex,
                color: step.contrastAgainstWhite > 4.5 ? '#ffffff' : '#000000',
              }}
              onClick={() => setCurrentColour(step.colour)}
              title={`${step.colour.name} - ${step.colour.hex}`}
            >
              <span className="font-bold text-[10px]">{step.tone}</span>
              <span className="text-[9px] opacity-80">{step.colour.hex}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Detailed Tonal Grid Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
        {tonalScale.steps.map((step) => {
          const isBase = step.colour.hex.toLowerCase() === state.currentColour.hex.toLowerCase();

          return (
            <div
              key={step.tone}
              className={`bg-[#14171d] border rounded-sm p-3 flex flex-col justify-between space-y-3 ${
                isBase ? 'border-[#ff5500] ring-1 ring-[#ff5500]/50' : 'border-[#242831]'
              }`}
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-[11px]">
                    TONE {step.tone}
                  </span>
                  {isBase && (
                    <span className="bg-[#ff5500] text-black font-bold px-1 py-0.2 rounded text-[9px]">
                      ANCHOR
                    </span>
                  )}
                </div>
                <div className="text-[#8e94a0] text-[10px] truncate">
                  OKLCh L: {(step.colour.oklch.l * 100).toFixed(0)}%
                </div>
              </div>

              <div
                className="h-16 rounded-xs border border-white/10 shadow-inner flex flex-col justify-end p-1.5 cursor-pointer"
                style={{ backgroundColor: step.colour.hex }}
                onClick={() => setCurrentColour(step.colour)}
                title="Click to set as active workstation colour"
              >
                <div className="flex justify-between items-center text-[10px]">
                  <span
                    className={`font-bold px-1 py-0.2 rounded-xs ${
                      step.contrastAgainstWhite > 4.5
                        ? 'bg-black/70 text-white'
                        : 'bg-white/80 text-black'
                    }`}
                  >
                    {step.colour.hex}
                  </span>
                </div>
              </div>

              <div className="text-[10px] text-[#8e94a0] space-y-0.5">
                <div className="flex justify-between">
                  <span>vs White:</span>
                  <span
                    className={
                      step.contrastAgainstWhite >= 4.5 ? 'text-[#38a169] font-bold' : ''
                    }
                  >
                    {step.contrastAgainstWhite}:1
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>vs Black:</span>
                  <span
                    className={
                      step.contrastAgainstBlack >= 4.5 ? 'text-[#38a169] font-bold' : ''
                    }
                  >
                    {step.contrastAgainstBlack}:1
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1 pt-1 border-t border-[#1e222b]">
                <button
                  onClick={() => handleCopy(step.tone, step.colour.hex)}
                  className="flex-1 bg-[#101216] hover:bg-[#1f242d] border border-[#262a33] text-[#c5c8d0] py-1 rounded-xs text-[10px] font-semibold flex items-center justify-center gap-1 cursor-pointer"
                >
                  {copiedTone === step.tone ? (
                    <Check className="w-3 h-3 text-[#38a169]" />
                  ) : (
                    <Copy className="w-3 h-3" />
                  )}
                  <span>HEX</span>
                </button>
                <button
                  onClick={() => addPaletteColour(step.colour, `tone-${step.tone}`)}
                  title="Add to system palette"
                  className="p-1 bg-[#101216] hover:bg-[#1f242d] border border-[#262a33] text-[#ff5500] rounded-xs cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
