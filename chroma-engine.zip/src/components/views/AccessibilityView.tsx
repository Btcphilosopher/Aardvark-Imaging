'use client';

import React, { useState } from 'react';
import { useColourStore } from '../../state/colour-store';
import { Eye, AlertTriangle, CheckCircle2, Info } from 'lucide-react';
import {
  simulateColourDeficiency,
  assessPaletteAccessibility,
} from '../../core/colour-blindness';
import { ColourBlindnessType } from '../../types/colour';

export function AccessibilityView() {
  const { state, setCurrentColour } = useColourStore();
  const [activeDeficiency, setActiveDeficiency] =
    useState<ColourBlindnessType>('deuteranopia');

  const activePalette =
    state.palettes.find((p) => p.id === state.activePaletteId) || state.palettes[0];
  const paletteColours = activePalette.colours.map((c) => c.colour);

  const adviceList = assessPaletteAccessibility(paletteColours);

  const deficiencyTypes: { type: ColourBlindnessType; label: string; desc: string }[] = [
    {
      type: 'deuteranopia',
      label: 'Deuteranopia (M-Cone Deficit)',
      desc: 'Most prevalent (~6% of males). Green photoreceptor insensitivity; confusion between greens, yellows, and warm reds.',
    },
    {
      type: 'protanopia',
      label: 'Protanopia (L-Cone Deficit)',
      desc: '~1% of males. Red photoreceptor insensitivity; reds appear darker and shift towards brown/grey.',
    },
    {
      type: 'tritanopia',
      label: 'Tritanopia (S-Cone Deficit)',
      desc: 'Rare (~0.01%). Blue photoreceptor insensitivity; confusion between blues and greens, yellows and pinks.',
    },
    {
      type: 'achromatopsia',
      label: 'Achromatopsia (Complete Monochromacy)',
      desc: 'Complete absence of cone function. Vision relies solely on rods; perceives only pure relative luminance.',
    },
    {
      type: 'low-vision',
      label: 'Low Vision / Cataract Haze',
      desc: 'Contrast attenuation and optical scattering common in aging eyes.',
    },
    {
      type: 'display-washout',
      label: 'High Ambient Glare / Washout',
      desc: 'Outdoor direct solar glare causing dynamic range compression on screens.',
    },
  ];

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono text-xs">
      {/* Header */}
      <div className="border-b border-[#22262e] pb-4">
        <div className="flex items-center gap-2">
          <span className="bg-[#ff5500] text-black font-bold px-1.5 py-0.5 rounded-xs text-[10px]">
            08
          </span>
          <h1 className="text-lg font-bold tracking-tight text-white uppercase">
            Accessibility & Colour Vision Deficiency Simulation
          </h1>
        </div>
        <p className="text-[#8e94a0] text-[11px] mt-0.5">
          Physiological cone-response simulations (Machado 2009) and automated perceptual confusion recommendations.
        </p>
      </div>

      {/* Deficiency Type Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
        {deficiencyTypes.map((d) => (
          <button
            key={d.type}
            onClick={() => setActiveDeficiency(d.type)}
            className={`p-2.5 rounded-xs border text-left flex flex-col justify-between space-y-1 cursor-pointer transition-colors ${
              activeDeficiency === d.type
                ? 'bg-[#1f242e] border-[#ff5500] text-white'
                : 'bg-[#14171d] border-[#242831] text-[#8e94a0] hover:text-white hover:bg-[#181b22]'
            }`}
          >
            <span className="font-bold text-[11px] truncate">{d.label.split(' ')[0]}</span>
            <span className="text-[9px] opacity-75 truncate">{d.type}</span>
          </button>
        ))}
      </div>

      {/* Active Simulation Description */}
      <div className="bg-[#14171d] border border-[#242831] rounded-sm p-4">
        <div className="flex items-center gap-2 text-white font-bold mb-1">
          <Eye className="w-4 h-4 text-[#ff5500]" />
          <span>
            {deficiencyTypes.find((d) => d.type === activeDeficiency)?.label}
          </span>
        </div>
        <p className="text-[#8e94a0] text-[11px]">
          {deficiencyTypes.find((d) => d.type === activeDeficiency)?.desc}
        </p>
      </div>

      {/* Side-by-Side Palette Simulation Matrix */}
      <div className="bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-4">
        <span className="font-semibold text-white tracking-wider">
          PALETTE DEFICIENCY COMPARISON MATRIX
        </span>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Standard Normal Vision */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-[#8e94a0]">
              <span className="font-bold text-white">1. STANDARD TRICHROMATIC VISION</span>
              <span>D65 Observer</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {activePalette.colours.map((item) => (
                <div
                  key={item.id}
                  className="bg-[#101216] border border-[#22262e] p-2 rounded-xs flex flex-col space-y-1.5"
                >
                  <div
                    className="h-16 rounded-xs border border-white/10 shadow-inner"
                    style={{ backgroundColor: item.colour.hex }}
                  />
                  <div className="font-bold text-white text-[10px] truncate">
                    {item.colour.name}
                  </div>
                  <div className="text-[#8e94a0] text-[9px]">{item.colour.hex}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Simulated Deficiency */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-[#ff5500]">
              <span className="font-bold uppercase">
                2. SIMULATED: {activeDeficiency.toUpperCase()}
              </span>
              <span>Machado Model</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {activePalette.colours.map((item) => {
                const sim = simulateColourDeficiency(item.colour, activeDeficiency);
                return (
                  <div
                    key={item.id}
                    className="bg-[#101216] border border-[#22262e] p-2 rounded-xs flex flex-col space-y-1.5"
                  >
                    <div
                      className="h-16 rounded-xs border border-white/10 shadow-inner"
                      style={{ backgroundColor: sim.hex }}
                    />
                    <div className="font-bold text-white text-[10px] truncate">
                      {sim.name}
                    </div>
                    <div className="text-[#ff5500] text-[9px] font-mono">{sim.hex}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Automated Diagnostic Advice */}
      <div className="bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-3">
        <span className="font-semibold text-white tracking-wider">
          SYSTEM ACCESSIBILITY AUDIT FINDINGS
        </span>

        <div className="space-y-2">
          {adviceList.map((adv, idx) => (
            <div
              key={idx}
              className={`p-3 rounded-xs border flex items-start gap-3 ${
                adv.status === 'critical'
                  ? 'bg-[#241414] border-[#e53e3e]/40 text-[#fca5a5]'
                  : adv.status === 'warning'
                  ? 'bg-[#241a12] border-[#dd6b20]/40 text-[#fbd38d]'
                  : 'bg-[#122218] border-[#38a169]/40 text-[#9ae6b4]'
              }`}
            >
              {adv.status === 'critical' ? (
                <AlertTriangle className="w-4 h-4 text-[#e53e3e] shrink-0 mt-0.5" />
              ) : adv.status === 'warning' ? (
                <AlertTriangle className="w-4 h-4 text-[#dd6b20] shrink-0 mt-0.5" />
              ) : (
                <CheckCircle2 className="w-4 h-4 text-[#38a169] shrink-0 mt-0.5" />
              )}
              <div className="space-y-0.5">
                <div className="font-bold text-white text-[11px]">{adv.title}</div>
                <div className="text-[11px] leading-relaxed opacity-90">
                  {adv.recommendation}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
