'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useColourStore } from '../../state/colour-store';
import { Box, Sun, Sliders, RefreshCw, Eye } from 'lucide-react';
import { MATERIAL_SPECS, renderMaterialPreview } from '../../core/materials';
import { MaterialSpec } from '../../types/colour';

export function MaterialsView() {
  const { state, setActiveMaterialId } = useColourStore();
  const [selectedMaterialId, setSelectedMaterialId] = useState<string>(
    state.activeMaterialId || MATERIAL_SPECS[0].id
  );
  const [lightAngle, setLightAngle] = useState(45);
  const [lightIntensity, setLightIntensity] = useState(1.0);

  const mainCanvasRef = useRef<HTMLCanvasElement>(null);
  const currentMaterial =
    MATERIAL_SPECS.find((m) => m.id === selectedMaterialId) || MATERIAL_SPECS[0];

  // Render main hero canvas
  useEffect(() => {
    if (mainCanvasRef.current) {
      renderMaterialPreview(
        mainCanvasRef.current,
        state.currentColour,
        currentMaterial,
        lightIntensity,
        lightAngle
      );
    }
  }, [state.currentColour, currentMaterial, lightIntensity, lightAngle]);

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono text-xs">
      {/* Header */}
      <div className="border-b border-[#22262e] pb-4">
        <div className="flex items-center gap-2">
          <span className="bg-[#ff5500] text-black font-bold px-1.5 py-0.5 rounded-xs text-[10px]">
            09
          </span>
          <h1 className="text-lg font-bold tracking-tight text-white uppercase">
            Materials Laboratory // Industrial & Architectural Physics
          </h1>
        </div>
        <p className="text-[#8e94a0] text-[11px] mt-0.5">
          Simulate how colour interacts with physical surfaces: micro-roughness, metallic sheen, Fresnel reflectance, anisotropy, and subsurface scattering.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Main 3D Render Canvas (7 Cols) */}
        <div className="lg:col-span-7 bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-4">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-white tracking-wider">
              {currentMaterial.name.toUpperCase()}
            </span>
            <span className="text-[#ff5500] text-[10px] font-bold uppercase">
              PHYSICAL SWATCH 3D
            </span>
          </div>

          <div className="flex justify-center bg-[#0d0f13] p-6 rounded-xs border border-[#1e222b]">
            <canvas
              ref={mainCanvasRef}
              width={340}
              height={340}
              className="rounded-full shadow-2xl"
            />
          </div>

          {/* Interactive Lighting Controls */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-[#22262e]">
            <div className="space-y-1">
              <div className="flex justify-between text-[11px]">
                <span className="text-[#c5c8d0]">Light Incident Angle (°)</span>
                <span className="text-white font-bold">{lightAngle}°</span>
              </div>
              <input
                type="range"
                min="0"
                max="360"
                value={lightAngle}
                onChange={(e) => setLightAngle(parseInt(e.target.value))}
                className="w-full accent-[#ff5500] cursor-pointer"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-[11px]">
                <span className="text-[#c5c8d0]">Illuminance Intensity</span>
                <span className="text-white font-bold">
                  {(lightIntensity * 100).toFixed(0)}%
                </span>
              </div>
              <input
                type="range"
                min="0.2"
                max="2.0"
                step="0.05"
                value={lightIntensity}
                onChange={(e) => setLightIntensity(parseFloat(e.target.value))}
                className="w-full accent-[#ff5500] cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Material Specs & Physics Inspector (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-3">
            <span className="font-semibold text-white tracking-wider">
              PHYSICAL PARAMETERS
            </span>
            <p className="text-[#8e94a0] text-[11px] leading-relaxed">
              {currentMaterial.description}
            </p>

            <div className="space-y-2 pt-2 border-t border-[#22262e] text-[11px]">
              <div className="flex justify-between p-2 rounded-xs bg-[#101216] border border-[#1e222b]">
                <span className="text-[#8e94a0]">Surface Roughness (Ra):</span>
                <span className="text-white font-bold">{currentMaterial.roughness}</span>
              </div>
              <div className="flex justify-between p-2 rounded-xs bg-[#101216] border border-[#1e222b]">
                <span className="text-[#8e94a0]">Metallic Conduction:</span>
                <span className="text-white font-bold">{currentMaterial.metallic}</span>
              </div>
              <div className="flex justify-between p-2 rounded-xs bg-[#101216] border border-[#1e222b]">
                <span className="text-[#8e94a0]">Fresnel Reflectance (F0):</span>
                <span className="text-white font-bold">{currentMaterial.reflectance}</span>
              </div>
              <div className="flex justify-between p-2 rounded-xs bg-[#101216] border border-[#1e222b]">
                <span className="text-[#8e94a0]">Specular Highlight:</span>
                <span className="text-white font-bold">{currentMaterial.specular}</span>
              </div>
              <div className="flex justify-between p-2 rounded-xs bg-[#101216] border border-[#1e222b]">
                <span className="text-[#8e94a0]">Brush Anisotropy:</span>
                <span className="text-white font-bold">{currentMaterial.anisotropy}</span>
              </div>
            </div>
          </div>

          {/* Material Library Quick Select Grid */}
          <div className="bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-3">
            <span className="font-semibold text-white tracking-wider">
              SUBSTRATE SAMPLES
            </span>

            <div className="grid grid-cols-2 gap-2">
              {MATERIAL_SPECS.map((mat) => (
                <button
                  key={mat.id}
                  onClick={() => {
                    setSelectedMaterialId(mat.id);
                    setActiveMaterialId(mat.id);
                  }}
                  className={`p-2 rounded-xs border text-left flex flex-col space-y-1 cursor-pointer transition-colors ${
                    selectedMaterialId === mat.id
                      ? 'bg-[#1f242e] border-[#ff5500] text-white'
                      : 'bg-[#101216] border-[#1e222b] text-[#8e94a0] hover:text-white hover:bg-[#161920]'
                  }`}
                >
                  <span className="font-bold text-[10px] truncate">{mat.name}</span>
                  <span className="text-[9px] opacity-70 uppercase">{mat.category}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
