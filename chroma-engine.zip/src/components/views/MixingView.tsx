'use client';

import React, { useState } from 'react';
import { useColourStore } from '../../state/colour-store';
import { Shuffle, Plus, ArrowRight } from 'lucide-react';
import { mixColours, generateMixingRamp } from '../../core/mixing';
import { ColourRecord, MixingModel } from '../../types/colour';
import { MASTER_COLOUR_LIBRARY } from '../../data/colour-library';

export function MixingView() {
  const { state, setCurrentColour, addPaletteColour } = useColourStore();

  const [colorA, setColorA] = useState<ColourRecord>(state.currentColour);
  const [colorB, setColorB] = useState<ColourRecord>(MASTER_COLOUR_LIBRARY[6]); // Deep Maritime Blue
  const [colorC, setColorC] = useState<ColourRecord>(MASTER_COLOUR_LIBRARY[18]); // Bauhaus Yellow
  const [ratio, setRatio] = useState<number>(0.5);
  const [selectedModel, setSelectedModel] = useState<MixingModel>('subtractive-pigment');

  // Compute 50/50 mix across all 5 models for comparison
  const srgbMix = mixColours(colorA, colorB, ratio, 'srgb');
  const linearMix = mixColours(colorA, colorB, ratio, 'linear-rgb');
  const labMix = mixColours(colorA, colorB, ratio, 'lab');
  const oklabMix = mixColours(colorA, colorB, ratio, 'oklab');
  const pigmentMix = mixColours(colorA, colorB, ratio, 'subtractive-pigment');

  // Compute 9-step ramps for visual analysis
  const srgbRamp = generateMixingRamp(colorA, colorB, 9, 'srgb');
  const oklabRamp = generateMixingRamp(colorA, colorB, 9, 'oklab');
  const pigmentRamp = generateMixingRamp(colorA, colorB, 9, 'subtractive-pigment');

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono text-xs">
      {/* Header */}
      <div className="border-b border-[#22262e] pb-4">
        <div className="flex items-center gap-2">
          <span className="bg-[#ff5500] text-black font-bold px-1.5 py-0.5 rounded-xs text-[10px]">
            03
          </span>
          <h1 className="text-lg font-bold tracking-tight text-white uppercase">
            Mixing Engine // Optical & Subtractive Pigment Laboratory
          </h1>
        </div>
        <p className="text-[#8e94a0] text-[11px] mt-0.5">
          Compare digital light synthesis against physical Kubelka-Munk pigment mechanics and uniform OKLab interpolation.
        </p>
      </div>

      {/* Input Colours Configuration Bar */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-[#14171d] border border-[#242831] rounded-sm p-4">
        {/* Source Colour A */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-[#ff5500] font-bold">SOURCE COMPONENT A (Weight: {((1 - ratio) * 100).toFixed(0)}%)</span>
            <span className="text-white font-mono">{colorA.hex}</span>
          </div>
          <div className="flex items-center gap-3">
            <div
              className="w-14 h-14 rounded-xs border border-white/20 shrink-0 shadow-inner"
              style={{ backgroundColor: colorA.hex }}
            />
            <div className="flex-1 space-y-1">
              <div className="text-white font-semibold truncate">{colorA.name}</div>
              <div className="text-[#8e94a0] text-[10px]">
                OKLCh: {(colorA.oklch.l * 100).toFixed(0)}% / {colorA.oklch.c} / {colorA.oklch.h}°
              </div>
              <select
                onChange={(e) => {
                  const found = MASTER_COLOUR_LIBRARY.find((c) => c.id === e.target.value);
                  if (found) setColorA(found);
                }}
                className="w-full bg-[#101216] border border-[#262a33] text-[#c5c8d0] p-1 rounded-xs text-[10px] focus:outline-none"
              >
                {MASTER_COLOUR_LIBRARY.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.hex})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Source Colour B */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-[#3182ce] font-bold">SOURCE COMPONENT B (Weight: {(ratio * 100).toFixed(0)}%)</span>
            <span className="text-white font-mono">{colorB.hex}</span>
          </div>
          <div className="flex items-center gap-3">
            <div
              className="w-14 h-14 rounded-xs border border-white/20 shrink-0 shadow-inner"
              style={{ backgroundColor: colorB.hex }}
            />
            <div className="flex-1 space-y-1">
              <div className="text-white font-semibold truncate">{colorB.name}</div>
              <div className="text-[#8e94a0] text-[10px]">
                OKLCh: {(colorB.oklch.l * 100).toFixed(0)}% / {colorB.oklch.c} / {colorB.oklch.h}°
              </div>
              <select
                defaultValue={colorB.id}
                onChange={(e) => {
                  const found = MASTER_COLOUR_LIBRARY.find((c) => c.id === e.target.value);
                  if (found) setColorB(found);
                }}
                className="w-full bg-[#101216] border border-[#262a33] text-[#c5c8d0] p-1 rounded-xs text-[10px] focus:outline-none"
              >
                {MASTER_COLOUR_LIBRARY.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.hex})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Mixing Proportion Slider */}
      <div className="bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-2">
        <div className="flex justify-between text-[11px]">
          <span className="text-[#c5c8d0]">Mixing Proportion (Interpolation Weight)</span>
          <span className="text-white font-bold">
            {(1 - ratio).toFixed(2)} A : {ratio.toFixed(2)} B
          </span>
        </div>
        <input
          type="range"
          min="0"
          max="1"
          step="0.01"
          value={ratio}
          onChange={(e) => setRatio(parseFloat(e.target.value))}
          className="w-full accent-[#ff5500] cursor-pointer"
        />
      </div>

      {/* Multi-Model Comparison Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        {[
          {
            title: 'Subtractive Pigment',
            subtitle: 'Kubelka-Munk Physical Paint',
            col: pigmentMix,
            badge: 'PHYSICAL',
            badgeClass: 'bg-[#ff5500]/20 text-[#ff5500]',
          },
          {
            title: 'OKLab (Ottosson)',
            subtitle: 'Perceptual Uniformity',
            col: oklabMix,
            badge: 'RECOMMENDED',
            badgeClass: 'bg-[#38a169]/20 text-[#38a169]',
          },
          {
            title: 'CIELAB (D65)',
            subtitle: 'Perceptual Uniform',
            col: labMix,
            badge: 'STANDARD',
            badgeClass: 'bg-[#3182ce]/20 text-[#3182ce]',
          },
          {
            title: 'Linear RGB',
            subtitle: 'Additive Photon Flux',
            col: linearMix,
            badge: 'OPTICAL',
            badgeClass: 'bg-[#805ad5]/20 text-[#805ad5]',
          },
          {
            title: 'Standard sRGB',
            subtitle: 'Naïve Hardware Interpolation',
            col: srgbMix,
            badge: 'LEGACY',
            badgeClass: 'bg-[#718096]/20 text-[#a0aec0]',
          },
        ].map((m) => (
          <div
            key={m.title}
            className="bg-[#14171d] border border-[#242831] rounded-sm p-3 flex flex-col justify-between space-y-3"
          >
            <div>
              <div className="flex items-center justify-between">
                <span className="font-bold text-white text-[11px] truncate">{m.title}</span>
                <span className={`text-[9px] px-1 py-0.5 rounded-xs font-bold ${m.badgeClass}`}>
                  {m.badge}
                </span>
              </div>
              <div className="text-[#8e94a0] text-[10px] truncate">{m.subtitle}</div>
            </div>

            <div
              className="h-24 rounded-xs border border-white/10 shadow-inner flex flex-col justify-end p-2 transition-colors cursor-pointer"
              style={{ backgroundColor: m.col.hex }}
              onClick={() => setCurrentColour(m.col)}
              title="Click to set as current workstation colour"
            >
              <span className="text-[10px] font-bold px-1 py-0.5 rounded-xs bg-black/70 text-white w-max">
                {m.col.hex}
              </span>
            </div>

            <div className="text-[10px] text-[#8e94a0] space-y-0.5">
              <div>Luminance: {(m.col.luminance * 100).toFixed(1)}%</div>
              <div>OKLCh: {(m.col.oklch.l * 100).toFixed(0)}% / {m.col.oklch.c}</div>
            </div>

            <button
              onClick={() => addPaletteColour(m.col, 'accent')}
              className="w-full bg-[#101216] hover:bg-[#1f242d] border border-[#262a33] text-white py-1 rounded-xs text-[10px] font-semibold flex items-center justify-center gap-1 cursor-pointer"
            >
              <Plus className="w-3 h-3" />
              <span>Capture to Palette</span>
            </button>
          </div>
        ))}
      </div>

      {/* Ramp Visualisers */}
      <div className="bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-4">
        <span className="font-semibold text-white tracking-wider">
          9-STEP GRADIENT RAMP COMPARISON
        </span>

        <div className="space-y-3">
          {/* Subtractive Pigment Ramp */}
          <div className="space-y-1">
            <div className="flex justify-between text-[10px] text-[#8e94a0]">
              <span className="text-[#ff5500] font-bold">Subtractive Physical Pigment (Kubelka-Munk)</span>
              <span>Smooth natural transitions without grey mud</span>
            </div>
            <div className="flex h-9 rounded-xs overflow-hidden border border-[#262a33]">
              {pigmentRamp.map((col, idx) => (
                <div
                  key={idx}
                  className="flex-1 cursor-pointer hover:opacity-80 transition-opacity"
                  style={{ backgroundColor: col.hex }}
                  onClick={() => setCurrentColour(col)}
                  title={`${col.hex} (Click to select)`}
                />
              ))}
            </div>
          </div>

          {/* OKLab Ramp */}
          <div className="space-y-1">
            <div className="flex justify-between text-[10px] text-[#8e94a0]">
              <span className="text-[#38a169] font-bold">OKLab Perceptually Linear</span>
              <span>Uniform lightness progression across all steps</span>
            </div>
            <div className="flex h-9 rounded-xs overflow-hidden border border-[#262a33]">
              {oklabRamp.map((col, idx) => (
                <div
                  key={idx}
                  className="flex-1 cursor-pointer hover:opacity-80 transition-opacity"
                  style={{ backgroundColor: col.hex }}
                  onClick={() => setCurrentColour(col)}
                  title={`${col.hex} (Click to select)`}
                />
              ))}
            </div>
          </div>

          {/* sRGB Ramp */}
          <div className="space-y-1">
            <div className="flex justify-between text-[10px] text-[#8e94a0]">
              <span className="text-[#a0aec0] font-bold">Naïve sRGB (Standard Gamma)</span>
              <span>Noticeable dip in luminance and desaturation in mid-tones</span>
            </div>
            <div className="flex h-9 rounded-xs overflow-hidden border border-[#262a33]">
              {srgbRamp.map((col, idx) => (
                <div
                  key={idx}
                  className="flex-1 cursor-pointer hover:opacity-80 transition-opacity"
                  style={{ backgroundColor: col.hex }}
                  onClick={() => setCurrentColour(col)}
                  title={`${col.hex} (Click to select)`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
