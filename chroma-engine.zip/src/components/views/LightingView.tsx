'use client';

import React, { useState } from 'react';
import { useColourStore } from '../../state/colour-store';
import { Sun, Sparkles, RefreshCw } from 'lucide-react';
import { LIGHTING_PRESETS, simulateIlluminatedColour } from '../../core/lighting';
import { LightingPreset } from '../../types/colour';

export function LightingView() {
  const { state, setCurrentColour, setActiveLightingPreset } = useColourStore();
  const [activePresetKey, setActivePresetKey] = useState<LightingPreset>(
    state.activeLightingPreset || 'daylight-d65'
  );

  const curr = state.currentColour;

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono text-xs">
      {/* Header */}
      <div className="border-b border-[#22262e] pb-4">
        <div className="flex items-center gap-2">
          <span className="bg-[#ff5500] text-black font-bold px-1.5 py-0.5 rounded-xs text-[10px]">
            10
          </span>
          <h1 className="text-lg font-bold tracking-tight text-white uppercase">
            Spectral Lighting Laboratory // Illuminants & Metamerism
          </h1>
        </div>
        <p className="text-[#8e94a0] text-[11px] mt-0.5">
          Simulate chromatic adaptation and appearance shifts under D65 daylight, 2700K tungsten, high-pressure sodium, and gallery halogen.
        </p>
      </div>

      {/* Lighting Presets Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {LIGHTING_PRESETS.map((light) => {
          const simColour = simulateIlluminatedColour(curr, light);
          const isSelected = activePresetKey === light.preset;

          return (
            <div
              key={light.preset}
              className={`bg-[#14171d] border rounded-sm p-4 flex flex-col justify-between space-y-3 cursor-pointer transition-all ${
                isSelected
                  ? 'border-[#ff5500] ring-1 ring-[#ff5500]/50'
                  : 'border-[#242831] hover:border-[#383e4c]'
              }`}
              onClick={() => {
                setActivePresetKey(light.preset);
                setActiveLightingPreset(light.preset);
              }}
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-[11px]">{light.name}</span>
                  <span className="text-[#ff5500] text-[10px] font-bold">
                    {light.temperatureK}K
                  </span>
                </div>
                <p className="text-[#8e94a0] text-[10px] mt-1 line-clamp-2">
                  {light.description}
                </p>
              </div>

              {/* Split view: Original vs Under Light */}
              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <div className="text-[9px] text-[#6e7583]">BASE D65</div>
                  <div
                    className="h-16 rounded-xs border border-white/10 shadow-inner"
                    style={{ backgroundColor: curr.hex }}
                  />
                  <div className="text-[10px] text-white font-mono">{curr.hex}</div>
                </div>

                <div className="space-y-1">
                  <div className="text-[9px] text-[#ff5500]">ILLUMINATED</div>
                  <div
                    className="h-16 rounded-xs border border-white/10 shadow-inner"
                    style={{ backgroundColor: simColour.hex }}
                  />
                  <div className="text-[10px] text-[#ff5500] font-mono">
                    {simColour.hex}
                  </div>
                </div>
              </div>

              {/* Light Filter Spectral Readout */}
              <div className="bg-[#101216] p-2 rounded-xs border border-[#1e222b] text-[10px] text-[#8e94a0] flex justify-between">
                <span>Filter RGB:</span>
                <span className="text-white font-mono">
                  {light.rgbFilter.r}, {light.rgbFilter.g}, {light.rgbFilter.b}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
