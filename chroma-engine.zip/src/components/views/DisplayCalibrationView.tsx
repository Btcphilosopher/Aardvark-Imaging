'use client';

import React from 'react';
import { useColourStore } from '../../state/colour-store';
import { Monitor, AlertTriangle, CheckCircle2 } from 'lucide-react';

export function DisplayCalibrationView() {
  const { state, setDisplayProfile } = useColourStore();
  const curr = state.currentColour;

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono text-xs">
      {/* Header */}
      <div className="border-b border-[#22262e] pb-4">
        <div className="flex items-center gap-2">
          <span className="bg-[#ff5500] text-black font-bold px-1.5 py-0.5 rounded-xs text-[10px]">
            16
          </span>
          <h1 className="text-lg font-bold tracking-tight text-white uppercase">
            Display Calibration & Gamut Volume Analysis
          </h1>
        </div>
        <p className="text-[#8e94a0] text-[11px] mt-0.5">
          Evaluate display profile clipping across standard sRGB, Apple Display-P3, and UHDTV Rec.2020 wide-gamut spaces.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* sRGB */}
        <div
          className={`bg-[#14171d] border rounded-sm p-4 space-y-3 cursor-pointer transition-all ${
            state.displayProfile === 'sRGB'
              ? 'border-[#ff5500] ring-1 ring-[#ff5500]/50'
              : 'border-[#242831]'
          }`}
          onClick={() => setDisplayProfile('sRGB')}
        >
          <div className="flex justify-between items-center">
            <span className="font-bold text-white text-sm">sRGB Profile</span>
            <span className="text-[#8e94a0] text-[10px]">IEC 61966-2-1</span>
          </div>
          <p className="text-[#8e94a0] text-[11px]">
            The standard web and consumer display gamut. Baseline reference for all unmanaged browsers.
          </p>
          <div className="p-2 rounded-xs bg-[#101216] border border-[#1e222b]">
            <div className="text-[#8e94a0] text-[10px]">Coverage Status:</div>
            <div
              className={`font-bold mt-1 flex items-center gap-1 ${
                curr.gamutStatus.inSRGB ? 'text-[#38a169]' : 'text-[#e53e3e]'
              }`}
            >
              {curr.gamutStatus.inSRGB ? (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5" /> 100% In Gamut
                </>
              ) : (
                <>
                  <AlertTriangle className="w-3.5 h-3.5" /> Out of Gamut (Clipped)
                </>
              )}
            </div>
          </div>
        </div>

        {/* Display-P3 */}
        <div
          className={`bg-[#14171d] border rounded-sm p-4 space-y-3 cursor-pointer transition-all ${
            state.displayProfile === 'Display-P3'
              ? 'border-[#ff5500] ring-1 ring-[#ff5500]/50'
              : 'border-[#242831]'
          }`}
          onClick={() => setDisplayProfile('Display-P3')}
        >
          <div className="flex justify-between items-center">
            <span className="font-bold text-white text-sm">Display-P3</span>
            <span className="text-[#ff5500] text-[10px] font-bold">WIDE GAMUT</span>
          </div>
          <p className="text-[#8e94a0] text-[11px]">
            Modern Apple displays, OLED phones, and professional creative monitors. 25% larger than sRGB.
          </p>
          <div className="p-2 rounded-xs bg-[#101216] border border-[#1e222b]">
            <div className="text-[#8e94a0] text-[10px]">Coverage Status:</div>
            <div
              className={`font-bold mt-1 flex items-center gap-1 ${
                curr.gamutStatus.inDisplayP3 ? 'text-[#38a169]' : 'text-[#e53e3e]'
              }`}
            >
              {curr.gamutStatus.inDisplayP3 ? (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5" /> In Wide Gamut
                </>
              ) : (
                <>
                  <AlertTriangle className="w-3.5 h-3.5" /> Exceeds P3 Gamut
                </>
              )}
            </div>
          </div>
        </div>

        {/* Rec.2020 */}
        <div
          className={`bg-[#14171d] border rounded-sm p-4 space-y-3 cursor-pointer transition-all ${
            state.displayProfile === 'Rec.2020'
              ? 'border-[#ff5500] ring-1 ring-[#ff5500]/50'
              : 'border-[#242831]'
          }`}
          onClick={() => setDisplayProfile('Rec.2020')}
        >
          <div className="flex justify-between items-center">
            <span className="font-bold text-white text-sm">Rec. 2020</span>
            <span className="text-[#3182ce] text-[10px] font-bold">UHDTV HDR</span>
          </div>
          <p className="text-[#8e94a0] text-[11px]">
            Next-generation ultra-wide HDR broadcast standard. Approaching pure monochromatic spectral laser primaries.
          </p>
          <div className="p-2 rounded-xs bg-[#101216] border border-[#1e222b]">
            <div className="text-[#8e94a0] text-[10px]">Coverage Status:</div>
            <div
              className={`font-bold mt-1 flex items-center gap-1 ${
                curr.gamutStatus.inRec2020 ? 'text-[#38a169]' : 'text-[#e53e3e]'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5" /> In Rec.2020 Master Volume
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
