'use client';

import React, { useState, useRef } from 'react';
import { useColourStore } from '../../state/colour-store';
import { FileImage, Upload, Plus, BarChart2 } from 'lucide-react';
import { extractColoursFromImage } from '../../core/image-analysis';
import { ImageColourExtraction } from '../../types/colour';

export function ImageAnalysisView() {
  const { setCurrentColour, addPaletteColour } = useColourStore();
  const [analysis, setAnalysis] = useState<ImageColourExtraction | null>(null);
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const src = e.target?.result as string;
      setImageSrc(src);

      const img = new Image();
      img.onload = async () => {
        const result = await extractColoursFromImage(img, file.name);
        setAnalysis(result);
      };
      img.src = src;
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files?.[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono text-xs">
      {/* Header */}
      <div className="border-b border-[#22262e] pb-4">
        <div className="flex items-center gap-2">
          <span className="bg-[#ff5500] text-black font-bold px-1.5 py-0.5 rounded-xs text-[10px]">
            13
          </span>
          <h1 className="text-lg font-bold tracking-tight text-white uppercase">
            Image Analysis // Local Palette & Histogram Extraction
          </h1>
        </div>
        <p className="text-[#8e94a0] text-[11px] mt-0.5">
          Local in-browser median quantization, luminance histograms, and dominant tone clustering.
        </p>
      </div>

      {/* Drag and Drop Zone */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`border-2 border-dashed rounded-sm p-8 flex flex-col items-center justify-center gap-3 cursor-pointer transition-colors ${
          isDragging
            ? 'border-[#ff5500] bg-[#1a1714]'
            : 'border-[#262a33] bg-[#14171d] hover:border-[#3d4350]'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => {
            if (e.target.files?.[0]) handleFileUpload(e.target.files[0]);
          }}
        />
        <Upload className="w-8 h-8 text-[#ff5500]" />
        <div className="text-center space-y-1">
          <div className="font-bold text-white text-sm">
            Drag and Drop Image or Click to Select
          </div>
          <div className="text-[#8e94a0] text-[11px]">
            PNG, JPG, WebP, SVG processed locally inside browser sandbox
          </div>
        </div>
      </div>

      {/* Analysis Results */}
      {analysis && (
        <div className="space-y-6">
          {/* Dominant Palette */}
          <div className="bg-[#14171d] border border-[#242831] rounded-sm p-4 space-y-4">
            <span className="font-semibold text-white tracking-wider">
              EXTRACTED DOMINANT PALETTE ({analysis.fileName})
            </span>

            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
              {analysis.dominantPalette.map((col, idx) => (
                <div
                  key={idx}
                  className="bg-[#101216] border border-[#22262e] p-2 rounded-xs flex flex-col space-y-2"
                >
                  <div
                    className="h-16 rounded-xs border border-white/10 shadow-inner cursor-pointer"
                    style={{ backgroundColor: col.hex }}
                    onClick={() => setCurrentColour(col)}
                    title="Click to set active colour"
                  />
                  <div className="text-white font-bold text-[10px] truncate">
                    {col.hex}
                  </div>
                  <button
                    onClick={() => addPaletteColour(col, 'extracted')}
                    className="w-full bg-[#171a22] hover:bg-[#252b36] border border-[#262a33] text-[#ff5500] py-0.5 rounded-xs text-[9px] font-bold flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-2.5 h-2.5" />
                    <span>Save</span>
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Key Tonal Roles */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: 'Vibrant Accent', col: analysis.vibrantColour },
              { label: 'Muted Tone', col: analysis.mutedColour },
              { label: 'Highlight Specular', col: analysis.highlightColour },
              { label: 'Shadow Basalt', col: analysis.shadowColour },
            ].map((card) => (
              <div
                key={card.label}
                className="bg-[#14171d] border border-[#242831] rounded-sm p-3 space-y-2"
              >
                <div className="text-[#8e94a0] text-[10px]">{card.label}</div>
                <div
                  className="h-14 rounded-xs border border-white/10 shadow-inner cursor-pointer"
                  style={{ backgroundColor: card.col.hex }}
                  onClick={() => setCurrentColour(card.col)}
                />
                <div className="text-white font-mono text-[10px] font-bold">
                  {card.col.hex}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
