'use client';

import React, { useState } from 'react';
import { useColourStore } from '../../state/colour-store';
import { GitCompare, ArrowRight } from 'lucide-react';
import { calculateAllColorDifferences } from '../../core/colour-difference';
import { MASTER_COLOUR_LIBRARY } from '../../data/colour-library';

export function DifferenceView() {
  const { state, setComparisonColour } = useColourStore();
  const [col1, setCol1] = useState(state.currentColour);
  const [col2, setCol2] = useState(state.comparisonColour);

  const diffs = calculateAllColorDifferences(col1, col2);

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono text-xs">
      {/* Header */}
      <div className="border-b border-[#22262e] pb-4">
        <div className="flex items-center gap-2">
          <span className="bg-[#ff5500] text-black font-bold px-1.5 py-0.5 rounded-xs text-[10px]">
            17
          </span>
          <h1 className="text-lg font-bold tracking-tight text-white uppercase">
            Colour Difference Engine // Multi-Metric Delta-E Tolerancing
          </h1>
        </div>
        <p className="text-[#8e94a0] text-[11px] mt-0.5">
          Evaluate perceptual distance across CIEDE2000, CIE94, CIE76, Delta-E OKLab, and Euclidean RGB.
        </p>
      </div>

      {/* Target Colours Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-[#14171d] border border-[#242831] rounded-sm p-4">
        <div className="space-y-2">
          <span className="font-bold text-white text-[11px]">SAMPLE SPECIMEN 1</span>
          <div className="flex items-center gap-3">
            <div
              className="w-14 h-14 rounded-xs border border-white/20 shadow-inner"
              style={{ backgroundColor: col1.hex }}
            />
            <div className="flex-1 space-y-1">
              <div className="text-white font-semibold">{col1.name}</div>
              <div className="text-[#8e94a0]">{col1.hex}</div>
              <select
                value={col1.id}
                onChange={(e) => {
                  const found = MASTER_COLOUR_LIBRARY.find((c) => c.id === e.target.value);
                  if (found) setCol1(found);
                }}
                className="w-full bg-[#101216] border border-[#262a33] text-white p-1 rounded-xs text-[10px]"
              >
                {MASTER_COLOUR_LIBRARY.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.hex})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <span className="font-bold text-white text-[11px]">SAMPLE SPECIMEN 2</span>
          <div className="flex items-center gap-3">
            <div
              className="w-14 h-14 rounded-xs border border-white/20 shadow-inner"
              style={{ backgroundColor: col2.hex }}
            />
            <div className="flex-1 space-y-1">
              <div className="text-white font-semibold">{col2.name}</div>
              <div className="text-[#8e94a0]">{col2.hex}</div>
              <select
                value={col2.id}
                onChange={(e) => {
                  const found = MASTER_COLOUR_LIBRARY.find((c) => c.id === e.target.value);
                  if (found) setCol2(found);
                }}
                className="w-full bg-[#101216] border border-[#262a33] text-white p-1 rounded-xs text-[10px]"
              >
                {MASTER_COLOUR_LIBRARY.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.hex})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Delta-E Metrics Comparison */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        {[
          {
            name: 'CIEDE2000 (ΔE00)',
            val: diffs.de2000,
            desc: 'ISO / CIE gold standard with rotation terms for blue non-linearity.',
            highlight: true,
          },
          {
            name: 'Delta-E OKLab',
            val: diffs.deOklab,
            desc: 'Euclidean distance in uniform OKLab space.',
          },
          {
            name: 'CIE94 (ΔE94)',
            val: diffs.de94,
            desc: 'Graphic arts & textile tolerance weighting.',
          },
          {
            name: 'CIE76 (ΔE76)',
            val: diffs.de76,
            desc: 'Classic unweighted Lab Euclidean distance.',
          },
          {
            name: 'Euclidean RGB',
            val: diffs.euclideanRgb,
            desc: 'Unweighted hardware distance (0..441).',
          },
        ].map((m) => (
          <div
            key={m.name}
            className={`bg-[#14171d] border rounded-sm p-4 space-y-2 flex flex-col justify-between ${
              m.highlight ? 'border-[#ff5500] ring-1 ring-[#ff5500]/40' : 'border-[#242831]'
            }`}
          >
            <div>
              <div className="font-bold text-white text-[11px]">{m.name}</div>
              <div className="text-2xl font-bold text-[#ff5500] mt-1">{m.val}</div>
            </div>
            <p className="text-[#8e94a0] text-[10px] leading-relaxed">{m.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
