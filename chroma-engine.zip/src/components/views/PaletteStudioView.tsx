'use client';

import React, { useState } from 'react';
import { useColourStore } from '../../state/colour-store';
import {
  Palette,
  Plus,
  Trash2,
  Lock,
  Unlock,
  Copy,
  Check,
  Download,
  Share2,
  ArrowUpDown,
  Laptop,
} from 'lucide-react';
import { SemanticRole } from '../../types/colour';
import { MASTER_COLOUR_LIBRARY } from '../../data/colour-library';

const AVAILABLE_ROLES: SemanticRole[] = [
  'background',
  'surface',
  'surface-elevated',
  'text-primary',
  'text-secondary',
  'border',
  'accent',
  'accent-hover',
  'success',
  'warning',
  'danger',
  'information',
  'selected',
  'disabled',
  'focus',
];

export function PaletteStudioView() {
  const {
    state,
    setCurrentColour,
    updateActivePalette,
    removePaletteColour,
    addPaletteColour,
    setActiveNavTab,
  } = useColourStore();

  const [copiedId, setCopiedId] = useState<string | null>(null);

  const activePalette =
    state.palettes.find((p) => p.id === state.activePaletteId) || state.palettes[0];

  const handleRoleChange = (colourId: string, newRole: SemanticRole) => {
    const updatedColours = activePalette.colours.map((c) =>
      c.id === colourId ? { ...c, role: newRole } : c
    );
    updateActivePalette({ ...activePalette, colours: updatedColours });
  };

  const handleToggleLock = (colourId: string) => {
    const updatedColours = activePalette.colours.map((c) =>
      c.id === colourId ? { ...c, locked: !c.locked } : c
    );
    updateActivePalette({ ...activePalette, colours: updatedColours });
  };

  const handleDuplicateColour = (item: (typeof activePalette.colours)[0]) => {
    addPaletteColour(item.colour, item.role);
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono text-xs">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#22262e] pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-[#ff5500] text-black font-bold px-1.5 py-0.5 rounded-xs text-[10px]">
              05
            </span>
            <h1 className="text-lg font-bold tracking-tight text-white uppercase">
              Palette Studio // Design Tokens & Semantic Systems
            </h1>
          </div>
          <p className="text-[#8e94a0] text-[11px] mt-0.5">
            Manage semantic roles, lock tokens, audit contrast, and prepare production design tokens.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveNavTab('TOKEN PLAYGROUND')}
            className="flex items-center gap-1.5 bg-[#1a1e26] hover:bg-[#252b36] text-[#ff5500] border border-[#ff5500]/30 px-3 py-1.5 rounded-xs cursor-pointer"
          >
            <Laptop className="w-3.5 h-3.5" />
            <span>Test in Live UI</span>
          </button>
          <button
            onClick={() => setActiveNavTab('EXPORT')}
            className="flex items-center gap-1.5 bg-[#ff5500] hover:bg-[#e04b00] text-white font-semibold px-3 py-1.5 rounded-xs cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Token Suite</span>
          </button>
        </div>
      </div>

      {/* Palette Metadata Banner */}
      <div className="bg-[#14171d] border border-[#242831] rounded-sm p-4 flex flex-col md:flex-row justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-white font-bold text-sm tracking-wide">
              {activePalette.name}
            </span>
            <span className="bg-[#1c2028] text-[#8e94a0] border border-[#262a33] px-1.5 py-0.2 rounded text-[10px]">
              v{activePalette.version}
            </span>
          </div>
          <p className="text-[#8e94a0] text-[11px] max-w-2xl leading-relaxed">
            {activePalette.description}
          </p>
        </div>

        <div className="flex items-center gap-2 self-start md:self-auto">
          <button
            onClick={() => addPaletteColour(state.currentColour, 'accent')}
            className="flex items-center gap-1 bg-[#1a1e27] hover:bg-[#222733] border border-[#2a2f3d] text-white px-2.5 py-1 rounded-xs cursor-pointer"
          >
            <Plus className="w-3 h-3 text-[#ff5500]" />
            <span>Add Workstation Colour</span>
          </button>
        </div>
      </div>

      {/* Tokens Table */}
      <div className="bg-[#14171d] border border-[#242831] rounded-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#101216] border-b border-[#22262e] text-[#8e94a0] text-[10px] uppercase">
                <th className="p-3">Swatch</th>
                <th className="p-3">Semantic Role</th>
                <th className="p-3">Token Name</th>
                <th className="p-3">HEX / Values</th>
                <th className="p-3">OKLCh Coordinates</th>
                <th className="p-3">Luminance / CR</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e222b]">
              {activePalette.colours.map((item) => (
                <tr
                  key={item.id}
                  className="hover:bg-[#181b22] transition-colors group text-[11px]"
                >
                  {/* Swatch */}
                  <td className="p-3">
                    <div
                      className="w-10 h-10 rounded-xs border border-white/20 shadow-inner cursor-pointer"
                      style={{ backgroundColor: item.colour.hex }}
                      onClick={() => setCurrentColour(item.colour)}
                      title="Click to inspect in Colour Lab"
                    />
                  </td>

                  {/* Semantic Role Dropdown */}
                  <td className="p-3">
                    <select
                      value={item.role}
                      onChange={(e) =>
                        handleRoleChange(item.id, e.target.value as SemanticRole)
                      }
                      className="bg-[#101216] border border-[#262a33] text-[#ff5500] font-bold px-2 py-1 rounded-xs focus:outline-none cursor-pointer text-[10px]"
                    >
                      {AVAILABLE_ROLES.map((role) => (
                        <option key={role} value={role}>
                          {role}
                        </option>
                      ))}
                    </select>
                  </td>

                  {/* Name & Notes */}
                  <td className="p-3">
                    <div className="text-white font-semibold">{item.colour.name}</div>
                    <div className="text-[#646a78] text-[10px] truncate max-w-[180px]">
                      {item.notes || 'System token'}
                    </div>
                  </td>

                  {/* HEX / Value */}
                  <td className="p-3 font-mono">
                    <div className="flex items-center gap-1.5">
                      <span className="text-white">{item.colour.hex}</span>
                      <button
                        onClick={() => handleCopy(item.id, item.colour.hex)}
                        className="text-[#646a78] hover:text-white p-0.5 cursor-pointer"
                      >
                        {copiedId === item.id ? (
                          <Check className="w-3 h-3 text-[#38a169]" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                    </div>
                    <div className="text-[#8e94a0] text-[10px]">
                      rgb({item.colour.srgb.r}, {item.colour.srgb.g}, {item.colour.srgb.b})
                    </div>
                  </td>

                  {/* OKLCh */}
                  <td className="p-3 text-[#8e94a0]">
                    <div>L: {(item.colour.oklch.l * 100).toFixed(0)}%</div>
                    <div>C: {item.colour.oklch.c} / H: {item.colour.oklch.h}°</div>
                  </td>

                  {/* Luminance & Contrast */}
                  <td className="p-3">
                    <div className="text-white">
                      Lum: {(item.colour.luminance * 100).toFixed(1)}%
                    </div>
                    <div className="text-[#8e94a0] text-[10px]">
                      CR on White: {item.colour.contrastData.contrastOnWhite}:1
                    </div>
                  </td>

                  {/* Action buttons */}
                  <td className="p-3 text-right">
                    <div className="flex items-center justify-end gap-1">
                      <button
                        onClick={() => handleToggleLock(item.id)}
                        title={item.locked ? 'Unlock token' : 'Lock token'}
                        className="p-1 text-[#8e94a0] hover:text-white cursor-pointer"
                      >
                        {item.locked ? (
                          <Lock className="w-3.5 h-3.5 text-[#ff5500]" />
                        ) : (
                          <Unlock className="w-3.5 h-3.5" />
                        )}
                      </button>

                      <button
                        onClick={() => handleDuplicateColour(item)}
                        title="Duplicate token"
                        className="p-1 text-[#8e94a0] hover:text-white cursor-pointer"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => removePaletteColour(item.id)}
                        title="Remove token"
                        className="p-1 text-[#8e94a0] hover:text-[#e53e3e] cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
