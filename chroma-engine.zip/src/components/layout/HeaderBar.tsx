'use client';

import React from 'react';
import { useColourStore } from '../../state/colour-store';
import {
  Sliders,
  Sparkles,
  Undo2,
  Redo2,
  Terminal,
  Monitor,
  CheckCircle2,
  HelpCircle,
} from 'lucide-react';

export function HeaderBar() {
  const {
    state,
    undo,
    redo,
    canUndo,
    canRedo,
    setDisplayProfile,
    setRenderMode,
    setCommandPaletteOpen,
    startDemoWorkflow,
  } = useColourStore();

  return (
    <header className="border-b border-[#22262e] bg-[#111317] text-[#f4f4f6] px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 select-none text-xs">
      {/* Brand Identity & System Title */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <div
            className="w-4 h-4 rounded-xs border border-[#ff5500] shadow-[0_0_8px_rgba(255,85,0,0.4)]"
            style={{ backgroundColor: state.currentColour.hex }}
          />
          <span className="font-mono font-bold text-sm tracking-wider text-white">
            CHROMA ENGINE
          </span>
        </div>
        <div className="hidden lg:block h-3.5 w-px bg-[#262930]" />
        <span className="hidden lg:inline text-[11px] font-mono text-[#8e94a0] uppercase tracking-wider">
          Colour Science Workstation
        </span>
      </div>

      {/* Project Status Readouts */}
      <div className="hidden xl:flex items-center gap-4 font-mono text-[11px] text-[#9ba1ad]">
        <div className="flex items-center gap-1.5">
          <span className="text-[#646a78]">PROJECT:</span>
          <span className="text-[#f4f4f6] font-semibold">{state.name}</span>
        </div>
        <div className="h-3 w-px bg-[#22262e]" />
        <div className="flex items-center gap-1.5">
          <span className="text-[#646a78]">COLOUR:</span>
          <span
            className="px-1.5 py-0.5 rounded-xs font-bold text-white text-[10px]"
            style={{ backgroundColor: state.currentColour.hex }}
          >
            {state.currentColour.hex}
          </span>
          <span className="text-[#c5c8d0] truncate max-w-[140px]">
            {state.currentColour.name}
          </span>
        </div>
      </div>

      {/* Control Matrix & Actions */}
      <div className="flex items-center gap-2 font-mono">
        {/* Profile Selector */}
        <div className="flex items-center bg-[#171a20] border border-[#262a33] rounded-xs px-2 py-1 text-[11px]">
          <Monitor className="w-3.5 h-3.5 text-[#ff5500] mr-1.5" />
          <select
            value={state.displayProfile}
            onChange={(e) => setDisplayProfile(e.target.value as any)}
            className="bg-transparent text-[#f4f4f6] focus:outline-none cursor-pointer text-[11px]"
          >
            <option value="sRGB">sRGB (IEC 61966-2-1)</option>
            <option value="Display-P3">Display-P3 (D65)</option>
            <option value="Rec.2020">Rec.2020 (UHDTV)</option>
          </select>
        </div>

        {/* Render Mode */}
        <div className="hidden md:flex items-center bg-[#171a20] border border-[#262a33] rounded-xs px-2 py-1 text-[11px]">
          <select
            value={state.renderMode}
            onChange={(e) => setRenderMode(e.target.value as any)}
            className="bg-transparent text-[#9ba1ad] focus:outline-none cursor-pointer text-[11px]"
          >
            <option value="DISPLAY PREVIEW">MODE: DISPLAY PREVIEW</option>
            <option value="PERCEPTUAL MATCH">MODE: PERCEPTUAL MATCH</option>
            <option value="PRINT SIMULATION">MODE: PRINT SIMULATION</option>
          </select>
        </div>

        {/* History Controls */}
        <div className="flex items-center bg-[#171a20] border border-[#262a33] rounded-xs p-0.5">
          <button
            onClick={undo}
            disabled={!canUndo}
            title="Undo (Ctrl+Z)"
            className="p-1 text-[#9ba1ad] hover:text-white disabled:opacity-30 disabled:hover:text-[#9ba1ad] cursor-pointer"
          >
            <Undo2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={redo}
            disabled={!canRedo}
            title="Redo (Ctrl+Shift+Z)"
            className="p-1 text-[#9ba1ad] hover:text-white disabled:opacity-30 disabled:hover:text-[#9ba1ad] cursor-pointer"
          >
            <Redo2 className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Demo Workflow Guide Trigger */}
        <button
          onClick={startDemoWorkflow}
          className="flex items-center gap-1.5 bg-[#1f242c] hover:bg-[#282e38] text-[#ff5500] border border-[#ff5500]/40 px-2.5 py-1 rounded-xs font-mono text-[11px] font-semibold cursor-pointer transition-colors"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>WORKFLOW</span>
        </button>

        {/* Command Palette Trigger */}
        <button
          onClick={() => setCommandPaletteOpen(true)}
          title="Command Palette (Ctrl+K)"
          className="flex items-center gap-1 bg-[#171a20] hover:bg-[#22262f] text-[#c5c8d0] border border-[#262a33] px-2 py-1 rounded-xs cursor-pointer text-[11px]"
        >
          <Terminal className="w-3.5 h-3.5 text-[#8e94a0]" />
          <span className="hidden sm:inline">CMD</span>
          <kbd className="bg-[#0e1013] text-[#717885] px-1 py-0.2 rounded text-[10px]">
            ⌘K
          </kbd>
        </button>
      </div>
    </header>
  );
}
