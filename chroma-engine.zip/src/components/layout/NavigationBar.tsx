'use client';

import React from 'react';
import { useColourStore } from '../../state/colour-store';
import {
  Sliders,
  Globe,
  Shuffle,
  Compass,
  Palette,
  Layers,
  Contrast,
  Eye,
  Box,
  Sun,
  LayoutGrid,
  Laptop,
  Maximize2,
  FileImage,
  BarChart3,
  Printer,
  Monitor,
  GitCompare,
  FlaskConical,
  Search,
  BookOpen,
  Download,
} from 'lucide-react';

interface NavItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'COLOUR LAB', label: 'COLOUR LAB', icon: Sliders },
  { id: 'COLOUR SPACES', label: 'COLOUR SPACES', icon: Globe },
  { id: 'MIXING ENGINE', label: 'MIXING ENGINE', icon: Shuffle },
  { id: 'HARMONIES', label: 'HARMONIES', icon: Compass },
  { id: 'PALETTE STUDIO', label: 'PALETTE STUDIO', icon: Palette },
  { id: 'TONAL SYSTEM', label: 'TONAL SYSTEM', icon: Layers },
  { id: 'CONTRAST', label: 'CONTRAST', icon: Contrast },
  { id: 'ACCESSIBILITY', label: 'ACCESSIBILITY', icon: Eye },
  { id: 'MATERIALS', label: 'MATERIALS', icon: Box },
  { id: 'LIGHTING', label: 'LIGHTING', icon: Sun },
  { id: 'BRAND SYSTEMS', label: 'BRAND SYSTEMS', icon: LayoutGrid },
  { id: 'TOKEN PLAYGROUND', label: 'TOKEN PLAYGROUND', icon: Laptop },
  { id: 'GRADIENTS', label: 'GRADIENTS', icon: Maximize2 },
  { id: 'IMAGE ANALYSIS', label: 'IMAGE ANALYSIS', icon: FileImage },
  { id: 'DATA COLOUR', label: 'DATA COLOUR', icon: BarChart3 },
  { id: 'PRINT & PRODUCTION', label: 'PRINT & PRODUCTION', icon: Printer },
  { id: 'DISPLAY', label: 'DISPLAY', icon: Monitor },
  { id: 'DIFFERENCE', label: 'DIFFERENCE', icon: GitCompare },
  { id: 'EXPERIMENTS', label: 'EXPERIMENTS', icon: FlaskConical },
  { id: 'COLOUR SEARCH', label: 'SEARCH', icon: Search },
  { id: 'LIBRARY', label: 'LIBRARY', icon: BookOpen },
  { id: 'EXPORT', label: 'EXPORT', icon: Download },
];

export function NavigationBar() {
  const { state, setActiveNavTab } = useColourStore();

  return (
    <nav className="bg-[#111317] border-b border-[#22262e] px-2 py-1 overflow-x-auto flex items-center gap-1 scrollbar-none select-none text-xs font-mono">
      {NAV_ITEMS.map((item) => {
        const Icon = item.icon;
        const isActive = state.activeNavTab === item.id;

        return (
          <button
            key={item.id}
            onClick={() => setActiveNavTab(item.id)}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xs transition-colors whitespace-nowrap cursor-pointer text-[11px] font-medium tracking-tight ${
              isActive
                ? 'bg-[#1e222a] text-[#ff5500] border-b-2 border-[#ff5500] font-semibold'
                : 'text-[#8e94a0] hover:text-[#f4f4f6] hover:bg-[#16181f]'
            }`}
          >
            <Icon
              className={`w-3.5 h-3.5 ${
                isActive ? 'text-[#ff5500]' : 'text-[#6a707e]'
              }`}
            />
            <span>{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
}
