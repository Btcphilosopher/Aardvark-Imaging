'use client';

import React from 'react';
import { useColourStore } from '../../state/colour-store';
import {
  ChevronRight,
  ChevronLeft,
  X,
  Sparkles,
  ArrowRight,
  CheckCircle2,
} from 'lucide-react';

const WORKFLOW_STEPS = [
  {
    step: 1,
    title: 'Select Hard Industrial Orange',
    tab: 'COLOUR LAB',
    desc: 'Verify canonical coordinates in sRGB (#D96B24) and OKLCh lightness & chroma.',
  },
  {
    step: 2,
    title: 'Inspect Multi-Space Coordinates',
    tab: 'COLOUR SPACES',
    desc: 'Compare position across sRGB, CIELAB, OKLab, Display-P3, and XYZ chrominance.',
  },
  {
    step: 3,
    title: 'Generate 0..100 Tonal Scale',
    tab: 'TONAL SYSTEM',
    desc: 'Examine lightness steps 0 through 100 with automated WCAG contrast ratios.',
  },
  {
    step: 4,
    title: 'Explore Geometric Harmonies',
    tab: 'HARMONIES',
    desc: 'Generate Complementary, Split-Complementary, and Analogous harmonic pairings.',
  },
  {
    step: 5,
    title: 'Audit System Accessibility',
    tab: 'ACCESSIBILITY',
    desc: 'Simulate Protanopia, Deuteranopia, Tritanopia, and test ISO luminance ratios.',
  },
  {
    step: 6,
    title: 'Apply Tokens to Live Dashboard',
    tab: 'TOKEN PLAYGROUND',
    desc: 'Preview how the industrial orange token drives UI navigation, alerts, and tables.',
  },
  {
    step: 7,
    title: 'Simulate Physical Materials',
    tab: 'MATERIALS',
    desc: 'Render on Anodised Aluminium, Cast Concrete, Brushed Steel, and Ceramic.',
  },
  {
    step: 8,
    title: 'Shift Spectral Lighting',
    tab: 'LIGHTING',
    desc: 'Simulate appearance shift from Daylight D65 to Warm Industrial Sodium / Incandescent.',
  },
  {
    step: 9,
    title: 'Inspect Display Gamut Warnings',
    tab: 'DISPLAY',
    desc: 'Audit P3 wide-gamut volume clipping and deltaE perceptual gamut mapping.',
  },
  {
    step: 10,
    title: 'Export Production Tokens',
    tab: 'EXPORT',
    desc: 'Generate CSS Variables, Tailwind v4 config, TypeScript tokens, and HTML Specimen Sheet.',
  },
];

export function DemoWorkflowBanner() {
  const {
    state,
    nextDemoStep,
    prevDemoStep,
    setDemoStep,
    closeDemoWorkflow,
    setActiveNavTab,
  } = useColourStore();

  if (!state.demoWorkflowActive) return null;

  const current =
    WORKFLOW_STEPS.find((s) => s.step === state.demoWorkflowStep) ||
    WORKFLOW_STEPS[0];

  return (
    <div className="bg-[#14171d] border-b border-[#ff5500]/30 px-4 py-2 flex flex-col md:flex-row items-center justify-between gap-3 text-xs font-mono">
      {/* Step Info */}
      <div className="flex items-center gap-3 w-full md:w-auto">
        <div className="flex items-center gap-1.5 bg-[#ff5500]/15 text-[#ff5500] border border-[#ff5500]/40 px-2 py-0.5 rounded-xs font-bold">
          <Sparkles className="w-3.5 h-3.5" />
          <span>STEP {current.step}/10</span>
        </div>

        <div className="flex flex-col">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-white tracking-wide">
              {current.title}
            </span>
            <button
              onClick={() => setActiveNavTab(current.tab)}
              className="text-[10px] text-[#ff5500] hover:underline flex items-center gap-0.5 cursor-pointer"
            >
              <span>[Open {current.tab}]</span>
              <ArrowRight className="w-2.5 h-2.5" />
            </button>
          </div>
          <span className="text-[11px] text-[#8e94a0]">{current.desc}</span>
        </div>
      </div>

      {/* Step Progress Dots & Pagination */}
      <div className="flex items-center gap-2 w-full md:w-auto justify-between md:justify-end">
        <div className="hidden lg:flex items-center gap-1 mr-2">
          {WORKFLOW_STEPS.map((s) => (
            <button
              key={s.step}
              onClick={() => {
                setDemoStep(s.step);
                setActiveNavTab(s.tab);
              }}
              title={`Step ${s.step}: ${s.title}`}
              className={`w-2.5 h-2.5 rounded-xs transition-all cursor-pointer ${
                s.step === state.demoWorkflowStep
                  ? 'bg-[#ff5500] ring-2 ring-[#ff5500]/40 scale-110'
                  : s.step < state.demoWorkflowStep
                  ? 'bg-[#38a169]'
                  : 'bg-[#262a33] hover:bg-[#3d4350]'
              }`}
            />
          ))}
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={prevDemoStep}
            disabled={state.demoWorkflowStep <= 1}
            className="flex items-center gap-1 bg-[#1c2028] hover:bg-[#252b36] disabled:opacity-30 disabled:hover:bg-[#1c2028] text-[#c5c8d0] border border-[#2a2e38] px-2 py-1 rounded-xs cursor-pointer text-[11px]"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            <span>Prev</span>
          </button>
          <button
            onClick={nextDemoStep}
            disabled={state.demoWorkflowStep >= 10}
            className="flex items-center gap-1 bg-[#ff5500] hover:bg-[#e04b00] disabled:opacity-30 disabled:hover:bg-[#ff5500] text-white font-semibold px-2.5 py-1 rounded-xs cursor-pointer text-[11px]"
          >
            <span>Next Step</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={closeDemoWorkflow}
            title="Dismiss Workflow Guide"
            className="p-1 text-[#6e7583] hover:text-white cursor-pointer ml-1"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
