'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useColourStore } from '../../state/colour-store';
import {
  Search,
  Sliders,
  Globe,
  Shuffle,
  Compass,
  Palette,
  Layers,
  Contrast,
  Eye,
  Box,
  Sun,
  Laptop,
  Maximize2,
  FileImage,
  BarChart3,
  Printer,
  Monitor,
  Download,
  Terminal,
  X,
} from 'lucide-react';
import { MASTER_COLOUR_LIBRARY } from '../../data/colour-library';

export function CommandPalette() {
  const {
    isCommandPaletteOpen,
    setCommandPaletteOpen,
    setActiveNavTab,
    setCurrentColour,
    toggleGamutWarnings,
    toggleHighContrastUi,
    setDisplayProfile,
    startDemoWorkflow,
    resetProject,
  } = useColourStore();

  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isCommandPaletteOpen) {
      const timer = setTimeout(() => {
        setQuery('');
        setSelectedIndex(0);
        inputRef.current?.focus();
      }, 10);
      return () => clearTimeout(timer);
    }
  }, [isCommandPaletteOpen]);

  if (!isCommandPaletteOpen) return null;

  const commands = [
    {
      id: 'lab',
      label: 'Open Colour Lab',
      category: 'Navigation',
      icon: Sliders,
      action: () => setActiveNavTab('COLOUR LAB'),
    },
    {
      id: 'spaces',
      label: 'Open Colour Spaces Lab',
      category: 'Navigation',
      icon: Globe,
      action: () => setActiveNavTab('COLOUR SPACES'),
    },
    {
      id: 'mix',
      label: 'Open Mixing Engine (Light & Subtractive Pigment)',
      category: 'Navigation',
      icon: Shuffle,
      action: () => setActiveNavTab('MIXING ENGINE'),
    },
    {
      id: 'harmonies',
      label: 'Generate Harmonies (Complementary, Triadic, Square)',
      category: 'Navigation',
      icon: Compass,
      action: () => setActiveNavTab('HARMONIES'),
    },
    {
      id: 'palette',
      label: 'Open Palette Studio',
      category: 'Navigation',
      icon: Palette,
      action: () => setActiveNavTab('PALETTE STUDIO'),
    },
    {
      id: 'tonal',
      label: 'Create 0..100 Tonal Scale',
      category: 'Navigation',
      icon: Layers,
      action: () => setActiveNavTab('TONAL SYSTEM'),
    },
    {
      id: 'contrast',
      label: 'Analyse WCAG & APCA Contrast',
      category: 'Navigation',
      icon: Contrast,
      action: () => setActiveNavTab('CONTRAST'),
    },
    {
      id: 'a11y',
      label: 'Simulate Colour Blindness (Protanopia / Deuteranopia)',
      category: 'Navigation',
      icon: Eye,
      action: () => setActiveNavTab('ACCESSIBILITY'),
    },
    {
      id: 'materials',
      label: 'Open Physical Materials Laboratory',
      category: 'Navigation',
      icon: Box,
      action: () => setActiveNavTab('MATERIALS'),
    },
    {
      id: 'lighting',
      label: 'Open Spectral Lighting Laboratory',
      category: 'Navigation',
      icon: Sun,
      action: () => setActiveNavTab('LIGHTING'),
    },
    {
      id: 'playground',
      label: 'Open Design Token UI Playground',
      category: 'Navigation',
      icon: Laptop,
      action: () => setActiveNavTab('TOKEN PLAYGROUND'),
    },
    {
      id: 'gradients',
      label: 'Open Multi-Stop Gradient Engine',
      category: 'Navigation',
      icon: Maximize2,
      action: () => setActiveNavTab('GRADIENTS'),
    },
    {
      id: 'image',
      label: 'Extract Image Palette & Histograms',
      category: 'Navigation',
      icon: FileImage,
      action: () => setActiveNavTab('IMAGE ANALYSIS'),
    },
    {
      id: 'data',
      label: 'Open Data Visualisation Colour Engine',
      category: 'Navigation',
      icon: BarChart3,
      action: () => setActiveNavTab('DATA COLOUR'),
    },
    {
      id: 'print',
      label: 'Open Print & CMYK Production Lab',
      category: 'Navigation',
      icon: Printer,
      action: () => setActiveNavTab('PRINT & PRODUCTION'),
    },
    {
      id: 'export',
      label: 'Export Tokens (CSS, Tailwind, TypeScript, Specimen)',
      category: 'Navigation',
      icon: Download,
      action: () => setActiveNavTab('EXPORT'),
    },
    {
      id: 'workflow',
      label: 'Launch 10-Step AUREOM Demonstration Workflow',
      category: 'System',
      icon: Terminal,
      action: () => startDemoWorkflow(),
    },
    {
      id: 'gamut_warn',
      label: 'Toggle Gamut Warnings',
      category: 'Settings',
      icon: Monitor,
      action: () => toggleGamutWarnings(),
    },
    {
      id: 'high_contrast',
      label: 'Toggle High Contrast UI Mode',
      category: 'Settings',
      icon: Contrast,
      action: () => toggleHighContrastUi(),
    },
    {
      id: 'p3_profile',
      label: 'Switch Profile to Display-P3 (Wide Gamut)',
      category: 'Settings',
      icon: Monitor,
      action: () => setDisplayProfile('Display-P3'),
    },
    {
      id: 'srgb_profile',
      label: 'Switch Profile to sRGB Standard',
      category: 'Settings',
      icon: Monitor,
      action: () => setDisplayProfile('sRGB'),
    },
    {
      id: 'reset',
      label: 'Reset Workspace to AUREOM Default',
      category: 'System',
      icon: X,
      action: () => resetProject(),
    },
  ];

  // Also include colours from library
  const colourCommands = MASTER_COLOUR_LIBRARY.map((c) => ({
    id: `col-${c.id}`,
    label: `Select Colour: ${c.name} (${c.hex})`,
    category: 'Colour Library',
    icon: Sliders,
    colorHex: c.hex,
    action: () => {
      setCurrentColour(c);
      setActiveNavTab('COLOUR LAB');
    },
  }));

  const allItems = [...commands, ...colourCommands];
  const filtered = allItems.filter(
    (item) =>
      item.label.toLowerCase().includes(query.toLowerCase()) ||
      item.category.toLowerCase().includes(query.toLowerCase())
  );

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev + 1) % (filtered.length || 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev - 1 + filtered.length) % (filtered.length || 1));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (filtered[selectedIndex]) {
        filtered[selectedIndex].action();
        setCommandPaletteOpen(false);
      }
    } else if (e.key === 'Escape') {
      setCommandPaletteOpen(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-start justify-center pt-[12vh] p-4"
      onClick={() => setCommandPaletteOpen(false)}
    >
      <div
        className="w-full max-w-2xl bg-[#14171d] border border-[#2a2f3a] rounded-sm shadow-2xl overflow-hidden font-mono text-xs flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Header */}
        <div className="flex items-center px-3.5 py-3 border-b border-[#22262f] bg-[#111317]">
          <Search className="w-4 h-4 text-[#ff5500] mr-2.5 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            placeholder="Type a command, colour name, hex code, or system view..."
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
            onKeyDown={handleKeyDown}
            className="w-full bg-transparent text-white placeholder-[#6a7180] focus:outline-none text-xs"
          />
          <kbd className="bg-[#1c2028] text-[#8e94a0] border border-[#2a2e38] px-1.5 py-0.5 rounded text-[10px]">
            ESC
          </kbd>
        </div>

        {/* Results List */}
        <div className="max-h-[380px] overflow-y-auto p-1.5 divide-y divide-[#1e222b]/50">
          {filtered.length === 0 ? (
            <div className="p-6 text-center text-[#6e7583]">
              No matching commands or colours found for &quot;{query}&quot;
            </div>
          ) : (
            filtered.map((item, idx) => {
              const Icon = item.icon;
              const isSelected = idx === selectedIndex;

              return (
                <div
                  key={item.id}
                  onClick={() => {
                    item.action();
                    setCommandPaletteOpen(false);
                  }}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`flex items-center justify-between px-3 py-2 rounded-xs cursor-pointer transition-colors ${
                    isSelected ? 'bg-[#1f242e] text-white' : 'text-[#9ba1ad] hover:bg-[#181b22]'
                  }`}
                >
                  <div className="flex items-center gap-2.5 truncate">
                    {'colorHex' in item && typeof (item as any).colorHex === 'string' ? (
                      <div
                        className="w-3.5 h-3.5 rounded-xs border border-[#333742] shrink-0"
                        style={{ backgroundColor: (item as any).colorHex }}
                      />
                    ) : (
                      <Icon
                        className={`w-3.5 h-3.5 shrink-0 ${
                          isSelected ? 'text-[#ff5500]' : 'text-[#6e7583]'
                        }`}
                      />
                    )}
                    <span className="truncate font-medium">{item.label}</span>
                  </div>

                  <span className="text-[10px] text-[#646a78] uppercase shrink-0 ml-3">
                    {item.category}
                  </span>
                </div>
              );
            })
          )}
        </div>

        {/* Footer info */}
        <div className="bg-[#101216] px-3.5 py-2 border-t border-[#1e222b] flex items-center justify-between text-[10px] text-[#6e7583]">
          <div className="flex items-center gap-3">
            <span>↑↓ Navigate</span>
            <span>↵ Select</span>
            <span>ESC Close</span>
          </div>
          <span className="text-[#8e94a0]">CHROMA COMMAND ENGINE</span>
        </div>
      </div>
    </div>
  );
}
