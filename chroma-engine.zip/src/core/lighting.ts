import { LightingCondition, LightingPreset, ColourRecord, RGB } from '../types/colour';
import { createColourRecord, srgbToLinear, linearToSrgb } from './colour-math';

export const LIGHTING_PRESETS: LightingCondition[] = [
  {
    preset: 'daylight-d65',
    name: 'Daylight D65 (6500K)',
    temperatureK: 6500,
    intensity: 1.0,
    ambientLevel: 0.25,
    angleDeg: 45,
    rgbFilter: { r: 255, g: 255, b: 255 },
    description: 'CIE Standard Illuminant D65. Balanced mid-day solar spectrum with clear blue sky contribution.',
  },
  {
    preset: 'overcast-7500k',
    name: 'Overcast Sky (7500K)',
    temperatureK: 7500,
    intensity: 0.9,
    ambientLevel: 0.45,
    angleDeg: 90,
    rgbFilter: { r: 235, g: 245, b: 255 },
    description: 'Diffuse cloud-scattered sunlight. Cool blue-shifted spectrum with high ambient fill and low directional specular.',
  },
  {
    preset: 'incandescent-2700k',
    name: 'Warm Incandescent / Tungsten (2700K)',
    temperatureK: 2700,
    intensity: 1.1,
    ambientLevel: 0.2,
    angleDeg: 35,
    rgbFilter: { r: 255, g: 195, b: 130 },
    description: 'Blackbody radiator at 2700K. Heavy emission in red/infrared, strong attenuation of blues and cyans.',
  },
  {
    preset: 'cool-led-4000k',
    name: 'Architectural Cool White LED (4000K)',
    temperatureK: 4000,
    intensity: 1.05,
    ambientLevel: 0.3,
    angleDeg: 60,
    rgbFilter: { r: 250, g: 245, b: 235 },
    description: 'Phosphor-converted blue LED. Sharp 450nm pump spike with broad yellow phosphor emission; crisp high CRI.',
  },
  {
    preset: 'gallery-halogen-3000k',
    name: 'Museum Gallery Halogen (3000K)',
    temperatureK: 3000,
    intensity: 1.15,
    ambientLevel: 0.15,
    angleDeg: 40,
    rgbFilter: { r: 255, g: 215, b: 165 },
    description: 'Continuous smooth incandescent spectrum with 99+ CRI. Renders warm industrial oranges and woods with high fidelity.',
  },
  {
    preset: 'sunset-2200k',
    name: 'Golden Hour Sunset (2200K)',
    temperatureK: 2200,
    intensity: 0.85,
    ambientLevel: 0.35,
    angleDeg: 15,
    rgbFilter: { r: 255, g: 150, b: 70 },
    description: 'Low-angle Rayleigh scattering. Extreme atmospheric absorption of short wavelengths, casting intense amber brilliance.',
  },
  {
    preset: 'moonlight-4100k',
    name: 'Night Moonlight / Mesopic (4100K)',
    temperatureK: 4100,
    intensity: 0.35,
    ambientLevel: 0.1,
    angleDeg: 75,
    rgbFilter: { r: 180, g: 205, b: 240 },
    description: 'Reflected solar spectrum attenuated by Purkinje shift. Low scotopic luminance with muted color discrimination.',
  },
  {
    preset: 'industrial-sodium',
    name: 'High-Pressure Sodium (2000K)',
    temperatureK: 2000,
    intensity: 0.95,
    ambientLevel: 0.2,
    angleDeg: 50,
    rgbFilter: { r: 255, g: 165, b: 40 },
    description: 'Industrial high-pressure sodium discharge. Strong 589nm doublet emission causing severe color rendering collapse.',
  },
];

/**
 * Simulates how a colour record reflects light under a specific illuminant
 */
export function simulateIlluminatedColour(
  colour: ColourRecord,
  light: LightingCondition
): ColourRecord {
  // Linear light multiplication
  const linR = srgbToLinear(colour.srgb.r);
  const linG = srgbToLinear(colour.srgb.g);
  const linB = srgbToLinear(colour.srgb.b);

  const lightR = srgbToLinear(light.rgbFilter.r) * light.intensity;
  const lightG = srgbToLinear(light.rgbFilter.g) * light.intensity;
  const lightB = srgbToLinear(light.rgbFilter.b) * light.intensity;

  // Reflected linear flux = diffuse reflectance * incident light + ambient
  const ambient = light.ambientLevel;
  const reflR = linR * (lightR * (1 - ambient) + ambient);
  const reflG = linG * (lightG * (1 - ambient) + ambient);
  const reflB = linB * (lightB * (1 - ambient) + ambient);

  const outR = linearToSrgb(Math.max(0, Math.min(1, reflR)));
  const outG = linearToSrgb(Math.max(0, Math.min(1, reflG)));
  const outB = linearToSrgb(Math.max(0, Math.min(1, reflB)));

  return createColourRecord(
    { r: outR, g: outG, b: outB },
    colour.alpha,
    `${colour.name} under ${light.name}`
  );
}
