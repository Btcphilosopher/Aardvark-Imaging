import { MaterialCategory, MaterialSpec, ColourRecord } from '../types/colour';

export const MATERIAL_SPECS: MaterialSpec[] = [
  {
    id: 'mat-anodised-aluminium',
    name: 'Anodised Aluminium',
    category: 'anodised aluminium',
    roughness: 0.35,
    metallic: 0.85,
    reflectance: 0.75,
    specular: 0.9,
    opacity: 1.0,
    normalNoise: 0.08,
    anisotropy: 0.65,
    description: 'Micro-porous oxide layer dyed with deep pigment. Characterised by tight anisotropic sheen and metallic core.',
  },
  {
    id: 'mat-brushed-steel',
    name: 'Brushed Stainless Steel (316L)',
    category: 'brushed steel',
    roughness: 0.45,
    metallic: 0.95,
    reflectance: 0.7,
    specular: 0.85,
    opacity: 1.0,
    normalNoise: 0.25,
    anisotropy: 0.9,
    description: 'Directional micro-grain hairline finish. High specular reflection elongated across the brush vector.',
  },
  {
    id: 'mat-polished-titanium',
    name: 'Polished Titanium (Grade 5)',
    category: 'titanium',
    roughness: 0.15,
    metallic: 0.92,
    reflectance: 0.82,
    specular: 0.95,
    opacity: 1.0,
    normalNoise: 0.03,
    anisotropy: 0.2,
    description: 'Precision mirror-finish aerospace alloy. Warm neutral grey metallic reflectance with sharp specular highlight.',
  },
  {
    id: 'mat-architectural-concrete',
    name: 'Smooth Cast Architectural Concrete',
    category: 'concrete',
    roughness: 0.88,
    metallic: 0.0,
    reflectance: 0.18,
    specular: 0.15,
    opacity: 1.0,
    normalNoise: 0.55,
    anisotropy: 0.0,
    description: 'Fine aggregate mineral finish. High diffuse scattering with subtle air-pocket voids and microporosity.',
  },
  {
    id: 'mat-carbon-fibre',
    name: 'Twill Weave Carbon Fibre (Gloss Clearcoat)',
    category: 'carbon fibre',
    roughness: 0.2,
    metallic: 0.3,
    reflectance: 0.6,
    specular: 0.9,
    opacity: 1.0,
    normalNoise: 0.4,
    anisotropy: 0.75,
    description: '2x2 twill composite weave embedded in optical resin. Deep parallax depth with dual-angle reflections.',
  },
  {
    id: 'mat-automotive-paint',
    name: 'Automotive Multi-Coat Metallic Paint',
    category: 'paint',
    roughness: 0.1,
    metallic: 0.6,
    reflectance: 0.85,
    specular: 0.95,
    opacity: 1.0,
    normalNoise: 0.05,
    anisotropy: 0.1,
    description: 'High-gloss acrylic polyurethane clearcoat over metallic flake base. Pronounced flip-flop angle shift.',
  },
  {
    id: 'mat-ceramic',
    name: 'Sintered Technical Ceramic (Zirconia)',
    category: 'ceramic',
    roughness: 0.18,
    metallic: 0.0,
    reflectance: 0.35,
    specular: 0.8,
    opacity: 1.0,
    normalNoise: 0.04,
    anisotropy: 0.0,
    description: 'Ultra-dense vitreous ceramic. Glass-like specular reflection with warm subsurface diffusion.',
  },
  {
    id: 'mat-oxidised-copper',
    name: 'Verdigris Patinated Copper',
    category: 'oxidised copper',
    roughness: 0.75,
    metallic: 0.35,
    reflectance: 0.25,
    specular: 0.3,
    opacity: 1.0,
    normalNoise: 0.6,
    anisotropy: 0.1,
    description: 'Natural copper carbonate patina. Matte chalky turquoise surface breaking through to metallic bronze.',
  },
  {
    id: 'mat-leather',
    name: 'Full-Grain Semi-Aniline Leather',
    category: 'leather',
    roughness: 0.65,
    metallic: 0.0,
    reflectance: 0.22,
    specular: 0.4,
    opacity: 1.0,
    normalNoise: 0.5,
    anisotropy: 0.15,
    description: 'Supple organic substrate with pebble-grain relief and velvety satin sheen.',
  },
  {
    id: 'mat-sandstone',
    name: 'Fine-Grained Architectural Sandstone',
    category: 'sandstone',
    roughness: 0.92,
    metallic: 0.0,
    reflectance: 0.2,
    specular: 0.08,
    opacity: 1.0,
    normalNoise: 0.7,
    anisotropy: 0.0,
    description: 'Sedimentary quartz matrix. Complete diffuse Lambertian scattering with sandy tactile texture.',
  },
  {
    id: 'mat-smoked-glass',
    name: 'Architectural Tinted Float Glass',
    category: 'glass',
    roughness: 0.05,
    metallic: 0.05,
    reflectance: 0.9,
    specular: 1.0,
    opacity: 0.85,
    normalNoise: 0.01,
    anisotropy: 0.0,
    description: 'Optically flat float glass with internal bulk absorption and clean Fresnel boundary reflection.',
  },
  {
    id: 'mat-textured-rubber',
    name: 'Matte Industrial EPDM Rubber',
    category: 'rubber',
    roughness: 0.8,
    metallic: 0.0,
    reflectance: 0.1,
    specular: 0.2,
    opacity: 1.0,
    normalNoise: 0.45,
    anisotropy: 0.05,
    description: 'High-friction polymer with ultra-deep absorption and subtle specular micro-sheen.',
  },
];

/**
 * Render physical material swatch onto an HTML5 Canvas
 */
export function renderMaterialPreview(
  canvas: HTMLCanvasElement,
  colour: ColourRecord,
  material: MaterialSpec,
  lightingIntensity: number = 1.0,
  lightAngleDeg: number = 45,
  lightTempK: number = 6500
): void {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const w = canvas.width;
  const h = canvas.height;
  ctx.clearRect(0, 0, w, h);

  const cx = w / 2;
  const cy = h / 2;
  const radius = Math.min(w, h) * 0.44;

  // Background subtle technical grid
  ctx.fillStyle = '#14161a';
  ctx.fillRect(0, 0, w, h);

  // Subtle border rim
  ctx.strokeStyle = '#262930';
  ctx.lineWidth = 1;
  ctx.strokeRect(0.5, 0.5, w - 1, h - 1);

  // Light vector calculation
  const lightRad = (lightAngleDeg * Math.PI) / 180;
  const lx = cx + Math.cos(lightRad) * radius * 0.7;
  const ly = cy - Math.sin(lightRad) * radius * 0.7;

  // Primary sphere gradient (Fresnel + diffuse shading)
  const sphereGrad = ctx.createRadialGradient(
    lx,
    ly,
    radius * 0.05,
    cx,
    cy,
    radius
  );

  const baseR = colour.srgb.r;
  const baseG = colour.srgb.g;
  const baseB = colour.srgb.b;

  // Highlight color affected by metallicness and light temp
  const isMetallic = material.metallic > 0.5;
  const highlightR = isMetallic ? Math.round(baseR * 0.8 + 255 * 0.2) : 255;
  const highlightG = isMetallic ? Math.round(baseG * 0.8 + 255 * 0.2) : 255;
  const highlightB = isMetallic ? Math.round(baseB * 0.8 + 255 * 0.2) : 255;

  const shadowR = Math.round(baseR * 0.25 * (1 - material.roughness * 0.2));
  const shadowG = Math.round(baseG * 0.25 * (1 - material.roughness * 0.2));
  const shadowB = Math.round(baseB * 0.25 * (1 - material.roughness * 0.2));

  sphereGrad.addColorStop(
    0,
    `rgba(${highlightR}, ${highlightG}, ${highlightB}, ${material.specular * lightingIntensity})`
  );
  sphereGrad.addColorStop(
    0.3,
    `rgba(${baseR}, ${baseG}, ${baseB}, ${material.opacity})`
  );
  sphereGrad.addColorStop(
    0.85,
    `rgba(${Math.round(baseR * 0.6)}, ${Math.round(baseG * 0.6)}, ${Math.round(baseB * 0.6)}, 1.0)`
  );
  sphereGrad.addColorStop(
    1.0,
    `rgba(${shadowR}, ${shadowG}, ${shadowB}, 1.0)`
  );

  // Draw 3D curved material sample pill / sphere
  ctx.save();
  ctx.beginPath();
  ctx.arc(cx, cy, radius, 0, Math.PI * 2);
  ctx.closePath();
  ctx.fillStyle = sphereGrad;
  ctx.fill();
  ctx.clip();

  // Draw procedural surface noise / grain / brushed anisotropy
  const imgData = ctx.getImageData(cx - radius, cy - radius, radius * 2, radius * 2);
  const data = imgData.data;

  const noiseAmp = material.normalNoise * 28;
  const aniso = material.anisotropy;

  for (let y = 0; y < radius * 2; y++) {
    for (let x = 0; x < radius * 2; x++) {
      const idx = (y * (radius * 2) + x) * 4;
      if (data[idx + 3] > 0) {
        // Procedural anisotropic brush or stipple
        let n = (Math.random() - 0.5) * noiseAmp;
        if (aniso > 0.3) {
          // Horizontal brushed streak lines
          const streak = Math.sin(y * 1.5) * 8 * aniso;
          n += streak;
        }

        data[idx] = Math.max(0, Math.min(255, data[idx] + n));
        data[idx + 1] = Math.max(0, Math.min(255, data[idx + 1] + n));
        data[idx + 2] = Math.max(0, Math.min(255, data[idx + 2] + n));
      }
    }
  }

  ctx.putImageData(imgData, cx - radius, cy - radius);

  // Specular gleam
  if (material.roughness < 0.5) {
    const specGrad = ctx.createRadialGradient(lx, ly, 1, lx, ly, radius * (0.5 - material.roughness * 0.6));
    specGrad.addColorStop(0, `rgba(255, 255, 255, ${0.9 * (1 - material.roughness) * lightingIntensity})`);
    specGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');

    ctx.fillStyle = specGrad;
    ctx.beginPath();
    ctx.arc(lx, ly, radius * 0.4, 0, Math.PI * 2);
    ctx.fill();
  }

  // Rim lighting
  ctx.strokeStyle = `rgba(255, 255, 255, ${0.15 * material.reflectance})`;
  ctx.lineWidth = 2;
  ctx.stroke();

  ctx.restore();
}
