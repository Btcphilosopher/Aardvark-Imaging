import {
  RGB,
  LinearRGB,
  HSL,
  HSV,
  HWB,
  XYZ,
  Lab,
  LCh,
  OKLab,
  OKLCh,
  CMYK,
  DisplayP3,
  Rec2020,
  GamutStatus,
  ContrastMetrics,
  ColourRecord,
  ColourMetadata,
} from '../types/colour';

// ==========================================
// 1. CONSTANTS & REFERENCE WHITE POINTS (D65)
// ==========================================
// Standard 2-degree observer D65 white point
export const D65 = {
  X: 95.047,
  Y: 100.0,
  Z: 108.883,
};

// Matrices for sRGB (D65) <-> XYZ
const SRGB_TO_XYZ_MATRIX = [
  [0.4124564, 0.3575761, 0.1804375],
  [0.2126729, 0.7151522, 0.072175],
  [0.0193339, 0.119192, 0.9503041],
];

const XYZ_TO_SRGB_MATRIX = [
  [3.2404542, -1.5371385, -0.4985314],
  [-0.969266, 1.8760108, 0.041556],
  [0.0556434, -0.2040259, 1.0572252],
];

// Display P3 (D65) <-> XYZ
const P3_TO_XYZ_MATRIX = [
  [0.4865709, 0.2656677, 0.1982173],
  [0.2289746, 0.6917393, 0.0792859],
  [0.0, 0.0451134, 1.0439444],
];

const XYZ_TO_P3_MATRIX = [
  [2.4934969, -0.9313836, -0.4027108],
  [-0.829489, 1.7626641, 0.0236247],
  [0.0358458, -0.0761724, 0.9568845],
];

// Rec.2020 (D65) <-> XYZ
const REC2020_TO_XYZ_MATRIX = [
  [0.636958, 0.1446169, 0.168881],
  [0.2627002, 0.6779981, 0.0593017],
  [0.0, 0.0280727, 1.0609851],
];

const XYZ_TO_REC2020_MATRIX = [
  [1.7166512, -0.3556708, -0.2533663],
  [-0.6666844, 1.6164812, 0.0157685],
  [0.0176399, -0.0427706, 0.9421031],
];

// OKLab Matrices (Björn Ottosson, 2020)
const M1_OKLAB = [
  [0.8189330101, 0.3618667424, -0.1288597137],
  [0.0329845436, 0.9293118715, 0.0361456387],
  [0.0482003018, 0.2643662691, 0.633851707],
];

const M1_INV_OKLAB = [
  [1.2270138511, -0.5577999807, 0.281256149],
  [-0.0405801784, 1.1122568696, -0.0716766787],
  [-0.0763812845, -0.4214819784, 1.5861632204],
];

const M2_OKLAB = [
  [0.2104542553, 0.793617785, -0.0040720468],
  [1.9779984951, -2.428592205, 0.4505937099],
  [0.0259040371, 0.7827717662, -0.808675766],
];

const M2_INV_OKLAB = [
  [1.0, 0.3963377774, 0.2158037573],
  [1.0, -0.1055613458, -0.0638541728],
  [1.0, -0.0894841775, -1.291485548],
];

// ==========================================
// 2. LINEARISATION & GAMMA CONVERSIONS
// ==========================================

export function srgbToLinear(val: number): number {
  const v = val / 255;
  if (v <= 0.04045) {
    return v / 12.92;
  }
  return Math.pow((v + 0.055) / 1.055, 2.4);
}

export function linearToSrgb(val: number): number {
  let v: number;
  if (val <= 0.0031308) {
    v = val * 12.92;
  } else {
    v = 1.055 * Math.pow(val, 1 / 2.4) - 0.055;
  }
  return Math.max(0, Math.min(255, Math.round(v * 255)));
}

export function rgbToLinearRgb(rgb: RGB): LinearRGB {
  return {
    r: srgbToLinear(rgb.r),
    g: srgbToLinear(rgb.g),
    b: srgbToLinear(rgb.b),
  };
}

export function linearRgbToRgb(lin: LinearRGB): RGB {
  return {
    r: linearToSrgb(lin.r),
    g: linearToSrgb(lin.g),
    b: linearToSrgb(lin.b),
  };
}

// ==========================================
// 3. RGB <-> HEX
// ==========================================

export function rgbToHex(rgb: RGB, alpha: number = 1): string {
  const r = Math.max(0, Math.min(255, Math.round(rgb.r))).toString(16).padStart(2, '0');
  const g = Math.max(0, Math.min(255, Math.round(rgb.g))).toString(16).padStart(2, '0');
  const b = Math.max(0, Math.min(255, Math.round(rgb.b))).toString(16).padStart(2, '0');
  if (alpha < 1) {
    const a = Math.max(0, Math.min(255, Math.round(alpha * 255))).toString(16).padStart(2, '0');
    return `#${r}${g}${b}${a}`.toUpperCase();
  }
  return `#${r}${g}${b}`.toUpperCase();
}

export const srgbToHex = rgbToHex;

export function hexToRgb(hex: string): { rgb: RGB; alpha: number } {
  let clean = hex.replace(/^#/, '').trim();
  let alpha = 1;

  if (clean.length === 3) {
    clean = clean.split('').map((c) => c + c).join('');
  } else if (clean.length === 4) {
    const chars = clean.split('');
    clean = chars.slice(0, 3).map((c) => c + c).join('');
    alpha = parseInt(chars[3] + chars[3], 16) / 255;
  } else if (clean.length === 8) {
    alpha = parseInt(clean.substring(6, 8), 16) / 255;
    clean = clean.substring(0, 6);
  }

  if (clean.length !== 6) {
    // Fallback on parse failure
    return { rgb: { r: 217, g: 107, b: 36 }, alpha: 1 };
  }

  const num = parseInt(clean, 16);
  if (isNaN(num)) {
    return { rgb: { r: 217, g: 107, b: 36 }, alpha: 1 };
  }

  return {
    rgb: {
      r: (num >> 16) & 255,
      g: (num >> 8) & 255,
      b: num & 255,
    },
    alpha: isNaN(alpha) ? 1 : Math.max(0, Math.min(1, alpha)),
  };
}

// ==========================================
// 4. MATRIX MULTIPLICATION HELPER
// ==========================================

function multiplyMatrix3x3(matrix: number[][], vec: [number, number, number]): [number, number, number] {
  return [
    matrix[0][0] * vec[0] + matrix[0][1] * vec[1] + matrix[0][2] * vec[2],
    matrix[1][0] * vec[0] + matrix[1][1] * vec[1] + matrix[1][2] * vec[2],
    matrix[2][0] * vec[0] + matrix[2][1] * vec[1] + matrix[2][2] * vec[2],
  ];
}

// ==========================================
// 5. RGB <-> XYZ (D65)
// ==========================================

export function linearRgbToXyz(lin: LinearRGB): XYZ {
  const [x, y, z] = multiplyMatrix3x3(SRGB_TO_XYZ_MATRIX, [lin.r, lin.g, lin.b]);
  return {
    x: x * 100,
    y: y * 100,
    z: z * 100,
  };
}

export function xyzToLinearRgb(xyz: XYZ): LinearRGB {
  const [r, g, b] = multiplyMatrix3x3(XYZ_TO_SRGB_MATRIX, [xyz.x / 100, xyz.y / 100, xyz.z / 100]);
  return { r, g, b };
}

export function rgbToXyz(rgb: RGB): XYZ {
  return linearRgbToXyz(rgbToLinearRgb(rgb));
}

export function xyzToRgb(xyz: XYZ): RGB {
  return linearRgbToRgb(xyzToLinearRgb(xyz));
}

// ==========================================
// 6. XYZ <-> CIELAB (D65) & CIELCh
// ==========================================

function labF(t: number): number {
  const delta = 6 / 29;
  if (t > delta * delta * delta) {
    return Math.cbrt(t);
  }
  return t / (3 * delta * delta) + 4 / 29;
}

function labFInv(t: number): number {
  const delta = 6 / 29;
  if (t > delta) {
    return t * t * t;
  }
  return 3 * delta * delta * (t - 4 / 29);
}

export function xyzToLab(xyz: XYZ): Lab {
  const fx = labF(xyz.x / D65.X);
  const fy = labF(xyz.y / D65.Y);
  const fz = labF(xyz.z / D65.Z);

  const l = 116 * fy - 16;
  const a = 500 * (fx - fy);
  const b = 200 * (fy - fz);

  return {
    l: Math.max(0, Math.min(100, l)),
    a,
    b,
  };
}

export function labToXyz(lab: Lab): XYZ {
  const fy = (lab.l + 16) / 116;
  const fx = lab.a / 500 + fy;
  const fz = fy - lab.b / 200;

  return {
    x: D65.X * labFInv(fx),
    y: D65.Y * labFInv(fy),
    z: D65.Z * labFInv(fz),
  };
}

export function labToLch(lab: Lab): LCh {
  const c = Math.hypot(lab.a, lab.b);
  let h = (Math.atan2(lab.b, lab.a) * 180) / Math.PI;
  if (h < 0) h += 360;
  return {
    l: lab.l,
    c: Number(c.toFixed(2)),
    h: Number(h.toFixed(2)),
  };
}

export function lchToLab(lch: LCh): Lab {
  const rad = (lch.h * Math.PI) / 180;
  return {
    l: lch.l,
    a: lch.c * Math.cos(rad),
    b: lch.c * Math.sin(rad),
  };
}

// ==========================================
// 7. XYZ <-> OKLab & OKLCh
// ==========================================

export function xyzToOklab(xyz: XYZ): OKLab {
  // Normalize XYZ to 0..1 range
  const x = xyz.x / 100;
  const y = xyz.y / 100;
  const z = xyz.z / 100;

  const [lLin, mLin, sLin] = multiplyMatrix3x3(M1_OKLAB, [x, y, z]);

  // Non-linear cube-root (preserving negative signs)
  const l = Math.cbrt(Math.max(0, lLin));
  const m = Math.cbrt(Math.max(0, mLin));
  const s = Math.cbrt(Math.max(0, sLin));

  const [L, a, b] = multiplyMatrix3x3(M2_OKLAB, [l, m, s]);

  return {
    l: Math.max(0, Math.min(1, L)),
    a,
    b,
  };
}

export function oklabToXyz(oklab: OKLab): XYZ {
  const [l, m, s] = multiplyMatrix3x3(M2_INV_OKLAB, [oklab.l, oklab.a, oklab.b]);

  const lLin = l * l * l;
  const mLin = m * m * m;
  const sLin = s * s * s;

  const [x, y, z] = multiplyMatrix3x3(M1_INV_OKLAB, [lLin, mLin, sLin]);

  return {
    x: x * 100,
    y: y * 100,
    z: z * 100,
  };
}

export function oklabToOklch(oklab: OKLab): OKLCh {
  const c = Math.hypot(oklab.a, oklab.b);
  let h = (Math.atan2(oklab.b, oklab.a) * 180) / Math.PI;
  if (h < 0) h += 360;
  return {
    l: Number(oklab.l.toFixed(4)),
    c: Number(c.toFixed(4)),
    h: Number(h.toFixed(2)),
  };
}

export function oklchToOklab(oklch: OKLCh): OKLab {
  const rad = (oklch.h * Math.PI) / 180;
  return {
    l: oklch.l,
    a: oklch.c * Math.cos(rad),
    b: oklch.c * Math.sin(rad),
  };
}

// ==========================================
// 8. HSL, HSV & HWB
// ==========================================

export function rgbToHsl(rgb: RGB): HSL {
  const r = rgb.r / 255;
  const g = rgb.g / 255;
  const b = rgb.b / 255;

  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const d = max - min;
  let h = 0;
  let s = 0;
  const l = (max + min) / 2;

  if (d !== 0) {
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      case b:
        h = (r - g) / d + 4;
        break;
    }
    h *= 60;
  }

  return {
    h: Math.round(h),
    s: Math.round(s * 100),
    l: Math.round(l * 100),
  };
}

export function hslToRgb(hsl: HSL): RGB {
  const h = hsl.h / 360;
  const s = hsl.s / 100;
  const l = hsl.l / 100;

  if (s === 0) {
    const val = Math.round(l * 255);
    return { r: val, g: val, b: val };
  }

  const hue2rgb = (p: number, q: number, t: number) => {
    let tt = t;
    if (tt < 0) tt += 1;
    if (tt > 1) tt -= 1;
    if (tt < 1 / 6) return p + (q - p) * 6 * tt;
    if (tt < 1 / 2) return q;
    if (tt < 2 / 3) return p + (q - p) * (2 / 3 - tt) * 6;
    return p;
  };

  const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
  const p = 2 * l - q;

  return {
    r: Math.round(hue2rgb(p, q, h + 1 / 3) * 255),
    g: Math.round(hue2rgb(p, q, h) * 255),
    b: Math.round(hue2rgb(p, q, h - 1 / 3) * 255),
  };
}

export function rgbToHsv(rgb: RGB): HSV {
  const r = rgb.r / 255;
  const g = rgb.g / 255;
  const b = rgb.b / 255;

  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const d = max - min;
  let h = 0;
  const s = max === 0 ? 0 : d / max;
  const v = max;

  if (d !== 0) {
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      case b:
        h = (r - g) / d + 4;
        break;
    }
    h *= 60;
  }

  return {
    h: Math.round(h),
    s: Math.round(s * 100),
    v: Math.round(v * 100),
  };
}

export function rgbToHwb(rgb: RGB): HWB {
  const hsl = rgbToHsl(rgb);
  const r = rgb.r / 255;
  const g = rgb.g / 255;
  const b = rgb.b / 255;
  const w = Math.min(r, g, b);
  const bk = 1 - Math.max(r, g, b);

  return {
    h: hsl.h,
    w: Math.round(w * 100),
    b: Math.round(bk * 100),
  };
}

// ==========================================
// 9. CMYK APPROXIMATION
// ==========================================

export function rgbToCmyk(rgb: RGB): CMYK {
  const r = rgb.r / 255;
  const g = rgb.g / 255;
  const b = rgb.b / 255;

  const k = 1 - Math.max(r, g, b);
  if (k === 1) {
    return { c: 0, m: 0, y: 0, k: 100 };
  }

  const c = (1 - r - k) / (1 - k);
  const m = (1 - g - k) / (1 - k);
  const y = (1 - b - k) / (1 - k);

  return {
    c: Math.round(c * 100),
    m: Math.round(m * 100),
    y: Math.round(y * 100),
    k: Math.round(k * 100),
  };
}

// ==========================================
// 10. DISPLAY P3 & REC.2020
// ==========================================

export function xyzToDisplayP3(xyz: XYZ): DisplayP3 {
  const [r, g, b] = multiplyMatrix3x3(XYZ_TO_P3_MATRIX, [xyz.x / 100, xyz.y / 100, xyz.z / 100]);
  return {
    r: Math.max(0, Math.min(1, r)),
    g: Math.max(0, Math.min(1, g)),
    b: Math.max(0, Math.min(1, b)),
  };
}

export function xyzToRec2020(xyz: XYZ): Rec2020 {
  const [r, g, b] = multiplyMatrix3x3(XYZ_TO_REC2020_MATRIX, [xyz.x / 100, xyz.y / 100, xyz.z / 100]);
  return {
    r: Math.max(0, Math.min(1, r)),
    g: Math.max(0, Math.min(1, g)),
    b: Math.max(0, Math.min(1, b)),
  };
}

// ==========================================
// 11. GAMUT CHECKING & GAMUT MAPPING
// ==========================================

export function checkGamut(xyz: XYZ): GamutStatus {
  const linSRGB = xyzToLinearRgb(xyz);
  const inSRGB =
    linSRGB.r >= -0.001 &&
    linSRGB.r <= 1.001 &&
    linSRGB.g >= -0.001 &&
    linSRGB.g <= 1.001 &&
    linSRGB.b >= -0.001 &&
    linSRGB.b <= 1.001;

  const [p3R, p3G, p3B] = multiplyMatrix3x3(XYZ_TO_P3_MATRIX, [xyz.x / 100, xyz.y / 100, xyz.z / 100]);
  const inP3 =
    p3R >= -0.001 && p3R <= 1.001 && p3G >= -0.001 && p3G <= 1.001 && p3B >= -0.001 && p3B <= 1.001;

  const [recR, recG, recB] = multiplyMatrix3x3(XYZ_TO_REC2020_MATRIX, [xyz.x / 100, xyz.y / 100, xyz.z / 100]);
  const inRec =
    recR >= -0.001 && recR <= 1.001 && recG >= -0.001 && recG <= 1.001 && recB >= -0.001 && recB <= 1.001;

  return {
    inSRGB,
    inDisplayP3: inP3,
    inRec2020: inRec,
    clippedChannels: {
      srgb: {
        r: linSRGB.r < 0 || linSRGB.r > 1,
        g: linSRGB.g < 0 || linSRGB.g > 1,
        b: linSRGB.b < 0 || linSRGB.b > 1,
      },
      p3: {
        r: p3R < 0 || p3R > 1,
        g: p3G < 0 || p3G > 1,
        b: p3B < 0 || p3B > 1,
      },
    },
    gamutMappingApplied: !inSRGB,
  };
}

/**
 * Gamut-maps an OKLCh colour into sRGB by reducing Chroma binary-search style
 * while maintaining Lightness and Hue constant (CSS Color 4 Gamut Mapping standard).
 */
export function mapOklchToSrgbGamut(oklch: OKLCh): OKLCh {
  let low = 0;
  let high = oklch.c;
  let bestC = 0;

  for (let i = 0; i < 20; i++) {
    const mid = (low + high) / 2;
    const testOklab = oklchToOklab({ l: oklch.l, c: mid, h: oklch.h });
    const testXyz = oklabToXyz(testOklab);
    const testLin = xyzToLinearRgb(testXyz);

    const fits =
      testLin.r >= -0.0001 &&
      testLin.r <= 1.0001 &&
      testLin.g >= -0.0001 &&
      testLin.g <= 1.0001 &&
      testLin.b >= -0.0001 &&
      testLin.b <= 1.0001;

    if (fits) {
      bestC = mid;
      low = mid;
    } else {
      high = mid;
    }
  }

  return {
    l: oklch.l,
    c: Number(bestC.toFixed(4)),
    h: oklch.h,
  };
}

// ==========================================
// 12. RELATIVE LUMINANCE & CONTRAST (WCAG 2.1 & APCA)
// ==========================================

export function calculateRelativeLuminance(rgb: RGB): number {
  const r = srgbToLinear(rgb.r);
  const g = srgbToLinear(rgb.g);
  const b = srgbToLinear(rgb.b);
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

export function calculateWcagContrast(lum1: number, lum2: number): number {
  const l1 = Math.max(lum1, lum2);
  const l2 = Math.min(lum1, lum2);
  const ratio = (l1 + 0.05) / (l2 + 0.05);
  return Number(ratio.toFixed(2));
}

// APCA Lightness contrast approximation (W3C Silver/WCAG 3 working draft)
export function calculateApcaContrast(txtLum: number, bgLum: number): number {
  const txtY = Math.max(0, Math.min(1, txtLum));
  const bgY = Math.max(0, Math.min(1, bgLum));

  // Soft power curves
  const txtExp = Math.pow(txtY, 0.56);
  const bgExp = Math.pow(bgY, 0.65);

  let SAPC = 0;
  if (bgY > txtY) {
    // Dark text on light background
    SAPC = (bgExp - Math.pow(txtY, 0.62)) * 1.14;
  } else {
    // Light text on dark background
    SAPC = (Math.pow(txtY, 0.56) - Math.pow(bgY, 0.57)) * 1.14;
  }

  const output = Math.round(SAPC * 100);
  return Math.max(-108, Math.min(108, output));
}

export function evaluateContrast(rgb: RGB): ContrastMetrics {
  const lum = calculateRelativeLuminance(rgb);
  const whiteLum = 1.0;
  const blackLum = 0.0;
  const darkGraphiteLum = calculateRelativeLuminance({ r: 18, g: 20, b: 23 });

  const cWhite = calculateWcagContrast(lum, whiteLum);
  const cBlack = calculateWcagContrast(lum, blackLum);
  const cDark = calculateWcagContrast(lum, darkGraphiteLum);

  const apcaWhite = calculateApcaContrast(lum, whiteLum);
  const apcaBlack = calculateApcaContrast(lum, blackLum);

  const higherContrast = Math.max(cWhite, cBlack);

  return {
    luminance: Number(lum.toFixed(4)),
    contrastOnWhite: cWhite,
    contrastOnBlack: cBlack,
    contrastOnDarkGraphite: cDark,
    apcaOnWhite: apcaWhite,
    apcaOnBlack: apcaBlack,
    wcagAaNormal: higherContrast >= 4.5,
    wcagAaLarge: higherContrast >= 3.0,
    wcagAaaNormal: higherContrast >= 7.0,
    wcagAaaLarge: higherContrast >= 4.5,
  };
}

// ==========================================
// 13. SPECTRAL & TEMPERATURE APPROXIMATIONS
// ==========================================

export function estimateDominantWavelength(hueDeg: number): number {
  // Approximate hue to spectrum locus (380 - 700 nm)
  // 0/360: Red (~650nm)
  // 30: Orange (~600nm)
  // 60: Yellow (~575nm)
  // 120: Green (~530nm)
  // 180: Cyan (~490nm)
  // 240: Blue (~460nm)
  // 280: Violet (~410nm)
  // 320: Non-spectral Purple (returns ~400nm complementary or marker)
  const h = ((hueDeg % 360) + 360) % 360;
  if (h <= 60) {
    return Math.round(650 - (h / 60) * 75); // 650 -> 575nm
  } else if (h <= 120) {
    return Math.round(575 - ((h - 60) / 60) * 45); // 575 -> 530nm
  } else if (h <= 180) {
    return Math.round(530 - ((h - 120) / 60) * 40); // 530 -> 490nm
  } else if (h <= 240) {
    return Math.round(490 - ((h - 180) / 60) * 30); // 490 -> 460nm
  } else if (h <= 300) {
    return Math.round(460 - ((h - 240) / 60) * 60); // 460 -> 400nm
  } else {
    // Purple / non-spectral boundary (300..360 -> 400..650)
    return Math.round(400 + ((h - 300) / 60) * 250);
  }
}

export function estimateCorrelatedColourTemperature(xyz: XYZ): number {
  // McCamy's approximation for CCT from CIE 1931 xy coordinates
  const sum = xyz.x + xyz.y + xyz.z;
  if (sum === 0) return 6500;
  const x = xyz.x / sum;
  const y = xyz.y / sum;

  const n = (x - 0.332) / (0.1858 - y);
  const cct = 449 * Math.pow(n, 3) + 3525 * Math.pow(n, 2) + 6823.3 * n + 5520.33;
  return Math.max(1000, Math.min(25000, Math.round(cct)));
}

export function oklchToSrgb(oklch: OKLCh): RGB {
  const oklab = oklchToOklab(oklch);
  const xyz = oklabToXyz(oklab);
  const lin = xyzToLinearRgb(xyz);
  return linearRgbToRgb({
    r: Math.max(0, Math.min(1, lin.r)),
    g: Math.max(0, Math.min(1, lin.g)),
    b: Math.max(0, Math.min(1, lin.b)),
  });
}

export function isRgbInSrgbGamut(rgb: RGB): boolean {
  return rgb.r >= 0 && rgb.r <= 255 && rgb.g >= 0 && rgb.g <= 255 && rgb.b >= 0 && rgb.b <= 255;
}

export function estimateApcaContrast(txtLum: number, bgLum: number): number {
  const yTxt = Math.max(0, Math.min(1, txtLum));
  const yBg = Math.max(0, Math.min(1, bgLum));
  if (Math.abs(yTxt - yBg) < 0.001) return 0;
  // Standard APCA approximation Lc value
  const deltaY = Math.abs(yBg - yTxt);
  const score = deltaY > 0.5 ? Math.round(deltaY * 105 + 10) : Math.round(deltaY * 95);
  return Math.min(108, Math.max(0, score));
}

// ==========================================
// 14. MASTER FACTORY: createColourRecord
// ==========================================

export function createColourRecord(
  rgb: RGB,
  alpha: number = 1,
  name?: string,
  metadata?: Partial<ColourMetadata>
): ColourRecord {
  const hex = rgbToHex(rgb, alpha);
  const linearRgb = rgbToLinearRgb(rgb);
  const xyz = linearRgbToXyz(linearRgb);
  const lab = xyzToLab(xyz);
  const lch = labToLch(lab);
  const oklab = xyzToOklab(xyz);
  const oklch = oklabToOklch(oklab);
  const hsl = rgbToHsl(rgb);
  const hsv = rgbToHsv(rgb);
  const hwb = rgbToHwb(rgb);
  const cmyk = rgbToCmyk(rgb);
  const displayP3 = xyzToDisplayP3(xyz);
  const rec2020 = xyzToRec2020(xyz);
  const luminance = calculateRelativeLuminance(rgb);
  const contrastData = evaluateContrast(rgb);
  const gamutStatus = checkGamut(xyz);

  const spectralPeak = estimateDominantWavelength(hsl.h);
  const tempK = estimateCorrelatedColourTemperature(xyz);

  const assignedName =
    name ||
    generateDescriptiveColourName(oklch, hsl);

  return {
    id: `col-${hex.replace('#', '').toLowerCase()}-${Math.round(alpha * 100)}`,
    name: assignedName,
    hex,
    alpha,
    srgb: rgb,
    linearRgb,
    hsl,
    hsv,
    hwb,
    xyz: {
      x: Number(xyz.x.toFixed(3)),
      y: Number(xyz.y.toFixed(3)),
      z: Number(xyz.z.toFixed(3)),
    },
    lab: {
      l: Number(lab.l.toFixed(2)),
      a: Number(lab.a.toFixed(2)),
      b: Number(lab.b.toFixed(2)),
    },
    lch,
    oklab: {
      l: Number(oklab.l.toFixed(4)),
      a: Number(oklab.a.toFixed(4)),
      b: Number(oklab.b.toFixed(4)),
    },
    oklch,
    cmyk,
    displayP3: {
      r: Number(displayP3.r.toFixed(4)),
      g: Number(displayP3.g.toFixed(4)),
      b: Number(displayP3.b.toFixed(4)),
    },
    rec2020: {
      r: Number(rec2020.r.toFixed(4)),
      g: Number(rec2020.g.toFixed(4)),
      b: Number(rec2020.b.toFixed(4)),
    },
    luminance: Number(luminance.toFixed(4)),
    contrastData,
    gamutStatus,
    metadata: {
      spectralPeakNm: spectralPeak,
      temperatureK: tempK,
      category: metadata?.category || 'General',
      source: metadata?.source || 'Chroma Core',
      tags: metadata?.tags || [],
      description: metadata?.description || `${assignedName} [${hex}] in sRGB / OKLCh`,
      ...metadata,
    },
  };
}

export function createColourFromHex(
  hex: string,
  name?: string,
  metadata?: Partial<ColourMetadata>
): ColourRecord {
  const { rgb, alpha } = hexToRgb(hex);
  return createColourRecord(rgb, alpha, name, metadata);
}

export function createColourFromOklch(
  oklch: OKLCh,
  name?: string,
  metadata?: Partial<ColourMetadata>
): ColourRecord {
  const oklab = oklchToOklab(oklch);
  const xyz = oklabToXyz(oklab);
  const lin = xyzToLinearRgb(xyz);
  const rgb = linearRgbToRgb({
    r: Math.max(0, Math.min(1, lin.r)),
    g: Math.max(0, Math.min(1, lin.g)),
    b: Math.max(0, Math.min(1, lin.b)),
  });
  return createColourRecord(rgb, 1, name, metadata);
}

export function createColourFromHsl(
  hsl: HSL,
  name?: string,
  metadata?: Partial<ColourMetadata>
): ColourRecord {
  const rgb = hslToRgb(hsl);
  return createColourRecord(rgb, 1, name, metadata);
}

export function createColourFromLab(
  lab: Lab,
  name?: string,
  metadata?: Partial<ColourMetadata>
): ColourRecord {
  const xyz = labToXyz(lab);
  const rgb = xyzToRgb(xyz);
  return createColourRecord(rgb, 1, name, metadata);
}

export const createColourFromRgb = (
  rgb: RGB,
  name?: string,
  metadata?: Partial<ColourMetadata>
) => createColourRecord(rgb, 1, name, metadata);

// ==========================================
// 15. SCIENTIFIC & TECHNICAL COLOUR NAMING
// ==========================================

export function generateDescriptiveColourName(oklch: OKLCh, hsl: HSL): string {
  const l = oklch.l; // 0..1
  const c = oklch.c; // 0..0.4
  const h = oklch.h; // 0..360

  // Neutrals & near-neutrals
  if (c < 0.02) {
    if (l > 0.96) return 'Warm Technical White';
    if (l > 0.88) return 'Light Architectural Grey';
    if (l > 0.70) return 'Aluminium Grey';
    if (l > 0.45) return 'Milled Steel Grey';
    if (l > 0.25) return 'Dark Graphite';
    if (l > 0.12) return 'Carbon Black';
    return 'Obsidian Deep';
  }

  // Tonal prefix
  let tonePrefix = '';
  if (l > 0.85) tonePrefix = 'Pale ';
  else if (l > 0.70) tonePrefix = 'Light ';
  else if (l < 0.25) tonePrefix = 'Deep ';
  else if (l < 0.40) tonePrefix = 'Dark ';

  let satPrefix = '';
  if (c < 0.06) satPrefix = 'Muted ';
  else if (c > 0.20) satPrefix = 'Vivid ';

  // Hue classifications in OKLCh
  let hueName = 'Neutral';
  if (h >= 15 && h < 45) hueName = 'Industrial Orange';
  else if (h >= 45 && h < 85) hueName = 'Amber Gold';
  else if (h >= 85 && h < 125) hueName = 'Technical Yellow';
  else if (h >= 125 && h < 165) hueName = 'Chartreuse / Acid Green';
  else if (h >= 165 && h < 210) hueName = 'Oxidised Copper Green';
  else if (h >= 210 && h < 250) hueName = 'Maritime Cyan';
  else if (h >= 250 && h < 285) hueName = 'Precision Cobalt';
  else if (h >= 285 && h < 325) hueName = 'Ultramarine Violet';
  else if (h >= 325 && h < 355) hueName = 'Industrial Magenta';
  else hueName = 'Signal Crimson';

  return `${satPrefix}${tonePrefix}${hueName}`.trim();
}
