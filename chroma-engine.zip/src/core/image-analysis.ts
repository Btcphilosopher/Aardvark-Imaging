import { ColourRecord, ImageColourExtraction, RGB } from '../types/colour';
import { createColourRecord } from './colour-math';

/**
 * Extracts dominant color palette, histograms, and statistical distributions from an HTML Image / Canvas
 */
export async function extractColoursFromImage(
  imageElement: HTMLImageElement | HTMLCanvasElement,
  fileName: string = 'Sample Image'
): Promise<ImageColourExtraction> {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) {
    throw new Error('Canvas 2D context unavailable');
  }

  // Downsample to max 256x256 for fast local processing
  const maxDim = 256;
  let w = imageElement.width || 256;
  let h = imageElement.height || 256;

  if (w > maxDim || h > maxDim) {
    if (w > h) {
      h = Math.round((h * maxDim) / w);
      w = maxDim;
    } else {
      w = Math.round((w * maxDim) / h);
      h = maxDim;
    }
  }

  canvas.width = w;
  canvas.height = h;
  ctx.drawImage(imageElement, 0, 0, w, h);

  const imgData = ctx.getImageData(0, 0, w, h);
  const data = imgData.data;
  const pixelCount = w * h;

  const lumHist = new Array(256).fill(0);
  const satHist = new Array(256).fill(0);
  const hueHist = new Array(360).fill(0);

  let totalR = 0;
  let totalG = 0;
  let totalB = 0;

  // Simple color quantization bucket map (4x4x4 RGB = 64 bins)
  const buckets = new Map<number, { r: number; g: number; b: number; count: number }>();

  let warmCount = 0;
  let coolCount = 0;

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];

    totalR += r;
    totalG += g;
    totalB += b;

    // Luminance
    const lum = Math.round(0.2126 * r + 0.7152 * g + 0.0722 * b);
    lumHist[lum]++;

    // Saturation & Hue
    const max = Math.max(r, g, b) / 255;
    const min = Math.min(r, g, b) / 255;
    const delta = max - min;
    const sat = max === 0 ? 0 : delta / max;
    satHist[Math.min(255, Math.round(sat * 255))]++;

    let hue = 0;
    if (delta !== 0) {
      if (max === r / 255) hue = ((g - b) / 255 / delta + (g < b ? 6 : 0)) * 60;
      else if (max === g / 255) hue = ((b - r) / 255 / delta + 2) * 60;
      else hue = ((r - g) / 255 / delta + 4) * 60;
    }
    const hIdx = Math.max(0, Math.min(359, Math.round(hue)));
    hueHist[hIdx]++;

    if (hIdx <= 90 || hIdx >= 300) warmCount++;
    else coolCount++;

    // Quantize to 64 buckets
    const bR = Math.floor(r / 64);
    const bG = Math.floor(g / 64);
    const bB = Math.floor(b / 64);
    const key = (bR << 4) | (bG << 2) | bB;

    const existing = buckets.get(key);
    if (existing) {
      existing.r += r;
      existing.g += g;
      existing.b += b;
      existing.count++;
    } else {
      buckets.set(key, { r, g, b, count: 1 });
    }
  }

  // Sort buckets by count
  const sorted = Array.from(buckets.values()).sort((a, b) => b.count - a.count);

  const dominantPalette: ColourRecord[] = sorted.slice(0, 8).map((b, idx) => {
    const avgR = Math.round(b.r / b.count);
    const avgG = Math.round(b.g / b.count);
    const avgB = Math.round(b.b / b.count);
    return createColourRecord({ r: avgR, g: avgG, b: avgB }, 1, `Dominant ${idx + 1}`);
  });

  const avgR = Math.round(totalR / pixelCount);
  const avgG = Math.round(totalG / pixelCount);
  const avgB = Math.round(totalB / pixelCount);
  const averageColour = createColourRecord({ r: avgR, g: avgG, b: avgB }, 1, 'Average Tone');

  // Find highlights (highest luminance) & shadows (lowest)
  const sortedByLum = [...dominantPalette].sort((a, b) => b.luminance - a.luminance);
  const highlightColour = sortedByLum[0] || dominantPalette[0];
  const shadowColour = sortedByLum[sortedByLum.length - 1] || dominantPalette[0];

  // Find vibrant (highest chroma in OKLCh) & muted
  const sortedByChroma = [...dominantPalette].sort((a, b) => b.oklch.c - a.oklch.c);
  const vibrantColour = sortedByChroma[0] || dominantPalette[0];
  const mutedColour = sortedByChroma[sortedByChroma.length - 1] || dominantPalette[0];

  return {
    fileName,
    dimensions: { width: w, height: h },
    dominantPalette,
    averageColour,
    highlightColour,
    shadowColour,
    vibrantColour,
    mutedColour,
    luminanceHistogram: lumHist,
    saturationHistogram: satHist,
    hueHistogram: hueHist,
    warmCoolRatio: Number((warmCount / (coolCount || 1)).toFixed(2)),
  };
}
