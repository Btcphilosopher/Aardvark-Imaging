import { ColourRecord, ColourBlindnessType, RGB } from '../types/colour';
import { createColourRecord, srgbToLinear, linearToSrgb } from './colour-math';

// Machado, Oliveira, and Fernandes (2009) physiologically-based color deficiency matrices
const PROTANOPIA_MATRIX = [
  [0.152286, 1.052583, -0.204868],
  [0.114503, 0.786281, 0.099216],
  [-0.003882, -0.048116, 1.051998],
];

const DEUTERANOPIA_MATRIX = [
  [0.367322, 0.860646, -0.227968],
  [0.280085, 0.672501, 0.047413],
  [-0.01182, 0.04294, 0.968881],
];

const TRITANOPIA_MATRIX = [
  [1.255528, -0.076749, -0.178779],
  [-0.078411, 0.930809, 0.147602],
  [0.004733, 0.691367, 0.3039],
];

function applyDeficiencyMatrix(rgb: RGB, matrix: number[][]): RGB {
  const linR = srgbToLinear(rgb.r);
  const linG = srgbToLinear(rgb.g);
  const linB = srgbToLinear(rgb.b);

  const outR = matrix[0][0] * linR + matrix[0][1] * linG + matrix[0][2] * linB;
  const outG = matrix[1][0] * linR + matrix[1][1] * linG + matrix[1][2] * linB;
  const outB = matrix[2][0] * linR + matrix[2][1] * linG + matrix[2][2] * linB;

  return {
    r: linearToSrgb(Math.max(0, Math.min(1, outR))),
    g: linearToSrgb(Math.max(0, Math.min(1, outG))),
    b: linearToSrgb(Math.max(0, Math.min(1, outB))),
  };
}

export function simulateColourDeficiency(
  colour: ColourRecord,
  type: ColourBlindnessType
): ColourRecord {
  switch (type) {
    case 'protanopia': {
      const rgb = applyDeficiencyMatrix(colour.srgb, PROTANOPIA_MATRIX);
      return createColourRecord(rgb, colour.alpha, `${colour.name} (Protanopia)`);
    }

    case 'deuteranopia': {
      const rgb = applyDeficiencyMatrix(colour.srgb, DEUTERANOPIA_MATRIX);
      return createColourRecord(rgb, colour.alpha, `${colour.name} (Deuteranopia)`);
    }

    case 'tritanopia': {
      const rgb = applyDeficiencyMatrix(colour.srgb, TRITANOPIA_MATRIX);
      return createColourRecord(rgb, colour.alpha, `${colour.name} (Tritanopia)`);
    }

    case 'achromatopsia': {
      // Relative luminance to full grayscale
      const gray = Math.round(colour.luminance * 255);
      return createColourRecord(
        { r: gray, g: gray, b: gray },
        colour.alpha,
        `${colour.name} (Achromatopsia)`
      );
    }

    case 'low-vision': {
      // Contrast reduction & mild fogging
      const gray = colour.luminance * 255;
      const r = Math.round(colour.srgb.r * 0.6 + gray * 0.4);
      const g = Math.round(colour.srgb.g * 0.6 + gray * 0.4);
      const b = Math.round(colour.srgb.b * 0.6 + gray * 0.4);
      return createColourRecord({ r, g, b }, colour.alpha, `${colour.name} (Low Vision)`);
    }

    case 'reduced-contrast': {
      // Compress dynamic range to 25%..80%
      const r = Math.round(64 + colour.srgb.r * 0.5);
      const g = Math.round(64 + colour.srgb.g * 0.5);
      const b = Math.round(64 + colour.srgb.b * 0.5);
      return createColourRecord({ r, g, b }, colour.alpha, `${colour.name} (Reduced Contrast)`);
    }

    case 'display-washout': {
      // High ambient glare simulation
      const r = Math.min(255, Math.round(colour.srgb.r * 0.8 + 60));
      const g = Math.min(255, Math.round(colour.srgb.g * 0.8 + 60));
      const b = Math.min(255, Math.round(colour.srgb.b * 0.8 + 60));
      return createColourRecord({ r, g, b }, colour.alpha, `${colour.name} (Ambient Washout)`);
    }

    default:
      return colour;
  }
}

export type AccessibilityAdvice = {
  status: 'optimal' | 'warning' | 'critical';
  title: string;
  recommendation: string;
};

export function assessPaletteAccessibility(colours: ColourRecord[]): AccessibilityAdvice[] {
  const advices: AccessibilityAdvice[] = [];

  // Check 1: Minimum contrast spread
  const luminances = colours.map((c) => c.luminance).sort((a, b) => a - b);
  const minLum = luminances[0] ?? 0;
  const maxLum = luminances[luminances.length - 1] ?? 1;

  if (maxLum - minLum < 0.4) {
    advices.push({
      status: 'critical',
      title: 'Compressed Dynamic Range',
      recommendation:
        'The current palette spans less than 40% luminance range. Ensure high-contrast foreground/background pairs exist with at least 4.5:1 ratio.',
    });
  }

  // Check 2: Red-Green distinguishability
  const hasWarmRed = colours.some((c) => c.hsl.h >= 340 || c.hsl.h <= 20);
  const hasGreen = colours.some((c) => c.hsl.h >= 90 && c.hsl.h <= 160);

  if (hasWarmRed && hasGreen) {
    advices.push({
      status: 'warning',
      title: 'Red/Green Co-dependence (Deuteranopia/Protanopia)',
      recommendation:
        'Red and Green are both present. Never convey status (e.g. Success vs Danger) via colour alone. Pair with icons, text labels, or distinct stroke patterns.',
    });
  }

  // Check 3: Near-duplicate shades in simulated monochrome
  for (let i = 0; i < colours.length; i++) {
    for (let j = i + 1; j < colours.length; j++) {
      const c1 = colours[i];
      const c2 = colours[j];
      const lumDiff = Math.abs(c1.luminance - c2.luminance);
      if (lumDiff < 0.05 && c1.hsl.h !== c2.hsl.h) {
        advices.push({
          status: 'warning',
          title: `Iso-luminant Pair: ${c1.name} & ${c2.name}`,
          recommendation: `These colours have nearly identical luminance (${(c1.luminance * 100).toFixed(0)}% vs ${(c2.luminance * 100).toFixed(0)}%) and will collapse into the same shade under Achromatopsia. Introduce a luminance delta of at least 15%.`,
        });
        break;
      }
    }
  }

  if (advices.length === 0) {
    advices.push({
      status: 'optimal',
      title: 'High Perceptual Differentiation',
      recommendation:
        'The selected palette exhibits robust luminance stratification and maintains distinguishable tonal steps under deficiency simulations.',
    });
  }

  return advices;
}
