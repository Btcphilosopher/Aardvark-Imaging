import { ColourRecord, DifferenceEvaluation, ColourDifferenceMethod } from '../types/colour';

/**
 * CIELAB Delta E 1976 (Euclidean distance in Lab space)
 */
export function calculateDeltaE76(c1: ColourRecord, c2: ColourRecord): number {
  const dL = c1.lab.l - c2.lab.l;
  const da = c1.lab.a - c2.lab.a;
  const db = c1.lab.b - c2.lab.b;
  return Number(Math.hypot(dL, da, db).toFixed(2));
}

/**
 * CIELAB Delta E 1994 (Graphic arts standard weighting)
 */
export function calculateDeltaE94(
  c1: ColourRecord,
  c2: ColourRecord,
  application: 'graphic' | 'textile' = 'graphic'
): number {
  const kL = application === 'textile' ? 2 : 1;
  const K1 = application === 'textile' ? 0.048 : 0.045;
  const K2 = application === 'textile' ? 0.014 : 0.015;

  const dL = c1.lab.l - c2.lab.l;
  const C1 = Math.hypot(c1.lab.a, c1.lab.b);
  const C2 = Math.hypot(c2.lab.a, c2.lab.b);
  const dC = C1 - C2;

  const da = c1.lab.a - c2.lab.a;
  const db = c1.lab.b - c2.lab.b;
  const dH2 = da * da + db * db - dC * dC;
  const dH = Math.sqrt(Math.max(0, dH2));

  const sL = 1;
  const sC = 1 + K1 * C1;
  const sH = 1 + K2 * C1;

  const termL = dL / (kL * sL);
  const termC = dC / sC;
  const termH = dH / sH;

  return Number(Math.sqrt(termL * termL + termC * termC + termH * termH).toFixed(2));
}

/**
 * CIEDE2000 (Standard modern CIE industrial colour difference formula)
 * Full implementation including hue rotation, chroma weighting, and parametric factors.
 */
export function calculateCIEDE2000(c1: ColourRecord, c2: ColourRecord): number {
  const L1 = c1.lab.l;
  const a1 = c1.lab.a;
  const b1 = c1.lab.b;

  const L2 = c2.lab.l;
  const a2 = c2.lab.a;
  const b2 = c2.lab.b;

  const avgL = (L1 + L2) / 2;
  const C1 = Math.hypot(a1, b1);
  const C2 = Math.hypot(a2, b2);
  const avgC = (C1 + C2) / 2;

  const G = 0.5 * (1 - Math.sqrt(Math.pow(avgC, 7) / (Math.pow(avgC, 7) + Math.pow(25, 7))));

  const a1Prime = a1 * (1 + G);
  const a2Prime = a2 * (1 + G);

  const C1Prime = Math.hypot(a1Prime, b1);
  const C2Prime = Math.hypot(a2Prime, b2);
  const avgCPrime = (C1Prime + C2Prime) / 2;

  const rad2deg = 180 / Math.PI;
  const deg2rad = Math.PI / 180;

  let h1Prime = Math.atan2(b1, a1Prime) * rad2deg;
  if (h1Prime < 0) h1Prime += 360;

  let h2Prime = Math.atan2(b2, a2Prime) * rad2deg;
  if (h2Prime < 0) h2Prime += 360;

  let deltahPrime = 0;
  if (C1Prime * C2Prime !== 0) {
    if (Math.abs(h2Prime - h1Prime) <= 180) {
      deltahPrime = h2Prime - h1Prime;
    } else if (h2Prime - h1Prime > 180) {
      deltahPrime = h2Prime - h1Prime - 360;
    } else {
      deltahPrime = h2Prime - h1Prime + 360;
    }
  }

  const deltaLPrime = L2 - L1;
  const deltaCPrime = C2Prime - C1Prime;
  const deltaHPrime = 2 * Math.sqrt(C1Prime * C2Prime) * Math.sin((deltahPrime * deg2rad) / 2);

  const avgLPrime = (L1 + L2) / 2;
  let avghPrime = 0;
  if (C1Prime * C2Prime !== 0) {
    if (Math.abs(h1Prime - h2Prime) <= 180) {
      avghPrime = (h1Prime + h2Prime) / 2;
    } else if (h1Prime + h2Prime < 360) {
      avghPrime = (h1Prime + h2Prime + 360) / 2;
    } else {
      avghPrime = (h1Prime + h2Prime - 360) / 2;
    }
  }

  const T =
    1 -
    0.17 * Math.cos((avghPrime - 30) * deg2rad) +
    0.24 * Math.cos(2 * avghPrime * deg2rad) +
    0.32 * Math.cos((3 * avghPrime + 6) * deg2rad) -
    0.2 * Math.cos((4 * avghPrime - 63) * deg2rad);

  const deltaTheta = 30 * Math.exp(-Math.pow((avghPrime - 275) / 25, 2));
  const RC = 2 * Math.sqrt(Math.pow(avgCPrime, 7) / (Math.pow(avgCPrime, 7) + Math.pow(25, 7)));
  const SL = 1 + (0.015 * Math.pow(avgLPrime - 50, 2)) / Math.sqrt(20 + Math.pow(avgLPrime - 50, 2));
  const SC = 1 + 0.045 * avgCPrime;
  const SH = 1 + 0.015 * avgCPrime * T;
  const RT = -Math.sin(2 * deltaTheta * deg2rad) * RC;

  const kL = 1;
  const kC = 1;
  const kH = 1;

  const dE = Math.sqrt(
    Math.pow(deltaLPrime / (kL * SL), 2) +
      Math.pow(deltaCPrime / (kC * SC), 2) +
      Math.pow(deltaHPrime / (kH * SH), 2) +
      RT * (deltaCPrime / (kC * SC)) * (deltaHPrime / (kH * SH))
  );

  return Number(dE.toFixed(2));
}

/**
 * OKLab Delta E (Euclidean distance in OKLab space * 100 for human readability scale)
 */
export function calculateDeltaEOKLab(c1: ColourRecord, c2: ColourRecord): number {
  const dL = c1.oklab.l - c2.oklab.l;
  const da = c1.oklab.a - c2.oklab.a;
  const db = c1.oklab.b - c2.oklab.b;
  // Scaled by 100 to align with JND scale
  return Number((Math.hypot(dL, da, db) * 100).toFixed(2));
}

export function evaluateColourDifference(
  c1: ColourRecord,
  c2: ColourRecord,
  method: ColourDifferenceMethod = 'deltaE2000'
): DifferenceEvaluation {
  let val = 0;
  let limitations = '';

  switch (method) {
    case 'deltaE2000':
      val = calculateCIEDE2000(c1, c2);
      limitations = 'Gold standard for industrial colour tolerance; complex non-linear compensation for blue hue rotation and neutral grays.';
      break;
    case 'deltaE94':
      val = calculateDeltaE94(c1, c2);
      limitations = 'Good for graphic arts and print; assumes standard lighting and high chroma tolerances.';
      break;
    case 'deltaE76':
      val = calculateDeltaE76(c1, c2);
      limitations = 'Simple Euclidean distance in CIELAB. Poor perceptual uniformity in saturated yellows and blues.';
      break;
    case 'deltaEOKLab':
      val = calculateDeltaEOKLab(c1, c2);
      limitations = 'Optimised for display graphics and digital blending; highly uniform across all hues.';
      break;
    case 'deltaEOKLCh': {
      const dL = c1.oklch.l - c2.oklch.l;
      const dC = c1.oklch.c - c2.oklch.c;
      const dh = Math.abs(c1.oklch.h - c2.oklch.h);
      const shortestH = dh > 180 ? 360 - dh : dh;
      val = Number((Math.hypot(dL, dC, (shortestH / 360) * 0.4) * 100).toFixed(2));
      limitations = 'Polar OKLCh comparison; weights hue separation alongside lightness and chroma.';
      break;
    }
    case 'euclideanRGB': {
      const dr = (c1.srgb.r - c2.srgb.r) / 255;
      const dg = (c1.srgb.g - c2.srgb.g) / 255;
      const db = (c1.srgb.b - c2.srgb.b) / 255;
      val = Number((Math.hypot(dr, dg, db) * 100).toFixed(2));
      limitations = 'Non-perceptual metric. Human eyes are significantly more sensitive to green than blue; do not use for tolerance gating.';
      break;
    }
  }

  let interpretation = '';
  let status: 'negligible' | 'perceptible' | 'significant' | 'distinct' = 'negligible';

  if (val <= 1.0) {
    interpretation = 'Imperceptible to the average human eye (< 1.0 JND)';
    status = 'negligible';
  } else if (val <= 2.5) {
    interpretation = 'Perceptible through close side-by-side inspection (1.0 - 2.5)';
    status = 'perceptible';
  } else if (val <= 6.0) {
    interpretation = 'Noticeable color difference in production components (2.5 - 6.0)';
    status = 'significant';
  } else {
    interpretation = 'Clearly distinct and contrasting colors (> 6.0)';
    status = 'distinct';
  }

  return {
    method,
    value: val,
    interpretation,
    toleranceStatus: status,
    limitations,
  };
}

export function calculateAllColorDifferences(c1: ColourRecord, c2: ColourRecord) {
  return {
    de2000: calculateCIEDE2000(c1, c2),
    de94: calculateDeltaE94(c1, c2),
    de76: calculateDeltaE76(c1, c2),
    deOklab: calculateDeltaEOKLab(c1, c2),
    euclideanRgb: Number(
      (
        Math.hypot(
          (c1.srgb.r - c2.srgb.r) / 255,
          (c1.srgb.g - c2.srgb.g) / 255,
          (c1.srgb.b - c2.srgb.b) / 255
        ) * 100
      ).toFixed(2)
    ),
  };
}
