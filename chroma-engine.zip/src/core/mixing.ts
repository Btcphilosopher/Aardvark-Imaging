import { ColourRecord, MixingModel, RGB } from '../types/colour';
import {
  createColourRecord,
  oklabToXyz,
  xyzToLinearRgb,
  linearRgbToRgb,
  labToXyz,
  xyzToRgb,
  hslToRgb,
  linearToSrgb,
} from './colour-math';

/**
 * Interpolates two numbers linearly
 */
function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

/**
 * Mix two colours in a specified colour model at ratio t (0..1)
 */
export function mixTwoColours(
  c1: ColourRecord,
  c2: ColourRecord,
  ratio: number = 0.5,
  model: MixingModel = 'oklab'
): ColourRecord {
  const t = Math.max(0, Math.min(1, ratio));

  switch (model) {
    case 'srgb': {
      const r = lerp(c1.srgb.r, c2.srgb.r, t);
      const g = lerp(c1.srgb.g, c2.srgb.g, t);
      const b = lerp(c1.srgb.b, c2.srgb.b, t);
      return createColourRecord(
        { r: Math.round(r), g: Math.round(g), b: Math.round(b) },
        lerp(c1.alpha, c2.alpha, t),
        `sRGB Mix (${Math.round((1 - t) * 100)}:${Math.round(t * 100)})`
      );
    }

    case 'linear-rgb': {
      const linR = lerp(c1.linearRgb.r, c2.linearRgb.r, t);
      const linG = lerp(c1.linearRgb.g, c2.linearRgb.g, t);
      const linB = lerp(c1.linearRgb.b, c2.linearRgb.b, t);
      const rgb: RGB = {
        r: linearToSrgb(linR),
        g: linearToSrgb(linG),
        b: linearToSrgb(linB),
      };
      return createColourRecord(
        rgb,
        lerp(c1.alpha, c2.alpha, t),
        `Linear-Light Mix (${Math.round((1 - t) * 100)}:${Math.round(t * 100)})`
      );
    }

    case 'lab': {
      const l = lerp(c1.lab.l, c2.lab.l, t);
      const a = lerp(c1.lab.a, c2.lab.a, t);
      const b = lerp(c1.lab.b, c2.lab.b, t);
      const xyz = labToXyz({ l, a, b });
      const rgb = xyzToRgb(xyz);
      return createColourRecord(
        rgb,
        lerp(c1.alpha, c2.alpha, t),
        `Lab Mix (${Math.round((1 - t) * 100)}:${Math.round(t * 100)})`
      );
    }

    case 'lch': {
      const l = lerp(c1.lch.l, c2.lch.l, t);
      const c = lerp(c1.lch.c, c2.lch.c, t);
      let h1 = c1.lch.h;
      let h2 = c2.lch.h;
      // Shortest path around hue circle
      const diff = h2 - h1;
      if (diff > 180) h2 -= 360;
      if (diff < -180) h2 += 360;
      let h = (lerp(h1, h2, t) + 360) % 360;
      const rad = (h * Math.PI) / 180;
      const lab = { l, a: c * Math.cos(rad), b: c * Math.sin(rad) };
      const xyz = labToXyz(lab);
      const rgb = xyzToRgb(xyz);
      return createColourRecord(
        rgb,
        lerp(c1.alpha, c2.alpha, t),
        `LCh Polar Mix (${Math.round((1 - t) * 100)}:${Math.round(t * 100)})`
      );
    }

    case 'oklab': {
      const l = lerp(c1.oklab.l, c2.oklab.l, t);
      const a = lerp(c1.oklab.a, c2.oklab.a, t);
      const b = lerp(c1.oklab.b, c2.oklab.b, t);
      const xyz = oklabToXyz({ l, a, b });
      const lin = xyzToLinearRgb(xyz);
      const rgb = linearRgbToRgb({
        r: Math.max(0, Math.min(1, lin.r)),
        g: Math.max(0, Math.min(1, lin.g)),
        b: Math.max(0, Math.min(1, lin.b)),
      });
      return createColourRecord(
        rgb,
        lerp(c1.alpha, c2.alpha, t),
        `OKLab Perceptual Mix (${Math.round((1 - t) * 100)}:${Math.round(t * 100)})`
      );
    }

    case 'oklch': {
      const l = lerp(c1.oklch.l, c2.oklch.l, t);
      const c = lerp(c1.oklch.c, c2.oklch.c, t);
      let h1 = c1.oklch.h;
      let h2 = c2.oklch.h;
      const diff = h2 - h1;
      if (diff > 180) h2 -= 360;
      if (diff < -180) h2 += 360;
      let h = (lerp(h1, h2, t) + 360) % 360;
      const rad = (h * Math.PI) / 180;
      const oklab = { l, a: c * Math.cos(rad), b: c * Math.sin(rad) };
      const xyz = oklabToXyz(oklab);
      const lin = xyzToLinearRgb(xyz);
      const rgb = linearRgbToRgb({
        r: Math.max(0, Math.min(1, lin.r)),
        g: Math.max(0, Math.min(1, lin.g)),
        b: Math.max(0, Math.min(1, lin.b)),
      });
      return createColourRecord(
        rgb,
        lerp(c1.alpha, c2.alpha, t),
        `OKLCh Polar Mix (${Math.round((1 - t) * 100)}:${Math.round(t * 100)})`
      );
    }

    case 'subtractive-pigment': {
      // Approximate Kubelka-Munk subtractive mixing:
      // Converts linear RGB into absorption (K) and scattering (S) approximations
      // When Blue + Yellow mix, subtractive yields Green instead of grey mud.
      const k1R = Math.pow(1 - c1.linearRgb.r, 2) / (2 * Math.max(0.01, c1.linearRgb.r));
      const k1G = Math.pow(1 - c1.linearRgb.g, 2) / (2 * Math.max(0.01, c1.linearRgb.g));
      const k1B = Math.pow(1 - c1.linearRgb.b, 2) / (2 * Math.max(0.01, c1.linearRgb.b));

      const k2R = Math.pow(1 - c2.linearRgb.r, 2) / (2 * Math.max(0.01, c2.linearRgb.r));
      const k2G = Math.pow(1 - c2.linearRgb.g, 2) / (2 * Math.max(0.01, c2.linearRgb.g));
      const k2B = Math.pow(1 - c2.linearRgb.b, 2) / (2 * Math.max(0.01, c2.linearRgb.b));

      const mixKR = lerp(k1R, k2R, t);
      const mixKG = lerp(k1G, k2G, t);
      const mixKB = lerp(k1B, k2B, t);

      // Invert K/S to reflectance R = 1 + K/S - sqrt((K/S)^2 + 2(K/S))
      const refR = 1 + mixKR - Math.sqrt(mixKR * mixKR + 2 * mixKR);
      const refG = 1 + mixKG - Math.sqrt(mixKG * mixKG + 2 * mixKG);
      const refB = 1 + mixKB - Math.sqrt(mixKB * mixKB + 2 * mixKB);

      const rgb: RGB = {
        r: linearToSrgb(Math.max(0, Math.min(1, refR))),
        g: linearToSrgb(Math.max(0, Math.min(1, refG))),
        b: linearToSrgb(Math.max(0, Math.min(1, refB))),
      };

      return createColourRecord(
        rgb,
        lerp(c1.alpha, c2.alpha, t),
        `Pigment Subtractive Mix (${Math.round((1 - t) * 100)}:${Math.round(t * 100)})`
      );
    }
  }
}

/**
 * Mix three colours with barycentric weights (w1, w2, w3)
 */
export function mixThreeColours(
  c1: ColourRecord,
  c2: ColourRecord,
  c3: ColourRecord,
  w1: number,
  w2: number,
  w3: number,
  model: MixingModel = 'oklab'
): ColourRecord {
  const total = w1 + w2 + w3 || 1;
  const nw1 = w1 / total;
  const nw2 = w2 / total;
  const nw3 = w3 / total;

  // Mix 1 and 2 first
  const subRatio = nw2 / (nw1 + nw2 || 1);
  const mix12 = mixTwoColours(c1, c2, subRatio, model);

  // Mix result with 3
  const finalRatio = nw3;
  return mixTwoColours(mix12, c3, finalRatio, model);
}

/**
 * Generate a multi-step mixing ramp between two colours
 */
export function generateMixingRamp(
  c1: ColourRecord,
  c2: ColourRecord,
  steps: number = 7,
  model: MixingModel = 'oklab'
): ColourRecord[] {
  const ramp: ColourRecord[] = [];
  for (let i = 0; i < steps; i++) {
    const ratio = steps === 1 ? 0.5 : i / (steps - 1);
    ramp.push(mixTwoColours(c1, c2, ratio, model));
  }
  return ramp;
}

export const mixColours = mixTwoColours;
