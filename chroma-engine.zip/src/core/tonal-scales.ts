import { ColourRecord, TonalScale, TonalStep } from '../types/colour';
import {
  createColourFromOklch,
  createColourFromLab,
  createColourFromHsl,
  calculateWcagContrast,
} from './colour-math';

const TONAL_LEVELS = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 95, 100];

export function generateTonalScale(
  base: ColourRecord,
  space: 'oklch' | 'lab' | 'lch' | 'hsl' = 'oklch'
): TonalScale {
  const steps: TonalStep[] = [];

  for (const level of TONAL_LEVELS) {
    let stepColour: ColourRecord;

    if (level === 0) {
      // Pure black tone
      stepColour = createColourFromOklch({ l: 0, c: 0, h: base.oklch.h }, `${base.name} 0`);
    } else if (level === 100) {
      // Pure white tone
      stepColour = createColourFromOklch({ l: 1, c: 0, h: base.oklch.h }, `${base.name} 100`);
    } else {
      switch (space) {
        case 'oklch': {
          // In OKLCh, target L is level / 100.
          // Taper chroma near extremes (L < 0.2 or L > 0.85) to prevent gamut overflow
          const targetL = level / 100;
          let chromaFactor = 1.0;
          if (targetL < 0.25) {
            chromaFactor = targetL / 0.25;
          } else if (targetL > 0.8) {
            chromaFactor = (1 - targetL) / 0.2;
          }
          const adjustedChroma = base.oklch.c * Math.max(0.2, chromaFactor);

          stepColour = createColourFromOklch(
            {
              l: Number(targetL.toFixed(3)),
              c: Number(adjustedChroma.toFixed(4)),
              h: base.oklch.h,
            },
            `${base.name} ${level}`
          );
          break;
        }

        case 'lab': {
          const targetL = level;
          const factor = Math.sin((level / 100) * Math.PI);
          stepColour = createColourFromLab(
            {
              l: targetL,
              a: base.lab.a * factor,
              b: base.lab.b * factor,
            },
            `${base.name} ${level}`
          );
          break;
        }

        case 'hsl': {
          const targetL = level;
          stepColour = createColourFromHsl(
            {
              h: base.hsl.h,
              s: base.hsl.s,
              l: targetL,
            },
            `${base.name} ${level}`
          );
          break;
        }

        default: {
          stepColour = createColourFromOklch(
            { l: level / 100, c: base.oklch.c * 0.8, h: base.oklch.h },
            `${base.name} ${level}`
          );
        }
      }
    }

    const cAgainstBase = calculateWcagContrast(stepColour.luminance, base.luminance);
    const cAgainstWhite = calculateWcagContrast(stepColour.luminance, 1.0);
    const cAgainstBlack = calculateWcagContrast(stepColour.luminance, 0.0);

    steps.push({
      tone: level,
      colour: stepColour,
      contrastAgainstBase: cAgainstBase,
      contrastAgainstWhite: cAgainstWhite,
      contrastAgainstBlack: cAgainstBlack,
    });
  }

  return {
    baseColour: base,
    space,
    steps,
  };
}
