import { ColourRecord, HarmonyResult, HarmonyType } from '../types/colour';
import { createColourFromOklch, createColourFromHsl } from './colour-math';

/**
 * Generate harmonies based on anchor colour and selected color space
 */
export function generateHarmonies(
  base: ColourRecord,
  space: 'oklch' | 'lch' | 'hsl' = 'oklch'
): HarmonyResult[] {
  const h = space === 'oklch' ? base.oklch.h : base.hsl.h;
  const l = space === 'oklch' ? base.oklch.l : base.hsl.l;
  const c = space === 'oklch' ? base.oklch.c : base.hsl.s;

  const createHarmonic = (targetH: number, targetL?: number, targetC?: number): ColourRecord => {
    const normH = ((targetH % 360) + 360) % 360;
    if (space === 'oklch') {
      return createColourFromOklch({
        l: targetL !== undefined ? targetL : base.oklch.l,
        c: targetC !== undefined ? targetC : base.oklch.c,
        h: Number(normH.toFixed(2)),
      });
    } else {
      return createColourFromHsl({
        h: Math.round(normH),
        s: targetC !== undefined ? Math.round(targetC) : base.hsl.s,
        l: targetL !== undefined ? Math.round(targetL) : base.hsl.l,
      });
    }
  };

  const results: HarmonyResult[] = [
    // 1. Complementary (180 deg)
    {
      type: 'complementary',
      title: 'Complementary',
      description: 'High chromatic opposition (180°). Maximises simultaneous contrast and visual tension.',
      angles: [0, 180],
      colours: [base, createHarmonic(h + 180)],
    },

    // 2. Split Complementary (150 deg & 210 deg)
    {
      type: 'split-complementary',
      title: 'Split-Complementary',
      description: 'Nuanced high contrast (+150° and +210°). Softer balance than a direct complement.',
      angles: [0, 150, 210],
      colours: [base, createHarmonic(h + 150), createHarmonic(h + 210)],
    },

    // 3. Analogous (+30 deg, -30 deg)
    {
      type: 'analogous',
      title: 'Analogous',
      description: 'Adjacent chromatic spectrum (±30°). Organic, cohesive and low-tension aesthetic.',
      angles: [-30, 0, 30],
      colours: [createHarmonic(h - 30), base, createHarmonic(h + 30)],
    },

    // 4. Triadic (120 deg intervals)
    {
      type: 'triadic',
      title: 'Triadic System',
      description: 'Equilateral chromatic triad (120° intervals). Vibrant, balanced three-point geometry.',
      angles: [0, 120, 240],
      colours: [base, createHarmonic(h + 120), createHarmonic(h + 240)],
    },

    // 5. Tetradic / Rectangular (+60, +180, +240)
    {
      type: 'tetradic',
      title: 'Tetradic (Dual Complement)',
      description: 'Rectangular four-point palette (±60° / 180°). Rich variety for comprehensive design systems.',
      angles: [0, 60, 180, 240],
      colours: [base, createHarmonic(h + 60), createHarmonic(h + 180), createHarmonic(h + 240)],
    },

    // 6. Square (90 deg intervals)
    {
      type: 'square',
      title: 'Square Geometry',
      description: 'Symmetric 90° intervals across the hue circle. Equal perceptual distribution.',
      angles: [0, 90, 180, 270],
      colours: [base, createHarmonic(h + 90), createHarmonic(h + 180), createHarmonic(h + 270)],
    },

    // 7. Monochromatic (Same hue, varied lightness & chroma)
    {
      type: 'monochromatic',
      title: 'Monochromatic Series',
      description: 'Strict hue fidelity with mathematical steps across lightness and chroma.',
      angles: [0, 0, 0, 0, 0],
      colours:
        space === 'oklch'
          ? [
              createHarmonic(h, Math.max(0.1, base.oklch.l - 0.35), Math.max(0.02, base.oklch.c * 0.5)),
              createHarmonic(h, Math.max(0.2, base.oklch.l - 0.18), Math.max(0.04, base.oklch.c * 0.8)),
              base,
              createHarmonic(h, Math.min(0.9, base.oklch.l + 0.18), Math.max(0.04, base.oklch.c * 0.8)),
              createHarmonic(h, Math.min(0.96, base.oklch.l + 0.35), Math.max(0.02, base.oklch.c * 0.4)),
            ]
          : [
              createHarmonic(h, Math.max(10, base.hsl.l - 35), Math.max(10, base.hsl.s * 0.5)),
              createHarmonic(h, Math.max(20, base.hsl.l - 18), Math.max(20, base.hsl.s * 0.8)),
              base,
              createHarmonic(h, Math.min(90, base.hsl.l + 18), Math.max(20, base.hsl.s * 0.8)),
              createHarmonic(h, Math.min(96, base.hsl.l + 35), Math.max(10, base.hsl.s * 0.4)),
            ],
    },

    // 8. Warm / Cool Counterpoint
    {
      type: 'warm-cool',
      title: 'Thermal Counterpoint',
      description: 'Juxtaposition of warm thermal locus (amber/orange) against cool locus (cyan/cobalt).',
      angles: [0, 180],
      colours:
        space === 'oklch'
          ? [
              base,
              createHarmonic(35, 0.65, 0.16), // Warm industrial orange
              createHarmonic(220, 0.65, 0.12), // Cool maritime slate
            ]
          : [
              base,
              createHarmonic(25, 55, 90),
              createHarmonic(205, 55, 75),
            ],
    },

    // 9. Near-Neutral System (Low chroma pairing)
    {
      type: 'near-neutral',
      title: 'Architectural Near-Neutral',
      description: 'Chroma subdued to < 0.03 for architectural grounding and surface hierarchy.',
      angles: [0, 0, 0],
      colours:
        space === 'oklch'
          ? [
              createHarmonic(h, 0.94, 0.015), // Light neutral
              createHarmonic(h, 0.65, 0.025), // Mid neutral
              createHarmonic(h, 0.22, 0.015), // Dark graphite
            ]
          : [
              createHarmonic(h, 94, 6),
              createHarmonic(h, 60, 8),
              createHarmonic(h, 18, 6),
            ],
    },
  ];

  return results;
}
