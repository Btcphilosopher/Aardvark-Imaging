'use client';

import React, { createContext, useContext, useState, useEffect, useCallback, useSyncExternalStore } from 'react';
import {
  ColourRecord,
  Palette,
  ProjectState,
  LightingPreset,
  MaterialSpec,
  ColourExperiment,
} from '../types/colour';
import {
  createColourFromHex,
  createColourFromOklch,
  createColourFromRgb,
  createColourFromHsl,
  createColourFromLab,
} from '../core/colour-math';
import { MASTER_COLOUR_LIBRARY, INITIAL_AUREOM_PALETTE } from '../data/colour-library';
import { MATERIAL_SPECS } from '../core/materials';

interface ColourStoreContextType {
  state: ProjectState;
  setCurrentColour: (colour: ColourRecord, pushHistory?: boolean) => void;
  setComparisonColour: (colour: ColourRecord) => void;
  updateCurrentColourFromHex: (hex: string) => void;
  updateCurrentColourFromRgb: (r: number, g: number, b: number) => void;
  updateCurrentColourFromOklch: (l: number, c: number, h: number) => void;
  updateCurrentColourFromHsl: (h: number, s: number, l: number) => void;
  updateCurrentColourFromLab: (l: number, a: number, b: number) => void;
  setActiveNavTab: (tab: string) => void;
  setActivePalette: (paletteId: string) => void;
  updateActivePalette: (updated: Palette) => void;
  addPaletteColour: (colour: ColourRecord, role?: string) => void;
  removePaletteColour: (colourId: string) => void;
  setActiveMaterialId: (materialId: string) => void;
  setActiveLightingPreset: (preset: LightingPreset) => void;
  setDisplayProfile: (profile: 'sRGB' | 'Display-P3' | 'Rec.2020') => void;
  setRenderMode: (mode: 'DISPLAY PREVIEW' | 'PERCEPTUAL MATCH' | 'PRINT SIMULATION') => void;
  toggleHighContrastUi: () => void;
  toggleReducedMotion: () => void;
  toggleGamutWarnings: () => void;
  undo: () => void;
  redo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  // Demonstration workflow
  startDemoWorkflow: () => void;
  nextDemoStep: () => void;
  prevDemoStep: () => void;
  setDemoStep: (step: number) => void;
  closeDemoWorkflow: () => void;
  // Command palette
  isCommandPaletteOpen: boolean;
  setCommandPaletteOpen: (open: boolean) => void;
  // Experiments
  addExperiment: (experiment: ColourExperiment) => void;
  resetProject: () => void;
}

const LOCAL_STORAGE_KEY = 'chroma_engine_project_v1';

const defaultInitialState: ProjectState = {
  id: 'proj-aureom-industrial-01',
  name: 'AUREOM / INDUSTRIAL PALETTE SYSTEM',
  tagline: 'COLOUR IS A SYSTEM. PERCEPTUAL COLOUR · MATERIAL · LIGHT · BRAND · DISPLAY',
  version: '1.4.0',
  currentColour: MASTER_COLOUR_LIBRARY[0], // Hard Industrial Orange (#D96B24)
  comparisonColour: MASTER_COLOUR_LIBRARY[1], // Graphite Black (#121417)
  palettes: [INITIAL_AUREOM_PALETTE],
  activePaletteId: INITIAL_AUREOM_PALETTE.id,
  experiments: [],
  activeMaterialId: MATERIAL_SPECS[0].id,
  activeLightingPreset: 'daylight-d65',
  displayProfile: 'sRGB',
  renderMode: 'DISPLAY PREVIEW',
  highContrastUi: false,
  reducedMotion: false,
  gamutWarningsEnabled: true,
  activeNavTab: 'COLOUR LAB',
  demoWorkflowStep: 1, // Start with demonstration banner active
  demoWorkflowActive: true,
};

// Global reactive store for synchronized project state
const listeners = new Set<() => void>();
let currentGlobalState: ProjectState = defaultInitialState;
let hasInitializedStorage = false;

function initStorageIfBrowser() {
  if (typeof window !== 'undefined' && !hasInitializedStorage) {
    hasInitializedStorage = true;
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (saved) {
        currentGlobalState = {
          ...defaultInitialState,
          ...JSON.parse(saved),
        };
      }
    } catch (err) {
      console.warn('Failed to load local storage state:', err);
    }
  }
}

function getClientSnapshot(): ProjectState {
  initStorageIfBrowser();
  return currentGlobalState;
}

function getServerSnapshot(): ProjectState {
  return defaultInitialState;
}

function subscribe(callback: () => void) {
  listeners.add(callback);
  return () => {
    listeners.delete(callback);
  };
}

function updateGlobalProjectState(updater: (prev: ProjectState) => ProjectState) {
  currentGlobalState = updater(currentGlobalState);
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(currentGlobalState));
    } catch (e) {
      console.warn('Local storage write error:', e);
    }
  }
  listeners.forEach((listener) => listener());
}

const ColourStoreContext = createContext<ColourStoreContextType | null>(null);

export function ColourStoreProvider({ children }: { children: React.ReactNode }) {
  const state = useSyncExternalStore(subscribe, getClientSnapshot, getServerSnapshot);
  const [history, setHistory] = useState<ColourRecord[]>([defaultInitialState.currentColour]);
  const [historyIndex, setHistoryIndex] = useState<number>(0);
  const [isCommandPaletteOpen, setCommandPaletteOpen] = useState(false);

  const setCurrentColour = useCallback((colour: ColourRecord, pushHistory: boolean = true) => {
    updateGlobalProjectState((prev) => ({ ...prev, currentColour: colour }));
    if (pushHistory) {
      setHistory((prev) => {
        const newHist = prev.slice(0, historyIndex + 1);
        newHist.push(colour);
        if (newHist.length > 50) newHist.shift();
        return newHist;
      });
      setHistoryIndex((prev) => Math.min(prev + 1, 49));
    }
  }, [historyIndex]);

  const setComparisonColour = useCallback((colour: ColourRecord) => {
    updateGlobalProjectState((prev) => ({ ...prev, comparisonColour: colour }));
  }, []);

  const updateCurrentColourFromHex = useCallback((hex: string) => {
    const col = createColourFromHex(hex);
    setCurrentColour(col, true);
  }, [setCurrentColour]);

  const updateCurrentColourFromRgb = useCallback((r: number, g: number, b: number) => {
    const col = createColourFromHex(
      `#${Math.max(0, Math.min(255, Math.round(r))).toString(16).padStart(2, '0')}${Math.max(0, Math.min(255, Math.round(g))).toString(16).padStart(2, '0')}${Math.max(0, Math.min(255, Math.round(b))).toString(16).padStart(2, '0')}`
    );
    setCurrentColour(col, false);
  }, [setCurrentColour]);

  const updateCurrentColourFromOklch = useCallback((l: number, c: number, h: number) => {
    const col = createColourFromOklch({ l, c, h });
    setCurrentColour(col, false);
  }, [setCurrentColour]);

  const updateCurrentColourFromHsl = useCallback((h: number, s: number, l: number) => {
    const col = createColourFromHsl({ h, s, l });
    setCurrentColour(col, false);
  }, [setCurrentColour]);

  const updateCurrentColourFromLab = useCallback((l: number, a: number, b: number) => {
    const col = createColourFromLab({ l, a, b });
    setCurrentColour(col, false);
  }, [setCurrentColour]);

  const setActiveNavTab = useCallback((tab: string) => {
    updateGlobalProjectState((prev) => ({ ...prev, activeNavTab: tab }));
  }, []);

  const setActivePalette = useCallback((paletteId: string) => {
    updateGlobalProjectState((prev) => ({ ...prev, activePaletteId: paletteId }));
  }, []);

  const updateActivePalette = useCallback((updated: Palette) => {
    updateGlobalProjectState((prev) => ({
      ...prev,
      palettes: prev.palettes.map((p) => (p.id === updated.id ? updated : p)),
    }));
  }, []);

  const addPaletteColour = useCallback((colour: ColourRecord, role: string = 'accent') => {
    updateGlobalProjectState((prev) => {
      const activeP = prev.palettes.find((p) => p.id === prev.activePaletteId) || prev.palettes[0];
      const newColours = [
        ...activeP.colours,
        {
          id: `pc-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
          role: role as any,
          colour,
          notes: 'Added from Chroma Engine Workstation',
        },
      ];
      const updatedP = { ...activeP, colours: newColours, updatedAt: new Date().toISOString() };
      return {
        ...prev,
        palettes: prev.palettes.map((p) => (p.id === updatedP.id ? updatedP : p)),
      };
    });
  }, []);

  const removePaletteColour = useCallback((colourId: string) => {
    updateGlobalProjectState((prev) => {
      const activeP = prev.palettes.find((p) => p.id === prev.activePaletteId) || prev.palettes[0];
      const newColours = activeP.colours.filter((c) => c.id !== colourId);
      const updatedP = { ...activeP, colours: newColours, updatedAt: new Date().toISOString() };
      return {
        ...prev,
        palettes: prev.palettes.map((p) => (p.id === updatedP.id ? updatedP : p)),
      };
    });
  }, []);

  const setActiveMaterialId = useCallback((materialId: string) => {
    updateGlobalProjectState((prev) => ({ ...prev, activeMaterialId: materialId }));
  }, []);

  const setActiveLightingPreset = useCallback((preset: LightingPreset) => {
    updateGlobalProjectState((prev) => ({ ...prev, activeLightingPreset: preset }));
  }, []);

  const setDisplayProfile = useCallback((profile: 'sRGB' | 'Display-P3' | 'Rec.2020') => {
    updateGlobalProjectState((prev) => ({ ...prev, displayProfile: profile }));
  }, []);

  const setRenderMode = useCallback((mode: 'DISPLAY PREVIEW' | 'PERCEPTUAL MATCH' | 'PRINT SIMULATION') => {
    updateGlobalProjectState((prev) => ({ ...prev, renderMode: mode }));
  }, []);

  const toggleHighContrastUi = useCallback(() => {
    updateGlobalProjectState((prev) => ({ ...prev, highContrastUi: !prev.highContrastUi }));
  }, []);

  const toggleReducedMotion = useCallback(() => {
    updateGlobalProjectState((prev) => ({ ...prev, reducedMotion: !prev.reducedMotion }));
  }, []);

  const toggleGamutWarnings = useCallback(() => {
    updateGlobalProjectState((prev) => ({ ...prev, gamutWarningsEnabled: !prev.gamutWarningsEnabled }));
  }, []);

  const undo = useCallback(() => {
    if (historyIndex > 0) {
      const newIdx = historyIndex - 1;
      setHistoryIndex(newIdx);
      setCurrentColour(history[newIdx], false);
    }
  }, [historyIndex, history, setCurrentColour]);

  const redo = useCallback(() => {
    if (historyIndex < history.length - 1) {
      const newIdx = historyIndex + 1;
      setHistoryIndex(newIdx);
      setCurrentColour(history[newIdx], false);
    }
  }, [historyIndex, history, setCurrentColour]);

  // Demo Workflow Handlers
  const startDemoWorkflow = useCallback(() => {
    updateGlobalProjectState((prev) => ({
      ...prev,
      demoWorkflowActive: true,
      demoWorkflowStep: 1,
      activeNavTab: 'COLOUR LAB',
      currentColour: MASTER_COLOUR_LIBRARY[0],
    }));
  }, []);

  const nextDemoStep = useCallback(() => {
    updateGlobalProjectState((prev) => {
      const next = Math.min(10, prev.demoWorkflowStep + 1);
      let nextTab = prev.activeNavTab;

      // Navigate to matching tabs on specific steps
      if (next === 2) nextTab = 'COLOUR SPACES';
      else if (next === 3) nextTab = 'TONAL SYSTEM';
      else if (next === 4) nextTab = 'HARMONIES';
      else if (next === 5) nextTab = 'ACCESSIBILITY';
      else if (next === 6) nextTab = 'TOKEN PLAYGROUND';
      else if (next === 7) nextTab = 'MATERIALS';
      else if (next === 8) nextTab = 'LIGHTING';
      else if (next === 9) nextTab = 'DISPLAY';
      else if (next === 10) nextTab = 'EXPORT';

      return {
        ...prev,
        demoWorkflowStep: next,
        activeNavTab: nextTab,
      };
    });
  }, []);

  const prevDemoStep = useCallback(() => {
    updateGlobalProjectState((prev) => {
      const prevStep = Math.max(1, prev.demoWorkflowStep - 1);
      let prevTab = prev.activeNavTab;

      if (prevStep === 1) prevTab = 'COLOUR LAB';
      else if (prevStep === 2) prevTab = 'COLOUR SPACES';
      else if (prevStep === 3) prevTab = 'TONAL SYSTEM';
      else if (prevStep === 4) prevTab = 'HARMONIES';
      else if (prevStep === 5) prevTab = 'ACCESSIBILITY';
      else if (prevStep === 6) prevTab = 'TOKEN PLAYGROUND';
      else if (prevStep === 7) prevTab = 'MATERIALS';
      else if (prevStep === 8) prevTab = 'LIGHTING';
      else if (prevStep === 9) prevTab = 'DISPLAY';
      else if (prevStep === 10) prevTab = 'EXPORT';

      return {
        ...prev,
        demoWorkflowStep: prevStep,
        activeNavTab: prevTab,
      };
    });
  }, []);

  const setDemoStep = useCallback((step: number) => {
    updateGlobalProjectState((prev) => ({ ...prev, demoWorkflowStep: step }));
  }, []);

  const closeDemoWorkflow = useCallback(() => {
    updateGlobalProjectState((prev) => ({ ...prev, demoWorkflowActive: false }));
  }, []);

  const addExperiment = useCallback((exp: ColourExperiment) => {
    updateGlobalProjectState((prev) => ({
      ...prev,
      experiments: [exp, ...prev.experiments],
    }));
  }, []);

  const resetProject = useCallback(() => {
    updateGlobalProjectState(() => defaultInitialState);
    setHistory([defaultInitialState.currentColour]);
    setHistoryIndex(0);
  }, []);

  // Global Keyboard Shortcuts
  useEffect(() => {
    let lastKey = '';
    let lastKeyTime = 0;

    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger shortcuts when focused in text inputs
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable) {
        if (e.key === 'Escape') {
          target.blur();
        }
        return;
      }

      // Ctrl + K -> Command Palette
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setCommandPaletteOpen((prev) => !prev);
        return;
      }

      // Ctrl + S -> Save notification
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        if (typeof window !== 'undefined') {
          localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(state));
        }
        return;
      }

      // Ctrl + Z -> Undo, Ctrl + Shift + Z -> Redo
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        if (e.shiftKey) redo();
        else undo();
        return;
      }

      // '/' -> Focus Search
      if (e.key === '/') {
        e.preventDefault();
        setActiveNavTab('COLOUR SEARCH');
        return;
      }

      if (e.key === 'Escape') {
        setCommandPaletteOpen(false);
        return;
      }

      // Two-key chord sequences (G then key)
      const now = Date.now();
      if (lastKey === 'g' && now - lastKeyTime < 1000) {
        if (e.key === 'l' || e.key === '1') setActiveNavTab('COLOUR LAB');
        if (e.key === 's' || e.key === '2') setActiveNavTab('COLOUR SPACES');
        if (e.key === 't' || e.key === '3') setActiveNavTab('TONAL SYSTEM');
        if (e.key === 'h' || e.key === '4') setActiveNavTab('HARMONIES');
        if (e.key === 'p' || e.key === '5') setActiveNavTab('PALETTES');
        if (e.key === 'a' || e.key === '6') setActiveNavTab('ACCESSIBILITY');
        if (e.key === 'k' || e.key === '7') setActiveNavTab('TOKEN PLAYGROUND');
        if (e.key === 'm' || e.key === '8') setActiveNavTab('MATERIALS');
        if (e.key === 'i' || e.key === '9') setActiveNavTab('LIGHTING');
        if (e.key === 'd' || e.key === '0') setActiveNavTab('DISPLAY');
        if (e.key === 'e') setActiveNavTab('EXPORT');
        lastKey = '';
        return;
      }

      if (e.key === 'g') {
        lastKey = 'g';
        lastKeyTime = now;
      } else {
        lastKey = '';
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [state, undo, redo, setActiveNavTab]);

  return (
    <ColourStoreContext.Provider
      value={{
        state,
        setCurrentColour,
        setComparisonColour,
        updateCurrentColourFromHex,
        updateCurrentColourFromRgb,
        updateCurrentColourFromOklch,
        updateCurrentColourFromHsl,
        updateCurrentColourFromLab,
        setActiveNavTab,
        setActivePalette,
        updateActivePalette,
        addPaletteColour,
        removePaletteColour,
        setActiveMaterialId,
        setActiveLightingPreset,
        setDisplayProfile,
        setRenderMode,
        toggleHighContrastUi,
        toggleReducedMotion,
        toggleGamutWarnings,
        undo,
        redo,
        canUndo: historyIndex > 0,
        canRedo: historyIndex < history.length - 1,
        startDemoWorkflow,
        nextDemoStep,
        prevDemoStep,
        setDemoStep,
        closeDemoWorkflow,
        isCommandPaletteOpen,
        setCommandPaletteOpen,
        addExperiment,
        resetProject,
      }}
    >
      {children}
    </ColourStoreContext.Provider>
  );
}

export function useColourStore() {
  const context = useContext(ColourStoreContext);
  if (!context) {
    throw new Error('useColourStore must be used within a ColourStoreProvider');
  }
  return context;
}
