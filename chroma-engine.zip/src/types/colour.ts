// Chroma Engine Master Colour Types & System Data Models

export type RGB = {
  r: number; // 0..255
  g: number; // 0..255
  b: number; // 0..255
};

export type LinearRGB = {
  r: number; // 0..1
  g: number; // 0..1
  b: number; // 0..1
};

export type HSL = {
  h: number; // 0..360
  s: number; // 0..100
  l: number; // 0..100
};

export type HSV = {
  h: number; // 0..360
  s: number; // 0..100
  v: number; // 0..100
};

export type HWB = {
  h: number; // 0..360
  w: number; // 0..100
  b: number; // 0..100
};

export type XYZ = {
  x: number; // ~0..95.047
  y: number; // ~0..100.000 (relative luminance)
  z: number; // ~0..108.883
};

export type Lab = {
  l: number; // 0..100
  a: number; // -128..127
  b: number; // -128..127
};

export type LCh = {
  l: number; // 0..100
  c: number; // 0..150
  h: number; // 0..360
};

export type OKLab = {
  l: number; // 0..1
  a: number; // -0.4..0.4
  b: number; // -0.4..0.4
};

export type OKLCh = {
  l: number; // 0..1 (or 0..100% display)
  c: number; // 0..0.4
  h: number; // 0..360
};

export type CMYK = {
  c: number; // 0..100
  m: number; // 0..100
  y: number; // 0..100
  k: number; // 0..100
};

export type DisplayP3 = {
  r: number; // 0..1
  g: number; // 0..1
  b: number; // 0..1
};

export type Rec2020 = {
  r: number; // 0..1
  g: number; // 0..1
  b: number; // 0..1
};

export type GamutStatus = {
  inSRGB: boolean;
  inDisplayP3: boolean;
  inRec2020: boolean;
  clippedChannels?: {
    srgb?: { r: boolean; g: boolean; b: boolean };
    p3?: { r: boolean; g: boolean; b: boolean };
  };
  gamutMappingApplied: boolean;
  gamutDeltaE?: number;
};

export type ContrastMetrics = {
  luminance: number; // 0..1 (WCAG standard relative luminance)
  contrastOnWhite: number; // e.g. 4.5:1
  contrastOnBlack: number;
  contrastOnDarkGraphite: number; // on #121417
  apcaOnWhite: number; // estimated APCA Lc value
  apcaOnBlack: number;
  wcagAaNormal: boolean;
  wcagAaLarge: boolean;
  wcagAaaNormal: boolean;
  wcagAaaLarge: boolean;
};

export type ColourMetadata = {
  category?: string;
  source?: string;
  tags?: string[];
  description?: string;
  spectralPeakNm?: number; // Approximate dominant wavelength in nm (380-700)
  temperatureK?: number; // Approximate correlated colour temperature in Kelvin
  isP3Only?: boolean;
};

export type ColourRecord = {
  id: string;
  name: string;
  hex: string;
  alpha: number; // 0..1

  srgb: RGB;
  linearRgb: LinearRGB;
  hsl: HSL;
  hsv: HSV;
  hwb: HWB;
  xyz: XYZ;
  lab: Lab;
  lch: LCh;
  oklab: OKLab;
  oklch: OKLCh;
  cmyk: CMYK;
  displayP3: DisplayP3;
  rec2020: Rec2020;

  luminance: number;
  contrastData: ContrastMetrics;
  gamutStatus: GamutStatus;
  metadata: ColourMetadata;
};

// Semantic UI Roles
export type SemanticRole =
  | 'background'
  | 'surface'
  | 'surface-elevated'
  | 'text-primary'
  | 'text-secondary'
  | 'border'
  | 'accent'
  | 'accent-hover'
  | 'success'
  | 'warning'
  | 'danger'
  | 'information'
  | 'selected'
  | 'disabled'
  | 'focus';

export type ColourRole = SemanticRole;

export type PaletteColour = {
  id: string;
  colour: ColourRecord;
  role: SemanticRole;
  locked?: boolean;
  notes?: string;
  lightVariantHex?: string;
  darkVariantHex?: string;
};

export type Palette = {
  id: string;
  name: string;
  description: string;
  category:
    | 'brand'
    | 'interface'
    | 'editorial'
    | 'architectural'
    | 'automotive'
    | 'fashion'
    | 'packaging'
    | 'scientific'
    | 'data visualisation'
    | 'monochrome'
    | 'neutral'
    | 'seasonal'
    | 'material'
    | 'cinematic'
    | 'accessibility-first';
  colours: PaletteColour[];
  version: string;
  author: string;
  createdAt: string;
  updatedAt: string;
  tags: string[];
};

export type TonalStep = {
  tone: number; // 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 95, 100
  colour: ColourRecord;
  contrastAgainstBase: number;
  contrastAgainstWhite: number;
  contrastAgainstBlack: number;
};

export type TonalScale = {
  baseColour: ColourRecord;
  space: 'oklch' | 'lab' | 'lch' | 'hsl';
  steps: TonalStep[];
};

export type HarmonyType =
  | 'monochromatic'
  | 'analogous'
  | 'complementary'
  | 'split-complementary'
  | 'triadic'
  | 'tetradic'
  | 'square'
  | 'double-complementary'
  | 'warm-cool'
  | 'near-neutral'
  | 'high-contrast'
  | 'low-contrast'
  | 'custom-angular';

export type HarmonyResult = {
  type: HarmonyType;
  title: string;
  description: string;
  colours: ColourRecord[];
  angles: number[];
};

export type MixingModel =
  | 'srgb'
  | 'linear-rgb'
  | 'lab'
  | 'lch'
  | 'oklab'
  | 'oklch'
  | 'subtractive-pigment';

export type MaterialCategory =
  | 'anodised aluminium'
  | 'brushed steel'
  | 'polished steel'
  | 'concrete'
  | 'sandstone'
  | 'brick'
  | 'ceramic'
  | 'glass'
  | 'carbon fibre'
  | 'rubber'
  | 'leather'
  | 'paper'
  | 'textile'
  | 'paint'
  | 'plastic'
  | 'wood'
  | 'oxidised copper'
  | 'titanium'
  | 'asphalt'
  | 'architectural stone';

export type MaterialSpec = {
  id: string;
  name: string;
  category: MaterialCategory;
  roughness: number; // 0..1
  metallic: number; // 0..1
  reflectance: number; // 0..1
  specular: number; // 0..1
  opacity: number; // 0..1
  normalNoise: number; // 0..1
  anisotropy: number; // 0..1
  description: string;
  subsurfaceScatter?: number;
};

export type LightingPreset =
  | 'daylight-d65'
  | 'overcast-7500k'
  | 'incandescent-2700k'
  | 'cool-led-4000k'
  | 'office-fluorescent'
  | 'gallery-halogen-3000k'
  | 'sunset-2200k'
  | 'moonlight-4100k'
  | 'industrial-sodium'
  | 'custom-rgb';

export type LightingCondition = {
  preset: LightingPreset;
  name: string;
  temperatureK: number;
  intensity: number; // 0..2
  ambientLevel: number; // 0..1
  angleDeg: number; // 0..360
  rgbFilter: RGB; // 0..255 multiplier
  description: string;
};

export type ColourBlindnessType =
  | 'protanopia' // L-cone missing (red-blind)
  | 'deuteranopia' // M-cone missing (green-blind)
  | 'tritanopia' // S-cone missing (blue-blind)
  | 'achromatopsia' // Rod monochromacy (total colour blindness)
  | 'low-vision' // Cataract / blur & contrast reduction
  | 'reduced-contrast'
  | 'display-washout';

export type ColourDifferenceMethod =
  | 'deltaE76'
  | 'deltaE94'
  | 'deltaE2000'
  | 'deltaEOKLab'
  | 'deltaEOKLCh'
  | 'euclideanRGB';

export type DifferenceEvaluation = {
  method: ColourDifferenceMethod;
  value: number;
  interpretation: string; // e.g., "Not perceptible by human eye (<1.0)", "Perceptible through close inspection (1.0-2.0)", etc.
  toleranceStatus: 'negligible' | 'perceptible' | 'significant' | 'distinct';
  limitations: string;
};

export type GradientStop = {
  id: string;
  position: number; // 0..100%
  colour: ColourRecord;
  opacity: number; // 0..1
};

export type GradientSpec = {
  id: string;
  name: string;
  type: 'linear' | 'radial' | 'conic';
  angle: number; // degrees
  interpolationSpace: 'srgb' | 'linear-rgb' | 'hsl' | 'lab' | 'lch' | 'oklab' | 'oklch';
  stops: GradientStop[];
  easing: 'linear' | 'ease-in' | 'ease-out' | 'ease-in-out' | 'perceptual';
};

export type ImageColourExtraction = {
  fileName: string;
  dimensions: { width: number; height: number };
  dominantPalette: ColourRecord[];
  averageColour: ColourRecord;
  highlightColour: ColourRecord;
  shadowColour: ColourRecord;
  vibrantColour: ColourRecord;
  mutedColour: ColourRecord;
  luminanceHistogram: number[]; // 256 bins
  saturationHistogram: number[]; // 256 bins
  hueHistogram: number[]; // 360 bins
  warmCoolRatio: number; // >1 = warmer, <1 = cooler
};

export type ColourExperiment = {
  id: string;
  name: string;
  objective: string;
  inputColours: ColourRecord[];
  colourSpace: string;
  conversionMethod: string;
  mixingMethod: MixingModel;
  lightingCondition: LightingPreset;
  material: MaterialCategory;
  contrastCriteria: string;
  results: {
    mixedColour?: ColourRecord;
    deltaE?: number;
    passContrast?: boolean;
    gamutClipping?: boolean;
    notes?: string;
  };
  notes: string;
  timestamp: string;
  version: number;
};

export type ProjectState = {
  id: string;
  name: string;
  tagline: string;
  version: string;
  currentColour: ColourRecord;
  comparisonColour: ColourRecord;
  palettes: Palette[];
  activePaletteId: string;
  experiments: ColourExperiment[];
  activeMaterialId: string;
  activeLightingPreset: LightingPreset;
  displayProfile: 'sRGB' | 'Display-P3' | 'Rec.2020';
  renderMode: 'DISPLAY PREVIEW' | 'PERCEPTUAL MATCH' | 'PRINT SIMULATION';
  highContrastUi: boolean;
  reducedMotion: boolean;
  gamutWarningsEnabled: boolean;
  activeNavTab: string;
  demoWorkflowStep: number; // 0 = not started or completed, 1..10 = active step
  demoWorkflowActive: boolean;
};
