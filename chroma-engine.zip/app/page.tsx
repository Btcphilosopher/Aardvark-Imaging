'use client';

import React from 'react';
import { ColourStoreProvider, useColourStore } from '../src/state/colour-store';
import { HeaderBar } from '../src/components/layout/HeaderBar';
import { NavigationBar } from '../src/components/layout/NavigationBar';
import { DemoWorkflowBanner } from '../src/components/layout/DemoWorkflowBanner';
import { CommandPalette } from '../src/components/layout/CommandPalette';

// Views
import { ColourLabView } from '../src/components/views/ColourLabView';
import { ColourSpacesView } from '../src/components/views/ColourSpacesView';
import { MixingView } from '../src/components/views/MixingView';
import { HarmoniesView } from '../src/components/views/HarmoniesView';
import { PaletteStudioView } from '../src/components/views/PaletteStudioView';
import { TonalScaleView } from '../src/components/views/TonalScaleView';
import { ContrastView } from '../src/components/views/ContrastView';
import { AccessibilityView } from '../src/components/views/AccessibilityView';
import { MaterialsView } from '../src/components/views/MaterialsView';
import { LightingView } from '../src/components/views/LightingView';
import { TokenPlaygroundView } from '../src/components/views/TokenPlaygroundView';
import { GradientsView } from '../src/components/views/GradientsView';
import { ImageAnalysisView } from '../src/components/views/ImageAnalysisView';
import { DataColourView } from '../src/components/views/DataColourView';
import { PrintProductionView } from '../src/components/views/PrintProductionView';
import { DisplayCalibrationView } from '../src/components/views/DisplayCalibrationView';
import { DifferenceView } from '../src/components/views/DifferenceView';
import { ExperimentsView } from '../src/components/views/ExperimentsView';
import { ColourSearchView } from '../src/components/views/ColourSearchView';
import { LibraryView } from '../src/components/views/LibraryView';
import { ExportView } from '../src/components/views/ExportView';

function WorkstationContent() {
  const { state } = useColourStore();

  const renderActiveView = () => {
    switch (state.activeNavTab) {
      case 'COLOUR LAB':
        return <ColourLabView />;
      case 'SPACES':
        return <ColourSpacesView />;
      case 'MIXING':
        return <MixingView />;
      case 'HARMONIES':
        return <HarmoniesView />;
      case 'PALETTE STUDIO':
        return <PaletteStudioView />;
      case 'TONAL SCALES':
        return <TonalScaleView />;
      case 'CONTRAST':
        return <ContrastView />;
      case 'ACCESSIBILITY':
        return <AccessibilityView />;
      case 'MATERIALS':
        return <MaterialsView />;
      case 'LIGHTING':
        return <LightingView />;
      case 'BRAND SYSTEMS':
      case 'TOKEN PLAYGROUND':
        return <TokenPlaygroundView />;
      case 'GRADIENTS':
        return <GradientsView />;
      case 'IMAGE ANALYSIS':
        return <ImageAnalysisView />;
      case 'DATA COLOUR':
        return <DataColourView />;
      case 'PRINT & PRODUCTION':
        return <PrintProductionView />;
      case 'DISPLAY':
        return <DisplayCalibrationView />;
      case 'DIFFERENCE':
        return <DifferenceView />;
      case 'EXPERIMENTS':
        return <ExperimentsView />;
      case 'SEARCH':
        return <ColourSearchView />;
      case 'LIBRARY':
        return <LibraryView />;
      case 'EXPORT':
        return <ExportView />;
      default:
        return <ColourLabView />;
    }
  };

  return (
    <div className="min-h-screen bg-[#0e1013] text-[#f4f4f6] flex flex-col antialiased selection:bg-[#ff5500] selection:text-white">
      {/* Top Application Bar */}
      <HeaderBar />

      {/* Guided Industrial Workflow Banner */}
      <DemoWorkflowBanner />

      {/* System Navigation Tabs */}
      <NavigationBar />

      {/* Main Dynamic Workstation Canvas */}
      <main className="flex-1 overflow-y-auto pb-12">
        {renderActiveView()}
      </main>

      {/* Command Palette Modal */}
      <CommandPalette />
    </div>
  );
}

export default function Page() {
  return (
    <ColourStoreProvider>
      <WorkstationContent />
    </ColourStoreProvider>
  );
}
