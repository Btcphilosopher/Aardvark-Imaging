import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Chroma Engine — Colour Science & Visual Systems Workstation',
  description:
    'Professional colour science, palette design, and visual systems workstation for industrial designers, brand architects, and material scientists.',
  openGraph: {
    title: 'Chroma Engine — Colour Science & Visual Systems Workstation',
    description:
      'Professional colour science, palette design, and visual systems workstation for industrial designers, brand architects, and material scientists.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Chroma Engine — Colour Science & Visual Systems Workstation',
    description:
      'Professional colour science, palette design, and visual systems workstation for industrial designers, brand architects, and material scientists.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="dark bg-[#0e1013] text-[#f4f4f6]">
      <body className="min-h-screen bg-[#0e1013] text-[#f4f4f6] antialiased selection:bg-[#ff5500] selection:text-white" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
