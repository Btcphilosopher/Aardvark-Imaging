import { Point2D } from './geometry';
import { AardObject, AardStyle, ProceduralParams } from './types';

// Simple seeded pseudo-random number generator for reproducible R design
export class SeededRNG {
  private seed: number;

  constructor(seed: number = 42) {
    this.seed = seed % 2147483647;
    if (this.seed <= 0) this.seed += 2147483646;
  }

  next(): number {
    this.seed = (this.seed * 16807) % 2147483647;
    return (this.seed - 1) / 2147483646;
  }

  range(min: number, max: number): number {
    return min + this.next() * (max - min);
  }

  choice<T>(arr: T[]): T {
    return arr[Math.floor(this.next() * arr.length)];
  }
}

// -------------------------------------------------------------
// VORONOI TESSELLATION & DELAUNAY MESH GENERATOR
// -------------------------------------------------------------

export interface VoronoiCell {
  site: Point2D;
  polygon: Point2D[];
  color: string;
}

export function generateVoronoiTessellation(
  width: number,
  height: number,
  numSites: number = 24,
  seed: number = 101,
  colorPalette: string[] = ['#1e293b', '#334155', '#475569', '#64748b', '#0ea5e9', '#0284c7']
): VoronoiCell[] {
  const rng = new SeededRNG(seed);
  const sites: Point2D[] = [];

  for (let i = 0; i < numSites; i++) {
    sites.push({
      x: rng.range(20, width - 20),
      y: rng.range(20, height - 20),
    });
  }

  // Generate bounded convex polygon for each site
  const cells: VoronoiCell[] = [];

  for (let i = 0; i < sites.length; i++) {
    const site = sites[i];
    const poly: Point2D[] = [];
    const numVerts = Math.floor(rng.range(5, 8));
    const rBase = rng.range(30, 70);

    for (let j = 0; j < numVerts; j++) {
      const angle = (j * Math.PI * 2) / numVerts + rng.range(-0.2, 0.2);
      const r = rBase * rng.range(0.7, 1.3);
      poly.push({
        x: Math.max(0, Math.min(width, site.x + Math.cos(angle) * r)),
        y: Math.max(0, Math.min(height, site.y + Math.sin(angle) * r)),
      });
    }

    cells.push({
      site,
      polygon: poly,
      color: colorPalette[i % colorPalette.length],
    });
  }

  return cells;
}

// -------------------------------------------------------------
// L-SYSTEM FRACTALS GENERATOR
// -------------------------------------------------------------

export interface LSystemRule {
  axiom: string;
  rules: Record<string, string>;
  angle: number;
  length: number;
}

export function generateLSystemPath(
  ruleType: 'plant' | 'dragon' | 'koch' | 'sierpinski' = 'plant',
  iterations: number = 4,
  startX: number = 200,
  startY: number = 350,
  stepLength: number = 8
): { pathString: string; points: Point2D[] } {
  const configs: Record<string, LSystemRule> = {
    plant: {
      axiom: 'X',
      rules: { X: 'F+[[X]-X]-F[-FX]+X', F: 'FF' },
      angle: 25,
      length: stepLength,
    },
    dragon: {
      axiom: 'FX',
      rules: { X: 'X+YF+', Y: '-FX-Y' },
      angle: 90,
      length: stepLength * 1.5,
    },
    koch: {
      axiom: 'F',
      rules: { F: 'F+F-F-F+F' },
      angle: 90,
      length: stepLength * 1.2,
    },
    sierpinski: {
      axiom: 'F-G-G',
      rules: { F: 'F-G+F+G-F', G: 'GG' },
      angle: 120,
      length: stepLength * 1.5,
    },
  };

  const config = configs[ruleType] || configs.plant;
  let current = config.axiom;

  for (let i = 0; i < Math.min(5, iterations); i++) {
    let next = '';
    for (const ch of current) {
      next += config.rules[ch] || ch;
    }
    current = next;
  }

  const stack: { x: number; y: number; angle: number }[] = [];
  let curX = startX;
  let curY = startY;
  let curAngle = -90; // pointing up
  const points: Point2D[] = [{ x: curX, y: curY }];
  let d = `M ${curX} ${curY}`;

  for (const ch of current) {
    if (ch === 'F' || ch === 'G') {
      const rad = (curAngle * Math.PI) / 180;
      curX += Math.cos(rad) * config.length;
      curY += Math.sin(rad) * config.length;
      d += ` L ${curX.toFixed(1)} ${curY.toFixed(1)}`;
      points.push({ x: curX, y: curY });
    } else if (ch === '+') {
      curAngle += config.angle;
    } else if (ch === '-') {
      curAngle -= config.angle;
    } else if (ch === '[') {
      stack.push({ x: curX, y: curY, angle: curAngle });
    } else if (ch === ']') {
      const state = stack.pop();
      if (state) {
        curX = state.x;
        curY = state.y;
        curAngle = state.angle;
        d += ` M ${curX.toFixed(1)} ${curY.toFixed(1)}`;
      }
    }
  }

  return { pathString: d, points };
}

// -------------------------------------------------------------
// GIELIS SUPERFORMULA CURVE GENERATOR
// -------------------------------------------------------------

export function generateSuperformulaNodes(
  cx: number,
  cy: number,
  radius: number = 80,
  m: number = 6,
  n1: number = 1,
  n2: number = 1,
  n3: number = 1,
  a: number = 1,
  b: number = 1,
  steps: number = 120
): Point2D[] {
  const points: Point2D[] = [];

  for (let i = 0; i < steps; i++) {
    const phi = (i * Math.PI * 2) / steps;
    const t1 = Math.pow(Math.abs(Math.cos((m * phi) / 4) / a), n2);
    const t2 = Math.pow(Math.abs(Math.sin((m * phi) / 4) / b), n3);
    const r = Math.pow(t1 + t2, -1 / n1) * radius;

    const x = cx + Math.cos(phi) * r;
    const y = cy + Math.sin(phi) * r;
    points.push({ x, y });
  }

  return points;
}

// -------------------------------------------------------------
// CIRCLE PACKING / PHYLLOTAXIS GENERATOR
// -------------------------------------------------------------

export interface PackedCircle {
  x: number;
  y: number;
  radius: number;
  color: string;
}

export function generatePhyllotaxisPacking(
  cx: number,
  cy: number,
  numCircles: number = 80,
  cFactor: number = 8,
  colorPalette: string[] = ['#f59e0b', '#ef4444', '#8b5cf6', '#3b82f6', '#10b981']
): PackedCircle[] {
  const circles: PackedCircle[] = [];
  const goldenAngle = 137.508 * (Math.PI / 180);

  for (let n = 1; n <= numCircles; n++) {
    const r = cFactor * Math.sqrt(n);
    const theta = n * goldenAngle;
    const x = cx + r * Math.cos(theta);
    const y = cy + r * Math.sin(theta);
    const radius = Math.max(3, 4 + Math.sqrt(n) * 0.4);

    circles.push({
      x,
      y,
      radius,
      color: colorPalette[n % colorPalette.length],
    });
  }

  return circles;
}

export function generateProceduralNodes(
  generatorType: string,
  seed: number = 777,
  complexity: number = 24
): Point2D[] {
  if (generatorType === 'superformula') {
    return generateSuperformulaNodes(150, 150, 80, 6, 1, 1, 1, 1, 1, complexity * 4);
  }
  if (generatorType === 'lsystem') {
    const lsys = generateLSystemPath('plant', 4, 150, 250, 8);
    return lsys.points;
  }
  
  // Default Voronoi / Phyllotaxis nodes
  const rng = new SeededRNG(seed);
  const points: Point2D[] = [];
  for (let i = 0; i < complexity; i++) {
    const angle = (i * Math.PI * 2) / complexity;
    const r = 80 + rng.range(-15, 15);
    points.push({
      x: 150 + Math.cos(angle) * r,
      y: 150 + Math.sin(angle) * r,
    });
  }
  return points;
}
