import { Point2D } from './geometry';
import { UnitType } from './types';

export type Matrix2D = [number, number, number, number, number, number]; // [a, b, c, d, e, f] representing [scaleX, skewY, skewX, scaleY, transX, transY]

export const IDENTITY_MATRIX: Matrix2D = [1, 0, 0, 1, 0, 0];

export function multiplyMatrices(m1: Matrix2D, m2: Matrix2D): Matrix2D {
  return [
    m1[0] * m2[0] + m1[2] * m2[1],
    m1[1] * m2[0] + m1[3] * m2[1],
    m1[0] * m2[2] + m1[2] * m2[3],
    m1[1] * m2[2] + m1[3] * m2[3],
    m1[0] * m2[4] + m1[2] * m2[5] + m1[4],
    m1[1] * m2[4] + m1[3] * m2[5] + m1[5],
  ];
}

export function createTranslationMatrix(tx: number, ty: number): Matrix2D {
  return [1, 0, 0, 1, tx, ty];
}

export function createRotationMatrix(angleDeg: number): Matrix2D {
  const rad = (angleDeg * Math.PI) / 180;
  const cos = Math.cos(rad);
  const sin = Math.sin(rad);
  return [cos, sin, -sin, cos, 0, 0];
}

export function createScaleMatrix(sx: number, sy: number): Matrix2D {
  return [sx, 0, 0, sy, 0, 0];
}

export function transformPoint(p: Point2D, m: Matrix2D): Point2D {
  return {
    x: m[0] * p.x + m[2] * p.y + m[4],
    y: m[1] * p.x + m[3] * p.y + m[5],
  };
}

export function invertMatrix(m: Matrix2D): Matrix2D | null {
  const det = m[0] * m[3] - m[1] * m[2];
  if (Math.abs(det) < 1e-6) return null;
  const invDet = 1 / det;
  return [
    m[3] * invDet,
    -m[1] * invDet,
    -m[2] * invDet,
    m[0] * invDet,
    (m[2] * m[5] - m[3] * m[4]) * invDet,
    (m[1] * m[4] - m[0] * m[5]) * invDet,
  ];
}

// -------------------------------------------------------------
// UNIT CONVERSION ENGINE (Canonical internal unit is px at 72/96 DPI)
// -------------------------------------------------------------

export function convertFromPx(pxValue: number, unit: UnitType, dpi: number = 72): number {
  switch (unit) {
    case 'px': return pxValue;
    case 'pt': return pxValue * (72 / dpi);
    case 'in': return pxValue / dpi;
    case 'mm': return (pxValue / dpi) * 25.4;
    case 'cm': return (pxValue / dpi) * 2.54;
    case 'pica': return (pxValue / dpi) * 6;
    default: return pxValue;
  }
}

export function convertToPx(unitValue: number, unit: UnitType, dpi: number = 72): number {
  switch (unit) {
    case 'px': return unitValue;
    case 'pt': return unitValue * (dpi / 72);
    case 'in': return unitValue * dpi;
    case 'mm': return (unitValue / 25.4) * dpi;
    case 'cm': return (unitValue / 2.54) * dpi;
    case 'pica': return (unitValue / 6) * dpi;
    default: return unitValue;
  }
}

export function formatUnit(value: number, unit: UnitType, precision: number = 1): string {
  const converted = convertFromPx(value, unit);
  return `${converted.toFixed(precision)} ${unit}`;
}

// -------------------------------------------------------------
// SNAPPING ENGINE (Grid, Smart Guides, Artboard Bounds)
// -------------------------------------------------------------

export interface SnapResult {
  x: number;
  y: number;
  snappedX: boolean;
  snappedY: boolean;
  guideLines: { x1: number; y1: number; x2: number; y2: number; label?: string }[];
}

export function screenToCanvas(
  screenPoint: Point2D,
  pan: Point2D,
  zoom: number
): Point2D {
  return {
    x: (screenPoint.x - pan.x) / zoom,
    y: (screenPoint.y - pan.y) / zoom,
  };
}

export function canvasToScreen(
  canvasPoint: Point2D,
  pan: Point2D,
  zoom: number
): Point2D {
  return {
    x: canvasPoint.x * zoom + pan.x,
    y: canvasPoint.y * zoom + pan.y,
  };
}

export function snapPointToGrid(
  pointOrX: Point2D | number,
  gridSizeOrY: number,
  gridSizeParam?: number,
  snapDistance: number = 8
): Point2D & { snapped: boolean } {
  let x: number;
  let y: number;
  let gridSize: number;

  if (typeof pointOrX === 'object') {
    x = pointOrX.x;
    y = pointOrX.y;
    gridSize = gridSizeOrY;
  } else {
    x = pointOrX;
    y = gridSizeOrY;
    gridSize = gridSizeParam || 10;
  }

  const remX = x % gridSize;
  const remY = y % gridSize;

  let snapX = x;
  let snapY = y;
  let snapped = false;

  if (Math.abs(remX) < snapDistance) {
    snapX = x - remX;
    snapped = true;
  } else if (Math.abs(remX - gridSize) < snapDistance) {
    snapX = x + (gridSize - remX);
    snapped = true;
  }

  if (Math.abs(remY) < snapDistance) {
    snapY = y - remY;
    snapped = true;
  } else if (Math.abs(remY - gridSize) < snapDistance) {
    snapY = y + (gridSize - remY);
    snapped = true;
  }

  return { x: snapX, y: snapY, snapped };
}
