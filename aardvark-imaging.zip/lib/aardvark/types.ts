export type UnitType = 'px' | 'pt' | 'mm' | 'cm' | 'in' | 'pica';

export type ToolType = 
  | 'select' 
  | 'node' 
  | 'pen' 
  | 'rect' 
  | 'ellipse' 
  | 'polygon' 
  | 'star' 
  | 'gear' 
  | 'spiral' 
  | 'wave' 
  | 'arrow' 
  | 'text' 
  | 'connector' 
  | 'dimension' 
  | 'pan' 
  | 'zoom';

export type NodeType = 'corner' | 'smooth' | 'symmetric';

export interface Point2D {
  x: number;
  y: number;
}

export interface BézierNode {
  point: Point2D;
  handleIn: Point2D;
  handleOut: Point2D;
  type: NodeType;
}

export interface AardNode {
  id: string;
  x: number;
  y: number;
  handleIn?: { x: number; y: number };
  handleOut?: { x: number; y: number };
  type: NodeType;
  selected?: boolean;
}

export type PathCommandType = 'M' | 'L' | 'C' | 'Q' | 'A' | 'Z';

export interface PathSegment {
  type: PathCommandType;
  values: number[];
}

export interface AardPath {
  segments: PathSegment[];
  nodes: AardNode[];
  closed: boolean;
}

export type FillType = 'solid' | 'linear_gradient' | 'radial_gradient' | 'conic_gradient' | 'pattern' | 'none';

export interface GradientStop {
  offset: number; // 0 to 1
  color: string;
  opacity: number;
}

export interface AardGradient {
  id: string;
  name: string;
  type: 'linear' | 'radial' | 'conic';
  startX: number;
  startY: number;
  endX: number;
  endY: number;
  stops: GradientStop[];
}

export type PatternType = 'hex' | 'grid' | 'radial' | 'dots' | 'diagonal' | 'circuit' | 'houndstooth';

export interface AardPattern {
  id: string;
  name: string;
  type: PatternType;
  width: number;
  height: number;
  fgColor: string;
  bgColor: string;
  scale: number;
}

export type StrokeCap = 'butt' | 'round' | 'square';
export type StrokeJoin = 'miter' | 'round' | 'bevel';
export type StrokeAlign = 'center' | 'inside' | 'outside';

export interface VariableStrokeProfile {
  name: string;
  widths: { t: number; width: number }[]; // t from 0 to 1
}

export interface AardStyle {
  fillType: FillType;
  fillColor: string;
  fillOpacity: number;
  gradientId?: string;
  gradient?: AardGradient;
  patternId?: string;
  pattern?: AardPattern;

  strokeColor: string;
  strokeWidth: number;
  strokeOpacity: number;
  strokeCap: StrokeCap;
  strokeJoin: StrokeJoin;
  strokeMiterLimit: number;
  strokeDashArray: number[];
  strokeDashOffset: number;
  strokeAlign: StrokeAlign;
  variableStroke?: VariableStrokeProfile;

  blendMode: 'normal' | 'multiply' | 'screen' | 'overlay' | 'darken' | 'lighten' | 'color-dodge' | 'color-burn' | 'difference' | 'exclusion';
  dropShadow?: {
    enabled: boolean;
    x: number;
    y: number;
    blur: number;
    color: string;
    opacity: number;
  };
  blur?: number;
}

export type ObjectType = 
  | 'rect'
  | 'ellipse'
  | 'star'
  | 'gear'
  | 'spiral'
  | 'wave'
  | 'polygon'
  | 'arrow'
  | 'path'
  | 'text'
  | 'connector'
  | 'dimension'
  | 'image'
  | 'group'
  | 'procedural'
  | 'data_viz';

export interface StarParams {
  points: number;
  innerRadius: number;
  outerRadius: number;
  roundness: number;
}

export interface GearParams {
  teeth: number;
  innerRadius: number;
  outerRadius: number;
  toothDepth: number;
  holeRadius: number;
  pressureAngle: number;
}

export interface SpiralParams {
  turns: number;
  decay: number;
  innerRadius: number;
  outerRadius: number;
  type: 'archimedean' | 'logarithmic' | 'golden';
}

export interface WaveParams {
  frequency: number;
  amplitude: number;
  phase: number;
  type: 'sine' | 'square' | 'triangle' | 'sawtooth';
  harmonics: number;
}

export interface PolygonParams {
  sides: number;
  radius: number;
  cornerRadius: number;
}

export interface ArrowParams {
  headLength: number;
  headWidth: number;
  shaftWidth: number;
  doubleHeaded: boolean;
}

export interface ConnectorParams {
  startObjId?: string;
  endObjId?: string;
  startPoint: { x: number; y: number };
  endPoint: { x: number; y: number };
  routing: 'straight' | 'orthogonal' | 'curved';
  startArrow: boolean;
  endArrow: boolean;
  arrowSize: number;
}

export interface DimensionParams {
  p1: { x: number; y: number };
  p2: { x: number; y: number };
  offset: number;
  unit: UnitType;
  customLabel?: string;
  showTicks: boolean;
  arrowStyle: 'filled' | 'open' | 'tick';
}

export interface TypographyParams {
  text: string;
  fontFamily: string;
  fontSize: number;
  fontWeight: number | string;
  fontStyle: 'normal' | 'italic';
  letterSpacing: number; // tracking in em or px
  lineHeight: number; // leading
  textAlign: 'left' | 'center' | 'right' | 'justify';
  textOnPathObjId?: string;
  pathOffset?: number;
  isAreaText?: boolean;
}

export interface ProceduralParams {
  generatorType: 'voronoi' | 'delaunay' | 'l_system' | 'superformula' | 'circle_pack' | 'lissajous' | 'flow_field';
  seed: number;
  iterations: number;
  complexity: number;
  params: Record<string, number | string | boolean>;
}

export interface DataVizParams {
  chartType: 'scatter' | 'bar' | 'line' | 'radar' | 'bubble';
  data: Array<Record<string, number | string>>;
  xKey: string;
  yKey: string;
  sizeKey?: string;
  colorKey?: string;
  showAxes: boolean;
  showGrid: boolean;
  showLegend: boolean;
}

export interface AardObject {
  id: string;
  name: string;
  type: ObjectType;
  artboardId: string;
  layerId: string;
  parentGroupId?: string;
  
  // Transform
  x: number;
  y: number;
  width: number;
  height: number;
  rotation: number; // degrees
  scaleX: number;
  scaleY: number;
  skewX: number;
  skewY: number;
  pivotX: number; // 0 to 1, default 0.5
  pivotY: number; // 0 to 1, default 0.5

  // Common properties
  opacity: number;
  visible: boolean;
  locked: boolean;
  zIndex: number;
  style: AardStyle;

  // Geometry / Specific payload
  path?: AardPath;
  cornerRadius?: number;
  starParams?: StarParams;
  gearParams?: GearParams;
  spiralParams?: SpiralParams;
  waveParams?: WaveParams;
  polygonParams?: PolygonParams;
  arrowParams?: ArrowParams;
  connectorParams?: ConnectorParams;
  dimensionParams?: DimensionParams;
  typography?: TypographyParams;
  procedural?: ProceduralParams;
  dataViz?: DataVizParams;
  imageUrl?: string;
  groupChildrenIds?: string[];

  // R & Metadata
  rSourceCode?: string;
  rGenerated?: boolean;
  tags?: string[];
  metadata?: Record<string, any>;
}

export interface AardLayer {
  id: string;
  name: string;
  visible: boolean;
  locked: boolean;
  color: string;
  opacity: number;
  expanded?: boolean;
}

export interface AardArtboard {
  id: string;
  name: string;
  x: number;
  y: number;
  width: number;
  height: number;
  bleed: number;
  margin: number;
  background: string;
  preset?: string;
}

export interface GridConfig {
  enabled: boolean;
  type: 'cartesian' | 'isometric' | 'polar' | 'technical';
  size: number;
  subdivisions: number;
  snap: boolean;
  color: string;
  opacity: number;
  isoAngle?: number;
}

export interface GuideLine {
  id: string;
  orientation: 'horizontal' | 'vertical';
  position: number;
  color: string;
  locked: boolean;
}

export interface AardDocument {
  id: string;
  name: string;
  version: string;
  createdAt: string;
  updatedAt: string;
  units: UnitType;
  dpi: number;
  artboards: AardArtboard[];
  activeArtboardId: string;
  layers: AardLayer[];
  activeLayerId: string;
  objects: AardObject[];
  gradients: AardGradient[];
  patterns: AardPattern[];
  colorPalette: string[];
  grid: GridConfig;
  guides: GuideLine[];
  rScriptSource: string;
  reproducibilitySeed: number;
  metadata: {
    author: string;
    description: string;
    version: string;
    rDependencies: string[];
  };
}

export interface HistoryEntry {
  id: string;
  title: string;
  timestamp: number;
  document: AardDocument;
}
