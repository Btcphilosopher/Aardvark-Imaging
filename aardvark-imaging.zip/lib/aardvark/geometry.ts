import { AardNode, AardObject, AardPath, PathSegment, StarParams, GearParams, SpiralParams, WaveParams, PolygonParams, ArrowParams } from './types';

export interface Point2D {
  x: number;
  y: number;
}

export interface BoundingBox {
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
  width: number;
  height: number;
  centerX: number;
  centerY: number;
}

// -------------------------------------------------------------
// BÉZIER CALCULATIONS
// -------------------------------------------------------------

export function evaluateCubicBezier(p0: Point2D, p1: Point2D, p2: Point2D, p3: Point2D, t: number): Point2D {
  const mt = 1 - t;
  const mt2 = mt * mt;
  const mt3 = mt2 * mt;
  const t2 = t * t;
  const t3 = t2 * t;

  return {
    x: mt3 * p0.x + 3 * mt2 * t * p1.x + 3 * mt * t2 * p2.x + t3 * p3.x,
    y: mt3 * p0.y + 3 * mt2 * t * p1.y + 3 * mt * t2 * p2.y + t3 * p3.y,
  };
}

export function evaluateCubicDerivative(p0: Point2D, p1: Point2D, p2: Point2D, p3: Point2D, t: number): Point2D {
  const mt = 1 - t;
  const mt2 = mt * mt;
  const t2 = t * t;

  return {
    x: 3 * mt2 * (p1.x - p0.x) + 6 * mt * t * (p2.x - p1.x) + 3 * t2 * (p3.x - p2.x),
    y: 3 * mt2 * (p1.y - p0.y) + 6 * mt * t * (p2.y - p1.y) + 3 * t2 * (p3.y - p2.y),
  };
}

export function evaluateCubicTangent(p0: Point2D, p1: Point2D, p2: Point2D, p3: Point2D, t: number): Point2D {
  const d = evaluateCubicDerivative(p0, p1, p2, p3, t);
  const len = Math.hypot(d.x, d.y) || 1e-6;
  return { x: d.x / len, y: d.y / len };
}

export function evaluateCubicNormal(p0: Point2D, p1: Point2D, p2: Point2D, p3: Point2D, t: number): Point2D {
  const tan = evaluateCubicTangent(p0, p1, p2, p3, t);
  return { x: -tan.y, y: tan.x };
}

export function approximateCubicLength(p0: Point2D, p1: Point2D, p2: Point2D, p3: Point2D, steps: number = 24): number {
  let length = 0;
  let prev = p0;
  for (let i = 1; i <= steps; i++) {
    const t = i / steps;
    const curr = evaluateCubicBezier(p0, p1, p2, p3, t);
    length += Math.hypot(curr.x - prev.x, curr.y - prev.y);
    prev = curr;
  }
  return length;
}

export function splitCubicBezier(p0: Point2D, p1: Point2D, p2: Point2D, p3: Point2D, t: number): [Point2D[], Point2D[]] {
  // de Casteljau's algorithm
  const p01 = { x: p0.x + (p1.x - p0.x) * t, y: p0.y + (p1.y - p0.y) * t };
  const p12 = { x: p1.x + (p2.x - p1.x) * t, y: p1.y + (p2.y - p1.y) * t };
  const p23 = { x: p2.x + (p3.x - p2.x) * t, y: p2.y + (p3.y - p2.y) * t };

  const p012 = { x: p01.x + (p12.x - p01.x) * t, y: p01.y + (p12.y - p01.y) * t };
  const p123 = { x: p12.x + (p23.x - p12.x) * t, y: p12.y + (p23.y - p12.y) * t };

  const p0123 = { x: p012.x + (p123.x - p012.x) * t, y: p012.y + (p123.y - p012.y) * t };

  return [
    [p0, p01, p012, p0123],
    [p0123, p123, p23, p3],
  ];
}

export function pointAtCubicDistance(p0: Point2D, p1: Point2D, p2: Point2D, p3: Point2D, targetDistance: number): Point2D {
  const total = approximateCubicLength(p0, p1, p2, p3, 32);
  if (total <= 0 || targetDistance <= 0) return p0;
  if (targetDistance >= total) return p3;

  let low = 0;
  let high = 1;
  for (let i = 0; i < 16; i++) {
    const mid = (low + high) / 2;
    const len = approximateCubicLength(p0, p1, p2, p3, 16) * mid; // approximate
    if (len < targetDistance) low = mid;
    else high = mid;
  }
  return evaluateCubicBezier(p0, p1, p2, p3, (low + high) / 2);
}

// -------------------------------------------------------------
// PATH GENERATION & SVG PATH STRINGS
// -------------------------------------------------------------

export function nodesToPathString(nodes: AardNode[], closed: boolean = false): string {
  if (!nodes || nodes.length === 0) return '';
  if (nodes.length === 1) return `M ${nodes[0].x} ${nodes[0].y}`;

  let d = `M ${nodes[0].x} ${nodes[0].y}`;

  for (let i = 1; i < nodes.length; i++) {
    const prev = nodes[i - 1];
    const curr = nodes[i];

    const cp1 = prev.handleOut ? { x: prev.x + prev.handleOut.x, y: prev.y + prev.handleOut.y } : { x: prev.x, y: prev.y };
    const cp2 = curr.handleIn ? { x: curr.x + curr.handleIn.x, y: curr.y + curr.handleIn.y } : { x: curr.x, y: curr.y };

    if (!prev.handleOut && !curr.handleIn) {
      d += ` L ${curr.x} ${curr.y}`;
    } else {
      d += ` C ${cp1.x} ${cp1.y} ${cp2.x} ${cp2.y} ${curr.x} ${curr.y}`;
    }
  }

  if (closed && nodes.length > 2) {
    const prev = nodes[nodes.length - 1];
    const curr = nodes[0];
    const cp1 = prev.handleOut ? { x: prev.x + prev.handleOut.x, y: prev.y + prev.handleOut.y } : { x: prev.x, y: prev.y };
    const cp2 = curr.handleIn ? { x: curr.x + curr.handleIn.x, y: curr.y + curr.handleIn.y } : { x: curr.x, y: curr.y };

    if (!prev.handleOut && !curr.handleIn) {
      d += ` Z`;
    } else {
      d += ` C ${cp1.x} ${cp1.y} ${cp2.x} ${cp2.y} ${curr.x} ${curr.y} Z`;
    }
  }

  return d;
}

export function pathToSvgString(path: AardPath): string {
  if (path.nodes && path.nodes.length > 0) {
    return nodesToPathString(path.nodes, path.closed);
  }
  if (!path.segments || path.segments.length === 0) return '';
  return path.segments
    .map(seg => {
      switch (seg.type) {
        case 'M': return `M ${seg.values.join(' ')}`;
        case 'L': return `L ${seg.values.join(' ')}`;
        case 'C': return `C ${seg.values.join(' ')}`;
        case 'Q': return `Q ${seg.values.join(' ')}`;
        case 'A': return `A ${seg.values.join(' ')}`;
        case 'Z': return 'Z';
        default: return '';
      }
    })
    .join(' ');
}

// -------------------------------------------------------------
// PARAMETRIC SHAPES GENERATORS
// -------------------------------------------------------------

export function generateStarNodes(params: StarParams, cx: number, cy: number): AardNode[] {
  const { points = 5, innerRadius = 30, outerRadius = 70 } = params;
  const nodes: AardNode[] = [];
  const totalPoints = points * 2;
  const angleStep = (Math.PI * 2) / totalPoints;

  for (let i = 0; i < totalPoints; i++) {
    const angle = i * angleStep - Math.PI / 2;
    const r = i % 2 === 0 ? outerRadius : innerRadius;
    const x = cx + Math.cos(angle) * r;
    const y = cy + Math.sin(angle) * r;
    nodes.push({
      id: `star_node_${i}`,
      x,
      y,
      type: 'corner',
    });
  }
  return nodes;
}

export function generateGearNodes(params: GearParams, cx: number, cy: number): AardNode[] {
  const { teeth = 12, innerRadius = 40, outerRadius = 60, toothDepth = 15 } = params;
  const nodes: AardNode[] = [];
  const numSteps = teeth * 4;
  const angleStep = (Math.PI * 2) / numSteps;

  const rRoot = outerRadius - toothDepth;
  const rTip = outerRadius;

  for (let i = 0; i < numSteps; i++) {
    const angle = i * angleStep;
    const phase = i % 4;
    let r = rRoot;
    if (phase === 1 || phase === 2) {
      r = rTip;
    }
    const x = cx + Math.cos(angle) * r;
    const y = cy + Math.sin(angle) * r;
    nodes.push({
      id: `gear_node_${i}`,
      x,
      y,
      type: 'corner',
    });
  }
  return nodes;
}

export function generateSpiralNodes(params: SpiralParams, cx: number, cy: number): AardNode[] {
  const { turns = 3.5, outerRadius = 80, type = 'archimedean' } = params;
  const nodes: AardNode[] = [];
  const steps = Math.floor(turns * 32);
  const totalAngle = turns * Math.PI * 2;

  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const angle = t * totalAngle;
    let r = 0;
    if (type === 'golden') {
      const phi = 1.6180339887;
      r = Math.pow(phi, (angle / (Math.PI * 2)) * 1.5) * (outerRadius / 15);
    } else if (type === 'logarithmic') {
      r = outerRadius * Math.exp(0.3 * (angle - totalAngle));
    } else {
      // Archimedean
      r = t * outerRadius;
    }

    const x = cx + Math.cos(angle) * r;
    const y = cy + Math.sin(angle) * r;
    nodes.push({
      id: `spiral_node_${i}`,
      x,
      y,
      type: 'smooth',
    });
  }
  return nodes;
}

export function generateWaveNodes(params: WaveParams, x: number, y: number, width: number, height: number): AardNode[] {
  const { frequency = 3, amplitude = 30, phase = 0, type = 'sine' } = params;
  const nodes: AardNode[] = [];
  const steps = 64;
  const cy = y + height / 2;

  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const px = x + t * width;
    const angle = t * frequency * Math.PI * 2 + (phase * Math.PI) / 180;
    let py = cy;

    if (type === 'square') {
      py = cy + (Math.sin(angle) >= 0 ? amplitude : -amplitude);
    } else if (type === 'triangle') {
      py = cy + amplitude * (2 / Math.PI) * Math.asin(Math.sin(angle));
    } else if (type === 'sawtooth') {
      py = cy + amplitude * (2 * (t * frequency - Math.floor(t * frequency + 0.5)));
    } else {
      py = cy + amplitude * Math.sin(angle);
    }

    nodes.push({
      id: `wave_node_${i}`,
      x: px,
      y: py,
      type: 'smooth',
    });
  }
  return nodes;
}

export function generatePolygonNodes(params: PolygonParams, cx: number, cy: number): AardNode[] {
  const { sides = 6, radius = 50 } = params;
  const nodes: AardNode[] = [];
  const angleStep = (Math.PI * 2) / sides;

  for (let i = 0; i < sides; i++) {
    const angle = i * angleStep - Math.PI / 2;
    const x = cx + Math.cos(angle) * radius;
    const y = cy + Math.sin(angle) * radius;
    nodes.push({
      id: `poly_node_${i}`,
      x,
      y,
      type: 'corner',
    });
  }
  return nodes;
}

export function generateArrowNodes(params: ArrowParams, x: number, y: number, width: number, height: number): AardNode[] {
  const { headLength = 30, headWidth = 40, shaftWidth = 16, doubleHeaded = false } = params;
  const cy = y + height / 2;
  const halfShaft = shaftWidth / 2;
  const halfHead = headWidth / 2;
  const startX = x;
  const endX = x + width;

  const nodes: AardNode[] = [];

  if (doubleHeaded) {
    nodes.push({ id: 'a0', x: startX, y: cy, type: 'corner' });
    nodes.push({ id: 'a1', x: startX + headLength, y: cy - halfHead, type: 'corner' });
    nodes.push({ id: 'a2', x: startX + headLength, y: cy - halfShaft, type: 'corner' });
    nodes.push({ id: 'a3', x: endX - headLength, y: cy - halfShaft, type: 'corner' });
    nodes.push({ id: 'a4', x: endX - headLength, y: cy - halfHead, type: 'corner' });
    nodes.push({ id: 'a5', x: endX, y: cy, type: 'corner' });
    nodes.push({ id: 'a6', x: endX - headLength, y: cy + halfHead, type: 'corner' });
    nodes.push({ id: 'a7', x: endX - headLength, y: cy + halfShaft, type: 'corner' });
    nodes.push({ id: 'a8', x: startX + headLength, y: cy + halfShaft, type: 'corner' });
    nodes.push({ id: 'a9', x: startX + headLength, y: cy + halfHead, type: 'corner' });
  } else {
    nodes.push({ id: 'a0', x: startX, y: cy - halfShaft, type: 'corner' });
    nodes.push({ id: 'a1', x: endX - headLength, y: cy - halfShaft, type: 'corner' });
    nodes.push({ id: 'a2', x: endX - headLength, y: cy - halfHead, type: 'corner' });
    nodes.push({ id: 'a3', x: endX, y: cy, type: 'corner' });
    nodes.push({ id: 'a4', x: endX - headLength, y: cy + halfHead, type: 'corner' });
    nodes.push({ id: 'a5', x: endX - headLength, y: cy + halfShaft, type: 'corner' });
    nodes.push({ id: 'a6', x: startX, y: cy + halfShaft, type: 'corner' });
  }
  return nodes;
}

// -------------------------------------------------------------
// OBJECT TO PATH CONVERTER
// -------------------------------------------------------------

export function objectToPath(obj: AardObject): AardPath {
  if (obj.path) return obj.path;

  const { x, y, width, height } = obj;
  const cx = x + width / 2;
  const cy = y + height / 2;

  switch (obj.type) {
    case 'rect': {
      const r = obj.cornerRadius || 0;
      if (r <= 0) {
        return {
          closed: true,
          segments: [],
          nodes: [
            { id: 'n0', x, y, type: 'corner' },
            { id: 'n1', x: x + width, y, type: 'corner' },
            { id: 'n2', x: x + width, y: y + height, type: 'corner' },
            { id: 'n3', x, y: y + height, type: 'corner' },
          ],
        };
      }
      // Rounded rect nodes with Bézier handles
      const k = 0.5522847498; // bezier circle constant
      const kr = r * (1 - k);
      return {
        closed: true,
        segments: [],
        nodes: [
          { id: 'n0', x: x + r, y, type: 'smooth', handleIn: { x: -r * k, y: 0 } },
          { id: 'n1', x: x + width - r, y, type: 'smooth', handleOut: { x: r * k, y: 0 } },
          { id: 'n2', x: x + width, y: y + r, type: 'smooth', handleIn: { x: 0, y: -r * k } },
          { id: 'n3', x: x + width, y: y + height - r, type: 'smooth', handleOut: { x: 0, y: r * k } },
          { id: 'n4', x: x + width - r, y: y + height, type: 'smooth', handleIn: { x: r * k, y: 0 } },
          { id: 'n5', x: x + r, y: y + height, type: 'smooth', handleOut: { x: -r * k, y: 0 } },
          { id: 'n6', x, y: y + height - r, type: 'smooth', handleIn: { x: 0, y: r * k } },
          { id: 'n7', x, y: y + r, type: 'smooth', handleOut: { x: 0, y: -r * k } },
        ],
      };
    }

    case 'ellipse': {
      const rx = width / 2;
      const ry = height / 2;
      const kx = rx * 0.5522847498;
      const ky = ry * 0.5522847498;

      return {
        closed: true,
        segments: [],
        nodes: [
          { id: 'e0', x: cx, y: cy - ry, type: 'symmetric', handleIn: { x: -kx, y: 0 }, handleOut: { x: kx, y: 0 } },
          { id: 'e1', x: cx + rx, y: cy, type: 'symmetric', handleIn: { x: 0, y: -ky }, handleOut: { x: 0, y: ky } },
          { id: 'e2', x: cx, y: cy + ry, type: 'symmetric', handleIn: { x: kx, y: 0 }, handleOut: { x: -kx, y: 0 } },
          { id: 'e3', x: cx - rx, y: cy, type: 'symmetric', handleIn: { x: 0, y: ky }, handleOut: { x: 0, y: -ky } },
        ],
      };
    }

    case 'star': {
      const nodes = generateStarNodes(obj.starParams || { points: 5, innerRadius: width * 0.25, outerRadius: width * 0.5, roundness: 0 }, cx, cy);
      return { closed: true, segments: [], nodes };
    }

    case 'gear': {
      const nodes = generateGearNodes(obj.gearParams || { teeth: 10, innerRadius: width * 0.3, outerRadius: width * 0.5, toothDepth: width * 0.1, holeRadius: width * 0.15, pressureAngle: 20 }, cx, cy);
      return { closed: true, segments: [], nodes };
    }

    case 'spiral': {
      const nodes = generateSpiralNodes(obj.spiralParams || { turns: 3, outerRadius: width * 0.5, decay: 0.1, innerRadius: 0, type: 'archimedean' }, cx, cy);
      return { closed: false, segments: [], nodes };
    }

    case 'wave': {
      const nodes = generateWaveNodes(obj.waveParams || { frequency: 3, amplitude: height * 0.4, phase: 0, type: 'sine', harmonics: 1 }, x, y, width, height);
      return { closed: false, segments: [], nodes };
    }

    case 'polygon': {
      const nodes = generatePolygonNodes(obj.polygonParams || { sides: 6, radius: width / 2, cornerRadius: 0 }, cx, cy);
      return { closed: true, segments: [], nodes };
    }

    case 'arrow': {
      const nodes = generateArrowNodes(obj.arrowParams || { headLength: width * 0.3, headWidth: height, shaftWidth: height * 0.4, doubleHeaded: false }, x, y, width, height);
      return { closed: true, segments: [], nodes };
    }

    default:
      return {
        closed: true,
        segments: [],
        nodes: [
          { id: 'd0', x, y, type: 'corner' },
          { id: 'd1', x: x + width, y, type: 'corner' },
          { id: 'd2', x: x + width, y: y + height, type: 'corner' },
          { id: 'd3', x, y: y + height, type: 'corner' },
        ],
      };
  }
}

// -------------------------------------------------------------
// VECTOR BOOLEAN OPERATIONS ENGINE
// -------------------------------------------------------------

function getPolygonVertices(obj: AardObject): Point2D[] {
  const path = objectToPath(obj);
  if (!path.nodes || path.nodes.length === 0) return [];
  
  // Sample curves if nodes have handles
  const pts: Point2D[] = [];
  for (let i = 0; i < path.nodes.length; i++) {
    const curr = path.nodes[i];
    const next = path.nodes[(i + 1) % path.nodes.length];
    
    if (curr.handleOut || next.handleIn) {
      const p0 = { x: curr.x, y: curr.y };
      const p1 = curr.handleOut ? { x: curr.x + curr.handleOut.x, y: curr.y + curr.handleOut.y } : p0;
      const p3 = { x: next.x, y: next.y };
      const p2 = next.handleIn ? { x: next.x + next.handleIn.x, y: next.y + next.handleIn.y } : p3;

      for (let step = 0; step < 8; step++) {
        pts.push(evaluateCubicBezier(p0, p1, p2, p3, step / 8));
      }
    } else {
      pts.push({ x: curr.x, y: curr.y });
    }
  }
  return pts;
}

export function isPointInsidePolygon(point: Point2D, polygon: Point2D[]): boolean {
  let inside = false;
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const xi = polygon[i].x, yi = polygon[i].y;
    const xj = polygon[j].x, yj = polygon[j].y;
    const intersect = ((yi > point.y) !== (yj > point.y)) &&
      (point.x < (xj - xi) * (point.y - yi) / (yj - yi) + xi);
    if (intersect) inside = !inside;
  }
  return inside;
}

export function performBooleanOperation(
  obj1: AardObject,
  obj2: AardObject,
  operation: 'union' | 'subtract' | 'intersect' | 'exclude'
): AardNode[] {
  const polyA = getPolygonVertices(obj1);
  const polyB = getPolygonVertices(obj2);

  if (polyA.length < 3 || polyB.length < 3) {
    return polyA.map((p, i) => ({ id: `bool_${i}`, x: p.x, y: p.y, type: 'corner' }));
  }

  const resultPts: Point2D[] = [];

  if (operation === 'union') {
    // Points of A outside B + Points of B outside A + Intersections
    for (const p of polyA) {
      if (!isPointInsidePolygon(p, polyB)) resultPts.push(p);
    }
    for (const p of polyB) {
      if (!isPointInsidePolygon(p, polyA)) resultPts.push(p);
    }
  } else if (operation === 'subtract') {
    // Points of A outside B + inverted B
    for (const p of polyA) {
      if (!isPointInsidePolygon(p, polyB)) resultPts.push(p);
    }
  } else if (operation === 'intersect') {
    // Points of A inside B + Points of B inside A
    for (const p of polyA) {
      if (isPointInsidePolygon(p, polyB)) resultPts.push(p);
    }
    for (const p of polyB) {
      if (isPointInsidePolygon(p, polyA)) resultPts.push(p);
    }
  } else {
    // Exclude
    for (const p of polyA) {
      if (!isPointInsidePolygon(p, polyB)) resultPts.push(p);
    }
    for (const p of polyB) {
      if (!isPointInsidePolygon(p, polyA)) resultPts.push(p);
    }
  }

  // Fallback to bounding hull if point set too sparse
  if (resultPts.length < 3) {
    return polyA.map((p, i) => ({ id: `bool_fallback_${i}`, x: p.x, y: p.y, type: 'corner' }));
  }

  // Sort angularly around centroid to form valid polygon ring
  const cx = resultPts.reduce((acc, p) => acc + p.x, 0) / resultPts.length;
  const cy = resultPts.reduce((acc, p) => acc + p.y, 0) / resultPts.length;

  resultPts.sort((a, b) => {
    return Math.atan2(a.y - cy, a.x - cx) - Math.atan2(b.y - cy, b.x - cx);
  });

  return resultPts.map((p, i) => ({
    id: `bool_res_${i}`,
    x: Math.round(p.x * 100) / 100,
    y: Math.round(p.y * 100) / 100,
    type: 'corner',
  }));
}

// -------------------------------------------------------------
// BOUNDING BOX & MEASUREMENTS
// -------------------------------------------------------------

export function calculateObjectBounds(obj: AardObject): BoundingBox {
  const path = objectToPath(obj);
  if (!path.nodes || path.nodes.length === 0) {
    return {
      minX: obj.x,
      minY: obj.y,
      maxX: obj.x + obj.width,
      maxY: obj.y + obj.height,
      width: obj.width,
      height: obj.height,
      centerX: obj.x + obj.width / 2,
      centerY: obj.y + obj.height / 2,
    };
  }

  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;

  for (const node of path.nodes) {
    minX = Math.min(minX, node.x);
    minY = Math.min(minY, node.y);
    maxX = Math.max(maxX, node.x);
    maxY = Math.max(maxY, node.y);

    if (node.handleIn) {
      minX = Math.min(minX, node.x + node.handleIn.x);
      minY = Math.min(minY, node.y + node.handleIn.y);
      maxX = Math.max(maxX, node.x + node.handleIn.x);
      maxY = Math.max(maxY, node.y + node.handleIn.y);
    }
    if (node.handleOut) {
      minX = Math.min(minX, node.x + node.handleOut.x);
      minY = Math.min(minY, node.y + node.handleOut.y);
      maxX = Math.max(maxX, node.x + node.handleOut.x);
      maxY = Math.max(maxY, node.y + node.handleOut.y);
    }
  }

  const width = Math.max(1, maxX - minX);
  const height = Math.max(1, maxY - minY);

  return {
    minX,
    minY,
    maxX,
    maxY,
    width,
    height,
    centerX: minX + width / 2,
    centerY: minY + height / 2,
  };
}

export function calculatePolygonArea(points: Point2D[]): number {
  let area = 0;
  for (let i = 0; i < points.length; i++) {
    const j = (i + 1) % points.length;
    area += points[i].x * points[j].y;
    area -= points[j].x * points[i].y;
  }
  return Math.abs(area) / 2;
}

export function calculatePathLength(path: AardPath): number {
  if (!path.nodes || path.nodes.length < 2) return 0;
  let total = 0;
  for (let i = 0; i < path.nodes.length - 1; i++) {
    const curr = path.nodes[i];
    const next = path.nodes[i + 1];
    if (curr.handleOut || next.handleIn) {
      const p0 = { x: curr.x, y: curr.y };
      const p1 = curr.handleOut ? { x: curr.x + curr.handleOut.x, y: curr.y + curr.handleOut.y } : p0;
      const p3 = { x: next.x, y: next.y };
      const p2 = next.handleIn ? { x: next.x + next.handleIn.x, y: next.y + next.handleIn.y } : p3;
      total += approximateCubicLength(p0, p1, p2, p3);
    } else {
      total += Math.hypot(next.x - curr.x, next.y - curr.y);
    }
  }
  if (path.closed && path.nodes.length > 2) {
    const curr = path.nodes[path.nodes.length - 1];
    const next = path.nodes[0];
    total += Math.hypot(next.x - curr.x, next.y - curr.y);
  }
  return total;
}
