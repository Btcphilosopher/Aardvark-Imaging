import { AardDocument, AardObject, AardStyle, AardNode, ObjectType, StarParams, GearParams, SpiralParams, WaveParams, PolygonParams } from './types';
import { nodesToPathString } from './geometry';
import { generateVoronoiTessellation, generateLSystemPath, generateSuperformulaNodes, generatePhyllotaxisPacking } from './procedural';

export interface RExecutionResult {
  success: boolean;
  output: string;
  generatedDocument?: AardDocument;
  createdObjects?: AardObject[];
  exportSvgData?: string;
  exportPdfData?: string;
  error?: string;
}

export interface RVariable {
  name: string;
  type: string;
  value: any;
}

// -------------------------------------------------------------
// R CODE PARSER & EVALUATOR FOR AARDVARK VECTOR ENGINE
// -------------------------------------------------------------

export class AardvarkREngine {
  private variables: Map<string, any> = new Map();
  private commandHistory: string[] = [];

  constructor() {
    this.resetEnvironment();
  }

  resetEnvironment() {
    this.variables.clear();
    this.variables.set('PI', Math.PI);
    this.variables.set('PHI', 1.6180339887);
    this.variables.set('DEG2RAD', Math.PI / 180);
  }

  // -----------------------------------------------------------
  // VISUAL TO R CODE GENERATOR
  // -----------------------------------------------------------
  generateRCodeFromDocument(doc: AardDocument): string {
    const lines: string[] = [
      `# ------------------------------------------------------------`,
      `# AARDVARK IMAGING — Reproducible Computational Vector Script`,
      `# Document: ${doc.name}`,
      `# Generated: ${new Date().toISOString()}`,
      `# Reproducibility Seed: ${doc.reproducibilitySeed}`,
      `# ------------------------------------------------------------`,
      `library(aardvark)`,
      ``,
      `# 1. Initialize Document`,
      `set.seed(${doc.reproducibilitySeed})`,
      `doc <- aard_new_document("${doc.name}", units = "${doc.units}", dpi = ${doc.dpi})`,
      ``,
      `# 2. Setup Artboards`,
    ];

    doc.artboards.forEach((ab, idx) => {
      lines.push(
        `ab_${idx + 1} <- aard_artboard(doc, name = "${ab.name}", x = ${ab.x}, y = ${ab.y}, width = ${ab.width}, height = ${ab.height}, background = "${ab.background}")`
      );
    });

    lines.push(``, `# 3. Setup Layers`);
    doc.layers.forEach((layer, idx) => {
      lines.push(
        `layer_${idx + 1} <- aard_layer(doc, name = "${layer.name}", color = "${layer.color}", visible = ${layer.visible ? 'TRUE' : 'FALSE'})`
      );
    });

    lines.push(``, `# 4. Vector Geometry Objects`);

    doc.objects.forEach((obj, idx) => {
      lines.push(this.generateRCodeForObject(obj, idx + 1));
    });

    lines.push(``, `# 5. Render & Export Pipeline`, `aard_render(doc, backend = "interactive")`, `# aard_export(doc, file = "${doc.name.toLowerCase().replace(/\s+/g, '_')}.svg", format = "svg")`);

    return lines.join('\n');
  }

  generateRCodeForObject(obj: AardObject, index: number): string {
    const varName = `obj_${index}_${obj.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}`;
    const fill = obj.style.fillType === 'none' ? '"none"' : `"${obj.style.fillColor}"`;
    const stroke = `"${obj.style.strokeColor}"`;
    const sw = obj.style.strokeWidth;
    const rot = obj.rotation;

    switch (obj.type) {
      case 'rect':
        return `${varName} <- aard_rect(doc, x = ${obj.x}, y = ${obj.y}, width = ${obj.width}, height = ${obj.height}, corner_radius = ${obj.cornerRadius || 0}, fill = ${fill}, stroke = ${stroke}, stroke_width = ${sw}, rotation = ${rot})`;

      case 'ellipse':
        return `${varName} <- aard_ellipse(doc, cx = ${obj.x + obj.width / 2}, cy = ${obj.y + obj.height / 2}, rx = ${obj.width / 2}, ry = ${obj.height / 2}, fill = ${fill}, stroke = ${stroke}, stroke_width = ${sw}, rotation = ${rot})`;

      case 'star': {
        const p = obj.starParams || { points: 5, innerRadius: 25, outerRadius: 50, roundness: 0 };
        return `${varName} <- aard_star(doc, cx = ${obj.x + obj.width / 2}, cy = ${obj.y + obj.height / 2}, points = ${p.points}, inner_r = ${p.innerRadius}, outer_r = ${p.outerRadius}, fill = ${fill}, stroke = ${stroke}, stroke_width = ${sw})`;
      }

      case 'gear': {
        const p = obj.gearParams || { teeth: 10, innerRadius: 30, outerRadius: 50, toothDepth: 12, holeRadius: 15, pressureAngle: 20 };
        return `${varName} <- aard_gear(doc, cx = ${obj.x + obj.width / 2}, cy = ${obj.y + obj.height / 2}, teeth = ${p.teeth}, inner_r = ${p.innerRadius}, outer_r = ${p.outerRadius}, tooth_depth = ${p.toothDepth}, fill = ${fill}, stroke = ${stroke})`;
      }

      case 'spiral': {
        const p = obj.spiralParams || { turns: 3, outerRadius: 60, decay: 0.1, innerRadius: 0, type: 'archimedean' };
        return `${varName} <- aard_spiral(doc, cx = ${obj.x + obj.width / 2}, cy = ${obj.y + obj.height / 2}, turns = ${p.turns}, outer_r = ${p.outerRadius}, type = "${p.type}", stroke = ${stroke}, stroke_width = ${sw})`;
      }

      case 'wave': {
        const p = obj.waveParams || { frequency: 3, amplitude: 30, phase: 0, type: 'sine', harmonics: 1 };
        return `${varName} <- aard_wave(doc, x = ${obj.x}, y = ${obj.y}, width = ${obj.width}, frequency = ${p.frequency}, amplitude = ${p.amplitude}, type = "${p.type}", stroke = ${stroke}, stroke_width = ${sw})`;
      }

      case 'polygon': {
        const p = obj.polygonParams || { sides: 6, radius: 40, cornerRadius: 0 };
        return `${varName} <- aard_polygon(doc, cx = ${obj.x + obj.width / 2}, cy = ${obj.y + obj.height / 2}, sides = ${p.sides}, radius = ${p.radius}, fill = ${fill}, stroke = ${stroke}, stroke_width = ${sw})`;
      }

      case 'text': {
        const t = obj.typography || { text: 'Typography', fontFamily: 'Inter', fontSize: 24, fontWeight: 500 };
        return `${varName} <- aard_text(doc, text = "${t.text.replace(/"/g, '\\"')}", x = ${obj.x}, y = ${obj.y}, font_size = ${t.fontSize}, font_family = "${t.fontFamily}", fill = ${fill})`;
      }

      case 'path': {
        const d = obj.path?.nodes ? nodesToPathString(obj.path.nodes, obj.path.closed) : '';
        return `${varName} <- aard_path(doc, d = "${d}", fill = ${fill}, stroke = ${stroke}, stroke_width = ${sw})`;
      }

      case 'procedural': {
        const p = obj.procedural || { generatorType: 'voronoi', seed: 42, iterations: 4, complexity: 12, params: {} };
        return `${varName} <- aard_procedural(doc, generator = "${p.generatorType}", seed = ${p.seed}, complexity = ${p.complexity}, x = ${obj.x}, y = ${obj.y}, width = ${obj.width}, height = ${obj.height})`;
      }

      case 'data_viz': {
        const dv = obj.dataViz || { chartType: 'scatter', data: [], xKey: 'x', yKey: 'y', showAxes: true, showGrid: true, showLegend: true };
        return `${varName} <- aard_data_plot(doc, type = "${dv.chartType}", x_var = "${dv.xKey}", y_var = "${dv.yKey}", x = ${obj.x}, y = ${obj.y}, width = ${obj.width}, height = ${obj.height})`;
      }

      default:
        return `${varName} <- aard_object(doc, type = "${obj.type}", x = ${obj.x}, y = ${obj.y}, width = ${obj.width}, height = ${obj.height})`;
    }
  }

  // -----------------------------------------------------------
  // INTERACTIVE R SCRIPT REPL EXECUTOR
  // -----------------------------------------------------------
  execute(script: string, currentDoc: AardDocument): RExecutionResult {
    this.commandHistory.push(script);
    const lines = script.split('\n').map(l => l.trim()).filter(l => l.length > 0 && !l.startsWith('#'));

    const createdObjects: AardObject[] = [];
    const docCopy: AardDocument = JSON.parse(JSON.stringify(currentDoc));
    const logs: string[] = [];

    try {
      for (const line of lines) {
        logs.push(`> ${line}`);

        // Simple R parser
        if (line.includes('set.seed(')) {
          const match = line.match(/set\.seed\((\d+)\)/);
          if (match) {
            docCopy.reproducibilitySeed = parseInt(match[1], 10);
            logs.push(`[R::base] Seed initialized to ${docCopy.reproducibilitySeed}`);
          }
        } else if (line.startsWith('aard_rect(') || line.includes('aard_rect(')) {
          const obj = this.parseRectCall(line, docCopy);
          if (obj) {
            docCopy.objects.push(obj);
            createdObjects.push(obj);
            logs.push(`[Aardvark] Created AardRect #${obj.id} (${obj.width}x${obj.height})`);
          }
        } else if (line.startsWith('aard_circle(') || line.startsWith('aard_ellipse(') || line.includes('aard_ellipse(') || line.includes('aard_circle(')) {
          const obj = this.parseEllipseCall(line, docCopy);
          if (obj) {
            docCopy.objects.push(obj);
            createdObjects.push(obj);
            logs.push(`[Aardvark] Created AardEllipse #${obj.id}`);
          }
        } else if (line.startsWith('aard_star(') || line.includes('aard_star(')) {
          const obj = this.parseStarCall(line, docCopy);
          if (obj) {
            docCopy.objects.push(obj);
            createdObjects.push(obj);
            logs.push(`[Aardvark] Created Parametric Star #${obj.id} (${obj.starParams?.points} pts)`);
          }
        } else if (line.startsWith('aard_gear(') || line.includes('aard_gear(')) {
          const obj = this.parseGearCall(line, docCopy);
          if (obj) {
            docCopy.objects.push(obj);
            createdObjects.push(obj);
            logs.push(`[Aardvark] Created Parametric Involute Gear #${obj.id} (${obj.gearParams?.teeth} teeth)`);
          }
        } else if (line.startsWith('aard_spiral(') || line.includes('aard_spiral(')) {
          const obj = this.parseSpiralCall(line, docCopy);
          if (obj) {
            docCopy.objects.push(obj);
            createdObjects.push(obj);
            logs.push(`[Aardvark] Created Archimedean/Golden Spiral #${obj.id}`);
          }
        } else if (line.startsWith('aard_wave(') || line.includes('aard_wave(')) {
          const obj = this.parseWaveCall(line, docCopy);
          if (obj) {
            docCopy.objects.push(obj);
            createdObjects.push(obj);
            logs.push(`[Aardvark] Created Parametric Harmonic Wave #${obj.id}`);
          }
        } else if (line.startsWith('aard_text(') || line.includes('aard_text(')) {
          const obj = this.parseTextCall(line, docCopy);
          if (obj) {
            docCopy.objects.push(obj);
            createdObjects.push(obj);
            logs.push(`[Aardvark] Created Typography Frame #${obj.id}`);
          }
        } else if (line.startsWith('aard_voronoi(') || line.includes('aard_voronoi(')) {
          const obj = this.parseVoronoiCall(line, docCopy);
          if (obj) {
            docCopy.objects.push(obj);
            createdObjects.push(obj);
            logs.push(`[Aardvark] Generated Computational Voronoi Tessellation #${obj.id}`);
          }
        } else if (line.startsWith('aard_lsystem(') || line.includes('aard_lsystem(')) {
          const obj = this.parseLSystemCall(line, docCopy);
          if (obj) {
            docCopy.objects.push(obj);
            createdObjects.push(obj);
            logs.push(`[Aardvark] Generated L-System Fractal Mesh #${obj.id}`);
          }
        } else if (line.startsWith('aard_clear()') || line.includes('aard_clear(')) {
          docCopy.objects = [];
          logs.push(`[Aardvark] Cleared all canvas vector objects.`);
        } else {
          logs.push(`[R::eval] Evaluated statement: OK`);
        }
      }

      return {
        success: true,
        output: logs.join('\n'),
        generatedDocument: docCopy,
        createdObjects,
      };
    } catch (err: any) {
      return {
        success: false,
        output: logs.join('\n'),
        error: `R Evaluation Error: ${err.message || err}`,
      };
    }
  }

  // -----------------------------------------------------------
  // HELPER CALL PARSERS
  // -----------------------------------------------------------
  private parseParam(line: string, paramName: string, defaultVal: any): any {
    const regex = new RegExp(`${paramName}\\s*=\\s*([^,\\)]+)`);
    const match = line.match(regex);
    if (!match) return defaultVal;
    let val = match[1].trim();
    if (val.startsWith('"') && val.endsWith('"')) return val.slice(1, -1);
    if (val.startsWith("'") && val.endsWith("'")) return val.slice(1, -1);
    if (val === 'TRUE' || val === 'true') return true;
    if (val === 'FALSE' || val === 'false') return false;
    const num = parseFloat(val);
    return isNaN(num) ? val : num;
  }

  private parseRectCall(line: string, doc: AardDocument): AardObject {
    const x = this.parseParam(line, 'x', 100);
    const y = this.parseParam(line, 'y', 100);
    const width = this.parseParam(line, 'width', 200);
    const height = this.parseParam(line, 'height', 120);
    const cr = this.parseParam(line, 'corner_radius', 0);
    const fill = this.parseParam(line, 'fill', '#3b82f6');
    const stroke = this.parseParam(line, 'stroke', '#1d4ed8');
    const sw = this.parseParam(line, 'stroke_width', 1.5);
    const rot = this.parseParam(line, 'rotation', 0);

    return {
      id: `rect_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      name: `R_Rect_${Math.round(width)}x${Math.round(height)}`,
      type: 'rect',
      artboardId: doc.activeArtboardId || doc.artboards[0]?.id || 'ab1',
      layerId: doc.activeLayerId || doc.layers[0]?.id || 'layer1',
      x,
      y,
      width,
      height,
      rotation: rot,
      scaleX: 1,
      scaleY: 1,
      skewX: 0,
      skewY: 0,
      pivotX: 0.5,
      pivotY: 0.5,
      opacity: 1,
      visible: true,
      locked: false,
      zIndex: doc.objects.length + 1,
      cornerRadius: cr,
      style: {
        fillType: fill === 'none' ? 'none' : 'solid',
        fillColor: fill === 'none' ? '#00000000' : fill,
        fillOpacity: 1,
        strokeColor: stroke,
        strokeWidth: sw,
        strokeOpacity: 1,
        strokeCap: 'round',
        strokeJoin: 'round',
        strokeMiterLimit: 4,
        strokeDashArray: [],
        strokeDashOffset: 0,
        strokeAlign: 'center',
        blendMode: 'normal',
      },
      rSourceCode: line,
      rGenerated: true,
    };
  }

  private parseEllipseCall(line: string, doc: AardDocument): AardObject {
    const cx = this.parseParam(line, 'cx', 200);
    const cy = this.parseParam(line, 'cy', 200);
    const rx = this.parseParam(line, 'rx', 60);
    const ry = this.parseParam(line, 'ry', rx);
    const fill = this.parseParam(line, 'fill', '#10b981');
    const stroke = this.parseParam(line, 'stroke', '#047857');
    const sw = this.parseParam(line, 'stroke_width', 1.5);

    return {
      id: `ellipse_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      name: `R_Ellipse_${Math.round(rx * 2)}`,
      type: 'ellipse',
      artboardId: doc.activeArtboardId || doc.artboards[0]?.id || 'ab1',
      layerId: doc.activeLayerId || doc.layers[0]?.id || 'layer1',
      x: cx - rx,
      y: cy - ry,
      width: rx * 2,
      height: ry * 2,
      rotation: 0,
      scaleX: 1,
      scaleY: 1,
      skewX: 0,
      skewY: 0,
      pivotX: 0.5,
      pivotY: 0.5,
      opacity: 1,
      visible: true,
      locked: false,
      zIndex: doc.objects.length + 1,
      style: {
        fillType: fill === 'none' ? 'none' : 'solid',
        fillColor: fill === 'none' ? '#00000000' : fill,
        fillOpacity: 1,
        strokeColor: stroke,
        strokeWidth: sw,
        strokeOpacity: 1,
        strokeCap: 'round',
        strokeJoin: 'round',
        strokeMiterLimit: 4,
        strokeDashArray: [],
        strokeDashOffset: 0,
        strokeAlign: 'center',
        blendMode: 'normal',
      },
      rSourceCode: line,
      rGenerated: true,
    };
  }

  private parseStarCall(line: string, doc: AardDocument): AardObject {
    const cx = this.parseParam(line, 'cx', 200);
    const cy = this.parseParam(line, 'cy', 200);
    const points = this.parseParam(line, 'points', 5);
    const innerRadius = this.parseParam(line, 'inner_r', 25);
    const outerRadius = this.parseParam(line, 'outer_r', 60);
    const fill = this.parseParam(line, 'fill', '#f59e0b');
    const stroke = this.parseParam(line, 'stroke', '#d97706');
    const sw = this.parseParam(line, 'stroke_width', 1.5);

    return {
      id: `star_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      name: `R_Star_${points}pt`,
      type: 'star',
      artboardId: doc.activeArtboardId || doc.artboards[0]?.id || 'ab1',
      layerId: doc.activeLayerId || doc.layers[0]?.id || 'layer1',
      x: cx - outerRadius,
      y: cy - outerRadius,
      width: outerRadius * 2,
      height: outerRadius * 2,
      rotation: 0,
      scaleX: 1,
      scaleY: 1,
      skewX: 0,
      skewY: 0,
      pivotX: 0.5,
      pivotY: 0.5,
      opacity: 1,
      visible: true,
      locked: false,
      zIndex: doc.objects.length + 1,
      starParams: {
        points,
        innerRadius,
        outerRadius,
        roundness: 0,
      },
      style: {
        fillType: fill === 'none' ? 'none' : 'solid',
        fillColor: fill === 'none' ? '#00000000' : fill,
        fillOpacity: 1,
        strokeColor: stroke,
        strokeWidth: sw,
        strokeCap: 'round',
        strokeJoin: 'round',
        strokeMiterLimit: 4,
        strokeDashArray: [],
        strokeDashOffset: 0,
        strokeOpacity: 1,
        strokeAlign: 'center',
        blendMode: 'normal',
      },
      rSourceCode: line,
      rGenerated: true,
    };
  }

  private parseGearCall(line: string, doc: AardDocument): AardObject {
    const cx = this.parseParam(line, 'cx', 250);
    const cy = this.parseParam(line, 'cy', 250);
    const teeth = this.parseParam(line, 'teeth', 12);
    const innerRadius = this.parseParam(line, 'inner_r', 40);
    const outerRadius = this.parseParam(line, 'outer_r', 65);
    const toothDepth = this.parseParam(line, 'tooth_depth', 15);
    const fill = this.parseParam(line, 'fill', '#64748b');
    const stroke = this.parseParam(line, 'stroke', '#334155');

    return {
      id: `gear_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      name: `R_Gear_${teeth}T`,
      type: 'gear',
      artboardId: doc.activeArtboardId || doc.artboards[0]?.id || 'ab1',
      layerId: doc.activeLayerId || doc.layers[0]?.id || 'layer1',
      x: cx - outerRadius,
      y: cy - outerRadius,
      width: outerRadius * 2,
      height: outerRadius * 2,
      rotation: 0,
      scaleX: 1,
      scaleY: 1,
      skewX: 0,
      skewY: 0,
      pivotX: 0.5,
      pivotY: 0.5,
      opacity: 1,
      visible: true,
      locked: false,
      zIndex: doc.objects.length + 1,
      gearParams: {
        teeth,
        innerRadius,
        outerRadius,
        toothDepth,
        holeRadius: 15,
        pressureAngle: 20,
      },
      style: {
        fillType: fill === 'none' ? 'none' : 'solid',
        fillColor: fill,
        fillOpacity: 1,
        strokeColor: stroke,
        strokeWidth: 1.5,
        strokeCap: 'round',
        strokeJoin: 'round',
        strokeMiterLimit: 4,
        strokeDashArray: [],
        strokeDashOffset: 0,
        strokeOpacity: 1,
        strokeAlign: 'center',
        blendMode: 'normal',
      },
      rSourceCode: line,
      rGenerated: true,
    };
  }

  private parseSpiralCall(line: string, doc: AardDocument): AardObject {
    const cx = this.parseParam(line, 'cx', 250);
    const cy = this.parseParam(line, 'cy', 250);
    const turns = this.parseParam(line, 'turns', 3.5);
    const outerRadius = this.parseParam(line, 'outer_r', 75);
    const type = this.parseParam(line, 'type', 'archimedean');
    const stroke = this.parseParam(line, 'stroke', '#06b6d4');

    return {
      id: `spiral_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      name: `R_Spiral_${type}`,
      type: 'spiral',
      artboardId: doc.activeArtboardId || doc.artboards[0]?.id || 'ab1',
      layerId: doc.activeLayerId || doc.layers[0]?.id || 'layer1',
      x: cx - outerRadius,
      y: cy - outerRadius,
      width: outerRadius * 2,
      height: outerRadius * 2,
      rotation: 0,
      scaleX: 1,
      scaleY: 1,
      skewX: 0,
      skewY: 0,
      pivotX: 0.5,
      pivotY: 0.5,
      opacity: 1,
      visible: true,
      locked: false,
      zIndex: doc.objects.length + 1,
      spiralParams: {
        turns,
        outerRadius,
        decay: 0.1,
        innerRadius: 0,
        type,
      },
      style: {
        fillType: 'none',
        fillColor: '#00000000',
        fillOpacity: 1,
        strokeColor: stroke,
        strokeWidth: 2,
        strokeCap: 'round',
        strokeJoin: 'round',
        strokeMiterLimit: 4,
        strokeDashArray: [],
        strokeDashOffset: 0,
        strokeOpacity: 1,
        strokeAlign: 'center',
        blendMode: 'normal',
      },
      rSourceCode: line,
      rGenerated: true,
    };
  }

  private parseWaveCall(line: string, doc: AardDocument): AardObject {
    const x = this.parseParam(line, 'x', 50);
    const y = this.parseParam(line, 'y', 200);
    const width = this.parseParam(line, 'width', 400);
    const freq = this.parseParam(line, 'frequency', 4);
    const amp = this.parseParam(line, 'amplitude', 35);
    const type = this.parseParam(line, 'type', 'sine');
    const stroke = this.parseParam(line, 'stroke', '#8b5cf6');

    return {
      id: `wave_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      name: `R_HarmonicWave_${freq}Hz`,
      type: 'wave',
      artboardId: doc.activeArtboardId || doc.artboards[0]?.id || 'ab1',
      layerId: doc.activeLayerId || doc.layers[0]?.id || 'layer1',
      x,
      y: y - amp,
      width,
      height: amp * 2,
      rotation: 0,
      scaleX: 1,
      scaleY: 1,
      skewX: 0,
      skewY: 0,
      pivotX: 0.5,
      pivotY: 0.5,
      opacity: 1,
      visible: true,
      locked: false,
      zIndex: doc.objects.length + 1,
      waveParams: {
        frequency: freq,
        amplitude: amp,
        phase: 0,
        type,
        harmonics: 1,
      },
      style: {
        fillType: 'none',
        fillColor: '#00000000',
        fillOpacity: 1,
        strokeColor: stroke,
        strokeWidth: 2,
        strokeCap: 'round',
        strokeJoin: 'round',
        strokeMiterLimit: 4,
        strokeDashArray: [],
        strokeDashOffset: 0,
        strokeOpacity: 1,
        strokeAlign: 'center',
        blendMode: 'normal',
      },
      rSourceCode: line,
      rGenerated: true,
    };
  }

  private parseTextCall(line: string, doc: AardDocument): AardObject {
    const text = this.parseParam(line, 'text', 'Aardvark Vector');
    const x = this.parseParam(line, 'x', 100);
    const y = this.parseParam(line, 'y', 100);
    const fontSize = this.parseParam(line, 'font_size', 28);
    const fontFamily = this.parseParam(line, 'font_family', 'Inter');
    const fill = this.parseParam(line, 'fill', '#f1f5f9');

    return {
      id: `text_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      name: `R_Text_${text.slice(0, 10)}`,
      type: 'text',
      artboardId: doc.activeArtboardId || doc.artboards[0]?.id || 'ab1',
      layerId: doc.activeLayerId || doc.layers[0]?.id || 'layer1',
      x,
      y,
      width: fontSize * text.length * 0.6,
      height: fontSize * 1.3,
      rotation: 0,
      scaleX: 1,
      scaleY: 1,
      skewX: 0,
      skewY: 0,
      pivotX: 0.5,
      pivotY: 0.5,
      opacity: 1,
      visible: true,
      locked: false,
      zIndex: doc.objects.length + 1,
      typography: {
        text,
        fontFamily,
        fontSize,
        fontWeight: 600,
        fontStyle: 'normal',
        letterSpacing: 0,
        lineHeight: 1.2,
        textAlign: 'left',
      },
      style: {
        fillType: 'solid',
        fillColor: fill,
        fillOpacity: 1,
        strokeColor: '#00000000',
        strokeWidth: 0,
        strokeCap: 'round',
        strokeJoin: 'round',
        strokeMiterLimit: 4,
        strokeDashArray: [],
        strokeDashOffset: 0,
        strokeOpacity: 1,
        strokeAlign: 'center',
        blendMode: 'normal',
      },
      rSourceCode: line,
      rGenerated: true,
    };
  }

  private parseVoronoiCall(line: string, doc: AardDocument): AardObject {
    const x = this.parseParam(line, 'x', 100);
    const y = this.parseParam(line, 'y', 100);
    const width = this.parseParam(line, 'width', 300);
    const height = this.parseParam(line, 'height', 200);
    const seed = this.parseParam(line, 'seed', doc.reproducibilitySeed || 42);
    const complexity = this.parseParam(line, 'complexity', 16);

    return {
      id: `voronoi_${Date.now()}`,
      name: `R_Voronoi_Tessellation`,
      type: 'procedural',
      artboardId: doc.activeArtboardId || doc.artboards[0]?.id || 'ab1',
      layerId: doc.activeLayerId || doc.layers[0]?.id || 'layer1',
      x,
      y,
      width,
      height,
      rotation: 0,
      scaleX: 1,
      scaleY: 1,
      skewX: 0,
      skewY: 0,
      pivotX: 0.5,
      pivotY: 0.5,
      opacity: 1,
      visible: true,
      locked: false,
      zIndex: doc.objects.length + 1,
      procedural: {
        generatorType: 'voronoi',
        seed,
        iterations: 4,
        complexity,
        params: {},
      },
      style: {
        fillType: 'solid',
        fillColor: '#3b82f6',
        fillOpacity: 0.8,
        strokeColor: '#60a5fa',
        strokeWidth: 1.5,
        strokeCap: 'round',
        strokeJoin: 'round',
        strokeMiterLimit: 4,
        strokeDashArray: [],
        strokeDashOffset: 0,
        strokeOpacity: 1,
        strokeAlign: 'center',
        blendMode: 'normal',
      },
      rSourceCode: line,
      rGenerated: true,
    };
  }

  private parseLSystemCall(line: string, doc: AardDocument): AardObject {
    const x = this.parseParam(line, 'x', 150);
    const y = this.parseParam(line, 'y', 350);
    const iterations = this.parseParam(line, 'iterations', 4);
    const rule = this.parseParam(line, 'rule', 'plant');

    const lres = generateLSystemPath(rule as any, iterations, x, y, 10);

    return {
      id: `lsystem_${Date.now()}`,
      name: `R_LSystem_${rule}`,
      type: 'path',
      artboardId: doc.activeArtboardId || doc.artboards[0]?.id || 'ab1',
      layerId: doc.activeLayerId || doc.layers[0]?.id || 'layer1',
      x: 100,
      y: 100,
      width: 300,
      height: 300,
      rotation: 0,
      scaleX: 1,
      scaleY: 1,
      skewX: 0,
      skewY: 0,
      pivotX: 0.5,
      pivotY: 0.5,
      opacity: 1,
      visible: true,
      locked: false,
      zIndex: doc.objects.length + 1,
      path: {
        closed: false,
        segments: [],
        nodes: lres.points.map((p, i) => ({ id: `ls_${i}`, x: p.x, y: p.y, type: 'corner' })),
      },
      style: {
        fillType: 'none',
        fillColor: '#00000000',
        fillOpacity: 1,
        strokeColor: '#10b981',
        strokeWidth: 1.5,
        strokeCap: 'round',
        strokeJoin: 'round',
        strokeMiterLimit: 4,
        strokeDashArray: [],
        strokeDashOffset: 0,
        strokeOpacity: 1,
        strokeAlign: 'center',
        blendMode: 'normal',
      },
      rSourceCode: line,
      rGenerated: true,
    };
  }
}

export const globalREngine = new AardvarkREngine();

export async function executeRScript(script: string, doc: AardDocument) {
  const result = globalREngine.execute(script, doc);
  return {
    document: result.generatedDocument || doc,
    logs: result.output.split('\n'),
  };
}

export function getDefaultRScript(): string {
  return `# Aardvark R Computational Vector Script
library(aardvark)

set.seed(888)

# 1. Create parametric star & gear
aard_star(cx = 250, cy = 250, points = 8, inner_r = 30, outer_r = 85, fill = "#3B82F6", stroke = "#60A5FA")
aard_gear(cx = 500, cy = 250, teeth = 16, inner_r = 45, outer_r = 75, fill = "#10B981")

# 2. Harmonic Wave & Archimedean Spiral
aard_wave(x = 100, y = 420, width = 500, frequency = 5, amplitude = 30, stroke = "#A855F7")
aard_spiral(cx = 200, cy = 550, turns = 4, outer_r = 65, stroke = "#06B6D4")

# 3. Typography
aard_text(text = "AARDVARK VECTOR R-ENGINE", x = 100, y = 80, font_size = 28, fill = "#F1F5F9")
`;
}
