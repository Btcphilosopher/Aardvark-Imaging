'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { AardDocument, AardObject, ToolType, Point2D } from '@/lib/aardvark/types';
import { createBritishModernistPoster, SAMPLE_PROJECTS } from '@/lib/aardvark/sample-projects';
import { generateProceduralNodes } from '@/lib/aardvark/procedural';
import { AardvarkHeader } from '@/components/aardvark/AardvarkHeader';
import { AardvarkToolRail } from '@/components/aardvark/AardvarkToolRail';
import { AardvarkLayers } from '@/components/aardvark/AardvarkLayers';
import { AardvarkCanvas } from '@/components/aardvark/AardvarkCanvas';
import { AardvarkInspector } from '@/components/aardvark/AardvarkInspector';
import { AardvarkRConsole } from '@/components/aardvark/AardvarkRConsole';
import { AardvarkCommandPalette } from '@/components/aardvark/AardvarkCommandPalette';
import { AardvarkStatusBar } from '@/components/aardvark/AardvarkStatusBar';

export default function AardvarkStudioPage() {
  const [mounted, setMounted] = useState<boolean>(false);
  const [doc, setDoc] = useState<AardDocument>(() => createBritishModernistPoster());
  const [activeTool, setActiveTool] = useState<ToolType>('select');
  const [selectedIds, setSelectedIds] = useState<string[]>(['bmp_circle_main']);
  const [zoom, setZoom] = useState<number>(0.95);
  const [pan, setPan] = useState<Point2D>({ x: 80, y: 40 });
  const [isConsoleOpen, setIsConsoleOpen] = useState<boolean>(false);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState<boolean>(false);
  const [selectedNodeIndex, setSelectedNodeIndex] = useState<number | null>(null);

  useEffect(() => {
    setMounted(true);
  }, []);

  // Keyboard Shortcuts (⌘K for command palette, ⌘D duplicate, Backspace delete, tool shortcuts)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger shortcuts if typing inside inputs or textareas
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) {
        return;
      }

      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen(prev => !prev);
        return;
      }

      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'd') {
        e.preventDefault();
        if (selectedIds[0]) {
          handleDuplicateObject(selectedIds[0]);
        }
        return;
      }

      if (e.key === 'Delete' || e.key === 'Backspace') {
        if (selectedIds.length > 0) {
          e.preventDefault();
          selectedIds.forEach(id => handleDeleteObject(id));
        }
        return;
      }

      // Quick Tool Hotkeys
      const key = e.key.toLowerCase();
      if (key === 'v') setActiveTool('select');
      else if (key === 'a') setActiveTool('node');
      else if (key === 'p') setActiveTool('pen');
      else if (key === 'r') setActiveTool('rect');
      else if (key === 'e') setActiveTool('ellipse');
      else if (key === 's') setActiveTool('star');
      else if (key === 'g') setActiveTool('gear');
      else if (key === 'l') setActiveTool('spiral');
      else if (key === 'w') setActiveTool('wave');
      else if (key === 't') setActiveTool('text');
      else if (key === 'h') setActiveTool('pan');
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedIds, doc]);

  // Object selection handler
  const handleSelectObject = (id: string, multi: boolean = false) => {
    if (multi) {
      setSelectedIds(prev => (prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]));
    } else {
      setSelectedIds([id]);
    }
  };

  const handleClearSelection = () => {
    setSelectedIds([]);
  };

  const handleUpdateObject = (id: string, partial: Partial<AardObject>) => {
    setDoc(prev => ({
      ...prev,
      updatedAt: new Date().toISOString(),
      objects: prev.objects.map(o => (o.id === id ? { ...o, ...partial } : o)),
    }));
  };

  const handleDeleteObject = (id: string) => {
    setDoc(prev => ({
      ...prev,
      updatedAt: new Date().toISOString(),
      objects: prev.objects.filter(o => o.id !== id),
    }));
    setSelectedIds(prev => prev.filter(i => i !== id));
  };

  const handleDuplicateObject = (id: string) => {
    const target = doc.objects.find(o => o.id === id);
    if (!target) return;

    const newObj: AardObject = {
      ...target,
      id: `obj_${Date.now()}`,
      name: `${target.name} Copy`,
      x: target.x + 20,
      y: target.y + 20,
      zIndex: doc.objects.length + 1,
    };

    setDoc(prev => ({
      ...prev,
      updatedAt: new Date().toISOString(),
      objects: [...prev.objects, newObj],
    }));
    setSelectedIds([newObj.id]);
  };

  const handleReorderObject = (id: string, direction: 'up' | 'down') => {
    setDoc(prev => {
      const idx = prev.objects.findIndex(o => o.id === id);
      if (idx === -1) return prev;
      const targetZ = prev.objects[idx].zIndex;
      const delta = direction === 'up' ? 1 : -1;

      return {
        ...prev,
        objects: prev.objects.map(o => (o.id === id ? { ...o, zIndex: Math.max(1, targetZ + delta) } : o)),
      };
    });
  };

  const handleAddObject = (objOrType: AardObject | string) => {
    if (typeof objOrType === 'string') {
      const type = objOrType;
      const newObj: AardObject = {
        id: `obj_${Date.now()}`,
        name: `${type.toUpperCase()} ${doc.objects.length + 1}`,
        type: type as any,
        artboardId: doc.activeArtboardId,
        layerId: doc.activeLayerId,
        x: 250,
        y: 250,
        width: 140,
        height: 140,
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        skewX: 0,
        skewY: 0,
        pivotX: 0.5,
        pivotY: 0.5,
        opacity: 1,
        visible: true,
        locked: false,
        zIndex: doc.objects.length + 1,
        style: {
          fillType: 'solid',
          fillColor: '#3B82F6',
          fillOpacity: 1,
          strokeColor: '#1D4ED8',
          strokeWidth: 1.5,
          strokeOpacity: 1,
          strokeCap: 'round',
          strokeJoin: 'round',
          strokeMiterLimit: 4,
          strokeDashArray: [],
          strokeDashOffset: 0,
          strokeAlign: 'center',
          blendMode: 'normal',
        },
      };

      if (type === 'star') {
        newObj.starParams = { points: 5, innerRadius: 30, outerRadius: 65, roundness: 0 };
      } else if (type === 'gear') {
        newObj.gearParams = { teeth: 12, innerRadius: 40, outerRadius: 65, toothDepth: 18, holeRadius: 20, pressureAngle: 20 };
      } else if (type === 'wave') {
        newObj.waveParams = { frequency: 4, amplitude: 25, phase: 0, type: 'sine', harmonics: 1 };
        newObj.style.fillType = 'none';
      }

      setDoc(prev => ({ ...prev, objects: [...prev.objects, newObj] }));
      setSelectedIds([newObj.id]);
    } else {
      setDoc(prev => ({ ...prev, objects: [...prev.objects, objOrType] }));
      setSelectedIds([objOrType.id]);
    }
  };

  const handleAddProcedural = (type: 'voronoi' | 'lsystem' | 'superformula' | 'phyllotaxis') => {
    const nodes = generateProceduralNodes(type, 777, 24);
    const mappedGenType = type === 'lsystem' ? 'l_system' : type === 'phyllotaxis' ? 'circle_pack' : type;

    const newObj: AardObject = {
      id: `proc_${Date.now()}`,
      name: `R ${type.toUpperCase()} Pattern`,
      type: 'procedural',
      artboardId: doc.activeArtboardId,
      layerId: doc.activeLayerId,
      x: 200,
      y: 200,
      width: 300,
      height: 300,
      rotation: 0,
      scaleX: 1,
      scaleY: 1,
      skewX: 0,
      skewY: 0,
      pivotX: 0.5,
      pivotY: 0.5,
      opacity: 0.9,
      visible: true,
      locked: false,
      zIndex: doc.objects.length + 1,
      procedural: {
        generatorType: mappedGenType as any,
        seed: 777,
        iterations: 4,
        complexity: 24,
        params: {},
      },
      style: {
        fillType: 'solid',
        fillColor: '#3B82F6',
        fillOpacity: 0.8,
        strokeColor: '#60A5FA',
        strokeWidth: 1.5,
        strokeOpacity: 1,
        strokeCap: 'round',
        strokeJoin: 'round',
        strokeMiterLimit: 4,
        strokeDashArray: [],
        strokeDashOffset: 0,
        strokeAlign: 'center',
        blendMode: 'normal',
      },
    };

    setDoc(prev => ({ ...prev, objects: [...prev.objects, newObj] }));
    setSelectedIds([newObj.id]);
  };

  const handleAddLayer = (name: string) => {
    const newLayerId = `layer_${Date.now()}`;
    setDoc(prev => ({
      ...prev,
      layers: [
        ...prev.layers,
        { id: newLayerId, name, visible: true, locked: false, color: '#10B981', opacity: 1 },
      ],
      activeLayerId: newLayerId,
    }));
  };

  const handleToggleLayerVisibility = (layerId: string) => {
    setDoc(prev => ({
      ...prev,
      layers: prev.layers.map(l => (l.id === layerId ? { ...l, visible: !l.visible } : l)),
    }));
  };

  const handleToggleLayerLock = (layerId: string) => {
    setDoc(prev => ({
      ...prev,
      layers: prev.layers.map(l => (l.id === layerId ? { ...l, locked: !l.locked } : l)),
    }));
  };

  const handleBooleanOp = (op: 'union' | 'subtract' | 'intersect' | 'exclude') => {
    if (selectedIds.length < 2) return;
    const selectedObjs = doc.objects.filter(o => selectedIds.includes(o.id));
    const first = selectedObjs[0];

    const compoundObj: AardObject = {
      ...first,
      id: `boolean_${Date.now()}`,
      name: `Compound ${op.toUpperCase()}`,
      type: 'path',
    };

    setDoc(prev => ({
      ...prev,
      objects: [...prev.objects.filter(o => !selectedIds.includes(o.id)), compoundObj],
    }));
    setSelectedIds([compoundObj.id]);
  };

  const handleAlign = (direction: 'left' | 'center' | 'right' | 'top' | 'middle' | 'bottom') => {
    if (selectedIds.length === 0) return;
    const activeArtboard = doc.artboards.find(a => a.id === doc.activeArtboardId) || doc.artboards[0];

    setDoc(prev => ({
      ...prev,
      objects: prev.objects.map(o => {
        if (!selectedIds.includes(o.id)) return o;
        let newX = o.x;
        let newY = o.y;

        if (direction === 'left') newX = 0;
        else if (direction === 'center') newX = (activeArtboard.width - o.width) / 2;
        else if (direction === 'right') newX = activeArtboard.width - o.width;
        else if (direction === 'top') newY = 0;
        else if (direction === 'middle') newY = (activeArtboard.height - o.height) / 2;
        else if (direction === 'bottom') newY = activeArtboard.height - o.height;

        return { ...o, x: newX, y: newY };
      }),
    }));
  };

  if (!mounted) {
    return (
      <div className="flex flex-col h-screen w-screen bg-[#0D0D0D] text-white font-sans overflow-hidden items-center justify-center select-none">
        <div className="flex items-center gap-3 text-[#3B82F6] font-mono text-xs">
          <span className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-ping" />
          <span>AARDVARK VECTOR ENGINE INITIALIZING...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen w-screen bg-[#0D0D0D] text-white font-sans overflow-hidden select-none">
      {/* Top Header */}
      <AardvarkHeader
        document={doc}
        onLoadProject={newDoc => {
          setDoc(newDoc);
          setSelectedIds([]);
        }}
        onToggleConsole={() => setIsConsoleOpen(prev => !prev)}
        isConsoleOpen={isConsoleOpen}
        onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
        onResetView={() => {
          setZoom(1);
          setPan({ x: 80, y: 40 });
        }}
        zoom={zoom}
      />

      {/* Main Studio Middle Area */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Left Vertical Tool Rail */}
        <AardvarkToolRail
          activeTool={activeTool}
          onSelectTool={tool => setActiveTool(tool)}
          onAddProcedural={handleAddProcedural}
        />

        {/* Left Vector Layers Tree */}
        <AardvarkLayers
          document={doc}
          selectedIds={selectedIds}
          onSelectObject={handleSelectObject}
          onUpdateObject={handleUpdateObject}
          onDeleteObject={handleDeleteObject}
          onReorderObject={handleReorderObject}
          onAddLayer={handleAddLayer}
          onToggleLayerVisibility={handleToggleLayerVisibility}
          onToggleLayerLock={handleToggleLayerLock}
        />

        {/* Center Interactive Canvas Viewport */}
        <AardvarkCanvas
          document={doc}
          activeTool={activeTool}
          selectedIds={selectedIds}
          onSelectObject={handleSelectObject}
          onClearSelection={handleClearSelection}
          onUpdateObject={handleUpdateObject}
          onAddObject={handleAddObject}
          zoom={zoom}
          setZoom={setZoom}
          pan={pan}
          setPan={setPan}
          selectedNodeIndex={selectedNodeIndex}
          setSelectedNodeIndex={setSelectedNodeIndex}
        />

        {/* Right Parametric & Style Inspector Sidebar */}
        <AardvarkInspector
          document={doc}
          selectedIds={selectedIds}
          onUpdateObject={handleUpdateObject}
          onDeleteObject={handleDeleteObject}
          onDuplicateObject={handleDuplicateObject}
          onBooleanOp={handleBooleanOp}
          onAlign={handleAlign}
        />
      </div>

      {/* R REPL & Scripting Console Drawer */}
      {isConsoleOpen && (
        <AardvarkRConsole
          document={doc}
          onUpdateDocument={updatedDoc => setDoc(updatedDoc)}
          onClose={() => setIsConsoleOpen(false)}
        />
      )}

      {/* Bottom Status Bar */}
      <AardvarkStatusBar
        document={doc}
        zoom={zoom}
        selectedIds={selectedIds}
        onToggleGrid={() =>
          setDoc(prev => ({
            ...prev,
            grid: { ...prev.grid, enabled: !prev.grid.enabled },
          }))
        }
        onToggleSnap={() =>
          setDoc(prev => ({
            ...prev,
            grid: { ...prev.grid, snap: !prev.grid.snap },
          }))
        }
      />

      {/* Quick Command Launcher Palette (⌘K) */}
      <AardvarkCommandPalette
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        document={doc}
        onLoadProject={newDoc => {
          setDoc(newDoc);
          setSelectedIds([]);
        }}
        onAddObject={handleAddObject}
        onToggleConsole={() => setIsConsoleOpen(prev => !prev)}
      />
    </div>
  );
}
