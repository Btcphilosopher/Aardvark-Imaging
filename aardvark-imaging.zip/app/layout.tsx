import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Aardvark Imaging — R-Based Vector Graphics Engine & Digital Design Studio',
  description: 'Computational R-based vector graphics studio, parametric geometry engine, and interactive digital design environment.',
  openGraph: {
    title: 'Aardvark Imaging — Computational Vector Graphics Studio',
    description: 'Computational R-based vector graphics studio, parametric geometry engine, and interactive digital design environment.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Aardvark Imaging — Computational Vector Graphics Studio',
    description: 'Computational R-based vector graphics studio, parametric geometry engine, and interactive digital design environment.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
