'use client';

import React, { useState, useRef, useEffect } from 'react';
import { 
  Terminal, 
  Play, 
  RotateCcw, 
  X, 
  CheckCircle2, 
  Sparkles, 
  Code2, 
  Download,
  Copy
} from 'lucide-react';
import { AardDocument } from '@/lib/aardvark/types';
import { executeRScript, getDefaultRScript } from '@/lib/aardvark/r-engine';

interface AardvarkRConsoleProps {
  document: AardDocument;
  onUpdateDocument: (doc: AardDocument) => void;
  onClose: () => void;
}

export const AardvarkRConsole: React.FC<AardvarkRConsoleProps> = ({
  document: doc,
  onUpdateDocument,
  onClose,
}) => {
  const [script, setScript] = useState<string>(doc.rScriptSource || getDefaultRScript());
  const [outputLogs, setOutputLogs] = useState<string[]>([
    'R-4.4.2 (2026-04-18) -- "Aardvark Vector Engine"',
    'Copyright (C) 2026 The R Foundation for Statistical Computing',
    'Platform: x86_64-pc-linux-gnu (64-bit)',
    'Loaded library: aardvark (v1.2.0)',
    'Type \'aard_help()\' or press Ctrl+Enter to execute code.',
  ]);
  const [isExecuting, setIsExecuting] = useState(false);
  const terminalEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [outputLogs]);

  const handleRunScript = async () => {
    setIsExecuting(true);
    setOutputLogs(prev => [...prev, `> Executing R vector synthesis script...`]);

    try {
      const result = await executeRScript(script, doc);
      setOutputLogs(prev => [
        ...prev,
        ...result.logs,
        `[SUCCESS] Generated ${result.document.objects.length} vector objects with seed ${result.document.reproducibilitySeed}.`,
      ]);
      onUpdateDocument(result.document);
    } catch (err: any) {
      setOutputLogs(prev => [...prev, `[ERROR] ${err.message || 'R execution error'}`]);
    } finally {
      setIsExecuting(false);
    }
  };

  const handleClearTerminal = () => {
    setOutputLogs(['R-4.4.2 Session Cleared.']);
  };

  return (
    <div className="h-72 bg-[#121212] border-t border-[#333] flex flex-col font-mono text-[11px] z-40 select-none shadow-2xl">
      {/* Console Title bar */}
      <div className="h-8 px-3 bg-[#1A1A1A] border-b border-[#2A2A2A] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Terminal className="w-3.5 h-3.5 text-[#3B82F6]" />
          <span className="font-bold text-[#EEE] text-[11px]">R REPL & Vector Synthesis Terminal</span>
          <span className="px-1.5 py-0.5 bg-[#252525] border border-[#333] text-[#A3E635] text-[9px] rounded font-mono">
            R 4.4.2 ACTIVE
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleRunScript}
            disabled={isExecuting}
            className="flex items-center gap-1 px-3 py-1 bg-[#3B82F6] hover:bg-[#2563EB] disabled:bg-[#333] text-white font-sans font-medium text-[10px] rounded transition-colors shadow-sm"
          >
            <Play className="w-3 h-3 fill-current" />
            <span>{isExecuting ? 'Running R...' : 'Execute Script (⌘↵)'}</span>
          </button>
          <button
            onClick={handleClearTerminal}
            className="p-1 hover:bg-[#2A2A2A] text-[#888] hover:text-[#FFF] rounded"
            title="Clear Console Output"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onClose}
            className="p-1 hover:bg-[#2A2A2A] text-[#888] hover:text-[#EF4444] rounded"
            title="Close Terminal"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Editor & Console Split View */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left: Code Editor */}
        <div className="flex-1 border-r border-[#222] bg-[#0E0E0E] flex flex-col p-2">
          <div className="text-[9px] text-[#666] uppercase font-bold tracking-wider mb-1 flex items-center justify-between">
            <span>R Script Editor</span>
            <span className="text-[#3B82F6]">library(aardvark)</span>
          </div>
          <textarea
            value={script}
            onChange={e => setScript(e.target.value)}
            onKeyDown={e => {
              if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
                e.preventDefault();
                handleRunScript();
              }
            }}
            className="flex-1 w-full bg-transparent text-[#A3E635] font-mono outline-none resize-none leading-relaxed text-[11px] p-1 selection:bg-[#3B82F6]/30"
            spellCheck={false}
          />
        </div>

        {/* Right: Execution Log Terminal Output */}
        <div className="flex-1 bg-[#090909] p-3 overflow-y-auto space-y-1 font-mono text-[10px]">
          {outputLogs.map((log, idx) => (
            <div
              key={idx}
              className={
                log.startsWith('[SUCCESS]')
                  ? 'text-emerald-400 font-bold'
                  : log.startsWith('[ERROR]')
                  ? 'text-rose-400 font-bold'
                  : log.startsWith('>')
                  ? 'text-[#3B82F6]'
                  : 'text-[#888]'
              }
            >
              {log}
            </div>
          ))}
          <div ref={terminalEndRef} />
        </div>
      </div>
    </div>
  );
};
