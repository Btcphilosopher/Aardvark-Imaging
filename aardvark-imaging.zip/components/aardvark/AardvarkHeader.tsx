'use client';

import React, { useState } from 'react';
import { 
  FileCode2, 
  Download, 
  Play, 
  Terminal, 
  Sparkles, 
  Layers, 
  Eye, 
  Grid, 
  Maximize2, 
  HelpCircle, 
  Sliders, 
  RotateCcw,
  CheckCircle2,
  FolderOpen
} from 'lucide-react';
import { AardDocument } from '@/lib/aardvark/types';
import { SAMPLE_PROJECTS } from '@/lib/aardvark/sample-projects';
import { exportDocumentToSvg, exportDocumentToPdf, triggerDownload } from '@/lib/aardvark/svg-pdf-export';

interface AardvarkHeaderProps {
  document: AardDocument;
  onLoadProject: (doc: AardDocument) => void;
  onToggleConsole: () => void;
  isConsoleOpen: boolean;
  onOpenCommandPalette: () => void;
  onResetView: () => void;
  zoom: number;
}

export const AardvarkHeader: React.FC<AardvarkHeaderProps> = ({
  document,
  onLoadProject,
  onToggleConsole,
  isConsoleOpen,
  onOpenCommandPalette,
  onResetView,
  zoom,
}) => {
  const [activeMenu, setActiveMenu] = useState<string | null>(null);

  const handleExportSvg = () => {
    const svgData = exportDocumentToSvg(document);
    triggerDownload(svgData, `${document.name.toLowerCase().replace(/\s+/g, '_')}.svg`, 'image/svg+xml');
  };

  const handleExportPdf = () => {
    const pdf = exportDocumentToPdf(document);
    pdf.save(`${document.name.toLowerCase().replace(/\s+/g, '_')}.pdf`);
  };

  const handleExportAard = () => {
    const jsonStr = JSON.stringify(document, null, 2);
    triggerDownload(jsonStr, `${document.name.toLowerCase().replace(/\s+/g, '_')}.aard`, 'application/json');
  };

  return (
    <header className="h-10 flex items-center justify-between px-3 bg-[#1F1F1F] border-b border-[#333] select-none text-[11px] z-50">
      {/* Left: Brand + App Menus */}
      <div className="flex items-center gap-5">
        {/* Aardvark Brand Mark */}
        <div className="flex items-center gap-2 cursor-pointer">
          <div className="w-5 h-5 bg-[#3B82F6] flex items-center justify-center rounded-[2px] shadow-sm">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#FFFFFF" strokeWidth="2.5" strokeLinecap="square">
              <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
            </svg>
          </div>
          <span className="font-bold tracking-widest text-[#F5F5F0] text-[12px]">AARDVARK</span>
          <span className="text-[9px] font-mono px-1 py-0.5 bg-[#2A2A2A] text-[#93C5FD] border border-[#3A3A3A] rounded-[2px]">
            R-4.4.2
          </span>
        </div>

        {/* Traditional Pro Desktop Menus */}
        <nav className="flex items-center gap-1 text-[#AAA] relative">
          {/* File Menu */}
          <div className="relative">
            <button
              onClick={() => setActiveMenu(activeMenu === 'file' ? null : 'file')}
              className={`px-2 py-1 rounded-[2px] hover:bg-[#2A2A2A] hover:text-[#FFF] ${activeMenu === 'file' ? 'bg-[#2A2A2A] text-[#FFF]' : ''}`}
            >
              File
            </button>
            {activeMenu === 'file' && (
              <div className="absolute left-0 top-full mt-1 w-52 bg-[#1A1A1A] border border-[#333] shadow-2xl rounded-[3px] py-1 z-50 text-[#CCC]">
                <div className="px-3 py-1 text-[9px] uppercase font-bold text-[#666] tracking-wider">Example Projects</div>
                {SAMPLE_PROJECTS.map(proj => (
                  <button
                    key={proj.id}
                    onClick={() => {
                      onLoadProject(proj.factory());
                      setActiveMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 hover:bg-[#2F2F2F] hover:text-[#FFF] flex items-center gap-2"
                  >
                    <FolderOpen className="w-3.5 h-3.5 text-[#3B82F6]" />
                    <span>{proj.name}</span>
                  </button>
                ))}
                <div className="h-[1px] bg-[#333] my-1" />
                <button
                  onClick={() => {
                    handleExportSvg();
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2F2F2F] hover:text-[#FFF] flex items-center justify-between"
                >
                  <span>Export SVG</span>
                  <span className="text-[9px] font-mono text-[#666]">Vector</span>
                </button>
                <button
                  onClick={() => {
                    handleExportPdf();
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2F2F2F] hover:text-[#FFF] flex items-center justify-between"
                >
                  <span>Export PDF</span>
                  <span className="text-[9px] font-mono text-[#666]">Print</span>
                </button>
                <button
                  onClick={() => {
                    handleExportAard();
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2F2F2F] hover:text-[#FFF] flex items-center justify-between"
                >
                  <span>Save .aard Document</span>
                  <span className="text-[9px] font-mono text-[#3B82F6]">Native</span>
                </button>
              </div>
            )}
          </div>

          {/* Quick Command Launcher button */}
          <button
            onClick={onOpenCommandPalette}
            className="px-2 py-1 rounded-[2px] hover:bg-[#2A2A2A] hover:text-[#FFF] flex items-center gap-1.5"
          >
            <Sparkles className="w-3 h-3 text-[#3B82F6]" />
            <span>Command Palette</span>
            <kbd className="text-[8px] bg-[#282828] px-1 rounded text-[#888] font-mono">⌘K</kbd>
          </button>
        </nav>
      </div>

      {/* Center: Current Document Name + Dimensions */}
      <div className="hidden md:flex items-center gap-3 text-[#888]">
        <span className="text-[#DDD] font-medium">{document.name}</span>
        <span className="text-[#555]">|</span>
        <span className="font-mono text-[10px] text-[#888]">
          {document.artboards[0]?.width || 800} × {document.artboards[0]?.height || 600} {document.units} ({Math.round(zoom * 100)}%)
        </span>
      </div>

      {/* Right: Actions & R Status */}
      <div className="flex items-center gap-3">
        {/* R Engine Indicator */}
        <div className="flex items-center gap-2 px-2.5 py-1 bg-[#141414] border border-[#2E2E2E] rounded-[2px]">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-[10px] uppercase font-mono tracking-wider text-[#A3E635]">R-Engine Active</span>
        </div>

        {/* Toggle R Console */}
        <button
          onClick={onToggleConsole}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-[2px] border text-[11px] transition-colors ${
            isConsoleOpen
              ? 'bg-[#3B82F6] border-[#2563EB] text-white shadow-sm'
              : 'bg-[#282828] border-[#3A3A3A] text-[#CCC] hover:bg-[#333]'
          }`}
        >
          <Terminal className="w-3.5 h-3.5" />
          <span>R Console</span>
        </button>

        {/* Quick SVG Export */}
        <button
          onClick={handleExportSvg}
          className="flex items-center gap-1.5 px-2.5 py-1 bg-[#282828] hover:bg-[#333] border border-[#3A3A3A] text-[#DDD] rounded-[2px] transition-colors"
          title="Export standalone SVG"
        >
          <Download className="w-3.5 h-3.5 text-[#3B82F6]" />
          <span>Export SVG</span>
        </button>
      </div>
    </header>
  );
};
