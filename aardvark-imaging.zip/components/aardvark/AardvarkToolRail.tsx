'use client';

import React from 'react';
import { 
  MousePointer, 
  Square, 
  Circle, 
  Star, 
  Settings2, 
  Activity, 
  Type, 
  PenTool, 
  GitBranch, 
  Ruler, 
  Hand, 
  ZoomIn, 
  Hexagon, 
  ArrowRight, 
  Spline,
  Sparkles,
  Compass
} from 'lucide-react';
import { ToolType } from '@/lib/aardvark/types';

interface AardvarkToolRailProps {
  activeTool: ToolType;
  onSelectTool: (tool: ToolType) => void;
  onAddProcedural: (type: 'voronoi' | 'lsystem' | 'superformula' | 'phyllotaxis') => void;
}

export const AardvarkToolRail: React.FC<AardvarkToolRailProps> = ({
  activeTool,
  onSelectTool,
  onAddProcedural,
}) => {
  const tools: { id: ToolType; label: string; icon: React.ReactNode; shortcut: string }[] = [
    { id: 'select', label: 'Object Select', icon: <MousePointer className="w-4 h-4" />, shortcut: 'V' },
    { id: 'node', label: 'Bézier Node Editor', icon: <Spline className="w-4 h-4" />, shortcut: 'A' },
    { id: 'pen', label: 'Pen Tool', icon: <PenTool className="w-4 h-4" />, shortcut: 'P' },
    { id: 'rect', label: 'Rectangle', icon: <Square className="w-4 h-4" />, shortcut: 'R' },
    { id: 'ellipse', label: 'Ellipse', icon: <Circle className="w-4 h-4" />, shortcut: 'E' },
    { id: 'star', label: 'Parametric Star', icon: <Star className="w-4 h-4" />, shortcut: 'S' },
    { id: 'gear', label: 'Involute Gear', icon: <Settings2 className="w-4 h-4" />, shortcut: 'G' },
    { id: 'spiral', label: 'Golden Spiral', icon: <Compass className="w-4 h-4" />, shortcut: 'L' },
    { id: 'wave', label: 'Harmonic Wave', icon: <Activity className="w-4 h-4" />, shortcut: 'W' },
    { id: 'polygon', label: 'Polygon', icon: <Hexagon className="w-4 h-4" />, shortcut: 'Y' },
    { id: 'arrow', label: 'Arrow', icon: <ArrowRight className="w-4 h-4" />, shortcut: 'O' },
    { id: 'text', label: 'Typography', icon: <Type className="w-4 h-4" />, shortcut: 'T' },
    { id: 'connector', label: 'Smart Connector', icon: <GitBranch className="w-4 h-4" />, shortcut: 'C' },
    { id: 'dimension', label: 'CAD Dimension', icon: <Ruler className="w-4 h-4" />, shortcut: 'D' },
    { id: 'pan', label: 'Hand / Pan', icon: <Hand className="w-4 h-4" />, shortcut: 'H' },
    { id: 'zoom', label: 'Zoom Tool', icon: <ZoomIn className="w-4 h-4" />, shortcut: 'Z' },
  ];

  return (
    <aside className="w-12 bg-[#1A1A1A] border-r border-[#333] flex flex-col items-center py-2.5 gap-1 select-none z-30">
      {/* Primary Tool Stack */}
      <div className="flex flex-col gap-1 w-full px-1.5">
        {tools.map(tool => {
          const isActive = activeTool === tool.id;
          return (
            <button
              key={tool.id}
              onClick={() => onSelectTool(tool.id)}
              className={`relative group w-full aspect-square flex items-center justify-center rounded-[2px] transition-colors ${
                isActive
                  ? 'bg-[#3B82F6] text-white shadow-sm'
                  : 'text-[#888] hover:bg-[#282828] hover:text-[#DDD]'
              }`}
              title={`${tool.label} (${tool.shortcut})`}
            >
              {tool.icon}
              {/* Tooltip on hover */}
              <div className="absolute left-full ml-2 hidden group-hover:flex items-center gap-1.5 px-2 py-1 bg-[#111] border border-[#333] text-[#EEE] text-[10px] font-sans rounded-[2px] shadow-xl whitespace-nowrap pointer-events-none z-50">
                <span>{tool.label}</span>
                <span className="text-[#3B82F6] font-mono font-bold">[{tool.shortcut}]</span>
              </div>
            </button>
          );
        })}
      </div>

      <div className="w-7 h-[1px] bg-[#2E2E2E] my-1" />

      {/* R Procedural Generator Menu */}
      <div className="flex flex-col gap-1 w-full px-1.5">
        <button
          onClick={() => onAddProcedural('voronoi')}
          className="group relative w-full aspect-square flex items-center justify-center rounded-[2px] text-[#A3E635] hover:bg-[#282828] transition-colors"
          title="Insert R Voronoi Tessellation"
        >
          <Sparkles className="w-4 h-4" />
          <div className="absolute left-full ml-2 hidden group-hover:flex items-center gap-1.5 px-2 py-1 bg-[#111] border border-[#333] text-[#EEE] text-[10px] font-sans rounded-[2px] shadow-xl whitespace-nowrap pointer-events-none z-50">
            <span>R Voronoi Generator</span>
          </div>
        </button>
      </div>

      {/* Bottom R Indicator */}
      <div className="mt-auto flex flex-col items-center gap-1">
        <div className="w-7 h-7 bg-[#141414] border border-[#333] flex items-center justify-center rounded-[2px] text-[10px] font-mono font-bold text-[#3B82F6]">
          R
        </div>
      </div>
    </aside>
  );
};
