'use client';

import React, { useState } from 'react';
import { 
  AardDocument, 
  AardObject, 
  AardStyle 
} from '@/lib/aardvark/types';
import { 
  Sliders, 
  Layers, 
  Type, 
  Combine, 
  Code, 
  AlignLeft, 
  AlignCenter, 
  AlignRight, 
  AlignJustify,
  Trash2,
  Copy,
  Lock,
  Unlock,
  Eye,
  EyeOff
} from 'lucide-react';

interface AardvarkInspectorProps {
  document: AardDocument;
  selectedIds: string[];
  onUpdateObject: (id: string, partial: Partial<AardObject>) => void;
  onDeleteObject: (id: string) => void;
  onDuplicateObject: (id: string) => void;
  onBooleanOp: (op: 'union' | 'subtract' | 'intersect' | 'exclude') => void;
  onAlign: (direction: 'left' | 'center' | 'right' | 'top' | 'middle' | 'bottom') => void;
}

export const AardvarkInspector: React.FC<AardvarkInspectorProps> = ({
  document: doc,
  selectedIds,
  onUpdateObject,
  onDeleteObject,
  onDuplicateObject,
  onBooleanOp,
  onAlign,
}) => {
  const [activeTab, setActiveTab] = useState<'properties' | 'parametric' | 'style' | 'r_code'>('properties');

  const selectedObject = doc.objects.find(o => selectedIds.includes(o.id));

  if (!selectedObject) {
    return (
      <aside className="w-72 bg-[#1A1A1A] border-l border-[#333] flex flex-col p-4 select-none text-[11px] text-[#888]">
        <div className="font-bold text-[#DDD] text-[12px] mb-2">Document Settings</div>
        <div className="space-y-3 font-mono">
          <div className="flex justify-between py-1 border-b border-[#282828]">
            <span>Document Units</span>
            <span className="text-[#3B82F6]">{doc.units}</span>
          </div>
          <div className="flex justify-between py-1 border-b border-[#282828]">
            <span>Active Artboard</span>
            <span className="text-[#DDD]">{doc.artboards[0]?.name || 'Artboard 1'}</span>
          </div>
          <div className="flex justify-between py-1 border-b border-[#282828]">
            <span>Resolution / DPI</span>
            <span className="text-[#DDD]">{doc.dpi} DPI</span>
          </div>
          <div className="flex justify-between py-1 border-b border-[#282828]">
            <span>Total Objects</span>
            <span className="text-[#DDD]">{doc.objects.length}</span>
          </div>
          <div className="flex justify-between py-1 border-b border-[#282828]">
            <span>R Random Seed</span>
            <span className="text-[#A3E635]">{doc.reproducibilitySeed}</span>
          </div>
        </div>

        <div className="mt-8 p-3 bg-[#141414] border border-[#2E2E2E] rounded-[2px] text-[10px] text-[#666] leading-relaxed">
          Select an object on canvas or the layer hierarchy to inspect parametric nodes, Bézier continuities, and R vector calls.
        </div>
      </aside>
    );
  }

  const updateStyle = (partial: Partial<AardStyle>) => {
    onUpdateObject(selectedObject.id, {
      style: { ...selectedObject.style, ...partial },
    });
  };

  return (
    <aside className="w-72 bg-[#1A1A1A] border-l border-[#333] flex flex-col select-none text-[11px] text-[#CCC] overflow-y-auto">
      {/* Inspector Header / Tabs */}
      <div className="flex items-center border-b border-[#333] bg-[#141414]">
        <button
          onClick={() => setActiveTab('properties')}
          className={`flex-1 py-2 text-center font-medium border-b-2 transition-colors ${
            activeTab === 'properties' ? 'border-[#3B82F6] text-[#FFF] bg-[#1F1F1F]' : 'border-transparent text-[#777] hover:text-[#BBB]'
          }`}
        >
          Transform
        </button>
        <button
          onClick={() => setActiveTab('parametric')}
          className={`flex-1 py-2 text-center font-medium border-b-2 transition-colors ${
            activeTab === 'parametric' ? 'border-[#3B82F6] text-[#FFF] bg-[#1F1F1F]' : 'border-transparent text-[#777] hover:text-[#BBB]'
          }`}
        >
          Params
        </button>
        <button
          onClick={() => setActiveTab('style')}
          className={`flex-1 py-2 text-center font-medium border-b-2 transition-colors ${
            activeTab === 'style' ? 'border-[#3B82F6] text-[#FFF] bg-[#1F1F1F]' : 'border-transparent text-[#777] hover:text-[#BBB]'
          }`}
        >
          Style
        </button>
        <button
          onClick={() => setActiveTab('r_code')}
          className={`flex-1 py-2 text-center font-medium border-b-2 transition-colors ${
            activeTab === 'r_code' ? 'border-[#3B82F6] text-[#FFF] bg-[#1F1F1F]' : 'border-transparent text-[#777] hover:text-[#BBB]'
          }`}
        >
          R Code
        </button>
      </div>

      {/* Object Title & Quick Actions */}
      <div className="p-3 border-b border-[#282828] flex items-center justify-between bg-[#1A1A1A]">
        <div className="flex items-center gap-2">
          <span className="font-bold text-[#EEE] truncate max-w-[120px]">{selectedObject.name}</span>
          <span className="text-[9px] uppercase px-1 py-0.5 bg-[#2A2A2A] text-[#3B82F6] rounded font-mono">
            {selectedObject.type}
          </span>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => onUpdateObject(selectedObject.id, { locked: !selectedObject.locked })}
            className="p-1 hover:bg-[#2A2A2A] text-[#888] hover:text-[#FFF] rounded"
            title={selectedObject.locked ? 'Unlock' : 'Lock'}
          >
            {selectedObject.locked ? <Lock className="w-3.5 h-3.5 text-[#F59E0B]" /> : <Unlock className="w-3.5 h-3.5" />}
          </button>
          <button
            onClick={() => onDuplicateObject(selectedObject.id)}
            className="p-1 hover:bg-[#2A2A2A] text-[#888] hover:text-[#FFF] rounded"
            title="Duplicate (⌘D)"
          >
            <Copy className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onDeleteObject(selectedObject.id)}
            className="p-1 hover:bg-[#2A2A2A] text-[#888] hover:text-[#EF4444] rounded"
            title="Delete (Backspace)"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* TAB 1: TRANSFORM & ALIGNMENT */}
      {activeTab === 'properties' && (
        <div className="p-3 space-y-4">
          {/* Alignment Tools */}
          <div>
            <div className="text-[10px] uppercase font-bold text-[#666] tracking-wider mb-2">Align & Distribute</div>
            <div className="grid grid-cols-6 gap-1 bg-[#141414] p-1 border border-[#2E2E2E] rounded-[2px]">
              <button onClick={() => onAlign('left')} className="p-1 hover:bg-[#2A2A2A] text-[#AAA] hover:text-[#FFF] flex justify-center" title="Align Left">
                <AlignLeft className="w-3.5 h-3.5" />
              </button>
              <button onClick={() => onAlign('center')} className="p-1 hover:bg-[#2A2A2A] text-[#AAA] hover:text-[#FFF] flex justify-center" title="Align Horizontal Center">
                <AlignCenter className="w-3.5 h-3.5" />
              </button>
              <button onClick={() => onAlign('right')} className="p-1 hover:bg-[#2A2A2A] text-[#AAA] hover:text-[#FFF] flex justify-center" title="Align Right">
                <AlignRight className="w-3.5 h-3.5" />
              </button>
              <button onClick={() => onAlign('top')} className="p-1 hover:bg-[#2A2A2A] text-[#AAA] hover:text-[#FFF] flex justify-center" title="Align Top">
                <AlignJustify className="w-3.5 h-3.5 rotate-90" />
              </button>
              <button onClick={() => onAlign('middle')} className="p-1 hover:bg-[#2A2A2A] text-[#AAA] hover:text-[#FFF] flex justify-center" title="Align Vertical Middle">
                <AlignCenter className="w-3.5 h-3.5 rotate-90" />
              </button>
              <button onClick={() => onAlign('bottom')} className="p-1 hover:bg-[#2A2A2A] text-[#AAA] hover:text-[#FFF] flex justify-center" title="Align Bottom">
                <AlignLeft className="w-3.5 h-3.5 rotate-90" />
              </button>
            </div>
          </div>

          {/* Coordinate Transformations */}
          <div>
            <div className="text-[10px] uppercase font-bold text-[#666] tracking-wider mb-2">Coordinates & Transform</div>
            <div className="grid grid-cols-2 gap-2">
              <div className="flex items-center bg-[#141414] border border-[#2E2E2E] rounded px-2 py-1">
                <span className="text-[#666] font-mono mr-2">X</span>
                <input
                  type="number"
                  value={Math.round(selectedObject.x)}
                  onChange={e => onUpdateObject(selectedObject.id, { x: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-transparent text-[#EEE] font-mono outline-none"
                />
              </div>
              <div className="flex items-center bg-[#141414] border border-[#2E2E2E] rounded px-2 py-1">
                <span className="text-[#666] font-mono mr-2">Y</span>
                <input
                  type="number"
                  value={Math.round(selectedObject.y)}
                  onChange={e => onUpdateObject(selectedObject.id, { y: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-transparent text-[#EEE] font-mono outline-none"
                />
              </div>
              <div className="flex items-center bg-[#141414] border border-[#2E2E2E] rounded px-2 py-1">
                <span className="text-[#666] font-mono mr-2">W</span>
                <input
                  type="number"
                  value={Math.round(selectedObject.width)}
                  onChange={e => onUpdateObject(selectedObject.id, { width: parseFloat(e.target.value) || 1 })}
                  className="w-full bg-transparent text-[#EEE] font-mono outline-none"
                />
              </div>
              <div className="flex items-center bg-[#141414] border border-[#2E2E2E] rounded px-2 py-1">
                <span className="text-[#666] font-mono mr-2">H</span>
                <input
                  type="number"
                  value={Math.round(selectedObject.height)}
                  onChange={e => onUpdateObject(selectedObject.id, { height: parseFloat(e.target.value) || 1 })}
                  className="w-full bg-transparent text-[#EEE] font-mono outline-none"
                />
              </div>
              <div className="flex items-center bg-[#141414] border border-[#2E2E2E] rounded px-2 py-1 col-span-2">
                <span className="text-[#666] font-mono mr-2">Rotation</span>
                <input
                  type="number"
                  value={Math.round(selectedObject.rotation)}
                  onChange={e => onUpdateObject(selectedObject.id, { rotation: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-transparent text-[#EEE] font-mono outline-none"
                />
                <span className="text-[#666] text-[10px]">°</span>
              </div>
            </div>
          </div>

          {/* Boolean Operations (Constructive Solid Geometry) */}
          <div>
            <div className="text-[10px] uppercase font-bold text-[#666] tracking-wider mb-2">Boolean Geometry</div>
            <div className="grid grid-cols-4 gap-1">
              <button
                onClick={() => onBooleanOp('union')}
                className="py-1.5 bg-[#242424] hover:bg-[#3B82F6] hover:text-white rounded-[2px] text-center font-mono text-[10px] transition-colors"
              >
                Union
              </button>
              <button
                onClick={() => onBooleanOp('subtract')}
                className="py-1.5 bg-[#242424] hover:bg-[#3B82F6] hover:text-white rounded-[2px] text-center font-mono text-[10px] transition-colors"
              >
                Subtract
              </button>
              <button
                onClick={() => onBooleanOp('intersect')}
                className="py-1.5 bg-[#242424] hover:bg-[#3B82F6] hover:text-white rounded-[2px] text-center font-mono text-[10px] transition-colors"
              >
                Intersect
              </button>
              <button
                onClick={() => onBooleanOp('exclude')}
                className="py-1.5 bg-[#242424] hover:bg-[#3B82F6] hover:text-white rounded-[2px] text-center font-mono text-[10px] transition-colors"
              >
                Exclude
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: PARAMETRIC SHAPE CONTROLS */}
      {activeTab === 'parametric' && (
        <div className="p-3 space-y-4">
          {/* Star Parameters */}
          {selectedObject.type === 'star' && selectedObject.starParams && (
            <div className="space-y-3">
              <div className="text-[10px] uppercase font-bold text-[#666] tracking-wider">Star Geometry</div>
              <div>
                <div className="flex justify-between mb-1">
                  <span>Points</span>
                  <span className="font-mono text-[#3B82F6]">{selectedObject.starParams.points}</span>
                </div>
                <input
                  type="range"
                  min="3"
                  max="32"
                  value={selectedObject.starParams.points}
                  onChange={e =>
                    onUpdateObject(selectedObject.id, {
                      starParams: { ...selectedObject.starParams!, points: parseInt(e.target.value) },
                    })
                  }
                  className="w-full accent-[#3B82F6]"
                />
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span>Inner Radius Ratio</span>
                  <span className="font-mono text-[#3B82F6]">{selectedObject.starParams.innerRadius}</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="150"
                  value={selectedObject.starParams.innerRadius}
                  onChange={e =>
                    onUpdateObject(selectedObject.id, {
                      starParams: { ...selectedObject.starParams!, innerRadius: parseFloat(e.target.value) },
                    })
                  }
                  className="w-full accent-[#3B82F6]"
                />
              </div>
            </div>
          )}

          {/* Involute Gear Parameters */}
          {selectedObject.type === 'gear' && selectedObject.gearParams && (
            <div className="space-y-3">
              <div className="text-[10px] uppercase font-bold text-[#666] tracking-wider">Involute Gear Parameters</div>
              <div>
                <div className="flex justify-between mb-1">
                  <span>Teeth Count</span>
                  <span className="font-mono text-[#3B82F6]">{selectedObject.gearParams.teeth}</span>
                </div>
                <input
                  type="range"
                  min="4"
                  max="48"
                  value={selectedObject.gearParams.teeth}
                  onChange={e =>
                    onUpdateObject(selectedObject.id, {
                      gearParams: { ...selectedObject.gearParams!, teeth: parseInt(e.target.value) },
                    })
                  }
                  className="w-full accent-[#3B82F6]"
                />
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span>Tooth Depth</span>
                  <span className="font-mono text-[#3B82F6]">{selectedObject.gearParams.toothDepth}</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="50"
                  value={selectedObject.gearParams.toothDepth}
                  onChange={e =>
                    onUpdateObject(selectedObject.id, {
                      gearParams: { ...selectedObject.gearParams!, toothDepth: parseFloat(e.target.value) },
                    })
                  }
                  className="w-full accent-[#3B82F6]"
                />
              </div>
            </div>
          )}

          {/* Wave Parameters */}
          {selectedObject.type === 'wave' && selectedObject.waveParams && (
            <div className="space-y-3">
              <div className="text-[10px] uppercase font-bold text-[#666] tracking-wider">Harmonic Waveform</div>
              <div>
                <div className="flex justify-between mb-1">
                  <span>Frequency</span>
                  <span className="font-mono text-[#3B82F6]">{selectedObject.waveParams.frequency}</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="24"
                  value={selectedObject.waveParams.frequency}
                  onChange={e =>
                    onUpdateObject(selectedObject.id, {
                      waveParams: { ...selectedObject.waveParams!, frequency: parseInt(e.target.value) },
                    })
                  }
                  className="w-full accent-[#3B82F6]"
                />
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span>Amplitude</span>
                  <span className="font-mono text-[#3B82F6]">{selectedObject.waveParams.amplitude}</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="100"
                  value={selectedObject.waveParams.amplitude}
                  onChange={e =>
                    onUpdateObject(selectedObject.id, {
                      waveParams: { ...selectedObject.waveParams!, amplitude: parseFloat(e.target.value) },
                    })
                  }
                  className="w-full accent-[#3B82F6]"
                />
              </div>
            </div>
          )}

          {/* Typography Parameters */}
          {selectedObject.type === 'text' && selectedObject.typography && (
            <div className="space-y-3">
              <div className="text-[10px] uppercase font-bold text-[#666] tracking-wider">Typography Attributes</div>
              <div>
                <span className="text-[#888] block mb-1">Content</span>
                <input
                  type="text"
                  value={selectedObject.typography.text}
                  onChange={e =>
                    onUpdateObject(selectedObject.id, {
                      typography: { ...selectedObject.typography!, text: e.target.value },
                    })
                  }
                  className="w-full bg-[#141414] border border-[#2E2E2E] rounded p-1.5 text-[#FFF] outline-none"
                />
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span>Font Size</span>
                  <span className="font-mono text-[#3B82F6]">{selectedObject.typography.fontSize} pt</span>
                </div>
                <input
                  type="range"
                  min="8"
                  max="120"
                  value={selectedObject.typography.fontSize}
                  onChange={e =>
                    onUpdateObject(selectedObject.id, {
                      typography: { ...selectedObject.typography!, fontSize: parseInt(e.target.value) },
                    })
                  }
                  className="w-full accent-[#3B82F6]"
                />
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: FILL & STROKE STYLE */}
      {activeTab === 'style' && (
        <div className="p-3 space-y-4">
          {/* Fill Section */}
          <div>
            <div className="text-[10px] uppercase font-bold text-[#666] tracking-wider mb-2">Fill Palette</div>
            <div className="flex items-center gap-2 mb-2">
              <input
                type="color"
                value={selectedObject.style.fillColor}
                onChange={e => updateStyle({ fillColor: e.target.value, fillType: 'solid' })}
                className="w-8 h-8 rounded border border-[#333] cursor-pointer bg-transparent"
              />
              <input
                type="text"
                value={selectedObject.style.fillColor}
                onChange={e => updateStyle({ fillColor: e.target.value })}
                className="flex-1 bg-[#141414] border border-[#2E2E2E] rounded px-2 py-1 font-mono uppercase text-[#EEE]"
              />
              <button
                onClick={() => updateStyle({ fillType: selectedObject.style.fillType === 'none' ? 'solid' : 'none' })}
                className={`px-2 py-1 rounded text-[10px] border ${
                  selectedObject.style.fillType === 'none' ? 'bg-[#3B82F6] text-white border-[#3B82F6]' : 'border-[#333] text-[#888]'
                }`}
              >
                None
              </button>
            </div>
          </div>

          {/* Stroke Section */}
          <div>
            <div className="text-[10px] uppercase font-bold text-[#666] tracking-wider mb-2">Stroke & Outline</div>
            <div className="flex items-center gap-2 mb-2">
              <input
                type="color"
                value={selectedObject.style.strokeColor}
                onChange={e => updateStyle({ strokeColor: e.target.value })}
                className="w-8 h-8 rounded border border-[#333] cursor-pointer bg-transparent"
              />
              <input
                type="text"
                value={selectedObject.style.strokeColor}
                onChange={e => updateStyle({ strokeColor: e.target.value })}
                className="flex-1 bg-[#141414] border border-[#2E2E2E] rounded px-2 py-1 font-mono uppercase text-[#EEE]"
              />
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[#888]">Width</span>
              <input
                type="number"
                min="0"
                max="50"
                step="0.5"
                value={selectedObject.style.strokeWidth}
                onChange={e => updateStyle({ strokeWidth: parseFloat(e.target.value) || 0 })}
                className="w-20 bg-[#141414] border border-[#2E2E2E] rounded px-2 py-1 font-mono text-[#EEE]"
              />
              <span className="text-[#666] text-[10px]">px</span>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: R SOURCE CODE */}
      {activeTab === 'r_code' && (
        <div className="p-3">
          <div className="text-[10px] uppercase font-bold text-[#666] tracking-wider mb-2">Generated R Vector Call</div>
          <pre className="p-2 bg-[#101010] border border-[#282828] rounded-[2px] font-mono text-[10px] text-[#A3E635] overflow-x-auto whitespace-pre-wrap leading-relaxed">
{`# R Object Definition
obj <- aard_${selectedObject.type}(
  doc,
  id = "${selectedObject.id}",
  x = ${Math.round(selectedObject.x)},
  y = ${Math.round(selectedObject.y)},
  width = ${Math.round(selectedObject.width)},
  height = ${Math.round(selectedObject.height)},
  fill = "${selectedObject.style.fillColor}",
  stroke = "${selectedObject.style.strokeColor}",
  stroke_width = ${selectedObject.style.strokeWidth}
)`}
          </pre>
        </div>
      )}
    </aside>
  );
};
