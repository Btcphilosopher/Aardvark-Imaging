'use client';

import React, { useRef, useState, useEffect, useCallback } from 'react';
import { 
  AardDocument, 
  AardObject, 
  ToolType, 
  Point2D, 
  BézierNode 
} from '@/lib/aardvark/types';
import { objectToPath, nodesToPathString } from '@/lib/aardvark/geometry';
import { snapPointToGrid, screenToCanvas, canvasToScreen } from '@/lib/aardvark/transforms';

interface AardvarkCanvasProps {
  document: AardDocument;
  activeTool: ToolType;
  selectedIds: string[];
  onSelectObject: (id: string, multi?: boolean) => void;
  onClearSelection: () => void;
  onUpdateObject: (id: string, partial: Partial<AardObject>) => void;
  onAddObject: (obj: AardObject) => void;
  zoom: number;
  setZoom: (z: number | ((prev: number) => number)) => void;
  pan: Point2D;
  setPan: (p: Point2D | ((prev: Point2D) => Point2D)) => void;
  selectedNodeIndex: number | null;
  setSelectedNodeIndex: (idx: number | null) => void;
}

export const AardvarkCanvas: React.FC<AardvarkCanvasProps> = ({
  document: doc,
  activeTool,
  selectedIds,
  onSelectObject,
  onClearSelection,
  onUpdateObject,
  onAddObject,
  zoom,
  setZoom,
  pan,
  setPan,
  selectedNodeIndex,
  setSelectedNodeIndex,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState<Point2D>({ x: 0, y: 0 });

  // Creation State
  const [isCreating, setIsCreating] = useState(false);
  const [createStart, setCreateStart] = useState<Point2D>({ x: 0, y: 0 });
  const [currentMousePos, setCurrentMousePos] = useState<Point2D>({ x: 0, y: 0 });

  // Transformation Handle Dragging State
  const [dragHandle, setDragHandle] = useState<string | null>(null);
  const [dragStartObj, setDragStartObj] = useState<AardObject | null>(null);

  // Pen tool temp nodes
  const [penNodes, setPenNodes] = useState<BézierNode[]>([]);

  const activeArtboard = doc.artboards.find(a => a.id === doc.activeArtboardId) || doc.artboards[0] || {
    x: 50,
    y: 50,
    width: 800,
    height: 600,
    background: '#121212',
    name: 'Artboard 1',
  };

  const selectedObjects = doc.objects.filter(o => selectedIds.includes(o.id));
  const primarySelected = selectedObjects[0] || null;

  // Handle Wheel Zoom & Pan
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    if (e.ctrlKey || e.metaKey) {
      // Zoom
      const zoomFactor = e.deltaY > 0 ? 0.9 : 1.1;
      setZoom(z => Math.max(0.05, Math.min(32, z * zoomFactor)));
    } else {
      // Pan
      setPan(p => ({
        x: p.x - e.deltaX,
        y: p.y - e.deltaY,
      }));
    }
  };

  // Convert mouse event to document/artboard coordinates
  const getCanvasCoordinates = (e: React.MouseEvent): Point2D => {
    if (!containerRef.current) return { x: 0, y: 0 };
    const rect = containerRef.current.getBoundingClientRect();
    const screenX = e.clientX - rect.left;
    const screenY = e.clientY - rect.top;
    const raw = screenToCanvas({ x: screenX, y: screenY }, pan, zoom);

    if (doc.grid.enabled && doc.grid.snap) {
      return snapPointToGrid(raw, doc.grid.size);
    }
    return raw;
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    // Pan Tool or Middle Click or Space/Shift Click
    if (activeTool === 'pan' || e.button === 1) {
      setIsPanning(true);
      setPanStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
      return;
    }

    const pos = getCanvasCoordinates(e);

    // Pen Tool Drawing
    if (activeTool === 'pen') {
      const newNode: BézierNode = {
        point: { x: pos.x, y: pos.y },
        handleIn: { x: pos.x, y: pos.y },
        handleOut: { x: pos.x, y: pos.y },
        type: 'smooth',
      };
      setPenNodes(prev => [...prev, newNode]);
      return;
    }

    // Shape Creation Initiation
    if (['rect', 'ellipse', 'star', 'gear', 'spiral', 'wave', 'polygon', 'arrow', 'text'].includes(activeTool)) {
      setIsCreating(true);
      setCreateStart(pos);
      setCurrentMousePos(pos);
      return;
    }

    // Clicked background in selection tool
    if (activeTool === 'select' && (e.target as HTMLElement).tagName === 'svg') {
      if (!e.shiftKey) {
        onClearSelection();
      }
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isPanning) {
      setPan({
        x: e.clientX - panStart.x,
        y: e.clientY - panStart.y,
      });
      return;
    }

    const pos = getCanvasCoordinates(e);
    setCurrentMousePos(pos);

    // If dragging a transform handle on selected object
    if (dragHandle && primarySelected && dragStartObj) {
      const dx = pos.x - createStart.x;
      const dy = pos.y - createStart.y;

      if (dragHandle === 'se') {
        onUpdateObject(primarySelected.id, {
          width: Math.max(10, dragStartObj.width + dx),
          height: Math.max(10, dragStartObj.height + dy),
        });
      } else if (dragHandle === 'move') {
        onUpdateObject(primarySelected.id, {
          x: dragStartObj.x + dx,
          y: dragStartObj.y + dy,
        });
      } else if (dragHandle === 'rot') {
        const cx = primarySelected.x + primarySelected.width / 2;
        const cy = primarySelected.y + primarySelected.height / 2;
        const angleRad = Math.atan2(pos.y - cy, pos.x - cx);
        const angleDeg = (angleRad * 180) / Math.PI;
        onUpdateObject(primarySelected.id, { rotation: Math.round(angleDeg) });
      }
    }
  };

  const handleMouseUp = () => {
    if (isPanning) {
      setIsPanning(false);
      return;
    }

    if (dragHandle) {
      setDragHandle(null);
      setDragStartObj(null);
      return;
    }

    // Finalize shape creation
    if (isCreating) {
      setIsCreating(false);
      const width = Math.abs(currentMousePos.x - createStart.x) || 120;
      const height = Math.abs(currentMousePos.y - createStart.y) || 120;
      const x = Math.min(createStart.x, currentMousePos.x);
      const y = Math.min(createStart.y, currentMousePos.y);

      const newId = `obj_${Date.now()}`;
      const defaultStyle = {
        fillType: 'solid' as const,
        fillColor: '#3B82F6',
        fillOpacity: 1,
        strokeColor: '#1D4ED8',
        strokeWidth: 1.5,
        strokeOpacity: 1,
        strokeCap: 'round' as const,
        strokeJoin: 'round' as const,
        strokeMiterLimit: 4,
        strokeDashArray: [],
        strokeDashOffset: 0,
        strokeAlign: 'center' as const,
        blendMode: 'normal' as const,
      };

      const baseObj: AardObject = {
        id: newId,
        name: `${activeTool.toUpperCase()} ${doc.objects.length + 1}`,
        type: activeTool as any,
        artboardId: activeArtboard.id,
        layerId: doc.activeLayerId,
        x,
        y,
        width,
        height,
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        skewX: 0,
        skewY: 0,
        pivotX: 0.5,
        pivotY: 0.5,
        opacity: 1,
        visible: true,
        locked: false,
        zIndex: doc.objects.length + 1,
        style: defaultStyle,
      };

      // Tool specific params
      if (activeTool === 'star') {
        baseObj.starParams = { points: 5, innerRadius: Math.min(width, height) * 0.25, outerRadius: Math.min(width, height) * 0.5, roundness: 0 };
      } else if (activeTool === 'gear') {
        baseObj.gearParams = { teeth: 12, innerRadius: width * 0.3, outerRadius: width * 0.48, toothDepth: 16, holeRadius: 18, pressureAngle: 20 };
      } else if (activeTool === 'spiral') {
        baseObj.spiralParams = { turns: 4, outerRadius: width * 0.48, decay: 0.1, innerRadius: 0, type: 'golden' };
        baseObj.style.fillType = 'none';
      } else if (activeTool === 'wave') {
        baseObj.waveParams = { frequency: 4, amplitude: 25, phase: 0, type: 'sine', harmonics: 1 };
        baseObj.style.fillType = 'none';
      } else if (activeTool === 'text') {
        baseObj.typography = {
          text: 'Vector Typography',
          fontFamily: 'Inter',
          fontSize: 28,
          fontWeight: 700,
          fontStyle: 'normal',
          letterSpacing: 0,
          lineHeight: 1.2,
          textAlign: 'left',
        };
        baseObj.style.strokeWidth = 0;
      }

      onAddObject(baseObj);
      onSelectObject(newId);
    }
  };

  // Render Grid Lines
  const renderGrid = () => {
    if (!doc.grid.enabled) return null;
    const size = doc.grid.size;
    const gridCols = Math.ceil(activeArtboard.width / size);
    const gridRows = Math.ceil(activeArtboard.height / size);

    const lines = [];
    // Vertical lines
    for (let i = 0; i <= gridCols; i++) {
      lines.push(
        <line
          key={`v_${i}`}
          x1={i * size}
          y1={0}
          x2={i * size}
          y2={activeArtboard.height}
          stroke={doc.grid.color}
          strokeWidth={i % 5 === 0 ? 0.8 : 0.4}
          opacity={doc.grid.opacity}
        />
      );
    }
    // Horizontal lines
    for (let j = 0; j <= gridRows; j++) {
      lines.push(
        <line
          key={`h_${j}`}
          x1={0}
          y1={j * size}
          x2={activeArtboard.width}
          y2={j * size}
          stroke={doc.grid.color}
          strokeWidth={j % 5 === 0 ? 0.8 : 0.4}
          opacity={doc.grid.opacity}
        />
      );
    }
    return <g className="grid-layer pointer-events-none">{lines}</g>;
  };

  return (
    <div
      ref={containerRef}
      onWheel={handleWheel}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      className={`relative flex-1 h-full bg-[#0D0D0D] overflow-hidden select-none ${
        activeTool === 'pan' ? 'cursor-grab active:cursor-grabbing' : 'cursor-crosshair'
      }`}
    >
      {/* Canvas SVG Viewport */}
      <svg
        suppressHydrationWarning
        className="w-full h-full block"
        style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
          transformOrigin: '0 0',
        }}
      >
        <defs>
          {/* Gradients */}
          {doc.gradients.map(grad => (
            <linearGradient key={grad.id} id={grad.id} x1={grad.startX} y1={grad.startY} x2={grad.endX} y2={grad.endY}>
              {grad.stops.map((s, i) => (
                <stop key={i} offset={`${s.offset * 100}%`} stopColor={s.color} stopOpacity={s.opacity} />
              ))}
            </linearGradient>
          ))}
        </defs>

        {/* Artboard Shadow and Bounds */}
        <rect
          x={0}
          y={0}
          width={activeArtboard.width}
          height={activeArtboard.height}
          fill={activeArtboard.background}
          className="shadow-2xl"
        />

        {/* Technical Grid */}
        {renderGrid()}

        {/* Render Vector Objects */}
        {doc.objects
          .slice()
          .sort((a, b) => a.zIndex - b.zIndex)
          .map(obj => {
            if (!obj.visible) return null;
            const isSelected = selectedIds.includes(obj.id);

            let fill = obj.style.fillType === 'none' ? 'none' : obj.style.fillColor;
            if (obj.style.fillType === 'linear_gradient' && obj.style.gradientId) {
              fill = `url(#${obj.style.gradientId})`;
            }

            const stroke = obj.style.strokeWidth > 0 ? obj.style.strokeColor : 'none';
            const strokeDash = obj.style.strokeDashArray.length > 0 ? obj.style.strokeDashArray.join(',') : undefined;

            const transform = `rotate(${obj.rotation}, ${obj.x + obj.width * obj.pivotX}, ${obj.y + obj.height * obj.pivotY})`;

            // Text Object
            if (obj.type === 'text' && obj.typography) {
              return (
                <g
                  key={obj.id}
                  transform={transform}
                  onClick={e => {
                    e.stopPropagation();
                    onSelectObject(obj.id, e.shiftKey);
                  }}
                  className="cursor-pointer"
                >
                  <text
                    x={obj.x}
                    y={obj.y + (obj.typography.fontSize || 20)}
                    fontFamily={obj.typography.fontFamily}
                    fontSize={obj.typography.fontSize}
                    fontWeight={obj.typography.fontWeight}
                    letterSpacing={obj.typography.letterSpacing}
                    fill={fill}
                    opacity={obj.opacity}
                  >
                    {obj.typography.text}
                  </text>
                </g>
              );
            }

            // Dimension Object
            if (obj.type === 'dimension' && obj.dimensionParams) {
              const p = obj.dimensionParams;
              return (
                <g
                  key={obj.id}
                  onClick={e => {
                    e.stopPropagation();
                    onSelectObject(obj.id, e.shiftKey);
                  }}
                  className="cursor-pointer font-mono"
                >
                  <line x1={p.p1.x} y1={p.p1.y} x2={p.p2.x} y2={p.p2.y} stroke={obj.style.strokeColor} strokeWidth={obj.style.strokeWidth} />
                  <line x1={p.p1.x} y1={p.p1.y - p.offset} x2={p.p1.x} y2={p.p1.y + p.offset} stroke={obj.style.strokeColor} strokeWidth={0.8} />
                  <line x1={p.p2.x} y1={p.p2.y - p.offset} x2={p.p2.x} y2={p.p2.y + p.offset} stroke={obj.style.strokeColor} strokeWidth={0.8} />
                  <text
                    x={(p.p1.x + p.p2.x) / 2}
                    y={(p.p1.y + p.p2.y) / 2 - 6}
                    fill={obj.style.strokeColor}
                    fontSize={10}
                    textAnchor="middle"
                  >
                    {p.customLabel || `${Math.round(Math.hypot(p.p2.x - p.p1.x, p.p2.y - p.p1.y))} ${p.unit}`}
                  </text>
                </g>
              );
            }

            // Geometry Paths
            const pathData = objectToPath(obj);
            const d = pathData.nodes ? nodesToPathString(pathData.nodes, pathData.closed) : '';

            return (
              <g
                key={obj.id}
                transform={transform}
                onClick={e => {
                  e.stopPropagation();
                  onSelectObject(obj.id, e.shiftKey);
                }}
                className="cursor-pointer"
              >
                <path
                  d={d}
                  fill={fill}
                  stroke={stroke}
                  strokeWidth={obj.style.strokeWidth}
                  strokeDasharray={strokeDash}
                  strokeLinecap={obj.style.strokeCap}
                  strokeLinejoin={obj.style.strokeJoin}
                  opacity={obj.opacity}
                />
              </g>
            );
          })}

        {/* Selected Object Bounding Box & Transformation Gizmo */}
        {primarySelected && activeTool === 'select' && (
          <g className="selection-gizmo pointer-events-auto">
            {/* Box frame */}
            <rect
              x={primarySelected.x}
              y={primarySelected.y}
              width={primarySelected.width}
              height={primarySelected.height}
              fill="none"
              stroke="#3B82F6"
              strokeWidth={1 / zoom}
              strokeDasharray="4 3"
            />
            {/* Corner Handle SE */}
            <rect
              x={primarySelected.x + primarySelected.width - 4 / zoom}
              y={primarySelected.y + primarySelected.height - 4 / zoom}
              width={8 / zoom}
              height={8 / zoom}
              fill="#FFFFFF"
              stroke="#3B82F6"
              strokeWidth={1.5 / zoom}
              className="cursor-nwse-resize"
              onMouseDown={e => {
                e.stopPropagation();
                setDragHandle('se');
                setDragStartObj({ ...primarySelected });
                setCreateStart(getCanvasCoordinates(e));
              }}
            />
            {/* Center Translation Gizmo */}
            <circle
              cx={primarySelected.x + primarySelected.width / 2}
              cy={primarySelected.y + primarySelected.height / 2}
              r={4 / zoom}
              fill="#3B82F6"
              className="cursor-move"
              onMouseDown={e => {
                e.stopPropagation();
                setDragHandle('move');
                setDragStartObj({ ...primarySelected });
                setCreateStart(getCanvasCoordinates(e));
              }}
            />
            {/* Rotation Handle */}
            <line
              x1={primarySelected.x + primarySelected.width / 2}
              y1={primarySelected.y}
              x2={primarySelected.x + primarySelected.width / 2}
              y2={primarySelected.y - 18 / zoom}
              stroke="#3B82F6"
              strokeWidth={1 / zoom}
            />
            <circle
              cx={primarySelected.x + primarySelected.width / 2}
              cy={primarySelected.y - 18 / zoom}
              r={4 / zoom}
              fill="#FFFFFF"
              stroke="#3B82F6"
              strokeWidth={1.5 / zoom}
              className="cursor-grab"
              onMouseDown={e => {
                e.stopPropagation();
                setDragHandle('rot');
                setDragStartObj({ ...primarySelected });
              }}
            />
          </g>
        )}

        {/* Node Editor (When in Node tool) */}
        {primarySelected && activeTool === 'node' && (
          <g className="node-editor-gizmo">
            {objectToPath(primarySelected).nodes.map((n, i) => (
              <g key={i}>
                {/* Handle line in */}
                {n.handleIn && (
                  <line
                    x1={n.x}
                    y1={n.y}
                    x2={n.handleIn.x}
                    y2={n.handleIn.y}
                    stroke="#60A5FA"
                    strokeWidth={0.8 / zoom}
                  />
                )}
                {/* Node vertex square */}
                <rect
                  x={n.x - 3 / zoom}
                  y={n.y - 3 / zoom}
                  width={6 / zoom}
                  height={6 / zoom}
                  fill={selectedNodeIndex === i ? '#F59E0B' : '#FFFFFF'}
                  stroke="#2563EB"
                  strokeWidth={1.2 / zoom}
                  className="cursor-pointer"
                  onClick={e => {
                    e.stopPropagation();
                    setSelectedNodeIndex(i);
                  }}
                />
              </g>
            ))}
          </g>
        )}

        {/* Interactive Shape Creation Preview */}
        {isCreating && (
          <rect
            x={Math.min(createStart.x, currentMousePos.x)}
            y={Math.min(createStart.y, currentMousePos.y)}
            width={Math.abs(currentMousePos.x - createStart.x)}
            height={Math.abs(currentMousePos.y - createStart.y)}
            fill="rgba(59, 130, 246, 0.15)"
            stroke="#3B82F6"
            strokeWidth={1 / zoom}
            strokeDasharray="4 2"
          />
        )}
      </svg>

      {/* Floating Canvas HUD: Zoom + Pan Controls */}
      <div className="absolute bottom-3 left-3 flex items-center gap-1.5 px-2 py-1 bg-[#1A1A1A]/90 backdrop-blur-md border border-[#333] rounded-[3px] text-[10px] text-[#AAA] font-mono shadow-xl z-20">
        <button
          onClick={() => setZoom(z => Math.max(0.1, z - 0.25))}
          className="w-5 h-5 flex items-center justify-center hover:bg-[#2A2A2A] hover:text-[#FFF] rounded-[2px]"
        >
          -
        </button>
        <span className="w-12 text-center text-[#DDD] font-bold">{Math.round(zoom * 100)}%</span>
        <button
          onClick={() => setZoom(z => Math.min(10, z + 0.25))}
          className="w-5 h-5 flex items-center justify-center hover:bg-[#2A2A2A] hover:text-[#FFF] rounded-[2px]"
        >
          +
        </button>
        <div className="w-[1px] h-3.5 bg-[#333] mx-1" />
        <button
          onClick={() => {
            setZoom(1);
            setPan({ x: 100, y: 50 });
          }}
          className="px-1.5 py-0.5 hover:bg-[#2A2A2A] hover:text-[#FFF] rounded-[2px]"
        >
          Fit (100%)
        </button>
      </div>
    </div>
  );
};
