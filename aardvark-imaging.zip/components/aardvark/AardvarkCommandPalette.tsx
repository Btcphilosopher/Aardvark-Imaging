'use client';

import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Sparkles, 
  Download, 
  Terminal, 
  Layers, 
  Square, 
  Circle, 
  Star, 
  Settings2, 
  Activity, 
  Compass, 
  FolderOpen,
  X 
} from 'lucide-react';
import { AardDocument } from '@/lib/aardvark/types';
import { SAMPLE_PROJECTS } from '@/lib/aardvark/sample-projects';
import { exportDocumentToSvg, exportDocumentToPdf, triggerDownload } from '@/lib/aardvark/svg-pdf-export';

interface AardvarkCommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  document: AardDocument;
  onLoadProject: (doc: AardDocument) => void;
  onAddObject: (type: string) => void;
  onToggleConsole: () => void;
}

export const AardvarkCommandPalette: React.FC<AardvarkCommandPaletteProps> = ({
  isOpen,
  onClose,
  document: doc,
  onLoadProject,
  onAddObject,
  onToggleConsole,
}) => {
  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const commands = [
    {
      id: 'exp_svg',
      title: 'Export Document as Clean SVG',
      category: 'Export',
      icon: <Download className="w-4 h-4 text-[#3B82F6]" />,
      action: () => {
        const svg = exportDocumentToSvg(doc);
        triggerDownload(svg, `${doc.name.toLowerCase().replace(/\s+/g, '_')}.svg`, 'image/svg+xml');
        onClose();
      },
    },
    {
      id: 'exp_pdf',
      title: 'Export Vector PDF Print File',
      category: 'Export',
      icon: <Download className="w-4 h-4 text-[#60A5FA]" />,
      action: () => {
        const pdf = exportDocumentToPdf(doc);
        pdf.save(`${doc.name.toLowerCase().replace(/\s+/g, '_')}.pdf`);
        onClose();
      },
    },
    {
      id: 'toggle_repl',
      title: 'Toggle R Scripting Console',
      category: 'R Engine',
      icon: <Terminal className="w-4 h-4 text-[#A3E635]" />,
      action: () => {
        onToggleConsole();
        onClose();
      },
    },
    {
      id: 'add_star',
      title: 'Insert Parametric 5-Point Star',
      category: 'Insert',
      icon: <Star className="w-4 h-4 text-[#F59E0B]" />,
      action: () => {
        onAddObject('star');
        onClose();
      },
    },
    {
      id: 'add_gear',
      title: 'Insert Involute Gear',
      category: 'Insert',
      icon: <Settings2 className="w-4 h-4 text-[#10B981]" />,
      action: () => {
        onAddObject('gear');
        onClose();
      },
    },
    {
      id: 'add_wave',
      title: 'Insert Harmonic Wave',
      category: 'Insert',
      icon: <Activity className="w-4 h-4 text-[#A855F7]" />,
      action: () => {
        onAddObject('wave');
        onClose();
      },
    },
    ...SAMPLE_PROJECTS.map(p => ({
      id: `proj_${p.id}`,
      title: `Load Project: ${p.name}`,
      category: 'Sample Projects',
      icon: <FolderOpen className="w-4 h-4 text-[#3B82F6]" />,
      action: () => {
        onLoadProject(p.factory());
        onClose();
      },
    })),
  ];

  const filteredCommands = commands.filter(c =>
    c.title.toLowerCase().includes(query.toLowerCase()) ||
    c.category.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-start justify-center pt-20 p-4 select-none">
      <div className="w-full max-w-lg bg-[#181818] border border-[#333] shadow-2xl rounded-[4px] overflow-hidden flex flex-col text-[12px]">
        {/* Search Input Bar */}
        <div className="px-3 py-2.5 bg-[#1F1F1F] border-b border-[#333] flex items-center gap-2">
          <Search className="w-4 h-4 text-[#888]" />
          <input
            type="text"
            placeholder="Type a command or project name..."
            value={query}
            onChange={e => setQuery(e.target.value)}
            className="w-full bg-transparent text-[#EEE] placeholder-[#666] outline-none text-[12px]"
            autoFocus
          />
          <button onClick={onClose} className="p-1 hover:bg-[#2A2A2A] text-[#888] hover:text-[#FFF] rounded">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Command List */}
        <div className="max-h-80 overflow-y-auto p-1.5 space-y-1">
          {filteredCommands.length === 0 ? (
            <div className="p-4 text-center text-[#666] italic">No matching vector commands found</div>
          ) : (
            filteredCommands.map(cmd => (
              <button
                key={cmd.id}
                onClick={cmd.action}
                className="w-full px-3 py-2 hover:bg-[#2A2A2A] rounded-[2px] flex items-center justify-between text-left group transition-colors"
              >
                <div className="flex items-center gap-2.5">
                  {cmd.icon}
                  <span className="text-[#DDD] group-hover:text-white font-medium">{cmd.title}</span>
                </div>
                <span className="text-[9px] font-mono uppercase px-1.5 py-0.5 bg-[#222] text-[#888] rounded">
                  {cmd.category}
                </span>
              </button>
            ))
          )}
        </div>

        {/* Footer info */}
        <div className="px-3 py-1.5 bg-[#141414] border-t border-[#2A2A2A] flex justify-between text-[10px] text-[#666] font-mono">
          <span>Navigation: ↑ ↓ Enter</span>
          <span>AARDVARK Studio ⌘K</span>
        </div>
      </div>
    </div>
  );
};
