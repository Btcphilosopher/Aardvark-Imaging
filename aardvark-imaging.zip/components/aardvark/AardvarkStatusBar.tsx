'use client';

import React from 'react';
import { 
  Grid, 
  Magnet, 
  Cpu, 
  Activity, 
  MousePointer, 
  Maximize2 
} from 'lucide-react';
import { AardDocument } from '@/lib/aardvark/types';

interface AardvarkStatusBarProps {
  document: AardDocument;
  zoom: number;
  selectedIds: string[];
  onToggleGrid: () => void;
  onToggleSnap: () => void;
}

export const AardvarkStatusBar: React.FC<AardvarkStatusBarProps> = ({
  document: doc,
  zoom,
  selectedIds,
  onToggleGrid,
  onToggleSnap,
}) => {
  const activeArtboard = doc.artboards.find(a => a.id === doc.activeArtboardId) || doc.artboards[0];

  return (
    <footer className="h-6 bg-[#171717] border-t border-[#2A2A2A] flex items-center justify-between px-3 text-[10px] font-mono text-[#777] select-none z-30">
      {/* Left: Document & Selection Status */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-1.5 text-[#AAA]">
          <span className="w-2 h-2 rounded-full bg-blue-500" />
          <span>{doc.name}</span>
        </div>

        <div className="hidden sm:flex items-center gap-2">
          <span>Artboard:</span>
          <span className="text-[#CCC]">{activeArtboard?.width || 800} × {activeArtboard?.height || 600} {doc.units}</span>
        </div>

        <div className="flex items-center gap-2">
          <span>Selected:</span>
          <span className="text-[#3B82F6] font-bold">{selectedIds.length} object(s)</span>
        </div>
      </div>

      {/* Right: Grid, Snap, Zoom, R Engine Status */}
      <div className="flex items-center gap-3">
        {/* Toggle Grid */}
        <button
          onClick={onToggleGrid}
          className={`flex items-center gap-1 px-1.5 py-0.5 rounded-[2px] transition-colors ${
            doc.grid.enabled ? 'bg-[#2A2A2A] text-[#3B82F6]' : 'text-[#555] hover:text-[#AAA]'
          }`}
          title="Toggle Grid Display"
        >
          <Grid className="w-3 h-3" />
          <span>GRID {doc.grid.enabled ? 'ON' : 'OFF'}</span>
        </button>

        {/* Toggle Snap */}
        <button
          onClick={onToggleSnap}
          className={`flex items-center gap-1 px-1.5 py-0.5 rounded-[2px] transition-colors ${
            doc.grid.snap ? 'bg-[#2A2A2A] text-[#A3E635]' : 'text-[#555] hover:text-[#AAA]'
          }`}
          title="Toggle Grid Snap"
        >
          <Magnet className="w-3 h-3" />
          <span>SNAP {doc.grid.snap ? 'ON' : 'OFF'}</span>
        </button>

        <div className="hidden md:flex items-center gap-1 text-[#666]">
          <Cpu className="w-3 h-3" />
          <span>Bézier Precision: G2</span>
        </div>

        <div className="flex items-center gap-1 px-1.5 bg-[#111] border border-[#222] rounded text-[#A3E635]">
          <Activity className="w-3 h-3 animate-pulse" />
          <span>R 4.4.2 OK</span>
        </div>
      </div>
    </footer>
  );
};
