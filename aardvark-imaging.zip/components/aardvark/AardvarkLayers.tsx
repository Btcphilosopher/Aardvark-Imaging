'use client';

import React, { useState } from 'react';
import { 
  Layers as LayersIcon, 
  FolderPlus, 
  Eye, 
  EyeOff, 
  Lock, 
  Unlock, 
  MoveUp, 
  MoveDown, 
  Trash2, 
  Plus, 
  ChevronRight, 
  ChevronDown,
  Box,
  Type,
  Square,
  Circle,
  Star,
  Settings2,
  Activity,
  Compass
} from 'lucide-react';
import { AardDocument, AardObject, AardLayer } from '@/lib/aardvark/types';

interface AardvarkLayersProps {
  document: AardDocument;
  selectedIds: string[];
  onSelectObject: (id: string, multi?: boolean) => void;
  onUpdateObject: (id: string, partial: Partial<AardObject>) => void;
  onDeleteObject: (id: string) => void;
  onReorderObject: (id: string, direction: 'up' | 'down') => void;
  onAddLayer: (name: string) => void;
  onToggleLayerVisibility: (layerId: string) => void;
  onToggleLayerLock: (layerId: string) => void;
}

export const AardvarkLayers: React.FC<AardvarkLayersProps> = ({
  document: doc,
  selectedIds,
  onSelectObject,
  onUpdateObject,
  onDeleteObject,
  onReorderObject,
  onAddLayer,
  onToggleLayerVisibility,
  onToggleLayerLock,
}) => {
  const [collapsedLayers, setCollapsedLayers] = useState<Record<string, boolean>>({});

  const toggleLayerCollapse = (layerId: string) => {
    setCollapsedLayers(prev => ({ ...prev, [layerId]: !prev[layerId] }));
  };

  const getObjectIcon = (type: string) => {
    switch (type) {
      case 'rect': return <Square className="w-3.5 h-3.5 text-[#3B82F6]" />;
      case 'ellipse': return <Circle className="w-3.5 h-3.5 text-[#60A5FA]" />;
      case 'star': return <Star className="w-3.5 h-3.5 text-[#F59E0B]" />;
      case 'gear': return <Settings2 className="w-3.5 h-3.5 text-[#10B981]" />;
      case 'text': return <Type className="w-3.5 h-3.5 text-[#EC4899]" />;
      case 'wave': return <Activity className="w-3.5 h-3.5 text-[#A855F7]" />;
      case 'spiral': return <Compass className="w-3.5 h-3.5 text-[#38BDF8]" />;
      default: return <Box className="w-3.5 h-3.5 text-[#888]" />;
    }
  };

  return (
    <div className="w-64 bg-[#181818] border-r border-[#333] flex flex-col select-none text-[11px] text-[#CCC]">
      {/* Header */}
      <div className="h-9 px-3 bg-[#1F1F1F] border-b border-[#333] flex items-center justify-between font-medium">
        <div className="flex items-center gap-1.5 text-[#DDD]">
          <LayersIcon className="w-4 h-4 text-[#3B82F6]" />
          <span>Layers & Objects</span>
        </div>
        <button
          onClick={() => onAddLayer(`Layer ${doc.layers.length + 1}`)}
          className="p-1 hover:bg-[#2A2A2A] text-[#888] hover:text-[#FFF] rounded-[2px]"
          title="Create New Vector Layer"
        >
          <FolderPlus className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Layers Tree */}
      <div className="flex-1 overflow-y-auto p-1.5 space-y-1">
        {doc.layers.map(layer => {
          const layerObjects = doc.objects.filter(o => o.layerId === layer.id);
          const isCollapsed = collapsedLayers[layer.id];

          return (
            <div key={layer.id} className="rounded border border-[#262626] bg-[#141414] overflow-hidden">
              {/* Layer Header Row */}
              <div className="flex items-center justify-between px-2 py-1.5 bg-[#1C1C1C] hover:bg-[#222]">
                <div className="flex items-center gap-1.5 flex-1 min-w-0">
                  <button
                    onClick={() => toggleLayerCollapse(layer.id)}
                    className="p-0.5 hover:bg-[#2A2A2A] text-[#777] rounded"
                  >
                    {isCollapsed ? <ChevronRight className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                  </button>
                  <div
                    className="w-2 h-2 rounded-full flex-shrink-0"
                    style={{ backgroundColor: layer.color || '#3B82F6' }}
                  />
                  <span className="font-semibold text-[#DDD] truncate">{layer.name}</span>
                  <span className="text-[9px] font-mono text-[#666]">({layerObjects.length})</span>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => onToggleLayerVisibility(layer.id)}
                    className="p-0.5 text-[#777] hover:text-[#FFF]"
                  >
                    {layer.visible ? <Eye className="w-3 h-3 text-[#10B981]" /> : <EyeOff className="w-3 h-3" />}
                  </button>
                  <button
                    onClick={() => onToggleLayerLock(layer.id)}
                    className="p-0.5 text-[#777] hover:text-[#FFF]"
                  >
                    {layer.locked ? <Lock className="w-3 h-3 text-[#F59E0B]" /> : <Unlock className="w-3 h-3" />}
                  </button>
                </div>
              </div>

              {/* Objects inside Layer */}
              {!isCollapsed && (
                <div className="py-0.5 bg-[#121212]">
                  {layerObjects.length === 0 ? (
                    <div className="px-6 py-1.5 text-[10px] text-[#555] font-mono italic">
                      Empty layer
                    </div>
                  ) : (
                    layerObjects
                      .slice()
                      .sort((a, b) => b.zIndex - a.zIndex)
                      .map(obj => {
                        const isSelected = selectedIds.includes(obj.id);
                        return (
                          <div
                            key={obj.id}
                            onClick={e => onSelectObject(obj.id, e.shiftKey)}
                            className={`flex items-center justify-between px-2 pl-6 py-1.5 cursor-pointer transition-colors ${
                              isSelected
                                ? 'bg-[#3B82F6]/20 text-[#FFF] border-l-2 border-[#3B82F6]'
                                : 'hover:bg-[#1A1A1A] text-[#AAA]'
                            }`}
                          >
                            <div className="flex items-center gap-2 truncate">
                              {getObjectIcon(obj.type)}
                              <span className="truncate">{obj.name}</span>
                            </div>

                            <div className="flex items-center gap-1 opacity-0 hover:opacity-100 group-hover:opacity-100">
                              <button
                                onClick={e => {
                                  e.stopPropagation();
                                  onReorderObject(obj.id, 'up');
                                }}
                                className="p-0.5 hover:text-[#FFF]"
                                title="Raise Z-Index"
                              >
                                <MoveUp className="w-3 h-3" />
                              </button>
                              <button
                                onClick={e => {
                                  e.stopPropagation();
                                  onReorderObject(obj.id, 'down');
                                }}
                                className="p-0.5 hover:text-[#FFF]"
                                title="Lower Z-Index"
                              >
                                <MoveDown className="w-3 h-3" />
                              </button>
                              <button
                                onClick={e => {
                                  e.stopPropagation();
                                  onDeleteObject(obj.id);
                                }}
                                className="p-0.5 hover:text-[#EF4444]"
                                title="Delete"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>
                          </div>
                        );
                      })
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
