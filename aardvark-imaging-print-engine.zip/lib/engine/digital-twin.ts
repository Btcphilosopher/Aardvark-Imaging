/**
 * AARDVARK IMAGING PRINT ENGINE
 * Printer Digital Twin & Physics Telemetry Engine
 * Models print head kinematics, thermal states, vacuum platen, nozzle health, and wear analytics.
 */

import { DigitalTwinTelemetry, InkChannelName, PrinterModel } from './types';

export class PrinterDigitalTwin {
  private telemetry: DigitalTwinTelemetry;
  private isPrinting: boolean = false;
  private currentPass: number = 0;
  private totalPasses: number = 100;
  private carriageDir: number = 1; // 1 = right, -1 = left

  constructor(printer: PrinterModel) {
    this.telemetry = {
      printer_id: printer.printer_id,
      timestamp: new Date().toISOString(),
      carriage_position_mm: 120.0,
      carriage_velocity_mps: 0.0,
      head_temperature_c: 38.4,
      platen_vacuum_kpa: -1.8,
      drying_heater_c: 42.0,
      relative_humidity_percent: 48.5,
      ambient_temperature_c: 21.8,
      ink_levels_percent: {
        C: 84.0,
        M: 78.5,
        Y: 91.0,
        PK: 62.0,
        MK: 95.0,
        LC: 72.0,
        LM: 69.5,
        LK: 88.0,
        LLK: 94.0,
        OR: 81.0,
        GR: 87.5,
        V: 79.0,
        CO: 92.0,
      },
      nozzle_health_percent: {
        C: 100,
        M: 99.8,
        Y: 100,
        PK: 100,
        MK: 100,
        LC: 100,
        LM: 99.7,
        LK: 100,
        LLK: 100,
        OR: 100,
        GR: 100,
        V: 100,
        CO: 100,
      },
      paper_feed_position_mm: 45.2,
      total_print_hours: 842.5,
      maintenance_countdown_hours: 157.5,
      failure_risk_score: 0.04,
      active_warnings: [],
    };
  }

  public getTelemetry(): DigitalTwinTelemetry {
    return { ...this.telemetry };
  }

  public startJob(passesCount: number = 80) {
    this.isPrinting = true;
    this.currentPass = 0;
    this.totalPasses = passesCount;
    this.telemetry.carriage_velocity_mps = 1.2;
    this.telemetry.platen_vacuum_kpa = -2.3;
  }

  public stopJob() {
    this.isPrinting = false;
    this.telemetry.carriage_velocity_mps = 0.0;
    this.telemetry.platen_vacuum_kpa = -1.2;
    this.telemetry.carriage_position_mm = 0.0; // parked at capping station
  }

  /**
   * Advance physics simulation step by dt milliseconds
   */
  public stepSimulation(dtMs: number = 100): DigitalTwinTelemetry {
    this.telemetry.timestamp = new Date().toISOString();

    if (this.isPrinting) {
      // Move carriage back and forth across platen
      const maxWidth = 1118; // 44 inches
      const moveDistance = (this.telemetry.carriage_velocity_mps * 1000 * dtMs) / 1000;
      this.telemetry.carriage_position_mm += moveDistance * this.carriageDir;

      if (this.telemetry.carriage_position_mm >= maxWidth) {
        this.telemetry.carriage_position_mm = maxWidth;
        this.carriageDir = -1;
        this.currentPass++;
        this.telemetry.paper_feed_position_mm += 1.4; // 1.4mm step per pass
      } else if (this.telemetry.carriage_position_mm <= 0) {
        this.telemetry.carriage_position_mm = 0;
        this.carriageDir = 1;
        this.currentPass++;
        this.telemetry.paper_feed_position_mm += 1.4;
      }

      // Slightly increase head temp during active piezoelectric firing
      this.telemetry.head_temperature_c = Math.min(42.5, 38.0 + (this.currentPass / this.totalPasses) * 3.5);
      
      // Gradually consume ink
      for (const ch of Object.keys(this.telemetry.ink_levels_percent) as InkChannelName[]) {
        this.telemetry.ink_levels_percent[ch] = Math.max(0, this.telemetry.ink_levels_percent[ch] - 0.001);
      }

      if (this.currentPass >= this.totalPasses) {
        this.stopJob();
      }
    } else {
      // Idling at maintenance station
      this.telemetry.carriage_velocity_mps = 0.0;
      this.telemetry.head_temperature_c = Math.max(34.0, this.telemetry.head_temperature_c - 0.05);
    }

    return { ...this.telemetry };
  }
}
