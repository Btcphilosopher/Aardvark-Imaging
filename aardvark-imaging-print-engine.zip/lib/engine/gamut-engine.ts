/**
 * AARDVARK IMAGING PRINT ENGINE
 * Gamut Analysis & Mapping Engine
 */

import { rgbToLab, labToRgb, deltaE2000 } from './colour-science';
import { PaperProfile, RenderingIntent } from './types';

export interface GamutBoundaryModel {
  maxChromaAtLightness: (L: number, hueDeg: number) => number;
  minL: number;
  maxL: number;
}

/**
 * Creates an empirical gamut boundary model for a specific paper and printer ink profile.
 * Fine art baryta and gloss papers achieve high Dmax (low minL ~ 2.5 - 4) and wide chroma (~85).
 * Matte and cotton rag have higher minL (~12 - 16) and restricted chroma in cyan/greens (~55-65).
 */
export function createPaperGamutModel(paper: PaperProfile): GamutBoundaryModel {
  const minL = Math.max(2.0, 100 * Math.pow(10, -paper.black_point_dmax));
  const maxL = paper.paper_white_lab[0]; // e.g. 96.5

  return {
    minL,
    maxL,
    maxChromaAtLightness: (L: number, hueDeg: number): number => {
      if (L <= minL || L >= maxL) return 0;

      // Peak chroma typically occurs between L = 45 to 65 depending on hue
      // In yellow (hue ~90), peak chroma is at high L ~ 85. In blue (hue ~270), peak is at L ~ 35.
      const rad = (hueDeg * Math.PI) / 180;
      const peakL = 50 + 25 * Math.sin(rad - 0.5); // Yellow peak higher, blue peak lower

      const baseMaxChroma = paper.type === 'baryta' || paper.type === 'glossy' || paper.type === 'luster'
        ? 88.0
        : paper.type === 'cotton rag' || paper.type === 'matte'
        ? 64.0
        : 72.0;

      // Parabolic falloff towards minL and maxL
      const distFromPeak = Math.abs(L - peakL) / (peakL < L ? maxL - peakL : peakL - minL);
      const factor = Math.max(0, 1 - Math.pow(distFromPeak, 1.8));

      // Hue specific adjustments (inks have asymmetric gamut lobes: Orange/Red wide, Cyan moderate)
      const hueScale = 1.0 + 0.15 * Math.cos(rad) + 0.12 * Math.sin(rad * 2);
      return baseMaxChroma * factor * hueScale;
    },
  };
}

export interface GamutCheckResult {
  inGamut: boolean;
  nearBoundary: boolean;
  distanceToGamut: number; // Delta E
  sourceLab: [number, number, number];
  projectedLab: [number, number, number];
}

/**
 * Check if a Lab colour is inside the paper gamut boundary
 */
export function checkColourGamut(
  lab: [number, number, number],
  gamutModel: GamutBoundaryModel
): GamutCheckResult {
  const [L, a, b] = lab;
  const chroma = Math.sqrt(a * a + b * b);
  let hue = (Math.atan2(b, a) * 180) / Math.PI;
  if (hue < 0) hue += 360;

  const maxChroma = gamutModel.maxChromaAtLightness(L, hue);
  const clampedL = Math.max(gamutModel.minL, Math.min(gamutModel.maxL, L));

  if (L < gamutModel.minL || L > gamutModel.maxL || chroma > maxChroma) {
    // Out of gamut
    const projectedChroma = Math.min(chroma, maxChroma);
    const rad = (hue * Math.PI) / 180;
    const projA = projectedChroma * Math.cos(rad);
    const projB = projectedChroma * Math.sin(rad);
    const projectedLab: [number, number, number] = [clampedL, projA, projB];
    const distance = deltaE2000(lab, projectedLab);

    return {
      inGamut: false,
      nearBoundary: distance < 2.0,
      distanceToGamut: distance,
      sourceLab: lab,
      projectedLab,
    };
  }

  // Check if near boundary (within 10% of maximum chroma)
  const isNear = chroma > maxChroma * 0.9;
  return {
    inGamut: true,
    nearBoundary: isNear,
    distanceToGamut: 0,
    sourceLab: lab,
    projectedLab: lab,
  };
}

/**
 * Gamut Mapping using Perceptual Soft Compression vs Relative Colorimetric Clipping
 */
export function mapToGamut(
  lab: [number, number, number],
  gamutModel: GamutBoundaryModel,
  intent: RenderingIntent = 'RELATIVE_COLORIMETRIC'
): [number, number, number] {
  const check = checkColourGamut(lab, gamutModel);
  if (check.inGamut && intent === 'RELATIVE_COLORIMETRIC') {
    return lab;
  }

  const [L, a, b] = lab;
  const chroma = Math.sqrt(a * a + b * b);
  let hue = (Math.atan2(b, a) * 180) / Math.PI;
  if (hue < 0) hue += 360;
  const rad = (hue * Math.PI) / 180;

  const maxChroma = gamutModel.maxChromaAtLightness(L, hue);
  const clampedL = Math.max(gamutModel.minL, Math.min(gamutModel.maxL, L));

  if (intent === 'PERCEPTUAL') {
    // Knee compression curve: keep 0-70% linear, compress 70-130% into 70-100%
    const knee = maxChroma * 0.7;
    let compressedChroma = chroma;
    if (chroma > knee) {
      const over = chroma - knee;
      const headroom = maxChroma - knee;
      compressedChroma = knee + headroom * Math.tanh(over / headroom);
    }
    return [clampedL, compressedChroma * Math.cos(rad), compressedChroma * Math.sin(rad)];
  }

  // Relative Colorimetric: hard clip chroma to boundary, clip L to media black/white
  return check.projectedLab;
}
