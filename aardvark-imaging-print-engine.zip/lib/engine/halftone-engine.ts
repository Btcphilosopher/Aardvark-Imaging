/**
 * AARDVARK IMAGING PRINT ENGINE
 * Halftoning, Screening & Microdot Physics Engine
 */

import { HalftoneMethod } from './types';

// Bayer 8x8 matrix normalized to 0.0 - 1.0
export const BAYER_8X8: number[][] = [
  [ 0, 32,  8, 40,  2, 34, 10, 42],
  [48, 16, 56, 24, 50, 18, 58, 26],
  [12, 44,  4, 36, 14, 46,  6, 38],
  [60, 28, 52, 20, 62, 30, 54, 22],
  [ 3, 35, 11, 43,  1, 33,  9, 41],
  [51, 19, 59, 27, 49, 17, 57, 25],
  [15, 47,  7, 39, 13, 45,  5, 37],
  [63, 31, 55, 23, 61, 29, 53, 21],
].map(row => row.map(v => (v + 0.5) / 64));

// Blue Noise 16x16 reference tile (high-frequency spatial dispersion)
export const BLUE_NOISE_16X16: number[][] = Array.from({ length: 16 }, (_, y) =>
  Array.from({ length: 16 }, (_, x) => {
    // Deterministic pseudo blue noise frequency distribution
    const v = (Math.sin(x * 12.9898 + y * 78.233) * 43758.5453) % 1;
    return Math.abs(v);
  })
);

/**
 * Dot Gain compensation using Yule-Nielsen equation:
 * Physical Dot Area = [1 - 10^(-D / n)] / [1 - 10^(-D_max / n)]
 * Compares nominal tone vs expanded dot footprint on paper fibers
 */
export function compensateDotGain(
  nominalTone: number, // 0.0 to 1.0
  dotGainPercentage: number = 18.0, // e.g. 18% dot gain at 50% tone
  nFactor: number = 1.7 // Yule-Nielsen optical factor
): number {
  if (nominalTone <= 0) return 0;
  if (nominalTone >= 1) return 1;

  // Maximum dot gain typically peaks near 50%
  const gainCurve = Math.sin(nominalTone * Math.PI);
  const gain = (dotGainPercentage / 100) * gainCurve;

  // Pre-compensate tone downwards so when the physical ink expands, the target tone is achieved
  const compensated = nominalTone - gain * 0.85;
  return Math.max(0, Math.min(1, compensated));
}

/**
 * Screen angle rotation for clustered dot AM screening
 */
export function clusteredDotScreen(
  intensity: number,
  x: number,
  y: number,
  screenAngleDeg: number,
  screenFrequencyLpi: number = 175,
  dpi: number = 2880
): boolean {
  const rad = (screenAngleDeg * Math.PI) / 180;
  const period = dpi / screenFrequencyLpi;

  // Rotate coordinates
  const u = (x * Math.cos(rad) - y * Math.sin(rad)) / period;
  const v = (x * Math.sin(rad) + y * Math.cos(rad)) / period;

  // Distance from dot center within grid cell
  const du = Math.abs((u % 1) - 0.5);
  const dv = Math.abs((v % 1) - 0.5);
  const distSq = du * du + dv * dv;

  // Threshold radius based on intensity
  const targetRadiusSq = (intensity * 0.5) / Math.PI;
  return distSq <= targetRadiusSq;
}

export interface HalftoneResult {
  bitmap: Uint8Array; // 1 for dot present, 0 for no dot
  width: number;
  height: number;
  totalDotsPlaced: number;
  dotDensityRatio: number;
}

/**
 * Dither an intensity 2D buffer into a printer binary microdot mask
 */
export function ditherChannel(
  channelData: Float32Array,
  width: number,
  height: number,
  method: HalftoneMethod,
  dotGainCompensation: boolean = true,
  screenAngleDeg: number = 45
): HalftoneResult {
  const bitmap = new Uint8Array(width * height);
  let totalDots = 0;

  if (method === 'ORDERED_BAYER_8X8') {
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const idx = y * width + x;
        let tone = channelData[idx];
        if (dotGainCompensation) tone = compensateDotGain(tone);

        const threshold = BAYER_8X8[y % 8][x % 8];
        if (tone > threshold) {
          bitmap[idx] = 1;
          totalDots++;
        }
      }
    }
  } else if (method === 'BLUE_NOISE_STOCHASTIC') {
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const idx = y * width + x;
        let tone = channelData[idx];
        if (dotGainCompensation) tone = compensateDotGain(tone);

        const threshold = BLUE_NOISE_16X16[y % 16][x % 16];
        if (tone > threshold) {
          bitmap[idx] = 1;
          totalDots++;
        }
      }
    }
  } else if (method === 'CLUSTERED_DOT_AM') {
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const idx = y * width + x;
        let tone = channelData[idx];
        if (dotGainCompensation) tone = compensateDotGain(tone);

        if (clusteredDotScreen(tone, x, y, screenAngleDeg)) {
          bitmap[idx] = 1;
          totalDots++;
        }
      }
    }
  } else {
    // Default to Floyd-Steinberg Error Diffusion with Serpentine Scanning
    const buffer = new Float32Array(channelData);
    for (let y = 0; y < height; y++) {
      const isRightToLeft = y % 2 === 1;
      const startX = isRightToLeft ? width - 1 : 0;
      const endX = isRightToLeft ? -1 : width;
      const stepX = isRightToLeft ? -1 : 1;

      for (let x = startX; x !== endX; x += stepX) {
        const idx = y * width + x;
        let oldVal = buffer[idx];
        if (dotGainCompensation) oldVal = compensateDotGain(oldVal);

        const newVal = oldVal >= 0.5 ? 1.0 : 0.0;
        bitmap[idx] = newVal === 1.0 ? 1 : 0;
        if (newVal === 1.0) totalDots++;

        const error = oldVal - newVal;

        if (isRightToLeft) {
          if (x - 1 >= 0) buffer[y * width + (x - 1)] += (error * 7) / 16;
          if (y + 1 < height) {
            if (x + 1 < width) buffer[(y + 1) * width + (x + 1)] += (error * 3) / 16;
            buffer[(y + 1) * width + x] += (error * 5) / 16;
            if (x - 1 >= 0) buffer[(y + 1) * width + (x - 1)] += (error * 1) / 16;
          }
        } else {
          if (x + 1 < width) buffer[y * width + (x + 1)] += (error * 7) / 16;
          if (y + 1 < height) {
            if (x - 1 >= 0) buffer[(y + 1) * width + (x - 1)] += (error * 3) / 16;
            buffer[(y + 1) * width + x] += (error * 5) / 16;
            if (x + 1 < width) buffer[(y + 1) * width + (x + 1)] += (error * 1) / 16;
          }
        }
      }
    }
  }

  return {
    bitmap,
    width,
    height,
    totalDotsPlaced: totalDots,
    dotDensityRatio: totalDots / (width * height),
  };
}
