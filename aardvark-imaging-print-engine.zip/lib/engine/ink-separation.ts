/**
 * AARDVARK IMAGING PRINT ENGINE
 * Ink Separation & Multi-Channel Limiting Engine
 * Supports 12-channel pigment inkjet: C, M, Y, PK/MK, LC, LM, LK, LLK, OR, GR, V, CO.
 */

import { InkChannelName, PaperProfile } from './types';
import { labToRgb, rgbToLab } from './colour-science';

export interface InkSeparationResult {
  channels: Record<InkChannelName, number>; // 0.0 - 1.0 per channel
  totalAreaCoveragePercent: number; // e.g. 240%
  tacLimitEnforced: boolean;
  chromaOptimizerCoverage: number; // 0.0 - 1.0 gloss differential equalizer
  poolingRiskScore: number; // 0.0 - 1.0
  bronzingRiskScore: number; // 0.0 - 1.0
}

/**
 * Multi-channel ink separation algorithm from CIE Lab
 */
export function separateLabToInks(
  lab: [number, number, number],
  paper: PaperProfile,
  isMatteMedia: boolean = false,
  gcrLevel: number = 0.6 // 0.0 (minimum black) to 1.0 (maximum black replacement)
): InkSeparationResult {
  const [L, a, b] = lab;

  // Convert to working CMYK first
  // Standard RGB approximation
  const [r, g, bVal] = labToRgb(lab, 'AdobeRGB_1998');
  const rNorm = r / 255;
  const gNorm = g / 255;
  const bNorm = bVal / 255;

  let rawC = 1 - rNorm;
  let rawM = 1 - gNorm;
  let rawY = 1 - bNorm;
  const rawK = Math.min(rawC, rawM, rawY);

  // Apply GCR (Gray Component Replacement)
  const blackReplaced = rawK * gcrLevel;
  let c = Math.max(0, rawC - blackReplaced);
  let m = Math.max(0, rawM - blackReplaced);
  let y = Math.max(0, rawY - blackReplaced);
  let k = blackReplaced;

  // Multi-density channel split:
  // Split Cyan into Cyan (C) and Light Cyan (LC)
  // Split Magenta into Magenta (M) and Light Magenta (LM)
  // Split Black into Black (PK/MK), Light Black (LK), and Light Light Black (LLK)
  let channelC = 0;
  let channelLC = 0;
  if (c <= 0.4) {
    channelLC = c * 2.2;
    channelC = 0;
  } else {
    channelLC = 0.88 - (c - 0.4) * 0.8;
    channelC = (c - 0.4) / 0.6;
  }

  let channelM = 0;
  let channelLM = 0;
  if (m <= 0.4) {
    channelLM = m * 2.2;
    channelM = 0;
  } else {
    channelLM = 0.88 - (m - 0.4) * 0.8;
    channelM = (m - 0.4) / 0.6;
  }

  let channelK = 0;
  let channelLK = 0;
  let channelLLK = 0;
  if (k <= 0.2) {
    channelLLK = k * 3.5;
  } else if (k <= 0.5) {
    channelLLK = 0.7 - (k - 0.2) * 1.5;
    channelLK = (k - 0.2) / 0.3 * 0.9;
  } else {
    channelLLK = 0.1;
    channelLK = 0.9 - (k - 0.5) * 0.8;
    channelK = (k - 0.5) / 0.5;
  }

  // Gamut Expanding Channels: Orange (OR), Green (GR), Violet (V)
  // Orange triggers in high-saturation warm tones (+a*, +b*)
  let channelOR = 0;
  if (a > 15 && b > 20) {
    const warmChroma = Math.sqrt(a * a + b * b);
    channelOR = Math.min(1.0, (warmChroma - 25) / 50);
    // Reduce yellow and magenta when orange replaces them
    y *= 1.0 - channelOR * 0.35;
    m *= 1.0 - channelOR * 0.25;
  }

  // Green triggers in saturated greens (-a*, +b*)
  let channelGR = 0;
  if (a < -15 && b > 10) {
    const greenChroma = Math.sqrt(a * a + b * b);
    channelGR = Math.min(1.0, (greenChroma - 20) / 45);
    c *= 1.0 - channelGR * 0.3;
    y *= 1.0 - channelGR * 0.3;
  }

  // Violet triggers in saturated purples/blues (+a*, -b*)
  let channelV = 0;
  if (a > 10 && b < -20) {
    const violetChroma = Math.sqrt(a * a + b * b);
    channelV = Math.min(1.0, (violetChroma - 22) / 45);
    c *= 1.0 - channelV * 0.25;
    m *= 1.0 - channelV * 0.25;
  }

  // Select Black channel based on media type
  const channelPK = isMatteMedia ? 0 : channelK;
  const channelMK = isMatteMedia ? channelK : 0;

  // Assemble channels dictionary
  const rawChannels: Record<InkChannelName, number> = {
    C: Math.max(0, Math.min(1, channelC)),
    M: Math.max(0, Math.min(1, channelM)),
    Y: Math.max(0, Math.min(1, y)),
    PK: Math.max(0, Math.min(1, channelPK)),
    MK: Math.max(0, Math.min(1, channelMK)),
    LC: Math.max(0, Math.min(1, channelLC)),
    LM: Math.max(0, Math.min(1, channelLM)),
    LK: Math.max(0, Math.min(1, channelLK)),
    LLK: Math.max(0, Math.min(1, channelLLK)),
    OR: Math.max(0, Math.min(1, channelOR)),
    GR: Math.max(0, Math.min(1, channelGR)),
    V: Math.max(0, Math.min(1, channelV)),
    CO: 0,
  };

  // Calculate Total Area Coverage (sum of all inks)
  let sumChannels = 0;
  for (const key of Object.keys(rawChannels) as InkChannelName[]) {
    if (key !== 'CO') {
      sumChannels += rawChannels[key];
    }
  }

  let totalCoveragePercent = Math.round(sumChannels * 100);
  const maxTac = paper.maximum_ink_load_tac; // e.g. 320%
  let tacLimitEnforced = false;

  // Enforce TAC Limit if exceeded
  if (totalCoveragePercent > maxTac) {
    tacLimitEnforced = true;
    const scaleFactor = maxTac / totalCoveragePercent;
    for (const key of Object.keys(rawChannels) as InkChannelName[]) {
      if (key !== 'CO') {
        rawChannels[key] = Math.max(0, Math.min(1, rawChannels[key] * scaleFactor));
      }
    }
    totalCoveragePercent = maxTac;
  }

  // Chroma Optimizer (CO) is used on glossy/luster papers to eliminate gloss differential and bronzing
  // Deposited in inverse proportion to total ink coverage
  let chromaOptimizer = 0;
  if (!isMatteMedia && (paper.type === 'glossy' || paper.type === 'luster' || paper.type === 'semi-gloss' || paper.type === 'baryta')) {
    chromaOptimizer = Math.max(0, Math.min(1, 1.0 - (totalCoveragePercent / 200)));
  }
  rawChannels.CO = chromaOptimizer;

  // Physical risk indicators
  const poolingRiskScore = Math.min(1, Math.max(0, (totalCoveragePercent - 260) / 80));
  // Bronzing risk occurs in heavy blacks and dark blues on glossy papers without CO
  const bronzingRiskScore = isMatteMedia ? 0 : Math.min(1, (rawChannels.PK * 0.8 + rawChannels.C * 0.4) * (1 - chromaOptimizer));

  return {
    channels: rawChannels,
    totalAreaCoveragePercent: totalCoveragePercent,
    tacLimitEnforced,
    chromaOptimizerCoverage: chromaOptimizer,
    poolingRiskScore,
    bronzingRiskScore,
  };
}
