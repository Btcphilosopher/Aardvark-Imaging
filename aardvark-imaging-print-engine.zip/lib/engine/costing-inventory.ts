/**
 * AARDVARK IMAGING PRINT ENGINE
 * Costing, Inventory & Print Farm Fleet Engine
 */

import { PrintJob, PaperProfile, InkProfile, PrinterModel, InventoryItem } from './types';

export interface CostBreakdown {
  inkCost: number;
  paperCost: number;
  energyCost: number;
  maintenanceCost: number;
  labourCost: number;
  wasteCost: number;
  depreciationCost: number;
  totalCost: number;
  costPerSquareMetre: number;
  costPerSquareFoot: number;
  costPerCopy: number;
  profitMarginRecommended: number;
  recommendedRetailPrice: number;
}

/**
 * Calculates industrial production cost for a print job
 */
export function calculatePrintJobCost(
  job: PrintJob,
  paper: PaperProfile,
  ink: InkProfile,
  printer: PrinterModel,
  labourRatePerHour: number = 45.0,
  wasteAllowanceRatio: number = 0.08 // 8% test strip & paper trim allowance
): CostBreakdown {
  const printAreaSqm = (job.target_dimensions.width_mm * job.target_dimensions.height_mm) / 1000000;
  const totalAreaSqm = printAreaSqm * job.copies;

  // 1. Paper Cost
  const rawPaperCost = totalAreaSqm * paper.cost_per_sqm;
  const paperCost = rawPaperCost * (1 + wasteAllowanceRatio);

  // 2. Ink Cost
  // Average fine art consumption ~14.5 ml/m^2
  const inkConsumedMl = totalAreaSqm * 14.5;
  const inkCost = inkConsumedMl * ink.cost_per_ml;

  // 3. Energy Cost
  const printDurationHours = totalAreaSqm / printer.print_speed_sqm_per_hr;
  const kwhConsumed = (printer.power_consumption_w * printDurationHours) / 1000;
  const energyCost = kwhConsumed * 0.28; // $0.28 per kWh

  // 4. Maintenance Cost
  const maintenanceCost = printDurationHours * 2.80; // wear & tear per hour

  // 5. Depreciation Cost ($12,000 printer amortized over 4,000 hours = $3.00/hr)
  const depreciationCost = printDurationHours * 3.00;

  // 6. Labour Cost (file prep, inspection, trimming: ~15 mins baseline + print time)
  const labourHours = (15 / 60) + (printDurationHours * 0.25);
  const labourCost = labourHours * labourRatePerHour;

  // 7. Waste / Consumables Cost (gloves, glassine sheets, core tubes, packaging)
  const wasteCost = totalAreaSqm * 3.50;

  const totalCost = paperCost + inkCost + energyCost + maintenanceCost + labourCost + wasteCost + depreciationCost;
  const costPerSqm = totalCost / totalAreaSqm;
  const costPerSqft = costPerSqm / 10.7639;
  const costPerCopy = totalCost / job.copies;

  return {
    inkCost: Math.round(inkCost * 100) / 100,
    paperCost: Math.round(paperCost * 100) / 100,
    energyCost: Math.round(energyCost * 100) / 100,
    maintenanceCost: Math.round(maintenanceCost * 100) / 100,
    labourCost: Math.round(labourCost * 100) / 100,
    wasteCost: Math.round(wasteCost * 100) / 100,
    depreciationCost: Math.round(depreciationCost * 100) / 100,
    totalCost: Math.round(totalCost * 100) / 100,
    costPerSquareMetre: Math.round(costPerSqm * 100) / 100,
    costPerSquareFoot: Math.round(costPerSqft * 100) / 100,
    costPerCopy: Math.round(costPerCopy * 100) / 100,
    profitMarginRecommended: 0.65, // 65% gallery margin
    recommendedRetailPrice: Math.round((costPerCopy / (1 - 0.65)) * 100) / 100,
  };
}

/**
 * Initial Factory Inventory
 */
export const INITIAL_INVENTORY: InventoryItem[] = [
  {
    sku: 'MED-BAR-310-44',
    category: 'PAPER',
    name: 'Aardvark Baryta Prestige 310gsm (44" x 50ft Roll)',
    supplier: 'Aardvark Fine Art Media Ltd',
    quantity: 14,
    unit: 'rolls',
    reorder_level: 4,
    unit_cost: 215.0,
    location: 'Aisle 3, Rack B',
    lot_number: 'LOT-2026-BP310-09',
  },
  {
    sku: 'MED-RAG-308-44',
    category: 'PAPER',
    name: 'Aardvark Museum Rag 308gsm (44" x 50ft Roll)',
    supplier: 'Aardvark Fine Art Media Ltd',
    quantity: 8,
    unit: 'rolls',
    reorder_level: 3,
    unit_cost: 245.0,
    location: 'Aisle 3, Rack C',
    lot_number: 'LOT-2026-MR308-04',
  },
  {
    sku: 'MED-LUS-260-A3P',
    category: 'PAPER',
    name: 'Aardvark Photo Luster 260gsm (A3+ 50 Sheets)',
    supplier: 'Aardvark Fine Art Media Ltd',
    quantity: 26,
    unit: 'boxes',
    reorder_level: 6,
    unit_cost: 78.50,
    location: 'Shelf 12-A',
    lot_number: 'LOT-2026-PL260-11',
  },
  {
    sku: 'INK-PIG-700-PK',
    category: 'INK_CARTRIDGE',
    name: 'Aardvark ChromaPure Pigment Photo Black (700ml)',
    supplier: 'Aardvark Ink Labs',
    quantity: 6,
    unit: 'cartridges',
    reorder_level: 2,
    unit_cost: 165.0,
    location: 'Flammables Cabinet 1',
    lot_number: 'INK-LOT-8842',
    expiry_date: '2028-12-31',
  },
  {
    sku: 'INK-PIG-700-C',
    category: 'INK_CARTRIDGE',
    name: 'Aardvark ChromaPure Pigment Cyan (700ml)',
    supplier: 'Aardvark Ink Labs',
    quantity: 5,
    unit: 'cartridges',
    reorder_level: 2,
    unit_cost: 165.0,
    location: 'Flammables Cabinet 1',
    lot_number: 'INK-LOT-8843',
    expiry_date: '2028-12-31',
  },
  {
    sku: 'INK-PIG-700-CO',
    category: 'INK_CARTRIDGE',
    name: 'Aardvark Chroma Optimizer Clear Coat (700ml)',
    supplier: 'Aardvark Ink Labs',
    quantity: 4,
    unit: 'cartridges',
    reorder_level: 2,
    unit_cost: 145.0,
    location: 'Flammables Cabinet 1',
    lot_number: 'INK-LOT-8850',
    expiry_date: '2029-01-15',
  },
  {
    sku: 'HD-PRO-12C',
    category: 'PRINT_HEAD',
    name: 'MicroPiezo VFP 12-Channel Precision Print Head',
    supplier: 'Aardvark Robotics',
    quantity: 3,
    unit: 'units',
    reorder_level: 1,
    unit_cost: 1250.0,
    location: 'Clean Room Vault',
    lot_number: 'HD-2026-REV4',
  },
  {
    sku: 'MT-PRO-600',
    category: 'MAINTENANCE_TANK',
    name: 'Maintenance Waste Ink Tank Box ProPrint 600',
    supplier: 'Aardvark Robotics',
    quantity: 7,
    unit: 'units',
    reorder_level: 3,
    unit_cost: 48.0,
    location: 'Bin 4',
    lot_number: 'MT-2026-02',
  },
];
