/**
 * AARDVARK IMAGING PRINT ENGINE
 * High-Precision Colour Science Engine
 * Standards: CIE 1976, CIE 15:2004, CIEDE2000, ISO 13655, ICC.1:2010
 */

import { ColourSpaceName, RenderingIntent } from './types';

// Standard Illuminant Tristimulus Values (2° Standard Observer)
export const ILLUMINANTS = {
  D50: [0.96422, 1.00000, 0.82521] as [number, number, number],
  D65: [0.95047, 1.00000, 1.08883] as [number, number, number],
  D55: [0.95682, 1.00000, 0.92149] as [number, number, number],
  A:   [1.09850, 1.00000, 0.35585] as [number, number, number],
};

// Bradford Chromatic Adaptation Matrix
const M_BRADFORD = [
  [ 0.8951,  0.2664, -0.1614],
  [-0.7502,  1.7135,  0.0367],
  [ 0.0389, -0.0685,  1.0296],
];

const M_BRADFORD_INV = [
  [ 0.9869929, -0.1470543,  0.1599627],
  [ 0.4323053,  0.5183603,  0.0492912],
  [-0.0085287,  0.0400428,  0.9684867],
];

/**
 * Perform Bradford Chromatic Adaptation from source white to target white
 */
export function chromaticAdaptationBradford(
  xyz: [number, number, number],
  srcWhite: [number, number, number] = ILLUMINANTS.D65,
  dstWhite: [number, number, number] = ILLUMINANTS.D50
): [number, number, number] {
  // Convert white points to cone response
  const [xs, ys, zs] = srcWhite;
  const [xd, yd, zd] = dstWhite;

  const [rs, gs, bs] = [
    M_BRADFORD[0][0] * xs + M_BRADFORD[0][1] * ys + M_BRADFORD[0][2] * zs,
    M_BRADFORD[1][0] * xs + M_BRADFORD[1][1] * ys + M_BRADFORD[1][2] * zs,
    M_BRADFORD[2][0] * xs + M_BRADFORD[2][1] * ys + M_BRADFORD[2][2] * zs,
  ];

  const [rd, gd, bd] = [
    M_BRADFORD[0][0] * xd + M_BRADFORD[0][1] * yd + M_BRADFORD[0][2] * zd,
    M_BRADFORD[1][0] * xd + M_BRADFORD[1][1] * yd + M_BRADFORD[1][2] * zd,
    M_BRADFORD[2][0] * xd + M_BRADFORD[2][1] * yd + M_BRADFORD[2][2] * zd,
  ];

  const [x, y, z] = xyz;
  const [r, g, b] = [
    M_BRADFORD[0][0] * x + M_BRADFORD[0][1] * y + M_BRADFORD[0][2] * z,
    M_BRADFORD[1][0] * x + M_BRADFORD[1][1] * y + M_BRADFORD[1][2] * z,
    M_BRADFORD[2][0] * x + M_BRADFORD[2][1] * y + M_BRADFORD[2][2] * z,
  ];

  // Scale cone responses
  const [rc, gc, bc] = [r * (rd / rs), g * (gd / gs), b * (bd / bs)];

  // Convert back to XYZ
  return [
    M_BRADFORD_INV[0][0] * rc + M_BRADFORD_INV[0][1] * gc + M_BRADFORD_INV[0][2] * bc,
    M_BRADFORD_INV[1][0] * rc + M_BRADFORD_INV[1][1] * gc + M_BRADFORD_INV[1][2] * bc,
    M_BRADFORD_INV[2][0] * rc + M_BRADFORD_INV[2][1] * gc + M_BRADFORD_INV[2][2] * bc,
  ];
}

// 3x3 Matrices for RGB to XYZ (D65 or D50 aligned)
export interface ColourSpaceDefinition {
  name: ColourSpaceName;
  whitePoint: [number, number, number];
  toLinear: (v: number) => number;
  fromLinear: (v: number) => number;
  toXYZMatrix: number[][];
  fromXYZMatrix: number[][];
}

export const COLOUR_SPACES: Record<ColourSpaceName, ColourSpaceDefinition> = {
  sRGB: {
    name: 'sRGB',
    whitePoint: ILLUMINANTS.D65,
    toLinear: (v: number) => {
      const c = v / 255;
      return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
    },
    fromLinear: (c: number) => {
      const clamped = Math.max(0, Math.min(1, c));
      const v = clamped <= 0.0031308 ? clamped * 12.92 : 1.055 * Math.pow(clamped, 1 / 2.4) - 0.055;
      return Math.round(v * 255);
    },
    toXYZMatrix: [
      [0.4124564, 0.3575761, 0.1804375],
      [0.2126729, 0.7151522, 0.0721750],
      [0.0193339, 0.1191920, 0.9503041],
    ],
    fromXYZMatrix: [
      [ 3.2404542, -1.5371385, -0.4985314],
      [-0.9692660,  1.8760108,  0.0415560],
      [ 0.0556434, -0.2040259,  1.0572252],
    ],
  },
  AdobeRGB_1998: {
    name: 'AdobeRGB_1998',
    whitePoint: ILLUMINANTS.D65,
    toLinear: (v: number) => Math.pow(v / 255, 2.19921875),
    fromLinear: (c: number) => {
      const clamped = Math.max(0, Math.min(1, c));
      return Math.round(Math.pow(clamped, 1 / 2.19921875) * 255);
    },
    toXYZMatrix: [
      [0.5767309, 0.1855540, 0.1881852],
      [0.2973769, 0.6273491, 0.0752741],
      [0.0270343, 0.0706872, 0.9911085],
    ],
    fromXYZMatrix: [
      [ 2.0413690, -0.5649464, -0.3446944],
      [-0.9692660,  1.8760108,  0.0415560],
      [ 0.0134474, -0.1183897,  1.0154096],
    ],
  },
  Display_P3: {
    name: 'Display_P3',
    whitePoint: ILLUMINANTS.D65,
    toLinear: (v: number) => {
      const c = v / 255;
      return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
    },
    fromLinear: (c: number) => {
      const clamped = Math.max(0, Math.min(1, c));
      const v = clamped <= 0.0031308 ? clamped * 12.92 : 1.055 * Math.pow(clamped, 1 / 2.4) - 0.055;
      return Math.round(v * 255);
    },
    toXYZMatrix: [
      [0.4865709, 0.2656677, 0.1982173],
      [0.2289746, 0.6917393, 0.0792861],
      [0.0000000, 0.0451134, 1.0439444],
    ],
    fromXYZMatrix: [
      [ 2.4934969, -0.9313836, -0.4027108],
      [-0.8294890,  1.7626641,  0.0236247],
      [ 0.0358458, -0.0761724,  0.9568845],
    ],
  },
  ProPhoto_RGB: {
    name: 'ProPhoto_RGB',
    whitePoint: ILLUMINANTS.D50,
    toLinear: (v: number) => {
      const c = v / 255;
      return c <= 16 / 512 ? c / 16 : Math.pow(c, 1.8);
    },
    fromLinear: (c: number) => {
      const clamped = Math.max(0, Math.min(1, c));
      const v = clamped <= 1 / 512 ? clamped * 16 : Math.pow(clamped, 1 / 1.8);
      return Math.round(v * 255);
    },
    toXYZMatrix: [
      [0.7976749, 0.1351917, 0.0313534],
      [0.2880402, 0.7118741, 0.0000857],
      [0.0000000, 0.0000000, 0.8252100],
    ],
    fromXYZMatrix: [
      [ 1.3459433, -0.2556075, -0.0511118],
      [-0.5445989,  1.5081673,  0.0205351],
      [ 0.0000000,  0.0000000,  1.2118128],
    ],
  },
  Rec2020: {
    name: 'Rec2020',
    whitePoint: ILLUMINANTS.D65,
    toLinear: (v: number) => {
      const c = v / 255;
      const alpha = 1.09929682680944;
      const beta = 0.018053968510807;
      return c < beta * 4.5 ? c / 4.5 : Math.pow((c + alpha - 1) / alpha, 1 / 0.45);
    },
    fromLinear: (c: number) => {
      const clamped = Math.max(0, Math.min(1, c));
      const alpha = 1.09929682680944;
      const beta = 0.018053968510807;
      const v = clamped < beta ? clamped * 4.5 : alpha * Math.pow(clamped, 0.45) - (alpha - 1);
      return Math.round(v * 255);
    },
    toXYZMatrix: [
      [0.6369580, 0.1446169, 0.1688810],
      [0.2627002, 0.6779981, 0.0593017],
      [0.0000000, 0.0280727, 1.0609851],
    ],
    fromXYZMatrix: [
      [ 1.7166512, -0.3556708, -0.2533663],
      [-0.6666844,  1.6164812,  0.0157685],
      [ 0.0176399, -0.0427706,  0.9421031],
    ],
  },
  Rec709: {
    name: 'Rec709',
    whitePoint: ILLUMINANTS.D65,
    toLinear: (v: number) => {
      const c = v / 255;
      return c < 0.081 ? c / 4.5 : Math.pow((c + 0.099) / 1.099, 1 / 0.45);
    },
    fromLinear: (c: number) => {
      const clamped = Math.max(0, Math.min(1, c));
      const v = clamped < 0.018 ? clamped * 4.5 : 1.099 * Math.pow(clamped, 0.45) - 0.099;
      return Math.round(v * 255);
    },
    toXYZMatrix: [
      [0.4124564, 0.3575761, 0.1804375],
      [0.2126729, 0.7151522, 0.0721750],
      [0.0193339, 0.1191920, 0.9503041],
    ],
    fromXYZMatrix: [
      [ 3.2404542, -1.5371385, -0.4985314],
      [-0.9692660,  1.8760108,  0.0415560],
      [ 0.0556434, -0.2040259,  1.0572252],
    ],
  },
  CIE_XYZ: {
    name: 'CIE_XYZ',
    whitePoint: ILLUMINANTS.D50,
    toLinear: (v: number) => v / 100,
    fromLinear: (c: number) => Math.round(c * 100),
    toXYZMatrix: [[1, 0, 0], [0, 1, 0], [0, 0, 1]],
    fromXYZMatrix: [[1, 0, 0], [0, 1, 0], [0, 0, 1]],
  },
  CIE_Lab: {
    name: 'CIE_Lab',
    whitePoint: ILLUMINANTS.D50,
    toLinear: (v: number) => v,
    fromLinear: (c: number) => c,
    toXYZMatrix: [[1, 0, 0], [0, 1, 0], [0, 0, 1]],
    fromXYZMatrix: [[1, 0, 0], [0, 1, 0], [0, 0, 1]],
  },
  Custom_ICC: {
    name: 'Custom_ICC',
    whitePoint: ILLUMINANTS.D50,
    toLinear: (v: number) => Math.pow(v / 255, 2.2),
    fromLinear: (c: number) => Math.round(Math.pow(Math.max(0, Math.min(1, c)), 1 / 2.2) * 255),
    toXYZMatrix: [
      [0.4360747, 0.3850649, 0.1430804],
      [0.2225045, 0.7168786, 0.0606169],
      [0.0139322, 0.0971045, 0.7141733],
    ],
    fromXYZMatrix: [
      [ 3.1338561, -1.6168667, -0.4906146],
      [-0.9787684,  1.9161415,  0.0334540],
      [ 0.0719453, -0.2289914,  1.4052427],
    ],
  },
};

/**
 * RGB to CIE XYZ in Profile Connection Space (D50)
 */
export function rgbToXyz(
  r: number,
  g: number,
  b: number,
  spaceName: ColourSpaceName = 'sRGB'
): [number, number, number] {
  const space = COLOUR_SPACES[spaceName] || COLOUR_SPACES.sRGB;
  const rLin = space.toLinear(r);
  const gLin = space.toLinear(g);
  const bLin = space.toLinear(b);

  const m = space.toXYZMatrix;
  const x = m[0][0] * rLin + m[0][1] * gLin + m[0][2] * bLin;
  const y = m[1][0] * rLin + m[1][1] * gLin + m[1][2] * bLin;
  const z = m[2][0] * rLin + m[2][1] * gLin + m[2][2] * bLin;

  // If source space is D65 based, adapt to D50 for ICC PCS
  if (space.whitePoint === ILLUMINANTS.D65) {
    return chromaticAdaptationBradford([x, y, z], ILLUMINANTS.D65, ILLUMINANTS.D50);
  }
  return [x, y, z];
}

/**
 * CIE XYZ (D50 PCS) to RGB
 */
export function xyzToRgb(
  x: number,
  y: number,
  z: number,
  targetSpaceName: ColourSpaceName = 'sRGB'
): [number, number, number] {
  const space = COLOUR_SPACES[targetSpaceName] || COLOUR_SPACES.sRGB;
  let targetXyz: [number, number, number] = [x, y, z];

  if (space.whitePoint === ILLUMINANTS.D65) {
    targetXyz = chromaticAdaptationBradford([x, y, z], ILLUMINANTS.D50, ILLUMINANTS.D65);
  }

  const [tx, ty, tz] = targetXyz;
  const m = space.fromXYZMatrix;
  const rLin = m[0][0] * tx + m[0][1] * ty + m[0][2] * tz;
  const gLin = m[1][0] * tx + m[1][1] * ty + m[1][2] * tz;
  const bLin = m[2][0] * tx + m[2][1] * ty + m[2][2] * tz;

  return [
    space.fromLinear(rLin),
    space.fromLinear(gLin),
    space.fromLinear(bLin),
  ];
}

/**
 * CIE XYZ (D50 reference) to CIE L*a*b*
 */
export function xyzToLab(
  xyz: [number, number, number],
  whitePoint: [number, number, number] = ILLUMINANTS.D50
): [number, number, number] {
  const [X, Y, Z] = xyz;
  const [Xn, Yn, Zn] = whitePoint;

  const f = (t: number) => {
    return t > 0.008856 ? Math.cbrt(t) : 7.787 * t + 16 / 116;
  };

  const fx = f(X / Xn);
  const fy = f(Y / Yn);
  const fz = f(Z / Zn);

  const L = Math.max(0, 116 * fy - 16);
  const a = 500 * (fx - fy);
  const b = 200 * (fy - fz);

  return [L, a, b];
}

/**
 * CIE L*a*b* to CIE XYZ (D50 reference)
 */
export function labToXyz(
  lab: [number, number, number],
  whitePoint: [number, number, number] = ILLUMINANTS.D50
): [number, number, number] {
  const [L, a, b] = lab;
  const [Xn, Yn, Zn] = whitePoint;

  const fy = (L + 16) / 116;
  const fx = a / 500 + fy;
  const fz = fy - b / 200;

  const fInv = (t: number) => {
    const t3 = t * t * t;
    return t3 > 0.008856 ? t3 : (t - 16 / 116) / 7.787;
  };

  return [
    Xn * fInv(fx),
    Yn * fInv(fy),
    Zn * fInv(fz),
  ];
}

/**
 * RGB directly to CIE L*a*b*
 */
export function rgbToLab(
  r: number,
  g: number,
  b: number,
  spaceName: ColourSpaceName = 'sRGB'
): [number, number, number] {
  const xyz = rgbToXyz(r, g, b, spaceName);
  return xyzToLab(xyz, ILLUMINANTS.D50);
}

/**
 * CIE L*a*b* to RGB
 */
export function labToRgb(
  lab: [number, number, number],
  targetSpaceName: ColourSpaceName = 'sRGB'
): [number, number, number] {
  const xyz = labToXyz(lab, ILLUMINANTS.D50);
  return xyzToRgb(xyz[0], xyz[1], xyz[2], targetSpaceName);
}

/**
 * Delta E 1976 (CIE76 Euclidean distance in Lab)
 */
export function deltaE1976(
  lab1: [number, number, number],
  lab2: [number, number, number]
): number {
  const dL = lab1[0] - lab2[0];
  const da = lab1[1] - lab2[1];
  const db = lab1[2] - lab2[2];
  return Math.sqrt(dL * dL + da * da + db * db);
}

/**
 * Delta E 2000 (CIEDE2000)
 * Standard international metric for color difference evaluation in graphic arts and proofing.
 */
export function deltaE2000(
  lab1: [number, number, number],
  lab2: [number, number, number],
  kL: number = 1.0,
  kC: number = 1.0,
  kH: number = 1.0
): number {
  const [L1, a1, b1] = lab1;
  const [L2, a2, b2] = lab2;

  const deg2rad = (deg: number) => (deg * Math.PI) / 180;
  const rad2deg = (rad: number) => (rad * 180) / Math.PI;

  const avgL = (L1 + L2) / 2.0;
  const C1 = Math.sqrt(a1 * a1 + b1 * b1);
  const C2 = Math.sqrt(a2 * a2 + b2 * b2);
  const avgC = (C1 + C2) / 2.0;

  const G = 0.5 * (1 - Math.sqrt(Math.pow(avgC, 7) / (Math.pow(avgC, 7) + Math.pow(25, 7))));
  const a1Prime = a1 * (1 + G);
  const a2Prime = a2 * (1 + G);

  const C1Prime = Math.sqrt(a1Prime * a1Prime + b1 * b1);
  const C2Prime = Math.sqrt(a2Prime * a2Prime + b2 * b2);
  const avgCPrime = (C1Prime + C2Prime) / 2.0;

  let h1Prime = rad2deg(Math.atan2(b1, a1Prime));
  if (h1Prime < 0) h1Prime += 360;
  let h2Prime = rad2deg(Math.atan2(b2, a2Prime));
  if (h2Prime < 0) h2Prime += 360;

  let avgHPrime = 0;
  if (Math.abs(h1Prime - h2Prime) > 180) {
    avgHPrime = (h1Prime + h2Prime + 360) / 2.0;
  } else {
    avgHPrime = (h1Prime + h2Prime) / 2.0;
  }

  const T =
    1 -
    0.17 * Math.cos(deg2rad(avgHPrime - 30)) +
    0.24 * Math.cos(deg2rad(2 * avgHPrime)) +
    0.32 * Math.cos(deg2rad(3 * avgHPrime + 6)) -
    0.20 * Math.cos(deg2rad(4 * avgHPrime - 63));

  let deltahPrime = 0;
  if (Math.abs(h2Prime - h1Prime) <= 180) {
    deltahPrime = h2Prime - h1Prime;
  } else if (h2Prime <= h1Prime) {
    deltahPrime = h2Prime - h1Prime + 360;
  } else {
    deltahPrime = h2Prime - h1Prime - 360;
  }

  const deltaLPrime = L2 - L1;
  const deltaCPrime = C2Prime - C1Prime;
  const deltaHPrime = 2 * Math.sqrt(C1Prime * C2Prime) * Math.sin(deg2rad(deltahPrime / 2.0));

  const SL = 1 + (0.015 * Math.pow(avgL - 50, 2)) / Math.sqrt(20 + Math.pow(avgL - 50, 2));
  const SC = 1 + 0.045 * avgCPrime;
  const SH = 1 + 0.015 * avgCPrime * T;

  const deltaTheta = 30 * Math.exp(-Math.pow((avgHPrime - 275) / 25, 2));
  const RC = 2 * Math.sqrt(Math.pow(avgCPrime, 7) / (Math.pow(avgCPrime, 7) + Math.pow(25, 7)));
  const RT = -Math.sin(deg2rad(2 * deltaTheta)) * RC;

  const dE = Math.sqrt(
    Math.pow(deltaLPrime / (kL * SL), 2) +
    Math.pow(deltaCPrime / (kC * SC), 2) +
    Math.pow(deltaHPrime / (kH * SH), 2) +
    RT * (deltaCPrime / (kC * SC)) * (deltaHPrime / (kH * SH))
  );

  return dE;
}

/**
 * Black Point Compensation (BPC)
 * Remaps source lightness range [Src_BP, Src_WP] to target media lightness range [Dst_BP, Dst_WP]
 */
export function applyBlackPointCompensation(
  lab: [number, number, number],
  srcBP_L: number = 0.0,
  dstBP_L: number = 3.5, // typical baryta or luster black point
  srcWP_L: number = 100.0,
  dstWP_L: number = 96.5 // paper white
): [number, number, number] {
  const [L, a, b] = lab;
  // Linear remapping of L*
  const t = Math.max(0, Math.min(1, (L - srcBP_L) / (srcWP_L - srcBP_L)));
  const mappedL = dstBP_L + t * (dstWP_L - dstBP_L);

  // Slight desaturation near extreme shadows to prevent color noise
  const shadowFactor = Math.min(1, mappedL / 20);
  return [mappedL, a * shadowFactor, b * shadowFactor];
}
