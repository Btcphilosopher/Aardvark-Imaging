/**
 * AARDVARK IMAGING PRINT ENGINE
 * Resolution & Resampling Engine
 * Calculates physical DPI, optical viewing limits, and high-fidelity output sharpening.
 */

import { ResamplingMethod, SharpeningMethod, PaperFinish } from './types';

export interface ResolutionMetrics {
  sourcePixelsWidth: number;
  sourcePixelsHeight: number;
  targetPrintWidthMm: number;
  targetPrintHeightMm: number;
  effectiveDpiX: number;
  effectiveDpiY: number;
  scalingRatio: number;
  recommendedViewingDistanceCm: number;
  humanEyeResolvingDpiAtViewingDistance: number;
  qualityAssessment: 'SUB_OPTIMAL' | 'ACCEPTABLE' | 'EXCELLENT' | 'MUSEUM_GRADE';
}

/**
 * Calculate exact effective print resolution and viewing metrics
 */
export function calculateResolutionMetrics(
  pixelsW: number,
  pixelsH: number,
  printWidthMm: number,
  printHeightMm: number,
  viewingDistanceCm: number = 50
): ResolutionMetrics {
  const inchesW = printWidthMm / 25.4;
  const inchesH = printHeightMm / 25.4;

  const effectiveDpiX = Math.round(pixelsW / inchesW);
  const effectiveDpiY = Math.round(pixelsH / inchesH);

  // Optical limit of the human fovea (~1 arcminute of resolution)
  // Resolving power (DPI) ≈ 3438 / viewing_distance_inches
  const viewingDistanceInches = viewingDistanceCm / 2.54;
  const humanEyeResolvingDpi = Math.round(3438 / viewingDistanceInches);

  // Recommended standard viewing distance for diagonal dimension
  const diagonalInches = Math.sqrt(inchesW * inchesW + inchesH * inchesH);
  const recommendedDistanceCm = Math.max(30, Math.round(diagonalInches * 1.5 * 2.54));

  let qualityAssessment: 'SUB_OPTIMAL' | 'ACCEPTABLE' | 'EXCELLENT' | 'MUSEUM_GRADE' = 'SUB_OPTIMAL';
  if (effectiveDpiX >= 360) {
    qualityAssessment = 'MUSEUM_GRADE';
  } else if (effectiveDpiX >= 240) {
    qualityAssessment = 'EXCELLENT';
  } else if (effectiveDpiX >= 150) {
    qualityAssessment = 'ACCEPTABLE';
  }

  return {
    sourcePixelsWidth: pixelsW,
    sourcePixelsHeight: pixelsH,
    targetPrintWidthMm: printWidthMm,
    targetPrintHeightMm: printHeightMm,
    effectiveDpiX,
    effectiveDpiY,
    scalingRatio: effectiveDpiX / 300,
    recommendedViewingDistanceCm: recommendedDistanceCm,
    humanEyeResolvingDpiAtViewingDistance: humanEyeResolvingDpi,
    qualityAssessment,
  };
}

/**
 * Lanczos Kernel function (Sinc windowed sinc)
 */
export function lanczos3Kernel(x: number): number {
  if (x === 0) return 1;
  const ax = Math.abs(x);
  if (ax >= 3) return 0;
  const piX = Math.PI * x;
  const piXOver3 = piX / 3;
  return (Math.sin(piX) / piX) * (Math.sin(piXOver3) / piXOver3);
}

/**
 * Catmull-Rom Bicubic Kernel
 */
export function bicubicKernel(x: number): number {
  const ax = Math.abs(x);
  if (ax <= 1) {
    return 1.5 * ax * ax * ax - 2.5 * ax * ax + 1;
  } else if (ax < 2) {
    return -0.5 * ax * ax * ax + 2.5 * ax * ax - 4 * ax + 2;
  }
  return 0;
}

/**
 * Output Sharpening Parameter Recommendations based on Paper Finish and Output DPI
 */
export function calculateOutputSharpeningParameters(
  paperFinish: PaperFinish,
  outputDpi: number,
  viewingDistanceCm: number = 50
) {
  // Matte & cotton rag papers absorb ink and suffer higher dot gain (~20-25%), requiring stronger compensation
  // Glossy and baryta have micro-porous coating with low dot gain (~10-14%), requiring sharper, smaller radius
  let baseRadius = 0.8;
  let baseAmount = 1.2;
  let threshold = 3;

  switch (paperFinish) {
    case 'matte':
    case 'cotton rag':
      baseRadius = outputDpi >= 2880 ? 1.4 : 1.1;
      baseAmount = 1.6;
      threshold = 4;
      break;
    case 'baryta':
    case 'luster':
    case 'semi-gloss':
      baseRadius = outputDpi >= 2880 ? 0.9 : 0.8;
      baseAmount = 1.35;
      threshold = 2;
      break;
    case 'glossy':
      baseRadius = 0.7;
      baseAmount = 1.25;
      threshold = 2;
      break;
    case 'canvas':
      baseRadius = 1.6;
      baseAmount = 1.8;
      threshold = 5;
      break;
    default:
      baseRadius = 1.0;
      baseAmount = 1.3;
      threshold = 3;
  }

  // Adjust for viewing distance
  if (viewingDistanceCm > 80) {
    baseRadius *= 1.3;
    baseAmount *= 1.1;
  }

  return {
    radius: Math.round(baseRadius * 10) / 10,
    amount: Math.round(baseAmount * 100) / 100,
    threshold,
  };
}

/**
 * Calculate effective resolution for image on print substrate
 */
export function calculateEffectiveResolution(
  widthPx: number,
  heightPx: number,
  widthMm: number,
  heightMm: number
) {
  const widthInches = widthMm / 25.4;
  const heightInches = heightMm / 25.4;
  const dpiX = Math.round(widthPx / widthInches);
  const dpiY = Math.round(heightPx / heightInches);
  const effectiveDpi = Math.min(dpiX, dpiY);

  let rating = 'Standard';
  if (effectiveDpi >= 360) rating = 'Museum / Exhibition Master (360+ DPI)';
  else if (effectiveDpi >= 240) rating = 'Gallery Fine Art (240-360 DPI)';
  else if (effectiveDpi >= 180) rating = 'High Quality Commercial (180-240 DPI)';
  else rating = 'Low Acuity / Billboards Only (<180 DPI)';

  return {
    dpi_x: dpiX,
    dpi_y: dpiY,
    effective_dpi: effectiveDpi,
    quality_rating: rating,
  };
}

/**
 * Calculate optical resolving limit of human visual system (60 cycles/degree)
 */
export function calculateViewingDistanceLimits(viewingDistanceMm: number = 500) {
  // Visual angle subtended: 1 arcminute ≈ 1/60 degree
  // At distance D (mm), 1 arcminute = 2 * D * tan(0.5 / 60 degrees) ≈ D * 0.000290888 mm
  // Resolving limit (DPI) = 25.4 / (D * 0.000290888)
  const resolvingDpi = Math.round(25.4 / (viewingDistanceMm * 0.000290888));

  return {
    viewing_distance_mm: viewingDistanceMm,
    resolving_limit_dpi: resolvingDpi,
    human_fovea_cycles_per_degree: 60,
  };
}

