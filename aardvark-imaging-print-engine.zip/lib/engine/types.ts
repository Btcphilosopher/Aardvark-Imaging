/**
 * AARDVARK IMAGING PRINT ENGINE
 * Canonical Types and System Models
 */

export type JobStatus =
  | 'DRAFT'
  | 'VALIDATING'
  | 'PROOFING'
  | 'RIPPING'
  | 'QUEUED'
  | 'PRINTING'
  | 'FINISHING'
  | 'QC'
  | 'COMPLETE'
  | 'FAILED'
  | 'CANCELLED'
  | 'ARCHIVED';

export type RenderingIntent =
  | 'PERCEPTUAL'
  | 'RELATIVE_COLORIMETRIC'
  | 'ABSOLUTE_COLORIMETRIC'
  | 'SATURATION';

export type ColourSpaceName =
  | 'sRGB'
  | 'AdobeRGB_1998'
  | 'Display_P3'
  | 'ProPhoto_RGB'
  | 'Rec2020'
  | 'Rec709'
  | 'CIE_XYZ'
  | 'CIE_Lab'
  | 'Custom_ICC';

export type BitDepth = 8 | 10 | 12 | 14 | 16 | 32;

export type HalftoneMethod =
  | 'ERROR_DIFFUSION_FLOYD_STEINBERG'
  | 'ERROR_DIFFUSION_JARVIS'
  | 'ORDERED_BAYER_8X8'
  | 'BLUE_NOISE_STOCHASTIC'
  | 'CLUSTERED_DOT_AM'
  | 'HYBRID_SCREENING';

export type ResamplingMethod =
  | 'NEAREST_NEIGHBOUR'
  | 'BILINEAR'
  | 'BICUBIC_CATMULL_ROM'
  | 'LANCZOS_3'
  | 'SINC_WINDOWED';

export type SharpeningMethod =
  | 'UNSHARP_MASK'
  | 'GAUSSIAN_HIGH_PASS'
  | 'EDGE_AWARE_ADAPTIVE'
  | 'MULTI_SCALE_PYRAMID';

export type PaperFinish =
  | 'glossy'
  | 'semi-gloss'
  | 'luster'
  | 'matte'
  | 'baryta'
  | 'cotton rag'
  | 'fine art'
  | 'canvas'
  | 'film'
  | 'proofing paper'
  | 'synthetic'
  | 'custom';

export type PrinterTechnology =
  | 'pigment inkjet'
  | 'dye inkjet'
  | 'dye sublimation'
  | 'laser'
  | 'electrophotographic'
  | 'large-format flatbed'
  | 'large-format roll-fed';

export type InkChannelName =
  | 'C'   // Cyan
  | 'M'   // Magenta
  | 'Y'   // Yellow
  | 'PK'  // Photo Black
  | 'MK'  // Matte Black
  | 'LC'  // Light Cyan
  | 'LM'  // Light Magenta
  | 'LK'  // Light Black
  | 'LLK' // Light Light Black
  | 'OR'  // Orange
  | 'GR'  // Green
  | 'V'   // Violet
  | 'CO'; // Chroma Optimizer

export type QCStatus = 'PASS' | 'WARNING' | 'FAIL';

export interface ImageMetadata {
  title: string;
  creator: string;
  copyright: string;
  captureDevice: string;
  lens: string;
  focalLength: string;
  aperture: string;
  shutterSpeed: string;
  iso: number;
  captureDate: string;
  sourceColourSpace: ColourSpaceName;
  bitDepth: BitDepth;
  nativeWidth: number;
  nativeHeight: number;
  iccProfileName: string;
  hash: string;
}

export interface ICCProfile {
  profile_id: string;
  name: string;
  manufacturer: string;
  device: string;
  media: string;
  ink_set: string;
  illuminant: 'D50' | 'D65' | 'A' | 'C';
  white_point: [number, number, number]; // XYZ
  black_point: [number, number, number]; // XYZ
  gamma: number;
  trc_type: 'parametric' | 'sampled' | 'linear';
  primaries: {
    r: [number, number, number];
    g: [number, number, number];
    b: [number, number, number];
  };
  gamut_volume: number; // in Lab Delta E^3
  version: string;
  creation_date: string;
  source: string;
}

export interface PaperProfile {
  paper_id: string;
  manufacturer: string;
  name: string;
  type: PaperFinish;
  finish: string;
  weight_gsm: number;
  thickness_mm: number;
  whiteness_cie: number;
  opacity_percent: number;
  texture: 'ultra-smooth' | 'smooth' | 'fine-textured' | 'textured' | 'linen';
  coating: string;
  absorption_rate: number; // 0.0 - 1.0
  maximum_ink_load_tac: number; // % e.g. 320%
  recommended_resolution_dpi: number;
  icc_profile_id: string;
  drying_time_minutes: number;
  archival_rating_years: number;
  cost_per_sqm: number;
  paper_white_lab: [number, number, number];
  black_point_dmax: number;
}

export interface InkProfile {
  ink_set_id: string;
  name: string;
  manufacturer: string;
  type: 'aqueous pigment' | 'dye-based' | 'solvent' | 'uv-curable';
  channels: InkChannelName[];
  droplet_size_min_pl: number;
  droplet_size_max_pl: number;
  droplet_frequencies_khz: number[];
  cost_per_ml: number;
  cartridge_capacity_ml: number;
  lightfastness_rating_years: number;
}

export interface PrinterModel {
  printer_id: string;
  manufacturer: string;
  model: string;
  technology: PrinterTechnology;
  max_width_mm: number;
  max_height_mm: number;
  max_resolution_dpi: [number, number]; // [horizontal, vertical] e.g. [2880, 1440]
  ink_channels: InkChannelName[];
  ink_set_id: string;
  paper_support: ('roll' | 'sheet' | 'board')[];
  borderless_support: boolean;
  duplex: boolean;
  maximum_ink_density: number;
  print_speed_sqm_per_hr: number;
  power_consumption_w: number;
  maintenance_interval_hours: number;
  driver_version: string;
  ip_address: string;
  status: 'ONLINE' | 'PRINTING' | 'MAINTENANCE' | 'OFFLINE';
}

export interface PrintDimensions {
  width_mm: number;
  height_mm: number;
  width_inches: number;
  height_inches: number;
  orientation: 'PORTRAIT' | 'LANDSCAPE';
}

export interface PrintJob {
  job_id: string;
  source_image: {
    uri: string;
    filename: string;
    width_px: number;
    height_px: number;
    metadata: ImageMetadata;
  };
  source_colour_space: ColourSpaceName;
  source_bit_depth: BitDepth;
  source_resolution: number; // DPI
  target_printer: string; // printer_id
  target_media: string; // paper_id
  target_profile: string; // icc_profile_id
  target_dimensions: PrintDimensions;
  orientation: 'PORTRAIT' | 'LANDSCAPE';
  scale: number;
  crop: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  bleed_mm: number;
  margins_mm: {
    top: number;
    bottom: number;
    left: number;
    right: number;
  };
  border_mm: number;
  layout: 'SINGLE' | 'CONTACT_SHEET' | 'DIPTYCH' | 'TRIPTYCH' | 'TILED_POSTER';
  render_intent: RenderingIntent;
  black_point_compensation: boolean;
  output_resolution: number; // e.g. 2880 or 1440 DPI
  ink_configuration: InkChannelName[];
  ink_limits: {
    total_area_coverage_max: number; // e.g. 300%
    per_channel_max: Record<InkChannelName, number>;
  };
  halftone_method: HalftoneMethod;
  dither_method: string;
  sharpening: {
    enabled: boolean;
    method: SharpeningMethod;
    radius: number;
    amount: number;
    threshold: number;
  };
  tone_mapping: {
    contrast: number;
    highlight_protection: number;
    shadow_open: number;
    black_point_shift: number;
  };
  quality_mode: 'DRAFT_720' | 'PRODUCTION_1440' | 'FINE_ART_2880' | 'MUSEUM_MASTER';
  copies: number;
  priority: 'NORMAL' | 'HIGH' | 'RUSH_CRITICAL';
  estimated_ink_ml: number;
  estimated_media_sqm: number;
  estimated_time_seconds: number;
  estimated_cost: {
    ink: number;
    paper: number;
    energy: number;
    depreciation: number;
    maintenance: number;
    labour: number;
    waste: number;
    total: number;
  };
  status: JobStatus;
  created_at: string;
  started_at?: string;
  completed_at?: string;
  operator: string;
  quality_result?: QCResult;
  rip_progress?: number;
  print_progress?: number;
}

export interface QCResult {
  qc_id: string;
  job_id: string;
  timestamp: string;
  inspector: string;
  status: QCStatus;
  mean_delta_e_2000: number;
  max_delta_e_2000: number;
  percentile_95_delta_e: number;
  std_dev_delta_e: number;
  density_neutrality_score: number; // 0-100
  banding_index: number; // 0-10
  registration_skew_mm: number;
  nozzle_outage_detected: boolean;
  measured_patches: {
    patch_id: string;
    name: string;
    reference_lab: [number, number, number];
    measured_lab: [number, number, number];
    delta_e_2000: number;
    status: QCStatus;
  }[];
  comments: string;
}

export interface DigitalTwinTelemetry {
  printer_id: string;
  timestamp: string;
  carriage_position_mm: number;
  carriage_velocity_mps: number;
  head_temperature_c: number;
  platen_vacuum_kpa: number;
  drying_heater_c: number;
  relative_humidity_percent: number;
  ambient_temperature_c: number;
  ink_levels_percent: Record<InkChannelName, number>;
  nozzle_health_percent: Record<InkChannelName, number>;
  paper_feed_position_mm: number;
  total_print_hours: number;
  maintenance_countdown_hours: number;
  failure_risk_score: number; // 0.0 - 1.0
  active_warnings: string[];
}

export interface SpectrophotometerMeasurement {
  patch_id: string;
  timestamp: string;
  illuminant: 'D50' | 'D65';
  spectral_wavelengths: number[]; // 380 - 730 nm
  spectral_reflectance: number[]; // 0.0 - 1.0
  cie_xyz: [number, number, number];
  cie_lab: [number, number, number];
}

export interface InventoryItem {
  sku: string;
  category: 'PAPER' | 'INK_CARTRIDGE' | 'PRINT_HEAD' | 'MAINTENANCE_TANK' | 'ROLLER_KIT' | 'CLEANING_WIPES';
  name: string;
  supplier: string;
  quantity: number;
  unit: string;
  reorder_level: number;
  unit_cost: number;
  location: string;
  lot_number: string;
  expiry_date?: string;
}

export type Screen =
  | 'PrintCommandCentre'
  | 'JobQueue'
  | 'ImageInspector'
  | 'SoftProof'
  | 'ColourManagement'
  | 'PrinterManager'
  | 'PaperManager'
  | 'InkManager'
  | 'RIPMonitor'
  | 'ProductionMonitor'
  | 'Calibration'
  | 'QualityControl'
  | 'Inventory'
  | 'Costing'
  | 'Archive'
  | 'DigitalTwin'
  | 'Settings';

