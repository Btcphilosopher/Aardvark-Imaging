/**
 * AARDVARK IMAGING PRINT ENGINE
 * Soft Proof Engine
 * Simulates physical print appearance on a calibrated monitor profile,
 * factoring in paper white tint, paper black point (Dmax), and gamut compression.
 */

import { PaperProfile, RenderingIntent, ColourSpaceName } from './types';
import { rgbToLab, labToRgb, deltaE2000, applyBlackPointCompensation } from './colour-science';
import { createPaperGamutModel, mapToGamut, checkColourGamut } from './gamut-engine';

export interface SoftProofOptions {
  paper: PaperProfile;
  intent: RenderingIntent;
  simulatePaperWhite: boolean;
  simulateBlackInk: boolean;
  blackPointCompensation: boolean;
  sourceColourSpace: ColourSpaceName;
  monitorColourSpace: ColourSpaceName;
}

export interface SoftProofPixelResult {
  proofRgb: [number, number, number];
  sourceLab: [number, number, number];
  proofLab: [number, number, number];
  deltaE: number;
  isOutOfGamut: boolean;
  isNearBoundary: boolean;
}

/**
 * Process a single RGB pixel through the soft proofing pipeline
 */
export function softProofPixel(
  r: number,
  g: number,
  b: number,
  options: SoftProofOptions
): SoftProofPixelResult {
  const { paper, intent, simulatePaperWhite, simulateBlackInk, blackPointCompensation, sourceColourSpace, monitorColourSpace } = options;

  // 1. Source RGB -> Profile Connection Space (Lab)
  const sourceLab = rgbToLab(r, g, b, sourceColourSpace);

  // 2. Build paper gamut model
  const gamutModel = createPaperGamutModel(paper);

  // 3. Black Point Compensation if requested
  let proofLab = [...sourceLab] as [number, number, number];
  if (blackPointCompensation) {
    const minL = Math.max(2.5, 100 * Math.pow(10, -paper.black_point_dmax));
    proofLab = applyBlackPointCompensation(proofLab, 0.0, minL, 100.0, paper.paper_white_lab[0]);
  }

  // 4. Gamut mapping to target paper/printer profile
  proofLab = mapToGamut(proofLab, gamutModel, intent);

  // 5. Simulate Paper White if Absolute Colorimetric or explicitly toggled
  if (simulatePaperWhite || intent === 'ABSOLUTE_COLORIMETRIC') {
    // Tint highlights towards the paper substrate color
    const paperWhite = paper.paper_white_lab;
    const highlightFactor = Math.pow(Math.max(0, proofLab[0] - 50) / 50, 1.5);
    proofLab[0] = Math.min(proofLab[0], paperWhite[0]);
    proofLab[1] += paperWhite[1] * highlightFactor * 0.4;
    proofLab[2] += paperWhite[2] * highlightFactor * 0.4;
  }

  // 6. Simulate Black Ink (media Dmax floor)
  if (simulateBlackInk) {
    const minL = Math.max(2.5, 100 * Math.pow(10, -paper.black_point_dmax));
    if (proofLab[0] < minL) {
      proofLab[0] = minL;
    }
  }

  // 7. Check gamut status
  const gamutCheck = checkColourGamut(sourceLab, gamutModel);
  const deltaE = deltaE2000(sourceLab, proofLab);

  // 8. Convert back to monitor RGB
  const proofRgb = labToRgb(proofLab, monitorColourSpace);

  return {
    proofRgb,
    sourceLab,
    proofLab,
    deltaE,
    isOutOfGamut: !gamutCheck.inGamut,
    isNearBoundary: gamutCheck.nearBoundary,
  };
}
