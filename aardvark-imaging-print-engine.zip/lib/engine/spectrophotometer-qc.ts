/**
 * AARDVARK IMAGING PRINT ENGINE
 * Spectrophotometer Interface, Test Chart Generator & Scanned QC Engine
 */

import { deltaE2000 } from './colour-science';
import { QCResult, QCStatus } from './types';

export interface SpectralReflectanceCurve {
  wavelengthsNm: number[]; // 380 to 730 nm step 10nm (36 points)
  reflectance: number[];   // 0.0 to 1.0
}

export interface PatchMeasurement {
  id: string;
  name: string;
  nominalLab: [number, number, number];
  measuredLab: [number, number, number];
  deltaE: number;
  status: QCStatus;
  spectral?: SpectralReflectanceCurve;
}

/**
 * Standard 24-Patch Photographic Target (CIE Lab values under D50 2°)
 */
export const COLOR_CHECKER_24_TARGETS: { name: string; lab: [number, number, number] }[] = [
  { name: 'Dark Skin', lab: [37.986, 13.555, 14.059] },
  { name: 'Light Skin', lab: [65.711, 18.130, 17.810] },
  { name: 'Blue Sky', lab: [49.927, -4.880, -21.925] },
  { name: 'Foliage', lab: [43.139, -13.095, 21.905] },
  { name: 'Blue Flower', lab: [55.112, 8.844, -25.399] },
  { name: 'Bluish Green', lab: [70.719, -33.397, -0.199] },
  { name: 'Orange', lab: [62.661, 36.067, 57.096] },
  { name: 'Purplish Blue', lab: [40.020, 10.410, -45.964] },
  { name: 'Moderate Red', lab: [51.124, 48.239, 16.248] },
  { name: 'Purple', lab: [30.325, 22.976, -21.587] },
  { name: 'Yellow Green', lab: [72.532, -23.709, 57.255] },
  { name: 'Orange Yellow', lab: [71.941, 19.363, 67.857] },
  { name: 'Blue', lab: [28.778, 14.179, -50.297] },
  { name: 'Green', lab: [55.261, -38.342, 31.370] },
  { name: 'Red', lab: [42.101, 53.378, 28.190] },
  { name: 'Yellow', lab: [81.733, 4.039, 79.819] },
  { name: 'Magenta', lab: [51.666, 49.986, -14.574] },
  { name: 'Cyan', lab: [50.627, -28.719, -28.646] },
  { name: 'White 9.5 (.05 D)', lab: [96.539, -0.425, 1.186] },
  { name: 'Neutral 8 (.23 D)', lab: [81.257, -0.638, -0.335] },
  { name: 'Neutral 6.5 (.44 D)', lab: [66.766, -0.734, -0.504] },
  { name: 'Neutral 5 (.70 D)', lab: [50.867, -0.153, -0.270] },
  { name: 'Neutral 3.5 (1.05 D)', lab: [35.656, -0.421, -1.231] },
  { name: 'Black 2 (1.5 D)', lab: [20.461, -0.079, -0.973] },
];

/**
 * Hardware Abstraction Interface for Spectrophotometers
 */
export interface SpectrophotometerDriver {
  deviceId: string;
  manufacturer: string;
  model: string;
  isConnected: boolean;
  connect: () => Promise<boolean>;
  disconnect: () => Promise<void>;
  measurePatch: (patchId: string) => Promise<PatchMeasurement>;
  measureChart: (chartType: 'COLOR_CHECKER_24' | 'IT8_7_4' | 'NEUTRAL_RAMP') => Promise<QCResult>;
}

/**
 * Automated QC evaluation of measured patches against target references
 */
export function evaluatePrintQuality(
  jobId: string,
  inspector: string = 'Automated Spectro QC Station 1',
  simulatedErrorLevel: 'EXCELLENT' | 'TYPICAL' | 'DEFECTIVE' = 'EXCELLENT'
): QCResult {
  const patches: PatchMeasurement[] = [];
  let sumDeltaE = 0;
  let maxDeltaE = 0;
  const deltaEList: number[] = [];

  const noiseScale = simulatedErrorLevel === 'EXCELLENT' ? 0.4 : simulatedErrorLevel === 'TYPICAL' ? 1.1 : 3.8;

  for (let i = 0; i < COLOR_CHECKER_24_TARGETS.length; i++) {
    const target = COLOR_CHECKER_24_TARGETS[i];
    // Deterministic pseudo error to simulate real physical print variation
    const dL = (Math.sin(i * 1.7) * 0.5 + 0.1) * noiseScale;
    const da = (Math.cos(i * 2.3) * 0.4 - 0.1) * noiseScale;
    const db = (Math.sin(i * 0.9) * 0.4 + 0.05) * noiseScale;

    const measuredLab: [number, number, number] = [
      Math.max(0, Math.min(100, target.lab[0] + dL)),
      target.lab[1] + da,
      target.lab[2] + db,
    ];

    const dE00 = deltaE2000(target.lab, measuredLab);
    deltaEList.push(dE00);
    sumDeltaE += dE00;
    if (dE00 > maxDeltaE) maxDeltaE = dE00;

    let patchStatus: QCStatus = 'PASS';
    if (dE00 > 3.0) {
      patchStatus = 'FAIL';
    } else if (dE00 > 1.5) {
      patchStatus = 'WARNING';
    }

    patches.push({
      id: `P${i + 1}`,
      name: target.name,
      nominalLab: target.lab,
      measuredLab,
      deltaE: Math.round(dE00 * 100) / 100,
      status: patchStatus,
    });
  }

  deltaEList.sort((a, b) => a - b);
  const meanDeltaE = Math.round((sumDeltaE / deltaEList.length) * 100) / 100;
  const percentile95Idx = Math.floor(deltaEList.length * 0.95);
  const percentile95 = Math.round(deltaEList[percentile95Idx] * 100) / 100;

  // Standard deviation
  const variance = deltaEList.reduce((acc, val) => acc + Math.pow(val - meanDeltaE, 2), 0) / deltaEList.length;
  const stdDev = Math.round(Math.sqrt(variance) * 100) / 100;

  let overallStatus: QCStatus = 'PASS';
  if (meanDeltaE > 2.0 || maxDeltaE > 4.5 || simulatedErrorLevel === 'DEFECTIVE') {
    overallStatus = 'FAIL';
  } else if (meanDeltaE > 1.2 || maxDeltaE > 2.5) {
    overallStatus = 'WARNING';
  }

  return {
    qc_id: `QC-${Date.now().toString(36).toUpperCase()}`,
    job_id: jobId,
    timestamp: new Date().toISOString(),
    inspector,
    status: overallStatus,
    mean_delta_e_2000: meanDeltaE,
    max_delta_e_2000: Math.round(maxDeltaE * 100) / 100,
    percentile_95_delta_e: percentile95,
    std_dev_delta_e: stdDev,
    density_neutrality_score: simulatedErrorLevel === 'EXCELLENT' ? 98.4 : simulatedErrorLevel === 'TYPICAL' ? 92.1 : 74.0,
    banding_index: simulatedErrorLevel === 'EXCELLENT' ? 0.3 : 1.8,
    registration_skew_mm: simulatedErrorLevel === 'EXCELLENT' ? 0.08 : 0.35,
    nozzle_outage_detected: simulatedErrorLevel === 'DEFECTIVE',
    measured_patches: patches.map(p => ({
      patch_id: p.id,
      name: p.name,
      reference_lab: p.nominalLab,
      measured_lab: p.measuredLab,
      delta_e_2000: p.deltaE,
      status: p.status,
    })),
    comments: overallStatus === 'PASS'
      ? 'Fogra 51 / ISO 12647-7 Proofing Certification criteria satisfied. Delta E 2000 within laboratory museum tolerances.'
      : overallStatus === 'WARNING'
      ? 'Minor chroma deviation in saturated magenta/red patches. Permissible for commercial exhibition.'
      : 'Out-of-tolerance colour drift detected. Recalibrate spectrophotometer and run head cleaning cycle.',
  };
}
