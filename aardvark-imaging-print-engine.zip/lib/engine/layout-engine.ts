/**
 * AARDVARK IMAGING PRINT ENGINE
 * Page Layout, Bleed, Marks & Poster Tiling Engine
 * All physical geometry computed in millimetres (mm).
 */

export interface PageGeometry {
  sheetWidthMm: number;
  sheetHeightMm: number;
  imageWidthMm: number;
  imageHeightMm: number;
  bleedMm: number;
  marginsMm: {
    top: number;
    bottom: number;
    left: number;
    right: number;
  };
  borderMm: number;
  printableWidthMm: number;
  printableHeightMm: number;
  cropBox: { x: number; y: number; width: number; height: number };
  bleedBox: { x: number; y: number; width: number; height: number };
  trimBox: { x: number; y: number; width: number; height: number };
}

export interface PosterTile {
  tileId: string; // e.g. "Tile A1", "Tile A2"
  rowIndex: number;
  colIndex: number;
  xMm: number;
  yMm: number;
  widthMm: number;
  heightMm: number;
  overlapMm: number;
  cutLineMarks: { x: number; y: number; length: number; orientation: 'H' | 'V' }[];
  label: string;
}

/**
 * Standard paper formats in millimeters
 */
export const STANDARD_PAPER_FORMATS: Record<string, { width: number; height: number; name: string }> = {
  A4: { width: 210, height: 297, name: 'ISO A4' },
  A3: { width: 297, height: 420, name: 'ISO A3' },
  A3_PLUS: { width: 329, height: 483, name: 'Super A3 / A3+' },
  A2: { width: 420, height: 594, name: 'ISO A2' },
  A1: { width: 594, height: 841, name: 'ISO A1' },
  A0: { width: 841, height: 1189, name: 'ISO A0' },
  ROLL_24_INCH: { width: 610, height: 914, name: '24" Roll (Arch D)' },
  ROLL_44_INCH: { width: 1118, height: 1600, name: '44" Roll Exhibition' },
  ROLL_60_INCH: { width: 1524, height: 2200, name: '60" Roll Grand Format' },
};

/**
 * Calculate precise physical layout boxes including bleed and trim
 */
export function calculatePageGeometry(
  sheetWidthMm: number,
  sheetHeightMm: number,
  desiredImageWidthMm: number,
  desiredImageHeightMm: number,
  bleedMm: number = 3.0,
  borderMm: number = 0.0,
  marginsMm = { top: 15, bottom: 20, left: 15, right: 15 }
): PageGeometry {
  const printableWidthMm = sheetWidthMm - (marginsMm.left + marginsMm.right);
  const printableHeightMm = sheetHeightMm - (marginsMm.top + marginsMm.bottom);

  // Center image inside printable area
  const imageX = marginsMm.left + (printableWidthMm - desiredImageWidthMm) / 2;
  const imageY = marginsMm.top + (printableHeightMm - desiredImageHeightMm) / 2;

  const trimBox = {
    x: imageX - borderMm,
    y: imageY - borderMm,
    width: desiredImageWidthMm + borderMm * 2,
    height: desiredImageHeightMm + borderMm * 2,
  };

  const bleedBox = {
    x: trimBox.x - bleedMm,
    y: trimBox.y - bleedMm,
    width: trimBox.width + bleedMm * 2,
    height: trimBox.height + bleedMm * 2,
  };

  const cropBox = {
    x: 0,
    y: 0,
    width: sheetWidthMm,
    height: sheetHeightMm,
  };

  return {
    sheetWidthMm,
    sheetHeightMm,
    imageWidthMm: desiredImageWidthMm,
    imageHeightMm: desiredImageHeightMm,
    bleedMm,
    marginsMm,
    borderMm,
    printableWidthMm,
    printableHeightMm,
    cropBox,
    bleedBox,
    trimBox,
  };
}

/**
 * Partition large artwork into multi-sheet poster tiles with assembly overlaps
 */
export function generatePosterTiles(
  totalWidthMm: number,
  totalHeightMm: number,
  sheetWidthMm: number,
  sheetHeightMm: number,
  overlapMm: number = 15.0
): PosterTile[] {
  const effectiveSheetW = sheetWidthMm - overlapMm;
  const effectiveSheetH = sheetHeightMm - overlapMm;

  const cols = Math.ceil(totalWidthMm / effectiveSheetW);
  const rows = Math.ceil(totalHeightMm / effectiveSheetH);

  const tiles: PosterTile[] = [];
  const rowLetters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const tileId = `Tile ${rowLetters[r] || 'Z'}${c + 1}`;
      const xMm = c * effectiveSheetW;
      const yMm = r * effectiveSheetH;
      const widthMm = Math.min(sheetWidthMm, totalWidthMm - xMm + overlapMm);
      const heightMm = Math.min(sheetHeightMm, totalHeightMm - yMm + overlapMm);

      tiles.push({
        tileId,
        rowIndex: r,
        colIndex: c,
        xMm,
        yMm,
        widthMm,
        heightMm,
        overlapMm,
        label: `${tileId} of ${rows * cols} (Assembly Overlap: ${overlapMm}mm)`,
        cutLineMarks: [
          { x: overlapMm, y: 0, length: 10, orientation: 'V' },
          { x: overlapMm, y: heightMm - 10, length: 10, orientation: 'V' },
        ],
      });
    }
  }

  return tiles;
}
