'use client';

import React, { useState } from 'react';
import { Settings as SettingsIcon, Save, Cpu, Layers, HardDrive } from 'lucide-react';

export function SettingsView() {
  const [memoryMb, setMemoryMb] = useState<number>(4096);
  const [threads, setThreads] = useState<number>(16);
  const [units, setUnits] = useState<'MM' | 'INCHES'>('MM');
  const [defaultIntent, setDefaultIntent] = useState<string>('RELATIVE_COLORIMETRIC');

  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-900 text-zinc-100 overflow-y-auto p-4 space-y-4 font-mono text-xs">
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <SettingsIcon className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-zinc-100">
              System Configuration & Engine Preferences
            </h2>
            <div className="text-xs text-zinc-400">
              RIP worker threads, memory buffers, units, and default colorimetric rendering intents
            </div>
          </div>
        </div>

        <button className="flex items-center gap-2 px-3 py-1.5 rounded bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs shadow">
          <Save className="w-3.5 h-3.5" />
          <span>Save Preferences</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* RIP Performance Config */}
        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-4 space-y-4">
          <h3 className="font-bold text-zinc-200 uppercase text-xs pb-2 border-b border-zinc-850">
            RIP Processing & Threading Budget
          </h3>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-zinc-400">Memory Allocation Budget:</span>
                <span className="text-amber-400 font-bold">{memoryMb} MB</span>
              </div>
              <input
                type="range"
                min="1024"
                max="16384"
                step="512"
                value={memoryMb}
                onChange={e => setMemoryMb(Number(e.target.value))}
                className="w-full accent-amber-500"
              />
              <span className="text-[10px] text-zinc-500">Allocated for multi-band 16K image buffering</span>
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-zinc-400">Parallel SIMD Worker Threads:</span>
                <span className="text-cyan-400 font-bold">{threads} Cores</span>
              </div>
              <input
                type="range"
                min="2"
                max="32"
                step="2"
                value={threads}
                onChange={e => setThreads(Number(e.target.value))}
                className="w-full accent-cyan-500"
              />
            </div>
          </div>
        </div>

        {/* Units and Color Defaults */}
        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-4 space-y-4">
          <h3 className="font-bold text-zinc-200 uppercase text-xs pb-2 border-b border-zinc-850">
            Prepress Metric & Color Defaults
          </h3>

          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-zinc-400">Measurement System:</span>
              <div className="flex gap-1">
                <button
                  onClick={() => setUnits('MM')}
                  className={`px-3 py-1 rounded text-xs ${
                    units === 'MM' ? 'bg-amber-500 text-zinc-950 font-bold' : 'bg-zinc-900 text-zinc-400'
                  }`}
                >
                  Millimetres (mm)
                </button>
                <button
                  onClick={() => setUnits('INCHES')}
                  className={`px-3 py-1 rounded text-xs ${
                    units === 'INCHES' ? 'bg-amber-500 text-zinc-950 font-bold' : 'bg-zinc-900 text-zinc-400'
                  }`}
                >
                  Inches (″)
                </button>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-zinc-400">Default Rendering Intent:</span>
              <select
                value={defaultIntent}
                onChange={e => setDefaultIntent(e.target.value)}
                className="bg-zinc-900 border border-zinc-700 rounded px-2.5 py-1 text-zinc-200"
              >
                <option value="RELATIVE_COLORIMETRIC">Relative Colorimetric</option>
                <option value="PERCEPTUAL">Perceptual (Photographic)</option>
                <option value="ABSOLUTE_COLORIMETRIC">Absolute Colorimetric</option>
              </select>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
