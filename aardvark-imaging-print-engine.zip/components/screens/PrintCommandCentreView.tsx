'use client';

import React, { useState } from 'react';
import { 
  Printer, 
  Layers, 
  Maximize2, 
  ShieldCheck, 
  Activity, 
  Droplets, 
  Play, 
  Cpu, 
  ArrowRight, 
  Sliders, 
  Check, 
  RotateCw, 
  Info,
  Calendar,
  Sparkles
} from 'lucide-react';
import { PrintJob, PaperProfile, InkChannelName, RenderingIntent } from '@/lib/engine/types';
import { calculateEffectiveResolution, calculateViewingDistanceLimits } from '@/lib/engine/resolution-resampling';
import { calculatePageGeometry } from '@/lib/engine/layout-engine';

interface PrintCommandCentreViewProps {
  job: PrintJob;
  paper: PaperProfile;
  papersList: PaperProfile[];
  onUpdateJob: (updated: Partial<PrintJob>) => void;
  onSelectPaper: (paperId: string) => void;
  onRunWorkflow: () => void;
  onNavigateToScreen: (screen: any) => void;
  isWorkflowRunning: boolean;
  workflowStep: number;
}

export function PrintCommandCentreView({
  job,
  paper,
  papersList,
  onUpdateJob,
  onSelectPaper,
  onRunWorkflow,
  onNavigateToScreen,
  isWorkflowRunning,
  workflowStep,
}: PrintCommandCentreViewProps) {
  const [selectedPreset, setSelectedPreset] = useState<string>('EXHIBITION');

  // Calculate resolution & viewing geometry
  const resMetrics = calculateEffectiveResolution(
    job.source_image.width_px,
    job.source_image.height_px,
    job.target_dimensions.width_mm,
    job.target_dimensions.height_mm
  );

  const viewingMetrics = calculateViewingDistanceLimits(500); // 500mm standard viewing distance

  // Physical Layout boxes
  const geometry = calculatePageGeometry(
    job.target_dimensions.width_mm + 40,
    job.target_dimensions.height_mm + 40,
    job.target_dimensions.width_mm,
    job.target_dimensions.height_mm,
    job.bleed_mm,
    job.border_mm,
    job.margins_mm
  );

  const presets = [
    { id: 'EXHIBITION', name: 'Museum Exhibition (Baryta 2880 DPI, Relative BPC)' },
    { id: 'FINE_ART_MATTE', name: 'Fine Art Cotton Rag (Smooth 308gsm, Perceptual)' },
    { id: 'PHOTO_LUSTER', name: 'Commercial Photo Luster (260gsm, Relative)' },
    { id: 'PROOFING', name: 'ISO 12647-7 Contract Proof (Absolute Colorimetric)' },
  ];

  const handlePresetSelect = (presetId: string) => {
    setSelectedPreset(presetId);
    if (presetId === 'FINE_ART_MATTE') {
      onSelectPaper('PAP-MUSEUM-RAG-308');
      onUpdateJob({
        render_intent: 'PERCEPTUAL' as RenderingIntent,
        black_point_compensation: true,
        output_resolution: 2880,
      });
    } else if (presetId === 'EXHIBITION') {
      onSelectPaper('PAP-BARYTA-310');
      onUpdateJob({
        render_intent: 'RELATIVE_COLORIMETRIC' as RenderingIntent,
        black_point_compensation: true,
        output_resolution: 2880,
      });
    } else if (presetId === 'PHOTO_LUSTER') {
      onSelectPaper('PAP-PHOTO-LUSTER-260');
      onUpdateJob({
        render_intent: 'RELATIVE_COLORIMETRIC' as RenderingIntent,
        black_point_compensation: true,
        output_resolution: 2880,
      });
    } else if (presetId === 'PROOFING') {
      onSelectPaper('PAP-PHOTO-LUSTER-260');
      onUpdateJob({
        render_intent: 'ABSOLUTE_COLORIMETRIC' as RenderingIntent,
        black_point_compensation: false,
        output_resolution: 2880,
      });
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-900 text-zinc-100 overflow-y-auto p-4 space-y-4">
      {/* Top Banner: Workflow status & Execution button */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-4 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 shadow-sm">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-amber-500/20 text-amber-400 border border-amber-500/40">
              JOB ID: {job.job_id}
            </span>
            <span className="text-zinc-400 text-xs font-mono">•</span>
            <span className="text-xs text-zinc-300 font-medium">
              {job.source_image.metadata.title}
            </span>
            <span className="text-xs text-zinc-500">by {job.source_image.metadata.creator}</span>
          </div>
          <div className="text-xs text-zinc-400 flex items-center gap-3">
            <span>
              Target Substrate: <strong className="text-zinc-200">{paper.name}</strong>
            </span>
            <span>•</span>
            <span>
              Print Size:{' '}
              <strong className="text-zinc-200">
                {job.target_dimensions.width_mm} × {job.target_dimensions.height_mm} mm
              </strong>{' '}
              ({job.target_dimensions.width_inches}″ × {job.target_dimensions.height_inches}″)
            </span>
            <span>•</span>
            <span className="text-emerald-400 font-mono font-semibold">
              {resMetrics.effective_dpi} DPI (Optical Sharpness: {resMetrics.quality_rating})
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full lg:w-auto">
          <button
            onClick={onRunWorkflow}
            disabled={isWorkflowRunning}
            className="flex-1 lg:flex-none flex items-center justify-center gap-2 px-4 py-2 rounded-md bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs shadow-md transition-all disabled:opacity-50"
          >
            <Play className={`w-4 h-4 fill-current ${isWorkflowRunning ? 'animate-spin' : ''}`} />
            <span>{isWorkflowRunning ? `Executing Step ${workflowStep} of 22...` : 'Run 22-Step Workflow'}</span>
          </button>
          <button
            onClick={() => onNavigateToScreen('SoftProof')}
            className="flex items-center gap-2 px-3 py-2 rounded-md bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold border border-zinc-700"
          >
            <Layers className="w-4 h-4 text-cyan-400" />
            <span>Soft Proof</span>
          </button>
          <button
            onClick={() => onNavigateToScreen('RIPMonitor')}
            className="flex items-center gap-2 px-3 py-2 rounded-md bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold border border-zinc-700"
          >
            <Cpu className="w-4 h-4 text-amber-400" />
            <span>RIP Engine</span>
          </button>
        </div>
      </div>

      {/* Main 2-Column Workstation Layout */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-4">
        {/* Left Column: Interactive Visual Canvas with Bleed, Crop, and Registration Marks (7 cols) */}
        <div className="xl:col-span-7 bg-zinc-950 border border-zinc-800 rounded-lg p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between pb-3 border-b border-zinc-800 text-xs">
            <div className="flex items-center gap-2">
              <Maximize2 className="w-4 h-4 text-amber-400" />
              <span className="font-bold text-zinc-200 uppercase tracking-wide">
                Platen Proofing Stage & Physical Boundaries
              </span>
            </div>
            <div className="flex items-center gap-3 text-[11px] font-mono text-zinc-400">
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 border border-red-500 bg-red-500/20 inline-block"></span>
                Bleed ({job.bleed_mm}mm)
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 border border-emerald-500 bg-emerald-500/20 inline-block"></span>
                Trim Line
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 border border-cyan-500 bg-cyan-500/10 inline-block"></span>
                Margins
              </span>
            </div>
          </div>

          {/* Visual Canvas Representation */}
          <div className="my-6 relative flex items-center justify-center p-6 bg-zinc-900/90 rounded border border-zinc-800/80 min-h-[380px] overflow-hidden">
            {/* Outer Sheet Surface */}
            <div 
              className="relative shadow-2xl transition-all duration-300 border border-zinc-700 bg-zinc-100 flex items-center justify-center"
              style={{
                width: '88%',
                maxWidth: '560px',
                aspectRatio: `${job.target_dimensions.width_mm} / ${job.target_dimensions.height_mm}`,
                backgroundColor: `rgb(${Math.round(paper.paper_white_lab[0] * 2.55)}, ${Math.round(paper.paper_white_lab[0] * 2.54)}, ${Math.round(paper.paper_white_lab[0] * 2.50)})`
              }}
            >
              {/* Registration Crosshairs in corners */}
              <div className="absolute -top-3 -left-3 w-6 h-6 border-l border-t border-black"></div>
              <div className="absolute -top-3 -right-3 w-6 h-6 border-r border-t border-black"></div>
              <div className="absolute -bottom-3 -left-3 w-6 h-6 border-l border-bottom border-black"></div>
              <div className="absolute -bottom-3 -right-3 w-6 h-6 border-r border-bottom border-black"></div>

              {/* Photographic Artwork Preview */}
              <div 
                className="relative w-full h-full overflow-hidden shadow-inner flex flex-col justify-between"
                style={{
                  backgroundImage: `url(${job.source_image.uri})`,
                  backgroundSize: 'cover',
                  backgroundPosition: 'center',
                }}
              >
                {/* Crop & Bleed Overlay Borders */}
                <div className="absolute inset-0 border-2 border-dashed border-red-500/60 pointer-events-none" />
                <div className="absolute inset-1.5 border border-emerald-500/80 pointer-events-none" />

                {/* Prepress Color Bar Test Strip at bottom */}
                <div className="mt-auto bg-white/90 p-1 flex items-center justify-between border-t border-black/20 text-[9px] font-mono text-zinc-900 select-none">
                  <div className="flex gap-0.5">
                    <span className="w-3 h-3 bg-cyan-500 inline-block"></span>
                    <span className="w-3 h-3 bg-fuchsia-500 inline-block"></span>
                    <span className="w-3 h-3 bg-yellow-400 inline-block"></span>
                    <span className="w-3 h-3 bg-black inline-block"></span>
                    <span className="w-3 h-3 bg-orange-500 inline-block"></span>
                    <span className="w-3 h-3 bg-green-500 inline-block"></span>
                    <span className="w-3 h-3 bg-violet-600 inline-block"></span>
                    <span className="w-3 h-3 bg-zinc-400 inline-block"></span>
                  </div>
                  <div className="truncate px-2">
                    AARDVARK RIP • {job.job_id} • {paper.name} • {job.render_intent} • D50 PCS
                  </div>
                  <div className="font-bold text-[8px] text-zinc-700">ISO 12647-7</div>
                </div>
              </div>
            </div>
          </div>

          {/* Canvas Bottom Details */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-3 border-t border-zinc-800 text-xs font-mono">
            <div>
              <span className="text-zinc-500 text-[10px] uppercase block">Native Pixels</span>
              <span className="font-semibold text-zinc-200">
                {job.source_image.width_px} × {job.source_image.height_px}
              </span>
            </div>
            <div>
              <span className="text-zinc-500 text-[10px] uppercase block">Megapixels</span>
              <span className="font-semibold text-amber-400">
                {Math.round((job.source_image.width_px * job.source_image.height_px) / 1000000)} MP
              </span>
            </div>
            <div>
              <span className="text-zinc-500 text-[10px] uppercase block">Print DPI</span>
              <span className="font-semibold text-emerald-400">{resMetrics.effective_dpi} DPI</span>
            </div>
            <div>
              <span className="text-zinc-500 text-[10px] uppercase block">Media Dmax</span>
              <span className="font-semibold text-zinc-200">{paper.black_point_dmax}</span>
            </div>
          </div>
        </div>

        {/* Right Column: Prepress Configuration, Presets & Ink State (5 cols) */}
        <div className="xl:col-span-5 space-y-4">
          {/* Preset Selector Card */}
          <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-zinc-300">
                Workflow Production Preset
              </span>
              <span className="text-[10px] font-mono text-amber-400 font-semibold">1-CLICK CALIBRATED</span>
            </div>
            <div className="grid grid-cols-1 gap-1.5">
              {presets.map(p => (
                <button
                  key={p.id}
                  onClick={() => handlePresetSelect(p.id)}
                  className={`text-left px-3 py-2 rounded text-xs transition-all flex items-center justify-between ${
                    selectedPreset === p.id
                      ? 'bg-amber-500/15 border border-amber-500/40 text-amber-300 font-semibold'
                      : 'bg-zinc-900 hover:bg-zinc-850 text-zinc-400 border border-zinc-800/80'
                  }`}
                >
                  <span>{p.name}</span>
                  {selectedPreset === p.id && <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                </button>
              ))}
            </div>
          </div>

          {/* Substrate & Profile Details */}
          <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold uppercase tracking-wider text-zinc-300">Target Substrate</span>
              <button
                onClick={() => onNavigateToScreen('PaperManager')}
                className="text-amber-400 hover:underline text-[11px]"
              >
                Media Profiles →
              </button>
            </div>

            <select
              value={paper.paper_id}
              onChange={e => onSelectPaper(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-700 rounded px-2.5 py-1.5 text-xs text-zinc-100 font-mono focus:border-amber-500 outline-none"
            >
              {papersList.map(p => (
                <option key={p.paper_id} value={p.paper_id}>
                  {p.name} ({p.weight_gsm}gsm, TAC {p.maximum_ink_load_tac}%)
                </option>
              ))}
            </select>

            <div className="grid grid-cols-3 gap-2 text-[11px] font-mono bg-zinc-900/60 p-2.5 rounded border border-zinc-800">
              <div>
                <span className="text-zinc-500 block text-[9px]">WEIGHT</span>
                <span className="text-zinc-200 font-semibold">{paper.weight_gsm} gsm</span>
              </div>
              <div>
                <span className="text-zinc-500 block text-[9px]">MAX TAC</span>
                <span className="text-zinc-200 font-semibold">{paper.maximum_ink_load_tac}%</span>
              </div>
              <div>
                <span className="text-zinc-500 block text-[9px]">DRY TIME</span>
                <span className="text-zinc-200 font-semibold">{paper.drying_time_minutes} min</span>
              </div>
            </div>
          </div>

          {/* Rendering Intent & BPC */}
          <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-4 space-y-3">
            <div className="text-xs font-bold uppercase tracking-wider text-zinc-300">
              Colour Conversion Parameters
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-zinc-400">Rendering Intent:</span>
                <select
                  value={job.render_intent}
                  onChange={e => onUpdateJob({ render_intent: e.target.value as RenderingIntent })}
                  className="bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-xs text-zinc-200 font-mono"
                >
                  <option value="RELATIVE_COLORIMETRIC">Relative Colorimetric</option>
                  <option value="PERCEPTUAL">Perceptual (Photographic)</option>
                  <option value="ABSOLUTE_COLORIMETRIC">Absolute Colorimetric (Proof)</option>
                  <option value="SATURATION">Saturation (Graphics)</option>
                </select>
              </div>

              <div className="flex items-center justify-between pt-1">
                <span className="text-zinc-400">Black Point Compensation (BPC):</span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={job.black_point_compensation}
                    onChange={e => onUpdateJob({ black_point_compensation: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-zinc-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500"></div>
                </label>
              </div>

              <div className="flex items-center justify-between pt-1">
                <span className="text-zinc-400">Halftone Screening:</span>
                <span className="font-mono text-zinc-300 text-[11px]">{job.halftone_method}</span>
              </div>
            </div>
          </div>

          {/* Ink System Snapshot (12 Channels) */}
          <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-4 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold uppercase tracking-wider text-zinc-300">
                12-Channel Ink Set Load
              </span>
              <span className="text-zinc-500 font-mono text-[10px]">ChromaPure Pigment</span>
            </div>

            <div className="grid grid-cols-6 sm:grid-cols-12 gap-1 text-center font-mono text-[9px] pt-1">
              {[
                { name: 'C', color: 'bg-cyan-500', val: 84 },
                { name: 'M', color: 'bg-fuchsia-500', val: 78 },
                { name: 'Y', color: 'bg-yellow-400', val: 91 },
                { name: 'PK', color: 'bg-zinc-900 border border-zinc-600', val: 62 },
                { name: 'MK', color: 'bg-zinc-700', val: 95 },
                { name: 'LC', color: 'bg-cyan-300', val: 72 },
                { name: 'LM', color: 'bg-fuchsia-300', val: 69 },
                { name: 'LK', color: 'bg-zinc-500', val: 88 },
                { name: 'LLK', color: 'bg-zinc-400', val: 94 },
                { name: 'OR', color: 'bg-orange-500', val: 81 },
                { name: 'GR', color: 'bg-emerald-500', val: 87 },
                { name: 'V', color: 'bg-purple-600', val: 79 },
              ].map(ink => (
                <div key={ink.name} className="flex flex-col items-center gap-1">
                  <div className="w-full h-10 bg-zinc-900 rounded-sm overflow-hidden flex flex-col justify-end p-0.5 border border-zinc-800">
                    <div className={`w-full ${ink.color} rounded-xs`} style={{ height: `${ink.val}%` }}></div>
                  </div>
                  <span className="text-zinc-400 font-bold">{ink.name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
