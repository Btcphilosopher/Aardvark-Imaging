'use client';

import React, { useState, useEffect } from 'react';
import { 
  Bot, 
  Play, 
  Pause, 
  RotateCw, 
  Activity, 
  Flame, 
  Wind, 
  Thermometer, 
  Gauge, 
  AlertCircle,
  CheckCircle2,
  Cpu
} from 'lucide-react';
import { PrinterModel, DigitalTwinTelemetry, InkChannelName } from '@/lib/engine/types';
import { PrinterDigitalTwin } from '@/lib/engine/digital-twin';

interface DigitalTwinViewProps {
  printer: PrinterModel;
}

export function DigitalTwinView({ printer }: DigitalTwinViewProps) {
  const [twin] = useState<PrinterDigitalTwin>(() => new PrinterDigitalTwin(printer));
  const [telemetry, setTelemetry] = useState<DigitalTwinTelemetry>(() => twin.getTelemetry());
  const [isSimulating, setIsSimulating] = useState<boolean>(true);

  useEffect(() => {
    twin.startJob(120);

    const interval = setInterval(() => {
      if (isSimulating) {
        const updated = twin.stepSimulation(100);
        setTelemetry(updated);
      }
    }, 100);

    return () => clearInterval(interval);
  }, [twin, isSimulating]);

  const carriagePercent = (telemetry.carriage_position_mm / 1118) * 100;

  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-900 text-zinc-100 overflow-y-auto p-4 space-y-4">
      {/* Header */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold uppercase tracking-wider text-zinc-100">
                Hardware Digital Twin & Physics Telemetry
              </h2>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                REAL-TIME KINEMATICS
              </span>
            </div>
            <div className="text-xs text-zinc-400">
              Modeling carriage velocity, platen vacuum, nozzle piezoelectric firing, and thermal gradients
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsSimulating(!isSimulating)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded text-xs font-bold transition-all shadow ${
              isSimulating
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30'
                : 'bg-emerald-500 text-zinc-950 hover:bg-emerald-400'
            }`}
          >
            {isSimulating ? (
              <>
                <Pause className="w-3.5 h-3.5 fill-current" />
                <span>Pause Telemetry</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Resume Physics</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Physics Telemetry Gauges */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-zinc-500 text-[10px] font-mono uppercase">
            <span>Carriage Velocity</span>
            <Activity className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <span className="text-zinc-100 font-mono text-lg font-bold block mt-1">
            {telemetry.carriage_velocity_mps.toFixed(2)} m/s
          </span>
          <span className="text-[10px] text-zinc-500 font-mono">
            Position: {telemetry.carriage_position_mm.toFixed(1)} mm
          </span>
        </div>

        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-zinc-500 text-[10px] font-mono uppercase">
            <span>Print Head Temp</span>
            <Thermometer className="w-3.5 h-3.5 text-red-400" />
          </div>
          <span className="text-zinc-100 font-mono text-lg font-bold block mt-1">
            {telemetry.head_temperature_c.toFixed(1)} °C
          </span>
          <span className="text-[10px] text-emerald-400 font-mono">Thermal Target: 38-42°C</span>
        </div>

        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-zinc-500 text-[10px] font-mono uppercase">
            <span>Platen Vacuum Pressure</span>
            <Gauge className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <span className="text-cyan-400 font-mono text-lg font-bold block mt-1">
            {telemetry.platen_vacuum_kpa.toFixed(2)} kPa
          </span>
          <span className="text-[10px] text-zinc-500 font-mono">Anti-Cockle Hold Down</span>
        </div>

        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3">
          <div className="flex items-center justify-between text-zinc-500 text-[10px] font-mono uppercase">
            <span>Drying Heater Curing</span>
            <Flame className="w-3.5 h-3.5 text-orange-400" />
          </div>
          <span className="text-zinc-100 font-mono text-lg font-bold block mt-1">
            {telemetry.drying_heater_c.toFixed(1)} °C
          </span>
          <span className="text-[10px] text-zinc-500 font-mono">
            RH: {telemetry.relative_humidity_percent}% | Amb: {telemetry.ambient_temperature_c}°C
          </span>
        </div>
      </div>

      {/* Interactive Platen & Print Head Kinematics Visualization */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-5 flex flex-col space-y-4">
        <div className="flex items-center justify-between text-xs font-mono">
          <span className="font-bold text-zinc-300 uppercase">
            44″ Precision Vacuum Platen & Head Motion Stage
          </span>
          <span className="text-amber-400">
            Pass Progress: Feed {telemetry.paper_feed_position_mm.toFixed(1)} mm
          </span>
        </div>

        {/* Platen Stage Simulator */}
        <div className="relative h-44 bg-zinc-900 rounded border border-zinc-800 overflow-hidden flex flex-col justify-between p-4">
          {/* Guide Rail */}
          <div className="absolute top-10 left-4 right-4 h-1.5 bg-zinc-800 rounded-full">
            <div className="w-full h-full bg-zinc-700/50"></div>
          </div>

          {/* Substrate Sheet Moving Underneath */}
          <div className="absolute inset-x-8 top-16 bottom-4 bg-zinc-200/90 rounded-sm shadow-inner overflow-hidden border border-zinc-600">
            {/* Printed rows */}
            <div className="w-full h-full bg-[radial-gradient(#d4d4d8_1px,transparent_1px)] [background-size:12px_12px] opacity-40"></div>
            <div className="absolute top-2 left-3 text-[10px] font-mono text-zinc-600 font-bold">
              Substrate: Aardvark Baryta Prestige 310gsm
            </div>
          </div>

          {/* Moving Print Head Carriage */}
          <div
            className="absolute top-4 w-20 h-28 bg-gradient-to-b from-zinc-800 to-zinc-950 rounded border-2 border-amber-500 shadow-[0_0_16px_rgba(245,158,11,0.4)] z-20 flex flex-col items-center justify-between p-1.5 transition-all duration-75"
            style={{ left: `calc(${carriagePercent}% - 40px)` }}
          >
            <div className="text-[8px] font-mono text-amber-400 font-bold uppercase tracking-tighter">
              12C HEAD
            </div>
            {/* Nozzle Array Firing Indicators */}
            <div className="grid grid-cols-6 gap-0.5 w-full px-1">
              {Array.from({ length: 12 }).map((_, i) => (
                <div
                  key={i}
                  className={`w-1.5 h-1.5 rounded-full ${
                    isSimulating ? 'bg-amber-400 animate-ping' : 'bg-zinc-600'
                  }`}
                />
              ))}
            </div>
            <div className="text-[7px] font-mono text-zinc-400">
              {telemetry.head_temperature_c.toFixed(1)}°C
            </div>
          </div>
        </div>
      </div>

      {/* Nozzle Health & Wear Analytics */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-4 space-y-3">
        <div className="flex items-center justify-between text-xs font-mono">
          <span className="font-bold text-zinc-300 uppercase">
            12-Channel Nozzle Array Piezo Health & Clog Diagnostics
          </span>
          <span className="text-emerald-400 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" /> 100% OPERATIONAL (Zero Missing Nozzles)
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 text-xs font-mono">
          {Object.entries(telemetry.nozzle_health_percent).map(([ch, health]) => (
            <div key={ch} className="bg-zinc-900/60 p-2 rounded border border-zinc-800 flex items-center justify-between">
              <span className="font-bold text-amber-400">{ch}</span>
              <span className="text-zinc-300 font-semibold">{health.toFixed(1)}%</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
