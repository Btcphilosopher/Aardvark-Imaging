'use client';

import React from 'react';
import { 
  ListOrdered, 
  Clock, 
  Droplets, 
  DollarSign, 
  ArrowUp, 
  ArrowDown, 
  Play, 
  X, 
  CheckCircle2, 
  AlertCircle,
  FileText,
  Copy
} from 'lucide-react';
import { PrintJob } from '@/lib/engine/types';

interface JobQueueViewProps {
  jobs: PrintJob[];
  onSelectJob: (jobId: string) => void;
  selectedJobId: string;
}

export function JobQueueView({ jobs, onSelectJob, selectedJobId }: JobQueueViewProps) {
  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-900 text-zinc-100 overflow-y-auto p-4 space-y-4">
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <ListOrdered className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-zinc-100">
              Active Production Spool Queue
            </h2>
            <div className="text-xs text-zinc-400">
              Prioritized multi-job spooler for ProPrint 600 & connected fleet engines
            </div>
          </div>
        </div>

        <div className="text-xs font-mono text-zinc-400 flex items-center gap-3">
          <span>Total Jobs: <strong className="text-zinc-200">{jobs.length}</strong></span>
          <span>•</span>
          <span className="text-emerald-400 font-semibold">Spooler Active</span>
        </div>
      </div>

      {/* Jobs Table */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg overflow-hidden flex flex-col">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-zinc-900 text-zinc-500 border-b border-zinc-800 text-[10px] uppercase">
              <tr>
                <th className="p-3">Job ID</th>
                <th className="p-3">Artwork Title</th>
                <th className="p-3">Substrate Media</th>
                <th className="p-3">Dimensions</th>
                <th className="p-3">Copies</th>
                <th className="p-3">Est. Time</th>
                <th className="p-3">Est. Cost</th>
                <th className="p-3">Priority</th>
                <th className="p-3">Status</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-850">
              {jobs.map(job => {
                const isSelected = job.job_id === selectedJobId;
                return (
                  <tr
                    key={job.job_id}
                    onClick={() => onSelectJob(job.job_id)}
                    className={`cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-amber-500/10 text-amber-200'
                        : 'hover:bg-zinc-900/50 text-zinc-300'
                    }`}
                  >
                    <td className="p-3 font-bold text-amber-400">{job.job_id}</td>
                    <td className="p-3 font-semibold text-zinc-100">
                      {job.source_image.metadata.title}
                    </td>
                    <td className="p-3 text-zinc-400">{job.target_media}</td>
                    <td className="p-3 text-zinc-300">
                      {job.target_dimensions.width_mm} × {job.target_dimensions.height_mm} mm
                    </td>
                    <td className="p-3 text-zinc-200">{job.copies}</td>
                    <td className="p-3 text-zinc-400">{Math.round(job.estimated_time_seconds / 60)} min</td>
                    <td className="p-3 text-emerald-400 font-bold">${job.estimated_cost.total.toFixed(2)}</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        job.priority === 'RUSH_CRITICAL'
                          ? 'bg-red-500/20 text-red-300 border border-red-500/40'
                          : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                      }`}>
                        {job.priority}
                      </span>
                    </td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        job.status === 'COMPLETE'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                          : job.status === 'PRINTING'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse'
                          : 'bg-zinc-800 text-zinc-300 border border-zinc-700'
                      }`}>
                        {job.status}
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectJob(job.job_id);
                        }}
                        className="px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-[10px] font-semibold border border-zinc-700"
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
