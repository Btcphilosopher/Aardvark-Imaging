'use client';

import React from 'react';
import { Palette, Check, Sparkles, Sliders, ArrowRight, ShieldCheck } from 'lucide-react';
import { ICC_PROFILES } from '@/lib/engine/mock-data';

export function ColourManagementView() {
  const gamuts = [
    { name: 'sRGB (Standard Web)', volume: 832000, color: 'bg-zinc-600', coverage: '68% of Baryta' },
    { name: 'Adobe RGB (1998)', volume: 1205000, color: 'bg-cyan-500', coverage: '94% of Baryta' },
    { name: 'Aardvark Baryta 310 (Print Gamut)', volume: 894000, color: 'bg-amber-400', coverage: 'Reference Media' },
    { name: 'ProPhoto RGB (Wide Archival)', volume: 2870000, color: 'bg-purple-500', coverage: 'Exceeds Print Gamut' },
  ];

  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-900 text-zinc-100 overflow-y-auto p-4 space-y-4">
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Palette className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-zinc-100">
              Colorimetric Engine & ICC Profile Manager
            </h2>
            <div className="text-xs text-zinc-400">
              D50 Profile Connection Space (PCS) • Bradford Chromatic Adaptation • ISO 12640-1 BPC
            </div>
          </div>
        </div>

        <span className="text-xs font-mono text-zinc-400">
          PCS Illuminant: <strong className="text-amber-400">CIE D50 (2° Observer)</strong>
        </span>
      </div>

      {/* Gamut Volume Comparative Bar Chart */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-4 space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-300">
          Colour Gamut Volume Comparison (CIE L*a*b* Cubic Units)
        </h3>

        <div className="space-y-3 font-mono text-xs">
          {gamuts.map(g => (
            <div key={g.name} className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-zinc-200 font-semibold">{g.name}</span>
                <span className="text-zinc-400">{g.volume.toLocaleString()} units ({g.coverage})</span>
              </div>
              <div className="h-3 bg-zinc-900 rounded-full overflow-hidden border border-zinc-800">
                <div
                  className={`h-full ${g.color} rounded-full`}
                  style={{ width: `${(g.volume / 2870000) * 100}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Bradford Chromatic Adaptation Matrix Display */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-4 space-y-3 font-mono text-xs">
          <h3 className="font-bold text-zinc-200 uppercase text-[11px]">
            Bradford Chromatic Adaptation (D65 → D50)
          </h3>
          <p className="text-zinc-400 text-[11px] leading-relaxed">
            All source images are aligned to the D50 print environment using the cone response matrix transformation:
          </p>

          <div className="bg-zinc-900 p-3 rounded border border-zinc-800 text-amber-300 space-y-1 text-center">
            <div>[ +1.0478112  +0.0228866  -0.0501270 ]</div>
            <div>[ +0.0295424  +0.9904844  -0.0170490 ]</div>
            <div>[ -0.0092345  +0.0150436  +0.7521316 ]</div>
          </div>
        </div>

        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-4 space-y-3 font-mono text-xs">
          <h3 className="font-bold text-zinc-200 uppercase text-[11px]">
            Active ICC Profiles Library
          </h3>
          <div className="space-y-2">
            {ICC_PROFILES.map(prof => (
              <div key={prof.profile_id} className="p-2 rounded bg-zinc-900/70 border border-zinc-850">
                <div className="flex justify-between items-start">
                  <span className="font-semibold text-zinc-200">{prof.name}</span>
                  <span className="text-amber-400 font-bold">{prof.gamut_volume.toLocaleString()} v</span>
                </div>
                <div className="text-[10px] text-zinc-500 mt-1">{prof.source}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
