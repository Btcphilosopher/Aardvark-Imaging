'use client';

import React from 'react';
import { Eye, Camera, HardDrive, Info, CheckCircle2, ShieldCheck } from 'lucide-react';
import { PrintJob } from '@/lib/engine/types';
import { calculateEffectiveResolution, calculateViewingDistanceLimits } from '@/lib/engine/resolution-resampling';

interface ImageInspectorViewProps {
  job: PrintJob;
}

export function ImageInspectorView({ job }: ImageInspectorViewProps) {
  const meta = job.source_image.metadata;
  const res = calculateEffectiveResolution(
    job.source_image.width_px,
    job.source_image.height_px,
    job.target_dimensions.width_mm,
    job.target_dimensions.height_mm
  );
  const viewing = calculateViewingDistanceLimits(500);

  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-900 text-zinc-100 overflow-y-auto p-4 space-y-4">
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Eye className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-zinc-100">
              High-Resolution Image & Metadata Inspector
            </h2>
            <div className="text-xs text-zinc-400">
              16-Bit RAW / TIFF parsing, EXIF tags, bit depth, and visual acuity resolving limits
            </div>
          </div>
        </div>

        <span className="text-xs font-mono text-zinc-400">
          Source Bit Depth: <strong className="text-amber-400">{job.source_bit_depth}-bit Linear</strong>
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Left: Metadata & EXIF */}
        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-4 space-y-3 font-mono text-xs">
          <div className="flex items-center gap-2 text-zinc-300 font-bold uppercase text-[11px] pb-2 border-b border-zinc-850">
            <Camera className="w-4 h-4 text-amber-400" />
            <span>Capture & Provenance Metadata</span>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-zinc-500">Artwork Title:</span>
              <span className="text-zinc-200 font-semibold">{meta.title}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-zinc-500">Artist / Creator:</span>
              <span className="text-zinc-200">{meta.creator}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-zinc-500">Capture Device:</span>
              <span className="text-zinc-200">{meta.captureDevice}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-zinc-500">Lens / Focal:</span>
              <span className="text-zinc-200">{meta.lens} ({meta.focalLength})</span>
            </div>
            <div className="flex justify-between">
              <span className="text-zinc-500">Exposure:</span>
              <span className="text-zinc-200">{meta.shutterSpeed} at {meta.aperture}, ISO {meta.iso}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-zinc-500">Native Pixels:</span>
              <span className="text-amber-400 font-bold">{meta.nativeWidth} × {meta.nativeHeight} px</span>
            </div>
            <div className="flex justify-between">
              <span className="text-zinc-500">Working Space:</span>
              <span className="text-cyan-400 font-bold">{meta.sourceColourSpace}</span>
            </div>
            <div className="flex justify-between pt-1 border-t border-zinc-850">
              <span className="text-zinc-500">Cryptographic Hash:</span>
              <span className="text-zinc-400 text-[10px] truncate max-w-[240px]">{meta.hash}</span>
            </div>
          </div>
        </div>

        {/* Right: Human Eye Resolving Power & Visual Acuity */}
        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-4 space-y-3 font-mono text-xs">
          <div className="flex items-center gap-2 text-zinc-300 font-bold uppercase text-[11px] pb-2 border-b border-zinc-850">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Optical Sharpness & Human Acuity Analysis</span>
          </div>

          <div className="space-y-3">
            <div className="bg-zinc-900/80 p-3 rounded border border-zinc-800">
              <div className="flex justify-between">
                <span className="text-zinc-400">Effective Print DPI:</span>
                <span className="text-emerald-400 font-bold text-base">{res.effective_dpi} DPI</span>
              </div>
              <p className="text-[11px] text-zinc-400 mt-1">
                Evaluation: <strong className="text-zinc-200">{res.quality_rating}</strong>
              </p>
            </div>

            <div className="space-y-1.5 text-xs text-zinc-300">
              <div className="flex justify-between">
                <span className="text-zinc-500">Standard Gallery Viewing:</span>
                <span>500 mm (20 inches)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-500">Human Visual Limit (60 cpd):</span>
                <span className="text-amber-400 font-bold">{viewing.resolving_limit_dpi} DPI</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-500">Acuity Conclusion:</span>
                <span className="text-emerald-400 font-bold">Individual ink dots physically invisible</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
