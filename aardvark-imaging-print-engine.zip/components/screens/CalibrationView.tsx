'use client';

import React, { useState } from 'react';
import { Sparkles, Check, RefreshCw, Crosshair, ShieldCheck } from 'lucide-react';

export function CalibrationView() {
  const [isCalibrating, setIsCalibrating] = useState<boolean>(false);
  const [lastCalibration, setLastCalibration] = useState<string>('2026-09-12 04:12:00 UTC');

  const handleRunCalibration = () => {
    setIsCalibrating(true);
    setTimeout(() => {
      setIsCalibrating(false);
      setLastCalibration(new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC');
    }, 1500);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-900 text-zinc-100 overflow-y-auto p-4 space-y-4">
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-zinc-100">
              Spectrophotometric Linearization & Neutral Gray Calibration
            </h2>
            <div className="text-xs text-zinc-400">
              12-Channel MicroPiezo single-channel tone curves and Dmax density calibration
            </div>
          </div>
        </div>

        <button
          onClick={handleRunCalibration}
          disabled={isCalibrating}
          className="flex items-center gap-2 px-3 py-1.5 rounded bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs shadow"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isCalibrating ? 'animate-spin' : ''}`} />
          <span>{isCalibrating ? 'Linearizing 12 Channels...' : 'Calibrate Substrate'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-4 space-y-2">
          <span className="text-zinc-500 text-[10px] block">LAST CALIBRATION TIMESTAMP</span>
          <span className="text-zinc-200 font-bold">{lastCalibration}</span>
          <span className="text-emerald-400 text-[11px] block">Neutral tracking error: ΔE 0.38</span>
        </div>

        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-4 space-y-2">
          <span className="text-zinc-500 text-[10px] block">SPECTROPHOTOMETER DEVICE</span>
          <span className="text-zinc-200 font-bold">X-Rite i1Pro3 Plus (M1 Condition)</span>
          <span className="text-zinc-400 text-[11px] block">Polarized D50 UV-Cut</span>
        </div>

        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-4 space-y-2">
          <span className="text-zinc-500 text-[10px] block">CORRECTION LUT STATUS</span>
          <span className="text-amber-400 font-bold">256-Step 16-Bit Precision Table</span>
          <span className="text-zinc-400 text-[11px] block">Active in RIP Memory Buffer</span>
        </div>
      </div>
    </div>
  );
}
