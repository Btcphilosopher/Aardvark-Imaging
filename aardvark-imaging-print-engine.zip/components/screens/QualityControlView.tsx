'use client';

import React, { useState } from 'react';
import { 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  RotateCw, 
  FileText, 
  Crosshair, 
  Activity,
  Award
} from 'lucide-react';
import { evaluatePrintQuality } from '@/lib/engine/spectrophotometer-qc';
import { QCResult, QCStatus } from '@/lib/engine/types';

interface QualityControlViewProps {
  jobId: string;
}

export function QualityControlView({ jobId }: QualityControlViewProps) {
  const [qcLevel, setQcLevel] = useState<'EXCELLENT' | 'TYPICAL' | 'DEFECTIVE'>('EXCELLENT');
  const [qcResult, setQcResult] = useState<QCResult>(() =>
    evaluatePrintQuality(jobId, 'X-Rite i1Pro3 Auto Spectro Station', 'EXCELLENT')
  );
  const [filterStatus, setFilterStatus] = useState<string>('ALL');

  const handleRescan = (level: 'EXCELLENT' | 'TYPICAL' | 'DEFECTIVE') => {
    setQcLevel(level);
    setQcResult(evaluatePrintQuality(jobId, 'X-Rite i1Pro3 Auto Spectro Station', level));
  };

  const filteredPatches = qcResult.measured_patches.filter(p => {
    if (filterStatus === 'ALL') return true;
    return p.status === filterStatus;
  });

  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-900 text-zinc-100 overflow-y-auto p-4 space-y-4">
      {/* Header */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded border ${
            qcResult.status === 'PASS' 
              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' 
              : qcResult.status === 'WARNING'
              ? 'bg-amber-500/10 text-amber-400 border-amber-500/20'
              : 'bg-red-500/10 text-red-400 border-red-500/20'
          }`}>
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold uppercase tracking-wider text-zinc-100">
                Spectrophotometric Quality Assurance (ISO 12647-7)
              </h2>
              <span className={`px-2 py-0.5 rounded text-[11px] font-mono font-bold border ${
                qcResult.status === 'PASS'
                  ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                  : qcResult.status === 'WARNING'
                  ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                  : 'bg-red-500/15 text-red-400 border-red-500/30'
              }`}>
                CERTIFICATE: {qcResult.status}
              </span>
            </div>
            <div className="text-xs text-zinc-400">
              Evaluated with <span className="text-zinc-200">{qcResult.inspector}</span> under D50 2° geometry
            </div>
          </div>
        </div>

        {/* Scan Trigger Buttons */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-zinc-500 font-mono">Simulate Scan:</span>
          <button
            onClick={() => handleRescan('EXCELLENT')}
            className={`px-2.5 py-1.5 rounded text-xs font-semibold border ${
              qcLevel === 'EXCELLENT'
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                : 'bg-zinc-900 text-zinc-400 border-zinc-800 hover:text-zinc-200'
            }`}
          >
            Fogra 51 Pass
          </button>
          <button
            onClick={() => handleRescan('TYPICAL')}
            className={`px-2.5 py-1.5 rounded text-xs font-semibold border ${
              qcLevel === 'TYPICAL'
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                : 'bg-zinc-900 text-zinc-400 border-zinc-800 hover:text-zinc-200'
            }`}
          >
            Slight Warning
          </button>
          <button
            onClick={() => handleRescan('DEFECTIVE')}
            className={`px-2.5 py-1.5 rounded text-xs font-semibold border ${
              qcLevel === 'DEFECTIVE'
                ? 'bg-red-500/20 text-red-300 border-red-500/40'
                : 'bg-zinc-900 text-zinc-400 border-zinc-800 hover:text-zinc-200'
            }`}
          >
            Out-of-Tolerance Fail
          </button>
        </div>
      </div>

      {/* Primary Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3">
          <span className="text-zinc-500 block text-[10px] font-mono uppercase">Mean ΔE₀₀</span>
          <span className={`font-mono text-lg font-bold ${
            qcResult.mean_delta_e_2000 <= 1.2 ? 'text-emerald-400' : 'text-amber-400'
          }`}>
            {qcResult.mean_delta_e_2000}
          </span>
          <span className="text-[10px] text-zinc-500 block font-mono">ISO Limit: ≤ 1.5</span>
        </div>

        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3">
          <span className="text-zinc-500 block text-[10px] font-mono uppercase">Peak Max ΔE₀₀</span>
          <span className={`font-mono text-lg font-bold ${
            qcResult.max_delta_e_2000 <= 3.0 ? 'text-emerald-400' : 'text-red-400'
          }`}>
            {qcResult.max_delta_e_2000}
          </span>
          <span className="text-[10px] text-zinc-500 block font-mono">ISO Limit: ≤ 3.0</span>
        </div>

        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3">
          <span className="text-zinc-500 block text-[10px] font-mono uppercase">95th Percentile ΔE₀₀</span>
          <span className="text-zinc-200 font-mono text-lg font-bold">
            {qcResult.percentile_95_delta_e}
          </span>
          <span className="text-[10px] text-zinc-500 block font-mono">ISO Limit: ≤ 2.5</span>
        </div>

        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3">
          <span className="text-zinc-500 block text-[10px] font-mono uppercase">Neutral Gray Balance</span>
          <span className="text-cyan-400 font-mono text-lg font-bold">
            {qcResult.density_neutrality_score}%
          </span>
          <span className="text-[10px] text-zinc-500 block font-mono">Target: ≥ 95.0%</span>
        </div>

        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3">
          <span className="text-zinc-500 block text-[10px] font-mono uppercase">Platen Skew Error</span>
          <span className="text-zinc-200 font-mono text-lg font-bold">
            {qcResult.registration_skew_mm} mm
          </span>
          <span className="text-[10px] text-zinc-500 block font-mono">Tolerance: &lt; 0.25mm</span>
        </div>
      </div>

      {/* Certification Summary Notes */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-xs font-mono text-zinc-300 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Award className="w-4 h-4 text-amber-400 shrink-0" />
          <span>{qcResult.comments}</span>
        </div>
        <span className="text-[10px] text-zinc-500">{qcResult.timestamp}</span>
      </div>

      {/* 24-Patch ColorChecker Table */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg overflow-hidden flex flex-col">
        <div className="p-3 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/60 text-xs">
          <span className="font-bold uppercase tracking-wider text-zinc-300">
            Measured 24-Patch ColorChecker Targets
          </span>
          <div className="flex items-center gap-2">
            <span className="text-zinc-500">Filter:</span>
            {['ALL', 'PASS', 'WARNING', 'FAIL'].map(st => (
              <button
                key={st}
                onClick={() => setFilterStatus(st)}
                className={`px-2 py-0.5 rounded text-[10px] font-mono transition-all ${
                  filterStatus === st
                    ? 'bg-zinc-700 text-zinc-100 font-bold'
                    : 'bg-zinc-900 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto max-h-[380px]">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-zinc-900 text-zinc-500 border-b border-zinc-800 text-[10px] uppercase sticky top-0">
              <tr>
                <th className="p-2.5">Patch ID</th>
                <th className="p-2.5">Patch Name</th>
                <th className="p-2.5">Reference L*a*b*</th>
                <th className="p-2.5">Measured L*a*b*</th>
                <th className="p-2.5">ΔE₀₀ Error</th>
                <th className="p-2.5">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-850">
              {filteredPatches.map(patch => (
                <tr key={patch.patch_id} className="hover:bg-zinc-900/40">
                  <td className="p-2.5 font-bold text-zinc-400">{patch.patch_id}</td>
                  <td className="p-2.5 font-semibold text-zinc-200">{patch.name}</td>
                  <td className="p-2.5 text-zinc-400">
                    [{patch.reference_lab.map(v => v.toFixed(1)).join(', ')}]
                  </td>
                  <td className="p-2.5 text-zinc-300">
                    [{patch.measured_lab.map(v => v.toFixed(1)).join(', ')}]
                  </td>
                  <td className="p-2.5 font-bold text-amber-400">{patch.delta_e_2000.toFixed(2)}</td>
                  <td className="p-2.5">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      patch.status === 'PASS'
                        ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                        : patch.status === 'WARNING'
                        ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                        : 'bg-red-500/15 text-red-400 border border-red-500/30'
                    }`}>
                      {patch.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
