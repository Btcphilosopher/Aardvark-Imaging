'use client';

import React, { useState } from 'react';
import { 
  Calculator, 
  DollarSign, 
  TrendingUp, 
  PieChart, 
  Droplets, 
  Scroll, 
  Zap, 
  Wrench, 
  Users, 
  Trash2, 
  Clock 
} from 'lucide-react';
import { PrintJob, PaperProfile, InkProfile, PrinterModel } from '@/lib/engine/types';
import { calculatePrintJobCost } from '@/lib/engine/costing-inventory';

interface CostingViewProps {
  job: PrintJob;
  paper: PaperProfile;
  ink: InkProfile;
  printer: PrinterModel;
}

export function CostingView({ job, paper, ink, printer }: CostingViewProps) {
  const [labourRate, setLabourRate] = useState<number>(45.0);
  const [wasteRate, setWasteRate] = useState<number>(0.08);

  const cost = calculatePrintJobCost(job, paper, ink, printer, labourRate, wasteRate);

  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-900 text-zinc-100 overflow-y-auto p-4 space-y-4">
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <Calculator className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-zinc-100">
              Industrial Costing & Yield Engine
            </h2>
            <div className="text-xs text-zinc-400">
              Full breakdown across ink, substrate, energy, maintenance, labour, waste, and depreciation
            </div>
          </div>
        </div>

        <div className="text-xs font-mono text-zinc-400">
          Job Target: <span className="text-amber-400 font-bold">{job.job_id}</span> ({job.copies} copies)
        </div>
      </div>

      {/* Top Cost KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3">
          <span className="text-zinc-500 block text-[10px] font-mono uppercase">Total Production Cost</span>
          <span className="text-emerald-400 font-mono text-xl font-bold block mt-0.5">
            ${cost.totalCost.toFixed(2)}
          </span>
          <span className="text-[10px] text-zinc-500 font-mono">For {job.copies} Finished Copies</span>
        </div>

        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3">
          <span className="text-zinc-500 block text-[10px] font-mono uppercase">Unit Cost (Per Print)</span>
          <span className="text-zinc-100 font-mono text-xl font-bold block mt-0.5">
            ${cost.costPerCopy.toFixed(2)}
          </span>
          <span className="text-[10px] text-zinc-500 font-mono">
            ${cost.costPerSquareMetre.toFixed(2)}/m² (${cost.costPerSquareFoot.toFixed(2)}/ft²)
          </span>
        </div>

        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3">
          <span className="text-zinc-500 block text-[10px] font-mono uppercase">Target Gallery Margin</span>
          <span className="text-amber-400 font-mono text-xl font-bold block mt-0.5">
            {(cost.profitMarginRecommended * 100).toFixed(0)}%
          </span>
          <span className="text-[10px] text-zinc-500 font-mono">Fine Art Standard</span>
        </div>

        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3">
          <span className="text-zinc-500 block text-[10px] font-mono uppercase">Recommended Retail (RRP)</span>
          <span className="text-cyan-400 font-mono text-xl font-bold block mt-0.5">
            ${cost.recommendedRetailPrice.toFixed(2)}
          </span>
          <span className="text-[10px] text-zinc-500 font-mono">Per Signed Exhibition Edition</span>
        </div>
      </div>

      {/* Itemized Cost Breakdown Table */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-4 space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-300">
          Component Itemized Cost Structure
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2 text-xs font-mono">
            {[
              { label: 'Substrate Media (Paper)', val: cost.paperCost, icon: Scroll, note: `${paper.name} (${paper.cost_per_sqm}/m²)` },
              { label: 'Pigment Inks (12-Channel)', val: cost.inkCost, icon: Droplets, note: `ChromaPure ($${ink.cost_per_ml}/ml)` },
              { label: 'Prepress & Finishing Labour', val: cost.labourCost, icon: Users, note: `$${labourRate}/hr bench rate` },
              { label: 'Packaging, Test Strips & Waste', val: cost.wasteCost, icon: Trash2, note: `${(wasteRate * 100).toFixed(0)}% margin allowance` },
              { label: 'Equipment Depreciation', val: cost.depreciationCost, icon: Clock, note: 'Amortized over 4,000 hrs' },
              { label: 'Maintenance & Consumables', val: cost.maintenanceCost, icon: Wrench, note: 'Waste tanks, wipers, head wear' },
              { label: 'Electrical Energy', val: cost.energyCost, icon: Zap, note: 'Heater + vacuum draw' },
            ].map(item => {
              const Icon = item.icon;
              return (
                <div key={item.label} className="flex items-center justify-between p-2 rounded bg-zinc-900/60 border border-zinc-850">
                  <div className="flex items-center gap-2">
                    <Icon className="w-3.5 h-3.5 text-zinc-400" />
                    <div>
                      <span className="text-zinc-200 block font-semibold">{item.label}</span>
                      <span className="text-[10px] text-zinc-500">{item.note}</span>
                    </div>
                  </div>
                  <span className="font-bold text-zinc-100">${item.val.toFixed(2)}</span>
                </div>
              );
            })}
          </div>

          {/* Interactive Bench Rate Adjuster */}
          <div className="bg-zinc-900/40 p-4 rounded border border-zinc-800 flex flex-col justify-between space-y-4 text-xs font-mono">
            <div>
              <span className="text-zinc-300 font-bold block mb-3 uppercase">Labor & Waste Factor Simulation</span>
              
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-zinc-400">Master Printer Bench Rate:</span>
                    <span className="text-amber-400 font-bold">${labourRate}/hr</span>
                  </div>
                  <input
                    type="range"
                    min="25"
                    max="100"
                    value={labourRate}
                    onChange={e => setLabourRate(Number(e.target.value))}
                    className="w-full accent-amber-500"
                  />
                </div>

                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-zinc-400">Substrate Waste & Proof Allowance:</span>
                    <span className="text-amber-400 font-bold">{(wasteRate * 100).toFixed(0)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0.02"
                    max="0.25"
                    step="0.01"
                    value={wasteRate}
                    onChange={e => setWasteRate(Number(e.target.value))}
                    className="w-full accent-amber-500"
                  />
                </div>
              </div>
            </div>

            <div className="bg-zinc-950 p-3 rounded border border-zinc-800/80 text-[11px] text-zinc-400 leading-relaxed">
              <strong className="text-zinc-200">ISO Prepress Accounting Standard:</strong> Commercial fine art edition costs guarantee minimum gross margins for museum gallery releases while preventing hidden consumable drain.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
