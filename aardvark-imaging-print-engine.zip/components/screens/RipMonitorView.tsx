'use client';

import React, { useState } from 'react';
import { 
  Cpu, 
  Play, 
  CheckCircle2, 
  AlertCircle, 
  HardDrive, 
  Layers, 
  Zap, 
  Clock, 
  Check, 
  Terminal,
  RotateCw
} from 'lucide-react';
import { PrintJob, PaperProfile } from '@/lib/engine/types';
import { CHROMAPURE_INK_SET } from '@/lib/engine/mock-data';
import { executeRipPipeline, RipExecutionResult } from '@/lib/engine/rip-engine';

interface RipMonitorViewProps {
  job: PrintJob;
  paper: PaperProfile;
}

export function RipMonitorView({ job, paper }: RipMonitorViewProps) {
  const [ripResult, setRipResult] = useState<RipExecutionResult>(() =>
    executeRipPipeline(job, paper, CHROMAPURE_INK_SET)
  );
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [activeStage, setActiveStage] = useState<number>(14);

  const handleReRunRip = () => {
    setIsRunning(true);
    setActiveStage(1);

    const interval = setInterval(() => {
      setActiveStage(prev => {
        if (prev >= 14) {
          clearInterval(interval);
          setIsRunning(false);
          setRipResult(executeRipPipeline(job, paper, CHROMAPURE_INK_SET));
          return 14;
        }
        return prev + 1;
      });
    }, 180);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-900 text-zinc-100 overflow-y-auto p-4 space-y-4">
      {/* Top Header */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-zinc-100">
              14-Stage Industrial RIP Architecture
            </h2>
            <div className="text-xs text-zinc-400">
              Parallel Tiled Rasterisation & Multi-Drop Binary Dot Screening Engine
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleReRunRip}
            disabled={isRunning}
            className="flex items-center gap-2 px-3 py-1.5 rounded bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs shadow transition-all disabled:opacity-50"
          >
            <RotateCw className={`w-3.5 h-3.5 ${isRunning ? 'animate-spin' : ''}`} />
            <span>{isRunning ? `Processing Stage ${activeStage}/14...` : 'Re-Execute 14-Stage RIP'}</span>
          </button>
        </div>
      </div>

      {/* KPI Banding & Memory Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3">
          <span className="text-zinc-500 block text-[10px] font-mono uppercase">Total RIP Duration</span>
          <span className="text-amber-400 font-mono text-base font-bold flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-zinc-500" />
            {ripResult.totalDurationMs} ms
          </span>
        </div>
        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3">
          <span className="text-zinc-500 block text-[10px] font-mono uppercase">Peak Memory Allocation</span>
          <span className="text-zinc-200 font-mono text-base font-bold flex items-center gap-1.5">
            <HardDrive className="w-4 h-4 text-zinc-500" />
            {ripResult.peakMemoryMb} MB
          </span>
        </div>
        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3">
          <span className="text-zinc-500 block text-[10px] font-mono uppercase">Banding Architecture</span>
          <span className="text-cyan-400 font-mono text-base font-bold flex items-center gap-1.5">
            <Layers className="w-4 h-4 text-zinc-500" />
            {ripResult.bandsCount} Bands (512px)
          </span>
        </div>
        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3">
          <span className="text-zinc-500 block text-[10px] font-mono uppercase">Raster Stream Size</span>
          <span className="text-zinc-200 font-mono text-base font-bold">
            {Math.round((ripResult.totalRasterBytes / (1024 * 1024)) * 10) / 10} MB
          </span>
        </div>
        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3">
          <span className="text-zinc-500 block text-[10px] font-mono uppercase">Total Microdots Placed</span>
          <span className="text-emerald-400 font-mono text-base font-bold">
            {(ripResult.totalDotsPlaced / 1000000).toFixed(1)} M Dots
          </span>
        </div>
      </div>

      {/* 14 Stages Table */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg overflow-hidden flex flex-col">
        <div className="p-3 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/60">
          <span className="text-xs font-bold uppercase tracking-wider text-zinc-300">
            Stage-by-Stage Transformation Logs
          </span>
          <span className="text-[11px] font-mono text-zinc-400">
            Pipeline: D50 PCS • Bradford • Lanczos-3 • GCR 60% • FM3 Screening
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-zinc-900 text-zinc-500 border-b border-zinc-800 text-[10px] uppercase">
              <tr>
                <th className="p-2.5">#</th>
                <th className="p-2.5">Stage Name</th>
                <th className="p-2.5">Input Specifications</th>
                <th className="p-2.5">Output Transform</th>
                <th className="p-2.5">Duration</th>
                <th className="p-2.5">Memory</th>
                <th className="p-2.5">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-850">
              {ripResult.stages.map(st => {
                const isCurrent = isRunning && activeStage === st.stageNumber;
                const isPassed = !isRunning || activeStage > st.stageNumber;

                return (
                  <tr
                    key={st.stageNumber}
                    className={`transition-colors ${
                      isCurrent
                        ? 'bg-amber-500/10 text-amber-300'
                        : isPassed
                        ? 'hover:bg-zinc-900/40 text-zinc-300'
                        : 'opacity-40 text-zinc-600'
                    }`}
                  >
                    <td className="p-2.5 font-bold text-zinc-500">{st.stageNumber}</td>
                    <td className="p-2.5 font-semibold text-zinc-100">{st.stageName}</td>
                    <td className="p-2.5 text-zinc-400 max-w-xs truncate">{st.inputSpecs}</td>
                    <td className="p-2.5 text-zinc-300 max-w-xs truncate">{st.outputSpecs}</td>
                    <td className="p-2.5 text-amber-400">{st.durationMs} ms</td>
                    <td className="p-2.5 text-zinc-400">{st.memoryAllocatedMb} MB</td>
                    <td className="p-2.5">
                      {isCurrent ? (
                        <span className="px-2 py-0.5 rounded text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse font-bold">
                          RIPPING
                        </span>
                      ) : isPassed ? (
                        <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center gap-1 w-max">
                          <Check className="w-3 h-3" /> SUCCESS
                        </span>
                      ) : (
                        <span className="text-zinc-600 text-[10px]">WAITING</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
