'use client';

import React from 'react';
import { Printer, Wifi, CheckCircle2, AlertTriangle, Activity, Wrench } from 'lucide-react';
import { PRINTER_FLEET } from '@/lib/engine/mock-data';
import { PrinterModel } from '@/lib/engine/types';

interface PrinterManagerViewProps {
  currentPrinter: PrinterModel;
}

export function PrinterManagerView({ currentPrinter }: PrinterManagerViewProps) {
  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-900 text-zinc-100 overflow-y-auto p-4 space-y-4">
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Printer className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-zinc-100">
              Hardware Fleet Controller
            </h2>
            <div className="text-xs text-zinc-400">
              Direct driver spooling, bi-directional ESC/P-R telemetry, and platen feed alignment
            </div>
          </div>
        </div>

        <span className="text-xs font-mono text-zinc-400">
          Connected Fleet: <strong className="text-zinc-200">{PRINTER_FLEET.length} Engines</strong>
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {PRINTER_FLEET.map(p => {
          const isPrimary = p.printer_id === currentPrinter.printer_id;
          return (
            <div
              key={p.printer_id}
              className={`p-4 rounded-lg border flex flex-col justify-between space-y-4 ${
                isPrimary
                  ? 'bg-zinc-950 border-amber-500/60 shadow-[0_0_15px_rgba(245,158,11,0.15)]'
                  : 'bg-zinc-950/70 border-zinc-800'
              }`}
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                    p.status === 'ONLINE'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  }`}>
                    {p.status}
                  </span>
                  <span className="text-xs font-mono text-zinc-500 flex items-center gap-1">
                    <Wifi className="w-3.5 h-3.5 text-zinc-400" /> {p.ip_address}
                  </span>
                </div>

                <h3 className="font-bold text-sm text-zinc-100 mt-2">{p.model}</h3>
                <p className="text-xs text-zinc-400">{p.manufacturer}</p>
              </div>

              <div className="space-y-2 text-xs font-mono bg-zinc-900/60 p-3 rounded border border-zinc-800">
                <div className="flex justify-between">
                  <span className="text-zinc-500">Max Platen Width:</span>
                  <span className="text-zinc-200 font-bold">{p.max_width_mm} mm ({(p.max_width_mm / 25.4).toFixed(0)}″)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-500">Max Resolution:</span>
                  <span className="text-amber-400 font-bold">{p.max_resolution_dpi.join(' × ')} DPI</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-500">Ink Channels:</span>
                  <span className="text-zinc-200">{p.ink_channels.length} Channels</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-500">Rated Speed:</span>
                  <span className="text-emerald-400">{p.print_speed_sqm_per_hr} m²/hr</span>
                </div>
              </div>

              <div className="flex items-center justify-between pt-1 text-xs font-mono">
                <span className="text-zinc-500 text-[10px]">Driver: {p.driver_version}</span>
                <button className="px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700 text-[11px] font-semibold">
                  Run Nozzle Check
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
