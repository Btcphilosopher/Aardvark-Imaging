'use client';

import React from 'react';
import { Droplets, ShieldCheck, AlertCircle, Info, Sparkles } from 'lucide-react';
import { CHROMAPURE_INK_SET } from '@/lib/engine/mock-data';

export function InkManagerView() {
  const inkChannels = [
    { code: 'C', name: 'Cyan', color: 'bg-cyan-500', level: 84, lot: 'LOT-C-8842', exp: '2028-11' },
    { code: 'M', name: 'Magenta', color: 'bg-fuchsia-500', level: 78, lot: 'LOT-M-8843', exp: '2028-11' },
    { code: 'Y', name: 'Yellow', color: 'bg-yellow-400', level: 91, lot: 'LOT-Y-8844', exp: '2028-10' },
    { code: 'PK', name: 'Photo Black', color: 'bg-zinc-900 border border-zinc-500', level: 62, lot: 'LOT-PK-8845', exp: '2029-01' },
    { code: 'MK', name: 'Matte Black', color: 'bg-zinc-700', level: 95, lot: 'LOT-MK-8846', exp: '2029-01' },
    { code: 'LC', name: 'Light Cyan', color: 'bg-cyan-300', level: 72, lot: 'LOT-LC-8847', exp: '2028-12' },
    { code: 'LM', name: 'Light Magenta', color: 'bg-fuchsia-300', level: 69, lot: 'LOT-LM-8848', exp: '2028-12' },
    { code: 'LK', name: 'Light Black (Gray)', color: 'bg-zinc-500', level: 88, lot: 'LOT-LK-8849', exp: '2029-02' },
    { code: 'LLK', name: 'Light Light Black', color: 'bg-zinc-400', level: 94, lot: 'LOT-LLK-8850', exp: '2029-02' },
    { code: 'OR', name: 'Orange', color: 'bg-orange-500', level: 81, lot: 'LOT-OR-8851', exp: '2028-09' },
    { code: 'GR', name: 'Green', color: 'bg-emerald-500', level: 87, lot: 'LOT-GR-8852', exp: '2028-09' },
    { code: 'V', name: 'Violet', color: 'bg-purple-600', level: 79, lot: 'LOT-V-8853', exp: '2028-08' },
    { code: 'CO', name: 'Chroma Optimizer', color: 'bg-sky-200', level: 92, lot: 'LOT-CO-8854', exp: '2029-03' },
  ];

  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-900 text-zinc-100 overflow-y-auto p-4 space-y-4">
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <Droplets className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-zinc-100">
              12-Channel Ultra-Gamut Pigment Ink Set
            </h2>
            <div className="text-xs text-zinc-400">
              {CHROMAPURE_INK_SET.name} • 700ml Hot-Swappable High-Capacity Cartridges
            </div>
          </div>
        </div>

        <span className="text-xs font-mono text-emerald-400 font-semibold flex items-center gap-1">
          <ShieldCheck className="w-3.5 h-3.5" /> 200+ Year Wilhelm Archival
        </span>
      </div>

      {/* Cartridge Levels Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
        {inkChannels.map(ink => (
          <div key={ink.code} className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 flex flex-col justify-between space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-sm text-zinc-100">{ink.code}</span>
              <span className="text-[10px] font-mono text-zinc-500">{ink.name}</span>
            </div>

            {/* Vertical Level Tube */}
            <div className="h-28 bg-zinc-900 rounded p-1 flex flex-col justify-end border border-zinc-800">
              <div
                className={`w-full ${ink.color} rounded-sm transition-all`}
                style={{ height: `${ink.level}%` }}
              />
            </div>

            <div className="text-center font-mono text-xs">
              <span className="font-bold text-zinc-200">{ink.level}%</span>
              <span className="text-[10px] text-zinc-500 block">
                {Math.round(700 * (ink.level / 100))} ml
              </span>
            </div>

            <div className="text-[9px] font-mono text-zinc-500 border-t border-zinc-900 pt-1 text-center">
              Exp: {ink.exp}
            </div>
          </div>
        ))}
      </div>

      {/* Technical Piezo Multi-Drop Specifications */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-4 space-y-3">
        <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-300">
          Piezoelectric Multi-Drop Droplet Engine
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono">
          <div className="bg-zinc-900/60 p-3 rounded border border-zinc-800">
            <span className="text-zinc-500 block text-[10px]">MINIMUM DROPLET SIZE</span>
            <span className="text-amber-400 text-base font-bold block mt-1">
              {CHROMAPURE_INK_SET.droplet_size_min_pl} Picolitres
            </span>
            <span className="text-zinc-400 text-[10px]">For continuous photographic skin grain</span>
          </div>

          <div className="bg-zinc-900/60 p-3 rounded border border-zinc-800">
            <span className="text-zinc-500 block text-[10px]">MAXIMUM DROPLET SIZE</span>
            <span className="text-cyan-400 text-base font-bold block mt-1">
              {CHROMAPURE_INK_SET.droplet_size_max_pl} Picolitres
            </span>
            <span className="text-zinc-400 text-[10px]">High-speed deep shadow saturation</span>
          </div>

          <div className="bg-zinc-900/60 p-3 rounded border border-zinc-800">
            <span className="text-zinc-500 block text-[10px]">CHROMA OPTIMIZER CLEAR COAT</span>
            <span className="text-emerald-400 text-base font-bold block mt-1">Automatic Uniform</span>
            <span className="text-zinc-400 text-[10px]">Eliminates differential gloss & bronzing</span>
          </div>
        </div>
      </div>
    </div>
  );
}
