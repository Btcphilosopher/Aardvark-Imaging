'use client';

import React from 'react';
import { Gauge, Activity, Zap, Thermometer, Droplets, CheckCircle2 } from 'lucide-react';

export function ProductionMonitorView() {
  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-900 text-zinc-100 overflow-y-auto p-4 space-y-4">
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Gauge className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-zinc-100">
              Industrial Fleet Production Telemetry
            </h2>
            <div className="text-xs text-zinc-400">
              Real-time throughput, clean-room humidity, electrical loads, and daily square meter production
            </div>
          </div>
        </div>

        <span className="text-xs font-mono text-emerald-400 font-semibold">
          Fleet Uptime: 99.4%
        </span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3">
          <span className="text-zinc-500 block text-[10px] uppercase">Daily Media Output</span>
          <span className="text-zinc-100 text-xl font-bold block mt-1">42.8 m²</span>
          <span className="text-zinc-500 text-[10px]">14 Fine Art Master Prints</span>
        </div>

        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3">
          <span className="text-zinc-500 block text-[10px] uppercase">Clean Room RH</span>
          <span className="text-cyan-400 text-xl font-bold block mt-1">48.5%</span>
          <span className="text-emerald-400 text-[10px]">Optimal Range (45-55%)</span>
        </div>

        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3">
          <span className="text-zinc-500 block text-[10px] uppercase">Clean Room Temp</span>
          <span className="text-amber-400 text-xl font-bold block mt-1">21.8 °C</span>
          <span className="text-zinc-400 text-[10px]">Target: 21.0-23.0°C</span>
        </div>

        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3">
          <span className="text-zinc-500 block text-[10px] uppercase">Total Active Power</span>
          <span className="text-zinc-100 text-xl font-bold block mt-1">315 W</span>
          <span className="text-zinc-500 text-[10px]">Heaters + Vacuum Pumps</span>
        </div>
      </div>
    </div>
  );
}
