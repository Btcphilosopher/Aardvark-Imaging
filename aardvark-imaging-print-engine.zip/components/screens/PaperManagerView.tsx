'use client';

import React from 'react';
import { Scroll, Check, Info, ShieldCheck } from 'lucide-react';
import { PaperProfile } from '@/lib/engine/types';

interface PaperManagerViewProps {
  papers: PaperProfile[];
  selectedPaperId: string;
  onSelectPaper: (id: string) => void;
}

export function PaperManagerView({ papers, selectedPaperId, onSelectPaper }: PaperManagerViewProps) {
  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-900 text-zinc-100 overflow-y-auto p-4 space-y-4">
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Scroll className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-zinc-100">
              Media & Substrate Profile Manager
            </h2>
            <div className="text-xs text-zinc-400">
              Calibrated absorption rates, Total Area Coverage (TAC), Dmax, and substrate Lab white points
            </div>
          </div>
        </div>

        <span className="text-xs font-mono text-zinc-400">
          Loaded Substrates: <strong className="text-zinc-200">{papers.length}</strong>
        </span>
      </div>

      {/* Grid of Papers */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {papers.map(p => {
          const isSelected = p.paper_id === selectedPaperId;
          return (
            <div
              key={p.paper_id}
              onClick={() => onSelectPaper(p.paper_id)}
              className={`p-4 rounded-lg border transition-all cursor-pointer flex flex-col justify-between space-y-3 ${
                isSelected
                  ? 'bg-zinc-950 border-amber-500/60 shadow-[0_0_15px_rgba(245,158,11,0.15)]'
                  : 'bg-zinc-950/70 border-zinc-800 hover:border-zinc-700'
              }`}
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-sm text-zinc-100">{p.name}</h3>
                    {isSelected && (
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold">
                        ACTIVE SUBSTRATE
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-zinc-400 mt-1">{p.finish}</p>
                </div>
                <span className="text-xs font-mono font-bold text-emerald-400">
                  ${p.cost_per_sqm.toFixed(2)}/m²
                </span>
              </div>

              {/* Physical Spec Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono bg-zinc-900/80 p-3 rounded border border-zinc-800/80">
                <div>
                  <span className="text-zinc-500 text-[10px] block">GRAMMAGE</span>
                  <span className="text-zinc-200 font-bold">{p.weight_gsm} gsm</span>
                </div>
                <div>
                  <span className="text-zinc-500 text-[10px] block">THICKNESS</span>
                  <span className="text-zinc-200 font-bold">{p.thickness_mm} mm</span>
                </div>
                <div>
                  <span className="text-zinc-500 text-[10px] block">DMAX</span>
                  <span className="text-amber-400 font-bold">{p.black_point_dmax}</span>
                </div>
                <div>
                  <span className="text-zinc-500 text-[10px] block">MAX TAC</span>
                  <span className="text-zinc-200 font-bold">{p.maximum_ink_load_tac}%</span>
                </div>
              </div>

              {/* Lab White & Archival Rating */}
              <div className="flex items-center justify-between text-[11px] font-mono text-zinc-400 pt-1">
                <span>
                  Paper White: L*{p.paper_white_lab[0]} a*{p.paper_white_lab[1]} b*{p.paper_white_lab[2]}
                </span>
                <span className="text-emerald-400 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" /> {p.archival_rating_years}+ Yrs Archival
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
