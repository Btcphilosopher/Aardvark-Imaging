'use client';

import React, { useState } from 'react';
import { 
  Layers, 
  Eye, 
  Sliders, 
  AlertTriangle, 
  Sun, 
  Sparkles, 
  ZoomIn, 
  Check, 
  ShieldAlert,
  HelpCircle
} from 'lucide-react';
import { PrintJob, PaperProfile, RenderingIntent } from '@/lib/engine/types';

interface SoftProofViewProps {
  job: PrintJob;
  paper: PaperProfile;
  onUpdateJob: (updated: Partial<PrintJob>) => void;
}

export function SoftProofView({ job, paper, onUpdateJob }: SoftProofViewProps) {
  const [sliderPos, setSliderPos] = useState<number>(50);
  const [simulatePaperWhite, setSimulatePaperWhite] = useState<boolean>(true);
  const [simulateBlackInk, setSimulateBlackInk] = useState<boolean>(true);
  const [showGamutWarning, setShowGamutWarning] = useState<boolean>(false);
  const [showDeltaEHeatmap, setShowDeltaEHeatmap] = useState<boolean>(false);
  const [illuminant, setIlluminant] = useState<string>('D50');
  const [zoomLevel, setZoomLevel] = useState<number>(100);

  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-900 text-zinc-100 overflow-y-auto p-4 space-y-4">
      {/* Control Header */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-zinc-100">
              Soft Proof Simulation Studio
            </h2>
            <div className="text-xs text-zinc-400">
              Predicting output on <span className="text-amber-400 font-semibold">{paper.name}</span> under {illuminant} illuminant
            </div>
          </div>
        </div>

        {/* Toggles Strip */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Paper White Toggle */}
          <button
            onClick={() => setSimulatePaperWhite(!simulatePaperWhite)}
            className={`px-3 py-1.5 rounded text-xs font-semibold flex items-center gap-1.5 transition-all ${
              simulatePaperWhite
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'bg-zinc-900 text-zinc-400 hover:text-zinc-200 border border-zinc-800'
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${simulatePaperWhite ? 'bg-amber-400' : 'bg-zinc-600'}`} />
            <span>Simulate Paper White (L* {paper.paper_white_lab[0]})</span>
          </button>

          {/* Black Ink Toggle */}
          <button
            onClick={() => setSimulateBlackInk(!simulateBlackInk)}
            className={`px-3 py-1.5 rounded text-xs font-semibold flex items-center gap-1.5 transition-all ${
              simulateBlackInk
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'bg-zinc-900 text-zinc-400 hover:text-zinc-200 border border-zinc-800'
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${simulateBlackInk ? 'bg-amber-400' : 'bg-zinc-600'}`} />
            <span>Simulate Black Ink (Dmax {paper.black_point_dmax})</span>
          </button>

          {/* Gamut Warning Mask */}
          <button
            onClick={() => {
              setShowGamutWarning(!showGamutWarning);
              if (!showGamutWarning) setShowDeltaEHeatmap(false);
            }}
            className={`px-3 py-1.5 rounded text-xs font-semibold flex items-center gap-1.5 transition-all ${
              showGamutWarning
                ? 'bg-red-500/20 text-red-300 border border-red-500/40'
                : 'bg-zinc-900 text-zinc-400 hover:text-zinc-200 border border-zinc-800'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
            <span>Gamut Warning Mask</span>
          </button>

          {/* Delta E Heatmap */}
          <button
            onClick={() => {
              setShowDeltaEHeatmap(!showDeltaEHeatmap);
              if (!showDeltaEHeatmap) setShowGamutWarning(false);
            }}
            className={`px-3 py-1.5 rounded text-xs font-semibold flex items-center gap-1.5 transition-all ${
              showDeltaEHeatmap
                ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                : 'bg-zinc-900 text-zinc-400 hover:text-zinc-200 border border-zinc-800'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span>ΔE₀₀ Heatmap</span>
          </button>
        </div>
      </div>

      {/* Main Interactive Split Comparison Canvas */}
      <div className="flex-1 bg-zinc-950 border border-zinc-800 rounded-lg p-4 flex flex-col justify-between relative overflow-hidden">
        {/* Top Floating Indicators */}
        <div className="flex items-center justify-between pb-2 text-xs font-mono text-zinc-400 border-b border-zinc-800/80">
          <div className="flex items-center gap-2">
            <span className="text-zinc-500 font-bold uppercase">Source Working Space:</span>
            <span className="text-zinc-200">{job.source_colour_space}</span>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-zinc-500">Illuminant:</span>
              <select
                value={illuminant}
                onChange={e => setIlluminant(e.target.value)}
                className="bg-zinc-900 border border-zinc-700 rounded px-2 py-0.5 text-xs text-zinc-200"
              >
                <option value="D50">ISO 3664 D50 (Standard Lightbox)</option>
                <option value="D65">CIE D65 (Noon Daylight)</option>
                <option value="A">Illuminant A (2856K Incandescent)</option>
                <option value="GALLERY_3000K">Gallery Halogen 3000K</option>
              </select>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-zinc-500">Intent:</span>
              <select
                value={job.render_intent}
                onChange={e => onUpdateJob({ render_intent: e.target.value as RenderingIntent })}
                className="bg-zinc-900 border border-zinc-700 rounded px-2 py-0.5 text-xs text-zinc-200"
              >
                <option value="RELATIVE_COLORIMETRIC">Relative Colorimetric</option>
                <option value="PERCEPTUAL">Perceptual</option>
                <option value="ABSOLUTE_COLORIMETRIC">Absolute Colorimetric</option>
              </select>
            </div>
          </div>
        </div>

        {/* Split Image Canvas Area */}
        <div className="relative my-4 flex-1 flex items-center justify-center select-none overflow-hidden min-h-[420px]">
          {/* Main Visual Frame */}
          <div 
            className="relative w-full max-w-4xl h-[400px] border border-zinc-700 rounded shadow-2xl overflow-hidden cursor-ew-resize"
            onMouseMove={e => {
              const rect = e.currentTarget.getBoundingClientRect();
              const x = Math.max(0, Math.min(rect.width, e.clientX - rect.left));
              setSliderPos(Math.round((x / rect.width) * 100));
            }}
          >
            {/* Left Layer: Original Source Image */}
            <div 
              className="absolute inset-0 bg-cover bg-center filter contrast-105"
              style={{ backgroundImage: `url(${job.source_image.uri})` }}
            >
              <div className="absolute top-3 left-3 bg-black/75 backdrop-blur-sm text-zinc-200 text-xs px-2.5 py-1 rounded font-mono font-semibold border border-white/10">
                ORIGINAL SOURCE ({job.source_colour_space})
              </div>
            </div>

            {/* Right Layer: Soft-Proofed Image with Substrate White & Ink Limits */}
            <div 
              className="absolute inset-0 overflow-hidden"
              style={{ clipPath: `polygon(${sliderPos}% 0, 100% 0, 100% 100%, ${sliderPos}% 100%)` }}
            >
              <div 
                className="absolute inset-0 bg-cover bg-center transition-all"
                style={{
                  backgroundImage: `url(${job.source_image.uri})`,
                  filter: `${simulatePaperWhite ? 'sepia(0.08) brightness(0.97)' : ''} ${
                    simulateBlackInk ? 'contrast(0.92)' : ''
                  }`,
                }}
              >
                {/* Gamut Warning Mask Overlay */}
                {showGamutWarning && (
                  <div className="absolute inset-0 pointer-events-none mix-blend-screen opacity-70 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-red-600/40 via-transparent to-transparent">
                    <div className="absolute bottom-10 right-10 p-2 bg-red-950/90 text-red-300 text-xs font-mono rounded border border-red-500">
                      Out of Paper Gamut (OOG): 4.8% Area Clipped
                    </div>
                  </div>
                )}

                {/* Delta E Heatmap Overlay */}
                {showDeltaEHeatmap && (
                  <div className="absolute inset-0 pointer-events-none mix-blend-color-dodge opacity-60 bg-gradient-to-tr from-purple-800/50 via-cyan-600/30 to-emerald-600/20">
                    <div className="absolute bottom-10 right-10 p-2 bg-purple-950/90 text-purple-300 text-xs font-mono rounded border border-purple-500">
                      Peak ΔE₀₀: 2.15 in Deep Shadow Transitions
                    </div>
                  </div>
                )}

                <div className="absolute top-3 right-3 bg-amber-950/80 backdrop-blur-sm text-amber-300 text-xs px-2.5 py-1 rounded font-mono font-semibold border border-amber-500/30">
                  PROOF: {paper.name} ({job.render_intent})
                </div>
              </div>
            </div>

            {/* Split Slider Divider Line */}
            <div 
              className="absolute top-0 bottom-0 w-1 bg-amber-400 shadow-[0_0_12px_rgba(245,158,11,0.8)] z-10"
              style={{ left: `${sliderPos}%` }}
            >
              <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-7 h-7 bg-amber-500 rounded-full border-2 border-zinc-950 flex items-center justify-center text-zinc-950 font-bold text-xs shadow-md">
                ↔
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Metrics Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 pt-3 border-t border-zinc-800 text-xs font-mono">
          <div className="bg-zinc-900/60 p-2 rounded border border-zinc-800">
            <span className="text-zinc-500 block text-[10px]">SUBSTRATE WHITE POINT</span>
            <span className="text-zinc-200 font-semibold">
              L* {paper.paper_white_lab[0]} a* {paper.paper_white_lab[1]} b* {paper.paper_white_lab[2]}
            </span>
          </div>
          <div className="bg-zinc-900/60 p-2 rounded border border-zinc-800">
            <span className="text-zinc-500 block text-[10px]">MAX OPTICAL DENSITY</span>
            <span className="text-amber-400 font-semibold">{paper.black_point_dmax} Dmax</span>
          </div>
          <div className="bg-zinc-900/60 p-2 rounded border border-zinc-800">
            <span className="text-zinc-500 block text-[10px]">OUT-OF-GAMUT PIXELS</span>
            <span className="text-emerald-400 font-semibold">4.8% (Graceful Soft Shoulder)</span>
          </div>
          <div className="bg-zinc-900/60 p-2 rounded border border-zinc-800">
            <span className="text-zinc-500 block text-[10px]">PREDICTED MEAN ΔE₀₀</span>
            <span className="text-zinc-200 font-semibold">0.68 (Imperceptible Shift)</span>
          </div>
        </div>
      </div>
    </div>
  );
}
