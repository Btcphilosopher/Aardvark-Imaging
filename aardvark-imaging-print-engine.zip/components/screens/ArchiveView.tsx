'use client';

import React from 'react';
import { Archive, ShieldCheck, Lock, Check, Copy, History } from 'lucide-react';
import { INITIAL_PRINT_JOBS } from '@/lib/engine/mock-data';

export function ArchiveView() {
  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-900 text-zinc-100 overflow-y-auto p-4 space-y-4">
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Archive className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-zinc-100">
              Immutable Reproduction Archive & Audit Vault
            </h2>
            <div className="text-xs text-zinc-400">
              Section 39 Archival: Cryptographic hashes guarantee bit-exact physical print reproducibility
            </div>
          </div>
        </div>

        <span className="text-xs font-mono text-emerald-400 font-semibold flex items-center gap-1">
          <ShieldCheck className="w-4 h-4" /> Cryptographically Sealed
        </span>
      </div>

      <div className="space-y-3">
        {INITIAL_PRINT_JOBS.map(job => (
          <div key={job.job_id} className="bg-zinc-950 border border-zinc-800 rounded-lg p-4 space-y-3 font-mono text-xs">
            <div className="flex items-center justify-between border-b border-zinc-850 pb-2">
              <div className="flex items-center gap-2">
                <Lock className="w-4 h-4 text-amber-400" />
                <span className="font-bold text-sm text-zinc-100">{job.job_id}</span>
                <span className="text-zinc-500">•</span>
                <span className="text-zinc-300">{job.source_image.metadata.title}</span>
              </div>
              <span className="text-[11px] text-zinc-400">{job.created_at}</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-zinc-300">
              <div className="bg-zinc-900/60 p-2.5 rounded border border-zinc-850">
                <span className="text-zinc-500 text-[10px] block">SOURCE IMAGE SHA-256</span>
                <span className="text-zinc-300 text-[10px] break-all">{job.source_image.metadata.hash}</span>
              </div>
              <div className="bg-zinc-900/60 p-2.5 rounded border border-zinc-850">
                <span className="text-zinc-500 text-[10px] block">ICC MEDIA PROFILE</span>
                <span className="text-amber-400 font-bold">{job.target_profile}</span>
                <span className="text-zinc-500 text-[10px] block mt-1">D50 PCS Relative Colorimetric BPC</span>
              </div>
              <div className="bg-zinc-900/60 p-2.5 rounded border border-zinc-850">
                <span className="text-zinc-500 text-[10px] block">AUTHORIZED OPERATOR</span>
                <span className="text-zinc-200 font-bold">{job.operator}</span>
                <span className="text-emerald-400 text-[10px] block mt-1">Certified Master Printer</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-1 text-[11px] text-zinc-400">
              <span>Halftoning: {job.halftone_method} • Substrate: {job.target_media}</span>
              <button className="px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 text-xs font-semibold">
                Export Audit Certificate (JSON)
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
