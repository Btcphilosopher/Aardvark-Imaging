'use client';

import React from 'react';
import { Boxes, AlertTriangle, Check, Package, Layers } from 'lucide-react';
import { INITIAL_INVENTORY } from '@/lib/engine/costing-inventory';

export function InventoryView() {
  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-900 text-zinc-100 overflow-y-auto p-4 space-y-4">
      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Boxes className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-zinc-100">
              Media, Ink & Consumables Warehouse Inventory
            </h2>
            <div className="text-xs text-zinc-400">
              Tracking paper rolls, 700ml cartridges, spare MicroPiezo heads, and maintenance boxes
            </div>
          </div>
        </div>

        <span className="text-xs font-mono text-zinc-400">
          Tracked SKUs: <strong className="text-zinc-200">{INITIAL_INVENTORY.length}</strong>
        </span>
      </div>

      <div className="bg-zinc-950 border border-zinc-800 rounded-lg overflow-hidden">
        <table className="w-full text-left text-xs font-mono">
          <thead className="bg-zinc-900 text-zinc-500 border-b border-zinc-800 text-[10px] uppercase">
            <tr>
              <th className="p-3">SKU</th>
              <th className="p-3">Category</th>
              <th className="p-3">Item Description</th>
              <th className="p-3">Quantity</th>
              <th className="p-3">Unit Cost</th>
              <th className="p-3">Location Bin</th>
              <th className="p-3">Lot Number</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-850">
            {INITIAL_INVENTORY.map(item => (
              <tr key={item.sku} className="hover:bg-zinc-900/50">
                <td className="p-3 font-bold text-amber-400">{item.sku}</td>
                <td className="p-3 text-zinc-400">{item.category}</td>
                <td className="p-3 text-zinc-200 font-semibold">{item.name}</td>
                <td className="p-3">
                  <span className="font-bold text-emerald-400">{item.quantity}</span> {item.unit}
                </td>
                <td className="p-3 text-zinc-300">${item.unit_cost.toFixed(2)}</td>
                <td className="p-3 text-zinc-400">{item.location}</td>
                <td className="p-3 text-zinc-500">{item.lot_number}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
