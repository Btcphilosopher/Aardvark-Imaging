'use client';

import React, { useState, useEffect } from 'react';
import { 
  X, 
  Play, 
  Pause, 
  CheckCircle2, 
  ArrowRight, 
  Sparkles, 
  ShieldCheck, 
  Cpu,
  Printer,
  Scroll,
  FileCheck
} from 'lucide-react';
import { DEMO_WORKFLOW_STEPS, WorkflowStepDefinition } from '@/lib/engine/workflow';
import { PrintJob, PaperProfile } from '@/lib/engine/types';

interface DemoWorkflowModalProps {
  isOpen: boolean;
  onClose: () => void;
  job: PrintJob;
  paper: PaperProfile;
}

export function DemoWorkflowModal({ isOpen, onClose, job, paper }: DemoWorkflowModalProps) {
  if (!isOpen) return null;
  return <DemoWorkflowModalContent onClose={onClose} job={job} paper={paper} />;
}

function DemoWorkflowModalContent({ onClose, job, paper }: { onClose: () => void; job: PrintJob; paper: PaperProfile }) {
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);

  const isFinished = currentStepIndex >= DEMO_WORKFLOW_STEPS.length;
  const isRunning = isPlaying && !isFinished;

  useEffect(() => {
    if (!isPlaying || currentStepIndex >= DEMO_WORKFLOW_STEPS.length) return;

    const timer = setTimeout(() => {
      setCompletedSteps(prev => [...prev, currentStepIndex]);
      setCurrentStepIndex(prev => prev + 1);
    }, 500); // 500ms per step

    return () => clearTimeout(timer);
  }, [isPlaying, currentStepIndex]);

  const currentStep = DEMO_WORKFLOW_STEPS[Math.min(currentStepIndex, DEMO_WORKFLOW_STEPS.length - 1)];

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-zinc-950 border border-zinc-800 rounded-xl max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden font-mono text-xs">
        {/* Modal Top Header */}
        <div className="p-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/60">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold uppercase tracking-wider text-zinc-100">
                  Aardvark Demonstration Workflow (Section 68)
                </h2>
                <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                  22 STEPS
                </span>
              </div>
              <p className="text-[11px] text-zinc-400">
                End-to-end industrial prepress, RIP, screening, physical simulation & archival
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Live Progress Bar */}
        <div className="px-5 pt-4">
          <div className="flex justify-between items-center mb-1 text-[11px] text-zinc-400">
            <span>
              Progress: <strong className="text-amber-400">{Math.min(currentStepIndex, 22)} of 22</strong> Steps Executed
            </span>
            <span className="text-emerald-400 font-bold">
              {Math.round((Math.min(currentStepIndex, 22) / 22) * 100)}% Complete
            </span>
          </div>
          <div className="h-2 w-full bg-zinc-900 rounded-full overflow-hidden border border-zinc-800">
            <div
              className="h-full bg-gradient-to-r from-amber-500 to-emerald-500 transition-all duration-300 rounded-full"
              style={{ width: `${(Math.min(currentStepIndex, 22) / 22) * 100}%` }}
            />
          </div>
        </div>

        {/* Middle: Active Step Spotlight Box */}
        <div className="p-5 flex-1 overflow-y-auto space-y-4">
          <div className="bg-zinc-900/80 border border-zinc-800 rounded-lg p-4 flex flex-col space-y-2">
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-amber-400 font-bold uppercase tracking-wider">
                CURRENT PHASE: {currentStep.phase}
              </span>
              <span className="text-zinc-500">STEP {currentStep.stepNumber} / 22</span>
            </div>
            <h3 className="text-sm font-bold text-zinc-100">{currentStep.name}</h3>
            <p className="text-zinc-400 text-xs leading-relaxed">{currentStep.description}</p>
          </div>

          {/* List of all 22 steps */}
          <div className="space-y-1.5 max-h-[320px] overflow-y-auto pr-2">
            {DEMO_WORKFLOW_STEPS.map((step, idx) => {
              const isDone = completedSteps.includes(idx);
              const isCurrent = currentStepIndex === idx;

              return (
                <div
                  key={step.stepNumber}
                  className={`p-2 rounded flex items-center justify-between border transition-all ${
                    isCurrent
                      ? 'bg-amber-500/10 border-amber-500/40 text-amber-200 font-semibold'
                      : isDone
                      ? 'bg-zinc-950/60 border-zinc-850 text-zinc-400'
                      : 'bg-zinc-950/30 border-transparent text-zinc-600'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className={`w-5 text-right font-bold ${isCurrent ? 'text-amber-400' : 'text-zinc-500'}`}>
                      {step.stepNumber}.
                    </span>
                    <span className={isCurrent ? 'text-zinc-100 font-bold' : isDone ? 'text-zinc-300' : ''}>
                      {step.name}
                    </span>
                  </div>

                  <div>
                    {isDone ? (
                      <span className="text-emerald-400 flex items-center gap-1 text-[10px] font-bold">
                        <CheckCircle2 className="w-3.5 h-3.5" /> DONE
                      </span>
                    ) : isCurrent ? (
                      <span className="text-amber-400 text-[10px] font-bold animate-pulse">
                        EXECUTING...
                      </span>
                    ) : (
                      <span className="text-zinc-700 text-[10px]">PENDING</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Modal Bottom Controls */}
        <div className="p-4 border-t border-zinc-800 flex items-center justify-between bg-zinc-900/60">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="px-3 py-1.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-semibold border border-zinc-700 flex items-center gap-1.5"
            >
              {isPlaying && !isFinished ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>{isPlaying && !isFinished ? 'Pause' : 'Resume'}</span>
            </button>
            <button
              onClick={() => {
                setCurrentStepIndex(0);
                setCompletedSteps([]);
                setIsPlaying(true);
              }}
              className="px-3 py-1.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-semibold border border-zinc-700"
            >
              Restart
            </button>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold shadow"
          >
            {currentStepIndex >= 22 ? 'Finished & View Dashboard' : 'Close Runner'}
          </button>
        </div>
      </div>
    </div>
  );
}
