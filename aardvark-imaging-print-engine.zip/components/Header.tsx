'use client';

import React from 'react';
import { 
  Printer, 
  Activity, 
  Play, 
  ShieldCheck, 
  Cpu, 
  Sliders, 
  CheckCircle2, 
  AlertTriangle,
  Flame,
  FileCode2
} from 'lucide-react';
import { Screen } from '@/lib/engine/types';

interface HeaderProps {
  currentScreen: Screen;
  onSelectScreen: (screen: Screen) => void;
  onRunDemoWorkflow: () => void;
  isDemoRunning: boolean;
  activeJobId: string;
}

export function Header({
  currentScreen,
  onSelectScreen,
  onRunDemoWorkflow,
  isDemoRunning,
  activeJobId,
}: HeaderProps) {
  return (
    <header className="h-14 border-b border-zinc-800 bg-zinc-950 px-4 flex items-center justify-between select-none shrink-0 z-30">
      {/* Brand & Identity */}
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded bg-gradient-to-br from-amber-500 to-orange-700 flex items-center justify-center font-bold text-zinc-950 shadow-md">
          <Printer className="w-5 h-5 text-black" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="font-extrabold tracking-wider text-sm text-zinc-100 uppercase">
              AARDVARK IMAGING PRINT ENGINE
            </span>
            <span className="text-[10px] px-1.5 py-0.5 rounded font-mono bg-zinc-800 text-amber-400 border border-amber-500/30">
              v4.8.2-PRO
            </span>
          </div>
          <div className="text-[10px] font-mono text-zinc-400 flex items-center gap-2">
            <span>DIGITAL IMAGE → PHYSICAL PRINT</span>
            <span className="text-zinc-600">•</span>
            <span className="text-emerald-400 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              PROPRINT 600 ONLINE
            </span>
          </div>
        </div>
      </div>

      {/* Center Live Telemetry Strip */}
      <div className="hidden xl:flex items-center gap-6 font-mono text-xs text-zinc-300 bg-zinc-900/80 px-3 py-1.5 rounded border border-zinc-800">
        <div className="flex items-center gap-2">
          <span className="text-zinc-500 text-[10px] uppercase">Active Job:</span>
          <span className="text-amber-300 font-semibold">{activeJobId}</span>
        </div>
        <div className="w-px h-3 bg-zinc-800" />
        <div className="flex items-center gap-2">
          <span className="text-zinc-500 text-[10px] uppercase">Head Temp:</span>
          <span className="text-zinc-200">38.4°C</span>
        </div>
        <div className="w-px h-3 bg-zinc-800" />
        <div className="flex items-center gap-2">
          <span className="text-zinc-500 text-[10px] uppercase">Platen Vac:</span>
          <span className="text-cyan-400">-1.8 kPa</span>
        </div>
        <div className="w-px h-3 bg-zinc-800" />
        <div className="flex items-center gap-2">
          <span className="text-zinc-500 text-[10px] uppercase">ISO QC:</span>
          <span className="text-emerald-400 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" /> PASS (ΔE 0.72)
          </span>
        </div>
      </div>

      {/* Right Actions */}
      <div className="flex items-center gap-2">
        <button
          onClick={onRunDemoWorkflow}
          disabled={isDemoRunning}
          className={`flex items-center gap-2 px-3 py-1.5 rounded text-xs font-semibold transition-all shadow-sm ${
            isDemoRunning
              ? 'bg-amber-600/30 text-amber-300 border border-amber-500/40 cursor-wait'
              : 'bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-zinc-950 font-bold border border-amber-400/40'
          }`}
          title="Run canonical 22-step industrial print workflow (Section 68)"
        >
          <Play className={`w-3.5 h-3.5 fill-current ${isDemoRunning ? 'animate-spin' : ''}`} />
          <span>{isDemoRunning ? 'Executing 22-Step Workflow...' : 'Run 22-Step Workflow'}</span>
        </button>

        <button
          onClick={() => onSelectScreen('DigitalTwin')}
          className="p-1.5 rounded bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-800 text-xs flex items-center gap-1.5"
          title="Open Digital Twin Simulator"
        >
          <Cpu className="w-4 h-4 text-cyan-400" />
          <span className="hidden sm:inline font-mono">Twin</span>
        </button>

        <a
          href="/api/openapi"
          target="_blank"
          rel="noopener noreferrer"
          className="p-1.5 rounded bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200 border border-zinc-800 text-xs flex items-center gap-1.5"
          title="OpenAPI Spec"
        >
          <FileCode2 className="w-4 h-4 text-amber-400" />
          <span className="hidden sm:inline font-mono">API</span>
        </a>
      </div>
    </header>
  );
}
