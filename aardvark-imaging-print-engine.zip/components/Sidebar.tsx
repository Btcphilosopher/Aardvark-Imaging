'use client';

import React from 'react';
import {
  Sliders,
  ListOrdered,
  Eye,
  Layers,
  Palette,
  Printer,
  Scroll,
  Droplets,
  Cpu,
  Gauge,
  Sparkles,
  ShieldCheck,
  Boxes,
  Calculator,
  Archive,
  Bot,
  Settings as SettingsIcon,
} from 'lucide-react';
import { Screen } from '@/lib/engine/types';

interface SidebarProps {
  currentScreen: Screen;
  onSelectScreen: (screen: Screen) => void;
  queueCount: number;
}

interface NavItem {
  id: Screen;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string | number;
}

interface NavSection {
  title: string;
  items: NavItem[];
}

export function Sidebar({ currentScreen, onSelectScreen, queueCount }: SidebarProps) {
  const sections: NavSection[] = [
    {
      title: 'Core Production',
      items: [
        { id: 'PrintCommandCentre', label: 'Command Centre', icon: Sliders },
        { id: 'JobQueue', label: 'Job Queue', icon: ListOrdered, badge: queueCount },
        { id: 'ImageInspector', label: 'Image Inspector', icon: Eye },
        { id: 'SoftProof', label: 'Soft Proof Studio', icon: Layers },
      ],
    },
    {
      title: 'Prepress & Colour',
      items: [
        { id: 'ColourManagement', label: 'ICC & Gamut Engine', icon: Palette },
        { id: 'RIPMonitor', label: '14-Stage RIP', icon: Cpu },
        { id: 'Calibration', label: 'Linearization & Calib', icon: Sparkles },
      ],
    },
    {
      title: 'Hardware & Media',
      items: [
        { id: 'PrinterManager', label: 'Fleet Printers', icon: Printer },
        { id: 'PaperManager', label: 'Media Profiles', icon: Scroll },
        { id: 'InkManager', label: '12-Channel Inks', icon: Droplets },
        { id: 'DigitalTwin', label: 'Hardware Digital Twin', icon: Bot },
      ],
    },
    {
      title: 'Assurance & Operations',
      items: [
        { id: 'QualityControl', label: 'Spectro QC (ISO)', icon: ShieldCheck },
        { id: 'ProductionMonitor', label: 'Production Telemetry', icon: Gauge },
        { id: 'Costing', label: 'Costing & Yields', icon: Calculator },
        { id: 'Inventory', label: 'Stock & Inventory', icon: Boxes },
        { id: 'Archive', label: 'Job Archive & Audit', icon: Archive },
        { id: 'Settings', label: 'System Settings', icon: SettingsIcon },
      ],
    },
  ];

  return (
    <aside className="w-64 bg-zinc-950 border-r border-zinc-800 flex flex-col shrink-0 select-none overflow-y-auto">
      <div className="p-3 space-y-5 text-xs">
        {sections.map(section => (
          <div key={section.title}>
            <div className="text-[10px] font-mono uppercase tracking-wider text-zinc-500 px-2 mb-1.5 font-bold">
              {section.title}
            </div>
            <div className="space-y-0.5">
              {section.items.map(item => {
                const Icon = item.icon;
                const isActive = currentScreen === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onSelectScreen(item.id)}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded transition-all ${
                      isActive
                        ? 'bg-amber-500/15 text-amber-300 font-semibold border border-amber-500/30'
                        : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/60'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon
                        className={`w-4 h-4 ${
                          isActive ? 'text-amber-400' : 'text-zinc-500'
                        }`}
                      />
                      <span>{item.label}</span>
                    </div>
                    {item.badge !== undefined && (
                      <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-zinc-800 text-zinc-300 border border-zinc-700">
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-auto p-3 border-t border-zinc-900 bg-zinc-950/80 text-[11px] font-mono text-zinc-500">
        <div className="flex items-center justify-between">
          <span>Engine State:</span>
          <span className="text-emerald-400 font-medium">READY</span>
        </div>
        <div className="flex items-center justify-between mt-1">
          <span>Target Lab:</span>
          <span className="text-zinc-400">D50 2° Observer</span>
        </div>
        <div className="flex items-center justify-between mt-1">
          <span>Memory:</span>
          <span className="text-zinc-400">512MB / 4096MB</span>
        </div>
      </div>
    </aside>
  );
}
