"""
AARDVARK IMAGING PRINT ENGINE
Canonical Data Models (Section 4 Specification)
"""

from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional, Tuple, Any
from pydantic import BaseModel, Field

class JobStatus(str, Enum):
    DRAFT = "DRAFT"
    VALIDATING = "VALIDATING"
    PROOFING = "PROOFING"
    RIPPING = "RIPPING"
    QUEUED = "QUEUED"
    PRINTING = "PRINTING"
    FINISHING = "FINISHING"
    QC = "QC"
    COMPLETE = "COMPLETE"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"
    ARCHIVED = "ARCHIVED"

class RenderingIntent(str, Enum):
    PERCEPTUAL = "PERCEPTUAL"
    RELATIVE_COLORIMETRIC = "RELATIVE_COLORIMETRIC"
    ABSOLUTE_COLORIMETRIC = "ABSOLUTE_COLORIMETRIC"
    SATURATION = "SATURATION"

class ColourSpace(str, Enum):
    SRGB = "sRGB"
    ADOBE_RGB = "AdobeRGB_1998"
    DISPLAY_P3 = "Display_P3"
    PROPHOTO_RGB = "ProPhoto_RGB"
    REC2020 = "Rec2020"
    REC709 = "Rec709"
    CIE_XYZ = "CIE_XYZ"
    CIE_LAB = "CIE_Lab"
    CUSTOM_ICC = "Custom_ICC"

class HalftoneMethod(str, Enum):
    ERROR_DIFFUSION_FLOYD_STEINBERG = "ERROR_DIFFUSION_FLOYD_STEINBERG"
    ERROR_DIFFUSION_JARVIS = "ERROR_DIFFUSION_JARVIS"
    ORDERED_BAYER_8X8 = "ORDERED_BAYER_8X8"
    BLUE_NOISE_STOCHASTIC = "BLUE_NOISE_STOCHASTIC"
    CLUSTERED_DOT_AM = "CLUSTERED_DOT_AM"

class ImageMetadata(BaseModel):
    title: str
    creator: str
    copyright: str
    capture_device: str
    lens: Optional[str] = None
    focal_length: Optional[str] = None
    aperture: Optional[str] = None
    shutter_speed: Optional[str] = None
    iso: Optional[int] = None
    capture_date: Optional[str] = None
    source_colour_space: ColourSpace
    bit_depth: int = 16
    native_width: int
    native_height: int
    icc_profile_name: str
    hash: str

class SourceImage(BaseModel):
    uri: str
    filename: str
    width_px: int
    height_px: int
    metadata: ImageMetadata

class PrintDimensions(BaseModel):
    width_mm: float
    height_mm: float
    width_inches: float
    height_inches: float
    orientation: str = "LANDSCAPE"

class EstimatedCost(BaseModel):
    ink: float
    paper: float
    energy: float
    depreciation: float
    maintenance: float
    labour: float
    waste: float
    total: float

class PrintJob(BaseModel):
    """Canonical PrintJob Model matching Section 4 specification"""
    job_id: str
    source_image: SourceImage
    source_colour_space: ColourSpace
    source_bit_depth: int
    source_resolution: int = 300
    target_printer: str
    target_media: str
    target_profile: str
    target_dimensions: PrintDimensions
    orientation: str = "LANDSCAPE"
    scale: float = 1.0
    crop: Dict[str, int]
    bleed_mm: float = 3.0
    margins_mm: Dict[str, float]
    border_mm: float = 0.0
    layout: str = "SINGLE"
    render_intent: RenderingIntent = RenderingIntent.RELATIVE_COLORIMETRIC
    black_point_compensation: bool = True
    output_resolution: int = 2880
    ink_configuration: List[str]
    ink_limits: Dict[str, Any]
    halftone_method: HalftoneMethod = HalftoneMethod.BLUE_NOISE_STOCHASTIC
    dither_method: str = "Multi-Drop FM3"
    sharpening: Dict[str, Any]
    tone_mapping: Dict[str, float]
    quality_mode: str = "FINE_ART_2880"
    copies: int = 1
    priority: str = "NORMAL"
    estimated_ink: float = 0.0
    estimated_media: float = 0.0
    estimated_time: float = 0.0
    estimated_cost: EstimatedCost
    status: JobStatus = JobStatus.DRAFT
    created_at: datetime = Field(default_factory=datetime.utcnow)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    operator: str = "Chief Colorist"
    quality_result: Optional[Dict[str, Any]] = None
