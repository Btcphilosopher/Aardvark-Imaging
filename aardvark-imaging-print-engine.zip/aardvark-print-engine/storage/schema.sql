-- ==========================================================
-- AARDVARK IMAGING PRINT ENGINE
-- PostgreSQL Production Schema (Section 57 Specification)
-- 19 Canonical Tables with Strict Constraints & Audit Trails
-- ==========================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Images
CREATE TABLE images (
    image_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    filename VARCHAR(255) NOT NULL,
    storage_path TEXT NOT NULL,
    file_size_bytes BIGINT NOT NULL,
    width_px INT NOT NULL,
    height_px INT NOT NULL,
    source_colour_space VARCHAR(64) NOT NULL,
    source_bit_depth INT NOT NULL CHECK (source_bit_depth IN (8, 10, 12, 14, 16, 32)),
    sha256_hash CHAR(64) NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. Image Versions (Edits, Cropping, Softproof Masters)
CREATE TABLE image_versions (
    version_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    image_id UUID NOT NULL REFERENCES images(image_id) ON DELETE RESTRICT,
    version_label VARCHAR(128) NOT NULL,
    derivative_path TEXT NOT NULL,
    transform_matrix JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. Inks
CREATE TABLE inks (
    ink_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sku VARCHAR(64) NOT NULL UNIQUE,
    manufacturer VARCHAR(128) NOT NULL,
    name VARCHAR(128) NOT NULL,
    technology VARCHAR(64) NOT NULL,
    cost_per_ml NUMERIC(10, 4) NOT NULL,
    cartridge_capacity_ml INT NOT NULL
);

-- 4. Ink Profiles
CREATE TABLE ink_profiles (
    ink_profile_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(128) NOT NULL,
    channels JSONB NOT NULL, -- ['C', 'M', 'Y', 'PK', 'MK', 'LC', 'LM', 'LK', 'LLK', 'OR', 'GR', 'V', 'CO']
    droplet_size_min_pl NUMERIC(6, 2) NOT NULL,
    droplet_size_max_pl NUMERIC(6, 2) NOT NULL,
    lightfastness_years INT NOT NULL
);

-- 5. Papers
CREATE TABLE papers (
    paper_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sku VARCHAR(64) NOT NULL UNIQUE,
    manufacturer VARCHAR(128) NOT NULL,
    name VARCHAR(128) NOT NULL,
    finish VARCHAR(64) NOT NULL,
    weight_gsm NUMERIC(8, 2) NOT NULL,
    thickness_mm NUMERIC(6, 3) NOT NULL,
    cost_per_sqm NUMERIC(10, 2) NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE
);

-- 6. Paper Profiles
CREATE TABLE paper_profiles (
    paper_profile_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    paper_id UUID NOT NULL REFERENCES papers(paper_id) ON DELETE CASCADE,
    whiteness_cie NUMERIC(6, 2) NOT NULL,
    opacity_percent NUMERIC(5, 2) NOT NULL,
    paper_white_lab JSONB NOT NULL,
    black_point_dmax NUMERIC(4, 2) NOT NULL,
    maximum_ink_load_tac INT NOT NULL,
    drying_time_minutes INT NOT NULL
);

-- 7. Printers
CREATE TABLE printers (
    printer_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code VARCHAR(64) NOT NULL UNIQUE,
    manufacturer VARCHAR(128) NOT NULL,
    model VARCHAR(128) NOT NULL,
    technology VARCHAR(64) NOT NULL,
    max_width_mm NUMERIC(8, 2) NOT NULL,
    max_resolution_dpi JSONB NOT NULL,
    ip_address INET,
    status VARCHAR(32) NOT NULL DEFAULT 'ONLINE'
);

-- 8. Printer Profiles
CREATE TABLE printer_profiles (
    printer_profile_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    printer_id UUID NOT NULL REFERENCES printers(printer_id) ON DELETE CASCADE,
    head_type VARCHAR(128) NOT NULL,
    channels_count INT NOT NULL,
    feed_calibration_skew NUMERIC(6, 4) DEFAULT 0.0
);

-- 9. Colour Profiles (ICC Engine)
CREATE TABLE colour_profiles (
    profile_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(128) NOT NULL,
    device_class VARCHAR(32) NOT NULL,
    media_substrate VARCHAR(128) NOT NULL,
    illuminant VARCHAR(16) NOT NULL DEFAULT 'D50',
    white_point JSONB NOT NULL,
    gamut_volume_units INT NOT NULL,
    icc_binary_path TEXT NOT NULL,
    sha256_hash CHAR(64) NOT NULL
);

-- 10. Operators
CREATE TABLE operators (
    operator_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    full_name VARCHAR(128) NOT NULL,
    badge_number VARCHAR(32) NOT NULL UNIQUE,
    role VARCHAR(64) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE
);

-- 11. Production Batches
CREATE TABLE production_batches (
    batch_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    batch_code VARCHAR(64) NOT NULL UNIQUE,
    priority VARCHAR(32) NOT NULL DEFAULT 'NORMAL',
    target_dispatch_date TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 12. Print Jobs
CREATE TABLE print_jobs (
    job_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_code VARCHAR(64) NOT NULL UNIQUE,
    image_id UUID NOT NULL REFERENCES images(image_id),
    printer_id UUID NOT NULL REFERENCES printers(printer_id),
    paper_id UUID NOT NULL REFERENCES papers(paper_id),
    colour_profile_id UUID NOT NULL REFERENCES colour_profiles(profile_id),
    operator_id UUID REFERENCES operators(operator_id),
    batch_id UUID REFERENCES production_batches(batch_id),
    target_dimensions_mm JSONB NOT NULL,
    margins_mm JSONB NOT NULL,
    bleed_mm NUMERIC(4, 1) NOT NULL DEFAULT 3.0,
    render_intent VARCHAR(32) NOT NULL,
    black_point_compensation BOOLEAN NOT NULL DEFAULT TRUE,
    halftone_method VARCHAR(64) NOT NULL,
    output_resolution_dpi INT NOT NULL,
    copies INT NOT NULL DEFAULT 1,
    estimated_cost_total NUMERIC(10, 2) NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'DRAFT',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ
);

-- 13. Raster Jobs (RIP Engine Output)
CREATE TABLE raster_jobs (
    raster_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_id UUID NOT NULL REFERENCES print_jobs(job_id) ON DELETE CASCADE,
    bands_count INT NOT NULL,
    raster_byte_size BIGINT NOT NULL,
    peak_memory_mb NUMERIC(8, 2) NOT NULL,
    processing_time_ms INT NOT NULL,
    storage_uri TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 14. Calibrations
CREATE TABLE calibrations (
    calibration_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    printer_id UUID NOT NULL REFERENCES printers(printer_id),
    paper_id UUID NOT NULL REFERENCES papers(paper_id),
    linearization_curve JSONB NOT NULL,
    density_response JSONB NOT NULL,
    performed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 15. Measurements
CREATE TABLE measurements (
    measurement_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    device_name VARCHAR(128) NOT NULL,
    illuminant VARCHAR(16) NOT NULL DEFAULT 'D50',
    spectral_data JSONB,
    lab_values JSONB NOT NULL,
    measured_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 16. QC Results
CREATE TABLE qc_results (
    qc_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_id UUID NOT NULL REFERENCES print_jobs(job_id),
    status VARCHAR(16) NOT NULL CHECK (status IN ('PASS', 'WARNING', 'FAIL')),
    mean_delta_e_2000 NUMERIC(5, 3) NOT NULL,
    max_delta_e_2000 NUMERIC(5, 3) NOT NULL,
    percentile_95_delta_e NUMERIC(5, 3) NOT NULL,
    density_neutrality_score NUMERIC(5, 2) NOT NULL,
    inspector_id UUID REFERENCES operators(operator_id),
    evaluated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 17. Inventory
CREATE TABLE inventory (
    inventory_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sku VARCHAR(64) NOT NULL UNIQUE,
    item_name VARCHAR(255) NOT NULL,
    category VARCHAR(64) NOT NULL,
    quantity_on_hand INT NOT NULL DEFAULT 0,
    reorder_level INT NOT NULL DEFAULT 5,
    unit_cost NUMERIC(10, 2) NOT NULL,
    location_bin VARCHAR(64)
);

-- 18. Maintenance
CREATE TABLE maintenance (
    maintenance_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    printer_id UUID NOT NULL REFERENCES printers(printer_id),
    action_type VARCHAR(64) NOT NULL,
    details TEXT,
    head_cleaning_cycles INT DEFAULT 1,
    nozzles_compensated INT DEFAULT 0,
    logged_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 19. Audit Events (Immutable Reproducibility Log - Section 58)
CREATE TABLE audit_events (
    event_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_id UUID REFERENCES print_jobs(job_id),
    event_type VARCHAR(64) NOT NULL,
    payload JSONB NOT NULL,
    source_hash CHAR(64),
    output_hash CHAR(64),
    software_version VARCHAR(32) NOT NULL,
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
