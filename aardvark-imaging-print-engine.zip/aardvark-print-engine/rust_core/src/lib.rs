//! AARDVARK IMAGING PRINT ENGINE
//! Rust High-Performance RIP Core
//! Tiled rasterisation, 16-bit colour transformation, and parallel multi-channel screening

pub struct ImageTile<'a> {
    pub x: usize,
    pub y: usize,
    pub width: usize,
    pub height: usize,
    pub channels: usize,
    pub data: &'a [f32],
}

pub struct RasterBand {
    pub band_index: usize,
    pub height: usize,
    pub width: usize,
    pub binary_dots: Vec<u8>,
}

/// Floyd-Steinberg error diffusion with serpentine scanning for continuous tone ink channels
pub fn dither_channel_serpentine(
    input: &[f32],
    width: usize,
    height: usize,
    output: &mut [u8],
) {
    let mut err_buffer = input.to_vec();

    for y in 0..height {
        let is_reverse = y % 2 == 1;
        if is_reverse {
            for x in (0..width).rev() {
                let idx = y * width + x;
                let val = err_buffer[idx];
                let out_val = if val >= 0.5 { 1u8 } else { 0u8 };
                output[idx] = out_val;
                let err = val - (out_val as f32);

                if x > 0 {
                    err_buffer[idx - 1] += err * (7.0 / 16.0);
                }
                if y + 1 < height {
                    if x + 1 < width {
                        err_buffer[(y + 1) * width + (x + 1)] += err * (3.0 / 16.0);
                    }
                    err_buffer[(y + 1) * width + x] += err * (5.0 / 16.0);
                    if x > 0 {
                        err_buffer[(y + 1) * width + (x - 1)] += err * (1.0 / 16.0);
                    }
                }
            }
        } else {
            for x in 0..width {
                let idx = y * width + x;
                let val = err_buffer[idx];
                let out_val = if val >= 0.5 { 1u8 } else { 0u8 };
                output[idx] = out_val;
                let err = val - (out_val as f32);

                if x + 1 < width {
                    err_buffer[idx + 1] += err * (7.0 / 16.0);
                }
                if y + 1 < height {
                    if x > 0 {
                        err_buffer[(y + 1) * width + (x - 1)] += err * (3.0 / 16.0);
                    }
                    err_buffer[(y + 1) * width + x] += err * (5.0 / 16.0);
                    if x + 1 < width {
                        err_buffer[(y + 1) * width + (x + 1)] += err * (1.0 / 16.0);
                    }
                }
            }
        }
    }
}
