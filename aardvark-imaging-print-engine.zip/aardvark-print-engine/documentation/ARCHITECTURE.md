# AARDVARK IMAGING PRINT ENGINE
## Production-Grade Digital Imaging & Print Production System

### 1. Fundamental Principle
$$\text{PIXEL} \longrightarrow \text{COLOUR} \longrightarrow \text{INK} \longrightarrow \text{DOT} \longrightarrow \text{PAPER} \longrightarrow \text{PHYSICAL IMAGE}$$

The system makes every transformation explicit and auditable:
- **Source Colour**: Input RGB/RAW encoded in working space (e.g. ProPhoto RGB, Adobe RGB 1998, Rec.2020).
- **Display Colour**: Calibrated monitor preview space via GPU LUT.
- **Proof Colour**: Simulated print appearance factoring in substrate white point, $D_{\max}$, and gamut mapping.
- **Device Colour**: Multi-channel ink plane amounts ($C, M, Y, PK/MK, LC, LM, LK, LLK, OR, GR, V, CO$).
- **Physical Print**: Microdot dot placement on physical paper fibers evaluated via spectrophotometric $\Delta E_{00}$ analysis.

### 2. 14-Stage Real RIP Architecture
1. **Parse**: Header metadata, EXIF, IPTC, embedded ICC profiles, SHA-256 integrity verification.
2. **Colour Convert**: Transformation from source colour space to PCS (Profile Connection Space CIE $L^*a^*b^*$ D50) using Bradford chromatic adaptation.
3. **Scale**: Precision resampling using Lanczos-3 windowed sinc or Catmull-Rom bicubic interpolation.
4. **Crop**: Geometry alignment, trim box, and symmetric reflection bleed synthesis.
5. **Rotate**: Aligning image orientation with the physical platen travel and carriage traverse direction.
6. **Sharpen**: Output sharpening calibrated specifically to media fiber absorption and target print DPI.
7. **Tone**: Black Point Compensation (BPC) and tonal remapping based on substrate $D_{\max}$.
8. **Gamut Map**: Perceptual soft shoulder compression or Relative Colorimetric clipping.
9. **Ink Separation**: 12-channel separation using GCR (Gray Component Replacement) and dynamic gamut-expansion inks.
10. **Ink Limiting**: Enforcing substrate Total Area Coverage (TAC) to eliminate pooling and bronzing.
11. **Halftoning**: Error diffusion (Floyd-Steinberg), blue-noise stochastic screening, or clustered-dot AM screening.
12. **Rasterisation**: Converting continuous-tone planes into binary piezoelectric nozzle firing maps.
13. **Banding**: Dividing into physical scanline bands for multi-pass microweaving printhead passes.
14. **Printer Output**: Direct spooling to Aardvark ProPrint 600 or network print farm engines.

### 3. Standards Compliance
- **ISO 12647-7**: Digital proofing and production certification tolerances ($\Delta E_{00} \le 1.5$ average, $\le 3.0$ peak).
- **ISO 13655**: Spectral measurement and colorimetric computation.
- **ICC.1:2010**: Profile specification and PCS alignment.
- **CIEDE2000**: Color difference metric including lightness, chroma, and hue weighting with rotation factor $R_T$.
