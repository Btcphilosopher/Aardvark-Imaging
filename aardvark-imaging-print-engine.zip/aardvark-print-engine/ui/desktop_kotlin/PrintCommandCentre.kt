package org.aardvark.imaging.ui

/**
 * AARDVARK IMAGING PRINT ENGINE
 * Professional Kotlin Desktop UI Suite (Compose for Desktop)
 * Section 52 Specification
 */

enum class Screen {
    PrintCommandCentre,
    JobQueue,
    ImageInspector,
    SoftProof,
    ColourManagement,
    PrinterManager,
    PaperManager,
    InkManager,
    RIPMonitor,
    ProductionMonitor,
    Calibration,
    QualityControl,
    Inventory,
    Costing,
    Archive,
    DigitalTwin,
    Settings
}

data class SystemState(
    val activeScreen: Screen = Screen.PrintCommandCentre,
    val selectedJobId: String? = "JOB-2026-0842-EXH",
    val activePrinterId: String = "PRN-ARD-600",
    val isSoftProofActive: Boolean = true,
    val isGamutWarningVisible: Boolean = false,
    val isBpcEnabled: Boolean = true,
    val zoomLevelPercent: Int = 100,
    val currentDpi: Int = 2880,
    val operatorName: String = "Chief Colorist K. Vance"
)

class PrintCommandCentreViewModel {
    var state = SystemState()
        private set

    fun selectScreen(screen: Screen) {
        state = state.copy(activeScreen = screen)
    }

    fun triggerWorkflowDemo() {
        // Runs the 22-step industrial print engineering workflow
    }

    fun toggleGamutWarning() {
        state = state.copy(isGamutWarningVisible = !state.isGamutWarningVisible)
    }

    fun toggleSoftProof() {
        state = state.copy(isSoftProofActive = !state.isSoftProofActive)
    }
}
