'use client';

import React, { useState } from 'react';
import { Screen, PrintJob, PaperProfile } from '@/lib/engine/types';
import { 
  INITIAL_PRINT_JOBS, 
  PAPER_PROFILES, 
  AARDVARK_PROPRINT_600, 
  CHROMAPURE_INK_SET 
} from '@/lib/engine/mock-data';
import { Header } from '@/components/Header';
import { Sidebar } from '@/components/Sidebar';
import { PrintCommandCentreView } from '@/components/screens/PrintCommandCentreView';
import { JobQueueView } from '@/components/screens/JobQueueView';
import { ImageInspectorView } from '@/components/screens/ImageInspectorView';
import { SoftProofView } from '@/components/screens/SoftProofView';
import { ColourManagementView } from '@/components/screens/ColourManagementView';
import { PrinterManagerView } from '@/components/screens/PrinterManagerView';
import { PaperManagerView } from '@/components/screens/PaperManagerView';
import { InkManagerView } from '@/components/screens/InkManagerView';
import { RipMonitorView } from '@/components/screens/RipMonitorView';
import { ProductionMonitorView } from '@/components/screens/ProductionMonitorView';
import { CalibrationView } from '@/components/screens/CalibrationView';
import { QualityControlView } from '@/components/screens/QualityControlView';
import { InventoryView } from '@/components/screens/InventoryView';
import { CostingView } from '@/components/screens/CostingView';
import { ArchiveView } from '@/components/screens/ArchiveView';
import { DigitalTwinView } from '@/components/screens/DigitalTwinView';
import { SettingsView } from '@/components/screens/SettingsView';
import { DemoWorkflowModal } from '@/components/DemoWorkflowModal';

export default function AppPage() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('PrintCommandCentre');
  const [jobsList, setJobsList] = useState<PrintJob[]>(INITIAL_PRINT_JOBS);
  const [activeJobId, setActiveJobId] = useState<string>(INITIAL_PRINT_JOBS[0].job_id);
  const [papersList] = useState<PaperProfile[]>(PAPER_PROFILES);
  const [selectedPaperId, setSelectedPaperId] = useState<string>(INITIAL_PRINT_JOBS[0].target_media);
  const [isDemoModalOpen, setIsDemoModalOpen] = useState<boolean>(false);
  const [isDemoRunning, setIsDemoRunning] = useState<boolean>(false);
  const [workflowStep, setWorkflowStep] = useState<number>(1);

  const activeJob = jobsList.find(j => j.job_id === activeJobId) || jobsList[0];
  const activePaper = papersList.find(p => p.paper_id === selectedPaperId) || papersList[0];

  const handleUpdateJob = (updated: Partial<PrintJob>) => {
    setJobsList(prev =>
      prev.map(j => (j.job_id === activeJob.job_id ? { ...j, ...updated } : j))
    );
  };

  const handleSelectPaper = (paperId: string) => {
    setSelectedPaperId(paperId);
    handleUpdateJob({ target_media: paperId });
  };

  const handleRunDemoWorkflow = () => {
    setIsDemoModalOpen(true);
  };

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-zinc-950 text-zinc-100 select-none">
      {/* Top Application Header */}
      <Header
        currentScreen={currentScreen}
        onSelectScreen={setCurrentScreen}
        onRunDemoWorkflow={handleRunDemoWorkflow}
        isDemoRunning={isDemoRunning}
        activeJobId={activeJob.job_id}
      />

      {/* Main Studio Body: Sidebar + Active Screen Workspace */}
      <div className="flex flex-1 overflow-hidden">
        <Sidebar
          currentScreen={currentScreen}
          onSelectScreen={setCurrentScreen}
          queueCount={jobsList.length}
        />

        <main className="flex-1 flex flex-col overflow-hidden bg-zinc-900">
          {currentScreen === 'PrintCommandCentre' && (
            <PrintCommandCentreView
              job={activeJob}
              paper={activePaper}
              papersList={papersList}
              onUpdateJob={handleUpdateJob}
              onSelectPaper={handleSelectPaper}
              onRunWorkflow={handleRunDemoWorkflow}
              onNavigateToScreen={setCurrentScreen}
              isWorkflowRunning={isDemoRunning}
              workflowStep={workflowStep}
            />
          )}

          {currentScreen === 'JobQueue' && (
            <JobQueueView
              jobs={jobsList}
              onSelectJob={id => {
                setActiveJobId(id);
                setCurrentScreen('PrintCommandCentre');
              }}
              selectedJobId={activeJobId}
            />
          )}

          {currentScreen === 'ImageInspector' && (
            <ImageInspectorView job={activeJob} />
          )}

          {currentScreen === 'SoftProof' && (
            <SoftProofView
              job={activeJob}
              paper={activePaper}
              onUpdateJob={handleUpdateJob}
            />
          )}

          {currentScreen === 'ColourManagement' && (
            <ColourManagementView />
          )}

          {currentScreen === 'RIPMonitor' && (
            <RipMonitorView job={activeJob} paper={activePaper} />
          )}

          {currentScreen === 'Calibration' && (
            <CalibrationView />
          )}

          {currentScreen === 'PrinterManager' && (
            <PrinterManagerView currentPrinter={AARDVARK_PROPRINT_600} />
          )}

          {currentScreen === 'PaperManager' && (
            <PaperManagerView
              papers={papersList}
              selectedPaperId={selectedPaperId}
              onSelectPaper={handleSelectPaper}
            />
          )}

          {currentScreen === 'InkManager' && (
            <InkManagerView />
          )}

          {currentScreen === 'DigitalTwin' && (
            <DigitalTwinView printer={AARDVARK_PROPRINT_600} />
          )}

          {currentScreen === 'QualityControl' && (
            <QualityControlView jobId={activeJob.job_id} />
          )}

          {currentScreen === 'ProductionMonitor' && (
            <ProductionMonitorView />
          )}

          {currentScreen === 'Costing' && (
            <CostingView
              job={activeJob}
              paper={activePaper}
              ink={CHROMAPURE_INK_SET}
              printer={AARDVARK_PROPRINT_600}
            />
          )}

          {currentScreen === 'Inventory' && (
            <InventoryView />
          )}

          {currentScreen === 'Archive' && (
            <ArchiveView />
          )}

          {currentScreen === 'Settings' && (
            <SettingsView />
          )}
        </main>
      </div>

      {/* 22-Step Demonstration Workflow Modal */}
      <DemoWorkflowModal
        isOpen={isDemoModalOpen}
        onClose={() => setIsDemoModalOpen(false)}
        job={activeJob}
        paper={activePaper}
      />
    </div>
  );
}
