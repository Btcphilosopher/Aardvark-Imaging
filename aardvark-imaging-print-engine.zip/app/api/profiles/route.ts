import { NextResponse } from 'next/server';
import { ICC_PROFILES } from '@/lib/engine/mock-data';

export async function GET() {
  return NextResponse.json({
    total: ICC_PROFILES.length,
    profiles: ICC_PROFILES,
  });
}
