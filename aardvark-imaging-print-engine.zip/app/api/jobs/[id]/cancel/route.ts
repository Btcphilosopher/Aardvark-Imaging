import { NextRequest, NextResponse } from 'next/server';

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  return NextResponse.json({
    job_id: id,
    status: 'CANCELLED',
    message: 'Job cancelled by operator. Print head parked and capped.',
    cancelled_at: new Date().toISOString(),
  });
}
