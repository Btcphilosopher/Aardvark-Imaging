import { NextRequest, NextResponse } from 'next/server';
import { INITIAL_PRINT_JOBS } from '@/lib/engine/mock-data';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const job = INITIAL_PRINT_JOBS.find(j => j.job_id === id);

  if (!job) {
    return NextResponse.json({ error: `Job ${id} not found` }, { status: 404 });
  }

  return NextResponse.json(job);
}
