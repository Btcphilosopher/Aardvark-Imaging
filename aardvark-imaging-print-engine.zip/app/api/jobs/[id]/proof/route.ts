import { NextRequest, NextResponse } from 'next/server';
import { INITIAL_PRINT_JOBS, PAPER_PROFILES } from '@/lib/engine/mock-data';
import { softProofPixel } from '@/lib/engine/soft-proof';

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await req.json().catch(() => ({}));
  const job = INITIAL_PRINT_JOBS.find(j => j.job_id === id) || INITIAL_PRINT_JOBS[0];
  const paper = PAPER_PROFILES.find(p => p.paper_id === (body.paper_id || job.target_media)) || PAPER_PROFILES[0];

  // Test critical sample patches under soft proofing
  const sampleTestRgb: [number, number, number][] = [
    [255, 255, 255], // white
    [0, 0, 0],       // black
    [230, 40, 30],   // vivid red
    [30, 180, 50],   // green
    [20, 80, 240],   // deep cyan/blue
    [245, 200, 30],  // yellow
    [180, 140, 110], // skin
  ];

  const patchResults = sampleTestRgb.map(rgb =>
    softProofPixel(rgb[0], rgb[1], rgb[2], {
      paper,
      intent: body.intent || job.render_intent,
      simulatePaperWhite: body.simulatePaperWhite ?? true,
      simulateBlackInk: body.simulateBlackInk ?? true,
      blackPointCompensation: body.blackPointCompensation ?? true,
      sourceColourSpace: job.source_colour_space,
      monitorColourSpace: 'sRGB',
    })
  );

  return NextResponse.json({
    job_id: id,
    paper: paper.name,
    paper_white_lab: paper.paper_white_lab,
    black_point_dmax: paper.black_point_dmax,
    intent: body.intent || job.render_intent,
    sampled_patches: patchResults,
  });
}
