import { NextRequest, NextResponse } from 'next/server';
import { INITIAL_PRINT_JOBS } from '@/lib/engine/mock-data';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const job = INITIAL_PRINT_JOBS.find(j => j.job_id === id);

  return NextResponse.json({
    job_id: id,
    status: job ? job.status : 'UNKNOWN',
    rip_progress: job?.status === 'PRINTING' ? 100 : 0,
    print_progress: job?.status === 'COMPLETE' ? 100 : 45,
    timestamp: new Date().toISOString(),
  });
}
