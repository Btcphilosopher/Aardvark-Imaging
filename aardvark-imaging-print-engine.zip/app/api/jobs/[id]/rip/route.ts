import { NextRequest, NextResponse } from 'next/server';
import { INITIAL_PRINT_JOBS, PAPER_PROFILES, CHROMAPURE_INK_SET } from '@/lib/engine/mock-data';
import { executeRipPipeline } from '@/lib/engine/rip-engine';

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const job = INITIAL_PRINT_JOBS.find(j => j.job_id === id) || INITIAL_PRINT_JOBS[0];
  const paper = PAPER_PROFILES.find(p => p.paper_id === job.target_media) || PAPER_PROFILES[0];

  const ripResult = executeRipPipeline(job, paper, CHROMAPURE_INK_SET);

  return NextResponse.json({
    job_id: id,
    status: 'RIPPED',
    result: ripResult,
  });
}
