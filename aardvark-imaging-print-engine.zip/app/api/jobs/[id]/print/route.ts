import { NextRequest, NextResponse } from 'next/server';

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  return NextResponse.json({
    job_id: id,
    status: 'PRINTING',
    spooler: 'Aardvark Spooler Daemon v4.8',
    message: 'Raster stream dispatched to print head driver. Vacuum platen engaged.',
    dispatched_at: new Date().toISOString(),
  });
}
