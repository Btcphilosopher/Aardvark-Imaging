import { NextRequest, NextResponse } from 'next/server';
import { INITIAL_PRINT_JOBS } from '@/lib/engine/mock-data';
import { PrintJob } from '@/lib/engine/types';

// In-memory job repository for demo session
let jobsStore: PrintJob[] = [...INITIAL_PRINT_JOBS];

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const status = searchParams.get('status');

  let filtered = jobsStore;
  if (status) {
    filtered = jobsStore.filter(j => j.status === status);
  }

  return NextResponse.json({
    total: filtered.length,
    jobs: filtered,
  });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const newJob: PrintJob = {
      ...body,
      job_id: body.job_id || `JOB-${Date.now().toString(36).toUpperCase()}`,
      status: 'DRAFT',
      created_at: new Date().toISOString(),
      copies: body.copies || 1,
      priority: body.priority || 'NORMAL',
    };

    jobsStore.unshift(newJob);
    return NextResponse.json(newJob, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: 'Invalid print job payload', details: err.message }, { status: 400 });
  }
}
