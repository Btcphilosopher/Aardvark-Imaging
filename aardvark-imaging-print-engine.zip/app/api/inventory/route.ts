import { NextResponse } from 'next/server';
import { INITIAL_INVENTORY } from '@/lib/engine/costing-inventory';

export async function GET() {
  return NextResponse.json({
    total: INITIAL_INVENTORY.length,
    inventory: INITIAL_INVENTORY,
  });
}
