import { NextResponse } from 'next/server';
import { PAPER_PROFILES } from '@/lib/engine/mock-data';

export async function GET() {
  return NextResponse.json({
    total: PAPER_PROFILES.length,
    papers: PAPER_PROFILES,
  });
}
