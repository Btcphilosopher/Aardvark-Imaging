import { NextRequest, NextResponse } from 'next/server';
import { evaluatePrintQuality } from '@/lib/engine/spectrophotometer-qc';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const jobId = searchParams.get('job_id') || 'JOB-2026-0842-EXH';
  const quality = (searchParams.get('level') || 'EXCELLENT') as any;

  const result = evaluatePrintQuality(jobId, 'Automated QC Spectro 1', quality);
  return NextResponse.json(result);
}
