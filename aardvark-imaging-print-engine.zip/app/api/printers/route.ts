import { NextResponse } from 'next/server';
import { PRINTER_FLEET } from '@/lib/engine/mock-data';

export async function GET() {
  return NextResponse.json({
    total: PRINTER_FLEET.length,
    printers: PRINTER_FLEET,
  });
}
