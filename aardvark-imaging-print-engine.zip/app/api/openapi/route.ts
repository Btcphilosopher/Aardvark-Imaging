import { NextResponse } from 'next/server';

export async function GET() {
  const openApiSpec = {
    openapi: '3.1.0',
    info: {
      title: 'Aardvark Imaging Print Engine Automation API',
      version: '1.0.0',
      description: 'Industrial-grade automation interface for digital imaging, RIP, multi-channel halftoning, print queue, and spectrophotometric QC.',
      contact: {
        name: 'Aardvark Imaging Systems Prepress Engineering',
        email: 'prepress@aardvark-imaging.internal',
      },
    },
    servers: [{ url: '/api', description: 'Production Print Engine Local Daemon' }],
    paths: {
      '/jobs': {
        get: { summary: 'List all queued and completed print jobs' },
        post: { summary: 'Submit a new Canonical PrintJob to the engine' },
      },
      '/jobs/{id}': {
        get: { summary: 'Retrieve full specification of a PrintJob' },
      },
      '/jobs/{id}/proof': {
        post: { summary: 'Execute high-precision soft proofing simulation' },
      },
      '/jobs/{id}/rip': {
        post: { summary: 'Trigger 14-stage RIP rasterisation and multi-channel screening' },
      },
      '/jobs/{id}/print': {
        post: { summary: 'Dispatch rasterized bands to printer physical driver' },
      },
      '/jobs/{id}/cancel': {
        post: { summary: 'Cancel printing and park print head carriage' },
      },
      '/jobs/{id}/status': {
        get: { summary: 'Poll real-time hardware telemetry and job progress' },
      },
      '/printers': {
        get: { summary: 'List connected fleet printers and driver statuses' },
      },
      '/papers': {
        get: { summary: 'Query physical media profiles, TAC limits, and absorption rates' },
      },
      '/profiles': {
        get: { summary: 'List calibrated ICC device and media profiles' },
      },
      '/inventory': {
        get: { summary: 'Query media rolls, pigment cartridges, and maintenance tanks' },
      },
      '/qc': {
        get: { summary: 'Retrieve spectrophotometric certification report & Delta E 2000 metrics' },
      },
      '/calibration': {
        post: { summary: 'Perform 12-channel linearization curve calibration' },
      },
      '/measurements': {
        post: { summary: 'Record single patch or full chart spectrophotometer spectral measurement' },
      },
    },
  };

  return NextResponse.json(openApiSpec);
}
