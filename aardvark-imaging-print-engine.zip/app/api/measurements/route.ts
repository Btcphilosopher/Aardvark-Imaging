import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const patchId = body.patch_id || 'PATCH-A1';

  return NextResponse.json({
    measurement_id: `MSR-${Date.now().toString(36).toUpperCase()}`,
    patch_id: patchId,
    device: body.device || 'X-Rite i1Pro3 Spectrophotometer (M1 Illumination)',
    illuminant: 'D50',
    observer: '2_DEGREE',
    spectral_reflectance_380_730nm: Array.from({ length: 36 }, (_, i) => Math.round((0.15 + 0.7 * Math.sin(i / 6)) * 1000) / 1000),
    cie_lab: [62.4, 18.2, 41.5],
    cie_xyz: [35.2, 31.0, 12.8],
    optical_density: 1.84,
    timestamp: new Date().toISOString(),
  });
}
