import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Aardvark Imaging Print Engine',
  description: 'Production-grade professional printing software platform: Colour Management, RIP, Multi-channel Ink Separation, Halftoning, Printer Digital Twin & Quality Assurance.',
  openGraph: {
    title: 'Aardvark Imaging Print Engine',
    description: 'Production-grade professional printing software platform: Colour Management, RIP, Multi-channel Ink Separation, Halftoning, Printer Digital Twin & Quality Assurance.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Aardvark Imaging Print Engine',
    description: 'Production-grade professional printing software platform: Colour Management, RIP, Multi-channel Ink Separation, Halftoning, Printer Digital Twin & Quality Assurance.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
